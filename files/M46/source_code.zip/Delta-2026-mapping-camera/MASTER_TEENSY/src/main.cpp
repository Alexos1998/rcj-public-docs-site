// #include <Arduino.h>
// #include <Camera.h>
// CAMERA openMV = CAMERA();
// void setup() {
//   openMV.init(2);
//   Serial.begin(115200);
//   Serial.println("I can't hit my proteinnnnn");
// }

// void loop() {
//   Serial.println("I can't hit my proteinnnnn");
//   //String line = Serial2.readStringUntil('7');
//   Serial.println(openMV.read_camera());
//   delay(100);
// }

#include <math.h>
#include <Arduino.h>
#include <string.h>
#include <vector>
#include <time.h>
#include <errno.h>

#include <Config.h>
#include <Bluetooth.h>
#include <Colour_Sensor.h>
#include <Distance_Sensors.h>
#include <IMU.h>
#include <Limit_Switch.h>
#include <Motor_Array.h>
#include <Servo_Motor.h>
#include <PID.h>
#include <Mapping.h>
//#include <Adafruit_NeoPixel.h>


// --------------------------------- Functions ---------------------------------
void movement_forward(int speed);
void movement_forward_corrected(float speed);
void movement_turing(int speed);
void movement_turing_corrected(float base_speed, float multiplier);

void state_finder();
void state_new();
void state_init();
void state_foward();
void state_left();
void state_right();
void state_back();
void state_mapping();
void state_black_tile_detected();
void state_black_tile_move_back();
void state_black_tile_move_return();
void state_black_tile_find_new_tile();
void state_blue_tile();
void state_victim_detected();
void state_victim_functions();

void set_tile_info(bool victim, bool explored, bool black, bool silver, 
  bool blue, bool red, bool obstacle, bool ramp);
    
void victim_led();
void victim_package();

void pivoting_lrf_front();
void pivoting_lrf_back();

void tile_calibration();

void led_on();
void led_off();
void led_flashing(uint16_t speed);

void dropper(int8_t side);

void onTick();

// --------------------------------- enum ---------------------------------
enum state_values { //1 is for movement, 2 for black tile, 3 for blue tile, 4 for victim
  INIT = 100,
  FORWARD = 101,
  LEFT = 102,
  RIGHT = 103,
  BACKWARD = 104,
  MAPPING = 105,
  RAMP = 106,
  BLACK_TILE_DETECTED = 201,
  BLACK_TILE_MOVE_BACK = 202,
  BLACK_TILE_MOVE_RETURN = 203,
  BLACK_TILE_FIND_NEW_TILE = 204,
  BLUE_TILE = 301,
  VICTIM_DETECTED = 401,
  VICTIM_FUNCTIONS = 402
};

enum tile_colours {
  BLACK = 1,
  SILVER = 2,
  BLUE = 3,
  RED = 4
};

// --------------------------------- Variables ---------------------------------
enum state_values current_states = MAPPING;


std::vector<int16_t> past_states = {100}; // should be 105

uint16_t target_distance;
uint16_t* p_target_distance = &target_distance;

uint16_t current_distance;
uint16_t* p_current_distance = &current_distance;

uint16_t average_distance;
uint16_t* p_average_distance =  &average_distance;

uint8_t next_state;
uint8_t* p_next_state = &next_state;

uint8_t turn_backward = 0;
uint8_t* p_turn_backward = &turn_backward;

bool robot_init = false;
bool new_state = false;
bool victim_found = false;
bool black_tile_found = false;
bool blue_tile_found = false;
bool mapping_completed = false;
bool switch_tile = false;
bool lrf_read = false;

uint8_t black_state_data[3] = {0, 0, 0};

enum tile_colours current_colour;

uint32_t timer_start;
uint32_t* p_timer_start = &timer_start;

uint32_t timer_led;
uint32_t* p_timer_led = &timer_led;

uint32_t timer_PID;
uint32_t* p_timer_PID = &timer_PID;

bool led_state = false;

IntervalTimer intTimer;
static volatile uint8_t read_lrf = 0;
static volatile uint8_t read_colour = 0;
static volatile uint8_t read_imu = 0;
static volatile uint8_t read_camera = 0;
static volatile uint8_t print_statements = 0;




// --------------------------------- Sensors ---------------------------------
//Adafruit_NeoPixel neopixel(1, 28, NEO_GRB + NEO_KHZ800);
IMU bno055 = IMU();
Motor_Array motors = Motor_Array();
Distance_Sensors lrf_sensors;
Colour_Sensor colour_sensor;

// Limit_Switch ls_1 = Limit_Switch();
Servo_Motor servo = Servo_Motor();
//Servo_Motor lrf_servo_front = Servo_Motor();
Servo_Motor lrf_servo_back = Servo_Motor();

Mapping maze_map;
PID motor_PID = PID(0.6,0,0.3);

int ledPin = 6;
int buttonPin = 23;


// --------------------------------- Setup ---------------------------------
void setup() {
  Serial.begin(115200);
  Serial.println("i'm here");
  //neopixel.begin();

  lrf_sensors.init();
  motors.init(3,4,2,5);
  // //ls_1.init(7);
  // servo.attach(9, true);
  bno055.init();
  bno055.target_angle(0, true);
  colour_sensor.init();

  //lrf_servo_front.attach(10,false);
  lrf_servo_back.attach(9,false);


  maze_map.init();

  pinMode(ledPin, OUTPUT);
  pinMode(buttonPin, INPUT);

  intTimer.begin(onTick, 5000);  // 5ms ticks
  intTimer.priority(128);
  lrf_sensors.read_array();
}



// --------------------------------- Main Loop ---------------------------------
void loop() {
  //Serial.println("hi");
  // *p_timer_start = millis();
  // neopixel.clear();
  // neopixel.show();
  // pivoting_lrf_front();
  // pivoting_lrf_back();

  if (print_statements) {
    #if GENERAL_PRINTS
    print_statements = 0;

    Serial.print("Current State: "); Serial.println(current_states);
    Serial.print("Current: "); Serial.print(*p_current_distance);  
    Serial.print(" Target: "); Serial.println(*p_target_distance); 
    // Serial.println("i'm here");
    // Serial.print("Compass stuff:\t"); Serial.print(bno055.imu_180());
    // Serial.print("\t"); Serial.println(bno055.imu_off());

    Serial.print(lrf_sensors.side_distance(1)); Serial.print("\t");
    Serial.print(lrf_sensors.side_distance(2)); Serial.print("\t");
    Serial.print(lrf_sensors.side_distance(3)); Serial.print("\t");
    Serial.print(lrf_sensors.side_distance(4)); Serial.println("\t");
    
    Serial.print("sensor_differences_fmod"); Serial.println(lrf_sensors.sensor_differences_fmod(3));
    #endif
  }
  

  // ------------------------------- Read Sensors -------------------------------
  *p_timer_PID = millis();
  
  if (read_lrf) {
    read_lrf = 0;
    lrf_sensors.read_array();
    *p_current_distance = lrf_sensors.side_distance(1);
  }
  if (read_camera) {
    read_camera = 0;
    // camera read here
  }
  if (read_colour) {
    read_colour = 0;
    *p_timer_start = millis();
    Serial.println("COLOUR");
    //noInterrupts();
    colour_sensor.read_sensor();
    //Serial.print("Run time 1: "); Serial.println((millis() - *p_timer_start));
    //interrupts();
    black_tile_found = colour_sensor.colour_checker("BLACK", 0);
    //Serial.print("Run time 2: "); Serial.println((millis() - *p_timer_start));
    colour_sensor.print_values();
    Serial.print("Run time: "); Serial.println((millis() - *p_timer_start));
  }
  if (read_imu) {
    read_imu = 0;
    bno055.imu_value_finder();
  }
  
  
  // ------------------------------- Check State -------------------------------
  state_finder();
  // Serial.println(*p_turn_backward);

  if(new_state) {
    movement_forward(0);
    state_new();
    int32_t counter = 0;

    while(counter < 50) {
      delay(1);
     counter += 1;
    }
  }

  if ((current_states == 101) &&(switch_tile == false) && 
  (lrf_sensors.side_distance(1) <= *p_average_distance)) {
    maze_map.switch_current_tile();
    switch_tile = true;
  }

  // ------------------------------- Run State -------------------------------
  switch (current_states) {
    case 100:
      state_init();
      break;

    case 101: // forward state
      state_foward();
      break;
    
    case 102: // left state
      state_left();
      break;
    
    case 103: // right state
      state_right();
      break;

    case 104: // back state
      state_back();
      break;
    
    case 105: // mapping state
      state_mapping();
      break;

    case 201: // black tile detected
      state_black_tile_detected();
      break;

    case 202: // black tile move back
      state_black_tile_move_back();
      break;

    case 203: // black tile move back
      state_black_tile_move_return();
      break;

    case 204: // black tile find new tile
      state_black_tile_find_new_tile();
      break;

    case 301: // blue tile
      state_blue_tile();
      break;

    case 401: // victim detected
      state_victim_detected();
      break;

    case 402: // victim functions
      state_victim_functions();
      break;

    default:
      break;
  }
  //delay(10);
  // Serial.print("Run time: "); Serial.println((millis() - *p_timer_start));
}




// function definitions:
// ================================== Movement ==================================
void movement_forward(int speed) {
  motors.move(speed, speed);
}


void movement_forward_corrected(float speed) {
  uint16_t current_time = millis();
  //Serial.print("sensor_differences_fmod"); Serial.println(lrf_sensors.sensor_differences_fmod(3));
  float pid_value = motor_PID.pid_value_finder((current_time- *p_timer_PID), 
  (lrf_sensors.sensor_differences_advance(3, (bno055.imu_180())))); // what happens when i can't do this?????
  // Serial.print("PID Value"); Serial.println(pid_value); 
  motors.move_float((speed + pid_value) , (speed - pid_value));

//   if(speed > abs(pid_value)) {
//     motors.move_float((speed + pid_value) , (speed - pid_value));
//   } else {
//     if(pid_value > 0) {
//       motors.move_float((speed + pid_value) , (20.0));
//     } else {
//       motors.move_float((20.0) , (speed - pid_value));
//     }
//   } 
}


void movement_turing(int speed) {
  motors.move(speed, -speed);  
}


void movement_turing_corrected(float base_speed, float multiplier) {
  float multiplier_val = (bno055.imu_off() * multiplier);
  motors.move((base_speed + multiplier_val), -(base_speed + multiplier_val));
}




// ================================== States ==================================
void state_finder(){
  switch (current_states) {
    case 100:
      if(robot_init) {
        current_states = MAPPING;
        new_state = true;
      } break;
    case 101: // forward state
      if (victim_found) {
        current_states = VICTIM_DETECTED;
        new_state = true;

      } else if (black_tile_found) {
        current_states = BLACK_TILE_DETECTED;
        new_state = true;

      } else if (blue_tile_found) {
        current_states = BLUE_TILE;
        new_state = true;

      } else if (*p_current_distance < *p_target_distance) {
        current_states = MAPPING;
        new_state = true;

      } break;
    
    case 102: // left state
      if (victim_found) {
        current_states = VICTIM_DETECTED;
        new_state = true;

      } else if (bno055.imu_off() < 2) {
        current_states = FORWARD;
        new_state = true;

      } break;
    
    case 103: // right state
      if (victim_found) {
        current_states = VICTIM_DETECTED;
        new_state = true;

      } else if (bno055.imu_off() > -2) {
        current_states = FORWARD;
        new_state = true;

      } break;

    case 104: // back state
      if (victim_found) {
        current_states = VICTIM_DETECTED;
        new_state = true;
      } else if ((bno055.imu_off() > -2) && (*p_turn_backward == 1)) {
        // current_states = BACKWARD;
        new_state = true;
      } else if ((bno055.imu_off() > -2) && (*p_turn_backward == 2)) {
        current_states = FORWARD;
        *p_turn_backward = 0;
        new_state = true;

      } break;
    
    case 105: // mapping state
      if (mapping_completed){
        if (*p_next_state == 1) {
          current_states = LEFT;
          new_state = true;

        } else if (*p_next_state == 2) {
          current_states = FORWARD;
          new_state = true;
        } else if (*p_next_state == 3) {
          current_states = RIGHT;
          new_state = true;
        } else {
          current_states = BACKWARD;
          new_state = true;
        }
        mapping_completed = false;
      }
      break;

    case 201: // black tile detected
      if(black_state_data[0] == 1){
        current_states = BLACK_TILE_MOVE_BACK;
        new_state = true;
      }
      break;

    case 202: // black tile move back
      if (*p_current_distance > *p_target_distance) {
        movement_forward(0);
        Serial.print("CONDITION MET"); Serial.print(past_states[0]);Serial.print(past_states[1]);Serial.print(past_states[2]);
        if(past_states[past_states.size() - 3] == 101){
          current_states = BLACK_TILE_FIND_NEW_TILE;
          new_state = true;
        } else {
          if(past_states[past_states.size() - 3] == 102){
            black_state_data[1] = 2;
            current_states = BLACK_TILE_MOVE_RETURN;
            new_state = true;

          } else if (past_states[past_states.size() - 3] == 103) {
            black_state_data[1] = 3;
            current_states = BLACK_TILE_MOVE_RETURN;
            new_state = true;

          } else if (past_states[past_states.size() - 3] == 104) {
            black_state_data[1] = 4;
            current_states = BLACK_TILE_MOVE_RETURN;
            new_state = true;
          }
        }
      }
      break;
    
    case 203: // black tile move return
      if(black_state_data[1] == 2){
        if (bno055.imu_off() < 2) {
        current_states = BLACK_TILE_FIND_NEW_TILE;
        new_state = true;
        } 
      } else if(black_state_data[1] == 3){
        if (bno055.imu_off() > -2) {
        current_states = BLACK_TILE_FIND_NEW_TILE;
        new_state = true;
        }
      } else if(black_state_data[1] == 4){
        if (bno055.imu_off() > -2) {
        current_states = BLACK_TILE_FIND_NEW_TILE;
        new_state = true;
        }
      }
      break;

    case 204: // black tile find new tile
      if(black_state_data[2] == 1) {
        current_states = FORWARD;
        new_state = true;
      } else if(black_state_data[2] == 2) {
        current_states = LEFT;
        new_state = true;
      } else if(black_state_data[2] == 3) {
        current_states = RIGHT;
        new_state = true;
      } else if (black_state_data[2] == 4) {
        current_states = BACKWARD;
        new_state = true;
      }
      break;

    case 301: // blue tile
      if (timer_start > millis()) {
        current_states = MAPPING;
        new_state = true;
      }
      break;

    case 401: // victim detected
      /* code */
      break;

    case 402: // victim functions
      /* code */
      break;

    default:
      break;
  }

} 


void state_new(){
  movement_forward(0);

  if (current_states == 101) { 
    //bool small_wait;

    lrf_read = false;
    int8_t read_counter = 0;
    while (read_counter < 2) {
      while (!lrf_read) {
        if (read_lrf) {
          read_lrf = 0;
          lrf_read = true;
          lrf_sensors.read_array();
          *p_current_distance = lrf_sensors.side_distance(1);
        }
        if (read_camera) {
          read_camera = 0;
          // camera read here
        }
        if (read_colour) {
          read_colour = 0;
          colour_sensor.read_sensor();
          black_tile_found = colour_sensor.colour_checker("BLACK", 0);
        }
        if (read_imu) {
          read_imu = 0;
          bno055.imu_value_finder();
        }
      } 
      lrf_read = false;
      read_counter += 1;
    }
    lrf_read = false;

    *p_current_distance = lrf_sensors.side_distance(1);
    // +++++ How will this change with different distances at front and back)
    // where do i need to move to
    int16_t distance_to_move = (lrf_sensors.fmod_distance(1) + 
    (300 - robot_length)/2 + robot_length); // find how much to move forward
    
    // = (lrf_sensors.fmod_distance(1) + 
    // (300 - robot_length - lrf_sensors.fmod_distance(4)))/2 + ((300 - robot_length)/2); // find how much to move forward

    // target distance
    int16_t target_dis = lrf_sensors.side_distance(1) - distance_to_move;// 150;
    
    if (target_dis < 60) { 
      *p_target_distance = 60;
    } else {
      *p_target_distance = target_dis;
    }
    
    *p_average_distance = ((*p_target_distance + lrf_sensors.side_distance(1))/2);

    // See if the imu needs to be zeroed
    // if (past_states[-1] == 102){
    //   bno055.target_angle(-90)
    // } else if(  past_states[-1] == 103){
    //   bno055.target_angle(90)
    // } else if(  past_states[-1] == 104){
    //   bno055.target_angle(180)
    // }
    past_states.push_back(101);
    new_state = false;
    //lrf_sensors.read_array();
    *p_timer_PID = millis();

  } else if (current_states == 102) {
    bno055.target_angle(-90, false);
    past_states.push_back(102);
    new_state = false;

  } else if (current_states == 103) {
    bno055.target_angle(90, false);
    past_states.push_back(103);
    new_state = false;

  } else if (current_states == 104) {
    bno055.target_angle(90, false);
    if (*p_turn_backward == 0) { past_states.push_back(104); }
    *p_turn_backward += 1;
    new_state = false;

  } else if (current_states == 105) {
    past_states.push_back(105);
    new_state = false;
    // bool input_data[8] = {false};
    // // is there something to the left of the robot
    // if (lrf_sensors.side_distance(1) > 200) {
    //     input_data[0] = true;
    // } 

    // // is there something infront of the robot
    // if (lrf_sensors.side_distance(2) > 200) {
    //     input_data[1] = true;
    // } 

    // // is there something to the right of the robot
    // if (lrf_sensors.side_distance(3) > 200) {
    //     input_data[2] = true;
    // } 

    // // is there something behind the robot
    // if (lrf_sensors.side_distance(4) > 200) {
    //     input_data[3] = true;
    // } 

    // // is the tile black 
    // if(colour_sensor.colour_checker("BLACK", 0.5)) {
    //   input_data[4] = true;
    // }

    // // is the tile sliver 
    // if(colour_sensor.colour_checker("SILVER", 0.5)) {
    //   input_data[5] = true;
    // }

    // // is the tile blue 
    // if(colour_sensor.colour_checker("BLUE", 0.5)) {
    //   input_data[6] = true;
    // }

    // // is the tile red 
    // if(colour_sensor.colour_checker("RED", 0.5)) {
    //   input_data[7] = true;
    // }
    // maze_map.new_tile_found(bno055.imu_180(),input_data[0], input_data[1], input_data[2],
    //   input_data[3],input_data[4],input_data[5],input_data[6],input_data[7]);

  } else if (current_states == 201) {
    black_state_data[0] = 0;
    black_state_data[1] = 0;
    black_state_data[2] = 0;
    past_states.push_back(201);
    new_state = false;

  } else if (current_states == 202) {
    int16_t distance_to_move = (lrf_sensors.fmod_distance(1) + 
    (300 - robot_length)/2 + robot_length); // find how much to move forward

    // target distance
    *p_target_distance = lrf_sensors.side_distance(1) + distance_to_move - 100;
    past_states.push_back(202);
    new_state = false;
    
  } else if (current_states == 203) {
      if (black_state_data[1] == 2) {
      bno055.target_angle(90, false);
      past_states.push_back(203);
      new_state = false; 
      
    } else if (black_state_data[1] == 3) {
      bno055.target_angle(-90, false);
      past_states.push_back(203);
      new_state = false;
    } else if (black_state_data[1] == 4) {
      bno055.target_angle(180, false);
      past_states.push_back(203);
      new_state = false;
    }
  } else if (current_states == 301) {
    *p_timer_start = millis();
    new_state = false; 
  }
}


void state_init(){
  // how will the state be initaliy be found

  robot_init = true;
}


void state_foward(){
  movement_forward_corrected(70);
}


void state_left(){
  movement_turing(-100);
}


void state_right(){
  movement_turing(100);
}


void state_back(){
  movement_turing(50);
}


void state_mapping(){
    uint8_t tile_available[4]= {0};
    int16_t side_distances[4] = {
        lrf_sensors.side_distance(2), 
        lrf_sensors.side_distance(1),
        lrf_sensors.side_distance(3), 
        lrf_sensors.side_distance(4)
    };

    for (uint8_t i = 0; i < 4; i++) {
        if(side_distances[i] > 250) { // may need to be changed
            tile_available[i] = 1;
        }
    }
  
  maze_map.create_tiles(bno055.imu_180(), tile_available);
  
  *p_next_state = maze_map.mapping_alg(bno055.imu_180());
  mapping_completed = true;
  switch_tile = false;
}


void state_black_tile_detected(){
  // where am i / was
  movement_forward(0);
  set_tile_info(false, true, true, false, false, false, false, false);
  black_state_data[0] = 1;
  // where will i be able to think about where to move next
  // how will this effect mapping
}


void state_black_tile_move_back(){
  movement_forward(-50);
  black_state_data[0] = 2;
}


void state_black_tile_move_return(){
  if (black_state_data[1] == 2) {
    movement_turing(25);

  } else if (black_state_data[1] == 3) {
    movement_turing(-25);

  } else if (black_state_data[1] == 4) {
    movement_turing(-25);
  }
}


void state_black_tile_find_new_tile(){
  // mapping - record that you can go there and they go to mapping state
  black_state_data[2] = maze_map.black_tile(bno055.imu_180());
}


void state_blue_tile(){
  movement_forward(0);
}


void state_victim_detected(){

}


void state_victim_functions(){


}




// ================================== Mapping ==================================
void set_tile_info(bool victim, bool explored, bool black, bool silver, 
  bool blue, bool red, bool obstacle, bool ramp) // remove explored
{ 
  uint8_t tile_info = 0;
  bool info_list[8] = {victim, explored, black, silver, blue, red, obstacle, ramp};
  uint8_t bmsk_list[8] = {BMSK_VICTIM, BMSK_EXPLORED, BMSK_BLACK, BMSK_SILVER, 
    BMSK_BLUE, BMSK_RED, BMSK_OBSTACLE, BMSK_RAMP};
  
  for (int8_t i = 0; i < 8; i++)
  {
    if (info_list[i]) {
      tile_info |= bmsk_list[i];
    }
  }
  maze_map.set_current_info(tile_info);
}




// ================================== Lrf servo ==================================
// void pivoting_lrf_front(){
//   lrf_servo_front.write_angle((90-int16_t(bno055.imu_180_y())));
// }


void pivoting_lrf_back(){
  lrf_servo_back.write_angle((90+int16_t(bno055.imu_180_y())));
}




// ================================== Calibration ==================================
void tile_calibration(){
  bool coloured_calibrated; 
  switch (current_colour) {
    case 1: // black
      colour_sensor.change_values("BLACK");
      delay(300);
      if (digitalRead(buttonPin)) {
        coloured_calibrated = true;
      }
      break;
    case 2: // silver
      colour_sensor.change_values("SILVER");
      delay(300);
      if (digitalRead(buttonPin)) {
        coloured_calibrated = true;
      }
      break;
    case 3: // blue
      colour_sensor.change_values("BLUE");
      delay(300);
      if (digitalRead(buttonPin)) {
        coloured_calibrated = true;
      }
      break;
    case 4: // red
      colour_sensor.change_values("RED");
      delay(300);
      if (digitalRead(buttonPin)) {
        coloured_calibrated = true;
      }
      break;

    default:
      break;
}
  
  if (coloured_calibrated) {
      if(current_colour == 1) {
        coloured_calibrated = false;
        current_colour = SILVER;
        //neopixel.Color(255, 255, 0);
       // neopixel.show();

      } else if (current_colour == 2) {
        coloured_calibrated = false;
        current_colour = BLUE;
       // neopixel.Color(0,0, 255);
        //neopixel.show();

      } else if (current_colour == 3) {
        coloured_calibrated = false;
        current_colour = RED;
        //neopixel.Color(255, 0 ,0);
        //neopixel.show();

      } else if (current_colour ==4) {
        coloured_calibrated = false;
        //neopixel.Color(255, 255 , 255);
        //neopixel.show();
      }
  }
}




// ================================== LED ==================================
void led_on(){
  digitalWrite(ledPin, HIGH);
}


void led_off(){
  digitalWrite(ledPin, LOW);
}


void led_flashing(uint16_t speed) {
  float time_between_flash = speed;

  if (timer_led > time_between_flash) {
    if(led_state) {
      led_off();
      led_state = false;
      time_between_flash += speed;
    } else {
      led_on();
      led_state = true;
      time_between_flash += speed;
    }
  }
}




// ================================== Victim ==================================
void dropper(int8_t side) {
  if (side == -1) {
    servo.write_angle(0);
  } else if (side == 1) {
    servo.write_angle(180);
  } else {
    Serial.print("Enter in a Valid Side");
  }
}




// ================================== Timer ==================================
void onTick() {
  static uint32_t ticks = 0;
  ticks++;
  if (ticks == 0)  {} // = true;
  if (ticks == 1)  {read_imu = 1;}
  if (ticks == 2) {read_lrf = 1;}
  if (ticks == 3) {print_statements = 1;}
  if (ticks == 4) {read_lrf = 1;}
  if (ticks == 5) {read_camera = 1;}
  if (ticks == 6) {} // = true;
  if (ticks == 7) {read_imu = 1;}
  if (ticks == 8) {}// read_colour = 1;}
  if (ticks == 9) {}
  if (ticks == 10) {read_imu = 1;}
  if (ticks == 11) // = true;
  if (ticks == 12) {read_lrf = 1;}
  if (ticks == 13) {read_imu = 1;}
  if (ticks == 14) {}// = true;
  if (ticks == 15) {read_camera = 1;}
  if (ticks == 16) {read_imu = 1;}
  if (ticks == 17) {} // = 1;
  if (ticks == 18) {} // = 1;
  if (ticks == 19) {read_imu = 1;}
  if (ticks >= 20){ticks = 0;}
}
