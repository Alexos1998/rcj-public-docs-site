#ifndef MAPPING_H
#define MAPPING_H

#include <Config.h>
#include <Arduino.h>
#include <cmath>
#include <vector>
//#include <cstdio>
#include <stdlib.h>
//#include <cassert>
#include <list>

// tile infomation
#define BMSK_VICTIM   (1 << 0) // 0000 0001
#define BMSK_EXPLORED (1 << 1) // 0000 0010
#define BMSK_BLACK    (1 << 2) // 0000 0100
#define BMSK_SILVER   (1 << 3) // 0000 1000
#define BMSK_BLUE     (1 << 4) // 0001 0000 
#define BMSK_RED      (1 << 5) // 0010 0000 
#define BMSK_OBSTACLE (1 << 6) // 0100 0000 
#define BMSK_RAMP     (1 << 7) // 1000 0000

//RAMP infomation
#define BMSK_RAMP_DOWN  (1 << 0)
#define BMSK_RAMP_UP    (1 << 0)




struct Coordinates { // Struct for tile coordinates
    int8_t x = 0;
    int8_t y = 0;
    int8_t z = 0;
};

struct Tile { // where foward is true 0 degrees
    uint8_t id;
    Coordinates location;
    uint8_t info;
    uint8_t ramp;
    Tile* front;
    Tile* left;
    Tile* right;
    Tile* back ;
};



class Mapping {
public:
    Mapping() {}
    void init();
    
    uint8_t get_current_tileID();
    void set_current_tileID(uint8_t tile_id);
    bool switch_current_tile();
    void set_current_info(uint8_t current_info);
    void create_tiles(float bearing, uint8_t tile_available[4]);

    void soft_reset();
    void ramp(uint8_t tile_id, float bearing, uint8_t direction, uint8_t tile_available[4]); // runs at end of ramp

    void tile_printout(uint8_t tile_id);
    void tile_printout_map(uint8_t tile_id);

    uint8_t black_tile(float bearing);
    uint8_t follow_left_wall(float bearing, int8_t black_direction); // finds next spot l,f,r,b
    uint8_t mapping_alg(float bearing);

private:
    Tile* map;
    uint8_t tile_num = 1;
    uint8_t current_tile_id = 0;
    int8_t next_tile_id = -1; 
    std::vector<int8_t> past_tiles = {0};
    std::vector<int8_t> past_tiles_mapping = {0};
    bool tile_visted = false;


    void create_empty_tile(uint8_t tile_id);

    float tile_headings[9] = {-360.0, -270.0, -180.0, -90.0, 0.0, 90.0, 180.0, 270.0, 360.0};

    //float tile_headings[5] = {-180.0, -90.0, 0.0, 90.0, 180.0};


    bool black_tile_here[0];
        /*
    //Setting the value
    info |= BMSK_VICTIM;

    // Clearing the value
    info &= ~BMSK_VICTIM

    // Reading the value
    reading = info & BMSK_VICTIM
    */
};
#endif