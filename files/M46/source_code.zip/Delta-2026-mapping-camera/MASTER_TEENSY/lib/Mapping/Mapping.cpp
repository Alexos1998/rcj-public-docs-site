#include "Mapping.h"


void Mapping::init()
{
    map = (Tile*)malloc(sizeof(Tile) * tile_num);
    current_tile_id = 0;
    create_empty_tile(current_tile_id);
}



uint8_t Mapping::get_current_tileID() // returns current tile id
{
    return current_tile_id;
}



void Mapping::set_current_tileID(uint8_t tile_id){
    current_tile_id = tile_id;
}



bool Mapping::switch_current_tile() // changes the tile; for when robot physial moves tiles
{
    if (next_tile_id == -1 ) { 
        return 0;
    }

    (map[current_tile_id]).info |= BMSK_EXPLORED;

    current_tile_id = next_tile_id;
    past_tiles.push_back(next_tile_id);

    if (!tile_visted) {
        past_tiles_mapping.push_back(next_tile_id);
    }
    return 1;    
}



void Mapping::set_current_info(uint8_t current_info) // add the current info for the tile
{
    (map[current_tile_id]).info |= current_info;
}



void Mapping::create_tiles(float bearing, uint8_t tile_available[4])
{
    // 1. ++++++++ What way is the robot facing ++++++++
    float closest_heading = tile_headings[0];
    float minimun_bearing = std::abs(bearing - tile_headings[0]);
    
    for (int i = 1; i < 9; i++) {
        float current_bearing = std::abs(bearing - tile_headings[i]);

        if (current_bearing < minimun_bearing) {
            minimun_bearing = current_bearing;
            closest_heading = tile_headings[i];
        }
    }
    Serial.print("Closest Bearing:"); Serial.println(closest_heading); 

    // 2. ++++++++ Where are the connected tiles based on this ++++++++
    uint8_t connected_tile[4] = {0}; // at 0 degrees: left, front, right, back

    if ((closest_heading == -360) || (closest_heading == 0) || (closest_heading == 360)) { // 0 degrees
        connected_tile[0] = tile_available[0];   connected_tile[1] = tile_available[1];
        connected_tile[2] = tile_available[2];  connected_tile[3] = tile_available[3];

    } else if ((closest_heading == 90) || (closest_heading == -270)) { // 90 degrees
        connected_tile[0] = tile_available[3];   connected_tile[1] = tile_available[0];
        connected_tile[2] = tile_available[1];  connected_tile[3] = tile_available[2];

    } else if ((closest_heading == 180) || (closest_heading == -180)) { // 180 degrees
        connected_tile[0] = tile_available[2];  connected_tile[1] = tile_available[3];
        connected_tile[2] = tile_available[0];   connected_tile[3] = tile_available[1];

    } else { // 270 degrees
        connected_tile[0] = tile_available[1];  connected_tile[1] = tile_available[2];
        connected_tile[2] = tile_available[3];   connected_tile[3] = tile_available[0];
    }
    Serial.print("Connected Tiles:"); Serial.print(connected_tile[0]); Serial.print("\t");
    Serial.print(connected_tile[1]); Serial.print("\t"); Serial.print(connected_tile[2]); Serial.print("\t");
    Serial.println(connected_tile[3]);

    // 3. ++++++++ What are the coords are these tiles ++++++++
    int8_t current_x = (map[current_tile_id]).location.x;
    int8_t current_y = (map[current_tile_id]).location.y;
    //int8_t current_z = (map[current_tile_id]).location.z;

    int8_t coord_values[4][2] = {
        {(int8_t)(current_x - 1), current_y              },
        {current_x              , (int8_t)(current_y + 1)},
        {(int8_t)(current_x + 1), current_y              },
        {current_x              , (int8_t)(current_y - 1)}
    };

    
    Serial.print("X Value :\t"); Serial.print(coord_values[0][0]); Serial.print("\t");
    Serial.print(coord_values[1][0]); Serial.print("\t"); Serial.print(coord_values[2][0]); Serial.print("\t");
    Serial.println(coord_values[3][0]);

    Serial.print("Y Value :\t"); Serial.print(coord_values[0][1]); Serial.print("\t");
    Serial.print(coord_values[1][1]); Serial.print("\t"); Serial.print(coord_values[2][1]); Serial.print("\t");
    Serial.println(coord_values[3][1]);

    // 4. ++++++++ Have i made these tiles ++++++++
    uint8_t uncommon_tiles[4] = {
        connected_tile[0],
        connected_tile[1], 
        connected_tile[2],
        connected_tile[3]
    };
    
    // check for all directions l,f,r,b
    for (uint8_t i = 0; i < 4; i++) {   
        uint8_t common_tile = 0;
        int8_t x_coord_1 = coord_values[i][0];
        int8_t y_coord_1 = coord_values[i][1];

         // check every tile that has been made
        for (uint8_t j = 0; j < tile_num; j++) {
            int8_t x_coord_2 = (map[j]).location.x;
            int8_t y_coord_2 = (map[j]).location.y;

            if (x_coord_1 == x_coord_2 && y_coord_1 == y_coord_2) {
                common_tile = 1;
            }
        }

        // if has been made make uncommon tile false
        if (common_tile) {
            uncommon_tiles[i] = 0;
        }    
    }

    Serial.print("Uncommon tiles :"); Serial.print(uncommon_tiles[0]); Serial.print("\t");
    Serial.print(uncommon_tiles[1]); Serial.print("\t"); Serial.print(uncommon_tiles[2]); Serial.print("\t");
    Serial.println(uncommon_tiles[3]);

    // 5. ++++++++ Make new tiles ++++++++
    uint8_t num_of_tile_to_create = 0;
    for (uint8_t i = 0; i < 4; i++) {
        num_of_tile_to_create += uncommon_tiles[i];
    }
    
    // Save the old count so we know where the new tiles start
    uint8_t old_tile_num = tile_num; 
    tile_num += num_of_tile_to_create;
    
    // Resize the map array
    map = (Tile*)realloc(map, sizeof(Tile) * tile_num);

    // Create only the brand new tiles
    for (int8_t i = old_tile_num; i < tile_num; i++) {
        create_empty_tile(i);
    }
    
    // Track the absolute map index for all 4 directions
    int8_t assigned_index[4] = {-1, -1, -1, -1}; // -1 means no tile in this direction
    int8_t new_tile_counter = 0;

    for (int8_t i = 0; i < 4; i++) {

        // it's a completely new tile'
        if (uncommon_tiles[i]) {

            // set coordinates and save the index
            uint8_t target_index = old_tile_num + new_tile_counter;
            map[target_index].location.x = coord_values[i][0];
            map[target_index].location.y = coord_values[i][1];
            assigned_index[i] = target_index;
            new_tile_counter++;

        // The tile was already made
        } else if (connected_tile[i]) {
            
            // search the map to find its existing index
            for (uint8_t j = 0; j < old_tile_num; j++) {
                if (map[j].location.x == coord_values[i][0] && map[j].location.y == coord_values[i][1]) {
                    assigned_index[i] = j; // Grab the existing tile's index
                    break;
                }
            }
        }
    }


    // 6. ++++++++ Pointer to connected tiles ++++++++
    
    // Connect the current tile to its neighbors (whether they are new or old)
    map[current_tile_id].left  = (assigned_index[0] != -1) ? &(map[assigned_index[0]]) : NULL;
    map[current_tile_id].front = (assigned_index[1] != -1) ? &(map[assigned_index[1]]) : NULL;
    map[current_tile_id].right = (assigned_index[2] != -1) ? &(map[assigned_index[2]]) : NULL;
    map[current_tile_id].back  = (assigned_index[3] != -1) ? &(map[assigned_index[3]]) : NULL;

    // Connect neighbors back to the current tile (mutual linking)
    // 0 (Left) connects back via Right
    if (assigned_index[0] != -1) {
        map[assigned_index[0]].right = &map[current_tile_id];
    }
    // 1 (Front) connects back via Back
    if (assigned_index[1] != -1) {
        map[assigned_index[1]].back = &map[current_tile_id];
    }
    // 2 (Right) connects back via Left
    if (assigned_index[2] != -1) {
        map[assigned_index[2]].left = &map[current_tile_id];
    }
    // 3 (Back) connects back via Front
    if (assigned_index[3] != -1) {
        map[assigned_index[3]].front = &map[current_tile_id];
    }

    #if DEBUG_CURRENT_TILE
    tile_printout(current_tile_id);
    #endif

    #if DEBUG_MAP
    for (size_t i = 0; i <= current_tile_id; i++) {
        tile_printout_map(i);
    }
    #endif
    
}



void Mapping::create_empty_tile(uint8_t tile_id) // Fill out the basic infomation for a tile
{
    (map[tile_id]).id = tile_id;
    (map[tile_id]).left = NULL;
    (map[tile_id]).front = NULL;
    (map[tile_id]).right = NULL;
    (map[tile_id]).back = NULL;
    (map[tile_id]).info = 0;
    (map[tile_id]).location.x = 0;
    (map[tile_id]).location.y = 0;
    (map[tile_id]).location.z = 0;
}



void Mapping::soft_reset() 
{
//     int16_t silver_tile;
//     for (int16_t i = 0; i < 1000; i++) {
//         bool silver_tile_status = tile_map[-1-i]->silver_tile;
//         silver_tile = current_tile - i;
//         if (silver_tile_status) {
//             break;
//         }
//         std::cout << i << "\n";
//   }
//     current_tile = silver_tile;
}


void Mapping::ramp(uint8_t tile_id, float bearing, uint8_t direction, uint8_t tile_available[4])
{
    // for when the tile has finished the ramp

    // sets the current tile as a ramp tile and look at what way it goes
    // makes the new tile below or above
    if (direction) {
        map[current_tile_id].ramp |= BMSK_RAMP_UP;
        map[current_tile_id].location.z += 1;
    } else {
        map[current_tile_id].ramp |= BMSK_RAMP_DOWN;
        map[current_tile_id].location.z -= 1;
    }
    
    // runs create tile for the new tile with adjusted z value
    create_tiles(bearing, tile_available); // will need fixing
}



void Mapping::tile_printout(uint8_t tile_id) // prints out all the tiles data
{
    Serial.print(" ------- MAPPING INFOMATION FOR "); 
    Serial.print(tile_id); Serial.println(" -------");

    Serial.print("Tile ID: \t"); Serial.println(map[tile_id].id);

    Serial.print("X Coordinate: \t"); Serial.println(map[tile_id].location.x);

    Serial.print("Y Coordinate: \t"); Serial.println(map[tile_id].location.y);

    Serial.print("Z Coordinate: \t"); Serial.println(map[tile_id].location.z);

    Serial.print("Left Tile: \t");  
    Serial.println((int8_t)(map[tile_id].left  != NULL ? map[tile_id].left->id  : -9));

    Serial.print("Front Tile: \t"); 
    Serial.println((int8_t)(map[tile_id].front != NULL ? map[tile_id].front->id : -9));

    Serial.print("Right Tile: \t"); 
    Serial.println((int8_t)(map[tile_id].right != NULL ? map[tile_id].right->id : -9));

    Serial.print("Back Tile: \t");  
    Serial.println((int8_t)(map[tile_id].back  != NULL ? map[tile_id].back->id  : -9));

    Serial.print("Info \t \t"); Serial.println(map[tile_id].info);

    Serial.print("Victim: \t"); 
    Serial.println((map[tile_id].info) & BMSK_VICTIM);

    Serial.print("Explored: \t"); 
    Serial.println((map[tile_id].info) & BMSK_EXPLORED);

    Serial.print("Black Tile: \t"); 
    Serial.println((map[tile_id].info) & BMSK_BLACK);

    Serial.print("Silver Tile: \t"); 
    Serial.println((map[tile_id].info) & BMSK_SILVER);

    Serial.print("Blue_tile: \t"); 
    Serial.println((map[tile_id].info) & BMSK_BLUE);

    Serial.print("Red_tile: \t"); 
    Serial.println((map[tile_id].info) & BMSK_RED);

    Serial.print("Obstacle: \t"); 
    Serial.println((map[tile_id].info) & BMSK_OBSTACLE);

    Serial.print("RAMP: \t \t"); 
    Serial.println((map[tile_id].info) & BMSK_RAMP);

    Serial.print("RAMP UP: \t"); 
    Serial.println((map[tile_id].ramp) & BMSK_RAMP_UP);

    Serial.print("RAMP DOWN: \t"); 
    Serial.println((map[tile_id].ramp) & BMSK_RAMP_DOWN);
    
}



void Mapping::tile_printout_map(uint8_t tile_id) // prints out all the tiles data
{
    Serial.print(" +++++++++++ MAP DATA FOR "); 
    Serial.print(tile_id); Serial.println(" +++++++++++ ");

    Serial.print("Tile ID: \t"); Serial.println(map[tile_id].id);

    Serial.print("X Coordinate: \t"); Serial.println(map[tile_id].location.x);

    Serial.print("Y Coordinate: \t"); Serial.println(map[tile_id].location.y);

    Serial.print("Z Coordinate: \t"); Serial.println(map[tile_id].location.z);

    Serial.print("Left Tile: \t");  
    Serial.println((int8_t)(map[tile_id].left  != NULL ? map[tile_id].left->id  : -9));

    Serial.print("Front Tile: \t"); 
    Serial.println((int8_t)(map[tile_id].front != NULL ? map[tile_id].front->id : -9));

    Serial.print("Right Tile: \t"); 
    Serial.println((int8_t)(map[tile_id].right != NULL ? map[tile_id].right->id : -9));

    Serial.print("Back Tile: \t");  
    Serial.println((int8_t)(map[tile_id].back  != NULL ? map[tile_id].back->id  : -9));

    Serial.println(" +++++++++++++++++++++++++++++++++ "); 
    Serial.println(" "); 

    if(tile_id == 0) {
        Serial.println(map[tile_id].front->id);
    }
}



uint8_t Mapping::black_tile(float bearing) 
{
    // find out what tile i moved to
    current_tile_id = past_tiles[past_tiles.size() - 2]; // fix??
    past_tiles.push_back(current_tile_id);

    // look at where to move next but don't think about that location

    int8_t tile_directions[4] = {
        static_cast<int8_t>(map[(past_tiles[past_tiles.size() - 2])].left != NULL ? 
        map[(past_tiles[past_tiles.size() -2])].left->id : -1),

        static_cast<int8_t>(map[(past_tiles[past_tiles.size() -2])].front != NULL ? 
        map[(past_tiles[past_tiles.size() -2])].front->id : -1),

        static_cast<int8_t>(map[(past_tiles[past_tiles.size() -2])].right != NULL ?
        map[(past_tiles[past_tiles.size() -2])].right->id : -1),

        static_cast<int8_t>(map[(past_tiles[past_tiles.size() -2])].back != NULL ? 
        map[(past_tiles[past_tiles.size() -2])].back->id : -1)};
        
    int8_t black_direction = 0;

    for (int8_t i = 0; i < 4; i++)
    {
        if((tile_directions[i] == past_tiles[past_tiles.size() -2])) { //(map[tile_directions[i]].info) & BMSK_BLACK
            black_direction = (i + 1);
        }
    }
    Serial.print("Black direction: "); Serial.println(black_direction);
    return (follow_left_wall(bearing, black_direction));
}



uint8_t Mapping::follow_left_wall(float bearing, int8_t black_tile)
{
    next_tile_id = -1;
    // find out what way the robot is facing
    float closest_heading = tile_headings[0];
    float minimun_distance = std::abs(bearing - tile_headings[0]);
    
    for (int i = 1; i < 9; i++) {
        float current_distance = std::abs(bearing - tile_headings[i]);

        if (current_distance < minimun_distance) {
            minimun_distance = current_distance;
            closest_heading = tile_headings[i];
        }
    }
    
    // then do connected tiles so it is for a heading o f 0*
    int8_t connected_tile[4] = {0,0,0,0}; // at 0 degrees: left, front, right, back

    int8_t current_tiles[4] = {
        ((int8_t)((map[current_tile_id]).left != NULL ? (map[current_tile_id]).left->id : -2)), 
        ((int8_t)((map[current_tile_id]).front != NULL ? (map[current_tile_id]).front->id  : -2)),
        ((int8_t)((map[current_tile_id]).right != NULL ? (map[current_tile_id]).right->id  : -2)), 
        ((int8_t)((map[current_tile_id]).back != NULL ? (map[current_tile_id]).back->id  : -2))};
    
    if (black_tile != 0) {
        for (int8_t i = 0; i < 4; i++)
        {
            if ((i + 1) == black_tile) {
                current_tiles[i] = 0;
            }
        }
    }

    if ((closest_heading == -360) || (closest_heading == 0) || (closest_heading == 360)) { // 0 degrees
        connected_tile[0] = current_tiles[0]; connected_tile[1] = current_tiles[1];
        connected_tile[2] = current_tiles[2]; connected_tile[3] = current_tiles[3];

    } else if (closest_heading == 90 || closest_heading == -270) { // 90 degrees
        connected_tile[0] = current_tiles[1]; connected_tile[1] = current_tiles[2];
        connected_tile[2] = current_tiles[3]; connected_tile[3] = current_tiles[0];


    } else if (closest_heading == 180 || closest_heading == -180) { // 180 degrees
        connected_tile[0] = current_tiles[2]; connected_tile[1] = current_tiles[3];
        connected_tile[2] = current_tiles[0]; connected_tile[3] = current_tiles[1];

    } else { // 270 degrees
        connected_tile[0] = current_tiles[3]; connected_tile[1] = current_tiles[0];
        connected_tile[2] = current_tiles[1]; connected_tile[3] = current_tiles[2];
    }

    


    if (connected_tile[0] >= 0) {
        // record where will move next
        next_tile_id = connected_tile[0];
        Serial.print("Next Tile ID"); Serial.println(next_tile_id);
        return 1;

    } else if (connected_tile[1] >= 0) { 
        // record where will move next
        next_tile_id = connected_tile[1];
        Serial.print("Next Tile ID"); Serial.println(next_tile_id);
        return 2;

    } else if (connected_tile[2] >= 0) {
        // record where will move next
        next_tile_id = connected_tile[2];
        Serial.print("Next Tile ID"); Serial.println(next_tile_id);
        return 3;

    } else {
        // record where will move next
        next_tile_id = connected_tile[3];
        Serial.print("Next Tile ID"); Serial.println(next_tile_id);
        return 4;
    }
}



uint8_t Mapping::mapping_alg(float bearing) 
{
    tile_visted = false;
    if(!(map[current_tile_id].info & BMSK_EXPLORED)) { // have not been here
        return (follow_left_wall(bearing, 0));
    } else { // have been here  
        
        float closest_heading = tile_headings[0];
        float minimun_distance = std::abs(bearing - tile_headings[0]);
        for (uint8_t i = 1; i < 9; i++) {
            float current_distance = std::abs(bearing - tile_headings[i]);

            if (current_distance < minimun_distance) {
                minimun_distance = current_distance;
                closest_heading = tile_headings[i];
            }
        }
        
        // then do connected tiles so it is for a heading o f 0*
        int8_t connected_tile[4]; // at 0 degrees: left, front, right, back
        int8_t current_tiles[4] = {
            ((int8_t)((map[current_tile_id]).left != NULL ? (map[current_tile_id]).left->id : -2)), 
            ((int8_t)((map[current_tile_id]).front != NULL ? (map[current_tile_id]).front->id  : -2)),
            ((int8_t)((map[current_tile_id]).right != NULL ? (map[current_tile_id]).right->id  : -2)), 
            ((int8_t)((map[current_tile_id]).back != NULL ? (map[current_tile_id]).back->id  : -2))};
        

        if ((closest_heading == -360) || (closest_heading == 0) || (closest_heading == 360)) { // 0 degrees
            connected_tile[0] = current_tiles[0]; connected_tile[1] = current_tiles[1];
            connected_tile[2] = current_tiles[2]; connected_tile[3] = current_tiles[3];

        } else if (closest_heading == 90 || closest_heading == -270) { // 90 degrees
            connected_tile[0] = current_tiles[1]; connected_tile[1] = current_tiles[2];
            connected_tile[2] = current_tiles[3]; connected_tile[3] = current_tiles[0];

        } else if (closest_heading == 180 || closest_heading == -180) { // 180 degrees
            connected_tile[0] = current_tiles[2]; connected_tile[1] = current_tiles[3];
            connected_tile[2] = current_tiles[0]; connected_tile[3] = current_tiles[1];

        } else { // 270 degrees
            connected_tile[0] = current_tiles[3]; connected_tile[1] = current_tiles[0];
            connected_tile[2] = current_tiles[1]; connected_tile[3] = current_tiles[2];
        }

        // if there an opening of an non exproled tile
        if(connected_tile[0] >= 0 && !(map[connected_tile[0]].info & BMSK_EXPLORED)) {
            next_tile_id = connected_tile[0];
            return 1;

        } else if (connected_tile[1] >= 0 && !(map[connected_tile[1]].info & BMSK_EXPLORED)) {
            next_tile_id = connected_tile[1];
            return 2;

        } else if (connected_tile[2] >= 0 && !(map[connected_tile[2]].info & BMSK_EXPLORED)) {
            next_tile_id = connected_tile[2];
            return 3;

        } else if (connected_tile[3] >= 0 && !(map[connected_tile[3]].info & BMSK_EXPLORED)) {
            next_tile_id = connected_tile[3];
            return 4;
            
        } else {
            int8_t last_direction = 0;
            for (size_t i = 0; i < 4; i++)
            {
                if (connected_tile[i] == past_tiles[(past_tiles.size()-1)]) {
                    last_direction = (i + 1);
                }
            }
            next_tile_id = last_direction;
            tile_visted = true;
            return last_direction;
        }
    }

}