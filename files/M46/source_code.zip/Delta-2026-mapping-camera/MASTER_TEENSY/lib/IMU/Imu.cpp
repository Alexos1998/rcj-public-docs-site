#include "IMU.h"


IMU::IMU() {};



void IMU::init() {
    while(!bno.begin(OPERATION_MODE_NDOF)) {
        Serial.println("No BNO055 detected. Check your wiring or I2C ADDR.");
        delay(1000);
    }
    bno.setExtCrystalUse(true);
    delay(500);
}



void IMU::imu_value_finder() {
    sensors_event_t event;
    bno.getEvent(&event);
    imu_x = event.orientation.x;
    imu_y = event.orientation.y;
    imu_z = event.orientation.z;
}



void IMU::target_angle(float angle_change, bool reset_angle) { 
    // reset_angle means the angle changes to angle_chnage
    float target_angle_value_full = 0;
    if (reset_angle) { 
        target_angle_value_full = angle_change;    
    } else {
        target_angle_value_full = (target_angle_value + angle_change);
    }

    if (target_angle_value_full > 180 || target_angle_value_full <= -180) {
        float f_target_angle_value_full = fmod(target_angle_value_full, 360);

        if (f_target_angle_value_full > 180) {
            target_angle_value = (f_target_angle_value_full - 360);
        } else {
            target_angle_value = (f_target_angle_value_full + 360);
        }
    } else {
        target_angle_value= target_angle_value_full;
    }
}



float IMU::imu_180() { // make so the imu read -180, 180

    // return imu_x > 180 ? imu_x - 180.0f : imu_x;

    float f_imu_value = fmod(imu_x, 360);
    //int f_imu_value = *p_imu_value_x;

    if(f_imu_value > 180) {
        return float(f_imu_value - 360);

    } else if(f_imu_value <= -180) {
        return float(f_imu_value + 360);

    } else if (f_imu_value <= 180){
            return float(f_imu_value);
    }          
}


// need more work (what about tagret of 90 and angle of -179)
float IMU::imu_off() { // find how much the robot is off from where it should be
    if(target_angle_value >= -90 && target_angle_value <= 90){
        // uses -180, 180 imu
        float angle_off_value = imu_180() - target_angle_value;

        if(angle_off_value > 180 || angle_off_value <= -180 ) {
           if(angle_off_value >= 180) {
                return float(angle_off_value - 360);
           } else {
                return float(angle_off_value + 360);
           }
        }else{
            return angle_off_value;
        }
    } else{
        // uses 0, 360 imu
        float target_angle_value_360;
        if(target_angle_value < 0){
            target_angle_value_360 = (target_angle_value + 360);
        } else {
            target_angle_value_360 = target_angle_value;
        }

        float angle_off_value = imu_x - target_angle_value_360;

        if(angle_off_value > 180 || angle_off_value <= -180 ) {
           if(angle_off_value >= 180) {
                return float(angle_off_value - 360);
           } else {
                return float(angle_off_value + 360);
           }
        }else{
            return angle_off_value;
        }
    }

}



float IMU::imu_180_y() { // give the y axis magnitude of the IMU
    float f_imu_value = fmod(imu_y, 360);
    //int f_imu_value = *p_imu_value_x;

    if(f_imu_value > 180) {
        return float(f_imu_value - 360);

    } else if(f_imu_value <= -180) {
        return float(f_imu_value + 360);

    } else if (f_imu_value <= 180){
            return float(f_imu_value);
        }  
}