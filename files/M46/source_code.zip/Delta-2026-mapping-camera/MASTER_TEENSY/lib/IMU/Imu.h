#ifndef IMU_H
#define IMU_H

#include <Adafruit_BNO055.h>
#include <Arduino.h>
#include <math.h>
#include <Wire.h>

class IMU {
public:
    IMU();
    void init();
    void imu_value_finder();
    void target_angle(float angle, bool reset_angle);
    float imu_180();
    float imu_off();
    float imu_180_y();

private:
    Adafruit_BNO055 bno = Adafruit_BNO055(55, BNO055_ADDRESS_B, &Wire1);

    // Variables
    float imu_x;
    float imu_y;
    float imu_z;
    float target_angle_value = 0;
};
#endif