#include "Distance_Sensors.h"



Distance_Sensors::Distance_Sensors(){}


void Distance_Sensors::init() {
  Wire.begin();
  // Disable/reset all sensors by driving their XSHUT pins low.
  for (uint8_t i = 0; i < sensorCount; i++)
  {
    pinMode(xshutPins[i], OUTPUT);
    digitalWrite(xshutPins[i], LOW);
  }

  // Enable, initialize, and start each sensor, one by one.
  for (uint8_t i = 0; i < sensorCount; i++) {
    pinMode(xshutPins[i], INPUT);
    delay(10);

    sensors[i].setTimeout(500);
    if (!sensors[i].init())
    {
      Serial.print("Failed to detect and initialize sensor ");
      Serial.println(i);
      while (1);
    }

    sensors[i].setAddress(0x2A + i);

    sensors[i].startContinuous();
  }
}




int16_t Distance_Sensors::Read_Sensor(int8_t sensor_number){
 int8_t sensor_value = sensor_number -1;
  lrf_values[sensor_value] = sensors[sensor_value].read();
  return lrf_values[sensor_value];
  if (sensors[sensor_value].timeoutOccurred()) { Serial.print(" TIMEOUT"); }

}





bool Distance_Sensors::read_array(){
  bool data_read = false;
  for (uint8_t i = 0; i < sensorCount; i++) {
    if(sensors[i].dataReady()) { data_read = true;}
    lrf_values[i] = sensors[i].read(false); // can disable blocking if needed
    if (sensors[i].timeoutOccurred()) { Serial.print(" TIMEOUT"); }
  }
  return data_read;
}



void Distance_Sensors::read_array_blocking(){
  for (uint8_t i = 0; i < sensorCount; i++) {
    lrf_values[i] = sensors[i].read(false); // can disable blocking if needed
    if (sensors[i].timeoutOccurred()) { Serial.print(" TIMEOUT"); }
  }

}



int16_t Distance_Sensors::side_distance(int8_t side){
  int8_t sensor_1[4] = {0,2,4,6};
  int8_t sensor_2[4] = {1,3,5,7};
  return int16_t((lrf_values[sensor_1[side-1]]+ lrf_values[sensor_2[side-1]])/2);

}



int16_t Distance_Sensors::fmod_distance(int8_t side){
  int8_t sensor_1[4] = {0,2,4,6};
  int8_t sensor_2[4] = {1,3,5,7};
  return int16_t(fmod(((lrf_values[sensor_1[side-1]]+ lrf_values[sensor_2[side-1]])/2), 300.0));
}



int16_t Distance_Sensors::sensor_differences(int8_t side){
  // other side is minused from side chosen
  int8_t other_side[4] = {4,3,2,1};
  return int16_t(side_distance(side) - side_distance(other_side[side-1]));
}



int16_t Distance_Sensors::sensor_differences_fmod(int8_t side){ // do i need??
  // other side is minused from side chosen
  int8_t other_side[4] = {4,3,2,1};
  return int16_t(fmod_distance(side))  - (fmod_distance(other_side[side-1]));
}



int16_t Distance_Sensors::sensor_differences_advance(int8_t side, float bearing){
  int16_t left_value = 0;
  int16_t right_value = 0;
  int16_t side_values [4] = {lrf_values[2],lrf_values[3],lrf_values[4],lrf_values[5]};
  bool large_side_values[4] = {false, false, false, false};

  for (int8_t i = 0; i < 4; i++) {
    if (side_values[i] > 200) {
      large_side_values[i] = true;
    }
  }
  int8_t large_left = int8_t(large_side_values[0]) + int8_t(large_side_values[1]);
  int8_t large_right = int8_t(large_side_values[2]) + int8_t(large_side_values[3]);
  int8_t any_large = large_left + large_right;

  if (!any_large) { // all less than 250
    // Serial.println("All good");
    left_value = ((side_values[0] + side_values[1])/2);
    right_value = ((side_values[2] + side_values[3])/2);

  } else if (large_left && large_right) { // all more than 250
    // Serial.println("All bad");
    left_value = 100;
    right_value = 100;

  } else {
    if ((large_side_values[0] == true) || (large_side_values[1] == true)) {
      // Serial.println("Right Good");
      right_value = ((side_values[2] + side_values[3])/2);
      left_value = (300- robot_width - right_value);
    } else if ((large_side_values[2] == true) || (large_side_values[3] == true)) {
      // Serial.println("Left Good");
      left_value = ((side_values[0] + side_values[1])/2);
      right_value = (300- robot_width - left_value);
    }
  }
  int16_t total_distance = (left_value + right_value + robot_length);
  //Serial.println(total_distance);
  if(side == 2) {
    return int16_t(left_value - right_value);
  } else if (side == 3) {
    return int16_t(right_value - left_value);
  }  
  return 0;
}



float Distance_Sensors::sensor_ratio(int8_t side){
  // side chosen is 1 and retrun the other value  
  int8_t other_side[4] = {4,3,2,1};
  return float(side_distance(other_side[side+1]) / side_distance(side));
}



void Distance_Sensors::print_distances(){
    Serial.print("FL:"); Serial.print(lrf_values[0]);

    Serial.print(" FR:"); Serial.print(lrf_values[1]);

    Serial.print(" LF:"); Serial.print(lrf_values[2]);

    Serial.print(" LB:"); Serial.print(lrf_values[3]);

    Serial.print(" RL:"); Serial.print(lrf_values[4]);

    Serial.print(" RB:"); Serial.print(lrf_values[5]);

    Serial.print(" BL:"); Serial.print(lrf_values[6]);

    Serial.print(" BR:"); Serial.print(lrf_values[7]);

    Serial.print(" FLcx:"); Serial.print(lrf_values[8]);

    Serial.print(" FRcx:"); Serial.println(lrf_values[9]);

}