#ifndef DISTANCE_SENSORS_H
#define DISTANCE_SENSORS_H

#include <Arduino.h>
#include <Wire.h>
#include <VL53L4CD.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <assert.h>
#include <stdlib.h>

#define robot_length 155 // mm
#define robot_width 107 // mm



// Components.
class Distance_Sensors { 
  public:
    Distance_Sensors();
    void init();
    int16_t Read_Sensor(int8_t sensor_number);
    bool read_array();
    void read_array_blocking();
    int16_t side_distance(int8_t side);
    int16_t fmod_distance(int8_t side);
    int16_t sensor_differences(int8_t side);
    int16_t sensor_differences_fmod(int8_t side);
    int16_t sensor_differences_advance(int8_t side, float bearing);
    float sensor_ratio(int8_t side);
    void print_distances();

  private:
    // The number of sensors in your system.
    const uint8_t sensorCount = 8;

    // The Arduino pin connected to the XSHUT pin of each sensor.
    const uint8_t xshutPins[8] = { 13, 15, 41, 39, 14, 40, 37, 38};

    VL53L4CD sensors[8];
    

    int16_t lrf_values[10] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1};
  

};
#endif


