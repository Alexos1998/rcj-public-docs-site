#ifndef PID_H
#define PID_H

#include <math.h>
#include <Arduino.h>
#include <vector.h>


class PID {
public:
    PID(float kp_value, float ki_value, float kd_value);
    void p_value_finder(float p);
    void i_value_finder();
    void d_value_finder();
    int16_t pid_value_finder(float x_value, float y_value);

private:
    float kp;
    float ki;
    float kd;

    float p_value;
    float i_value;
    float d_value;

    std::vector<int> x_values = {0}; // time
    std::vector<int> y_values = {0}; // value off

};
#endif