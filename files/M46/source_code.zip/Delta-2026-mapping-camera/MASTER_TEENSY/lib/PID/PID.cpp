#include "PID.h"


PID::PID(float kp_value, float ki_value, float kd_value){
    kp = kp_value;
    ki = ki_value;
    kd = kd_value;
};

void PID::p_value_finder(float p){
    p_value = p;
}

void PID::i_value_finder(){
    float x_difference = abs(x_values[x_values.size()-1] - x_values[x_values.size()-2]);
    float y_difference = abs(y_values[y_values.size()-1] - y_values[y_values.size()-2]) * 
    (y_values[y_values.size()-1] / abs(y_values[x_values.size()-1]));
    i_value = x_difference * y_difference;
}

void PID::d_value_finder(){
    d_value = (y_values[y_values.size()-1] - y_values[y_values.size()-2])/ 
    (x_values[x_values.size()-1] - x_values[x_values.size()-2]);
}

int16_t PID::pid_value_finder(float x, float y){
    x_values[0] = x_values[1];
    y_values[0] = y_values[1];
    x_values[1] = x;
    y_values[1] = y;

    p_value_finder(y);
    i_value_finder();
    d_value_finder();

    return (((kp * p_value) + (ki * i_value)) - (kd * d_value));
}

