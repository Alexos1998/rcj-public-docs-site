#ifndef LIMIT_SWITCH_H
#define LIMIT_SWITCH_H

#include <Config.h>
#include <Arduino.h>
#include <math.h>


class Limit_Switch {
public:
    Limit_Switch();
    void init(uint8_t pin);
    bool read();

private:
    uint8_t pin_value;

};
#endif