#include "Limit_Switch.h"


Limit_Switch::Limit_Switch(){};



void Limit_Switch::init(uint8_t pin){
    pin_value = pin;
    pinMode(pin_value, INPUT_PULLUP);

}



bool Limit_Switch::read(){
    bool Switch_value = digitalRead(pin_value);
    return Switch_value;

}
