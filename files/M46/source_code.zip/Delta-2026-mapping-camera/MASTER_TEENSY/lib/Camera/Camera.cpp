#include "Camera.h"


CAMERA::CAMERA(){}



void CAMERA::init(uint8_t serial) {
    if(serial == 1) {
        Serial1.begin(115200);
        openMV = &Serial1;
    } else {
        Serial2.begin(115200);
        openMV = &Serial2;
    }
}



uint8_t CAMERA::read_camera() {
    Serial.print("IS THERE STUFF"); Serial.println(openMV->available());
    if (openMV->available()) {
        Serial.print("data");
        uint8_t data = 0;
        while(openMV->available()) {
            data = openMV->read();
            Serial.print(data);

            if(data == START_BYTE) {
                uint8_t data = openMV->read();
            }
            if (data < 10 && data < 0) {
                camera_value = data;
                uint8_t data = openMV->read();
            }

            if (data == END_BYTE) {
                
            }
                
            if ((data != START_BYTE && data != END_BYTE) || (data > 10 && data <0)) {
                Serial.println("ERROR WITH CAMERA");
                data = 0;
            }
        }
        Serial.print("Camera Value: "); Serial.println(camera_value);
        return camera_value;
    } else {

        return camera_value;
    }

}