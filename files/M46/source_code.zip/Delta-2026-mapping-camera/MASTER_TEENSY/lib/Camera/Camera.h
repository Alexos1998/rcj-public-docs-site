#ifndef CAMERA_H
#define CAMERA_H

#include <Arduino.h>
#include <math.h>

#define START_BYTE 0xAA
#define END_BYTE   0xBB

class CAMERA {
public:
    CAMERA();
    void init(uint8_t serial);
    uint8_t read_camera();

private:
    Stream *openMV; 
    uint8_t camera_value;

};
#endif