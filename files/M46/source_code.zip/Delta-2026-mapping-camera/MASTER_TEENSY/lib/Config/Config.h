#ifndef CONFIG_H
#define CONFIG_H

// ================= General =================
#define GENERAL_PRINTS 0


// ================= Mapping =================
#define DEBUG_CURRENT_TILE 1
#define DEBUG_MAP 1


#endif