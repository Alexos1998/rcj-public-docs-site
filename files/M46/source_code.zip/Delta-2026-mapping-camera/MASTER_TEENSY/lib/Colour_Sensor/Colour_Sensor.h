#ifndef COLOUR_SENSOR_H
#define COLOUR_SENSOR_H

#include <math.h>
#include <Arduino.h>
#include <string.h>
#include <Adafruit_AS7341.h>

class Colour_Sensor {
public:
    Colour_Sensor();
    void init();
    void read_sensor();
    bool colour_checker(String colour, u_int8_t tolerance);
    void change_values(String colour); //how to do?
    void print_values();


private:
    bool is_reading = false;
    struct colour_values {
        u_int16_t Channel_415nm;
        u_int16_t Channel_445nm;
        u_int16_t Channel_480nm;
        u_int16_t Channel_515nm;
        u_int16_t Channel_555nm;
        u_int16_t Channel_590nm;
        u_int16_t Channel_630nm;
        u_int16_t Channel_680nm;
        u_int16_t Channel_Clear;
        u_int16_t Channel_Near_IR;
    };

    colour_values Colour_Data;
    colour_values Silver_Values;
    colour_values Blue_Values;
    colour_values Black_Values;
    colour_values Red_Values;
    colour_values Constant_Value;


    Adafruit_AS7341 as7341;
};
#endif