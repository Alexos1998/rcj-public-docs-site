#include "Colour_Sensor.h"


Colour_Sensor::Colour_Sensor(){}



void Colour_Sensor::init(){
    Wire2.begin();
    as7341.begin(AS7341_I2CADDR_DEFAULT, &Wire2);
    as7341.setATIME(5);
    as7341.setASTEP(50);
    as7341.setGain(AS7341_GAIN_64X);
    as7341.setLEDCurrent(255);
    as7341.enableLED(true);
    //as7341.
    Black_Values.Channel_Clear = 10;
    is_reading = false;
}



void Colour_Sensor::read_sensor(){
    uint32_t p_timer_start = millis();
    if (!is_reading) {
        as7341.startReading(); 
        is_reading = true;
        return; 
    }
    Serial.print("Run time 1: "); Serial.println((millis() - p_timer_start));
    if (is_reading) {
        
        if (!as7341.checkReadingProgress()) {
            return; 
        }
        Serial.print("Run time 2: "); Serial.println((millis() - p_timer_start));
        uint16_t readings[12];
        
        
        as7341.getAllChannels(readings);
        Serial.print("Run time 3: "); Serial.println((millis() - p_timer_start));

        Colour_Data.Channel_415nm   = readings[0];  // F1
        Colour_Data.Channel_445nm   = readings[1];  // F2
        Colour_Data.Channel_480nm   = readings[2];  // F3
        Colour_Data.Channel_515nm   = readings[3];  // F4
        Colour_Data.Channel_555nm   = readings[6];  // F5 
        Colour_Data.Channel_590nm   = readings[7];  // F6
        Colour_Data.Channel_630nm   = readings[8];  // F7
        Colour_Data.Channel_680nm   = readings[9];  // F8
        Colour_Data.Channel_Clear    = readings[10]; // Clear
        Colour_Data.Channel_Near_IR  = readings[11]; // NIR
        
        Serial.print("Run time 4: "); Serial.println((millis() - p_timer_start));
        
        as7341.startReading(); 
        
        is_reading = false; 
        
    }
    Serial.print("Run time 5: "); Serial.println((millis() - p_timer_start));
}



bool Colour_Sensor::colour_checker(String colour, u_int8_t tolerance) { // fix
    if (colour == "BLUE"){
        Constant_Value = Blue_Values;

    } else if (colour == "SILVER"){
        Constant_Value = Silver_Values;

    } else if (colour == "BLACK"){
        if(Black_Values.Channel_Clear > Colour_Data.Channel_Clear ) {
                Serial.println(Colour_Data.Channel_Clear);
                return true;
        } else { return false; }

    } else if (colour == "RED"){
       Constant_Value = Red_Values;

    }
}



void Colour_Sensor::change_values(String colour) {
    if (colour == "BLUE"){
        Blue_Values = Colour_Data;

    } else if (colour == "SILVER"){
        Silver_Values = Colour_Data;

    } else if (colour == "BLACK"){
        Black_Values= Colour_Data;

    } else if (colour == "RED"){
       Red_Values= Colour_Data;

    }
}



void Colour_Sensor::print_values(){
    Serial.print("415nm: "); Serial.print(Colour_Data.Channel_415nm);
    Serial.print("  445nm: "); Serial.print(Colour_Data.Channel_445nm);
    Serial.print("  480nm: "); Serial.print(Colour_Data.Channel_480nm);
    Serial.print("  515nm: "); Serial.print(Colour_Data.Channel_515nm);
    Serial.print("  555nm: "); Serial.print(Colour_Data.Channel_555nm);
    Serial.print("  590nm: "); Serial.print(Colour_Data.Channel_590nm);
    Serial.print("  630nm: "); Serial.print(Colour_Data.Channel_630nm);
    Serial.print("  680nm: "); Serial.print(Colour_Data.Channel_680nm);
    Serial.print("  Clear: "); Serial.print(Colour_Data.Channel_Clear);
    Serial.print("  Near_IR: "); Serial.println(Colour_Data.Channel_Near_IR);
}