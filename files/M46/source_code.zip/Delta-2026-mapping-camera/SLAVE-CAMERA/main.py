import sensor, image, time
from machine import UART, LED

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(time=2000)

r = LED("LED_RED")
g = LED("LED_GREEN")
b = LED("LED_BLUE")

r.off()
g.off()
b.off()
g.toggle()

uart = UART(3, 115200, timeout_char=1000)

START_BYTE = 0xAA
END_BYTE   = 0xBB

def send_value(val):
    """Send a framed single byte value."""
    val = max(0, min(255, int(val)))  # clamp to byte range
    print(uart.write(bytes([START_BYTE, val, END_BYTE])))

clock = time.clock()

while True:
    #send_value(2)
    g.toggle()
    time.sleep_ms(100)
