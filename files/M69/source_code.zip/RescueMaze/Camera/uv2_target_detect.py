"""
M5Stack UnitV2 온보드 실행용 Cognitive Target 검출.

- 카메라를 로컬에서 직접 열어(cv2.VideoCapture) 프레임을 받는다.
- 5링 동심원 타겟의 색을 읽어 health status(합계 0/1/2)를 판정.
- 결과를 JSON 한 줄씩 stdout 으로 출력 (UnitV2 가 UART 로 전달).
  예: {"result":"Stable","sum":1,"rings":["red","green","black","green","blue"],
       "conf":0.91,"cx":278,"cy":248,"r":238}
  타겟이 없으면: {"result":null}

기기에 업로드 후:  python3 uv2_target_detect.py
(Flask / 웹 / PC 불필요. 온보드 단독 실행.)
"""
import time
import signal
import threading
import cv2
import numpy as np

try:
    import serial  # pyserial
except Exception:
    serial = None

try:
    from flask import Flask, Response  # 웹 표시용 (선택)
except Exception:
    Flask = None
    Response = None

# ==========================================
# 설정 / 튜닝 파라미터
# ==========================================
CAM_IDX = 0                # UnitV2 온보드 카메라
FRAME_W, FRAME_H = 640, 480

# --- UART (호스트 MCU 연결) ---
UART_DEV = "/dev/ttyS1"    # UnitV2 그로브 포트 UART (확인됨). ttyS0 은 시스템 콘솔이라 사용 금지
UART_BAUD = 115200
AUTO_FREEZE = True         # True: 확정 검출 시 1회 보고 후 RESUME 올 때까지 정지
ALSO_STDOUT = True         # 디버깅용으로 stdout 에도 같이 출력

# --- 웹 표시 (브라우저 오버레이 뷰) ---
WEB_ENABLE = True          # Flask 로 카메라+오버레이 스트림 제공
WEB_PORT = 80              # http://<기기IP>/ (기존 웹 UI 와 동일하게 80)
BUTTON_PATH = "/sys/class/gpio/gpio2/value"  # 윗면 물리 버튼 (평상시 1, 누름 0)
BUTTON_ACTIVE_LOW = True   # 눌림 = 0 이면 True
BUTTON_LONG_SEC = 3.0      # 이 시간 이상 누르면 '길게'(웹 표시 토글). 짧게 = RESUME
JPEG_QUALITY = 70

MIN_RADIUS_RATIO = 0.04    # 타겟 최소 반축(프레임 짧은변 대비)
MAX_RADIUS_RATIO = 0.60    # 타겟 최대 반축
MIN_AREA_RATIO = 0.003     # 유채색 코어 최소 면적(프레임 대비)
MIN_RING_CONFIDENCE = 0.4  # 각 링 우세 색 최소 비율
STABLE_FRAMES = 3          # 같은 결과 N프레임 연속 시에만 확정 출력

# --- 속도 ---
# 검출은 다운스케일 해상도에서 수행(연산량 ∝ 픽셀수). 좌표는 원본으로 환산.
# 위치 탐색만 이 배율로 축소해 수행(빠름). 링 색 판독은 원본 해상도 ROI에서 하므로
# 스케일을 낮춰도 판독 정확도는 유지된다.
DETECT_SCALE = 0.5         # 위치 탐색 해상도 배율 (작을수록 빠름)
                           # 0.25(160x120)에서는 반지름 추정 오차가 커서 가장 바깥쪽
                           # 링(파란색)의 색 판독 신뢰도가 MIN_RING_CONFIDENCE 아래로
                           # 떨어져 타겟이 있어도 미검출되는 문제가 있었음(실측 재현됨)
MORPH_KSIZE = (5, 5)       # 형태학 커널(다운스케일 기준)
MAX_CORE_CANDIDATES = 2    # 분석할 색 코어 후보 최대 수(최악 처리시간 상한)
ANALYZE_MAX_PX = 96        # 링 색 분석 ROI 의 최대 변 길이(초과 시 축소 → 처리시간 상한)
                           # 96 이면 링당 ~19px 로 색 판독 충분, 혼잡 장면에서도 ~35fps(격리)
CAM_FPS = 20               # 카메라 요청 fps. 동기 read 라 카메라가 detect 보다 빠르면
                           # 프레임이 적체될 수 있어, detect 소비율과 비슷하게 맞춘다.
PRINT_FPS_SEC = 5          # >0 이면 N초마다 검출 fps 를 로그에 출력(0=끔)

# 검정 = 아주 어두움(채도 무관) OR 어둑+무채색
BLACK_V_DARK = 90
BLACK_V_GRAY = 160
BLACK_S_GRAY = 60
DISK_FACTOR = 1.1          # 유채색 코어 반지름 대비 외곽 탐색 디스크 배수
                           # 1.55 였을 때는 배경 그림자까지 같이 붙잡혀 타겟 반지름이
                           # 실측보다 45% 가까이 부풀려지는 경우가 있었음(실측 재현됨)

COLOR_RANGES = {
    "red1":   ([0,   100, 100], [10,  255, 255]),
    "red2":   ([160, 100, 100], [180, 255, 255]),
    "yellow": ([20,  100, 100], [35,  255, 255]),
    "green":  ([40,  60,  60],  [85,  255, 255]),
    "blue":   ([95,  80,  80],  [130, 255, 255]),
}
COLOR_VALUES = {"black": -2, "red": -1, "yellow": 0, "green": 1, "blue": 2}
HEALTH_STATUS = {2: "Harmed", 1: "Stable", 0: "Unharmed"}

# --- Letter Victim (글자) 검출 ---
# Φ/Ψ/Ω 는 서로 링·세로획을 공유해 템플릿 매칭이 쉽게 혼동된다(실측: Φ→Ω 오검).
# 대신 크기·두께·회전에 강인한 '기하 특징'으로 판별한다:
#   구멍 수(닫힌 흰 영역): Φ=2 / Ω·Ψ=0~1
#   중앙 세로획(stem):     Ψ 有 / Ω 無
#   하단 양끝 발(feet):     Ω 有 / Ψ 無
# 글자값은 색 동심원 sum 과 같은 의미(Φ=2, Ψ=1, Ω=0)라 UART/AUTO_FREEZE 그대로.
LETTER_ENABLE = True        # 글자(Φ/Ψ/Ω) 검출 추가
LETTER_PRIORITY = True      # 글자가 잡히면 색 동심원보다 우선
LETTER_SCALE = 0.8          # 글자 검출 해상도 배율(작을수록 빠름, ~320폭)
LETTER_MAX_CANDIDATES = 3   # 판별할 후보 최대 수(최악 처리시간 상한)
LETTER_MAX_CHROMA = 40      # 획 평균 색도(max-min BGR) 상한. 글자는 흑백(~5) 이라
                            # 이보다 색을 띠면 색 타겟/컬러 물체로 보고 글자에서 제외(오검 방지)
LETTER_ASPECT = (0.5, 2.0)  # 글자 후보 가로/세로 비율 허용범위(정사각형 근처, 회전 포함)
LETTER_MIN_CONTRAST = 90    # (배경밝기 − 획밝기) 하한. 진짜 글자는 흰 종이 위 검은 획이라
                            # 대비 180+. 그림자는 회색·저대비(수십)라 이 값으로 걸러낸다.
LETTER_DEFECT_FRAC = 0.25   # '깊은' 볼록결함 판정 = ROI 대각선의 이 비율보다 깊은 결함.
                            # Ψ(갈래 틈 2개, 깊이~38%) vs Ω(열림 1개+얕은것, 2등~11%) 구분.
CHAR_ORDER = ["Φ", "Ψ", "Ω"]
CHAR_VALUE = {"Φ": 2, "Ψ": 1, "Ω": 0}   # Harmed / Stable / Unharmed → sum 과 동일


def classify_letter_shape(roi_bin):
    """이진 글자 ROI(획=255)를 '회전 불변' 기하 특징으로 Φ/Ψ/Ω 판별.
    반환: (char, conf[0..1]) 또는 (None, 0.0) — 애매하면 None(오검 방지).

    - Φ = 닫힌 구멍 2개 (링 안이 세로바로 둘로 나뉨)
    - Ω = 구멍 0, 깊은 볼록결함 1개 (아래로 열린 곳 1군데)
    - Ψ = 구멍 0, 깊은 볼록결함 2개 이상 (갈래 사이 틈 2군데)
    구멍 수·볼록결함 수는 회전과 무관하므로 글자를 눕혀도 동일하게 잡힌다.
    """
    b = (roi_bin > 0).astype(np.uint8)
    H, W = b.shape
    if H < 12 or W < 12:
        return None, 0.0
    fill = float(b.mean())
    if fill < 0.06 or fill > 0.92:       # 글자다운 채움 비율이 아니면 기각
        return None, 0.0
    # 닫힌 구멍(내부 흰 영역) 수: 바깥 배경을 floodfill 로 지우고 남은 흰 덩어리 count
    pad = cv2.copyMakeBorder(b * 255, 1, 1, 1, 1, cv2.BORDER_CONSTANT, value=0)
    ff = cv2.bitwise_not(pad)
    mask = np.zeros((ff.shape[0] + 2, ff.shape[1] + 2), np.uint8)
    cv2.floodFill(ff, mask, (0, 0), 0)
    n, _, stats, _ = cv2.connectedComponentsWithStats(ff)
    area = H * W
    holes = sum(1 for i in range(1, n)
                if stats[i, cv2.CC_STAT_AREA] >= area * 0.01)
    # 최대 윤곽의 '깊은 볼록결함' 수 — Ψ=2(갈래 틈 둘 다 깊음), Ω=1(아래 열림만).
    # 깊이 기준을 ROI 대각선의 일정 비율로: 실측 Ω 2등결함≈11%, Ψ 2등결함≈38% 라
    # 25% 로 자르면 Ω 2등은 확실히 탈락, Ψ 2등은 포함(둘레%기준보다 마진이 큼).
    ndef = 0
    diag = (H * H + W * W) ** 0.5
    cnts = find_contours(b * 255)
    if cnts:
        cnt = max(cnts, key=cv2.contourArea)
        if len(cnt) >= 5:
            hull_idx = cv2.convexHull(cnt, returnPoints=False)
            try:
                defs = cv2.convexityDefects(cnt, hull_idx)
                if defs is not None:
                    ndef = sum(1 for i in range(defs.shape[0])
                               if defs[i, 0, 3] / 256.0 > diag * LETTER_DEFECT_FRAC)
            except cv2.error:
                pass
    if holes >= 2:
        return "Φ", 0.9
    if ndef >= 2:
        return "Ψ", 0.85
    if ndef == 1:
        return "Ω", 0.85
    return None, 0.0


def is_black_sv(s, v):
    return (v < BLACK_V_DARK) | ((v < BLACK_V_GRAY) & (s < BLACK_S_GRAY))


def find_contours(mask):
    """OpenCV 3.x(3값) / 4.x(2값) 모두 호환되게 윤곽 리스트만 반환."""
    res = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    return res[0] if len(res) == 2 else res[1]


# ==========================================
# 색 판정
# ==========================================
def detect_color_in_pixels(hsv_pixels):
    counts = {}
    red_mask = cv2.bitwise_or(
        cv2.inRange(hsv_pixels, np.array(COLOR_RANGES["red1"][0]),
                    np.array(COLOR_RANGES["red1"][1])),
        cv2.inRange(hsv_pixels, np.array(COLOR_RANGES["red2"][0]),
                    np.array(COLOR_RANGES["red2"][1])))
    counts["red"] = int(cv2.countNonZero(red_mask))
    for name in ["yellow", "green", "blue"]:
        m = cv2.inRange(hsv_pixels, np.array(COLOR_RANGES[name][0]),
                        np.array(COLOR_RANGES[name][1]))
        counts[name] = int(cv2.countNonZero(m))
    s = hsv_pixels[..., 1].ravel()
    v = hsv_pixels[..., 2].ravel()
    counts["black"] = int(is_black_sv(s, v).sum())

    total = int(hsv_pixels.shape[0]) if hsv_pixels.ndim >= 1 else 0
    if total == 0:
        return None, 0.0
    best_color, best_count = None, 0
    for name, cnt in counts.items():
        if cnt > best_count:
            best_count, best_color = cnt, name
    return best_color, best_count / total


# ==========================================
# 마스크 / 위치 검출
# ==========================================
def foreground_mask(hsv):
    s, v = hsv[:, :, 1], hsv[:, :, 2]
    mask = ((s > 60) | is_black_sv(s, v)).astype(np.uint8) * 255
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, MORPH_KSIZE)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=2)
    return mask


def colored_mask(hsv):
    mask = (hsv[:, :, 1] > 60).astype(np.uint8) * 255
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, MORPH_KSIZE)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=2)
    return mask


def locate_candidates(hsv):
    full = foreground_mask(hsv)
    core = colored_mask(hsv)
    h, w = hsv.shape[:2]
    min_area = (w * h) * MIN_AREA_RATIO
    core_cnts = find_contours(core)
    cands = []
    for cc in sorted(core_cnts, key=cv2.contourArea, reverse=True)[:MAX_CORE_CANDIDATES]:
        if cv2.contourArea(cc) < min_area or len(cc) < 5:
            continue
        (cx, cy), (cd1, cd2), _ = cv2.fitEllipse(cc)
        rc = max(cd1, cd2) / 2.0
        disk = np.zeros((h, w), dtype=np.uint8)
        cv2.circle(disk, (int(cx), int(cy)), int(rc * DISK_FACTOR), 255, -1)
        comp = cv2.bitwise_and(full, disk)
        comp_cnts = find_contours(comp)
        best = None
        for c2 in sorted(comp_cnts, key=cv2.contourArea, reverse=True):
            if len(c2) < 5:
                continue
            if cv2.pointPolygonTest(c2, (float(cx), float(cy)), False) >= 0:
                best = c2
                break
        if best is None and comp_cnts:
            best = max(comp_cnts, key=cv2.contourArea)
        if best is None or len(best) < 5:
            continue
        (ecx, ecy), (d1, d2), angle = cv2.fitEllipse(best)
        cands.append(((ecx, ecy), (d1 / 2.0, d2 / 2.0), angle))
    return cands


def analyze_elliptical_target(frame, center, axes, angle):
    """타겟 주변 ROI 만 잘라 '원본 해상도'로 5개 링의 색을 판정.

    center/axes 는 원본 프레임 좌표. 위치 탐색은 저해상도로 하되 링 색
    판독은 풀해상도 ROI 에서 해서, 속도와 정확도를 함께 얻는다.
    """
    h, w = frame.shape[:2]
    cx, cy = center
    a, b = axes
    # 타겟을 감싸는 사각 ROI (약간의 여유)
    rad = max(a, b) * 1.1
    x0, x1 = max(0, int(cx - rad)), min(w, int(cx + rad) + 1)
    y0, y1 = max(0, int(cy - rad)), min(h, int(cy + rad) + 1)
    if x1 - x0 < 5 or y1 - y0 < 5:
        return ["unknown"] * 5, 0, [0.0] * 5
    roi = frame[y0:y1, x0:x1]
    # ROI 가 너무 크면(큰 색 영역) 분석 비용이 튀므로 상한 해상도로 축소.
    # 링당 픽셀은 ANALYZE_MAX_PX/10 이상 유지되어 색 판독 정확도엔 영향 없음.
    fa = 1.0
    m = max(roi.shape[0], roi.shape[1])
    if m > ANALYZE_MAX_PX:
        fa = ANALYZE_MAX_PX / float(m)
        roi = cv2.resize(roi, None, fx=fa, fy=fa, interpolation=cv2.INTER_AREA)
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    lcx, lcy = int(round((cx - x0) * fa)), int(round((cy - y0) * fa))  # ROI 내부 중심
    a, b = a * fa, b * fa
    colors, confs, total = [], [], 0
    for i in range(5):
        scale_out = (i + 0.85) / 5.0
        scale_in = (i + 0.15) / 5.0
        mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
        cv2.ellipse(mask, (lcx, lcy),
                    (max(1, int(a * scale_out)), max(1, int(b * scale_out))),
                    angle, 0, 360, 255, -1)
        cv2.ellipse(mask, (lcx, lcy),
                    (max(1, int(a * scale_in)), max(1, int(b * scale_in))),
                    angle, 0, 360, 0, -1)
        px = hsv[mask > 0]
        if px.size == 0:
            colors.append("unknown"); confs.append(0.0); continue
        color, conf = detect_color_in_pixels(px.reshape(-1, 1, 3))
        if color is None:
            color = "unknown"
        colors.append(color); confs.append(conf)
        if color in COLOR_VALUES:
            total += COLOR_VALUES[color]
    return colors, total, confs


def detect_letter(frame):
    """프레임에서 글자(Φ/Ψ/Ω) 빅팀을 찾아 결과 dict 반환 (없으면 None).

    LETTER_SCALE 축소 프레임에서 Otsu 이진화 후 흑백 윤곽 후보를 뽑아
    classify_letter_shape 로 판별한다. rect 좌표는 원본 해상도로 환산해 돌려준다.
    """
    if not LETTER_ENABLE:
        return None
    if LETTER_SCALE != 1.0:
        small = cv2.resize(frame, None, fx=LETTER_SCALE, fy=LETTER_SCALE,
                           interpolation=cv2.INTER_AREA)
    else:
        small = frame
    inv = 1.0 / LETTER_SCALE
    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    # 글자는 흰 배경 위 큰 검은 획이라 고대비 → Otsu 전역 이진화로 획을 '솔리드'로
    # 채운다. (adaptiveThreshold 는 큰 솔리드 영역을 속 빈 '윤곽선'으로 만들어
    #  템플릿 매칭이 무너졌다: Φ 실측 0.12 → Otsu 0.38.)
    _, bw = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
    h, w = gray.shape
    amin, amax = w * h * 0.005, w * h * 0.7
    cands = []
    for c in find_contours(bw):
        area = cv2.contourArea(c)
        if not (amin < area < amax):
            continue
        x, y, rw, rh = cv2.boundingRect(c)
        if rh == 0 or not (LETTER_ASPECT[0] <= rw / float(rh) <= LETTER_ASPECT[1]):
            continue
        pad = 3
        x1, y1 = max(0, x - pad), max(0, y - pad)
        x2, y2 = min(w, x + rw + pad), min(h, y + rh + pad)
        cands.append((area, bw[y1:y2, x1:x2], (x1, y1, x2 - x1, y2 - y1)))
    if not cands:
        return None
    cands.sort(key=lambda t: t[0], reverse=True)
    best_char, best_conf, best_rect = None, 0.0, None
    for _, roi, rect in cands[:LETTER_MAX_CANDIDATES]:
        if min(roi.shape[:2]) < 12:
            continue
        rx, ry, rw2, rh2 = rect
        # 무채색(흑백) 글자만 인정: 획 픽셀이 색을 띠면(색 동심원 타겟·컬러 물체) 제외
        strokes = small[ry:ry + rh2, rx:rx + rw2][roi > 0]
        if strokes.size:
            s16 = strokes.astype(np.int16)
            chroma = float((s16.max(axis=1) - s16.min(axis=1)).mean())
            if chroma > LETTER_MAX_CHROMA:
                continue
        # 그림자 배제: 진짜 글자는 흰 배경 위 검은 획이라 고대비. 획(어두움) 대비
        # 주변 배경(밝음)의 밝기차가 작으면(회색 그림자) 글자가 아니다.
        crop_g = gray[ry:ry + rh2, rx:rx + rw2]
        st_g, bg_g = crop_g[roi > 0], crop_g[roi == 0]
        if st_g.size and bg_g.size:
            if float(bg_g.mean()) - float(st_g.mean()) < LETTER_MIN_CONTRAST:
                continue
        ch, conf = classify_letter_shape(roi)
        if ch is not None and conf > best_conf:
            best_char, best_conf, best_rect = ch, conf, rect
    if best_char is None:
        return None
    x, y, rw, rh = best_rect
    val = CHAR_VALUE[best_char]
    return {
        "kind": "letter",
        "result": HEALTH_STATUS[val],
        "sum": val,
        "char": best_char,
        "score": round(best_conf, 2),
        "rect": (int(x * inv), int(y * inv), int(rw * inv), int(rh * inv)),
    }


def detect_color(frame):
    """프레임에서 색 동심원 타겟을 찾아 결과 dict 반환 (없으면 None).

    검출 연산은 DETECT_SCALE 배율의 축소 프레임에서 수행하고,
    반환 좌표(cx, cy, r)는 원본 해상도로 환산한다.
    """
    if DETECT_SCALE != 1.0:
        small = cv2.resize(frame, None, fx=DETECT_SCALE, fy=DETECT_SCALE,
                           interpolation=cv2.INTER_AREA)
    else:
        small = frame
    hsv = cv2.cvtColor(small, cv2.COLOR_BGR2HSV)
    inv = 1.0 / DETECT_SCALE
    h, w = small.shape[:2]
    min_axis = min(h, w) * MIN_RADIUS_RATIO
    max_axis = min(h, w) * MAX_RADIUS_RATIO
    for (ecx, ecy), (a, b), angle in locate_candidates(hsv):
        outer = max(a, b)
        if outer < min_axis or outer > max_axis:
            continue
        if min(a, b) / max(a, b) < 0.35:
            continue
        # 링 색 분석은 원본 해상도 ROI 에서 (좌표/축을 원본 스케일로 환산)
        rings, total, confs = analyze_elliptical_target(
            frame, (ecx * inv, ecy * inv), (a * inv, b * inv), angle)
        if any(c == "unknown" for c in rings):
            continue
        if min(confs) < MIN_RING_CONFIDENCE:
            continue
        if total not in HEALTH_STATUS:
            continue
        return {
            "kind": "color",
            "result": HEALTH_STATUS[total],
            "sum": total,
            "rings": rings,                      # 안쪽→바깥쪽
            "conf": round(min(confs), 2),
            "cx": int(ecx * inv), "cy": int(ecy * inv),
            "r": int(round(outer * inv)),
        }
    return None


def detect(frame):
    """글자 빅팀 + 색 동심원 타겟을 통합 검출.

    LETTER_PRIORITY 면 글자를 먼저 보고 잡히면 그것을 반환(색보다 우선),
    아니면 색 동심원을 검출한다. 두 결과 모두 'sum'(0/1/2) 을 가지므로
    이후 UART/오버레이/AUTO_FREEZE 경로는 동일하게 동작한다.
    """
    if LETTER_ENABLE and LETTER_PRIORITY:
        lt = detect_letter(frame)
        if lt is not None:
            return lt
    color = detect_color(frame)
    if color is not None:
        return color
    if LETTER_ENABLE and not LETTER_PRIORITY:
        return detect_letter(frame)
    return None


# ==========================================
# UART 제어
# ==========================================
class Control:
    """UART 명령으로 바뀌는 공유 상태 (Thread-Safe)."""
    def __init__(self):
        self.lock = threading.Lock()
        self.running = True      # 연속 검출 on/off
        self.frozen = False      # 정지(다음 RESUME 까지)
        self.once = False        # 1회 검출 요청
        self.resync = False      # 다음 출력은 값이 같아도 강제로 1회 보냄
        self.quit = False


def open_uart():
    if serial is None:
        print("pyserial 없음 → UART 비활성, stdout 만 사용", flush=True)
        return None
    try:
        ser = serial.Serial(UART_DEV, UART_BAUD, timeout=0.05)
        print("UART 열림: %s @ %d" % (UART_DEV, UART_BAUD), flush=True)
        return ser
    except Exception as e:
        print("UART 열기 실패(%r) → stdout 만 사용" % e, flush=True)
        return None


def send_value(ser, n):
    """판정값 한 줄로 UART(+옵션 stdout) 출력. n 은 -1/0/1/2 정수."""
    line = str(int(n))
    if ser is not None:
        try:
            ser.write((line + "\n").encode())
        except Exception:
            pass
    if ALSO_STDOUT or ser is None:
        print(line, flush=True)


def handle_command(cmd, ctrl, ser):
    """호스트가 보낸 한 줄 명령 처리. (응답은 따로 보내지 않음 - 출력은 -1/0/1/2 만)"""
    cmd = cmd.strip().upper()
    if not cmd:
        return
    with ctrl.lock:
        if cmd in ("START", "RUN"):
            ctrl.running = True; ctrl.frozen = False; ctrl.resync = True
        elif cmd in ("STOP", "IDLE", "PAUSE"):
            ctrl.running = False
        elif cmd == "ONCE":
            ctrl.once = True; ctrl.frozen = False
        elif cmd == "FREEZE":
            ctrl.frozen = True
        elif cmd == "RESUME":
            ctrl.frozen = False; ctrl.running = True; ctrl.resync = True
        elif cmd in ("QUIT", "EXIT"):
            ctrl.quit = True


def uart_reader(ser, ctrl):
    """백그라운드: UART 에서 줄 단위 명령을 읽어 처리."""
    buf = b""
    while True:
        with ctrl.lock:
            if ctrl.quit:
                return
        if ser is None:
            time.sleep(0.2)
            continue
        try:
            data = ser.read(64)
        except Exception:
            time.sleep(0.1); continue
        if not data:
            continue
        buf += data
        while b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            handle_command(line.decode("utf-8", "ignore"), ctrl, ser)


# ==========================================
# 웹 표시 (오버레이 스트림) + 물리 버튼
# ==========================================
RING_BGR = {
    "red": (0, 0, 255), "yellow": (0, 255, 255), "green": (0, 200, 0),
    "blue": (255, 0, 0), "black": (40, 40, 40), "unknown": (160, 160, 160),
}


class Display:
    """웹 표시용 공유 상태 (버튼으로 on/off 토글).

    웹 화면은 'UART 동작'을 시각화하는 보조 역할이다. 카메라 영상/검출
    오버레이 위에, 실제로 UART 로 보낸 값과 제어 상태를 함께 표기한다.
    """
    def __init__(self):
        self.lock = threading.Lock()
        self.on = False          # 웹 오버레이 표시 on/off
        self.frame = None        # 최신 raw BGR 프레임
        self.res = None          # 최신 검출 결과(dict 또는 None)
        self.sent = None         # 마지막으로 UART 로 보낸 값(-1/0/1/2)
        self.state = "RUN"       # 제어 상태: RUN / FROZEN / STOP


STATE_BGR = {"RUN": (0, 200, 0), "FROZEN": (0, 200, 255), "STOP": (0, 0, 255)}


def _text(frame, s, org, scale, color, thick=2):
    """검정 외곽선 + 색 본문으로 가독성 있게 텍스트를 그린다."""
    cv2.putText(frame, s, org, cv2.FONT_HERSHEY_SIMPLEX, scale,
                (0, 0, 0), thick + 2, cv2.LINE_AA)
    cv2.putText(frame, s, org, cv2.FONT_HERSHEY_SIMPLEX, scale,
                color, thick, cv2.LINE_AA)


def draw_overlay(frame, res, sent=None, state="RUN"):
    """카메라 영상 위에 검출 오버레이 + 'UART 동작'(보낸 값/상태)을 표기."""
    h = frame.shape[0]
    # --- 검출 오버레이 (배경/맥락) ---
    if res and res.get("kind") == "letter":
        x, y, rw, rh = res["rect"]
        cv2.rectangle(frame, (x, y), (x + rw, y + rh), (0, 255, 0), 2)
        _text(frame, "LETTER %s  sum=%d  %.2f" % (res["result"], res["sum"], res["score"]),
              (10, 30), 0.7, (0, 255, 0))
    elif res:
        cx, cy, r = res["cx"], res["cy"], res["r"]
        cv2.circle(frame, (cx, cy), r, (0, 255, 0), 2)
        cv2.circle(frame, (cx, cy), 3, (0, 255, 0), -1)
        for i, name in enumerate(res["rings"]):   # 안쪽→바깥쪽 링 색
            ry = int(r * (i + 0.5) / 5.0)
            cv2.circle(frame, (cx, cy - ry), 5, RING_BGR.get(name, (200, 200, 200)), -1)
        _text(frame, "%s  sum=%d  conf=%.2f" % (res["result"], res["sum"], res["conf"]),
              (10, 30), 0.7, (0, 255, 0))
        _text(frame, " > ".join(res["rings"]), (10, h - 15), 0.55, (255, 255, 255))
    elif state == "RUN":
        # 검출 중인데 타겟이 없을 때만 표시 (정지/멈춤 상태는 상태 라벨로 충분)
        _text(frame, "no target", (10, 30), 0.7, (0, 0, 255))

    # --- UART 동작 (메인 정보) : 보낸 값 + 제어 상태 ---
    sval = "-" if sent is None else str(sent)
    _text(frame, "UART > %s" % sval, (10, h - 50), 0.9, (0, 255, 255), 2)
    _text(frame, state, (frame.shape[1] - 150, 30), 0.8,
          STATE_BGR.get(state, (200, 200, 200)), 2)
    return frame


def _off_frame():
    img = np.zeros((FRAME_H, FRAME_W, 3), dtype=np.uint8)
    cv2.putText(img, "DISPLAY OFF", (FRAME_W // 2 - 150, FRAME_H // 2 - 10),
                cv2.FONT_HERSHEY_SIMPLEX, 1.1, (80, 80, 80), 3, cv2.LINE_AA)
    cv2.putText(img, "hold button 3s", (FRAME_W // 2 - 130, FRAME_H // 2 + 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (80, 80, 80), 2, cv2.LINE_AA)
    ok, jpg = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY])
    return jpg.tobytes() if ok else b""


def button_watcher(disp, ctrl):
    """윗면 물리 버튼(gpio2):
       - 짧게 누름(< BUTTON_LONG_SEC)  → RESUME (AUTO_FREEZE 정지 해제)
       - 길게 누름(>= BUTTON_LONG_SEC) → 웹 표시 ON/OFF 토글
    """
    pressed_level = "0" if BUTTON_ACTIVE_LOW else "1"
    try:
        f = open(BUTTON_PATH, "r")
    except Exception as e:
        print("버튼 열기 실패(%r) → 버튼 비활성" % e, flush=True)
        return
    prev = None
    press_t = None       # 눌리기 시작한 시각
    long_fired = False   # 이번 눌림에서 '길게' 동작을 이미 실행했는지
    while True:
        try:
            f.seek(0)
            cur = f.read().strip()
        except Exception:
            time.sleep(0.2); continue
        pressed = (cur == pressed_level)
        was_pressed = (prev == pressed_level)

        # 눌림 시작(엣지): 타이머 시작
        if prev is not None and not was_pressed and pressed:
            press_t = time.time()
            long_fired = False

        # 누르고 있는 동안 3초 도달 → '길게'(웹 표시 토글) 1회 발화
        if pressed and press_t is not None and not long_fired \
                and (time.time() - press_t) >= BUTTON_LONG_SEC:
            with disp.lock:
                disp.on = not disp.on
                on = disp.on
            print("[button] (long) 웹 표시 %s" % ("ON" if on else "OFF"), flush=True)
            long_fired = True

        # 뗌(엣지): '길게'가 아니었으면 짧게 → RESUME
        if prev is not None and was_pressed and not pressed:
            if press_t is not None and not long_fired:
                with ctrl.lock:
                    ctrl.frozen = False
                    ctrl.running = True
                    ctrl.resync = True
                print("[button] (short) RESUME", flush=True)
            press_t = None
            long_fired = False
            time.sleep(0.2)  # 디바운스

        prev = cur
        time.sleep(0.03)


def mjpeg_generator(disp):
    boundary = b"--frame\r\n"
    while True:
        with disp.lock:
            on = disp.on
            frame = disp.frame.copy() if (on and disp.frame is not None) else None
            res = disp.res
            sent, state = disp.sent, disp.state
        if not on:
            jpg = _off_frame()
            yield boundary + b"Content-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.2)
            continue
        if frame is None:
            time.sleep(0.03)
            continue
        draw_overlay(frame, res, sent, state)
        ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY])
        if ok:
            yield boundary + b"Content-Type: image/jpeg\r\n\r\n" + buf.tobytes() + b"\r\n"
        time.sleep(0.05)


INDEX_HTML = """<!doctype html><html><head><meta charset=utf-8>
<title>UnitV2 Target</title>
<style>body{margin:0;background:#111;color:#eee;font-family:sans-serif;text-align:center}
img{max-width:100%;height:auto}h3{margin:10px}</style></head>
<body><h3>UnitV2 Target Detect</h3>
<img src="/stream"><p>윗면 버튼: 짧게=RESUME, 3초 길게=표시 ON/OFF</p></body></html>"""


def start_web_server(disp):
    if not WEB_ENABLE or Flask is None:
        if WEB_ENABLE and Flask is None:
            print("flask 없음 → 웹 표시 비활성", flush=True)
        return
    app = Flask(__name__)

    @app.route("/")
    def index():
        return INDEX_HTML

    @app.route("/stream")
    def stream():
        return Response(mjpeg_generator(disp),
                        mimetype="multipart/x-mixed-replace; boundary=frame")

    def run():
        try:
            app.run(host="0.0.0.0", port=WEB_PORT, threaded=True)
        except Exception as e:
            print("웹 서버 시작 실패(%r)" % e, flush=True)

    threading.Thread(target=run, daemon=True).start()
    print("웹 표시 서버: http://<기기IP>:%d/" % WEB_PORT, flush=True)


# ==========================================
# 카메라 캡처 스레드 (항상 최신 프레임만 유지)
# ==========================================
class Camera:
    """카메라 래퍼 — 메인 루프에서 직접 동기 read(). 캡처 스레드 없음.

    캡처 스레드를 쓰면 fps 는 다소 오르지만, detect 가 카메라보다 느릴 때
    드라이버 버퍼에 프레임이 쌓여 '오래된 프레임'을 처리하게 된다(지연 누적).
    여기서는 fps 가 낮더라도 항상 '최신 프레임'을 처리하는 쪽을 택한다.
    BUFFERSIZE=1 로 적체를 막아, read() 가 늘 가장 최근 프레임을 돌려준다.
    """
    def __init__(self, idx):
        self.cap = cv2.VideoCapture(idx)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, FRAME_W)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_H)
        self.cap.set(cv2.CAP_PROP_FPS, CAM_FPS)
        try:
            self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)   # 프레임 적체 방지(최신만)
        except Exception:
            pass
        print("cam: %dx%d @ %.0ffps(요청 %d)" % (
            self.cap.get(cv2.CAP_PROP_FRAME_WIDTH),
            self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT),
            self.cap.get(cv2.CAP_PROP_FPS), CAM_FPS), flush=True)

    def opened(self):
        return self.cap.isOpened()

    def start(self):
        return self          # 호환용 (별도 스레드 없음)

    def read(self):
        ok, f = self.cap.read()
        return f if ok else None

    def release(self):
        self.cap.release()


# ==========================================
# 메인 루프 (온보드 실행)
# ==========================================
def main():
    cam = Camera(CAM_IDX)

    ser = open_uart()
    ctrl = Control()
    threading.Thread(target=uart_reader, args=(ser, ctrl), daemon=True).start()

    disp = Display()
    start_web_server(disp)
    threading.Thread(target=button_watcher, args=(disp, ctrl), daemon=True).start()

    # 종료 신호(SIGTERM/SIGINT) 시 카메라를 깨끗이 해제하고 빠져나간다.
    # (kill -9 로 강제 종료하면 /dev/video0 가 정상 반납되지 않아 다음 실행이
    #  저프레임으로 떨어진다. 재시작은 TERM 으로 보내야 함.)
    def _term(_sig, _frm):
        with ctrl.lock:
            ctrl.quit = True
    signal.signal(signal.SIGTERM, _term)
    signal.signal(signal.SIGINT, _term)

    if not cam.opened():
        send_value(ser, -1)          # 카메라 실패도 -1(인식 안 됨)로 통일
        return
    cam.start()

    # 부팅 시 항상 능동 검출(RUN) 상태로 시작 — 정지(FROZEN)/멈춤(STOP) 아님.
    # 버튼이나 웹 접속 없이도 곧바로 검출을 시작한다. AUTO_FREEZE 는 '검출 후'에만
    # 정지시키며, 이후 재개는 버튼 짧게(RESUME) 또는 호스트 RESUME 명령으로 한다.
    with ctrl.lock:
        ctrl.running = True
        ctrl.frozen = False

    last_sum, stable = None, 0       # 안정성 추적
    last_sent = None                 # 마지막으로 보낸 값(중복 전송 방지)
    fps_n, fps_t = 0, time.time()    # 검출 fps 측정
    while True:
        with ctrl.lock:
            if ctrl.quit:
                break
            running, frozen = ctrl.running, ctrl.frozen
            once = ctrl.once
            ctrl.once = False
            resync = ctrl.resync
            ctrl.resync = False

        # 캡처 스레드에서 최신 프레임 즉시 획득 (블로킹 없음)
        frame = cam.read()
        if frame is None:
            time.sleep(0.01)
            continue
        cur_state = "STOP" if not running else ("FROZEN" if frozen else "RUN")
        with disp.lock:
            disp.frame = frame
            disp.state = cur_state

        # ONCE 가 아니고, 정지/멈춤 상태면 검출 건너뜀.
        # 이때 검출이 갱신되지 않으므로 옛 타겟 오버레이가 박혀 보이지 않도록 지운다.
        # (UART 로 보낸 값 disp.sent 와 상태는 그대로 표시 → "무엇을 보고했는지"는 유지)
        if not once and (frozen or not running):
            with disp.lock:
                disp.res = None
            time.sleep(0.02)
            continue

        res = detect(frame)
        with disp.lock:
            disp.res = res
        cur_sum = res["sum"] if res else None   # 0/1/2 또는 None

        # 검출 fps 로깅
        if PRINT_FPS_SEC > 0:
            fps_n += 1
            dt = time.time() - fps_t
            if dt >= PRINT_FPS_SEC:
                print("fps=%.1f (web=%s)" % (fps_n / dt, disp.on), flush=True)
                fps_n, fps_t = 0, time.time()

        # ONCE: 안정성 무시하고 현재 값 1회 보고 (-1/0/1/2)
        if once:
            v = cur_sum if cur_sum is not None else -1
            send_value(ser, v)
            with disp.lock:
                disp.sent = v
            continue

        # 연속 모드: 같은 값 STABLE_FRAMES 연속이어야 확정
        if cur_sum is not None and cur_sum == last_sum:
            stable += 1
        else:
            stable = 1 if cur_sum is not None else 0
        last_sum = cur_sum

        if cur_sum is not None and stable >= STABLE_FRAMES:
            value = cur_sum          # 0/1/2
        else:
            value = -1               # 인식 안 됨

        # 값이 바뀌었을 때(또는 resync 요청 시)만 전송 → 스트림 깔끔
        if value != last_sent or resync:
            send_value(ser, value)
            last_sent = value
            with disp.lock:
                disp.sent = value
            if AUTO_FREEZE and value != -1:
                with ctrl.lock:
                    ctrl.frozen = True   # 확정 후 다음 RESUME 까지 정지
                last_sum, stable, last_sent = None, 0, None

        # detect() 자체가 프레임을 페이싱하므로 큰 sleep 불필요.
        # 다른 스레드(UART/버튼/웹)에 양보할 최소한만 쉰다.
        time.sleep(0.003)

    cam.release()
    if ser is not None:
        ser.close()


if __name__ == "__main__":
    main()
