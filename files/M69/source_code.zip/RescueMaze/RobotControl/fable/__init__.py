"""
fable — BaseX 미로 로봇 정리본 라이브러리 패키지.

기존 리포 루트의 basex/devices/VL53L0X/dropper/logger + astar 를 검증된 동작 그대로
가져오되, 실주행에서 확인된 버그(내리막 오탐, ToF 무한 재시도, print 플러딩)를 고치고
최근 튜닝(PI 직진, 감속 스케일링, 컬러 ATIME/GAIN)을 반영해 새로 구성했다.

설계 원칙(검증된 제약에서 도출):
  ① 두 스레드가 I2C를 만지면 무조건 259(ESP_ERR_INVALID_STATE).
  ② async 함수 안에서 I2C를 호출해도 에러.
  ③ 락은 핫루프에 너무 느림.
→ 모든 I2C는 메인 제너레이터 루프라는 단 하나의 동기 컨텍스트에서만 직접 호출한다.

모듈 구성:
  scheduler  — gsleep/grun/grace 제너레이터 협력 스케줄러
  drivebase  — BASEX 모터 컨트롤러 DriveBase (구 basex.py)
  devices    — PaHub / ColorSensor / IMU / Touch (구 devices.py)
  vl53l0x    — ToF 거리센서 드라이버 (구 VL53L0X.py)
  dropper    — UnitV2 UART + 서보 투하 (구 dropper.py)
  logger     — error.log 기록 (구 logger.py)
  astar      — 그리드/A*/시각화 (구 astar/ 3파일 통합)

메인 앱은 apps/fa_main.py.
"""
