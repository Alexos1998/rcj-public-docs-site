"""error.log 기록 (구 logger.py 정리본, 로직 동일).

⚠ init_logging()은 모든 print()마다 플래시에 append 한다 — 빠른 루프 안에서 매 틱
print 하면 플래시 쓰기+USB 버퍼로 루프가 멈칫한다. 디버그 출력은 이벤트당 1회 원칙.
"""

import sys
import time

_LOG_FILE = "error.log"
_MAX_BYTES = 1048576  # 플래시 절약: 1MB 초과 시 비우고 다시 씀


def init_logging():
    """모든 print() 출력을 error.log에 동시 기록한다."""
    import builtins
    _orig = builtins.print

    def _print(*args, **kwargs):
        _orig(*args, **kwargs)
        sep = kwargs.get("sep", " ")
        end = kwargs.get("end", "\n")
        line = sep.join(str(a) for a in args) + end
        try:
            with open(_LOG_FILE, "a") as f:
                f.write(line)
        except OSError:
            pass

    builtins.print = _print


def log_error(e, context=""):
    """예외를 error.log에 저장. 트레이스백 포함."""
    try:
        try:
            import os
            if os.stat(_LOG_FILE)[6] > _MAX_BYTES:
                _clear()
        except OSError:
            pass

        with open(_LOG_FILE, "a") as f:
            f.write("=== %dms" % time.ticks_ms())
            if context:
                f.write(" [%s]" % context)
            f.write(" ===\n")
            sys.print_exception(e, f)
            f.write("\n")
    except Exception:
        pass  # 로그 저장 실패는 무시


def read_log():
    """저장된 로그 반환."""
    try:
        with open(_LOG_FILE, "r") as f:
            return f.read()
    except OSError:
        return ""


def _clear():
    try:
        with open(_LOG_FILE, "w") as f:
            f.write("")
    except OSError:
        pass
