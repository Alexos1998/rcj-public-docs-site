"""
UnitV2 2대(UART) → 서보 투하 (구 dropper.py 정리본, 로직 동일). 투하 행위는 drive 함수에 귀속.

각 UnitV2는 좌/우 한 대씩 물리적으로 다른 UART 포트에 연결돼, victim 의 건강상태를
한 줄 정수로 보낸다(RCJ 3.6/3.7): -1=쓰레기값(미검출), 0=Unharmed(키트0),
1=Stable(키트1), 2=Harmed(키트2). "어느 카메라에서 왔는지"로 투하 방향(좌/우),
"값"으로 투하할 키트 수를 정한다. 카메라는 RESUME\n 를 받을 때마다 재무장된다.

drive 함수에서의 사용:
  dropper.start()                     # drive 시작 시 — 두 카메라에 RESUME 송신(둘 다 무장)
  r = dropper.poll()                  # drive 매 틱 — (카메라 index, 키트수) 또는 None
  dropper.resume(cam)                 # 오검출(해당 방향에 벽 없음) 시 — 그 카메라만 다시 무장
  yield from dropper.drop(cam, kits)  # 잠시 멈춰 키트수만큼 서보 동작 후 중립 복귀(카운트 감소)

좌/우 적재량은 left_count/right_count(기본 5/5). 0이 되면 그 방향은 더 투하하지 않는다.
서보는 BASEX(I2C0) 너머라 robot.set_servo_angle()로 제어 — 메인 루프 단일 컨텍스트에서만
I2C에 접근하므로 259(동시 접근) 문제가 없다. UART는 별도 자원이라 I2C와 무관.
"""

import time
from machine import UART, Pin


def _gsleep(ms):
    # drive 컨텍스트에서 ms 동안 매 틱 양보(자이로 적분은 상위 grace가 펌프).
    end = time.ticks_add(time.ticks_ms(), ms)
    while time.ticks_diff(end, time.ticks_ms()) > 0:
        yield


class Dropper:
    def __init__(self, robot, servo=1, neutral=90,
                 left_angle=20, right_angle=160,
                 left_count=5, right_count=5,
                 drop_hold_ms=500,
                 left_uart=(0, 17, 18),   # (id, tx, rx) 왼쪽 카메라
                 right_uart=(1, 9, 8),    # (id, tx, rx) 오른쪽 카메라
                 baud=115200):
        self._robot = robot
        self._servo = servo
        self._neutral = neutral
        # 카메라 index 0=왼쪽, 1=오른쪽. 각 방향의 투하 각도 / 남은 적재량.
        self._angle = (left_angle, right_angle)
        self._count = [left_count, right_count]
        self._hold = drop_hold_ms

        # UART 2개 (8N1, 논블로킹: timeout=0). index 0=왼쪽, 1=오른쪽.
        self._uarts = [
            UART(left_uart[0], baudrate=baud, bits=8, parity=None, stop=1,
                 tx=Pin(left_uart[1]), rx=Pin(left_uart[2]), timeout=0),
            UART(right_uart[0], baudrate=baud, bits=8, parity=None, stop=1,
                 tx=Pin(right_uart[1]), rx=Pin(right_uart[2]), timeout=0),
        ]
        self._rxbuf = [b"", b""]   # 카메라별 줄조립 버퍼

        self._robot.set_servo_angle(self._servo, self._neutral)   # 시작 시 중립

    def is_right(self, cam):
        # 카메라 index → 오른쪽이면 True. drive 가 좌/우 ToF 센서를 고르는 데 쓴다.
        return cam == 1

    def _resume(self, i):
        # 카메라 i 를 다시 무장 — 밀린 옛 수신/줄버퍼는 버리고 RESUME 송신.
        u = self._uarts[i]
        if u.any():
            u.read()
        self._rxbuf[i] = b""
        try:
            u.write(b"RESUME\n")
        except Exception:
            pass

    def start(self):
        # drive 시작 — 두 카메라 모두 무장(RESUME).
        self._resume(0)
        self._resume(1)

    def resume(self, cam):
        # 오검출(해당 방향에 벽 없음)일 때 — 그 카메라만 다시 무장.
        self._resume(cam)

    def poll(self):
        # 두 카메라 폴링 — 건강상태값이 수신된 카메라를 (index, 키트수)로 반환(없으면 None).
        # 카메라는 victim 건강상태(RCJ 3.6/3.7)를 한 줄 정수로 보낸다:
        #   -1=쓰레기값(미검출) → 무시,  0=Unharmed(키트0),  1=Stable(키트1),  2=Harmed(키트2).
        # 여러 줄이 쌓였으면 가장 최근 줄만 본다(밀린 옛 신호 무시).
        for i in (0, 1):
            u = self._uarts[i]
            n = u.any()
            if n:
                self._rxbuf[i] += u.read(n)
            val = None
            while b"\n" in self._rxbuf[i]:
                line, self._rxbuf[i] = self._rxbuf[i].split(b"\n", 1)
                line = line.strip()
                if line:
                    try:
                        val = int(line)
                    except ValueError:
                        pass
            # -1(쓰레기)·None 은 그대로 둔다 — 0/1/2 (키트 수)일 때만 보고.
            if val is not None and val in (0, 1, 2):
                return i, val
        return None

    def drop(self, cam, kits=1):
        # cam 방향으로 kits 개를 투하 — 서보 1회 왕복(중립→투하각→중립)=키트 1개.
        # 남은 적재량 한도 내에서만 투하하고, 실제 투하한 개수를 반환한다(0 가능).
        # drive 가 yield from 으로 호출하며 반환값을 받는다.
        n = min(kits, self._count[cam])
        if n <= 0:
            return 0
        self._robot.stop()                                          # 잠시 멈춤(모터 정지)
        for _ in range(n):
            self._robot.set_servo_angle(self._servo, self._angle[cam])
            yield from _gsleep(self._hold)
            self._robot.set_servo_angle(self._servo, self._neutral)  # 중립 복귀
            yield from _gsleep(self._hold)
            self._count[cam] -= 1
        return n
