"""
그리드/A*/시각화 — 구 astar/grid.py + Astar.py + visualize.py 통합 정리본 (로직 동일).

벽 비트 규약(시각적 레이아웃 기준): bit0=N벽, bit1=S벽, bit2=W벽, bit3=E벽 (1=벽 있음).
wall == -1 은 미탐색 셀(사방 벽 취급 → A*가 통과하지 않음).
"""

from collections import namedtuple
import heapq

direction = namedtuple('direction', ['x', 'y'])


class Color:
    # 타일 색 상수 — Node.color / get_cost 매핑용 (구 utils.Color에서 필요분만).
    RED = "RED"
    BLUE = "BLUE"
    GREEN = "GREEN"
    SILVER = "SILVER"
    BLACK = "BLACK"
    CYAN = "CYAN"


# -----------------------------------------------------------------------
# 탐색 그리드 노드 (구 grid.py)
# -----------------------------------------------------------------------

class Node:
    def __init__(self, x, y, wall, color=None, originPos=None):
        if originPos is None:
            originPos = [0, 0]
        self.x = x
        self.y = y
        self.xx = originPos[0]
        self.yy = originPos[1]
        self.wall = wall
        self.color = color  # None / Color.RED / Color.BLUE / ...

    def __repr__(self):
        return 'Node(x=%d, y=%d, wall=%d, color=%s, oPos=%d,%d)' % (
            self.x, self.y, self.wall, self.color, self.xx, self.yy)

    def set_xy(self, x, y):
        self.x = x
        self.y = y

    def add_xy(self, x, y):
        self.x += x
        self.y += y

    def add_origin(self, xx, yy):
        self.xx += xx
        self.yy += yy

    def pos(self, dir=direction(0, 0)):
        return direction(self.x + dir.x, self.y + dir.y)

    def copy(self):
        return Node(self.x, self.y, self.wall, self.color, originPos=[self.xx, self.yy])

    def get_cost(self):
        return {Color.RED: 5, Color.BLUE: 3, None: 0, Color.BLACK: 0, Color.CYAN: 'A'}[self.color]


class NNode(Node):
    # 미탐색 셀 자리표시자 — wall=-1(사방 벽 취급).
    def __init__(self):
        super().__init__(0, 0, -1)


# -----------------------------------------------------------------------
# A* 경로 탐색 (구 Astar.py) — 내부 노드는 이름 충돌 방지를 위해 PathNode.
# -----------------------------------------------------------------------

class PathNode:
    def __init__(self, x, y, wall, cost):
        self.x = x
        self.y = y
        self.wall = wall
        self.parent = 0
        self.g = float('inf')
        self.h = 0
        self.cost = 0
        self.rift = False
        if cost == "A":
            self.rift = True
        else:
            self.cost = cost

    def __repr__(self):
        return 'PathNode({},{},{},{},{})'.format(self.x, self.y, self.wall, self.get_cost(), self.g)

    def get_cost(self):
        return self.g + self.h + self.cost

    def __lt__(self, other):
        """ heapq에서 최소값 정렬을 위해 필요 """
        return self.get_cost() < other.get_cost()

    def __eq__(self, other):
        """ 노드 비교를 위해 필요 """
        return self.x == other.x and self.y == other.y

    def __sub__(self, other):
        return direction(self.x - other.x, self.y - other.y)

    def __add__(self, other):
        return direction(self.x + other.x, self.y + other.y)

    def __hash__(self):
        """ set에 추가할 수 있도록 hash 함수 추가 """
        return hash((self.x, self.y))


def get_grid(grid):
    return [[PathNode(i, j, grid[j][i].wall, grid[j][i].get_cost())
             for i in range(len(grid[0]))] for j in range(len(grid))]


def get_directions(grid, startPos, targetPos, isGriding=False):
    """
    A* 알고리즘을 사용하여 startPos에서 targetPos까지의 최단 경로를 찾는 함수.

    :param grid: 2D 리스트 형태의 맵 (Node 객체)
    :param startPos: 출발 지점의 [x, y] 좌표
    :param targetPos: 목표 지점의 [x, y] 좌표
    :return: 이동 방향(direction) 리스트
    """
    overflow = False
    if len(grid) <= targetPos[1] or targetPos[1] < 0:
        targetPos[1] = max(0, min(len(grid) - 1, targetPos[1]))
        overflow = True
    if len(grid[0]) <= targetPos[0] or targetPos[0] < 0:
        targetPos[0] = max(0, min(len(grid[0]) - 1, targetPos[0]))
        overflow = True
    grid = get_grid(grid)  # PathNode 객체로 이루어진 새로운 grid 생성

    startNode = grid[startPos[1]][startPos[0]]
    targetNode = grid[targetPos[1]][targetPos[0]]

    openList = []    # 탐색할 노드를 저장하는 우선순위 큐 (힙)
    openSet = set()  # 중복 방지를 위한 set
    closedSet = set()  # 이미 방문한 노드를 저장하는 set
    nodeList = []    # 최종 경로 저장 리스트

    # 시작 노드 초기화 및 추가
    startNode.g = 0
    startNode.h = (abs(startNode.x - targetNode.x) + abs(startNode.y - targetNode.y)) * 10
    heapq.heappush(openList, startNode)
    openSet.add(startNode)

    def append_open_list(x, y):
        """ 주어진 (x, y) 위치의 노드를 openList에 추가하는 함수 """
        if 0 <= x < len(grid[0]) and 0 <= y < len(grid):  # 좌표 유효성 검사
            nNode = grid[y][x]
            if nNode in closedSet:
                return

            # 이동 비용 계산 (현재 노드의 g + 이동거리 10)
            moveCost = nextNode.g + 10

            # 더 짧은 경로를 발견했을 때만 갱신
            if moveCost < nNode.g:
                nNode.g = moveCost
                nNode.h = (abs(nNode.x - targetNode.x) + abs(nNode.y - targetNode.y)) * 10
                nNode.parent = nextNode

                if nNode not in openSet:
                    heapq.heappush(openList, nNode)
                    openSet.add(nNode)

    # A* 알고리즘 실행
    while openList:
        nextNode = heapq.heappop(openList)
        openSet.remove(nextNode)  # openSet에서 제거
        closedSet.add(nextNode)   # 방문한 노드 저장

        # 목표 도착 시 경로 반환
        if nextNode == targetNode:
            fNode = nextNode.parent
            while fNode:
                if fNode.rift:
                    fNode = fNode.parent
                    continue
                nodeList.insert(0, nextNode - fNode)  # 경로 역추적
                nextNode = fNode
                fNode = fNode.parent
            if (not overflow) and isGriding:
                try:
                    nodeList.pop()
                except IndexError:
                    pass
            return nodeList  # 최종 경로 반환

        n, s, w, e = get_azimuth(nextNode.wall)

        if not n:
            append_open_list(nextNode.x, nextNode.y - 1)  # 북쪽 이동
        if not s:
            append_open_list(nextNode.x, nextNode.y + 1)  # 남쪽 이동
        if not w:
            append_open_list(nextNode.x - 1, nextNode.y)  # 서쪽 이동
        if not e:
            append_open_list(nextNode.x + 1, nextNode.y)  # 동쪽 이동

    raise Exception("A*: no path found")


def get_azimuth(wall):
    if wall == -1:
        return 1, 1, 1, 1
    # bit0=N벽, bit1=S벽, bit2=W벽, bit3=E벽 (1=벽 있음)
    return (wall & 1), (wall >> 1) & 1, (wall >> 2) & 1, (wall >> 3) & 1


# -----------------------------------------------------------------------
# 그리드 텍스트 시각화 (구 visualize.py) — 디버그 출력용.
# -----------------------------------------------------------------------

li_dir = [
    ["↑", "▲"],
    ["→", "▶"],
    ["↓", "▼"],
    ["←", "◀"]
]


def _viz_expand(pos, dir, grid):
    # 시각화 전용 그리드 확장 — create_grid(dir=...)에서만 쓴다.
    dx = dy = gx = gy = 0

    if dir.x != 0:
        if len(grid[0]) <= pos.x + dir.x or pos.x + dir.x + 1 <= 0:
            gx = 1
            if dir.x < 0:
                dx = 1

    if dir.y != 0:
        if len(grid) <= pos.y + dir.y or pos.y + dir.y + 1 <= 0:
            gy = 1
            if dir.y < 0:
                dy = 1

    tGrid = [[-1 for _ in range(len(grid[0]) + gx)] for _ in range(len(grid) + gy)]

    for y in range(len(grid)):
        for x in range(len(grid[0])):
            tGrid[y + dy][x + dx] = grid[y][x]

    return tGrid


def create_grid(dg, pos=direction(0, 0), heading=None, dir=None):
    # 정수 벽값 2D 리스트(dg)를 벽 문자로 그려 print 한다. pos/heading이 있으면
    # 현재 위치에 방향 화살표를 찍는다. dir이 있으면 그 방향으로 한 칸 확장해 그린다.
    if dir is not None:
        dg = _viz_expand(pos, dir, dg)
        pos = direction(pos.x + (1 if dir.x > 0 else 0), pos.y + (1 if dir.y > 0 else 0))

    grid = ""

    g = dg[0]
    for i in range(len(dg[0])):
        upper_str = "  "
        if g[i] % 2 == 1 and g[i] != -1:
            upper_str = " _"
        grid += upper_str
    grid += "\n"

    for i, g in enumerate(dg):
        for j, e in enumerate(g):
            el = " "
            has_w = (e != -1 and num_to_col(e))
            has_prev_e = (j > 0 and g[j - 1] != -1 and num_to_col1(g[j - 1]))
            if has_w or has_prev_e:
                el = "|"
            grid += el
            el = " "
            if e == -1:
                el = "□"
            if e % 4 >= 2 and g[j] != -1:
                el = "_"
            if len(dg) > i + 1 and dg[i + 1][j] % 2 == 1 and dg[i + 1][j] != -1 and e == -1:
                el = "■"
            if heading is not None and i == pos.y and j == pos.x:
                el = li_dir[heading][e % 4 >= 2 if e != -1 else 0]
            grid += el
        escape_str = "|\n"
        if heading is not None and 0 <= e < 8 or e == -1:
            escape_str = "\n"
        grid += escape_str

    print(grid)


def num_to_col(i):
    if i >= 12:
        return 1
    if i >= 8:
        return 0
    if i >= 4:
        return 1
    return 0


def num_to_col1(i):
    if i >= 8:
        return 1
    return 0
