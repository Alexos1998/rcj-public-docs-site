"""
I2C 디바이스 드라이버 — 단일 컨텍스트 직접접근 (구 devices.py 정리본).

설계 원칙(검증된 제약에서 도출):
  ① 두 스레드가 I2C를 만지면 무조건 259(ESP_ERR_INVALID_STATE).
  ② async 함수 안에서 I2C를 호출해도 에러.
  ③ 락은 핫루프에 너무 느림.
→ 모든 I2C는 메인 제너레이터 루프라는 단 하나의 동기 컨텍스트에서만 직접 호출한다.
  백그라운드 스레드도, reader/writer 등록·tick() 간접층도 두지 않는다. 각 디바이스가
  필요할 때 곧바로 읽고/쓴다. 스레드가 없으니 동시 접근(259)이 구조적으로 불가능하다.
"""

import time
from machine import Pin, I2C, SoftI2C

PAHUB_ADDR = 0x70


# -----------------------------------------------------------------------
# PaHub (I2C 멀티플렉서) + 그 너머의 I2C 디바이스들
# -----------------------------------------------------------------------

class PaHub:
    def __init__(self, sda=2, scl=1, id=1, freq=100000):
        self._sda, self._scl, self._id, self._freq = sda, scl, id, freq
        # I2C는 여기서 만들지 않는다. __init__과 start()가 둘 다 I2C(포트1)을 만들면
        # 첫 객체가 참조 끊겨 GC될 때 finalizer가 i2c_driver_delete(포트1)을 호출,
        # start()가 만든 같은 포트의 드라이버까지 증발시켜 이후 writeto가 259가 된다.
        self.i2c = None
        self._current_channel = None

    def start(self):
        # I2C 컨트롤러 초기화. 이 뒤에 VL53L0X 등 디바이스를 생성해야 한다(생성 시 hub.i2c 참조).
        self.i2c = SoftI2C(sda=Pin(self._sda), scl=Pin(self._scl), freq=self._freq)
        print(self.i2c.scan())
        self._current_channel = None

    def _set_channel(self, channel):
        if self._current_channel != channel:
            self.i2c.writeto(PAHUB_ADDR, bytes([1 << channel]))
            self._current_channel = channel

    def get(self, devices):
        """여러 센서를 직접 읽는다 — 각 센서 채널로 전환 후 _read(). 메인 제너레이터
        루프 단일 컨텍스트에서만 호출되어 충돌이 없다. 노이즈성 실패는 직전 캐시(_last)를
        그대로 반환해 9999로 떨어지지 않게 한다."""
        out = []
        for d in devices:
            try:
                self._set_channel(d.channel)
                d._last = d._read()
            except OSError:
                pass
            out.append(d._last)
        return out


class I2CDevice:
    def __init__(self, hub: PaHub, channel, addr):
        self.address = addr
        self.channel = channel
        self._hub = hub
        self._last = 9999            # 마지막 측정 캐시 (초기값=벽없음, 읽기 실패 시 폴백)
        hub._set_channel(channel)
        self._init()

    @property
    def i2c(self):
        # 항상 hub의 현재 I2C를 참조 — hub.start() 재초기화 후에도 유효.
        return self._hub.i2c

    def _init(self):
        pass

    def get(self):
        """단일 센서를 직접 읽는다 — 채널 전환 후 _read(). 실패 시 직전 캐시 반환."""
        try:
            self._hub._set_channel(self.channel)
            self._last = self._read()
        except OSError:
            pass
        return self._last

    def _read(self):
        pass


# -----------------------------------------------------------------------
# ColorSensor (TCS3472) — RCJ 바닥 타일 분류
# -----------------------------------------------------------------------

class ColorSensor(I2CDevice):
    # RCJ Rescue Maze 바닥 타일 기준점 (w, r, g, b) — apps/color_cal.py 로 보정해 갱신.
    # 분류는 측정값과 가장 가까운(4채널 유클리드 거리 최소) 기준점을 고른다 → 한 채널이
    # 아니라 밝기(w)와 색(r,g,b)을 동시에 본다. 환경 바뀌면 이 표만 다시 측정해 바꾼다.
    # ⚠ ATIME/GAIN(_init)을 바꾸면 raw 스케일이 달라지므로 반드시 재보정할 것.

    REF = [
        #  name      w    r    g    b
        ("black",  85,  23,  29,  36),
        ("blue",  105,  23,  34,  50),
        ("red",   111,  44,  32,  39),
        ("white", 253,  73,  84,  94),
        ("silver",308,  90, 111, 126),
    ]

    REF_REV = [
        #  name      w    r    g    b
        ("black",  95,  20,  33,  44),
        ("blue",  118,  20,  39,  62),
        ("red",   117,  42,  35,  46),
        ("white", 249,  64,  87, 103),
        ("silver",262,  70,  92, 113),
    ]

    # 규정(3.2 Floor)상 각 타일색의 의미/요구 동작
    MEANING = {
        "black":  "HOLE",        # 구멍 → 진입 금지
        "silver": "CHECKPOINT",  # 체크포인트
        "blue":   "PUDDLE",      # 웅덩이 → 진입 시 5초 정지
        "red":    "DANGER",      # 위험구역 입구
        "white":  "NORMAL",      # 일반 타일
    }

    def __init__(self, hub: PaHub, channel, ref=None):
        # ref 생략 시 클래스 기본 REF 공유. 센서 개체차 보정이 필요하면 이 센서 전용
        # 기준표를 넘긴다(인스턴스 속성이 클래스 REF를 가려 self.REF로 각각 분류됨).
        if ref is not None:
            self.REF = ref
        super().__init__(hub, channel, 0x29)

    def _init(self):
        # ATIME(적분시간) — 하드웨어 하한(1cycle=2.4ms)까지 내려봤더니 광량 부족으로
        # 색상 간 카운트 차이가 1~3 수준(노이즈 레벨)까지 떨어져 오분류 위험이 커졌다.
        # 24ms(10cycle)면 신호는 충분히 확보되면서도, 이 속도(150mm/s)에서 한 사이클
        # 동안 로봇이 3.6mm밖에 안 움직여 체감 반응성엔 지장 없다 → 이 값으로 고정.
        # 소프트리셋 사이엔 레지스터가 리셋되지 않아 이전 세션(UIFlow 등)이 남겨둔 값이
        # 그대로 남을 수 있으므로 매번 명시적으로 써준다.
        self._hub.i2c.writeto_mem(0x29, 0x81, b'\xF6')  # ATIME: 10cycle*2.4ms ≈ 24ms
        self._hub.i2c.writeto_mem(0x29, 0x8F, b'\x02')  # GAIN: x16
        self._hub.i2c.writeto_mem(0x29, 0x80, b'\x03')  # ENABLE: PON+AEN
        time.sleep_ms(3)

    def _read(self):
        data = self._hub.i2c.readfrom_mem(0x29, 0x94, 8)
        w = data[0] | (data[1] << 8)
        r = data[2] | (data[3] << 8)
        g = data[4] | (data[5] << 8)
        b = data[6] | (data[7] << 8)
        return w, r, g, b

    def classify(self, sample):
        # 4채널 (w,r,g,b) 제곱 유클리드 거리 — 모든 데이터를 함께 보고 최근접 기준점 선택.
        w, r, g, b = sample
        best, best_d = self.REF[0][0], None
        for name, rw, rr, rg, rb in self.REF:
            d = (w - rw) ** 2 + (r - rr) ** 2 + (g - rg) ** 2 + (b - rb) ** 2
            if best_d is None or d < best_d:
                best, best_d = name, d
        return best

    def detect(self):
        # 센서를 직접 읽어 타일색 이름을 반환. 읽기 실패(캐시가 튜플 아님)면 None.
        sample = self.get()
        if not isinstance(sample, tuple):
            return None
        return self.classify(sample)

    def is_black(self):
        # 주행 중 전용 — 구멍(검정)만 본다. 전체 기준점 중 최근접이 black이면 True.
        return self.detect() == "black"

    def detect_stop(self, targets=("red", "blue", "silver"), samples=5):
        # 정지(도착) 상태 측정 — 노이즈 제거를 위해 samples회 읽어 각각 분류 후 다수결(최빈값).
        # 분류 자체는 전체 기준점 대상(흰/검정이 자기 표를 가져가 오검출 방지)이고,
        # 최빈값이 targets(빨강/파랑/은색)에 들 때만 그 이름을, 아니면 None을 반환한다.
        counts = {}
        for _ in range(samples):
            sample = self.get()
            if isinstance(sample, tuple):
                name = self.classify(sample)
                counts[name] = counts.get(name, 0) + 1
            time.sleep_ms(10)
        if not counts:
            return None
        winner = None
        for name, c in counts.items():
            if winner is None or c > counts[winner]:
                winner = name
        return winner if winner in targets else None


# -----------------------------------------------------------------------
# IMU (BMI270 자이로) — heading 추정용 gz 적분
# 지자계(BMM150)는 자기간섭으로 미사용. 방향은 자이로 적분 + 벽정렬 재앵커링.
# -----------------------------------------------------------------------

BMI270_ADDR          = 0x69
BMI270_REG_GYR_X     = 0x12   # gx LSB(0x12)/MSB(0x13)
BMI270_REG_GYR_Z     = 0x16   # gz LSB(0x16)/MSB(0x17)
BMI270_REG_PWR_CTRL  = 0x7D
BMI270_REG_GYR_RANGE = 0x43
BMI270_REG_GYR_CONF  = 0x42
GYR_SCALE = 500.0 / 32768.0   # ±500 dps 레인지 (GYR_RANGE=0x02와 반드시 일치)

# pitch — 자이로 X축(gx) 적분으로 기울기 추적. gz→heading과 동일한 방식.
# 내리막 진입 시 gx 부호가 양수 → downhill > 0 이 되도록 PITCH_SIGN 조정(실측 후 ±1).
PITCH_SIGN = 1

# 상시 ZUPT — 정지 중 자이로 바이어스 추종 계수/판정 범위
ZUPT_ALPHA = 0.02             # 0~1, 작을수록 느리게 추종
ZUPT_STATIONARY_RANGE = 3.0   # 샘플 범위(dps)가 이보다 작을 때만 정지로 보고 보정

# BMI270 config 로드 (정상 동작에 필수)
BMI270_REG_PWR_CONF        = 0x7C
BMI270_REG_INIT_CTRL       = 0x59
BMI270_REG_INIT_ADDR_0     = 0x5B
BMI270_REG_INIT_ADDR_1     = 0x5C
BMI270_REG_INIT_DATA       = 0x5E
BMI270_REG_INTERNAL_STATUS = 0x21


class IMU:
    def __init__(self, i2c, gyro_deadzone=0.4, gyro_offset=0.0):
        self._i2c = i2c
        self._deadzone = gyro_deadzone
        self._offset = gyro_offset
        self._angle = 0.0
        self._samples = []
        self._sum = 0.0                      # _samples 러닝합 (ZUPT 평균을 sum() 없이)
        self._last_tick = time.ticks_us()    # 적분 dt 측정 (us 해상도)
        self.last_gz = 0
        self.last_gx = 0
        self._gz_buf = bytearray(2)          # update()가 재사용 — 매 틱 bytes 할당(가비지) 제거
        self._gx_buf = bytearray(2)
        self._pitch = 0.0                    # gx 적분 누적(heading과 동일 방식)
        self._gx_offset = 0.0                # gx 바이어스 (ZUPT 추종)

        self._load_config(i2c)               # config 블롭 로드 — 미로드면 자이로 무응답
        i2c.writeto_mem(BMI270_ADDR, BMI270_REG_PWR_CTRL, bytes([0x0E]))   # gyro enable
        time.sleep_ms(50)
        i2c.writeto_mem(BMI270_ADDR, BMI270_REG_GYR_RANGE, bytes([0x02]))  # ±500 dps
        time.sleep_ms(5)
        i2c.writeto_mem(BMI270_ADDR, BMI270_REG_GYR_CONF, bytes([0xAC]))   # ODR 1600Hz
        time.sleep_ms(50)

    def _load_config(self, i2c):
        """BMI270 config 파일(8KB) 로드 — Bosch BMI270-Sensor-API 초기화 시퀀스."""
        from bmi270_config import CONFIG

        i2c.writeto_mem(BMI270_ADDR, BMI270_REG_PWR_CONF, bytes([0x00]))   # adv_power_save off
        time.sleep_us(450)
        i2c.writeto_mem(BMI270_ADDR, BMI270_REG_INIT_CTRL, bytes([0x00]))  # config 로드 시작

        # config를 chunk 단위로 burst write. 각 chunk 전에 워드 주소(INIT_ADDR) 설정.
        CHUNK = 32
        for i in range(0, len(CONFIG), CHUNK):
            word = i >> 1  # 바이트 오프셋 → 워드(2바이트) 주소
            i2c.writeto_mem(BMI270_ADDR, BMI270_REG_INIT_ADDR_0, bytes([word & 0x0F]))
            i2c.writeto_mem(BMI270_ADDR, BMI270_REG_INIT_ADDR_1, bytes([(word >> 4) & 0xFF]))
            i2c.writeto_mem(BMI270_ADDR, BMI270_REG_INIT_DATA, CONFIG[i:i + CHUNK])

        i2c.writeto_mem(BMI270_ADDR, BMI270_REG_INIT_CTRL, bytes([0x01]))  # config 로드 완료
        time.sleep_ms(20)

        st = i2c.readfrom_mem(BMI270_ADDR, BMI270_REG_INTERNAL_STATUS, 1)[0]
        if (st & 0x0F) == 0x01:
            print("BMI270 config 로드 성공 (status=0x%02x)" % st)
        else:
            print("BMI270 config 로드 실패 (status=0x%02x)" % st)

    def update(self):
        # 메인 제너레이터 루프가 매 틱 호출 — 자이로 gz를 직접 읽어 적분한다.
        # (reader 콜백/백그라운드 스레드 대신 직접 접근. 단일 컨텍스트라 충돌 없음.)
        try:
            self._i2c.readfrom_mem_into(BMI270_ADDR, BMI270_REG_GYR_Z, self._gz_buf)
        except OSError:
            return
        raw = self._gz_buf
        # 매뉴얼 언팩 — 직접 바이트 결합 + 16비트 부호확장으로 가비지 없이 gz(int)를 얻는다.
        gz = raw[0] | (raw[1] << 8)
        if gz & 0x8000:
            gz -= 0x10000
        gz_raw = gz * GYR_SCALE
        self.last_gz = gz_raw
        gz = gz_raw - self._offset

        now = time.ticks_us()
        dt = time.ticks_diff(now, self._last_tick) / 1_000_000.0  # us → s
        self._last_tick = now

        s = self._samples
        if abs(gz) > self._deadzone:
            # 모션 — del s[:]로 in-place 비움(새 리스트 할당 회피).
            if s:
                del s[:]
                self._sum = 0.0
            self._angle += gz * dt
        else:
            # 정지 — in-place 갱신 + 러닝합으로 가비지 최소화.
            s.append(gz_raw)
            self._sum += gz_raw
            if len(s) > 20:
                self._sum -= s[0]
                del s[0]
            # 상시 ZUPT — 정지로 판단되고 샘플 분산이 작을 때만 자이로 바이어스를
            # 느리게 추종(적분 드리프트의 주원인=영점 바이어스 보정, 각도는 불변).
            if len(s) >= 20 and max(s) - min(s) < ZUPT_STATIONARY_RANGE:
                self._offset += (self._sum / 20 - self._offset) * ZUPT_ALPHA

        try:
            self._i2c.readfrom_mem_into(BMI270_ADDR, BMI270_REG_GYR_X, self._gx_buf)
            gx = self._gx_buf[0] | (self._gx_buf[1] << 8)
            if gx & 0x8000:
                gx -= 0x10000
            gx_raw = gx * GYR_SCALE
            self.last_gx = gx_raw
            gx_cal = gx_raw - self._gx_offset
            if abs(gx_cal) > self._deadzone:
                self._pitch += gx_cal * dt
            elif len(s) >= 20:  # gz도 정지 상태 → gx 바이어스 느리게 추종
                self._gx_offset += (gx_raw - self._gx_offset) * ZUPT_ALPHA
        except OSError:
            pass

    def pitch_deg(self):
        # 자이로 X 적분 기울기(도). gz→heading과 동일 방식. 부호는 PITCH_SIGN으로 실측 조정.
        return self._pitch * PITCH_SIGN

    def angle(self):
        return self._angle

    def set_angle(self, value):
        # 적분 각을 특정 값으로 강제 설정 — 벽정렬 등으로 실제 자세를 알 때 재앵커링용.
        self._angle = value

    def reset_angle(self):
        if self._samples:
            self._offset = self._sum / len(self._samples)
        self._angle = 0.0


# -----------------------------------------------------------------------
# Touch (FT6336) — raw 직접읽기
# -----------------------------------------------------------------------

FT6336_ADDR          = 0x38
FT6336_REG_TD_STATUS = 0x02

# CoreS3: FT6336 터치 칩의 RST 핀은 메인보드 GPIO가 아니라 AW9523 IO expander(0x58)의
# Port0 bit0 에 물려 있다. 콜드부팅(하드리셋) 시 AW9523가 전원과 함께 디폴트로 떠
# 터치 RST가 풀리지 않아 FT6336이 죽는다(=하드리셋만 터치 실패). 소프트리셋은 expander
# 출력 레지스터가 전원 유지로 보존돼 RST가 풀린 채라 정상. → 부팅마다 AW9523를 M5.begin과
# 같은 GPIO 모드/방향으로 세팅하고 P0 bit0 을 low→high 펄스로 터치 RST를 직접 풀어준다.
AW9523_ADDR = 0x58


def reset_cores3_touch(i2c):
    # AW9523 경유 FT6336 하드웨어 리셋 펄스 (CoreS3 전용, raw I2C — M5 라이브러리 미사용).
    # 레지스터/값은 M5GFX CoreS3 보드 init과 동일하게 맞춘다.
    try:
        i2c.writeto_mem(AW9523_ADDR, 0x11, b'\x10')  # GCR: P0 push-pull
        i2c.writeto_mem(AW9523_ADDR, 0x12, b'\xff')  # P0 = GPIO 모드 (LED 모드 해제)
        i2c.writeto_mem(AW9523_ADDR, 0x13, b'\xff')  # P1 = GPIO 모드
        i2c.writeto_mem(AW9523_ADDR, 0x04, b'\x18')  # P0 방향: bit3,4 입력, 나머지 출력
        # 터치 RST 펄스: P0 출력에서 bit0 만 토글(나머지 0b110은 M5GFX 디폴트값 유지).
        i2c.writeto_mem(AW9523_ADDR, 0x02, b'\x06')  # bit0=0 → 터치 RST assert
        time.sleep_ms(10)
        i2c.writeto_mem(AW9523_ADDR, 0x02, b'\x07')  # bit0=1 → 터치 RST 해제
        time.sleep_ms(300)                           # FT6336 부팅 대기
    except OSError:
        pass


class Touch:
    def __init__(self, i2c, debounce=4):
        self._i2c = i2c
        self._buf = bytearray(1)   # is_touching()이 재사용 — 매 호출 bytes 할당 제거
        self._debounce = debounce  # 연속 N회 일치해야 상태 전환 (EMI 단발 스파이크 제거)
        self._count = 0            # 연속 raw-touch 카운트(히스테리시스)
        self._state = False        # 디바운스된 안정 상태
        # 콜드부팅 시 죽어 있는 FT6336을 AW9523 경유로 먼저 하드웨어 리셋해 깨운다.
        reset_cores3_touch(self._i2c)
        # FT6336 G_MODE(0xA4)=0x00 → 폴링 모드(인터럽트 비활성). 콜드부팅 시
        # 인터럽트/트리거 모드로 떠 TD_STATUS가 안 갱신되는 걸 막고 연속 리포트로 둔다.
        try:
            self._i2c.writeto_mem(FT6336_ADDR, 0xA4, b'\x00')
        except OSError:
            pass

    def _raw(self):
        # FT6336 TD_STATUS 하위 4비트 = 현재 터치점 개수(0~2). EMI로 상위비트가
        # 튀거나 개수가 3+로 깨진 read는 garbage로 보고 무시한다.
        self._buf = self._i2c.readfrom_mem(FT6336_ADDR, FT6336_REG_TD_STATUS, 1)
        return 1 <= (self._buf[0] & 0x0F) <= 2

    def is_touching(self):
        # 히스테리시스 디바운스 — raw 터치가 연속 debounce회 잡혀야 True로,
        # 연속 debounce회 풀려야 False로 전환. 근처 전선 EMI로 TD_STATUS가
        # 단발 또는 T/F/T/F로 튀는 가짜 터치는 카운터가 임계에 못 가 걸러진다.
        if self._raw():
            if self._count < self._debounce:
                self._count += 1
        elif self._count > 0:
            self._count -= 1
        if self._count >= self._debounce:
            self._state = True
        elif self._count == 0:
            self._state = False
        return self._state
