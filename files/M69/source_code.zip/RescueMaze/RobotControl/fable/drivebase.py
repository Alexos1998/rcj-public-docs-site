"""
BASEX 모터 컨트롤러(I2C 0x22) DriveBase — 구 basex.py 정리본 (로직 동일).

- 모터 속도/엔코더/서보를 I2C 레지스터 직접 쓰기로 제어한다.
- 모든 호출은 메인 제너레이터 루프 단일 컨텍스트에서만 일어난다(스레드/락 없음).
- brake()=set_motor_speed(0): 속도모드 폐루프가 0을 유지하므로 서보처럼 그 자리에
  버틴다(코스트 아님).
"""

import ustruct as struct
import math
import time

BASEX_ADDR = 0x22

# 서보 제어 레지스터
SERVO1_ANGLE_ADDR = 0x00  # 0~180
SERVO2_ANGLE_ADDR = 0x01  # 0~180
SERVO1_PULSE_ADDR = 0x10  # (uint16_t) 500~2500
SERVO2_PULSE_ADDR = 0x12  # (uint16_t) 500~2500


class DriveBase:
    def __init__(self, i2c, right_motors, left_motors,
                 wheel_diameter, axle_track, gear=None, left_counter=False, right_counter=False,
                 max_speed=600, motor_max=128):
        self._i2c = i2c
        self.wheel_diameter = wheel_diameter
        self.axle_track = axle_track
        self.circum = math.pi * self.wheel_diameter

        self.l_counter = -1 if left_counter else 1
        self.r_counter = -1 if right_counter else 1

        gear = gear if gear else []
        self.ratio = gear[-1] / gear[0] if gear else 1
        self.counts_per_mm = 360 / self.circum * self.ratio
        self._deg_to_mm = self.circum / 360 / self.ratio
        self._half_track = self.axle_track / 2

        self.left_ports = left_motors
        self.right_ports = right_motors
        self.all_ports = self.left_ports + self.right_ports

        self.current_encoder = [0, 0, 0, 0]
        self.speed_scale = motor_max / max_speed
        self._speed_regs = [0x5C + m * 0x10 for m in range(4)]
        self._speed_buf = bytearray(1)
        self._enc_buf = bytearray(4)   # 엔코더 직접읽기 버퍼 재사용

        # 모터 컨트롤러(BASEX) 직접 초기화
        for p in self.all_ports:
            n = 0x50 + (p - 1) * 0x10
            i2c.writeto_mem(BASEX_ADDR, n, b'\x01')
            time.sleep_us(100)
        for p in self.all_ports:
            n = 0x50 + (p - 1) * 0x10
            # 위치 PID — EV3 Medium(position_pid_k={p:160000,i:0,d:0}) 성격: 순수 P.
            # EV3 원값은 고정소수점이라 1바이트 레지스터에 못 옮긴다 → P 크기는 컨트롤러
            # 동작 영역에 맞추되 Medium이 Large(80000)의 2배인 점을 반영해 12→24로 올린다.
            i2c.writeto_mem(BASEX_ADDR, n + 0x01, bytes([24]))
            time.sleep_us(100)
            i2c.writeto_mem(BASEX_ADDR, n + 0x02, bytes([0]))
            time.sleep_us(100)
            i2c.writeto_mem(BASEX_ADDR, n + 0x03, bytes([0]))
            time.sleep_us(100)
        for p in self.all_ports:
            n = 0x50 + (p - 1) * 0x10
            i2c.writeto_mem(BASEX_ADDR, n, b'\x02')
            time.sleep_us(100)
        for p in self.all_ports:
            n = 0x50 + (p - 1) * 0x10
            # 속도 PID — EV3 Medium(speed_pid_k={p:1000,i:60,d:0}, 전 모터 공통) 성격:
            # P 위주 + I≈P의 6%, D=0. P 크기는 컨트롤러 스케일이 달라 기존 22 유지,
            # I=round(22*60/1000)=1, D=0.
            i2c.writeto_mem(BASEX_ADDR, n + 0x09, bytes([22]))
            time.sleep_us(100)
            i2c.writeto_mem(BASEX_ADDR, n + 0x0A, bytes([1]))
            time.sleep_us(100)
            i2c.writeto_mem(BASEX_ADDR, n + 0x0B, bytes([0]))
            time.sleep_us(100)

        # 시작 기준 엔코더를 직접 읽어 ref 설정.
        self.update_encoders()
        self.left_ref = self.current_encoder[self.left_ports[0] - 1]
        self.right_ref = self.current_encoder[self.right_ports[0] - 1]

    def _read_encoder(self, motor):
        n = 0x30 + (motor - 1) * 0x04
        self._i2c.readfrom_mem_into(BASEX_ADDR, n, self._enc_buf)
        return struct.unpack('>i', self._enc_buf)[0]

    def update_encoders(self):
        # distance()/odo_yaw가 쓰는 좌·우 기준 모터 엔코더만 직접 읽어 갱신한다.
        # 메인 제너레이터 루프 단일 컨텍스트라 충돌 없음. 노이즈성 실패는 직전 값 유지.
        enc = self.current_encoder[:]
        for motor in (self.left_ports[0], self.right_ports[0]):
            try:
                enc[motor - 1] = self._read_encoder(motor)
            except OSError:
                pass
        self.current_encoder = enc

    def _clamp(self, value, min_val=-128, max_val=127):
        return max(min_val, min(max_val, value))

    def write(self, reg, data):
        self._i2c.writeto_mem(BASEX_ADDR, reg, data)

    def set_mode(self, motor, value):
        n = 0x50 + (motor - 1) * 0x10
        self._i2c.writeto_mem(BASEX_ADDR, n, value)

    def set_motor_pwm(self, motor, value):
        n = 0x20 + (motor - 1) * 0x01
        try:
            self._i2c.writeto_mem(BASEX_ADDR, n, struct.pack('b', self._clamp(int(value))))
        except OSError:
            pass   # 종료/노이즈 시 모터쓰기 실패가 예외로 전파되지 않게 (close 경로 보호)

    def set_position_pid(self, motor, p, i, d):
        n = 0x50 + (motor - 1) * 0x10
        self._i2c.writeto_mem(BASEX_ADDR, n + 0x01, bytes([int(p)]))
        self._i2c.writeto_mem(BASEX_ADDR, n + 0x02, bytes([int(i)]))
        self._i2c.writeto_mem(BASEX_ADDR, n + 0x03, bytes([int(d)]))

    def set_position_point(self, motor, target):
        n = 0x50 + (motor - 1) * 0x10
        self._i2c.writeto_mem(BASEX_ADDR, n + 0x04, struct.pack('<i', int(target)))

    def set_position_max_speed(self, motor, speed):
        n = 0x50 + (motor - 1) * 0x10
        self._i2c.writeto_mem(BASEX_ADDR, n + 0x08, bytes([self._clamp(abs(int(speed)), 0, 127)]))

    def set_motor_pid(self, motor, p, i, d):
        n = 0x50 + (motor - 1) * 0x10
        self._i2c.writeto_mem(BASEX_ADDR, n + 0x09, bytes([int(p)]))
        self._i2c.writeto_mem(BASEX_ADDR, n + 0x0A, bytes([int(i)]))
        self._i2c.writeto_mem(BASEX_ADDR, n + 0x0B, bytes([int(d)]))

    def set_motor_speed(self, motor, value):
        # 즉시 쓰기 — 미러/플러시 없이 호출 즉시 모터 속도 레지스터에 반영.
        idx = motor - 1
        self._speed_buf[0] = self._clamp(int(value)) & 0xFF
        try:
            self._i2c.writeto_mem(BASEX_ADDR, self._speed_regs[idx], self._speed_buf)
        except OSError:
            pass

    def set_servo_angle(self, servo, angle):
        addr = SERVO1_ANGLE_ADDR if servo == 1 else SERVO2_ANGLE_ADDR
        self._i2c.writeto_mem(BASEX_ADDR, addr, bytes([self._clamp(int(angle), 0, 180)]))

    def set_servo_pulse(self, servo, pulse):
        addr = SERVO1_PULSE_ADDR if servo == 1 else SERVO2_PULSE_ADDR
        self._i2c.writeto_mem(BASEX_ADDR, addr, struct.pack('<H', self._clamp(int(pulse), 500, 2500)))

    def distance(self):
        self.update_encoders()   # 호출 즉시 엔코더 직접 읽기 — 항상 최신값
        l_deg = self.current_encoder[self.left_ports[0] - 1] - self.left_ref
        r_deg = self.current_encoder[self.right_ports[0] - 1] - self.right_ref
        return (l_deg * self.l_counter + r_deg * self.r_counter) * self._deg_to_mm / 2

    def reset(self):
        self.update_encoders()   # ref도 최신 엔코더 기준으로
        self.left_ref = self.current_encoder[self.left_ports[0] - 1]
        self.right_ref = self.current_encoder[self.right_ports[0] - 1]

    def drive_init(self):
        for p in self.all_ports:
            self.set_mode(p, b'\x02')
        time.sleep_ms(20)

    def drive(self, speed, steering):
        scaled_speed = speed * self.speed_scale
        turn_rate_rad = math.radians(steering)
        v_l = scaled_speed - turn_rate_rad * self._half_track
        v_r = scaled_speed + turn_rate_rad * self._half_track

        for p in self.left_ports:
            self.set_motor_speed(p, int(v_l * self.l_counter))
        for p in self.right_ports:
            self.set_motor_speed(p, int(v_r * self.r_counter))

        return v_l, v_r

    def _odo_yaw(self):
        # 좌우 바퀴 주행차로 추정한 헤딩 변화(deg). reset() 기준이라 직진 중엔 0이어야 정상.
        # 양수 = CCW(좌)로 틀어짐. 자이로 없이 엔코더만으로 직진 보정에 사용.
        l = (self.current_encoder[self.left_ports[0] - 1] - self.left_ref) * self.l_counter
        r = (self.current_encoder[self.right_ports[0] - 1] - self.right_ref) * self.r_counter
        return (r - l) * self._deg_to_mm / self.axle_track * 57.29577951308232

    def straight(self, speed, mm, kp=2.0):
        # 엔코더 오도메트리만으로 mm만큼 직진하는 협력 제너레이터.
        # IMU 없이 좌우 주행차(_odo_yaw)를 0으로 맞춰 직진성을 유지한다.
        # 호출부: yield from robot.straight(speed, mm)
        target = abs(mm)
        actual_speed = -speed if mm < 0 else speed

        self.reset()
        while True:
            dist = abs(self.distance())   # distance()가 내부에서 엔코더 직접 갱신
            if dist >= target:
                break
            # odo_yaw>0(좌로 드리프트)면 우로 보정 → 조향 부호 반대로.
            self.drive(actual_speed, -kp * self._odo_yaw())
            yield

        self.brake()
        self.reset()

    def stop(self, lock=True):
        for p in self.all_ports:
            self.set_motor_speed(p, 0)
            if not lock:
                self.set_motor_pwm(p, 0)

    def brake(self):
        self.stop()

    def close(self):
        self.stop(False)
