"""
제너레이터 협력 스케줄러 (asyncio 대체).

제약: ① 두 스레드가 I2C → 259  ② async 함수 안에서 I2C → 에러  ③ 락은 핫루프에 느림.
→ 스레드/asyncio를 모두 없애고 순수 제너레이터(yield) 협력 멀티태스킹으로 돌린다.
  모든 I2C는 이 단일 루프 컨텍스트에서 각 호출이 직접(machine.I2C로) 수행 — 동시
  접근이 구조적으로 불가능. uasyncio의 숨은 타이머/스케줄러 훅도 없어 통제가 명확하다.

변환 규칙: async def→def, await asyncio.sleep_ms(n)→yield from gsleep(n),
  await f()→yield from f().

grun/grace 의 tick 인자에는 매 틱 반드시 돌아야 하는 콜백(자이로 적분 펌프
imu.update 등)을 넘긴다 — 연속 샘플링이 필요한 유일한 항목이라 스케줄러가 대신 돈다.
"""

import time


def gsleep(ms):
    # ms가 0 이하이면 대기 시간 없이 단 한 번만 다른 제너레이터에게 순서를 양보한다.
    if ms <= 0:
        yield
        return

    end = time.ticks_add(time.ticks_ms(), ms)
    while time.ticks_diff(end, time.ticks_ms()) > 0:
        yield


def grun(gen, tick=None):
    # 제너레이터 하나를 끝까지 구동한다 (최상위 엔트리용).
    # 매 틱 tick()(보통 imu.update)으로 자이로 적분을 직접 갱신한다.
    # 모터/엔코더/터치/ToF는 각 호출 지점이 그때그때 직접 I2C에 접근한다.
    while True:
        if tick:
            tick()
        try:
            next(gen)
        except StopIteration:
            break


def grace(*gens, tick=None):
    # 여러 제너레이터를 라운드로빈으로 돌리다 하나라도 끝나면 그 인덱스를 반환하고
    # 나머지는 close()로 중단한다. asyncio.create_task + done 폴링을 대체.
    # 여기서도 매 틱 tick()으로 자이로 적분을 펌프한다(메인 루프 단일 컨텍스트).
    gens = list(gens)
    while True:
        if tick:
            tick()
        for i, g in enumerate(gens):
            try:
                next(g)
            except StopIteration:
                for j, other in enumerate(gens):
                    if j != i:
                        other.close()
                return i
