"""
//TODO 턴 뒤 뒤에 벽이 있으면 벽정렬
"""


import time
import uasyncio as asyncio
from machine import I2C, Pin

import M5
M5.begin()  # I2C 초기화 전에 가장 먼저 실행
from basex import DriveBase
from devices import I2CBus, IMU, Touch
from astar.grid import *
from astar.Astar import get_directions
from astar.visualize import create_grid
from logger import log_error, init_logging
from utils import *
init_logging()


# -----------------------------------------------------------------------
# 하드웨어 초기화
# -----------------------------------------------------------------------

# I2CBus: 백그라운드 스레드에서 I2C 읽기/쓰기를 처리한다.
# IMU, DriveBase, Touch 가 모두 이 버스를 공유한다.
bus  = I2CBus(0, scl=Pin(11), sda=Pin(12), freq=1000000)
_i2c = bus._i2c

imu   = IMU(bus, gyro_deadzone=0.7)        # 자이로 데드존 1도: 미세 노이즈 무시
touch = Touch(bus)                        # 터치 패널 (FT6336)
robot = DriveBase(
    bus,
    right_motors=[2, 3], left_motors=[1, 4],
    wheel_diameter=62.4,   # 바퀴 직경 (mm)
    axle_track=112,        # 좌우 바퀴 간격 (mm)
    right_counter=True,    # 우측 모터 엔코더 방향 반전
    gear=[12, 28]          # 기어비: 구동 12T → 피동 28T
)

# bus.start()는 비동기 루프 진입 직전(main())에서 호출한다.

# -----------------------------------------------------------------------
# 미로 맵 (dg)
# -----------------------------------------------------------------------
#
# 각 셀은 4비트 정수로 벽 유무를 표현한다.
# azimuthList 인덱스와 1:1 대응:
#
#   bit0 = N(북)  bit1 = S(남)  bit2 = W(서)  bit3 = E(동)
#   1 = 벽 있음 / 0 = 통로
#
#   예) 13 = 0b1101 → N벽, S통로, W벽, E벽 → 남쪽만 통로
#
#   시각적 레이아웃:
#             ___             ___
#   0=     1=     2=     3=
#                     ___     ___
#             ___             ___
#   4= |   5= |   6= |   7= |
#      |      |      |___   |___
#             ___             ___
#   8=    |9=    |10=   |11=   |
#          |      |   ___|   ___|
#             ___             ___
#  12=|  |13=|  |14=|  |15=|  |
#     |  |   |  |   |__|   |__|

dg = [
    [13,  5,  1, 11],
    [12, 12, 14, 13],
    [ 4,  2,  1,  8],
    [14, 13, 12, 14],
    [ 5,  2, 10, 13],
    [ 6,  1,  1, 10],
    [13, 14, 12, 13],
    [ 6,  3,  2, 10]
]

# -----------------------------------------------------------------------
# 상수 / 타입 정의
# -----------------------------------------------------------------------

# 셀의 4방향 통행 가능 여부를 담는 네임드튜플
azimuth = namedtuple('azimuth', ['n', 's', 'w', 'e'])

# 정수 인덱스(0~15) → azimuth 변환 테이블.
# heading별 추가 배열 없이 이 하나의 테이블만 사용하고,
# heading 보정은 get_open_side 에서 직접 계산한다.
azimuthList = [
    azimuth(1,1,1,1), azimuth(0,1,1,1), azimuth(1,0,1,1), azimuth(0,0,1,1),
    azimuth(1,1,0,1), azimuth(0,1,0,1), azimuth(1,0,0,1), azimuth(0,0,0,1),
    azimuth(1,1,1,0), azimuth(0,1,1,0), azimuth(1,0,1,0), azimuth(0,0,1,0),
    azimuth(1,1,0,0), azimuth(0,1,0,0), azimuth(1,0,0,0), azimuth(0,0,0,0),
]

_DIRS = [direction(0,-1), direction(1,0), direction(0,1), direction(-1,0)]  # N E S W

def look_dir(h, d):
    # 현재 heading h 에서 방향벡터 d 를 향하기 위해 회전해야 할 각도
    return [0, -90, 180, 90][(_DIRS.index(d) - h) % 4]

def next_dir(h, i):
    # h=현재heading, i: 0=좌 1=전 2=우
    return _DIRS[(h + i - 1) % 4]

# -----------------------------------------------------------------------
# 전역 상태
# -----------------------------------------------------------------------

lastYaw     = 0   # 직진 PID 이전 프레임 편차 (미분항 계산용)
lastTurnYaw = 0   # 회전 PID 이전 프레임 편차
gyroAngle   = 0   # 누적 목표 각도 (회전할 때마다 갱신)
heading     = 0   # 로봇의 논리적 진행 방향 (0=N 1=E 2=S 3=W)

# 전후면 반전 플래그.
# True 이면 후면이 진행 방향 — 실제 180도 회전 대신 모터 방향만 반전한다.
is_reversed = True

pos      = [0, 0]   # 현재 그리드 좌표 (절대)
startPos = [0, 0]   # 시작 셀의 그리드 좌표 (그리드 확장 시 함께 갱신)

# dg 배열에서의 현재 셀 좌표 — dg[cur_dg[1]][cur_dg[0]] 로 접근
cur_dg   = [0, 0]
dg_start = [0, 7]   # 미로에서의 물리적 시작 위치 (dg 배열 좌표)

openList   = []                    # 아직 방문하지 않은 이웃 방향 스택
closedList = [direction(0, 0)]     # 이미 방문한 셀 좌표 목록

# 프로그램 재시작 시 이전 상태를 복원하기 위한 체크포인트
checkpoint = {
    "grid": None,       # 탐색 그리드
    "node": None,       # 마지막 노드
    "dir": None,        # 다음 이동 방향
    "openList": None,
    "closedList": None,
    "startPos": None,
    "gyroAngle": None,
    "heading": None,
    "cur_dg": None,
}

# -----------------------------------------------------------------------
# PID 제어
# -----------------------------------------------------------------------

# A: 오도메트리 직진 보정 가중치 (deg당 조향량). 0이면 비활성. 실측 튜닝 필요.
ODO_STRAIGHT_GAIN = 2.0

def odo_yaw():
    # 좌우 바퀴 주행차로 추정한 헤딩 변화(deg). 자이로와 독립 → 자기간섭/적분 드리프트 면역.
    # robot.reset()(=drive 시작) 기준이라 직진 중엔 0이어야 정상. 양수=CCW(좌)로 틀어짐.
    l = (robot.current_encoder[robot.left_ports[0] - 1] - robot.left_ref) * robot.l_counter
    r = (robot.current_encoder[robot.right_ports[0] - 1] - robot.right_ref) * robot.r_counter
    return (r - l) * robot._deg_to_mm / robot.axle_track * 57.29577951308232


def pid_control(speed, gain, kp, kd):
    global lastYaw
    yaw = -(imu.angle() - gyroAngle)
    diff = yaw - lastYaw
    lastYaw = yaw
    # A: 자이로 PID + 오도메트리 직진 보정(독립 신호). odo_yaw>0(좌로 드리프트)면 우로 보정.
    robot.drive(speed, (kp * yaw + kd * diff) * gain - ODO_STRAIGHT_GAIN * odo_yaw())


def pid_turn_control(dest, gain, kp, kd):
    global lastTurnYaw
    yaw  = dest - (imu.angle() - gyroAngle)
    diff = yaw - lastTurnYaw
    lastTurnYaw = yaw
    robot.drive(0, (kp * yaw + kd * diff) * gain)


async def reset_turn():
    start = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), start) < 5000:
        if abs(imu.angle() - gyroAngle) < 0.1:
            break
        pid_turn_control(gyroAngle, 0.26, 17.2, 4)
        await asyncio.sleep_ms(0)
    robot.brake()


async def turn(dest, duration=2000):
    global heading, lastYaw, gyroAngle, is_reversed

    if dest == 0:
        return

    if abs(dest) == 180:
        is_reversed = not is_reversed
        heading = (heading + 2) % 4
        return

    robot.brake()
    i = 0
    start = time.ticks_ms()

    while time.ticks_diff(time.ticks_ms(), start) < duration:
        remaining = dest - (imu.angle() - gyroAngle)
        ratio = min(1.0, abs(remaining) / abs(dest))
        pid_turn_control(dest, 0.15 + 0.30 * ratio ** 2, 17.2, 10)
        if abs(remaining) < 0.5 and i == 0:
            start = time.ticks_ms()
            i = 1
        await asyncio.sleep_ms(0)

    gyroAngle += dest
    lastYaw = 0
    robot.brake()
    print("turn finished")
    robot.brake()
    # await wait(100)
    # robot.stop(False)
    # await wait(100)
    # await imu.calibrate_with_mag()
    # await wait(100)

    heading = (heading + (-1 if dest == 90 else 1)) % 4

# -----------------------------------------------------------------------
# dg 벽 감지
# -----------------------------------------------------------------------

def _dg_az(gx, gy):
    # 시각적 레이아웃 기준: bit0=N벽, bit1=S벽, bit2=W벽, bit3=E벽 (1=벽 있음)
    v = dg[gy][gx]
    return azimuth(1-(v&1), 1-((v>>1)&1), 1-((v>>2)&1), 1-((v>>3)&1))


def has_front_wall(gx, gy):
    if gy < 0 or gy >= len(dg) or gx < 0 or gx >= len(dg[0]):
        return True
    az = _dg_az(gx, gy)
    walls_fwd = (az.n, az.e, az.s, az.w)
    walls_rev = (az.s, az.w, az.n, az.e)
    return (walls_rev if is_reversed else walls_fwd)[heading] == 0

# -----------------------------------------------------------------------
# 주행
# -----------------------------------------------------------------------

async def drive(speed, destMM):
    i = 0
    lastError = imu.angle()
    actual_speed = -speed if is_reversed else speed

    robot.reset()

    while True:
        dist = abs(robot.distance())
        if dist > destMM:
            break
        ratio = dist / destMM
        pid_control(actual_speed * (1 - ratio * 0.5), 6, 1.8, 3.6)

        angle = imu.angle()
        diff = angle - lastError
        lastError = angle
        if abs(diff) * 5 > 6 and not i:
            destMM += 10
            i = 1

        await asyncio.sleep_ms(0)

    robot.brake()
    robot.reset()
    print("drive finished")

# -----------------------------------------------------------------------
# 그리드 계산
# -----------------------------------------------------------------------

def get_open_side(gx, gy):
    # cur_dg 전역으로 dg 배열의 현재 셀 조회
    dg_x, dg_y = cur_dg[0], cur_dg[1]
    if dg_y < 0 or dg_y >= len(dg) or dg_x < 0 or dg_x >= len(dg[0]):
        az = azimuth(0, 0, 0, 0)
    else:
        az = _dg_az(dg_x, dg_y)
    raw = [
        (az.w, az.n, az.e),
        (az.n, az.e, az.s),
        (az.e, az.s, az.w),
        (az.s, az.w, az.n),
    ][heading]
    sides = list(raw)

    for i in range(3):
        nb = direction(gx + next_dir(heading, i).x, gy + next_dir(heading, i).y)
        if nb in closedList:
            sides[i] = 0
        elif sides[i] and next_dir(heading, i) in openList:
            openList.remove(next_dir(heading, i))

    return sides


def sides_to_wall(sides, isFirst=False):
    # isFirst=True: 시작 셀은 후면이 항상 벽(막힌 면에 붙여 출발)
    backward = 0 if isFirst else 1
    n = s = w = e = 0
    if   heading == 0: n, s, w, e = sides[1], backward, sides[0], sides[2]
    elif heading == 1: n, s, w, e = sides[0], sides[2], backward, sides[1]
    elif heading == 2: n, s, w, e = backward, sides[1], sides[2], sides[0]
    elif heading == 3: n, s, w, e = sides[2], sides[0], sides[1], backward
    # 시각적 레이아웃: bit0=N벽, bit1=S벽, bit2=W벽, bit3=E벽 (1=벽 있음, 0=통로)
    return (1-n) | ((1-s) << 1) | ((1-w) << 2) | ((1-e) << 3)


def check_open_dir(gx, gy, isFirst=False):
    sides = get_open_side(gx, gy)
    return sides, sides_to_wall(sides, isFirst)


def _expand_grid(grid, _node, dir):
    dx = dy = tx = ty = gx = gy = 0
    old_h, old_w = len(grid), len(grid[0])
    if dir.x != 0:
        tx = -dir.x
        if not (0 <= _node.x + dir.x < old_w):
            gx = 1
            if dir.x < 0: dx = 1
    if dir.y != 0:
        ty = -dir.y
        if not (0 <= _node.y + dir.y < old_h):
            gy = 1
            if dir.y < 0: dy = 1
    return dx, dy, tx, ty, gx, gy


def _build_grid(grid, dx, dy, gx, gy):
    tGrid = [[NNode() for _ in range(len(grid[0]) + gx)]
             for _ in range(len(grid) + gy)]
    for y in range(len(grid)):
        for x in range(len(grid[0])):
            n = grid[y][x]
            n.set_xy(n.x + dx, n.y + dy)
            tGrid[y + dy][x + dx] = n
    return tGrid


def modify_grid(_node, dir, grid):
    global openList, closedList

    dx, dy, tx, ty, gx, gy = _expand_grid(grid, _node, dir)

    openList   = [direction(e[0] + tx, e[1] + ty) for e in openList]
    closedList = [direction(e[0] + dx, e[1] + dy) for e in closedList]

    nx, ny = _node.x + dir.x + dx, _node.y + dir.y + dy
    sides, _wall = check_open_dir(nx, ny)

    _node = Node(nx, ny, _wall, None)
    tGrid = _build_grid(grid, dx, dy, gx, gy)
    tGrid[_node.y][_node.x] = _node

    for i, cond in enumerate(sides):
        if cond:
            openList.append(next_dir(heading, i))
    closedList.append(direction(_node.x, _node.y))

    return _node, tGrid, dx, dy


async def follow_next_dir(_dir, _node, _grid):
    isGriding = True
    _node = _node.copy()
    try:
        _grid[_node.pos(_dir)[1]][_node.pos(_dir)[0]]
    except Exception:
        isGriding = False

    dirs = get_directions(_grid, dir_to_pos(_node.pos()), dir_to_pos(_node.pos(_dir)), isGriding)
    await asyncio.sleep_ms(200)

    for __dir in dirs:
        if __dir in (direction(0,2), direction(0,-2), direction(2,0), direction(-2,0)):
            half = direction(__dir.x // 2, __dir.y // 2)
            _node.add_xy(half.x, half.y)
            _dir = add_dir(_dir, -half.x, -half.y)
            openList[:] = [add_dir(e, -half.x, -half.y) for e in openList]
            create_grid(grid_to_int(_grid), direction(_node.x, _node.y), heading)
            continue

        await turn(look_dir(heading, __dir))
        await asyncio.sleep_ms(200)
        cur_dg[0] += __dir.x  # drive() 호출 전 dg 좌표 갱신
        cur_dg[1] += __dir.y
        await drive(300, 230)
        await asyncio.sleep_ms(200)

        _node.add_xy(__dir.x, __dir.y)
        _dir = add_dir(_dir, -__dir.x, -__dir.y)
        openList[:] = [add_dir(e, -__dir.x, -__dir.y) for e in openList]
        create_grid(grid_to_int(_grid), direction(_node.x, _node.y), heading)

    return _dir, _node


def grid_to_int(grid):
    return [[n.wall for n in row] for row in grid]


def dir_to_pos(d):
    return [d.x, d.y]


def add_dir(d, x, y):
    return direction(d.x + x, d.y + y)

# -----------------------------------------------------------------------
# 메인 탐색 루프
# -----------------------------------------------------------------------

async def start_program():
    global pos, startPos, checkpoint, openList, closedList, heading, gyroAngle, cur_dg

    if checkpoint["grid"] is None:
        pos = startPos = [0, 0]
        cur_dg = list(dg_start)
        openList, closedList = [], [direction(0, 0)]
        heading = gyroAngle = 0
        await reset_turn()

        sides, wall = check_open_dir(0, 0, True)
        openList = [next_dir(heading, i) for i, ok in enumerate(sides) if ok]

        node = Node(0, 0, wall, None)
        grid = [[node]]
        dir  = openList.pop()
        create_grid(grid_to_int(grid), direction(node.x, node.y), heading)
    else:
        node       = checkpoint["node"]
        dir        = checkpoint["dir"]
        grid       = checkpoint["grid"]
        openList   = checkpoint["openList"]
        closedList = checkpoint["closedList"]
        startPos   = checkpoint["startPos"]
        gyroAngle  = checkpoint["gyroAngle"]
        heading    = checkpoint["heading"]
        cur_dg     = checkpoint["cur_dg"]
        await reset_turn()

    while True:
        checkpoint["grid"]      = grid
        checkpoint["node"]      = node
        checkpoint["dir"]       = dir
        checkpoint["openList"]  = list(openList)
        checkpoint["closedList"]= list(closedList)
        checkpoint["startPos"]  = list(startPos)
        checkpoint["gyroAngle"] = gyroAngle
        checkpoint["heading"]   = heading
        checkpoint["cur_dg"]    = list(cur_dg)

        if dir not in (direction(0,-1), direction(0,1), direction(-1,0), direction(1,0)):
            dir, node = await follow_next_dir(dir, node, grid)
        elif node.wall in (7, 11, 13, 14):
            one_exit = {7: direction(1,0), 11: direction(-1,0),
                        13: direction(0,1), 14: direction(0,-1)}[node.wall]
            if dir != one_exit:
                dir, node = await follow_next_dir(dir, node, grid)

        await turn(look_dir(heading, dir))

        cur_dg[0] += dir.x  # drive() 호출 전 목적 셀로 dg 좌표 갱신
        cur_dg[1] += dir.y
        await drive(300, 320)

        node, grid, dx, dy = modify_grid(node, dir, grid)
        pos = node.pos()
        startPos[0] += dx
        startPos[1] += dy

        create_grid(grid_to_int(grid), direction(node.x, node.y), heading)

        if not openList:
            break

        dir = openList.pop()
        await asyncio.sleep_ms(0)

    print("탐색 완료")
    await follow_next_dir(
        direction(startPos[0] - node.x, startPos[1] - node.y), node, grid
    )


# -----------------------------------------------------------------------
# 엔트리포인트
# -----------------------------------------------------------------------

_touch_result = None

async def _wait_touch():
    global _touch_result
    _touch_result = await touch.wait_for_touch(hold_threshold=2000, detect_hold=True)


async def main():
    try:
        # I2C 장치 응답 확인 — 0x22=BASEX, 0x38=FT6336, 0x69=BMI270
        await wait(1000)
        try:
            bus._i2c.writeto_mem(0x69, 0x12, bytes([0x0E]))
        except Exception as e:
            bus.init()
        devs = _i2c.scan()
        print("I2C scan:", [hex(d) for d in devs])
        for addr, name in [(0x22, "BASEX"), (0x38, "FT6336"), (0x69, "BMI270")]:
            if addr not in devs:
                bus._i2c = I2C(0, scl=Pin(11), sda=Pin(12), freq=1000000)
                devs = _i2c.scan()
                print("I2C scan:", [hex(d) for d in devs])
                for addr, name in [(0x22, "BASEX"), (0x38, "FT6336"), (0x69, "BMI270")]:
                    print(f"  {name}(0x{addr:02x}): {'OK' if addr in devs else 'NOT FOUND'}")
                break
            print(f"  {name}(0x{addr:02x}): {'OK' if addr in devs else 'NOT FOUND'}")

        bus.start()
        print("bus started")

        imu.reset_angle()
        await imu.calibrate_with_mag()  # 시작 방향을 지자계 오프셋으로 저장 (_mag_initial)

        # 첫 터치로 탐색 시작
        await touch.wait_for_touch(detect_hold=False)

        while True:
            done       = asyncio.create_task(start_program())
            touch_task = asyncio.create_task(_wait_touch())

            while not done.done() and not touch_task.done():
                await asyncio.sleep_ms(10)

            if done.done():
                # 탐색 정상 완료
                touch_task.cancel()
                break

            # 터치로 중단 — 결과에 따라 재시작 방식 결정
            done.cancel()
            await asyncio.sleep_ms(0)
            result = _touch_result

            if result == 2:  # 길게 누름: 저장 데이터 초기화 후 재시작
                checkpoint["grid"] = None
            # 짧게 누름(1): 체크포인트부터 재시작 — 루프 계속

    except Exception as e:
        log_error(e, "fixed_main")
        print("오류:", e)
    finally:
        robot.close()
        bus.close()  # 예외 발생 시에도 버스 스레드 안전 종료

try:
    asyncio.run(main())
except:
    robot.close()
    bus.close()