"""
fixed_main.py 의 미로 탐색 로직을 일반 파이썬에서 검증하는 테스트 파일.
하드웨어(IMU, DriveBase, Touch, I2CBus)는 모두 모의 객체로 대체한다.
turn() / drive() 는 모터를 작동시키지 않고 상태 갱신만 수행한다.
"""

import sys
import os
# 프로젝트 루트를 path에 추가 (astar/ 임포트용)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# utils.py 가 MicroPython 전용이므로 Color 만 제공하는 모의 모듈을 주입
import types as _types
_utils_mock = _types.ModuleType('utils')
class _Color:
    RED = "RED"; BLUE = "BLUE"; GREEN = "GREEN"
    SILVER = "SILVER"; BLACK = "BLACK"; CYAN = "CYAN"
_utils_mock.Color = _Color
sys.modules.setdefault('utils', _utils_mock)

import asyncio
from collections import namedtuple
from astar.grid import *
from astar.Astar import get_directions
from astar.visualize import create_grid


# -----------------------------------------------------------------------
# 하드웨어 모의 객체
# -----------------------------------------------------------------------

class MockIMU:
    def angle(self): return 0.0
    def reset_angle(self): pass

class MockRobot:
    def distance(self): return 0.0
    def reset(self): pass
    def brake(self): pass
    def drive(self, speed, steering): pass
    def close(self): pass

imu   = MockIMU()
robot = MockRobot()

# -----------------------------------------------------------------------
# 미로 맵 (dg)
# -----------------------------------------------------------------------

dg = [
    [13,  5,  1, 11],
    [12, 12, 14, 13],
    [ 4,  2,  1,  8],
    [14, 13, 12, 14],
    [ 5,  2, 10, 13],
    [ 6,  1,  1, 10],
    [13, 14, 12, 13],
    [ 6,  3,  2, 10]
]

# -----------------------------------------------------------------------
# 상수 / 타입 정의
# -----------------------------------------------------------------------

azimuth = namedtuple('azimuth', ['n', 's', 'w', 'e'])

azimuthList = [
    azimuth(1,1,1,1), azimuth(0,1,1,1), azimuth(1,0,1,1), azimuth(0,0,1,1),
    azimuth(1,1,0,1), azimuth(0,1,0,1), azimuth(1,0,0,1), azimuth(0,0,0,1),
    azimuth(1,1,1,0), azimuth(0,1,1,0), azimuth(1,0,1,0), azimuth(0,0,1,0),
    azimuth(1,1,0,0), azimuth(0,1,0,0), azimuth(1,0,0,0), azimuth(0,0,0,0),
]

_DIRS = [direction(0,-1), direction(1,0), direction(0,1), direction(-1,0)]  # N E S W

def look_dir(h, d):
    # 현재 heading h 에서 방향벡터 d 를 향하기 위해 회전해야 할 각도
    return [0, 90, 180, -90][(_DIRS.index(d) - h) % 4]

def next_dir(h, i):
    # h=현재heading, i: 0=좌 1=전 2=우
    return _DIRS[(h + i - 1) % 4]

# -----------------------------------------------------------------------
# 전역 상태
# -----------------------------------------------------------------------

lastYaw     = 0
lastTurnYaw = 0
gyroAngle   = 0
heading     = 2   # 로봇의 논리적 진행 방향 (0=N 북 / 1=E 동 / 2=S 남 / 3=W 서)
is_reversed = False

pos      = [0, 0]
startPos = [0, 0]
cur_dg   = [0, 0]
dg_start = [0, 0]   # 미로에서의 물리적 시작 위치 (dg 배열 좌표)

openList   = []
closedList = [direction(0, 0)]

checkpoint = {
    "grid": None, "node": None, "dir": None,
    "openList": None, "closedList": None,
    "startPos": None, "gyroAngle": None,
    "heading": None, "cur_dg": None,
}

# -----------------------------------------------------------------------
# PID (모의 — 상태 변수 갱신만)
# -----------------------------------------------------------------------

def pid_control(speed, gain, kp, kd):
    pass

def pid_turn_control(dest, gain, kp, kd):
    pass

# -----------------------------------------------------------------------
# 회전 / 리셋 (모터 미작동, 상태만 갱신)
# -----------------------------------------------------------------------

async def reset_turn():
    pass


async def turn(dest, duration=2000):
    global heading, lastYaw, gyroAngle, is_reversed

    if dest == 0:
        return

    if abs(dest) == 180:
        is_reversed = not is_reversed
        heading = (heading + 2) % 4
        return

    actual_dest = -dest if is_reversed else dest
    gyroAngle += actual_dest
    lastYaw = 0
    heading = (heading + (1 if dest == 90 else -1)) % 4

# -----------------------------------------------------------------------
# dg 벽 감지
# -----------------------------------------------------------------------

def _dg_az(gx, gy):
    # 시각적 레이아웃 기준: bit0=N벽, bit1=S벽, bit2=W벽, bit3=E벽 (1=벽 있음)
    v = dg[gy][gx]
    return azimuth(1-(v&1), 1-((v>>1)&1), 1-((v>>2)&1), 1-((v>>3)&1))


def has_front_wall(gx, gy):
    if gy < 0 or gy >= len(dg) or gx < 0 or gx >= len(dg[0]):
        return True
    az = _dg_az(gx, gy)
    walls_fwd = (az.n, az.e, az.s, az.w)
    walls_rev = (az.s, az.w, az.n, az.e)
    return (walls_rev if is_reversed else walls_fwd)[heading] == 0

# -----------------------------------------------------------------------
# 주행 (모터 미작동)
# -----------------------------------------------------------------------

async def drive(speed, destMM):
    robot.reset()
    await asyncio.sleep(0.05)  # 주행 시간 시뮬레이션

# -----------------------------------------------------------------------
# 그리드 계산
# -----------------------------------------------------------------------

def get_open_side(gx, gy):
    dg_x, dg_y = cur_dg[0], cur_dg[1]
    if dg_y < 0 or dg_y >= len(dg) or dg_x < 0 or dg_x >= len(dg[0]):
        az = azimuth(0, 0, 0, 0)
    else:
        az = _dg_az(dg_x, dg_y)
    raw = [
        (az.w, az.n, az.e),
        (az.n, az.e, az.s),
        (az.e, az.s, az.w),
        (az.s, az.w, az.n),
    ][heading]
    sides = list(raw)

    for i in range(3):
        nb = direction(gx + next_dir(heading, i).x, gy + next_dir(heading, i).y)
        if nb in closedList:
            sides[i] = 0
        elif sides[i] and next_dir(heading, i) in openList:
            openList.remove(next_dir(heading, i))

    return sides


def sides_to_wall(sides, isFirst=False):
    # isFirst=True: 시작 셀은 후면이 항상 벽(막힌 면에 붙여 출발)
    backward = 0 if isFirst else 1
    n = s = w = e = 0
    if   heading == 0: n, s, w, e = sides[1], backward, sides[0], sides[2]
    elif heading == 1: n, s, w, e = sides[0], sides[2], backward, sides[1]
    elif heading == 2: n, s, w, e = backward, sides[1], sides[2], sides[0]
    elif heading == 3: n, s, w, e = sides[2], sides[0], sides[1], backward
    # 시각적 레이아웃: bit0=N벽, bit1=S벽, bit2=W벽, bit3=E벽 (1=벽 있음, 0=통로)
    return (1-n) | ((1-s) << 1) | ((1-w) << 2) | ((1-e) << 3)


def check_open_dir(gx, gy, isFirst=False):
    sides = get_open_side(gx, gy)
    return sides, sides_to_wall(sides, isFirst)


def _expand_grid(grid, _node, dir):
    dx = dy = tx = ty = gx = gy = 0
    old_h, old_w = len(grid), len(grid[0])
    if dir.x != 0:
        tx = -dir.x
        if not (0 <= _node.x + dir.x < old_w):
            gx = 1
            if dir.x < 0: dx = 1
    if dir.y != 0:
        ty = -dir.y
        if not (0 <= _node.y + dir.y < old_h):
            gy = 1
            if dir.y < 0: dy = 1
    return dx, dy, tx, ty, gx, gy


def _build_grid(grid, dx, dy, gx, gy):
    tGrid = [[NNode() for _ in range(len(grid[0]) + gx)]
             for _ in range(len(grid) + gy)]
    for y in range(len(grid)):
        for x in range(len(grid[0])):
            n = grid[y][x]
            n.set_xy(n.x + dx, n.y + dy)
            tGrid[y + dy][x + dx] = n
    return tGrid


def modify_grid(_node, dir, grid):
    global openList, closedList

    dx, dy, tx, ty, gx, gy = _expand_grid(grid, _node, dir)

    openList   = [direction(e[0] + tx, e[1] + ty) for e in openList]
    closedList = [direction(e[0] + dx, e[1] + dy) for e in closedList]

    nx, ny = _node.x + dir.x + dx, _node.y + dir.y + dy
    sides, _wall = check_open_dir(nx, ny)

    _node = Node(nx, ny, _wall, None)
    tGrid = _build_grid(grid, dx, dy, gx, gy)
    tGrid[_node.y][_node.x] = _node

    for i, cond in enumerate(sides):
        if cond:
            openList.append(next_dir(heading, i))
    closedList.append(direction(_node.x, _node.y))

    return _node, tGrid, dx, dy


async def follow_next_dir(_dir, _node, _grid):
    isGriding = True
    _node = _node.copy()
    try:
        _grid[_node.pos(_dir)[1]][_node.pos(_dir)[0]]
    except Exception:
        isGriding = False

    dirs = get_directions(_grid, dir_to_pos(_node.pos()), dir_to_pos(_node.pos(_dir)), isGriding)
    await asyncio.sleep(0)

    for __dir in dirs:
        if __dir in (direction(0,2), direction(0,-2), direction(2,0), direction(-2,0)):
            half = direction(__dir.x // 2, __dir.y // 2)
            _node.add_xy(half.x, half.y)
            _dir = add_dir(_dir, -half.x, -half.y)
            openList[:] = [add_dir(e, -half.x, -half.y) for e in openList]
            create_grid(grid_to_int(_grid), direction(_node.x, _node.y), heading)
            continue

        await turn(look_dir(heading, __dir))
        cur_dg[0] += __dir.x
        cur_dg[1] += __dir.y
        await drive(300, 230)

        _node.add_xy(__dir.x, __dir.y)
        _dir = add_dir(_dir, -__dir.x, -__dir.y)
        openList[:] = [add_dir(e, -__dir.x, -__dir.y) for e in openList]
        create_grid(grid_to_int(_grid), direction(_node.x, _node.y), heading)

    return _dir, _node


def grid_to_int(grid):
    return [[n.wall for n in row] for row in grid]


def dir_to_pos(d):
    return [d.x, d.y]


def add_dir(d, x, y):
    return direction(d.x + x, d.y + y)

# -----------------------------------------------------------------------
# 메인 탐색 루프
# -----------------------------------------------------------------------

async def start_program():
    global pos, startPos, checkpoint, openList, closedList, heading, gyroAngle, cur_dg

    pos = startPos = [0, 0]
    cur_dg = list(dg_start)
    openList, closedList = [], [direction(0, 0)]
    gyroAngle = 0
    await reset_turn()

    sides, wall = check_open_dir(0, 0, True)
    openList = [next_dir(heading, i) for i, ok in enumerate(sides) if ok]

    node = Node(0, 0, wall, None)
    grid = [[node]]
    if not openList:
        create_grid(grid_to_int(grid), direction(node.x, node.y), heading)
        return
    dir  = openList.pop()
    create_grid(grid_to_int(grid), direction(node.x, node.y), heading)

    while True:
        if dir not in (direction(0,-1), direction(0,1), direction(-1,0), direction(1,0)):
            dir, node = await follow_next_dir(dir, node, grid)
        elif node.wall in (7, 11, 13, 14):
            one_exit = {7: direction(1,0), 11: direction(-1,0),
                        13: direction(0,1), 14: direction(0,-1)}[node.wall]
            if dir != one_exit:
                dir, node = await follow_next_dir(dir, node, grid)

        await turn(look_dir(heading, dir))

        cur_dg[0] += dir.x
        cur_dg[1] += dir.y
        await drive(300, 320)

        node, grid, dx, dy = modify_grid(node, dir, grid)
        pos = node.pos()
        startPos[0] += dx
        startPos[1] += dy

        create_grid(grid_to_int(grid), direction(node.x, node.y), heading)

        if not openList:
            break

        dir = openList.pop()
        await asyncio.sleep(0)

    print("탐색 완료")
    await follow_next_dir(
        direction(startPos[0] - node.x, startPos[1] - node.y), node, grid
    )


# -----------------------------------------------------------------------
# 엔트리포인트
# -----------------------------------------------------------------------

if __name__ == "__main__":
    asyncio.run(start_program())