from machine import I2C, Pin
import struct
import time

# 보드에 맞게 I2C 핀 번호 설정 (예: ESP32 기준 SCL=22, SDA=21)
i2c = I2C(0, scl=Pin(11), sda=Pin(12))

# 1. I2C 통신 연결 확인
devices = i2c.scan()
print("연결된 I2C 주소들:", [hex(d) for d in devices])
if 0x22 not in devices:
    print("경고: 0x22 주소의 모터 드라이버가 인식되지 않았습니다! (선 연결이나 전원 확인 필요)")

# 2. 1번 모터 생사결 테스트 (일반 PWM 모드)
try:
    print("1번 모터 모드 초기화 중...")
    i2c.writeto_mem(0x22, 0x50, b'\x00')  # 1번 모터(0x50)를 PWM 모드(0x00)로 설정
    time.sleep(0.1)

    print("1번 모터 회전 명령 전송 (PWM 50)")
    i2c.writeto_mem(0x22, 0x20, struct.pack('b', 50))  # 1번 모터 PWM 레지스터(0x20)에 50 입력
    time.sleep(2)

    print("1번 모터 정지")
    i2c.writeto_mem(0x22, 0x20, struct.pack('b', 0))

except Exception as e:
    print("통신 중 에러 발생:", e)