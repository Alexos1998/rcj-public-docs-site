"""
fable 패키지 기반 메인 앱 — apps/main.py(fixed_main+ToF)의 정리본.

구조(turn/탐색/main)는 검증된 main.py와 동일하게 유지하고, 실주행에서 확인된
문제들만 고쳤다:
  1) 내리막 오탐 — 주석으로만 있고 구현이 빠져 있던 워밍업/pitch0 영점 상쇄를 실제로
     구현하고, 연속 N틱 유지 시에만 판정(단발 pitch 스파이크 무시).
  2) get_open_side 무한 재시도 — ToF가 계속 -1이면 영원히 도는 while True를 유한
     재시도로 바꾸고, 끝까지 무효면 그 면을 벽으로 보수 처리(구멍/미지로 진입 방지).
  3) print 플러딩 — 주행 핫루프의 매 틱 컬러 출력 제거(USB 버퍼 블로킹 방지).
  4) destMM += 10 휴리스틱 제거 — 목표 거리를 몰래 늘려 오버슛을 유발했다.
  5) 검정(구멍) 판정 연속 2틱 디바운스 — 오분류 1틱으로 정지/후진하지 않게.
"""


import time
from machine import I2C, Pin

import M5
M5.begin()  # I2C 초기화 전에 가장 먼저 실행
# 콜드(하드)부팅 settle — M5.begin()이 시작한 FT6336 터치 init/reset 해제가 끝나기 전에
# 아래에서 I2C(0)를 재생성하면 그 init 트랜잭션이 중간에 끊겨 터치가 죽는다(콜드부팅만
# 실패, 소프트리셋은 이전 부팅 init이 남아 정상). 충분히 기다린 뒤 버스를 잡는다.
time.sleep_ms(500)

from collections import namedtuple
from fable.scheduler import gsleep, grun, grace
from fable.drivebase import DriveBase
from fable.vl53l0x import VL53L0X
from fable.devices import PaHub, IMU, Touch, reset_cores3_touch, ColorSensor
from fable.dropper import Dropper
from fable.astar import direction, Node, NNode, get_directions, create_grid
from fable.logger import log_error, init_logging
init_logging()


# -----------------------------------------------------------------------
# 하드웨어 초기화
# -----------------------------------------------------------------------

# 메인 버스(하드웨어 I2C id=0). IMU·DriveBase·Touch가 이 i2c 객체를 직접 공유한다.
# 콜드부팅 터치 실패의 진짜 원인은 I2C 인스턴스 충돌이 아니라 FT6336 RST(AW9523 P0 bit0)가
# 안 풀린 것 → Touch.__init__의 reset_cores3_touch()가 AW9523로 직접 리셋을 풀어 해결한다.
_i2c = I2C(0, scl=Pin(11), sda=Pin(12), freq=800000)

# Touch 를 가장 먼저 생성한다 — __init__의 reset_cores3_touch()가 콜드부팅에서 죽어 있는
# FT6336 RST(AW9523 P0 bit0)를 풀어 깨운다. IMU/DriveBase init 트래픽보다 앞서 깨워야
# 진단(touch_aw9523_test.py)에서 검증된 "I2C 생성 → 곧바로 리셋" 순서와 일치한다.
touch = Touch(_i2c)                        # 터치 패널 (FT6336)
imu   = IMU(_i2c, gyro_deadzone=0.6)       # 자이로 데드존: 미세 노이즈 무시
robot = DriveBase(
    _i2c,
    right_motors=[2, 3], left_motors=[1, 4],
    wheel_diameter=62.4,   # 바퀴 직경 (mm)
    axle_track=112,        # 좌우 바퀴 간격 (mm)
    right_counter=True,    # 우측 모터 엔코더 방향 반전
    gear=[12, 28]          # 기어비: 구동 12T → 피동 28T
)

# UnitV2 2대 → 서보 투하 장치.
#   왼쪽 = Port C(UART2, RX=G17/TX=G18),  오른쪽 = Port B(UART1, G8/G9).
#   문자 수신 시 해당 방향(서보1: 중립 90° → 왼쪽 20°/오른쪽 160°)으로 투하 후 복귀.
#   좌/우 적재량은 left_count/right_count(기본 5/5). 투하는 drive 함수에 귀속.
#   ※ 카메라 좌/우가 바뀌어 있으면 left_uart/right_uart 를 서로 바꾼다.
dropper = Dropper(robot, servo=1, neutral=90,
                  left_angle=20, right_angle=160,
                  left_count=5, right_count=5, drop_hold_ms=500)

# ToF 4개 (PaHub 너머). 포트: 앞5 오4 뒷1 왼0.
# 실제 i2c 초기화/센서 생성/start는 main()에서 수행한다.
pahub = PaHub(sda=2, scl=1)
tof1 = tof2 = tof3 = tof4 = None

# 바닥 컬러센서 (TCS3472, 같은 PaHub). ToF가 0/1/4/5 → 남는 2/3번.
# 실제 생성은 main()에서 pahub.start() 뒤에 한다.
COLOR_CH = 2       # 컬러센서(전진 방향) — is_reversed=False일 때 사용
COLOR_CH_REV = 3   # 컬러센서(후진 방향) — is_reversed=True일 때 사용
color = None
color_rev = None

# 피해자(victim) 종류별 화면 표시색 — 식별 시 규정상 5초 시각신호로 표시.
VICTIM_RGB = {0: 0x00FF00, 1: 0xFFFF00, 2: 0xFF0000}  # 0=Unharmed(초록) 1=Stable(노랑) 2=Harmed(빨강)

WALL_MM = 105  # 벽으로 판정하는 거리 임계값 (mm)
STOP_MM = 35   # 주행 중 충돌 방지 긴급 정지 임계값 (mm)
DROP_TOF_MAX = 135     # 투하 판정: 해당 방향 ToF 가 이 값(mm) 이하일 때만 유효 감지로 처리

# 후방 벽정렬(회전 직후 재앵커링)
ALIGN_BACK_MM = 35     # 이 거리(mm)까지 후진해 평평한 벽에 밀착
ALIGN_TIMEOUT = 2000   # 후진 정렬 타임아웃 (ms)
ALIGN_PUSH_MS = 600    # 밀착 후 추가로 미는 시간(ms) — 양측 동일 출력으로 스퀘어 맞춤
ALIGN_FRONT_MM = 40    # 전방 벽 정렬 목표 거리(mm) — 전방 ToF가 이 값이 되도록 straight 보정
ALIGN_SPEED = 75       # 후방 벽정렬 주행속도 — 일반 주행(150)보다 낮춰 충돌/오버슈트 완화
ALIGN_FRONT_SPEED = 60 # 전방 벽정렬 주행속도 — 근거리 정밀 보정이라 더 낮게

# -----------------------------------------------------------------------
# 상수 / 타입 정의
# -----------------------------------------------------------------------

# 셀의 4방향 통행 가능 여부를 담는 네임드튜플
azimuth = namedtuple('azimuth', ['n', 's', 'w', 'e'])

_DIRS = [direction(0, -1), direction(1, 0), direction(0, 1), direction(-1, 0)]  # N E S W


def look_dir(h, d):
    # 현재 heading h 에서 방향벡터 d 를 향하기 위해 회전해야 할 각도
    return [0, -90, 180, 90][(_DIRS.index(d) - h) % 4]


def next_dir(h, i):
    # h=현재heading, i: 0=좌 1=전 2=우
    return _DIRS[(h + i - 1) % 4]

# -----------------------------------------------------------------------
# 전역 상태
# -----------------------------------------------------------------------

lastYaw     = 0   # 직진 PID 이전 프레임 편차 (미분항 계산용)
lastTurnYaw = 0   # 회전 PID 이전 프레임 편차
yawIntegral = 0   # 직진 PID 적분항 — 모터 출력 불균형 등 일정한 외란에 의한 정상상태
                  # 편향(한쪽으로 계속 치우침)은 P(D)만으로는 못 없앤다. drive() 시작 시 리셋.
gyroAngle   = 0   # 누적 목표 각도 (회전할 때마다 갱신)
heading     = 0   # 로봇의 논리적 진행 방향 (0=N 1=E 2=S 3=W)

# 전후면 반전 플래그.
# True 이면 후면이 진행 방향 — 실제 180도 회전 대신 모터 방향만 반전한다.
# 이후 상태는 180도 턴에서의 토글(not is_reversed)로만 바뀌므로, 이 초기값만으로
# 탐색 시작 시 정면/후면 중 어느 쪽으로 진행할지가 결정된다 — 시작은 정면 진행(False).
is_reversed = False

pos      = [0, 0]   # 현재 그리드 좌표 (절대)
startPos = [0, 0]   # 시작 셀의 그리드 좌표 (그리드 확장 시 함께 갱신)

openList   = []                    # 아직 방문하지 않은 이웃 방향 스택
closedList = [direction(0, 0)]     # 이미 방문한 셀 좌표 목록

# 프로그램 재시작 시 이전 상태를 복원하기 위한 체크포인트
checkpoint = {
    "grid": None,       # 탐색 그리드
    "node": None,       # 마지막 노드
    "dir": None,        # 다음 이동 방향
    "openList": None,
    "closedList": None,
    "startPos": None,
    "gyroAngle": None,
    "heading": None,
}

# -----------------------------------------------------------------------
# 제너레이터 유틸 (스케줄러는 fable.scheduler, 여기는 앱 전용)
# -----------------------------------------------------------------------

def wait_touch(hold_threshold=300, detect_hold=True):
    # Touch.is_touching()(디바운스 캐시) 기반 터치 대기 제너레이터.
    press_time = 0
    was_touching = False
    while True:
        touching = touch.is_touching()
        now = time.ticks_ms()
        if not was_touching and touching:
            press_time = now
        if was_touching and not touching:
            if detect_hold:
                if time.ticks_diff(now, press_time) >= hold_threshold:
                    return 2
                else:
                    return 1
            else:
                return True
        was_touching = touching
        yield


def blink_victim(rgb):
    # 규정 5.6.1: victim 성공 식별 조건 — 15cm 이내 정지 상태에서 전용 표시(LED/Display)를
    # ON 500ms / OFF 500ms 간격으로 5초간(=5회) 점멸해야 한다. 정적 표시는 인정되지 않는다.
    for _ in range(5):
        M5.Lcd.fillScreen(rgb)
        yield from gsleep(500)
        M5.Lcd.fillScreen(0x000000)
        yield from gsleep(500)


def blink_exit():
    # 규정 5.6.12 Exit Bonus: 시작 타일 복귀 시 victim 식별과 같은 표시로 ON 1s / OFF 1s
    # 간격으로 최소 10초간(=10회) 점멸해 종료 신호를 낸다.
    for _ in range(10):
        M5.Lcd.fillScreen(0xFFFFFF)
        yield from gsleep(1000)
        M5.Lcd.fillScreen(0x000000)
        yield from gsleep(1000)

# -----------------------------------------------------------------------
# PID 제어
# -----------------------------------------------------------------------

# 오도메트리 직진 보정 가중치 (deg당 조향량). 0이면 비활성. 실측 튜닝 필요.
ODO_STRAIGHT_GAIN = 2.0
ODO_DEADBAND_DEG = 0.3   # 엔코더 양자화 노이즈 불감대 — limit cycle 방지

# 직진 감속 프로파일. drive()의 순항 속도(150) 기준.
DRV_DEC_SPEED = 0.4       # 지수 감속 밑 — speed_factor = DRV_DEC_SPEED ** ratio
SPEED_FLOOR = 0.7         # 떨림방지 감속 하한 — 그 이하 감속은 stiction 한계 근처라 후반 떨림 유발
FINAL_APPROACH_MM = 60    # 목표 지점까지 이 거리(mm) 이내면 하한을 무시하고 더 감속
                          # (30mm로는 순항속도에서 실제 감속할 물리적 거리가 부족했음)
FINAL_MIN_FACTOR = 0.2    # 근접 구간 최저 속도비 — brake() 시점 속도를 낮춰 정지 정확도 우선

YAW_KI = 0.15             # 직진 적분 게인 — 정상상태 편향(한쪽 쏠림)만 서서히 상쇄
YAW_I_CLAMP = 8.0         # 적분 누적 상한(deg) — 와인드업(정지/급커브 후 과잉반응) 방지

# 내리막 처리 — 무게중심 문제로 빠르게 내려오면 모서리에서 앞으로 굴러떨어진다.
# 단순 감속은 150 관성이 이미 붙어 늦으므로, pitch 감지 시 일단 정지→출발점 후진→저속
# 재진입으로 "관성 없이 저속으로 모서리 진입"(=떨어지지 않던) 조건을 재현한다.
DOWNHILL_PITCH = 15.0       # 내리막/오르막 판정 임계(도) — 실측으로 조정
DOWNHILL_SPEED = 75         # 내리막 저속(후진 재진입 후 통과 속도) — 실측으로 안 떨어지던 값
BACKOFF_TOL_MM = 3          # 후진(이 drive 출발점으로 복귀) 정지 허용오차(mm)
DOWNHILL_WARMUP_MM = 25     # 출발 직후 이 거리까지 감지 보류 + pitch0 추종 — 출발 가속 노이즈 방지
DOWNHILL_TRIG_TICKS = 3     # 임계 초과가 연속 이 틱 수만큼 유지돼야 판정 — 단발 스파이크(타일 턱) 무시


def odo_yaw():
    # 좌우 바퀴 주행차로 추정한 헤딩 변화(deg). 자이로와 독립 → 자기간섭/적분 드리프트 면역.
    # robot.reset()(=drive 시작) 기준이라 직진 중엔 0이어야 정상. 양수=CCW(좌)로 틀어짐.
    l = (robot.current_encoder[robot.left_ports[0] - 1] - robot.left_ref) * robot.l_counter
    r = (robot.current_encoder[robot.right_ports[0] - 1] - robot.right_ref) * robot.r_counter
    return (r - l) * robot._deg_to_mm / robot.axle_track * 57.29577951308232


def pid_control(speed, gain, kp, kd, odo_scale=1.0):
    global lastYaw, yawIntegral
    yaw = -(imu.angle() - gyroAngle)
    diff = yaw - lastYaw
    lastYaw = yaw
    yawIntegral = max(-YAW_I_CLAMP, min(YAW_I_CLAMP, yawIntegral + yaw))
    # 엔코더 양자화 노이즈가 조향으로 반사돼 limit cycle을 만들지 않게 소량 불감대.
    odo = odo_yaw()
    if abs(odo) < ODO_DEADBAND_DEG:
        odo = 0
    # 자이로 PID + 오도메트리 직진 보정(독립 신호). odo_yaw>0(좌로 드리프트)면 우로 보정.
    # 감속 시 조향(gain/odo_scale)을 speed에 비례 축소해 정지 직전 좌우 흔들림 제거.
    # I항: 모터 출력 불균형 등 일정한 외란으로 인한 한쪽 쏠림(정상상태 오차)을 상쇄.
    robot.drive(speed, (kp * yaw + kd * diff + YAW_KI * yawIntegral) * gain
                - ODO_STRAIGHT_GAIN * odo_scale * odo)


def pid_turn_control(dest, gain, kp, kd):
    global lastTurnYaw
    yaw = dest - (imu.angle() - gyroAngle)
    diff = yaw - lastTurnYaw
    lastTurnYaw = yaw
    robot.drive(0, (kp * yaw + kd * diff) * gain)


def reset_turn():
    print("reset_turn 시작 angle=%.1f" % imu.angle())
    start = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), start) < 5000:
        if abs(imu.angle() - gyroAngle) < 0.1:
            break
        pid_turn_control(gyroAngle, 0.26, 17.2, 4)
        yield
    robot.brake()
    print("reset_turn 완료 angle=%.1f" % imu.angle())

# -----------------------------------------------------------------------
# ToF 읽기 / 벽 정렬
# -----------------------------------------------------------------------

def read_tof(sensor, retries=5):
    # ToF 단발 읽기 + -1(무효) 처리 — -1이면 최대 retries회 재시도, 끝까지 -1이면 -1 반환.
    for _ in range(retries):
        v = sensor.get()
        if v != -1:
            return v
    return -1


def read_tof_median3(sensor):
    # 단발 읽기는 크로스토크/반사로 실제 벽 없는 곳에서도 순간적으로 짧게 튀어 오검출을
    # 일으킬 수 있다 — 3회 읽어 중앙값으로 판단해 노이즈성 단발 튐을 걸러낸다.
    samples = sorted(read_tof(sensor) for _ in range(3))
    return samples[1]


def align_back(rev):
    # 회전 직후 후방에 벽이 있으면 그 벽에 평평히 붙여 자세/헤딩을 재앵커링한다.
    # 센서가 면당 1개뿐이라 각도 측정은 못 한다 → 평평한 벽에 양측 동일 출력(조향 0)으로
    # 밀어붙여 섀시를 기계적으로 스퀘어시킨 뒤, imu 각을 목표(gyroAngle)에 맞춰 적분 드리프트 제거.
    global lastYaw

    # 진행 전방의 반대편이 후방 센서 (drive의 front: not reversed=tof1 / reversed=tof4).
    rear = tof1 if is_reversed else tof4
    if rear is None:
        yield from robot.straight(ALIGN_SPEED, 20 * rev)
        return

    d = read_tof_median3(rear)
    if d == -1 or d > WALL_MM:   # 무효(-1) 또는 후방에 벽 없음 → 정렬 생략
        print("후방 벽 없음/무효 → 정렬 생략", d)
        return
    print("후방 벽 정렬 시작", d)

    # 후방으로 천천히 후진해 벽에 붙인다 (모터 부호는 전진의 반대 = -rev). 후진량은 distance로 측정.
    robot.reset()
    start = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), start) < ALIGN_TIMEOUT:
        rv = rear.get()
        if 0 <= rv <= ALIGN_BACK_MM:   # -1(무효)은 무시, 정상 근접일 때만 종료
            break
        robot.drive(-ALIGN_SPEED * rev, 0)
        yield from gsleep(1)

    # 평평히 밀착되도록 잠깐 더 민다 — 양측 동일 출력이라 벽 반력으로 스퀘어가 맞춰진다.
    push = time.ticks_add(time.ticks_ms(), ALIGN_PUSH_MS)
    while time.ticks_diff(push, time.ticks_ms()) > 0:
        robot.drive(-ALIGN_SPEED * rev, 0)
        yield from gsleep(1)
    robot.brake()

    # 후진한 거리 (straight가 내부에서 reset 하므로 전진 전에 읽어둔다).
    back_dist = 15

    # 재앵커링 — 물리적으로 그리드 축에 정렬됐으므로 imu 각을 목표(gyroAngle)로 맞춘다.
    imu.set_angle(gyroAngle)
    lastYaw = 0

    # 후진한 만큼 다시 전진해 셀 중앙으로 복귀.
    yield from robot.straight(ALIGN_SPEED, back_dist * rev)
    robot.brake()
    print("후방 벽 정렬 완료, 복귀 %.0fmm angle=%.1f" % (back_dist, imu.angle()))


def align_front():
    # 진행 방향 앞에 벽이 있으면 전방 ToF 거리가 ALIGN_FRONT_MM(40mm)이 되도록
    # straight로 보정한다. (벽 없으면 생략. 중앙값 3회로 단발 오검출 차단.)
    front = tof4 if is_reversed else tof1   # drive의 전방 센서와 동일
    if front is None:
        return
    d = read_tof_median3(front)
    if d == -1 or d > WALL_MM:   # 무효(-1) 또는 앞에 벽 없음 → 정렬 생략
        print("전방 벽 없음/무효 → 정렬 생략", d)
        return
    rev = -1 if not is_reversed else 1
    move = d - ALIGN_FRONT_MM   # 앞으로 (d-40)mm 가면 전방이 40mm가 된다 (음수면 후진)
    if move < 0:                # 후진은 보수적으로 — 거리를 1/2배만 보정
        move *= 0.5
    print("전방 벽 정렬", d, "→", ALIGN_FRONT_MM, "이동", move)
    yield from robot.straight(ALIGN_FRONT_SPEED, move * rev)
    robot.brake()

# -----------------------------------------------------------------------
# 회전
# -----------------------------------------------------------------------

def turn(dest, duration=2000):
    global heading, lastYaw, gyroAngle, is_reversed

    if dest == 0:
        return

    if abs(dest) == 180:
        is_reversed = not is_reversed
        heading = (heading + 2) % 4
        rev = -1 if not is_reversed else 1
        yield from align_back(rev)
        return

    # is_reversed면 진행 방향이 뒤집히므로 부호도 반전 (align_back에 전달).
    rev = -1 if not is_reversed else 1

    robot.brake()
    settle_start = None   # angle-gyroAngle 편차가 0.5 이하로 들어온 시각 (None=아직 미도달)
    dropped_turn = set()
    dropper.start()

    # remaining(오차)이 0.5° 이하로 duration(기본 2000ms) 이상 연속 유지돼야 회전 종료.
    # 중간에 다시 벌어지면(카메라 드롭 등으로 흔들려도) 정착 타이머를 리셋한다.
    while True:
        remaining = dest - (imu.angle() - gyroAngle)
        ratio = min(1.0, abs(remaining) / abs(dest))  # 1.0=출발 → 0.0=도착
        pid_turn_control(dest, 0.14 + 0.28 * ratio, 17.2, 10)
        # 회전 바깥쪽 카메라 폴링 — 우회전(dest>0)이면 왼쪽, 좌회전이면 오른쪽
        r = dropper.poll()
        if r is not None:
            c, kits = r
            outside = (not dropper.is_right(c)) if dest > 0 else dropper.is_right(c)
            if outside and c not in dropped_turn:
                d = (tof2 if dropper.is_right(c) else tof3).get()
                if not (0 < d <= DROP_TOF_MAX):
                    dropper.resume(c)
                else:
                    dropped_turn.add(c)
                    robot.brake()
                    if kits:
                        yield from dropper.drop(c, kits)
                    yield from blink_victim(VICTIM_RGB.get(kits, 0xFFFFFF))
                    settle_start = None  # 흔들렸으니 정착 타이머 리셋
        if abs(remaining) < 0.5:
            if settle_start is None:
                settle_start = time.ticks_ms()
            elif time.ticks_diff(time.ticks_ms(), settle_start) >= duration:
                break
        else:
            settle_start = None
        yield

    gyroAngle += dest
    lastYaw = 0
    robot.brake()
    print("turn finished")

    # 회전 직후 후방에 벽이 있으면 그 벽에 붙여 자세/헤딩 재앵커링 (없으면 자동 생략).
    yield from align_back(rev)

    heading = (heading + (-1 if dest == 90 else 1)) % 4

# -----------------------------------------------------------------------
# 주행
# -----------------------------------------------------------------------

def drive(speed, destMM, cam=True):
    # cam=True면 투하 행위를 이 drive 에 귀속: 시작 시 두 카메라 START → 주행 중 0/1/2
    #   수신 시 해당 방향 ToF로 벽 확인 후 서보 투하. follow_next_dir(먼 노드)은 cam=False.
    global yawIntegral, lastYaw
    yawIntegral = 0   # 이전 세그먼트의 누적 편향이 새 구간으로 새지 않게 리셋
    sensor = tof4 if is_reversed else tof1  # 진행방향 전방 센서(전/후 swap)
    downhill_done = False
    downhill_ticks = 0                      # 임계 초과 연속 틱 카운트(디바운스)
    pitch0 = imu.pitch_deg()                # drive 시작(평지) 기준 pitch — 장착 바이어스 상쇄
    black_ticks = 0                         # 검정(구멍) 연속 감지 카운트(디바운스)

    dropped = set()                         # 투하/식별 완료한 카메라(방향)들 — 그 카메라만 이후 무시
    if cam:
        dropper.start()                     # 두 카메라 무장(RESUME 송신)

    robot.reset()

    blocked = None                          # "black"이면 구멍 감지로 중단(호출부가 벽으로 기록)

    while True:
        dist = abs(robot.distance())
        if dist > destMM:
            break
        ratio = dist / destMM

        # ---- 내리막 진입 처리 -------------------------------------------
        # 진행방향 기준 '내리막으로 숙은 정도'(downhill, 양수=내리막)가 임계를
        # 연속 DOWNHILL_TRIG_TICKS 틱 넘으면 정지→출발점 후진→저속 재진입한다
        # (150 관성을 끊고 저속 모서리 진입을 재현). 한 번 처리하면 이 drive 남은
        # 구간은 저속(DOWNHILL_SPEED)으로 캡한다.
        # 출발 직후 DOWNHILL_WARMUP_MM 까지는 출발 가속으로 pitch가 튀므로 감지를
        # 보류하고 그동안 pitch0 를 현재값으로 추종(평지 영점 재정렬)시켜 오트리거를
        # 막는다. 진행방향 부호: 전진은 앞이 숙으면 pitch↓라 -(cur-pitch0), 후진은
        # 뒤가 숙으면 pitch↑라 +(cur-pitch0).
        cur = imu.pitch_deg()
        if not downhill_done:
            if dist < DOWNHILL_WARMUP_MM:
                pitch0 = cur       # 워밍업 — 판정 보류 + 평지 영점 추종
                downhill_ticks = 0
            else:
                downhill = -(cur - pitch0) if not is_reversed else (cur - pitch0)
                if downhill > DOWNHILL_PITCH:
                    downhill_ticks += 1
                else:
                    downhill_ticks = 0
                if downhill_ticks >= DOWNHILL_TRIG_TICKS:
                    print("내리막 감지 → 정지/후진/저속 재진입 (pitch %.1f)" % downhill)
                    bs = DOWNHILL_SPEED if not is_reversed else -DOWNHILL_SPEED
                    while abs(robot.distance()) > BACKOFF_TOL_MM:
                        robot.drive(bs, 0)
                        yield from gsleep(1)
                    robot.brake()
                    yield from gsleep(150)
                    # 정지/후진 동안 벌어진 yaw로 재개 첫 틱에 미분이 튀지 않게 리셋.
                    lastYaw = -(imu.angle() - gyroAngle)
                    downhill_done = True
                    continue

        # ---- 속도/조향 -------------------------------------------------
        eff = DOWNHILL_SPEED if downhill_done else speed
        drive_speed = -eff if not is_reversed else eff
        # 오르막(pitch0 기준 상승 방향): 감속 프로파일을 우회하고 전속력 유지.
        # 하중에 맞서 올라가는 중에 감속하면 실속 가능성이 있다.
        uphill = (cur - pitch0) if not is_reversed else -(cur - pitch0)
        # 감속 구간 떨림 방지: 조향량은 speed와 무관한 절대값이라 저속일수록 상대 비중이
        # 커짐 → gain과 오도 보정을 감속 비율에 맞춰 같이 축소. 하한 SPEED_FLOOR —
        # 그 이하 감속은 모터 stiction 한계 근처라 후반 떨림을 유발.
        # 단, 정지 목표 바로 앞(FINAL_APPROACH_MM 이내)은 떨림보다 정지 정확도를
        # 우선해 하한을 무시하고 FINAL_MIN_FACTOR까지 더 감속한다.
        remaining = destMM - dist
        if uphill > DOWNHILL_PITCH:
            speed_factor = 1.0
        elif remaining > FINAL_APPROACH_MM:
            speed_factor = max(DRV_DEC_SPEED ** ratio, SPEED_FLOOR)
        else:
            speed_factor = min(DRV_DEC_SPEED ** ratio, FINAL_MIN_FACTOR)
        # kd는 미분 지배(자이로 노이즈 증폭)를 피해 kp의 3배 수준(9)으로 유지.
        pid_control(drive_speed * speed_factor, 0.2 * speed_factor, 3, 9,
                    odo_scale=speed_factor)

        # ---- 전방 벽(ToF) 긴급 정지 -------------------------------------
        t = sensor.get()
        if not downhill_done and 0 <= t <= STOP_MM:   # -1(무효 읽기) 등 음수는 트리거에서 제외
            print("전방 벽(TOF) → 긴급 정지", t)
            break

        # ---- 카메라 투하 ------------------------------------------------
        # 문자 수신 시 해당 방향 ToF 로 벽 유무를 먼저 확인한다.
        #   ToF > WALL_MM+여유 → 그 방향에 벽이 없음(열린 면) → 오검출로 보고 그 카메라만
        #     재무장(RESUME)하고 drive 루프를 계속한다(투하하지 않음).
        #   벽이 있으면 서보 동작 후 계속. 한 번 투하하면 dropped 에 넣어 이후 그 카메라 무시.
        #   (오른쪽=tof2/물리우, 왼쪽=tof3/물리좌)
        if cam:
            r = dropper.poll()
            if r is not None:
                c, kits = r                          # kits: 0=Unharmed 1=Stable 2=Harmed
                if c not in dropped:                 # 이미 처리한 카메라(방향)면 그것만 무시
                    d = (tof2 if dropper.is_right(c) else tof3).get()
                    if not (0 < d <= DROP_TOF_MAX):
                        dropper.resume(c)            # 벽 없음(열린 면) → 오검출, 재무장만
                    else:
                        dropped.add(c)               # 이 카메라만 유효 식별 → 이후 이 카메라 무시
                        robot.brake()                # 규정 5.6: victim 15cm 이내 정지 상태에서
                        if kits:                     # 0(Unharmed)이면 식별만, 투하는 없음
                            yield from dropper.drop(c, kits)
                        yield from blink_victim(VICTIM_RGB.get(kits, 0xFFFFFF))
                        # 재개 시 PID 미분 튐 방지 — pid_control의 yaw 정의와 같은 부호로 리셋.
                        lastYaw = -(imu.angle() - gyroAngle)

        # ---- 검정(구멍) 감지 --------------------------------------------
        # 주행 중엔 검정만 본다 → 연속 2틱 감지 시 즉시 정지 후 후진(규정 3.2: 구멍 진입 금지).
        # 오분류 1틱만으로 정지/후진하지 않도록 디바운스. (핫루프 print 금지 — 이벤트만 출력)
        cs = cur_color()
        if cs is not None and cs.is_black():
            black_ticks += 1
        else:
            black_ticks = 0
        if black_ticks >= 2:
            print("구멍(검정 타일) 감지 → 긴급 정지/후진")
            robot.brake()
            rev = -1 if not is_reversed else 1
            yield from robot.straight(150, -dist * rev)
            blocked = "black"
            break

        yield from gsleep(1)

    robot.brake()
    robot.reset()
    print("drive finished")
    return blocked

# -----------------------------------------------------------------------
# 바닥 컬러 (RCJ 3.2 Floor) — 타일색 분류 + 규정 동작
# -----------------------------------------------------------------------

def blue_stop():
    # 규정: 파랑(웅덩이) 진입 시 다음 타일로 가기 전 5초 정지. 글자 없이 파랑/검정 깜빡임.
    robot.brake()
    for s in range(5, 0, -1):
        M5.Lcd.fillScreen(0x0000FF if s % 2 else 0x000000)
        yield from gsleep(1000)


def cur_color():
    # 진행 방향에 맞는 컬러센서 선택 — is_reversed=True(후면 진행)면 후방(채널3), 아니면 전방(채널2).
    return color if is_reversed else color_rev


def check_floor():
    # 정지(도착) 상태 측정 — 빨강/파랑/은색만 5회 다수결로 감지(노이즈 제거).
    # 검정(구멍)은 주행 중 drive()에서 처리하고, 흰색(일반)은 무시한다.
    # red(위험구역 입구)/silver(체크포인트)는 색 표시만, blue(웅덩이)는 5초 정지.
    cs = cur_color()
    if cs is None:
        return
    name = cs.detect_stop()
    if name is None:
        return
    print("floor:", name, cs.MEANING.get(name, "?"))
    if name == "blue":
        yield from blue_stop()

# -----------------------------------------------------------------------
# 그리드 계산
# -----------------------------------------------------------------------

def get_open_side(gx, gy):
    # 실제 ToF로 좌/전/우 개방 판정. 전/후·좌/우 물리 swap 반영:
    #   not reversed: 전방=tof1, 좌=tof3, 우=tof2
    #   reversed:     전방=tof4, 논리우=tof3, 논리좌=tof2
    print("get_open_side")

    # 워밍업 — 연속측정 모드 최신값으로 캐시를 채운다(-1/스테일 밀어내기).
    for _ in range(3):
        pahub.get([tof4, tof3, tof2, tof1])

    # -1(읽기 실패/무효)이 섞이면 재측정 — 단, 무한 루프가 되지 않게 유한 재시도.
    # 끝까지 무효인 면은 벽으로 보수 처리한다(미확인 방향으로 진입하지 않는 쪽이 안전).
    for attempt in range(10):
        if is_reversed:
            d_f, d_r, d_l = pahub.get([tof4, tof3, tof2])
        else:
            d_f, d_l, d_r = pahub.get([tof1, tof3, tof2])
        if -1 not in (d_f, d_r, d_l):
            break
        print("ToF -1 감지 → 재측정", d_f, d_r, d_l)
    print(d_f, d_r, d_l)

    # -1이 남아 있으면 그 면은 '벽 있음'(0) 처리 — d > WALL_MM 비교에서 -1은 자연히 0.
    sides = [int(d_l > WALL_MM), int(d_f > WALL_MM), int(d_r > WALL_MM)]

    for i in range(3):
        nb = direction(gx + next_dir(heading, i).x, gy + next_dir(heading, i).y)
        if nb in closedList:
            sides[i] = 0
        elif sides[i] and next_dir(heading, i) in openList:
            openList.remove(next_dir(heading, i))

    return sides


def sides_to_wall(sides, isFirst=False):
    # isFirst=True: 시작 셀은 후면이 항상 벽(막힌 면에 붙여 출발)
    backward = 0 if isFirst else 1
    n = s = w = e = 0
    if   heading == 0: n, s, w, e = sides[1], backward, sides[0], sides[2]
    elif heading == 1: n, s, w, e = sides[0], sides[2], backward, sides[1]
    elif heading == 2: n, s, w, e = backward, sides[1], sides[2], sides[0]
    elif heading == 3: n, s, w, e = sides[2], sides[0], sides[1], backward
    # 시각적 레이아웃: bit0=N벽, bit1=S벽, bit2=W벽, bit3=E벽 (1=벽 있음, 0=통로)
    return (1 - n) | ((1 - s) << 1) | ((1 - w) << 2) | ((1 - e) << 3)


# 절대 방향(direction) → sides_to_wall과 동일한 비트 (N=bit0 S=bit1 W=bit2 E=bit3)
_DIR_WALL_BIT = {direction(0, -1): 1, direction(0, 1): 2, direction(-1, 0): 4, direction(1, 0): 8}


def check_open_dir(gx, gy, isFirst=False):
    sides = get_open_side(gx, gy)
    return sides, sides_to_wall(sides, isFirst)


def _expand_grid(grid, _node, dir):
    dx = dy = tx = ty = gx = gy = 0
    old_h, old_w = len(grid), len(grid[0])
    if dir.x != 0:
        tx = -dir.x
        if not (0 <= _node.x + dir.x < old_w):
            gx = 1
            if dir.x < 0:
                dx = 1
    if dir.y != 0:
        ty = -dir.y
        if not (0 <= _node.y + dir.y < old_h):
            gy = 1
            if dir.y < 0:
                dy = 1
    return dx, dy, tx, ty, gx, gy


def _build_grid(grid, dx, dy, gx, gy):
    tGrid = [[NNode() for _ in range(len(grid[0]) + gx)]
             for _ in range(len(grid) + gy)]
    for y in range(len(grid)):
        for x in range(len(grid[0])):
            n = grid[y][x]
            n.set_xy(n.x + dx, n.y + dy)
            tGrid[y + dy][x + dx] = n
    return tGrid


def modify_grid(_node, dir, grid):
    global openList, closedList

    dx, dy, tx, ty, gx, gy = _expand_grid(grid, _node, dir)

    openList   = [direction(e[0] + tx, e[1] + ty) for e in openList]
    closedList = [direction(e[0] + dx, e[1] + dy) for e in closedList]

    nx, ny = _node.x + dir.x + dx, _node.y + dir.y + dy
    sides, _wall = check_open_dir(nx, ny)

    _node = Node(nx, ny, _wall, None)
    tGrid = _build_grid(grid, dx, dy, gx, gy)
    tGrid[_node.y][_node.x] = _node

    for i, cond in enumerate(sides):
        if cond:
            openList.append(next_dir(heading, i))
    closedList.append(direction(_node.x, _node.y))

    return _node, tGrid, dx, dy


def follow_next_dir(_dir, _node, _grid):
    isGriding = True
    _node = _node.copy()
    try:
        _grid[_node.pos(_dir)[1]][_node.pos(_dir)[0]]
    except Exception:
        isGriding = False

    dirs = get_directions(_grid, dir_to_pos(_node.pos()), dir_to_pos(_node.pos(_dir)), isGriding)

    for __dir in dirs:
        if __dir in (direction(0, 2), direction(0, -2), direction(2, 0), direction(-2, 0)):
            half = direction(__dir.x // 2, __dir.y // 2)
            _node.add_xy(half.x, half.y)
            _dir = add_dir(_dir, -half.x, -half.y)
            openList[:] = [add_dir(e, -half.x, -half.y) for e in openList]
            create_grid(grid_to_int(_grid), direction(_node.x, _node.y), heading)
            continue

        yield from turn(look_dir(heading, __dir))
        yield from gsleep(100)
        yield from drive(150, 305, cam=False)   # 먼 노드 이동 → 카메라(투하)만 끔, 전방 벽은 유지
        yield from align_front()   # 앞에 벽 있으면 전방 40mm로 맞춤
        yield from check_floor()
        yield from gsleep(100)

        _node.add_xy(__dir.x, __dir.y)
        _dir = add_dir(_dir, -__dir.x, -__dir.y)
        openList[:] = [add_dir(e, -__dir.x, -__dir.y) for e in openList]
        create_grid(grid_to_int(_grid), direction(_node.x, _node.y), heading)

    return _dir, _node


def grid_to_int(grid):
    return [[n.wall for n in row] for row in grid]


def dir_to_pos(d):
    return [d.x, d.y]


def add_dir(d, x, y):
    return direction(d.x + x, d.y + y)

# -----------------------------------------------------------------------
# 메인 탐색 루프
# -----------------------------------------------------------------------

def start_program():
    global pos, startPos, checkpoint, openList, closedList, heading, gyroAngle

    if checkpoint["grid"] is None:
        pos = startPos = [0, 0]
        openList, closedList = [], [direction(0, 0)]
        heading = gyroAngle = 0
        yield from reset_turn()

        sides, wall = check_open_dir(0, 0, True)
        openList = [next_dir(heading, i) for i, ok in enumerate(sides) if ok]

        node = Node(0, 0, wall, None)
        grid = [[node]]
        dir = openList.pop()
        create_grid(grid_to_int(grid), direction(node.x, node.y), heading)
    else:
        node       = checkpoint["node"]
        dir        = checkpoint["dir"]
        grid       = checkpoint["grid"]
        openList   = checkpoint["openList"]
        closedList = checkpoint["closedList"]
        startPos   = checkpoint["startPos"]
        gyroAngle  = checkpoint["gyroAngle"]
        heading    = checkpoint["heading"]
        yield from reset_turn()

    while True:
        if dir not in (direction(0, -1), direction(0, 1), direction(-1, 0), direction(1, 0)):
            dir, node = yield from follow_next_dir(dir, node, grid)
        elif node.wall in (7, 11, 13, 14):
            one_exit = {7: direction(1, 0), 11: direction(-1, 0),
                        13: direction(0, 1), 14: direction(0, -1)}[node.wall]
            if dir != one_exit:
                dir, node = yield from follow_next_dir(dir, node, grid)

        yield from turn(look_dir(heading, dir))

        blocked = yield from drive(125, 305)
        if blocked == "black":
            # 구멍(검정 타일) → 그 칸엔 진입하지 않았으므로 새 노드를 만들지 않고,
            # 현재 노드의 해당 방향만 벽으로 기록해 다음 탐색에서 다시 시도하지 않게 한다.
            print("구멍 방향을 벽으로 기록:", dir)
            node.wall |= _DIR_WALL_BIT[dir]
            create_grid(grid_to_int(grid), direction(node.x, node.y), heading)

            if not openList:
                break

            dir = openList.pop()
            yield
            continue

        yield from align_front()   # 앞에 벽 있으면 전방 40mm로 맞춤
        yield from check_floor()

        yield from gsleep(1)

        node, grid, dx, dy = modify_grid(node, dir, grid)
        pos = node.pos()
        startPos[0] += dx
        startPos[1] += dy

        create_grid(grid_to_int(grid), direction(node.x, node.y), heading)

        if not openList:
            break

        dir = openList.pop()
        yield

    print("탐색 완료")
    fin_dir, _ = yield from follow_next_dir(
        direction(startPos[0] - node.x, startPos[1] - node.y), node, grid
    )
    # follow_next_dir 은 목표 직전 칸까지만 이동하므로(탐색 루프처럼 이후 turn+drive 필요),
    # 남은 방향(fin_dir)으로 마지막 한 칸을 마저 이동해 시작 타일에 실제로 진입한다.
    if fin_dir.x or fin_dir.y:
        yield from turn(look_dir(heading, fin_dir))
        yield from drive(125, 305, cam=False)
    print("시작 타일 복귀 → Exit Bonus 점멸(ON1s/OFF1s 10초)")
    yield from blink_exit()
    yield from blink_exit()

# -----------------------------------------------------------------------
# 엔트리포인트
# -----------------------------------------------------------------------

_touch_result = None


def _wait_touch():
    global _touch_result
    _touch_result = yield from wait_touch(hold_threshold=2000, detect_hold=True)


def main():
    try:
        # I2C 장치 응답 확인 — 0x22=BASEX, 0x38=FT6336, 0x69=BMI270
        print("scan:", _i2c.scan())

        # ToF 초기화 — PaHub I2C 컨트롤러 생성 후 센서 생성/start.
        # 읽기는 get_open_side/drive에서 그때그때 직접 한다(폴링 스레드 없음).
        global tof1, tof2, tof3, tof4, color, color_rev
        pahub.start()
        # 2점 보정: 각 센서를 25mm·150mm 벽에 대고 raw를 측정해 offset_25/offset_150에 채운다.
        # 미측정이면 기본값(25/150)이라 raw 그대로 나온다 → 측정 후 값만 바꾸면 자동 보정.
        tof1 = VL53L0X(pahub, channel=5, offset_25=56,  offset_150=190)  # 정면
        tof2 = VL53L0X(pahub, channel=4, offset_25=92,  offset_150=221)  # 우측
        tof3 = VL53L0X(pahub, channel=0, offset_25=120, offset_150=245)  # 좌측
        tof4 = VL53L0X(pahub, channel=1, offset_25=81,  offset_150=225)  # 후면
        tof1.start()
        tof2.start()
        tof3.start()
        tof4.start()
        # 바닥 컬러센서 — PaHub 같은 버스. 전진용(채널2, REF)/후진용(채널3, REF_REV).
        # 채널과 보정표 짝을 반드시 유지할 것(섞이면 오분류).
        color = ColorSensor(pahub, channel=COLOR_CH)
        color_rev = ColorSensor(pahub, channel=COLOR_CH_REV, ref=ColorSensor.REF_REV)
        print("init 완료")

        imu.reset_angle()

        # 콜드부팅 대응 — 첫 터치를 읽기 "직전"에 FT6336을 한 번 더 리셋한다.
        # Touch.__init__의 리셋 이후 pahub.start()/ToF init 과정에서 FT6336이 다시
        # 죽는 경우가 있어, 진단(touch_aw9523_test.py)에서 검증된 "읽기 직전 리셋" 순서를
        # 여기서 재현한다. reset_cores3_touch 내부에 부팅 대기(300ms)가 포함돼 있다.
        reset_cores3_touch(_i2c)

        # 첫 터치로 탐색 시작 — 화면 색으로 터치 상태 표시(시리얼 없이 눈으로 확인).
        #   준비(대기)=빨강, 터치 중=흰색, 터치 끝(시작)=검정
        while True:
            M5.Lcd.fillScreen(0xFF0000)
            _was = False
            while True:
                _t = touch.is_touching()
                if _t and not _was:
                    M5.Lcd.fillScreen(0xFFFFFF)  # 누르는 동안 흰색
                elif _was and not _t:
                    M5.Lcd.fillScreen(0x000000)  # 떼면 검정 → 탐색 시작
                    break
                _was = _t
                yield from gsleep(10)
            print("터치 감지 — 탐색 시작")

            # start_program 과 터치 감시를 제너레이터 협력으로 동시 구동.
            # 먼저 끝난 쪽 인덱스를 받는다(0=탐색 완료, 1=터치 중단). 나머지는 grace가 close.
            idx = grace(start_program(), _wait_touch(), tick=imu.update)

            if idx == 0:
                # 탐색 정상 완료
                break

            # 터치로 중단 — 결과에 따라 재시작 방식 결정
            result = _touch_result
            print("touch result:", result)

            if result == 2:  # 길게 누름: 저장 데이터 초기화 후 재시작
                checkpoint["grid"] = None
            # 짧게 누름(1): 체크포인트부터 재시작 — 루프 계속

            robot.stop(lock=False)

            while True:
                _t = touch.is_touching()
                if not _t:
                    break
                yield from gsleep(10)

            yield from gsleep(1000)

    except Exception as e:
        log_error(e, "fa_main")
        print("오류:", e)
    finally:
        robot.close()


try:
    grun(main(), tick=imu.update)
except KeyboardInterrupt:
    robot.stop(lock=False)
