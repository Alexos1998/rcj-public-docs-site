import _thread
import time
import M5
from machine import I2C, Pin

# 1. 하드웨어 초기화
i2c = I2C(0, scl=Pin(11), sda=Pin(12), freq=400000)

# 2. 쓰레드 간 공유할 '열쇠(Lock)' 생성
hw_lock = _thread.allocate_lock()

thread_stop = False

i2c.writeto_mem(0x22, 0x50, b'\00')
i2c.writeto_mem(0x22, 0x51, b'\01')

# 3. 쓰레드에서 실행될 함수
def i2c_thread_task(a):
    print("I2C 반복 테스트 시작", a)
    while True:
        with hw_lock:
            try:
                d = i2c.readfrom_mem(0x22, 0x50 + a-1, 1)
                print("Write Success", a, d)
            except Exception as e:
                print(f"Error: {e}")

        # 중요: 통신 후 하드웨어가 정리될 시간을 줘야 함
        # time.sleep_ms(1)
        if thread_stop:
            break
    print('stopped')


# 4. 쓰레드 실행
_thread.start_new_thread(i2c_thread_task, (1,))
_thread.start_new_thread(i2c_thread_task, (2,))

# 5. 메인 루프 (여기서도 I2C를 쓴다면 반드시 동일한 락을 써야 함)
try:
    while True:
        time.sleep(0.02)
except KeyboardInterrupt:
    thread_stop = True
    time.sleep_ms(1)

print("중단됨")