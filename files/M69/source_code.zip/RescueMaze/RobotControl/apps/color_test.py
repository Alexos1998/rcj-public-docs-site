"""
컬러센서(TCS3472, PaHub) 단독 테스트.

화면을 터치하면 1회 측정 → devices.ColorSensor 가 바닥 타일색을 분류하고
규정(3.2 Floor)상 의미를 화면/시리얼에 표시한다.
  - black  : HOLE       구멍 → 진입 금지
  - silver : CHECKPOINT 체크포인트
  - blue   : PUDDLE     웅덩이 → 진입 시 5초 정지
  - red    : DANGER     위험구역 입구
  - white  : NORMAL     일반 타일

기준점(REF)/분류 로직은 devices.ColorSensor 안에 있다.
재보정은 apps/color_cal.py 실행 → 출력된 REF 표를 devices.py 에 붙여넣기.
"""

import time
import M5
M5.begin()
time.sleep_ms(500)   # 콜드부팅 settle — 터치 init 끝난 뒤 버스 잡기

from machine import I2C, Pin
from devices import PaHub, ColorSensor, Touch

COLOR_CH = 2   # 컬러센서가 꽂힌 PaHub 채널 (ToF가 0/1/4/5 사용 → 남는 채널로)

# 분류 결과 → 화면 표시색(RGB888)
TILE_RGB = {
    "black": 0x202020, "silver": 0xC0C0C0, "blue": 0x0000FF,
    "red": 0xFF0000, "white": 0xFFFFFF,
}


def show(color):
    # 글자 없이 색상으로만 표기 — 화면 전체를 타일색으로 채운다.
    M5.Lcd.fillScreen(color)


def blue_stop(touch):
    # 규정: 파랑(웅덩이) 진입 시 다음 타일 가기 전 5초 정지.
    # 글자 대신 파랑/검정 깜빡임으로 정지 중임을 색으로만 표시.
    for s in range(5, 0, -1):
        show(0x0000FF if s % 2 else 0x000000)
        end = time.ticks_add(time.ticks_ms(), 1000)
        while time.ticks_diff(end, time.ticks_ms()) > 0:
            time.sleep_ms(10)


def main():
    # 메인 버스(id=0) — 터치 패널. 컬러센서 PaHub(id=1)와 버스가 달라 충돌 없음.
    _i2c = I2C(0, scl=Pin(11), sda=Pin(12), freq=800000)
    touch = Touch(_i2c)

    pahub = PaHub(sda=2, scl=1)
    pahub.start()
    sensor = ColorSensor(pahub, channel=COLOR_CH)
    print("컬러센서 준비 완료 — 화면을 터치하면 한 번 읽는다")
    M5.Lcd.fillScreen(0x00FF00)   # 준비 완료 신호 = 초록 (이제 터치 가능)

    while True:
        # 눌림 대기
        while not touch.is_touching():
            time.sleep_ms(10)

        # 눌림 확정 → 1회 측정 + 분류
        w, r, g, b = sensor.get()
        name = sensor.classify((w, r, g, b))
        meaning = sensor.MEANING.get(name, "?")
        print("w=%5d r=%5d g=%5d b=%5d | %-6s | %s" % (w, r, g, b, name, meaning))

        # 규정상 의미를 화면에 색상으로만 표시 (글자 없음)
        show(TILE_RGB[name])

        # 규정 동작 — 파랑이면 5초 정지 시뮬레이션
        if name == "blue":
            blue_stop(touch)

        # 손 뗄 때까지 대기 — 떼기 전엔 재측정 안 함(연속 트리거 방지)
        while touch.is_touching():
            time.sleep_ms(10)
        M5.Lcd.fillScreen(0x00FF00)   # 다시 준비 완료(초록)


if __name__ == "__main__":
    main()
