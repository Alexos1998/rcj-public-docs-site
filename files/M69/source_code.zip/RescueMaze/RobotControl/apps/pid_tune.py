"""
PID 튜닝 하네스 — main.py의 모터/직진/회전 PID를 한 파일에서 잡는다.

값은 전부 main.py에서 가져온 현재 동작점이며, REPL/WebREPL에서 파라미터를
바꿔가며 테스트해 수치로 맞춘다. 각 테스트는 목표 대비 실제값/편차를 출력한다.

실행:
    이 파일을 그대로 실행(업로드 후 run)하면 터치로 반복 테스트가 돈다.
        터치 짧게 = 직진 / 길게 = 회전
    각 테스트는 목표 대비 실제값/편차를 출력한다.

튜닝:
    아래 STRAIGHT / TURN / MOTOR_SPD_PID / MOTOR_POS_PID / ODO_STRAIGHT_GAIN
    값을 수정하고 다시 실행해 수치로 맞춘다.
    (REPL에서 import 해 set_spd_pid()/set_pos_pid()로 모터 PID 즉시 반영도 가능)
"""

import time
import uasyncio as asyncio
from machine import Pin

# UIFlow 런처(framework.run) 이벤트 루프 분리 — main.py와 동일 이유.
# 같은 단일 루프를 공유하면 await마다 런처 while이 재개돼 터치/버튼 충돌이 난다.
asyncio.new_event_loop()

from devices import I2CBus, IMU, Touch
from basex import DriveBase
from utils import *

# -----------------------------------------------------------------------
# 하드웨어 초기화 (main.py와 동일 구성)
# -----------------------------------------------------------------------
bus   = I2CBus(0, scl=Pin(11), sda=Pin(12), freq=1000000)
imu   = IMU(bus, gyro_deadzone=0.7)
robot = DriveBase(
    bus,
    right_motors=[2, 3], left_motors=[1, 4],
    wheel_diameter=62.4, axle_track=112,
    right_counter=True, gear=[12, 28]
)
touch = Touch(bus)

# -----------------------------------------------------------------------
# 튜닝 대상 파라미터 — REPL에서 바로 수정해 다시 테스트
# (초기값은 main.py의 현재 동작점)
# -----------------------------------------------------------------------

# 직진 PID (pid_control): drive() 중 헤딩 유지
STRAIGHT = {'kp': 1.8, 'kd': 3.6, 'gain': 6.0}

# 회전 PID (pid_turn_control): turn() 중 목표각 도달
#   gain = base + ratio_coef * ratio**2   (ratio: 남은각 비율 1→0)
TURN = {'kp': 17.2, 'kd': 15.0, 'base': 0.15, 'ratio_coef': 0.30}

# 모터 PID (보드 내부) — 즉시 반영하려면 set_spd_pid / set_pos_pid 사용
MOTOR_SPD_PID = (22, 2, 26)   # 속도 모드 PID (robot.drive 가 쓰는 모드)
MOTOR_POS_PID = (12, 1, 22)   # 위치 모드 PID (DriveBase.straight 등)

# A: 오도메트리 직진 보정 (deg당 조향량, 0이면 비활성) — 직진 PID와 함께 검증
ODO_STRAIGHT_GAIN = 2.0

# 테스트 기본값 (main.py 기준)
STRAIGHT_MM  = 320
STRAIGHT_SPD = 500
TURN_DEG     = 90
TURN_MS      = 1700

# -----------------------------------------------------------------------
# PID 상태
# -----------------------------------------------------------------------
lastYaw     = 0
lastTurnYaw = 0
gyroAngle   = 0


def odo_yaw():
    # 좌우 바퀴 주행차로 추정한 헤딩 변화(deg). 자이로와 독립.
    l = (robot.current_encoder[robot.left_ports[0] - 1] - robot.left_ref) * robot.l_counter
    r = (robot.current_encoder[robot.right_ports[0] - 1] - robot.right_ref) * robot.r_counter
    return (r - l) * robot._deg_to_mm / robot.axle_track * 57.29577951308232


def pid_control(speed):
    global lastYaw
    s = STRAIGHT
    yaw = -(imu.angle() - gyroAngle)
    diff = yaw - lastYaw
    lastYaw = yaw
    robot.drive(speed, (s['kp'] * yaw + s['kd'] * diff) * s['gain'] - ODO_STRAIGHT_GAIN * odo_yaw())


def pid_turn_control(dest, ratio):
    global lastTurnYaw
    t = TURN
    yaw  = dest - (imu.angle() - gyroAngle)
    diff = yaw - lastTurnYaw
    lastTurnYaw = yaw
    gain = t['base'] + t['ratio_coef'] * ratio ** 2
    robot.drive(0, (t['kp'] * yaw + t['kd'] * diff) * gain)

# -----------------------------------------------------------------------
# 모터 PID 적용
# -----------------------------------------------------------------------
def set_spd_pid(p, i, d):
    global MOTOR_SPD_PID
    MOTOR_SPD_PID = (p, i, d)
    for m in robot.all_ports:
        robot.set_motor_pid(m, p, i, d)
    print("speed PID =", MOTOR_SPD_PID)

def set_pos_pid(p, i, d):
    global MOTOR_POS_PID
    MOTOR_POS_PID = (p, i, d)
    for m in robot.all_ports:
        robot.set_position_pid(m, p, i, d)
    print("position PID =", MOTOR_POS_PID)

def apply_motor_pid():
    for m in robot.all_ports:
        robot.set_motor_pid(m, *MOTOR_SPD_PID)
        robot.set_position_pid(m, *MOTOR_POS_PID)

# -----------------------------------------------------------------------
# 테스트 루틴 (지표 출력)
# -----------------------------------------------------------------------
async def _straight(mm, speed):
    global lastYaw
    robot.drive_init()
    await asyncio.sleep_ms(20)
    robot.reset()
    lastYaw = 0
    max_dev = 0.0
    start = time.ticks_ms()

    while True:
        dist = abs(robot.distance())
        if dist > mm:
            break
        ratio = dist / mm
        pid_control(speed * (1 - ratio * 0.5))
        dev = abs(imu.angle() - gyroAngle)
        if dev > max_dev:
            max_dev = dev
        await asyncio.sleep_ms(0)

    robot.brake()
    elapsed = time.ticks_diff(time.ticks_ms(), start)
    print("── 직진 결과 ─────────────")
    print(" 목표 %dmm | 실제 %.1fmm" % (mm, abs(robot.distance())))
    print(" 헤딩 최대편차 %.2f° | 최종 %.2f°" % (max_dev, imu.angle() - gyroAngle))
    print(" 오도메트리(독립) %.2f°" % odo_yaw())
    print(" 소요 %dms | STRAIGHT=%s ODO=%.1f" % (elapsed, STRAIGHT, ODO_STRAIGHT_GAIN))
    robot.reset()


async def _spin(deg, duration):
    global gyroAngle, lastTurnYaw
    robot.drive_init()
    robot.brake()
    lastTurnYaw = 0
    g0 = gyroAngle          # 이번 회전 시작 기준
    max_over = 0.0
    i = 0
    start = time.ticks_ms()

    while time.ticks_diff(time.ticks_ms(), start) < duration:
        rel = imu.angle() - gyroAngle           # 시작 대비 현재 회전량
        remaining = deg - rel
        ratio = min(1.0, abs(remaining) / abs(deg))
        pid_turn_control(deg, ratio)
        over = (rel - deg) if deg > 0 else (deg - rel)   # 목표 초과량
        if over > max_over:
            max_over = over
        if abs(remaining) < 0.5 and i == 0:
            start = time.ticks_ms()             # 도착 후 정착(settle) 시간 재기
            i = 1
        await asyncio.sleep_ms(0)

    robot.brake()
    actual = imu.angle() - g0
    gyroAngle += deg
    print("── 회전 결과 ─────────────")
    print(" 목표 %.1f° | 실제 %.1f° | 오차 %.2f°" % (deg, actual, deg - actual))
    print(" 오버슈트 %.2f° | TURN=%s" % (max_over, TURN))
    await wait(100)

# -----------------------------------------------------------------------
# REPL 단발 실행용 래퍼 (선택) — import 해서 straight()/spin() 직접 호출
# -----------------------------------------------------------------------
def straight(mm=None, speed=None):
    asyncio.run(_straight(STRAIGHT_MM if mm is None else mm,
                          STRAIGHT_SPD if speed is None else speed))

def spin(deg=None, duration=None):
    asyncio.run(_spin(TURN_DEG if deg is None else deg,
                      TURN_MS if duration is None else duration))

# -----------------------------------------------------------------------
# 엔트리포인트 — 실행하면 터치로 반복 테스트 (짧게=직진 / 길게=회전)
#   PID 값은 위 STRAIGHT / TURN / MOTOR_*_PID / ODO_STRAIGHT_GAIN 를
#   수정하고 다시 실행해 맞춘다. 각 테스트가 목표 대비 편차를 출력.
# -----------------------------------------------------------------------
async def main():
    try:
        bus.start()
        apply_motor_pid()
        imu.reset_angle()
        print("PID 튜너 준비 — 터치: 짧게=직진 / 길게=회전")
        print(" 직진PID STRAIGHT=%s ODO=%.1f" % (STRAIGHT, ODO_STRAIGHT_GAIN))
        print(" 회전PID TURN=%s" % TURN)
        print(" 모터PID 속도=%s 위치=%s" % (MOTOR_SPD_PID, MOTOR_POS_PID))

        await touch.wait_for_touch(detect_hold=False)   # 첫 터치로 시작

        while True:
            r = await touch.wait_for_touch(hold_threshold=1000, detect_hold=True)
            if r == 1:
                await _straight(STRAIGHT_MM, STRAIGHT_SPD)
            elif r == 2:
                await _spin(TURN_DEG, TURN_MS)
            await asyncio.sleep_ms(10)
    finally:
        robot.close()
        bus.close()


try:
    asyncio.run(main())
except Exception as e:
    print("오류:", e)
finally:
    robot.close()
    bus.close()
