"""
컬러센서(TCS3472) 보정 프로그램 — 전진용/후진용 센서 2개를 동시에 보정한다.

두 센서가 같은 로봇에 달려 있어 한 타일 위에서 둘 다 동시에 읽히므로, 색상당
터치 1번으로 두 센서를 함께 샘플링한다(총 5번 터치).
devices.ColorSensor.REF(전진, 채널2) / REF_REV(후진, 채널3) 에 붙여넣을
(name, w, r, g, b) 줄을 센서별로 출력한다.
순서: black -> blue -> red -> white -> silver.

⚠ 보정 중 센서 높이/조명을 실전과 동일하게 유지할 것 — raw 절대값이
   흔들리면(특히 white/silver) 분류가 틀어진다.
"""

import time
import M5
M5.begin()
time.sleep_ms(500)   # 콜드부팅 settle

from machine import I2C, Pin
from devices import PaHub, ColorSensor, Touch

# (센서 이름, PaHub 채널, devices.py에 붙여넣을 변수명)
SENSORS = [
    ("전진(FWD)", 2, "REF"),
    ("후진(REV)", 3, "REF_REV"),
]
N = 30   # 평균 샘플 수

# (이름, 화면 힌트색 RGB888) — 보정 순서
TARGETS = [
    ("black",  0x202020),
    ("blue",   0x0000FF),
    ("red",    0xFF0000),
    ("white",  0xFFFFFF),
    ("silver", 0xC0C0C0),
]


def show(text, color, text_color=0x000000):
    M5.Lcd.fillScreen(color)
    try:
        M5.Lcd.setCursor(10, 100)
        M5.Lcd.setTextColor(text_color)
        M5.Lcd.setTextSize(4)
        M5.Lcd.print(text)
    except Exception:
        pass


def wait_press(touch):
    while not touch.is_touching():
        time.sleep_ms(10)


def wait_release(touch):
    while touch.is_touching():
        time.sleep_ms(10)


def sample_avg(sensor, n):
    sw = sr = sg = sb = 0
    for _ in range(n):
        w, r, g, b = sensor.get()
        sw += w; sr += r; sg += g; sb += b
        time.sleep_ms(10)
    return sw // n, sr // n, sg // n, sb // n


def main():
    # 메인 버스(id=0)=터치. 컬러센서 PaHub(id=1)와 버스가 달라 충돌 없음.
    _i2c = I2C(0, scl=Pin(11), sda=Pin(12), freq=800000)
    touch = Touch(_i2c)

    pahub = PaHub(sda=2, scl=1)
    pahub.start()
    sensors = [(label, ref_name, ColorSensor(pahub, channel=ch)) for label, ch, ref_name in SENSORS]

    print("보정 시작 — 화면 안내색 타일에 두 센서를 함께 대고 터치 (색상당 1회)")
    results = {ref_name: [] for _, _, ref_name in SENSORS}

    for name, hint in TARGETS:
        show(name, hint, 0xFFFFFF if name in ("black", "blue", "red") else 0x000000)
        print(">>> '%s' 타일에 두 센서를 대고 화면 터치" % name)
        wait_press(touch)

        for label, ref_name, sensor in sensors:
            w, r, g, b = sample_avg(sensor, N)
            print('    [%s] ("%s", %4d, %4d, %4d, %4d),' % (label, name, w, r, g, b))
            results[ref_name].append((name, w, r, g, b))

        show("OK", 0x00FF00)
        wait_release(touch)
        time.sleep(1)

    # 센서별 REF 출력 (devices.py 에 붙여넣기)
    for label, ref_name, _ in sensors:
        print("")
        print("    %s = [" % ref_name)
        print("        #  name      w    r    g    b")
        for name, w, r, g, b in results[ref_name]:
            print('        ("%s", %4d, %4d, %4d, %4d),' % (name, w, r, g, b))
        print("    ]")

    show("DONE", 0x00FF00)


if __name__ == "__main__":
    main()
