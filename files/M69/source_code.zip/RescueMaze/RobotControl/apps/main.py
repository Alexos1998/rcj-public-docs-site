"""
fixed_main 기반 + 실제 ToF 벽감지 버전.
fixed_main(잘 동작하는 베이스)에서 딱 세 군데만 바꿈:
  1) PaHub + VL53L0X 4개 하드웨어 추가
  2) get_open_side: dg 배열 조회 → 실제 ToF 읽기
  3) drive(): 전방 ToF 긴급정지 추가
turn/탐색/main 구조는 fixed_main과 동일.
"""


import time
from machine import I2C, Pin

import M5
M5.begin()  # I2C 초기화 전에 가장 먼저 실행
# 콜드(하드)부팅 settle — M5.begin()이 시작한 FT6336 터치 init/reset 해제가 끝나기 전에
# 아래에서 I2C(0)를 재생성하면 그 init 트랜잭션이 중간에 끊겨 터치가 죽는다(콜드부팅만
# 실패, 소프트리셋은 이전 부팅 init이 남아 정상). 충분히 기다린 뒤 버스를 잡는다.
time.sleep_ms(500)
from basex import DriveBase
from VL53L0X import VL53L0X
from devices import PaHub, IMU, Touch, reset_cores3_touch, ColorSensor
from dropper import Dropper
from astar.grid import *
from astar.Astar import get_directions
from astar.visualize import create_grid
from logger import log_error, init_logging
from utils import *
init_logging()


# -----------------------------------------------------------------------
# 제너레이터 협력 스케줄러 (asyncio 대체)
# 제약: ① 두 스레드가 I2C → 259  ② async 함수 안에서 I2C → 에러  ③ 락은 핫루프에 느림.
# → 스레드/asyncio를 모두 없애고 순수 제너레이터(yield) 협력 멀티태스킹으로 돌린다.
#   모든 I2C는 이 단일 루프 컨텍스트에서 각 호출이 직접(machine.I2C로) 수행 — 동시
#   접근이 구조적으로 불가능. uasyncio의 숨은 타이머/스케줄러 훅도 없어 통제가 명확하다.
# 변환 규칙: async def→def, yield→yield,
#   await asyncio.sleep_ms(n)→yield from gsleep(n), await f()→yield from f().
# -----------------------------------------------------------------------

def gsleep(ms):
    # ms가 0 이하이면 대기 시간 없이 단 한 번만 다른 제너레이터에게 순서를 양보한다.
    if ms <= 0:
        yield
        return

    end = time.ticks_add(time.ticks_ms(), ms)
    while time.ticks_diff(end, time.ticks_ms()) > 0:
        yield


def grun(gen):
    # 제너레이터 하나를 끝까지 구동한다 (최상위 엔트리용).
    # 매 틱 imu.update()로 자이로 적분을 직접 갱신한다(연속 샘플링 필요한 유일한 항목).
    # 모터/엔코더/터치/ToF는 각 호출 지점이 그때그때 직접 I2C에 접근한다.
    while True:
        imu.update()
        try:
            next(gen)
        except StopIteration:
            break


def grace(*gens):
    # 여러 제너레이터를 라운드로빈으로 돌리다 하나라도 끝나면 그 인덱스를 반환하고
    # 나머지는 close()로 중단한다. asyncio.create_task + done 폴링을 대체.
    # 여기서도 매 틱 imu.update()로 자이로 적분을 펌프한다(메인 루프 단일 컨텍스트).
    gens = list(gens)
    while True:
        imu.update()
        for i, g in enumerate(gens):
            try:
                next(g)
            except StopIteration:
                for j, other in enumerate(gens):
                    if j != i:
                        other.close()
                return i


def wait_touch(hold_threshold=300, detect_hold=True, debug=False):
    # devices.Touch.wait_for_touch의 제너레이터 판 — is_touching()(캐시, I2C 아님)만 본다.
    press_time = 0
    was_touching = False
    while True:
        touching = touch.is_touching()
        now = time.ticks_ms()
        if not was_touching and touching:
            press_time = now
        if was_touching and not touching:
            if detect_hold:
                if time.ticks_diff(now, press_time) >= hold_threshold:
                    return 2
                else:
                    return 1
            else:
                return True
        was_touching = touching
        yield


def blink_victim(rgb):
    # 규정 5.6.1: victim 성공 식별 조건 — 15cm 이내 정지 상태에서 전용 표시(LED/Display)를
    # ON 500ms / OFF 500ms 간격으로 5초간(=5회) 점멸해야 한다. 정적 표시는 인정되지 않는다.
    for _ in range(5):
        M5.Lcd.fillScreen(rgb)
        yield from gsleep(500)
        M5.Lcd.fillScreen(0x000000)
        yield from gsleep(500)


def blink_exit():
    # 규정 5.6.12 Exit Bonus: 시작 타일 복귀 시 victim 식별과 같은 표시로 ON 1s / OFF 1s
    # 간격으로 최소 10초간(=10회) 점멸해 종료 신호를 낸다.
    for _ in range(10):
        M5.Lcd.fillScreen(0xFFFFFF)
        yield from gsleep(1000)
        M5.Lcd.fillScreen(0x000000)
        yield from gsleep(1000)


# -----------------------------------------------------------------------
# 하드웨어 초기화
# -----------------------------------------------------------------------

# 메인 버스(하드웨어 I2C id=0). IMU·DriveBase·Touch가 이 i2c 객체를 직접 공유한다.
# 콜드부팅 터치 실패의 진짜 원인은 I2C 인스턴스 충돌이 아니라 FT6336 RST(AW9523 P0 bit0)가
# 안 풀린 것 → Touch.__init__의 reset_cores3_touch()가 AW9523로 직접 리셋을 풀어 해결한다.
# (이전의 I2C(0) 이중생성 트릭은 헛다리였으므로 제거하고 버스를 한 번만 만든다.)
_i2c = I2C(0, scl=Pin(11), sda=Pin(12), freq=800000)

# Touch 를 가장 먼저 생성한다 — __init__의 reset_cores3_touch()가 콜드부팅에서 죽어 있는
# FT6336 RST(AW9523 P0 bit0)를 풀어 깨운다. IMU/DriveBase init 트래픽보다 앞서 깨워야
# 진단(touch_aw9523_test.py)에서 검증된 "I2C 생성 → 곧바로 리셋" 순서와 일치한다.
touch = Touch(_i2c)                        # 터치 패널 (FT6336)
imu   = IMU(_i2c, gyro_deadzone=0.9)       # 자이로 데드존 0.7도: 미세 노이즈 무시
robot = DriveBase(
    _i2c,
    right_motors=[2, 3], left_motors=[1, 4],
    wheel_diameter=62.4,   # 바퀴 직경 (mm)
    axle_track=112,        # 좌우 바퀴 간격 (mm)
    right_counter=True,    # 우측 모터 엔코더 방향 반전
    gear=[12, 28]          # 기어비: 구동 12T → 피동 28T
)

# UnitV2 2대 → 서보 투하 장치.
#   왼쪽 = Port C(UART2, RX=G17/TX=G18),  오른쪽 = Port B(UART1, G8/G9).
#   문자 수신 시 해당 방향(서보1: 중립 90° → 왼쪽 20°/오른쪽 160°)으로 투하 후 복귀.
#   좌/우 적재량은 left_count/right_count(기본 5/5). 투하는 drive 함수에 귀속(start/poll/drop).
#   ※ 카메라 좌/우가 바뀌어 있으면 left_uart/right_uart 를 서로 바꾼다.
dropper = Dropper(robot, servo=1, neutral=90,
                  left_angle=20, right_angle=160,
                  left_count=5, right_count=5, drop_hold_ms=500)

# ToF 4개 (PaHub 하드웨어 I2C id=1 너머). 포트: 앞5 오4 뒷1 왼0.
# 실제 i2c 초기화/센서 생성/start는 main()에서 수행한다.
pahub = PaHub(sda=2, scl=1)
tof1 = tof2 = tof3 = tof4 = None

# 바닥 컬러센서 (TCS3472, 같은 PaHub 채널 2). ToF가 0/1/4/5 → 남는 2번.
# 실제 생성은 main()에서 pahub.start() 뒤에 한다.
COLOR_CH = 2       # 컬러센서(전진 방향) — is_reversed=False일 때 사용
COLOR_CH_REV = 3   # 컬러센서(후진 방향) — is_reversed=True일 때 사용
color = None
color_rev = None

# 분류 결과 → LCD 표시색(RGB888). 글자 없이 색으로만 표기한다.
TILE_RGB = {
    "black": 0x202020, "silver": 0xC0C0C0, "blue": 0x0000FF,
    "red": 0xFF0000, "white": 0xFFFFFF,
}

# 피해자(victim) 종류별 화면 표시색 — 식별 시 규정상 5초 시각신호로 표시.
VICTIM_RGB = {0: 0x00FF00, 1: 0xFFFF00, 2: 0xFF0000}  # 0=Unharmed(초록) 1=Stable(노랑) 2=Harmed(빨강)

WALL_MM = 105  # 벽으로 판정하는 거리 임계값 (mm)
STOP_MM = 35  # 주행 중 충돌 방지 긴급 정지 임계값 (mm)
DROP_WALL_MARGIN = 30  # 투하 판정: 해당 방향 ToF > WALL_MM+이 값이면 벽 없음(오검출)으로 보고 재무장

# 후방 벽정렬(회전 직후 재앵커링)
ALIGN_BACK_MM = 35     # 이 거리(mm)까지 후진해 평평한 벽에 밀착
ALIGN_TIMEOUT = 2000   # 후진 정렬 타임아웃 (ms)
ALIGN_PUSH_MS = 600    # 밀착 후 추가로 미는 시간(ms) — 양측 동일 출력으로 스퀘어 맞춤
ALIGN_FRONT_MM = 40    # 전방 벽 정렬 목표 거리(mm) — 전방 ToF가 이 값이 되도록 straight 보정
ALIGN_SPEED = 75       # 후방 벽정렬 주행속도 — 일반 주행(150)보다 낮춰 충돌/오버슈트 완화
ALIGN_FRONT_SPEED = 60 # 전방 벽정렬 주행속도 — 근거리 정밀 보정이라 더 낮게

# -----------------------------------------------------------------------
# 상수 / 타입 정의
# -----------------------------------------------------------------------

# 셀의 4방향 통행 가능 여부를 담는 네임드튜플
azimuth = namedtuple('azimuth', ['n', 's', 'w', 'e'])

_DIRS = [direction(0,-1), direction(1,0), direction(0,1), direction(-1,0)]  # N E S W

def look_dir(h, d):
    # 현재 heading h 에서 방향벡터 d 를 향하기 위해 회전해야 할 각도
    return [0, -90, 180, 90][(_DIRS.index(d) - h) % 4]

def next_dir(h, i):
    # h=현재heading, i: 0=좌 1=전 2=우
    return _DIRS[(h + i - 1) % 4]

# -----------------------------------------------------------------------
# 전역 상태
# -----------------------------------------------------------------------

lastYaw     = 0   # 직진 PID 이전 프레임 편차 (미분항 계산용)
lastTurnYaw = 0   # 회전 PID 이전 프레임 편차
yawIntegral = 0   # 직진 PID 적분항 — 모터 출력 불균형 등 일정한 외란에 의한 정상상태
                   # 편향(한쪽으로 계속 치우침)은 P(D)만으로는 못 없앤다. drive() 시작 시 리셋.
gyroAngle   = 0   # 누적 목표 각도 (회전할 때마다 갱신)
heading     = 0   # 로봇의 논리적 진행 방향 (0=N 1=E 2=S 3=W)

# 전후면 반전 플래그.
# True 이면 후면이 진행 방향 — 실제 180도 회전 대신 모터 방향만 반전한다.
# 이후 상태는 180도 턴에서의 토글(not is_reversed)로만 바뀌므로, 이 초기값만으로
# 탐색 시작 시 정면/후면 중 어느 쪽으로 진행할지가 결정된다 — 시작은 정면 진행(False).
is_reversed = False

pos      = [0, 0]   # 현재 그리드 좌표 (절대)
startPos = [0, 0]   # 시작 셀의 그리드 좌표 (그리드 확장 시 함께 갱신)

openList   = []                    # 아직 방문하지 않은 이웃 방향 스택
closedList = [direction(0, 0)]     # 이미 방문한 셀 좌표 목록

# 프로그램 재시작 시 이전 상태를 복원하기 위한 체크포인트
checkpoint = {
    "grid": None,       # 탐색 그리드
    "node": None,       # 마지막 노드
    "dir": None,        # 다음 이동 방향
    "openList": None,
    "closedList": None,
    "startPos": None,
    "gyroAngle": None,
    "heading": None,
}

# -----------------------------------------------------------------------
# PID 제어
# -----------------------------------------------------------------------

# A: 오도메트리 직진 보정 가중치 (deg당 조향량). 0이면 비활성. 실측 튜닝 필요.
ODO_STRAIGHT_GAIN = 2.0

# 직진 기준속도 — 감속(파워 ↓) 시 조향을 곡률 일정하게 비례 축소(steering ∝ speed)하는 분모.
# drive()의 순항 속도(=150)와 맞춘다. speed가 이 값 미만이면 robot.drive()가 조향을
# speed/REF 로 줄여 저속에서 κ=steering/speed 폭주(좌우 흔들림)를 막는다.
# 턴(pid_turn_control, speed=0)에는 fade_below 를 넘기지 않으므로 영향 없음 → 자이로 그대로 회전.
STRAIGHT_REF_SPEED = 125
DRV_DEC_SPEED = 0.4
FINAL_APPROACH_MM = 60   # 목표 지점까지 이 거리(mm) 이내면 떨림방지 감속 하한(0.6)을 무시
                          # 30mm였을 때도 40mm 밀림 — 순항속도(150)에서 실제로 감속할 물리적
                          # 거리가 부족했던 것으로 보여 구간을 넓힘.
FINAL_MIN_FACTOR = 0.2   # 근접 구간 최저 속도비 — brake() 관성 오버슛 억제가 떨림보다 우선

# 내리막 처리 — 무게중심 문제로 빠르게 내려오면 모서리에서 앞으로 굴러떨어진다.
# 단순 감속은 150 관성이 이미 붙어 늦으므로, pitch 감지 시 일단 정지→원위치 후진→저속
# 재진입으로 "관성 없이 저속으로 모서리 진입"(=떨어지지 않던) 조건을 재현한다.
DOWNHILL_PITCH = 5.0      # 내리막 판정 임계(도) — 실측으로 조정: 2cm 턱은 gx 적분이 상쇄, 램프는 큰 spike 유지
DOWNHILL_SPEED = 75        # 내리막 저속(후진 재진입 후 통과 속도) — 실측으로 안 떨어지던 값
BACKOFF_TOL_MM = 3         # 후진(이 drive 출발점으로 복귀) 정지 허용오차(mm)
DOWNHILL_WARMUP_MM = 25    # 출발 직후 이 거리까지 감지 보류 + pitch0 추종 — 출발 가속 노이즈 오트리거 방지

def odo_yaw():
    # 좌우 바퀴 주행차로 추정한 헤딩 변화(deg). 자이로와 독립 → 자기간섭/적분 드리프트 면역.
    # robot.reset()(=drive 시작) 기준이라 직진 중엔 0이어야 정상. 양수=CCW(좌)로 틀어짐.
    l = (robot.current_encoder[robot.left_ports[0] - 1] - robot.left_ref) * robot.l_counter
    r = (robot.current_encoder[robot.right_ports[0] - 1] - robot.right_ref) * robot.r_counter
    return (r - l) * robot._deg_to_mm / robot.axle_track * 57.29577951308232


YAW_KI = 0.15          # 적분 게인 — 작게 시작해 정상상태 편향만 서서히 상쇄
YAW_I_CLAMP = 8.0       # 적분 누적 상한(deg) — 와인드업(정지/급커브 후 과잉반응) 방지

def pid_control(speed, gain, kp, kd, odo_scale=1.0):
    global lastYaw, yawIntegral
    yaw = -(imu.angle() - gyroAngle)
    diff = yaw - lastYaw
    lastYaw = yaw
    yawIntegral = max(-YAW_I_CLAMP, min(YAW_I_CLAMP, yawIntegral + yaw))
    # 엔코더 양자화 노이즈가 조향으로 반사돼 limit cycle을 만들지 않게 소량 불감대.
    odo = odo_yaw()
    if abs(odo) < 0.3:
        odo = 0
    # A: 자이로 PID + 오도메트리 직진 보정(독립 신호). odo_yaw>0(좌로 드리프트)면 우로 보정.
    # 감속 시 조향을 speed 에 비례 축소(곡률 일정)해 정지 직전 좌우 흔들림 제거.
    # I항: 모터 출력 불균형 등 일정한 외란으로 인한 한쪽 쏠림(정상상태 오차)을 상쇄.
    robot.drive(speed, (kp * yaw + kd * diff + YAW_KI * yawIntegral) * gain - ODO_STRAIGHT_GAIN * odo_scale * odo)


def pid_turn_control(dest, gain, kp, kd):
    global lastTurnYaw
    yaw  = dest - (imu.angle() - gyroAngle)
    diff = yaw - lastTurnYaw
    lastTurnYaw = yaw
    robot.drive(0, (kp * yaw + kd * diff) * gain)


def reset_turn():
    print("reset_turn 시작 angle=%.1f" % imu.angle())
    start = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), start) < 5000:
        if abs(imu.angle() - gyroAngle) < 0.1:
            break
        pid_turn_control(gyroAngle, 0.26, 17.2, 4)
        yield
    robot.brake()
    print("reset_turn 완료 angle=%.1f" % imu.angle())


def read_tof(sensor, retries=5):
    # ToF 단발 읽기 + -1(무효) 처리 — -1이면 최대 retries회 재시도, 끝까지 -1이면 -1 반환.
    for _ in range(retries):
        v = sensor.get()
        if v != -1:
            return v
    return -1


def align_back(rev):
    # 회전 직후 후방에 벽이 있으면 그 벽에 평평히 붙여 자세/헤딩을 재앵커링한다.
    # 센서가 면당 1개뿐이라 각도 측정은 못 한다 → 평평한 벽에 양측 동일 출력(조향 0)으로
    # 밀어붙여 섀시를 기계적으로 스퀘어시킨 뒤, imu 각을 목표(gyroAngle)에 맞춰 적분 드리프트 제거.
    global lastYaw

    # 진행 전방의 반대편이 후방 센서 (drive의 front: not reversed=tof4 / reversed=tof1).
    rear = tof1 if is_reversed else tof4
    if rear is None:
        yield from robot.straight(ALIGN_SPEED, 20 * rev)
        return

    d = read_tof(rear)
    if d == -1 or d > WALL_MM:   # 무효(-1) 또는 후방에 벽 없음 → 정렬 생략
        print("후방 벽 없음/무효 → 정렬 생략", d)
        return
    print("후방 벽 정렬 시작", d)

    # 후방으로 천천히 후진해 벽에 붙인다 (모터 부호는 전진의 반대 = -rev). 후진량은 distance로 측정.
    rev = -1 if not is_reversed else 1
    robot.reset()
    start = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), start) < ALIGN_TIMEOUT:
        rv = rear.get()
        if 0 <= rv <= ALIGN_BACK_MM:   # -1(무효)은 무시, 정상 근접일 때만 종료
            break
        robot.drive(-ALIGN_SPEED * rev, 0)
        yield from gsleep(1)

    # 평평히 밀착되도록 잠깐 더 민다 — 양측 동일 출력이라 벽 반력으로 스퀘어가 맞춰진다.
    push = time.ticks_add(time.ticks_ms(), ALIGN_PUSH_MS)
    while time.ticks_diff(push, time.ticks_ms()) > 0:
        robot.drive(-ALIGN_SPEED * rev, 0)
        yield from gsleep(1)
    robot.brake()

    # 후진한 거리 (straight가 내부에서 reset 하므로 전진 전에 읽어둔다).
    back_dist = abs(robot.distance())

    # 재앵커링 — 물리적으로 그리드 축에 정렬됐으므로 imu 각을 목표(gyroAngle)로 맞춘다.
    imu.set_angle(gyroAngle)
    lastYaw = 0

    # 후진한 만큼 다시 전진해 셀 중앙으로 복귀.
    yield from robot.straight(ALIGN_SPEED, back_dist * rev)
    robot.brake()
    print("후방 벽 정렬 완료, 복귀 %.0fmm angle=%.1f" % (back_dist, imu.angle()))


def align_front():
    # 진행 방향 앞에 벽이 있으면 전방 ToF를 그 거리가 ALIGN_FRONT_MM(40mm)이
    # 되도록 straight로 보정한다. (벽 없으면 생략)
    front = tof4 if is_reversed else tof1   # drive의 전방 센서와 동일
    if front is None:
        return
    # 단발 읽기는 크로스토크/반사로 실제 벽 없는 곳에서도 순간적으로 짧게 튀어 오검출을
    # 일으킬 수 있다 — 3회 읽어 중앙값으로 판단해 노이즈성 단발 튐을 걸러낸다.
    samples = sorted(read_tof(front) for _ in range(3))
    d = samples[1]
    if d == -1 or d > WALL_MM:   # 무효(-1) 또는 앞에 벽 없음 → 정렬 생략
        print("전방 벽 없음/무효 → 정렬 생략", d)
        return
    rev = -1 if not is_reversed else 1
    move = d - ALIGN_FRONT_MM   # 앞으로 (d-40)mm 가면 전방이 40mm가 된다 (음수면 후진)
    if move < 0:                # 후진은 보수적으로 — 거리를 1/2배만 보정
        move *= 0.5
    print("전방 벽 정렬", d, "→", ALIGN_FRONT_MM, "이동", move)
    yield from robot.straight(ALIGN_FRONT_SPEED, move * rev)
    robot.brake()


def turn(dest, duration=2000):
    global heading, lastYaw, gyroAngle, is_reversed

    if dest == 0:
        return

    if abs(dest) == 180:
        is_reversed = not is_reversed
        heading = (heading + 2) % 4
        rev = -1 if not is_reversed else 1
        yield from align_back(rev)
        return

    # 턴 시작 전 뒤로 15mm — 셀 중앙 확보 후 포인트턴.
    # is_reversed면 진행 방향이 뒤집히므로 부호도 반전.
    rev = -1 if not is_reversed else 1
    # yield from robot.straight(150, -15 * rev)

    robot.brake()
    settle_start = None   # angle-gyroAngle 편차가 0.5 이하로 들어온 시각 (None=아직 미도달)
    dropped_turn = set()
    dropper.start()

    # remaining(오차)이 0.5° 이하로 duration(기본 2000ms) 이상 연속 유지돼야 회전 종료.
    # 중간에 다시 벌어지면(카메라 드롭 등으로 흔들려도) 정착 타이머를 리셋한다.
    while True:
        remaining = dest - (imu.angle() - gyroAngle)
        ratio = min(1.0, abs(remaining) / abs(dest))  # 1.0=출발 → 0.0=도착
        pid_turn_control(dest, 0.14 + 0.28 * ratio, 17.2, 10)
        # 회전 바깥쪽 카메라 폴링 — 우회전(dest>0)이면 왼쪽, 좌회전이면 오른쪽
        r = dropper.poll()
        if r is not None:
            c, kits = r
            outside = (not dropper.is_right(c)) if dest > 0 else dropper.is_right(c)
            if outside and c not in dropped_turn:
                d = (tof2 if dropper.is_right(c) else tof3).get()
                if d > WALL_MM + DROP_WALL_MARGIN:
                    dropper.resume(c)
                else:
                    dropped_turn.add(c)
                    robot.brake()
                    if kits:
                        yield from dropper.drop(c, kits)
                    yield from blink_victim(VICTIM_RGB.get(kits, 0xFFFFFF))
                    settle_start = None  # 흔들렸으니 정착 타이머 리셋
        if abs(remaining) < 0.5:
            if settle_start is None:
                settle_start = time.ticks_ms()
            elif time.ticks_diff(time.ticks_ms(), settle_start) >= duration:
                break
        else:
            settle_start = None
        # print(imu.angle(), gyroAngle, remaining)
        yield

    gyroAngle += dest
    lastYaw = 0
    robot.brake()
    print("turn finished")
    # yield from gsleep(100)

    # 턴 종료 후 앞으로 15mm — 후진분 복원 (is_reversed면 부호 반전).
    robot.brake()

    # 회전 직후 후방에 벽이 있으면 그 벽에 붙여 자세/헤딩 재앵커링 (없으면 자동 생략).
    yield from align_back(rev)
    # await wait(100)
    # robot.stop(False)
    # await wait(100)
    # await imu.calibrate_with_mag()
    # await wait(100)

    heading = (heading + (-1 if dest == 90 else 1)) % 4

# -----------------------------------------------------------------------
# 주행
# -----------------------------------------------------------------------

def drive(speed, destMM, cam=True):
    # cam=True면 투하 행위를 이 drive 에 귀속: 시작 시 두 카메라 START → 주행 중 0/1/2
    #   수신 시 해당 방향 ToF로 벽 확인 후 서보 투하. follow_next_dir(먼 노드)은 cam=False.
    global yawIntegral
    yawIntegral = 0   # 이전 세그먼트의 누적 편향이 새 구간으로 새지 않게 리셋
    i = 0
    lastError = imu.angle()
    sensor = tof4 if is_reversed else tof1  # 진행방향 전방 센서(전/후 swap)
    downhill_done = False
    pitch0 = imu.pitch_deg()                   # drive 시작(평지) 기준 pitch — 장착 바이어스 상쇄

    dropped = set()                             # 투하/식별 완료한 카메라(방향)들 — 그 카메라만 이후 무시
    if cam:
        dropper.start()                          # 두 카메라 무장(RESUME 송신)

    robot.reset()

    blocked = None                              # "black"이면 구멍 감지로 중단(호출부가 벽으로 기록)

    while True:
        dist = abs(robot.distance())
        if dist > destMM:
            break
        ratio = dist / destMM
        # 내리막 진입 처리: 진행방향 기준 '내리막으로 숙은 정도'(downhill, 양수=내리막)가
        # 임계를 넘으면 정지→원위치 후진→저속 재진입한다(150 관성을 끊고 저속 모서리 진입을
        # 재현). 한 번 처리하면 이 drive 남은 구간은 저속(DOWNHILL_SPEED)으로 캡한다.
        # downhill: drive 시작(평지) pitch(pitch0)를 영점으로 빼 장착 바이어스를 상쇄하고
        # 진행방향에 맞춰 부호를 정렬 — 전진은 앞이 숙으면 pitch↓라 (pitch0-cur), 후진은 뒤가
        # 숙으면 pitch↑라 (cur-pitch0). 평지는 0 근처라 (>임계) 비교로 트리거되지 않는다.
        # 출발 직후 DOWNHILL_WARMUP_MM 까지는 출발 가속으로 pitch가 튀므로 감지를 보류하고 그
        # 구간 pitch0 를 현재값으로 추종(평지 영점 재정렬)시켜 출발 직후 오트리거를 막는다.
        cur = imu.pitch_deg()
        if not downhill_done:
            downhill = -(cur) if not is_reversed else (cur)
            if downhill > DOWNHILL_PITCH:
                print("내리막 감지 → 정지/후진/저속 재진입")
                # robot.brake()
                # yield from gsleep(150)
                bs = DOWNHILL_SPEED if not is_reversed else -DOWNHILL_SPEED
                while abs(robot.distance()) > BACKOFF_TOL_MM:
                    robot.drive(bs, 0)
                    yield from gsleep(1)
                robot.brake()
                yield from gsleep(150)
                lastError = imu.angle()
                downhill_done = True
                continue
        eff = DOWNHILL_SPEED if downhill_done else speed
        drive_speed = -eff if not is_reversed else eff
        # 감속 구간 떨림 방지: 조향량은 speed와 무관한 절대값이라 저속일수록 상대 비중이
        # 커짐 → gain과 오도 보정을 감속 비율에 맞춰 같이 축소. 하한 0.6 — 그 이하 감속은
        # 모터 stiction 한계 근처라 후반 떨림을 유발.
        # 단, 정지 목표 바로 앞(FINAL_APPROACH_MM 이내)까지 0.6 하한을 유지하면 brake()가
        # 관성을 못 죽여 5cm 이상 오버슛한다 — 이 구간만 떨림보다 정지 정확도를 우선해
        # 하한을 무시하고 더 감속한다.
        remaining = destMM - dist
        if remaining > FINAL_APPROACH_MM:
            speed_factor = max(DRV_DEC_SPEED ** ratio, 0.6)
        else:
            speed_factor = min(DRV_DEC_SPEED ** ratio, FINAL_MIN_FACTOR)
        # kd(13)가 kp(3)의 4배 이상인 미분 지배형이라 자이로 노이즈를 증폭 → 남은 떨림의
        # 주 원인으로 추정. kd를 9로 낮춰 미분 민감도 완화.
        pid_control(drive_speed * speed_factor, 0.2 * speed_factor, 3, 9,
                    odo_scale=speed_factor)

        angle = imu.angle()
        diff = angle - lastError
        lastError = angle

        t = sensor.get()
        if not downhill_done and 0 <= t <= STOP_MM:   # -1(무효 읽기) 등 음수는 긴급정지 트리거에서 제외
            print("전방 벽(TOF) → 긴급 정지", t)
            break
        # print(t)

        # 카메라 투하 — 문자 수신 시 해당 방향 ToF 로 벽 유무를 먼저 확인한다.
        #   ToF > WALL_MM+여유 → 그 방향에 벽이 없음(열린 면) → 오검출로 보고 그 카메라만
        #     재무장(RESUME)하고 drive 루프를 계속한다(투하하지 않음).
        #   벽이 있으면 서보 동작 후 계속. 한 번 투하하면 dropped=True 로 이후 UART 무시.
        #   (오른쪽=tof2/물리우, 왼쪽=tof3/물리좌)
        if cam:
            r = dropper.poll()
            if r is not None:
                c, kits = r                          # kits: 0=Unharmed 1=Stable 2=Harmed
                if c not in dropped:                 # 이미 처리한 카메라(방향)면 그것만 무시
                    d = (tof2 if dropper.is_right(c) else tof3).get()
                    if d > WALL_MM + DROP_WALL_MARGIN:
                        dropper.resume(c)            # 벽 없음(열린 면) → 오검출, 재무장만
                    else:
                        dropped.add(c)               # 이 카메라만 유효 식별 → 이후 이 카메라 무시
                        robot.brake()                # 규정 5.6: victim 15cm 이내 정지 상태에서
                        if kits:                     # 0(Unharmed)이면 식별만, 투하는 없음
                            yield from dropper.drop(c, kits)
                        lastError = imu.angle()      # 재개 시 PID 미분 튐 방지

        # 주행 중엔 검정(구멍)만 본다 → 감지 시 즉시 정지 후 후진(규정 3.2: 구멍 진입 금지).
        cs = cur_color()
        print(cs.detect())
        if cs is not None and cs.is_black():
            print("구멍(검정 타일) 감지 → 긴급 정지/후진")
            robot.brake()
            rev = -1 if not is_reversed else 1
            yield from robot.straight(150, -dist * rev)
            blocked = "black"
            break

        yield from gsleep(1)

    robot.brake()
    robot.reset()
    print("drive finished")
    return blocked


# -----------------------------------------------------------------------
# 바닥 컬러 (RCJ 3.2 Floor) — 타일색 분류 + 규정 동작
# -----------------------------------------------------------------------

def blue_stop():
    # 규정: 파랑(웅덩이) 진입 시 다음 타일로 가기 전 5초 정지. 글자 없이 파랑/검정 깜빡임.
    robot.brake()
    for s in range(5, 0, -1):
        M5.Lcd.fillScreen(0x0000FF if s % 2 else 0x000000)
        yield from gsleep(1000)


def cur_color():
    # 진행 방향에 맞는 컬러센서 선택 — is_reversed=True(후면 진행)면 후방(채널3), 아니면 전방(채널2).
    return color if not is_reversed else color_rev


def check_floor():
    # 정지(도착) 상태 측정 — 빨강/파랑/은색만 5회 다수결로 감지(노이즈 제거).
    # 검정(구멍)은 주행 중 drive()에서 처리하고, 흰색(일반)은 무시한다.
    # red(위험구역 입구)/silver(체크포인트)는 색 표시만, blue(웅덩이)는 5초 정지.
    cs = cur_color()
    if cs is None:
        return
    name = cs.detect_stop()
    if name is None:
        return
    print("floor:", name, cs.MEANING.get(name, "?"))
    if name == "blue":
        yield from blue_stop()

# -----------------------------------------------------------------------
# 그리드 계산
# -----------------------------------------------------------------------

def get_open_side(gx, gy):
    # 실제 ToF로 좌/전/우 개방 판정. 전/후·좌/우 물리 swap 반영:
    #   not reversed: 전방=tof4, 우=tof3, 좌=tof2
    #   reversed:     전방=tof1, 논리좌=tof3, 논리우=tof2
    # try:
    print("get_open_side")

    # ToF가 하나라도 -1(읽기 실패/무효)이면 셋 다 정상값일 때까지 다시 읽는다.
    for _ in range(3):
        pahub.get([tof4, tof3, tof2, tof1])

    while True:
        if is_reversed:
            d_f, d_r, d_l = pahub.get([tof4, tof3, tof2])
        else:
            d_f, d_l, d_r = pahub.get([tof1, tof3, tof2])

        if -1 not in (d_f, d_r, d_l):
            break
        print("ToF -1 감지 → 재측정", d_f, d_r, d_l)
    print(d_f, d_r, d_l)
    sides = [int(d_l > WALL_MM), int(d_f > WALL_MM), int(d_r > WALL_MM)]

    for i in range(3):
        nb = direction(gx + next_dir(heading, i).x, gy + next_dir(heading, i).y)
        if nb in closedList:
            sides[i] = 0
        elif sides[i] and next_dir(heading, i) in openList:
            openList.remove(next_dir(heading, i))

    return sides


def sides_to_wall(sides, isFirst=False):
    # isFirst=True: 시작 셀은 후면이 항상 벽(막힌 면에 붙여 출발)
    backward = 0 if isFirst else 1
    n = s = w = e = 0
    if   heading == 0: n, s, w, e = sides[1], backward, sides[0], sides[2]
    elif heading == 1: n, s, w, e = sides[0], sides[2], backward, sides[1]
    elif heading == 2: n, s, w, e = backward, sides[1], sides[2], sides[0]
    elif heading == 3: n, s, w, e = sides[2], sides[0], sides[1], backward
    # 시각적 레이아웃: bit0=N벽, bit1=S벽, bit2=W벽, bit3=E벽 (1=벽 있음, 0=통로)
    return (1-n) | ((1-s) << 1) | ((1-w) << 2) | ((1-e) << 3)


# 절대 방향(direction) → sides_to_wall과 동일한 비트 (N=bit0 S=bit1 W=bit2 E=bit3)
_DIR_WALL_BIT = {direction(0, -1): 1, direction(0, 1): 2, direction(-1, 0): 4, direction(1, 0): 8}


def check_open_dir(gx, gy, isFirst=False):
    sides = get_open_side(gx, gy)
    return sides, sides_to_wall(sides, isFirst)


def _expand_grid(grid, _node, dir):
    dx = dy = tx = ty = gx = gy = 0
    old_h, old_w = len(grid), len(grid[0])
    if dir.x != 0:
        tx = -dir.x
        if not (0 <= _node.x + dir.x < old_w):
            gx = 1
            if dir.x < 0: dx = 1
    if dir.y != 0:
        ty = -dir.y
        if not (0 <= _node.y + dir.y < old_h):
            gy = 1
            if dir.y < 0: dy = 1
    return dx, dy, tx, ty, gx, gy


def _build_grid(grid, dx, dy, gx, gy):
    tGrid = [[NNode() for _ in range(len(grid[0]) + gx)]
             for _ in range(len(grid) + gy)]
    for y in range(len(grid)):
        for x in range(len(grid[0])):
            n = grid[y][x]
            n.set_xy(n.x + dx, n.y + dy)
            tGrid[y + dy][x + dx] = n
    return tGrid


def modify_grid(_node, dir, grid):
    global openList, closedList

    dx, dy, tx, ty, gx, gy = _expand_grid(grid, _node, dir)

    openList   = [direction(e[0] + tx, e[1] + ty) for e in openList]
    closedList = [direction(e[0] + dx, e[1] + dy) for e in closedList]

    nx, ny = _node.x + dir.x + dx, _node.y + dir.y + dy
    sides, _wall = check_open_dir(nx, ny)

    _node = Node(nx, ny, _wall, None)
    tGrid = _build_grid(grid, dx, dy, gx, gy)
    tGrid[_node.y][_node.x] = _node

    for i, cond in enumerate(sides):
        if cond:
            openList.append(next_dir(heading, i))
    closedList.append(direction(_node.x, _node.y))

    return _node, tGrid, dx, dy


def follow_next_dir(_dir, _node, _grid):
    isGriding = True
    _node = _node.copy()
    try:
        _grid[_node.pos(_dir)[1]][_node.pos(_dir)[0]]
    except Exception:
        isGriding = False

    dirs = get_directions(_grid, dir_to_pos(_node.pos()), dir_to_pos(_node.pos(_dir)), isGriding)
    # yield from gsleep(200)

    for __dir in dirs:
        if __dir in (direction(0,2), direction(0,-2), direction(2,0), direction(-2,0)):
            half = direction(__dir.x // 2, __dir.y // 2)
            _node.add_xy(half.x, half.y)
            _dir = add_dir(_dir, -half.x, -half.y)
            openList[:] = [add_dir(e, -half.x, -half.y) for e in openList]
            create_grid(grid_to_int(_grid), direction(_node.x, _node.y), heading)
            continue

        yield from turn(look_dir(heading, __dir))
        yield from gsleep(100)
        yield from drive(150, 300, cam=False)   # 먼 노드 이동 → 카메라(투하)만 끔, 전방 벽은 유지
        yield from align_front()   # 앞에 벽 있으면 전방 40mm로 맞춤
        yield from check_floor()
        yield from gsleep(100)

        _node.add_xy(__dir.x, __dir.y)
        _dir = add_dir(_dir, -__dir.x, -__dir.y)
        openList[:] = [add_dir(e, -__dir.x, -__dir.y) for e in openList]
        create_grid(grid_to_int(_grid), direction(_node.x, _node.y), heading)

    return _dir, _node


def grid_to_int(grid):
    return [[n.wall for n in row] for row in grid]


def dir_to_pos(d):
    return [d.x, d.y]


def add_dir(d, x, y):
    return direction(d.x + x, d.y + y)

# -----------------------------------------------------------------------
# 메인 탐색 루프
# -----------------------------------------------------------------------

def start_program():
    global pos, startPos, checkpoint, openList, closedList, heading, gyroAngle

    if checkpoint["grid"] is None:
        pos = startPos = [0, 0]
        openList, closedList = [], [direction(0, 0)]
        heading = gyroAngle = 0
        yield from reset_turn()

        sides, wall = check_open_dir(0, 0, True)
        openList = [next_dir(heading, i) for i, ok in enumerate(sides) if ok]

        node = Node(0, 0, wall, None)
        grid = [[node]]
        dir  = openList.pop()
        create_grid(grid_to_int(grid), direction(node.x, node.y), heading)
    else:
        node       = checkpoint["node"]
        dir        = checkpoint["dir"]
        grid       = checkpoint["grid"]
        openList   = checkpoint["openList"]
        closedList = checkpoint["closedList"]
        startPos   = checkpoint["startPos"]
        gyroAngle  = checkpoint["gyroAngle"]
        heading    = checkpoint["heading"]
        yield from reset_turn()

    while True:
        # checkpoint["grid"]      = grid
        # checkpoint["node"]      = node
        # checkpoint["dir"]       = dir
        # checkpoint["openList"]  = list(openList)
        # checkpoint["closedList"]= list(closedList)
        # checkpoint["startPos"]  = list(startPos)
        # checkpoint["gyroAngle"] = gyroAngle
        # checkpoint["heading"]   = heading

        if dir not in (direction(0,-1), direction(0,1), direction(-1,0), direction(1,0)):
            dir, node = yield from follow_next_dir(dir, node, grid)
        elif node.wall in (7, 11, 13, 14):
            one_exit = {7: direction(1,0), 11: direction(-1,0),
                        13: direction(0,1), 14: direction(0,-1)}[node.wall]
            if dir != one_exit:
                dir, node = yield from follow_next_dir(dir, node, grid)

        yield from turn(look_dir(heading, dir))

        blocked = yield from drive(125, 300)
        if blocked == "black":
            # 구멍(검정 타일) → 그 칸엔 진입하지 않았으므로 새 노드를 만들지 않고,
            # 현재 노드의 해당 방향만 벽으로 기록해 다음 탐색에서 다시 시도하지 않게 한다.
            print("구멍 방향을 벽으로 기록:", dir)
            node.wall |= _DIR_WALL_BIT[dir]
            create_grid(grid_to_int(grid), direction(node.x, node.y), heading)

            if not openList:
                break

            dir = openList.pop()
            yield
            continue

        yield from align_front()   # 앞에 벽 있으면 전방 40mm로 맞춤
        yield from check_floor()

        yield from gsleep(1)

        node, grid, dx, dy = modify_grid(node, dir, grid)
        pos = node.pos()
        startPos[0] += dx
        startPos[1] += dy

        create_grid(grid_to_int(grid), direction(node.x, node.y), heading)

        if not openList:
            break

        dir = openList.pop()
        yield

    print("탐색 완료")
    fin_dir, _ = yield from follow_next_dir(
        direction(startPos[0] - node.x, startPos[1] - node.y), node, grid
    )
    # follow_next_dir 은 목표 직전 칸까지만 이동하므로(탐색 루프처럼 이후 turn+drive 필요),
    # 남은 방향(fin_dir)으로 마지막 한 칸을 마저 이동해 시작 타일에 실제로 진입한다.
    if fin_dir.x or fin_dir.y:
        yield from turn(look_dir(heading, fin_dir))
        yield from drive(125, 300, cam=False)
    print("시작 타일 복귀 → Exit Bonus 점멸(ON1s/OFF1s 10초)")
    yield from blink_exit()
    yield from blink_exit()

# -----------------------------------------------------------------------
# 엔트리포인트
# -----------------------------------------------------------------------

_touch_result = None

def _wait_touch():
    global _touch_result
    _touch_result = yield from wait_touch(hold_threshold=2000, detect_hold=True)


def main():
    try:
        # I2C 장치 응답 확인 — 0x22=BASEX, 0x38=FT6336, 0x69=BMI270
        # yield from gsleep(1000)
        print("scan:", _i2c.scan())

        # ToF(id=1) 초기화 — PaHub I2C 컨트롤러 생성 후 센서 생성/start.
        # 읽기는 get_open_side/drive에서 그때그때 직접 한다(폴링 스레드 없음).
        global tof1, tof2, tof3, tof4, color, color_rev
        pahub.start()
        # 2점 보정: 각 센서를 25mm·150mm 벽에 대고 raw를 측정해 offset_25/offset_150에 채운다.
        # 미측정이면 기본값(25/150)이라 raw 그대로 나온다 → 측정 후 값만 바꾸면 자동 보정.
        tof1 = VL53L0X(pahub, channel=5, offset_25=56,  offset_150=190)  # 정면
        tof2 = VL53L0X(pahub, channel=4, offset_25=92,  offset_150=221)  # 우측
        tof3 = VL53L0X(pahub, channel=0, offset_25=120, offset_150=245)  # 좌측
        tof4 = VL53L0X(pahub, channel=1, offset_25=81,  offset_150=225)  # 후면
        tof1.start()
        tof2.start()
        tof3.start()
        tof4.start()
        # 바닥 컬러센서 — PaHub 같은 버스. 전진용(채널2)/후진용(채널3) 각 1개, is_reversed로 선택.
        # 생성 시 _init()이 채널 전환 후 자동 실행.
        color = ColorSensor(pahub, channel=COLOR_CH)
        color_rev = ColorSensor(pahub, channel=COLOR_CH_REV, ref=ColorSensor.REF_REV)
        print("init 완료")

        imu.reset_angle()
        # await imu.calibrate_with_mag()  # 시작 방향을 지자계 오프셋으로 저장 (_mag_initial)



        # 콜드부팅 대응 — 첫 터치를 읽기 "직전"에 FT6336을 한 번 더 리셋한다.
        # Touch.__init__의 리셋 이후 pahub.start()/ToF init 과정에서 FT6336이 다시
        # 죽는 경우가 있어, 진단(touch_aw9523_test.py)에서 검증된 "읽기 직전 리셋" 순서를
        # 여기서 재현한다. reset_cores3_touch 내부에 부팅 대기(300ms)가 포함돼 있다.
        reset_cores3_touch(_i2c)

        # 첫 터치로 탐색 시작 — 화면 색으로 터치 상태 표시(시리얼 없이 눈으로 확인).
        #   준비(대기)=빨강, 터치 중=흰색, 터치 끝(시작)=검정


        while True:
            M5.Lcd.fillScreen(0xFF0000)
            _was = False
            while True:
                _t = touch.is_touching()
                if _t and not _was:
                    M5.Lcd.fillScreen(0xFFFFFF)  # 누르는 동안 흰색
                elif _was and not _t:
                    M5.Lcd.fillScreen(0x000000)  # 떼면 검정 → 탐색 시작
                    break
                _was = _t
                yield from gsleep(10)
            print("터치 감지 — 탐색 시작")

            # start_program 과 터치 감시를 제너레이터 협력으로 동시 구동.
            # 먼저 끝난 쪽 인덱스를 받는다(0=탐색 완료, 1=터치 중단). 나머지는 grace가 close.
            idx = grace(start_program(), _wait_touch())
            # idx = grace(drive(200, 300), _wait_touch())

            if idx == 0:
                # 탐색 정상 완료
                break

            # 터치로 중단 — 결과에 따라 재시작 방식 결정
            result = _touch_result
            print("touch result:", result)

            if result == 2:  # 길게 누름: 저장 데이터 초기화 후 재시작
                checkpoint["grid"] = None
            # 짧게 누름(1): 체크포인트부터 재시작 — 루프 계속

            robot.stop(lock=False)

            while True:
                _t = touch.is_touching()
                if not _t:
                    break
                yield from gsleep(10)

            yield from gsleep(1000)

    except Exception as e:
        log_error(e, "tof_f_main")
        print("오류:", e)
    finally:
        robot.close()


try:
    grun(main())
    # grun(drive(200, 300))
except KeyboardInterrupt:
    robot.stop(lock=False)
