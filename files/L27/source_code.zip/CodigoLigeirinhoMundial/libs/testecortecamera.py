from flask import Flask, Response
import threading
import time
import cv2

app = Flask(__name__)

frame_atual = None
lock = threading.Lock()


# --- Função que corta as laterais ---
def cortar_laterais(frame, px=20):
    h, w = frame.shape[:2]

    if w <= px*2:
        return frame

    return frame[:, px:w-px].copy()


# --- THREAD que captura a câmera e atualiza o frame ---
def captura_camera():
    global frame_atual

    cap = cv2.VideoCapture(1)
    if not cap.isOpened():
        print("ERRO: câmera não abriu")
        return

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        # corta as laterais
        frame_cortado = cortar_laterais(frame, 100)

        # atualiza frame para o Flask
        with lock:
            frame_atual = frame_cortado.copy()

        time.sleep(0.02)  # ~50 fps

    cap.release()


# --- STREAM de vídeo para o Flask ---
def gerar_video():
    global frame_atual

    while True:
        if frame_atual is not None:
            with lock:
                ret, buffer = cv2.imencode('.jpg', frame_atual)
            frame_bytes = buffer.tobytes()

            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' +
                   frame_bytes + b'\r\n')

        time.sleep(0.03)


@app.route('/')
def index():
    return '<h1>Camera do robô</h1><img src="/video" width="640">'


@app.route('/video')
def video_feed():
    return Response(gerar_video(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')


# --- INÍCIO DO PROGRAMA ---
if __name__ == '__main__':
    # inicia thread de captura
    t = threading.Thread(target=captura_camera, daemon=True)
    t.start()

    # inicia servidor
    app.run(host='0.0.0.0', port=5000, debug=False)
