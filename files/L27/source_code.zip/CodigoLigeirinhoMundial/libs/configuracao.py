import json

class Configuracao:
    def __init__(self, nomeArquivo):
        self.nomeArquivo = nomeArquivo + ".json"
        try:
            self.carrega()
        except:
            self.config = {}

    def limpa(self):
        self.config = {}
        self.salva()

    def salva(self):
        with open(self.nomeArquivo, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)

    def carrega(self):
        with open(self.nomeArquivo, 'r', encoding='utf-8') as f:
            self.config = json.load(f)

    def obtem(self, chave):
        return self.config.get(chave, None)

    def insere(self, chave, valor):
        self.config[chave] = valor
        self.salva()