from imports import *
import numpy as np
import processamentoCamera as cam

import cv2
import numpy as np

class StuckDetector:
    def __init__(self, threshold=10000, frames_to_confirm=150):
        # self.cam = cam
        self.prev_frame = None
        self.threshold = threshold
        self.frames_to_confirm = frames_to_confirm
        self.stuck_counter = 0

    def ta_preso(self):
        ret, frame = cam.cap.read()
        # ret, frame = self.cam.cap.read()

        if not ret or frame is None:
            # print("Erro ao capturar frame")
            return False

        # Converte para escala de cinza
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Reduz ruído
        gray = cv2.GaussianBlur(gray, (5, 5), 0)

        if self.prev_frame is None:
            self.prev_frame = gray
            return False

        # Diferença entre frames
        diff = cv2.absdiff(self.prev_frame, gray)

        # Threshold binário
        _, thresh = cv2.threshold(diff, 25, 255, cv2.THRESH_BINARY)

        # Conta pixels diferentes
        motion_score = cv2.countNonZero(thresh)

        self.prev_frame = gray

        if motion_score < self.threshold:
            self.stuck_counter += 1
        else:
            self.stuck_counter = 0

        return self.stuck_counter >= self.frames_to_confirm