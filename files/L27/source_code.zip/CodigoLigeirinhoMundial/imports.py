from libs.vl53 import VL53L0X
from datetime import datetime
from libs.configuracao import Configuracao
from libs.pinosDigitais import Botoes
from libs.teclado import Teclado
arquivosConfiguracao = Configuracao("ARQUIVOS-BASE")
import random
import numpy as np
import cv2
importarIA = True
import variaveis as var
import time
from threading import Thread
from threadVideo import VideoStream
from libs.giroscopio import Giroscopio
from libs.motores import Motores
from libs.portas import Portas
import cronometros as cron
from math import e
from flask import Flask, Response
import constantes as cons
import variaveis as var
import cronometros as cron
import os
from libs.placaControleMotor import PlacaControleMotor
from libs.placaControleServo import PlacaControleServo
import glob
import threading
import logging
from libs.stuckDetector import StuckDetector
import cv2
import time
from datetime import datetime
import platform
import copy
import IA
import processamentoCamera as cam
sistema = platform.system()
import serial
import numpy as np
import os
import json
import glob
import os
import subprocess
import math
from threadVideo import VideoStream
from flask import Flask, Response, render_template, jsonify
from threading import Thread
botoes = Botoes()
teclado = Teclado(0,0x38)
servoEsquerdoGarra = PlacaControleServo(Portas.SERIAL1, id_equipamento=54)
servoDireitoGarra = PlacaControleServo(Portas.SERIAL1, id_equipamento=52)
servoCentralGarra = PlacaControleServo(Portas.SERIAL1, id_equipamento=45)
servoCacamba = PlacaControleServo(Portas.SERIAL1, id_equipamento=64)
device = 'cpu'
sensorDistanciaDireito = VL53L0X(Portas.I2C7)
sensorDistanciaEsquerdo = VL53L0X(Portas.I2C3)
sensorDistanciaFrontal = VL53L0X(Portas.I2C6) 
sensorDistanciaVitimaMorta = VL53L0X(Portas.I2C8)
sensorDistanciaVitimaVivaCima = VL53L0X(Portas.I2C2) 
sensorDistanciaVitimaVivaBaixo = VL53L0X(Portas.I2C1) 
roboTaPreso = StuckDetector()
portas = Portas()
portaSerialbarramento = portas.abre_porta_serial(Portas.SERIAL1, 250000, timeout=0.005)
motor1 = PlacaControleMotor(portaSerialbarramento, id_equipamento=5)
motor2 = PlacaControleMotor(portaSerialbarramento, id_equipamento=72)
posicao = 0
potencia = 0
zona_morta = 5
MOTOR_DIREITO = 2
MOTOR_ESQUERDO = 1
motores = Motores(True)
motores.direcao_motor(1, Motores.INVERTIDO)
resultado = motor1.reset()
print(resultado)
resultado = motor2.reset()
print(resultado)
motor1.direcao_motor(Motores.INVERTIDO)
motor1.calibracao_manual(32,-32)
motor2.calibracao_manual(32,-32)
resultado = motores.obtem_calibracao_motores()
print(resultado)
time.sleep(0.5)
motores.pid_motor(2,2,2)
motores.set_modo_freio(Motores.HOLD)
motor1.set_freio(PlacaControleMotor.FREIO_TRAVADO)
motor2.set_freio(PlacaControleMotor.FREIO_TRAVADO)
motor1.set_kp_freio(3)
motor1.set_kd_freio(10)
motor2.set_kp_freio(3)
motor2.set_kd_freio(10)
motor1.set_delta_freio(20)
motor2.set_delta_freio(20)
motor1.set_kp(2)
motor1.set_kd(2)
motor1.set_ki(2)
motor2.set_kp(2)
motor2.set_kd(2)
motor2.set_ki(2)
giroscopio = Giroscopio(Portas.SERIAL4)
import threading
def velocidade_motores_encoder(velocidadeEsquerdos,velocidadeDireitos):
    t = threading.Thread(target=motores.velocidade_motores, args=(velocidadeEsquerdos*1.2, velocidadeDireitos*1.2))
    t.start()
    resultado = motor1.velocidade_motor(velocidadeDireitos)
    t.join()
    resultado = motor2.velocidade_motor(velocidadeEsquerdos)
def para_motores():
    velocidade_motores_encoder(0,0)
