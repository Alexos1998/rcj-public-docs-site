import imports
from imports import *
import IA

lower_green = np.array([60, 200, 50]) 
upper_green = np.array([95, 255, 180]) 

lower_silver = np.array([0,0,120])
upper_silver = np.array([100,50,255])

width = 100
height = 75
cap = None

def esperar(tempoEsperar):
    cron.tempoParar.reseta()
    imports.para_motores()
    while cron.tempoParar.tempo() < tempoEsperar:
        continue
    return 

def calcularErro(frame):
    frame = cv2.resize(frame, (width, height))
    frameGray = cv2.resize(frame, (width, height))
    global lower_green, upper_green
    FAIXA_LARGURA_PERCENT = 0.85  
    faixa_largura = int(width * FAIXA_LARGURA_PERCENT)
    faixa_inicio = (width - faixa_largura) // 2
    faixa_fim = faixa_inicio + faixa_largura
    centro_faixa = faixa_inicio + faixa_largura // 2  
    valorMaximoBranco = 0.4
    valorMinimoPreto = 0.6
    valorMinimoVermelho = 0.3
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mask_green = cv2.inRange(hsv, lower_green, upper_green)
    mask_silver = cv2.inRange(hsv, lower_silver, upper_silver)
    frameGray[mask_green == 255] = [255,255,255] 
    result = np.full_like(frame, 255)
    gray = cv2.cvtColor(frameGray, cv2.COLOR_BGR2GRAY)  
    quad_height = max(20, height // 6)
    left_square = gray[height//3:(height//2)+10, faixa_inicio:centro_faixa]
    right_square = gray[height//3:(height//2)+10, centro_faixa:faixa_fim]
    retanguloConferirNoventa = gray[height//5:(height//3), centro_faixa-6:centro_faixa+6]  
    retanguloRealizarNoventaDireito = gray[10:quad_height+10, centro_faixa+10:centro_faixa+20]
    retanguloRealizarNoventaEsquerdo = gray[10:quad_height+10, centro_faixa-20:centro_faixa-10]
    retanguloRealizarNoventa = gray[cons.HEIGHT_IMAGEM//2+20:cons.HEIGHT_IMAGEM//2+30, centro_faixa-2:centro_faixa+2]
    retanguloPegarPrataReflexivo = gray[0:quad_height, faixa_inicio+20:faixa_fim-20]
    if retanguloPegarPrataReflexivo.size > 0:
        var.valorPrataReflexivo = np.count_nonzero(mask_silver) / mask_silver.size
    if var.valorPrataReflexivo > 0.07:
        var.pegouPrataReflexivo = True
    else:
        var.pegouPrataReflexivo = False
    if var.conferirErroAlto > 0.7:
        var.amenizarErro = True
    else:
        var.amenizarErro = False
    retanguloConferirVermelho = frame[20:height+20, faixa_inicio:faixa_fim]
    retanguloConferirGapEsquerdo = frame[height//3:height//2, faixa_inicio:faixa_inicio+10]
    retanguloConferirGapDireito = frame[height//3:height//2, faixa_fim-10:faixa_fim]
    if retanguloRealizarNoventa.size > 0:
        var.qtdPretoFinalizarNoventa = np.count_nonzero(retanguloRealizarNoventa < 100) / retanguloRealizarNoventa.size
    else:
        var.qtdPretoFinalizarNoventa = 0
    if retanguloRealizarNoventaDireito.size > 0:
        var.qtdPretoFinalizarNoventaDireito = np.count_nonzero(retanguloRealizarNoventaDireito < 100) / retanguloRealizarNoventaDireito.size
    else:
        var.qtdPretoFinalizarNoventaDireito = 0
    if retanguloRealizarNoventaEsquerdo.size > 0:
        var.qtdPretoFinalizarNoventaEsquerdo = np.count_nonzero(retanguloRealizarNoventaEsquerdo < 100) / retanguloRealizarNoventaEsquerdo.size
    else:
        var.qtdPretoFinalizarNoventaEsquerdo = 0
    cv2.rectangle(result, (faixa_inicio, 30), (faixa_inicio+5, (height//2)+10), (255, 0, 0), 1)
    cv2.rectangle(result, (faixa_fim-5, 30), (faixa_fim, (height//2)+10), (255, 0, 0), 1)
    hsv_vermelho = cv2.cvtColor(retanguloConferirVermelho, cv2.COLOR_BGR2HSV)
    lower_red1 = np.array([0, 80, 80])
    upper_red1 = np.array([15, 255, 255])
    lower_red2 = np.array([150, 80, 80])
    upper_red2 = np.array([200, 255, 255])
    mask1 = cv2.inRange(hsv_vermelho, lower_red1, upper_red1)
    mask2 = cv2.inRange(hsv_vermelho, lower_red2, upper_red2)
    mask = cv2.bitwise_or(mask1, mask2)
    red_ratio = np.count_nonzero(mask) / mask.size
    if red_ratio >= valorMinimoVermelho:
        var.vermelhoConfirmado = True
        esperar(8000)
    else:
        var.vermelhoConfirmado = False
    left_black_ratio = np.count_nonzero(left_square < 100) / left_square.size
    right_black_ratio = np.count_nonzero(right_square < 100) / right_square.size
    var.valorPretoConferirGapEsquerdo = np.count_nonzero(retanguloConferirGapEsquerdo < 100) / retanguloConferirGapEsquerdo.size
    var.valorPretoConferirGapDireito = np.count_nonzero(retanguloConferirGapDireito < 100) / retanguloConferirGapDireito.size
    if left_black_ratio >= valorMinimoPreto and right_black_ratio <= valorMaximoBranco:
            var.noventaGraus = True
            var.direcaoNoventa = -1
    elif right_black_ratio >= valorMinimoPreto and left_black_ratio <= valorMaximoBranco:
            var.noventaGraus = True
            var.direcaoNoventa = 1
    if var.noventaGraus:
        var.qtdPretoConferirNoventa = np.count_nonzero(retanguloConferirNoventa < 100) / retanguloConferirNoventa.size
        if var.qtdPretoConferirNoventa == 0:
            var.noventaConfirmado = True
    quantDivisions = 3
    heightIndiv = height//quantDivisions
    listaError = []
    for i in range(quantDivisions):
        if i == 2:
            dark_threshold = 80
            if var.estouNaRampa:
                dark_threshold = 20
        else:
            dark_threshold = 110
            if var.estouNaRampa:
                dark_threshold = 80
        gray_div = gray[i*heightIndiv:(i+1)*heightIndiv, faixa_inicio:faixa_fim]
        mask_black_div = (gray_div < dark_threshold).astype(np.uint8) * 255
        mask_completa = np.zeros((heightIndiv, width), dtype=np.uint8)
        mask_completa[:, faixa_inicio:faixa_fim] = mask_black_div
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
        mask_completa = cv2.morphologyEx(mask_completa, cv2.MORPH_CLOSE, kernel, iterations=1)
        result[i*heightIndiv:(i+1)*heightIndiv, :] = np.where(mask_completa[..., None] == 255, (0,0,0), result[i*heightIndiv:(i+1)*heightIndiv, :])
        imgDiv = mask_completa
        error = 0
        contours, _ = cv2.findContours(imgDiv.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            listaError.append("sem linha")
            continue
        largest = max(contours, key=cv2.contourArea)
        if cv2.contourArea(largest) < 250:
            listaError.append("sem linha")
            continue
        elif cv2.contourArea(largest) > 650 and not var.estouNaRampa:
            listaError.append(0)
            continue 
        pts = largest.reshape(-1, 2)
        x_min, y_min = int(pts[:, 0].min()), int(pts[:, 1].min())
        x_max, y_max = int(pts[:, 0].max()), int(pts[:, 1].max())
        cv2.line(result, (faixa_inicio, i*heightIndiv), (faixa_inicio, (i+1)*heightIndiv), (255, 0, 0), 1)
        cv2.line(result, (faixa_fim, i*heightIndiv), (faixa_fim, (i+1)*heightIndiv), (255, 0, 0), 1)
        cv2.line(result, (centro_faixa, i*heightIndiv), (centro_faixa, (i+1)*heightIndiv), (0, 255, 0), 1)
        cv2.drawContours(result, [largest + [0, i*heightIndiv]], -1, (0, 0, 255), 1)
        centro_linha = (x_min + x_max)//2   
        error = centro_linha - centro_faixa  
        cx = centro_linha
        cy = (y_min + y_max)//2
        cv2.circle(result, (cx, (i*heightIndiv)+cy), 3, (255, 255, 255), -1)
        cv2.circle(result, (centro_faixa, (i*heightIndiv+cy)), 2, (0, 255, 0), -1)  
        cv2.putText(result, f"{error}", (cx+width//75, (i*heightIndiv)+cy), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1, cv2.LINE_AA)
        if not error:
            error = 0
        if i != 0:
            listaError.append((error))
        else:
            listaError.append((2*error))
    listaErrosUsados = [listaError[0], listaError[1], listaError[2]]
    if var.estouNaRampa:
        listaErrosUsados = [listaError[1], listaError[2]]
    non_zero_errors = [e for e in listaErrosUsados if e != "sem linha"]
    if non_zero_errors:
        mediaErros = sum(non_zero_errors) / len(non_zero_errors)
    else:
        mediaErros = "sem linha"
    if var.confirmandoNoventa:
        listaError[0] = "sem linha"
    return result, listaError, mediaErros, var.noventaGraus

def expand_box(box, scale=2):
    center = np.mean(box, axis=0)
    expanded = (box - center) * scale + center
    return np.intp(expanded)

def order_box_points(pts):
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]   
    rect[2] = pts[np.argmax(s)]   
    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]  
    rect[3] = pts[np.argmax(diff)]  
    return rect.astype(int)

def draw_quadrant_lines_and_labels(frame, box):
    expanded_box = expand_box(box, scale=1.6)
    rect = order_box_points(expanded_box)
    top_mid = (rect[0] + rect[1]) // 2
    bottom_mid = (rect[2] + rect[3]) // 2
    left_mid = (rect[0] + rect[3]) // 2
    right_mid = (rect[1] + rect[2]) // 2
    cv2.line(frame, tuple(left_mid), tuple(right_mid), (255, 255, 255), 1)
    cv2.line(frame, tuple(top_mid), tuple(bottom_mid), (255, 255, 255), 1)
    cv2.polylines(frame, [expanded_box], True, (255, 255, 255), 1)
    offset = 3
    labels = {
        "(-x, +y)": rect[0] - [offset, offset],
        "(+x, +y)": rect[1] + [offset, -offset],
        "(+x, -y)": rect[2] + [offset, offset],
        "(-x, -y)": rect[3] - [offset, -offset],
    }
    for text, pos in labels.items():
        cv2.putText(frame, text, tuple(pos.astype(int)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.2, (0, 0, 255), 1)
    return rect

def detectar_quadrantes(frame, estouNoVerde=False):
    frame = cv2.resize(frame, (width, height))
    global lower_green, upper_green
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    mask_green = cv2.inRange(hsv, lower_green, upper_green)
    contours, _ = cv2.findContours(mask_green, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    dark_threshold = 110
    if var.estouNaRampa:
        dark_threshold = 80
    valoresVerde = []
    for contour in contours:
        if cv2.contourArea(contour) < 300:
            continue
        rect = cv2.minAreaRect(contour)
        box = np.intp(cv2.boxPoints(rect))
        ordered_box = order_box_points(box)
        expanded_box = expand_box(ordered_box, scale=2)
        mask_expanded = np.zeros(frame.shape[:2], dtype=np.uint8)
        mask_inner = np.zeros_like(mask_expanded)
        cv2.fillPoly(mask_expanded, [expanded_box], 255)
        cv2.fillPoly(mask_inner, [ordered_box], 255)
        mask_ring = cv2.bitwise_and(mask_expanded, cv2.bitwise_not(mask_inner))
        cx = int(np.mean(expanded_box[:, 0]))
        cy = int(np.mean(expanded_box[:, 1]))
        var.posicoesVerde = [cx,cy]
        if var.posicoesVerde[1] < 15:
            continue
        h, w = gray.shape
        ys, xs = np.indices((h, w))
        dark = gray < dark_threshold
        quadrants_masks = {
            "(-x, +y)": (xs < cx) & (ys < cy),
            "(+x, +y)": (xs >= cx) & (ys < cy),
            "(+x, -y)": (xs >= cx) & (ys >= cy),
            "(-x, -y)": (xs < cx) & (ys >= cy),
        }
        dark_counts = {}
        for q, qmask in quadrants_masks.items():
            total = np.count_nonzero(qmask & (mask_ring > 0))
            dark_pixels = np.count_nonzero(dark & qmask & (mask_ring > 0))
            dark_counts[q] = dark_pixels / total if total > 0 else 0
        quadrante1 = "(-x, +y)"
        quadrante2 = "(+x, +y)"
        quadrante3 = "(-x, -y)"
        quadrante4 = "(+x, -y)"
        quadrantes = [quadrante1,quadrante2,quadrante3,quadrante4]
        preto1 = dark_counts.get(quadrante1, 0)
        preto2 = dark_counts.get(quadrante2, 0)
        preto3 = dark_counts.get(quadrante3, 0)
        preto4 = dark_counts.get(quadrante4, 0)
        listaValorDeQuadrantes = [preto1,preto2,preto3,preto4]
        quadranteMaisPreto = max(listaValorDeQuadrantes)
        valoresContornoAtual = []
        for i in range(4):
            if listaValorDeQuadrantes[i] == quadranteMaisPreto:
                valoresContornoAtual.append(quadrantes[i])
        if (valoresContornoAtual[0] == "(+x, +y)" and var.posicoesVerde[0] > cons.WIDTH_IMAGEM//2+5) or (valoresContornoAtual[0] == "(-x, +y)" and var.posicoesVerde[0] < cons.WIDTH_IMAGEM//2-5):
            print(var.posicoesVerde)
            pass
        else:
            valoresVerde.append(valoresContornoAtual[0])
        cv2.drawContours(frame, [ordered_box], 0, (0, 0, 255), 2)
        draw_quadrant_lines_and_labels(frame, box)
    if not valoresVerde:
        valoresVerde = ["sem verde"]
    msg = str(valoresVerde)
    cv2.putText(frame, msg, (0, 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.2, (0, 255, 0), 1)
    return frame, valoresVerde

def detectarTriangulo(trianguloProcurar):
    lower_green = np.array([44,  70,  40])
    upper_green = np.array([85, 255, 120])
    ret, frame = IA.cap2.read()
    if not ret:
        return None
    frame = cv2.resize(frame, (width, height))
    frameInicial = frame.copy()
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_red1 = np.array([0,  100, 40])
    upper_red1 = np.array([20, 255, 170])
    lower_red2 = np.array([160, 100, 40])
    upper_red2 = np.array([179, 255, 170])
    mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
    mask2 = cv2.inRange(hsv, lower_red2, upper_red2)   
    maskRed = cv2.bitwise_or(mask1, mask2)
    maskGreen = cv2.inRange(hsv, lower_green, upper_green) 
    if trianguloProcurar == cons.TRIANGULO_VERDE:
        maskProcurarTriangulo = maskGreen
    else:
        maskProcurarTriangulo = maskRed
    contours, _ = cv2.findContours(maskProcurarTriangulo, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contornosPequenos = []
    centroTriangulo = [0,0]
    for contour in contours:
        if cv2.contourArea(contour) < 50:
            contornosPequenos.append(contour)
            continue
        var.areaTriangulo = cv2.contourArea(contour)
        rect = cv2.minAreaRect(contour)
        box = np.intp(cv2.boxPoints(rect))
        ordered_box = order_box_points(box)
        expanded_box = expand_box(ordered_box, scale=2)
        cy = int(np.mean(expanded_box[:, 1]))
        cx = int(np.mean(expanded_box[:, 0]))
        centroTriangulo = [cx,cy]
        if abs(cy-height//2) <= 10:
            cv2.drawContours(frame, [ordered_box], 0, (0, 0, 255), 2)
            draw_quadrant_lines_and_labels(frame, box)
    if not contours:
        return frame, [0,0]
    return frame, centroTriangulo 

cap = VideoStream(f"/dev/video_usb2") 

def open_camera():
    global cap
    if cap is not None:
        return cap
    cap = VideoStream("/dev/video_usb2")
    return cap
    