import imports
from imports import *

temp = {
    "classe": None,
    "classe_id": None,
    "diametro": 0,
    "centro": None,
    "conf": None,
    "distanciaCentro": 0
}

imagemIA = None

cap2 = VideoStream(f"/dev/video_usb1")

width = cons.WIDTH_IMAGEM_IA
height = cons.WIDTH_IMAGEM_IA

MODELO_ONNX   = "/home/banana/obr/best.onnx"
CONFIANCA_MIN = 0.7
NMS_LIMIAR    = 0.4
LARG_ENTRADA  = 320
ALT_ENTRADA   = 320

CLASSES = ["Black Ball", "Silver Ball"]

model = cv2.dnn.readNetFromONNX(MODELO_ONNX)
model.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
model.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)

ret, frame = cap2.read()
frame = cv2.resize(frame, (width, height))
var.videoIA = frame.copy()


def detectar_yolov8(frame):
    altura_orig, largura_orig = frame.shape[:2]

    blob = cv2.dnn.blobFromImage(
        frame, scalefactor=1 / 255.0,
        size=(LARG_ENTRADA, ALT_ENTRADA),
        swapRB=True, crop=False
    )
    model.setInput(blob)
    saida = model.forward()
    saida = saida[0].T

    scale_x = largura_orig / LARG_ENTRADA
    scale_y = altura_orig  / ALT_ENTRADA

    scores_classes = saida[:, 4:]
    ids_classes    = np.argmax(scores_classes, axis=1)
    confianças     = scores_classes[np.arange(len(saida)), ids_classes]

    mask = confianças >= CONFIANCA_MIN
    if not np.any(mask):
        return []

    saida_f = saida[mask]
    ids_f   = ids_classes[mask]
    conf_f  = confianças[mask]

    cx   = saida_f[:, 0]; cy   = saida_f[:, 1]
    w    = saida_f[:, 2]; h    = saida_f[:, 3]
    x1   = ((cx - w / 2) * scale_x).astype(np.int32)
    y1   = ((cy - h / 2) * scale_y).astype(np.int32)
    larg = (w * scale_x).astype(np.int32)
    alt  = (h * scale_y).astype(np.int32)

    caixas       = np.stack([x1, y1, larg, alt], axis=1).tolist()
    confianças_l = conf_f.tolist()

    indices = cv2.dnn.NMSBoxes(caixas, confianças_l, CONFIANCA_MIN, NMS_LIMIAR)

    deteccoes = []
    if len(indices) > 0:
        for i in indices.flatten():
            x, y, lw, lh = caixas[i]
            nome = CLASSES[ids_f[i]] if ids_f[i] < len(CLASSES) else str(ids_f[i])
            deteccoes.append({
                "caixa": (x, y, x + lw, y + lh),
                "confianca": confianças_l[i],
                "nome_classe": nome,
                "classe_id": int(ids_f[i]),
            })
    return deteccoes


def conferirImagem():
    ret, frame = cap2.read()
    frame = cv2.resize(frame, (cons.WIDTH_IMAGEM_IA, cons.HEIGHT_IMAGEM_IA))
    start_time = time.time()
    results = detectar_yolov8(frame)

    frame_anotado = frame.copy()
    for det in results:
        x1, y1, x2, y2 = det["caixa"]
        cv2.rectangle(frame_anotado, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(frame_anotado, det["nome_classe"], (x1, y1 - 8),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
    
    var.videoIA = frame_anotado.copy()


    temp["centro"] = None
    temp["diametro"] = 0
    temp["classe"] = None
    temp["classe_id"] = None
    temp["distanciaCentro"] = 0

    for det in results:
        x1, y1, x2, y2 = det["caixa"]
        cls  = det["classe_id"]
        conf = det["confianca"]
        nome = det["nome_classe"]
        dx   = int(abs(x2 - x1))
        cx   = int((x1 + x2) / 2)
        cy   = int((y1 + y2) / 2)
        distanciaCentro = abs(cons.WIDTH_IMAGEM_IA // 2 - cx)

        if cls == 1:
            if (temp["classe_id"] == 0 or (dx > temp["diametro"] and distanciaCentro > temp["distanciaCentro"]) and abs(cy - 120) <= 20):
                print("Salvando prata")
                temp["classe"] = nome
                temp["classe_id"] = cls
                temp["diametro"] = dx
                temp["centro"] = [cx, cy]
                temp["conf"] = round(conf, 2)
        elif temp["classe_id"] != 1:
            if dx > temp["diametro"] and abs(cy - 120) <= 10 and distanciaCentro > temp["distanciaCentro"]:
                print("Salvando preta")
                temp["classe"] = nome
                temp["classe_id"] = cls
                temp["diametro"] = dx
                temp["centro"] = [cx, cy]
                temp["conf"] = round(conf, 2)

    if temp["centro"]:
        print("\nTemp do frame:", temp)
        finalResult = temp.copy()
        centro = tuple(temp["centro"])
        raio = temp["diametro"] // 2
        return finalResult, centro, raio

    fps = 1.0 / (time.time() - start_time)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")

    img_filename = f"/home/banana/imagens/{timestamp}.jpg"
    img_proc_filename = f"/home/banana/imagensProcessadas/{timestamp}.jpg"

    cv2.imwrite(img_filename, frame)
    cv2.imwrite(img_proc_filename, frame_anotado)

    print("Nada encontrado")
    return {"classe": None, "classe_id": None, "diametro": 0, "centro": None, "conf": None}, None, 0