from imports import *
import imports

class VideoStream:
    def __init__(self, src=0):
        self.cap = cv2.VideoCapture(src)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 400)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 300)
        self.cap.set(cv2.CAP_PROP_AUTO_WB, 0) 
        self.cap.set(cv2.CAP_PROP_AUTOFOCUS, 0)
        self.cap.set(cv2.CAP_PROP_FOCUS, 100)
        self.fps = 0

        if not self.cap.isOpened():
            raise ValueError("Não foi possível abrir a câmera.")
                             
        self.ret, self.frame = self.cap.read()
        self.running = True
        Thread(target=self.update, daemon=True).start()

    def update(self):
        semLeitura = False
        while self.running:
            start_time = time.time()
            ret, frame = self.cap.read()
            if ret:
                  self.ret, self.frame = ret, frame
            else: 
                if not semLeitura:
                    print("deu pau")
                    semLeitura = True
                    
            time.sleep(0.025) # Espera 25ms para simular 40 FPS
            self.fps = 1 / (time.time() - start_time)
    
    def read(self):
        return self.ret, self.frame

    def stop(self):
        self.running = False
        self.cap.release()
