import imports
import IA as IA
from imports import *

KP = 2 
KD = 0.45 
KI = 0
ultimoErro = 0

app = Flask(__name__)
frame_atual1 = None
frame_atual2 = None
frame_atual3 = None

lock = threading.Lock()  

os.system("v4l2-ctl -d /dev/video_usb2 -c auto_exposure=1 -c exposure_time_absolute=180")
os.system("v4l2-ctl -d /dev/video_usb1 --set-fmt-video=width=320,height=240,pixelformat=MJPG")

def atualizarCamera():
    ret, frame = cam.cap.read()
    if not ret: 
        print("Falha ao capturar frame")
        return
    return frame

def correcaoDistancia(valor, valorCorrecao=60):
    if valor < 8000:
        return valor - valorCorrecao
    return valor

def lerDistancias(valorCorrecao=60):
    imports.sensorDistanciaEsquerdo.solicita_leitura()
    imports.sensorDistanciaFrontal.solicita_leitura()
    imports.sensorDistanciaDireito.solicita_leitura()
    time.sleep(0.03)
    distanciaEsquerda = imports.sensorDistanciaEsquerdo.leitura_mm()
    distanciaFrontal = imports.sensorDistanciaFrontal.leitura_mm()
    distanciaDireita = imports.sensorDistanciaDireito.leitura_mm()
    distanciaEsquerda = correcaoDistancia(distanciaEsquerda, valorCorrecao)
    distanciaFrontal = correcaoDistancia(distanciaFrontal, valorCorrecao)
    distanciaDireita = correcaoDistancia(distanciaDireita, valorCorrecao)
    return distanciaEsquerda, distanciaFrontal, distanciaDireita

def esperar(tempoEsperar):
    cron.tempoParar.reseta()
    imports.para_motores()
    while cron.tempoParar.tempo() < tempoEsperar:
        continue
    return

def testarCamera():
    try:
        cam.open_camera()
        ret = False
        while not ret:
            ret, frame = cam.cap.read()
            print("capturando frame inicial")
        return ret, frame
    except Exception as e:
        print(f"Erro ao abrir a câmera: {e}")
        return

def processoCorteDeImagem(imagemIA, diametro, centroVitima):
    if var.vitimaEncontrada:
        imagemVitima = imagemIA[(centroVitima[1]-diametro//2)-20:(centroVitima[1]+diametro//2)+20, (centroVitima[0]-diametro//2)-20:(centroVitima[0]+diametro//2)+20]
        return imagemVitima
    return None

def atualizarFrames(imagemIA=None):
    global frame_atual1, frame_atual2, frame_atual3, ultimoErro
    ret, frame = cam.cap.read()
    resultado1 = None
    if not ret:
        print("Falha ao capturar frame")
        return
    if not var.procurandoTriangulo:
        resultado1, erros, mediaErros, noventaGraus = cam.calcularErro(frame)
    elif var.procurandoTriangulo:
        resultado1, var.centroTriangulo = cam.detectarTriangulo(var.trianguloAtual)
    else:
        return
    resultado2, msg = cam.detectar_quadrantes(frame)
    if var.centroVitima:
        if len(var.centroVitima) > 0:
            diametro = var.informacoesVitima["diametro"]
            imagemVitima = processoCorteDeImagem(imagemIA, diametro, var.centroVitima)
    elif frame_atual3 is not None:
        imagemVitima = frame_atual3
    else:
        imagemVitima = None
    with lock:
        if resultado1 is not None:
            frame_atual1 = resultado1.copy()
        if imagemIA is not None:
            print("Atualizando frame_atual2")  
            frame_atual2 = imagemIA.copy()
            if imagemVitima is not None:
                frame_atual3 = imagemVitima.copy()
            else:
                frame_atual3 = None
        else:
            frame_atual2 = resultado2.copy()
    if not var.procurandoTriangulo:
        return [erros, mediaErros, noventaGraus], msg

def SeguirLinha(mediaErros,KP,KD,KI=0,valorIntegral=0):
    negativarEsquerdo = False
    negativarDireito = False
    if mediaErros == "sem linha":
        mediaErros = 0
    if var.ultimoErro == "sem linha":
        var.ultimoErro = 0
    p = mediaErros * KP
    i = valorIntegral*KI
    d = (mediaErros - var.ultimoErro) * KD
    val = p + d
    if abs(imports.giroscopio.le_angulo_y()) >= 4 and abs(imports.giroscopio.le_angulo_y()) <= 8:
        cron.tempoVariacaoRedutor.reseta()
        var.estouNoRedutor = True
    if cron.tempoToVendoVerde.tempo() < 100:
        val //=3
    Velocidade_esquerdo = cons.VELOCIDADE_PADRAO + val
    Velocidade_direito = cons.VELOCIDADE_PADRAO - val
    qtdVezesAcelerou = 20
    if var.acelerarRobo:
        Velocidade_esquerdo *= 2
        Velocidade_direito *= 2
        if Velocidade_direito or Velocidade_esquerdo == 0:
            Velocidade_direito = 20 if Velocidade_direito == 0 else Velocidade_direito
            Velocidade_esquerdo = 20 if Velocidade_esquerdo == 0 else Velocidade_esquerdo
        qtdVezesAcelerou -= 1
    elif qtdVezesAcelerou == 0:
        var.acelerarRobo = False
    valoresGiroscopio = lerValoresGiroscopio()
    return Velocidade_esquerdo, Velocidade_direito, val

def aumentarVelocidadeEnquantoPreso():
    if roboTaPreso.ta_preso():
        print("Robo preso! Acelerando motores...")
        var.acelerarRobo = True
    else:
        var.acelerarRobo = False

def gire4Velocidades(VEF, VET, VDF ,VDT):
    t = threading.Thread(target=motores.velocidade_motores, args=(VET, VDT))
    t.start()
    resultado = motor1.velocidade_motor(VDF)
    t.join()
    resultado = motor2.velocidade_motor(VEF)

def  limitarVelocidadeRampa(Velocidade_esquerdo,Velocidade_direito, velocidademax, velocidademin):
    if Velocidade_esquerdo > velocidademax:
        Velocidade_esquerdo = velocidademax
    elif Velocidade_esquerdo <= velocidademin:
        Velocidade_esquerdo = velocidademin
    if Velocidade_direito > velocidademax:
        Velocidade_direito = velocidademax
    elif Velocidade_direito <= velocidademin:
        Velocidade_direito = velocidademin
    return Velocidade_esquerdo, Velocidade_direito

def extrairResultados(ListaResultados):
    noventaGraus = ListaResultados[2]
    mediaErros = ListaResultados[1]
    erros = ListaResultados[0]
    return noventaGraus, mediaErros, erros

def analisarVerde(possivelVerde):
    if len(possivelVerde) != 2:
        if possivelVerde[0] == "(-x, +y)":
            return "VerdeDireito"
        elif possivelVerde[0] == "(+x, +y)":
            return "VerdeEsquerdo"
        elif "-y)" in possivelVerde[0]:
            return "VerdeFalso"
    elif len(possivelVerde) == 2 and (not "-y)" in possivelVerde[0] and not "-y)" in possivelVerde[1]):
        if possivelVerde[0] ==  "(-x, +y)":
            var.doisVerdeParaDireita = True
        elif possivelVerde[0] ==  "(+x, +y)":
            var.doisVerdeParaEsquerda = True
        return "DoisVerdes"
    return "sem verde"

def avisoVerdeInicial(tipoDeAviso):
    imports.para_motores()
    if tipoDeAviso == "DoisVerdes":
        for i in (0,8):
            imports.motores.set_led_rgb_one(i,0, 255, 0)
            time.sleep(0.3)
        for i in (0,8):
            imports.motores.set_led_rgb_one(i,0, 0, 0)
    elif tipoDeAviso == "VerdeDireito":
            imports.motores.set_led_rgb_one(0,0, 255, 0)
            time.sleep(0.3)
            imports.motores.set_led_rgb_one(0,0, 0, 0)
    elif tipoDeAviso == "VerdeEsquerdo":
        imports.motores.set_led_rgb_one(0,0, 255, 0)
        time.sleep(0.3)
        imports.motores.set_led_rgb_one(0,0, 0, 0)
    elif tipoDeAviso == "terminouVerde":
        imports.motores.set_led_rgb_one(0,0, 0, 255)
        imports.motores.set_led_rgb_one(8,0, 0, 255)
        time.sleep(0.3)
        imports.motores.set_led_rgb_one(0,0, 0, 0)
        imports.motores.set_led_rgb_one(8,0, 0, 0)

def movimentoGiroVerde(direcao):
    if direcao in ("VerdeDireito", "VerdeEsquerdo","DoisVerdes"):
        direcaoVerde = direcao
        possiveisDirecoes = [0]
        velocidadeGiro = cons.VELOCIDADE_GIRO_PADRAO
        if direcao == "VerdeDireito":
            valoresGirarVerde = [velocidadeGiro, -velocidadeGiro, cons.VALOR_GIRO_CEGO, "Direito", cons.DIRECAO_DIREITA, var.qtdPretoFinalizarNoventaDireito]
        elif direcao == "VerdeEsquerdo":
            valoresGirarVerde = [-velocidadeGiro, velocidadeGiro, cons.VALOR_GIRO_CEGO, "Esquerdo", cons.DIRECAO_ESQUERDA, var.qtdPretoFinalizarNoventaEsquerdo]
        else:
            valoresGirarVerde = [-velocidadeGiro//1.5, velocidadeGiro//1.5, cons.VALOR_GIRO_CEGO_DOIS_VERDES, "Esquerdo", cons.DIRECAO_ESQUERDA, var.qtdPretoFinalizarNoventaEsquerdo]
        imports.motores.reseta_angulo_motor(imports.MOTOR_DIREITO)
        imports.motores.reseta_angulo_motor(imports.MOTOR_ESQUERDO)
        valoresGiroscopio = lerValoresGiroscopio()
        if conferirInclinacao(valoresGiroscopio):
            velocidadeGiro = cons.VELOCIDADE_GIRO_RAMPA
            if var.rampaSubida:
                andePorCertaDistancia(cons.VELOCIDADE_RAMPA, cons.DISTANCIA_AJUSTE_GIRO*2.4, cons.DIRECAO_FRENTE)
                if not direcao == "DoisVerdes":
                    while abs(valoresGiroscopio[cons.ANGULO_X]) < 19:
                        gire4Velocidades(cons.VELOCIDADE_RAMPA, velocidadeGiro*valoresGirarVerde[4], cons.VELOCIDADE_RAMPA, -velocidadeGiro*valoresGirarVerde[4])
                        valoresGiroscopio = lerValoresGiroscopio()
                    imports.para_motores()
                    andePorCertaDistancia(cons.VELOCIDADE_RAMPA, cons.DISTANCIA_AJUSTE_GIRO*1.5, cons.DIRECAO_TRAS)
                    andeAteVerPreto(cons.VELOCIDADE_RAMPA, cons.DIRECAO_TRAS)
                    cron.tempoFezVerde.reseta()
                    return False
            elif var.rampaDeLado:
                if not direcao == "DoisVerdes":
                    valoresGiroscopio = lerValoresGiroscopio()
                    conferirInclinacao(valoresGiroscopio)
                    direcao = valoresGiroscopio[cons.ANGULO_X]/abs(valoresGiroscopio[cons.ANGULO_X])
                    if direcao == cons.DIRECAO_ESQUERDA:
                        if direcaoVerde == "VerdeDireito":
                            direcao = cons.DIRECAO_DIREITA
                        else:
                            direcao = cons.DIRECAO_ESQUERDA
                    else:
                        if direcaoVerde == "VerdeDireito":
                            direcao = cons.DIRECAO_ESQUERDA
                        else:
                            direcao = cons.DIRECAO_DIREITA
                    anguloInicial = valoresGiroscopio[cons.ANGULO_X]
                    while abs(valoresGiroscopio[cons.ANGULO_X])+1 > abs(valoresGiroscopio[cons.ANGULO_Y]):
                        valoresGiroscopio = lerValoresGiroscopio()
                        gire4Velocidades(cons.VELOCIDADE_GIRO_RAMPA*direcao, cons.VELOCIDADE_GIRO_RAMPA*direcao, -cons.VELOCIDADE_GIRO_RAMPA*direcao, -cons.VELOCIDADE_GIRO_RAMPA*direcao)
                    andePorCertaDistancia(cons.VELOCIDADE_RAMPA, cons.DISTANCIA_AJUSTE_GIRO, cons.DIRECAO_FRENTE)
                    imports.para_motores()
                    return False
                else:
                    valoresGiroscopio = lerValoresGiroscopio()
                    conferirInclinacao(valoresGiroscopio)
                    direcao = valoresGiroscopio[cons.ANGULO_X]/abs(valoresGiroscopio[cons.ANGULO_X])
                    anguloInicial = valoresGiroscopio[cons.ANGULO_X]
                    while abs(valoresGiroscopio[cons.ANGULO_X])+8 > abs(valoresGiroscopio[cons.ANGULO_Y]):
                        valoresGiroscopio = lerValoresGiroscopio()
                        gire4Velocidades(cons.VELOCIDADE_RAMPA*direcao, cons.VELOCIDADE_GIRO_RAMPA*direcao, -cons.VELOCIDADE_RAMPA*direcao, -cons.VELOCIDADE_GIRO_RAMPA*direcao)
                    imports.para_motores()
                    andePorCertaDistancia(cons.VELOCIDADE_RAMPA, cons.DISTANCIA_AJUSTE_GIRO*3.5, cons.DIRECAO_FRENTE)       
                    while abs(valoresGiroscopio[cons.ANGULO_X]) < 19:
                        gire4Velocidades(cons.VELOCIDADE_RAMPA, cons.VELOCIDADE_GIRO_RAMPA*direcao, -cons.VELOCIDADE_RAMPA, -cons.VELOCIDADE_GIRO_RAMPA*direcao)
                        valoresGiroscopio = lerValoresGiroscopio()
                    imports.para_motores()
                    andePorCertaDistancia(cons.VELOCIDADE_RAMPA, cons.DISTANCIA_AJUSTE_GIRO*1.5, cons.DIRECAO_TRAS)
                    andeAteVerPreto(cons.VELOCIDADE_RAMPA, cons.DIRECAO_TRAS)
                    cron.tempoFezVerde.reseta()
                    return
        if not direcao == "DoisVerdes":
            resetaTrens()
            posicaoIncial = imports.giroscopio.le_angulo_z()
            gireAnguloGiroscopio(cons.VELOCIDADE_GIRO_PADRAO,valoresGirarVerde[4],valoresGirarVerde[2])
            ListaResultados, VerdeEncontrado = atualizarFrames()
            noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
            acheiLinha = var.qtdPretoFinalizarNoventa
            while (acheiLinha < 0.4 and abs((abs(posicaoIncial) - abs(imports.giroscopio.le_angulo_z()))) < 85) or abs((abs(posicaoIncial) - abs(imports.giroscopio.le_angulo_z()))) < 58:
                acheiLinha = var.qtdPretoFinalizarNoventa
                ListaResultados, VerdeEncontrado = atualizarFrames()
                noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
                imports.velocidade_motores_encoder(valoresGirarVerde[0], valoresGirarVerde[1])
            imports.para_motores()
            andePorCertaDistancia(cons.VELOCIDADE_RAMPA, cons.DISTANCIA_AJUSTE_POS_GIRO, cons.DIRECAO_TRAS)
            ListaResultados, VerdeEncontrado = atualizarFrames()
            noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
            VerdeEncontrado = analisarVerde(VerdeEncontrado)
            esperar(200)
            print("Curva bem sucedida!",direcao)
            cron.tempoFezVerde.reseta()
            return False
        else:
            andePorCertaDistancia(cons.VELOCIDADE_PADRAO,67,cons.DIRECAO_FRENTE)
            resetaTrens()
            if var.doisVerdeParaDireita == True:
                direcao = 1
            elif var.doisVerdeParaEsquerda == True:
                direcao = -1
            gireAnguloGiroscopio(cons.VELOCIDADE_GIRO_PADRAO,direcao,valoresGirarVerde[2])
            imports.para_motores()
            ret, frame = testarCamera()
            ListaResultados, VerdeEncontrado = atualizarFrames()
            noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
            while possiveisDirecoes[0] < 0.01 and abs(imports.giroscopio.le_angulo_z()) < 85:
                possiveisDirecoes[0] = var.qtdPretoFinalizarNoventaDireito if valoresGirarVerde[3] == "Direito" else var.qtdPretoFinalizarNoventaEsquerdo
                ListaResultados, VerdeEncontrado = atualizarFrames()
                noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
                imports.velocidade_motores_encoder(valoresGirarVerde[0], valoresGirarVerde[1])
                print('Valor giroscópio no giro do verde: ', imports.giroscopio.le_angulo_z())
            imports.para_motores()
            while possiveisDirecoes[0] > 0.01:
                possiveisDirecoes[0] = var.qtdPretoFinalizarNoventaDireito if valoresGirarVerde[3] == "Direito" else var.qtdPretoFinalizarNoventaEsquerdo
                ListaResultados, VerdeEncontrado = atualizarFrames()
                noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
                imports.velocidade_motores_encoder(valoresGirarVerde[0], valoresGirarVerde[1])
                print('Valor giroscópio no giro do verde: ', imports.giroscopio.le_angulo_z())
            imports.para_motores()
            return False
    else:
        return False

def andarDistanciaConferindo(velocidade,distancia,direcao):
    imports.motores.reseta_angulo_motor((imports.MOTOR_DIREITO))
    imports.motores.reseta_angulo_motor((imports.MOTOR_ESQUERDO))
    imports.motor1.reseta_angulo_motor()
    imports.motor2.reseta_angulo_motor()
    distanciaInicial = abs(imports.motores.angulo_motor(imports.MOTOR_DIREITO))
    proporcao = 0.8
    while (abs(imports.motores.angulo_motor(imports.MOTOR_DIREITO)) - distanciaInicial)*proporcao < distancia:
        ListaResultados, VerdeEncontrado = atualizarFrames()
        noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
        VerdeEncontrado = analisarVerde(VerdeEncontrado)
        if VerdeEncontrado == "DoisVerdes":
            return VerdeEncontrado
        imports.velocidade_motores_encoder(velocidade*direcao,velocidade*direcao)
    print(f"Distância percorrida: {abs(imports.motores.angulo_motor(imports.MOTOR_DIREITO)) - distanciaInicial}")
    imports.para_motores()

def andePorCertaDistancia(velocidade,distancia,direcao):
    imports.motores.reseta_angulo_motor((imports.MOTOR_DIREITO))
    imports.motores.reseta_angulo_motor((imports.MOTOR_ESQUERDO))
    imports.motor1.reseta_angulo_motor()
    imports.motor2.reseta_angulo_motor()
    distanciaInicial = abs(imports.motores.angulo_motor(imports.MOTOR_DIREITO))
    proporcao = 0.8
    while (abs(imports.motores.angulo_motor(imports.MOTOR_DIREITO)) - distanciaInicial)*proporcao < distancia:
        imports.velocidade_motores_encoder(velocidade*direcao,velocidade*direcao)
    imports.para_motores()

def gireAnguloMotor(velocidade,distancia,direcao):
    imports.motores.reseta_angulo_motor((imports.MOTOR_DIREITO))
    imports.motores.reseta_angulo_motor((imports.MOTOR_ESQUERDO))
    posicaoInicial = abs(imports.motores.angulo_motor(imports.MOTOR_DIREITO))
    while (abs(imports.motores.angulo_motor(imports.MOTOR_DIREITO)) - posicaoInicial) < distancia:
        imports.velocidade_motores_encoder(velocidade*direcao,-velocidade*direcao)
    imports.para_motores()

def andeAteVerPreto(velocidade,direcao=1):
    ret, frame = testarCamera()
    ListaResultados, VerdeEncontrado = atualizarFrames()
    noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
    if direcao == cons.DIRECAO_TRAS:
        erros[0] = "sem linha"
        erroEscolhido = 0
    else:
        erros[2] = "sem linha"
        erroEscolhido = 2
    imports.motores.reseta_angulo_motor((imports.MOTOR_DIREITO))
    while erros[erroEscolhido] == "sem linha":
        ListaResultados, VerdeEncontrado = atualizarFrames()
        noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
        imports.velocidade_motores_encoder(velocidade*direcao,velocidade*direcao)
        valorTorto = erros[erroEscolhido]
    valorTorto = (erros[erroEscolhido])
    if var.verdeFalso:
        valorTorto //= 2
    if erros[erroEscolhido] != 0:
        tortoPara = abs(erros[erroEscolhido])/erros[erroEscolhido]
    else:
        tortoPara = False
    imports.para_motores()
    return tortoPara, abs(valorTorto)

def alinharGap():
    imports.para_motores()
    tortoPara, valorTorto = andeAteVerPreto(60,cons.DIRECAO_TRAS)
    esperar(300)
    resetaTrens()
    return

def gire(velocidade,direcao):
    imports.velocidade_motores_encoder(velocidade*direcao,-velocidade*direcao)

def gireAnguloGiroscopio(velocidade,direcao,angulo):
    resetaTrens()
    while abs(imports.giroscopio.le_angulo_z()) < angulo-15:
        gire(velocidade,direcao)
    while abs(imports.giroscopio.le_angulo_z()) < angulo:
        gire(velocidade//2,direcao)
    imports.para_motores()

def gireAnguloGiroscopio4Velocidades(velocidades,angulo):
    resetaTrens()
    while abs(imports.giroscopio.le_angulo_z()) < angulo-15:
        gire4Velocidades(velocidades[0], velocidades[1], velocidades[2], velocidades[3])
    while abs(imports.giroscopio.le_angulo_z()) < angulo:
        gire4Velocidades(velocidades[0], velocidades[1], velocidades[2], velocidades[3])
    imports.para_motores()

def gireAjeitarNoventa(velocidade,direcao,angulo):
    resetaTrens()
    esperar(500)
    if direcao == 1:
        while abs(imports.giroscopio.le_angulo_z()) < angulo:
            imports.velocidade_motores_encoder(0,-velocidade//3)
    else:
        while abs(imports.giroscopio.le_angulo_z()) < angulo:
            imports.velocidade_motores_encoder(-velocidade//3,0)
def resetaTrens():
 
    imports.motores.reseta_angulo_motor(imports.MOTOR_ESQUERDO)
    imports.motores.reseta_angulo_motor(imports.MOTOR_DIREITO)
    imports.giroscopio.reseta_z()
    var.resetarErro = True

def ligarLeds():
    for i in (2,3,4,5):
        imports.motores.set_led_rgb_one(i,127, 127, 50)
    for i in (0,1,6,7):
        imports.motores.set_led_rgb_one(i,0, 0, 0)

def depositarVitima(tipoVitima, qtdDepositos=4):
    for depositar in range(qtdDepositos):
        abrirCacamba(tipoVitima)    
        andePorCertaDistancia(-cons.VELOCIDADE_DEPOSITAR, cons.DISTANCIA_AJUSTAR_TRIANGULO//2, cons.DIRECAO_TRAS)
        time.sleep(3)
        fecharCacamba()
        andePorCertaDistancia(-cons.VELOCIDADE_DEPOSITAR, cons.DISTANCIA_AJUSTAR_TRIANGULO//2, cons.DIRECAO_FRENTE)
        time.sleep(0.5)

def ajeitarTriangulo(parachoqueEncostado):
    if parachoqueEncostado == var.parachoqueDireito:
        velocidadesGirar = [0, 0, cons.VELOCIDADE_AREA, cons.VELOCIDADE_AREA]
        gireAnguloGiroscopio4Velocidades(velocidadesGirar, cons.ANGULO_AJEITAR_TRIANGULO)
    else:
        velocidadesGirar = [cons.VELOCIDADE_AREA, cons.VELOCIDADE_AREA, 0, 0]
        gireAnguloGiroscopio4Velocidades(velocidadesGirar, cons.ANGULO_AJEITAR_TRIANGULO)

def andeDepositeVitima(tipoVitima):
    while True:
        if var.parachoqueEsquerdo and cron.tempoConferirOutroParachoque.tempo() > var.tempoConferirParachoqueInvertido + 700:
            outroParachoque = var.parachoqueDireito
            cron.tempoConferirOutroParachoque.reseta()
        elif var.parachoqueDireito and cron.tempoConferirOutroParachoque.tempo() > var.tempoConferirParachoqueInvertido + 700:
            outroParachoque = var.parachoqueEsquerdo
            cron.tempoConferirOutroParachoque.reseta()
        elif not var.parachoqueDireito and not var.parachoqueEsquerdo and cron.tempoConferirOutroParachoque.tempo() > var.tempoConferirParachoqueInvertido + 700:
            outroParachoque = False
        if cron.tempoConferirOutroParachoque.tempo() < var.tempoConferirParachoqueInvertido:
            if outroParachoque:
                depositarVitima(tipoVitima, cons.QUANTIDADE_DEPOSITOS)
                return
        elif cron.tempoConferirOutroParachoque.tempo() > var.tempoConferirParachoqueInvertido and outroParachoque:
            ajeitarTriangulo(outroParachoque) 
        imports.velocidade_motores_encoder(-cons.VELOCIDADE_AREA, -cons.VELOCIDADE_AREA)

def acheiPrata():
    if var.pegouPrataReflexivo:
        imports.para_motores()
        valoresGiroscopio = lerValoresGiroscopio()
        var.estouNaRampa = conferirInclinacao(valoresGiroscopio)
        if var.estouNaRampa:
            while var.estouNaRampa:
                valoresGiroscopio = lerValoresGiroscopio()
                var.estouNaRampa = conferirInclinacao(valoresGiroscopio)
                imports.velocidade_motores_encoder(cons.VELOCIDADE_PADRAO, cons.VELOCIDADE_PADRAO)
        else:
            andePorCertaDistancia(cons.VELOCIDADE_PADRAO,450,cons.DIRECAO_FRENTE)
            gireAnguloGiroscopio(cons.VELOCIDADE_GIRO_PADRAO,cons.DIRECAO_DIREITA,180)
            gireProcurandoVitima()
            gireProcurandoTriangulo(cons.TRIANGULO_VERDE)
            andeDepositeVitima(cons.VITIMA_VIVA)
            gireProcurandoTriangulo(cons.TRIANGULO_VERMELHO)
            andeDepositeVitima(cons.VITIMA_MORTA)
        esperar(15000)

def encontreiObstaculo(distanciaMinimaObstaculo):
    if var.distanciaFrontal < distanciaMinimaObstaculo:
        return True

def desvioDoObstaculo():
    imports.para_motores()
    gireAnguloGiroscopio(80,cons.DIRECAO_DIREITA,50)
    andePorCertaDistancia(80,80,cons.DIRECAO_FRENTE)
    ListaResultados, VerdeEncontrado = atualizarFrames()
    noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
    errosFlask = f"ERROS: {erros}"
    mediaErrosFlask = f"MEDIA ERROS: {mediaErros}"
    while erros[0] == "sem linha":
        ListaResultados, VerdeEncontrado = atualizarFrames()
        noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
        errosFlask = f"ERROS: {erros}"
        mediaErrosFlask = f"MEDIA ERROS: {mediaErros}"
        imports.velocidade_motores_encoder(20, 100)
    while erros[2] != "sem linha":
        ListaResultados, VerdeEncontrado = atualizarFrames()
        noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
        errosFlask = f"ERROS: {erros}"
        mediaErrosFlask = f"MEDIA ERROS: {mediaErros}"
        imports.velocidade_motores_encoder(80, 80)
    andePorCertaDistancia(80,200,cons.DIRECAO_FRENTE)
    gireAnguloGiroscopio(80,cons.DIRECAO_DIREITA,45)
tempocontador=int(time.time()*1000)
contador=0

def contadorDeCiclos():
    global contador, tempocontador
    contador+=1
    if int(time.time()*1000) - tempocontador > 1000: 
        print("ciclos",contador)
        contador = 0
        tempocontador= int(time.time()*1000)

def atualizarDistancias():
    while True:
        var.leituraThreadSensor = True
        var.distanciaEsquerda, var.distanciaFrontal, var.distanciaDireita = lerDistancias()
        var.leituraThreadSensor = False
        time.sleep(0.01)

def conferirRampa(variacaoMinimaRampa):
    if imports.giroscopio.le_angulo_y() > variacaoMinimaRampa:
        var.rampaSubida = True
    elif imports.giroscopio.le_angulo_y() < -variacaoMinimaRampa:
        var.rampaDescida = True
    else:
        var.rampaSubida = False
        var.rampaDescida = False

def andeAteObjeto(velocidade, centroImagem, centroObjeto, diametroVitima, KPVitima):
    erro = (centroImagem - centroObjeto)
    valorDiferenca = erro*KPVitima
    if abs(valorDiferenca) > 27:
        valorDiferenca //= 1.7
    velocidadeEsquerda = velocidade - valorDiferenca
    velocidadeDireita = velocidade + valorDiferenca
    imports.velocidade_motores_encoder(velocidadeEsquerda,velocidadeDireita)

def procurarVitima():
    var.informacoesVitima, var.centroVitima, raio = IA.conferirImagem()
    atualizarFrames(var.videoIA)
    return var.informacoesVitima, var.centroVitima, raio 

def voltarParaArea(distanciaFinal, distanciaInicial, proporcao=1):
    if var.distanciaFrontal > cons.DISTANCIA_MINIMA_SAIDA:
        distanciaRestante = distanciaFinal - ((abs(imports.motores.angulo_motor(imports.MOTOR_DIREITO)) - distanciaInicial)*proporcao) 
        andePorCertaDistancia(-cons.VELOCIDADE_PADRAO, 100, cons.DIRECAO_FRENTE)
        gireAnguloGiroscopio(cons.VELOCIDADE_PADRAO, cons.DIRECAO_ESQUERDA, 90)
        imports.motores.reseta_angulo_motor((imports.MOTOR_DIREITO))
        distanciaFinal = distanciaRestante
    return distanciaFinal

def andeConferindo(velocidade, distanciaFinal, direcao, conferirPreto=True, conferirPrata=True, conferirParachoque=False):
    imports.motores.reseta_angulo_motor((imports.MOTOR_DIREITO))
    imports.motores.reseta_angulo_motor((imports.MOTOR_ESQUERDO))
    imports.motor1.reseta_angulo_motor()
    imports.motor2.reseta_angulo_motor()
    distanciaInicial = abs(imports.motores.angulo_motor(imports.MOTOR_DIREITO))
    imports.motores.set_led_rgb_all(255,255,255)
    time.sleep(1)
    cron.tempoAndandoConferindo.reseta()
    tempoMaximoAndarConferindo = cons.TEMPO_MAXIMO_ANDAR_CONFERINDO
    while ((abs(imports.motores.angulo_motor(imports.MOTOR_DIREITO)) - distanciaInicial) < distanciaFinal) and cron.tempoAndandoConferindo.tempo() < tempoMaximoAndarConferindo:
        contadorDeCiclos()
        ListaResultados, VerdeEncontrado = atualizarFrames()
        noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
        errosFlask = f"ERROS: {erros}"
        mediaErrosFlask = f"MEDIA ERROS: {mediaErros}"
        VerdeEncontrado = analisarVerde(VerdeEncontrado)
        if (erros[0] != "sem linha" and conferirPreto == True) or (var.pegouPrataReflexivo and conferirPrata == True):
            print(f"Valor de erro: {erros[0]}| Pegou prata: {var.pegouPrataReflexivo}")
            tempoRestante = cons.TEMPO_MAXIMO_ANDAR_CONFERINDO - cron.tempoAndandoConferindo.tempo()
            tempoMaximoAndarConferindo = tempoRestante
            cron.tempoAndandoConferindo.reseta()
            distanciaRestante = voltarParaArea(distanciaFinal, distanciaInicial)
            distanciaFinal = distanciaRestante
            return False
        if var.distanciaFrontal < 100:
            distanciaRestante = distanciaFinal - ((abs(imports.motores.angulo_motor(imports.MOTOR_DIREITO)) - distanciaInicial)) 
            distanciaFinal = distanciaRestante
            tempoRestante = cons.TEMPO_MAXIMO_ANDAR_CONFERINDO - cron.tempoAndandoConferindo.tempo()
            tempoMaximoAndarConferindo = tempoRestante
            cron.tempoAndandoConferindo.reseta()
            gireAnguloGiroscopio(cons.VELOCIDADE_PADRAO, cons.DIRECAO_ESQUERDA, 90)
            resetaTrens()
        imports.velocidade_motores_encoder(velocidade*direcao,velocidade*direcao)
    imports.para_motores()
    return True

def procurarOutroPontoDeObservacao():
    valorGirarAngulo = random.randint(50,90)
    gireAnguloGiroscopio(-cons.VELOCIDADE_PADRAO, cons.DIRECAO_DIREITA, valorGirarAngulo)
    proximoPonto = random.randint(400,600)
    var.procurandoTriangulo = False
    andeConferindo(cons.VELOCIDADE_PADRAO, proximoPonto, cons.DIRECAO_FRENTE, cons.CONFERIR_PRETO, cons.CONFERIR_PRATA)

def abaixarGarra():
    imports.servoCentralGarra.move_servo(cons.POSICAO_GARRA_C_ABAIXADA, 200, cons.DELTA_SERVOS)
    time.sleep(0.1)
    imports.servoCentralGarra.move_servo(cons.POSICAO_GARRA_C_ABAIXADA+20, 255, cons.DELTA_SERVOS)

def abrirGarra():
    imports.servoEsquerdoGarra.move_servo(cons.POSICAO_GARRA_E_ABERTA, 200, cons.DELTA_SERVOS)
    imports.servoDireitoGarra.move_servo(cons.POSICAO_GARRA_D_ABERTA, 200, cons.DELTA_SERVOS)

def abrirGarraPegarVitima():
    imports.servoEsquerdoGarra.move_servo(580, 200, 20)
    imports.servoDireitoGarra.move_servo(550, 200, 20)

def fechargarra():
    imports.servoEsquerdoGarra.move_servo(cons.POSICAO_GARRA_E_FECHADA, 200, cons.DELTA_SERVOS)
    imports.servoDireitoGarra.move_servo(cons.POSICAO_GARRA_D_FECHADA, 200, cons.DELTA_SERVOS)

def levantarGarra():
    imports.servoCentralGarra.move_servo(cons.POSICAO_GARRA_C_LEVANTADA, 255, cons.DELTA_SERVOS)

def setarGarra():
    imports.servoCentralGarra.move_servo(cons.POSICAO_GARRA_C_LEVANTADA, 255, cons.DELTA_SERVOS)
    fecharCacamba()
    abrirGarra()

def decidirLadoVitima(tipoVitima):
    if tipoVitima == cons.VITIMA_VIVA:
        posicaoServoVitima, servoVitima = cons.POSICAO_GARRA_D_VITIMA_VIVA, imports.servoDireitoGarra
        posicaoServoContrario, servoContrario, posicaoServoContrarioAberto = cons.POSICAO_GARRA_E_VITIMA_VIVA, imports.servoEsquerdoGarra, cons.POSICAO_GARRA_E_ABERTA
    elif tipoVitima == cons.VITIMA_MORTA:
        posicaoServoVitima, servoVitima = cons.POSICAO_GARRA_E_VITIMA_MORTA, imports.servoEsquerdoGarra
        posicaoServoContrario, servoContrario, posicaoServoContrarioAberto = cons.POSICAO_GARRA_D_VITIMA_MORTA, imports.servoDireitoGarra, cons.POSICAO_GARRA_D_ABERTA
    if not posicaoServoVitima:
        print("VITIMA INVALIDA")
        return
    servoContrario.move_servo(posicaoServoContrario, 170, cons.DELTA_SERVOS)
    servoVitima.move_servo(posicaoServoVitima, 170, cons.DELTA_SERVOS)
    time.sleep(0.5)
    servoContrario.move_servo(posicaoServoContrarioAberto, 170, cons.DELTA_SERVOS)
    time.sleep(0.5)
    abrirGarra()
    time.sleep(1)

def afrouxarGarra():
    imports.servoEsquerdoGarra.move_servo(cons.POSICAO_GARRA_E_ABERTA, 50, cons.DELTA_SERVOS)
    imports.servoDireitoGarra.move_servo(cons.POSICAO_GARRA_D_ABERTA, 50, cons.DELTA_SERVOS)

def pegarVitima(tipoVitima):
    abrirGarra()
    time.sleep(0.5)
    afrouxarGarra()
    time.sleep(0.6)
    abaixarGarra()
    time.sleep(0.6)
    posicaoServo = servoCentralGarra.le_posicao()
    if abs(posicaoServo - cons.POSICAO_GARRA_C_ABAIXADA) > 30:
        levantarGarra()
        time.sleep(0.6)
        andePorCertaDistancia(-50, cons.DISTANCIA_PEGAR_VITIMA-100, cons.DIRECAO_TRAS)
        imports.para_motores()
        while servoCentralGarra.le_posicao() > cons.POSICAO_GARRA_C_ABAIXADA + 21:
            abaixarGarra()
            continue
    abrirGarraPegarVitima()
    andePorCertaDistancia(-cons.VELOCIDADE_PADRAO, cons.DISTANCIA_PEGAR_VITIMA, cons.DIRECAO_FRENTE)
    fechargarra()
    time.sleep(0.5)
    andePorCertaDistancia(cons.VELOCIDADE_PADRAO, cons.DISTANCIA_PEGAR_VITIMA//2, cons.DIRECAO_FRENTE)
    fechargarra()
    andePorCertaDistancia(cons.VELOCIDADE_PADRAO, cons.DISTANCIA_PEGAR_VITIMA//2, cons.DIRECAO_FRENTE)
    time.sleep(0.6)
    levantarGarra()
    time.sleep(2.5)
    decidirLadoVitima(tipoVitima)
    setarGarra()

def conferirInclinacao(valoresGiroscopio):
    inclinou = False
    if abs(valoresGiroscopio[cons.ANGULO_X])> abs(valoresGiroscopio[cons.ANGULO_Y]):
        if abs(valoresGiroscopio[cons.ANGULO_X]) > cons.MINIMO_VARICAO_RAMPA:
            var.rampaDeLado = True
            var.rampaDescida = False
            var.rampaSubida = False
    elif valoresGiroscopio[cons.ANGULO_Y] <= -cons.MINIMO_VARICAO_RAMPA:
        var.rampaDescida = True
        var.rampaDeLado = False
        var.rampaSubida = False
    elif valoresGiroscopio[cons.ANGULO_Y] > cons.MINIMO_VARICAO_RAMPA:
        var.rampaSubida = True
        var.rampaDeLado = False
        var.rampaDescida = False
    else:
        var.rampaDeLado = False
        var.rampaDescida = False
        var.rampaSubida = False
    if var.rampaDeLado or var.rampaDescida or var.rampaSubida:
        inclinou = True
    return inclinou

def lerValoresGiroscopio():
    return [imports.giroscopio.le_angulo_x(), imports.giroscopio.le_angulo_y(), imports.giroscopio.le_angulo_z()]

def lerValoresBotoes():
    while True:
        var.parachoqueEsquerdo = botoes.botao_pressionado(botoes.P1)
        var.parachoqueDireito = botoes.botao_pressionado(botoes.P8)
        time.sleep(0.02)
        if var.finalizarCodigo:
            exit()    

def gireProcurandoTriangulo(tipoTriangulo):
    anguloInicial = 0
    while True:
        setarGarra()
        var.procurandoTriangulo = True
        var.trianguloAtual = tipoTriangulo
        atualizarFrames()
        imagem, var.centroTriangulo = cam.detectarTriangulo(var.trianguloAtual)
        distanciaCentro = cons.WIDTH_IMAGEM//2 - var.centroTriangulo[0]
        if var.centroTriangulo[0] != 0:
            if abs(distanciaCentro) != 0:
                gireAnguloGiroscopio(-cons.VELOCIDADE_PADRAO,abs(distanciaCentro)/(distanciaCentro),abs(distanciaCentro)*0.5)
            framesSemVitima = 0
            while var.areaTriangulo < 5000 and framesSemVitima < 3:
                print(var.areaTriangulo)
                if var.centroTriangulo[0] != 0:
                    andeAteObjeto(cons.VELOCIDADE_AREA*2, cons.WIDTH_IMAGEM//2, var.centroTriangulo[0], 0, cons.KP_VITIMA)
                imagem, var.centroTriangulo = cam.detectarTriangulo(var.trianguloAtual)
                if var.centroTriangulo[0] == 0:
                    framesSemVitima += 1
            if framesSemVitima > 3:
                continue
            andePorCertaDistancia(cons.VELOCIDADE_AREA, cons.DISTANCIA_AJUSTE_GIRO, cons.DIRECAO_FRENTE)
            andePorCertaDistancia(cons.VELOCIDADE_AREA, cons.DISTANCIA_AJUSTAR_TRIANGULO, cons.DIRECAO_TRAS)
            gireAnguloGiroscopio(cons.VELOCIDADE_GIRO_PADRAO,cons.DIRECAO_DIREITA,180)
            return
        if anguloInicial < 360:
            imagem, var.centroTriangulo = cam.detectarTriangulo(var.trianguloAtual)
            if var.centroTriangulo[0] != 0:
                continue
            gireAnguloGiroscopio(cons.VELOCIDADE_PADRAO, cons.DIRECAO_GIRAR_AREA, cons.ANGULO_GIRAR_AREA)
            esperar(500)
            anguloInicial+=cons.ANGULO_GIRAR_AREA
        else:
            imagem, var.centroTriangulo = cam.detectarTriangulo(var.trianguloAtual)
            if var.centroTriangulo[0] != 0:
                continue
            procurarOutroPontoDeObservacao()
            anguloInicial = 0
            esperar(1000)
            imagem, var.centroTriangulo = cam.detectarTriangulo(var.trianguloAtual)

def vitimaJaDepositada(tipoVitima):
    if tipoVitima == cons.VITIMA_VIVA:
        if var.qtdVitimasVivasCapturadas is not None and var.qtdVitimasVivasCapturadas >= 2:
            return True
    elif tipoVitima == cons.VITIMA_MORTA:
        if var.qtdVitimasMortasCapturadas is not None and var.qtdVitimasMortasCapturadas >= 1:
            return True
    return False

def gireProcurandoVitima():
    anguloInicial = 0
    while var.qtdVitimasMortasCapturadas < 1 or var.qtdVitimasVivasCapturadas < 2:
        setarGarra()
        if var.centroVitima and not vitimaJaDepositada(var.informacoesVitima["classe_id"]):
            vitimaAtual = var.informacoesVitima["classe_id"]
            distanciaCentro = cons.WIDTH_IMAGEM_IA//2 - var.centroVitima[0]
            if abs(distanciaCentro) != 0:
                gireAnguloGiroscopio(-cons.VELOCIDADE_PADRAO,abs(distanciaCentro)/(distanciaCentro),abs(distanciaCentro)*0.16)
            var.informacoesVitima, var.centroVitima, raio = procurarVitima()
            framesSemVitima = 0
            while raio < 28 and framesSemVitima < 3:
                if var.centroVitima:
                    andeAteObjeto(cons.VELOCIDADE_AREA, cons.WIDTH_IMAGEM_IA//2, var.centroVitima[0], raio, cons.KP_VITIMA)
                var.informacoesVitima, var.centroVitima, raio = procurarVitima()
                if raio == 0:
                    framesSemVitima += 1
            if not raio == 0:
                imports.para_motores()
                var.informacoesVitima, var.centroVitima, raio = procurarVitima()
                distanciaAjeitar = (raio - 28)*1.53
                if distanciaAjeitar != 0:
                    direcao = (distanciaAjeitar/abs(distanciaAjeitar))
                    andePorCertaDistancia(cons.VELOCIDADE_PADRAO, distanciaAjeitar*4, direcao)
                    esperar(1000)
                    var.informacoesVitima, var.centroVitima, raio = procurarVitima()
                if var.centroVitima:
                    distanciaCentro = cons.WIDTH_IMAGEM_IA//2 - var.centroVitima[0]
                    if abs(distanciaCentro) != 0:
                        gireAnguloGiroscopio(-cons.VELOCIDADE_PADRAO,abs(distanciaCentro)/(distanciaCentro),abs(distanciaCentro)*0.16)
                    var.vitimaEncontrada = True
                    vitimaAtual = var.informacoesVitima["classe_id"]
                    pegarVitima(vitimaAtual)
                    if var.informacoesVitima["classe_id"] == cons.VITIMA_VIVA:
                        var.ultimaVitimaEncontrada = "VITIMA VIVA"
                        var.qtdVitimasVivasCapturadas += 1
                    else:    
                        var.ultimaVitimaEncontrada = "VITIMA MORTA"
                        var.qtdVitimasMortasCapturadas += 1
                    var.ultimaVitimaEncontrada = var.informacoesVitima["classe_id"]
                    var.vitimaEncontrada = False
                    print(f"VITIMA ENCONTRADA: {var.ultimaVitimaEncontrada} | VIVAS: {var.qtdVitimasVivasCapturadas} | MORTAS: {var.qtdVitimasMortasCapturadas}")
        else:
            if anguloInicial < 360:
                var.informacoesVitima, var.centroVitima, raio = procurarVitima()
                if var.centroVitima:
                    continue
                gireAnguloGiroscopio(cons.VELOCIDADE_PADRAO, cons.DIRECAO_GIRAR_AREA, cons.ANGULO_GIRAR_AREA)
                anguloInicial+=cons.ANGULO_GIRAR_AREA
            else:
                var.informacoesVitima, var.centroVitima, raio = procurarVitima()
                if var.centroVitima:
                    continue
                procurarOutroPontoDeObservacao()
                anguloInicial = 0
                esperar(1000)
                var.informacoesVitima, var.centroVitima, raio = procurarVitima()

def fecharCacamba():
    imports.servoCacamba.move_servo(cons.POSICAO_CACAMBA_FECHADA, 100, cons.DELTA_SERVOS)

def abrirCacamba(tipoVitima):
    if tipoVitima == cons.VITIMA_VIVA:
        imports.servoCacamba.move_servo(cons.POSICAO_CACAMBA_VITIMA_VIVA, 200, cons.DELTA_SERVOS)
    else:
        imports.servoCacamba.move_servo(cons.POSICAO_CACAMBA_VITIMA_MORTA, 200, cons.DELTA_SERVOS)

def lerBotaoFinalizar():
    while True:
        if imports.teclado.le_botao(teclado.BOTAO_ENTER) == cons.BOTAO_PRESSIONADO:
            var.finalizarCodigo = True

mediaErrosFlask = "NENHUM ERRO"
errosFlask = "SEM LINHA"
VerdeEncontrado = False
debug = False
imports.motores.set_led_rgb_all(255,255,255)
esperar(2000)

def controle_robot():
    global mediaErrosFlask, errosFlask, VerdeEncontrado, frame_count, frame_atual1, debug
    estouNoVerde = False
    ret, frame = testarCamera()
    primeiroNoventa = False
    direcao = None
    while True:    
        setarGarra()
        imports.motores.set_led_rgb_all(255,255,255)
        ListaResultados, VerdeEncontrado = atualizarFrames()
        noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
        errosFlask = f"ERROS: {erros}"
        mediaErrosFlask = f"MEDIA ERROS: {mediaErros}"
        VerdeEncontrado = analisarVerde(VerdeEncontrado)
        if VerdeEncontrado != var.verde:
            var.verdeAnterior = var.verde
            var.verde = VerdeEncontrado
        contadorDeCiclos()
        valoresGiroscopio = lerValoresGiroscopio()
        var.estouNaRampa = conferirInclinacao(valoresGiroscopio)
        if not debug:
            if acheiPrata():
                pass
            if VerdeEncontrado == "VerdeFalso":
                cron.tempoViuNoventa.reseta()
                cron.tempoViVerdeFalso.reseta()
                var.noventaGraus = False
                var.verdeFalso = True
                if mediaErros != "sem linha":
                    mediaErros //= 2
            else:
                var.verdeFalso = False
            if VerdeEncontrado in ("VerdeDireito", "VerdeEsquerdo","DoisVerdes") and cron.tempoViVerdeFalso.tempo() > 310 and 60 > var.posicoesVerde[1] > 15:
                TalvezVerde = VerdeEncontrado
                if conferirInclinacao(valoresGiroscopio):
                    VerdeEncontrado = andarDistanciaConferindo(cons.VELOCIDADE_RAMPA,var.distanciaAjusteParaFrente,cons.DIRECAO_FRENTE)
                    if cron.tempoFezVerde.tempo() < 500:
                        continue
                else:
                    posicaoYdoVerde = var.posicoesVerde[1]
                    print(posicaoYdoVerde)
                    VerdeEncontrado = andarDistanciaConferindo(cons.VELOCIDADE_PADRAO,var.distanciaAjusteParaFrente*1.8,cons.DIRECAO_FRENTE)
                    imports.para_motores()
                if VerdeEncontrado == "DoisVerdes":
                    avisoVerdeInicial(VerdeEncontrado)
                    estouNoVerde = movimentoGiroVerde(VerdeEncontrado)
                elif (VerdeEncontrado != "sem verde" and VerdeEncontrado != None) and VerdeEncontrado != TalvezVerde:
                    avisoVerdeInicial("DoisVerdes")
                    estouNoVerde = movimentoGiroVerde("DoisVerdes")
                else:
                    avisoVerdeInicial(TalvezVerde)
                    estouNoVerde = movimentoGiroVerde(TalvezVerde)
                imports.para_motores()     
                var.noventaGraus = False
                var.noventaConfirmado = False
                var.doisVerdeParaDireita = False
                var.doisVerdeParaEsquerda = False
                var.verdeNaRampa = False
                cron.tempoViVerdeFalso.reseta()
                var.ultimoErro = 0
                continue
            if var.noventaConfirmado:
                velocidadeGiro = cons.VELOCIDADE_GIRO_PADRAO
                possiveisNoventa = [0]
                if var.direcaoNoventa in (1,-1):
                    direcao = var.direcaoNoventa
                    if var.direcaoNoventa == -1:
                        p1, p2 = -velocidadeGiro, velocidadeGiro
                        possiveisNoventa[0] = var.qtdPretoFinalizarNoventaEsquerdo
                        valorAndarAntesDeGirar = var.valorPretoConferirGapEsquerdo
                    else:
                        p1, p2 = velocidadeGiro, -velocidadeGiro
                        possiveisNoventa[0] = var.qtdPretoFinalizarNoventaDireito
                        valorAndarAntesDeGirar = var.valorPretoConferirGapDireito
                valoresGiroscopio = lerValoresGiroscopio()
                if conferirInclinacao(valoresGiroscopio):
                    velocidadeGiro = cons.VELOCIDADE_GIRO_RAMPA
                    if var.rampaSubida:
                        andePorCertaDistancia(cons.VELOCIDADE_RAMPA, cons.DISTANCIA_AJUSTE_GIRO+40, cons.DIRECAO_FRENTE)
                        if direcao == cons.DIRECAO_DIREITA:
                            velocidadesGirar1 = [cons.VELOCIDADE_GIRO_RAMPA, cons.VELOCIDADE_GIRO_RAMPA, 0, 0]
                        else:
                            velocidadesGirar1 = [0, 0, cons.VELOCIDADE_GIRO_RAMPA, cons.VELOCIDADE_GIRO_RAMPA]
                        while abs(valoresGiroscopio[cons.ANGULO_X]) < 19:
                            gire4Velocidades(velocidadesGirar1[0], velocidadesGirar1[1], velocidadesGirar1[2], velocidadesGirar1[3])
                            valoresGiroscopio = lerValoresGiroscopio()
                        var.direcaoNoventa = None
                        var.noventaGraus = False
                        var.noventaConfirmado = False
                        var.resetarErro = True
                        continue
                    elif var.rampaDeLado:
                        valoresGiroscopio = lerValoresGiroscopio()
                        conferirInclinacao(valoresGiroscopio)
                        anguloInicial = valoresGiroscopio[cons.ANGULO_X]
                        print(direcao)
                        while abs(valoresGiroscopio[cons.ANGULO_X])+4 > abs(valoresGiroscopio[cons.ANGULO_Y]):
                            valoresGiroscopio = lerValoresGiroscopio()
                            gire4Velocidades(cons.VELOCIDADE_GIRO_RAMPA*direcao, cons.VELOCIDADE_GIRO_RAMPA*direcao, -cons.VELOCIDADE_GIRO_RAMPA*direcao, -cons.VELOCIDADE_GIRO_RAMPA*direcao)
                        andePorCertaDistancia(cons.VELOCIDADE_RAMPA, cons.DISTANCIA_AJUSTE_GIRO*1.5, cons.DIRECAO_FRENTE)
                        imports.para_motores()
                        var.direcaoNoventa = None
                        var.noventaGraus = False
                        var.noventaConfirmado = False
                        var.resetarErro = True
                        continue
                imports.para_motores()
                print("fazer 90")
                resetaTrens()
                distanciaAjuste = var.distanciaAjusteParaFrente
                distanciaInicial = imports.motores.angulo_motor(imports.MOTOR_ESQUERDO)
                while abs(abs(distanciaInicial) - abs(imports.motores.angulo_motor(imports.MOTOR_ESQUERDO))) < distanciaAjuste-44:
                    ListaResultados, VerdeEncontrado = atualizarFrames()
                    noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
                    imports.velocidade_motores_encoder(cons.VELOCIDADE_PADRAO,cons.VELOCIDADE_PADRAO)
                posicaoInicial = 0
                direcaoInicial = var.direcaoNoventa
                imports.para_motores()
                resetaTrens()
                posicaoInicial = abs(imports.giroscopio.le_angulo_z())
                achouLinha = var.qtdPretoFinalizarNoventa
                ListaResultados, VerdeEncontrado = atualizarFrames()
                noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
                while (achouLinha < 0.4 and abs(imports.giroscopio.le_angulo_z()) <= 85) or abs(imports.giroscopio.le_angulo_z()) <= 50:
                    ListaResultados, VerdeEncontrado = atualizarFrames()
                    achouLinha = var.qtdPretoFinalizarNoventa
                    noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
                    imports.velocidade_motores_encoder(p1, p2)
                    if mediaErros != "sem linha":
                        var.ultimoErroNumerico = mediaErros
                imports.para_motores()
                posicaoInicial -= abs(imports.giroscopio.le_angulo_z())
                atualizarCamera()
                ListaResultados, VerdeEncontrado = atualizarFrames()
                noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
                if abs(imports.giroscopio.le_angulo_z()) > 120:
                    imports.para_motores()
                    resetaTrens()
                    while possiveisNoventa[0] < 0.01 and abs(imports.giroscopio.le_angulo_z()) <= 160:
                        possiveisNoventa[0] = var.qtdPretoFinalizarNoventaDireito if direcaoInicial == 1 else var.qtdPretoFinalizarNoventaEsquerdo
                        ListaResultados, VerdeEncontrado = atualizarFrames()
                        noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
                        imports.velocidade_motores_encoder(p2, p1)
                    posicaoInicial += abs(imports.giroscopio.le_angulo_z())
                    imports.para_motores()
                if abs(imports.giroscopio.le_angulo_z()) > 170:
                    gireAnguloGiroscopio(60,direcaoInicial,abs(posicaoInicial))
                    tortoPara, valorTorto = andeAteVerPreto(60,cons.DIRECAO_TRAS)
                    if tortoPara and tortoPara != 0:
                        alinharGap(tortoPara,valorTorto)
                imports.para_motores()
                andePorCertaDistancia(cons.VELOCIDADE_RAMPA, cons.DISTANCIA_AJUSTE_POS_GIRO, cons.DIRECAO_TRAS)
                ListaResultados, VerdeEncontrado = atualizarFrames()
                noventaGraus, mediaErros, erros = extrairResultados(ListaResultados)
                VerdeEncontrado = analisarVerde(VerdeEncontrado)
                esperar(200)
                imports.motores.reseta_angulo_motor(imports.MOTOR_DIREITO)
                imports.motores.reseta_angulo_motor(imports.MOTOR_ESQUERDO)
                var.direcaoNoventa = None
                var.noventaGraus = False
                var.noventaConfirmado = False
                var.ultimoErro = 0
                continue
            elif erros[1] == "sem linha" and cron.tempoAjeiteiGap.tempo() > 2300 and abs(imports.giroscopio.le_angulo_y()) < 6:
                alinharGap()
                cron.tempoAjeiteiGap.reseta()
                var.noventaGraus = False              
            elif cron.tempoViuNoventa.tempo() > 200:
                var.noventaGraus = False              
            aumentarVelocidadeEnquantoPreso()
            if var.resetarErro:
                mediaErros = 0
            Velocidade_esquerdo, Velocidade_direito, val = SeguirLinha(mediaErros, KP, KD, KI, var.valorIntegral)
            var.resetarErro = False
            if cron.tempoFezVerde.tempo() > 500:
                cron.tempoFezVerde.reseta()
            imports.velocidade_motores_encoder(Velocidade_esquerdo, Velocidade_direito)

def gerar_video1():
    global frame_atual1
    while True:
        if frame_atual1 is not None:
            with lock:
                _, buffer = cv2.imencode('.jpg', frame_atual1)
            frame_bytes = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
        time.sleep(0.03)  

def gerar_video2():
    global frame_atual2
    while True:
        if frame_atual2 is not None:
            with lock:
                _, buffer = cv2.imencode('.jpg', frame_atual2)
            frame_bytes = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
        time.sleep(0.03)  

def gerar_video3():
    global frame_atual3
    while True:
        if frame_atual3 is not None:
            with lock:
                _, buffer = cv2.imencode('.jpg', frame_atual3)
            frame_bytes = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
        time.sleep(0.03)  

@app.route('/')
def index():
    global mediaErrosFlask, errosFlask, VerdeEncontrado
    return """
    <html>
    <head>
        <title>Camera do robô</title>
        <style>
            body { font-family: Arial; margin: 20px; background-color: 
            h1 { text-align: center; color: 
            .container { display: flex; gap: 20px; justify-content: center; flex-wrap: wrap; }
            .video-box { background-color: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
            .video-box h2 { margin: 0 0 10px 0; font-size: 16px; color: 
            .video-box img { width: 400; height: 300; border: 2px solid 
        </style>
    </head>
    <body>
        <h1>Camera do robô</h1>
        <div class="container">
            <div class="video-box">
                <h2>Seguidor de Linha</h2>
                <img src="/video" width="400" height="300">
            </div>
            <div class="video-box">
                <h2>Verde/VitimasEncontradas</h2>
                <img src="/video2" width="400" height="300">
            </div>
            <div class="video-box">
                <h2>Última Vítima Encontrada</h2>
                <img src="/video3" width="400" height="300">
            </div>
        <br>
        <div class ="container" id="temp_info" style="font-size: 75px;"></div>
        <div id="temp_info" class="container">
            <div class="video-box">
                <p>Dados Retirados das Imagens</p>
                <div class="video-box" id="info_box" >
                    <!-- dados vão aparecer aqui -->
                </div>
            </div>
        </div>
        <script>
        // Função para atualizar as informações
        function atualizarTemp() {
        fetch('/temp_data')
            .then(response => response.json())
            .then(data => {
                document.getElementById('info_box').innerHTML = `
                    <p>${data.mediaErrosFlask}</p>
                    <p>${data.errosFlask}</p>
                    <p>${data.verde}</p>
                    <p>${data.verdeAnterior}</p>
                    <p>${data.ultimaVitimaEncontrada}</p>
                `;
            })
            .catch(error => {
                document.getElementById('info_box').innerHTML = 'Erro ao carregar dados!';
            });
}
        // Atualiza a cada 350ms
        setInterval(atualizarTemp, 350);
        </script>
    </body>
    </html>
    """

@app.route('/temp_data')
def temp_data():
    return {
        'mediaErrosFlask': mediaErrosFlask,
        'errosFlask': errosFlask,
        'verde': VerdeEncontrado,
        'verdeAnterior': var.verdeAnterior,
        'ultimaVitimaEncontrada': var.ultimaVitimaEncontrada
    }

@app.route('/video')
def video_feed1():
    return Response(gerar_video1(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/video2')
def video_feed2():
    return Response(gerar_video2(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/video3')
def video_feed3():
    return Response(gerar_video3(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

def iniciar_flask():
    app.run(host='0.0.0.0', port=8080, threaded=True)
    if var.finalizarCodigo:
        exit()

if __name__ == '__main__':

    try:
        log = logging.getLogger('werkzeug')
        log.setLevel(logging.ERROR)
        t = threading.Thread(target=atualizarDistancias, daemon=False)
        t.start()

        thread_botoes = threading.Thread(target=lerValoresBotoes)
        thread_botoes.daemon = True
        thread_botoes.start()

        finalizarCodigo = threading.Thread(target=lerBotaoFinalizar)
        finalizarCodigo.daemon = True
        finalizarCodigo.start()

        flask_thread = threading.Thread(target=iniciar_flask)
        flask_thread.daemon = True
        flask_thread.start()

        controle_robot()

    except KeyboardInterrupt as e:
        imports.para_motores()
        print("\n", e ,"\nInterrupção detectada! Parando os motores e encerrando...")
        print("Programa encerrado com segurança.")
        exit()
