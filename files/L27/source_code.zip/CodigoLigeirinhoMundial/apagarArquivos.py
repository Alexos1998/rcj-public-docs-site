from imports import arquivosConfiguracao

arquivosConfiguracao.limpa()

if arquivosConfiguracao.obtem("VITIMA-MORTA") is None:
    print("SEM VITIMAS MORTAS")
if arquivosConfiguracao.obtem("VITIMA-VIVA") is None:
    print("SEM VITIMAS VIVAS")

