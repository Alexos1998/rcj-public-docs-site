// =============================================================================
// STEP 4 v2 COLOR — Time-calibrated GRID explorer + COLOR SENSOR (black/blue)
// =============================================================================
// Base = step4_grid_timed_v2 (proven backtracking-DFS navigation on this robot:
//   v2 motor mapping, steering signs, gyro/turn tuning, RETRACK recovery,
//   write-once majority-vote wall sensing, time-calibrated per-tile driving).
//
// ADDED: a front-facing TCS34725 color sensor for special tiles --
//   - BLACK tile (hole): detected while ENTERING -> stop, reverse out, mark the
//     target cell blocked so DFS never targets it again.
//   - BLUE tile (checkpoint): detected at cell center -> pause + blink ~5s once.
//     Explored THROUGH normally (entered once, scored), but the RETURN phase
//     avoids re-crossing it (rules penalty for a second pass over the same blue).
//
// EXPLORE/RETURN: forward exploration is the same DFS dive (prefer an unvisited
// open neighbor). When no unvisited neighbor is adjacent, a flood-fill (BFS)
// planner routes to the nearest frontier, then home to start, over confirmed-safe
// VISITED cells -- and AVOIDS scored BLUE tiles. Blue is only re-crossed as a last
// resort to get home (so the robot never deadlocks), never just to keep exploring.
//
// COLOR CALIBRATION (from test5_color_calibrate_v2, 50ms / 4X on THIS chassis):
//   BLACK  R~18 G~39 B~41 C~105 (edge-spikes ~136) -> B~=G (B-G small), low clear
//   BLUE   R~21 G~44 B~54 C~125                     -> B>G (B-G~10), B-R~33
//   WHITE  R~59 G~95 B~87 C~254                     -> G>B, high clear
//   Black/blue clear OVERLAP, so they are separated on B-G (signed):
//     black B-G<=5 (and C<=160) ; blue B-G>=7 AND B-R>=20 (and 90<=C<=185).
//
// NAVIGATION CALIBRATION (this robot, from test4_calibrate_time_v2):
//   3-tile avg = 2678 ms ; 5-tile avg = 5240 ms
//   msPerTile = (T5 - T3)/2 = 1281 ms ; ONE_TILE_MS = msPerTile - TILE_TRIM_MS
//
// Wiring:
//   Left US 2/3, Front US 6/26, Right US 4/5
//   RIGHT motor M1A 8 / M1B 9,  LEFT motor M2A 10 / M2B 11
//   MPU6050 SDA 16 / SCL 17,    NeoPixel pin 18
//   TCS34725 color sensor on the same I2C bus (SDA 16 / SCL 17), facing floor
//   LED: RED=new cell, GREEN=re-entered known cell, MAGENTA=backtrack,
//        PURPLE=black tile (reversed out), BLUE-blink(~5s)=blue checkpoint,
//        AMBER=blocked/corrected, BLUE(steady)=done.
// =============================================================================

#include <Wire.h>
#include <MPU6050_light.h>
#include <Adafruit_NeoPixel.h>
#include <Adafruit_TCS34725.h>
#include <Servo.h>

// =============================================================================
//  VICTIM DETECTION (OpenMV H7+ over UART) -- added, does not change DFS logic
// =============================================================================
// OpenMV sends: "VICTIM,<label>,<score0-100>\n" where label is one of
// control / harmed / stable / unharmed (see fomo_detection.py).
// Wiring: OpenMV P4 (TX) -> RP2040 GP5 (Serial1 RX), GND -> GND.
#define VICTIM_RX_PIN 5
#define RED_LED_PIN   19      // separate red LED, lights on ANY victim detection
#define SERVO_PIN     20      // servo pulsed for harmed/stable victims
#define SERVO_REST_US 1000
#define SERVO_PULSE_US 2000
#define SERVO_PULSE_MS 400    // time servo holds the pulse position

Servo victimServo;
String victimLine = "";


// ---------- PINS ----------
#define TRIG_LEFT 2
#define ECHO_LEFT 3
#define TRIG_FRONT 6
#define ECHO_FRONT 26
#define TRIG_RIGHT 4
#define ECHO_RIGHT 5
const int M1A = 8, M1B = 9, M2A = 10, M2B = 11;   // M1=RIGHT, M2=LEFT
#define SDA_PIN 16
#define SCL_PIN 17
MPU6050 mpu(Wire);
#define PIXEL_PIN 18
#define PIXEL_COUNT 2
Adafruit_NeoPixel pixels(PIXEL_COUNT, PIXEL_PIN, NEO_GRB + NEO_KHZ800);

// ---------- COLOR SENSOR (front, facing floor) ----------
// Keep 50ms / 4X to match the calibrated black/blue thresholds below.
Adafruit_TCS34725 tcs = Adafruit_TCS34725(TCS34725_INTEGRATIONTIME_50MS, TCS34725_GAIN_4X);
bool tcsReady = false;

// =====================  CALIBRATION  (from test4_v2 averages)  ===============
unsigned long CALIB_TIME_3_MS = 2678;   // 3-tile ping-pong average
unsigned long CALIB_TIME_5_MS = 5240;   // 5-tile ping-pong average
// Derived at boot:
float         msPerTile  = 1281.0f;
unsigned long ONE_TILE_MS = 1281;
// Manual trim applied to ONE_TILE_MS to compensate for coast/overshoot.
// Positive value = drive LESS time per tile (stop earlier). Tune on the floor.
long          TILE_TRIM_MS = -25;  // was +50 (undershot center); negative = drive a touch LONGER to reach tile center
// =============================================================================

// ---------- DIRECTIONS ----------  N=0 E=1 S=2 W=3 ; N=+y E=+x S=-y W=-x
const int8_t DX[4] = { 0, +1, 0, -1 };
const int8_t DY[4] = { +1, 0, -1, 0 };
const char*  DNAME[4] = { "N", "E", "S", "W" };
inline uint8_t opposite(uint8_t d) { return (d + 2) & 3; }

// ---------- GRID ----------
#define GRID 25
#define START 12
struct Cell { bool visited; uint8_t walls; uint8_t known; uint8_t tried; bool black; bool blue; };
Cell grid[GRID][GRID];
int rx = START, ry = START;
uint8_t heading = 0;
bool firstCell = true;
enum RunMode : uint8_t { EXPLORING, DONE };
RunMode mode = EXPLORING;
int  movedBlueHits = 0;     // blue reads seen during the last drive into a cell
int  blueCooldown  = 0;     // >0 = skip blue handling (just left a blue tile)
bool blackAbort    = false; // set by driveOneTile when a move aborts on a black hole

// ---------- WALL THRESHOLDS (sensing while stopped) ----------
const float SIDE_WALL_CM  = 16.0f;
// A wall on the FRONT edge of the current tile reads ~14-16 cm on this robot,
// while an open corridor reads >=39 cm. 13 was too low -> edge walls were
// misread as OPEN, causing phantom forward moves + one-tile position desync.
// 25 sits safely in the gap (above ~16 walls, below ~39 open).
const float FRONT_WALL_CM = 25.0f;
const float FRONT_STOP_CM = 11.0f;   // stop/realign early; clearance for 180 turns
// Pre-turn front alignment: if a wall is within FRONT_APPROACH_CM ahead and the
// robot is about to TURN, creep forward to FRONT_ALIGN_CM from it first, so the
// turn always starts squared to the wall from a repeatable spot (no corner clip).
const float FRONT_APPROACH_CM = 25.0f;
const float FRONT_ALIGN_CM    = 9.0f;   // stop this far from front wall before turning
                                        // (9 > 7: don't ram so close to the wall)
// If a tile move hits a wall sooner than this, the way ahead was NOT really open
// (sensor misread) -> mark it a wall and don't advance. A real tile entry drives
// most of ONE_TILE_MS (~1231); a misread/phantom blocks in well under this.
const unsigned long MIN_TILE_PROGRESS_MS = 500;

// ---------- COLOR LAYER MASTER SWITCH ----------
// false = color sensor FULLY OFF: no color reads during a drive (no black-hole
//         abort, no blue tally) and no blue handling at a cell. Navigation then
//         behaves exactly like the pure step4_grid_timed_v2 explorer. Use this to
//         test whether edge-clipping / poor centering is caused by the color
//         layer or by something else (motors/battery/centering tuning).
// true  = color sensing active (black + blue tiles handled).
bool COLOR_ENABLED = true;

// ---------- COLOR TILE THRESHOLDS (calibrated 50ms/4X, this robot) ----------
// Lifted verbatim from test5_color_calibrate_v2. Black/blue clear overlap, so
// both key on the SIGNED B-G difference (uint16_t underflow would wrap huge).
// Re-measured Jun 9: REAL black tile reads C~112 (up to ~128 at edges), B-G~2. Normal white
// floor reads C~250, bright white ~1400, blue ~224. So black's clear sits well below the floor;
// ceiling 160 catches black (112-128) and rejects floor (250). (b-g<=5 also excludes blue B-G~13.)
#define BLACK_MAX_C 160
bool guessBlack(uint16_t r, uint16_t g, uint16_t b, uint16_t c) {
  (void)r;
  if (c > BLACK_MAX_C) return false;               // floor ~250 / white ~1400 -> not black
  int bg = (int)b - (int)g;                        // SIGNED: black B-G~2; bright-blue B-G~5
  return bg <= 4;                                  // tightened 5->4 so bright-blue isn't black
}
bool guessBlue(uint16_t r, uint16_t g, uint16_t b, uint16_t c) {
  // Current lighting: blue reads C~125-163, and B-R is the stable marker (~32-34) across the
  // dim core (21/44/54) and bright edge (30/57/63), while floor/black sit at B-R~22. B-G is
  // unreliable here (shrinks to 5-6 on bright reads), so key on B-R; B-G>=4 is a light guard.
  if (c < 100 || c > 600) return false;            // covers dim & bright blue
  int bg = (int)b - (int)g, br = (int)b - (int)r;  // SIGNED
  return br >= 26 && bg >= 4;                       // B-R~33 blue vs ~22 floor/black
}
const int BLACK_CONFIRM = 2;                 // consecutive dark reads to confirm black
const int BLUE_CONFIRM  = 2;                 // total blue reads to confirm a blue tile
// Front-mounted sensor still sees the PREVIOUS tile early in a move, so ignore
// blue during the first part of the drive, and skip blue on the very next tile.
const unsigned long BLUE_LEAD_SKIP_MS = 700; // don't count blue this early in a move
const int BLUE_COOLDOWN_TILES = 1;           // tiles to ignore blue after handling one
// Sample color at most this often while DRIVING. The sensor integrates every
// ~50ms, so this yields one FRESH reading per sample (consecutive BLACK_CONFIRM
// hits span distinct integrations -> robust to a transient dark grout line),
// while the heading/wall control loop keeps running at its faster ~20ms cadence.
const unsigned long COLOR_SAMPLE_MS = 55;
// On a black hole, reversing for the FULL forward time overshoots back past the
// origin (coast + the fact we'd already crept toward the hole), so the next turn
// clips the wall behind. Back out only this FRACTION of the forward time.
const float BLACK_REVERSE_FRAC = 1.1f;

// ---------- DRIVING ----------
int   BASE_SPEED = 160;          // lowered 180->160 for more time to correct near walls
// BASE_SPEED used during the test4 time calibration (CALIB_TIME_3/5 below were
// measured at this speed). ONE_TILE_MS is auto-scaled by CALIB_BASE_SPEED/BASE_SPEED
// at boot so changing BASE_SPEED keeps the per-tile DISTANCE correct (slower ->
// proportionally more time per tile). Re-verify on the floor / recalibrate if off.
const int CALIB_BASE_SPEED = 180;
int   MAX_CORRECTION = 90;
float DIST_ALPHA = 0.5f;
const float WALL_PRESENT_CM = 16.0f;
const float SIDE_TARGET_CM = 9.0f;
// More aggressive wall avoidance (prevention): trigger the "too close" escape
// sooner (7 vs 6) and push away harder (45 vs 35) so the robot stays clear of
// side walls and doesn't end up close enough to clip a frame when turning.
const float MIN_WALL_DISTANCE = 8.0f;
const float ESCAPE_BIAS_PWM = 45.0f;
float Kp_center = 9.0f, Kp_side = 13.0f;  // corridor stays 9; single-wall bumped 9->13 for faster re-center when the reference wall switches sides

// ---------- GYRO + TURNS ----------
const int GYRO_SIGN = 1;
const int STEER_SIGN = 1;
float Kp_gyro = 0.5f;
const float MAX_GYRO_CORR = 30.0f;
const float GYRO_ALPHA = 0.35f;
float LEFT_TRIM = 1.16f, RIGHT_TRIM = 1.00f;   // left motor weaker on this chassis
bool  TURN_RIGHT_IS_CW = true;                 // verified in test1_turn_direction_v2
const float TURN_TOL = 2.0f;
const float Kp_turn = 2.0f;
const int MIN_TURN_PWM = 120, MAX_TURN_PWM = 180;

// ---------- RETRACK (blocked-move recovery) FEATURE FLAG ----------
// true  = on a blocked turn, back up / re-center / retry before marking a wall
//         (recovers from doorframe clips, but does extra turns/nudges).
// false = a blocked move is immediately marked a wall (simpler, no extra motion).
bool RETRACK_ENABLED = true;
// Target turn angles (deg). Tuned to land JUST UNDER 90 so a turn never
// over-rotates into the corner/frame (target 92 measured ~90.1-90.4 = slightly
// OVER, which clipped corners). 91 lands ~89. If LEFT still over-turns, drop
// TURN_LEFT_DEG a bit more (motor asymmetry).
float TURN_RIGHT_DEG = 91.0f;
float TURN_LEFT_DEG  = 91.0f;
// MUST stay < 180: turn progress is fabs(wrap180(...)) which caps at 180, so a
// target >= 180 can never be "reached" -> it overshoots, times out, and (with
// stall recovery) spins forever. 178 lands a clean ~180 on this robot.
float TURN_180_DEG   = 178.0f;

float leftFiltered = SIDE_TARGET_CM, rightFiltered = SIDE_TARGET_CM, frontFiltered = 200.0f;
float gyroCorrFiltered = 0.0f, headingSetpoint = 0.0f;

// =============================================================================
//  LOW-LEVEL  (new mapping: RIGHT=M1 normal, LEFT=M2 swapped)
// =============================================================================
void setMotor(int a, int b, int s) {
  s = constrain(s, -255, 255);
  if (s > 0)      { analogWrite(a, s); analogWrite(b, 0); }
  else if (s < 0) { analogWrite(a, 0); analogWrite(b, -s); }
  else            { analogWrite(a, 0); analogWrite(b, 0); }
}
void setMotorSpeeds(int l, int r) {
  l = (int)round(l * LEFT_TRIM); r = (int)round(r * RIGHT_TRIM);
  setMotor(M1A, M1B, r);   // RIGHT = M1, normal order
  setMotor(M2B, M2A, l);   // LEFT  = M2, swapped order
}
void stopMotors() { setMotorSpeeds(0, 0); }

long readRaw(int t, int e) {
  digitalWrite(t, LOW);  delayMicroseconds(2);
  digitalWrite(t, HIGH); delayMicroseconds(10);
  digitalWrite(t, LOW);
  return pulseIn(e, HIGH, 25000);
}
float readOnce(int t, int e) { long d = readRaw(t, e); return (d <= 0) ? 200.0f : (d * 0.0343f / 2.0f); }
float readMedian3(int t, int e) {
  float a = readOnce(t, e); delay(2);
  float b = readOnce(t, e); delay(2);
  float c = readOnce(t, e);
  if (a > b) { float x = a; a = b; b = x; }
  if (b > c) { float x = b; b = c; c = x; }
  if (a > b) { float x = a; a = b; b = x; }
  return b;
}

// ---- COLOR: one fresh read. Reliability comes from sampling CONTINUOUSLY
// (every drive iteration) + several reads at the cell center, not a single read.
// NON-BLOCKING read. Adafruit's getRawData() ends with delay(integrationTime) --
// delay(50) at 50ms/4X -- on EVERY call. Sampled inside the drive loop that would
// stall heading/wall control ~50ms per iteration (motors running uncorrected) and
// halve the steering update rate. The sensor runs in CONTINUOUS mode (begin()
// enables AEN/RGBC), so its data registers always hold the most recent finished
// integration; reading them directly takes <1ms and never disturbs driving.
static uint16_t tcsRaw16(uint8_t reg) {
  Wire.beginTransmission(TCS34725_ADDRESS);
  Wire.write(TCS34725_COMMAND_BIT | reg);
  Wire.endTransmission();
  Wire.requestFrom(TCS34725_ADDRESS, (uint8_t)2);
  uint8_t lo = Wire.read();
  uint8_t hi = Wire.read();
  return ((uint16_t)hi << 8) | lo;
}
bool readColor(uint16_t &r, uint16_t &g, uint16_t &b, uint16_t &c) {
  if (!tcsReady) return false;
  c = tcsRaw16(TCS34725_CDATAL);
  r = tcsRaw16(TCS34725_RDATAL);
  g = tcsRaw16(TCS34725_GDATAL);
  b = tcsRaw16(TCS34725_BDATAL);
  return true;
}

// How many samples to vote over when classifying a wall while stopped at a cell.
const int SENSE_SAMPLES = 5;

// Majority-vote wall classification: take SENSE_SAMPLES reads, classify each
// against `threshold`, and return the majority verdict (true = WALL). This makes
// the map robust to a single bad ping / intermittent spike (e.g. a specular
// dropout reading 148 cm). Reports the median distance via outDist + the count.
bool classifyWall(int trig, int echo, float threshold, float &outDist, int &wallVotes) {
  float vals[SENSE_SAMPLES];
  wallVotes = 0;
  for (int i = 0; i < SENSE_SAMPLES; i++) {
    float d = readOnce(trig, echo);
    vals[i] = d;
    if (d < threshold) wallVotes++;
    delay(6);
  }
  for (int i = 0; i < SENSE_SAMPLES; i++)
    for (int j = i + 1; j < SENSE_SAMPLES; j++)
      if (vals[j] < vals[i]) { float t = vals[i]; vals[i] = vals[j]; vals[j] = t; }
  outDist = vals[SENSE_SAMPLES / 2];          // median, for logging
  return wallVotes > (SENSE_SAMPLES / 2);     // majority -> wall
}
float wrap180(float a) { while (a > 180) a -= 360; while (a <= -180) a += 360; return a; }
void led(uint8_t r, uint8_t g, uint8_t b, int ms) {
  for (int i = 0; i < PIXEL_COUNT; i++) pixels.setPixelColor(i, pixels.Color(r, g, b));
  pixels.show(); delay(ms); pixels.clear(); pixels.show();
}

// =============================================================================
//  VICTIM DETECTION HANDLING (OpenMV UART)
// =============================================================================
// Single servo pulse: move to pulse position, hold, return to rest.
void servoPulse() {
  victimServo.writeMicroseconds(SERVO_PULSE_US);
  delay(SERVO_PULSE_MS);
  victimServo.writeMicroseconds(SERVO_REST_US);
  delay(SERVO_PULSE_MS);
}

// Briefly light the red LED (separate from the NeoPixel status indicator).
void redLedFlash() {
  digitalWrite(RED_LED_PIN, HIGH);
  delay(150);
  digitalWrite(RED_LED_PIN, LOW);
}

// Non-blocking-ish check for a line from the OpenMV camera. Call once per
// loop(). Parses "VICTIM,<label>,<score>" and reacts:
//   harmed   -> red LED + servo pulse x2
//   stable   -> red LED + servo pulse x1
//   unharmed -> red LED only, no servo
//   control  -> red LED only, no servo
void checkVictimDetections() {
  while (Serial1.available() > 0) {
    char c = Serial1.read();
    if (c == '\n') {
      victimLine.trim();
      if (victimLine.startsWith("VICTIM,")) {
        int c1 = victimLine.indexOf(',');
        int c2 = victimLine.indexOf(',', c1 + 1);
        String label = (c2 > c1) ? victimLine.substring(c1 + 1, c2) : victimLine.substring(c1 + 1);
        label.toLowerCase();

        Serial.print("[VICTIM] detected: "); Serial.println(label);

        // Red LED glows on every victim detection.
        redLedFlash();

        if (label == "harmed") {
          servoPulse();
          servoPulse();
        } else if (label == "stable") {
          servoPulse();
        }
        // "unharmed" and "control": LED only, no servo action.
      }
      victimLine = "";
    } else if (c != '\r') {
      victimLine += c;
    }
  }
}


// =============================================================================
//  SENSE -> CONTROL  (v2 steering signs)
// =============================================================================
void readAndFilter() {
  float l = readOnce(TRIG_LEFT, ECHO_LEFT);
  float f = readOnce(TRIG_FRONT, ECHO_FRONT);
  float r = readOnce(TRIG_RIGHT, ECHO_RIGHT);
  leftFiltered  = DIST_ALPHA * l + (1 - DIST_ALPHA) * leftFiltered;
  rightFiltered = DIST_ALPHA * r + (1 - DIST_ALPHA) * rightFiltered;
  frontFiltered = DIST_ALPHA * f + (1 - DIST_ALPHA) * frontFiltered;
}
void updateHeadingHold() {
  mpu.update();
  float e = wrap180(headingSetpoint - mpu.getAngleZ());
  float raw = constrain((float)GYRO_SIGN * Kp_gyro * e, -MAX_GYRO_CORR, MAX_GYRO_CORR);
  gyroCorrFiltered = GYRO_ALPHA * raw + (1 - GYRO_ALPHA) * gyroCorrFiltered;
}
void applyWallCentering() {
  bool lw = (leftFiltered < WALL_PRESENT_CM), rw = (rightFiltered < WALL_PRESENT_CM);
  // Too close LEFT -> steer RIGHT (faster LEFT wheel).
  if (lw && leftFiltered  < MIN_WALL_DISTANCE) { setMotorSpeeds(BASE_SPEED + (int)ESCAPE_BIAS_PWM, BASE_SPEED - (int)ESCAPE_BIAS_PWM); return; }
  // Too close RIGHT -> steer LEFT (faster RIGHT wheel).
  if (rw && rightFiltered < MIN_WALL_DISTANCE) { setMotorSpeeds(BASE_SPEED - (int)ESCAPE_BIAS_PWM, BASE_SPEED + (int)ESCAPE_BIAS_PWM); return; }
  float c = 0;
  if (lw && rw) c = Kp_center * 0.5f * (leftFiltered - rightFiltered);
  else if (lw)  c = Kp_side * (leftFiltered - SIDE_TARGET_CM);
  else if (rw)  c = Kp_side * (SIDE_TARGET_CM - rightFiltered);
  c = (float)STEER_SIGN * constrain(c, -(float)MAX_CORRECTION, (float)MAX_CORRECTION);
  // POSITIVE correction -> faster RIGHT wheel -> turn LEFT.
  setMotorSpeeds(constrain((int)round(BASE_SPEED - c - gyroCorrFiltered), -255, 255),
                 constrain((int)round(BASE_SPEED + c + gyroCorrFiltered), -255, 255));
}

// =============================================================================
//  TURNS
// =============================================================================
void resetHeadingSetpoint() {
  float s = 0; const int N = 6;
  for (int i = 0; i < N; i++) { mpu.update(); delay(8); s += mpu.getAngleZ(); }
  headingSetpoint = s / N; gyroCorrFiltered = 0;
}
void gyroTurn(float ang, bool rightDir, unsigned long to) {
  stopMotors(); delay(80);
  for (int i = 0; i < 15; i++) { mpu.update(); delay(5); }
  float start = mpu.getAngleZ();
  bool cw = (rightDir == TURN_RIGHT_IS_CW);
  int stalls = 0;
  bool reached = false;
  unsigned long t0 = millis();
  while (true) {
    mpu.update();
    float rem = ang - fabs(wrap180(mpu.getAngleZ() - start));
    if (rem <= TURN_TOL) { reached = true; break; }
    int pwm = constrain((int)(Kp_turn * rem), MIN_TURN_PWM, MAX_TURN_PWM);
    if (cw) setMotorSpeeds(pwm, -pwm); else setMotorSpeeds(-pwm, pwm);
    if (millis() - t0 > to) {
      float prog = fabs(wrap180(mpu.getAngleZ() - start));
      // Only treat as a JAM (back up + retry) if we barely rotated. A turn that
      // got most of the way and merely ran out of time must NOT retry/spin.
      if (prog < ang * 0.5f && stalls < 2) {
        stalls++;
        stopMotors(); delay(80);
        Serial.print("   [TURN] STALL at "); Serial.print(prog, 1);
        Serial.print(" deg -> back up & retry ("); Serial.print(stalls); Serial.println(")");
        setMotorSpeeds(-150, -150); delay(300); stopMotors(); delay(150);
        t0 = millis();           // reset the timeout window
      } else {
        Serial.print("   [TURN] timed out at "); Serial.print(prog, 1); Serial.println(" deg -> stop");
        break;
      }
    }
    delay(8);
  }
  stopMotors();
  float measured = fabs(wrap180(mpu.getAngleZ() - start));
  Serial.print("   [TURN] target="); Serial.print(ang, 0);
  Serial.print(" measured="); Serial.print(measured, 1);
  Serial.print(" deg ("); Serial.print(rightDir ? "right" : "left");
  Serial.println(reached ? ")" : ") <<< INCOMPLETE");
  resetHeadingSetpoint();
}
void faceDir(uint8_t target) {
  uint8_t diff = (target + 4 - heading) & 3;
  if      (diff == 1) gyroTurn(TURN_RIGHT_DEG, true, 3500);
  else if (diff == 3) gyroTurn(TURN_LEFT_DEG, false, 3500);
  else if (diff == 2) gyroTurn(TURN_180_DEG, true, 6500);
  heading = target;
  delay(100);
}

// =============================================================================
//  PRE-TURN FRONT ALIGNMENT
//  If a wall is close ahead, creep forward to FRONT_ALIGN_CM so the upcoming
//  turn starts from a repeatable, wall-squared position (prevents clipping a
//  corner/pillar when pivoting from mid-tile). No effect if the way ahead is open.
// =============================================================================
void alignFrontIfWall() {
  for (int i = 0; i < 3; i++) { readAndFilter(); delay(5); }   // settle the filter
  if (frontFiltered > FRONT_APPROACH_CM) return;               // open ahead: nothing to align to

  unsigned long t0 = millis();
  while (frontFiltered > FRONT_ALIGN_CM && millis() - t0 < 1500) {
    readAndFilter();
    updateHeadingHold();
    int v = (int)(BASE_SPEED * 0.45f);   // gentle approach speed
    setMotorSpeeds(constrain(v - (int)gyroCorrFiltered, -255, 255),
                   constrain(v + (int)gyroCorrFiltered, -255, 255));
    delay(15);
  }
  stopMotors();
  delay(100);
  Serial.print("   [ALIGN] crept to front wall, F="); Serial.println(frontFiltered, 0);
}

// =============================================================================
//  MOVE ONE TILE  — purely time-based (ONE_TILE_MS), front wall only realigns
// =============================================================================
// Reverse straight back for `ms` while holding heading (v2 sign convention) --
// used to back out of a black hole roughly to the tile we came from.
void reverseForMs(unsigned long ms) {
  unsigned long t0 = millis();
  while (millis() - t0 < ms) {
    updateHeadingHold();
    setMotorSpeeds(constrain(-BASE_SPEED - (int)round(gyroCorrFiltered), -255, 255),
                   constrain(-BASE_SPEED + (int)round(gyroCorrFiltered), -255, 255));
    delay(20);
  }
  stopMotors();
  delay(140);
}

// Returns true if the robot actually advanced one tile. Returns false either
// because the way ahead was a wall (sensor misread / clip) OR because a BLACK
// hole was detected and we reversed out -- the caller checks `blackAbort` to
// tell the two apart.
bool driveOneTile() {
  blackAbort = false;
  // Prime the front filter so a STALE reading (e.g. ~5cm left over from
  // alignFrontIfWall, or the previous tile's end wall) can't trigger an instant
  // false front-stop that exits without moving (-> phantom tile / desync).
  frontFiltered = 200.0f;
  for (int i = 0; i < 4; i++) { readAndFilter(); delay(8); }

  unsigned long t0 = millis();
  bool earlyStop = false;
  int  darkCount = 0;
  movedBlueHits = 0;                              // reset blue tally for this move
  unsigned long lastColorMs = 0;                  // 0 -> sample on the first pass
  while (millis() - t0 < ONE_TILE_MS) {
    readAndFilter();
    updateHeadingHold();
    if (frontFiltered <= FRONT_STOP_CM) { earlyStop = true; break; }  // wall ahead

    // Color sampled on a ~50ms cadence (one fresh integration), decoupled from
    // the faster heading/wall control below so steering stays crisp.
    if (COLOR_ENABLED && millis() - lastColorMs >= COLOR_SAMPLE_MS) {
      lastColorMs = millis();
      uint16_t cr, cg, cb, cc;
      if (readColor(cr, cg, cb, cc)) {
        if (guessBlack(cr, cg, cb, cc)) {
          Serial.print("   [DARK] r/g/b/c="); Serial.print(cr); Serial.print('/');
          Serial.print(cg); Serial.print('/'); Serial.print(cb); Serial.print('/');
          Serial.print(cc); Serial.print(" bg="); Serial.print((int)cb - (int)cg);
          Serial.print(" @"); Serial.print(millis() - t0); Serial.print("ms n=");
          Serial.println(darkCount + 1);
          if (++darkCount >= BLACK_CONFIRM) {      // confirmed black -> abort
            stopMotors();
            unsigned long drove = millis() - t0;
            unsigned long backMs = (unsigned long)(drove * BLACK_REVERSE_FRAC);
            Serial.print("   [BLACK] hole ahead after "); Serial.print(drove);
            Serial.print("ms -> reversing out "); Serial.print(backMs); Serial.println("ms");
            led(60, 0, 70, 150);                   // PURPLE flash = black detected
            reverseForMs(backMs);                  // back out (fraction of forward time)
            blackAbort = true;
            return false;
          }
        } else {
          darkCount = 0;
        }
        // Only tally blue once the front sensor has cleared the previous tile.
        if ((millis() - t0) > BLUE_LEAD_SKIP_MS && guessBlue(cr, cg, cb, cc)) movedBlueHits++;
      }
    }
    applyWallCentering();
    delay(20);
  }
  stopMotors();
  unsigned long drove = millis() - t0;
  delay(140);

  // REALITY CHECK: if we slammed into a wall almost immediately, we did NOT
  // advance. Could be a genuine wall (e.g. 148cm specular misread of a pillar)
  // OR a doorframe clip from being off-center. Caller decides (recovery first).
  if (earlyStop && drove < MIN_TILE_PROGRESS_MS) {
    Serial.print("   [TILE] BLOCKED after "); Serial.print(drove);
    Serial.print("ms (F="); Serial.print(frontFiltered, 0);
    Serial.print(") -> stayed at ("); Serial.print(rx); Serial.print(","); Serial.print(ry); Serial.println(")");
    return false;
  }

  int oldx = rx, oldy = ry;
  rx = constrain(rx + DX[heading], 0, GRID - 1);
  ry = constrain(ry + DY[heading], 0, GRID - 1);
  Serial.print("   [TILE] ("); Serial.print(oldx); Serial.print(","); Serial.print(oldy);
  Serial.print(")->("); Serial.print(rx); Serial.print(","); Serial.print(ry);
  Serial.print(") face="); Serial.print(DNAME[heading]);
  Serial.print(" drove="); Serial.print(drove); Serial.print("ms");
  Serial.print(earlyStop ? " (front-wall stop, F=" : " (timed, F=");
  Serial.print(frontFiltered, 0); Serial.println(")");
  return true;
}

// Gentle timed nudge along the CURRENT heading (cm>0 forward, cm<0 back), used
// by RETRACK recovery to re-center longitudinally. Stops if a front wall is hit.
void nudge(int cm) {
  if (cm == 0) return;
  bool fwd = (cm > 0);
  unsigned long ms = (unsigned long)(ONE_TILE_MS * (abs(cm) / 30.0f));
  int spd = fwd ? (int)(BASE_SPEED * 0.5f) : -(int)(BASE_SPEED * 0.5f);
  unsigned long t0 = millis();
  while (millis() - t0 < ms) {
    readAndFilter();
    updateHeadingHold();
    if (fwd && frontFiltered <= FRONT_STOP_CM) break;
    setMotorSpeeds(constrain(spd - (int)gyroCorrFiltered, -255, 255),
                   constrain(spd + (int)gyroCorrFiltered, -255, 255));
    delay(15);
  }
  stopMotors(); delay(80);
}

// Turn toward d and advance one tile. If RETRACK_ENABLED and the move is blocked
// (clipped a doorframe because off-center), turn back to the corridor axis,
// re-center (front-align if a wall is there, else nudge), and retry before
// concluding it's a wall. A BLACK hole abort bails immediately (no re-drive into
// the hole) -- the caller marks the target black.
bool moveTile(uint8_t d, uint8_t entryHeading) {
  int maxAttempts = RETRACK_ENABLED ? 3 : 1;
  for (int attempt = 0; attempt < maxAttempts; attempt++) {
    if (attempt > 0) {
      Serial.print("   [RETRACK] re-center & retry ("); Serial.print(attempt); Serial.println(")");
      faceDir(entryHeading);          // back to the corridor axis
      alignFrontIfWall();             // if a corridor wall is ahead, this re-centers us
      nudge(attempt == 1 ? 7 : -14);  // else sweep longitudinally (+7, then -7 net)
    }
    if (d != heading) alignFrontIfWall();   // square to front wall before turning
    faceDir(d);
    if (driveOneTile()) return true;
    if (blackAbort) return false;           // hole -> don't retry, caller marks black
  }
  return false;
}

// =============================================================================
//  GRID HELPERS
// =============================================================================
inline bool inBounds(int x, int y) { return x >= 0 && x < GRID && y >= 0 && y < GRID; }
void setWall(int x, int y, uint8_t d, bool isWall) {
  if (!inBounds(x, y)) return;
  grid[x][y].known |= (1 << d);
  if (isWall) grid[x][y].walls |= (1 << d); else grid[x][y].walls &= ~(1 << d);
  int nx = x + DX[d], ny = y + DY[d];
  if (inBounds(nx, ny)) {
    uint8_t od = opposite(d);
    grid[nx][ny].known |= (1 << od);
    if (isWall) grid[nx][ny].walls |= (1 << od); else grid[nx][ny].walls &= ~(1 << od);
  }
}
inline bool passable(int x, int y, uint8_t d) { return (grid[x][y].known & (1 << d)) && !(grid[x][y].walls & (1 << d)); }

void senseCell() {
  // WRITE-ONCE: a cell is fully mapped (all 4 sides) on its first visit, when
  // we approach it head-on along the corridor (most reliable readings). On a
  // REVISIT (e.g. during backtracking) the same wall can be read by a different
  // sensor from a different angle (e.g. a front/back wall seen by a side sensor
  // at ~25 cm) and would flip a correct "wall" to a false "OPEN", creating a
  // phantom tile. So we only update the map the FIRST time we stand on a cell.
  bool revisit = grid[rx][ry].visited;

  // Majority-vote each side over SENSE_SAMPLES reads so one bad ping can't map a
  // phantom wall/opening.
  float l, f, r;
  int lv, fv, rv;
  bool lw = classifyWall(TRIG_LEFT,  ECHO_LEFT,  SIDE_WALL_CM,  l, lv);
  bool fw = classifyWall(TRIG_FRONT, ECHO_FRONT, FRONT_WALL_CM, f, fv);
  bool rw = classifyWall(TRIG_RIGHT, ECHO_RIGHT, SIDE_WALL_CM,  r, rv);

  if (!revisit) {
    uint8_t aF = heading, aL = (heading + 3) & 3, aR = (heading + 1) & 3, aB = (heading + 2) & 3;
    setWall(rx, ry, aF, fw);
    setWall(rx, ry, aL, lw);
    setWall(rx, ry, aR, rw);
    if (!firstCell) setWall(rx, ry, aB, false);  // came from behind -> open
    firstCell = false;
    grid[rx][ry].visited = true;
  }

  // BLUE checkpoint: combine blue seen while DRIVING in (movedBlueHits) with a
  // few reads now that we're stopped over the tile. Continuous sampling = reliable
  // detection. Handled on ANY arrival (forward OR backtrack); the cooldown only
  // blocks the tile immediately after a blue tile (front-sensor leakage guard).
  if (!COLOR_ENABLED) {
    // color layer off: no blue handling
  } else if (blueCooldown > 0) {
    blueCooldown--;
  } else {
    int blueHits = movedBlueHits;
    for (int i = 0; i < 6; i++) {
      uint16_t cr, cg, cb, cc;
      if (readColor(cr, cg, cb, cc) && guessBlue(cr, cg, cb, cc)) blueHits++;
      delay(50);   // ~one integration apart -> 6 DISTINCT samples (reads are non-blocking now)
    }
    if (blueHits >= BLUE_CONFIRM) {
      bool firstTime = !grid[rx][ry].blue;
      grid[rx][ry].blue = true;
      blueCooldown = BLUE_COOLDOWN_TILES;            // ignore blue on the next tile
      Serial.print("[BLUE] checkpoint at ("); Serial.print(rx); Serial.print(","); Serial.print(ry);
      Serial.print(firstTime ? ")  first" : ")  revisit"); Serial.print("  hits="); Serial.println(blueHits);
      stopMotors();
      for (int i = 0; i < 5; i++) { led(0, 0, 90, 500); delay(500); }  // blink 500on/500off, ~5s
    }
  }

  Serial.print("[CELL] ("); Serial.print(rx); Serial.print(","); Serial.print(ry);
  Serial.print(") face="); Serial.print(DNAME[heading]);
  Serial.print(revisit ? " (revisit, map kept)" : "");
  Serial.print(" | L="); Serial.print(lw ? "wall" : "OPEN");
  Serial.print(" F="); Serial.print(fw ? "wall" : "OPEN");
  Serial.print(" R="); Serial.print(rw ? "wall" : "OPEN");
  Serial.print("  ("); Serial.print(l,0); Serial.print("/"); Serial.print(f,0); Serial.print("/"); Serial.print(r,0);
  Serial.print(") votes L"); Serial.print(lv); Serial.print("/"); Serial.print(SENSE_SAMPLES);
  Serial.print(" F"); Serial.print(fv); Serial.print("/"); Serial.print(SENSE_SAMPLES);
  Serial.print(" R"); Serial.print(rv); Serial.print("/"); Serial.print(SENSE_SAMPLES);
  Serial.println();
}

int chooseUnvisitedDir() {
  // Explore THROUGH a blue tile normally: enter it once (scored on arrival), then
  // keep diving past it if open. Re-crossing blue is avoided later, during the
  // return phase, by the blue-avoiding flood-fill planner (see planNextStep).
  uint8_t order[3] = { heading, (uint8_t)((heading+3)&3), (uint8_t)((heading+1)&3) };
  for (int i = 0; i < 3; i++) {
    uint8_t d = order[i];
    if (!passable(rx, ry, d)) continue;
    if (grid[rx][ry].tried & (1 << d)) continue;
    int nx = rx + DX[d], ny = ry + DY[d];
    if (!inBounds(nx, ny) || grid[nx][ny].visited || grid[nx][ny].black) continue;
    return d;
  }
  return -1;
}

// True if cell (x,y) still has an exit worth exploring: a passable, in-bounds,
// not-yet-visited, non-black, untried neighbor (i.e. chooseUnvisitedDir would
// succeed if the robot were standing there). These are the exploration frontiers.
bool cellHasFrontier(int x, int y) {
  for (uint8_t d = 0; d < 4; d++) {
    if (!passable(x, y, d)) continue;
    if (grid[x][y].tried & (1 << d)) continue;
    int nx = x + DX[d], ny = y + DY[d];
    if (!inBounds(nx, ny) || grid[nx][ny].visited || grid[nx][ny].black) continue;
    return true;
  }
  return false;
}

// =============================================================================
//  FLOOD-FILL NAVIGATION (return / relocation planner)
// =============================================================================
// Breadth-first search over cells we have actually VISITED (confirmed safe: walls
// mapped, not a hole), moving only through known-OPEN walls. Finds the shortest
// route from the current cell to the nearest goal and returns the FIRST step
// (a direction 0..3), or -1 if no goal is reachable under the constraints.
//   goalIsStart=false -> nearest exploration frontier (a cellHasFrontier cell)
//   goalIsStart=true  -> the START cell (used once exploration is finished)
//   avoidBlue=true     -> never route THROUGH a scored blue tile (the cell we are
//                         standing on is exempt, so we can always leave it)
// Re-run every loop so the plan adapts as the map is corrected.
int8_t bfsFirstStep(bool goalIsStart, bool avoidBlue) {
  static int qx[GRID * GRID], qy[GRID * GRID];
  static bool seen[GRID][GRID];
  static int8_t firstStep[GRID][GRID];
  for (int x = 0; x < GRID; x++)
    for (int y = 0; y < GRID; y++) { seen[x][y] = false; firstStep[x][y] = -1; }

  int head = 0, tail = 0;
  seen[rx][ry] = true; qx[tail] = rx; qy[tail] = ry; tail++;
  while (head < tail) {
    int cx = qx[head], cy = qy[head]; head++;
    int8_t fs = firstStep[cx][cy];
    if (fs != -1) {   // skip the source itself (fs==-1): it is never a goal
      bool isGoal = goalIsStart ? (cx == START && cy == START) : cellHasFrontier(cx, cy);
      if (isGoal) return fs;
    }
    for (uint8_t d = 0; d < 4; d++) {
      if (!passable(cx, cy, d)) continue;            // wall between -> can't cross
      int nx = cx + DX[d], ny = cy + DY[d];
      if (!inBounds(nx, ny) || seen[nx][ny]) continue;
      if (!grid[nx][ny].visited) continue;           // only travel confirmed-safe cells
      if (grid[nx][ny].black) continue;              // never enter a hole
      if (avoidBlue && grid[nx][ny].blue) continue;  // avoid re-crossing blue
      seen[nx][ny] = true;
      firstStep[nx][ny] = (fs == -1) ? (int8_t)d : fs;
      qx[tail] = nx; qy[tail] = ny; tail++;
    }
  }
  return -1;
}

// Decide where to go when no unvisited neighbor is adjacent. Priority:
//   1. nearest frontier WITHOUT crossing blue (keep exploring blue-free areas)
//   2. else, if no frontiers remain, head HOME (start) WITHOUT crossing blue
//   3. worst case only: head HOME crossing blue (so we never get stuck in a loop)
// Returns a step direction 0..3, or -1 if there is genuinely nowhere left to go
// (exploration done AND already at start). *crossedBlue reports the fallback.
int8_t planNextStep(bool &goingHome, bool &viaBlue) {
  goingHome = false; viaBlue = false;
  int8_t s = bfsFirstStep(false, true);             // (1) frontier, avoid blue
  if (s >= 0) return s;
  goingHome = true;
  s = bfsFirstStep(true, true);                     // (2) home, avoid blue
  if (s >= 0) return s;
  s = bfsFirstStep(true, false);                    // (3) home, blue allowed
  if (s >= 0) { viaBlue = true; return s; }
  return -1;
}

// Per-direction map state at the current cell (why we explore vs backtrack).
void logNeighbors() {
  Serial.print("   [NBR]");
  for (uint8_t d = 0; d < 4; d++) {
    int nx = rx + DX[d], ny = ry + DY[d];
    Serial.print(" "); Serial.print(DNAME[d]); Serial.print("=");
    if (!(grid[rx][ry].known & (1 << d)))      { Serial.print("?"); continue; } // unknown
    if (grid[rx][ry].walls & (1 << d))         { Serial.print("W"); continue; } // wall
    // open: show neighbor coord + visited/tried/black flags
    Serial.print("open(");
    Serial.print(nx); Serial.print(","); Serial.print(ny); Serial.print(")");
    if (inBounds(nx, ny) && grid[nx][ny].visited) Serial.print("v");
    if (inBounds(nx, ny) && grid[nx][ny].black)   Serial.print("b");
    if (inBounds(nx, ny) && grid[nx][ny].blue)    Serial.print("u");   // blue checkpoint
    if (grid[rx][ry].tried & (1 << d))            Serial.print("t");
  }
  Serial.println();
}

void dumpGrid() {
  Serial.println("------ VISITED CELLS (relative to start) ------");
  for (int y = GRID - 1; y >= 0; y--)
    for (int x = 0; x < GRID; x++)
      if (grid[x][y].visited) {
        Serial.print("("); Serial.print(x - START); Serial.print(","); Serial.print(y - START); Serial.print(") ");
      }
  Serial.println();
  Serial.print("BLACK: ");
  for (int y = GRID - 1; y >= 0; y--)
    for (int x = 0; x < GRID; x++)
      if (grid[x][y].black) { Serial.print("("); Serial.print(x - START); Serial.print(","); Serial.print(y - START); Serial.print(") "); }
  Serial.println();
  Serial.print("BLUE:  ");
  for (int y = GRID - 1; y >= 0; y--)
    for (int x = 0; x < GRID; x++)
      if (grid[x][y].blue) { Serial.print("("); Serial.print(x - START); Serial.print(","); Serial.print(y - START); Serial.print(") "); }
  Serial.println();
  Serial.println("-----------------------------------------------");
}

// =============================================================================
//  SETUP
// =============================================================================
void setup() {
  Serial.begin(115200);
  pinMode(TRIG_LEFT, OUTPUT);  pinMode(ECHO_LEFT, INPUT);
  pinMode(TRIG_FRONT, OUTPUT); pinMode(ECHO_FRONT, INPUT);
  pinMode(TRIG_RIGHT, OUTPUT); pinMode(ECHO_RIGHT, INPUT);
  pinMode(M1A, OUTPUT); pinMode(M1B, OUTPUT);
  pinMode(M2A, OUTPUT); pinMode(M2B, OUTPUT);

  Wire.setSDA(SDA_PIN); Wire.setSCL(SCL_PIN); Wire.begin();

  // --- Victim detection setup (OpenMV UART, red LED, servo) ---
  Serial1.setRX(VICTIM_RX_PIN);
  Serial1.begin(115200);
  pinMode(RED_LED_PIN, OUTPUT);
  digitalWrite(RED_LED_PIN, LOW);
  victimServo.attach(SERVO_PIN);
  victimServo.writeMicroseconds(SERVO_REST_US);


  Serial.println("Initializing MPU...");
  byte status = mpu.begin();
  Serial.print("MPU status = "); Serial.println(status);
  delay(300);
  Serial.println("Calibrating MPU... KEEP STILL");
  mpu.calcOffsets(true, true);
  delay(300);
  mpu.update();
  headingSetpoint = mpu.getAngleZ();
  gyroCorrFiltered = 0;

  tcsReady = tcs.begin();
  Serial.println(tcsReady ? "TCS34725 READY" : "TCS34725 NOT FOUND (color disabled)");
  Serial.print("COLOR_ENABLED = "); Serial.println(COLOR_ENABLED ? "true" : "false");

  // Derive per-tile timing from the two calibration runs (difference method).
  msPerTile = (float)((long)CALIB_TIME_5_MS - (long)CALIB_TIME_3_MS) / 2.0f;
  if (msPerTile < 100) msPerTile = 100;
  // Speed-compensate: the calibration ran at CALIB_BASE_SPEED. At a different
  // BASE_SPEED the robot covers a tile in inversely proportional time, so scale
  // the per-tile time to keep the DISTANCE per move constant.
  msPerTile *= (float)CALIB_BASE_SPEED / (float)BASE_SPEED;
  long trimmed = (long)msPerTile - TILE_TRIM_MS;
  if (trimmed < 100) trimmed = 100;
  ONE_TILE_MS = (unsigned long)trimmed;

  pixels.begin(); pixels.clear(); pixels.show();
  stopMotors();

  for (int x = 0; x < GRID; x++)
    for (int y = 0; y < GRID; y++) { grid[x][y].visited = false; grid[x][y].walls = grid[x][y].known = grid[x][y].tried = 0; grid[x][y].black = grid[x][y].blue = false; }
  rx = START; ry = START; heading = 0; firstCell = true; mode = EXPLORING;
  movedBlueHits = 0; blueCooldown = 0; blackAbort = false;

  Serial.print("msPerTile = "); Serial.print(msPerTile, 1);
  Serial.print("  ONE_TILE_MS = "); Serial.println(ONE_TILE_MS);
  Serial.println("=== STEP 4 v2 COLOR: time-calibrated grid explorer + color ready ===");
  delay(1500);
}

// =============================================================================
//  MAIN — one DFS action per loop()
// =============================================================================
void loop() {
  checkVictimDetections();

  if (mode == DONE) { stopMotors(); delay(300); return; }

  senseCell();
  logNeighbors();

  int d = chooseUnvisitedDir();
  if (d >= 0) {
    grid[rx][ry].tried |= (1 << d);        // mark this exit tried regardless
    Serial.print("[MOVE] -> "); Serial.println(DNAME[d]);
    uint8_t entryHeading = heading;
    int fromx = rx, fromy = ry;
    int tx = rx + DX[d], ty = ry + DY[d];
    bool wasVisited = inBounds(tx, ty) && grid[tx][ty].visited;
    if (moveTile(d, entryHeading)) {
      if (wasVisited) led(0, 70, 0, 120);   // GREEN = re-entered a known cell
      else            led(70, 0, 0, 120);   // RED   = new cell
    } else if (blackAbort) {
      // BLACK hole -> reversed out, stayed put. Mark target blocked so DFS never
      // targets it again (and don't treat the side between us and it as a wall).
      if (inBounds(tx, ty)) grid[tx][ty].black = true;
      Serial.print("   [BLACK] ("); Serial.print(tx); Serial.print(","); Serial.print(ty);
      Serial.println(") marked black, staying put");
      led(60, 0, 70, 120);                  // PURPLE blip = black/blocked
    } else {
      // Still blocked after recovery -> it really is a wall. Correct the map.
      setWall(fromx, fromy, d, true);
      Serial.print("   [MOVE] blocked after recovery -> WALL "); Serial.println(DNAME[d]);
      led(70, 30, 0, 80);                   // AMBER blip = blocked/corrected
    }
    return;
  }

  // No unvisited neighbor adjacent -> flood-fill to the nearest frontier, else
  // home to start. The planner avoids re-crossing scored BLUE tiles, and only
  // routes through blue as a last resort to get home (never stuck in a loop).
  bool goingHome, viaBlue;
  int8_t back = planNextStep(goingHome, viaBlue);
  if (back >= 0) {
    Serial.print(goingHome ? "[HOME] -> " : "[BACK] -> "); Serial.print(DNAME[back]);
    if (viaBlue) Serial.print("  (no blue-free route home -> crossing blue)");
    Serial.println();
    led(70, 0, 70, 120);                   // MAGENTA = backtracking / relocating
    uint8_t entryHeading = heading;
    if (!moveTile(back, entryHeading)) {
      if (blackAbort) {
        int tx = rx + DX[back], ty = ry + DY[back];
        if (inBounds(tx, ty)) grid[tx][ty].black = true;   // shouldn't happen on a visited cell
        Serial.println("   [BACK] black hole on return path -> marked, re-planning");
      } else {
        setWall(rx, ry, back, true);        // map correction; BFS reroutes next loop
        Serial.print("   [BACK] blocked -> WALL "); Serial.println(DNAME[back]);
      }
    }
    return;
  }

  // planNextStep returned -1. Normal case: no frontiers left and we are already
  // at start -> exploration complete.
  if (rx == START && ry == START) {
    Serial.println("[DONE] exploration complete, back at start.");
    dumpGrid();
    led(0, 0, 90, 800);                    // BLUE = done
    mode = DONE;
    return;
  }
  // Anomaly: no plan but not at start (map says start is unreachable -- e.g. a
  // transient wall misread). Stop, dump, and finish rather than spin in place.
  Serial.println("[DONE] no route to start found (map anomaly) - stopping.");
  dumpGrid();
  led(90, 30, 0, 800);                     // AMBER = ended off-start
  mode = DONE;
}
