"""
Image classifier for v27Cam130S dataset.
Classes: H, S, U, background  |  Input: 64x40 RGB images
"""

import os
import sys
import csv
import shutil
import random
import math
from pathlib import Path
from collections import Counter

# ── install deps if missing ───────────────────────────────────────────────────
def _ensure(pkg, import_name=None):
    import importlib
    name = import_name or pkg
    try:
        importlib.import_module(name)
    except ImportError:
        print(f"Installing {pkg}...")
        os.system(f"{sys.executable} -m pip install {pkg} -q")

_ensure("torch")
_ensure("torchvision")
_ensure("matplotlib")
_ensure("scikit-learn", "sklearn")

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler
import torchvision.transforms as T
from PIL import Image
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use("Agg")          # no display needed
from sklearn.metrics import classification_report, confusion_matrix
import numpy as np

# ── config ────────────────────────────────────────────────────────────────────
DATA_DIR   = Path(__file__).parent / "v27Cam130S"
MODEL_PATH = Path(__file__).parent / "classifier.pt"
IMG_W, IMG_H = 64, 40
BATCH_SIZE   = 32
EPOCHS       = 100
LR           = 5e-4
SEED         = 42

# full-width U folder is named with a unicode char — normalise to "U"
CLASS_MAP = {"H": 0, "S": 1, "U": 2, "background": 3}
CLASS_NAMES = ["H", "S", "U", "background"]

# S and U are visually similar (both curved) — boost both heavily; H also needs help vs U
CLASS_WEIGHTS = [2.5, 3.5, 4.0, 0.5]   # [H, S, U, background]

torch.manual_seed(SEED)
random.seed(SEED)
DEVICE = torch.device("cuda" if torch.cuda.is_available() else
                       "mps"  if torch.backends.mps.is_available() else "cpu")
print(f"Device: {DEVICE}")

# ── dataset ───────────────────────────────────────────────────────────────────
class RCDataset(Dataset):
    def __init__(self, samples, transform):
        self.samples   = samples      # list of (path, label)
        self.transform = transform

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        path, label = self.samples[idx]
        img = Image.open(path).convert("RGB")
        return self.transform(img), label


def load_samples():
    samples = []
    for folder in DATA_DIR.iterdir():
        if not folder.is_dir():
            continue
        label = CLASS_MAP.get(folder.name)
        if label is None:
            print(f"  [skip] unknown folder: {folder.name}")
            continue
        jpgs = list(folder.glob("*.jpg"))
        for p in jpgs:
            samples.append((p, label))
    return samples


def split(samples, val_ratio=0.15, test_ratio=0.15):
    random.shuffle(samples)
    n = len(samples)
    n_val  = math.ceil(n * val_ratio)
    n_test = math.ceil(n * test_ratio)
    return samples[n_val + n_test:], samples[:n_val], samples[n_val:n_val + n_test]


# ── transforms ────────────────────────────────────────────────────────────────
MEAN = [0.485, 0.456, 0.406]
STD  = [0.229, 0.224, 0.225]

# Crop off the top 6px teal background bar, then resize back to IMG_H×IMG_W
_crop = T.Lambda(lambda img: T.functional.crop(img, 6, 0, img.height - 6, img.width))

train_tf = T.Compose([
    _crop,
    T.Resize((IMG_H, IMG_W)),
    T.RandomHorizontalFlip(),
    T.RandomAffine(degrees=15, translate=(0.1, 0.1), scale=(0.85, 1.15), shear=5),
    T.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.3),
    T.RandomGrayscale(p=0.1),
    T.ToTensor(),
    T.Normalize(MEAN, STD),
])

eval_tf = T.Compose([
    _crop,
    T.Resize((IMG_H, IMG_W)),
    T.ToTensor(),
    T.Normalize(MEAN, STD),
])

# ── model ─────────────────────────────────────────────────────────────────────
class SmallCNN(nn.Module):
    """Lightweight CNN for 64×40 images → 4 classes."""
    def __init__(self, num_classes=4):
        super().__init__()
        self.features = nn.Sequential(
            # block 1 – 64×40 → 32×20
            nn.Conv2d(3, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(),
            nn.Conv2d(32, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Dropout2d(0.1),

            # block 2 – 32×20 → 16×10
            nn.Conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.Conv2d(64, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Dropout2d(0.15),

            # block 3 – 16×10 → 8×5
            nn.Conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Dropout2d(0.2),
        )
        # 128 × 8 × 5 = 5120
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(128 * 8 * 5, 256),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(256, num_classes),
        )

    def forward(self, x):
        return self.classifier(self.features(x))


# ── training ──────────────────────────────────────────────────────────────────
def make_weighted_sampler(samples):
    counts = Counter(lbl for _, lbl in samples)
    total  = len(samples)
    weights = [total / counts[lbl] for _, lbl in samples]
    return WeightedRandomSampler(weights, num_samples=total, replacement=True)


def train_epoch(model, loader, criterion, optimizer):
    model.train()
    total_loss, correct = 0.0, 0
    for imgs, labels in loader:
        imgs, labels = imgs.to(DEVICE), labels.to(DEVICE)
        optimizer.zero_grad()
        out  = model(imgs)
        loss = criterion(out, labels)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * imgs.size(0)
        correct    += (out.argmax(1) == labels).sum().item()
    n = len(loader.dataset)
    return total_loss / n, correct / n


@torch.no_grad()
def eval_epoch(model, loader, criterion):
    model.eval()
    total_loss, correct = 0.0, 0
    for imgs, labels in loader:
        imgs, labels = imgs.to(DEVICE), labels.to(DEVICE)
        out  = model(imgs)
        loss = criterion(out, labels)
        total_loss += loss.item() * imgs.size(0)
        correct    += (out.argmax(1) == labels).sum().item()
    n = len(loader.dataset)
    return total_loss / n, correct / n


def plot_curves(history, save_path):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
    epochs = range(1, len(history["train_loss"]) + 1)
    ax1.plot(epochs, history["train_loss"], label="train")
    ax1.plot(epochs, history["val_loss"],   label="val")
    ax1.set_title("Loss"); ax1.legend()
    ax2.plot(epochs, history["train_acc"], label="train")
    ax2.plot(epochs, history["val_acc"],   label="val")
    ax2.set_title("Accuracy"); ax2.legend()
    plt.tight_layout()
    plt.savefig(save_path, dpi=120)
    print(f"Saved training curves → {save_path}")


# ── evaluation ────────────────────────────────────────────────────────────────
@torch.no_grad()
def full_eval(model, loader):
    model.eval()
    all_preds, all_labels = [], []
    for imgs, labels in loader:
        preds = model(imgs.to(DEVICE)).argmax(1).cpu()
        all_preds.extend(preds.tolist())
        all_labels.extend(labels.tolist())
    return all_labels, all_preds


@torch.no_grad()
def save_test_csv(model, test_samples, save_path):
    """Predict each test image individually and write per-image results to CSV."""
    model.eval()
    rows = []
    for img_path, true_idx in test_samples:
        img    = Image.open(img_path).convert("RGB")
        tensor = eval_tf(img).unsqueeze(0).to(DEVICE)
        logits = model(tensor)
        prob   = torch.softmax(logits, dim=1)[0]
        pred_idx  = prob.argmax().item()
        confidence = prob[pred_idx].item()
        rows.append({
            "filename":   img_path.name,
            "true":       CLASS_NAMES[true_idx],
            "predicted":  CLASS_NAMES[pred_idx],
            "correct":    "Y" if pred_idx == true_idx else "N",
            "confidence": f"{confidence:.4f}",
        })
    rows.sort(key=lambda r: (r["true"], r["filename"]))
    with open(save_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["filename", "true", "predicted", "correct", "confidence"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved test results  → {save_path}")


def plot_confusion(labels, preds, save_path):
    cm = confusion_matrix(labels, preds)
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(4)); ax.set_xticklabels(CLASS_NAMES)
    ax.set_yticks(range(4)); ax.set_yticklabels(CLASS_NAMES)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True")
    ax.set_title("Confusion Matrix (test set)")
    for i in range(4):
        for j in range(4):
            ax.text(j, i, cm[i, j], ha="center", va="center",
                    color="white" if cm[i, j] > cm.max() / 2 else "black")
    plt.colorbar(im, ax=ax)
    plt.tight_layout()
    plt.savefig(save_path, dpi=120)
    print(f"Saved confusion matrix → {save_path}")


# ── main ──────────────────────────────────────────────────────────────────────
def main():
    # data
    samples = load_samples()
    print(f"\nTotal images: {len(samples)}")
    for cname, cid in sorted(set((n, CLASS_MAP[n]) for n in CLASS_MAP), key=lambda x: x[1]):
        n = sum(1 for _, l in samples if l == cid)
        print(f"  {cname:12s}: {n}")

    train_s, val_s, test_s = split(samples)
    print(f"\nSplit  train={len(train_s)}  val={len(val_s)}  test={len(test_s)}")

    # copy test images into v27Test/<class>/ for manual inspection
    test_dir = Path(__file__).parent / "v27Test"
    for cls in CLASS_NAMES:
        (test_dir / cls).mkdir(parents=True, exist_ok=True)
    for img_path, label_idx in test_s:
        shutil.copy2(img_path, test_dir / CLASS_NAMES[label_idx] / img_path.name)
    print(f"Copied {len(test_s)} test image(s) → {test_dir}")

    train_ds = RCDataset(train_s, train_tf)
    val_ds   = RCDataset(val_s,   eval_tf)
    test_ds  = RCDataset(test_s,  eval_tf)

    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE,
                              sampler=make_weighted_sampler(train_s),
                              num_workers=0, pin_memory=False)
    val_loader   = DataLoader(val_ds,  batch_size=BATCH_SIZE, shuffle=False)
    test_loader  = DataLoader(test_ds, batch_size=BATCH_SIZE, shuffle=False)

    # model
    model     = SmallCNN(num_classes=4).to(DEVICE)
    w         = torch.tensor(CLASS_WEIGHTS, dtype=torch.float, device=DEVICE)
    criterion = nn.CrossEntropyLoss(weight=w)
    optimizer = optim.AdamW(model.parameters(), lr=LR, weight_decay=1e-4)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS)

    history = {"train_loss": [], "val_loss": [], "train_acc": [], "val_acc": []}
    best_val_acc = 0.0

    print(f"\nTraining for {EPOCHS} epochs …\n{'Epoch':>6} {'TrLoss':>8} {'TrAcc':>7} {'VaLoss':>8} {'VaAcc':>7}")
    print("-" * 45)
    for epoch in range(1, EPOCHS + 1):
        tr_loss, tr_acc = train_epoch(model, train_loader, criterion, optimizer)
        va_loss, va_acc = eval_epoch(model, val_loader,   criterion)
        scheduler.step()

        history["train_loss"].append(tr_loss)
        history["val_loss"].append(va_loss)
        history["train_acc"].append(tr_acc)
        history["val_acc"].append(va_acc)

        marker = " ◀ best" if va_acc > best_val_acc else ""
        if va_acc > best_val_acc:
            best_val_acc = va_acc
            torch.save(model.state_dict(), MODEL_PATH)

        if epoch % 5 == 0 or epoch == 1:
            print(f"{epoch:>6} {tr_loss:>8.4f} {tr_acc:>7.3f} {va_loss:>8.4f} {va_acc:>7.3f}{marker}")

    print(f"\nBest val accuracy: {best_val_acc:.3f}  →  model saved to {MODEL_PATH}")

    # plots
    base = Path(__file__).parent
    plot_curves(history, base / "training_curves.png")

    # test evaluation with best checkpoint
    model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE))
    labels, preds = full_eval(model, test_loader)
    print("\n── Test set report ──────────────────────────────")
    print(classification_report(labels, preds, target_names=CLASS_NAMES))
    plot_confusion(labels, preds, base / "confusion_matrix.png")
    save_test_csv(model, test_s, base / "test_results.csv")


if __name__ == "__main__":
    main()
