"""
Predict images in v27Cam130S_predict/ and move each to its predicted class subfolder.
Usage: python3 predict.py
"""

import os
import sys
import shutil
from pathlib import Path

import torch
import torch.nn as nn
import torchvision.transforms as T
from PIL import Image

# ── paths ─────────────────────────────────────────────────────────────────────
BASE_DIR    = Path(__file__).parent
MODEL_PATH  = BASE_DIR / "classifier.pt"
PREDICT_DIR = BASE_DIR / "v27Cam130S_predict"

CLASS_NAMES = ["H", "S", "U", "background"]
IMG_W, IMG_H = 64, 40
MEAN = [0.485, 0.456, 0.406]
STD  = [0.229, 0.224, 0.225]

DEVICE = torch.device("cuda" if torch.cuda.is_available() else
                       "mps"  if torch.backends.mps.is_available() else "cpu")

# ── model (must match train_classifier.py exactly) ────────────────────────────
class SmallCNN(nn.Module):
    def __init__(self, num_classes=4):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(),
            nn.Conv2d(32, 32, 3, padding=1), nn.BatchNorm2d(32), nn.ReLU(),
            nn.MaxPool2d(2), nn.Dropout2d(0.1),

            nn.Conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.Conv2d(64, 64, 3, padding=1), nn.BatchNorm2d(64), nn.ReLU(),
            nn.MaxPool2d(2), nn.Dropout2d(0.15),

            nn.Conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.ReLU(),
            nn.MaxPool2d(2), nn.Dropout2d(0.2),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(128 * 8 * 5, 256), nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(256, num_classes),
        )

    def forward(self, x):
        return self.classifier(self.features(x))


def load_model():
    if not MODEL_PATH.exists():
        sys.exit(f"Model not found: {MODEL_PATH}\nRun train_classifier.py first.")
    model = SmallCNN(num_classes=4).to(DEVICE)
    model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE))
    model.eval()
    return model


transform = T.Compose([
    T.Lambda(lambda img: T.functional.crop(img, 6, 0, img.height - 6, img.width)),
    T.Resize((IMG_H, IMG_W)),
    T.ToTensor(),
    T.Normalize(MEAN, STD),
])


def predict_image(model, img_path: Path) -> str:
    img    = Image.open(img_path).convert("RGB")
    tensor = transform(img).unsqueeze(0).to(DEVICE)
    with torch.no_grad():
        logits = model(tensor)
        prob   = torch.softmax(logits, dim=1)
        idx    = prob.argmax(1).item()
    confidence = prob[0, idx].item()
    return CLASS_NAMES[idx], confidence


def main():
    if not PREDICT_DIR.exists():
        sys.exit(f"Predict folder not found: {PREDICT_DIR}")

    # collect only jpg/png files directly inside PREDICT_DIR (not in subfolders)
    images = [p for p in PREDICT_DIR.iterdir()
              if p.is_file() and p.suffix.lower() in {".jpg", ".jpeg", ".png"}]

    if not images:
        print(f"No images found in {PREDICT_DIR}")
        return

    # create output subfolders
    for cls in CLASS_NAMES:
        (PREDICT_DIR / cls).mkdir(exist_ok=True)

    model = load_model()
    print(f"Device: {DEVICE}  |  Model: {MODEL_PATH.name}")
    print(f"Found {len(images)} image(s) to classify.\n")
    print(f"{'File':<30} {'Prediction':<12} {'Confidence':>10}")
    print("-" * 55)

    moved, errors = 0, 0
    for img_path in sorted(images):
        try:
            cls, conf = predict_image(model, img_path)
            dest = PREDICT_DIR / cls / img_path.name
            shutil.move(str(img_path), str(dest))
            print(f"{img_path.name:<30} {cls:<12} {conf:>9.1%}")
            moved += 1
        except Exception as e:
            print(f"{img_path.name:<30} ERROR: {e}")
            errors += 1

    print("-" * 55)
    print(f"\nDone — {moved} image(s) moved, {errors} error(s).")
    for cls in CLASS_NAMES:
        n = len(list((PREDICT_DIR / cls).glob("*")))
        if n:
            print(f"  {cls:12s}: {n} image(s)")


if __name__ == "__main__":
    main()
