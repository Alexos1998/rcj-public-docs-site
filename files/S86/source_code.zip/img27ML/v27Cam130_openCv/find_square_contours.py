import csv
import shutil
import cv2
import numpy as np
from pathlib import Path

AREA_MIN = 256
AREA_MAX = 625
RATIO_MIN = 0.9
RATIO_MAX = 1.1

BASE_DIR = Path(__file__).parent
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)
ANG90_DIR = BASE_DIR / "ang90_notCxCenter"
ANG90_DIR.mkdir(exist_ok=True)

# Progressive kernel sizes: try without morph first, then increasing close kernels
MORPH_KERNELS = [1, 3, 5, 7]


def find_square_contour(img_path):
    """Return the best matching contour (first found via progressive morph close)."""
    img = cv2.imread(str(img_path))
    if img is None:
        print(f"  [!] Cannot read {img_path.name}")
        return None, None

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (3, 3), 0)
    _, th = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    for k in MORPH_KERNELS:
        if k == 1:
            proc = th
        else:
            kernel = np.ones((k, k), np.uint8)
            proc = cv2.morphologyEx(th, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(proc, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if not (AREA_MIN <= area <= AREA_MAX):
                continue
            rect = cv2.minAreaRect(cnt)
            w, h = rect[1]
            if max(w, h) == 0:
                continue
            ratio = min(w, h) / max(w, h)
            if ratio < RATIO_MIN:
                continue
            return {
                "contour": cnt,
                "area": area,
                "rect": rect,
                "w": w,
                "h": h,
                "ratio": ratio,
                "angle": rect[2],
                "morph_k": k,
            }, img

    return None, img


def annotate_and_save(img, match, img_path, folder_name):
    out = img.copy()
    box = cv2.boxPoints(match["rect"])
    box = np.intp(box)
    cv2.drawContours(out, [box], 0, (0, 255, 0), 2)
    cx, cy = np.intp(match["rect"][0])
    label = (f"A={match['area']:.0f} R={match['ratio']:.2f} "
             f"ang={match['angle']:.1f} k={match['morph_k']}")
    cv2.putText(out, label, (cx - 55, cy - 8),
                cv2.FONT_HERSHEY_SIMPLEX, 0.32, (0, 200, 255), 1)

    out_path = OUTPUT_DIR / folder_name / img_path.name
    out_path.parent.mkdir(exist_ok=True)
    cv2.imwrite(str(out_path), out)
    return out_path


def process_folder(folder_name):
    folder = BASE_DIR / folder_name
    images = sorted(folder.glob("*.jpg")) + sorted(folder.glob("*.png"))
    print(f"\n=== {folder_name.upper()} ({len(images)} images) ===")

    csv_path = OUTPUT_DIR / f"{folder_name}_results.csv"
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["filename", "area", "aspect_ratio", "morph_k", "angle", "cx"])

        for img_path in images:
            match, img = find_square_contour(img_path)
            if match:
                out_path = annotate_and_save(img, match, img_path, folder_name)
                writer.writerow([
                    img_path.name,
                    f"{match['area']:.1f}",
                    f"{match['ratio']:.3f}",
                    match['morph_k'],
                    f"{match['angle']:.1f}",
                    f"{match['rect'][0][0]:.1f}",
                ])
                print(f"  {img_path.name}: area={match['area']:.1f}  "
                      f"w={match['w']:.1f} h={match['h']:.1f}  "
                      f"ratio={match['ratio']:.3f}  angle={match['angle']:.1f}°  "
                      f"morph_k={match['morph_k']}  -> {out_path.relative_to(BASE_DIR)}")
            else:
                writer.writerow([img_path.name, "", "", "", "", ""])
                print(f"  {img_path.name}: NO MATCH FOUND")

    print(f"  CSV saved: {csv_path.relative_to(BASE_DIR)}")


def collect_ang90_not_cx_center():
    """Copy images from real/ and fake/ that satisfy:
       -90 <= angle < -88  AND  (cx < 26 OR cx > 38)
    into ang90_notCxCenter/, prefixed with their source folder name.
    """
    copied = 0
    for folder_name in ("real", "fake"):
        folder = BASE_DIR / folder_name
        images = sorted(folder.glob("*.jpg")) + sorted(folder.glob("*.png"))
        for img_path in images:
            match, _ = find_square_contour(img_path)
            if not match:
                continue
            angle = match["angle"]
            cx = match["rect"][0][0]
            if -90 <= angle < -88 and (cx < 26 or cx > 38):
                dest = ANG90_DIR / f"{folder_name}_{img_path.name}"
                shutil.copy2(img_path, dest)
                print(f"  copied [{folder_name}] {img_path.name}  angle={angle:.1f}  cx={cx:.1f}")
                copied += 1
    print(f"\n  Total copied to ang90_notCxCenter: {copied}")


if __name__ == "__main__":
    process_folder("real")
    process_folder("fake")
    print(f"\nAnnotated images saved to: {OUTPUT_DIR}")
    print("\n=== Collecting ang90_notCxCenter ===")
    collect_ang90_not_cx_center()
