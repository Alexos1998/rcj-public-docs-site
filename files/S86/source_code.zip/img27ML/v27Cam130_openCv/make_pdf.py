from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, Preformatted, KeepTogether
)
from reportlab.lib.enums import TA_LEFT, TA_CENTER

OUTPUT = "/Users/jasontalk/Documents/RCJS2025/img27ML/v27Cam130_openCV/contour_detection_explained.pdf"

# ── Styles ────────────────────────────────────────────────────────────────────
base = getSampleStyleSheet()

title_style = ParagraphStyle("DocTitle",
    fontSize=22, leading=28, alignment=TA_CENTER,
    textColor=colors.HexColor("#1a237e"), spaceAfter=6,
    fontName="Helvetica-Bold")

subtitle_style = ParagraphStyle("DocSubtitle",
    fontSize=12, leading=16, alignment=TA_CENTER,
    textColor=colors.HexColor("#5c6bc0"), spaceAfter=20,
    fontName="Helvetica-Oblique")

h1_style = ParagraphStyle("H1",
    fontSize=15, leading=20, spaceBefore=18, spaceAfter=6,
    textColor=colors.white, fontName="Helvetica-Bold",
    backColor=colors.HexColor("#1a237e"),
    leftIndent=-0.3*cm, rightIndent=-0.3*cm,
    borderPad=5)

h2_style = ParagraphStyle("H2",
    fontSize=12, leading=16, spaceBefore=12, spaceAfter=4,
    textColor=colors.HexColor("#1a237e"), fontName="Helvetica-Bold")

body_style = ParagraphStyle("Body",
    fontSize=10, leading=15, spaceAfter=6,
    textColor=colors.HexColor("#212121"), fontName="Helvetica")

note_style = ParagraphStyle("Note",
    fontSize=9.5, leading=14, spaceAfter=6,
    textColor=colors.HexColor("#1b5e20"), fontName="Helvetica-Oblique",
    leftIndent=0.5*cm, borderPad=4,
    backColor=colors.HexColor("#f1f8e9"),
    borderColor=colors.HexColor("#a5d6a7"), borderWidth=1,
    borderRadius=3)

code_style = ParagraphStyle("Code",
    fontSize=8.5, leading=13, fontName="Courier",
    textColor=colors.HexColor("#212121"),
    backColor=colors.HexColor("#f5f5f5"),
    borderColor=colors.HexColor("#bdbdbd"), borderWidth=1,
    borderPad=6, spaceAfter=8, leftIndent=0.3*cm)

ascii_style = ParagraphStyle("ASCII",
    fontSize=8, leading=11, fontName="Courier",
    textColor=colors.HexColor("#37474f"),
    backColor=colors.HexColor("#eceff1"),
    borderColor=colors.HexColor("#90a4ae"), borderWidth=1,
    borderPad=6, spaceAfter=8, leftIndent=0.3*cm)

summary_style = ParagraphStyle("Summary",
    fontSize=9, leading=13, fontName="Courier",
    textColor=colors.HexColor("#1a237e"),
    backColor=colors.HexColor("#e8eaf6"),
    borderColor=colors.HexColor("#7986cb"), borderWidth=1,
    borderPad=8, spaceAfter=8)

def H1(text):
    return Paragraph(f"&nbsp;&nbsp;{text}", h1_style)

def H2(text):
    return Paragraph(text, h2_style)

def B(text):
    return Paragraph(text, body_style)

def Note(text):
    return Paragraph(f"<b>Key idea:</b> {text}", note_style)

def Code(text):
    return Preformatted(text, code_style)

def ASCII(text):
    return Preformatted(text, ascii_style)

def Gap(n=6):
    return Spacer(1, n)

def HR():
    return HRFlowable(width="100%", thickness=0.5,
                      color=colors.HexColor("#bdbdbd"), spaceAfter=4)

# ── Document ──────────────────────────────────────────────────────────────────
doc = SimpleDocTemplate(OUTPUT, pagesize=A4,
                        leftMargin=2*cm, rightMargin=2*cm,
                        topMargin=2*cm, bottomMargin=2*cm)
story = []

# Title
story += [
    Paragraph("Finding Shapes in Images", title_style),
    Paragraph("An OpenCV Contour Detection Guide for High School Students", subtitle_style),
    HR(), Gap(10),
]

# ── Section 1 ─────────────────────────────────────────────────────────────────
story += [
    H1("1. How a Computer \"Sees\" an Image"),
    B("A digital image is just a giant grid of tiny colored dots called <b>pixels</b>. "
      "Each pixel stores a number that represents its brightness or color."),
    Gap(),
    ASCII(
"Zoomed-in image (grayscale):\n"
"┌─────┬─────┬─────┬─────┬─────┐\n"
"│ 255 │ 240 │  10 │   8 │  12 │   0 = black\n"
"│ 230 │ 245 │   9 │  11 │   7 │   255 = white\n"
"│   5 │   8 │ 200 │ 210 │   6 │\n"
"│   7 │  10 │ 215 │ 205 │   9 │\n"
"└─────┴─────┴─────┴─────┴─────┘"
    ),
    B("A color image has <b>3 layers</b> — Red, Green, Blue (RGB). To simplify processing, "
      "we convert to <b>grayscale</b>: one layer where every pixel is just a brightness value from 0 to 255."),
    Code("gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)"),
    Note("Think of grayscale as a black-and-white photo. One number per pixel is all we need to find shapes."),
    Gap(),
]

# ── Section 2 ─────────────────────────────────────────────────────────────────
story += [
    H1("2. Gaussian Blur — Removing Noise"),
    B("Real camera images contain <b>noise</b> — random bright or dark pixels caused by the camera sensor. "
      "Noise looks like static on an old TV. If we don't remove it, those random speckles will be "
      "mistakenly detected as shapes."),
    Gap(),
    B("A <b>Gaussian blur</b> fixes this by replacing each pixel with the <b>weighted average</b> of "
      "its neighbors. Pixels that are closer contribute more to the average; pixels farther away "
      "contribute less. This weighting follows a <b>bell curve (Gaussian curve)</b> — that is where "
      "the name comes from."),
    Gap(),
    ASCII(
"Before blur:      After 5×5 Gaussian blur:\n"
"255  0  255       170  170  170\n"
"  0 255   0   →   170  170  170\n"
"255  0  255       170  170  170\n"
"\n"
"Sharp spikes of noise smooth out into gentle slopes."
    ),
    Code("blurred = cv2.GaussianBlur(gray, (5, 5), 0)\n"
         "#                               ↑↑↑\n"
         "#                   5×5 neighborhood window"),
    Note("The (5, 5) means we look at a 5-pixel wide, 5-pixel tall neighborhood around each pixel."),
    Gap(),
]

# ── Section 3 ─────────────────────────────────────────────────────────────────
story += [
    H1("3. Thresholding — Making It Black & White"),
    B("To find shapes, we need to separate the <b>object</b> (foreground) from the <b>background</b>. "
      "We do this with a rule called a <b>threshold</b>:"),
    Gap(),
    ASCII(
"Pixel value >  threshold  →  WHITE (255)\n"
"Pixel value <= threshold  →  BLACK  (0)"
    ),
    B("But which threshold value should we use? Different photos have different lighting. "
      "<b>Otsu's Method</b> solves this automatically. It looks at the histogram of all pixel "
      "brightness values and finds the value that best divides them into two groups: dark background "
      "and bright object."),
    Gap(),
    ASCII(
"Pixel count\n"
"  |    background       object\n"
"  |       ███          ████\n"
"  |      █████        ██████\n"
"  |     ███████      ████████\n"
"  └─────────────────────────────── brightness\n"
"  0    50   100   150   200   255\n"
"                   ↑\n"
"        Otsu picks this value automatically"
    ),
    Code("_, thresh = cv2.threshold(blurred, 0, 255,\n"
         "                          cv2.THRESH_BINARY + cv2.THRESH_OTSU)\n"
         "# The 0 means: let Otsu decide the threshold value"),
    Note("Otsu's method is like asking: where should I draw the line between 'dark' and 'bright' "
         "pixels so that both groups are as pure as possible?"),
    Gap(),
]

# ── Section 4 ─────────────────────────────────────────────────────────────────
story += [
    H1("4. Contours — Tracing the Outlines of Shapes"),
    B("After thresholding we have a <b>binary image</b> — only black and white pixels. "
      "A <b>contour</b> is a curve that traces around the boundary of a white region, "
      "like drawing an outline around a shape with a pen."),
    Gap(),
    ASCII(
"Binary image:             Contour found:\n"
"0 0 0 0 0 0 0             . . . . . . .\n"
"0 0 1 1 1 0 0             . . *─────* .\n"
"0 0 1 1 1 0 0     →       . . │     │ .\n"
"0 0 1 1 1 0 0             . . │     │ .\n"
"0 0 1 1 1 0 0             . . *─────* .\n"
"0 0 0 0 0 0 0             . . . . . . ."
    ),
    B("OpenCV finds <b>all</b> contours in one call:"),
    Code("contours, _ = cv2.findContours(\n"
         "    thresh,\n"
         "    cv2.RETR_TREE,           # find nested contours too\n"
         "    cv2.CHAIN_APPROX_SIMPLE  # store only corner points\n"
         ")"),
    B("Each contour is stored as a list of (x, y) coordinate points along its edge. "
      "One image can contain dozens or hundreds of contours — from large shapes to tiny specks."),
    Note("RETR_TREE means 'find all contours, including shapes inside other shapes.' "
         "CHAIN_APPROX_SIMPLE saves memory by only storing corners, not every single edge pixel."),
    Gap(),
]

# ── Section 5 ─────────────────────────────────────────────────────────────────
story += [
    H1("5. Filtering by Area"),
    B("Not every contour is the rectangle we are looking for. A speck of dust creates a tiny "
      "contour; the image border creates a huge one. We use <b>area</b> — the number of pixels "
      "enclosed inside the contour — as a size filter."),
    Gap(),
    B("We only keep contours whose area is between <b>256 and 625 pixels</b>:"),
    Gap(),
    ASCII(
"256 = 16 × 16   (our rectangle is at least this big)\n"
"625 = 25 × 25   (our rectangle is at most this big)"
    ),
    Code("area = cv2.contourArea(cnt)     # count pixels inside contour\n"
         "if not (256 <= area <= 625):\n"
         "    continue                    # skip — too small or too big"),
    Note("Think of this step like a sieve. Only objects of the right size pass through to the next step."),
    Gap(),
]

# ── Section 6 ─────────────────────────────────────────────────────────────────
story += [
    H1("6. The Rotated Rectangle — minAreaRect"),
    B("A regular bounding box always has sides parallel to the image edges. But our rectangle "
      "might be <b>tilted at any angle</b>. So we use a special OpenCV function: "
      "<b>cv2.minAreaRect()</b>. It finds the <b>smallest possible rectangle</b> that fits "
      "snugly around the contour, even if it is rotated."),
    Gap(),
    ASCII(
"Regular bounding box:       minAreaRect:\n"
"┌───────────────────┐            ╱───────╲\n"
"│   ╱───────────╲   │           ╱  shape  ╲\n"
"│  ╱    shape    ╲  │  →       ╲           ╱\n"
"│  ╲             ╱  │           ╲──────────╱\n"
"│   ╲────────────╱  │       Tight fit, follows the angle\n"
"└───────────────────┘"
    ),
    B("The function returns three things:"),
    Code("rect   = cv2.minAreaRect(cnt)\n"
         "center = rect[0]    # (x, y) position of the rectangle center\n"
         "size   = rect[1]    # (width, height) of the rectangle\n"
         "angle  = rect[2]    # rotation angle in degrees"),
    Note("minAreaRect works even when the rectangle is rotated 45 degrees, 30 degrees, or any angle. "
         "This is important because the rectangles in our images are not always perfectly upright."),
    Gap(),
]

# ── Section 7 ─────────────────────────────────────────────────────────────────
story += [
    H1("7. Checking the Shape — Width/Height Ratio"),
    B("A perfect <b>square</b> has equal width and height, so width ÷ height = 1.0. "
      "We allow a small tolerance for imperfect detection, accepting anything between "
      "<b>0.9 and 1.1</b>. We always divide the smaller side by the larger so the result "
      "is always ≤ 1.0, and check that it is ≥ 0.9:"),
    Gap(),
    ASCII(
"w=24, h=24  →  ratio = 24/24 = 1.00  ✓  perfect square\n"
"w=24, h=22  →  ratio = 22/24 = 0.92  ✓  close enough\n"
"w=24, h=10  →  ratio = 10/24 = 0.42  ✗  too elongated — not square"),
    Code("w, h  = rect[1]\n"
         "ratio = min(w, h) / max(w, h)   # always <= 1.0\n"
         "if ratio < 0.9:\n"
         "    continue    # skip — too stretched, not square-like"),
    Note("By dividing smaller/larger we avoid problems when width and height swap depending "
         "on rotation angle. The ratio 0.9–1.1 means we accept shapes that are at most 10% "
         "away from a perfect square."),
    Gap(),
]

# ── Section 8 ─────────────────────────────────────────────────────────────────
story += [
    H1("8. Why Fake Images Need Morphological Closing"),
    B("This is the trickiest part. The <b>fake images</b> have lower-contrast or partially "
      "broken rectangle edges, which causes the thresholding step to leave <b>gaps</b> in "
      "the contour. OpenCV then sees many small fragments instead of one solid rectangle:"),
    Gap(),
    ASCII(
"Real rectangle (solid edges):    Fake rectangle (broken edges):\n"
"\n"
"█████████                        █ █ █ █ █\n"
"█       █                        █       █\n"
"█       █                                 \n"
"█       █                                █\n"
"█████████                        █ █ █ █ █\n"
"\n"
"→ ONE contour, area = 576        → Many tiny fragments, each area ≈ 50"),
    H2("The Solution: MORPH_CLOSE"),
    B("<b>Morphological Closing</b> is a two-step operation that seals gaps and connects "
      "broken edges:"),
    Gap(),
    B("<b>Step 1 — Dilation:</b> Each white pixel expands outward, growing to fill nearby gaps."),
    ASCII(
"Before dilation:   █ _ █ _ █\n"
"After dilation:    ███████████    (gaps are filled)"
    ),
    B("<b>Step 2 — Erosion:</b> Shrink back to roughly the original size. The gaps stay "
      "filled because they were bridged by dilation first."),
    ASCII(
"After erosion:     █████          (back to original size, gaps gone)"
    ),
    Code("kernel = np.ones((k, k), np.uint8)    # k=3 means a 3×3 square\n"
         "proc   = cv2.morphologyEx(th, cv2.MORPH_CLOSE, kernel)"),
    H2("Progressive Kernel Sizes"),
    B("Bigger gaps need bigger kernels. We try them in order and stop at the first success:"),
    Gap(),
    ASCII(
"k=1  no morphology     for clean real images (no gaps)\n"
"k=3  closes ~2px gaps  for mildly broken edges\n"
"k=5  closes ~4px gaps  for moderately faint edges\n"
"k=7  closes ~6px gaps  for the hardest fake images"),
    Code("for k in [1, 3, 5, 7]:\n"
         "    if k == 1:\n"
         "        proc = thresh\n"
         "    else:\n"
         "        kernel = np.ones((k, k), np.uint8)\n"
         "        proc   = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)\n"
         "    # ... try to find matching contour in proc ..."),
    Note("Real images mostly need k=1 (no morphology needed). Fake images need k=3 to k=7. "
         "This difference in required kernel size is itself a clue that could help tell real "
         "from fake!"),
    Gap(),
]

# ── Section 9 ─────────────────────────────────────────────────────────────────
story += [
    H1("9. Drawing the Result"),
    B("Once we find the rectangle, we draw it on the image as a green rotated box. "
      "We use <b>cv2.boxPoints()</b> to convert the center/size/angle format into "
      "four corner coordinates, then draw lines between them:"),
    Code("box = cv2.boxPoints(match['rect'])  # get 4 corner (x,y) points\n"
         "box = np.intp(box)                  # round to integer pixels\n"
         "cv2.drawContours(out, [box], 0, (0, 255, 0), 2)  # green, 2px thick\n"
         "\n"
         "# Add a text label at the center\n"
         "label = f\"A={area:.0f} R={ratio:.2f} ang={angle:.1f}\"\n"
         "cv2.putText(out, label, (cx, cy), cv2.FONT_HERSHEY_SIMPLEX, 0.35, ...)"),
    Gap(),
    ASCII(
"Output image:\n"
"┌──────────────────────────┐\n"
"│                          │\n"
"│        ╱───────╲         │\n"
"│       ╱   ✓     ╲        │  ← green rotated rectangle\n"
"│       ╲          ╱       │\n"
"│        ╲────────╱        │\n"
"│  A=400 R=1.00 ang=-45    │  ← area, ratio, angle label\n"
"└──────────────────────────┘"),
    Note("The (0, 255, 0) color is green in BGR format (Blue=0, Green=255, Red=0). "
         "OpenCV uses BGR order instead of the more common RGB order."),
    Gap(),
]

# ── Section 10 — Summary ──────────────────────────────────────────────────────
story += [
    H1("10. Full Pipeline Summary"),
    B("Here is the complete journey from a raw camera image to a detected rectangle:"),
    Gap(),
    Preformatted(
"Camera Image (color, 3 channels)\n"
"         │\n"
"         ▼\n"
"  Convert to Grayscale          (simplify: 1 number per pixel)\n"
"         │\n"
"         ▼\n"
"  Gaussian Blur                 (remove noise with bell-curve averaging)\n"
"         │\n"
"         ▼\n"
"  Otsu Threshold                (auto split dark background / bright object)\n"
"         │\n"
"         ▼\n"
"  Morphological Close           (seal gaps, try k = 1, 3, 5, 7)\n"
"         │\n"
"         ▼\n"
"  Find All Contours             (trace outlines of white blobs)\n"
"         │\n"
"         ▼\n"
"  Filter by Area                (256 <= area <= 625 pixels)\n"
"         │\n"
"         ▼\n"
"  minAreaRect                   (fit tightest rotated rectangle)\n"
"         │\n"
"         ▼\n"
"  Filter by Ratio               (0.9 <= w/h <= 1.1  →  nearly square)\n"
"         │\n"
"         ▼\n"
"  Draw Green Box & Save Result",
    summary_style),
    Gap(10),
    H2("Key Observation from Results"),
    Gap(),
]

# Results table
table_data = [
    ["Property", "Real Images", "Fake Images"],
    ["morph_k needed", "Mostly 1 (clean edges)", "3 to 7 (broken edges)"],
    ["Rotation angles", "Varied: -29.7°, -45°, -60°, -90°", "All at -90° (axis-aligned)"],
    ["Area range", "261 – 591 px²", "263 – 576 px²"],
    ["Ratio range", "0.917 – 1.000", "0.917 – 1.000"],
]

t = Table(table_data, colWidths=[4*cm, 6.5*cm, 6.5*cm])
t.setStyle(TableStyle([
    ("BACKGROUND",   (0, 0), (-1, 0), colors.HexColor("#1a237e")),
    ("TEXTCOLOR",    (0, 0), (-1, 0), colors.white),
    ("FONTNAME",     (0, 0), (-1, 0), "Helvetica-Bold"),
    ("FONTSIZE",     (0, 0), (-1, -1), 9),
    ("BACKGROUND",   (0, 1), (0, -1), colors.HexColor("#e8eaf6")),
    ("FONTNAME",     (0, 1), (0, -1), "Helvetica-Bold"),
    ("ROWBACKGROUNDS", (1, 1), (-1, -1), [colors.white, colors.HexColor("#f5f5f5")]),
    ("GRID",         (0, 0), (-1, -1), 0.5, colors.HexColor("#9fa8da")),
    ("VALIGN",       (0, 0), (-1, -1), "MIDDLE"),
    ("LEFTPADDING",  (0, 0), (-1, -1), 6),
    ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ("TOPPADDING",   (0, 0), (-1, -1), 5),
    ("BOTTOMPADDING",(0, 0), (-1, -1), 5),
]))
story.append(t)
story.append(Gap(10))
story.append(Note(
    "The morph_k value and the rotation angle are potential machine learning features: "
    "real images have varied rotation angles and clean edges (k=1), while fake images "
    "are always axis-aligned and need gap-filling (k=3–7). This structural difference "
    "could help an ML model classify images automatically."
))

# Build
doc.build(story)
print(f"PDF saved to: {OUTPUT}")
