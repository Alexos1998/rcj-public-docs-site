import cv2
import numpy as np
from pathlib import Path
from find_square_contours import find_square_contour

BASE_DIR = Path(__file__).parent


def black_weight(pixels: np.ndarray, threshold: int = 128) -> int:
    """Count pixels darker than threshold (black pixels) in a 1-D or 2-D array."""
    return int((pixels < threshold).sum())


def process_image(img_path):
    match, img = find_square_contour(img_path)
    if match is None:
        print(f"  {img_path.name}: NO SQUARE FOUND")
        return

    # miniRect properties
    cx, cy = match["rect"][0]
    cx, cy = int(round(cx)), int(round(cy))
    rw, rh = int(round(match["w"])), int(round(match["h"]))

    # miniRect bounds (clamped to image)
    img_h, img_w = img.shape[:2]
    x0 = max(cx - rw // 2, 0)
    x1 = min(cx + rw // 2, img_w)
    y0 = max(cy - rh // 2, 0)
    y1 = min(cy + rh // 2, img_h)

    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Extract miniRect region
    roi = gray[y0:y1, x0:x1]
    area = roi.size  # rw * rh (actual pixel count inside clamped rect)
    S = int(roi.sum())
    s_per_area = S / area if area > 0 else 0

    # Extract bar regions from original gray BEFORE drawing (inside miniRect)
    h_bar = gray[max(cy - 1, y0):min(cy + 2, y1), x0:x1]   # horizontal bar
    v_bar = gray[y0:y1, max(cx - 1, x0):min(cx + 2, x1)]   # vertical bar

    h_black = black_weight(h_bar)
    v_black = black_weight(v_bar)

    # Draw bars (value 128) for visualisation
    gray[max(cy - 1, y0):min(cy + 2, y1), x0:x1] = 128
    gray[y0:y1, max(cx - 1, x0):min(cx + 2, x1)] = 128

    predict = "real" if s_per_area >= 135 else "fake"

    print(f"  {img_path.name}: cx={cx}  cy={cy}  angle={match['angle']:.1f}"
          f"  h_black={h_black}  v_black={v_black}"
          f"  S={S}  area={area}  S/area={s_per_area:.2f}  predict={predict}")
    return gray, cx, cy, match["angle"], h_black, v_black, S, area, s_per_area, predict


def process_folder_to_csv(folder_path: Path, csv_path: Path):
    import csv
    images = sorted(folder_path.glob("*.jpg")) + sorted(folder_path.glob("*.png"))
    print(f"\n=== {folder_path} ({len(images)} images) ===")

    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["filename", "cx", "cy", "angle", "h_black", "v_black",
                         "S", "area", "S_per_area", "predict"])
        for img_path in images:
            result = process_image(img_path)
            if result is None:
                writer.writerow([img_path.name] + [""] * 9)
                continue
            _, cx, cy, angle, h_black, v_black, S, area, s_per_area, predict = result
            writer.writerow([img_path.name, cx, cy, f"{angle:.1f}",
                             h_black, v_black, S, area, f"{s_per_area:.2f}", predict])

    print(f"  CSV saved: {csv_path}")


if __name__ == "__main__":
    for folder in ("real", "fake"):
        folder_path = BASE_DIR / folder
        images = sorted(folder_path.glob("*.jpg")) + sorted(folder_path.glob("*.png"))
        print(f"\n=== {folder.upper()} ({len(images)} images) ===")
        for img_path in images:
            process_image(img_path)

    # Process ang90_notCxCenter subfolders
    for symbol in ("omega", "phi", "psi"):
        folder = BASE_DIR / "ang90_notCxCenter" / symbol
        csv_path = folder / f"{symbol}_black_weights.csv"
        process_folder_to_csv(folder, csv_path)
