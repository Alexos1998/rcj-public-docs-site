import cv2 as cv
import numpy as np


Lower_Green = np.array([40, 150, 70])
Upper_Green = np.array([80, 255, 255])


Lower_Red1 = np.array([0, 120, 70])  
Upper_Red1 = np.array([10, 255, 255])


Lower_Red2 = np.array([170, 120, 70]) 
Upper_Red2 = np.array([180, 255, 255])


def go_to_red(frame):# find the red box

    TARGET_AREA = 359000  
    MIN_SPEED = 20       
    MAX_SPEED = 50        
    CENTER_THRESHOLD = 15
    #settings
    
    lspeed, rspeed = 0, 0
    reached_red = False

    hsv_frame = cv.cvtColor(frame, cv.COLOR_BGR2HSV) #convert to hsv
    red_mask1 = cv.inRange(hsv_frame, Lower_Red1, Upper_Red1) # mask 1
    red_mask2 = cv.inRange(hsv_frame, Lower_Red2, Upper_Red2) # mask 2
    red_mask = cv.bitwise_or(red_mask1, red_mask2) # combined mask with bitwise or
    
    contours, _ = cv.findContours(red_mask, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE) # contours
    frame_height, frame_width, _ = frame.shape # unpack the frame size
    center_x = int(frame_width // 2) # get center

    # Filter small noise
    red_contours = [c for c in contours if cv.contourArea(c) > 3000]

    if not red_contours:# rotate right till the box is seen
        print("Looking for red box...")
        return -22, 22, False  # Slightly slower search turn for better detection


    contour = max(red_contours, key=cv.contourArea)# biggest contour
    x, y, w, h = cv.boundingRect(contour)# get the bounding box
    center_of_red_box = int(x + (w / 2))
    area_of_red_box = w * h
    
    error = center_x - center_of_red_box
    Kp = 0.11 
    steering = int(Kp * error)

    distance_ratio = min(area_of_red_box / TARGET_AREA, 1.0) # calcuate how far u are from box
    
    base_speed = int(MAX_SPEED - (distance_ratio * (MAX_SPEED - MIN_SPEED))) # vary speed accordingly
    
    #       like speedz
    lspeed = base_speed + steering
    rspeed = base_speed - steering

    # Apply limits (constarints to speed) to prevent being too fast
    lspeed = max(min(lspeed, 35), -35)
    rspeed = max(min(rspeed, 35), -35)
    
    if area_of_red_box >= TARGET_AREA: # box reached lenthwise
        if abs(error) < CENTER_THRESHOLD: # centered
            reached_red = True
            lspeed, rspeed = 0, 0
            print(f"LOCKED ON: {area_of_red_box}")
        else: # adjusting right and left only
            lspeed = steering
            rspeed = -steering
            print("Final centering adjustment...")

    # Visual Feedback
    cv.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2) # draw bounding box
    cv.line(frame, (center_x, 0), (center_x, frame_height), (255, 255, 0), 1) # draw a line with the width of the box
    
    return lspeed, rspeed, reached_red


def go_to_green(frame): # same as before

    TARGET_AREA = 359000  
    MIN_SPEED = 20       
    MAX_SPEED = 50        
    CENTER_THRESHOLD = 15
    
    lspeed, rspeed = 0, 0
    reached_green = False

    hsv_frame = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
    green_mask = cv.inRange(hsv_frame, Lower_Green, Upper_Green)
    kernel = np.ones((3, 3), np.uint8)
    green_mask = cv.morphologyEx(green_mask, cv.MORPH_CLOSE, kernel, iterations=4)
    grn_contours, _ = cv.findContours(green_mask, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
    
    contours, _ = cv.findContours(green_mask, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
    frame_height, frame_width, _ = frame.shape
    center_x = int(frame_width // 2)

    # Filter small noise
    grn_contours = [c for c in contours if cv.contourArea(c) > 3000]

    if not grn_contours:
        print("Looking for green box...")
        return -22, 22, False  # Slightly slower search turn for better detection

    # Focus on the largest red object
    contour = max(grn_contours, key=cv.contourArea)
    x, y, w, h = cv.boundingRect(contour)
    center_of_green_box = int(x + (w / 2))
    area_of_green_box = w * h
    
    error = center_x - center_of_green_box
    Kp = 0.11 
    steering = int(Kp * error)

    distance_ratio = min(area_of_green_box / TARGET_AREA, 1.0)
    
    base_speed = int(MAX_SPEED - (distance_ratio * (MAX_SPEED - MIN_SPEED)))

    lspeed = base_speed + steering
    rspeed = base_speed - steering

    # Apply limits
    lspeed = max(min(lspeed, 35), -35)
    rspeed = max(min(rspeed, 35), -35)
    
    if area_of_green_box >= TARGET_AREA:
        if abs(error) < CENTER_THRESHOLD:
            reached_green = True
            lspeed, rspeed = 0, 0
            print(f"LOCKED ON: {area_of_green_box}")
        else:
            #s If we are close but not centered, slow down and just pivot
            lspeed = steering
            rspeed = -steering
            print("Final centering adjustment...")

    # Visual Feedback
    cv.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
    cv.line(frame, (center_x, 0), (center_x, frame_height), (255, 255, 0), 1)
    
    return lspeed, rspeed, reached_green
