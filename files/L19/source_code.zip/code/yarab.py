from picamera2 import Picamera2, Preview  # Raspberry Pi camera library
from green import green  # Custom green marker detection function
import cv2 as cv  # OpenCV for computer vision
import os
import numpy as np  # Array/math operations
import time
from ultralytics import YOLO  # AI model library
import serial  # UART communication
from libcamera import controls  # Camera controls like focus
from linef import line, steering,run_evacuation_zone, detect_silver, read_imu 
# Import custom robot functions

import math


folder_name = "new_silver"
os.makedirs(folder_name, exist_ok=True)  
# Create folder if it doesn't already exist


# =========================
# NUMERIC VARIABLES
# =========================

Black_Threshold = 140  # Threshold for black line detection
Black_Threshold_Tee = 100  # Threshold for tee intersections

kp = 0.5  # PID proportional constant
ki = 0  # PID integral constant
kd = 0.025  # PID derivative constant

speedz = 40  # Base robot speed


# =========================
# ToF SENSOR PLACEHOLDERS
# =========================

s1 = None 
s2 = None 
s3 = None 
# Distance sensors not initialized yet


# =========================
# BOOLEAN FLAGS
# =========================

SilverDetected = False
GreenDetected = False
RedDetected = False
# Robot state flags


# =========================
# SERIAL SETUP
# =========================

try:
    ser = serial.Serial('/dev/ttyUSB1', 57600)  
    # Open motor controller serial port

    ser.reset_input_buffer()  
    # Clear old serial data

    ser.write(f"{0} {0} {1} s \n".encode('utf-8'))  
    # Send startup stop command

except serial.SerialException as e:

    ser = serial.Serial('/dev/ttyUSB0', 57600)  
    # Backup serial port if first one fails

    ser.reset_input_buffer()

    print(f"Error opening serial port: {e}")

    ser.write(f"{0} {0} {1} s \n".encode('utf-8'))


# =========================
# YOLO MODEL
# =========================

print("Loading YOLO Model...")

model = YOLO(
    "/home/kol5ara/Downloads/ball_detect_s_edgetpu.tflite",
    task="detect"
)
# Load AI object detection model


# =========================
# MAIN CAMERA
# =========================

picam2 = Picamera2(1)

camera_config = picam2.create_still_configuration(
    main={"size": (1400, 1500), "format": "RGB888"}
)
# Configure camera resolution + color format

picam2.configure(camera_config)

picam2.set_controls({
    "AfMode": controls.AfModeEnum.Manual,
    "LensPosition": 10.0
})
# Manual focus to prevent autofocus hunting

picam2.set_controls({
    "NoiseReductionMode": 0,
    "FrameRate": 90
})
# Disable noise reduction and force high FPS

picam2.start()


# =========================
# SECOND CAMERA
# =========================

picam_silver = Picamera2(0)
# Second camera for evacuation zone

config_silver = picam_silver.create_still_configuration(
    main={"size": (1024, 448), "format": "RGB888"}
)

picam_silver.configure(config_silver)

picam_silver.set_controls({
    "AfMode": controls.AfModeEnum.Manual,
    "LensPosition": 9.0
})

picam_silver.start()


# =========================
# RED HSV RANGES
# =========================
#                      H    S    V
lower_red1 = np.array([0, 100, 100])
upper_red1 = np.array([10, 255, 255])

lower_red2 = np.array([160, 100, 100])
upper_red2 = np.array([179, 255, 255])

# Red needs TWO ranges in HSV because hue wraps around


last_time = time.time()


# =========================
# MAIN LOOP
# =========================

while True:

    try:

        current_time = time.time()

        dt = current_time - last_time  
        # Time between loops

        last_time = current_time

        image = picam2.capture_array()  
        # Capture camera frame

        if dt == 0:
            dt = 0.001  
            # Prevent division by zero in PID


        # =========================
        # BLACK LINE PROCESSING
        # =========================

        ROI_Black = image[600:950,100:1400-100].copy()
        # Crop only region where line exists

        ROI_Black = cv.resize(ROI_Black, (600, 215))
        # Resize for faster processing

        Black_Mask = cv.cvtColor(ROI_Black, cv.COLOR_BGR2GRAY)
        # Convert to grayscale

        Black_Mask = cv.inRange(
            Black_Mask,
             Black_Threshold,
            255,
            cv.THRESH_BINARY_INV
        )
        # Create binary black/white mask

        Black_Mask = cv.bitwise_not(Black_Mask)
        # Invert colorss

        kernel = np.ones((4, 4), np.uint8)

        Black_Mask = cv.morphologyEx(
            Black_Mask,
            cv.MORPH_CLOSE,
            kernel,
            iterations=4
        )
        # Fill holes/remove noise

        contours_blk, _ = cv.findContours(
            Black_Mask,
            cv.RETR_TREE,
            cv.CHAIN_APPROX_SIMPLE
        )
        # Detect blobs/contours

#-------- line detection
        # =========================
        # GREEN DETECTION
        # =========================

        ROI_Green = image[:900, :]
        # Crop top area for green markers

        ROI_Green = cv.resize(ROI_Green, (700, 450))

        move_instructions = {
            "forward": False,
            "right": False,
            "left": False,
            "turn": False
        }

        forward, right, left, turn, ROI_Green, green_mask, GreenDetected = green(ROI_Green)
        # Run green marker detection


        # =========================
        # TEE DETECTION
        # =========================

        ROI_Tee = image[:300,:]
        # Crop upper region for tee intersections

        Black_Mask_Tee = cv.cvtColor(ROI_Tee, cv.COLOR_BGR2GRAY)

        Black_Mask_Tee = cv.inRange(
            Black_Mask_Tee,
            Black_Threshold_Tee,
            255,
            cv.THRESH_BINARY_INV
        )

        Black_Mask_Tee = cv.bitwise_not(Black_Mask_Tee)

        kernell = np.ones((3, 3), np.uint8)

        Black_Mask_Tee = cv.morphologyEx(
            Black_Mask_Tee,
            cv.MORPH_CLOSE,
            kernell,
            iterations=4
        )

        contours_blkk, __ = cv.findContours(
            Black_Mask_Tee,
            cv.RETR_TREE,
            cv.CHAIN_APPROX_SIMPLE
        )


        # =========================
        # SILVER DETECTION
        # =========================

        ROI_Silver = image[:880,310:1190]
        # Crop silver tile area

        ROI_Silver = cv.resize(ROI_Silver, (220, 220))
        # Resize to AI model input size

        cls,conf = detect_silver(ROI_Silver)
        # Run AI classification


        # =========================
        # RED DETECTION
        # =========================

        hsv = cv.cvtColor(ROI_Black, cv.COLOR_BGR2HSV)
        # Convert image to HSV

        mask1 = cv.inRange(hsv, lower_red1, upper_red1)
        mask2 = cv.inRange(hsv, lower_red2, upper_red2)

        red_mask = cv.bitwise_or(mask1, mask2)
        # Combine both red masks

        contours, _ = cv.findContours(
            red_mask,
            cv.RETR_EXTERNAL,
            cv.CHAIN_APPROX_SIMPLE
        )

        for contour in contours:

            area = cv.contourArea(contour)
            # Measure contour size

            if area > 250000:
                RedDetected = True
                # Ignore tiny red noise


        # =========================
        # SILVER TILE ACTION
        # =========================

        if cls == "Silver":

            cv.putText(
                ROI_Silver,
                "silver",
                (10, 150),
                cv.FONT_HERSHEY_SIMPLEX,
                1,
                (255, 10, 28),
                2
            )

            print("Silver Detected!")

            ser.write(f"{0} {0} {0} s \n".encode('utf-8'))
            # Stop motors

            time.sleep(0.5)
            # run_evacuation_zone() #NOTE:add the arguments to the function!
            # Let robot settle before evacuation mode


        elif cls == "Tee":

            print("Tee detected")

            ser.write(f"{0} {0} {0} s \n".encode('utf-8'))
            # Stop at tee


        # =========================
        # RED TILE STOP
        # =========================

        if RedDetected :

            ser.write(f"{0} {0} {0} s \n".encode('utf-8'))
            # Stop robot

            time.sleep(6)
            # Wait on red tile


        # =========================
        # LINE CONTOUR FILTERING
        # =========================

        if len(contours_blk) > 0 and not RedDetected:

            max_contour = max(contours_blk,key=cv.contourArea)
            # Use biggest contour as the line

            contour_area = cv.contourArea(max_contour)

            if contour_area < 5000:
                contours_blk = []
                # Ignore tiny blobs


        # =========================
        # PID LINE FOLLOWING
        # =========================

        if len(contours_blk) > 0 and not RedDetected :

            error, ang, centerx_blk, centery_blk = line(
                max_contour,
                ROI_Black
            )
            # Calculate line position

            P_value = error * kp
            # Proportional term

            sumerror += error
            # Accumulate error

            I_value = sumerror * ki
            # Integral term

            I_value = max(min(I_value,50),-50)
            # Clamp integral to avoid runaway

            D_value = kd * (error - previous_error) / dt
            # Derivative term

            previous_error = error

            if -10 < error < 10:
                I_value = 0
                # Reset integral near center

            steer = P_value + I_value + D_value
            # Final steering value

            rspeed, lspeed = steering(speedz, steer)
            # Convert steering into wheel speeds


        # =========================
        # GREEN MARKER ACTIONS
        # =========================

        if GreenDetected and not RedDetected:

            if turn:

                ser.write(f"{80} {-140} {1} s\n".encode('utf-8'))
                # Rotate robot sharply

                time.sleep(1)

            elif left:

                ser.write(f"{0} {100} {1} s \n".encode('utf-8'))
                # Turn left

                time.sleep(0.6)

            elif right:

                ser.write(f"{100} {0} {1} s \n".encode('utf-8'))
                # Turn right

                time.sleep(0.6)

            elif forward:

                ser.write(f"{50} {50} {1} s \n".encode('utf-8'))
                # Drive straight

                time.sleep(0.1)

############################################################################ stopped here
        # =========================
        # DEBUG DISPLAY
        # =========================

        target_width = min( #find smallest width
            ROI_Black.shape[1],
            ROI_Green.shape[1]
        )

        Black_Resized = cv.resize(#resize both to smaller width
            ROI_Black,
            (target_width, ROI_Black.shape[0])
        )

        Green_Resized = cv.resize(#resize both to smaller width
            ROI_Green,
            (target_width, ROI_Green.shape[0])
        )

        Stacked_Frames = np.vstack( # put frames above each other (1 window view)
            (Black_Resized, Green_Resized)
        )
        # Stack debug images vertically


        output = ( # flushprint example!
            f"Speed(L/R):{int(lspeed)}/{int(rspeed)} "
            f"| Err:{int(error)} "
            f"| P:{int(P_value)} "
            f"I:{int(I_value)} "
            f"D:{int(D_value)}"
        )

        print(output, end='\r', flush=True)
        # Live PID debug info


        cv.imshow("Stacked Frame", Stacked_Frames)
        # Show debug window

        cv.imshow("Tee",ROI_Silver)

        cv.imshow("mask",red_mask)


        # =========================
        # KEYBOARD CONTROLS
        # =========================

        key = cv.waitKey(1) & 0xFF

        if key == ord('c'):# take screenshots when C is pressed

            screenshot_name = os.path.join(
                folder_name,
                f"screenshot_{screenshot_count}.png"
            )

            cv.imwrite(screenshot_name, image)
            # Save screenshot

            screenshot_count += 1


        elif key == ord('s'):#press s to stop

            ser.write(f"{0} {0} {1} s \n".encode('utf-8'))
            # led on


        elif key == ord('q'): #quit code

            ser.write(f"{0} {0} {0} s \n".encode('utf-8'))
            # led off

            break
            # Exit program


        else:
            ser.write(f"{rspeed} {lspeed} {1} s \n".encode('utf-8'))
            # Normal continuous motor update


    except Exception as e:

        print(f"An error occurred: {e}")

        try:
            ser.write(f"{rspeed} {lspeed} {0} s \n".encode('utf-8'))
            # Stop motors on crash

        except:
            pass

        break


cv.destroyAllWindows()
# Close OpenCV windows

picam2.stop()
# Stop main camera

picam_silver.stop()
# Stop second camera