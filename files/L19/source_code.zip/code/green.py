import cv2 as cv
import numpy as np
import math



def green(roig):
    # Initialize detection status
    GreenDetected = False
    global x1_center 
    global y1_center 
    global x2_center
    global y2_center
    x1_center=0
    y1_center=0
    y2_center=0
    x2_center=0
    
    

    # Convert to HSV format
#     kernel = np.ones((3, 3), np.uint8)
#     dilate_kernel = np.ones((9, 9), np.uint8)
    Green_HSV = cv.cvtColor(roig, cv.COLOR_BGR2HSV) #hsv cov

    Lower_Green = np.array([35, 50, 50]) # max and min thresholds
    Upper_Green = np.array([85, 255, 255])

    green_mask = cv.inRange(Green_HSV, Lower_Green, Upper_Green) #make mask from thresholds

    # Find contours in the green mask
    contours = []
    green_contours, _ = cv.findContours(green_mask, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE) # find contours

    
    for contour in green_contours: # only use big contours (avoid noise)
        contour1_area = cv.contourArea(contour)
        if contour1_area > 110000:
            contours.append(contour)

    # Initialize movement instructions list
    move_instructions = {"forward": False, "right": False, "left": False, "turn": False}
    
    if not len(contours): # no green
        return (move_instructions["forward"], move_instructions["right"], 
                move_instructions["left"], move_instructions["turn"], roig,green_mask,GreenDetected)        
    
     # Check for the first contour and process it
    if len(contours) >= 1:
        GreenDetected = True

        x1, y1, w1, h1 = cv.boundingRect(contours[0]) # finds coords of bounding box

        cv.rectangle(roig, (x1, y1), (x1 + w1, y1 + h1), (0, 255, 0), 2) #draws green box around contour


        x1_center = x1 + w1 // 2
        y1_center = y1 + h1 // 2
        # get center of contour
        
        # Define regions for checking black color
        left1 = x1_center - w1 // 2 - 30 # left of green
        right1 = x1_center + w1 // 2 + 30 # right of green
        top1 = y1_center - h1 // 2 - 30 # above green

        bottom1 = y1_center + h1 // 2 + 30 # below green (only used for debug shapes) 


        # check for black around the first contour 
        top1_black = is_black(roig, top1 , x1_center) # above green
        right1_black = is_black(roig, y1_center , right1) # right of green
        left1_black = is_black(roig, y1_center , left1) # left of green

        # Draw additional shapes
        draw_debug_shapes(roig, x1_center, y1_center, top1, bottom1, left1, right1)

    # Check for the second contour and process it
    if len(contours) >= 2:
        GreenDetected = True
        x2, y2, w2, h2 = cv.boundingRect(contours[1]) # finds coords of bounding box
        cv.rectangle(roig, (x2, y2), (x2 + w2, y2 + h2), (0, 0, 255), 2) #draws green box around contour

        x2_center = x2 + w2 // 2
        y2_center = y2 + h2 // 2
        # center of contour

        # Define regions for checking black color
        top2 = y2_center - h2 // 2 - 20 # above green (only above beacuse 2 greens = turn, so no right/left, only fake/not fake)


        right2 = x2_center + w2 // 2 + 20 # right of green (only used for debug shapes)
        left2 = x2_center - w2 // 2 - 20 # left of green (only used for debug shapes)
        bottom2 = y2_center + h2 // 2 + 20 # below green (only used for debug shapes)
        #these only used for debug shapes because this is a turn, so only top is needed. 

        # check for black above the first contour (to find if the turn is fake)
        top2_black = is_black(roig, top2 , x2_center) # only top is needed beacuse this is a turn

        # Draw additional shapes
        draw_debug_shapes(roig, x2_center, y2_center, top2, bottom2, left2, right2)

    distance = math.sqrt((x2_center - x1_center) ** 2 + (y2_center - y1_center) ** 2) # find distance between 2 contours (for turning)
##### last

    #       (turn)          (not fake)      (not fake) (turn not 2 seperate greens)
    #      2 greens        black above g1  black above g2  close dist together
    if len(contours) >= 2 and top1_black and top2_black and 400<distance<700:
        move_instructions["turn"] = True #tell robot to turn

    #       1 green    
    elif len(contours) >= 1:
        #  (not fake)       (near the robot)
        #  no black below   close to bottom
        if top1_black and y1_center >= 600 :
            move_instructions["right"] = left1_black and not right1_black # or statement, if left to contour is black, then go right
            move_instructions["left"] = right1_black and not left1_black # or statement, if right to contour is black, then go left

            
    # no condition matches = no greens = move fwds
    if not any(move_instructions.values()):
        move_instructions["forward"] = True

    return (move_instructions["forward"], move_instructions["right"], 
            move_instructions["left"], move_instructions["turn"], roig,green_mask,GreenDetected)


def is_black(roig, y, x):
    """Check if a pixel is black."""
    if 0 <= y < roig.shape[0] and 0 <= x < roig.shape[1]:
        b, g, r = roig[y, x]
        return (r, g, b) <= (200, 200, 200) # threshold of black
    return False


def draw_debug_shapes(roig, x_center, y_center, top, bottom, left, right):
    """Draw debug shapes on the roig."""
    cv.circle(roig, (x_center, top), 4, (0, 255, 53), 3)
    cv.circle(roig, (x_center, bottom), 4, (255, 0, 255), 3)
    cv.circle(roig, (left, y_center), 4, (0, 255, 53), 3)
    cv.circle(roig, (right, y_center), 4, (255, 0, 255), 3)
    cv.circle(roig, (x_center, y_center), 4, (0, 0, 255), 3)

