import cv2 as cv
import numpy as np
import math
from ultralytics import YOLO
import time
from function_of_evacuation_zone import go_to_green, go_to_red
from picamera2 import Picamera2


model = YOLO("/home/kol5ara/Desktop/RoboCup2026/silverr_int8.tflite", task="classify")
SET_X = 600
#        biggest contour detected
def line(max_contour,image):

    black_box = cv.minAreaRect(max_contour) # get bounding box for biggest line contour

    (x_min, y_min), (w_min, h_min), ang = black_box # unpack data from the bounding box

    centerx_blk = x_min + (w_min / 2) #center X of bounding box
    centery_blk = y_min + (h_min / 2) #center Y of bounding box
    
    if w_min > h_min:
        ang = ang - 90
    
    ang = int(ang) #remove decimals

    box = cv.boxPoints(black_box) #get points of box

    box = np.intp(box) #remove decimals

    setpoint = SET_X / 2 #center point for line calcs (normal line)

    error = int(x_min - setpoint) #deviation (error) calc

    cv.drawContours(image, [box], 0, (0, 0, 255), 3) #drawing the bounding box around contour

    cv.putText(image, str(ang), (10, 40), cv.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2) # show angle

    cv.putText(image, str(error), (int(x_min), int(y_min)), cv.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2) #show error at bottom right of bounding box

    return error, ang, centerx_blk, centery_blk # return data

    
def steering(speed,steer):
    
    lspeeed=(speed-(steer))
    rspeeed=(speed+(steer))

    lspeed=lspeeed
    rspeed=rspeeed
    
    return rspeed,lspeed


def map_range(x, old_min, old_max, new_min, new_max): # arduino map-like
    return ((x - old_min) / (old_max - old_min)) * (new_max - new_min) + new_min
 

def is_black(roi, y, x): # same as green ifblk
    """Check if a pixel is black."""
    if 0 <= y < roi.shape[0] and 0 <= x < roi.shape[1]:
        b, g, r = roi[y, x]
        return (r, g, b) <= (150, 150, 150)
    return False


def draw_debug_shapes(roi, x_center, y_center, top, bottom, left, right):
    """Draw debug shapes on the ROI."""
    cv.circle(roi, (x_center, top), 4, (0, 255, 53), 3)
    cv.circle(roi, (x_center, bottom), 4, (255, 0, 255), 3)
    cv.circle(roi, (left, y_center), 4, (0, 255, 53), 3)
    cv.circle(roi, (right, y_center), 4, (255, 0, 255), 3)
    cv.circle(roi, (x_center, y_center), 4, (0, 0, 255), 3)
    # cv.namedWindow("roi_left", cv.WINDOW_NORMAL)
    # cv.resizeWindow("roi_left", 700,400)
    # cv.namedWindow("roi_right", cv.WINDOW_NORMAL)
    # cv.resizeWindow("roi_right", 700,400)


def detect_silver(silver_frame):
     
    silver = False
    suml = 0
    results = model.predict(silver_frame, imgsz=224, conf=0.6,verbose=False) # run model

    if results and results[0].probs is not None: # if model found silver
        probs = results[0].probs # unpack probability (confidence)

        top_class = int(probs.top1) # unpack class (category)
        
        class_name = model.names[top_class] # convert top class to name
        confidence = float(probs.top1conf) #convert top confidence to a float
        
    return class_name, confidence #return the data

def read_tof(ser):
    ser.reset_input_buffer()# clear buffer

    linee = ser.readline() # read data
    if not linee: # no data
        return None

    linee = linee.decode(errors="ignore").strip()  # '8191,57,8191'
    parts = linee.split(",")

    if len(parts) != 3:
        return None

    tof_r, tof_l, tof_f = parts

    try:
        tof_R = int(tof_r)
        tof_L = int(tof_l)
        tof_F = int(tof_f)
    except ValueError:
        return None

    return tof_R, tof_L, tof_F

yaw_offset = None
pitch_offset = None
roll_offset = None

def read_imu(ser):
    """
    Reads yaw, pitch, roll from IMU via UART.
    Applies zero-offset on first reading.
    Returns a tuple: (yaw, pitch, roll) in degrees.
    """
    global yaw_offset, pitch_offset, roll_offset

    try:
        ser.reset_input_buffer() # clear buffer
        line = ser.readline() # clear buffer

        if not line:
            return None  # no data yet

        line = line.decode(errors="ignore").strip() #decoding

        if line.startswith("#YPR="):
            try:
                y_str, r_str, p_str = line[5:].split(",") #unpack data

                yaw = float(y_str) # convert string to float
                pitch = float(p_str) # convert string to float
                roll = float(r_str) # convert string to float

                # set offsets on first reading (calibration)
                if yaw_offset is None:
                    yaw_offset = yaw
                    pitch_offset = pitch
                    roll_offset = roll

                # subtract offsets
                yaw_zeroed = ((yaw - yaw_offset + 180) % 360) - 180
                pitch_zeroed = ((pitch - pitch_offset + 180) % 360) - 180
                roll_zeroed = ((roll - roll_offset + 180) % 360) - 180

                return yaw_zeroed, pitch_zeroed, roll_zeroed

            except ValueError: # wrong data received (corrupted)
                print("Malformed line:", line)
                return None

    except (serial.SerialException, OSError) as e:
        print("UART crashed, reopening:", e)
        traceback.print_exc()
        return None
    
lower_black = np.array([0, 0, 0])
upper_black = np.array([180, 255, 50])

lower_silver = np.array([0, 0, 180])
upper_silver = np.array([180, 60, 255])



# evac tmrw
def run_evacuation_zone(ser, picam_silver, model, s1, s2,s3, picam2):

    silver_collected_count = 0
    silver_needed = 2
    black_collected = False 
    is_busy = False 
    #NOTE: is_busy is used when the robot is stopped to do something, it is
    # set to true so the code keeps sending (0,0) to prevent the robot from moving
    Going_to_red_box = False
    Going_to_green_box = False
    
    move_strap = False
    finding_exit = False
    LedState = 0

    search_dir = 1  # direction flip (1 rotate CW 0 rotate CCW)


    # ===== BLACK HSV Thresholds =====
    lower_black = np.array([0, 0, 0])
    upper_black = np.array([180, 255, 50])
    
    

    while True:

        silver = False

        # ==========================
        # CAMERA INPUT
        # ==========================
        frame = picam_silver.capture_array() # get room camera frame
        
        frame = cv.rotate(frame, cv.ROTATE_180) # flip the frame (camera is mounted upside down for cable)
        
        center_x = frame.shape[1] // 2 # centerpoint of frame
        
        frame2 = picam2.capture_array() # get line camera frame

        # ==========================
        # SPLIT ROI
        # ==========================
        roi_full = frame2[600:950, 100:1300]
        roi_full = cv.resize(roi_full, (600, 215))

        h, w, _ = roi_full.shape
        roi_left  = roi_full[:, :w//2]
        roi_right = roi_full[:, w//2:]
        # This is because they detect using ROIs, if ball is in left ROI then go left, in right ROI go right.

        # ==========================
        # BLACK DETECTION (SAFE)
        # ==========================
        hsv_left  = cv.cvtColor(roi_left, cv.COLOR_BGR2HSV)
        hsv_right = cv.cvtColor(roi_right, cv.COLOR_BGR2HSV)
        # covert both ROIs to HSV

        mask_left  = cv.inRange(hsv_left, lower_black, upper_black)
        mask_right = cv.inRange(hsv_right, lower_black, upper_black)
        # mask both ROIs with the black mask

        cont_left, _  = cv.findContours(mask_left, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
        cont_right, _ = cv.findContours(mask_right, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
        # get contours in both ROIs

        # SAFE AREA CALCULATION
        area_left = float(sum(cv.contourArea(c) for c in cont_left)) if len(cont_left) > 0 else 0.0
        area_right = float(sum(cv.contourArea(c) for c in cont_right)) if len(cont_right) > 0 else 0.0


        # ==========================
        # SILVER DETECTION
        # ==========================
        # Silver balls are detected using an AI model because silver cannot be seen by the camera
        ROI_Silver = frame2[:980, 310:1190]
        ROI_Silver = cv.resize(ROI_Silver, (220, 220))

        clss, conf = detect_silver(ROI_Silver) # YOLO model function

        if clss == "Silver" and conf > 0.6: # Silver & more than 60% conf
            silver = True

        # DEBUG WINDOWS
#         cv.imshow("LEFT MASK", mask_left)
#         cv.imshow("RIGHT MASK", mask_right)

        # ==========================
        # EXIT LOGIC
        # ==========================
        if finding_exit:
            s1.update()
            s2.update()
            s3.update()
            # Update ToFs
            dist_center = s1.latest_dist
            dist_left = s2.latest_dist
            dist_right = s3.latest_dist
            
#             print(f"center : {dist_center} , left : {dist_left} , right : {dist_right}")

            # -------- SEARCH --------
            if not move_strap:
                if dist_center > 1000:
#                     print("EXIT FOUND → CHECK STRAP")
                    move_strap = True
                    
                else:
#                     print(f"SEARCHING... {dist_center}")
#                     print(dist_center)
                    ser.write(f"{26 * search_dir} {-26 * search_dir} 0 s\n".encode())

            # -------- APPROACH STRAP --------
            else:
                ser.write(f"{70} {70} 0 s\n".encode())
                if dist_right < 35:
#                     print("turn left")
                    ser.write(f"{-25} {25} 0 s\n".encode())
                elif dist_right > 35 and dist_right < 50:   
                    print("turn right")
                    ser.write(f"{-25} {25} 0 s\n".encode())
                    
                elif dist_right > 105 and dist_center < 115:
                    print("turn left")
                    ser.write(f"{-25} {25} 0 s\n".encode())
#                 elif dist_right < 60:
#                     print("turn right")
#                     ser.write(f"{-35} {35} 0 s\n".encode())
#                 else:
#                     if dist_right > 860:
#                         print("turn left")
#                         ser.write(f"{35} {-35} 0 s\n".encode())
#                     elif dist_right < 850:
#                         print("turn right")
#                         ser.write(f"{-35} {35} 0 s\n".encode())
#                 threshold = 100
#                 hysteresis= 20
# 						
#                 diff = dist_left - dist_right
# 
#                 if abs(diff) < threshold:
#                     print("move forward")
#                     ser.write(f"{70} {70} 0 s\n".encode())
#                 elif diff > threshold + hysteresis:
#                     print("turn left")
#                     ser.write(f"{35} {-35} 0 s\n".encode())
#                 elif diff < (threshold + hysteresis):
#                     print("turn right")
#                     ser.write(f"{-35} {35} 0 s\n".encode())

                # ==========================
                # DECISION
                # ==========================

                # ===== SILVER =====
#                 if silver:
#                     print("SILVER → WRONG EXIT")
# 
#                     ser.write(f"50 -50 0 s\n".encode())
#                     time.sleep(1.2)
# 
#                     ser.write(f"35 35 0 s\n".encode())
#                     time.sleep(2.0)
# 
#                     # flip search direction
#                     search_dir *= -1
# 
#                     move_strap = False
# 
#                 # ===== BLACK =====
#                 elif (area_left > 3000) or (area_right > 3000):
# 
#                     print("BLACK DETECTED")
# 
#                     if area_right > area_left:
#                         print("BLACK RIGHT → TURN LEFT")
#                         ser.write(f"0 0 0 s\n".encode())
#                         time.sleep(6)
# 
#                     elif area_left > area_right:
#                         print("BLACK LEFT → TURN RIGHT")
#                         ser.write(f"0 0 0 s\n".encode())
#                         time.sleep(8)
# 
#                     else:
#                         print("CENTER → STRAIGHT")
# 
#                     ser.write(f"30 30 0 s\n".encode())
#                     time.sleep(0.8)
# 
#                     ser.write(f"0 0 0 s\n".encode())
# 
#                     return   # EXIT CLEANLY

            continue

        # ==========================
        # BALL DETECTION
        # ==========================
        results = model.predict(frame, imgsz=(512, 224), conf=0.3, iou=0.2, agnostic_nms=True, workers=4, verbose=False)  # verbose=True to enable debug info
#         print(f"class = {results}")
        ball_detected = False
        

        # ==========================
        # BOX DELIVERY
        # ==========================
        if (Going_to_green_box or Going_to_red_box) and not is_busy:
            lspeed, rspeed, reached = go_to_green(frame,s1) if Going_to_green_box else go_to_red(frame)# try green, if done then try red
            
            if reached:
                ser.write(f"30 30 {LedState} s\n".encode()); time.sleep(1)
                ser.write(f"0 0 {LedState} c\n".encode()); time.sleep(1.2)
                ser.write(f"-70 -70 {LedState} s\n".encode()); time.sleep(3.1)
                ser.write(f"0 0 {LedState} s\n".encode()); time.sleep(0.8)
            
                if Going_to_red_box:
                    black_collected = True
                
                if silver_collected_count >= silver_needed and black_collected: # all 3 balls completed
#                     print("--- SWITCHING TO EXIT MODE ---")
                    finding_exit = True
                
                Going_to_red_box = Going_to_green_box = is_busy = False


        # ==========================
        # BALL PICKUP
        # ==========================
        if results and results[0].boxes:# there is 1 resut for a ball
            for box in results[0].boxes:
                cls = int(box.cls[0])# get the class (category/type of ball)

                x1, y1, x2, y2 = map(int, box.xyxy[0]) # unpack ball coords
                cx = (x1 + x2) // 2 # find center

                print(f"detected class {cls}") # print which ball


                # Set ball bounding box colours
                color = (0, 0, 255) if cls == 0 else (0, 255, 0)
                label = "Black Ball" if cls == 0 else "Silver Ball"
                # Red bounding box for Black and Green bounding box for Silver

                #CLASS 0 = BLACK | CLASS 1 = Silver Ball


                cv.rectangle(frame, (x1, y1), (x2, y2), color, 2) # draw the bounding box
                cv.putText(frame, label, (x1, y1 - 10),
                           cv.FONT_HERSHEY_SIMPLEX, 0.6, color, 2) # put text showing label (which ball)

                #   SILVER       Less than 2 collected                       Black        black wasnt collected
                if (cls == 1 and silver_collected_count < silver_needed) or (cls == 0 and not black_collected):
                    ball_detected = True

                    cx = (x1 + x2) // 2 # get ball center by add
                    area = (x2 - x1) * (y2 - y1) / 20 # get ball area


                
            error = center_x - cx # ball center diff from frame center

            print(f"error : {error}")

            if -30< error <30: # close to middle
                if area >= 5300: # close lengthwise
                    #NOTE: Arm Commands:
                    # D = stowed upward, still attached
                    # B = collect ball
                    # C = throw ball
                    # S = Unnatched, Free to move


                    ser.write(f"0 0 {LedState} b\n".encode()); time.sleep(1.4) # collect the ball

                    ser.write(f"0 0 {LedState} d\n".encode()); time.sleep(0.8) # raise the arm

                    if cls == 1:# was a silver ball
                        silver_collected_count += 1
                        Going_to_green_box = True # move to the green box to drop it
                    else:
                        Going_to_red_box = True # ball is black, move to red box to drop it
               
                else: # ball wasnt close lengthwise, but centered, so keep moving fwd
                  ser.write(f"30 30 {LedState} d\n".encode())
            else:# ball isnt centered      
              error = center_x - cx # get center diff
              lspeed, rspeed = (25, -25) if error > 0 else (-25, 25) # if error is -ve turn left, +ve then turn right
              print("another")
                

        cv.imshow("frame",frame) # show the frame



        # ==========================
        # DEFAULT SEARCH
        # ==========================
        if not ball_detected and not is_busy and not (Going_to_green_box or Going_to_red_box):# no ball seen, not going to a box, and
            ser.write(f"25 -25 {LedState} d\n".encode())


        if cv.waitKey(1) & 0xFF == ord('q'): # quit code if q is clicked
            break