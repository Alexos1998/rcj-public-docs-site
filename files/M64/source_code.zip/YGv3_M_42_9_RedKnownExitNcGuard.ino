

// MAIN: 走行（直進=壁補正 / 壁無し=Yaw補正 / 旋回=絶対角度で90°停止）
// OLED：Yaw/Pitch小 + 2行目に座標(大) + 3行目に「方角,回数,被災者」
// 座標更新：30cm走行中に「15cm到達」で1回だけ更新（区間内最大1回）
// 拡張左手法：壁マップ優先、訪問回数最小優先、同率なら左→前→右→後
//
// ★色分類＋黒タイル動作復活版（MAIN主導・停止中だけ判定）
// ★回転中はMAIN側ToFを読まない版
//   - gTurningActive中は serviceMainTof() 内で即returnし、VL53L0XのI2C読み取りをしない
//   - SUBからの C,STOP / C,GO / C,K / C,B / C,R は処理しない
//   - 常時カラー監視はしない。30cm前進中、7cm地点と13cm地点でMAINがSUBへ色分類(CL?)を要求
//   - SUBは154msで1回読み、白/黒/青/赤/その他を分類し、CL,W / CL,K / CL,B / CL,R / CL,N を返す
//   - 黒は原則CL,Kで前方を仮想壁化。7cmのCL,Kだけは+2cm前進して9cmで再判定
//   - 青は7cm/13cmで候補フラグだけ立て、30cm完了後に青座標記録・訪問回数+2・BLUEを5秒表示
//   - 赤は7cm/13cmで前方タイルへ記録。通常はノーマル探索完了(N-)後まで一時進入禁止
//   - 5分経過しても未突入なら、保険として記録済み赤入口へRed_Number(BFS)で向かう
//   - 赤入口到達後は通常訪問+1だけで、REDを3秒表示し、レッドゾーン攻略へ移行
//
// ★壁押し当てジャイロ補正（新方式：基本ソフト）
//   - ソフト補正量>=5° が2回連続 → 2回目で物理RST(1.5s) + OLED表示
//
// ★定期的な意図的壁当て（停止中）
//   - 電源ON(boot)から 0スロットでも対象
//   - 「前が壁になった瞬間（前ToFが130mm未満になった瞬間）」に候補を立てる
//   - その時点の「電源ONからの30秒スロット」が nextWallHitSlot 以上なら実行
//   - 実行後 nextWallHitSlot を +1（次は30秒後…）
//
// ★両タッチ最優先：
//   - 直進中：両タッチ → ジャイロ補正 → 3cmバック → 拡張左手法へ
//   - 旋回中：両タッチは完全無視
//
// ★回転スタック救済（バックアップ機能）
//   - 2026.4.26：現在は完全OFF（コードは残す）
//   - 理由：回転中の被災者発見5秒停止を、回転スタックと誤判定して2cmバックする副作用を防ぐ
//   - 将来ONに戻しても、被災者停止/T180停止中は救済バックしない
//
// ★坂・階段検知＋前進地形通過モード
//   - 2026.5.20：旧バック登り処理を削除し、UP/DOWN確定後は前進継続で地形を通過する
//   - 2026.5.20：地形通過中は左/右/180°旋回、UNKNOWN確認、Frontier判断、色検知、被災者処理を禁止
//   - 2026.5.20：地形通過中に座標更新した坂セルをSLとして記録し、出口の平地マスはSLにしない
//   - 2026.5.20：地形通過開始から6cm以上進んだ後、abs(Pitch)<5°が0.8秒続いたらフロア切替
//   - 2026.5.20：地形通過中は前ToF(S2)による前壁/片タッチターン判定を使わない
//   - 2026.5.23：通常直進中はPitchが+5°以上まで上がった後、+5°未満へ下がった時点でバンプ確定し、最大値1回分だけ距離補正する
//   - 2026.5.23：坂UP確定は、UP?開始から8cm以上、かつ+8°以上を維持した場合だけに変更する
//   - 2026.5.23：バンプ判定LOW/MEDIUM/HIGHのOLED表示を座標更新後も3秒間強制継続する
//   - 2026.5.23：短時間で終わったUP?候補でも、最大Pitchが+4°以上ならLOWバンプとして確定する
//   - 2026.5.23：バンプ検知した進行先マスをBPとして記録し、OLEDの方角・訪問回数の右に表示する
//   - 2026.5.23：地形開始から直線上4マス以内の+8°/-8°両検知でTR:STAIRを表示するデバッグ判定を追加
//   - 2026.5.23：TR:RAMP判定を直線上4マス到達時点で確定するように変更（5マス目まで待たない）
//   - 2026.5.23：TR:STAIR判定後も直線上4マス以内は観察を継続し、追加の登り/下りを同じ階段として扱う
//   - 2026.5.23：TR:STAIR/TR:UNKはフロア切替なし、TR:RAMP確定時だけフロア切替するゲートを追加
//   - 2026.5.23：地形観察中に曲がった場合は保留し、次座標へ正常移動できたらTR:RAMP確定にする
//   - 2026.5.23：坂出口マスのUNKNOWN無視は後ろ方向だけにし、左右UNKNOWNは探索候補に戻す
//   - 2026.5.23：坂出口マスexitX/exitYは、坂セル左右壁自動BLOCKEDから必ず除外する
//   - 2026.5.23：坂出口マスexitX/exitYは通常探索へ戻すが、既存の左右壁情報は保持する
//   - 2026.5.23：フロア切替PENDING時点で旧フロア側の坂出口マスを先に通常探索へ戻す
//   - 2026.5.23：坂入口/坂出口マスでは前・左・右を試すまでUターンを最後の手段にする
//   - 2026.5.23：坂入口/坂出口マスでは全モードで後方選択を禁止し、左→前→右を強制候補にする
//   - 2026.5.23：坂入口/坂出口マスでは、進入時の基準方向で左→前→右→後ろの順に固定し、左2回による実質Uターンを防ぐ
//   - 2026.5.23：坂入口/坂出口マスの既存壁情報は消さず、SL解除とIGNORE整理だけ行う
//   - 2026.5.23：訪問回数3回以上のマスでは、UNKNOWN壁方向をフロンティア未探索ターゲットから除外する
//   - 2026.5.23：M_40_18をベースに、坂/階段入口・出口マスの固定試行順を前→左→右→後ろへ変更する
//   - 2026.5.23：訪問回数3回以上のマスは、UNKNOWN/OPEN未訪問に関係なくフロンティア未探索ターゲットから除外する
//
// ★SD LOAD後ローカライズ強化
//   - 2026.5.17：ローカライズ中だけ後ろToF(S5)の壁あり投票を復活
//   - 2026.5.17：16〜24cm走行中に最大10回、多数決で一時マップへ壁情報を記録
//   - 2026.5.17：LOC OK後も一時マップの壁・カラー・訪問回数は本物マップへ反映しない
//   - 2026.5.17：壁あり観測は保存側unknownでも不一致扱いにし、壁なし観測は保存側unknownなら保留
//   - 2026.5.17：XY_Number/Red_Numberだけのマスをローカライズ候補にしない
//   - 2026.5.17：SD LOAD直後の初期壁確認後にも候補照合を実行
//   - 2026.5.17：通常スタート時も移動前に10回多数決で4方向壁確認し、後ろ壁ありも記録
//   - 2026.5.17：ローカライズ中の16〜24cm壁投票は左右だけ、30cm停止時に前後を10回多数決
//   - 2026.5.17：通常探索中も16〜24cm壁投票は左右だけ、30cm通常停止時は前だけ10回多数決（後ろToFは通常探索では使わない）
//
// ★3フロア座標管理（1st/2nd/3rd）
//   - 2026.5.17：マップを41×41×3へ変更。同じX,Yでもフロア別に壁/色/訪問回数を分離
//   - 2026.5.17：登坂/降坂後、平地復帰時にフロア切替。X,Y,方角はそのまま受け継ぐ
//   - 2026.5.17：高さレベル方式。1stから同方向の坂は同じ2nd、反対方向の坂は3rdへ割当
//   - 2026.5.17：実際に通った坂だけ、同じX,Yのフロアリンクとして記録。XY_Number/Red_Numberはリンク経由で継承
//
// 2026.5.20 (forward terrain pass + 3-floor map / color-stage reset fix)
// 2026.5.31 (multi red entrance info record + Serial visibility / stage 1)
// 2026.5.31 (red normal confirm mode / stage 2A)
// 2026.5.31 (red normal confirm candidate localization + direction/yaw soft fix / stage 2B)
// 2026.5.31 (remove unused shouldSaveCell wrapper warning / M_41_13)
// 2026.5.31 (red tile exit direction by red entrance candidates / stage 2C)
// 2026.5.31 (elapsed minute digit on OLED upper-right / M_41_15)
// 2026.5.31 (red exit dedicated localization like SD LOAD / M_41_17)
// 2026.5.31 (red exit NC score match + OLED lower-right shift / M_41_18)
// 2026.5.31 (red tile temporary wall observation for NC candidate scoring / M_41_19)
// 2026.5.31 (protect redEntrance normalSide from red-zone forward detection / M_41_20)
// 2026.5.31 (red tile wall observation is mismatch-filter only; resolve by next normal tiles / M_41_21)
// 2026.5.31 (red NC keeps all candidates and resolves by total score / M_41_22)
// 2026.5.31 (red NC single-tile scoring: reset score every tile / M_41_23)
// 2026.5.31 (red NC candidates from all redFlag tiles; redEntranceInfo is hint only / M_41_24)
// 2026.5.31 (red recovery search: visit>=4 resets red-zone walls/visits and uses live ToF ExtLH / M_41_25)
// 2026.5.31 (compile fix: redRecovery helpers can see later global state declarations / M_41_26)
// 2026.5.31 (red recovery also starts by elapsed time >=6min in red zone / M_41_27)
// 2026.5.31 (red exit NC matches against first RED-save snapshot, not live map / M_41_28)
// 2026.5.31 (M_42_10: red/color-map mismatch triggers red-exit NC; C,R not snapshot-red => recovery, not-red on snapshot-red => NC)
// 2026.5.31 (inside red zone, unknown-coordinate red tile is handled as recovery red arrival; no ghost redFlag / M_42_9)
// 2026.5.31 (M_42_11: any known red tile reached from red zone is forced to red-exit NC; no visit4 reset after physical exit)

#include <Arduino.h>
#include <Wire.h>
#include <VL53L0X.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <SD.h>

#include "SparkFun_BNO080_Arduino_Library.h"
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// UART
const uint32_t BAUD = 115200;

// ======= Arduino自動プロトタイプ対策（宣言）=======
// 2026.5.23：下の構造体を引数に取る関数の自動プロトタイプ生成対策。
struct CellBackup;
struct PendingFloorCoordRecord;
static inline float normalize180(float deg);
static inline void imuUpdate();
static inline bool tofValid(uint16_t mm);
static inline bool tofFarMeansOpen(uint16_t mm);
static inline void neighborByRel(uint8_t relDir, int cx, int cy, uint8_t curDir, int &nx, int &ny);
static inline void neighborByAbs(uint8_t absDir, int cx, int cy, int &nx, int &ny);
static inline uint8_t oppositeAbsDir(uint8_t absDir);
static inline const char* absDirName(uint8_t absDir);
static inline uint8_t wallStateGet(int x, int y, uint8_t absDir);
static inline void wallSetKnownState(int x, int y, uint8_t absDir, bool isWall);
static inline void wallSetKnownStateBoth(int x, int y, uint8_t absDir, bool isWall);
static inline void wallMarkFrontBlockedCurrentCell();
static inline void wallMarkForwardOpenByTraverse();
static inline void slopeEstimateFloorLinkEntryCell(uint8_t travelAbsDir, int exitX, int exitY, int &entryX, int &entryY);
static inline bool wallIsOpenBetweenVisitedCells(int x, int y, uint8_t absDir);
static inline void wallVoteReset();
static inline void wallVoteTrySample(long avgPulses);
static inline void wallVoteFinalize();
static inline bool cellHasUnknownWall(int x, int y);
static inline bool shouldSpotCheckCurrentCellWalls();
static void classifyCurrentCellWallsAtStop(bool onlyUnknown);
static void warmupAndClassifyStartCellWalls();
static void warmupAndClassifyLocalizationStartCellWalls();
static void classifyFrontBackAtStop(bool isLocalization);
static void classifyLocalizationFrontBackAtStop();
static void drawWallMiniIcon(int x, int y, int size);
static void drawHudScreen();
static inline uint16_t xyNumberGet(int x, int y);
static inline void xyNumberSet(int x, int y, uint16_t v);
static void rebuildXY_NumberAll();
static inline void refreshXY_NumberAfterForwardTraverse();
static inline uint16_t redNumberGet(int x, int y);
static inline void redNumberSet(int x, int y, uint16_t v);
static inline bool hasKnownRedEntrance();
static int redEntranceInfoFind(uint8_t floor, int x, int y);
static uint8_t redFlagCountAllFloors();
static uint8_t redNcSnapshotRedFlagCountAllFloors();
static uint8_t redNcSourceRedFlagCountAllFloors();
static void redNcCaptureSnapshotFromActive(const char* reason);
static inline uint8_t redNcSnapshotWallStateGetFloor(uint8_t floor, int x, int y, uint8_t absDir);
static inline uint8_t redNcSnapshotRedGetFloor(uint8_t floor, int x, int y);
static void redRecoveryStart(const char* reason);
static bool redRecoveryShouldStart();
static bool redRecoveryTimeShouldStart();
static void redRecoveryResetRedZoneMemory();
static inline void redRecoveryVisitReset();
static inline uint16_t redRecoveryVisitGet(int x, int y);
static inline void redRecoveryVisitInc(int x, int y);
static bool redRecoveryReadOpenRelMask(uint8_t &openRelMask);
static int redRecoveryChooseExploreRelDir(bool isOnRedTile);
static bool redRecoveryHandleAtStop();
static void redEntranceInfoPrintAll(const char* reason);
static void redEntranceInfoRecord(uint8_t floor, int redX, int redY, uint8_t normalSideAbsDir, const char* reason);
static inline bool isNormalExplorationComplete();
static inline bool shouldReturnBecauseNormalDoneNoRed();
static inline void enterReturnMode(const char* reason);
static inline bool shouldRedTargetMode();
static void rebuildRed_NumberAll();
static inline bool canRedTargetMoveByRel(uint8_t relDir);
static inline int chooseRedTargetRelDirByRed_Number();
static inline bool shouldStartRedExitMode();
static inline void startRedExitMode(const char* reason);
static inline bool canRedExitToNormalByRel(uint8_t relDir);
static inline int chooseRedExitToNormalRelDir();
static inline uint8_t redExitNearestDirFromYaw();
static inline int chooseRedExitToNormalRelDirByEntranceCandidates();
static void startRedNormalConfirmMode(const char* reason);
static void cancelRedNormalConfirmMode(const char* reason);
static bool redNormalConfirmCurrentCellMatches();
static inline int chooseRedNormalConfirmRelDir();
static inline float redYawTargetForDir(uint8_t absDir);
static inline void redNormalConfirmResetCandidates();
static inline void redNormalConfirmClearCandidateArrayOnly();
static inline void redNormalConfirmResetObservations();
static bool redNormalConfirmStoreCurrentObservation(uint8_t obsKnownRelMask, uint8_t obsWallRelMask);
static bool redNormalConfirmReadRelPatternNoWrite(uint8_t &obsKnownRelMask, uint8_t &obsWallRelMask);
static void redNormalConfirmClearRedTileObservation();
static bool redNormalConfirmCaptureRedTileObservation(const char* reason);
static bool redNormalConfirmScoreRedTileObservation(uint8_t redIndex, uint8_t facingAbsDir, uint8_t &matchCount, uint8_t &mismatchCount, int16_t &score);
static bool redNormalConfirmCandidateScoreAllObservations(uint8_t floor, int startX, int startY, uint8_t startDir, uint8_t &matchCount, uint8_t &mismatchCount, int16_t &score);
static void redNormalConfirmVirtualToAbsPose(uint8_t floor, int startX, int startY, uint8_t startDir, int virtX, int virtY, uint8_t virtDir, uint8_t &outFloor, int &outX, int &outY, uint8_t &outDir);
static void redNormalConfirmBuildCandidates();
static void redNormalConfirmPrintCandidates(const char* reason);
static inline void redNormalConfirmRotateCandidatesRel(uint8_t relDir);
static inline void redNormalConfirmAdvanceCandidatesForward();
static bool redNormalConfirmResolveIfUnique(const char* reason);
static inline int chooseRedNormalConfirmRelDirByCandidates();

static void serviceSubRx();
static void serviceMainTof();
static bool requestColorClassOnce(char &colorCode);
static void showLargeColorStatus(const char* label);
static void showLargeColorStatusForMs(const char* label, uint32_t displayMs);
static void processBlueConfirmedCurrentTile();
static void processRedConfirmedCurrentTile();
static void redRecoveryEnterUnknownRedTileNoWrite(const char* reason);
static bool redNcHandleArrivalColorMapMismatch(char observedColor, bool observedOk, const char* reason);
static bool initSdSave();
static void clearSdSaveFile();
static void showSdStatusForMs(const char* label, uint32_t displayMs);
static void showSdStartupStatus();
static bool readSdLine(File &f, char* line, size_t lineLen);
static void resetMapForSdLoad();
static bool loadMazeCheckpointFromSd();
static void prepareLocalizationFromSdLoad();
static void decideNextMoveAtStop_Localize();
static void serviceLocalizationMode();
static bool tryResolveLocalization(bool &isResolved, int &resolvedOriginX, int &resolvedOriginY, uint16_t &candidateCount);
static void showLocalizationCandidateStatus(uint16_t candidateCount);
static void finishLocalizationOk(int originX, int originY);
static void finishLocalizationErr();
static bool saveMazeCheckpoint(const char* reason, bool lockAfterSave);
static void markForwardTileAsBlackBlocked();
static void markForwardTileAsRedEntrance();
static inline uint8_t zoneGet(int x, int y);
static inline void zoneSet(int x, int y, uint8_t v);
static inline void markCurrentCellZone();
static inline bool isFrontierCellForZone(int x, int y, uint8_t zone);
static bool hasFrontierInZone(uint8_t zone);
static bool hasFrontierInNormalZone();
static bool hasFrontierInRedZone();
static inline uint16_t frontierNumberGet(int x, int y);
static inline void frontierNumberSet(int x, int y, uint16_t v);
static inline bool isCellUsableForFrontierBfs(int x, int y, uint8_t zone);
static void rebuildFrontier_NumberAll(uint8_t zone);
static inline bool canFrontierTargetMoveByRel(uint8_t relDir, uint8_t zone);
static inline int chooseFrontierTargetRelDirByFrontier_Number(uint8_t zone);
static inline bool isExploreCandidateAllowedForZone(uint8_t absDir, uint8_t zone);
static inline bool canChooseOpenUnvisitedFrontierRel(uint8_t relDir, uint8_t zone);
static inline bool canChooseUnknownAbsDir(uint8_t absDir, uint8_t zone);
static inline bool canChooseUnknownFrontierRel(uint8_t relDir, uint8_t zone);
static inline void unknownSweepReset();
static inline int chooseUnknownSweepRelDir(uint8_t zone);
static inline int choosePriorityFrontierRelDir(uint8_t zone);
static inline bool shouldUseFrontierTargetMode(uint8_t zone);
static void drawFrontierStatusOnHud();
static inline bool isRedEntryAllowedNow();
static void serviceOledHud();
static void slopeDetectResetForStraight();
static void slopeDetectServiceDuringStraight(long avgPulses, bool coordAlreadyUpdated);
static void drawSlopeStatusOnHud();
static void slopeSetStatus(const char* label, uint32_t holdMs);
static inline bool terrainPassActive();
static inline bool terrainPassMotionLocked();
static inline bool terrainPassShouldSuppressColorVictim();
static void terrainPassBegin(uint8_t slopeDir);
static void terrainPassFinish(uint8_t slopeDir);
static bool terrainPassApplyPendingFloorSwitch(const char* reason);
static void terrainPassCancelPendingFloorSwitch(const char* reason);
static void terrainClassOnCoordinateStepCompleted();
static inline void tickall();
static inline void stopMotors();
static inline bool floorIndexInRange(uint8_t floor);
static inline void floorLinkSetBoth(uint8_t floorA, uint8_t floorB, int x, int y);
static inline void floorLinkSetBothWithDir(uint8_t floorA, uint8_t floorB, int x, int y, uint8_t absDirAToB);
static inline void floorLinkSetBothWithDirBetween(uint8_t floorA, int xA, int yA, uint8_t floorB, int xB, int yB, uint8_t absDirAToB);
static bool floorSwitchAfterSlope(uint8_t slopeDir);
static void showFloorFullWarning();
static inline const char* floorName(uint8_t floor);

static inline bool victimStopActive();
static inline bool t180ActionActive();
static inline bool holdActive();
static inline uint32_t holdBlock();
static inline void waitMs(uint32_t ms);

static void runRawDistance(bool forward, int pwmL, int pwmR, long targetPulses, uint32_t timeoutMs);
static void runRawDistanceForce(bool forward, int pwmL, int pwmR, long targetPulses, uint32_t timeoutMs);
static uint8_t runStraightDistance(int basePwm, long targetPulses, uint32_t timeoutMs, bool allowAbort);

static inline bool needTurnDebounced();

static void turnLeft90Yaw(int basePwm);
static void turnRight90Yaw(int basePwm);
static void turnBack180Yaw2x90();
static void turn180YawOneShot(int basePwm, bool isBackTurn); // 被災者投下用：T180=右200°, T180BK=左200°

static void sidestepAwayFromLeftObstacle();
static void sidestepAwayFromRightObstacle();
static void doHomeSignalAndStop();
static inline void handleHomeSignalIfNeeded();
static void decideNextMoveAtStop_ExtLH();

static void doT180ActionOnce();

// ★ジャイロ補正
static void performGyroReset();

// ★両タッチラッチ
static inline float chooseNearestCardinalYaw(float y);
static inline void triggerBothTouchEvent();
static inline void serviceTouchLatch();

// ★前壁イベント
static inline bool frontIsWallNow();
static inline void updateFrontWallApproachEvent();

// ★定期壁当て
static void serviceProactiveWallHitAtStop();

// =====================
// ===== 調整用（必須）=====
// =====================
int TRIM_R_FWD = +4;
int TRIM_R_REV = -5;

// =====================
// ===== 直進補正周期 =====
// =====================
const uint32_t STRAIGHT_CTRL_MS = 20;

// =====================
// ===== 壁無し時Yaw補正（直進）=====
// =====================
const int   NO_WALL_YAW_CORR_SIGN    = -1;
const float NO_WALL_YAW_KP           = 5.0f;
const float NO_WALL_YAW_DEADBAND_DEG = 1.0f;
const int   NO_WALL_YAW_MAX_CORR_PWM = 25;

// =====================
// ===== 片タッチ救済（S2近接＋片タッチ2秒 → ターン）=====
// =====================
const uint16_t S2_TURN_MM = 60;
const uint32_t ONE_TOUCH_HOLD_MS = 1000;

// =====================
// ===== 横ズレ回避（前が空いてる & 片タッチ）=====
// =====================
const uint16_t S2_OPEN_MM = 70;
const int SIDESTEP_DELTA_PWM = 20;
const uint32_t SIDESTEP_TIMEOUT_MS = 8000;

// =====================
// ===== 壁補正（直進時のみ）=====
// =====================
const uint16_t EARLY_WALL_L_MM = 190;
const uint16_t EARLY_WALL_R_MM = 170;

const uint16_t WALL_L_DETECT_MM  = 220;
const uint16_t WALL_R_DETECT_MM  = 200;

const int16_t  WALL_TRIM_S1_MM   = 20;
const float    WALL_KP           = 1.0f;
const int      WALL_MAX_CORR_PWM = 20;
const uint16_t WALL_DEADBAND_MM  = 5;

const uint16_t TARGET_S0_ONE_MM = 133;
const uint16_t TARGET_S1_ONE_MM = 133;
const float    WALL_ONE_KP      = 1.0f;

// =====================
// ===== 旋回（Yawで止める）=====
// =====================
const float TURN_TOL_DEG     = 2.5f;
const float TURN_KP_PWM      = 2.6f;
const int   TURN_PWM_MIN     = 52;
const int   TURN_PWM_MAX     = 135;
const uint32_t TURN_CTRL_MS  = 20;
const uint32_t TURN_TIMEOUT_MS = 15000;
const float VICTIM_T180_SWEEP_DEG = 200.0f; // 被災者投下用：反対側キット使用時の旋回角

// ★回転スタック救済（純変化量）
// 2026.4.26：完全OFF。ただしコードは残して、必要になったら true に戻せるようにする。
const bool     ENABLE_TURN_STALL_RESCUE = false;
const uint32_t TURN_STALL_WINDOW_MS     = 1000;
const float    TURN_STALL_DEG           = 10.0f;
const int      TURN_STALL_MAX_TRIES     = 3;

// =====================
// ===== AbortReason =====
// =====================
const uint8_t AR_NONE = 0;
const uint8_t AR_TURN = 1;
const uint8_t AR_SIDESTEP_LEFT_TOUCH  = 2;
const uint8_t AR_SIDESTEP_RIGHT_TOUCH = 3;
const uint8_t AR_ABORT = 4;
const uint8_t AR_BOTH_TOUCH = 6;
const uint8_t AR_BLACK_TILE = 7;
const uint8_t AR_RED_BLOCKED = 8;

// =====================
// ===== 座標＆向き =====
// =====================
int posX = 0;
int posY = 0;
uint8_t direction = 0; // 0:N,1:E,2:S,3:W

// ===== 3フロア座標管理 =====
// 1st=0 / 2nd=1 / 3rd=2。3rdは必ず上階とは限らず、「3つ目に使う別フロアID」。
const uint8_t FLOOR_COUNT = 3;
const uint8_t FLOOR_1ST = 0;
const uint8_t FLOOR_2ND = 1;
const uint8_t FLOOR_3RD = 2;
const int8_t FLOOR_HEIGHT_UNKNOWN = 127;

uint8_t currentFloor = FLOOR_1ST;
int8_t floorHeight[FLOOR_COUNT] = {0, FLOOR_HEIGHT_UNKNOWN, FLOOR_HEIGHT_UNKNOWN}; // 1stを高さ0にする
bool floorAssigned[FLOOR_COUNT] = {true, false, false};

// ===== マップ関連 =====
const int VIS_W = 41;
const int VIS_H = 41;
const int VIS_OX = VIS_W / 2;
const int VIS_OY = VIS_H / 2;
const int VIS_CELL_COUNT = VIS_W * VIS_H;
const int VIS_QUEUE_COUNT = VIS_CELL_COUNT * FLOOR_COUNT;

uint16_t visitCnt[FLOOR_COUNT][VIS_H][VIS_W];
uint8_t victimFlag[FLOOR_COUNT][VIS_H][VIS_W];
uint8_t blueFlag[FLOOR_COUNT][VIS_H][VIS_W]; // 1=青タイル記録済み
uint8_t redFlag[FLOOR_COUNT][VIS_H][VIS_W];  // 1=赤タイル入口記録済み
uint8_t bumpFlag[FLOOR_COUNT][VIS_H][VIS_W]; // 1=バンプ(BP)通過マス記録済み

// ===== 複数赤入口情報（2026.5.31 第1段階：保存＋Serial見える化）=====
// normalSideAbsDir は「赤タイルからノーマル側へ出る絶対方向」。
// 例：ノーマルから東へ進んで赤を発見した場合、赤から見たノーマル側は西(W)。
const uint8_t RED_ENTRANCE_INFO_MAX = 16;
const uint8_t RED_ENTRANCE_DIR_UNKNOWN = 4;

struct RedEntranceInfo {
  bool used;
  uint8_t floor;
  int16_t x;
  int16_t y;
  uint8_t normalSideAbsDir;
  int16_t normalX;
  int16_t normalY;
  uint8_t enterFromNormalAbsDir;
  uint32_t discoveredMs;
};

RedEntranceInfo redEntranceInfo[RED_ENTRANCE_INFO_MAX];
uint8_t redEntranceInfoCount = 0;

// ===== 赤脱出ノーマル確認候補（2026.5.31 M_41_17：赤脱出専用ローカライズ）=====
// SD LOAD後ローカライズと同じ考え方で、NC中の観測は一時観測として保持し、
// 保存済みノーマルマップへ重ね合わせて候補を絞る。本物マップへは書き込まない。
const uint8_t RED_NC_CANDIDATE_MAX = (uint8_t)(RED_ENTRANCE_INFO_MAX * 4);
const uint8_t RED_NC_MIN_MATCH_TO_RESOLVE = 1;
const uint8_t RED_NC_MIN_WALL_MATCH_TO_RESOLVE = 1;
const int16_t RED_NC_MIN_SCORE_GAP_TO_RESOLVE = 3;
const uint8_t RED_NC_OBS_MAX = 4;

struct RedNormalConfirmCandidate {
  bool used;
  uint8_t floor;
  int16_t x;
  int16_t y;
  uint8_t dir;
  uint8_t redIndex;
  uint8_t exitAbsDir;
  uint8_t matchCount;
  uint8_t mismatchCount;
  uint8_t redMatchCount;
  uint8_t redMismatchCount;
  int16_t score;
};

struct RedNormalConfirmObservation {
  bool used;
  int16_t virtX;
  int16_t virtY;
  uint8_t virtDir;
  uint8_t knownRelMask;
  uint8_t wallRelMask;
};

RedNormalConfirmCandidate redNcCandidates[RED_NC_CANDIDATE_MAX];
uint8_t redNormalConfirmCandidateCount = 0;
int16_t redNormalConfirmLastBestMatch = -32768;
int16_t redNormalConfirmSecondBestMatch = -32768;
RedNormalConfirmObservation redNcObservations[RED_NC_OBS_MAX];
uint8_t redNormalConfirmObservationCount = 0;
int16_t redNormalConfirmVirtX = 0;
int16_t redNormalConfirmVirtY = 0;
uint8_t redNormalConfirmVirtDir = 0;

// 赤タイル上の壁配置は、座標未確定中に使う一時観測。
// 本物マップへは書かず、NC候補のスコア判定だけに使う。
bool redNormalConfirmHasRedTileObservation = false;
uint8_t redNormalConfirmRedKnownRelMask = 0;
uint8_t redNormalConfirmRedWallRelMask = 0;
uint8_t redNormalConfirmRedFacingAbsDir = 0;

// ===== M_41_25：レッドゾーン迷走時リカバリー =====
const uint16_t RED_RECOVERY_VISIT_LIMIT = 4;
const uint32_t RED_RECOVERY_TIME_MS = 360000UL; // 試合開始から6分で赤リカバリー開始（4分にするなら240000UL）
bool redRecoverySearchMode = false;       // visit>=4後、古い赤ゾーン壁を信用せずセンサー主体で赤タイル探索
bool redRecoveryOnRedTile = false;        // リカバリー中に赤タイルへ到達済み
bool redRecoveryNcActive = false;         // リカバリーから赤脱出NCへ入ったか
uint16_t redRecoveryVisitCnt[VIS_H][VIS_W];

// ===== 探索ゾーン記録 =====
// 0=未分類 / 1=ノーマルゾーン / 2=レッドゾーン
const uint8_t ZONE_UNKNOWN = 0;
const uint8_t ZONE_NORMAL  = 1;
const uint8_t ZONE_RED     = 2;
uint8_t zoneFlag[FLOOR_COUNT][VIS_H][VIS_W];

// ===== 帰還用番号マップ =====
// スタート(1st,0,0)からの最短距離番号。フロアリンクは同じX,Yで0コスト継承。
uint16_t XY_Number[FLOOR_COUNT][VIS_H][VIS_W];
const uint16_t XY_NUMBER_INF = 65535;
static int16_t xyQueueX[VIS_QUEUE_COUNT];
static int16_t xyQueueY[VIS_QUEUE_COUNT];
static uint8_t xyQueueF[VIS_QUEUE_COUNT];

// ===== 赤入口ターゲット用番号マップ =====
// 赤入口を0として、現在地から赤入口へ向かうためのBFS番号
uint16_t Red_Number[FLOOR_COUNT][VIS_H][VIS_W];
const uint16_t RED_NUMBER_INF = 65535;

// ===== フロンティアターゲット用番号マップ =====
// 最寄りのフロンティアセルを0として、そこへ向かうためのBFS番号
uint16_t Frontier_Number[FLOOR_COUNT][VIS_H][VIS_W];
const uint16_t FRONTIER_NUMBER_INF = 65535;

// ===== 壁マップ（北東南西）=====
// knownビット: その方向の壁情報を観測済み
// existビット: knownのとき、1=壁あり / 0=壁なし
uint8_t wallKnownMap[FLOOR_COUNT][VIS_H][VIS_W];
uint8_t wallExistMap[FLOOR_COUNT][VIS_H][VIS_W];

// ===== フロア間リンク =====
// 2026.5.17：坂入口セルと坂出口セルを接続する。bit0=1st, bit1=2nd, bit2=3rd。
// 例：F1 X2,Y3 ⇔ F2 X5,Y3 のように、異なるX,Y同士をつなげる。
uint8_t floorLinkMap[FLOOR_COUNT][VIS_H][VIS_W];
// source floor/cell -> target floor/cell へ入るための絶対方角。0=N,1=E,2=S,3=W,4=未設定。
const uint8_t FLOOR_LINK_DIR_NONE = 4;
uint8_t floorLinkDirMap[FLOOR_COUNT][VIS_H][VIS_W][FLOOR_COUNT];
// target座標。int8_tで -20〜+20 を保存する。旧SD等で未設定の場合は同じX,Y扱いへ補正する。
int8_t floorLinkTargetXMap[FLOOR_COUNT][VIS_H][VIS_W][FLOOR_COUNT];
int8_t floorLinkTargetYMap[FLOOR_COUNT][VIS_H][VIS_W][FLOOR_COUNT];

// ===== フロア切替時の旧フロア側・接続専用セル =====
// 例：F1で坂を進み、平地復帰後にF2へ切り替わった場合、
// F1側の到達点は実在探索セルではなくフロアリンク用の接続点として扱う。
// 1=RETURNを止める未探索フロンティア判定から除外する。
uint8_t floorConnectorOnlyMap[FLOOR_COUNT][VIS_H][VIS_W];

// ===== 坂直後セルの未探索除外マスク =====
// 坂を抜けた直後の平地マスは、マス中央からズレている可能性が高い。
// そこで進行方向基準の「左・右・後ろ」のUNKNOWNは、RETURNを止める未探索扱いにしない。
// bit0=N, bit1=E, bit2=S, bit3=W。壁情報自体はUNKNOWNのまま残す。
uint8_t slopeExitIgnoreUnknownMap[FLOOR_COUNT][VIS_H][VIS_W];

// ===== 坂セルの未探索除外 =====
// 坂そのもののセルは、坂途中でToFが不安定になりやすい。
// 壁情報がUNKNOWNのままでもRETURNを止める未探索フロンティアにはしない。
uint8_t slopeTransitCellMap[FLOOR_COUNT][VIS_H][VIS_W];

// ===== 下り坂直後セルの左右ToF壁判定禁止マスク =====
// 下り坂を抜けた直後の平地マスは、車体姿勢/位置ズレで左右ToFが近距離誤値を返しやすい。
// 既存の壁情報は残し、新しい左右壁投票だけを行わない。bit0=N, bit1=E, bit2=S, bit3=W。
uint8_t slopeDownExitNoSideReadMap[FLOOR_COUNT][VIS_H][VIS_W];

const uint8_t WALL_STATE_UNKNOWN = 0;
const uint8_t WALL_STATE_OPEN    = 1;
const uint8_t WALL_STATE_BLOCKED = 2;

// ===== 不明壁の再確認ルール =====
// 2026.5.17：探索中はUNKNOWN(・)をOPEN相当の候補として扱う。
// ただし、その場ToF再確認は2回目訪問から行う。
const uint8_t  UNKNOWN_WALL_FRONTIER_VISIT_LIMIT = 2;
const uint8_t  FRONTIER_IGNORE_VISIT_COUNT = 3; // 3回以上訪問済みのマスはフロンティア未探索ターゲットにしない
const uint16_t SPOT_WALL_THRESHOLD_MM       = 200; // 後ろ用/汎用
const uint16_t SPOT_SIDE_WALL_THRESHOLD_MM = 170; // 左右ToF用：坂直後の横壁誤判定を減らす
const uint16_t SPOT_FRONT_WALL_THRESHOLD_MM = 130; // 前ToF S2用

static inline uint16_t spotWallThresholdForRel(uint8_t rel) {
  if (rel == 0) return SPOT_FRONT_WALL_THRESHOLD_MM;       // 前
  if (rel == 1 || rel == 3) return SPOT_SIDE_WALL_THRESHOLD_MM; // 右/左
  return SPOT_WALL_THRESHOLD_MM;                           // 後ろ
}

// ===== UNKNOWN確認モード =====
// 2026.5.17：そのマスに入った時の向きを基準に、UNKNOWN(・)を 左→前→右→後ろ の順で潰す。
// 両タッチ後にロボットの向きが変わっても、基準方向は変えない。
bool gUnknownSweepActive = false;
uint8_t gUnknownSweepFloor = FLOOR_1ST;
int gUnknownSweepX = 0;
int gUnknownSweepY = 0;
uint8_t gUnknownSweepBaseDir = 0;

// 2026.5.23：坂入口/坂出口マス専用。
// そのマスへ入った時点の向きを基準に、前→左→右→後ろの順を固定して試す。
bool gSlopeEndpointSweepActive = false;
uint8_t gSlopeEndpointSweepFloor = FLOOR_1ST;
int gSlopeEndpointSweepX = 0;
int gSlopeEndpointSweepY = 0;
uint8_t gSlopeEndpointSweepBaseDir = 0;
uint8_t gSlopeEndpointSweepTriedMask = 0; // bit0=左, bit1=前, bit2=右, bit3=後ろ

// 2026.5.17：坂の左右壁自動確定は、平地復帰時の現在地ではなく「坂タイル」だけに入れる。
// 坂検知時点で、実際に入っている/入ろうとしている坂タイル座標を保存する。
static bool gSlopeMapCellValid = false;
static int gSlopeMapX = 0;
static int gSlopeMapY = 0;
static uint8_t gSlopeMapTravelAbsDir = 0;
// 2026.5.17：坂左右壁は、UP/DOWN確定時ではなく候補開始時の坂タイルへ入れる。
// DOWNは確定が遅れると下り直後の平地タイルを誤って坂扱いするため。
static bool gSlopeCandidateMapCellValid = false;
static int gSlopeCandidateMapX = 0;
static int gSlopeCandidateMapY = 0;
static uint8_t gSlopeCandidateMapTravelAbsDir = 0;

// 2026.5.17：坂が複数マス続く場合に備えて、坂中に通過したタイルを複数記録する。
// 左右壁の自動BLOCKEDは、このリストに入った坂セルだけへ入れる。
const uint8_t SLOPE_SIDE_WALL_CELL_MAX = 12;
static uint8_t gSlopeCellCount = 0;
static int gSlopeCellX[SLOPE_SIDE_WALL_CELL_MAX];
static int gSlopeCellY[SLOPE_SIDE_WALL_CELL_MAX];
static uint8_t gSlopeCellTravelAbsDir[SLOPE_SIDE_WALL_CELL_MAX];

// RETURNに入れない理由をOLED/Serialへ詳しく出すための一時デバッグ表示
static uint32_t gReturnBlockDebugUntilMs = 0;
static uint8_t gReturnBlockFloor = 255;
static int gReturnBlockX = 0;
static int gReturnBlockY = 0;
static uint8_t gReturnBlockDir = 255;

// 2026.5.17：RETURN中にSL(坂)セルへ入ったら、坂を抜けるまで進行方向を固定する。
// 坂途中でXY_Number再判定により180°Uターン/左右旋回する事故を防ぐ。
static bool gReturnSlopePassActive = false;
static uint8_t gReturnSlopePassFloor = FLOOR_1ST;
static int gReturnSlopePassX = 0;
static int gReturnSlopePassY = 0;
static uint8_t gReturnSlopePassDir = 0;

// 2026.5.20：前進地形通過モード。
// UP/DOWN確定後、坂・階段を抜けるまでは探索判断や旋回を禁止して前進を優先する。
// エンコーダ本体の定義は後段のピン定義ブロックにあるため、ここで先行宣言しておく。
extern volatile long encFL;
extern volatile long encFR;
extern volatile long encBL;
extern volatile long encBR;
static bool gTerrainPassActive = false;
static uint8_t gTerrainPassDir = 0; // 1=UP / 2=DOWN
static uint8_t gTerrainPassStartFloor = FLOOR_1ST;
static int gTerrainPassStartX = 0;
static int gTerrainPassStartY = 0;
static uint8_t gTerrainPassTravelAbsDir = 0;
static long gTerrainPassStartFL = 0;
static long gTerrainPassStartFR = 0;
static long gTerrainPassStartBL = 0;
static long gTerrainPassStartBR = 0;
// 2026.5.20：登り切り判定後、今の直進目標を「あと10cm」に切り替えるためのロック。
static bool gTerrainPassClearanceActive = false;
static long gTerrainPassClearanceTargetAvgPulses = 0;

// 2026.5.23：TR分類が確定するまでフロア切替を保留する。
// STAIR/UNKなら切替なし、RAMP確定時だけ後からfloorSwitchAfterSlope()を実行する。
static bool gTerrainPassFloorSwitchPending = false;
static uint8_t gTerrainPassPendingSlopeDir = 0;
static uint8_t gTerrainPassPendingTravelAbsDir = 0;
static uint8_t gTerrainPassPendingFromFloor = FLOOR_1ST;
static int gTerrainPassPendingExitX = 0;
static int gTerrainPassPendingExitY = 0;

// 遅延フロア切替時は、現在の向きではなく坂を通過した向き・出口座標を使う。
static bool gFloorSwitchOverrideActive = false;
static uint8_t gFloorSwitchOverrideTravelAbsDir = 0;
static int gFloorSwitchOverrideExitX = 0;
static int gFloorSwitchOverrideExitY = 0;
static bool gFloorSwitchRestoreCurrentOldCell = false;

static uint32_t gConnectorIgnoreDebugUntilMs = 0;
static uint8_t gConnectorIgnoreFloor = 255;
static int gConnectorIgnoreX = 0;
static int gConnectorIgnoreY = 0;


// =====================
// ===== SDカード保存（第1段階：保存のみ）=====
// =====================
const char* SD_SAVE_FILE = "/susano_save.txt";
const uint32_t SD_STATUS_DISPLAY_MS = 500;

static bool gSdReady = false;
static bool gSdSaveLocked = false;        // 赤タイル保存後は、青でも赤でも保存しない
static bool gSdClearHandledThisBoot = false;
static bool gSdLoadSucceededThisBoot = false;
static uint32_t gSdLoadedElapsedMs = 0;
static bool gOledReady = false;

// ===== SD LOAD後の座標不明ローカライズ =====
// SDから読み込んだ保存マップを退避し、通常のマップ配列を一時マップとして使う。
// LOC OK後も一時マップの壁・カラー・訪問回数は本物マップへ反映しない。
const uint8_t LOCALIZE_MIN_MOVES = 1;  // 2026.5.17：初期壁確認後も照合するため、1マス走行後から再照合
const uint8_t LOCALIZE_MAX_MOVES = 10;
static bool gLocalizationActive = false;
static uint8_t gLocalizationMoveCount = 0;
static bool gLocalizationCandidateResolved = false;
static uint16_t gLocalizationLastCandidateCount = 0;
static bool gLocalizationHasCandidateCount = false;
static const bool ENABLE_LOC_DEBUG_PRINT = true; // 2026.5.17：原因確認用。一時的なSerialデバッグ

// 2026.5.17：ローカライズ退避マップは大きいためRAM2(DMAMEM)へ配置し、RAM1不足を防ぐ。
DMAMEM uint16_t savedVisitCnt[FLOOR_COUNT][VIS_H][VIS_W];
DMAMEM uint8_t  savedVictimFlag[FLOOR_COUNT][VIS_H][VIS_W];
DMAMEM uint8_t  savedBlueFlag[FLOOR_COUNT][VIS_H][VIS_W];
DMAMEM uint8_t  savedRedFlag[FLOOR_COUNT][VIS_H][VIS_W];
DMAMEM uint8_t  savedBumpFlag[FLOOR_COUNT][VIS_H][VIS_W];
DMAMEM uint8_t  savedZoneFlag[FLOOR_COUNT][VIS_H][VIS_W];
DMAMEM uint16_t savedXY_Number[FLOOR_COUNT][VIS_H][VIS_W];
DMAMEM uint16_t savedRed_Number[FLOOR_COUNT][VIS_H][VIS_W];
DMAMEM uint8_t  savedWallKnownMap[FLOOR_COUNT][VIS_H][VIS_W];
DMAMEM uint8_t  savedWallExistMap[FLOOR_COUNT][VIS_H][VIS_W];
DMAMEM uint8_t  savedFloorLinkMap[FLOOR_COUNT][VIS_H][VIS_W];
DMAMEM uint8_t  savedFloorLinkDirMap[FLOOR_COUNT][VIS_H][VIS_W][FLOOR_COUNT];
DMAMEM int8_t   savedFloorLinkTargetXMap[FLOOR_COUNT][VIS_H][VIS_W][FLOOR_COUNT];
DMAMEM int8_t   savedFloorLinkTargetYMap[FLOOR_COUNT][VIS_H][VIS_W][FLOOR_COUNT];
DMAMEM uint8_t  savedFloorConnectorOnlyMap[FLOOR_COUNT][VIS_H][VIS_W];
DMAMEM uint8_t  savedSlopeExitIgnoreUnknownMap[FLOOR_COUNT][VIS_H][VIS_W];
DMAMEM uint8_t  savedSlopeTransitCellMap[FLOOR_COUNT][VIS_H][VIS_W];
DMAMEM uint8_t  savedSlopeDownExitNoSideReadMap[FLOOR_COUNT][VIS_H][VIS_W];
static uint8_t  savedCurrentFloorForLoc = FLOOR_1ST;
static int8_t   savedFloorHeightForLoc[FLOOR_COUNT];
static bool     savedFloorAssignedForLoc[FLOOR_COUNT];

// M_41_28：赤脱出NC照合用スナップショット。
// 初回RED保存時、またはSD LOADで赤情報を含む保存データを読み込んだ時点の安全な地図を、saved*配列へ保持する。
static bool gRedNcSnapshotValid = false;


static inline bool floorIndexInRange(uint8_t floor) {
  return (floor < FLOOR_COUNT);
}

static inline const char* floorName(uint8_t floor) {
  switch (floor) {
    case FLOOR_1ST: return "1st";
    case FLOOR_2ND: return "2nd";
    case FLOOR_3RD: return "3rd";
    default: return "F?";
  }
}

static inline bool visInRange(int x, int y) {
  int mx = x + VIS_OX;
  int my = y + VIS_OY;
  return (mx >= 0 && mx < VIS_W && my >= 0 && my < VIS_H);
}

static inline uint16_t visGetFloor(uint8_t floor, int x, int y) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return 0;
  return visitCnt[floor][y + VIS_OY][x + VIS_OX];
}
static inline uint16_t visGet(int x, int y) {
  return visGetFloor(currentFloor, x, y);
}
static inline uint16_t visIncFloor(uint8_t floor, int x, int y) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return 0;
  uint16_t &v = visitCnt[floor][y + VIS_OY][x + VIS_OX];
  if (v < 65535) v++;
  // 実際にそのフロアのセルとして訪問した場合は、接続専用扱いを解除する。
  floorConnectorOnlyMap[floor][y + VIS_OY][x + VIS_OX] = 0;
  return v;
}
static inline uint16_t visInc(int x, int y) {
  return visIncFloor(currentFloor, x, y);
}
static inline void visAdd(int x, int y, uint16_t val) {
  if (!visInRange(x, y)) return;
  uint32_t v = (uint32_t)visitCnt[currentFloor][y + VIS_OY][x + VIS_OX] + val;
  if (v > 65535) v = 65535;
  visitCnt[currentFloor][y + VIS_OY][x + VIS_OX] = (uint16_t)v;
}

// 2026.5.17：坂処理の途中で旧フロア側へ一時的に作られる訪問記録を、
// 「1減らす」ではなく、座標更新前のセル状態へ復元するためのバックアップ。
struct CellBackup {
  bool valid;
  uint8_t floor;
  int x;
  int y;
  uint16_t visit;
  uint8_t zone;
  uint8_t victim;
  uint8_t blue;
  uint8_t red;
  uint8_t bump;
  uint8_t connectorOnly;
  uint8_t slopeExitIgnore;
  uint8_t slopeTransit;
  uint8_t slopeDownNoSide;
  uint8_t wallKnownBits;
  uint8_t wallExistBits;
};

static CellBackup gLastCoordStepBackup = {};

// 2026.5.23：TR:RAMP確定待ち(PENDING)中に旧フロアへ仮記録された座標を覚える。
// RAMP確定時は新フロア側へ訪問記録を移し、旧フロア側は座標更新前へ復元する。
const uint8_t PENDING_FLOOR_COORD_MAX = 8;
struct PendingFloorCoordRecord {
  bool valid;
  uint8_t floor;
  int x;
  int y;
  CellBackup backup;
};
static PendingFloorCoordRecord gPendingFloorCoord[PENDING_FLOOR_COORD_MAX];
static uint8_t gPendingFloorCoordCount = 0;

// 2026.5.23：Arduino IDEの自動プロトタイプ生成対策。
// CellBackup / PendingFloorCoordRecord を引数に取る関数は、型定義後に明示プロトタイプを置く。
static inline bool terrainPendingCoordRestoreBackup(const CellBackup &backup, const char* reason);
static void terrainPendingCoordMigrateOneToFloor(const PendingFloorCoordRecord &r, uint8_t toFloor);

static inline void lastCoordStepBackupSave(uint8_t floor, int x, int y) {
  CellBackup &b = gLastCoordStepBackup;
  b.valid = false;
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return;

  int mx = x + VIS_OX;
  int my = y + VIS_OY;

  b.valid = true;
  b.floor = floor;
  b.x = x;
  b.y = y;
  b.visit = visitCnt[floor][my][mx];
  b.zone = zoneFlag[floor][my][mx];
  b.victim = victimFlag[floor][my][mx];
  b.blue = blueFlag[floor][my][mx];
  b.red = redFlag[floor][my][mx];
  b.bump = bumpFlag[floor][my][mx];
  b.connectorOnly = floorConnectorOnlyMap[floor][my][mx];
  b.slopeExitIgnore = slopeExitIgnoreUnknownMap[floor][my][mx];
  b.slopeTransit = slopeTransitCellMap[floor][my][mx];
  b.slopeDownNoSide = slopeDownExitNoSideReadMap[floor][my][mx];
  b.wallKnownBits = wallKnownMap[floor][my][mx] & 0x0F;
  b.wallExistBits = wallExistMap[floor][my][mx] & 0x0F;
}

static inline bool lastCoordStepBackupMatches(uint8_t floor, int x, int y) {
  const CellBackup &b = gLastCoordStepBackup;
  return (b.valid && b.floor == floor && b.x == x && b.y == y && floorIndexInRange(floor) && visInRange(x, y));
}

static inline bool lastCoordStepBackupRestoreIfMatches(uint8_t floor, int x, int y, const char* reason) {
  const CellBackup &b = gLastCoordStepBackup;
  if (!lastCoordStepBackupMatches(floor, x, y)) return false;

  int mx = x + VIS_OX;
  int my = y + VIS_OY;

  visitCnt[floor][my][mx] = b.visit;
  zoneFlag[floor][my][mx] = b.zone;
  victimFlag[floor][my][mx] = b.victim;
  blueFlag[floor][my][mx] = b.blue;
  redFlag[floor][my][mx] = b.red;
  bumpFlag[floor][my][mx] = b.bump;
  floorConnectorOnlyMap[floor][my][mx] = b.connectorOnly;
  slopeExitIgnoreUnknownMap[floor][my][mx] = b.slopeExitIgnore;
  slopeTransitCellMap[floor][my][mx] = b.slopeTransit;
  slopeDownExitNoSideReadMap[floor][my][mx] = b.slopeDownNoSide;
  wallKnownMap[floor][my][mx] = b.wallKnownBits & 0x0F;
  wallExistMap[floor][my][mx] = b.wallExistBits & 0x0F;

  // targetセル側の壁状態を復元したので、隣接セルの反対側も一致させる。
  // これで、坂出口の旧フロア側に一時的に作られたOPEN辺も残りにくくなる。
  for (uint8_t absDir = 0; absDir < 4; absDir++) {
    int nx, ny;
    neighborByAbs(absDir, x, y, nx, ny);
    if (!visInRange(nx, ny)) continue;

    int nmx = nx + VIS_OX;
    int nmy = ny + VIS_OY;
    uint8_t od = oppositeAbsDir(absDir);

    if ((b.wallKnownBits & (uint8_t)(1u << absDir)) != 0) {
      wallKnownMap[floor][nmy][nmx] |= (uint8_t)(1u << od);
      if ((b.wallExistBits & (uint8_t)(1u << absDir)) != 0) wallExistMap[floor][nmy][nmx] |= (uint8_t)(1u << od);
      else                                                   wallExistMap[floor][nmy][nmx] &= (uint8_t)~(1u << od);
    } else {
      wallKnownMap[floor][nmy][nmx] &= (uint8_t)~(1u << od);
      wallExistMap[floor][nmy][nmx] &= (uint8_t)~(1u << od);
    }
  }

  Serial.print("CELL RESTORE ");
  Serial.print(reason ? reason : "");
  Serial.print(" F");
  Serial.print((unsigned)(floor + 1));
  Serial.print(" X:");
  Serial.print(x);
  Serial.print(" Y:");
  Serial.print(y);
  Serial.print(" VIS:");
  Serial.println((unsigned)b.visit);

  return true;
}

static inline uint8_t vicGetFloor(uint8_t floor, int x, int y) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return 0;
  return victimFlag[floor][y + VIS_OY][x + VIS_OX];
}
static inline uint8_t vicGet(int x, int y) {
  return vicGetFloor(currentFloor, x, y);
}
static inline void vicSet(int x, int y, uint8_t v) {
  if (!visInRange(x, y)) return;
  victimFlag[currentFloor][y + VIS_OY][x + VIS_OX] = (v ? 1 : 0);
}

static inline uint8_t blueGetFloor(uint8_t floor, int x, int y) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return 0;
  return blueFlag[floor][y + VIS_OY][x + VIS_OX];
}
static inline uint8_t blueGet(int x, int y) {
  return blueGetFloor(currentFloor, x, y);
}
static inline void blueSet(int x, int y, uint8_t v) {
  if (!visInRange(x, y)) return;
  blueFlag[currentFloor][y + VIS_OY][x + VIS_OX] = (v ? 1 : 0);
}

static inline uint8_t redGetFloor(uint8_t floor, int x, int y) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return 0;
  return redFlag[floor][y + VIS_OY][x + VIS_OX];
}
static inline uint8_t redGet(int x, int y) {
  return redGetFloor(currentFloor, x, y);
}
static inline void redSet(int x, int y, uint8_t v) {
  if (!visInRange(x, y)) return;
  redFlag[currentFloor][y + VIS_OY][x + VIS_OX] = (v ? 1 : 0);
}

static uint8_t redFlagCountAllFloors() {
  uint8_t count = 0;
  for (uint8_t floor = 0; floor < FLOOR_COUNT; floor++) {
    for (int my = 0; my < VIS_H; my++) {
      for (int mx = 0; mx < VIS_W; mx++) {
        if (redFlag[floor][my][mx] != 0 && count < 255) count++;
      }
    }
  }
  return count;
}

static uint8_t redNcSnapshotRedFlagCountAllFloors() {
  if (!gRedNcSnapshotValid) return 0;
  uint8_t count = 0;
  for (uint8_t floor = 0; floor < FLOOR_COUNT; floor++) {
    for (int my = 0; my < VIS_H; my++) {
      for (int mx = 0; mx < VIS_W; mx++) {
        if (savedRedFlag[floor][my][mx] != 0 && count < 255) count++;
      }
    }
  }
  return count;
}

static uint8_t redNcSourceRedFlagCountAllFloors() {
  uint8_t snapCount = redNcSnapshotRedFlagCountAllFloors();
  if (gRedNcSnapshotValid && snapCount > 0) return snapCount;
  return redFlagCountAllFloors();
}

static void redNcCaptureSnapshotFromActive(const char* reason) {
  // M_41_28：初回RED保存時の地図を、赤脱出NCの照合元としてRAMへ退避する。
  // 以後のレッドゾーン内迷走・壁リセット・仮想座標処理でlive mapが変わっても、NCはこの安全な地図を見る。
  memcpy(savedVisitCnt, visitCnt, sizeof(visitCnt));
  memcpy(savedVictimFlag, victimFlag, sizeof(victimFlag));
  memcpy(savedBlueFlag, blueFlag, sizeof(blueFlag));
  memcpy(savedRedFlag, redFlag, sizeof(redFlag));
  memcpy(savedBumpFlag, bumpFlag, sizeof(bumpFlag));
  memcpy(savedZoneFlag, zoneFlag, sizeof(zoneFlag));
  memcpy(savedXY_Number, XY_Number, sizeof(XY_Number));
  memcpy(savedRed_Number, Red_Number, sizeof(Red_Number));
  memcpy(savedWallKnownMap, wallKnownMap, sizeof(wallKnownMap));
  memcpy(savedWallExistMap, wallExistMap, sizeof(wallExistMap));
  memcpy(savedFloorLinkMap, floorLinkMap, sizeof(floorLinkMap));
  memcpy(savedFloorLinkDirMap, floorLinkDirMap, sizeof(floorLinkDirMap));
  memcpy(savedFloorLinkTargetXMap, floorLinkTargetXMap, sizeof(floorLinkTargetXMap));
  memcpy(savedFloorLinkTargetYMap, floorLinkTargetYMap, sizeof(floorLinkTargetYMap));
  memcpy(savedFloorConnectorOnlyMap, floorConnectorOnlyMap, sizeof(floorConnectorOnlyMap));
  memcpy(savedSlopeExitIgnoreUnknownMap, slopeExitIgnoreUnknownMap, sizeof(slopeExitIgnoreUnknownMap));
  memcpy(savedSlopeTransitCellMap, slopeTransitCellMap, sizeof(slopeTransitCellMap));
  memcpy(savedSlopeDownExitNoSideReadMap, slopeDownExitNoSideReadMap, sizeof(slopeDownExitNoSideReadMap));
  savedCurrentFloorForLoc = currentFloor;
  memcpy(savedFloorHeightForLoc, floorHeight, sizeof(floorHeight));
  memcpy(savedFloorAssignedForLoc, floorAssigned, sizeof(floorAssigned));

  gRedNcSnapshotValid = (redNcSnapshotRedFlagCountAllFloors() > 0);
  Serial.print("RED_NC SNAP ");
  Serial.print(reason ? reason : "");
  Serial.print(" valid:");
  Serial.print(gRedNcSnapshotValid ? 1 : 0);
  Serial.print(" R:");
  Serial.println((unsigned)redNcSnapshotRedFlagCountAllFloors());
}

// ===== M_41_26 compile fix =====
// redRecovery系ヘルパーはこの位置で定義しているが、
// returnMode / inRedZone など一部のグローバル状態変数は下側で定義されている。
// C++では使用前に宣言が必要なので、ここでextern宣言だけ先に置く。
extern bool returnMode;
extern bool inRedZone;
extern bool redExitMode;
extern bool redExitLeavePending;
extern bool redNormalConfirmMode;
extern uint8_t redNormalConfirmStepCount;
extern bool frontierTargetMode;
extern uint8_t frontierTargetZone;
extern bool gFrontierFallbackExtLH;

static inline void redRecoveryVisitReset() {
  memset(redRecoveryVisitCnt, 0, sizeof(redRecoveryVisitCnt));
}

static inline uint16_t redRecoveryVisitGet(int x, int y) {
  if (!visInRange(x, y)) return 65535;
  return redRecoveryVisitCnt[y + VIS_OY][x + VIS_OX];
}

static inline void redRecoveryVisitInc(int x, int y) {
  if (!visInRange(x, y)) return;
  uint16_t &v = redRecoveryVisitCnt[y + VIS_OY][x + VIS_OX];
  if (v < 65535) v++;
}

static void redRecoveryResetRedZoneMemory() {
  // ZONE_REDとして記録されたセルの壁・訪問回数だけを消す。
  // redFlag / redEntranceInfo は、赤脱出NC候補に必要なので残す。
  for (uint8_t floor = 0; floor < FLOOR_COUNT; floor++) {
    for (int my = 0; my < VIS_H; my++) {
      for (int mx = 0; mx < VIS_W; mx++) {
        if (zoneFlag[floor][my][mx] != ZONE_RED) continue;
        visitCnt[floor][my][mx] = 0;
        wallKnownMap[floor][my][mx] = 0;
        wallExistMap[floor][my][mx] = 0;
        Frontier_Number[floor][my][mx] = FRONTIER_NUMBER_INF;
        // zoneFlagはREDのまま残す。redFlagも残す。
      }
    }
  }
}

static bool redRecoveryShouldStart() {
  if (!inRedZone) return false;
  // M_42_11：赤脱出NC中・赤タイル脱出直後の未確定ステップでは、物理的にはノーマル側にいる。
  // ここでvisitCnt>=4を拾うと、ノーマル側でRRSTしてしまうので禁止する。
  if (returnMode || redNormalConfirmMode || redRecoverySearchMode || redExitLeavePending || redRecoveryNcActive) return false;
  if (!floorIndexInRange(currentFloor) || !visInRange(posX, posY)) return false;
  return (visGet(posX, posY) >= RED_RECOVERY_VISIT_LIMIT);
}

static void redRecoveryStart(const char* reason) {
  Serial.print("RED_RECOVERY START ");
  Serial.print(reason ? reason : "");
  Serial.print(" F");
  Serial.print((unsigned)(currentFloor + 1));
  Serial.print(" oldX:");
  Serial.print(posX);
  Serial.print(" oldY:");
  Serial.print(posY);
  Serial.print(" oldDir:");
  Serial.println(dirChar(direction));

  redRecoveryResetRedZoneMemory();
  redRecoveryVisitReset();

  // ここからはレッドゾーン内の仮想座標として(0,0)北向きで再探索する。
  // NC確定まではreturnModeへ入らない。
  posX = 0;
  posY = 0;
  direction = 0;
  redRecoveryVisitInc(posX, posY);

  inRedZone = true;
  redRecoverySearchMode = true;
  redRecoveryOnRedTile = false;
  redRecoveryNcActive = false;
  redExitMode = false;
  redExitLeavePending = false;
  redNormalConfirmMode = false;
  redNormalConfirmStepCount = 0;
  redNormalConfirmResetCandidates();
  frontierTargetMode = false;
  frontierTargetZone = ZONE_UNKNOWN;
  gFrontierFallbackExtLH = false;
  unknownSweepReset();
  rebuildRed_NumberAll();
  showSdStatusForMs("RRST", 500);
}

static int redEntranceInfoFind(uint8_t floor, int x, int y) {
  for (uint8_t i = 0; i < redEntranceInfoCount; i++) {
    if (!redEntranceInfo[i].used) continue;
    if (redEntranceInfo[i].floor == floor && redEntranceInfo[i].x == x && redEntranceInfo[i].y == y) {
      return (int)i;
    }
  }
  return -1;
}

static void redEntranceInfoPrintOne(uint8_t idx) {
  if (idx >= redEntranceInfoCount || !redEntranceInfo[idx].used) return;

  const RedEntranceInfo &r = redEntranceInfo[idx];

  Serial.print("[RED-ENT] [");
  Serial.print((unsigned)idx);
  Serial.print("] F=");
  Serial.print((unsigned)(r.floor + 1));
  Serial.print(" X=");
  Serial.print((int)r.x);
  Serial.print(" Y=");
  Serial.print((int)r.y);
  Serial.print(" normalSide=");
  if (r.normalSideAbsDir <= 3) Serial.print(absDirName(r.normalSideAbsDir));
  else                         Serial.print("?");
  Serial.print(" normalNeighbor=(");
  Serial.print((int)r.normalX);
  Serial.print(",");
  Serial.print((int)r.normalY);
  Serial.print(") enterFromNormal=");
  if (r.enterFromNormalAbsDir <= 3) Serial.print(absDirName(r.enterFromNormalAbsDir));
  else                              Serial.print("?");
  Serial.print(" t=");
  Serial.println((unsigned long)r.discoveredMs);
}

static void redEntranceInfoPrintAll(const char* reason) {
  Serial.print("[RED-ENT] reason=");
  Serial.print(reason ? reason : "NONE");
  Serial.print(" count=");
  Serial.println((unsigned)redEntranceInfoCount);

  for (uint8_t i = 0; i < redEntranceInfoCount; i++) {
    redEntranceInfoPrintOne(i);
  }
}

static void redEntranceInfoRecord(uint8_t floor, int redX, int redY, uint8_t normalSideAbsDir, const char* reason) {
  if (!floorIndexInRange(floor) || !visInRange(redX, redY)) return;

  normalSideAbsDir &= 3;

  int normalX, normalY;
  neighborByAbs(normalSideAbsDir, redX, redY, normalX, normalY);

  int idx = redEntranceInfoFind(floor, redX, redY);
  bool isNew = false;

  if (idx < 0) {
    if (redEntranceInfoCount >= RED_ENTRANCE_INFO_MAX) {
      Serial.print("[RED-ENT] FULL drop F=");
      Serial.print((unsigned)(floor + 1));
      Serial.print(" X=");
      Serial.print(redX);
      Serial.print(" Y=");
      Serial.println(redY);
      return;
    }
    idx = redEntranceInfoCount++;
    isNew = true;
  }

  RedEntranceInfo &r = redEntranceInfo[idx];
  r.used = true;
  r.floor = floor;
  r.x = (int16_t)redX;
  r.y = (int16_t)redY;
  r.normalSideAbsDir = normalSideAbsDir;
  r.normalX = (int16_t)normalX;
  r.normalY = (int16_t)normalY;
  r.enterFromNormalAbsDir = oppositeAbsDir(normalSideAbsDir);
  r.discoveredMs = millis();

  Serial.print("[RED-ENT] ");
  Serial.print(isNew ? "ADD " : "UPD ");
  Serial.println(reason ? reason : "NONE");
  redEntranceInfoPrintAll(reason);
}

static inline uint8_t bumpGetFloor(uint8_t floor, int x, int y) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return 0;
  return bumpFlag[floor][y + VIS_OY][x + VIS_OX];
}
static inline uint8_t bumpGet(int x, int y) {
  return bumpGetFloor(currentFloor, x, y);
}
static inline void bumpSetFloor(uint8_t floor, int x, int y, uint8_t v) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return;
  bumpFlag[floor][y + VIS_OY][x + VIS_OX] = (v ? 1 : 0);
}
static inline void bumpSet(int x, int y, uint8_t v) {
  bumpSetFloor(currentFloor, x, y, v);
}

static inline uint16_t redNumberGetFloor(uint8_t floor, int x, int y) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return RED_NUMBER_INF;
  return Red_Number[floor][y + VIS_OY][x + VIS_OX];
}
static inline uint16_t redNumberGet(int x, int y) {
  return redNumberGetFloor(currentFloor, x, y);
}
static inline void redNumberSetFloor(uint8_t floor, int x, int y, uint16_t v) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return;
  Red_Number[floor][y + VIS_OY][x + VIS_OX] = v;
}
static inline void redNumberSet(int x, int y, uint16_t v) {
  redNumberSetFloor(currentFloor, x, y, v);
}

static inline uint16_t frontierNumberGetFloor(uint8_t floor, int x, int y) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return FRONTIER_NUMBER_INF;
  return Frontier_Number[floor][y + VIS_OY][x + VIS_OX];
}
static inline uint16_t frontierNumberGet(int x, int y) {
  return frontierNumberGetFloor(currentFloor, x, y);
}
static inline void frontierNumberSetFloor(uint8_t floor, int x, int y, uint16_t v) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return;
  Frontier_Number[floor][y + VIS_OY][x + VIS_OX] = v;
}
static inline void frontierNumberSet(int x, int y, uint16_t v) {
  frontierNumberSetFloor(currentFloor, x, y, v);
}

static inline bool hasKnownRedEntrance() {
  for (uint8_t floor = 0; floor < FLOOR_COUNT; floor++) {
    for (int my = 0; my < VIS_H; my++) {
      for (int mx = 0; mx < VIS_W; mx++) {
        if (redFlag[floor][my][mx]) return true;
      }
    }
  }
  return false;
}

static inline uint16_t xyNumberGetFloor(uint8_t floor, int x, int y) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return XY_NUMBER_INF;
  return XY_Number[floor][y + VIS_OY][x + VIS_OX];
}
static inline uint16_t xyNumberGet(int x, int y) {
  return xyNumberGetFloor(currentFloor, x, y);
}
static inline void xyNumberSetFloor(uint8_t floor, int x, int y, uint16_t v) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return;
  XY_Number[floor][y + VIS_OY][x + VIS_OX] = v;
}
static inline void xyNumberSet(int x, int y, uint16_t v) {
  xyNumberSetFloor(currentFloor, x, y, v);
}

static inline uint8_t wallDirBit(uint8_t absDir) {
  return (uint8_t)(1u << (absDir & 3));
}
static inline void neighborByAbs(uint8_t absDir, int cx, int cy, int &nx, int &ny) {
  nx = cx; ny = cy;
  switch (absDir & 3) {
    case 0: ny += 1; break; // N
    case 1: nx += 1; break; // E
    case 2: ny -= 1; break; // S
    default: nx -= 1; break; // W
  }
}
static inline uint8_t oppositeAbsDir(uint8_t absDir) {
  return (uint8_t)((absDir + 2) & 3);
}

static inline const char* absDirName(uint8_t absDir) {
  switch (absDir & 3) {
    case 0: return "N";
    case 1: return "E";
    case 2: return "S";
    default: return "W";
  }
}

static inline uint8_t wallStateGetFloor(uint8_t floor, int x, int y, uint8_t absDir) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return WALL_STATE_UNKNOWN;
  uint8_t bit = wallDirBit(absDir);
  uint8_t known = wallKnownMap[floor][y + VIS_OY][x + VIS_OX];
  if ((known & bit) == 0) return WALL_STATE_UNKNOWN;
  uint8_t exist = wallExistMap[floor][y + VIS_OY][x + VIS_OX];
  return (exist & bit) ? WALL_STATE_BLOCKED : WALL_STATE_OPEN;
}

static inline uint8_t redNcSnapshotWallStateGetFloor(uint8_t floor, int x, int y, uint8_t absDir) {
  // M_41_28：赤脱出NCでは、レッドゾーン進入後に汚れた可能性があるlive mapではなく、
  // 初回RED保存時/SD LOAD時のスナップショットを照合元にする。
  if (!gRedNcSnapshotValid) return wallStateGetFloor(floor, x, y, absDir);
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return WALL_STATE_UNKNOWN;
  uint8_t bit = wallDirBit(absDir);
  uint8_t known = savedWallKnownMap[floor][y + VIS_OY][x + VIS_OX];
  if ((known & bit) == 0) return WALL_STATE_UNKNOWN;
  uint8_t exist = savedWallExistMap[floor][y + VIS_OY][x + VIS_OX];
  return (exist & bit) ? WALL_STATE_BLOCKED : WALL_STATE_OPEN;
}

static inline uint8_t redNcSnapshotRedGetFloor(uint8_t floor, int x, int y) {
  if (!gRedNcSnapshotValid) return redGetFloor(floor, x, y);
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return 0;
  return savedRedFlag[floor][y + VIS_OY][x + VIS_OX];
}

static inline uint8_t wallStateGet(int x, int y, uint8_t absDir) {
  return wallStateGetFloor(currentFloor, x, y, absDir);
}
static inline void wallSetKnownStateFloor(uint8_t floor, int x, int y, uint8_t absDir, bool isWall) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return;
  uint8_t bit = wallDirBit(absDir);
  uint8_t &known = wallKnownMap[floor][y + VIS_OY][x + VIS_OX];
  uint8_t &exist = wallExistMap[floor][y + VIS_OY][x + VIS_OX];
  known |= bit;
  if (isWall) exist |= bit;
  else        exist &= (uint8_t)~bit;
}
static inline void wallSetKnownState(int x, int y, uint8_t absDir, bool isWall) {
  wallSetKnownStateFloor(currentFloor, x, y, absDir, isWall);
}
static inline void wallSetKnownStateBothFloor(uint8_t floor, int x, int y, uint8_t absDir, bool isWall) {
  wallSetKnownStateFloor(floor, x, y, absDir, isWall);

  int nx, ny;
  neighborByAbs(absDir, x, y, nx, ny);
  if (visInRange(nx, ny)) {
    wallSetKnownStateFloor(floor, nx, ny, oppositeAbsDir(absDir), isWall);
  }
}
static inline void wallSetKnownStateBoth(int x, int y, uint8_t absDir, bool isWall) {
  wallSetKnownStateBothFloor(currentFloor, x, y, absDir, isWall);
}

static inline void wallClearKnownStateFloor(uint8_t floor, int x, int y, uint8_t absDir) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return;
  uint8_t bit = wallDirBit(absDir);
  uint8_t &known = wallKnownMap[floor][y + VIS_OY][x + VIS_OX];
  uint8_t &exist = wallExistMap[floor][y + VIS_OY][x + VIS_OX];
  known &= (uint8_t)~bit;
  exist &= (uint8_t)~bit;
}

static inline void wallClearKnownStateBothFloor(uint8_t floor, int x, int y, uint8_t absDir) {
  wallClearKnownStateFloor(floor, x, y, absDir);

  int nx, ny;
  neighborByAbs(absDir, x, y, nx, ny);
  if (visInRange(nx, ny)) {
    wallClearKnownStateFloor(floor, nx, ny, oppositeAbsDir(absDir));
  }
}

static inline bool floorLinkExists(uint8_t floor, int x, int y, uint8_t targetFloor) {
  if (!floorIndexInRange(floor) || !floorIndexInRange(targetFloor) || !visInRange(x, y)) return false;
  return (floorLinkMap[floor][y + VIS_OY][x + VIS_OX] & (uint8_t)(1u << targetFloor)) != 0;
}

static inline uint8_t floorLinkMaskGet(uint8_t floor, int x, int y) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return 0;
  return floorLinkMap[floor][y + VIS_OY][x + VIS_OX] & 0x07;
}

static inline uint8_t floorLinkDirGet(uint8_t floor, int x, int y, uint8_t targetFloor) {
  if (!floorIndexInRange(floor) || !floorIndexInRange(targetFloor) || !visInRange(x, y)) return FLOOR_LINK_DIR_NONE;
  if (!floorLinkExists(floor, x, y, targetFloor)) return FLOOR_LINK_DIR_NONE;
  uint8_t d = floorLinkDirMap[floor][y + VIS_OY][x + VIS_OX][targetFloor];
  return (d <= 3) ? d : FLOOR_LINK_DIR_NONE;
}

static inline void floorLinkTargetGet(uint8_t floor, int x, int y, uint8_t targetFloor, int &tx, int &ty) {
  tx = x;
  ty = y;
  if (!floorIndexInRange(floor) || !floorIndexInRange(targetFloor) || !visInRange(x, y)) return;
  if (!floorLinkExists(floor, x, y, targetFloor)) return;

  int mx = x + VIS_OX;
  int my = y + VIS_OY;
  tx = (int)floorLinkTargetXMap[floor][my][mx][targetFloor];
  ty = (int)floorLinkTargetYMap[floor][my][mx][targetFloor];

  if (!visInRange(tx, ty)) {
    tx = x;
    ty = y;
  }
}

static inline void floorLinkTargetSetByIndex(uint8_t floor, int mx, int my, uint8_t targetFloor, int tx, int ty) {
  if (!floorIndexInRange(floor) || !floorIndexInRange(targetFloor)) return;
  if (mx < 0 || mx >= VIS_W || my < 0 || my >= VIS_H) return;
  tx = constrain(tx, -VIS_OX, VIS_W - VIS_OX - 1);
  ty = constrain(ty, -VIS_OY, VIS_H - VIS_OY - 1);
  floorLinkTargetXMap[floor][my][mx][targetFloor] = (int8_t)tx;
  floorLinkTargetYMap[floor][my][mx][targetFloor] = (int8_t)ty;
}

static inline void floorLinkSetBoth(uint8_t floorA, uint8_t floorB, int x, int y) {
  if (!floorIndexInRange(floorA) || !floorIndexInRange(floorB) || floorA == floorB || !visInRange(x, y)) return;
  floorLinkSetBothWithDirBetween(floorA, x, y, floorB, x, y, 0);
  floorLinkDirMap[floorA][y + VIS_OY][x + VIS_OX][floorB] = FLOOR_LINK_DIR_NONE;
  floorLinkDirMap[floorB][y + VIS_OY][x + VIS_OX][floorA] = FLOOR_LINK_DIR_NONE;
}

static inline void floorLinkSetBothWithDir(uint8_t floorA, uint8_t floorB, int x, int y, uint8_t absDirAToB) {
  floorLinkSetBothWithDirBetween(floorA, x, y, floorB, x, y, absDirAToB);
}

static inline void floorLinkSetBothWithDirBetween(uint8_t floorA, int xA, int yA, uint8_t floorB, int xB, int yB, uint8_t absDirAToB) {
  if (absDirAToB > 3) return;
  if (!floorIndexInRange(floorA) || !floorIndexInRange(floorB) || floorA == floorB) return;
  if (!visInRange(xA, yA) || !visInRange(xB, yB)) return;

  int mxA = xA + VIS_OX;
  int myA = yA + VIS_OY;
  int mxB = xB + VIS_OX;
  int myB = yB + VIS_OY;

  floorLinkMap[floorA][myA][mxA] |= (uint8_t)(1u << floorB);
  floorLinkMap[floorB][myB][mxB] |= (uint8_t)(1u << floorA);

  floorLinkDirMap[floorA][myA][mxA][floorB] = absDirAToB;
  floorLinkDirMap[floorB][myB][mxB][floorA] = oppositeAbsDir(absDirAToB);

  floorLinkTargetSetByIndex(floorA, mxA, myA, floorB, xB, yB);
  floorLinkTargetSetByIndex(floorB, mxB, myB, floorA, xA, yA);
}

static inline uint16_t floorLinkDirsPackByIndex(uint8_t floor, int mx, int my) {
  if (!floorIndexInRange(floor) || mx < 0 || mx >= VIS_W || my < 0 || my >= VIS_H) return 0;
  uint16_t packed = 0;
  for (uint8_t tf = 0; tf < FLOOR_COUNT; tf++) {
    uint8_t d = floorLinkDirMap[floor][my][mx][tf];
    if (d > FLOOR_LINK_DIR_NONE) d = FLOOR_LINK_DIR_NONE;
    packed |= (uint16_t)((d & 0x07) << (tf * 3));
  }
  return packed;
}

static inline void floorLinkDirsUnpackByIndex(uint8_t floor, int mx, int my, uint16_t packed) {
  if (!floorIndexInRange(floor) || mx < 0 || mx >= VIS_W || my < 0 || my >= VIS_H) return;
  for (uint8_t tf = 0; tf < FLOOR_COUNT; tf++) {
    uint8_t d = (uint8_t)((packed >> (tf * 3)) & 0x07);
    floorLinkDirMap[floor][my][mx][tf] = (d <= 3) ? d : FLOOR_LINK_DIR_NONE;
  }
}

static inline uint32_t floorLinkTargetsXPackByIndex(uint8_t floor, int mx, int my) {
  if (!floorIndexInRange(floor) || mx < 0 || mx >= VIS_W || my < 0 || my >= VIS_H) return 0;
  uint32_t packed = 0;
  for (uint8_t tf = 0; tf < FLOOR_COUNT; tf++) {
    int v = (int)floorLinkTargetXMap[floor][my][mx][tf] + VIS_OX;
    v = constrain(v, 0, 63);
    packed |= ((uint32_t)(v & 0x3F) << (tf * 6));
  }
  return packed;
}

static inline uint32_t floorLinkTargetsYPackByIndex(uint8_t floor, int mx, int my) {
  if (!floorIndexInRange(floor) || mx < 0 || mx >= VIS_W || my < 0 || my >= VIS_H) return 0;
  uint32_t packed = 0;
  for (uint8_t tf = 0; tf < FLOOR_COUNT; tf++) {
    int v = (int)floorLinkTargetYMap[floor][my][mx][tf] + VIS_OY;
    v = constrain(v, 0, 63);
    packed |= ((uint32_t)(v & 0x3F) << (tf * 6));
  }
  return packed;
}

static inline void floorLinkTargetsUnpackByIndex(uint8_t floor, int mx, int my, uint32_t packedX, uint32_t packedY) {
  if (!floorIndexInRange(floor) || mx < 0 || mx >= VIS_W || my < 0 || my >= VIS_H) return;
  for (uint8_t tf = 0; tf < FLOOR_COUNT; tf++) {
    int tx = (int)((packedX >> (tf * 6)) & 0x3F) - VIS_OX;
    int ty = (int)((packedY >> (tf * 6)) & 0x3F) - VIS_OY;
    if (!visInRange(tx, ty)) {
      tx = mx - VIS_OX;
      ty = my - VIS_OY;
    }
    floorLinkTargetXMap[floor][my][mx][tf] = (int8_t)tx;
    floorLinkTargetYMap[floor][my][mx][tf] = (int8_t)ty;
  }
}

static inline bool floorConnectorOnlyGetFloor(uint8_t floor, int x, int y) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return false;
  return floorConnectorOnlyMap[floor][y + VIS_OY][x + VIS_OX] != 0;
}

static inline void floorConnectorOnlySetFloor(uint8_t floor, int x, int y, bool isConnectorOnly) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return;
  floorConnectorOnlyMap[floor][y + VIS_OY][x + VIS_OX] = isConnectorOnly ? 1 : 0;
}

static inline bool slopeExitIgnoreUnknownDirGetFloor(uint8_t floor, int x, int y, uint8_t absDir) {
  if (!floorIndexInRange(floor) || !visInRange(x, y) || absDir > 3) return false;
  uint8_t mask = slopeExitIgnoreUnknownMap[floor][y + VIS_OY][x + VIS_OX] & 0x0F;
  return (mask & (uint8_t)(1u << absDir)) != 0;
}

static inline void slopeExitIgnoreUnknownSetFloor(uint8_t floor, int x, int y, uint8_t travelAbsDir) {
  if (!floorIndexInRange(floor) || !visInRange(x, y) || travelAbsDir > 3) return;

  uint8_t leftAbs  = (uint8_t)((travelAbsDir + 3) & 3);
  uint8_t rightAbs = (uint8_t)((travelAbsDir + 1) & 3);
  uint8_t backAbs  = (uint8_t)((travelAbsDir + 2) & 3);

  // 2026.5.23：坂出口マスは位置ズレしやすいが、進路選択では左右UNKNOWNを候補に戻す。
  // 後ろ方向だけは坂を戻る方向になりやすいので、UNKNOWN確認候補から外す。
  uint8_t* pMask = &slopeExitIgnoreUnknownMap[floor][y + VIS_OY][x + VIS_OX];
  uint8_t mask = (uint8_t)(*pMask & 0x0F);
  mask &= (uint8_t)~((uint8_t)((1u << leftAbs) | (1u << rightAbs))); // 旧版で立った左右IGNOREを解除
  mask |= (uint8_t)(1u << backAbs);                                  // 後ろだけIGNORE継続
  *pMask = (uint8_t)((*pMask & 0xF0) | (mask & 0x0F));

  Serial.print("SLOPE EXIT IGNORE BACK F");
  Serial.print((unsigned)(floor + 1));
  Serial.print(" X:");
  Serial.print(x);
  Serial.print(" Y:");
  Serial.print(y);
  Serial.print(" BACK:");
  Serial.print((unsigned)backAbs);
  Serial.print(" MASK:");
  Serial.println((unsigned)(slopeExitIgnoreUnknownMap[floor][y + VIS_OY][x + VIS_OX] & 0x0F));
}

static inline bool slopeDownExitNoSideReadDirGetFloor(uint8_t floor, int x, int y, uint8_t absDir) {
  if (!floorIndexInRange(floor) || !visInRange(x, y) || absDir > 3) return false;
  uint8_t mask = slopeDownExitNoSideReadMap[floor][y + VIS_OY][x + VIS_OX] & 0x0F;
  return (mask & (uint8_t)(1u << absDir)) != 0;
}

static inline void slopeDownExitNoSideReadSetFloor(uint8_t floor, int x, int y, uint8_t travelAbsDir) {
  if (!floorIndexInRange(floor) || !visInRange(x, y) || travelAbsDir > 3) return;

  uint8_t leftAbs  = (uint8_t)((travelAbsDir + 3) & 3);
  uint8_t rightAbs = (uint8_t)((travelAbsDir + 1) & 3);
  uint8_t mask = (uint8_t)((1u << leftAbs) | (1u << rightAbs));
  slopeDownExitNoSideReadMap[floor][y + VIS_OY][x + VIS_OX] |= mask;

  Serial.print("DOWN EXIT NO SIDE READ F");
  Serial.print((unsigned)(floor + 1));
  Serial.print(" X:");
  Serial.print(x);
  Serial.print(" Y:");
  Serial.print(y);
  Serial.print(" MASK:");
  Serial.println((unsigned)(slopeDownExitNoSideReadMap[floor][y + VIS_OY][x + VIS_OX] & 0x0F));
}

static inline bool slopeTransitCellGetFloor(uint8_t floor, int x, int y) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return false;
  return slopeTransitCellMap[floor][y + VIS_OY][x + VIS_OX] != 0;
}

static inline void slopeTransitCellSetFloor(uint8_t floor, int x, int y, bool isSlopeCell) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return;
  uint8_t &cell = slopeTransitCellMap[floor][y + VIS_OY][x + VIS_OX];
  if (!isSlopeCell) {
    cell = 0;
  } else if (cell == 0) {
    cell = 1; // 1=SLのみ / 2=SL+LOW / 3=SL+HIGH
  }
}

static inline void slopeTransitCellSetUpExtraModeForFloor(uint8_t floor, int x, int y, uint8_t mode) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return;
  if (mode != 1 && mode != 2) return;
  // 2=LOW、3=HIGH。SL判定は従来通り「0以外」で扱う。
  slopeTransitCellMap[floor][y + VIS_OY][x + VIS_OX] = (mode == 2) ? 3 : 2;
}

static inline uint8_t slopeTransitCellUpExtraModeGetFloor(uint8_t floor, int x, int y) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return 0;
  uint8_t cell = slopeTransitCellMap[floor][y + VIS_OY][x + VIS_OX];
  if (cell == 2) return 1; // LOW
  if (cell == 3) return 2; // HIGH
  return 0;
}

static inline void slopeExitClearSideWallsAndTransitForFloor(uint8_t floor, int x, int y, uint8_t travelAbsDir, const char* reason) {
  if (!floorIndexInRange(floor) || !visInRange(x, y) || travelAbsDir > 3) return;

  uint8_t leftAbs  = (uint8_t)((travelAbsDir + 3) & 3);
  uint8_t rightAbs = (uint8_t)((travelAbsDir + 1) & 3);

  // 2026.5.23：坂入口/坂出口マスは通常探索へ戻す。
  // 既に読み取った左右壁情報は保持し、SLセル扱いと左右UNKNOWN無視マスクだけ解除する。
  // 入口マスが後から出口扱いになっても、正しく読めていた壁情報をUnknownへ戻さない。
  slopeTransitCellSetFloor(floor, x, y, false);

  uint8_t* pMask = &slopeExitIgnoreUnknownMap[floor][y + VIS_OY][x + VIS_OX];
  *pMask &= (uint8_t)~((uint8_t)((1u << leftAbs) | (1u << rightAbs)));

  Serial.print("SLOPE EXIT CLEAR SL/IGNORE KEEP_WALLS ");
  Serial.print(reason ? reason : "");
  Serial.print(" F");
  Serial.print((unsigned)(floor + 1));
  Serial.print(" X:");
  Serial.print(x);
  Serial.print(" Y:");
  Serial.print(y);
  Serial.print(" L:");
  Serial.print((unsigned)leftAbs);
  Serial.print(" R:");
  Serial.println((unsigned)rightAbs);
}


static inline void terrainPendingCoordReset(const char* reason) {
  if (gPendingFloorCoordCount > 0) {
    Serial.print("PENDING COORD RESET reason=");
    Serial.print(reason ? reason : "");
    Serial.print(" count=");
    Serial.println((unsigned)gPendingFloorCoordCount);
  }
  for (uint8_t i = 0; i < PENDING_FLOOR_COORD_MAX; i++) {
    gPendingFloorCoord[i].valid = false;
  }
  gPendingFloorCoordCount = 0;
}

static inline bool terrainPendingCoordContains(uint8_t floor, int x, int y) {
  for (uint8_t i = 0; i < gPendingFloorCoordCount; i++) {
    const PendingFloorCoordRecord &r = gPendingFloorCoord[i];
    if (r.valid && r.floor == floor && r.x == x && r.y == y) return true;
  }
  return false;
}

static inline void terrainPendingCoordRecordIfActive(const char* reason) {
  if (!gTerrainPassFloorSwitchPending) return;
  if (currentFloor != gTerrainPassPendingFromFloor) return;
  if (!floorIndexInRange(currentFloor) || !visInRange(posX, posY)) return;
  if (terrainPendingCoordContains(currentFloor, posX, posY)) return;

  if (gPendingFloorCoordCount >= PENDING_FLOOR_COORD_MAX) {
    Serial.print("PENDING COORD FULL reason=");
    Serial.print(reason ? reason : "");
    Serial.print(" F");
    Serial.print((unsigned)(currentFloor + 1));
    Serial.print(" X:");
    Serial.print(posX);
    Serial.print(" Y:");
    Serial.println(posY);
    return;
  }

  PendingFloorCoordRecord &r = gPendingFloorCoord[gPendingFloorCoordCount++];
  r.valid = true;
  r.floor = currentFloor;
  r.x = posX;
  r.y = posY;
  r.backup.valid = false;
  if (lastCoordStepBackupMatches(currentFloor, posX, posY)) {
    r.backup = gLastCoordStepBackup;
  }

  Serial.print("PENDING COORD ADD reason=");
  Serial.print(reason ? reason : "");
  Serial.print(" F");
  Serial.print((unsigned)(r.floor + 1));
  Serial.print(" X:");
  Serial.print(r.x);
  Serial.print(" Y:");
  Serial.print(r.y);
  Serial.print(" backup=");
  Serial.println(r.backup.valid ? 1 : 0);
}

static inline bool terrainPendingCoordRestoreBackup(const CellBackup &backup, const char* reason) {
  if (!backup.valid) return false;
  CellBackup keep = gLastCoordStepBackup;
  gLastCoordStepBackup = backup;
  bool ok = lastCoordStepBackupRestoreIfMatches(backup.floor, backup.x, backup.y, reason);
  gLastCoordStepBackup = keep;
  return ok;
}

static inline bool absDirFromAdjacentCells(int x0, int y0, int x1, int y1, uint8_t &absDir) {
  if (x1 == x0 && y1 == y0 + 1) { absDir = 0; return true; }
  if (x1 == x0 + 1 && y1 == y0) { absDir = 1; return true; }
  if (x1 == x0 && y1 == y0 - 1) { absDir = 2; return true; }
  if (x1 == x0 - 1 && y1 == y0) { absDir = 3; return true; }
  return false;
}

static inline void terrainPendingMarkVisitedOnFloor(uint8_t floor, int x, int y, uint16_t addCount) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return;
  int mx = x + VIS_OX;
  int my = y + VIS_OY;
  uint32_t v = (uint32_t)visitCnt[floor][my][mx] + (uint32_t)((addCount == 0) ? 1 : addCount);
  if (v > 65535) v = 65535;
  visitCnt[floor][my][mx] = (uint16_t)v;
  if (zoneFlag[floor][my][mx] == ZONE_UNKNOWN) zoneFlag[floor][my][mx] = ZONE_NORMAL;
  floorConnectorOnlyMap[floor][my][mx] = 0;
  slopeTransitCellSetFloor(floor, x, y, false);
}

static void terrainPendingCoordMigrateOneToFloor(const PendingFloorCoordRecord &r, uint8_t toFloor) {
  if (!r.valid || !floorIndexInRange(r.floor) || !floorIndexInRange(toFloor) || !visInRange(r.x, r.y)) return;

  int mx = r.x + VIS_OX;
  int my = r.y + VIS_OY;
  uint16_t beforeVisit = r.backup.valid ? r.backup.visit : 0;
  uint16_t afterVisit = visitCnt[r.floor][my][mx];
  uint16_t addVisit = (afterVisit > beforeVisit) ? (uint16_t)(afterVisit - beforeVisit) : 1;
  terrainPendingMarkVisitedOnFloor(toFloor, r.x, r.y, addVisit);

  // 色・被災者・バンプなど、PENDING中に新しく立ったフラグだけ新フロア側へ移す。
  if (victimFlag[r.floor][my][mx]) victimFlag[toFloor][my][mx] = 1;
  if (blueFlag[r.floor][my][mx])   blueFlag[toFloor][my][mx] = 1;
  if (redFlag[r.floor][my][mx])    redFlag[toFloor][my][mx] = 1;
  if (bumpFlag[r.floor][my][mx])   bumpFlag[toFloor][my][mx] = 1;
  if (zoneFlag[r.floor][my][mx] != ZONE_UNKNOWN) zoneFlag[toFloor][my][mx] = zoneFlag[r.floor][my][mx];

  uint8_t afterKnown = wallKnownMap[r.floor][my][mx] & 0x0F;
  uint8_t afterExist = wallExistMap[r.floor][my][mx] & 0x0F;
  uint8_t beforeKnown = r.backup.valid ? (r.backup.wallKnownBits & 0x0F) : 0;
  uint8_t beforeExist = r.backup.valid ? (r.backup.wallExistBits & 0x0F) : 0;

  for (uint8_t absDir = 0; absDir < 4; absDir++) {
    uint8_t bit = (uint8_t)(1u << absDir);
    if ((afterKnown & bit) == 0) continue;
    bool beforeSame = ((beforeKnown & bit) != 0) && (((beforeExist ^ afterExist) & bit) == 0);
    if (beforeSame) continue;
    wallSetKnownStateBothFloor(toFloor, r.x, r.y, absDir, ((afterExist & bit) != 0));
  }

  Serial.print("PENDING COORD MOVE TO F");
  Serial.print((unsigned)(toFloor + 1));
  Serial.print(" X:");
  Serial.print(r.x);
  Serial.print(" Y:");
  Serial.print(r.y);
  Serial.print(" addVis=");
  Serial.println((unsigned)addVisit);
}

static void terrainPendingCoordApplyToNewFloor(uint8_t toFloor, int exitX, int exitY, uint8_t travelAbsDir) {
  if (!floorIndexInRange(toFloor)) return;

  // 坂出口の平地マスは、新フロア側で必ず訪問済みにする。
  terrainPendingMarkVisitedOnFloor(toFloor, exitX, exitY, 1);
  slopeExitClearSideWallsAndTransitForFloor(toFloor, exitX, exitY, travelAbsDir, "PENDING_TO_EXIT");

  int prevX = exitX;
  int prevY = exitY;
  for (uint8_t i = 0; i < gPendingFloorCoordCount; i++) {
    PendingFloorCoordRecord &r = gPendingFloorCoord[i];
    if (!r.valid) continue;
    terrainPendingCoordMigrateOneToFloor(r, toFloor);

    uint8_t openDir = 0;
    if (absDirFromAdjacentCells(prevX, prevY, r.x, r.y, openDir)) {
      wallSetKnownStateBothFloor(toFloor, prevX, prevY, openDir, false);
    }
    prevX = r.x;
    prevY = r.y;
  }
}

static void terrainPendingCoordRestoreOldFloor(const char* reason) {
  for (uint8_t i = 0; i < gPendingFloorCoordCount; i++) {
    PendingFloorCoordRecord &r = gPendingFloorCoord[i];
    if (!r.valid) continue;
    if (!terrainPendingCoordRestoreBackup(r.backup, reason ? reason : "PENDING OLD RESTORE")) {
      // バックアップが無い場合は、幽霊セルを残さないため最低限の情報だけ落とす。
      if (floorIndexInRange(r.floor) && visInRange(r.x, r.y)) {
        int mx = r.x + VIS_OX;
        int my = r.y + VIS_OY;
        visitCnt[r.floor][my][mx] = 0;
        zoneFlag[r.floor][my][mx] = ZONE_UNKNOWN;
        floorConnectorOnlyMap[r.floor][my][mx] = 0;
        slopeExitIgnoreUnknownMap[r.floor][my][mx] = 0;
        slopeTransitCellMap[r.floor][my][mx] = 0;
        slopeDownExitNoSideReadMap[r.floor][my][mx] = 0;
      }
    }
  }
}

static inline void markSlopeTransitCellForFloor(uint8_t floor, int x, int y, uint8_t travelAbsDir) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return;

  slopeTransitCellSetFloor(floor, x, y, true);

  Serial.print("SLOPE TRANSIT IGNORE F");
  Serial.print((unsigned)(floor + 1));
  Serial.print(" X:");
  Serial.print(x);
  Serial.print(" Y:");
  Serial.print(y);
  Serial.print(" DIR:");
  Serial.println((unsigned)(travelAbsDir & 3));
}

static inline void markSlopeSideWallsBlockedForFloor(uint8_t floor, int x, int y, uint8_t travelAbsDir) {
  if (!floorIndexInRange(floor) || !visInRange(x, y) || travelAbsDir > 3) return;
  uint8_t leftAbs  = (uint8_t)((travelAbsDir + 3) & 3);
  uint8_t rightAbs = (uint8_t)((travelAbsDir + 1) & 3);
  wallSetKnownStateBothFloor(floor, x, y, leftAbs, true);
  wallSetKnownStateBothFloor(floor, x, y, rightAbs, true);
}


static inline void slopeSideWallCellsReset() {
  gSlopeCellCount = 0;
}

static inline bool slopeSideWallCellAlreadyRecorded(int x, int y, uint8_t travelAbsDir) {
  for (uint8_t i = 0; i < gSlopeCellCount; i++) {
    if (gSlopeCellX[i] == x && gSlopeCellY[i] == y && gSlopeCellTravelAbsDir[i] == (travelAbsDir & 3)) return true;
  }
  return false;
}

static inline void slopeSideWallCellAdd(int x, int y, uint8_t travelAbsDir, const char* reason) {
  if (!visInRange(x, y) || travelAbsDir > 3) return;
  if (slopeSideWallCellAlreadyRecorded(x, y, travelAbsDir)) return;
  if (gSlopeCellCount >= SLOPE_SIDE_WALL_CELL_MAX) return;

  gSlopeCellX[gSlopeCellCount] = x;
  gSlopeCellY[gSlopeCellCount] = y;
  gSlopeCellTravelAbsDir[gSlopeCellCount] = travelAbsDir & 3;
  gSlopeCellCount++;

  Serial.print("SLOPE CELL ADD ");
  Serial.print(reason ? reason : "");
  Serial.print(" X:");
  Serial.print(x);
  Serial.print(" Y:");
  Serial.print(y);
  Serial.print(" DIR:");
  Serial.println((unsigned)(travelAbsDir & 3));
}

// 2026.5.17：記録済み坂セルをSLセルとして確実に残す。
// SLセルは未探索フロンティア/UNKNOWN確認から除外するが、通路・RETURN経路としては残す。
static inline void markRecordedSlopeCellsAsSLForFloor(uint8_t floor, const char* reason) {
  if (!floorIndexInRange(floor)) return;

  for (uint8_t i = 0; i < gSlopeCellCount; i++) {
    if (!visInRange(gSlopeCellX[i], gSlopeCellY[i])) continue;

    slopeTransitCellSetFloor(floor, gSlopeCellX[i], gSlopeCellY[i], true);

    Serial.print("SL CELL MARK ");
    Serial.print(reason ? reason : "");
    Serial.print(" F");
    Serial.print((unsigned)(floor + 1));
    Serial.print(" X:");
    Serial.print(gSlopeCellX[i]);
    Serial.print(" Y:");
    Serial.print(gSlopeCellY[i]);
    Serial.print(" DIR:");
    Serial.println((unsigned)(gSlopeCellTravelAbsDir[i] & 3));
  }
}

static inline void markRecordedSlopeCellsUpExtraModeForFloor(uint8_t floor, uint8_t mode, const char* reason) {
  if (!floorIndexInRange(floor)) return;
  if (mode != 1 && mode != 2) return;

  for (uint8_t i = 0; i < gSlopeCellCount; i++) {
    if (!visInRange(gSlopeCellX[i], gSlopeCellY[i])) continue;

    slopeTransitCellSetUpExtraModeForFloor(floor, gSlopeCellX[i], gSlopeCellY[i], mode);

    Serial.print("SL CELL MODE ");
    Serial.print(reason ? reason : "");
    Serial.print(" F");
    Serial.print((unsigned)(floor + 1));
    Serial.print(" X:");
    Serial.print(gSlopeCellX[i]);
    Serial.print(" Y:");
    Serial.print(gSlopeCellY[i]);
    Serial.print(" MODE:");
    Serial.println(mode == 2 ? "HIGH" : "LOW");
  }
}

static inline void slopeSideWallCellAddCandidate(bool coordAlreadyUpdated, const char* reason) {
  uint8_t travelAbsDir = direction & 3;
  int sx = posX;
  int sy = posY;
  if (!coordAlreadyUpdated) {
    neighborByAbs(travelAbsDir, posX, posY, sx, sy);
  }
  slopeSideWallCellAdd(sx, sy, travelAbsDir, reason);
}

static inline void slopeSideWallCellAddCurrentIfSlopeLike(float currentPitchDeg, const char* reason) {
  // 平地復帰直後の平らなタイルへ左右壁を入れないため、Pitchが十分傾いている時だけ追加する。
  // SLOPE_RELEASE_PITCH_DEGの宣言位置より前の関数なので、同じ5.0°を直接使う。
  if (fabsf(currentPitchDeg) < 5.0f) return;
  slopeSideWallCellAdd(posX, posY, direction & 3, reason);
}

static inline void applySlopeSideWallCellsForFloors(uint8_t fromFloor, uint8_t toFloor, int exitX, int exitY) {
  if (!floorIndexInRange(fromFloor) || !floorIndexInRange(toFloor)) return;

  // 2026.5.23：
  // TR:RAMP保留方式では、floorSwitchAfterSlope()実行時のposX,posYが
  // すでに坂出口ではなく、90°回転後に進んだ隣マスになっている場合がある。
  // そのため、現在posX,posYだけでなく、実際の坂出口exitX,exitYも
  // 坂セル左右壁自動BLOCKEDから必ず除外する。
  if (gSlopeCellCount > 0) {
    for (uint8_t i = 0; i < gSlopeCellCount; i++) {
      bool isCurrentPos = (gSlopeCellX[i] == posX && gSlopeCellY[i] == posY);
      bool isSlopeExit = (gSlopeCellX[i] == exitX && gSlopeCellY[i] == exitY);
      if (isCurrentPos || isSlopeExit) {
        Serial.print("SLOPE EXIT CELL SKIP SIDE WALL ");
        Serial.print(isSlopeExit ? "EXIT " : "CURRENT ");
        Serial.print("X:");
        Serial.print(gSlopeCellX[i]);
        Serial.print(" Y:");
        Serial.print(gSlopeCellY[i]);
        Serial.print(" DIR:");
        Serial.println((unsigned)gSlopeCellTravelAbsDir[i]);
        continue;
      }

      markSlopeSideWallsBlockedForFloor(fromFloor, gSlopeCellX[i], gSlopeCellY[i], gSlopeCellTravelAbsDir[i]);
      markSlopeSideWallsBlockedForFloor(toFloor,   gSlopeCellX[i], gSlopeCellY[i], gSlopeCellTravelAbsDir[i]);
      markSlopeTransitCellForFloor(fromFloor, gSlopeCellX[i], gSlopeCellY[i], gSlopeCellTravelAbsDir[i]);
      markSlopeTransitCellForFloor(toFloor,   gSlopeCellX[i], gSlopeCellY[i], gSlopeCellTravelAbsDir[i]);
      Serial.print("SLOPE SIDE WALL CELL F");
      Serial.print((unsigned)(fromFloor + 1));
      Serial.print("/F");
      Serial.print((unsigned)(toFloor + 1));
      Serial.print(" X:");
      Serial.print(gSlopeCellX[i]);
      Serial.print(" Y:");
      Serial.print(gSlopeCellY[i]);
      Serial.print(" DIR:");
      Serial.println((unsigned)gSlopeCellTravelAbsDir[i]);
    }
    return;
  }

  // フォールバック：候補開始セルが取れなかった場合だけ、旧1セル方式を使う。
  // ただし、フォールバック先が現在posX,posYまたは坂出口exitX,exitYなら、
  // 坂出口の平地マスなので左右壁自動BLOCKEDは行わない。
  if (gSlopeMapCellValid && visInRange(gSlopeMapX, gSlopeMapY)) {
    bool isCurrentPos = (gSlopeMapX == posX && gSlopeMapY == posY);
    bool isSlopeExit = (gSlopeMapX == exitX && gSlopeMapY == exitY);
    if (isCurrentPos || isSlopeExit) {
      Serial.print("SLOPE EXIT FALLBACK SKIP SIDE WALL ");
      Serial.print(isSlopeExit ? "EXIT " : "CURRENT ");
      Serial.print("X:");
      Serial.print(gSlopeMapX);
      Serial.print(" Y:");
      Serial.print(gSlopeMapY);
      Serial.print(" DIR:");
      Serial.println((unsigned)gSlopeMapTravelAbsDir);
      return;
    }

    markSlopeSideWallsBlockedForFloor(fromFloor, gSlopeMapX, gSlopeMapY, gSlopeMapTravelAbsDir);
    markSlopeSideWallsBlockedForFloor(toFloor,   gSlopeMapX, gSlopeMapY, gSlopeMapTravelAbsDir);
    markSlopeTransitCellForFloor(fromFloor, gSlopeMapX, gSlopeMapY, gSlopeMapTravelAbsDir);
    markSlopeTransitCellForFloor(toFloor,   gSlopeMapX, gSlopeMapY, gSlopeMapTravelAbsDir);
    Serial.print("SLOPE SIDE WALL FALLBACK F");
    Serial.print((unsigned)(fromFloor + 1));
    Serial.print("/F");
    Serial.print((unsigned)(toFloor + 1));
    Serial.print(" X:");
    Serial.print(gSlopeMapX);
    Serial.print(" Y:");
    Serial.print(gSlopeMapY);
    Serial.print(" DIR:");
    Serial.println((unsigned)gSlopeMapTravelAbsDir);
  }
}

static inline void slopeEstimateFloorLinkEntryCell(uint8_t travelAbsDir, int exitX, int exitY, int &entryX, int &entryY) {
  entryX = exitX;
  entryY = exitY;

  bool foundSlopeCell = false;
  int firstSlopeX = exitX;
  int firstSlopeY = exitY;

  for (uint8_t i = 0; i < gSlopeCellCount; i++) {
    if (!visInRange(gSlopeCellX[i], gSlopeCellY[i])) continue;
    if (gSlopeCellX[i] == exitX && gSlopeCellY[i] == exitY) continue; // 坂出口の平地は入口推定に使わない
    firstSlopeX = gSlopeCellX[i];
    firstSlopeY = gSlopeCellY[i];
    foundSlopeCell = true;
    break;
  }

  if (!foundSlopeCell && gSlopeMapCellValid && visInRange(gSlopeMapX, gSlopeMapY) &&
      !(gSlopeMapX == exitX && gSlopeMapY == exitY)) {
    firstSlopeX = gSlopeMapX;
    firstSlopeY = gSlopeMapY;
    foundSlopeCell = true;
  }

  if (foundSlopeCell) {
    neighborByAbs(oppositeAbsDir(travelAbsDir), firstSlopeX, firstSlopeY, entryX, entryY);
  } else {
    // 最後の保険。坂セルが記録できていない場合だけ、出口の1マス手前を入口扱いにする。
    neighborByAbs(oppositeAbsDir(travelAbsDir), exitX, exitY, entryX, entryY);
  }

  if (!visInRange(entryX, entryY)) {
    entryX = exitX;
    entryY = exitY;
  }
}

// 2026.5.17：フロア切替前に旧フロアへ一時的に入ってしまった坂出口セルを戻す。
// 「1減らす」方式では、坂検知遅れ等で2回以上加算された幽霊訪問が残ることがある。
// 直前の座標更新前バックアップへ復元し、元々本当に訪問済みだった記録は維持する。
static inline void restoreTransientSlopeExitVisitFromFloor(uint8_t floor, int x, int y) {
  if (lastCoordStepBackupRestoreIfMatches(floor, x, y, "SLOPE EXIT")) return;

  // バックアップが取れていない場合だけ、旧方式に近い保険処理。
  // 通常はここへ来ない想定。
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return;

  int mx = x + VIS_OX;
  int my = y + VIS_OY;

  visitCnt[floor][my][mx] = 0;
  zoneFlag[floor][my][mx] = ZONE_UNKNOWN;
  floorConnectorOnlyMap[floor][my][mx] = 0;
  slopeExitIgnoreUnknownMap[floor][my][mx] = 0;
  slopeTransitCellMap[floor][my][mx] = 0;
  slopeDownExitNoSideReadMap[floor][my][mx] = 0;

  Serial.print("CELL RESTORE SLOPE EXIT FALLBACK F");
  Serial.print((unsigned)(floor + 1));
  Serial.print(" X:");
  Serial.print(x);
  Serial.print(" Y:");
  Serial.println(y);
}

static inline bool wallIsOpenBetweenVisitedCells(int x, int y, uint8_t absDir) {
  if (!visInRange(x, y)) return false;
  if (wallStateGet(x, y, absDir) != WALL_STATE_OPEN) return false;

  int nx, ny;
  neighborByAbs(absDir, x, y, nx, ny);
  if (!visInRange(nx, ny)) return false;

  // 両側のマスを訪問済みで、通路がOPENなら、実走行で通過できた可能性が高い。
  // ToFの一瞬の近距離誤値でBLOCKEDへ上書きしない。
  return (visGet(x, y) > 0 && visGet(nx, ny) > 0);
}

static void rebuildXY_NumberAll() {
  memset(XY_Number, 0xFF, sizeof(XY_Number));
  if (!visInRange(0, 0)) return;

  xyNumberSetFloor(FLOOR_1ST, 0, 0, 0);

  int head = 0;
  int tail = 0;
  xyQueueF[tail] = FLOOR_1ST;
  xyQueueX[tail] = 0;
  xyQueueY[tail] = 0;
  tail++;

  while (head < tail) {
    uint8_t cf = xyQueueF[head];
    int cx = (int)xyQueueX[head];
    int cy = (int)xyQueueY[head];
    head++;

    uint16_t curNo = xyNumberGetFloor(cf, cx, cy);
    if (curNo == XY_NUMBER_INF || curNo >= (XY_NUMBER_INF - 1)) continue;

    // フロアリンクは坂入口セル⇔坂出口セルを接続する。XY_Numberでは従来どおり0コスト継承。
    uint8_t linkMask = floorLinkMaskGet(cf, cx, cy);
    for (uint8_t nf = 0; nf < FLOOR_COUNT; nf++) {
      if ((linkMask & (uint8_t)(1u << nf)) == 0) continue;
      int tx, ty;
      floorLinkTargetGet(cf, cx, cy, nf, tx, ty);
      if (!visInRange(tx, ty)) continue;
      if (curNo < xyNumberGetFloor(nf, tx, ty)) {
        xyNumberSetFloor(nf, tx, ty, curNo);
        if (tail < VIS_QUEUE_COUNT) {
          xyQueueF[tail] = nf;
          xyQueueX[tail] = (int16_t)tx;
          xyQueueY[tail] = (int16_t)ty;
          tail++;
        }
      }
    }

    for (uint8_t absDir = 0; absDir < 4; absDir++) {
      if (wallStateGetFloor(cf, cx, cy, absDir) != WALL_STATE_OPEN) continue; // 壁なし確定だけ使う

      int nx, ny;
      neighborByAbs(absDir, cx, cy, nx, ny);
      if (!visInRange(nx, ny)) continue;

      uint16_t cand = (uint16_t)(curNo + 1);
      if (cand < xyNumberGetFloor(cf, nx, ny)) {
        xyNumberSetFloor(cf, nx, ny, cand);
        if (tail < VIS_QUEUE_COUNT) {
          xyQueueF[tail] = cf;
          xyQueueX[tail] = (int16_t)nx;
          xyQueueY[tail] = (int16_t)ny;
          tail++;
        }
      }
    }
  }
}

static inline void refreshXY_NumberAfterForwardTraverse() {
  int prevX, prevY;
  neighborByAbs(oppositeAbsDir(direction), posX, posY, prevX, prevY);
  if (!visInRange(prevX, prevY) || !visInRange(posX, posY)) return;

  uint16_t prevNo = xyNumberGet(prevX, prevY);
  uint16_t nextNo = xyNumberGet(posX, posY);

  bool needRebuild = false;
  if (prevNo == XY_NUMBER_INF || nextNo == XY_NUMBER_INF) {
    needRebuild = true;
  } else {
    int diff = (int)nextNo - (int)prevNo;
    if (diff != 1 && diff != -1) needRebuild = true;
  }

  if (needRebuild) rebuildXY_NumberAll();
}

static void rebuildRed_NumberAll() {
  memset(Red_Number, 0xFF, sizeof(Red_Number));

  int head = 0;
  int tail = 0;

  // 記録済みの赤入口をすべてゴール(0)として登録する。
  for (uint8_t floor = 0; floor < FLOOR_COUNT; floor++) {
    for (int my = 0; my < VIS_H; my++) {
      for (int mx = 0; mx < VIS_W; mx++) {
        if (!redFlag[floor][my][mx]) continue;
        int rx = mx - VIS_OX;
        int ry = my - VIS_OY;
        redNumberSetFloor(floor, rx, ry, 0);
        if (tail < VIS_QUEUE_COUNT) {
          xyQueueF[tail] = floor;
          xyQueueX[tail] = (int16_t)rx;
          xyQueueY[tail] = (int16_t)ry;
          tail++;
        }
      }
    }
  }

  while (head < tail) {
    uint8_t cf = xyQueueF[head];
    int cx = (int)xyQueueX[head];
    int cy = (int)xyQueueY[head];
    head++;

    uint16_t curNo = redNumberGetFloor(cf, cx, cy);
    if (curNo == RED_NUMBER_INF || curNo >= (RED_NUMBER_INF - 1)) continue;

    // フロアリンクは坂入口セル⇔坂出口セルを接続する。Red_Numberでは従来どおり0コスト継承。
    uint8_t linkMask = floorLinkMaskGet(cf, cx, cy);
    for (uint8_t nf = 0; nf < FLOOR_COUNT; nf++) {
      if ((linkMask & (uint8_t)(1u << nf)) == 0) continue;
      int tx, ty;
      floorLinkTargetGet(cf, cx, cy, nf, tx, ty);
      if (!visInRange(tx, ty)) continue;
      if (curNo < redNumberGetFloor(nf, tx, ty)) {
        redNumberSetFloor(nf, tx, ty, curNo);
        if (tail < VIS_QUEUE_COUNT) {
          xyQueueF[tail] = nf;
          xyQueueX[tail] = (int16_t)tx;
          xyQueueY[tail] = (int16_t)ty;
          tail++;
        }
      }
    }

    for (uint8_t absDir = 0; absDir < 4; absDir++) {
      // 赤入口ターゲットBFSは、確定した開通路だけを使う。
      // 赤入口検知時に、外側セル↔赤入口の辺はOPENとして記録する。
      if (wallStateGetFloor(cf, cx, cy, absDir) != WALL_STATE_OPEN) continue;

      int nx, ny;
      neighborByAbs(absDir, cx, cy, nx, ny);
      if (!visInRange(nx, ny)) continue;

      uint16_t cand = (uint16_t)(curNo + 1);
      if (cand < redNumberGetFloor(cf, nx, ny)) {
        redNumberSetFloor(cf, nx, ny, cand);
        if (tail < VIS_QUEUE_COUNT) {
          xyQueueF[tail] = cf;
          xyQueueX[tail] = (int16_t)nx;
          xyQueueY[tail] = (int16_t)ny;
          tail++;
        }
      }
    }
  }
}

// フロアリンクを作ってから現在フロアを切り替える。壁/色/訪問回数はコピーしない。
static void showFloorFullWarning() {
  slopeSetStatus("FLOOR FULL", 1500);
  drawHudScreen();
  Serial.println("FLOOR FULL: cannot allocate new floor");
}

static bool floorSwitchAfterSlope(uint8_t slopeDir) {
  if (slopeDir != 1 && slopeDir != 2) return false;
  if (!floorIndexInRange(currentFloor)) return false;
  if (!visInRange(posX, posY)) return false;
  if (!floorAssigned[currentFloor]) return false;

  int8_t fromHeight = floorHeight[currentFloor];
  if (fromHeight == FLOOR_HEIGHT_UNKNOWN) return false;

  int8_t targetHeight = (int8_t)(fromHeight + ((slopeDir == 1) ? 1 : -1));
  int8_t targetFloor = -1;

  for (uint8_t f = 0; f < FLOOR_COUNT; f++) {
    if (floorAssigned[f] && floorHeight[f] == targetHeight) {
      targetFloor = (int8_t)f;
      break;
    }
  }

  if (targetFloor < 0) {
    for (uint8_t f = 0; f < FLOOR_COUNT; f++) {
      if (!floorAssigned[f]) {
        floorAssigned[f] = true;
        floorHeight[f] = targetHeight;
        targetFloor = (int8_t)f;
        break;
      }
    }
  }

  if (targetFloor < 0) {
    showFloorFullWarning();
    return false;
  }

  uint8_t fromFloor = currentFloor;
  uint8_t toFloor = (uint8_t)targetFloor;
  if (toFloor == fromFloor) return false;

  uint8_t slopeTravelAbsDir = gFloorSwitchOverrideActive ? (gFloorSwitchOverrideTravelAbsDir & 3) : (direction & 3);
  int exitX = gFloorSwitchOverrideActive ? gFloorSwitchOverrideExitX : posX;
  int exitY = gFloorSwitchOverrideActive ? gFloorSwitchOverrideExitY : posY;
  int entryX = posX;
  int entryY = posY;
  slopeEstimateFloorLinkEntryCell(slopeTravelAbsDir, exitX, exitY, entryX, entryY);

  uint16_t oldXYNo = xyNumberGetFloor(fromFloor, entryX, entryY);
  uint16_t oldRedNo = redNumberGetFloor(fromFloor, entryX, entryY);

  bool pendingCurrentMigrated = terrainPendingCoordContains(fromFloor, posX, posY) ||
                                (gFloorSwitchOverrideActive && exitX == posX && exitY == posY);

  // 2026.5.23：PENDING中に旧フロアへ仮記録された座標を、新フロア側へ先に移す。
  // このあと旧フロア側を復元するため、移す処理は復元より先に行う。
  if (gFloorSwitchOverrideActive || gPendingFloorCoordCount > 0) {
    terrainPendingCoordApplyToNewFloor(toFloor, exitX, exitY, slopeTravelAbsDir);
  }

  // 2026.5.17：
  // 坂出口の平地セルは新フロア側の通常セルとして扱う。
  // 旧フロア側に一時的に入った訪問カウントだけ戻し、F1 X5,Y3のような幽霊セルを作らない。
  restoreTransientSlopeExitVisitFromFloor(fromFloor, exitX, exitY);
  if (gFloorSwitchOverrideActive && gFloorSwitchRestoreCurrentOldCell && !(exitX == posX && exitY == posY)) {
    // 坂上で90°回転後、隣座標へ進んでからRAMP確定した場合、
    // その隣座標が旧フロアへ一時記録されているので復元する。
    lastCoordStepBackupRestoreIfMatches(fromFloor, posX, posY, "SLOPE DELAY CURRENT");
  }
  terrainPendingCoordRestoreOldFloor("PENDING OLD RESTORE");

  // 2026.5.17：
  // フロアリンクは同じX,Yではなく、坂入口セルと坂出口セルを接続する。
  // 例：F1 X2,Y3 ⇔ F2 X5,Y3
  floorLinkSetBothWithDirBetween(fromFloor, entryX, entryY, toFloor, exitX, exitY, slopeTravelAbsDir);

  floorConnectorOnlySetFloor(toFloor, exitX, exitY, false);
  gConnectorIgnoreDebugUntilMs = millis() + 2500;
  gConnectorIgnoreFloor = fromFloor;
  gConnectorIgnoreX = entryX;
  gConnectorIgnoreY = entryY;

  // 坂・階段通路は左右へ分岐しない前提で、坂セルだけ左右壁を確定する。
  // 2026.5.17：坂が複数マス続く場合に備えて、坂中に記録した複数セルへ適用する。
  // 坂手前/坂直後の平地には入れない。前後は実走行/ToF/両タッチで確定させる。
  applySlopeSideWallCellsForFloors(fromFloor, toFloor, exitX, exitY);

  // 2026.5.23：坂出口マスは進路選択で通常マスとして扱う。
  // 左右はUnknownへ戻し、SLセル扱いを解除する。後ろUnknown除外はこの後で再設定する。
  slopeExitClearSideWallsAndTransitForFloor(fromFloor, exitX, exitY, slopeTravelAbsDir, "FROM");
  slopeExitClearSideWallsAndTransitForFloor(toFloor,   exitX, exitY, slopeTravelAbsDir, "TO");

  currentFloor = toFloor;

  // 新フロアの現在地を訪問済みにする。
  // PENDING中に移した座標なら、ここで二重加算しない。
  if (!pendingCurrentMigrated) {
    visInc(posX, posY);
  }
  markCurrentCellZone();

  // 2026.5.23：坂直後の平地マスは中央ズレが出やすい。
  // ただし進路選択では左右UNKNOWNを探索候補に戻す。
  // 後ろ方向だけは坂を戻る方向になりやすいので、UNKNOWN確認候補から外す。
  slopeExitIgnoreUnknownSetFloor(toFloor, exitX, exitY, slopeTravelAbsDir);
  // 2026.5.17：下り坂直後の平地マスは、左右ToFの近距離誤値で壁ありを作りやすい。
  // 既にその座標にある壁情報は残し、このマスの左右方向だけ新しい左右壁投票をしない。
  if (slopeDir == 2) {
    slopeDownExitNoSideReadSetFloor(toFloor, exitX, exitY, slopeTravelAbsDir);
  }

  if (oldXYNo != XY_NUMBER_INF && xyNumberGet(posX, posY) == XY_NUMBER_INF) xyNumberSet(posX, posY, oldXYNo);
  if (oldRedNo != RED_NUMBER_INF && redNumberGet(posX, posY) == RED_NUMBER_INF) redNumberSet(posX, posY, oldRedNo);

  rebuildXY_NumberAll();
  rebuildRed_NumberAll();

  Serial.print("FLOOR SWITCH ");
  Serial.print(floorName(fromFloor));
  Serial.print(" -> ");
  Serial.print(floorName(currentFloor));
  Serial.print(" slope=");
  Serial.print((slopeDir == 1) ? "UP" : "DOWN");
  Serial.print(" h=");
  Serial.print((int)targetHeight);
  Serial.print(" entry=");
  Serial.print(entryX);
  Serial.print(',');
  Serial.print(entryY);
  Serial.print(" exit=");
  Serial.print(exitX);
  Serial.print(',');
  Serial.print(exitY);
  Serial.print(" link F");
  Serial.print((unsigned)(fromFloor + 1));
  Serial.print("->F");
  Serial.println((unsigned)(toFloor + 1));

  return true;
}

// 帰還関連
bool homeArmed = false;
bool homePending = false;
bool returnMode = false;
bool missionComplete = false;
bool returnNotifiedToSub = false;
bool inRedZone = false;        // 赤入口に到達後、レッドゾーン攻略中ならtrue
bool redExitMode = false;      // レッドゾーン探索完了後、赤入口へ戻って脱出するモード
bool redExitLeavePending = false; // 次の30cm前進で赤入口からノーマル側へ出る予約

// ===== 複数赤入口対応 M_41_17：赤脱出後の専用ローカライズ =====
// 赤入口から出た直後に即RETURNへ入らず、最大3マスだけ一時観測をためる。
// 赤入口情報(normalSideAbsDir)を起点候補にし、SD LOAD後ローカライズ風に保存済みノーマルマップと照合する。
// このモード中に読んだ壁情報は、本物マップへ書き込まない。
bool redNormalConfirmMode = false;
uint8_t redNormalConfirmStepCount = 0;
const uint8_t RED_NORMAL_CONFIRM_MAX_STEPS = 3;
uint8_t redNormalConfirmStartFloor = 0;
int16_t redNormalConfirmStartX = 0;
int16_t redNormalConfirmStartY = 0;
uint8_t redNormalConfirmExitAbsDir = 0;

bool frontierTargetMode = false;  // 現在地に未探索方向が無い時、最寄りフロンティアへBFS移動するモード
uint8_t frontierTargetZone = ZONE_UNKNOWN;
// 2026.5.17：Frontier_Targetが同じ場所を踏み続けた場合、その試合中は拡張左手法へフォールバックする。
bool gFrontierFallbackExtLH = false;
const uint16_t FRONTIER_FALLBACK_VISIT_LIMIT = 5;

const uint32_t RED_ENTRY_START_DELAY_MS = 300000UL; // 保険：5分経過してもレッドゾーン未突入なら赤入口へ向かう
const uint32_t RETURN_START_DELAY_MS    = 420000UL; // 保険：7分経過で強制帰還

static inline bool isOrigin() { return (currentFloor == FLOOR_1ST && posX == 0 && posY == 0); }
static inline char dirChar(uint8_t d) {
  switch (d & 3) {
    case 0: return 'N';
    case 1: return 'E';
    case 2: return 'S';
    default: return 'W';
  }
}

static inline uint8_t zoneGetFloor(uint8_t floor, int x, int y) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return ZONE_UNKNOWN;
  return zoneFlag[floor][y + VIS_OY][x + VIS_OX];
}

static inline uint8_t zoneGet(int x, int y) {
  return zoneGetFloor(currentFloor, x, y);
}

static inline void zoneSetFloor(uint8_t floor, int x, int y, uint8_t v) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return;
  zoneFlag[floor][y + VIS_OY][x + VIS_OX] = v;
}

static inline void zoneSet(int x, int y, uint8_t v) {
  zoneSetFloor(currentFloor, x, y, v);
}

static inline void markCurrentCellZone() {
  uint8_t z = inRedZone ? ZONE_RED : ZONE_NORMAL;

  // 赤入口タイルそのものはレッドゾーン側として扱う。
  if (redGet(posX, posY)) z = ZONE_RED;

  zoneSet(posX, posY, z);
}

static inline bool isFrontierCellForZoneFloor(uint8_t floor, int x, int y, uint8_t zone) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return false;

  if (floorConnectorOnlyGetFloor(floor, x, y)) return false;
  // 2026.5.17：SLセル（坂そのもののセル）は、UNKNOWNが残っても未探索フロンティア扱いしない。
  if (slopeTransitCellGetFloor(floor, x, y)) return false;
  uint16_t cellVisitCount = visGetFloor(floor, x, y);
  if (cellVisitCount == 0) return false;

  // 2026.5.23：安全弁。3回以上訪問済みのマスは、UNKNOWN壁方向だけでなく、
  // OPEN未訪問が残っていてもフロンティア未探索ターゲットから除外する。
  // 壁情報・訪問回数自体は変更せず、遠方からBFSで追い続ける対象からだけ外す。
  if (cellVisitCount >= FRONTIER_IGNORE_VISIT_COUNT) return false;

  if (zoneGetFloor(floor, x, y) != zone) return false;

  for (uint8_t absDir = 0; absDir < 4; absDir++) {
    uint8_t st = wallStateGetFloor(floor, x, y, absDir);
    if (st == WALL_STATE_BLOCKED) continue;

    int nx, ny;
    neighborByAbs(absDir, x, y, nx, ny);
    if (!visInRange(nx, ny)) continue;

    if (zone == ZONE_NORMAL) {
      if (redGetFloor(floor, nx, ny)) continue;
      if (zoneGetFloor(floor, nx, ny) == ZONE_RED) continue;
    }

    if (zone == ZONE_RED) {
      if (zoneGetFloor(floor, nx, ny) == ZONE_NORMAL) continue;
    }

    if (st == WALL_STATE_UNKNOWN) {
      // 坂直後セルでは、後ろ方向UNKNOWNだけRETURN阻害フロンティアにしない。
      // 左右UNKNOWNは探索候補に戻すため、ここで除外されるのは基本的に後ろ方向だけ。
      if (slopeExitIgnoreUnknownDirGetFloor(floor, x, y, absDir)) continue;

      return true;
    }

    if (st == WALL_STATE_OPEN && visGetFloor(floor, nx, ny) == 0) return true;
  }
  return false;
}

static inline bool isFrontierCellForZone(int x, int y, uint8_t zone) {
  return isFrontierCellForZoneFloor(currentFloor, x, y, zone);
}

static bool hasFrontierInZone(uint8_t zone) {
  for (uint8_t floor = 0; floor < FLOOR_COUNT; floor++) {
    if (!floorAssigned[floor]) continue;
    for (int my = 0; my < VIS_H; my++) {
      for (int mx = 0; mx < VIS_W; mx++) {
        int x = mx - VIS_OX;
        int y = my - VIS_OY;
        if (isFrontierCellForZoneFloor(floor, x, y, zone)) return true;
      }
    }
  }
  return false;
}

static bool hasFrontierInNormalZone() {
  return hasFrontierInZone(ZONE_NORMAL);
}

static bool hasFrontierInRedZone() {
  return hasFrontierInZone(ZONE_RED);
}

static bool findFirstFrontierInZone(uint8_t zone, uint8_t &outFloor, int &outX, int &outY) {
  for (uint8_t floor = 0; floor < FLOOR_COUNT; floor++) {
    if (!floorAssigned[floor]) continue;
    for (int my = 0; my < VIS_H; my++) {
      for (int mx = 0; mx < VIS_W; mx++) {
        int x = mx - VIS_OX;
        int y = my - VIS_OY;
        if (isFrontierCellForZoneFloor(floor, x, y, zone)) {
          outFloor = floor;
          outX = x;
          outY = y;
          return true;
        }
      }
    }
  }
  return false;
}

static void reportFrontierBlockingReturn(uint8_t zone, const char* tag) {
  static uint32_t lastReportMs = 0;
  static uint8_t lastFloor = 255;
  static int lastX = 9999;
  static int lastY = 9999;

  uint8_t f = 0;
  int x = 0, y = 0;
  if (!findFirstFrontierInZone(zone, f, x, y)) return;

  uint32_t now = millis();
  if (f == lastFloor && x == lastX && y == lastY && (uint32_t)(now - lastReportMs) < 1000) return;

  lastReportMs = now;
  lastFloor = f;
  lastX = x;
  lastY = y;

  gReturnBlockDebugUntilMs = now + 2500;
  gReturnBlockFloor = f;
  gReturnBlockX = x;
  gReturnBlockY = y;
  gReturnBlockDir = 255;
  for (uint8_t absDir = 0; absDir < 4; absDir++) {
    uint8_t st = wallStateGetFloor(f, x, y, absDir);
    if (st == WALL_STATE_UNKNOWN) {
      if (slopeExitIgnoreUnknownDirGetFloor(f, x, y, absDir)) continue;
      if (visGetFloor(f, x, y) >= FRONTIER_IGNORE_VISIT_COUNT) continue;
      gReturnBlockDir = absDir;
      break;
    }
    if (st == WALL_STATE_OPEN) {
      int nx, ny;
      neighborByAbs(absDir, x, y, nx, ny);
      if (visInRange(nx, ny) && visGetFloor(f, nx, ny) == 0) { gReturnBlockDir = absDir; break; }
    }
  }

  Serial.print(tag ? tag : "FRONTIER");
  Serial.print(" CUR F");
  Serial.print((unsigned)(currentFloor + 1));
  Serial.print(" X:");
  Serial.print(posX);
  Serial.print(" Y:");
  Serial.print(posY);
  Serial.print(" -> BLK F");
  Serial.print((unsigned)(f + 1));
  Serial.print(" X:");
  Serial.print(x);
  Serial.print(" Y:");
  Serial.print(y);
  Serial.print(" DIR:");
  if (gReturnBlockDir <= 3) Serial.print(dirChar(gReturnBlockDir));
  else Serial.print('-');
  Serial.print(" CUR_FN:");
  Serial.print(frontierNumberGet(posX, posY));
  Serial.print(" XY:");
  Serial.println(xyNumberGet(posX, posY));
}

static inline bool isCellUsableForFrontierBfsFloor(uint8_t floor, int x, int y, uint8_t zone) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return false;
  if (visGetFloor(floor, x, y) == 0) return false;
  if (zoneGetFloor(floor, x, y) != zone) return false;

  if (zone == ZONE_NORMAL) {
    if (redGetFloor(floor, x, y)) return false;
  }
  return true;
}

static inline bool isCellUsableForFrontierBfs(int x, int y, uint8_t zone) {
  return isCellUsableForFrontierBfsFloor(currentFloor, x, y, zone);
}

static void rebuildFrontier_NumberAll(uint8_t zone) {
  memset(Frontier_Number, 0xFF, sizeof(Frontier_Number));
  if (zone != ZONE_NORMAL && zone != ZONE_RED) return;

  int head = 0;
  int tail = 0;

  for (uint8_t floor = 0; floor < FLOOR_COUNT; floor++) {
    if (!floorAssigned[floor]) continue;
    for (int my = 0; my < VIS_H; my++) {
      for (int mx = 0; mx < VIS_W; mx++) {
        int x = mx - VIS_OX;
        int y = my - VIS_OY;
        if (!isFrontierCellForZoneFloor(floor, x, y, zone)) continue;

        frontierNumberSetFloor(floor, x, y, 0);
        if (tail < VIS_QUEUE_COUNT) {
          xyQueueF[tail] = floor;
          xyQueueX[tail] = (int16_t)x;
          xyQueueY[tail] = (int16_t)y;
          tail++;
        }
      }
    }
  }

  while (head < tail) {
    uint8_t cf = xyQueueF[head];
    int cx = (int)xyQueueX[head];
    int cy = (int)xyQueueY[head];
    head++;

    uint16_t curNo = frontierNumberGetFloor(cf, cx, cy);
    if (curNo == FRONTIER_NUMBER_INF || curNo >= (FRONTIER_NUMBER_INF - 1)) continue;

    uint8_t linkMask = floorLinkMaskGet(cf, cx, cy);
    for (uint8_t nf = 0; nf < FLOOR_COUNT; nf++) {
      if ((linkMask & (uint8_t)(1u << nf)) == 0) continue;
      int tx, ty;
      floorLinkTargetGet(cf, cx, cy, nf, tx, ty);
      if (!isCellUsableForFrontierBfsFloor(nf, tx, ty, zone)) continue;
      // 2026.5.17：Frontier_Numberではフロアリンクも1歩として扱う。
      // 坂入口セル⇔坂出口セルを1歩でつなぎ、別フロア未探索へ向かえるようにする。
      uint16_t cand = (uint16_t)(curNo + 1);
      if (cand < frontierNumberGetFloor(nf, tx, ty)) {
        frontierNumberSetFloor(nf, tx, ty, cand);
        if (tail < VIS_QUEUE_COUNT) {
          xyQueueF[tail] = nf;
          xyQueueX[tail] = (int16_t)tx;
          xyQueueY[tail] = (int16_t)ty;
          tail++;
        }
      }
    }

    for (uint8_t absDir = 0; absDir < 4; absDir++) {
      if (wallStateGetFloor(cf, cx, cy, absDir) != WALL_STATE_OPEN) continue;

      int nx, ny;
      neighborByAbs(absDir, cx, cy, nx, ny);
      if (!isCellUsableForFrontierBfsFloor(cf, nx, ny, zone)) continue;

      uint16_t cand = (uint16_t)(curNo + 1);
      if (cand < frontierNumberGetFloor(cf, nx, ny)) {
        frontierNumberSetFloor(cf, nx, ny, cand);
        if (tail < VIS_QUEUE_COUNT) {
          xyQueueF[tail] = cf;
          xyQueueX[tail] = (int16_t)nx;
          xyQueueY[tail] = (int16_t)ny;
          tail++;
        }
      }
    }
  }
}

static inline void stepForwardOneTile() {
  int nx = posX;
  int ny = posY;
  switch (direction & 3) {
    case 0: ny += 1; break;
    case 1: nx += 1; break;
    case 2: ny -= 1; break;
    default: nx -= 1; break;
  }

  // 坂検知時にrollbackAlreadyUpdatedで戻す可能性があるため、
  // 座標更新前のtargetセル状態を保存しておく。
  lastCoordStepBackupSave(currentFloor, nx, ny);

  const bool isRedNcUncertainStep = (redExitLeavePending || redNormalConfirmMode);

  posX = nx;
  posY = ny;

  // 赤脱出後のノーマル確認中は、座標・方角が未確定なので本物マップの訪問回数も増やさない。
  // 候補が1つに絞れた時点で、確定座標へ補正してから必要最小限だけ反映する。
  if (!isRedNcUncertainStep) {
    if (redRecoverySearchMode) redRecoveryVisitInc(posX, posY);
    else                       visInc(posX, posY);
  }

  if (redExitLeavePending) {
    // 2026.5.31 M_41_17：赤入口から出た直後に即RETURNへ入らない。
    // 赤入口normalSide起点の専用ローカライズで、最大3マスだけ一時観測照合する。
    redExitLeavePending = false;
    startRedNormalConfirmMode("LEAVE_RED_TILE");
  } else if (redNormalConfirmMode) {
    redNormalConfirmAdvanceCandidatesForward();
  } else {
    if (!redRecoverySearchMode) markCurrentCellZone();
  }

  if (!isRedNcUncertainStep) {
    // 2026.5.23：TR分類待ちで旧フロアへ入った仮座標を覚える。
    // RAMP確定時に新フロアへ移し、旧フロア側の幽霊未探索を消す。
    terrainPendingCoordRecordIfActive("coord_step");

    // 2026.5.23：地形観察中に曲がって保留したRAMPは、次座標へ正常移動できた時点で確定する。
    terrainClassOnCoordinateStepCompleted();
  }
}

// =====================
// ===== OLED (Wire2) =====
// =====================
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
const uint8_t OLED_ADDR = 0x3C;
Adafruit_SSD1306 oled(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire2, OLED_RESET); // OLED: SDA=25, SCL=24 (Wire2)

// =====================
// ===== BNO08X (Wire1) =====
// =====================
BNO080 myIMU;
const byte BNO08X_ADDR = 0x4A;
const int PIN_INT = 15;
const int PIN_RST = 14;

float yawOffset = 0.0f;
bool  isYawTared  = false;
float yawDeg    = 0.0f;

// 2026.5.16：坂・階段検知用Pitch
// 登りで表示がDOWNになる場合は PITCH_SIGN を -1 に変更する。
// 2026.5.16 実機では getRoll() が前後傾き（ピッチ）として出るため、USE_ROLL_AS_PITCH=true で使用する。
float pitchOffset = 0.0f;
bool  isPitchTared = false;
float pitchDeg = 0.0f;
const int  PITCH_SIGN = +1;
const bool USE_ROLL_AS_PITCH = true;

static inline float normalize180(float deg) {
  while (deg > 180.0f) deg -= 360.0f;
  while (deg < -180.0f) deg += 360.0f;
  return deg;
}
static inline void imuUpdate() {
  if (myIMU.dataAvailable()) {
    float currentYaw = myIMU.getYaw() * 180.0f / PI;
    float currentPitch = (USE_ROLL_AS_PITCH ? myIMU.getRoll() : myIMU.getPitch()) * 180.0f / PI;

    if (!isYawTared) {
      yawOffset = currentYaw;
      isYawTared = true;
    }
    if (!isPitchTared) {
      pitchOffset = currentPitch;
      isPitchTared = true;
    }

    yawDeg = normalize180(currentYaw - yawOffset);
    pitchDeg = (currentPitch - pitchOffset) * (float)PITCH_SIGN;
  }
}

static inline float chooseNearestAbs090180(float y) {
  const float cand[5] = {-180.0f, -90.0f, 0.0f, 90.0f, 180.0f};
  float best = cand[0];
  float bestErr = 1e9f;
  for (int i = 0; i < 5; i++) {
    float e = fabsf(normalize180(y - cand[i]));
    if (e < bestErr) { bestErr = e; best = cand[i]; }
  }
  return best;
}

// ★両タッチ後のスナップ先：0, +90, +180(=-180), -90
static inline float chooseNearestCardinalYaw(float y) {
  const float cand[4] = {0.0f, 90.0f, 180.0f, -90.0f};
  float best = cand[0];
  float bestErr = 1e9f;
  for (int i = 0; i < 4; i++) {
    float e = fabsf(normalize180(y - cand[i]));
    if (e < bestErr) { bestErr = e; best = cand[i]; }
  }
  return best;
}

// =====================
// ===== TOF（SUB5 + MAIN1）=====
// =====================
VL53L0X tofMain;
uint16_t mainMm = 8190;
uint16_t distMm[6] = {8190,8190,8190,8190,8190,8190}; // S0..S4=SUB, S5=MAIN

static char rxBuf[96];
static uint8_t rxLen = 0;

static bool parseFrame5(const char* s, uint16_t out5[5]) {
  const char* p1 = strchr(s, '<');
  const char* p2 = strchr(s, '>');
  if (!p1 || !p2 || p2 <= p1) return false;
  char tmp[64];
  size_t len = (size_t)(p2 - (p1 + 1));
  if (len >= sizeof(tmp)) return false;
  memcpy(tmp, p1 + 1, len);
  tmp[len] = '\0';
  char* saveptr = nullptr;
  char* token = strtok_r(tmp, ",", &saveptr);
  int idx = 0;
  while (token && idx < 5) {
    out5[idx] = (uint16_t)strtoul(token, nullptr, 10);
    idx++;
    token = strtok_r(nullptr, ",", &saveptr);
  }
  return (idx == 5);
}

// =====================
// ===== モータ/エンコーダ =====
// =====================
const float PULSES_PER_CM = 154.2f;

const long TARGET_30CM_PULSES = (long)(PULSES_PER_CM * 29.0f + 0.5f);
const long TARGET_25CM_PULSES = (long)(PULSES_PER_CM * 25.0f + 0.5f);
const long TARGET_20CM_PULSES = (long)(PULSES_PER_CM * 20.0f + 0.5f);
const long TARGET_18CM_PULSES = (long)(PULSES_PER_CM * 18.0f + 0.5f);
const long TARGET_15CM_PULSES = (long)(PULSES_PER_CM * 15.0f + 0.5f);
const long TARGET_13CM_PULSES = (long)(PULSES_PER_CM * 13.0f + 0.5f);
const long TARGET_12CM_PULSES = (long)(PULSES_PER_CM * 12.0f + 0.5f);
const long TARGET_11CM_PULSES = (long)(PULSES_PER_CM * 11.0f + 0.5f);
const long TARGET_10CM_PULSES = (long)(PULSES_PER_CM * 10.0f + 0.5f);
const long TARGET_9CM_PULSES  =  (long)(PULSES_PER_CM * 9.0f + 0.5f);
const long TARGET_8CM_PULSES  =  (long)(PULSES_PER_CM * 8.0f + 0.5f);
const long TARGET_7CM_PULSES   = (long)(PULSES_PER_CM * 7.0f + 0.5f);
const long TARGET_6CM_PULSES   = (long)(PULSES_PER_CM * 6.0f + 0.5f);
const long TARGET_5CM_PULSES   = (long)(PULSES_PER_CM * 5.0f + 0.5f);
const long TARGET_4CM_PULSES   = (long)(PULSES_PER_CM * 4.0f + 0.5f);
const long TARGET_3_5CM_PULSES = (long)(PULSES_PER_CM * 3.5f + 0.5f);
const long TARGET_3CM_PULSES   = (long)(PULSES_PER_CM * 3.0f + 0.5f);
const long TARGET_2_5CM_PULSES = (long)(PULSES_PER_CM * 2.5f + 0.5f);
const long TARGET_2CM_PULSES   = (long)(PULSES_PER_CM * 2.0f + 0.5f);
const long TARGET_1CM_PULSES   = (long)(PULSES_PER_CM * 1.0f + 0.5f);

// =====================
// ===== 坂・階段検知＋前進地形通過モード（2026.5.20）=====
// =====================
const bool ENABLE_SLOPE_STAIR_DETECT = true;
const float SLOPE_UP_CANDIDATE_PITCH_DEG = 3.0f;   // UP?開始：+3°以上
const float SLOPE_UP_CANCEL_PITCH_DEG = 3.0f;      // UP?候補中：+3°未満で候補解除
const float SLOPE_UP_CONFIRM_PITCH_DEG = 8.0f;     // UP確定用ピーク：+8°以上
const float SLOPE_DOWN_PITCH_DEG = -10.0f;
const float SLOPE_RELEASE_PITCH_DEG = 5.0f;        // 平地復帰はabs(Pitch)<5°を使う
const uint32_t SLOPE_UP_LOW_HOLD_MS = 0;           // 旧+5°0.8秒条件は廃止（互換用に残す）
const uint32_t SLOPE_UP_HIGH_HOLD_MS = 100;        // +8°以上が0.1秒継続
const uint32_t SLOPE_DOWN_DETECT_HOLD_MS = 800;
const uint32_t SLOPE_RELEASE_HOLD_MS = 200;        // abs(Pitch)<5°が0.2秒続いたら登り切り/下り切り判定
const uint32_t SLOPE_BUMP_MAX_HOLD_MS = 500;
const uint32_t SLOPE_BUMP_DISPLAY_MS = 1500;
const long SLOPE_UP_MIN_DETECT_PULSES = TARGET_5CM_PULSES;       // 旧互換用：現在のUP確定本体はSLOPE_UP_SUSTAIN_CONFIRM_PULSESを使う
const long SLOPE_UP_SUSTAIN_CONFIRM_PULSES = TARGET_8CM_PULSES;  // UP?開始から8cm以上、+8°以上維持で坂/階段確定
const float SLOPE_UP_DROP_TO_BUMP_PITCH_DEG = 5.0f;              // UP?候補中に+5°未満へ下がったら坂候補をリセットしてバンプ判定
const long SLOPE_UP_MAX_CANDIDATE_PULSES = TARGET_15CM_PULSES;  // 15cm進んでも+8°維持なしならBUMP扱い
const long SLOPE_DOWN_MIN_DETECT_PULSES = TARGET_5CM_PULSES;
const long TERRAIN_PASS_AFTER_FLAT_CLEARANCE_PULSES = TARGET_10CM_PULSES; // 登り切り/下り切り判定後、中央寄せであと10cm前進
const float SLOPE_UP_EXTRA_HIGH_PITCH_DEG = 20.0f;
const long SLOPE_UP_EXTRA_LOW_PULSES = TARGET_5CM_PULSES;   // UP検知後の前進距離補正：+5cm
const long SLOPE_UP_EXTRA_HIGH_PULSES = TARGET_10CM_PULSES; // 20°以上:+10cm

// 2026.5.23：通常直進中のバンプ乗り越え距離補正（正方向Pitchだけ使い、マイナスPitchは無視）
const float BUMP_COMP_LOW_PITCH_DEG    = 5.0f;
const float BUMP_COMP_QUICK_LOW_PITCH_DEG = 4.0f; // 短時間バンプ救済：+5°未満でも+4°以上ならLOW扱い
const float BUMP_COMP_MEDIUM_PITCH_DEG = 8.0f;
const float BUMP_COMP_HIGH_PITCH_DEG   = 10.0f;
const long BUMP_COMP_LOW_PULSES    = TARGET_2CM_PULSES;
const long BUMP_COMP_MEDIUM_PULSES = TARGET_3_5CM_PULSES;
const long BUMP_COMP_HIGH_PULSES   = TARGET_5CM_PULSES;
const uint32_t BUMP_COMP_DISPLAY_MS = 3000;

// 2026.5.23：階段/坂の地形分類。STAIR/UNKはフロア維持、RAMPだけフロア切替する。
// STAIR確定後も直線上4マス以内は観察を継続し、追加のUP/DOWNを同じ階段として扱う。
const float TERRAIN_CLASS_UP_PITCH_DEG = 8.0f;
const float TERRAIN_CLASS_DOWN_PITCH_DEG = -8.0f;
const uint8_t TERRAIN_CLASS_MAX_STRAIGHT_CELLS = 4;
const uint32_t TERRAIN_CLASS_DISPLAY_MS = 5000;

static char gSlopeStatus[12] = "FLAT"; // FLAT / UP? / LOW / MEDIUM / HIGH / DOWN? / DOWN / BUMP? / FWD UP / FWD DOWN
static uint32_t gSlopeStatusUntilMs = 0;
// 2026.5.23：バンプLOW/MEDIUM/HIGH表示は、座標更新や次の直進開始でFLATへ戻されても3秒保持する。
static char gBumpCompHudStatus[8] = ""; // LOW / MEDIUM / HIGH
static uint32_t gBumpCompHudUntilMs = 0;
static uint8_t gSlopeCandidateDir = 0; // 0=なし / 1=登り / 2=下り
static uint32_t gSlopeCandidateStartMs = 0;
static long gSlopeCandidateStartPulses = 0;
static bool gSlopeDetectedThisMove = false;
static uint8_t gSlopeLatchedDir = 0; // 0=なし / 1=登りUP / 2=下りDOWN
static uint8_t gSlopeUpExtraCm = 0;   // 表示用モード：0=なし / 1=LOW / 2=HIGH
static uint32_t gSlopeFlatStartMs = 0;
static uint32_t gSlopeUpLowStartMs = 0;
static uint32_t gSlopeUpHighStartMs = 0;
static bool gSlopeUpHighHeld = false;
static float gSlopeCandidateMaxPitch = 0.0f;       // 2026.5.23：UP?候補中の正方向Pitch最大値。バンプLOW/MEDIUM/HIGH判定に使う
static uint8_t gBumpCompConfirmedModeThisMove = 0; // 2026.5.23：同じ30cm直進中の確定バンプ最大モード。0=なし/1=LOW/2=MEDIUM/3=HIGH

static bool gTerrainClassActive = false;
static int gTerrainClassStartX = 0;
static int gTerrainClassStartY = 0;
static uint8_t gTerrainClassStartFloor = 0;
static uint8_t gTerrainClassStartDir = 0;
static bool gTerrainClassHasUp = false;
static bool gTerrainClassHasDown = false;
static char gTerrainClassHudStatus[8] = ""; // OBS / STAIR / RAMP / UNK
static char gTerrainClassResult[8] = "";    // 観察中のSTAIR確定保持。STAIR確定後も4マス内は観察を継続する。
static char gTerrainClassFinalResult[8] = ""; // 最終分類。RAMP確定時のフロア切替ゲートに使う
static bool gTerrainClassTurnRampPending = false; // 曲がった後、次座標へ正常移動できたらRAMPにする保留
static uint32_t gTerrainClassHudUntilMs = 0;

static void slopeSetStatus(const char* label, uint32_t holdMs = 0) {
  strncpy(gSlopeStatus, label, sizeof(gSlopeStatus) - 1);
  gSlopeStatus[sizeof(gSlopeStatus) - 1] = '\0';
  gSlopeStatusUntilMs = (holdMs > 0) ? (millis() + holdMs) : 0;
}

static void bumpCompSetHudStatus(const char* label, uint32_t holdMs = BUMP_COMP_DISPLAY_MS) {
  strncpy(gBumpCompHudStatus, label, sizeof(gBumpCompHudStatus) - 1);
  gBumpCompHudStatus[sizeof(gBumpCompHudStatus) - 1] = '\0';
  gBumpCompHudUntilMs = (holdMs > 0) ? (millis() + holdMs) : 0;
}

static bool bumpCompHudIsActive() {
  return (gBumpCompHudUntilMs != 0) && ((int32_t)(millis() - gBumpCompHudUntilMs) < 0);
}

static void bumpCompHudService() {
  if (gBumpCompHudUntilMs != 0 && ((int32_t)(millis() - gBumpCompHudUntilMs) >= 0)) {
    gBumpCompHudUntilMs = 0;
    gBumpCompHudStatus[0] = '\0';
  }
}

static void terrainClassSetHudStatus(const char* label, uint32_t holdMs = TERRAIN_CLASS_DISPLAY_MS) {
  strncpy(gTerrainClassHudStatus, label, sizeof(gTerrainClassHudStatus) - 1);
  gTerrainClassHudStatus[sizeof(gTerrainClassHudStatus) - 1] = '\0';
  gTerrainClassHudUntilMs = (holdMs > 0) ? (millis() + holdMs) : 0;
}

static bool terrainClassHudIsActive() {
  return gTerrainClassActive ||
         ((gTerrainClassHudUntilMs != 0) && ((int32_t)(millis() - gTerrainClassHudUntilMs) < 0));
}

static void terrainClassHudService() {
  if (!gTerrainClassActive && gTerrainClassHudUntilMs != 0 &&
      ((int32_t)(millis() - gTerrainClassHudUntilMs) >= 0)) {
    gTerrainClassHudUntilMs = 0;
    gTerrainClassHudStatus[0] = '\0';
  }
}

static inline bool terrainClassResultIsStair() {
  return strcmp(gTerrainClassResult, "STAIR") == 0;
}

static inline bool terrainClassFinalIs(const char* label) {
  return (label != nullptr) && (strcmp(gTerrainClassFinalResult, label) == 0);
}

static inline bool terrainClassHasAnySlopePitch() {
  return gTerrainClassHasUp || gTerrainClassHasDown;
}

static void terrainClassSetFinalResult(const char* label) {
  strncpy(gTerrainClassFinalResult, label ? label : "UNK", sizeof(gTerrainClassFinalResult) - 1);
  gTerrainClassFinalResult[sizeof(gTerrainClassFinalResult) - 1] = '\0';
}

static int terrainClassStraightProgressCells() {
  int dx = posX - gTerrainClassStartX;
  int dy = posY - gTerrainClassStartY;
  switch (gTerrainClassStartDir & 3) {
    case 0: // N
      if (dx != 0) return -999;
      return dy;
    case 1: // E
      if (dy != 0) return -999;
      return dx;
    case 2: // S
      if (dx != 0) return -999;
      return -dy;
    default: // W
      if (dy != 0) return -999;
      return -dx;
  }
}

static void terrainClassFinish(const char* label, const char* reason) {
  int progress = gTerrainClassActive ? terrainClassStraightProgressCells() : 0;

  Serial.print("TR CLASS ");
  Serial.print(label ? label : "");
  Serial.print(" reason=");
  Serial.print(reason ? reason : "");
  Serial.print(" startF");
  Serial.print((unsigned)(gTerrainClassStartFloor + 1));
  Serial.print(" start=");
  Serial.print(gTerrainClassStartX);
  Serial.print(",");
  Serial.print(gTerrainClassStartY);
  Serial.print(" dir=");
  Serial.print(dirChar(gTerrainClassStartDir));
  Serial.print(" nowF");
  Serial.print((unsigned)(currentFloor + 1));
  Serial.print(" now=");
  Serial.print(posX);
  Serial.print(",");
  Serial.print(posY);
  Serial.print(" cells=");
  Serial.print(progress);
  Serial.print(" up=");
  Serial.print(gTerrainClassHasUp ? 1 : 0);
  Serial.print(" down=");
  Serial.println(gTerrainClassHasDown ? 1 : 0);

  const char* finalLabel = label ? label : "UNK";
  gTerrainClassActive = false;
  gTerrainClassTurnRampPending = false;
  terrainClassSetFinalResult(finalLabel);
  terrainClassSetHudStatus(finalLabel, TERRAIN_CLASS_DISPLAY_MS);
  gTerrainClassResult[0] = '\0';

  if (strcmp(finalLabel, "RAMP") == 0) {
    terrainPassApplyPendingFloorSwitch(reason ? reason : "terrain_class_ramp");
  } else if (strcmp(finalLabel, "STAIR") == 0 || strcmp(finalLabel, "UNK") == 0) {
    terrainPassCancelPendingFloorSwitch(reason ? reason : "terrain_class_no_floor_switch");
  }
}

static void terrainClassMarkStair(const char* reason) {
  if (terrainClassResultIsStair()) return;

  strncpy(gTerrainClassResult, "STAIR", sizeof(gTerrainClassResult) - 1);
  gTerrainClassResult[sizeof(gTerrainClassResult) - 1] = '\0';
  terrainClassSetFinalResult("STAIR");
  gTerrainClassTurnRampPending = false;
  terrainClassSetHudStatus("STAIR", 0);
  terrainPassCancelPendingFloorSwitch(reason ? reason : "stair_marked");

  Serial.print("TR CLASS STAIR reason=");
  Serial.print(reason ? reason : "");
  Serial.print(" startF");
  Serial.print((unsigned)(gTerrainClassStartFloor + 1));
  Serial.print(" start=");
  Serial.print(gTerrainClassStartX);
  Serial.print(",");
  Serial.print(gTerrainClassStartY);
  Serial.print(" dir=");
  Serial.print(dirChar(gTerrainClassStartDir));
  Serial.print(" nowF");
  Serial.print((unsigned)(currentFloor + 1));
  Serial.print(" now=");
  Serial.print(posX);
  Serial.print(",");
  Serial.print(posY);
  Serial.print(" cells=");
  Serial.print(terrainClassStraightProgressCells());
  Serial.print(" up=");
  Serial.print(gTerrainClassHasUp ? 1 : 0);
  Serial.print(" down=");
  Serial.println(gTerrainClassHasDown ? 1 : 0);
}

static void terrainClassDeferRampAfterTurn(const char* reason) {
  if (!gTerrainClassActive) return;

  if (terrainClassResultIsStair()) {
    terrainClassFinish("STAIR", reason ? reason : "turn_after_stair");
    return;
  }

  if (terrainClassHasAnySlopePitch()) {
    int progress = terrainClassStraightProgressCells();
    Serial.print("TR RAMP PENDING reason=");
    Serial.print(reason ? reason : "turn_wait_next_coord");
    Serial.print(" startF");
    Serial.print((unsigned)(gTerrainClassStartFloor + 1));
    Serial.print(" start=");
    Serial.print(gTerrainClassStartX);
    Serial.print(',');
    Serial.print(gTerrainClassStartY);
    Serial.print(" dir=");
    Serial.print(dirChar(gTerrainClassStartDir));
    Serial.print(" nowF");
    Serial.print((unsigned)(currentFloor + 1));
    Serial.print(" now=");
    Serial.print(posX);
    Serial.print(',');
    Serial.print(posY);
    Serial.print(" cells=");
    Serial.print(progress);
    Serial.print(" up=");
    Serial.print(gTerrainClassHasUp ? 1 : 0);
    Serial.print(" down=");
    Serial.println(gTerrainClassHasDown ? 1 : 0);

    gTerrainClassActive = false;
    gTerrainClassTurnRampPending = true;
    terrainClassSetHudStatus("OBS", 0);
    return;
  }

  terrainClassFinish("UNK", reason ? reason : "turn_no_pitch");
}

static void terrainClassOnCoordinateStepCompleted() {
  if (!gTerrainClassTurnRampPending) return;

  gTerrainClassTurnRampPending = false;
  terrainClassSetFinalResult("RAMP");
  terrainClassSetHudStatus("RAMP", TERRAIN_CLASS_DISPLAY_MS);

  Serial.print("TR CLASS RAMP reason=turn_next_coord_ok nowF");
  Serial.print((unsigned)(currentFloor + 1));
  Serial.print(" now=");
  Serial.print(posX);
  Serial.print(',');
  Serial.print(posY);
  Serial.print(" up=");
  Serial.print(gTerrainClassHasUp ? 1 : 0);
  Serial.print(" down=");
  Serial.println(gTerrainClassHasDown ? 1 : 0);

  terrainPassApplyPendingFloorSwitch("turn_next_coord_ok");
  gTerrainClassResult[0] = '\0';
}

static void terrainClassBegin(uint8_t slopeDir) {
  if (slopeDir != 1 && slopeDir != 2) return;

  // 既に同じ直線上の観察中ならリセットせず、UP/DOWN検知だけ追加する。
  // これにより、階段の「上り→下り」を同じ観察として扱える。
  if (gTerrainClassActive) {
    if ((direction & 3) != gTerrainClassStartDir) {
      terrainClassDeferRampAfterTurn(terrainClassResultIsStair() ? "turn_after_stair" : "turn_before_class");
    } else {
      int progress = terrainClassStraightProgressCells();
      if (progress < 0) {
        terrainClassDeferRampAfterTurn(terrainClassResultIsStair() ? "line_end_after_stair" : "line_end_before_new_off_line");
      } else if (progress >= TERRAIN_CLASS_MAX_STRAIGHT_CELLS) {
        terrainClassFinish(terrainClassResultIsStair() ? "STAIR" : ((gTerrainClassHasUp || gTerrainClassHasDown) ? "RAMP" : "UNK"), terrainClassResultIsStair() ? "line_end_at_4cells_after_stair" : "line_end_at_4cells_before_new");
      } else {
        if (slopeDir == 1) gTerrainClassHasUp = true;
        if (slopeDir == 2) gTerrainClassHasDown = true;
        if (gTerrainClassHasUp && gTerrainClassHasDown) {
          terrainClassMarkStair("new_slope_same_stair_within_4cells");
        }
        // STAIR確定後は、追加の登り/下りが来てもOBSへ戻さない。
        terrainClassSetHudStatus(terrainClassResultIsStair() ? "STAIR" : "OBS", 0);
        return;
      }
    }
  }

  gTerrainClassActive = true;
  gTerrainClassResult[0] = '\0';
  gTerrainClassFinalResult[0] = '\0';
  gTerrainClassTurnRampPending = false;
  gTerrainClassStartX = posX;
  gTerrainClassStartY = posY;
  gTerrainClassStartFloor = currentFloor;
  gTerrainClassStartDir = direction & 3;
  gTerrainClassHasUp = (slopeDir == 1);
  gTerrainClassHasDown = (slopeDir == 2);
  terrainClassSetHudStatus("OBS", 0);

  Serial.print("TR OBS BEGIN F");
  Serial.print((unsigned)(gTerrainClassStartFloor + 1));
  Serial.print(" X:");
  Serial.print(gTerrainClassStartX);
  Serial.print(" Y:");
  Serial.print(gTerrainClassStartY);
  Serial.print(" dir=");
  Serial.print(dirChar(gTerrainClassStartDir));
  Serial.print(" first=");
  Serial.println((slopeDir == 1) ? "UP" : "DOWN");
}

static void terrainClassServiceDuringStraight(float p) {
  if (!gTerrainClassActive) return;

  if ((direction & 3) != gTerrainClassStartDir) {
    terrainClassDeferRampAfterTurn(terrainClassResultIsStair() ? "direction_changed_after_stair" : "direction_changed_wait_next_coord");
    return;
  }

  int progress = terrainClassStraightProgressCells();
  if (progress < 0) {
    terrainClassDeferRampAfterTurn(terrainClassResultIsStair() ? "off_line_after_stair" : "off_line_wait_next_coord");
    return;
  }
  if (progress > TERRAIN_CLASS_MAX_STRAIGHT_CELLS) {
    terrainClassFinish(terrainClassResultIsStair() ? "STAIR" : ((gTerrainClassHasUp || gTerrainClassHasDown) ? "RAMP" : "UNK"), terrainClassResultIsStair() ? "over_4cells_after_stair" : "over_4cells_safety");
    return;
  }

  bool changed = false;
  if (p >= TERRAIN_CLASS_UP_PITCH_DEG && !gTerrainClassHasUp) {
    gTerrainClassHasUp = true;
    changed = true;
  }
  if (p <= TERRAIN_CLASS_DOWN_PITCH_DEG && !gTerrainClassHasDown) {
    gTerrainClassHasDown = true;
    changed = true;
  }

  if (changed) {
    Serial.print("TR OBS pitch P=");
    Serial.print(p, 1);
    Serial.print(" cells=");
    Serial.print(progress);
    Serial.print(" up=");
    Serial.print(gTerrainClassHasUp ? 1 : 0);
    Serial.print(" down=");
    Serial.println(gTerrainClassHasDown ? 1 : 0);
  }

  if (gTerrainClassHasUp && gTerrainClassHasDown) {
    // 2026.5.23：STAIR確定後も観察は終了しない。
    // 3段階段などでさらに登り/下りが来ても、直線上4マス以内なら同じ階段として扱う。
    terrainClassMarkStair("up_and_down_within_4cells_straight");
  }

  // 2026.5.23：4マス以内で階段条件（+8°と-8°の両方）が成立しなければ、
  // 5マス目まで待たずに4マス到達時点でRAMPとして分類する。
  if (progress >= TERRAIN_CLASS_MAX_STRAIGHT_CELLS) {
    terrainClassFinish(terrainClassResultIsStair() ? "STAIR" : ((gTerrainClassHasUp || gTerrainClassHasDown) ? "RAMP" : "UNK"), terrainClassResultIsStair() ? "at_4cells_stair_complete" : "at_4cells_no_opposite_pitch");
    return;
  }
}

static bool slopeIsLatchedUp() {
  return (gSlopeDetectedThisMove && gSlopeLatchedDir == 1);
}

static long slopeGetUpExtraPulsesForCurrentPitch() {
  if (!slopeIsLatchedUp()) return 0;

  // 20°未満はLOW、20°以上はHIGH。補正距離の数値を変えてもOLED表示はLOW/HIGHのまま。
  if (pitchDeg >= SLOPE_UP_EXTRA_HIGH_PITCH_DEG) return SLOPE_UP_EXTRA_HIGH_PULSES;
  return SLOPE_UP_EXTRA_LOW_PULSES;
}

static void slopeApplyUpExtraLabel(bool isHigh) {
  if (!slopeIsLatchedUp()) return;

  uint8_t mode = isHigh ? 2 : 1;
  if (gSlopeUpExtraCm == mode) return;

  gSlopeUpExtraCm = mode;
  slopeSetStatus(isHigh ? "HIGH" : "LOW");
  markRecordedSlopeCellsUpExtraModeForFloor(currentFloor, mode, isHigh ? "HIGH" : "LOW");

  Serial.print("SLOPE UP EXTRA ");
  Serial.print(isHigh ? "HIGH" : "LOW");
  Serial.print(" P=");
  Serial.println(pitchDeg, 1);
}

static uint8_t bumpCompModeForMaxPitch(float maxPitchDeg) {
  if (maxPitchDeg >= BUMP_COMP_HIGH_PITCH_DEG) return 3;
  if (maxPitchDeg >= BUMP_COMP_MEDIUM_PITCH_DEG) return 2;
  if (maxPitchDeg >= BUMP_COMP_LOW_PITCH_DEG) return 1;
  return 0;
}

static long bumpCompPulsesForMode(uint8_t mode) {
  if (mode == 3) return BUMP_COMP_HIGH_PULSES;
  if (mode == 2) return BUMP_COMP_MEDIUM_PULSES;
  if (mode == 1) return BUMP_COMP_LOW_PULSES;
  return 0;
}

static const char* bumpCompLabelForMode(uint8_t mode) {
  if (mode == 3) return "HIGH";
  if (mode == 2) return "MEDIUM";
  if (mode == 1) return "LOW";
  return "FLAT";
}

static inline bool bumpCompStatusIsShowing() {
  if (bumpCompHudIsActive()) return true;
  return (gSlopeStatusUntilMs != 0) &&
         (strcmp(gSlopeStatus, "LOW") == 0 ||
          strcmp(gSlopeStatus, "MEDIUM") == 0 ||
          strcmp(gSlopeStatus, "HIGH") == 0);
}

static void slopeSetBumpCandidateStatus() {
  // バンプ補正のLOW/MEDIUM/HIGH表示中は、旧BUMP?表示で上書きしない。
  if (!bumpCompStatusIsShowing()) {
    slopeSetStatus("BUMP?", SLOPE_BUMP_DISPLAY_MS);
  }
}

static void bumpRecordTargetCellFromCandidate(bool coordAlreadyUpdated, const char* reason) {
  uint8_t floor = currentFloor;
  int bx = posX;
  int by = posY;

  // 候補開始時点で「進行先マス」を固定しているので、基本はこれを使う。
  if (gSlopeCandidateMapCellValid && visInRange(gSlopeCandidateMapX, gSlopeCandidateMapY)) {
    bx = gSlopeCandidateMapX;
    by = gSlopeCandidateMapY;
  } else if (!coordAlreadyUpdated) {
    // 念のためのフォールバック：座標更新前なら前方タイルへ記録。
    neighborByAbs(direction & 3, posX, posY, bx, by);
  }

  if (!visInRange(bx, by)) return;

  bool wasAlready = (bumpGetFloor(floor, bx, by) != 0);
  bumpSetFloor(floor, bx, by, 1);

  Serial.print(wasAlready ? "BP KEEP" : "BP SET");
  Serial.print(" reason=");
  Serial.print(reason ? reason : "");
  Serial.print(" F");
  Serial.print((unsigned)(floor + 1));
  Serial.print(" X:");
  Serial.print(bx);
  Serial.print(" Y:");
  Serial.println(by);
}

static void bumpCompConfirmFromSlopeCandidate(long dp, const char* reason, bool coordAlreadyUpdated) {
  uint8_t mode = bumpCompModeForMaxPitch(gSlopeCandidateMaxPitch);
  if (mode == 0) return;

  if (mode > gBumpCompConfirmedModeThisMove) {
    gBumpCompConfirmedModeThisMove = mode;
  }

  bumpRecordTargetCellFromCandidate(coordAlreadyUpdated, reason);

  const char* label = bumpCompLabelForMode(mode);
  slopeSetStatus(label, BUMP_COMP_DISPLAY_MS);
  bumpCompSetHudStatus(label, BUMP_COMP_DISPLAY_MS);

  Serial.print("BUMP CONF ");
  Serial.print(label);
  Serial.print(" reason=");
  Serial.print(reason);
  Serial.print(" maxP=");
  Serial.print(gSlopeCandidateMaxPitch, 1);
  Serial.print(" dist_cm=");
  Serial.print((float)dp / PULSES_PER_CM, 1);
  Serial.print(" use_mode=");
  Serial.println(bumpCompLabelForMode(gBumpCompConfirmedModeThisMove));
}

static void bumpCompConfirmQuickLowFromSlopeCandidate(long dp, const char* reason, bool coordAlreadyUpdated) {
  // 2026.5.23：垂直バンプなどで前輪の持ち上がりが短すぎる場合の救済。
  // +5°には届かなくても、短時間候補で最大+4°以上ならLOWバンプとして確定する。
  if (gSlopeCandidateMaxPitch < BUMP_COMP_QUICK_LOW_PITCH_DEG) return;

  uint8_t mode = 1; // LOW固定
  if (mode > gBumpCompConfirmedModeThisMove) {
    gBumpCompConfirmedModeThisMove = mode;
  }

  bumpRecordTargetCellFromCandidate(coordAlreadyUpdated, reason);

  const char* label = bumpCompLabelForMode(mode);
  slopeSetStatus(label, BUMP_COMP_DISPLAY_MS);
  bumpCompSetHudStatus(label, BUMP_COMP_DISPLAY_MS);

  Serial.print("BUMP CONF ");
  Serial.print(label);
  Serial.print(" reason=");
  Serial.print(reason);
  Serial.print(" maxP=");
  Serial.print(gSlopeCandidateMaxPitch, 1);
  Serial.print(" dist_cm=");
  Serial.print((float)dp / PULSES_PER_CM, 1);
  Serial.print(" use_mode=");
  Serial.println(bumpCompLabelForMode(gBumpCompConfirmedModeThisMove));
}


static inline bool terrainPassActive() {
  return gTerrainPassActive;
}

static inline bool terrainPassMotionLocked() {
  return gTerrainPassActive || gTerrainPassClearanceActive;
}

static inline long terrainPassDistancePulses() {
  if (!gTerrainPassActive) return 0;
  long aFL = labs(encFL - gTerrainPassStartFL);
  long aFR = labs(encFR - gTerrainPassStartFR);
  long aBL = labs(encBL - gTerrainPassStartBL);
  long aBR = labs(encBR - gTerrainPassStartBR);
  return (aFL + aFR + aBL + aBR) / 4;
}

static inline bool terrainPassShouldSuppressColorVictim() {
  // 坂・階段そのものには色タイル/被災者が無い前提。
  // ただしUP?/DOWN?候補だけで止めると、右回転後の軽い姿勢変化でも
  // 7cm/13cm色チェックが丸ごと無効になるため、確定後だけ抑制する。
  return terrainPassMotionLocked() || gSlopeDetectedThisMove || gSlopeLatchedDir != 0;
}

static void terrainPassBegin(uint8_t slopeDir) {
  if (slopeDir != 1 && slopeDir != 2) return;
  if (gTerrainPassActive) return;

  // 2026.5.23：RAMP確定待ち中に反対向きの坂/下りを検知した場合、
  // 前回のPENDINGを先にRAMPとして確定してから次の地形処理へ入る。
  if (gTerrainPassFloorSwitchPending && currentFloor == gTerrainPassPendingFromFloor &&
      gTerrainPassPendingSlopeDir != 0 && gTerrainPassPendingSlopeDir != slopeDir) {
    Serial.println("TERRAIN PENDING FORCE RAMP before_opposite_slope");
    gTerrainClassActive = false;
    gTerrainClassTurnRampPending = false;
    gTerrainClassResult[0] = '\0';
    terrainClassSetFinalResult("RAMP");
    terrainClassSetHudStatus("RAMP", TERRAIN_CLASS_DISPLAY_MS);
    terrainPassApplyPendingFloorSwitch("pending_before_opposite_slope");
  }

  gTerrainPassActive = true;
  gTerrainPassDir = slopeDir;
  terrainClassBegin(slopeDir);
  gTerrainPassStartFloor = currentFloor;
  gTerrainPassStartX = posX;
  gTerrainPassStartY = posY;
  gTerrainPassTravelAbsDir = direction & 3;
  gTerrainPassStartFL = encFL;
  gTerrainPassStartFR = encFR;
  gTerrainPassStartBL = encBL;
  gTerrainPassStartBR = encBR;
  gTerrainPassClearanceActive = false;
  gTerrainPassClearanceTargetAvgPulses = 0;

  frontierTargetMode = false;
  frontierTargetZone = ZONE_UNKNOWN;
  unknownSweepReset();

  slopeSetStatus((slopeDir == 1) ? "FWD UP" : "FWD DOWN");

  Serial.print((slopeDir == 1) ? "TERRAIN PASS UP ON F" : "TERRAIN PASS DOWN ON F");
  Serial.print((unsigned)(currentFloor + 1));
  Serial.print(" X:");
  Serial.print(posX);
  Serial.print(" Y:");
  Serial.print(posY);
  Serial.print(" DIR:");
  Serial.println((unsigned)(direction & 3));
}

static void terrainPassFinish(uint8_t slopeDir) {
  if (slopeDir != 1 && slopeDir != 2) return;

  uint8_t fromFloor = currentFloor;
  uint8_t passTravelAbsDir = gTerrainPassTravelAbsDir & 3;
  int passExitX = posX;
  int passExitY = posY;
  long passCm10 = (long)((terrainPassDistancePulses() * 10L) / PULSES_PER_CM);

  bool didSwitch = false;
  if (terrainClassResultIsStair() || terrainClassFinalIs("STAIR")) {
    terrainPassCancelPendingFloorSwitch("terrain_pass_finish_stair_keep_floor");
  } else if (terrainClassFinalIs("UNK")) {
    terrainPassCancelPendingFloorSwitch("terrain_pass_finish_unk_keep_floor");
  } else if (terrainClassFinalIs("RAMP")) {
    didSwitch = floorSwitchAfterSlope(slopeDir);
  } else {
    // まだOBS中。STAIR/UNK/RAMPが確定するまでフロア切替を保留する。
    terrainPendingCoordReset("pending_begin");
    gTerrainPassFloorSwitchPending = true;
    gTerrainPassPendingSlopeDir = slopeDir;
    gTerrainPassPendingTravelAbsDir = passTravelAbsDir;
    gTerrainPassPendingFromFloor = fromFloor;
    gTerrainPassPendingExitX = passExitX;
    gTerrainPassPendingExitY = passExitY;

    // 2026.5.23：TR分類待ちでフロア切替を保留している間も、坂出口マスでは通常探索できるようにする。
//   - 2026.5.23：PENDING中に旧フロアへ仮記録された座標を、RAMP確定時に新フロアへ移し旧フロアを復元する。
    // floorSwitchAfterSlope()を待つと、出口マスがSLセル扱いのまま残り、前壁時に左右Unknownを選ばずUターンする。
    // そのため、旧フロア側の出口マスだけ先に「左右Unknown・SL解除・後ろUnknown除外」へ戻す。
    slopeExitClearSideWallsAndTransitForFloor(fromFloor, passExitX, passExitY, passTravelAbsDir, "PENDING_FROM");
    slopeExitIgnoreUnknownSetFloor(fromFloor, passExitX, passExitY, passTravelAbsDir);
    if (slopeDir == 2) {
      slopeDownExitNoSideReadSetFloor(fromFloor, passExitX, passExitY, passTravelAbsDir);
    }

    Serial.print("TERRAIN FLOOR SWITCH PENDING F");
    Serial.print((unsigned)(fromFloor + 1));
    Serial.print(" X:");
    Serial.print(passExitX);
    Serial.print(" Y:");
    Serial.print(passExitY);
    Serial.print(" DIR:");
    Serial.print((unsigned)passTravelAbsDir);
    Serial.print(" slope=");
    Serial.println((slopeDir == 1) ? "UP" : "DOWN");
  }

  Serial.print((slopeDir == 1) ? "TERRAIN PASS UP OFF " : "TERRAIN PASS DOWN OFF ");
  Serial.print("F");
  Serial.print((unsigned)(fromFloor + 1));
  Serial.print("->F");
  Serial.print((unsigned)(currentFloor + 1));
  Serial.print(" X:");
  Serial.print(posX);
  Serial.print(" Y:");
  Serial.print(posY);
  Serial.print(" dist_cm=");
  Serial.print(passCm10 / 10);
  Serial.print('.');
  Serial.print(abs((int)(passCm10 % 10)));
  Serial.print(" switch=");
  Serial.println(didSwitch ? "NOW" : (gTerrainPassFloorSwitchPending ? "PENDING" : "NO"));

  gTerrainPassActive = false;
  gTerrainPassDir = 0;
  gTerrainPassStartFloor = currentFloor;
  gTerrainPassStartX = posX;
  gTerrainPassStartY = posY;
  gTerrainPassTravelAbsDir = direction & 3;
}

static bool terrainPassApplyPendingFloorSwitch(const char* reason) {
  if (!gTerrainPassFloorSwitchPending) return false;

  if (!floorIndexInRange(gTerrainPassPendingFromFloor) || currentFloor != gTerrainPassPendingFromFloor) {
    Serial.print("TERRAIN FLOOR SWITCH PENDING CANCEL reason=floor_changed pendingF");
    Serial.print((unsigned)(gTerrainPassPendingFromFloor + 1));
    Serial.print(" nowF");
    Serial.println((unsigned)(currentFloor + 1));
    gTerrainPassFloorSwitchPending = false;
    terrainPendingCoordReset("pending_cancel_floor_changed");
    return false;
  }

  Serial.print("TERRAIN FLOOR SWITCH APPLY reason=");
  Serial.print(reason ? reason : "");
  Serial.print(" F");
  Serial.print((unsigned)(currentFloor + 1));
  Serial.print(" exit=");
  Serial.print(gTerrainPassPendingExitX);
  Serial.print(',');
  Serial.print(gTerrainPassPendingExitY);
  Serial.print(" now=");
  Serial.print(posX);
  Serial.print(',');
  Serial.print(posY);
  Serial.print(" dir=");
  Serial.println((unsigned)(gTerrainPassPendingTravelAbsDir & 3));

  gFloorSwitchOverrideActive = true;
  gFloorSwitchOverrideTravelAbsDir = gTerrainPassPendingTravelAbsDir & 3;
  gFloorSwitchOverrideExitX = gTerrainPassPendingExitX;
  gFloorSwitchOverrideExitY = gTerrainPassPendingExitY;
  gFloorSwitchRestoreCurrentOldCell = true;
  bool ok = floorSwitchAfterSlope(gTerrainPassPendingSlopeDir);
  gFloorSwitchOverrideActive = false;
  gFloorSwitchRestoreCurrentOldCell = false;
  gTerrainPassFloorSwitchPending = false;
  terrainPendingCoordReset(ok ? "pending_apply_done" : "pending_apply_failed");

  if (ok) {
    memset(Frontier_Number, 0xFF, sizeof(Frontier_Number));
    frontierTargetMode = false;
    frontierTargetZone = ZONE_UNKNOWN;
    gFrontierFallbackExtLH = false;
    unknownSweepReset();
    Serial.println("FRONTIER RESET reason=terrain_ramp_floor_fix");
  }
  return ok;
}

static void terrainPassCancelPendingFloorSwitch(const char* reason) {
  if (!gTerrainPassFloorSwitchPending) return;
  Serial.print("TERRAIN FLOOR SWITCH CANCEL reason=");
  Serial.print(reason ? reason : "");
  Serial.print(" pendingF");
  Serial.print((unsigned)(gTerrainPassPendingFromFloor + 1));
  Serial.print(" exit=");
  Serial.print(gTerrainPassPendingExitX);
  Serial.print(',');
  Serial.println(gTerrainPassPendingExitY);
  gTerrainPassFloorSwitchPending = false;
  terrainPendingCoordReset(reason ? reason : "pending_cancel");
}

static void slopeDetectResetForStraight() {
  gSlopeCandidateDir = 0;
  gSlopeCandidateStartMs = 0;
  gSlopeCandidateStartPulses = 0;
  gSlopeFlatStartMs = 0;
  gSlopeUpLowStartMs = 0;
  gSlopeUpHighStartMs = 0;
  gSlopeUpHighHeld = false;
  gSlopeCandidateMaxPitch = 0.0f;
  gBumpCompConfirmedModeThisMove = 0;

  // 2026.5.16：UP/DOWN確定後は、次の30cm区間へ入っても表示を消さない。
  // 坂・階段が2マス以上続く場合に、UP -> UP? と戻るのを防ぐ。
  if (!gSlopeDetectedThisMove) {
    gSlopeLatchedDir = 0;
    slopeSideWallCellsReset();
    gSlopeMapCellValid = false;
    gSlopeMapX = posX;
    gSlopeMapY = posY;
    gSlopeMapTravelAbsDir = direction & 3;
    gSlopeCandidateMapCellValid = false;
    gSlopeCandidateMapX = posX;
    gSlopeCandidateMapY = posY;
    gSlopeCandidateMapTravelAbsDir = direction & 3;
    gSlopeUpExtraCm = 0;
    slopeSetStatus("FLAT");
  }
}

static void slopeRememberMapCellForSideWalls(bool coordAlreadyUpdated) {
  gSlopeMapTravelAbsDir = direction & 3;

  int sx = posX;
  int sy = posY;
  if (!coordAlreadyUpdated) {
    // 15cm座標更新前に坂確定した場合は、現在向いている前方タイルを坂タイルとして保存する。
    neighborByAbs(gSlopeMapTravelAbsDir, posX, posY, sx, sy);
  }

  if (visInRange(sx, sy)) {
    gSlopeMapX = sx;
    gSlopeMapY = sy;
    gSlopeMapCellValid = true;
  } else {
    gSlopeMapCellValid = false;
  }
}

static void slopeRememberCandidateMapCellForSideWalls(bool coordAlreadyUpdated) {
  gSlopeCandidateMapTravelAbsDir = direction & 3;

  int sx = posX;
  int sy = posY;
  if (!coordAlreadyUpdated) {
    // 候補開始時点でまだ座標更新前なら、前方タイルが坂タイル。
    neighborByAbs(gSlopeCandidateMapTravelAbsDir, posX, posY, sx, sy);
  }

  if (visInRange(sx, sy)) {
    gSlopeCandidateMapX = sx;
    gSlopeCandidateMapY = sy;
    gSlopeCandidateMapCellValid = true;
  } else {
    gSlopeCandidateMapCellValid = false;
  }
}

static void slopeUseCandidateMapCellForSideWalls(bool coordAlreadyUpdated) {
  if (gSlopeCandidateMapCellValid && visInRange(gSlopeCandidateMapX, gSlopeCandidateMapY)) {
    gSlopeMapX = gSlopeCandidateMapX;
    gSlopeMapY = gSlopeCandidateMapY;
    gSlopeMapTravelAbsDir = gSlopeCandidateMapTravelAbsDir;
    gSlopeMapCellValid = true;
  } else {
    // 念のためのフォールバック。通常は候補開始時の座標を使う。
    slopeRememberMapCellForSideWalls(coordAlreadyUpdated);
  }
}

static void slopeDetectServiceDuringStraight(long avgPulses, bool coordAlreadyUpdated) {
  if (!ENABLE_SLOPE_STAIR_DETECT) return;

  uint32_t now = millis();
  bumpCompHudService();

  if (gSlopeStatusUntilMs != 0 && (int32_t)(now - gSlopeStatusUntilMs) >= 0) {
    gSlopeStatusUntilMs = 0;
    if (gSlopeCandidateDir == 0 && !gSlopeDetectedThisMove) slopeSetStatus("FLAT");
  }

  float p = pitchDeg;
  terrainClassServiceDuringStraight(p);
  uint8_t dirNow = 0;
  if (p >= SLOPE_UP_CANDIDATE_PITCH_DEG) {
    dirNow = 1;
  } else if (gSlopeCandidateDir == 1 && p >= SLOPE_UP_CANCEL_PITCH_DEG) {
    // UP?候補中は、+3°未満へ落ちるまで候補を維持する。
    // ただし、+5°未満の時間はUP確定用の0.8秒には数えない。
    dirNow = 1;
  } else if (p <= SLOPE_DOWN_PITCH_DEG) {
    dirNow = 2;
  }

  // 一度UP/DOWN確定した後は、平面に戻るまで前進を優先する。
  // 解除条件：abs(Pitch)<5° が0.2秒以上続くこと。解除した瞬間に今の直進目標を「あと10cm」へ切り替える。
  if (gSlopeDetectedThisMove) {
    if (fabsf(p) < SLOPE_RELEASE_PITCH_DEG) {
      if (gSlopeFlatStartMs == 0) {
        gSlopeFlatStartMs = now;
      } else if ((uint32_t)(now - gSlopeFlatStartMs) >= SLOPE_RELEASE_HOLD_MS) {
        uint8_t slopeDirToSwitch = gSlopeLatchedDir; // 1=UP / 2=DOWN
        float passCm = (float)terrainPassDistancePulses() / PULSES_PER_CM;
        if (slopeDirToSwitch != 0) {
          terrainPassFinish(slopeDirToSwitch);
        }

        // 登り切り/下り切り判定後は、現在の30cm+補正目標を捨て、ここからあと10cmだけ進んで止まる。
        gTerrainPassClearanceActive = true;
        gTerrainPassClearanceTargetAvgPulses = avgPulses + TERRAIN_PASS_AFTER_FLAT_CLEARANCE_PULSES;

        gSlopeDetectedThisMove = false;
        gSlopeLatchedDir = 0;
        slopeSideWallCellsReset();
        gSlopeMapCellValid = false;
        gSlopeMapX = posX;
        gSlopeMapY = posY;
        gSlopeMapTravelAbsDir = direction & 3;
        gSlopeCandidateMapCellValid = false;
        gSlopeCandidateMapX = posX;
        gSlopeCandidateMapY = posY;
        gSlopeCandidateMapTravelAbsDir = direction & 3;
        gSlopeUpExtraCm = 0;
        gSlopeCandidateDir = 0;
        gSlopeFlatStartMs = 0;
        gSlopeUpLowStartMs = 0;
        gSlopeUpHighStartMs = 0;
        gSlopeUpHighHeld = false;
        gSlopeCandidateMaxPitch = 0.0f;
        slopeSetStatus("FLAT");

        Serial.print("SLOPE FLAT P=");
        Serial.print(pitchDeg, 1);
        Serial.print(" flat_ms=");
        Serial.print(SLOPE_RELEASE_HOLD_MS);
        Serial.print(" clearance_cm=10 dist_cm=");
        Serial.println(passCm, 1);
      }
    } else {
      gSlopeFlatStartMs = 0;
    }
    return;
  }

  // 2026.5.23：UP?候補中に+5°以上まで上がった後、一度でも+5°未満へ下がったら、坂ではなくバンプとして確定/解除する。
  // 斜めバンプで「左タイヤ→右タイヤ」と2回上下しても、ここで候補を分離するため坂誤判定しない。
  if (gSlopeCandidateDir == 1) {
    if (p > gSlopeCandidateMaxPitch) gSlopeCandidateMaxPitch = p;

    if (gSlopeCandidateMaxPitch >= BUMP_COMP_LOW_PITCH_DEG && p < SLOPE_UP_DROP_TO_BUMP_PITCH_DEG) {
      long dp = avgPulses - gSlopeCandidateStartPulses;
      bumpCompConfirmFromSlopeCandidate(dp, "drop<5deg", coordAlreadyUpdated);

      gSlopeCandidateDir = 0;
      gSlopeCandidateMapCellValid = false;
      slopeSideWallCellsReset();
      gSlopeUpLowStartMs = 0;
      gSlopeUpHighStartMs = 0;
      gSlopeUpHighHeld = false;
      gSlopeCandidateMaxPitch = 0.0f;
      return;
    }
  }

  if (dirNow == 0) {
    if (gSlopeCandidateDir != 0) {
      uint32_t dt = now - gSlopeCandidateStartMs;
      long dp = avgPulses - gSlopeCandidateStartPulses;

      // 角度変化が短時間、または距離が短いまま終わったものはバンプ候補にする。
      long minDetectPulses = (gSlopeCandidateDir == 1) ? SLOPE_UP_MIN_DETECT_PULSES : SLOPE_DOWN_MIN_DETECT_PULSES;
      bool isQuickCandidate = (dt <= SLOPE_BUMP_MAX_HOLD_MS || dp < minDetectPulses);

      if (isQuickCandidate) {
        // 2026.5.23：垂直バンプ救済。
        // 前輪の乗り越えが短すぎて+5°に届かなくても、最大+4°以上ならLOWバンプとして補正する。
        if (gSlopeCandidateDir == 1 && gSlopeCandidateMaxPitch >= BUMP_COMP_QUICK_LOW_PITCH_DEG) {
          bumpCompConfirmQuickLowFromSlopeCandidate(dp, "quick4_drop<3deg", coordAlreadyUpdated);
        } else {
          slopeSetBumpCandidateStatus();
          Serial.print("SLOPE BUMP? P=");
          Serial.print(pitchDeg, 1);
          Serial.print(" dt=");
          Serial.print(dt);
          Serial.print(" dist_cm=");
          Serial.println((float)dp / PULSES_PER_CM, 1);
        }
      } else {
        slopeSetStatus("FLAT");
      }
      gSlopeCandidateDir = 0;
      gSlopeCandidateMapCellValid = false;
      slopeSideWallCellsReset();
      gSlopeUpLowStartMs = 0;
      gSlopeUpHighStartMs = 0;
      gSlopeUpHighHeld = false;
      gSlopeCandidateMaxPitch = 0.0f;
    }
    return;
  }

  if (gSlopeCandidateDir != dirNow) {
    gSlopeCandidateDir = dirNow;
    gSlopeCandidateStartMs = now;
    gSlopeCandidateStartPulses = avgPulses;
    gSlopeFlatStartMs = 0;
    gSlopeUpLowStartMs = 0; // 旧+5°継続条件は廃止
    gSlopeUpHighStartMs = 0;
    gSlopeUpHighHeld = false;
    gSlopeCandidateMaxPitch = (dirNow == 1 && p > 0.0f) ? p : 0.0f;
    // 2026.5.17：坂左右壁の対象は候補開始時のタイルに固定する。
    // DOWN確定時まで待つと、下り直後の平地タイルに左右壁を入れることがある。
    slopeSideWallCellsReset();
    slopeRememberCandidateMapCellForSideWalls(coordAlreadyUpdated);
    slopeSideWallCellAddCandidate(coordAlreadyUpdated, (dirNow == 1) ? "UP?" : "DOWN?");
    slopeSetStatus((dirNow == 1) ? "UP?" : "DOWN?");

    Serial.print((dirNow == 1) ? "SLOPE UP? P=" : "SLOPE DOWN? P=");
    Serial.print(pitchDeg, 1);
    Serial.print(" avg_cm=");
    Serial.print((float)avgPulses / PULSES_PER_CM, 1);
    if (dirNow == 1) Serial.print(" rule=3deg_quick4_low_drop5_bump_or_8cm_8deg100ms");
    Serial.println();
    return;
  }

  uint32_t dt = now - gSlopeCandidateStartMs;
  long dp = avgPulses - gSlopeCandidateStartPulses;
  bool shouldDetect = false;

  if (dirNow == 1) {
    // 2026.5.23：坂/階段とバンプの分離。
    // +3°でUP?候補開始。
    // 候補中に+5°以上まで上がった後、一度でも+5°未満へ下がれば、坂候補をリセットしてバンプ確定。
    // +5°未満へ下がらず、UP?開始から8cm以上進み、+8°以上が100ms継続したらUP確定。
    if (p > gSlopeCandidateMaxPitch) gSlopeCandidateMaxPitch = p;

    if (p >= SLOPE_UP_CONFIRM_PITCH_DEG) {
      if (gSlopeUpHighStartMs == 0) {
        gSlopeUpHighStartMs = now;
      } else if ((uint32_t)(now - gSlopeUpHighStartMs) >= SLOPE_UP_HIGH_HOLD_MS) {
        gSlopeUpHighHeld = true;
      }
    } else {
      gSlopeUpHighStartMs = 0;
      gSlopeUpHighHeld = false;
    }

    shouldDetect = (gSlopeUpHighHeld && dp >= SLOPE_UP_SUSTAIN_CONFIRM_PULSES);

    if (!shouldDetect && dp >= SLOPE_UP_MAX_CANDIDATE_PULSES) {
      // 15cm進んでも坂として確定しない場合は、安全側に候補解除。
      // 最大Pitchが5°以上ならバンプとして確定し、そうでなければ単なる姿勢揺れとして捨てる。
      bumpCompConfirmFromSlopeCandidate(dp, "timeout15cm", coordAlreadyUpdated);
      if (bumpCompModeForMaxPitch(gSlopeCandidateMaxPitch) == 0) {
        slopeSetBumpCandidateStatus();
      }
      Serial.print("SLOPE UP RESET no sustained +8deg dist_cm=");
      Serial.print((float)dp / PULSES_PER_CM, 1);
      Serial.print(" maxP=");
      Serial.print(gSlopeCandidateMaxPitch, 1);
      Serial.print(" P=");
      Serial.println(pitchDeg, 1);

      gSlopeCandidateDir = 0;
      gSlopeCandidateMapCellValid = false;
      slopeSideWallCellsReset();
      gSlopeUpLowStartMs = 0;
      gSlopeUpHighStartMs = 0;
      gSlopeUpHighHeld = false;
      gSlopeCandidateMaxPitch = 0.0f;
      return;
    }
  } else {
    shouldDetect = (dt >= SLOPE_DOWN_DETECT_HOLD_MS && dp >= SLOPE_DOWN_MIN_DETECT_PULSES);
  }

  if (shouldDetect) {
    gSlopeDetectedThisMove = true;
    gSlopeLatchedDir = dirNow;
    slopeUseCandidateMapCellForSideWalls(coordAlreadyUpdated);
    // 坂が確定した時点で、候補開始時に記録した坂セルをSLとして残す。
    markRecordedSlopeCellsAsSLForFloor(currentFloor, (dirNow == 1) ? "UP DET" : "DOWN DET");
    gSlopeUpExtraCm = 0;
    gSlopeFlatStartMs = 0;
    gSlopeUpLowStartMs = 0;
    gSlopeUpHighStartMs = 0;
    gSlopeUpHighHeld = false;
    gSlopeCandidateMaxPitch = 0.0f;
    terrainPassBegin(dirNow);
    slopeSetStatus((dirNow == 1) ? "FWD UP" : "FWD DOWN");

    Serial.print((dirNow == 1) ? "SLOPE UP DET P=" : "SLOPE DOWN DET P=");
    Serial.print(pitchDeg, 1);
    Serial.print(" dt=");
    Serial.print(dt);
    Serial.print(" dist_cm=");
    Serial.println((float)dp / PULSES_PER_CM, 1);
  }
}


static inline bool slopeShouldIgnoreFrontS2ForWallJudge() {
  // 2026.5.20：地形通過中は前ToF(S2)を壁/片タッチターン判定に使わない。
  // 下りでは床読み、登り/階段では段差を壁として読む可能性があるため。
  if (terrainPassMotionLocked()) return true;
  if (pitchDeg <= -5.0f) return true;
  if (gSlopeCandidateDir == 2) return true;          // DOWN?中
  if (gSlopeDetectedThisMove && gSlopeLatchedDir == 2) return true; // DOWN確定中
  return false;
}

static void drawSlopeStatusOnHud() {
  oled.setTextSize(1);
  oled.setCursor(62, SCREEN_HEIGHT - 10);
  oled.print("S:");
  oled.print(gSlopeStatus);
}

static void drawTerrainClassStatusOnHud() {
  oled.setTextSize(1);
  oled.setCursor(62, SCREEN_HEIGHT - 10);
  oled.print("TR:");
  oled.print(gTerrainClassHudStatus);
}

static void drawBumpCompStatusOnHud() {
  oled.setTextSize(1);
  oled.setCursor(62, SCREEN_HEIGHT - 10);
  oled.print("Bump:");
  oled.print(gBumpCompHudStatus);
}


// =====================
// ===== 黒タイル検知（MAIN主導）=====
// =====================
const bool ENABLE_BLACK_TILE_CHECK = true;
const long BLACK_CHECK_FIRST_PULSES  = TARGET_6CM_PULSES;   // 30cm前進開始から6cmで一次チェック
const long BLACK_CHECK_SECOND_PULSES = TARGET_11CM_PULSES;  // 一次で黒なしなら、合計11cmで二次チェック
const long BLACK_BACK_FIRST_PULSES   = TARGET_6CM_PULSES;   // 一次で黒確定した場合、6cm戻す
const long BLACK_BACK_SECOND_PULSES  = TARGET_11CM_PULSES;  // 二次で黒確定した場合、11cm戻す
const uint32_t BLACK_CHECK_SETTLE_MS = 100;
const uint32_t BLACK_REPLY_TIMEOUT_MS = 1500;

static bool gBlackReplyReceived = false;
static bool gBlackReplyValue = false;
static bool gBlackReplyError = false;



static void markForwardTileAsBlackBlocked() {
  // 黒タイルは穴扱いなので、現在マスの前方を仮想壁として登録する。
  wallSetKnownStateBoth(posX, posY, direction, true);
  rebuildXY_NumberAll();
}

static void markForwardTileAsRedEntrance() {
  // 赤タイルはDangerous Zone入口。黒と違い、永久壁にはしない。
  // 7cm/13cm検知時点ではまだ座標更新前なので、現在マスの前方タイルへ記録する。
  int rx, ry;
  neighborByAbs(direction, posX, posY, rx, ry);

  // M_41_25：赤リカバリー探索中は、仮想座標上のredFlagを増やさない。
  // 赤到達後のNC候補は、通常探索中に記録済みのredFlag全体から作る。
  if (redRecoverySearchMode) {
    Serial.print("[RED-ENT] RECOVERY SKIP VIRTUAL FORWARD_RED X=");
    Serial.print(rx);
    Serial.print(" Y=");
    Serial.println(ry);
    return;
  }

  redSet(rx, ry, 1);
  zoneSet(rx, ry, ZONE_RED);

  // 赤発見時のnormalSideAbsDirは「ノーマル側から見つけたとき」だけ保存する。
  // レッドゾーン内から赤タイルを前方検知した場合は、レッドゾーン側をノーマル側として
  // 上書きしてしまう危険があるため、redEntranceInfoは更新しない。
  if (!inRedZone) {
    redEntranceInfoRecord(currentFloor, rx, ry, oppositeAbsDir(direction), "FORWARD_DETECT_NORMAL");
  } else {
    Serial.print("[RED-ENT] SKIP FORWARD_DETECT_IN_RED F=");
    Serial.print((unsigned)(currentFloor + 1));
    Serial.print(" X=");
    Serial.print(rx);
    Serial.print(" Y=");
    Serial.println(ry);
  }

  // 赤入口は4分後に進入する通路なので、実壁ではなくOPENとして記録する。
  // 4分以内の進入禁止はcanMoveByRelFromWallMap()側で一時的に止める。
  wallSetKnownStateBoth(posX, posY, direction, false);
  rebuildXY_NumberAll();
  rebuildRed_NumberAll();
}

// =====================
// ===== 色分類検知154ms・1回判定（MAIN主導）=====
// =====================
const bool ENABLE_COLOR_CLASS_DETECT = true;
const long COLOR_CHECK_FIRST_PULSES  = TARGET_7CM_PULSES;    // 30cm前進開始から7cmで一次チェック
const long COLOR_CHECK_SECOND_PULSES = TARGET_13CM_PULSES;   // 一次の次は合計13cmで二次チェック
const long COLOR_BLACK_RECHECK_EXTRA_PULSES = TARGET_2CM_PULSES; // 7cmで黒なら+2cm進んで9cm再判定
const long COLOR_BLACK_RECHECK_PULSES = TARGET_9CM_PULSES;       // 9cm再判定で黒/赤確定なら9cm戻す
const uint32_t COLOR_CHECK_SETTLE_MS = 100;
const uint32_t COLOR_REPLY_TIMEOUT_MS = 1500;
const uint32_t COLOR_STATUS_DISPLAY_MS = 5000;  // BLUE表示＝5秒停止
const uint32_t RED_STATUS_DISPLAY_MS = 3000;    // RED表示＝3秒停止

static bool gColorReplyReceived = false;
static bool gColorReplyError = false;
static char gColorReplyCode = 'N'; // W/K/B/R/N

// 青停止直後の次1タイルだけ、7cm/13cm地点の青判定を無視する。
// 黒判定は通常通り処理し、30cm完了後に到着地点で青を再確認する。
static bool gIgnoreBlueEarlyCheckOnNextTile = false;
static bool gSkipFirstColorCheckAfterRedTile = false; // 赤入口停止後の次1タイルだけ、7cm色チェックを飛ばす

static bool requestColorClassOnce(char &colorCode) {
  colorCode = 'N';
  gColorReplyReceived = false;
  gColorReplyError = false;
  gColorReplyCode = 'N';

  Serial1.print("CL?\n");

  uint32_t t0 = millis();
  while ((millis() - t0) < COLOR_REPLY_TIMEOUT_MS) {
    imuUpdate();
    serviceSubRx();
    serviceMainTof();
    serviceOledHud();

    if (gColorReplyReceived) {
      if (gColorReplyError) return false;
      colorCode = gColorReplyCode;
      return true;
    }
    delay(1);
  }

  return false;
}

static void showLargeColorStatusForMs(const char* label, uint32_t displayMs) {
  stopMotors();

  oled.clearDisplay();
  oled.setTextWrap(false);
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextSize(3);

  int len = (int)strlen(label);
  int textW = len * 6 * 3;
  int x = (SCREEN_WIDTH - textW) / 2;
  if (x < 0) x = 0;

  int y = (SCREEN_HEIGHT - 8 * 3) / 2;
  if (y < 0) y = 0;

  oled.setCursor(x, y);
  oled.print(label);
  oled.display();

  uint32_t t0 = millis();
  while ((millis() - t0) < displayMs) {
    // 仮表示中にserviceOledHud()を回すと通常画面で上書きされるため、ここでは回さない。
    imuUpdate();
    serviceSubRx();
    serviceMainTof();
    delay(1);
  }

  drawHudScreen();
}

static void showLargeColorStatus(const char* label) {
  showLargeColorStatusForMs(label, COLOR_STATUS_DISPLAY_MS);
}

static void showSdStatusForMs(const char* label, uint32_t displayMs) {
  if (!gOledReady) return;

  stopMotors();

  oled.clearDisplay();
  oled.setTextWrap(false);
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextSize(2);

  int len = (int)strlen(label);
  int textW = len * 6 * 2;
  int x = (SCREEN_WIDTH - textW) / 2;
  if (x < 0) x = 0;

  int y = (SCREEN_HEIGHT - 8 * 2) / 2;
  if (y < 0) y = 0;

  oled.setCursor(x, y);
  oled.print(label);
  oled.display();

  uint32_t t0 = millis();
  while ((millis() - t0) < displayMs) {
    delay(1);
  }

  drawHudScreen();
}

static void showSdStartupStatus() {
  if (!initSdSave()) {
    showSdStatusForMs("SD ERR", SD_STATUS_DISPLAY_MS);
    return;
  }

  if (!SD.exists(SD_SAVE_FILE)) {
    showSdStatusForMs("SD EMPTY", SD_STATUS_DISPLAY_MS);
    return;
  }

  // 保存データがある場合は、SD DATA表示は省略し、
  // 読み込み成功後にSD LOADだけを0.5秒表示する。
  if (loadMazeCheckpointFromSd()) {
    showSdStatusForMs("SD LOAD", SD_STATUS_DISPLAY_MS);
  } else {
    showSdStatusForMs("SD ERR", SD_STATUS_DISPLAY_MS);
  }
}

static void processBlueConfirmedCurrentTile() {
  // 15cm地点でstepForwardOneTile()済みなので、ここでのposX/posYが青タイル座標。
  // 通常訪問+1に加えて、青ペナルティ+2で合計3回扱いにする。
  blueSet(posX, posY, 1);
  visAdd(posX, posY, 2);
  if (!gLocalizationActive) {
    saveMazeCheckpoint("BLUE", false);
  }
  showLargeColorStatus("BLUE");

  // 青停止直後の次1タイルでは、7cm/13cm地点の青判定だけ無視する。
  // ただし、その次タイルの30cm完了後に青を再確認する。
  gIgnoreBlueEarlyCheckOnNextTile = true;
}

static void redRecoveryEnterUnknownRedTileNoWrite(const char* reason) {
  Serial.print("RED UNKNOWN_AS_RECOVERY ");
  Serial.print(reason ? reason : "");
  Serial.print(" F");
  Serial.print((unsigned)(currentFloor + 1));
  Serial.print(" X:");
  Serial.print(posX);
  Serial.print(" Y:");
  Serial.print(posY);
  Serial.print(" DIR:");
  Serial.println(dirChar(direction));

  inRedZone = true;
  redRecoverySearchMode = true;
  redRecoveryOnRedTile = true;
  redRecoveryNcActive = false;
  redRecoveryVisitReset();
  if (visInRange(posX, posY)) redRecoveryVisitInc(posX, posY);

  redExitMode = true;
  redExitLeavePending = false;
  redNormalConfirmMode = false;
  redNormalConfirmStepCount = 0;
  redNormalConfirmResetCandidates();
  frontierTargetMode = false;
  frontierTargetZone = ZONE_UNKNOWN;
  gFrontierFallbackExtLH = false;
  unknownSweepReset();
  showLargeColorStatusForMs("RED", RED_STATUS_DISPLAY_MS);
  gSkipFirstColorCheckAfterRedTile = true;
}

static bool redNcHandleArrivalColorMapMismatch(char observedColor, bool observedOk, const char* reason) {
  if (!inRedZone) return false;
  if (returnMode || redNormalConfirmMode || redRecoverySearchMode) return false;
  if (!floorIndexInRange(currentFloor) || !visInRange(posX, posY)) return false;

  const bool snapshotRedHere = (redNcSnapshotRedGetFloor(currentFloor, posX, posY) != 0);

  // C,Rなのに、初回RED保存スナップショット上では赤ではない。
  // live mapがズレている可能性が高いので、ゴーストredFlagを追加せず赤リカバリー経由にする。
  if (observedOk && observedColor == 'R' && !snapshotRedHere) {
    redRecoveryEnterUnknownRedTileNoWrite(reason ? reason : "ARRIVAL_R_NOT_SNAPSHOT_RED");
    return true;
  }

  // 地図上は赤のはずなのに、実際は赤を読めない（W/N/未検知など）。
  // これは赤からノーマル側へ出た後に、内部座標だけが赤マスに残っている典型的なズレ。
  // 現在地をNCの1マス目として、初回RED保存スナップショットで照合する。
  if (snapshotRedHere && (!observedOk || observedColor != 'R')) {
    Serial.print("RED_NC START_BY_MAP_COLOR_MISMATCH ");
    Serial.print(reason ? reason : "");
    Serial.print(" obs:");
    Serial.print(observedOk ? observedColor : '?');
    Serial.print(" F");
    Serial.print((unsigned)(currentFloor + 1));
    Serial.print(" X:");
    Serial.print(posX);
    Serial.print(" Y:");
    Serial.print(posY);
    Serial.print(" DIR:");
    Serial.println(dirChar(direction));

    redExitLeavePending = false;
    redExitMode = false;
    redRecoveryNcActive = true;
    startRedNormalConfirmMode(reason ? reason : "SNAP_RED_BUT_NOT_RED");
    return true;
  }

  return false;
}

static void processRedConfirmedCurrentTile() {
  // 15cm地点でstepForwardOneTile()済みなので、ここでのposX/posYが赤入口座標。
  // 赤は青のような訪問回数ペナルティを付けない。通常の+1のみ。
  bool wasInRedZone = inRedZone;

  // M_41_25：赤リカバリー探索中に赤タイルへ到達した場合は、仮想座標へredFlagを追加しない。
  // 既存のredFlag全体をNC候補に使うため、ここで仮想赤を増やすと候補が汚れる。
  if (redRecoverySearchMode && wasInRedZone) {
    inRedZone = true;
    redExitMode = true;
    redExitLeavePending = false;
    redNormalConfirmMode = false;
    redNormalConfirmStepCount = 0;
    redRecoveryOnRedTile = true;
    frontierTargetMode = false;
    frontierTargetZone = ZONE_UNKNOWN;
    showLargeColorStatusForMs("RED", RED_STATUS_DISPLAY_MS);
    gSkipFirstColorCheckAfterRedTile = true;
    return;
  }

  // M_42_10：レッドゾーン内で C,R を読んだのに、初回RED保存スナップショット上の赤ではない場合、
  // 座標ズレで実赤タイルに到達した可能性が高い。live mapのredFlagではなく、保存済みスナップショットを基準にする。
  // ここで posX/posY に redFlag を追加すると、存在しない「ゴースト赤」がNC候補に混ざるため、
  // 追加せずリカバリー赤到達扱いにする。
  if (wasInRedZone && !redNcSnapshotRedGetFloor(currentFloor, posX, posY)) {
    redRecoveryEnterUnknownRedTileNoWrite("C_R_NOT_SNAPSHOT_RED");
    return;
  }

  // M_42_11：レッドゾーン内で既知の赤タイルに到達した場合も、通常の赤進入処理で終わらせない。
  // 赤タイルは境界なので、ここから出た後は物理的にノーマル側。必ず redExitLeavePending → NC へ進ませ、
  // 初回RED保存スナップショットで座標・方角・Yawを補正する。
  if (wasInRedZone) {
    inRedZone = true;
    redExitMode = true;
    redExitLeavePending = false;
    redNormalConfirmMode = false;
    redNormalConfirmStepCount = 0;
    redNormalConfirmResetCandidates();
    redRecoverySearchMode = false;
    redRecoveryOnRedTile = false;
    redRecoveryNcActive = false;
    frontierTargetMode = false;
    frontierTargetZone = ZONE_UNKNOWN;
    gFrontierFallbackExtLH = false;
    unknownSweepReset();
    showLargeColorStatusForMs("RED", RED_STATUS_DISPLAY_MS);
    gSkipFirstColorCheckAfterRedTile = true;
    return;
  }

  redSet(posX, posY, 1);

  // ノーマル側から赤へ入った初回だけ、赤から見たノーマル側方向を保存する。
  // すでにレッドゾーン内なら、背面がノーマル側とは限らないので更新しない。
  if (!wasInRedZone) {
    redEntranceInfoRecord(currentFloor, posX, posY, oppositeAbsDir(direction), "ENTER_RED_TILE");
  }

  inRedZone = true;
  redExitMode = false;
  redExitLeavePending = false;
  redNormalConfirmMode = false;
  redNormalConfirmStepCount = 0;
  redNormalConfirmResetCandidates();
  frontierTargetMode = false;
  frontierTargetZone = ZONE_UNKNOWN;
  markCurrentCellZone();
  rebuildRed_NumberAll();
  if (!gLocalizationActive && !gRedNcSnapshotValid) {
    redNcCaptureSnapshotFromActive("FIRST_RED");
  }
  if (!gLocalizationActive) {
    saveMazeCheckpoint("RED", true);
  }
  showLargeColorStatusForMs("RED", RED_STATUS_DISPLAY_MS);

  // 赤タイル直後は、床色の境目・赤の残り読みで誤判定しやすい。
  // 次の1タイルだけ7cmの色チェックを飛ばし、13cmのみで判定する。
  gSkipFirstColorCheckAfterRedTile = true;
}

const long WALL_VOTE_START_PULSES = (long)(PULSES_PER_CM * 16.0f + 0.5f);
const long WALL_VOTE_END_PULSES   = (long)(PULSES_PER_CM * 24.0f + 0.5f);
const uint8_t WALL_VOTE_MIN_SAMPLES = 3;
const uint8_t WALL_VOTE_MIN_SAMPLES_LOCALIZE = 4; // 2026.5.17：ローカライズ中は最低4回で多数決
const uint8_t WALL_VOTE_MAX_SAMPLES = 10;

const long THRESH_10CM_PULSES  = (long)(PULSES_PER_CM * 10.0f + 0.5f);

const int speed = 120; // 左の基準PWM
const uint32_t STOP_MS = 100;
const uint32_t FWD_TIMEOUT_MS  = 15000;
const uint32_t MOVE_TIMEOUT_MS = 15000;

const int SW_L = 30;
const int SW_R = 31;
static inline bool touchPressed(int pin) { return digitalReadFast(pin) == LOW; }

const int DIR_FL  = 34; const int PWM_FL  = 33; const int ENC_FL_A = 9;  const int ENC_FL_B = 10; volatile long encFL = 0;
const int DIR_FR  = 35; const int PWM_FR  = 36; const int ENC_FR_A = 11; const int ENC_FR_B = 12; volatile long encFR = 0;
const int DIR_BL  = 3;  const int PWM_BL  = 2;  const int ENC_BL_A = 20; const int ENC_BL_B = 21; volatile long encBL = 0;
const int DIR_BR  = 4;  const int PWM_BR  = 5;  const int ENC_BR_A = 40; const int ENC_BR_B = 39; volatile long encBR = 0;

void isrFL_A() { int a=digitalReadFast(ENC_FL_A), b=digitalReadFast(ENC_FL_B); encFL += (a==b)?-1:+1; }
void isrFL_B() { int a=digitalReadFast(ENC_FL_A), b=digitalReadFast(ENC_FL_B); encFL += (a!=b)?-1:+1; }
void isrFR_A() { int a=digitalReadFast(ENC_FR_A), b=digitalReadFast(ENC_FR_B); encFR += (a==b)?+1:-1; }
void isrFR_B() { int a=digitalReadFast(ENC_FR_A), b=digitalReadFast(ENC_FR_B); encFR += (a!=b)?+1:-1; }
void isrBL_A() { int a=digitalReadFast(ENC_BL_A), b=digitalReadFast(ENC_BL_B); encBL += (a==b)?+1:-1; }
void isrBL_B() { int a=digitalReadFast(ENC_BL_A), b=digitalReadFast(ENC_BL_B); encBL += (a!=b)?+1:-1; }
void isrBR_A() { int a=digitalReadFast(ENC_BR_A), b=digitalReadFast(ENC_BR_B); encBR += (a==b)?+1:-1; }
void isrBR_B() { int a=digitalReadFast(ENC_BR_A), b=digitalReadFast(ENC_BR_B); encBR += (a!=b)?+1:-1; }

// =====================
// ===== 被災者停止（5秒）=====
// =====================
const uint32_t VICTIM_STOP_MS = 5000;
uint32_t victimStopUntilMs = 0;
static bool victimEventHoldActive = false; // VACK,OK後、SUBからVENDが来るまで停止イベントを保持

static inline bool victimStopActive() {
  bool isMinStopActive = (victimStopUntilMs != 0) && ((int32_t)(millis() - victimStopUntilMs) < 0);
  return isMinStopActive || victimEventHoldActive;
}
static inline void victimStopTrigger() {
  if (t180ActionActive()) return;
  victimEventHoldActive = true;
  uint32_t newDeadline = millis() + VICTIM_STOP_MS;
  if (victimStopUntilMs == 0 || (int32_t)(newDeadline - victimStopUntilMs) > 0) {
    victimStopUntilMs = newDeadline;
  }
}

// =====================
// ★フラグ類（T180）
// =====================
static bool t180Pending = false;
static bool t180Active  = false;   // T180/T180BKの実行中だけtrue
static bool t180DidAction = false;
static bool t180IsBackCommand = false;

static inline bool t180ActionActive() { return t180Active; }

static bool gAbortDrive = false;

static bool gStraightActive = false;
static long gStraightAvgPulses = 0;
static bool gStraightCoordUpdated = false;

// =====================
// ★両タッチ→ジャイロ補正（直進時のみ。旋回中は完全無視）
// =====================
static bool gGyroResetPending = false;
static float gGyroPreYaw = 0.0f;
static bool gGyroHasPreYaw = false;

static const uint32_t BOTH_TOUCH_GAP_MS = 1500;

static bool gPrevTouchL = false;
static bool gPrevTouchR = false;

static bool gSeenL = false;
static bool gSeenR = false;
static uint32_t gSeenStartMs = 0;

static bool gBothLockout = false;

static bool gAbortByBothTouch = false;

// ソフト補正 大ズレ連続回数（>=5°が2回連続→2回目で物理RST）
static int gLargeSoftCount = 0;

// 両タッチ後、直進中のみ3cmバック
static bool gDoBack3cmPending = false;

// ===== 回転中の制御 =====
static bool gTurningActive = false;

// 回転中断/回転スタック失敗 → 次に拡張左手法へ回す
static bool gNeedReDecideAtStop = false;

// =====================
// ★壁アタック：boot時間起点の「30秒スロット」管理
// =====================
static uint32_t bootMs = 0;

static inline bool isNormalExplorationComplete() {
  return !hasFrontierInNormalZone();
}

static inline void enterReturnMode(const char* reason) {
  if (missionComplete) return;

  frontierTargetMode = false;
  frontierTargetZone = ZONE_UNKNOWN;

  if (!returnMode) {
    returnMode = true;

    Serial.print("RETURN: ");
    Serial.println(reason ? reason : "UNKNOWN");
  }

  if (!returnNotifiedToSub) {
    Serial1.print("RETURN\n");
    returnNotifiedToSub = true;
  }
}

static inline bool shouldReturnBecauseNormalDoneNoRed() {
  if (returnMode || inRedZone || hasKnownRedEntrance()) return false;
  if (isNormalExplorationComplete()) return true;

  // RETURNに入れない理由を見える化する。
  reportFrontierBlockingReturn(ZONE_NORMAL, "RETURN_WAIT_FRONTIER");
  return false;
}

static inline bool isRedEntryAllowedNow() {
  if (inRedZone) return true;

  // 通常条件：ノーマルゾーンの未探索がなくなったら赤入口を解禁する。
  if (hasKnownRedEntrance() && isNormalExplorationComplete()) return true;

  // 保険条件：5分経過してもレッドゾーン未突入なら赤入口を解禁する。
  return (uint32_t)(millis() - bootMs) >= RED_ENTRY_START_DELAY_MS;
}

static inline bool shouldRedTargetMode() {
  return (!returnMode && !inRedZone && hasKnownRedEntrance() && isRedEntryAllowedNow());
}

static bool redRecoveryTimeShouldStart() {
  if (!inRedZone) return false;
  if (returnMode || redNormalConfirmMode || redRecoverySearchMode) return false;
  return (uint32_t)(millis() - bootMs) >= RED_RECOVERY_TIME_MS;
}

static inline bool shouldStartRedExitMode() {
  if (returnMode || !inRedZone || redExitMode) return false;
  if (!hasFrontierInRedZone()) return true;

  reportFrontierBlockingReturn(ZONE_RED, "RED_WAIT_FRONTIER");
  return false;
}

static inline void startRedExitMode(const char* reason) {
  if (returnMode || !inRedZone) return;
  frontierTargetMode = false;
  frontierTargetZone = ZONE_UNKNOWN;

  if (!redExitMode) {
    redExitMode = true;
    Serial.print("RED_EXIT: ");
    Serial.println(reason ? reason : "R_DONE");
  }
}

static uint32_t nextWallHitSlot = 0;  // 0スロットから対象（0,1,2,...）
static const uint32_t WALL_HIT_PERIOD_MS = 30000UL; // ★30秒ごと
static const bool ENABLE_PROACTIVE_WALL_HIT_AT_STOP = true; // ★定期壁アタックON：青/赤タイル関連状態では禁止  （切り分け時：停止中の定期壁アタックを完全OFF）

// =====================
// ===== SDカード保存 =====
// =====================
static bool initSdSave() {
  if (gSdReady) return true;

  if (!SD.begin(BUILTIN_SDCARD)) {
    gSdReady = false;
    Serial.println("SD init failed");
    return false;
  }

  gSdReady = true;
  Serial.println("SD init OK");
  return true;
}

static void clearSdSaveFile() {
  // SUBが起動直後に複数回SDCLRを送るため、1回だけ処理する。
  if (gSdClearHandledThisBoot) return;
  gSdClearHandledThisBoot = true;

  if (!initSdSave()) {
    Serial.println("SD clear skipped: SD not ready");
    showSdStatusForMs("SD ERR", SD_STATUS_DISPLAY_MS);
    return;
  }

  SD.remove(SD_SAVE_FILE);
  gSdSaveLocked = false;
  gRedNcSnapshotValid = false;

  Serial.println("SD save file cleared");
  showSdStatusForMs("SD CLR", SD_STATUS_DISPLAY_MS);
}

static bool readSdLine(File &f, char* line, size_t lineLen) {
  if (lineLen == 0) return false;
  if (!f.available()) return false;

  size_t n = f.readBytesUntil('\n', line, lineLen - 1);
  line[n] = '\0';

  // CR/LF、末尾スペース、タブを落とす
  while (n > 0 && (line[n - 1] == '\r' || line[n - 1] == '\n' || line[n - 1] == ' ' || line[n - 1] == '\t')) {
    line[n - 1] = '\0';
    n--;
  }
  return true;
}

static void resetMapForSdLoad() {
  memset(visitCnt, 0, sizeof(visitCnt));
  memset(victimFlag, 0, sizeof(victimFlag));
  memset(blueFlag, 0, sizeof(blueFlag));
  memset(redFlag, 0, sizeof(redFlag));
  memset(redEntranceInfo, 0, sizeof(redEntranceInfo));
  redEntranceInfoCount = 0;
  memset(bumpFlag, 0, sizeof(bumpFlag));
  memset(zoneFlag, 0, sizeof(zoneFlag));
  memset(wallKnownMap, 0, sizeof(wallKnownMap));
  memset(wallExistMap, 0, sizeof(wallExistMap));
  memset(XY_Number, 0xFF, sizeof(XY_Number));
  memset(Red_Number, 0xFF, sizeof(Red_Number));
  memset(Frontier_Number, 0xFF, sizeof(Frontier_Number));
  memset(floorLinkMap, 0, sizeof(floorLinkMap));
  memset(floorLinkDirMap, FLOOR_LINK_DIR_NONE, sizeof(floorLinkDirMap));
  memset(floorLinkTargetXMap, 0, sizeof(floorLinkTargetXMap));
  memset(floorLinkTargetYMap, 0, sizeof(floorLinkTargetYMap));
  memset(floorConnectorOnlyMap, 0, sizeof(floorConnectorOnlyMap));
  memset(slopeExitIgnoreUnknownMap, 0, sizeof(slopeExitIgnoreUnknownMap));
  memset(slopeTransitCellMap, 0, sizeof(slopeTransitCellMap));
  memset(slopeDownExitNoSideReadMap, 0, sizeof(slopeDownExitNoSideReadMap));
  currentFloor = FLOOR_1ST;
  frontierTargetMode = false;
  frontierTargetZone = ZONE_UNKNOWN;
  gFrontierFallbackExtLH = false;
  floorAssigned[0] = true; floorAssigned[1] = false; floorAssigned[2] = false;
  floorHeight[0] = 0; floorHeight[1] = FLOOR_HEIGHT_UNKNOWN; floorHeight[2] = FLOOR_HEIGHT_UNKNOWN;
}

static bool loadMazeCheckpointFromSd() {
  gSdLoadSucceededThisBoot = false;
  gSdLoadedElapsedMs = 0;

  if (!initSdSave()) {
    Serial.println("SD load failed: SD not ready");
    return false;
  }

  if (!SD.exists(SD_SAVE_FILE)) {
    Serial.println("SD load skipped: file not found");
    return false;
  }

  File f = SD.open(SD_SAVE_FILE, FILE_READ);
  if (!f) {
    Serial.println("SD load failed: open failed");
    return false;
  }

  resetMapForSdLoad();

  bool hasHeader = false;
  bool hasElapsed = false;
  bool hasEnd = false;
  bool savedLock = false;
  uint32_t savedElapsedMs = 0;
  uint16_t loadedCellCount = 0;

  char line[128];
  while (readSdLine(f, line, sizeof(line))) {
    if (line[0] == '\0') continue;
    if (line[0] == '#') continue;

    if (strcmp(line, "TOKAI_SUSANO_SAVE_V1") == 0) {
      hasHeader = true;
      continue;
    }

    if (strncmp(line, "elapsedMs=", 10) == 0) {
      savedElapsedMs = (uint32_t)strtoul(line + 10, NULL, 10);
      hasElapsed = true;
      continue;
    }

    if (strncmp(line, "saveLockedAfterThis=", 20) == 0) {
      savedLock = (atoi(line + 20) != 0);
      continue;
    }

    if (strncmp(line, "CELLF,", 6) == 0 || strncmp(line, "CELL,", 5) == 0) {
      // CELLFは3フロア対応の新形式。CELLは旧形式として1stへ読み込む。
      int floor = FLOOR_1ST;
      int x = 0, y = 0;
      unsigned long visit = 0;
      unsigned long victim = 0;
      unsigned long blue = 0;
      unsigned long red = 0;
      unsigned long xyNo = XY_NUMBER_INF;
      unsigned long redNo = RED_NUMBER_INF;
      unsigned long wallKnownBits = 0;
      unsigned long wallExistBits = 0;
      unsigned long floorLinks = 0;
      unsigned long floorLinkDirs = 0;
      unsigned long connectorOnly = 0;
      unsigned long slopeExitIgnore = 0;
      unsigned long slopeTransit = 0;
      unsigned long slopeDownNoSideRead = 0;
      unsigned long floorLinkTargetXPacked = 0;
      unsigned long floorLinkTargetYPacked = 0;
      int n = 0;

      if (strncmp(line, "CELLF,", 6) == 0) {
        n = sscanf(line, "CELLF,%d,%d,%d,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu",
                   &floor, &x, &y, &visit, &victim, &blue, &red, &xyNo, &redNo, &wallKnownBits, &wallExistBits, &floorLinks, &floorLinkDirs, &connectorOnly, &slopeExitIgnore, &slopeTransit, &slopeDownNoSideRead, &floorLinkTargetXPacked, &floorLinkTargetYPacked);
      } else {
        n = sscanf(line, "CELL,%d,%d,%lu,%lu,%lu,%lu,%lu,%lu,%lu,%lu",
                   &x, &y, &visit, &victim, &blue, &red, &xyNo, &redNo, &wallKnownBits, &wallExistBits);
        floor = FLOOR_1ST;
      }

      if ((n == 10 || n == 12 || n == 13 || n == 14 || n == 15 || n == 16 || n == 17 || n == 19) && floorIndexInRange((uint8_t)floor) && visInRange(x, y)) {
        int mx = x + VIS_OX;
        int my = y + VIS_OY;
        uint8_t fl = (uint8_t)floor;

        if (visit > 65535UL) visit = 65535UL;
        if (xyNo > 65535UL) xyNo = 65535UL;
        if (redNo > 65535UL) redNo = 65535UL;

        floorAssigned[fl] = true;
        if (fl == FLOOR_1ST) floorHeight[fl] = 0;
        else if (floorHeight[fl] == FLOOR_HEIGHT_UNKNOWN) floorHeight[fl] = (fl == FLOOR_2ND) ? 1 : -1;

        visitCnt[fl][my][mx] = (uint16_t)visit;
        victimFlag[fl][my][mx] = (victim != 0) ? 1 : 0;
        blueFlag[fl][my][mx] = (blue != 0) ? 1 : 0;
        redFlag[fl][my][mx] = (red != 0) ? 1 : 0;
        if (redFlag[fl][my][mx]) zoneFlag[fl][my][mx] = ZONE_RED;
        else if (visitCnt[fl][my][mx] != 0) zoneFlag[fl][my][mx] = ZONE_NORMAL;
        XY_Number[fl][my][mx] = (uint16_t)xyNo;
        Red_Number[fl][my][mx] = (uint16_t)redNo;
        wallKnownMap[fl][my][mx] = (uint8_t)(wallKnownBits & 0x0F);
        wallExistMap[fl][my][mx] = (uint8_t)(wallExistBits & 0x0F);
        floorLinkMap[fl][my][mx] = (uint8_t)(floorLinks & 0x07);
        if (n >= 13) floorLinkDirsUnpackByIndex(fl, mx, my, (uint16_t)(floorLinkDirs & 0x01FF));
        if (n >= 14) floorConnectorOnlyMap[fl][my][mx] = (connectorOnly != 0) ? 1 : 0;
        if (n >= 15) slopeExitIgnoreUnknownMap[fl][my][mx] = (uint8_t)(slopeExitIgnore & 0x0F);
        if (n >= 16) {
          // 0=なし / 1=SL / 2=SL+LOW / 3=SL+HIGH。旧データの0以外はSLとして読む。
          slopeTransitCellMap[fl][my][mx] = (slopeTransit <= 3) ? (uint8_t)slopeTransit : ((slopeTransit != 0) ? 1 : 0);
        }
        if (n >= 17) slopeDownExitNoSideReadMap[fl][my][mx] = (uint8_t)(slopeDownNoSideRead & 0x0F);
        if (n >= 19) {
          floorLinkTargetsUnpackByIndex(fl, mx, my, (uint32_t)floorLinkTargetXPacked, (uint32_t)floorLinkTargetYPacked);
        } else {
          // 旧形式は同じX,Yリンクとして補完する。
          for (uint8_t tf = 0; tf < FLOOR_COUNT; tf++) {
            if ((floorLinkMap[fl][my][mx] & (uint8_t)(1u << tf)) != 0) {
              floorLinkTargetSetByIndex(fl, mx, my, tf, x, y);
            }
          }
        }
        loadedCellCount++;
      }
      continue;
    }

    if (strcmp(line, "END") == 0) {
      hasEnd = true;
      break;
    }
  }

  f.close();

  if (!hasHeader) {
    Serial.println("SD load failed: bad header");
    resetMapForSdLoad();
    visitCnt[FLOOR_1ST][VIS_OY][VIS_OX] = 1;
    XY_Number[FLOOR_1ST][VIS_OY][VIS_OX] = 0;
    zoneSet(0, 0, ZONE_NORMAL);
    return false;
  }

  if (!hasEnd) {
    Serial.println("SD load warning: END not found");
  }

  if (!hasElapsed) {
    savedElapsedMs = 0;
  }

  // 今回は「スタート地点から再スタート」前提なので、保存時のpos/directionは使わない。
  posX = 0;
  posY = 0;
  direction = 0;
  currentFloor = FLOOR_1ST;

  // 走行状態は再スタート用に安全側へ戻す。
  homeArmed = false;
  homePending = false;
  returnMode = false;
  missionComplete = false;
  returnNotifiedToSub = false;
  inRedZone = false;
  redExitMode = false;
  redExitLeavePending = false;

  // 赤保存後の「以後保存しない」は維持する。
  gSdSaveLocked = savedLock;

  // 起動後の経過時間を、保存時刻から再開する。
  gSdLoadedElapsedMs = savedElapsedMs;
  bootMs = (uint32_t)(millis() - savedElapsedMs);

  // 念のため、スタートマスは訪問済み・XY=0を保証する。
  if (visitCnt[FLOOR_1ST][VIS_OY][VIS_OX] == 0) visitCnt[FLOOR_1ST][VIS_OY][VIS_OX] = 1;
  XY_Number[FLOOR_1ST][VIS_OY][VIS_OX] = 0;
  zoneSet(0, 0, ZONE_NORMAL);

  // 壁と赤入口から番号マップを再構築して整合性を取る。
  rebuildXY_NumberAll();
  rebuildRed_NumberAll();

  gSdLoadSucceededThisBoot = true;

  Serial.print("SD load OK: cells=");
  Serial.print(loadedCellCount);
  Serial.print(" elapsedMs=");
  Serial.println(savedElapsedMs);

  return true;
}

static bool shouldSaveCellFloor(uint8_t floor, int x, int y) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return false;

  int mx = x + VIS_OX;
  int my = y + VIS_OY;

  if (visitCnt[floor][my][mx] != 0) return true;
  if (victimFlag[floor][my][mx] != 0) return true;
  if (blueFlag[floor][my][mx] != 0) return true;
  if (redFlag[floor][my][mx] != 0) return true;
  if (wallKnownMap[floor][my][mx] != 0) return true;
  if (wallExistMap[floor][my][mx] != 0) return true;
  if (XY_Number[floor][my][mx] != XY_NUMBER_INF) return true;
  if (Red_Number[floor][my][mx] != RED_NUMBER_INF) return true;
  if ((floorLinkMap[floor][my][mx] & 0x07) != 0) return true;
  if (floorConnectorOnlyMap[floor][my][mx] != 0) return true;
  if ((slopeExitIgnoreUnknownMap[floor][my][mx] & 0x0F) != 0) return true;
  if (slopeTransitCellMap[floor][my][mx] != 0) return true;
  if ((slopeDownExitNoSideReadMap[floor][my][mx] & 0x0F) != 0) return true;

  return false;
}


static bool saveMazeCheckpoint(const char* reason, bool lockAfterSave) {
  // 赤タイル保存後は、青でも赤でも保存しない。
  if (gSdSaveLocked) return false;

  if (!initSdSave()) {
    Serial.println("SD save skipped: SD not ready");
    return false;
  }

  // SDへ出す直前に番号マップを最新化する。
  rebuildXY_NumberAll();
  rebuildRed_NumberAll();

  // 最新状態1個だけを残すため、必ず上書きする。
  SD.remove(SD_SAVE_FILE);
  File f = SD.open(SD_SAVE_FILE, FILE_WRITE);
  if (!f) {
    Serial.println("SD save failed: open failed");
    return false;
  }

  uint32_t elapsedMs = millis() - bootMs;

  f.println("TOKAI_SUSANO_SAVE_V1");
  f.print("reason="); f.println(reason);
  f.print("elapsedMs="); f.println(elapsedMs);
  f.print("posX="); f.println(posX);
  f.print("posY="); f.println(posY);
  f.print("direction="); f.println(direction);
  f.print("visitCurrent="); f.println(visGet(posX, posY));
  f.print("victimCurrent="); f.println(vicGet(posX, posY));
  f.print("blueCurrent="); f.println(blueGet(posX, posY));
  f.print("redCurrent="); f.println(redGet(posX, posY));
  f.print("xyCurrent="); f.println(xyNumberGet(posX, posY));
  f.print("redNumberCurrent="); f.println(redNumberGet(posX, posY));
  f.print("inRedZone="); f.println(inRedZone ? 1 : 0);
  f.print("saveLockedAfterThis="); f.println(lockAfterSave ? 1 : 0);
  f.print("returnMode="); f.println(returnMode ? 1 : 0);
  f.print("missionComplete="); f.println(missionComplete ? 1 : 0);
  f.print("currentFloor="); f.println(currentFloor);
  f.println("# CELLF,floor,x,y,visit,victim,blue,red,xyNo,redNo,wallKnownBits,wallExistBits,floorLinks,floorLinkDirs,connectorOnly,slopeExitIgnoreMask,slopeTransitCell,slopeDownNoSideReadMask,floorLinkTargetXPacked,floorLinkTargetYPacked");

  uint16_t cellCount = 0;
  for (uint8_t floor = 0; floor < FLOOR_COUNT; floor++) {
    for (int my = 0; my < VIS_H; my++) {
      for (int mx = 0; mx < VIS_W; mx++) {
        int x = mx - VIS_OX;
        int y = my - VIS_OY;
        if (!shouldSaveCellFloor(floor, x, y)) continue;

        cellCount++;
        f.print("CELLF,");
        f.print(floor); f.print(',');
        f.print(x); f.print(',');
        f.print(y); f.print(',');
        f.print(visitCnt[floor][my][mx]); f.print(',');
        f.print(victimFlag[floor][my][mx]); f.print(',');
        f.print(blueFlag[floor][my][mx]); f.print(',');
        f.print(redFlag[floor][my][mx]); f.print(',');
        f.print(XY_Number[floor][my][mx]); f.print(',');
        f.print(Red_Number[floor][my][mx]); f.print(',');
        f.print(wallKnownMap[floor][my][mx]); f.print(',');
        f.print(wallExistMap[floor][my][mx]); f.print(',');
        f.print(floorLinkMap[floor][my][mx] & 0x07); f.print(',');
        f.print(floorLinkDirsPackByIndex(floor, mx, my)); f.print(',');
        f.print(floorConnectorOnlyMap[floor][my][mx]); f.print(',');
        f.print(slopeExitIgnoreUnknownMap[floor][my][mx] & 0x0F); f.print(',');
        f.print(slopeTransitCellMap[floor][my][mx]); f.print(',');
        f.print(slopeDownExitNoSideReadMap[floor][my][mx] & 0x0F); f.print(',');
        f.print(floorLinkTargetsXPackByIndex(floor, mx, my)); f.print(',');
        f.println(floorLinkTargetsYPackByIndex(floor, mx, my));
      }
    }
  }

  f.print("cellCount="); f.println(cellCount);
  f.println("END");
  f.flush();
  f.close();

  if (lockAfterSave) gSdSaveLocked = true;

  Serial.print("SD save OK: ");
  Serial.print(reason);
  Serial.print(" cells=");
  Serial.println(cellCount);

  return true;
}


// ★前壁「近づいた瞬間」イベント
static bool gFrontWallLatched = false;
static bool gFrontWallApproachEvent = false;

// ===== ToF更新シーケンス（壁投票用）=====
static uint32_t gSubTofSeq = 0;
static uint32_t gMainTofSeq = 0;
static uint32_t gMainTofLastSeqMs = 0;

// ===== 16〜24cm 壁投票 =====
static uint8_t gWallVoteWallCnt[4] = {0, 0, 0, 0}; // N,E,S,W
static uint8_t gWallVoteOpenCnt[4] = {0, 0, 0, 0}; // N,E,S,W
static bool gWallVoteAnySample = false;
static bool gWallVoteFinalized = false;
static int gWallVoteTargetX = 0;
static int gWallVoteTargetY = 0;
static uint32_t gWallVoteLastSubSeq = 0;
static uint32_t gWallVoteLastMainSeq = 0;

// =====================
// ===== OLED: HUD表示 =====
// =====================
const uint32_t DISP_INTERVAL_MS = 100;
uint32_t lastDispMs = 0;

static void drawWallMiniIcon(int x, int y, int size) {
  if (size < 3) return;

  const int last = size - 1;
  const int cx = x + (last / 2);
  const int cy = y + (last / 2);

  uint8_t sFront = wallStateGet(posX, posY, direction);
  uint8_t sRight = wallStateGet(posX, posY, (direction + 1) & 3);
  uint8_t sBack  = wallStateGet(posX, posY, (direction + 2) & 3);
  uint8_t sLeft  = wallStateGet(posX, posY, (direction + 3) & 3);

  if (sFront == WALL_STATE_BLOCKED) oled.drawFastHLine(x, y, size, SSD1306_WHITE);
  else if (sFront == WALL_STATE_UNKNOWN) oled.drawPixel(cx, y, SSD1306_WHITE);

  if (sRight == WALL_STATE_BLOCKED) oled.drawFastVLine(x + last, y, size, SSD1306_WHITE);
  else if (sRight == WALL_STATE_UNKNOWN) oled.drawPixel(x + last, cy, SSD1306_WHITE);

  if (sBack == WALL_STATE_BLOCKED) oled.drawFastHLine(x, y + last, size, SSD1306_WHITE);
  else if (sBack == WALL_STATE_UNKNOWN) oled.drawPixel(cx, y + last, SSD1306_WHITE);

  if (sLeft == WALL_STATE_BLOCKED) oled.drawFastVLine(x, y, size, SSD1306_WHITE);
  else if (sLeft == WALL_STATE_UNKNOWN) oled.drawPixel(x, cy, SSD1306_WHITE);
}

static void drawFrontierStatusOnHud() {
  bool normalFrontier = hasFrontierInNormalZone();
  bool redFrontier = hasFrontierInRedZone();

  oled.setTextSize(1);
  oled.setCursor(98, 0);

  if (gFrontierFallbackExtLH) {
    oled.print("FBK");
    return;
  }

  oled.print("N");
  oled.print(normalFrontier ? "+" : "-");

  oled.print("R");
  oled.print(redFrontier ? "+" : "-");
}

static inline bool isAnyFrontierCellForOLED(uint8_t floor, int x, int y) {
  return isFrontierCellForZoneFloor(floor, x, y, ZONE_NORMAL) ||
         isFrontierCellForZoneFloor(floor, x, y, ZONE_RED);
}

static uint16_t countFrontierForOLEDFloor(uint8_t floor) {
  if (!floorAssigned[floor]) return 0;

  uint16_t count = 0;
  for (int my = 0; my < VIS_H; my++) {
    for (int mx = 0; mx < VIS_W; mx++) {
      int x = mx - VIS_OX;
      int y = my - VIS_OY;
      if (isAnyFrontierCellForOLED(floor, x, y)) count++;
    }
  }
  return count;
}

static uint16_t collectFrontierCoordsForOLED(uint8_t outFloor[3], int outX[3], int outY[3]) {
  uint16_t count = 0;

  for (uint8_t floor = 0; floor < FLOOR_COUNT; floor++) {
    if (!floorAssigned[floor]) continue;
    for (int my = 0; my < VIS_H; my++) {
      for (int mx = 0; mx < VIS_W; mx++) {
        int x = mx - VIS_OX;
        int y = my - VIS_OY;
        if (!isAnyFrontierCellForOLED(floor, x, y)) continue;

        if (count < 3) {
          outFloor[count] = floor;
          outX[count] = x;
          outY[count] = y;
        }
        count++;
      }
    }
  }
  return count;
}

static void drawFrontierCoordListOnHud() {
  uint8_t fs[3] = {0, 0, 0};
  int xs[3] = {0, 0, 0};
  int ys[3] = {0, 0, 0};

  uint16_t floorCount[FLOOR_COUNT] = {0, 0, 0};
  uint16_t totalCount = 0;
  for (uint8_t floor = 0; floor < FLOOR_COUNT; floor++) {
    floorCount[floor] = countFrontierForOLEDFloor(floor);
    totalCount += floorCount[floor];
  }

  oled.setTextSize(1);

  if (totalCount == 0) {
    oled.setCursor(84, 18);
    oled.print("FR--");
    return;
  }

  // 2026.5.17：4か所以上ある場合は、未探索の総数をフロア別に表示する。
  // 例：FR1:5 / FR2:1。F1側に2F座標が混ざる不具合の確認用。
  if (totalCount > 3) {
    uint8_t row = 0;
    for (uint8_t floor = 0; floor < FLOOR_COUNT && row < 4; floor++) {
      if (!floorAssigned[floor] && floorCount[floor] == 0) continue;
      oled.setCursor(84, 18 + (int)row * 10);
      oled.print("FR");
      oled.print((unsigned)(floor + 1));
      oled.print(":");
      oled.print((unsigned)floorCount[floor]);
      row++;
    }
    return;
  }

  uint16_t count = collectFrontierCoordsForOLED(fs, xs, ys);
  oled.setCursor(84, 18);
  oled.print("FR");

  for (uint8_t i = 0; i < count && i < 3; i++) {
    oled.setCursor(84, 28 + (int)i * 10);
    // 表示スペース節約のため、階数を1桁で付ける。例：1:5,1
    oled.print((unsigned)(fs[i] + 1));
    oled.print(":");
    oled.print(xs[i]);
    oled.print(",");
    oled.print(ys[i]);
  }
}

static void drawHudScreen() {
  oled.clearDisplay();
  oled.setTextWrap(false);
  oled.setTextColor(SSD1306_WHITE);

  oled.setTextSize(1);
  oled.setCursor(0, 0);
  oled.print("Y:");
  oled.print(yawDeg, 1);
  oled.setCursor(50, 0);
  oled.print("P:");
  oled.print(pitchDeg, 1);
  oled.setCursor(108, 8);
  oled.print("F");
  oled.print((unsigned)(currentFloor + 1));

  char coord[20];
  snprintf(coord, sizeof(coord), "%d,%d", posX, posY);
  int clen = (int)strlen(coord);

  int coordSize = 4;
  if (clen >= 6) coordSize = 3;
  if (clen >= 8) coordSize = 2;
  if (clen >= 12) coordSize = 1;

  int cx = 0; // 2026.5.17：未探索座標を右側へ出すため、現在座標は左寄せにする。

  int cy = 14;
  oled.setTextSize(coordSize);
  oled.setCursor(cx, cy);
  oled.print(coord);

  drawFrontierCoordListOnHud();

  uint16_t vcnt = visGet(posX, posY);
  bool hasV = (vicGet(posX, posY) != 0);
  bool hasB = (blueGet(posX, posY) != 0);
  bool hasR = (redGet(posX, posY) != 0);
  bool hasBP = (bumpGet(posX, posY) != 0);
  bool isSL = slopeTransitCellGetFloor(currentFloor, posX, posY);

  char info[32];
  snprintf(info, sizeof(info), "%c,%u", dirChar(direction), (unsigned)vcnt);
  if (hasBP) strncat(info, " BP", sizeof(info) - strlen(info) - 1);
  if (hasV) strncat(info, ",V", sizeof(info) - strlen(info) - 1);
  if (hasB) strncat(info, ",B", sizeof(info) - strlen(info) - 1);
  if (hasR) strncat(info, ",R", sizeof(info) - strlen(info) - 1);
  if (isSL) {
    strncat(info, ",SL", sizeof(info) - strlen(info) - 1);
    uint8_t slopeExtraMode = slopeTransitCellUpExtraModeGetFloor(currentFloor, posX, posY);
    if (slopeExtraMode == 2) strncat(info, ",HIGH", sizeof(info) - strlen(info) - 1);
    else if (slopeExtraMode == 1) strncat(info, ",LOW", sizeof(info) - strlen(info) - 1);
  }

  int ilen = (int)strlen(info);
  int infoSize = 2;
  if (ilen >= 8) infoSize = 1;

  int infoW = ilen * 6 * infoSize;
  int ix = (SCREEN_WIDTH - infoW) / 2;
  if (ix < 0) ix = 0;

  int coordH = coordSize * 8;
  int iy = cy + coordH + 2;
  int infoH = infoSize * 8;
  if (iy + infoH > SCREEN_HEIGHT) {
    infoSize = 1; infoH = 8; iy = SCREEN_HEIGHT - infoH;
  }

  oled.setTextSize(infoSize);
  oled.setCursor(ix, iy);
  oled.print(info);

  drawWallMiniIcon(1, SCREEN_HEIGHT - 14, 13);

  uint16_t xyNo = xyNumberGet(posX, posY);
  uint8_t xyDisp = (xyNo >= 100 || xyNo == XY_NUMBER_INF) ? 99 : (uint8_t)xyNo;
  char xyBuf[3];
  snprintf(xyBuf, sizeof(xyBuf), "%02u", (unsigned)xyDisp);
  oled.setTextSize(1);
  oled.setCursor(18, SCREEN_HEIGHT - 10);
  oled.print(xyBuf);

  if (gLocalizationActive) {
    oled.setTextSize(1);
    oled.setCursor(100, SCREEN_HEIGHT - 10);
    oled.print("M:");
    oled.print((unsigned)gLocalizationMoveCount);
    oled.print(" C:");
    if (gLocalizationHasCandidateCount) oled.print((unsigned)gLocalizationLastCandidateCount);
    else oled.print("--");
  } else {
    if (redNormalConfirmMode) {
      oled.setTextSize(1);
      oled.setCursor(100, SCREEN_HEIGHT - 10);
      oled.print("NC:");
      oled.print((unsigned)redNormalConfirmStepCount);
      oled.print(" C:");
      oled.print((unsigned)redNormalConfirmCandidateCount);
      oled.setCursor(100, SCREEN_HEIGHT - 20);
      oled.print("E");
      oled.print((unsigned)redEntranceInfoCount);
      oled.print("R");
      oled.print((unsigned)redNcSourceRedFlagCountAllFloors());
    }
    drawFrontierStatusOnHud();
    // 2026.5.23：通常は未探索座標表示を優先し、地形/バンプなどの一時ステータスだけ左下へ表示する。
    if (gSlopeStatusUntilMs != 0 && strcmp(gSlopeStatus, "FLAT") != 0) {
      drawSlopeStatusOnHud();
    }
    terrainClassHudService();
    if (terrainClassHudIsActive()) {
      drawTerrainClassStatusOnHud();
    }
    // 2026.5.23：バンプ補正LOW/MEDIUM/HIGHは、座標更新でSlope表示がFLATへ戻っても3秒間優先表示する。
    bumpCompHudService();
    if (bumpCompHudIsActive()) {
      drawBumpCompStatusOnHud();
    }
  }

  // 2026.5.31：試合開始からの経過分を右上に1桁表示する。
  // 0:00〜0:59=0、3:00〜3:59=3、9分以降は9で固定。
  // SD LOAD時はbootMsが復元済みelapsedMsぶん補正されるため、継続時間として表示される。
  uint32_t elapsedMinute = (uint32_t)(millis() - bootMs) / 60000UL;
  if (elapsedMinute > 9UL) elapsedMinute = 9UL;
  oled.fillRect(122, 0, 6, 8, SSD1306_BLACK);
  oled.setTextSize(1);
  oled.setCursor(122, 0);
  oled.print((unsigned)elapsedMinute);

  oled.display();
}

static void serviceOledHud() {
  uint32_t now = millis();
  if (now - lastDispMs < DISP_INTERVAL_MS) return;
  lastDispMs = now;
  drawHudScreen();
}

// =====================
// ===== モータ基本 =====
// =====================
static inline void stopMotors() {
  analogWrite(PWM_FL, 0); analogWrite(PWM_FR, 0); analogWrite(PWM_BL, 0); analogWrite(PWM_BR, 0);
}
static inline void setLR(int pwmL, int pwmR) {
  if (holdActive()) { stopMotors(); return; }
  pwmL = constrain(pwmL, 0, 255); pwmR = constrain(pwmR, 0, 255);
  analogWrite(PWM_FL, pwmL); analogWrite(PWM_BL, pwmL); analogWrite(PWM_FR, pwmR); analogWrite(PWM_BR, pwmR);
}
static inline void setLR_force(int pwmL, int pwmR) {
  pwmL = constrain(pwmL, 0, 255); pwmR = constrain(pwmR, 0, 255);
  analogWrite(PWM_FL, pwmL); analogWrite(PWM_BL, pwmL); analogWrite(PWM_FR, pwmR); analogWrite(PWM_BR, pwmR);
}

static inline bool tofValid(uint16_t mm) { return (mm != 0 && mm < 8000); }
// 2026.5.17：VL53L0Xの遠すぎ値は、左右ToFの壁投票では「壁なし」扱いにする。
// 0は通信/読取失敗の可能性があるため、OPEN扱いにしない。
static inline bool tofFarMeansOpen(uint16_t mm) { return (mm >= 8000); }

static inline bool cellHasUnknownWall(int x, int y) {
  if (!visInRange(x, y)) return false;
  for (uint8_t absDir = 0; absDir < 4; absDir++) {
    if (wallStateGet(x, y, absDir) == WALL_STATE_UNKNOWN) return true;
  }
  return false;
}

static inline bool shouldSpotCheckCurrentCellWalls() {
  if (redNormalConfirmMode) return false; // 座標未確定中は本物マップへ壁を書かない
  if (!visInRange(posX, posY)) return false;
  if (!cellHasUnknownWall(posX, posY)) return false;

  // スタート地点だけは1回目からその場判定を行う。
  if (posX == 0 && posY == 0) return true;

  // その他のマスは、2回目以降の訪問時だけその場判定で再確認する。
  return (visGet(posX, posY) >= UNKNOWN_WALL_FRONTIER_VISIT_LIMIT);
}

static void classifyCurrentCellWallsAtStop(bool onlyUnknown) {
  if (!visInRange(posX, posY)) return;

  // rel: 0=前, 1=右, 2=後, 3=左
  // 既存の壁投票と同じ対応に合わせる。
  const uint16_t relMm[4] = {distMm[2], distMm[1], distMm[5], distMm[0]};
  bool changed = false;

  for (uint8_t rel = 0; rel < 4; rel++) {
    uint8_t absDir = (direction + rel) & 3;
    if (onlyUnknown && wallStateGet(posX, posY, absDir) != WALL_STATE_UNKNOWN) continue;

    // 2026.5.17：下り坂を抜けた直後の平地マスでは、左右ToFで再確認しない。
    // 既にある壁情報は保持し、UNKNOWNならUNKNOWNのまま残す。
    if (slopeDownExitNoSideReadDirGetFloor(currentFloor, posX, posY, absDir)) continue;

    // 地形通過中/下り坂中は、誤読しやすい前ToF(S2)を壁判定から外す。
    if (rel == 0 && slopeShouldIgnoreFrontS2ForWallJudge()) continue;

    uint16_t mm = relMm[rel];
    if (!tofValid(mm)) continue;

    uint16_t threshold = spotWallThresholdForRel(rel);
    bool isWall = (mm < threshold);

    // 後ろToFは遠距離で一瞬だけ近距離誤値を返すことがあるため、
    // 後ろ方向(rel=2)のBLOCKED確定には使わない。
    // OPEN側は従来通り許可するが、通常は通過実績によるOPEN確定を優先する。
    if (rel == 2 && isWall) continue;

    wallSetKnownStateBoth(posX, posY, absDir, isWall);
    changed = true;
  }

  if (changed) {
    rebuildXY_NumberAll();
    rebuildRed_NumberAll();
  }
}

static void warmupAndClassifyStartCellWalls() {
  if (posX != 0 || posY != 0) return;
  if (gLocalizationActive) return;

  uint8_t wallCnt[4] = {0, 0, 0, 0}; // N,E,S,W
  uint8_t openCnt[4] = {0, 0, 0, 0}; // N,E,S,W

  // 2026.5.17：通常スタート地点はマス中央にいる前提なので、移動前に4方向を読む。
  // 従来のclassifyCurrentCellWallsAtStop()は後ろToF(S5)のBLOCKED確定を捨てるため、
  // スタート地点だけは専用の10回多数決で後ろ壁ありも記録する。
  for (uint8_t i = 0; i < WALL_VOTE_MAX_SAMPLES; i++) {
    serviceSubRx();
    serviceMainTof();
    imuUpdate();
    delay(20);

    const uint16_t relMm[4] = {distMm[2], distMm[1], distMm[5], distMm[0]}; // 前,右,後,左
    for (uint8_t rel = 0; rel < 4; rel++) {
      if (rel == 0 && slopeShouldIgnoreFrontS2ForWallJudge()) continue;

      uint16_t mm = relMm[rel];
      if (!tofValid(mm)) continue;

      uint8_t absDir = (direction + rel) & 3;
      uint16_t threshold = spotWallThresholdForRel(rel);
      if (mm < threshold) wallCnt[absDir]++;
      else                openCnt[absDir]++;
    }
  }

  bool changed = false;
  for (uint8_t absDir = 0; absDir < 4; absDir++) {
    uint8_t total = (uint8_t)(wallCnt[absDir] + openCnt[absDir]);
    if (total < WALL_VOTE_MIN_SAMPLES_LOCALIZE) continue;

    if (wallCnt[absDir] > openCnt[absDir]) {
      wallSetKnownStateBoth(posX, posY, absDir, true);
      changed = true;
    } else if (openCnt[absDir] > wallCnt[absDir]) {
      if (wallStateGet(posX, posY, absDir) != WALL_STATE_BLOCKED) {
        wallSetKnownStateBoth(posX, posY, absDir, false);
        changed = true;
      }
    }
  }

  if (changed) {
    rebuildXY_NumberAll();
    rebuildRed_NumberAll();
  }

  if (visInRange(posX, posY)) {
    int mx = posX + VIS_OX;
    int my = posY + VIS_OY;
    Serial.print("START WALL K=0x");
    Serial.print(wallKnownMap[currentFloor][my][mx], HEX);
    Serial.print(" E=0x");
    Serial.println(wallExistMap[currentFloor][my][mx], HEX);
  }
}

static inline bool holdActive() {
  return victimStopActive() || t180ActionActive();
}

// =====================
static void serviceMainTof() {
  // ★2026.5.1：回転中はMAIN側ToFを読まない
  // 目的：回転制御中のI2C読み取り負荷・一瞬の詰まりを避ける。
  // mainMm / distMm[5] は直前値を保持する。
  if (gTurningActive) {
    distMm[5] = mainMm;
    return;
  }

  uint16_t mm = tofMain.readRangeContinuousMillimeters();
  if (!tofMain.timeoutOccurred()) {
    mainMm = mm;
    uint32_t now = millis();
    if (now - gMainTofLastSeqMs >= 40) {
      gMainTofLastSeqMs = now;
      gMainTofSeq++;
    }
  }
  distMm[5] = mainMm;
}

// =====================
// ===== Hold/Delay =====
// =====================
static inline uint32_t holdBlock() {
  if (!holdActive()) return 0;
  stopMotors();
  uint32_t p0 = millis();
  while (holdActive()) {
    tickall();
    // 停止イベント保持中にT180/T180BKが来たら、その場で実行してACKを返す。
    // これにより、30cm移動中/90°回転中でも、VEND後に残り動作へ戻れる。
    if (t180Pending && !t180DidAction) {
      t180DidAction = true;
      t180Active = true;
      doT180ActionOnce();
      t180Active = false;
      t180Pending = false;
      t180DidAction = false;
      Serial1.print(t180IsBackCommand ? "T180BK,DONE\n" : "T180,DONE\n");
      stopMotors();
      continue;
    }
    delay(1);
    stopMotors();
  }
  return millis() - p0;
}

static inline void waitMs(uint32_t ms) {
  uint32_t t0 = millis();
  while (millis() - t0 < ms) {
    tickall();
    uint32_t paused = holdBlock();
    if (paused) t0 += paused;
    delay(1);
  }
}

// ===== 生PWMで指定距離だけ動かす（補正なし）=====
static void runRawDistance(bool forward, int pwmL, int pwmR, long targetPulses, uint32_t timeoutMs) {
  digitalWriteFast(DIR_FL, forward ? LOW  : HIGH);
  digitalWriteFast(DIR_FR, forward ? HIGH : LOW);
  digitalWriteFast(DIR_BL, forward ? LOW  : HIGH);
  digitalWriteFast(DIR_BR, forward ? HIGH : LOW);

  setLR(pwmL, pwmR);

  const long sFL = encFL, sFR = encFR, sBL = encBL, sBR = encBR;
  uint32_t t0 = millis();

  while (true) {
    tickall();
    uint32_t paused = holdBlock();
    if (paused) { t0 += paused; setLR(pwmL, pwmR); continue; }

    long aFL = labs(encFL - sFL);
    long aFR = labs(encFR - sFR);
    long aBL = labs(encBL - sBL);
    long aBR = labs(encBR - sBR);
    long avg = (aFL + aFR + aBL + aBR) / 4;

    if (avg >= targetPulses) break;
    if (millis() - t0 > timeoutMs) break;
  }
  stopMotors();
}

static void runRawDistanceForce(bool forward, int pwmL, int pwmR, long targetPulses, uint32_t timeoutMs) {
  digitalWriteFast(DIR_FL, forward ? LOW  : HIGH);
  digitalWriteFast(DIR_FR, forward ? HIGH : LOW);
  digitalWriteFast(DIR_BL, forward ? LOW  : HIGH);
  digitalWriteFast(DIR_BR, forward ? HIGH : LOW);

  setLR_force(pwmL, pwmR);

  const long sFL = encFL, sFR = encFR, sBL = encBL, sBR = encBR;
  uint32_t t0 = millis();

  while (true) {
    imuUpdate();
    serviceMainTof();
    serviceOledHud();
    delay(1);

    long aFL = labs(encFL - sFL);
    long aFR = labs(encFR - sFR);
    long aBL = labs(encBL - sBL);
    long aBR = labs(encBR - sBR);
    long avg = (aFL + aFR + aBL + aBR) / 4;

    if (avg >= targetPulses) break;
    if (millis() - t0 > timeoutMs) break;
  }
  stopMotors();
}

static inline void wallVoteReset() {
  for (int i = 0; i < 4; i++) {
    gWallVoteWallCnt[i] = 0;
    gWallVoteOpenCnt[i] = 0;
  }
  gWallVoteAnySample = false;
  gWallVoteFinalized = false;
  gWallVoteTargetX = posX;
  gWallVoteTargetY = posY;
  gWallVoteLastSubSeq = gSubTofSeq;
  gWallVoteLastMainSeq = gMainTofSeq;
}

static inline void wallVoteResolveTargetCell(long avgPulses, int &tx, int &ty) {
  if (gStraightCoordUpdated || avgPulses >= TARGET_20CM_PULSES) {
    tx = posX;
    ty = posY;
  } else {
    neighborByRel(0, posX, posY, direction, tx, ty);
  }
}

static inline void wallVoteTrySample(long avgPulses) {
  if (gWallVoteFinalized) return;
  if (avgPulses < WALL_VOTE_START_PULSES || avgPulses > WALL_VOTE_END_PULSES) return;

  if (gSubTofSeq == gWallVoteLastSubSeq && gMainTofSeq == gWallVoteLastMainSeq) return;

  gWallVoteLastSubSeq = gSubTofSeq;
  gWallVoteLastMainSeq = gMainTofSeq;

  int tx, ty;
  wallVoteResolveTargetCell(avgPulses, tx, ty);
  gWallVoteTargetX = tx;
  gWallVoteTargetY = ty;

  const uint16_t relMm[4] = {distMm[2], distMm[1], distMm[5], distMm[0]}; // 前,右,後,左
  for (uint8_t rel = 0; rel < 4; rel++) {
    // 2026.5.17：通常探索/ローカライズとも、16〜24cmでは左右だけ投票する。
    // 前後は30cm完了後の0.1秒停止中に classifyFrontBackAtStop() で読む。
    if (rel == 0 || rel == 2) continue;

    // 前ToF(S2)は上で除外済み。将来前方向を戻す場合に備え、下り坂ガードは残す。
    if (rel == 0 && slopeShouldIgnoreFrontS2ForWallJudge()) continue;

    uint16_t mm = relMm[rel];

    uint8_t absDir = (direction + rel) & 3; // N,E,S,Wに変換

    // 2026.5.17：下り坂「途中」は左右ToFを読む。
    // 理由：坂3マス中に左右がUNKNOWNのままだと、坂途中で左/右旋回することがあるため。
    // 下り坂を抜けた直後の平地マスだけ、左右ToFの壁投票を行わない。
    // 事前にその座標の壁情報があれば保持し、新しい壁あり/壁なし判定で上書きしない。
    if (slopeDownExitNoSideReadDirGetFloor(currentFloor, gWallVoteTargetX, gWallVoteTargetY, absDir)) continue;

    uint8_t total = (uint8_t)(gWallVoteWallCnt[absDir] + gWallVoteOpenCnt[absDir]);
    if (total >= WALL_VOTE_MAX_SAMPLES) continue;

    // 2026.5.17：左右ToFの16〜24cm壁投票では、170mm未満を壁あり、遠すぎ/計測上限値をOPEN投票にする。
    // 0は通信/読取失敗の可能性があるため、従来通り無視する。
    if (tofFarMeansOpen(mm)) {
      gWallVoteOpenCnt[absDir]++;
    } else if (tofValid(mm)) {
      if (mm < SPOT_SIDE_WALL_THRESHOLD_MM) {
        gWallVoteWallCnt[absDir]++;
      } else {
        gWallVoteOpenCnt[absDir]++;
      }
    } else {
      continue;
    }

    gWallVoteAnySample = true;
  }
}

static inline void wallVoteFinalize() {
  if (redRecoverySearchMode) { gWallVoteFinalized = true; return; }
  if (gWallVoteFinalized) return;
  gWallVoteFinalized = true;
  if (!gWallVoteAnySample) return;

  for (uint8_t absDir = 0; absDir < 4; absDir++) {
    // 2026.5.17：下り坂を抜けた直後の平地マスでは、左右ToFの投票結果を確定しない。
    // floorSwitchAfterSlope()より前に溜まった投票もここで捨て、既存情報はそのまま保持する。
    if (slopeDownExitNoSideReadDirGetFloor(currentFloor, gWallVoteTargetX, gWallVoteTargetY, absDir)) continue;

    uint8_t wallCnt = gWallVoteWallCnt[absDir];
    uint8_t openCnt = gWallVoteOpenCnt[absDir];
    uint8_t total = (uint8_t)(wallCnt + openCnt);

    uint8_t minSamples = gLocalizationActive ? WALL_VOTE_MIN_SAMPLES_LOCALIZE : WALL_VOTE_MIN_SAMPLES;
    if (total < minSamples) continue;
    if (wallCnt > openCnt) {
      // 既に通過済みと見なせるOPEN通路は、ToFの近距離誤値でBLOCKEDへ上書きしない。
      // 両タッチによる前壁確定は wallMarkFrontBlockedCurrentCell() 側で別処理なので、この保護の対象外。
      if (wallIsOpenBetweenVisitedCells(gWallVoteTargetX, gWallVoteTargetY, absDir)) continue;
      wallSetKnownStateBoth(gWallVoteTargetX, gWallVoteTargetY, absDir, true);
    } else if (openCnt > wallCnt) {
      // ★両タッチなどで既に「壁あり」へ上書き済みなら、そちらを優先
      if (wallStateGet(gWallVoteTargetX, gWallVoteTargetY, absDir) != WALL_STATE_BLOCKED) {
        wallSetKnownStateBoth(gWallVoteTargetX, gWallVoteTargetY, absDir, false);
      }
    }
    // 同数は不明のまま
  }
}

static inline void wallMarkFrontBlockedCurrentCell() {
  if (!gStraightActive) return;
  if (redRecoverySearchMode) return;
  wallSetKnownStateBoth(posX, posY, direction, true);
}

static inline void wallMarkForwardOpenByTraverse() {
  if (redRecoverySearchMode) return;
  int oldX, oldY;
  neighborByAbs(oppositeAbsDir(direction), posX, posY, oldX, oldY);
  wallSetKnownStateBoth(oldX, oldY, direction, false);
  refreshXY_NumberAfterForwardTraverse();
}

// =====================
// ★前壁「壁になった瞬間」判定（前ToF S2は130mm未満=壁）
// =====================
static inline bool frontIsWallNow() {
  if (slopeShouldIgnoreFrontS2ForWallJudge()) return false;

  uint16_t mm = distMm[2];
  if (mm == 0) return true;     // エラーは壁扱い
  return (mm < SPOT_FRONT_WALL_THRESHOLD_MM); // 前ToF S2は130mm未満で壁
}

static inline void updateFrontWallApproachEvent() {
  bool wall = frontIsWallNow();
  if (wall) {
    if (!gFrontWallLatched) {
      gFrontWallLatched = true;
      gFrontWallApproachEvent = true; // ★壁になった瞬間
    }
  } else {
    gFrontWallLatched = false;
    gFrontWallApproachEvent = false;
  }
}

// =====================
// ★両タッチ検出（最優先）
// =====================
static inline void triggerBothTouchEvent() {
  if (gBothLockout) return;

  // 2026.5.20：地形通過中は段差/階段への接触で両タッチが入っても停止・バックしない。
  if (terrainPassMotionLocked()) {
    gBothLockout = true;
    gSeenL = gSeenR = false;
    return;
  }

  // ★旋回中の両タッチは完全無視
  if (gTurningActive) {
    gBothLockout = true;
    gSeenL = gSeenR = false;
    return;
  }

  if (!gGyroResetPending) {
    gGyroResetPending = true;
    gGyroPreYaw = yawDeg;
    gGyroHasPreYaw = true;
  }

  gDoBack3cmPending = true;      // 直進中のみ3cmバック

  if (gStraightActive) {
    wallMarkFrontBlockedCurrentCell(); // ★保険：現在座標の前壁を壁ありに上書き
    gAbortByBothTouch = true;
  }

  gBothLockout = true;
  gSeenL = gSeenR = false;
}

static inline void serviceTouchLatch() {
  uint32_t now = millis();
  bool L = touchPressed(SW_L);
  bool R = touchPressed(SW_R);

  if (gBothLockout) {
    if (!L && !R) gBothLockout = false;
    gPrevTouchL = L;
    gPrevTouchR = R;
    return;
  }

  if (gTurningActive) {
    if (L && R) {
      gBothLockout = true;
      gSeenL = gSeenR = false;
    } else {
      bool Ledge = (L && !gPrevTouchL);
      bool Redge = (R && !gPrevTouchR);

      if (Ledge) {
        if (!gSeenL && !gSeenR) gSeenStartMs = now;
        gSeenL = true;
      }
      if (Redge) {
        if (!gSeenL && !gSeenR) gSeenStartMs = now;
        gSeenR = true;
      }

      if (gSeenL && gSeenR) {
        gBothLockout = true;
        gSeenL = gSeenR = false;
      } else {
        if ((gSeenL ^ gSeenR) && (now - gSeenStartMs > BOTH_TOUCH_GAP_MS)) {
          gSeenL = gSeenR = false;
        }
      }
    }

    gPrevTouchL = L;
    gPrevTouchR = R;
    return;
  }

  if (L && R) {
    triggerBothTouchEvent();
    gPrevTouchL = L;
    gPrevTouchR = R;
    return;
  }

  bool Ledge = (L && !gPrevTouchL);
  bool Redge = (R && !gPrevTouchR);

  if (Ledge) {
    if (!gSeenL && !gSeenR) gSeenStartMs = now;
    gSeenL = true;
  }
  if (Redge) {
    if (!gSeenL && !gSeenR) gSeenStartMs = now;
    gSeenR = true;
  }

  if (gSeenL && gSeenR) {
    triggerBothTouchEvent();
  } else {
    if ((gSeenL ^ gSeenR) && (now - gSeenStartMs > BOTH_TOUCH_GAP_MS)) {
      gSeenL = gSeenR = false;
    }
  }

  gPrevTouchL = L;
  gPrevTouchR = R;
}

// =====================
// ★ジャイロ補正（新方式）
// =====================
static void performGyroReset() {
  stopMotors();

  imuUpdate();
  float preYaw = gGyroHasPreYaw ? gGyroPreYaw : yawDeg;
  float targetYaw = chooseNearestCardinalYaw(preYaw);
  float diff = normalize180(preYaw - targetYaw);
  float err = fabsf(diff);

  if (err >= 5.0f) {
    gLargeSoftCount++;

    if (gLargeSoftCount >= 2) {
      // 物理RST（2回連続の2回目）
      oled.clearDisplay();
      oled.setTextWrap(false);
      oled.setTextColor(SSD1306_WHITE);
      oled.setTextSize(2);
      oled.setCursor(16, 24);
      oled.print("GYRO RST");
      oled.display();

      uint32_t tStart = millis();

      digitalWriteFast(PIN_RST, LOW);
      delay(50);
      digitalWriteFast(PIN_RST, HIGH);

      myIMU.begin(BNO08X_ADDR, Wire1, PIN_INT);

      // ★地磁気を使わないYawなら、環境に合わせてここを enableGameRotationVector(20) に変更
      myIMU.enableGameRotationVector(20);

      float rawYaw = 0.0f;
      float rawPitch = 0.0f;
      bool gotImu = false;
      isPitchTared = false;
      while (millis() - tStart < 1500) {
        if (myIMU.dataAvailable()) {
          rawYaw = myIMU.getYaw() * 180.0f / PI;
          rawPitch = (USE_ROLL_AS_PITCH ? myIMU.getRoll() : myIMU.getPitch()) * 180.0f / PI;
          gotImu = true;
        }
        delay(1);
      }

      yawOffset = rawYaw - targetYaw;
      yawDeg = targetYaw;
      isYawTared = true;
      if (gotImu) {
        pitchOffset = rawPitch;
        pitchDeg = 0.0f;
        isPitchTared = true;
      }

      gLargeSoftCount = 0;
      drawHudScreen();
    } else {
      // 1回目の5°以上はソフトスナップ
      yawOffset += diff;
      yawDeg = targetYaw;
      isYawTared = true;
    }
  } else {
    // 5°未満ならソフトスナップして連続カウントをリセット
    yawOffset += diff;
    yawDeg = targetYaw;
    isYawTared = true;

    gLargeSoftCount = 0;
  }

  gGyroResetPending = false;
  gGyroHasPreYaw = false;
}

// =====================
// Serial1受信（SUB→MAIN）
// =====================
static void serviceSubRx() {
  while (Serial1.available() > 0) {
    char c = (char)Serial1.read();
    if (c == '\r') continue;

    if (c == '\n') {
      rxBuf[rxLen] = '\0';

      // ===== 色分類チェック応答 =====
      if (strcmp(rxBuf, "CL,W") == 0) {
        gColorReplyReceived = true;
        gColorReplyCode = 'W';
        gColorReplyError = false;
        rxLen = 0;
        continue;
      }
      if (strcmp(rxBuf, "CL,K") == 0) {
        gColorReplyReceived = true;
        gColorReplyCode = 'K';
        gColorReplyError = false;
        rxLen = 0;
        continue;
      }
      if (strcmp(rxBuf, "CL,B") == 0) {
        gColorReplyReceived = true;
        gColorReplyCode = 'B';
        gColorReplyError = false;
        rxLen = 0;
        continue;
      }
      if (strcmp(rxBuf, "CL,R") == 0) {
        gColorReplyReceived = true;
        gColorReplyCode = 'R';
        gColorReplyError = false;
        rxLen = 0;
        continue;
      }
      if (strcmp(rxBuf, "CL,N") == 0) {
        gColorReplyReceived = true;
        gColorReplyCode = 'N';
        gColorReplyError = false;
        rxLen = 0;
        continue;
      }
      if (strcmp(rxBuf, "CL,ERR") == 0) {
        gColorReplyReceived = true;
        gColorReplyCode = 'N';
        gColorReplyError = true;
        rxLen = 0;
        continue;
      }

      // ===== 黒チェック応答 =====
      if (strcmp(rxBuf, "BK,1") == 0) {
        gBlackReplyReceived = true;
        gBlackReplyValue = true;
        gBlackReplyError = false;
        rxLen = 0;
        continue;
      }
      if (strcmp(rxBuf, "BK,0") == 0) {
        gBlackReplyReceived = true;
        gBlackReplyValue = false;
        gBlackReplyError = false;
        rxLen = 0;
        continue;
      }
      if (strcmp(rxBuf, "BK,ERR") == 0) {
        gBlackReplyReceived = true;
        gBlackReplyValue = false;
        gBlackReplyError = true;
        rxLen = 0;
        continue;
      }

      // ===== 被災者投下用T180/T180BK要求（ACKあり）=====
      if (strcmp(rxBuf, "T180") == 0 || strcmp(rxBuf, "T180BK") == 0) {
        // 2026.5.20：地形通過中/坂候補中は被災者系の割り込みを無効化する。
        // 坂・階段・ランプには被災者が置かれない前提で、姿勢制御と座標更新を優先する。
        if (terrainPassShouldSuppressColorVictim()) {
          rxLen = 0;
          continue;
        }
        if (!t180Pending && !t180Active) {
          t180IsBackCommand = (strcmp(rxBuf, "T180BK") == 0);
          t180Pending = true;
          t180DidAction = false;
          // gAbortDriveは立てない。停止イベント中にT180を実行し、VEND後に残りの30cm/回転へ戻す。
          stopMotors();
        }
        rxLen = 0;
        continue;
      }

      // ===== 被災者イベント終了通知 =====
      if (strcmp(rxBuf, "VEND") == 0) {
        victimEventHoldActive = false;
        victimStopUntilMs = 0;
        rxLen = 0;
        continue;
      }

      // ===== 被災者通知 =====
      if (rxBuf[0] == 'V' && rxBuf[1] == ',') {
        // 2026.5.20：地形通過中/坂候補中は被災者処理を無効化する。
        if (terrainPassShouldSuppressColorVictim()) {
          Serial1.print("VACK,SKIP\n");
          rxLen = 0;
          continue;
        }

        // 座標不明ローカライズ中は、位置特定を優先するため被災者処理は無視する。
        if (gLocalizationActive) {
          Serial1.print("VACK,SKIP\n");
          rxLen = 0;
          continue;
        }

        if (vicGet(posX, posY) != 0) {
          Serial1.print("VACK,SKIP\n");
          rxLen = 0;
          continue;
        }

        vicSet(posX, posY, 1);
        victimStopTrigger();
        stopMotors();
        Serial1.print("VACK,OK\n");
        rxLen = 0;
        continue;
      }

      // ===== SD保存データ消去指令 =====
      if (strcmp(rxBuf, "SDCLR") == 0) {
        clearSdSaveFile();
        rxLen = 0;
        continue;
      }

      // ===== MAINリセット指令 =====
      if (strcmp(rxBuf, "RST_MCU") == 0) {
        stopMotors();
        delay(20);
        SCB_AIRCR = 0x05FA0004;
        while (1) {}
      }

      // ===== TOFフレーム =====
      uint16_t v5[5];
      if (parseFrame5(rxBuf, v5)) {
        for (int i = 0; i < 5; i++) distMm[i] = v5[i];
        gSubTofSeq++;
      }

      rxLen = 0;
    } else {
      if (rxLen < sizeof(rxBuf) - 1) rxBuf[rxLen++] = c;
      else rxLen = 0;
    }
  }
}

// =====================
// background：両タッチ最優先 + 前壁イベント更新
// =====================
static inline void tickall() {
  imuUpdate();
  serviceTouchLatch();

  // 旋回中の両タッチは完全無視
  if (!gTurningActive) {
    if (gGyroResetPending) {
      performGyroReset();
    }

    // ★両タッチ後は必ず3cmバック（直進/停止中のみ）
    if (gDoBack3cmPending) {
      runRawDistanceForce(false, speed, speed + TRIM_R_REV, TARGET_3CM_PULSES, MOVE_TIMEOUT_MS);
      gDoBack3cmPending = false;
    }
  }

  serviceSubRx();
  updateFrontWallApproachEvent(); // distMm[2] は SUB 受信後に更新
  serviceMainTof();
  serviceOledHud();
}


// =====================
// 坂・階段：前進地形通過モードは slopeDetectServiceDuringStraight() で処理
// =====================

// =====================
// 直進（壁補正 / 壁無しYaw補正）
// =====================
uint8_t runStraightDistance(int basePwm, long targetPulses, uint32_t timeoutMs, bool allowAbort) {
  gStraightActive = true;
  gStraightAvgPulses = 0;
  gStraightCoordUpdated = false;

  gAbortDrive = false;
  gAbortByBothTouch = false;

  uint8_t colorCheckStage = 0; // 0:未チェック / 1:7cm一次済み / 2:13cm二次済み
  bool blueCandidateDuringMove = false; // 7cm/13cmで青を読んだら、30cm完了後に処理する
  bool redCandidateDuringMove = false;  // 4分以降に7cm/13cmで赤を読んだら、30cm完了後に処理する
  bool reachedTargetPulses = false;     // タイムアウト時は色到達処理しないための完走フラグ
  bool ignoreBlueEarlyThisMove = gIgnoreBlueEarlyCheckOnNextTile;
  bool skipFirstColorCheckAfterRedThisMove = gSkipFirstColorCheckAfterRedTile;
  long slopeExtraPulsesThisMove = 0;      // UP確定後だけ、今回の1マス走行距離を+5cmへ延長
  long bumpExtraPulsesThisMove = 0;       // 2026.5.23：確定バンプだけ補正 +2/+2.5/+3cm。同じ30cm中は最大値1回分だけ
  uint8_t bumpCompModeThisMove = 0;       // 0=なし / 1=LOW / 2=MEDIUM / 3=HIGH

  // 2026.5.20：前回直進のUP?/DOWN?候補フラグが残った状態で色検知抑制を決めると、
  // 右回転後や坂通過後の次タイルで7cm/13cm色チェックが丸ごと無効になる。
  // 先に直進開始リセットを行ってから、今回の初期抑制状態を決める。
  slopeDetectResetForStraight();
  bool terrainSuppressColorThisMove = terrainPassShouldSuppressColorVictim();
  wallVoteReset();

  digitalWriteFast(DIR_FL, LOW);
  digitalWriteFast(DIR_FR, HIGH);
  digitalWriteFast(DIR_BL, LOW);
  digitalWriteFast(DIR_BR, HIGH);

  int baseL = constrain(basePwm, 0, 255);
  int baseR = constrain(basePwm + TRIM_R_FWD, 0, 255);

  setLR(baseL, baseR);

  long sFL = encFL, sFR = encFR, sBL = encBL, sBR = encBR;
  uint32_t t0 = millis();
  uint32_t lastCtrl = 0;

  while (true) {
    // ★両タッチ押されっぱなしでも前進させない
    // ただし、地形通過中は階段/段差への接触で止まると登れないため、両タッチ停止を抑制する。
    if (!terrainPassMotionLocked() && touchPressed(SW_L) && touchPressed(SW_R)) {
      if (!gBothLockout) triggerBothTouchEvent();
      tickall(); // 補正＆3cmバックまで回す
      stopMotors();
      wallVoteFinalize();
      gStraightActive = false;
      gAbortByBothTouch = false;
      return AR_BOTH_TOUCH;
    }

    tickall();

    if (gAbortByBothTouch) {
      stopMotors();
      wallVoteFinalize();
      gStraightActive = false;
      gAbortByBothTouch = false;
      return AR_BOTH_TOUCH;
    }


    if (gAbortDrive) {
      stopMotors();
      wallVoteFinalize();
      gStraightActive = false;
      return AR_ABORT;
    }

    // 停止イベント中にT180/T180BKを行った場合、旋回中のエンコーダ増加を直進距離に数えない。
    // また、T180/T180BKで変更されたDIRピンを、直進用へ必ず戻す。
    long pauseFL = encFL, pauseFR = encFR, pauseBL = encBL, pauseBR = encBR;
    uint32_t paused = holdBlock();
    if (paused) {
      sFL += (encFL - pauseFL);
      sFR += (encFR - pauseFR);
      sBL += (encBL - pauseBL);
      sBR += (encBR - pauseBR);
      t0 += paused;
      lastCtrl += paused;
      digitalWriteFast(DIR_FL, LOW);
      digitalWriteFast(DIR_FR, HIGH);
      digitalWriteFast(DIR_BL, LOW);
      digitalWriteFast(DIR_BR, HIGH);
      setLR(baseL, baseR);
      continue;
    }

    long aFL = labs(encFL - sFL);
    long aFR = labs(encFR - sFR);
    long aBL = labs(encBL - sBL);
    long aBR = labs(encBR - sBR);
    long avg = (aFL + aFR + aBL + aBR) / 4;

    gStraightAvgPulses = avg;
    slopeDetectServiceDuringStraight(avg, gStraightCoordUpdated);
    if (terrainPassShouldSuppressColorVictim()) terrainSuppressColorThisMove = true;

    // 登りUP確定中だけ、30cm相当の1マス走行距離を+5cm/+10cm延長する。
    // DOWNは滑り量と斜面距離増加が相殺されやすいので、今回は補正しない。
    if (targetPulses == TARGET_30CM_PULSES) {
      long extraNow = slopeGetUpExtraPulsesForCurrentPitch();
      if (extraNow > 0) {
        bool extraHigh = (pitchDeg >= SLOPE_UP_EXTRA_HIGH_PITCH_DEG);
        if (extraNow > slopeExtraPulsesThisMove) {
          slopeExtraPulsesThisMove = extraNow;
        }
        slopeApplyUpExtraLabel(extraHigh);
      }

      // 2026.5.23：通常直進中のバンプ補正。
      // Pitch最大値だけでは確定せず、UP?候補中に一度+5°未満へ下がった後だけ補正する。
      // 坂・階段が確定した場合は、バンプ補正を無効化する。
      bool bumpAllowed = (!terrainPassMotionLocked() && !gSlopeDetectedThisMove && gSlopeLatchedDir == 0);
      if (bumpAllowed) {
        uint8_t bumpModeNow = gBumpCompConfirmedModeThisMove;
        long bumpExtraNow = bumpCompPulsesForMode(bumpModeNow);
        if (bumpExtraNow > bumpExtraPulsesThisMove) {
          bumpExtraPulsesThisMove = bumpExtraNow;
        }

        if (bumpModeNow != 0 && bumpModeNow != bumpCompModeThisMove) {
          bumpCompModeThisMove = bumpModeNow;

          Serial.print("BUMP COMP APPLY ");
          Serial.print(bumpCompLabelForMode(bumpModeNow));
          Serial.print(" extra_cm=");
          Serial.println((float)bumpExtraPulsesThisMove / PULSES_PER_CM, 1);
        }
      } else {
        bumpExtraPulsesThisMove = 0;
        gBumpCompConfirmedModeThisMove = 0;
      }
    }

    // ===== 色分類：7cm一次チェック → 13cm二次チェック =====
    // 黒は動作。青は候補フラグだけ立て、30cm完了後に処理する。
    // 赤は前方タイルへ記録し、4分以内は一時進入禁止として検知位置ぶんバックする。
    // 青停止直後の次1タイルだけは、7cm/13cm地点の青判定を無視する。
    // 赤入口停止直後の次1タイルだけは、赤の残り読み対策として7cm色チェックを飛ばし、13cmだけ読む。
    if (ENABLE_COLOR_CLASS_DETECT && allowAbort && !gStraightCoordUpdated && !terrainSuppressColorThisMove) {
      bool shouldColorCheck = false;
      long blackBackPulses = 0;
      long redBackPulses = 0;

      if (colorCheckStage == 0 && avg >= COLOR_CHECK_FIRST_PULSES) {
        colorCheckStage = 1;
        blackBackPulses = COLOR_CHECK_FIRST_PULSES;
        redBackPulses = COLOR_CHECK_FIRST_PULSES;

        if (skipFirstColorCheckAfterRedThisMove) {
          // 赤タイルの次のタイルへ向かう時だけ、7cm読みを捨てる。
          // 13cm地点では通常どおり読む。
          shouldColorCheck = false;
          gSkipFirstColorCheckAfterRedTile = false;
          skipFirstColorCheckAfterRedThisMove = false;
        } else {
          shouldColorCheck = true;
        }
      } else if (colorCheckStage == 1 && avg >= COLOR_CHECK_SECOND_PULSES) {
        colorCheckStage = 2;
        shouldColorCheck = true;
        blackBackPulses = COLOR_CHECK_SECOND_PULSES - TARGET_1CM_PULSES; //１３ｃｍ検知時は１２ｃｍバックする（青青黒からのＵターン対策）これでもギリ
        redBackPulses = COLOR_CHECK_SECOND_PULSES; // 赤は指定どおり13cm検知なら13cm戻す
      }

      if (shouldColorCheck) {
        stopMotors();
        uint32_t pauseStart = millis();
        waitMs(COLOR_CHECK_SETTLE_MS);

        char colorCode = 'N';
        bool colorOk = requestColorClassOnce(colorCode);

        if (gAbortDrive) {
          uint32_t paused = millis() - pauseStart;
          t0 += paused;
          lastCtrl += paused;
          stopMotors();
          wallVoteFinalize();
          gStraightActive = false;
          return AR_ABORT;
        }
        if (gAbortByBothTouch) {
          uint32_t paused = millis() - pauseStart;
          t0 += paused;
          lastCtrl += paused;
          stopMotors();
          wallVoteFinalize();
          gStraightActive = false;
          gAbortByBothTouch = false;
          return AR_BOTH_TOUCH;
        }

        if (colorOk) {
          if (colorCode == 'K') {
            // 7cm地点だけは、赤タイル境界を黒と誤読することがある。
            // そのため7cmのCL,Kだけ、さらに2cm進んで9cmで再判定する。
            if (colorCheckStage == 1) {
              runRawDistanceForce(true, speed, speed + TRIM_R_FWD, COLOR_BLACK_RECHECK_EXTRA_PULSES, MOVE_TIMEOUT_MS);
              waitMs(COLOR_CHECK_SETTLE_MS);

              char recheckCode = 'N';
              bool recheckOk = requestColorClassOnce(recheckCode);

              if (gAbortDrive) {
                uint32_t paused = millis() - pauseStart;
                t0 += paused;
                lastCtrl += paused;
                stopMotors();
                wallVoteFinalize();
                gStraightActive = false;
                return AR_ABORT;
              }
              if (gAbortByBothTouch) {
                uint32_t paused = millis() - pauseStart;
                t0 += paused;
                lastCtrl += paused;
                stopMotors();
                wallVoteFinalize();
                gStraightActive = false;
                gAbortByBothTouch = false;
                return AR_BOTH_TOUCH;
              }

              if (!recheckOk) {
                // 9cm再判定でERR/タイムアウトなら、安全側で黒確定。
                stopMotors();
                markForwardTileAsBlackBlocked();
                wallVoteFinalize();
                gStraightActive = false;
                runRawDistanceForce(false, speed, speed + TRIM_R_REV, COLOR_BLACK_RECHECK_PULSES, MOVE_TIMEOUT_MS);
                return AR_BLACK_TILE;
              }

              if (recheckCode == 'K') {
                stopMotors();
                markForwardTileAsBlackBlocked();
                wallVoteFinalize();
                gStraightActive = false;
                runRawDistanceForce(false, speed, speed + TRIM_R_REV, COLOR_BLACK_RECHECK_PULSES, MOVE_TIMEOUT_MS);
                return AR_BLACK_TILE;
              } else if (recheckCode == 'R') {
                markForwardTileAsRedEntrance();

                if (!isRedEntryAllowedNow()) {
                  stopMotors();
                  wallVoteFinalize();
                  gStraightActive = false;
                  runRawDistanceForce(false, speed, speed + TRIM_R_REV, COLOR_BLACK_RECHECK_PULSES, MOVE_TIMEOUT_MS);
                  return AR_RED_BLOCKED;
                } else {
                  redCandidateDuringMove = true;
                }
              } else if (recheckCode == 'B') {
                if (!ignoreBlueEarlyThisMove) {
                  blueCandidateDuringMove = true;
                }
              }
              // 9cm再判定でW/Nなら、7cm黒は境界誤検知として無視し、13cm判定へ進む。

            } else {
              stopMotors();
              markForwardTileAsBlackBlocked();
              wallVoteFinalize();
              gStraightActive = false;

              // 13cm地点の黒は従来どおり黒確定。現在の色チェック位置まで戻して、座標は進めない。
              runRawDistanceForce(false, speed, speed + TRIM_R_REV, blackBackPulses, MOVE_TIMEOUT_MS);
              return AR_BLACK_TILE;
            }

          } else if (colorCode == 'B') {
            if (!ignoreBlueEarlyThisMove) {
              blueCandidateDuringMove = true;
            }
            // ignoreBlueEarlyThisMove中の青は、前の青タイルを読んでいる可能性が高いので無視。
            // この移動が30cm完了した後、到着地点で改めて青チェックする。
          } else if (colorCode == 'R') {
            markForwardTileAsRedEntrance();

            if (!isRedEntryAllowedNow()) {
              stopMotors();
              wallVoteFinalize();
              gStraightActive = false;

              // 赤入口解禁前の赤は黒と同じく進入しない。ただし黒のような永久壁にはしない。
              runRawDistanceForce(false, speed, speed + TRIM_R_REV, redBackPulses, MOVE_TIMEOUT_MS);
              return AR_RED_BLOCKED;
            } else {
              redCandidateDuringMove = true;
            }
          }
          // CL,W と CL,N は表示しない。走行だけ再開する。
        }

        // 停止・判定・仮表示に使った時間は、直進タイムアウトと制御周期から除外する。
        uint32_t paused = millis() - pauseStart;
        t0 += paused;
        lastCtrl += paused;

        digitalWriteFast(DIR_FL, LOW);
        digitalWriteFast(DIR_FR, HIGH);
        digitalWriteFast(DIR_BL, LOW);
        digitalWriteFast(DIR_BR, HIGH);
        setLR(baseL, baseR);
      }
    }

    if (!gStraightCoordUpdated && avg >= TARGET_15CM_PULSES) {
      stepForwardOneTile();
      wallMarkForwardOpenByTraverse();
      gStraightCoordUpdated = true;

      // 2026.5.20：坂・階段が複数マス続く場合、座標更新した坂セルも記録する。
      // 平地復帰直後の出口タイルを誤ってSLにしないため、Pitchが平地範囲なら追加しない。
      if (gSlopeCandidateDir != 0 || gSlopeDetectedThisMove || gSlopeLatchedDir != 0 || terrainPassMotionLocked()) {
        slopeSideWallCellAddCurrentIfSlopeLike(pitchDeg, "STEP");
        if (gSlopeDetectedThisMove || gSlopeLatchedDir != 0 || terrainPassMotionLocked()) {
          markRecordedSlopeCellsAsSLForFloor(currentFloor, "STEP");
          if (gSlopeUpExtraCm != 0) {
            markRecordedSlopeCellsUpExtraModeForFloor(currentFloor, gSlopeUpExtraCm, "STEP");
          }
        }
      }
    }

    wallVoteTrySample(avg);

    if (allowAbort && !terrainPassMotionLocked()) {
      if (needTurnDebounced()) { stopMotors(); wallVoteFinalize(); gStraightActive = false; return AR_TURN; }

      bool oneTouch = (touchPressed(SW_L) ^ touchPressed(SW_R));
      uint16_t s2 = distMm[2];
      bool s2open = tofValid(s2) && (s2 >= S2_OPEN_MM);
      if (oneTouch && s2open) {
        stopMotors();
        wallVoteFinalize();
        gStraightActive = false;
        if (touchPressed(SW_L)) return AR_SIDESTEP_LEFT_TOUCH;
        else return AR_SIDESTEP_RIGHT_TOUCH;
      }
    }

    long currentTargetPulses = targetPulses + slopeExtraPulsesThisMove + bumpExtraPulsesThisMove;
    if (gTerrainPassClearanceActive && gTerrainPassClearanceTargetAvgPulses > 0) {
      currentTargetPulses = gTerrainPassClearanceTargetAvgPulses;
    }
    if (avg >= currentTargetPulses) {
      reachedTargetPulses = true;
      break;
    }
    if (millis() - t0 > timeoutMs) break;

    if (millis() - lastCtrl >= STRAIGHT_CTRL_MS) {
      lastCtrl = millis();

      int corr = 0;

      uint16_t s0 = distMm[0];
      uint16_t s1 = distMm[1];
      uint16_t s3 = distMm[3];
      uint16_t s4 = distMm[4];

      bool s0ok = tofValid(s0);
      bool s1ok = tofValid(s1);

      bool earlyPhase = (avg < TARGET_15CM_PULSES);

      bool leftWall  = false;
      bool rightWall = false;

      if (earlyPhase) {
        leftWall  = s0ok && (s0 < EARLY_WALL_L_MM);
        rightWall = s1ok && (s1 < EARLY_WALL_R_MM);
      } else {
        leftWall  = tofValid(s3) && (s3 < WALL_L_DETECT_MM);
        rightWall = tofValid(s4) && (s4 < WALL_R_DETECT_MM);
        if (!s0ok) leftWall = false;
        if (!s1ok) rightWall = false;
      }

      if (leftWall || rightWall) {
        float left_mm  = s0ok ? (float)s0 : 0.0f;
        float right_mm = s1ok ? ((float)s1 + (float)WALL_TRIM_S1_MM) : 0.0f;

        float corrWall_f = 0.0f;
        if (leftWall && rightWall) {
          float err = right_mm - left_mm;
          if (fabsf(err) < (float)WALL_DEADBAND_MM) err = 0.0f;
          corrWall_f = -WALL_KP * err;
        } else if (!leftWall && rightWall) {
          float err = right_mm - (float)TARGET_S1_ONE_MM;
          if (fabsf(err) < (float)WALL_DEADBAND_MM) err = 0.0f;
          corrWall_f = -WALL_ONE_KP * err;
        } else if (leftWall && !rightWall) {
          float err = left_mm - (float)TARGET_S0_ONE_MM;
          if (fabsf(err) < (float)WALL_DEADBAND_MM) err = 0.0f;
          corrWall_f = +WALL_ONE_KP * err;
        }

        corr = (int)corrWall_f;
        corr = constrain(corr, -WALL_MAX_CORR_PWM, WALL_MAX_CORR_PWM);

      } else {
        float targetYaw = chooseNearestAbs090180(yawDeg);
        float err = normalize180(yawDeg - targetYaw);
        if (fabsf(err) < NO_WALL_YAW_DEADBAND_DEG) err = 0.0f;

        int corrYaw = (int)(NO_WALL_YAW_KP * err);
        corrYaw = constrain(corrYaw, -NO_WALL_YAW_MAX_CORR_PWM, NO_WALL_YAW_MAX_CORR_PWM);
        corrYaw = corrYaw * NO_WALL_YAW_CORR_SIGN;
        corr = corrYaw;
      }

      setLR(baseL - corr, baseR + corr);
    }
  }

  stopMotors();
  wallVoteFinalize();
  gStraightActive = false;

  if (gTerrainPassClearanceActive && reachedTargetPulses) {
    gTerrainPassClearanceActive = false;
    gTerrainPassClearanceTargetAvgPulses = 0;
  }

  if (reachedTargetPulses) {
    if (blueCandidateDuringMove) {
      processBlueConfirmedCurrentTile();
    } else if (redCandidateDuringMove) {
      processRedConfirmedCurrentTile();
    } else {
      // M_42_10：赤脱出時の「地図上Rなのに実際は白/未検知」または
      // 「実際Rなのにスナップショット赤でない」矛盾をここで拾う。
      // これにより、1マスずれでNC入口をすり抜けるケースを防ぐ。
      bool handledRedNcMismatch = false;
      if (inRedZone && !returnMode && !redNormalConfirmMode && !redRecoverySearchMode && floorIndexInRange(currentFloor) && visInRange(posX, posY)) {
        bool shouldArrivalRedCheck = (redNcSnapshotRedGetFloor(currentFloor, posX, posY) != 0);
        if (shouldArrivalRedCheck) {
          waitMs(COLOR_CHECK_SETTLE_MS);
          char arrivalRedNcCode = 'N';
          bool arrivalRedNcOk = requestColorClassOnce(arrivalRedNcCode);
          handledRedNcMismatch = redNcHandleArrivalColorMapMismatch(arrivalRedNcCode, arrivalRedNcOk, "ARRIVAL_SNAPSHOT_RED_CHECK");
        }
      }

      if (handledRedNcMismatch) {
        // 赤リカバリーまたはNCへ入ったので、通常の到着処理は行わない。
      } else if (shouldRedTargetMode() && redGet(posX, posY)) {
      // 赤入口BFSで赤タイルへ入ったが、7cm/13cmの色判定を拾えなかった場合の保険。
      processRedConfirmedCurrentTile();
      } else if (ignoreBlueEarlyThisMove) {
      // 青停止後の次1タイルでは、7cm/13cmの青は無視した。
      // ここで到着地点を1回だけ確認し、連続した青タイルを見逃さない。
      waitMs(COLOR_CHECK_SETTLE_MS);

      char arrivalCode = 'N';
      bool arrivalOk = requestColorClassOnce(arrivalCode);
      if (arrivalOk && arrivalCode == 'B') {
        processBlueConfirmedCurrentTile();
      } else {
        // 次タイルが青ではなかったので、早期青無視モードを解除する。
        gIgnoreBlueEarlyCheckOnNextTile = false;
      }
    }
    }
  }

  return AR_NONE;
}

// =====================
// ===== ターンデバウンス（片タッチ用）=====
// =====================
static inline bool needTurnDebounced() {
  static uint32_t holdStartMs = 0;

  if (slopeShouldIgnoreFrontS2ForWallJudge()) {
    holdStartMs = 0;
    return false;
  }

  bool oneTouch = (touchPressed(SW_L) ^ touchPressed(SW_R));
  uint16_t s2 = distMm[2];
  bool s2close = tofValid(s2) && (s2 <= S2_TURN_MM);
  bool cond = oneTouch && s2close;
  uint32_t now = millis();

  if (!cond) { holdStartMs = 0; return false; }
  if (holdStartMs == 0) { holdStartMs = now; return false; }

  if (now - holdStartMs >= ONE_TOUCH_HOLD_MS) {
    oneTouch = (touchPressed(SW_L) ^ touchPressed(SW_R));
    s2 = distMm[2];
    s2close = tofValid(s2) && (s2 <= S2_TURN_MM);
    if (oneTouch && s2close) return true;
    holdStartMs = 0;
  }
  return false;
}

// =====================
// ★回転スタック救済（純変化量 + DIR復帰）
// turnAllHigh: 左旋回(true=全HIGH) / 右旋回・180(false=全LOW)
// =====================
static inline bool turnStallRescueIfNeeded(
  uint32_t &winStartMs,
  float &yawWinStartYaw,
  float &lastY,
  int &tries,
  bool turnAllHigh
) {
  uint32_t now = millis();

  // 2026.4.26：現在は回転スタック救済を完全OFF。
  // コードは残し、必要になったら ENABLE_TURN_STALL_RESCUE を true に戻す。
  if (!ENABLE_TURN_STALL_RESCUE) {
    winStartMs = now;
    yawWinStartYaw = yawDeg;
    return false;
  }

  // 将来ONに戻しても、被災者停止/T180停止中は絶対に2cmバックしない。
  if (holdActive()) {
    winStartMs = now;
    yawWinStartYaw = yawDeg;
    return false;
  }

  if (now - winStartMs < TURN_STALL_WINDOW_MS) return false;

  float net = fabsf(normalize180(yawDeg - yawWinStartYaw));
  if (net >= TURN_STALL_DEG) {
    winStartMs = now;
    yawWinStartYaw = yawDeg;
    return false;
  }

  // ===== スタック救済 =====
  tries++;
  stopMotors();

  // 2cmバック
  runRawDistanceForce(false, speed, speed + TRIM_R_REV, TARGET_2CM_PULSES, MOVE_TIMEOUT_MS);
  waitMs(STOP_MS);

  // ★超重要：DIRを旋回方向に戻す（戻し忘れ罠を完全に潰す）
  if (turnAllHigh) {
    digitalWriteFast(DIR_FL, HIGH);
    digitalWriteFast(DIR_BL, HIGH);
    digitalWriteFast(DIR_FR, HIGH);
    digitalWriteFast(DIR_BR, HIGH);
  } else {
    digitalWriteFast(DIR_FL, LOW);
    digitalWriteFast(DIR_BL, LOW);
    digitalWriteFast(DIR_FR, LOW);
    digitalWriteFast(DIR_BR, LOW);
  }

  imuUpdate();
  lastY = yawDeg;
  winStartMs = millis();
  yawWinStartYaw = yawDeg;

  if (tries > TURN_STALL_MAX_TRIES) return true; // 諦める
  return false;
}

// =====================
// ★T180アクション
// =====================
static void doT180ActionOnce() {
  stopMotors();

  // 2026.5.5：被災者投下専用T180。
  // 30cm区切りへ進める/戻す補正、座標更新、壁情報更新は一切しない。
  uint32_t t0 = millis();
  while ((uint32_t)(millis() - t0) < STOP_MS) {
    imuUpdate();
    serviceSubRx();
    serviceOledHud();
    delay(1);
    stopMotors();
  }

  turn180YawOneShot(speed, t180IsBackCommand);
  stopMotors();
}

// =====================
// ★ 左/右90°、180°旋回：絶対角度スナップ（回転中の両タッチは完全無視）
// =====================
void turnLeft90Yaw(int basePwm) {
  (void)basePwm;

  gTurningActive = true;

  // 左旋回：全HIGH
  digitalWriteFast(DIR_FL, HIGH);
  digitalWriteFast(DIR_BL, HIGH);
  digitalWriteFast(DIR_FR, HIGH);
  digitalWriteFast(DIR_BR, HIGH);

  imuUpdate();
  float startYaw = yawDeg;

  float currentBase = chooseNearestAbs090180(startYaw);
  float targetYaw = normalize180(currentBase + 90.0f);
  float targetSwept = fabsf(normalize180(targetYaw - startYaw));

  uint32_t t0 = millis();
  uint32_t lastCtrl = 0;

  float swept = 0.0f;
  float lastY = startYaw;

  uint32_t winStartMs = millis();
  float yawWinStartYaw = yawDeg;
  int rescueTries = 0;

  while (true) {
    tickall();
    uint32_t paused = holdBlock();
    if (paused) {
      t0 += paused;
      lastCtrl += paused;
      winStartMs += paused;
      lastY = yawDeg;
      yawWinStartYaw = yawDeg;
      continue;
    }

    float d = normalize180(yawDeg - lastY);
    swept += fabsf(d);
    lastY = yawDeg;

    // スタック救済（失敗なら諦めて停止→拡張左手法へ）
    if (turnStallRescueIfNeeded(winStartMs, yawWinStartYaw, lastY, rescueTries, true)) {
      stopMotors();
      gTurningActive = false;
      gNeedReDecideAtStop = true;
      return;
    }

    float errToTarget = targetSwept - swept;
    if (errToTarget <= TURN_TOL_DEG) break;
    if (millis() - t0 > TURN_TIMEOUT_MS) break;

    if (millis() - lastCtrl >= TURN_CTRL_MS) {
      lastCtrl = millis();
      int pwmTurn = (int)(TURN_PWM_MIN + TURN_KP_PWM * errToTarget);
      pwmTurn = constrain(pwmTurn, TURN_PWM_MIN, TURN_PWM_MAX);
      setLR(pwmTurn, pwmTurn + TRIM_R_FWD);
    }
  }

  stopMotors();
  gTurningActive = false;
  direction = (direction + 3) & 3;
}

void turnRight90Yaw(int basePwm) {
  (void)basePwm;

  gTurningActive = true;

  // 右旋回：全LOW
  digitalWriteFast(DIR_FL, LOW);
  digitalWriteFast(DIR_BL, LOW);
  digitalWriteFast(DIR_FR, LOW);
  digitalWriteFast(DIR_BR, LOW);

  imuUpdate();
  float startYaw = yawDeg;

  float currentBase = chooseNearestAbs090180(startYaw);
  float targetYaw = normalize180(currentBase - 90.0f);
  float targetSwept = fabsf(normalize180(targetYaw - startYaw));

  uint32_t t0 = millis();
  uint32_t lastCtrl = 0;

  float swept = 0.0f;
  float lastY = startYaw;

  uint32_t winStartMs = millis();
  float yawWinStartYaw = yawDeg;
  int rescueTries = 0;

  while (true) {
    tickall();
    uint32_t paused = holdBlock();
    if (paused) {
      t0 += paused;
      lastCtrl += paused;
      winStartMs += paused;
      lastY = yawDeg;
      yawWinStartYaw = yawDeg;
      continue;
    }

    float d = normalize180(yawDeg - lastY);
    swept += fabsf(d);
    lastY = yawDeg;

    if (turnStallRescueIfNeeded(winStartMs, yawWinStartYaw, lastY, rescueTries, false)) {
      stopMotors();
      gTurningActive = false;
      gNeedReDecideAtStop = true;
      return;
    }

    float errToTarget = targetSwept - swept;
    if (errToTarget <= TURN_TOL_DEG) break;
    if (millis() - t0 > TURN_TIMEOUT_MS) break;

    if (millis() - lastCtrl >= TURN_CTRL_MS) {
      lastCtrl = millis();
      int pwmTurn = (int)(TURN_PWM_MIN + TURN_KP_PWM * errToTarget);
      pwmTurn = constrain(pwmTurn, TURN_PWM_MIN, TURN_PWM_MAX);
      setLR(pwmTurn, pwmTurn + TRIM_R_REV);
    }
  }

  stopMotors();
  gTurningActive = false;
  direction = (direction + 1) & 3;
}

static void turnBack180Yaw2x90() {
  turnRight90Yaw(speed);
  if (gNeedReDecideAtStop) return;
  waitMs(STOP_MS);

  turnRight90Yaw(speed);
  if (gNeedReDecideAtStop) return;
  waitMs(STOP_MS);
}

static void turn180YawOneShot(int basePwm, bool isBackTurn) {
  (void)basePwm;

  gTurningActive = true;

  // T180   : 右回り200°
  // T180BK : 元の向きへ戻すため、左回り200°
  bool turnLeft = isBackTurn;

  if (turnLeft) {
    // 左旋回：全HIGH
    digitalWriteFast(DIR_FL, HIGH);
    digitalWriteFast(DIR_BL, HIGH);
    digitalWriteFast(DIR_FR, HIGH);
    digitalWriteFast(DIR_BR, HIGH);
  } else {
    // 右旋回：全LOW
    digitalWriteFast(DIR_FL, LOW);
    digitalWriteFast(DIR_BL, LOW);
    digitalWriteFast(DIR_FR, LOW);
    digitalWriteFast(DIR_BR, LOW);
  }

  imuUpdate();
  float startYaw = yawDeg;

  // 被災者投下用T180/T180BKは、近い0/90/180/-90へ寄せず、現在Yawから純粋に相対200°回す。
  float targetSwept = VICTIM_T180_SWEEP_DEG;

  uint32_t t0 = millis();
  uint32_t lastCtrl = 0;

  float swept = 0.0f;
  float lastY = startYaw;

  uint32_t winStartMs = millis();
  float yawWinStartYaw = yawDeg;
  int rescueTries = 0;

  while (true) {
    imuUpdate();
    serviceMainTof();
    serviceOledHud();
    delay(1);

    tickall();

    float d = normalize180(yawDeg - lastY);
    swept += fabsf(d);
    lastY = yawDeg;

    if (turnStallRescueIfNeeded(winStartMs, yawWinStartYaw, lastY, rescueTries, turnLeft)) {
      stopMotors();
      gTurningActive = false;
      gNeedReDecideAtStop = true;
      return;
    }

    float errToTarget = targetSwept - swept;
    if (errToTarget <= TURN_TOL_DEG) break;
    if (millis() - t0 > TURN_TIMEOUT_MS) break;

    if (millis() - lastCtrl >= TURN_CTRL_MS) {
      lastCtrl = millis();
      int pwmTurn = (int)(TURN_PWM_MIN + TURN_KP_PWM * errToTarget);
      pwmTurn = constrain(pwmTurn, TURN_PWM_MIN, TURN_PWM_MAX);

      if (turnLeft) {
        setLR_force(pwmTurn, pwmTurn + TRIM_R_FWD);
      } else {
        setLR_force(pwmTurn, pwmTurn + TRIM_R_REV);
      }
    }
  }

  stopMotors();
  gTurningActive = false;

  // T180/T180BKは被災者投下姿勢用の一時動作。
  // 走行マップ上の方角 direction は変更しない。
}

// =====================
// sidestep
// =====================
void sidestepAwayFromLeftObstacle() {
  runRawDistance(false, speed + SIDESTEP_DELTA_PWM, 0, TARGET_5CM_PULSES, SIDESTEP_TIMEOUT_MS);
  waitMs(STOP_MS);
  runRawDistance(false, 0, speed + SIDESTEP_DELTA_PWM, TARGET_6CM_PULSES, SIDESTEP_TIMEOUT_MS);
  waitMs(STOP_MS);
  runRawDistance(true, speed, speed + TRIM_R_FWD, TARGET_10CM_PULSES, SIDESTEP_TIMEOUT_MS);
  waitMs(STOP_MS);
}
void sidestepAwayFromRightObstacle() {
  runRawDistance(false, 0, speed + SIDESTEP_DELTA_PWM, TARGET_5CM_PULSES, SIDESTEP_TIMEOUT_MS);
  waitMs(STOP_MS);
  runRawDistance(false, speed + SIDESTEP_DELTA_PWM, 0, TARGET_6CM_PULSES, SIDESTEP_TIMEOUT_MS);
  waitMs(STOP_MS);
  runRawDistance(true, speed, speed + TRIM_R_FWD, TARGET_10CM_PULSES, SIDESTEP_TIMEOUT_MS);
  waitMs(STOP_MS);
}

// =====================
// HOME
// =====================
static void doHomeSignalAndStop() {
  stopMotors();
  Serial1.print("HOME\n");
  missionComplete = true;
  homePending = false;
  homeArmed = false;
  drawHudScreen();
}
static inline void handleHomeSignalIfNeeded() {
  if (returnMode && isOrigin()) doHomeSignalAndStop();
}

// =====================
// 拡張左手法（壁マップのみ）
// =====================
static inline void neighborByRel(uint8_t relDir, int cx, int cy, uint8_t curDir, int &nx, int &ny) {
  uint8_t absDir = (curDir + relDir) & 3;
  nx = cx; ny = cy;
  if (absDir == 0) ny += 1;
  else if (absDir == 1) nx += 1;
  else if (absDir == 2) ny -= 1;
  else nx -= 1;
}

static inline bool canMoveByRelFromWallMap(uint8_t relDir) {
  uint8_t absDir = (direction + relDir) & 3;
  uint8_t st = wallStateGet(posX, posY, absDir);
  if (st == WALL_STATE_BLOCKED) return false;

  // 赤入口解禁前は、発見済みの赤入口を一時的な壁として扱う。
  // wallMap自体は書き換えないので、N-または5分経過後に自動で進入候補へ戻る。
  int nx, ny;
  neighborByAbs(absDir, posX, posY, nx, ny);
  if (!isRedEntryAllowedNow() && redGet(nx, ny)) return false;

  return true; // 壁なし・不明を開通扱い
}

static inline bool canReturnMoveByRel(uint8_t relDir) {
  uint8_t absDir = (direction + relDir) & 3;
  return (wallStateGet(posX, posY, absDir) == WALL_STATE_OPEN); // 帰還は壁なし確定だけ
}

static inline int absHeightToBase(uint8_t floor) {
  if (!floorIndexInRange(floor)) return 100;
  if (floorHeight[floor] == FLOOR_HEIGHT_UNKNOWN) return 100;
  return abs((int)floorHeight[floor]);
}

// 2026.5.17：RETURN中のSL(坂)通過ロック。
// SLセル上ではXY_Numberによる再判定を一時停止し、現在の向きのまま直進だけ許可する。
// SLでなくなったら解除する。両タッチなどの物理安全処理は走行側で従来通り優先される。
static inline int chooseReturnSlopePassRelDir() {
  bool isSL = slopeTransitCellGetFloor(currentFloor, posX, posY);

  if (!isSL) {
    if (gReturnSlopePassActive) {
      Serial.print("RETURN SL PASS OFF F");
      Serial.print((unsigned)(currentFloor + 1));
      Serial.print(" X:");
      Serial.print(posX);
      Serial.print(" Y:");
      Serial.println(posY);
    }
    gReturnSlopePassActive = false;
    return -1;
  }

  if (!gReturnSlopePassActive) {
    gReturnSlopePassActive = true;
    gReturnSlopePassFloor = currentFloor;
    gReturnSlopePassX = posX;
    gReturnSlopePassY = posY;
    gReturnSlopePassDir = direction & 3;

    Serial.print("RETURN SL PASS ON F");
    Serial.print((unsigned)(currentFloor + 1));
    Serial.print(" X:");
    Serial.print(posX);
    Serial.print(" Y:");
    Serial.print(posY);
    Serial.print(" DIR:");
    Serial.println((unsigned)gReturnSlopePassDir);
  }

  // 坂の途中では左/右/180°回転を禁止し、前進だけ許可する。
  // directionが何らかの理由で変わっていても、ここでは補正ターンを要求しない。
  return 0;
}

static inline int chooseFloorLinkRelDirByXY_Number() {
  uint16_t curNo = xyNumberGet(posX, posY);
  if (curNo == XY_NUMBER_INF) return -1;

  int curHeightAbs = absHeightToBase(currentFloor);
  int chosen = -1;
  uint16_t bestNo = XY_NUMBER_INF;
  int bestHeightAbs = 100;

  uint8_t linkMask = floorLinkMaskGet(currentFloor, posX, posY);
  for (uint8_t nf = 0; nf < FLOOR_COUNT; nf++) {
    if ((linkMask & (uint8_t)(1u << nf)) == 0) continue;

    uint8_t absDir = floorLinkDirGet(currentFloor, posX, posY, nf);
    if (absDir > 3) continue;

    int tx, ty;
    floorLinkTargetGet(currentFloor, posX, posY, nf, tx, ty);
    uint16_t nextNo = xyNumberGetFloor(nf, tx, ty);
    if (nextNo == XY_NUMBER_INF) continue;

    int nextHeightAbs = absHeightToBase(nf);
    bool isCloserToBase = (nextHeightAbs < curHeightAbs);

    // フロアリンクはBFS上で同じ番号を継承することがあるため、
    // 2F/3Fから1st側へ戻るリンクは nextNo == curNo でも許可する。
    if (!isCloserToBase && nextNo >= curNo) continue;

    if (chosen < 0 || nextNo < bestNo || (nextNo == bestNo && nextHeightAbs < bestHeightAbs)) {
      chosen = (int)((absDir + 4 - direction) & 3);
      bestNo = nextNo;
      bestHeightAbs = nextHeightAbs;
    }
  }

  return chosen;
}

static inline int chooseReturnRelDirByXY_Number() {
  // 2026.5.17：RETURN中にSL(坂)セルへ入ったら、坂を抜けるまで直進固定。
  // ここでXY_Number判定を走らせると、坂途中でUターンして2nd側へ戻ることがある。
  int slopePassRel = chooseReturnSlopePassRelDir();
  if (slopePassRel >= 0) return slopePassRel;

  rebuildXY_NumberAll();

  uint16_t curNo = xyNumberGet(posX, posY);
  if (curNo == XY_NUMBER_INF) return -1;

  int linkRel = chooseFloorLinkRelDirByXY_Number();
  if (linkRel >= 0) return linkRel;

  const int prio[4] = {0, 3, 1, 2}; // 前→左→右→後
  int chosen = -1;
  uint16_t bestNo = XY_NUMBER_INF;

  for (int k = 0; k < 4; k++) {
    int rel = prio[k];
    if (!canReturnMoveByRel((uint8_t)rel)) continue;

    int nx, ny;
    neighborByRel((uint8_t)rel, posX, posY, direction, nx, ny);
    uint16_t nextNo = xyNumberGet(nx, ny);
    if (nextNo == XY_NUMBER_INF) continue;
    if (nextNo >= curNo) continue;

    if (chosen < 0 || nextNo < bestNo) {
      chosen = rel;
      bestNo = nextNo;
    }
  }
  return chosen;
}

static inline bool canRedTargetMoveByRel(uint8_t relDir) {
  uint8_t absDir = (direction + relDir) & 3;
  return (wallStateGet(posX, posY, absDir) == WALL_STATE_OPEN);
}

static inline int chooseFloorLinkRelDirByRed_Number() {
  uint16_t curNo = redNumberGet(posX, posY);
  if (curNo == RED_NUMBER_INF) return -1;

  int chosen = -1;
  uint16_t bestNo = RED_NUMBER_INF;
  uint8_t linkMask = floorLinkMaskGet(currentFloor, posX, posY);
  for (uint8_t nf = 0; nf < FLOOR_COUNT; nf++) {
    if ((linkMask & (uint8_t)(1u << nf)) == 0) continue;
    uint8_t absDir = floorLinkDirGet(currentFloor, posX, posY, nf);
    if (absDir > 3) continue;
    int tx, ty;
    floorLinkTargetGet(currentFloor, posX, posY, nf, tx, ty);
    uint16_t nextNo = redNumberGetFloor(nf, tx, ty);
    if (nextNo == RED_NUMBER_INF) continue;
    if (nextNo > curNo) continue;
    if (chosen < 0 || nextNo < bestNo) {
      chosen = (int)((absDir + 4 - direction) & 3);
      bestNo = nextNo;
    }
  }
  return chosen;
}

static inline int chooseRedTargetRelDirByRed_Number() {
  rebuildRed_NumberAll();

  uint16_t curNo = redNumberGet(posX, posY);
  if (curNo == RED_NUMBER_INF) return -1;

  int linkRel = chooseFloorLinkRelDirByRed_Number();
  if (linkRel >= 0) return linkRel;

  const int prio[4] = {0, 3, 1, 2}; // 前→左→右→後
  int chosen = -1;
  uint16_t bestNo = RED_NUMBER_INF;

  for (int k = 0; k < 4; k++) {
    int rel = prio[k];
    if (!canRedTargetMoveByRel((uint8_t)rel)) continue;

    int nx, ny;
    neighborByRel((uint8_t)rel, posX, posY, direction, nx, ny);
    uint16_t nextNo = redNumberGet(nx, ny);
    if (nextNo == RED_NUMBER_INF) continue;
    if (nextNo >= curNo) continue;

    if (chosen < 0 || nextNo < bestNo) {
      chosen = rel;
      bestNo = nextNo;
    }
  }
  return chosen;
}

static inline bool canRedExitToNormalByRel(uint8_t relDir) {
  uint8_t absDir = (direction + relDir) & 3;
  if (wallStateGet(posX, posY, absDir) != WALL_STATE_OPEN) return false;

  int nx, ny;
  neighborByAbs(absDir, posX, posY, nx, ny);
  if (!visInRange(nx, ny)) return false;
  return (zoneGet(nx, ny) == ZONE_NORMAL);
}

static inline uint8_t redExitNearestDirFromYaw() {
  // Yawから「今ロボットが物理的に向いていそうな絶対方角」を4択で推定する。
  // direction変数がレッドゾーン内でズレた場合でも、赤入口から出る相対方向を選びやすくする。
  imuUpdate();

  uint8_t bestDir = 0;
  float bestErr = 1.0e9f;
  for (uint8_t d = 0; d < 4; d++) {
    float target = redYawTargetForDir(d);
    float err = fabsf(normalize180(yawDeg - target));
    if (err < bestErr) {
      bestErr = err;
      bestDir = d;
    }
  }
  return bestDir;
}

static inline int chooseRedExitToNormalRelDirByEntranceCandidates() {
  // 第2段階C：赤タイル上では、現在のdirectionだけを信用しない。
  // 記録済み赤入口のnormalSideAbsDirと、Yawから推定した実方角を使って、
  // 「物理的にどちらへ出ればノーマル側の可能性が高いか」を相対方向で選ぶ。
  if (redEntranceInfoCount == 0) return -1;

  const uint8_t relPriority[4] = {0, 3, 1, 2}; // 前→左→右→後。Uターンは最後。
  int score[4] = {0, 0, 0, 0};
  uint8_t vote[4] = {0, 0, 0, 0};

  uint8_t yawDir = redExitNearestDirFromYaw();
  uint8_t mapDir = direction & 3;

  for (uint8_t i = 0; i < redEntranceInfoCount; i++) {
    if (!redEntranceInfo[i].used) continue;
    const RedEntranceInfo &r = redEntranceInfo[i];
    if (!floorIndexInRange(r.floor) || !visInRange(r.x, r.y)) continue;
    if (r.normalSideAbsDir > 3) continue;

    uint8_t redWall = wallStateGetFloor(r.floor, r.x, r.y, r.normalSideAbsDir);
    if (redWall == WALL_STATE_BLOCKED) continue;

    int nx, ny;
    neighborByAbs(r.normalSideAbsDir, r.x, r.y, nx, ny);
    if (!visInRange(nx, ny)) continue;

    int base = 10;

    // 今の推定座標と同じ赤入口なら最優先。ただしdirectionそのものは強く信用しない。
    if (r.floor == currentFloor && r.x == posX && r.y == posY) {
      base += 60;
    } else {
      base += 5;
    }

    // 初回発見時に記録したノーマル隣接マスと一致するなら信頼度を上げる。
    if (r.normalX == nx && r.normalY == ny) base += 10;
    if (zoneGetFloor(r.floor, nx, ny) == ZONE_NORMAL) base += 40;
    if (xyNumberGetFloor(r.floor, nx, ny) != XY_NUMBER_INF) base += 15;
    if (redWall == WALL_STATE_OPEN) base += 15;
    else                            base += 3; // UNKNOWNでも候補には残す

    for (uint8_t candDir = 0; candDir < 4; candDir++) {
      uint8_t rel = (uint8_t)((r.normalSideAbsDir + 4 - candDir) & 3);
      int s = base;

      // Yawから見た実方角に合う候補を強く優先。
      // 90°ズレ実験では、ここが効いてUターン事故を減らす狙い。
      uint8_t yawDiff = (uint8_t)((candDir + 4 - yawDir) & 3);
      if (yawDiff == 0)      s += 90;
      else if (yawDiff == 1 || yawDiff == 3) s += 15;
      else                  s -= 10;

      // map上のdirectionはズレている可能性があるので、小さな加点だけにする。
      if (candDir == mapDir) s += 5;

      score[rel] += s;
      vote[rel]++;
    }
  }

  int bestRel = -1;
  int bestScore = -32768;
  for (uint8_t pi = 0; pi < 4; pi++) {
    uint8_t rel = relPriority[pi];
    if (vote[rel] == 0) continue;

    int finalScore = score[rel];
    // 同点時だけでなく、少しだけUターンを不利にする。
    if (rel == 2) finalScore -= 8;

    if (bestRel < 0 || finalScore > bestScore) {
      bestRel = rel;
      bestScore = finalScore;
    }
  }

  if (bestRel >= 0) {
    Serial.print("RED_EXIT CAND rel:");
    Serial.print(bestRel);
    Serial.print(" score:");
    Serial.print(bestScore);
    Serial.print(" yawDir:");
    Serial.print(dirChar(yawDir));
    Serial.print(" mapDir:");
    Serial.print(dirChar(mapDir));
    Serial.print(" votes F/L/R/B:");
    Serial.print((unsigned)vote[0]);
    Serial.print('/');
    Serial.print((unsigned)vote[3]);
    Serial.print('/');
    Serial.print((unsigned)vote[1]);
    Serial.print('/');
    Serial.println((unsigned)vote[2]);
  }

  return bestRel;
}

static inline int chooseRedExitToNormalRelDir() {
  // 第2段階C：まず赤入口候補ベースで出口方向を選ぶ。
  // 失敗時だけ従来の推定座標・推定方角ベースにフォールバックする。
  int candRel = chooseRedExitToNormalRelDirByEntranceCandidates();
  if (candRel >= 0) return candRel;

  const int prio[4] = {0, 3, 1, 2}; // 前→左→右→後
  int chosen = -1;
  uint16_t bestNo = XY_NUMBER_INF;

  for (int k = 0; k < 4; k++) {
    int rel = prio[k];
    if (!canRedExitToNormalByRel((uint8_t)rel)) continue;

    int nx, ny;
    neighborByRel((uint8_t)rel, posX, posY, direction, nx, ny);
    uint16_t nextNo = xyNumberGet(nx, ny);

    if (chosen < 0 || nextNo < bestNo) {
      chosen = rel;
      bestNo = nextNo;
    }
  }
  return chosen;
}

static void startRedNormalConfirmMode(const char* reason) {
  redNormalConfirmMode = true;
  redNormalConfirmStepCount = 1;
  redNormalConfirmStartFloor = currentFloor;
  redNormalConfirmStartX = posX;
  redNormalConfirmStartY = posY;
  redNormalConfirmExitAbsDir = direction & 3;
  redNormalConfirmResetObservations();

  if (redRecoveryNcActive) {
    redRecoverySearchMode = false;
    redRecoveryOnRedTile = false;
  }

  // ノーマル確定までは、まだレッドゾーン内として扱う。
  inRedZone = true;
  redExitMode = false;
  frontierTargetMode = false;
  frontierTargetZone = ZONE_UNKNOWN;

  redNormalConfirmBuildCandidates();

  Serial.print("RED_NC START ");
  Serial.print(reason ? reason : "");
  Serial.print(" F");
  Serial.print((unsigned)(currentFloor + 1));
  Serial.print(" X:");
  Serial.print(posX);
  Serial.print(" Y:");
  Serial.print(posY);
  Serial.print(" DIR:");
  Serial.println(dirChar(direction));
}

static void cancelRedNormalConfirmMode(const char* reason) {
  Serial.print("RED_NC CANCEL ");
  Serial.print(reason ? reason : "");
  Serial.print(" step:");
  Serial.print((unsigned)redNormalConfirmStepCount);
  Serial.print(" F");
  Serial.print((unsigned)(currentFloor + 1));
  Serial.print(" X:");
  Serial.print(posX);
  Serial.print(" Y:");
  Serial.println(posY);

  redNormalConfirmMode = false;
  redNormalConfirmStepCount = 0;
  redNormalConfirmResetCandidates();
  redExitLeavePending = false;
  redExitMode = false;
  inRedZone = true;
  frontierTargetMode = false;
  frontierTargetZone = ZONE_UNKNOWN;
  if (redRecoveryNcActive) {
    redRecoveryNcActive = false;
    redRecoverySearchMode = true;
    redRecoveryOnRedTile = false;
  }
}

static inline float redYawTargetForDir(uint8_t absDir) {
  // direction: N=0/E=1/S=2/W=3 に対し、Yawは N=0, E=-90, S=180, W=+90 に合わせる。
  return normalize180(-90.0f * (float)(absDir & 3));
}

static inline void redNormalConfirmClearCandidateArrayOnly() {
  redNormalConfirmCandidateCount = 0;
  redNormalConfirmLastBestMatch = -32768;
  redNormalConfirmSecondBestMatch = -32768;
  for (uint8_t i = 0; i < RED_NC_CANDIDATE_MAX; i++) {
    redNcCandidates[i].used = false;
    redNcCandidates[i].floor = 0;
    redNcCandidates[i].x = 0;
    redNcCandidates[i].y = 0;
    redNcCandidates[i].dir = 0;
    redNcCandidates[i].redIndex = 0xFF;
    redNcCandidates[i].exitAbsDir = 0;
    redNcCandidates[i].matchCount = 0;
    redNcCandidates[i].mismatchCount = 0;
    redNcCandidates[i].redMatchCount = 0;
    redNcCandidates[i].redMismatchCount = 0;
    redNcCandidates[i].score = -32768;
  }
}

static inline void redNormalConfirmResetObservations() {
  redNormalConfirmObservationCount = 0;
  redNormalConfirmVirtX = 0;
  redNormalConfirmVirtY = 0;
  redNormalConfirmVirtDir = 0;
  for (uint8_t i = 0; i < RED_NC_OBS_MAX; i++) {
    redNcObservations[i].used = false;
    redNcObservations[i].virtX = 0;
    redNcObservations[i].virtY = 0;
    redNcObservations[i].virtDir = 0;
    redNcObservations[i].knownRelMask = 0;
    redNcObservations[i].wallRelMask = 0;
  }
}

static inline void redNormalConfirmResetCandidates() {
  redNormalConfirmClearCandidateArrayOnly();
  redNormalConfirmResetObservations();
  redNormalConfirmClearRedTileObservation();
}

static bool redNormalConfirmCandidateExists(uint8_t floor, int x, int y, uint8_t dir) {
  for (uint8_t i = 0; i < redNormalConfirmCandidateCount; i++) {
    const RedNormalConfirmCandidate &c = redNcCandidates[i];
    if (!c.used) continue;
    if (c.floor == floor && c.x == x && c.y == y && c.dir == (dir & 3)) return true;
  }
  return false;
}

static void redNormalConfirmAddCandidate(uint8_t floor, int x, int y, uint8_t dir, uint8_t redIndex, uint8_t exitAbsDir) {
  if (!floorIndexInRange(floor) || !visInRange(x, y)) return;
  if (redNormalConfirmCandidateExists(floor, x, y, dir)) return;
  if (redNormalConfirmCandidateCount >= RED_NC_CANDIDATE_MAX) return;

  RedNormalConfirmCandidate &c = redNcCandidates[redNormalConfirmCandidateCount++];
  c.used = true;
  c.floor = floor;
  c.x = (int16_t)x;
  c.y = (int16_t)y;
  c.dir = dir & 3;
  c.redIndex = redIndex;
  c.exitAbsDir = exitAbsDir & 3;
  c.matchCount = 0;
  c.mismatchCount = 0;
  c.redMatchCount = 0;
  c.redMismatchCount = 0;
  c.score = -32768;
}

static void redNormalConfirmVirtualToAbsPose(uint8_t floor, int startX, int startY, uint8_t startDir,
                                             int virtX, int virtY, uint8_t virtDir,
                                             uint8_t &outFloor, int &outX, int &outY, uint8_t &outDir) {
  int dx = 0;
  int dy = 0;
  switch (startDir & 3) {
    case 0: dx = virtX;  dy = virtY;  break; // N: そのまま
    case 1: dx = virtY;  dy = -virtX; break; // E: 仮想Nが地図Eへ向く
    case 2: dx = -virtX; dy = -virtY; break; // S
    default:dx = -virtY; dy = virtX;  break; // W
  }

  outFloor = floor;
  outX = startX + dx;
  outY = startY + dy;
  outDir = (uint8_t)((startDir + virtDir) & 3);
}

static bool redNormalConfirmStoreCurrentObservation(uint8_t obsKnownRelMask, uint8_t obsWallRelMask) {
  if (obsKnownRelMask == 0) return false;

  // M_41_23：NCは「そのマス単独判定」に変更する。
  // 前の赤タイル/前のマスの加点・減点を引きずると、逆候補を毎回選ぶ可能性があるため、
  // 観測は常に最新1マス分だけ保持する。
  for (uint8_t i = 0; i < RED_NC_OBS_MAX; i++) {
    redNcObservations[i].used = false;
    redNcObservations[i].virtX = 0;
    redNcObservations[i].virtY = 0;
    redNcObservations[i].virtDir = 0;
    redNcObservations[i].knownRelMask = 0;
    redNcObservations[i].wallRelMask = 0;
  }
  redNormalConfirmObservationCount = 1;

  RedNormalConfirmObservation &o = redNcObservations[0];
  o.used = true;
  o.virtX = redNormalConfirmVirtX;
  o.virtY = redNormalConfirmVirtY;
  o.virtDir = redNormalConfirmVirtDir & 3;
  o.knownRelMask = obsKnownRelMask;
  o.wallRelMask = (uint8_t)(obsWallRelMask & obsKnownRelMask);
  return true;
}

static bool redNormalConfirmCandidateScoreAllObservations(uint8_t floor, int startX, int startY, uint8_t startDir, uint8_t &matchCount, uint8_t &mismatchCount, int16_t &score) {
  matchCount = 0;
  mismatchCount = 0;
  score = 0;

  // M_41_23：NCは最新1マスの壁配置だけで判定する。
  // 赤タイル上や前マスのスコア、ZONE_NORMAL、XY_Numberは使わない。
  // 例：(2,2)の壁配置 vs (3,0)の壁配置だけで、そのマス単独の勝敗を決める。
  if (redNormalConfirmObservationCount == 0) return true;

  const RedNormalConfirmObservation &o = redNcObservations[redNormalConfirmObservationCount - 1];
  if (!o.used) return true;

  uint8_t cf = 0;
  int cx = 0;
  int cy = 0;
  uint8_t cdir = 0;
  redNormalConfirmVirtualToAbsPose(floor, startX, startY, startDir, o.virtX, o.virtY, o.virtDir, cf, cx, cy, cdir);

  if (!floorIndexInRange(cf) || !visInRange(cx, cy)) {
    mismatchCount += 4;
    score -= 40;
    return true;
  }

  if (redNcSnapshotRedGetFloor(cf, cx, cy)) {
    mismatchCount += 3;
    score -= 30;
    return true;
  }

  for (uint8_t rel = 0; rel < 4; rel++) {
    uint8_t relBit = (uint8_t)(1u << rel);
    if ((o.knownRelMask & relBit) == 0) continue;

    uint8_t absDir = (uint8_t)((cdir + rel) & 3);
    uint8_t saved = redNcSnapshotWallStateGetFloor(cf, cx, cy, absDir);
    if (saved == WALL_STATE_UNKNOWN) continue;

    bool obsIsWall = ((o.wallRelMask & relBit) != 0);
    bool savedIsWall = (saved == WALL_STATE_BLOCKED);

    if (obsIsWall == savedIsWall) {
      matchCount++;
      score += 4;
    } else {
      mismatchCount++;
      score -= 8;
    }
  }

  return true;
}


static void redNormalConfirmClearRedTileObservation() {
  redNormalConfirmHasRedTileObservation = false;
  redNormalConfirmRedKnownRelMask = 0;
  redNormalConfirmRedWallRelMask = 0;
  redNormalConfirmRedFacingAbsDir = 0;
}

static bool redNormalConfirmCaptureRedTileObservation(const char* reason) {
  if (!floorIndexInRange(currentFloor) || !visInRange(posX, posY)) return false;
  if (!redGet(posX, posY) && !redRecoveryOnRedTile) return false;

  uint8_t knownRel = 0;
  uint8_t wallRel = 0;
  if (!redNormalConfirmReadRelPatternNoWrite(knownRel, wallRel)) {
    Serial.print("RED_NC REDOBS NG ");
    Serial.println(reason ? reason : "");
    return false;
  }

  redNormalConfirmHasRedTileObservation = true;
  redNormalConfirmRedKnownRelMask = knownRel;
  redNormalConfirmRedWallRelMask = (uint8_t)(wallRel & knownRel);
  redNormalConfirmRedFacingAbsDir = direction & 3;

  Serial.print("RED_NC REDOBS ");
  Serial.print(reason ? reason : "");
  Serial.print(" F");
  Serial.print((unsigned)(currentFloor + 1));
  Serial.print(" X:");
  Serial.print(posX);
  Serial.print(" Y:");
  Serial.print(posY);
  Serial.print(" DIR:");
  Serial.print(dirChar(direction));
  Serial.print(" K:");
  Serial.print(redNormalConfirmRedKnownRelMask, BIN);
  Serial.print(" W:");
  Serial.println(redNormalConfirmRedWallRelMask, BIN);
  return true;
}

static bool redNormalConfirmScoreRedTileObservation(uint8_t redIndex, uint8_t facingAbsDir, uint8_t &matchCount, uint8_t &mismatchCount, int16_t &score) {
  matchCount = 0;
  mismatchCount = 0;
  score = 0;

  if (!redNormalConfirmHasRedTileObservation) return true;
  if (redIndex == 0xFF || redIndex >= redEntranceInfoCount) return true;
  const RedEntranceInfo &r = redEntranceInfo[redIndex];
  if (!r.used || !floorIndexInRange(r.floor) || !visInRange(r.x, r.y)) return true;

  for (uint8_t rel = 0; rel < 4; rel++) {
    uint8_t relBit = (uint8_t)(1u << rel);
    if ((redNormalConfirmRedKnownRelMask & relBit) == 0) continue;

    uint8_t absDir = (uint8_t)((facingAbsDir + rel) & 3);
    uint8_t saved = redNcSnapshotWallStateGetFloor(r.floor, r.x, r.y, absDir);
    if (saved == WALL_STATE_UNKNOWN) continue;

    bool obsIsWall = ((redNormalConfirmRedWallRelMask & relBit) != 0);
    bool savedIsWall = (saved == WALL_STATE_BLOCKED);

    // M_41_21：赤タイル上の壁配置は「矛盾候補を落とす補助情報」に限定する。
    // 一致しても加点しない。未到達の赤タイルは保存壁がUNKNOWNになりやすく、
    // 進入時の赤タイルと同じ壁配置だっただけで逆候補を勝たせないため。
    if (obsIsWall == savedIsWall) {
      matchCount++;
    } else {
      mismatchCount++;
    }
  }

  return true;
}


static void redNormalConfirmBuildCandidates() {
  redNormalConfirmClearCandidateArrayOnly();

  // M_41_28：NC候補は、原則として初回RED保存時/SD LOAD時のスナップショット側 redFlag から作る。
  // live mapはレッドゾーン内の障害物・座標ズレ・リカバリー処理で汚れる可能性があるため、照合元にしない。
  // - redEntranceInfoがある赤：normalSideAbsDirを優先し、その方向だけを候補にする。
  // - redEntranceInfoが無い赤：ノーマル側が不明なので4方向すべてを候補にする。
  // スナップショットが無い場合だけ、保険としてlive redFlagを使う。
  for (uint8_t floor = 0; floor < FLOOR_COUNT; floor++) {
    for (int my = 0; my < VIS_H; my++) {
      for (int mx = 0; mx < VIS_W; mx++) {
        uint8_t redCell = (gRedNcSnapshotValid && redNcSnapshotRedFlagCountAllFloors() > 0)
                            ? savedRedFlag[floor][my][mx]
                            : redFlag[floor][my][mx];
        if (redCell == 0) continue;

        int redX = mx - VIS_OX;
        int redY = my - VIS_OY;
        if (!visInRange(redX, redY)) continue;

        int infoIdx = redEntranceInfoFind(floor, redX, redY);
        if (infoIdx >= 0 && infoIdx < (int)redEntranceInfoCount && redEntranceInfo[infoIdx].used && redEntranceInfo[infoIdx].normalSideAbsDir <= 3) {
          const RedEntranceInfo &r = redEntranceInfo[infoIdx];

          int startX = r.normalX;
          int startY = r.normalY;
          if (!visInRange(startX, startY)) {
            neighborByAbs(r.normalSideAbsDir, r.x, r.y, startX, startY);
          }
          if (!visInRange(startX, startY)) continue;

          uint8_t matchCount = 0;
          uint8_t mismatchCount = 0;
          int16_t score = 0;
          redNormalConfirmCandidateScoreAllObservations(r.floor, startX, startY, r.normalSideAbsDir, matchCount, mismatchCount, score);

          uint8_t redMatch = 0;
          uint8_t redMismatch = 0;
          int16_t redScore = 0;
          redNormalConfirmScoreRedTileObservation((uint8_t)infoIdx, r.normalSideAbsDir, redMatch, redMismatch, redScore);
          (void)redScore;

          uint8_t cf = 0;
          int cx = 0;
          int cy = 0;
          uint8_t cdir = 0;
          redNormalConfirmVirtualToAbsPose(r.floor, startX, startY, r.normalSideAbsDir,
                                           redNormalConfirmVirtX, redNormalConfirmVirtY, redNormalConfirmVirtDir,
                                           cf, cx, cy, cdir);
          if (!floorIndexInRange(cf) || !visInRange(cx, cy)) continue;

          uint8_t beforeCount = redNormalConfirmCandidateCount;
          redNormalConfirmAddCandidate(cf, cx, cy, cdir, (uint8_t)infoIdx, r.normalSideAbsDir);
          if (redNormalConfirmCandidateCount > beforeCount) {
            RedNormalConfirmCandidate &added = redNcCandidates[redNormalConfirmCandidateCount - 1];
            added.matchCount = matchCount;
            added.mismatchCount = mismatchCount;
            added.redMatchCount = redMatch;
            added.redMismatchCount = redMismatch;
            added.score = score;
            if (score > redNormalConfirmLastBestMatch) {
              redNormalConfirmSecondBestMatch = redNormalConfirmLastBestMatch;
              redNormalConfirmLastBestMatch = score;
            } else if (score > redNormalConfirmSecondBestMatch) {
              redNormalConfirmSecondBestMatch = score;
            }
          }
        } else {
          // redEntranceInfoが無い赤は、ノーマル側が不明なので4方向すべてを候補にする。
          for (uint8_t exitAbsDir = 0; exitAbsDir < 4; exitAbsDir++) {
            int startX = 0;
            int startY = 0;
            neighborByAbs(exitAbsDir, redX, redY, startX, startY);
            if (!visInRange(startX, startY)) continue;

            uint8_t matchCount = 0;
            uint8_t mismatchCount = 0;
            int16_t score = 0;
            redNormalConfirmCandidateScoreAllObservations(floor, startX, startY, exitAbsDir, matchCount, mismatchCount, score);

            uint8_t cf = 0;
            int cx = 0;
            int cy = 0;
            uint8_t cdir = 0;
            redNormalConfirmVirtualToAbsPose(floor, startX, startY, exitAbsDir,
                                             redNormalConfirmVirtX, redNormalConfirmVirtY, redNormalConfirmVirtDir,
                                             cf, cx, cy, cdir);
            if (!floorIndexInRange(cf) || !visInRange(cx, cy)) continue;

            uint8_t beforeCount = redNormalConfirmCandidateCount;
            redNormalConfirmAddCandidate(cf, cx, cy, cdir, 0xFF, exitAbsDir);
            if (redNormalConfirmCandidateCount > beforeCount) {
              RedNormalConfirmCandidate &added = redNcCandidates[redNormalConfirmCandidateCount - 1];
              added.matchCount = matchCount;
              added.mismatchCount = mismatchCount;
              added.redMatchCount = 0;
              added.redMismatchCount = 0;
              added.score = score;
              if (score > redNormalConfirmLastBestMatch) {
                redNormalConfirmSecondBestMatch = redNormalConfirmLastBestMatch;
                redNormalConfirmLastBestMatch = score;
              } else if (score > redNormalConfirmSecondBestMatch) {
                redNormalConfirmSecondBestMatch = score;
              }
            }
          }
        }
      }
    }
  }

  // redFlag自体が無い場合だけの保険。通常は使わない。
  if (redNormalConfirmCandidateCount == 0 && redNcSourceRedFlagCountAllFloors() == 0 && floorIndexInRange(currentFloor) && visInRange(posX, posY)) {
    redNormalConfirmAddCandidate(currentFloor, posX, posY, direction & 3, 0xFF, direction & 3);
  }

  redNormalConfirmPrintCandidates("BUILD_FROM_REDFLAG");
}

static void redNormalConfirmPrintCandidates(const char* reason) {
  Serial.print("RED_NC CAND ");
  Serial.print(reason ? reason : "");
  Serial.print(" step:");
  Serial.print((unsigned)redNormalConfirmStepCount);
  Serial.print(" obs:");
  Serial.print((unsigned)redNormalConfirmObservationCount);
  Serial.print(" vpos:");
  Serial.print((int)redNormalConfirmVirtX);
  Serial.print(',');
  Serial.print((int)redNormalConfirmVirtY);
  Serial.print(" vdir:");
  Serial.print(dirChar(redNormalConfirmVirtDir));
  Serial.print(" count:");
  Serial.print((unsigned)redNormalConfirmCandidateCount);
  Serial.print(" E:");
  Serial.print((unsigned)redEntranceInfoCount);
  Serial.print(" R:");
  Serial.print((unsigned)redNcSourceRedFlagCountAllFloors());
  Serial.print(" snap:");
  Serial.print(gRedNcSnapshotValid ? 1 : 0);
  Serial.print(" best:");
  Serial.print(redNormalConfirmLastBestMatch);
  Serial.print(" second:");
  Serial.println(redNormalConfirmSecondBestMatch);

  for (uint8_t i = 0; i < redNormalConfirmCandidateCount; i++) {
    const RedNormalConfirmCandidate &c = redNcCandidates[i];
    if (!c.used) continue;
    Serial.print("RED_NC C[");
    Serial.print((unsigned)i);
    Serial.print("] F");
    Serial.print((unsigned)(c.floor + 1));
    Serial.print(" X:");
    Serial.print((int)c.x);
    Serial.print(" Y:");
    Serial.print((int)c.y);
    Serial.print(" DIR:");
    Serial.print(dirChar(c.dir));
    Serial.print(" redIdx:");
    if (c.redIndex == 0xFF) Serial.print("?");
    else                    Serial.print((unsigned)c.redIndex);
    Serial.print(" exit:");
    Serial.print(dirChar(c.exitAbsDir));
    Serial.print(" match:");
    Serial.print((unsigned)c.matchCount);
    Serial.print(" mis:");
    Serial.print((unsigned)c.mismatchCount);
    Serial.print(" rM:");
    Serial.print((unsigned)c.redMatchCount);
    Serial.print(" rMis:");
    Serial.print((unsigned)c.redMismatchCount);
    Serial.print(" score:");
    Serial.println(c.score);
  }
}

static bool redNormalConfirmReadRelPatternNoWrite(uint8_t &obsKnownRelMask, uint8_t &obsWallRelMask) {
  obsKnownRelMask = 0;
  obsWallRelMask = 0;

  uint8_t wallCnt[4] = {0, 0, 0, 0};
  uint8_t openCnt[4] = {0, 0, 0, 0};

  for (uint8_t i = 0; i < WALL_VOTE_MAX_SAMPLES; i++) {
    serviceSubRx();
    serviceMainTof();
    imuUpdate();
    delay(20);

    const uint16_t relMm[4] = {distMm[2], distMm[1], distMm[5], distMm[0]}; // 前,右,後,左
    for (uint8_t rel = 0; rel < 4; rel++) {
      if (rel == 0 && slopeShouldIgnoreFrontS2ForWallJudge()) continue;

      uint16_t mm = relMm[rel];
      if (!tofValid(mm)) continue;

      uint16_t threshold = spotWallThresholdForRel(rel);
      if (mm < threshold) wallCnt[rel]++;
      else                openCnt[rel]++;
    }
  }

  for (uint8_t rel = 0; rel < 4; rel++) {
    uint8_t total = (uint8_t)(wallCnt[rel] + openCnt[rel]);
    if (total < WALL_VOTE_MIN_SAMPLES_LOCALIZE) continue;

    // M_41_22：NC中の後ろToFは通常壁確認と同じく「壁あり」を採用しない。
    // 赤タイルを出た直後は後ろ側が不安定になりやすいので、後ろOPENだけ参考にする。
    if (rel == 2 && wallCnt[rel] > openCnt[rel]) continue;

    obsKnownRelMask |= (uint8_t)(1u << rel);
    if (wallCnt[rel] > openCnt[rel]) {
      obsWallRelMask |= (uint8_t)(1u << rel);
    } else if (openCnt[rel] > wallCnt[rel]) {
      // open は wall bit を立てない
    } else {
      // 同数なら未確定扱いに戻す
      obsKnownRelMask &= (uint8_t)~(1u << rel);
    }
  }

  return obsKnownRelMask != 0;
}

static bool redNormalConfirmResolveIfUnique(const char* reason) {
  if (redNormalConfirmCandidateCount == 0) return false;

  int bestIndex = -1;
  int16_t bestScore = -32768;
  int16_t secondScore = -32768;
  bool bestTie = false;

  for (uint8_t i = 0; i < redNormalConfirmCandidateCount; i++) {
    const RedNormalConfirmCandidate &cand = redNcCandidates[i];
    if (!cand.used) continue;

    if (bestIndex < 0 || cand.score > bestScore) {
      secondScore = bestScore;
      bestScore = cand.score;
      bestIndex = i;
      bestTie = false;
    } else if (cand.score == bestScore) {
      bestTie = true;
    } else if (cand.score > secondScore) {
      secondScore = cand.score;
    }
  }

  if (bestIndex < 0) return false;
  const RedNormalConfirmCandidate &bestCandForCheck = redNcCandidates[bestIndex];
  if (bestCandForCheck.matchCount < RED_NC_MIN_WALL_MATCH_TO_RESOLVE) return false;
  if (bestScore < (int16_t)RED_NC_MIN_MATCH_TO_RESOLVE) return false;
  if (bestTie) return false;
  if ((bestScore - secondScore) < RED_NC_MIN_SCORE_GAP_TO_RESOLVE) return false;

  redNormalConfirmLastBestMatch = bestScore;
  redNormalConfirmSecondBestMatch = secondScore;

  const RedNormalConfirmCandidate &c = redNcCandidates[bestIndex];

  currentFloor = c.floor;
  posX = c.x;
  posY = c.y;
  direction = c.dir & 3;

  zoneSetFloor(currentFloor, posX, posY, ZONE_NORMAL);
  visInc(posX, posY);

  // 方角も4方向の候補に合わせる。物理RSTではなくYaw基準のソフト補正だけ行う。
  imuUpdate();
  float targetYaw = redYawTargetForDir(direction);
  float diff = normalize180(yawDeg - targetYaw);
  yawOffset += diff;
  yawDeg = targetYaw;
  isYawTared = true;

  Serial.print("RED_NC RESOLVE ");
  Serial.print(reason ? reason : "");
  Serial.print(" F");
  Serial.print((unsigned)(currentFloor + 1));
  Serial.print(" X:");
  Serial.print(posX);
  Serial.print(" Y:");
  Serial.print(posY);
  Serial.print(" DIR:");
  Serial.print(dirChar(direction));
  Serial.print(" score:");
  Serial.print(redNormalConfirmLastBestMatch);
  Serial.print(" second:");
  Serial.print(redNormalConfirmSecondBestMatch);
  Serial.print(" yawTarget:");
  Serial.print(targetYaw, 1);
  Serial.print(" yawDiff:");
  Serial.println(diff, 1);

  redNormalConfirmResetCandidates();
  return true;
}


static bool redNormalConfirmCurrentCellMatches() {
  if (!redNormalConfirmMode) return false;

  uint8_t obsKnownRel = 0;
  uint8_t obsWallRel = 0;
  if (!redNormalConfirmReadRelPatternNoWrite(obsKnownRel, obsWallRel)) return false;

  if (!redNormalConfirmStoreCurrentObservation(obsKnownRel, obsWallRel)) return false;

  redNormalConfirmBuildCandidates();
  if (redNormalConfirmCandidateCount == 0) {
    redNormalConfirmPrintCandidates("ZERO");
    return false;
  }

  redNormalConfirmPrintCandidates("AFTER_LOC_MATCH");
  return redNormalConfirmResolveIfUnique("RED_EXIT_LOC");
}

static inline void redNormalConfirmRotateCandidatesRel(uint8_t relDir) {
  if (!redNormalConfirmMode) return;
  uint8_t r = relDir & 3;
  if (r == 0) return;

  redNormalConfirmVirtDir = (uint8_t)((redNormalConfirmVirtDir + r) & 3);
  redNormalConfirmBuildCandidates();
  redNormalConfirmPrintCandidates("ROTATE_VIRT");
}

static inline void redNormalConfirmAdvanceCandidatesForward() {
  if (!redNormalConfirmMode) return;

  int nx = redNormalConfirmVirtX;
  int ny = redNormalConfirmVirtY;
  switch (redNormalConfirmVirtDir & 3) {
    case 0: ny += 1; break;
    case 1: nx += 1; break;
    case 2: ny -= 1; break;
    default: nx -= 1; break;
  }
  redNormalConfirmVirtX = (int16_t)nx;
  redNormalConfirmVirtY = (int16_t)ny;

  redNormalConfirmBuildCandidates();
  redNormalConfirmPrintCandidates("ADVANCE_VIRT");
}

static inline int chooseRedNormalConfirmRelDirByCandidates() {
  if (redNormalConfirmCandidateCount == 0) return -1;

  const uint8_t relPriority[4] = {0, 3, 1, 2}; // 前→左→右→後。戻り優先点で最終決定する。
  int bestRel = -1;
  int bestScore = -32768;

  for (uint8_t pi = 0; pi < 4; pi++) {
    uint8_t rel = relPriority[pi];
    int score = 0;
    uint8_t validMoves = 0;

    for (uint8_t i = 0; i < redNormalConfirmCandidateCount; i++) {
      const RedNormalConfirmCandidate &c = redNcCandidates[i];
      if (!c.used) continue;

      uint8_t absDir = (c.dir + rel) & 3;
      uint8_t st = wallStateGetFloor(c.floor, c.x, c.y, absDir);
      if (st == WALL_STATE_BLOCKED) continue;

      int nx, ny;
      neighborByAbs(absDir, c.x, c.y, nx, ny);
      if (!visInRange(nx, ny)) continue;
      if (redGetFloor(c.floor, nx, ny)) continue;

      uint16_t curNo = xyNumberGetFloor(c.floor, c.x, c.y);
      uint16_t nextNo = xyNumberGetFloor(c.floor, nx, ny);
      uint8_t nextZone = zoneGetFloor(c.floor, nx, ny);

      // 保存済みノーマルマップ上を進ませる。XY_Numberが小さくなる方向を強く優先。
      if (nextZone == ZONE_NORMAL && nextNo != XY_NUMBER_INF) {
        validMoves++;
        score += 20;
        if (curNo != XY_NUMBER_INF && nextNo < curNo) score += 80;
        else if (curNo != XY_NUMBER_INF && nextNo == curNo) score += 5;
      } else if (st == WALL_STATE_OPEN) {
        // OPENだが未採番なら、候補維持の保険として少しだけ加点。
        validMoves++;
        score += 2;
      }
    }

    if (validMoves == 0) continue;
    score += (int)validMoves * 3;

    if (score > bestScore) {
      bestScore = score;
      bestRel = rel;
    }
  }

  if (bestRel >= 0) {
    Serial.print("RED_NC NEXT rel:");
    Serial.print(bestRel);
    Serial.print(" score:");
    Serial.println(bestScore);
  }
  return bestRel;
}

static inline int chooseRedNormalConfirmRelDir() {
  int candRel = chooseRedNormalConfirmRelDirByCandidates();
  if (candRel >= 0) return candRel;

  // 候補が崩れた場合の保険。従来の推定座標ベースで最大3マスだけ進める。
  int retRel = chooseReturnRelDirByXY_Number();
  if (retRel >= 0) return retRel;

  if (canMoveByRelFromWallMap(0)) return 0;
  if (canMoveByRelFromWallMap(3)) return 3;
  if (canMoveByRelFromWallMap(1)) return 1;
  if (canMoveByRelFromWallMap(2)) return 2;
  return -1;
}

static inline bool canFrontierTargetMoveByRel(uint8_t relDir, uint8_t zone) {
  uint8_t absDir = (direction + relDir) & 3;
  if (wallStateGet(posX, posY, absDir) != WALL_STATE_OPEN) return false;

  int nx, ny;
  neighborByAbs(absDir, posX, posY, nx, ny);
  return isCellUsableForFrontierBfs(nx, ny, zone);
}

static inline int chooseFloorLinkRelDirByFrontier_Number() {
  uint16_t curNo = frontierNumberGet(posX, posY);
  if (curNo == FRONTIER_NUMBER_INF) return -1;

  int chosen = -1;
  uint16_t bestNo = FRONTIER_NUMBER_INF;
  uint8_t linkMask = floorLinkMaskGet(currentFloor, posX, posY);
  for (uint8_t nf = 0; nf < FLOOR_COUNT; nf++) {
    if ((linkMask & (uint8_t)(1u << nf)) == 0) continue;
    uint8_t absDir = floorLinkDirGet(currentFloor, posX, posY, nf);
    if (absDir > 3) continue;
    int tx, ty;
    floorLinkTargetGet(currentFloor, posX, posY, nf, tx, ty);
    uint16_t nextNo = frontierNumberGetFloor(nf, tx, ty);
    if (nextNo == FRONTIER_NUMBER_INF) continue;
    // 2026.5.17：FRONTIER_TARGET中は同番号のフロアリンクへ入らない。
    // F1に未探索が残っているのに、F2へ吸い込まれるループを防ぐ。
    if (nextNo >= curNo) continue;
    if (chosen < 0 || nextNo < bestNo) {
      chosen = (int)((absDir + 4 - direction) & 3);
      bestNo = nextNo;
    }
  }
  return chosen;
}

static inline int chooseFrontierTargetRelDirByFrontier_Number(uint8_t zone) {
  rebuildFrontier_NumberAll(zone);

  uint16_t curNo = frontierNumberGet(posX, posY);
  if (curNo == FRONTIER_NUMBER_INF) return -1;

  int linkRel = chooseFloorLinkRelDirByFrontier_Number();
  if (linkRel >= 0) return linkRel;

  const int prio[4] = {0, 3, 1, 2}; // 移動中は前→左→右→後で無駄な旋回を減らす
  int chosen = -1;
  uint16_t bestNo = FRONTIER_NUMBER_INF;

  for (int k = 0; k < 4; k++) {
    int rel = prio[k];
    if (!canFrontierTargetMoveByRel((uint8_t)rel, zone)) continue;

    int nx, ny;
    neighborByRel((uint8_t)rel, posX, posY, direction, nx, ny);
    uint16_t nextNo = frontierNumberGet(nx, ny);
    if (nextNo == FRONTIER_NUMBER_INF) continue;
    if (nextNo >= curNo) continue;

    if (chosen < 0 || nextNo < bestNo) {
      chosen = rel;
      bestNo = nextNo;
    }
  }
  return chosen;
}

static inline bool isExploreCandidateAllowedForZone(uint8_t absDir, uint8_t zone) {
  int nx, ny;
  neighborByAbs(absDir, posX, posY, nx, ny);
  if (!visInRange(nx, ny)) return false;

  // ノーマル探索中は、赤入口・レッドゾーン側を通常探索候補にしない。
  // 赤入口へはN-または5分保険のRed_Numberモードで向かう。
  if (zone == ZONE_NORMAL) {
    if (redGet(nx, ny)) return false;
    if (zoneGet(nx, ny) == ZONE_RED) return false;
    return true;
  }

  // レッド探索中は、ノーマル側へ戻る方向を通常探索候補にしない。
  // 脱出はR-後のredExitModeに任せる。
  if (zone == ZONE_RED) {
    if (zoneGet(nx, ny) == ZONE_NORMAL) return false;
    return true;
  }

  return false;
}

static inline bool canChooseOpenUnvisitedFrontierRel(uint8_t relDir, uint8_t zone) {
  // SLセルでは探索候補を作らない。通路/RETURN経路としてだけ使う。
  // ただし坂出口マスは通常探索へ戻すため、slopeExitIgnoreマスクがある場合は除外しない。
  if (slopeTransitCellGetFloor(currentFloor, posX, posY) &&
      ((slopeExitIgnoreUnknownMap[currentFloor][posY + VIS_OY][posX + VIS_OX] & 0x0F) == 0)) return false;

  uint8_t absDir = (direction + relDir) & 3;
  if (wallStateGet(posX, posY, absDir) != WALL_STATE_OPEN) return false;
  if (!isExploreCandidateAllowedForZone(absDir, zone)) return false;

  int nx, ny;
  neighborByAbs(absDir, posX, posY, nx, ny);
  return (visGet(nx, ny) == 0);
}

static inline bool canChooseUnknownAbsDir(uint8_t absDir, uint8_t zone) {
  // SLセルではUNKNOWN確認もしない。坂マスで左/右旋回へ入る事故を防ぐ。
  // ただし坂出口マスは左右UNKNOWNを候補へ戻すため、slopeExitIgnoreマスクがある場合は除外しない。
  if (slopeTransitCellGetFloor(currentFloor, posX, posY) &&
      ((slopeExitIgnoreUnknownMap[currentFloor][posY + VIS_OY][posX + VIS_OX] & 0x0F) == 0)) return false;

  if (wallStateGet(posX, posY, absDir) != WALL_STATE_UNKNOWN) return false;
  // 坂出口マスでは後ろ方向UNKNOWNだけ候補から外す。左右UNKNOWNは候補に戻す。
  if (slopeExitIgnoreUnknownDirGetFloor(currentFloor, posX, posY, absDir)) return false;
  if (!isExploreCandidateAllowedForZone(absDir, zone)) return false;

  // 2026.5.17：UNKNOWN(・)は訪問回数に関係なく探索候補にする。
  // 実際に進んで壁なら両タッチでBLOCKED、通過できればOPENに確定する。
  return true;
}

static inline bool canChooseUnknownFrontierRel(uint8_t relDir, uint8_t zone) {
  uint8_t absDir = (direction + relDir) & 3;
  return canChooseUnknownAbsDir(absDir, zone);
}

static inline void unknownSweepReset() {
  gUnknownSweepActive = false;
}

static inline int relFromAbsDirNow(uint8_t absDir) {
  return (int)((absDir + 4 - direction) & 3);
}

static inline int chooseUnknownSweepRelDir(uint8_t zone) {
  if (returnMode || redExitMode) {
    unknownSweepReset();
    return -1;
  }
  if (zone != ZONE_NORMAL && zone != ZONE_RED) {
    unknownSweepReset();
    return -1;
  }
  if (zoneGet(posX, posY) != zone) {
    unknownSweepReset();
    return -1;
  }

  // マスが変わったら、そのマスへ入った時点の向きを新しい基準にする。
  if (!gUnknownSweepActive ||
      gUnknownSweepFloor != currentFloor ||
      gUnknownSweepX != posX ||
      gUnknownSweepY != posY) {
    gUnknownSweepActive = true;
    gUnknownSweepFloor = currentFloor;
    gUnknownSweepX = posX;
    gUnknownSweepY = posY;
    gUnknownSweepBaseDir = direction;
  }

  // 基準方向から見た 左→前→右→後ろ の順で、UNKNOWN(・)だけを確認する。
  const int basePrio[4] = {3, 0, 1, 2};
  for (int k = 0; k < 4; k++) {
    uint8_t targetAbsDir = (uint8_t)((gUnknownSweepBaseDir + basePrio[k]) & 3);
    if (canChooseUnknownAbsDir(targetAbsDir, zone)) {
      return relFromAbsDirNow(targetAbsDir);
    }
  }

  // このマスの確認可能なUNKNOWNがなくなったら通常探索へ戻す。
  unknownSweepReset();
  return -1;
}

static inline int choosePriorityFrontierRelDir(uint8_t zone) {
  if (returnMode || redExitMode) {
    unknownSweepReset();
    return -1;
  }
  if (zone != ZONE_NORMAL && zone != ZONE_RED) {
    unknownSweepReset();
    return -1;
  }
  if (zoneGet(posX, posY) != zone) {
    unknownSweepReset();
    return -1;
  }

  // 第1優先：UNKNOWN確認モード。
  // そのマスに入った時の向きを基準に、左→前→右→後ろでUNKNOWN(・)を潰す。
  // OPEN未訪問よりも優先する。
  int sweepRel = chooseUnknownSweepRelDir(zone);
  if (sweepRel >= 0) return sweepRel;

  const int prio[4] = {3, 0, 1, 2}; // 左→前→右→後

  // 第2優先：壁なし確定で、隣が未訪問の方向。
  for (int k = 0; k < 4; k++) {
    int rel = prio[k];
    if (canChooseOpenUnvisitedFrontierRel((uint8_t)rel, zone)) return rel;
  }

  return -1;
}

static void enterFrontierFallbackExtLH(const char* reason) {
  if (gFrontierFallbackExtLH) return;

  gFrontierFallbackExtLH = true;
  frontierTargetMode = false;
  frontierTargetZone = ZONE_UNKNOWN;

  Serial.print("FRONTIER_FALLBACK FBK: ");
  Serial.print(reason ? reason : "UNKNOWN");
  Serial.print(" F");
  Serial.print((unsigned)(currentFloor + 1));
  Serial.print(" X:");
  Serial.print(posX);
  Serial.print(" Y:");
  Serial.print(posY);
  Serial.print(" VIS:");
  Serial.println((unsigned)visGet(posX, posY));
}

static bool redRecoveryReadOpenRelMask(uint8_t &openRelMask) {
  openRelMask = 0;
  uint8_t knownRel = 0;
  uint8_t wallRel = 0;
  bool ok = redNormalConfirmReadRelPatternNoWrite(knownRel, wallRel);

  // センサーが取れた方向は壁なら閉、OPENなら開。
  // 取れなかった方向は、古い壁マップを信用しないため候補として残す。
  for (uint8_t rel = 0; rel < 4; rel++) {
    uint8_t bit = (uint8_t)(1u << rel);
    if ((knownRel & bit) == 0) {
      openRelMask |= bit;
      continue;
    }
    if ((wallRel & bit) == 0) openRelMask |= bit;
  }
  return ok;
}

static int redRecoveryChooseExploreRelDir(bool isOnRedTile) {
  uint8_t openMask = 0;
  redRecoveryReadOpenRelMask(openMask);

  if (openMask == 0) return 2;

  if (isOnRedTile) {
    // 赤タイル到達後の脱出時だけ、Uターンを最後にする。
    const uint8_t prioExit[4] = {0, 3, 1, 2}; // 前→左→右→後
    for (uint8_t i = 0; i < 4; i++) {
      uint8_t rel = prioExit[i];
      if ((openMask & (uint8_t)(1u << rel)) != 0) return rel;
    }
    return 2;
  }

  // 赤探索中は拡張左手法：訪問回数最小、同点なら左→前→右→後。
  const uint8_t prioExplore[4] = {3, 0, 1, 2};
  uint16_t bestVisit = 65535;
  int bestRel = -1;
  for (uint8_t i = 0; i < 4; i++) {
    uint8_t rel = prioExplore[i];
    if ((openMask & (uint8_t)(1u << rel)) == 0) continue;
    int nx, ny;
    neighborByRel(rel, posX, posY, direction, nx, ny);
    uint16_t v = redRecoveryVisitGet(nx, ny);
    if (bestRel < 0 || v < bestVisit) {
      bestRel = rel;
      bestVisit = v;
    }
  }
  return (bestRel >= 0) ? bestRel : 2;
}

static bool redRecoveryHandleAtStop() {
  if (!redRecoverySearchMode || !inRedZone || returnMode || redNormalConfirmMode) return false;

  frontierTargetMode = false;
  frontierTargetZone = ZONE_UNKNOWN;
  redExitMode = false;

  bool isOnRedTile = redRecoveryOnRedTile;
  int rel = redRecoveryChooseExploreRelDir(isOnRedTile);

  if (isOnRedTile) {
    redExitLeavePending = true;
    redRecoveryNcActive = true;
    if (rel == 0) {
      redNormalConfirmCaptureRedTileObservation("RECOVERY_BEFORE_LEAVE_RED");
      return true;
    }
    if (rel == 1) { turnRight90Yaw(speed); waitMs(STOP_MS); return true; }
    if (rel == 3) { turnLeft90Yaw(speed);  waitMs(STOP_MS); return true; }
    if (rel == 2) { turnBack180Yaw2x90(); return true; }
    return true;
  }

  if (rel == 0) return true;
  if (rel == 1) { turnRight90Yaw(speed); waitMs(STOP_MS); return true; }
  if (rel == 3) { turnLeft90Yaw(speed);  waitMs(STOP_MS); return true; }
  if (rel == 2) { turnBack180Yaw2x90(); return true; }
  return true;
}

static inline bool shouldUseFrontierTargetMode(uint8_t zone) {
  if (gFrontierFallbackExtLH) return false;
  if (returnMode || redExitMode) return false;
  if (zone != ZONE_NORMAL && zone != ZONE_RED) return false;
  if (zoneGet(posX, posY) != zone) return false;
  if (!hasFrontierInZone(zone)) return false;

  // 今いるマスに未探索方向がある場合は、従来のその場判断を優先する。
  if (isFrontierCellForZone(posX, posY, zone)) return false;

  return true;
}

// 2026.5.23：坂入口/坂出口マス専用の後方選択禁止。
// 坂/階段の端で後ろ（坂方向）へ戻ると、未探索が残ったり、坂を往復して迷走しやすい。
// そのため通常探索・フロンティア・リターンを問わず、まず前→左→右を優先し、最後だけ後ろを許可する。
static inline bool slopeEndpointNoUTurnCellNow() {
  if (!floorIndexInRange(currentFloor) || !visInRange(posX, posY)) return false;

  int mx = posX + VIS_OX;
  int my = posY + VIS_OY;

  // 坂出口：PENDING中やRAMP確定後に後ろUNKNOWN除外マスクが立つ。
  if ((slopeExitIgnoreUnknownMap[currentFloor][my][mx] & 0x0F) != 0) return true;

  // 坂入口/出口：RAMP確定後はフロアリンクが立つ。
  if (floorLinkMaskGet(currentFloor, posX, posY) != 0) return true;

  return false;
}

static inline bool slopeEndpointCandidateAllowedAbs(uint8_t absDir, uint8_t zone) {
  if (absDir > 3) return false;
  if (zone != ZONE_NORMAL && zone != ZONE_RED) return false;
  if (zoneGet(posX, posY) != zone) return false;
  if (!isExploreCandidateAllowedForZone(absDir, zone)) return false;
  return true;
}

static inline void slopeEndpointSweepReset() {
  gSlopeEndpointSweepActive = false;
  gSlopeEndpointSweepTriedMask = 0;
}

static inline uint8_t slopeEndpointAbsDirByStage(uint8_t stage) {
  // stage 0=前, 1=左, 2=右, 3=後ろ。すべて「坂端マスへ入った時の基準方向」から見た絶対方向。
  static const int8_t offset[4] = {0, 3, 1, 2};
  if (stage > 3) stage = 3;
  return (uint8_t)((gSlopeEndpointSweepBaseDir + offset[stage]) & 3);
}

static inline bool slopeEndpointBasicAllowedAbs(uint8_t absDir, uint8_t zone) {
  if (absDir > 3) return false;
  if (zone != ZONE_NORMAL && zone != ZONE_RED) return false;
  if (zoneGet(posX, posY) != zone) return false;
  return isExploreCandidateAllowedForZone(absDir, zone);
}

static inline bool slopeEndpointFirstThreeFinished() {
  // 前・左・右を「試した」または「候補外」として処理し終えたか。
  return (gSlopeEndpointSweepTriedMask & 0x07) == 0x07;
}

static inline int slopeEndpointRelTowardAbsNoDirectUTurn(uint8_t targetAbsDir) {
  int rel = relFromAbsDirNow(targetAbsDir);
  // 坂端マスでは、いきなり180°回転しない。必要なら右90°を2回に分けて向きを合わせる。
  // これで段差上の不要な180°旋回を避け、前→左→右→後ろの固定順を守る。
  if (rel == 2) return 1;
  return rel;
}

static inline int chooseSlopeEndpointNoUTurnRelDir(uint8_t zone) {
  // 2026.5.23：坂/階段の入口・出口では、現在向き基準ではなく、入口時の基準方向で
  // 前→左→右→後ろの順に固定する。段差上で不要な左旋回から壁に当たる事故を減らす。
  // ローカライズ中だけは位置照合を優先するため、このガードを使わない。
  if (gLocalizationActive) {
    slopeEndpointSweepReset();
    return -1;
  }
  if (!slopeEndpointNoUTurnCellNow()) {
    slopeEndpointSweepReset();
    return -1;
  }

  if (!gSlopeEndpointSweepActive ||
      gSlopeEndpointSweepFloor != currentFloor ||
      gSlopeEndpointSweepX != posX ||
      gSlopeEndpointSweepY != posY) {
    gSlopeEndpointSweepActive = true;
    gSlopeEndpointSweepFloor = currentFloor;
    gSlopeEndpointSweepX = posX;
    gSlopeEndpointSweepY = posY;
    gSlopeEndpointSweepBaseDir = direction;
    gSlopeEndpointSweepTriedMask = 0;

    Serial.print("SL END SWEEP BEGIN F");
    Serial.print((unsigned)(currentFloor + 1));
    Serial.print(" X:");
    Serial.print(posX);
    Serial.print(" Y:");
    Serial.print(posY);
    Serial.print(" baseAbs:");
    Serial.println((unsigned)gSlopeEndpointSweepBaseDir);
  }

  // stage 0=前、1=左、2=右、3=後ろ。後ろは前・左・右を処理し終えた後だけ許可する。
  for (uint8_t stage = 0; stage < 4; stage++) {
    if (stage == 3 && !slopeEndpointFirstThreeFinished()) continue;
    if ((gSlopeEndpointSweepTriedMask & (uint8_t)(1u << stage)) != 0) continue;

    uint8_t absDir = slopeEndpointAbsDirByStage(stage);
    if (!slopeEndpointBasicAllowedAbs(absDir, zone)) {
      // 候補外方向は処理済みにして、同じマスで同じ方向に詰まらないようにする。
      gSlopeEndpointSweepTriedMask |= (uint8_t)(1u << stage);
      continue;
    }

    int rel = slopeEndpointRelTowardAbsNoDirectUTurn(absDir);

    frontierTargetMode = false;
    frontierTargetZone = ZONE_UNKNOWN;
    if (returnMode || redExitMode) {
      returnMode = false;
      redExitMode = false;
      redExitLeavePending = false;
    }

    Serial.print("SL END FIXED ");
    Serial.print((stage == 0) ? "FRONT" : (stage == 1) ? "LEFT" : (stage == 2) ? "RIGHT" : "BACK");
    Serial.print(" F");
    Serial.print((unsigned)(currentFloor + 1));
    Serial.print(" X:");
    Serial.print(posX);
    Serial.print(" Y:");
    Serial.print(posY);
    Serial.print(" baseAbs:");
    Serial.print((unsigned)gSlopeEndpointSweepBaseDir);
    Serial.print(" targetAbs:");
    Serial.print((unsigned)absDir);
    Serial.print(" rel:");
    Serial.print(rel);
    Serial.print(" tried:");
    Serial.println((unsigned)gSlopeEndpointSweepTriedMask, BIN);

    // 目標方向を向いた状態で前進を返す時だけ「試した」と記録する。
    // 回転だけの段階では記録しないので、次のdecideで同じ目標方向へ向き合わせる。
    if (rel == 0) {
      gSlopeEndpointSweepTriedMask |= (uint8_t)(1u << stage);
    }
    return rel;
  }

  // 全方向が候補外または試行済みなら通常ロジックへ戻す。
  // ここまで来るケースは少ないが、永久ループを避けるためリセットする。
  Serial.print("SL END FIXED DONE F");
  Serial.print((unsigned)(currentFloor + 1));
  Serial.print(" X:");
  Serial.print(posX);
  Serial.print(" Y:");
  Serial.println(posY);
  slopeEndpointSweepReset();
  return -1;
}
// 2026.5.17：SLセル上では通常探索の左/右旋回判断に入らない。
// 坂セルは探索対象ではなく通過経路として扱うため、基本は正面通過だけを優先する。
static inline int chooseSlopeTransitPassThroughRelDir() {
  if (!slopeTransitCellGetFloor(currentFloor, posX, posY)) return -1;
  // 2026.5.23：坂出口マスは後ろUNKNOWNだけ除外する通常探索マス。
  // 古いSLフラグが残っていても、SL通過ロックでUターンさせない。
  if ((slopeExitIgnoreUnknownMap[currentFloor][posY + VIS_OY][posX + VIS_OX] & 0x0F) != 0) return -1;
  if (returnMode || redExitMode || gLocalizationActive) return -1;

  if (canMoveByRelFromWallMap(0)) return 0; // 坂方向へそのまま通過
  if (canReturnMoveByRel(2)) return 2;      // 正面が確定壁なら、確定OPENの後ろだけ許可
  return -2;                                // SL上で探索旋回させない
}

static void decideNextMoveAtStop_ExtLH() {
  gNeedReDecideAtStop = false;

  // 2026.5.20：前進地形通過中は、探索/RETURN/赤入口判断よりも前進を最優先する。
  // ここで左・右・180°旋回、UNKNOWN確認、Frontier判断を完全に止める。
  if (terrainPassMotionLocked()) {
    frontierTargetMode = false;
    frontierTargetZone = ZONE_UNKNOWN;
    unknownSweepReset();
    return;
  }

  if (redRecoveryShouldStart()) {
    redRecoveryStart("VISIT4");
  } else if (redRecoveryTimeShouldStart()) {
    redRecoveryStart("TIME6");
  }

  // 2026.5.31 M_41_17：赤入口から出たあと、即RETURNせず最大3マスだけ赤脱出専用ローカライズを行う。
  if (redNormalConfirmMode && !returnMode) {
    if (redNormalConfirmCurrentCellMatches()) {
      redNormalConfirmMode = false;
      redNormalConfirmStepCount = 0;
      redNormalConfirmResetCandidates();
      redRecoverySearchMode = false;
      redRecoveryOnRedTile = false;
      redRecoveryNcActive = false;
      inRedZone = false;
      redExitMode = false;
      redExitLeavePending = false;
      rebuildXY_NumberAll();
      rebuildRed_NumberAll();
      enterReturnMode("RED_NORMAL_CONFIRMED");
      // このまま下のreturnMode処理へ進み、補正済みの座標・方角で帰還判断へ進む。
    } else {
      if (redNormalConfirmStepCount >= RED_NORMAL_CONFIRM_MAX_STEPS) {
        cancelRedNormalConfirmMode("NO_MATCH_3TILES");
        showSdStatusForMs("NC NG", 500);
        return;
      }

      int ncRel = chooseRedNormalConfirmRelDir();
      if (ncRel >= 0) {
        redNormalConfirmStepCount++;
        showSdStatusForMs("NC", 300);
        if (ncRel == 0) return;
        redNormalConfirmRotateCandidatesRel((uint8_t)ncRel);
        if (ncRel == 1) { turnRight90Yaw(speed); waitMs(STOP_MS); return; }
        if (ncRel == 3) { turnLeft90Yaw(speed);  waitMs(STOP_MS); return; }
        if (ncRel == 2) { turnBack180Yaw2x90(); return; }
      }

      cancelRedNormalConfirmMode("NO_ROUTE");
      showSdStatusForMs("NC NG", 500);
      return;
    }
  }

  if (redRecoveryHandleAtStop()) {
    return;
  }

  uint8_t exploreZone = inRedZone ? ZONE_RED : ZONE_NORMAL;

  // 2026.5.23：坂/階段入口・出口マスでは、全モードで後方選択を最後に回す。
  // RETURN/Frontier/FBKより先に処理し、まず前→左→右を固定順で試す。
  int slopeEndRel = chooseSlopeEndpointNoUTurnRelDir(exploreZone);
  if (slopeEndRel >= 0) {
    if (slopeEndRel == 0) return;
    if (slopeEndRel == 1) { turnRight90Yaw(speed); waitMs(STOP_MS); return; }
    if (slopeEndRel == 2) { turnBack180Yaw2x90(); return; }
    if (slopeEndRel == 3) { turnLeft90Yaw(speed);  waitMs(STOP_MS); return; }
  }

  // 第4段階B：スタート地点は1回目から、その他のマスは2回目以降、
  // その場ToFでUNKNOWN壁を再確認する。
  if (shouldSpotCheckCurrentCellWalls()) {
    classifyCurrentCellWallsAtStop(true);
  }

  // 第2段階：ノーマル探索完了(N-)なのに赤入口未発見なら、行くべき赤入口が無いので帰還へ入る。
  if (shouldReturnBecauseNormalDoneNoRed()) {
    enterReturnMode("NORMAL_DONE_NO_RED");
  }

  // 第3段階：レッドゾーン探索完了(R-)なら、赤入口へ戻ってノーマル側へ脱出する。
  if (shouldStartRedExitMode()) {
    startRedExitMode("RED_FRONTIER_DONE");
  }

  if (redExitMode && inRedZone && !returnMode) {
    if (redGet(posX, posY)) {
      int exitRel = chooseRedExitToNormalRelDir();
      if (exitRel >= 0) {
        redExitLeavePending = true;
        if (exitRel == 0) {
          redNormalConfirmCaptureRedTileObservation("BEFORE_LEAVE_RED");
          return;
        }
        if (exitRel == 1) { turnRight90Yaw(speed); waitMs(STOP_MS); return; }
        if (exitRel == 3) { turnLeft90Yaw(speed);  waitMs(STOP_MS); return; }
        if (exitRel == 2) { turnBack180Yaw2x90(); return; }
      }

      // 赤入口からノーマル側へ出る方向が作れない場合は、通常探索へ戻す。
      redExitMode = false;
      redExitLeavePending = false;
    } else {
      int redRel = chooseRedTargetRelDirByRed_Number();
      if (redRel == 0) return;
      if (redRel == 1) { turnRight90Yaw(speed); waitMs(STOP_MS); return; }
      if (redRel == 3) { turnLeft90Yaw(speed);  waitMs(STOP_MS); return; }
      if (redRel == 2) { turnBack180Yaw2x90(); return; }

      // 赤入口までのRed_Number経路が作れない場合は、通常探索へ戻す。
      redExitMode = false;
      redExitLeavePending = false;
    }
  }

  if (returnMode) {
    int retRel = chooseReturnRelDirByXY_Number();
    if (retRel == 0) return;
    if (retRel == 1) { turnRight90Yaw(speed); waitMs(STOP_MS); return; }
    if (retRel == 3) { turnLeft90Yaw(speed);  waitMs(STOP_MS); return; }
    if (retRel == 2) { turnBack180Yaw2x90(); return; }
    // 下がる方向が無いときは通常探索へ戻る
  }

  if (shouldRedTargetMode()) {
    frontierTargetMode = false;
    frontierTargetZone = ZONE_UNKNOWN;

    if (redGet(posX, posY)) {
      processRedConfirmedCurrentTile();
      return;
    }

    int redRel = chooseRedTargetRelDirByRed_Number();
    if (redRel == 0) return;
    if (redRel == 1) { turnRight90Yaw(speed); waitMs(STOP_MS); return; }
    if (redRel == 3) { turnLeft90Yaw(speed);  waitMs(STOP_MS); return; }
    if (redRel == 2) { turnBack180Yaw2x90(); return; }
    // 赤入口までのOPEN経路がまだ作れない場合は、通常探索へ戻る。
    // 5分保険で赤入口未発見の場合は、shouldRedTargetMode()自体がfalseなので探索継続する。
  }

  // SLセル（坂セル）は未探索候補ではなく通過経路。ここで左/右探索旋回へ入らないようにする。
  int slPassRel = chooseSlopeTransitPassThroughRelDir();
  if (slPassRel == 0) return;
  if (slPassRel == 2) { turnBack180Yaw2x90(); return; }
  if (slPassRel == -2) return;

  // 第4段階C：フロンティアセル上では、通常の訪問回数優先よりも未探索方向を優先する。
  // 1) UNKNOWN確認モード(入った時の向き基準で左→前→右→後)
  // 2) 壁なし確定＆隣未訪問 → 3) 通常の拡張左手法
  int priorityRel = choosePriorityFrontierRelDir(exploreZone);
  if (priorityRel >= 0) {
    frontierTargetMode = false;
    frontierTargetZone = ZONE_UNKNOWN;

    if (priorityRel == 0) return;
    if (priorityRel == 1) { turnRight90Yaw(speed); waitMs(STOP_MS); return; }
    if (priorityRel == 3) { turnLeft90Yaw(speed);  waitMs(STOP_MS); return; }
    if (priorityRel == 2) { turnBack180Yaw2x90(); return; }
  }

  // 第4段階A：現在地に未探索方向が無い場合、同じゾーン内の最寄りフロンティアへBFSで向かう。
  // 赤入口ターゲット中・レッド脱出中・帰還中はここには入らない.
  if (!gFrontierFallbackExtLH && frontierTargetMode && frontierTargetZone == exploreZone &&
      visGet(posX, posY) >= FRONTIER_FALLBACK_VISIT_LIMIT && hasFrontierInZone(exploreZone)) {
    enterFrontierFallbackExtLH("VIS_LIMIT_BEFORE_TARGET");
  }

  if (shouldUseFrontierTargetMode(exploreZone)) {
    if (!frontierTargetMode || frontierTargetZone != exploreZone) {
      frontierTargetMode = true;
      frontierTargetZone = exploreZone;
      Serial.print("FRONTIER_TARGET: ");
      Serial.println((exploreZone == ZONE_RED) ? "RED" : "NORMAL");
    }

    if (visGet(posX, posY) >= FRONTIER_FALLBACK_VISIT_LIMIT && hasFrontierInZone(exploreZone)) {
      enterFrontierFallbackExtLH("VIS_LIMIT_IN_TARGET");
    } else {
      int frRel = chooseFrontierTargetRelDirByFrontier_Number(exploreZone);
      if (frRel == 0) return;
      if (frRel == 1) { turnRight90Yaw(speed); waitMs(STOP_MS); return; }
      if (frRel == 3) { turnLeft90Yaw(speed);  waitMs(STOP_MS); return; }
      if (frRel == 2) { turnBack180Yaw2x90(); return; }

      // 経路が作れない場合は、BFS移動を解除して通常探索へ戻す。
      frontierTargetMode = false;
      frontierTargetZone = ZONE_UNKNOWN;
    }
  } else {
    frontierTargetMode = false;
    frontierTargetZone = ZONE_UNKNOWN;
  }

  bool openRel[4];
  for (int i = 0; i < 4; i++) openRel[i] = canMoveByRelFromWallMap((uint8_t)i);

  if (!openRel[0] && !openRel[1] && !openRel[2] && !openRel[3]) {
    turnBack180Yaw2x90();
    return;
  }

  uint16_t cntRel[4] = {65535,65535,65535,65535};
  for (int rel = 0; rel < 4; rel++) {
    if (!openRel[rel]) continue;
    int nx, ny;
    neighborByRel((uint8_t)rel, posX, posY, direction, nx, ny);
    cntRel[rel] = visGet(nx, ny);
  }

  uint16_t minCnt = 65535;
  for (int rel = 0; rel < 4; rel++) {
    if (openRel[rel] && cntRel[rel] < minCnt) minCnt = cntRel[rel];
  }

  int chosen = -1;
  const int prio[4] = {3, 0, 1, 2}; // 左→前→右→後
  for (int k = 0; k < 4; k++) {
    int rel = prio[k];
    if (openRel[rel] && cntRel[rel] == minCnt) { chosen = rel; break; }
  }
  if (chosen < 0) {
    for (int rel = 0; rel < 4; rel++) if (openRel[rel]) { chosen = rel; break; }
  }

  if (chosen == 0) return;
  if (chosen == 1) { turnRight90Yaw(speed); waitMs(STOP_MS); return; }
  if (chosen == 3) { turnLeft90Yaw(speed);  waitMs(STOP_MS); return; }
  turnBack180Yaw2x90();
}


// =====================
// SD LOAD後の座標不明ローカライズ
// =====================
static inline bool savedCellHasAnyInfoByIndex(int mx, int my) {
  if (mx < 0 || mx >= VIS_W || my < 0 || my >= VIS_H) return false;

  // 2026.5.17：XY_Number / Red_Number はBFS計算値であり、実測証拠ではない。
  // それだけで候補にすると、壁情報が薄いマスまで候補に残り、Cが減らない原因になる。
  // 候補開始点は、訪問・壁Known・色・被災者のような「観測済み情報」があるマスに限定する。
  if (savedVisitCnt[FLOOR_1ST][my][mx] != 0) return true;
  if (savedVictimFlag[FLOOR_1ST][my][mx] != 0) return true;
  if (savedBlueFlag[FLOOR_1ST][my][mx] != 0) return true;
  if (savedRedFlag[FLOOR_1ST][my][mx] != 0) return true;
  if ((savedWallKnownMap[FLOOR_1ST][my][mx] & 0x0F) != 0) return true;
  return false;
}

static inline bool tempCellHasAnyInfoByIndex(int mx, int my) {
  if (mx < 0 || mx >= VIS_W || my < 0 || my >= VIS_H) return false;
  if (visitCnt[currentFloor][my][mx] != 0) return true;
  if (blueFlag[currentFloor][my][mx] != 0) return true;
  if (redFlag[currentFloor][my][mx] != 0) return true;
  if (wallKnownMap[currentFloor][my][mx] != 0) return true;
  if (wallExistMap[currentFloor][my][mx] != 0) return true;
  return false;
}

static void copyActiveMapToSavedForLocalization() {
  memcpy(savedVisitCnt, visitCnt, sizeof(visitCnt));
  memcpy(savedVictimFlag, victimFlag, sizeof(victimFlag));
  memcpy(savedBlueFlag, blueFlag, sizeof(blueFlag));
  memcpy(savedRedFlag, redFlag, sizeof(redFlag));
  memcpy(savedBumpFlag, bumpFlag, sizeof(bumpFlag));
  memcpy(savedZoneFlag, zoneFlag, sizeof(zoneFlag));
  memcpy(savedXY_Number, XY_Number, sizeof(XY_Number));
  memcpy(savedRed_Number, Red_Number, sizeof(Red_Number));
  memcpy(savedWallKnownMap, wallKnownMap, sizeof(wallKnownMap));
  memcpy(savedWallExistMap, wallExistMap, sizeof(wallExistMap));
  memcpy(savedFloorLinkMap, floorLinkMap, sizeof(floorLinkMap));
  memcpy(savedFloorLinkDirMap, floorLinkDirMap, sizeof(floorLinkDirMap));
  memcpy(savedFloorLinkTargetXMap, floorLinkTargetXMap, sizeof(floorLinkTargetXMap));
  memcpy(savedFloorLinkTargetYMap, floorLinkTargetYMap, sizeof(floorLinkTargetYMap));
  memcpy(savedFloorConnectorOnlyMap, floorConnectorOnlyMap, sizeof(floorConnectorOnlyMap));
  memcpy(savedSlopeExitIgnoreUnknownMap, slopeExitIgnoreUnknownMap, sizeof(slopeExitIgnoreUnknownMap));
  memcpy(savedSlopeTransitCellMap, slopeTransitCellMap, sizeof(slopeTransitCellMap));
  memcpy(savedSlopeDownExitNoSideReadMap, slopeDownExitNoSideReadMap, sizeof(slopeDownExitNoSideReadMap));
  savedCurrentFloorForLoc = currentFloor;
  memcpy(savedFloorHeightForLoc, floorHeight, sizeof(floorHeight));
  memcpy(savedFloorAssignedForLoc, floorAssigned, sizeof(floorAssigned));
}

static void restoreSavedMapFromLocalization() {
  memcpy(visitCnt, savedVisitCnt, sizeof(visitCnt));
  memcpy(victimFlag, savedVictimFlag, sizeof(victimFlag));
  memcpy(blueFlag, savedBlueFlag, sizeof(blueFlag));
  memcpy(redFlag, savedRedFlag, sizeof(redFlag));
  memcpy(bumpFlag, savedBumpFlag, sizeof(bumpFlag));
  memcpy(zoneFlag, savedZoneFlag, sizeof(zoneFlag));
  memcpy(XY_Number, savedXY_Number, sizeof(XY_Number));
  memcpy(Red_Number, savedRed_Number, sizeof(Red_Number));
  memcpy(wallKnownMap, savedWallKnownMap, sizeof(wallKnownMap));
  memcpy(wallExistMap, savedWallExistMap, sizeof(wallExistMap));
  memcpy(floorLinkMap, savedFloorLinkMap, sizeof(floorLinkMap));
  memcpy(floorLinkDirMap, savedFloorLinkDirMap, sizeof(floorLinkDirMap));
  memcpy(floorLinkTargetXMap, savedFloorLinkTargetXMap, sizeof(floorLinkTargetXMap));
  memcpy(floorLinkTargetYMap, savedFloorLinkTargetYMap, sizeof(floorLinkTargetYMap));
  memcpy(floorConnectorOnlyMap, savedFloorConnectorOnlyMap, sizeof(floorConnectorOnlyMap));
  memcpy(slopeExitIgnoreUnknownMap, savedSlopeExitIgnoreUnknownMap, sizeof(slopeExitIgnoreUnknownMap));
  memcpy(slopeTransitCellMap, savedSlopeTransitCellMap, sizeof(slopeTransitCellMap));
  memcpy(slopeDownExitNoSideReadMap, savedSlopeDownExitNoSideReadMap, sizeof(slopeDownExitNoSideReadMap));
  currentFloor = savedCurrentFloorForLoc;
  memcpy(floorHeight, savedFloorHeightForLoc, sizeof(floorHeight));
  memcpy(floorAssigned, savedFloorAssignedForLoc, sizeof(floorAssigned));
}

static void resetActiveMapForLocalizationTemp() {
  memset(visitCnt, 0, sizeof(visitCnt));
  memset(victimFlag, 0, sizeof(victimFlag));
  memset(blueFlag, 0, sizeof(blueFlag));
  memset(redFlag, 0, sizeof(redFlag));
  memset(redEntranceInfo, 0, sizeof(redEntranceInfo));
  redEntranceInfoCount = 0;
  memset(bumpFlag, 0, sizeof(bumpFlag));
  memset(zoneFlag, 0, sizeof(zoneFlag));
  memset(wallKnownMap, 0, sizeof(wallKnownMap));
  memset(wallExistMap, 0, sizeof(wallExistMap));
  memset(XY_Number, 0xFF, sizeof(XY_Number));
  memset(Red_Number, 0xFF, sizeof(Red_Number));
  memset(Frontier_Number, 0xFF, sizeof(Frontier_Number));
  memset(floorLinkMap, 0, sizeof(floorLinkMap));
  memset(floorLinkDirMap, FLOOR_LINK_DIR_NONE, sizeof(floorLinkDirMap));
  memset(floorLinkTargetXMap, 0, sizeof(floorLinkTargetXMap));
  memset(floorLinkTargetYMap, 0, sizeof(floorLinkTargetYMap));
  memset(floorConnectorOnlyMap, 0, sizeof(floorConnectorOnlyMap));
  memset(slopeExitIgnoreUnknownMap, 0, sizeof(slopeExitIgnoreUnknownMap));
  memset(slopeTransitCellMap, 0, sizeof(slopeTransitCellMap));
  memset(slopeDownExitNoSideReadMap, 0, sizeof(slopeDownExitNoSideReadMap));
  currentFloor = FLOOR_1ST;
  floorAssigned[0] = true; floorAssigned[1] = false; floorAssigned[2] = false;
  floorHeight[0] = 0; floorHeight[1] = FLOOR_HEIGHT_UNKNOWN; floorHeight[2] = FLOOR_HEIGHT_UNKNOWN;

  visitCnt[FLOOR_1ST][VIS_OY][VIS_OX] = 1;
  XY_Number[FLOOR_1ST][VIS_OY][VIS_OX] = 0;
  zoneSet(0, 0, ZONE_NORMAL);
}

static void warmupAndClassifyLocalizationStartCellWalls() {
  if (!gLocalizationActive) return;
  if (!visInRange(posX, posY)) return;

  uint8_t wallCnt[4] = {0, 0, 0, 0}; // N,E,S,W
  uint8_t openCnt[4] = {0, 0, 0, 0}; // N,E,S,W

  // SD LOAD直後だけの初期照合用。
  // 停止状態なので通常の16〜24cm投票は使えないが、10回多数決にして一瞬値を避ける。
  for (uint8_t i = 0; i < WALL_VOTE_MAX_SAMPLES; i++) {
    serviceSubRx();
    serviceMainTof();
    imuUpdate();
    delay(20);

    const uint16_t relMm[4] = {distMm[2], distMm[1], distMm[5], distMm[0]}; // 前,右,後,左
    for (uint8_t rel = 0; rel < 4; rel++) {
      if (rel == 0 && slopeShouldIgnoreFrontS2ForWallJudge()) continue;

      uint16_t mm = relMm[rel];
      if (!tofValid(mm)) continue;

      uint8_t absDir = (direction + rel) & 3;
      if (mm < 200) wallCnt[absDir]++;
      else          openCnt[absDir]++;
    }
  }

  bool changed = false;
  for (uint8_t absDir = 0; absDir < 4; absDir++) {
    uint8_t total = (uint8_t)(wallCnt[absDir] + openCnt[absDir]);
    if (total < WALL_VOTE_MIN_SAMPLES_LOCALIZE) continue;

    if (wallCnt[absDir] > openCnt[absDir]) {
      wallSetKnownStateBoth(posX, posY, absDir, true);
      changed = true;
    } else if (openCnt[absDir] > wallCnt[absDir]) {
      if (wallStateGet(posX, posY, absDir) != WALL_STATE_BLOCKED) {
        wallSetKnownStateBoth(posX, posY, absDir, false);
        changed = true;
      }
    }
  }

  if (changed) {
    rebuildXY_NumberAll();
    rebuildRed_NumberAll();
  }
}

static void classifyFrontBackAtStop(bool isLocalization) {
  if (isLocalization && !gLocalizationActive) {
    waitMs(STOP_MS);
    return;
  }
  if (!visInRange(posX, posY)) {
    waitMs(STOP_MS);
    return;
  }

  uint8_t wallCnt[4] = {0, 0, 0, 0}; // N,E,S,W
  uint8_t openCnt[4] = {0, 0, 0, 0}; // N,E,S,W
  uint16_t lastFrontMm = 0;
  uint16_t lastBackMm = 0;

  // 30cm完了後の0.1秒停止中に、前(S2)を10回多数決する。
  // 後ろ(S5)はローカライズ中だけ使い、通常探索では壁あり/壁なしとも記録しない。
  // 左右は走行中16〜24cmの壁投票で読む。
  uint32_t t0 = millis();
  for (uint8_t i = 0; i < WALL_VOTE_MAX_SAMPLES; i++) {
    tickall();

    // 前ToF S2：地形通過中/下り坂中は使わない。
    if (!slopeShouldIgnoreFrontS2ForWallJudge()) {
      uint16_t frontMm = distMm[2];
      lastFrontMm = frontMm;
      if (tofValid(frontMm)) {
        uint8_t absDir = direction;
        if (frontMm < SPOT_FRONT_WALL_THRESHOLD_MM) wallCnt[absDir]++;
        else                                      openCnt[absDir]++;
      }
    }

    // 後ろToF S5：ローカライズ中だけ使う。
    // 通常探索では、誤近距離値で壁ありを作らないため、壁あり/壁なしとも記録しない。
    if (isLocalization) {
      uint16_t backMm = distMm[5];
      lastBackMm = backMm;
      if (tofValid(backMm)) {
        uint8_t absDir = oppositeAbsDir(direction);
        if (backMm < SPOT_WALL_THRESHOLD_MM) wallCnt[absDir]++;
        else                                openCnt[absDir]++;
      }
    }

    // 10回をSTOP_MS内に均等配置する。最後に足りない停止時間があれば下で埋める。
    uint32_t targetElapsed = ((uint32_t)(i + 1) * STOP_MS) / WALL_VOTE_MAX_SAMPLES;
    while ((uint32_t)(millis() - t0) < targetElapsed) {
      tickall();
      delay(1);
    }
  }

  while ((uint32_t)(millis() - t0) < STOP_MS) {
    tickall();
    delay(1);
  }

  bool changed = false;
  for (uint8_t absDir = 0; absDir < 4; absDir++) {
    uint8_t total = (uint8_t)(wallCnt[absDir] + openCnt[absDir]);
    if (total < WALL_VOTE_MIN_SAMPLES_LOCALIZE) continue;

    if (wallCnt[absDir] > openCnt[absDir]) {
      // 既に通過済みと見なせるOPEN通路は、停止中ToFの近距離誤値でBLOCKEDへ上書きしない。
      if (wallIsOpenBetweenVisitedCells(posX, posY, absDir)) continue;
      wallSetKnownStateBoth(posX, posY, absDir, true);
      changed = true;
    } else if (openCnt[absDir] > wallCnt[absDir]) {
      if (wallStateGet(posX, posY, absDir) != WALL_STATE_BLOCKED) {
        wallSetKnownStateBoth(posX, posY, absDir, false);
        changed = true;
      }
    }
  }

  if (changed) {
    rebuildXY_NumberAll();
    rebuildRed_NumberAll();
  }

  if (isLocalization) {
    Serial.print("LOCFB pos="); Serial.print(posX); Serial.print(','); Serial.print(posY);
    Serial.print(" dir="); Serial.print(direction);
    Serial.print(" Fmm="); Serial.print(lastFrontMm);
    Serial.print(" Fw="); Serial.print(wallCnt[direction]);
    Serial.print(" Fo="); Serial.print(openCnt[direction]);
    uint8_t backDir = oppositeAbsDir(direction);
    Serial.print(" Bmm="); Serial.print(lastBackMm);
    Serial.print(" Bw="); Serial.print(wallCnt[backDir]);
    Serial.print(" Bo="); Serial.print(openCnt[backDir]);
    Serial.print(" pitch="); Serial.println(pitchDeg, 1);
  }
}

static void classifyLocalizationFrontBackAtStop() {
  classifyFrontBackAtStop(true);
}

static void prepareLocalizationFromSdLoad() {
  if (!gSdLoadSucceededThisBoot) return;

  copyActiveMapToSavedForLocalization();
  gRedNcSnapshotValid = (redNcSnapshotRedFlagCountAllFloors() > 0);
  Serial.print("RED_NC SNAP SDLOAD valid:");
  Serial.print(gRedNcSnapshotValid ? 1 : 0);
  Serial.print(" R:");
  Serial.println((unsigned)redNcSnapshotRedFlagCountAllFloors());
  resetActiveMapForLocalizationTemp();

  posX = 0;
  posY = 0;
  direction = 0; // 方角はN開始
  currentFloor = FLOOR_1ST;

  gLocalizationActive = true;
  gLocalizationMoveCount = 0;
  gLocalizationCandidateResolved = false;
  gLocalizationLastCandidateCount = 0;
  gLocalizationHasCandidateCount = false;

  // 位置特定中は物理的にはスタート/チェックポイント上なので、帰還・完了状態は止めておく。
  returnMode = false;
  missionComplete = false;
  returnNotifiedToSub = false;

  warmupAndClassifyLocalizationStartCellWalls();

  // 2026.5.17：初期位置の壁だけで一意に決まるコースがあるため、
  // 1マスも進む前に候補照合を1回実行する。
  {
    bool isResolved = false;
    int originX = 0;
    int originY = 0;
    uint16_t candCount = 0;
    tryResolveLocalization(isResolved, originX, originY, candCount);
    if (isResolved) {
      finishLocalizationOk(originX, originY);
      return;
    }
    showLocalizationCandidateStatus(candCount);
  }

  drawHudScreen();
  decideNextMoveAtStop_Localize();
}

static bool isLocalizationCandidateMatch(int originX, int originY) {
  for (int tyi = 0; tyi < VIS_H; tyi++) {
    for (int txi = 0; txi < VIS_W; txi++) {
      if (!tempCellHasAnyInfoByIndex(txi, tyi)) continue;

      int tx = txi - VIS_OX;
      int ty = tyi - VIS_OY;
      int sx = originX + tx;
      int sy = originY + ty;
      if (!visInRange(sx, sy)) return false;

      int smx = sx + VIS_OX;
      int smy = sy + VIS_OY;

      // 観測で青/赤が出た場合、保存側も同じ色でなければ不一致。
      if (blueFlag[currentFloor][tyi][txi] && !savedBlueFlag[FLOOR_1ST][smy][smx]) return false;
      if (redFlag[currentFloor][tyi][txi] && !savedRedFlag[FLOOR_1ST][smy][smx]) return false;

      // 壁情報：
      // - 一時観測が「壁あり」なら、保存側unknownも不一致にする。
      //   例：右+後ろ壁が唯一の場所なら、unknown候補を残さずCを一気に減らすため。
      // - 一時観測が「壁なし」なら、保存側unknownは保留（一致扱い）にする。
      //   OPENは未記録になりやすいため、unknownを即不一致にすると消しすぎる。
      uint8_t tempKnown = wallKnownMap[currentFloor][tyi][txi] & 0x0F;
      uint8_t tempExist = wallExistMap[currentFloor][tyi][txi] & 0x0F;
      uint8_t savedKnown = savedWallKnownMap[FLOOR_1ST][smy][smx] & 0x0F;
      uint8_t savedExist = savedWallExistMap[FLOOR_1ST][smy][smx] & 0x0F;

      for (uint8_t absDir = 0; absDir < 4; absDir++) {
        uint8_t bit = wallDirBit(absDir);
        if ((tempKnown & bit) == 0) continue;

        bool tempWall = (tempExist & bit) != 0;
        bool savedIsKnown = (savedKnown & bit) != 0;
        bool savedWall = (savedExist & bit) != 0;

        if (tempWall) {
          // 観測で壁あり：保存側も既知の壁ありでなければ不一致。
          if (!savedIsKnown) return false;
          if (!savedWall) return false;
        } else {
          // 観測で壁なし：保存側が壁ありなら不一致。保存側unknownなら保留。
          if (savedIsKnown && savedWall) return false;
        }
      }
    }
  }

  return true;
}

static void printLocalizationDebugCurrentCell() {
  if (!ENABLE_LOC_DEBUG_PRINT) return;
  if (!gLocalizationActive) return;

  int tmx = posX + VIS_OX;
  int tmy = posY + VIS_OY;
  if (tmx < 0 || tmx >= VIS_W || tmy < 0 || tmy >= VIS_H) return;

  uint8_t tempK = wallKnownMap[currentFloor][tmy][tmx] & 0x0F;
  uint8_t tempE = wallExistMap[currentFloor][tmy][tmx] & 0x0F;

  Serial.print("LOCDBG temp pos=");
  Serial.print(posX); Serial.print(','); Serial.print(posY);
  Serial.print(" dir="); Serial.print(direction);
  Serial.print(" K=0x"); Serial.print(tempK, HEX);
  Serial.print(" E=0x"); Serial.println(tempE, HEX);
}

static void printLocalizationDebugForCandidate(int candOriginX, int candOriginY) {
  if (!ENABLE_LOC_DEBUG_PRINT) return;
  if (!gLocalizationActive) return;

  int tmx = posX + VIS_OX;
  int tmy = posY + VIS_OY;
  if (tmx < 0 || tmx >= VIS_W || tmy < 0 || tmy >= VIS_H) return;

  int sx = candOriginX + posX;
  int sy = candOriginY + posY;
  if (!visInRange(sx, sy)) return;
  int smx = sx + VIS_OX;
  int smy = sy + VIS_OY;

  uint8_t tempK = wallKnownMap[currentFloor][tmy][tmx] & 0x0F;
  uint8_t tempE = wallExistMap[currentFloor][tmy][tmx] & 0x0F;
  uint8_t savedK = savedWallKnownMap[FLOOR_1ST][smy][smx] & 0x0F;
  uint8_t savedE = savedWallExistMap[FLOOR_1ST][smy][smx] & 0x0F;

  Serial.print("LOCDBG temp pos=");
  Serial.print(posX); Serial.print(','); Serial.print(posY);
  Serial.print(" K=0x"); Serial.print(tempK, HEX);
  Serial.print(" E=0x"); Serial.println(tempE, HEX);

  Serial.print("LOCDBG cand origin=");
  Serial.print(candOriginX); Serial.print(','); Serial.print(candOriginY);
  Serial.print(" savedAt=");
  Serial.print(sx); Serial.print(','); Serial.print(sy);
  Serial.print(" K=0x"); Serial.print(savedK, HEX);
  Serial.print(" E=0x"); Serial.println(savedE, HEX);
}

static bool tryResolveLocalization(bool &isResolved, int &resolvedOriginX, int &resolvedOriginY, uint16_t &candidateCount) {
  isResolved = false;
  resolvedOriginX = 0;
  resolvedOriginY = 0;
  candidateCount = 0;

  printLocalizationDebugCurrentCell();

  for (int smy = 0; smy < VIS_H; smy++) {
    for (int smx = 0; smx < VIS_W; smx++) {
      if (!savedCellHasAnyInfoByIndex(smx, smy)) continue;

      int candOriginX = smx - VIS_OX;
      int candOriginY = smy - VIS_OY;
      if (!isLocalizationCandidateMatch(candOriginX, candOriginY)) continue;

      printLocalizationDebugForCandidate(candOriginX, candOriginY);

      if (candidateCount < 65535) candidateCount++;
      resolvedOriginX = candOriginX;
      resolvedOriginY = candOriginY;
    }
  }

  if (candidateCount == 1) {
    isResolved = true;
  }

  gLocalizationLastCandidateCount = candidateCount;
  gLocalizationHasCandidateCount = true;

  Serial.print("LOC candidates=");
  Serial.print(candidateCount);
  Serial.print(" moves=");
  Serial.println(gLocalizationMoveCount);

  return true;
}

static void showLocalizationCandidateStatus(uint16_t candidateCount) {
  if (candidateCount == 1) return;

  char msg[16];
  if (candidateCount == 0) {
    snprintf(msg, sizeof(msg), "LOC NG 0");
    Serial.println("LOC NG 0");
  } else {
    snprintf(msg, sizeof(msg), "LOC C:%u", (unsigned)candidateCount);
    Serial.print("LOC C:");
    Serial.println(candidateCount);
  }

  showSdStatusForMs(msg, SD_STATUS_DISPLAY_MS);
}

static void mergeTempLocalizationMapToActive(int originX, int originY) {
  // ローカライズ中の一時マップ情報は、位置特定の照合だけに使う。
  // LOC OK後も、壁情報・カラー情報・訪問回数・被災者情報は本物マップへ反映しない。
  // 理由：ローカライズ中は座標未確定であり、壁・カラーの一時誤判定で保存マップを汚す可能性があるため。
  (void)originX;
  (void)originY;
}

static void applyReturnModeIfTimeElapsed() {
  if (!returnMode && (uint32_t)(millis() - bootMs) >= RETURN_START_DELAY_MS) {
    enterReturnMode("TIME_7MIN");
  }
}

static void finishLocalizationOk(int originX, int originY) {
  int tempX = posX;
  int tempY = posY;
  uint8_t tempDir = direction;
  bool tempInRedZone = inRedZone;
  bool tempSkipFirstColor = gSkipFirstColorCheckAfterRedTile;
  bool tempIgnoreBlue = gIgnoreBlueEarlyCheckOnNextTile;

  restoreSavedMapFromLocalization();
  mergeTempLocalizationMapToActive(originX, originY);

  posX = originX + tempX;
  posY = originY + tempY;
  direction = tempDir;
  inRedZone = tempInRedZone;
  gSkipFirstColorCheckAfterRedTile = tempSkipFirstColor;
  gIgnoreBlueEarlyCheckOnNextTile = tempIgnoreBlue;

  rebuildXY_NumberAll();
  rebuildRed_NumberAll();

  gLocalizationActive = false;
  gLocalizationCandidateResolved = true;

  applyReturnModeIfTimeElapsed();

  showSdStatusForMs("LOC OK", SD_STATUS_DISPLAY_MS);
  drawHudScreen();

  handleHomeSignalIfNeeded();
  if (!missionComplete) {
    decideNextMoveAtStop_ExtLH();
  }
}

static void finishLocalizationErr() {
  restoreSavedMapFromLocalization();

  posX = 0;
  posY = 0;
  direction = 0;
  inRedZone = false;

  rebuildXY_NumberAll();
  rebuildRed_NumberAll();

  gLocalizationActive = false;
  gLocalizationCandidateResolved = false;

  applyReturnModeIfTimeElapsed();

  showSdStatusForMs("LOC ERR", SD_STATUS_DISPLAY_MS);
  drawHudScreen();

  handleHomeSignalIfNeeded();
  if (!missionComplete) {
    decideNextMoveAtStop_ExtLH();
  }
}

static void decideNextMoveAtStop_Localize() {
  if (!gLocalizationActive) return;

  bool openRel[4];
  for (int i = 0; i < 4; i++) openRel[i] = canMoveByRelFromWallMap((uint8_t)i);

  if (!openRel[0] && !openRel[1] && !openRel[2] && !openRel[3]) {
    turnBack180Yaw2x90();
    return;
  }

  uint16_t cntRel[4] = {65535,65535,65535,65535};
  for (int rel = 0; rel < 4; rel++) {
    if (!openRel[rel]) continue;
    int nx, ny;
    neighborByRel((uint8_t)rel, posX, posY, direction, nx, ny);
    cntRel[rel] = visGet(nx, ny);
  }

  uint16_t minCnt = 65535;
  for (int rel = 0; rel < 4; rel++) {
    if (openRel[rel] && cntRel[rel] < minCnt) minCnt = cntRel[rel];
  }

  int chosen = -1;
  const int prio[4] = {3, 0, 1, 2}; // 左→前→右→後
  for (int k = 0; k < 4; k++) {
    int rel = prio[k];
    if (openRel[rel] && cntRel[rel] == minCnt) { chosen = rel; break; }
  }
  if (chosen < 0) {
    for (int rel = 0; rel < 4; rel++) if (openRel[rel]) { chosen = rel; break; }
  }

  if (chosen == 0) return;
  if (chosen == 1) { turnRight90Yaw(speed); waitMs(STOP_MS); return; }
  if (chosen == 3) { turnLeft90Yaw(speed);  waitMs(STOP_MS); return; }
  turnBack180Yaw2x90();
}

static void serviceLocalizationMode() {
  if (!gLocalizationActive) return;

  uint8_t r = runStraightDistance(speed, TARGET_30CM_PULSES, FWD_TIMEOUT_MS, true);

  if (r == AR_ABORT) {
    delay(1);
    return;
  }

  if (r == AR_BOTH_TOUCH) {
    waitMs(STOP_MS);

    bool isResolved = false;
    int originX = 0;
    int originY = 0;
    uint16_t candCount = 0;
    tryResolveLocalization(isResolved, originX, originY, candCount);

    if (isResolved) {
      finishLocalizationOk(originX, originY);
      return;
    }

    showLocalizationCandidateStatus(candCount);
    decideNextMoveAtStop_Localize();
    return;
  }

  if (r == AR_BLACK_TILE || r == AR_RED_BLOCKED) {
    waitMs(STOP_MS);
    decideNextMoveAtStop_Localize();
    return;
  }

  if (r == AR_NONE) {
    classifyLocalizationFrontBackAtStop();

    if (gLocalizationMoveCount < 255) gLocalizationMoveCount++;

    if (gLocalizationMoveCount >= LOCALIZE_MIN_MOVES) {
      bool isResolved = false;
      int originX = 0;
      int originY = 0;
      uint16_t candCount = 0;
      tryResolveLocalization(isResolved, originX, originY, candCount);

      if (isResolved) {
        finishLocalizationOk(originX, originY);
        return;
      }

      showLocalizationCandidateStatus(candCount);

      if (gLocalizationMoveCount >= LOCALIZE_MAX_MOVES) {
        finishLocalizationErr();
        return;
      }
    }

    decideNextMoveAtStop_Localize();
    return;
  }

  if (r == AR_SIDESTEP_LEFT_TOUCH) {
    sidestepAwayFromLeftObstacle();
    waitMs(STOP_MS);
    decideNextMoveAtStop_Localize();
    return;
  }

  if (r == AR_SIDESTEP_RIGHT_TOUCH) {
    sidestepAwayFromRightObstacle();
    waitMs(STOP_MS);
    decideNextMoveAtStop_Localize();
    return;
  }

  // 片タッチ救済フォールバック
  runRawDistance(false, speed, speed + TRIM_R_REV, TARGET_3CM_PULSES, MOVE_TIMEOUT_MS);
  waitMs(STOP_MS);
  turnLeft90Yaw(speed);
  waitMs(STOP_MS);
  decideNextMoveAtStop_Localize();
}

// =====================
// 定期壁当て（停止中）30秒ごと
// =====================
static void serviceProactiveWallHitAtStop() {
  if (terrainPassMotionLocked()) return;
  if (!gFrontWallApproachEvent) return;
  if (!frontIsWallNow()) return;

  uint32_t curSlot = (uint32_t)((millis() - bootMs) / WALL_HIT_PERIOD_MS);
  if (curSlot < nextWallHitSlot) return;

  stopMotors();
  waitMs(STOP_MS);

  // 壁に押し当て（最大3秒）
  digitalWriteFast(DIR_FL, LOW);
  digitalWriteFast(DIR_FR, HIGH);
  digitalWriteFast(DIR_BL, LOW);
  digitalWriteFast(DIR_BR, HIGH);

  setLR_force(speed, speed + TRIM_R_FWD);

  uint32_t t0 = millis();
  while (true) {
    if (touchPressed(SW_L) && touchPressed(SW_R)) {
      if (!gBothLockout) triggerBothTouchEvent();
      stopMotors();
      tickall(); // 補正＆3cmバック
      break;
    }

    if (millis() - t0 > 3000) {
      stopMotors();
      break;
    }

    tickall();
    delay(1);
  }

  stopMotors();
  waitMs(STOP_MS);

  nextWallHitSlot = curSlot + 1;
  gFrontWallApproachEvent = false;
}

// =====================
// SETUP / LOOP
// =====================
void setup() {
  Serial.begin(BAUD);
  Serial1.begin(BAUD);
  delay(300);

  initSdSave();

  bootMs = millis();
  nextWallHitSlot = 0;

  memset(visitCnt, 0, sizeof(visitCnt));
  memset(victimFlag, 0, sizeof(victimFlag));
  memset(blueFlag, 0, sizeof(blueFlag));
  memset(redFlag, 0, sizeof(redFlag));
  memset(redEntranceInfo, 0, sizeof(redEntranceInfo));
  redEntranceInfoCount = 0;
  memset(bumpFlag, 0, sizeof(bumpFlag));
  memset(zoneFlag, 0, sizeof(zoneFlag));
  memset(wallKnownMap, 0, sizeof(wallKnownMap));
  memset(wallExistMap, 0, sizeof(wallExistMap));
  memset(XY_Number, 0xFF, sizeof(XY_Number));
  memset(Red_Number, 0xFF, sizeof(Red_Number));
  memset(Frontier_Number, 0xFF, sizeof(Frontier_Number));
  memset(floorLinkMap, 0, sizeof(floorLinkMap));
  memset(floorLinkDirMap, FLOOR_LINK_DIR_NONE, sizeof(floorLinkDirMap));
  memset(floorLinkTargetXMap, 0, sizeof(floorLinkTargetXMap));
  memset(floorLinkTargetYMap, 0, sizeof(floorLinkTargetYMap));
  memset(floorConnectorOnlyMap, 0, sizeof(floorConnectorOnlyMap));
  memset(slopeExitIgnoreUnknownMap, 0, sizeof(slopeExitIgnoreUnknownMap));
  memset(slopeTransitCellMap, 0, sizeof(slopeTransitCellMap));
  memset(slopeDownExitNoSideReadMap, 0, sizeof(slopeDownExitNoSideReadMap));
  currentFloor = FLOOR_1ST;
  floorAssigned[0] = true; floorAssigned[1] = false; floorAssigned[2] = false;
  floorHeight[0] = 0; floorHeight[1] = FLOOR_HEIGHT_UNKNOWN; floorHeight[2] = FLOOR_HEIGHT_UNKNOWN;
  visitCnt[FLOOR_1ST][VIS_OY][VIS_OX] = 1;
  XY_Number[FLOOR_1ST][VIS_OY][VIS_OX] = 0;
  zoneSet(0, 0, ZONE_NORMAL);

  Wire.begin();
  Wire.setClock(400000);

  Wire2.begin();
  Wire2.setClock(400000);

  if (!oled.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    while (1) delay(10);
  }
  oled.setTextWrap(false);
  oled.clearDisplay();
  oled.display();
  gOledReady = true;

  if (!tofMain.init()) {
    while (1) delay(10);
  }
  tofMain.setTimeout(150);
  tofMain.setMeasurementTimingBudget(33000);
  tofMain.startContinuous(50);

  Wire1.begin();
  Wire1.setClock(100000);

  pinMode(PIN_RST, OUTPUT);
  digitalWriteFast(PIN_RST, LOW);
  delay(50);
  digitalWriteFast(PIN_RST, HIGH);
  delay(500);

  if (!myIMU.begin(BNO08X_ADDR, Wire1, PIN_INT)) {
    while (1) delay(10);
  }
  // ★地磁気を使わないYawなら、環境に合わせて enableGameRotationVector(20) に変更
  myIMU.enableGameRotationVector(20);

  uint32_t tWait = millis();
  while ((!isYawTared || !isPitchTared) && (millis() - tWait < 2000)) {
    imuUpdate();
    delay(5);
  }

  pinMode(DIR_FL, OUTPUT); pinMode(PWM_FL, OUTPUT);
  pinMode(DIR_FR, OUTPUT); pinMode(PWM_FR, OUTPUT);
  pinMode(DIR_BL, OUTPUT); pinMode(PWM_BL, OUTPUT);
  pinMode(DIR_BR, OUTPUT); pinMode(PWM_BR, OUTPUT);

  pinMode(ENC_FL_A, INPUT_PULLUP); pinMode(ENC_FL_B, INPUT_PULLUP);
  pinMode(ENC_FR_A, INPUT_PULLUP); pinMode(ENC_FR_B, INPUT_PULLUP);
  pinMode(ENC_BL_A, INPUT_PULLUP); pinMode(ENC_BL_B, INPUT_PULLUP);
  pinMode(ENC_BR_A, INPUT_PULLUP); pinMode(ENC_BR_B, INPUT_PULLUP);

  pinMode(SW_L, INPUT_PULLUP);
  pinMode(SW_R, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(ENC_FL_A), isrFL_A, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_FL_B), isrFL_B, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_FR_A), isrFR_A, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_FR_B), isrFR_B, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_BL_A), isrBL_A, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_BL_B), isrBL_B, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_BR_A), isrBR_A, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_BR_B), isrBR_B, CHANGE);

  posX = 0; posY = 0; direction = 0;
  homeArmed = false;
  homePending = false;
  returnMode = false;
  missionComplete = false;
  returnNotifiedToSub = false;
  inRedZone = false;
  redExitMode = false;
  redExitLeavePending = false;
  redNormalConfirmMode = false;
  redNormalConfirmStepCount = 0;
  redNormalConfirmResetCandidates();
  redRecoverySearchMode = false;
  redRecoveryOnRedTile = false;
  redRecoveryNcActive = false;
  redRecoveryVisitReset();
  gRedNcSnapshotValid = false;
  frontierTargetMode = false;
  frontierTargetZone = ZONE_UNKNOWN;
  gFrontierFallbackExtLH = false;

  // 起動直後にSUBから届いている可能性があるSDCLRを先に処理する。
  serviceSubRx();

  // SDCLRを処理していない通常起動時だけ、保存データの有無を表示する。
  // SD DATAがある場合は、この中で保存マップと保存時間を読み込む。
  if (!gSdClearHandledThisBoot) {
    showSdStartupStatus();
  }

  // 通常起動のスタート地点だけ、移動前にその場で壁の有無を判定する。
  // SDロード後の座標不明ローカライズでは、保存マップを優先するためここでは判定しない。
  if (!gSdLoadSucceededThisBoot) {
    warmupAndClassifyStartCellWalls();
  }

  drawHudScreen();

  // 保存データを読み込んだ再スタートでは、まず座標不明ローカライズモードに入る。
  // 方角はN開始、まず2マス走行し、候補が複数なら最大10マスまで追加照合する。
  if (gSdLoadSucceededThisBoot && !missionComplete) {
    prepareLocalizationFromSdLoad();
  }
}

void loop() {
  tickall();

  if (missionComplete) {
    stopMotors();
    delay(1);
    return;
  }

  if (gLocalizationActive) {
    serviceLocalizationMode();
    return;
  }

  // 回転中断/回転スタック失敗の直後：即 拡張左手法へ
  if (gNeedReDecideAtStop) {
    waitMs(STOP_MS);
    handleHomeSignalIfNeeded();
    if (missionComplete) return;
    decideNextMoveAtStop_ExtLH();
    return;
  }

  if (t180Active) {
    stopMotors();
    delay(1);
    return;
  }

  if (t180Pending && !t180DidAction) {
    t180DidAction = true;
    t180Active = true;
    doT180ActionOnce();
    t180Active = false;
    t180Pending = false;
    t180DidAction = false;
    Serial1.print(t180IsBackCommand ? "T180BK,DONE\n" : "T180,DONE\n");
    return;
  }

  holdBlock();

  uint8_t r = runStraightDistance(speed, TARGET_30CM_PULSES, FWD_TIMEOUT_MS, true);

  if (r == AR_ABORT) {
    delay(1);
    return;
  }

  if (r == AR_BOTH_TOUCH) {
    waitMs(STOP_MS);
    handleHomeSignalIfNeeded();
    if (missionComplete) return;
    decideNextMoveAtStop_ExtLH();
    return;
  }

  if (r == AR_BLACK_TILE || r == AR_RED_BLOCKED) {
    waitMs(STOP_MS);
    handleHomeSignalIfNeeded();
    if (missionComplete) return;
    decideNextMoveAtStop_ExtLH();
    return;
  }

  if (r == AR_NONE) {
    // 2026.5.20：地形通過中は停止時の前後壁判定も止める。
    // 坂・階段中のToF誤読で壁情報を壊さないため。
    if (terrainPassMotionLocked()) {
      waitMs(STOP_MS);
    } else if (redNormalConfirmMode) {
      // 赤脱出後のノーマル確認中は、座標・方角未確定の可能性があるため、
      // 停止時の前後壁多数決を本物マップへ書き込まない。
      waitMs(STOP_MS);
    } else if (blueGet(posX, posY) || redGet(posX, posY)) {
      // 青/赤タイル上では、色タイル停止を優先し、今回の前後壁停止判定は入れない。
      waitMs(STOP_MS);
    } else {
      // 通常探索では、30cm通常到達後に停止中で前後だけ10回多数決する。
      classifyFrontBackAtStop(false);
    }

    applyReturnModeIfTimeElapsed();

    if (!returnMode) {
      // ★定期壁アタック復活版
      // ただし serviceProactiveWallHitAtStop() 内で、青/赤タイル関連状態なら実行しない。
      if (ENABLE_PROACTIVE_WALL_HIT_AT_STOP) {
        serviceProactiveWallHitAtStop();
        if (gNeedReDecideAtStop) return;
      }
    }

    handleHomeSignalIfNeeded();
    if (missionComplete) return;
    decideNextMoveAtStop_ExtLH();
    return;
  }

  if (r == AR_SIDESTEP_LEFT_TOUCH) {
    sidestepAwayFromLeftObstacle();
    waitMs(STOP_MS);
    handleHomeSignalIfNeeded();
    if (missionComplete) return;
    return;
  }

  if (r == AR_SIDESTEP_RIGHT_TOUCH) {
    sidestepAwayFromRightObstacle();
    waitMs(STOP_MS);
    handleHomeSignalIfNeeded();
    if (missionComplete) return;
    return;
  }

  // 片タッチ救済フォールバック
  runRawDistance(false, speed, speed + TRIM_R_REV, TARGET_3CM_PULSES, MOVE_TIMEOUT_MS);
  waitMs(STOP_MS);
  turnLeft90Yaw(speed);
  waitMs(STOP_MS);

  handleHomeSignalIfNeeded();
  if (missionComplete) return;
}
