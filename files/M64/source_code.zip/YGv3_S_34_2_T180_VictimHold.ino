// SUB: TOF5EA 読み取り -> Serial1送信 + SUB OLED表示
// OLED=Wire2 / TOF=Wire / カラーセンサー=Wire1
// ★色分類検知154ms・1回判定版（MAIN主導・停止中だけ判定）
//   - 常時カラー監視はしない
//   - MAINから CL? が来た時だけ、154msで1回読み、白/黒/青/赤/その他を分類する
//   - 応答は CL,W / CL,K / CL,B / CL,R / CL,N / CL,ERR
//   - BK? は旧黒チェック用として残す（154ms・1回判定）
//   - C,STOP / C,GO / C,K / C,B / C,R は送信しない
// 2026.5.5 (rescue kit 8 / victim OLED H-S-U + T180/T180BK ACK flow)

#include <Arduino.h>
#include <Wire.h>
#include <VL53L0X.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Servo.h>
#include <string.h>
#include <Adafruit_TCS34725.h>

const uint32_t BAUD = 115200;

// 関数宣言
void tickall();
static void pollUartCommands();
static void pollButtons();
static void drawTofScreenSub(bool isWaitingVack);
static void sendFrameTof5(const uint16_t v[5]);
static void serviceHomeBlink();
static void serviceVictimDisplayTimeout();
static void victimBlinkService();
static void victimActionService();
static void performBlackCheckAndReply();
static void performColorClassAndReply();
static void sendSdClearAtBootIfPressed();

// ===== OLED (Wire2: SDA=25, SCL=24) =====
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
const uint8_t OLED_ADDR = 0x3C;
Adafruit_SSD1306 oled(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire2, OLED_RESET);

// ===== TOF =====
const int XSHUT_PINS[5] = {37, 33, 35, 36, 34};
const uint8_t ADDR[5]   = {0x30, 0x31, 0x32, 0x33, 0x34};
VL53L0X tof[5];
uint16_t distMm[5] = {8190,8190,8190,8190,8190};

const uint32_t TOF_READ_INTERVAL_MS = 50;
uint32_t lastTofReadMs = 0;

const uint32_t TX_INTERVAL_MS   = 50;
const uint32_t DISP_INTERVAL_MS = 200;
uint32_t lastTxMs = 0;
uint32_t lastDispMs = 0;

// ===== カラーセンサー (TCS34725 / Wire1) =====
Adafruit_TCS34725 tcs = Adafruit_TCS34725(TCS34725_INTEGRATIONTIME_154MS, TCS34725_GAIN_1X);
bool isTcsPresent = false;

// 154ms色分類用の基準値（実測値）
// 順番は 白 → 黒 → 青 → 赤。
float C_white_154 = 362.0f;
float rW_154 = 0.25f, gW_154 = 0.41f, bW_154 = 0.33f;

float C_black_154 = 38.0f;
float rK_154 = 0.26f, gK_154 = 0.42f, bK_154 = 0.32f;

float C_blue_154 = 57.0f;
float rB_154 = 0.21f, gB_154 = 0.42f, bB_154 = 0.42f;

float C_red_154 = 60.0f;
float rR_154 = 0.48f, gR_154 = 0.33f, bR_154 = 0.25f;

float C_white = C_white_154;

enum ColorID { COL_WHITE, COL_BLACK, COL_BLUE, COL_RED, COL_UNKNOWN };
struct Feature { float rn=0, gn=0, bn=0, cRatio=0; bool valid=false; };
Feature refW, refK, refB, refR;
const float W_C = 1.0f, W_R = 2.0f, W_G = 2.0f, W_B = 2.0f;
float D_norm = 1.0f;
const float NORM_ALPHA = 1.10f;

static Feature makeFeature(float C, float r, float g, float b, float Cw) {
  Feature f;
  if (Cw > 0) { f.rn = r; f.gn = g; f.bn = b; f.cRatio = C / Cw; f.valid = true; }
  return f;
}
static float colorDist(const Feature &a, const Feature &b) {
  float dr = a.rn - b.rn;
  float dg = a.gn - b.gn;
  float db = a.bn - b.bn;
  float dc = a.cRatio - b.cRatio;
  return sqrtf(W_R*dr*dr + W_G*dg*dg + W_B*db*db + W_C*dc*dc);
}
static void computeRefNorm() {
  Feature refs[4] = {refW, refK, refB, refR};
  int n = 0;
  double sum = 0;
  for (int i = 0; i < 4; i++) {
    for (int j = i + 1; j < 4; j++) {
      if (refs[i].valid && refs[j].valid) { sum += colorDist(refs[i], refs[j]); n++; }
    }
  }
  D_norm = (n > 0) ? max(1e-6f, (float)(sum / n)) : 1.0f;
}
static void applyColorClassRefs154() {
  refW = makeFeature(C_white_154, rW_154, gW_154, bW_154, C_white_154);
  refK = makeFeature(C_black_154, rK_154, gK_154, bK_154, C_white_154);
  refB = makeFeature(C_blue_154,  rB_154, gB_154, bB_154, C_white_154);
  refR = makeFeature(C_red_154,   rR_154, gR_154, bR_154, C_white_154);
  C_white = C_white_154;
  computeRefNorm();
}
static float distanceToPercent(float d) {
  float denom = D_norm * NORM_ALPHA;
  if (denom <= 1e-6f) denom = 1.0f;
  float p = 100.0f * (1.0f - (d / denom));
  if (p < 0) p = 0;
  if (p > 100) p = 100;
  return p;
}
static ColorID classifyWithScores(uint16_t r, uint16_t g, uint16_t b, uint16_t c, float &pW, float &pK, float &pB, float &pR) {
  pW = pK = pB = pR = 0;
  if (c == 0 || C_white == 0) return COL_UNKNOWN;
  Feature x = {(float)r / c, (float)g / c, (float)b / c, (float)c / C_white, true};

  float dW = colorDist(x, refW);
  float dK = colorDist(x, refK);
  float dB = colorDist(x, refB);
  float dR = colorDist(x, refR);

  pW = distanceToPercent(dW);
  pK = distanceToPercent(dK);
  pB = distanceToPercent(dB);
  pR = distanceToPercent(dR);

  float best = dW;
  ColorID id = COL_WHITE;
  if (dK < best) { best = dK; id = COL_BLACK; }
  if (dB < best) { best = dB; id = COL_BLUE; }
  if (dR < best) { best = dR; id = COL_RED; }
  return id;
}

static bool isBlackSample(uint16_t r, uint16_t g, uint16_t b, uint16_t c) {
  float pW, pK, pB, pR;
  ColorID col = classifyWithScores(r, g, b, c, pW, pK, pB, pR);

  // BK?用の旧互換判定。MAIN本線はCL?を使う。
  bool isDarkEnough = ((float)c <= (C_white_154 * 0.20f));
  return isDarkEnough && (col == COL_BLACK);
}

static void performBlackCheckAndReply() {
  if (!isTcsPresent) {
    Serial1.print("BK,ERR\n");
    return;
  }

  // BK?は旧互換用。154msで1回だけ読み、黒なら1を返す。
  tcs.setIntegrationTime(TCS34725_INTEGRATIONTIME_154MS);
  applyColorClassRefs154();

  uint16_t r, g, b, c;
  tcs.getRawData(&r, &g, &b, &c);

  if (isBlackSample(r, g, b, c)) Serial1.print("BK,1\n");
  else                          Serial1.print("BK,0\n");
}

static char classifyColorSampleCode(uint16_t r, uint16_t g, uint16_t b, uint16_t c) {
  float pW, pK, pB, pR;
  ColorID col = classifyWithScores(r, g, b, c, pW, pK, pB, pR);

  if (col == COL_UNKNOWN) return 'N';

  // 154ms・1回判定。
  // 見逃しを減らすため、多数決や4/5一致は使わず、実測基準値に最も近い色を返す。
  switch (col) {
    case COL_WHITE: return 'W';
    case COL_BLACK: return 'K';
    case COL_BLUE:  return 'B';
    case COL_RED:   return 'R';
    default:        return 'N';
  }
}

static void performColorClassAndReply() {
  if (!isTcsPresent) {
    Serial1.print("CL,ERR\n");
    return;
  }

  // 154msで1回だけ読み、白/黒/青/赤/その他を分類する。
  // 7cm/13cmの2地点チェックはMAIN側でそのまま行う。
  tcs.setIntegrationTime(TCS34725_INTEGRATIONTIME_154MS);
  applyColorClassRefs154();

  uint16_t r, g, b, c;
  tcs.getRawData(&r, &g, &b, &c);
  char code = classifyColorSampleCode(r, g, b, c);

  if      (code == 'W') Serial1.print("CL,W\n");
  else if (code == 'K') Serial1.print("CL,K\n");
  else if (code == 'B') Serial1.print("CL,B\n");
  else if (code == 'R') Serial1.print("CL,R\n");
  else                  Serial1.print("CL,N\n");
}

// ===== Buttons =====
const int PIN_RST_SUB_BTN  = 10;
const int PIN_RST_MAIN_BTN = 9;
const int PIN_SD_CLEAR_BTN = 11; // 起動時に押していたらMAINのSD保存データを消去

const uint32_t SD_CLEAR_SEND_MS = 2000;
const uint32_t SD_CLEAR_SEND_INTERVAL_MS = 100;

const uint32_t DEBOUNCE_MS = 30;
bool isSubBtnStable  = HIGH, isSubBtnLast  = HIGH; uint32_t subBtnChangedAt  = 0;
bool isMainBtnStable = HIGH, isMainBtnLast = HIGH; uint32_t mainBtnChangedAt = 0;

volatile bool isMainRstPending = false;

static void rebootMCU() { SCB_AIRCR = 0x05FA0004; while (1) {} }

static void sendSdClearAtBootIfPressed() {
  // 起動直後のピン状態が安定するまで少し待つ
  delay(300);

  // 押していなければ何もしない
  if (digitalRead(PIN_SD_CLEAR_BTN) != LOW) {
    return;
  }

  // 誤判定防止：0.8秒間ずっとLOWなら「押しながら電源ON」と判定
  uint32_t holdStartMs = millis();
  while ((millis() - holdStartMs) < 800) {
    if (digitalRead(PIN_SD_CLEAR_BTN) != LOW) {
      return;
    }
    delay(10);
  }

  // MAIN側の起動タイミングずれ対策として、2秒間SDCLRを繰り返し送る
  uint32_t sendStartMs = millis();
  while ((millis() - sendStartMs) < SD_CLEAR_SEND_MS) {
    Serial1.print("SDCLR\n");
    delay(SD_CLEAR_SEND_INTERVAL_MS);
  }
}

// ===== HOME LED =====
const int LED_R = 13;
const int LED_Y = 40;
const int LED_G = 41;

static inline void ledsAll(bool on) {
  digitalWriteFast(LED_R, on ? HIGH : LOW);
  digitalWriteFast(LED_Y, on ? HIGH : LOW);
  digitalWriteFast(LED_G, on ? HIGH : LOW);
}

bool isHomeBlinkActive = false;
bool isHomeLedOn = false;
uint8_t homeCyclesDone = 0;
uint32_t homeNextToggleMs = 0;

static void startHomeBlink() {
  isHomeBlinkActive = true;
  homeCyclesDone = 0;
  isHomeLedOn = true;
  ledsAll(true);
  homeNextToggleMs = millis() + 500;
}
static void serviceHomeBlink() {
  if (!isHomeBlinkActive) return;
  uint32_t now = millis();
  if ((int32_t)(now - homeNextToggleMs) < 0) return;

  if (isHomeLedOn) {
    isHomeLedOn = false;
    ledsAll(false);
    homeNextToggleMs = now + 500;

    homeCyclesDone++;
    if (homeCyclesDone >= 10) {
      isHomeBlinkActive = false;
      ledsAll(false);
    }
  } else {
    isHomeLedOn = true;
    ledsAll(true);
    homeNextToggleMs = now + 500;
  }
}

// ===== 残弾 =====
static int ammoL = 4;
static int ammoR = 4;
static inline int &ammoRefBySide(char side) { return (side == 'L') ? ammoL : ammoR; }
static inline char otherSide(char side) { return (side == 'L') ? 'R' : 'L'; }

// ===== UART（MAIN→SUB コマンド）=====
static char cmdBuf[48];
static uint8_t cmdLen = 0;

static bool isVackOkReceived = false;
static bool isVackSkipReceived = false;
static bool isT180DoneReceived = false;
static bool isT180BkDoneReceived = false;
static bool isReturnDisplayActive = false;

static void handleCommandLine(const char* s) {
  if (strcmp(s, "CL?") == 0)    { performColorClassAndReply(); return; }
  if (strcmp(s, "BK?") == 0)    { performBlackCheckAndReply(); return; }
  if (strcmp(s, "HOME") == 0)   { startHomeBlink(); return; }
  if (strcmp(s, "RETURN") == 0) { isReturnDisplayActive = true; return; }
  if (strcmp(s, "VACK,OK") == 0) { isVackOkReceived = true; return; }
  if (strcmp(s, "VACK,SKIP") == 0) { isVackSkipReceived = true; return; }
  if (strcmp(s, "T180,DONE") == 0) { isT180DoneReceived = true; return; }
  if (strcmp(s, "T180BK,DONE") == 0) { isT180BkDoneReceived = true; return; }
}
static void pollUartCommands() {
  while (Serial1.available() > 0) {
    char c = (char)Serial1.read();
    if (c == '\r') continue;
    if (c == '\n') {
      cmdBuf[cmdLen] = '\0';
      if (cmdLen > 0) handleCommandLine(cmdBuf);
      cmdLen = 0;
    } else {
      if (cmdLen < sizeof(cmdBuf) - 1) cmdBuf[cmdLen++] = c;
      else cmdLen = 0;
    }
  }
}

static bool initToF5Units() {
  for (int i = 0; i < 5; i++) tof[i] = VL53L0X();

  for (int i = 0; i < 5; i++) {
    pinMode(XSHUT_PINS[i], OUTPUT);
    digitalWrite(XSHUT_PINS[i], LOW);
  }
  delay(10);

  for (int i = 0; i < 5; i++) {
    digitalWrite(XSHUT_PINS[i], HIGH);
    delay(10);

    tof[i].setTimeout(200);
    if (!tof[i].init()) return false;

    tof[i].setAddress(ADDR[i]);
    delay(5);
  }

  for (int i = 0; i < 5; i++) {
    tof[i].setTimeout(100);
    tof[i].setMeasurementTimingBudget(33000);
    tof[i].startContinuous(50);
  }
  return true;
}

// ===== OLED =====
static void printMm4(int16_t x, int16_t y, uint16_t mm) {
  oled.setCursor(x, y);
  if (mm == 0 || mm >= 8000) oled.print("----");
  else {
    char buf[8];
    snprintf(buf, sizeof(buf), "%4u", (unsigned)mm);
    oled.print(buf);
  }
}
static const int BAR_MAX_MM = 200;
static void drawBar(int x, int y, int W, int H, uint16_t mm) {
  oled.drawRect(x, y, W, H, SSD1306_WHITE);
  if (mm == 0 || mm >= 8000) return;
  int len = map((int)constrain(mm, 0, BAR_MAX_MM), 0, BAR_MAX_MM, 0, W);
  if (len > 0) oled.fillRect(x, y, len, H, SSD1306_WHITE);
}

// ===== 被災者表示（10秒）=====
static const uint32_t VICTIM_DISPLAY_MS = 10000;
static char dispVictimL = '-';
static char dispVictimR = '-';
static uint32_t dispVictimLUntilMs = 0;
static uint32_t dispVictimRUntilMs = 0;
static inline bool dispVictimActiveL() { return dispVictimLUntilMs && ((int32_t)(millis() - dispVictimLUntilMs) < 0); }
static inline bool dispVictimActiveR() { return dispVictimRUntilMs && ((int32_t)(millis() - dispVictimRUntilMs) < 0); }
static inline void serviceVictimDisplayTimeout() {
  uint32_t now = millis();
  if (dispVictimLUntilMs && (int32_t)(now - dispVictimLUntilMs) >= 0) { dispVictimLUntilMs = 0; dispVictimL = '-'; }
  if (dispVictimRUntilMs && (int32_t)(now - dispVictimRUntilMs) >= 0) { dispVictimRUntilMs = 0; dispVictimR = '-'; }
}

static bool isWaitingVack = false;

static void drawTofScreenSub(bool isWaitingVack_) {
  oled.clearDisplay();
  oled.setTextWrap(false);
  oled.setTextColor(SSD1306_WHITE);

  if (isReturnDisplayActive) {
    oled.setTextSize(3);
    oled.setCursor(10, 20);
    oled.print("RETURN");
    oled.display();
    return;
  }

  oled.setTextSize(2);
  oled.setCursor(0, 0);

  oled.print("R:");
  if (dispVictimActiveR()) oled.print(dispVictimR);
  else oled.print(ammoR);

  oled.print(" ");
  oled.print("L:");
  if (dispVictimActiveL()) oled.print(dispVictimL);
  else oled.print(ammoL);

  oled.setTextSize(1);

  oled.setCursor(118, 0);
  oled.print(isMainRstPending ? 'R' : ' ');
  oled.print(isHomeBlinkActive ? 'H' : ' ');
  oled.print(isWaitingVack_    ? 'V' : ' ');

  const int yNum1 = 16;
  const int yNum2 = 26;

  oled.setCursor(0,  yNum1); oled.print("S1:"); printMm4(18, yNum1, distMm[1]);
  oled.setCursor(64, yNum1); oled.print("S0:"); printMm4(82, yNum1, distMm[0]);

  oled.setCursor(0,  yNum2); oled.print("S4:"); printMm4(18, yNum2, distMm[4]);
  oled.setCursor(64, yNum2); oled.print("S3:"); printMm4(82, yNum2, distMm[3]);

  const int H = 8, W = 60;
  const int by1 = 36, by2 = 46, by3 = 56;

  drawBar(0,  by1, W, H, distMm[1]);  drawBar(66, by1, W, H, distMm[0]);
  drawBar(0,  by2, W, H, distMm[4]);  drawBar(66, by2, W, H, distMm[3]);
  drawBar(0,  by3, W, H, distMm[2]);

  oled.setCursor(66, by3 + 1);
  oled.print("S2:");
  if (distMm[2] == 0 || distMm[2] >= 8000) oled.print("----");
  else { char b[8]; snprintf(b, sizeof(b), "%4u", (unsigned)distMm[2]); oled.print(b); }

  oled.display();
}

// ===== TOF送信 =====
static void sendFrameTof5(const uint16_t v[5]) {
  char buf[64];
  int n = snprintf(buf, sizeof(buf), "<%u,%u,%u,%u,%u>\n",
                   (unsigned)v[0], (unsigned)v[1], (unsigned)v[2],
                   (unsigned)v[3], (unsigned)v[4]);
  if (n > 0) Serial1.write((const uint8_t*)buf, (size_t)n);
}

// ===== ボタン =====
static void pollButtons() {
  bool r1 = digitalRead(PIN_RST_SUB_BTN);
  if (r1 != isSubBtnLast) { isSubBtnLast = r1; subBtnChangedAt = millis(); }
  if ((millis() - subBtnChangedAt) >= DEBOUNCE_MS) {
    if (isSubBtnStable != isSubBtnLast) { isSubBtnStable = isSubBtnLast; if (isSubBtnStable == LOW) { delay(20); rebootMCU(); } }
  }

  bool r2 = digitalRead(PIN_RST_MAIN_BTN);
  if (r2 != isMainBtnLast) { isMainBtnLast = r2; mainBtnChangedAt = millis(); }
  if ((millis() - mainBtnChangedAt) >= DEBOUNCE_MS) {
    if (isMainBtnStable != isMainBtnLast) { isMainBtnStable = isMainBtnLast; if (isMainBtnStable == LOW) isMainRstPending = true; }
  }

}

// =========================================================
// 被災者（カメラ2台）→ MAINへV → VACK → LED→投下
// タイマー制限：timeStart+2s 残り投下 / +3s TOF再開 / +4s 終了
// =========================================================
static const uint32_t CAM_BAUD = 19200;
static const uint32_t EVENT_COOLDOWN_MS = 250;

// サーボ
static const int SERVO_L_PIN = 22;
static const int SERVO_R_PIN = 23;
static const int L_CLOSED = 70;
static const int L_OPEN   = 160;
static const int R_CLOSED = 120;
static const int R_OPEN   = 30;

static const uint32_t SERVO_STEP_MS = 2;
static const uint32_t SERVO_HOLD_MS = 100;

static const uint32_t LED_PERIOD_MS = 500;
static const int LED_BLINK_COUNT = 5;
static const uint32_t BLINK_TO_DROP_GAP_MS = 60;
static const uint32_t MAIN_VICTIM_STOP_MS = 5000;
static const uint32_t TURN_CMD_RETRY_MS = 300;
static const uint8_t TURN_CMD_SEND_COUNT = 3;

// ---- ID→表示文字 / Vtype(H/S/U) ----
static inline char idToDispChar(uint8_t id) {
  switch (id) {
    case 1: return 'S';
    case 2: return 'H';
    case 3: return 'U';
    case 4: return 'S';
    case 5: return 'H';
    case 6: return 'U';
    default: return '-';
  }
}
// H/S/Uへ統合：1=H(2回),2=S(1回),3=U(0回)
static inline uint8_t idToVtype(uint8_t id) {
  if (id == 2 || id == 5) return 1;
  if (id == 1 || id == 4) return 2;
  if (id == 3 || id == 6) return 3;
  return 0;
}
static inline char vtypeChar(uint8_t vtype) {
  if (vtype == 1) return 'H';
  if (vtype == 2) return 'S';
  if (vtype == 3) return 'U';
  return '?';
}
static inline int vtypeLedPin(uint8_t vtype) {
  if (vtype == 1) return LED_R;
  if (vtype == 2) return LED_Y;
  return LED_G;
}
static inline int vtypeDrops(uint8_t vtype) {
  if (vtype == 1) return 2;
  if (vtype == 2) return 1;
  return 0;
}

#define CAMERA_PAUSE_DURING_ACTION 1
static void camerasPause(bool pause) {
#if CAMERA_PAUSE_DURING_ACTION
  uint8_t c = pause ? 'p' : 'g';
  Serial2.write(c);
  Serial7.write(c);
#else
  (void)pause;
#endif
}

static void sendVictimRequestToMain(char side, uint8_t vtype) {
  Serial1.print("V,");
  Serial1.print(side);
  Serial1.print(",");
  Serial1.print(vtypeChar(vtype));
  Serial1.print("\n");
}

// ---- LED点滅（被災者）----
static bool victimBlinkActive = false;
static int  victimBlinkPin = LED_R;
static int  victimTogglesRemaining = 0;
static bool victimBlinkLevel = false;
static uint32_t victimNextToggleMs = 0;
static uint32_t victimBlinkEndedMs = 0;

static void victimBlinkStart(int pin, int blinkCount) {
  victimBlinkActive = true;
  victimBlinkPin = pin;
  victimTogglesRemaining = blinkCount * 2;
  victimBlinkLevel = true;
  digitalWriteFast(victimBlinkPin, HIGH);
  victimNextToggleMs = millis() + (LED_PERIOD_MS / 2);
  victimBlinkEndedMs = 0;
}
static void victimBlinkService() {
  if (isHomeBlinkActive) return;
  if (!victimBlinkActive) return;

  uint32_t now = millis();
  if ((int32_t)(now - victimNextToggleMs) < 0) return;

  victimBlinkLevel = !victimBlinkLevel;
  digitalWriteFast(victimBlinkPin, victimBlinkLevel ? HIGH : LOW);
  victimTogglesRemaining--;
  victimNextToggleMs = now + (LED_PERIOD_MS / 2);

  if (victimTogglesRemaining <= 0) {
    digitalWriteFast(victimBlinkPin, LOW);
    victimBlinkActive = false;
    victimBlinkEndedMs = now;
  }
}

// ---- Dropper（滑らか版）----
enum DropPhase : uint8_t { DP_IDLE=0, DP_MOVE_OPEN, DP_HOLD_OPEN, DP_MOVE_CLOSE };
struct Dropper {
  Servo sv;
  int closedAngle = 0;
  int openAngle = 0;
  int angle = 0;
  DropPhase phase = DP_IDLE;
  uint32_t lastStepMs = 0;
  uint32_t holdStartMs = 0;
  bool donePulse = false;
};
static const uint8_t IDX_L = 0;
static const uint8_t IDX_R = 1;
static Dropper gDrop[2];

static void dropperInitIdx(uint8_t idx, int pin, int closedA, int openA) {
  Dropper &d = gDrop[idx];
  d.closedAngle = closedA;
  d.openAngle = openA;
  d.angle = closedA;
  d.phase = DP_IDLE;
  d.donePulse = false;
  d.sv.attach(pin);
  d.sv.write(d.angle);
  delay(20);
}
static inline bool dropperBusyIdx(uint8_t idx) { return gDrop[idx].phase != DP_IDLE; }
static void dropperStartIdx(uint8_t idx) {
  Dropper &d = gDrop[idx];
  if (d.phase != DP_IDLE) return;
  d.donePulse = false;
  d.phase = DP_MOVE_OPEN;
  d.lastStepMs = millis();
}
static void dropperServiceIdx(uint8_t idx) {
  Dropper &d = gDrop[idx];
  d.donePulse = false;
  if (d.phase == DP_IDLE) return;

  const uint32_t now = millis();
  const int STEP_DEG = 1;
  const int MAX_STEPS_PER_CALL = 12;

  auto stepTowardTarget = [&](int target) -> bool {
    if (d.angle == target) return true;
    d.angle += (target > d.angle) ? STEP_DEG : -STEP_DEG;
    if (target > d.angle && d.angle > target) d.angle = target;
    if (target < d.angle && d.angle < target) d.angle = target;
    d.sv.write(d.angle);
    return (d.angle == target);
  };

  if (d.phase == DP_MOVE_OPEN) {
    int target = d.openAngle;
    int steps = 0;
    while ((int32_t)(now - d.lastStepMs) >= (int32_t)SERVO_STEP_MS && steps < MAX_STEPS_PER_CALL) {
      d.lastStepMs += SERVO_STEP_MS;
      steps++;
      if (stepTowardTarget(target)) { d.phase = DP_HOLD_OPEN; d.holdStartMs = now; break; }
    }
    return;
  }

  if (d.phase == DP_HOLD_OPEN) {
    if ((int32_t)(now - d.holdStartMs) >= (int32_t)SERVO_HOLD_MS) { d.phase = DP_MOVE_CLOSE; d.lastStepMs = now; }
    return;
  }

  if (d.phase == DP_MOVE_CLOSE) {
    int target = d.closedAngle;
    int steps = 0;
    while ((int32_t)(now - d.lastStepMs) >= (int32_t)SERVO_STEP_MS && steps < MAX_STEPS_PER_CALL) {
      d.lastStepMs += SERVO_STEP_MS;
      steps++;
      if (stepTowardTarget(target)) { d.phase = DP_IDLE; d.donePulse = true; break; }
    }
    return;
  }
}

// ---- Victim action stage ----
enum VictimStage : uint8_t { VS_IDLE=0, VS_WAIT_ACK, VS_BLINK, VS_GAP, VS_DROP, VS_TURN, VS_TURN_BACK };
static VictimStage vStage = VS_IDLE;

static char reqSide = 'L';
static uint8_t reqVtype = 0;
static char reqDispChar = '-';

static bool isActionActive = false;

// 2フェーズ投下管理
static char sidePhase1 = 'L';
static char sidePhase2 = 'R';
static bool isPlanTurn = false;
static int remainingNeed = 0;

static char actionSide = 'L';
static int actionDropsRemaining = 0;
static bool isActionDropCycle = false;
static uint32_t actionNextDropMs = 0;

// ★被災者停止・T180 ACK制御
static uint32_t mainStopDoneMs = 0;
static bool isPhase2Active = false;
static bool isTurnCommandStarted = false;
static uint32_t lastTurnCommandMs = 0;
static uint8_t turnCommandSendCount = 0;

// pending（1件）
static bool isPendingValid = false;
static char pendingSide = 'L';
static uint8_t pendingVtype = 0;
static char pendingDispChar = '-';

static void startVictimPlan(char side, uint8_t vtype) {
  isActionActive = true;

  sidePhase1 = side;
  sidePhase2 = otherSide(side);

  remainingNeed = vtypeDrops(vtype); // H=2, S=1, U=0

  // フェーズ1：出せる分だけ
  actionSide = sidePhase1;
  int &a1 = ammoRefBySide(actionSide);
  if (a1 < 0) a1 = 0;
  int d1 = min(remainingNeed, a1);
  remainingNeed -= d1;
  actionDropsRemaining = d1;

  // 残りがある & 反対側に残弾がある → タイマー制御へ
  int &a2 = ammoRefBySide(sidePhase2);
  if (a2 < 0) a2 = 0;
  isPlanTurn = (remainingNeed > 0 && a2 > 0);

  isActionDropCycle = false;
  actionNextDropMs = 0;

  mainStopDoneMs = millis() + MAIN_VICTIM_STOP_MS;
  isPhase2Active = false;
  isTurnCommandStarted = false;
  lastTurnCommandMs = 0;
  turnCommandSendCount = 0;
  isT180DoneReceived = false;
  isT180BkDoneReceived = false;

  victimBlinkStart(vtypeLedPin(vtype), LED_BLINK_COUNT);
  vStage = VS_BLINK;
}

static void finishActionAndMaybePending() {
  Serial1.print("VEND\n");

  isActionActive = false;
  vStage = VS_IDLE;
  camerasPause(false);

  mainStopDoneMs = 0;
  isPhase2Active = false;
  isTurnCommandStarted = false;
  lastTurnCommandMs = 0;
  turnCommandSendCount = 0;
  isT180DoneReceived = false;
  isT180BkDoneReceived = false;

  if (isPendingValid) {
    reqSide = pendingSide; reqVtype = pendingVtype; reqDispChar = pendingDispChar;
    isPendingValid = false;
    isWaitingVack = true;
    vStage = VS_WAIT_ACK;
    camerasPause(true);
    sendVictimRequestToMain(reqSide, reqVtype);
  }
}

static void resetTurnCommandWait() {
  isTurnCommandStarted = false;
  lastTurnCommandMs = 0;
  turnCommandSendCount = 0;
}

static void serviceSendTurnCommand(const char* cmd) {
  uint32_t now = millis();
  if (!isTurnCommandStarted) {
    isTurnCommandStarted = true;
    lastTurnCommandMs = 0;
    turnCommandSendCount = 0;
  }
  if (turnCommandSendCount < TURN_CMD_SEND_COUNT &&
      (lastTurnCommandMs == 0 || (int32_t)(now - (lastTurnCommandMs + TURN_CMD_RETRY_MS)) >= 0)) {
    Serial1.print(cmd);
    Serial1.print("\n");
    lastTurnCommandMs = now;
    turnCommandSendCount++;
  }
}

static void preparePhase2Drop() {
  actionSide = sidePhase2;
  int &a2 = ammoRefBySide(actionSide);
  if (a2 < 0) a2 = 0;
  int d2 = min(remainingNeed, a2);
  remainingNeed -= d2;
  actionDropsRemaining = d2;
  isPhase2Active = true;
  isActionDropCycle = false;
  actionNextDropMs = millis();
}

static void victimActionService() {
  if (isHomeBlinkActive) return;

  if (vStage == VS_WAIT_ACK) {
    if (isVackSkipReceived) {
      isVackSkipReceived = false;
      isWaitingVack = false;
      vStage = VS_IDLE;
      camerasPause(false);
      return;
    }
    if (isVackOkReceived) {
      isVackOkReceived = false;
      isWaitingVack = false;

      uint32_t deadline = millis() + VICTIM_DISPLAY_MS;
      if (reqSide == 'L') { dispVictimL = reqDispChar; dispVictimLUntilMs = deadline; }
      else                { dispVictimR = reqDispChar; dispVictimRUntilMs = deadline; }

      startVictimPlan(reqSide, reqVtype);
      return;
    }
    return;
  }

  if (vStage == VS_BLINK) {
    if (!victimBlinkActive) vStage = VS_GAP;
    return;
  }

  if (vStage == VS_GAP) {
    if (victimBlinkEndedMs == 0) victimBlinkEndedMs = millis();
    if ((int32_t)(millis() - (victimBlinkEndedMs + BLINK_TO_DROP_GAP_MS)) < 0) return;
    if (mainStopDoneMs != 0 && (int32_t)(millis() - mainStopDoneMs) < 0) return;

    if (actionDropsRemaining > 0) {
      vStage = VS_DROP;
      actionNextDropMs = millis();
      return;
    }

    if (isPlanTurn) {
      resetTurnCommandWait();
      vStage = VS_TURN;
      return;
    }

    finishActionAndMaybePending();
    return;
  }

  if (vStage == VS_DROP) {
    if (actionDropsRemaining <= 0) {
      if (isPhase2Active) {
        isPhase2Active = false;
        resetTurnCommandWait();
        vStage = VS_TURN_BACK;
        return;
      }
      if (isPlanTurn && remainingNeed > 0) {
        resetTurnCommandWait();
        vStage = VS_TURN;
        return;
      }
      finishActionAndMaybePending();
      return;
    }

    uint32_t now = millis();
    uint8_t idx = (actionSide == 'L') ? IDX_L : IDX_R;

    if (!isActionDropCycle && (int32_t)(now - actionNextDropMs) >= 0) {
      if (!dropperBusyIdx(idx)) {
        dropperStartIdx(idx);
        isActionDropCycle = true;
      }
    }

    if (isActionDropCycle) {
      bool done = gDrop[idx].donePulse || (!dropperBusyIdx(idx));
      if (done) {
        isActionDropCycle = false;
        int &ammo = ammoRefBySide(actionSide);
        if (ammo > 0) ammo--;
        actionDropsRemaining--;
        if (actionDropsRemaining > 0) actionNextDropMs = millis() + 150;
      }
    }
    return;
  }

  if (vStage == VS_TURN) {
    serviceSendTurnCommand("T180");
    if (isT180DoneReceived) {
      isT180DoneReceived = false;
      resetTurnCommandWait();
      preparePhase2Drop();
      vStage = VS_DROP;
    }
    return;
  }

  if (vStage == VS_TURN_BACK) {
    serviceSendTurnCommand("T180BK");
    if (isT180BkDoneReceived) {
      isT180BkDoneReceived = false;
      resetTurnCommandWait();
      finishActionAndMaybePending();
    }
    return;
  }
}

// ---- Camera RX（OpenMV: 255,id,count）----
static bool camPollLeft(uint8_t &outVtype, char &outDispChar) {
  static uint8_t st = 0, id = 0, cnt = 0;
  static uint32_t lastEv = 0;
  outVtype = 0; outDispChar = '-';

  while (Serial2.available()) {
    uint8_t b = (uint8_t)Serial2.read();
    if (st == 0) {
       if (b == 255) st = 1; 
      }
    else if (st == 1) {
       id = b; st = 2; 
       }
    else {
      cnt = b; (void)cnt; st = 0;
      uint8_t vt = idToVtype(id);
      if (!vt) return false;

      uint32_t now = millis();
      if (now - lastEv < EVENT_COOLDOWN_MS) return false;
      lastEv = now;

      outVtype = vt;
      outDispChar = idToDispChar(id);
      return true;
    }
  }
  return false;
}
static bool camPollRight(uint8_t &outVtype, char &outDispChar) {
  static uint8_t st = 0, id = 0, cnt = 0;
  static uint32_t lastEv = 0;
  outVtype = 0; outDispChar = '-';

  while (Serial7.available()) {
    uint8_t b = (uint8_t)Serial7.read();
    if (st == 0) { if (b == 255) st = 1; }
    else if (st == 1) { id = b; st = 2; }
    else {
      cnt = b; (void)cnt; st = 0;
      uint8_t vt = idToVtype(id);
      if (!vt) return false;

      uint32_t now = millis();
      if (now - lastEv < EVENT_COOLDOWN_MS) return false;
      lastEv = now;

      outVtype = vt;
      outDispChar = idToDispChar(id);
      return true;
    }
  }
  return false;
}

// =====================
// setup / loop
// =====================
void setup() {
  Serial.begin(BAUD);
  Serial1.begin(BAUD);

  pinMode(PIN_RST_SUB_BTN, INPUT_PULLUP);
  pinMode(PIN_RST_MAIN_BTN, INPUT_PULLUP);
  pinMode(PIN_SD_CLEAR_BTN, INPUT_PULLUP);

  // MAINの起動タイミングに合わせるため、押されていたら2秒間SDCLRを繰り返し送る。
  sendSdClearAtBootIfPressed();
  pinMode(LED_R, OUTPUT);
  pinMode(LED_Y, OUTPUT);
  pinMode(LED_G, OUTPUT);
  ledsAll(false);

  Wire.begin();
  Wire.setClock(400000);

  Wire1.begin();
  Wire1.setClock(50000);  // TCS34725は低速で安定優先

  Wire2.begin();
  Wire2.setClock(400000);

  if (!oled.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) while (1) {}
  oled.setTextWrap(false);
  oled.clearDisplay();
  oled.display();

  bool ok = initToF5Units();
  if (!ok) for (int i = 0; i < 5; i++) distMm[i] = 8190;

  if (tcs.begin(TCS34725_ADDRESS, &Wire1)) {
    isTcsPresent = true;
    tcs.setIntegrationTime(TCS34725_INTEGRATIONTIME_154MS);
    applyColorClassRefs154();
  } else {
    isTcsPresent = false;
  }

  Serial2.begin(CAM_BAUD);
  Serial7.begin(CAM_BAUD);

  dropperInitIdx(IDX_L, SERVO_L_PIN, L_CLOSED, L_OPEN);
  dropperInitIdx(IDX_R, SERVO_R_PIN, R_CLOSED, R_OPEN);

  drawTofScreenSub(false);
}

void tickall() {
  pollUartCommands();
  pollButtons();
  serviceHomeBlink();
  serviceVictimDisplayTimeout();

  uint32_t now = millis();

  // TOF読み取り
  if (now - lastTofReadMs >= TOF_READ_INTERVAL_MS) {
    lastTofReadMs = now;
    for (int i = 0; i < 5; i++) {
      uint16_t mm = tof[i].readRangeContinuousMillimeters();
      if (!tof[i].timeoutOccurred()) {
        distMm[i] = mm;
      }
    }
  }

  // MAIN reset
  if (isMainRstPending) {
    Serial1.println("RST_MCU");
    isMainRstPending = false;
  }

  // TOF送信（被災者アクション中はカメラ/投下/T180通信を優先して止める）
  bool suppressTofTx = isActionActive;
  if (!suppressTofTx && (now - lastTxMs >= TX_INTERVAL_MS)) {
    lastTxMs = now;
    sendFrameTof5(distMm);
  }

  // OLED
  if (now - lastDispMs >= DISP_INTERVAL_MS) {
    lastDispMs = now;
    drawTofScreenSub(isWaitingVack);
  }

  // サーボ
  dropperServiceIdx(IDX_L);
  dropperServiceIdx(IDX_R);

  // LED点滅（被災者）
  victimBlinkService();

  // 被災者アクション
  victimActionService();

  // ===== カメラ受信 → Vリクエスト =====
  if (!isHomeBlinkActive && vStage == VS_IDLE && !isWaitingVack && !isActionActive) {

    uint8_t vt; char dc;

    if (camPollLeft(vt, dc)) {
      // S0(左)が200mm以上の場合は壁がないので誤検知としてブロック！
      bool noWallLeft = (distMm[0] >= 200);
      
      if (!noWallLeft) {
        reqSide = 'L'; reqVtype = vt; reqDispChar = dc;
        isWaitingVack = true;
        vStage = VS_WAIT_ACK;
        camerasPause(true);
        sendVictimRequestToMain(reqSide, reqVtype);
      }
    } 
    else if (camPollRight(vt, dc)) {
      // S1(右)が200mm以上の場合は壁がないので誤検知としてブロック！
      bool noWallRight = (distMm[1] >= 200);
      
      if (!noWallRight) {
        reqSide = 'R'; reqVtype = vt; reqDispChar = dc;
        isWaitingVack = true;
        vStage = VS_WAIT_ACK;
        camerasPause(true);
        sendVictimRequestToMain(reqSide, reqVtype);
      }
    }
  }

  delay(0);
}

void loop() {
  tickall();
}
