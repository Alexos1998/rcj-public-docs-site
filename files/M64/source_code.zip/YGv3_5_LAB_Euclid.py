import sensor, image, time, math
from pyb import UART

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QQVGA)  # 160x120
sensor.set_auto_exposure(False, exposure_us=25000)
sensor.skip_frames(time=2000)

uart = UART(3, 19200)

WHITE_CIRCLE = (40, 100, -20, 20, -20, 20)

sum_history = []
MAX_HISTORY = 5

# 表示用
COLOR_NAME = {
    -2: "BLACK",
    -1: "RED",
     0: "YELLOW",
     1: "GREEN",
     2: "BLUE"
}

# LAB距離方式の基準値
# K=BLACK, R=RED, Y=YELLOW, G=GREEN, B=BLUE
REF_LAB = {
    "K": (14.3, -9.8,   9.0),
    "R": (34.5, 31.5,  11.8),
    "Y": (80.0,-12.0,  54.5),
    "G": (40.7,-29.3,  16.7),
    "B": (41.6, -0.6, -30.6)
}

# 距離方式の色キー → SUMコード
KEY_TO_CODE = {
    "K": -2,
    "R": -1,
    "Y":  0,
    "G":  1,
    "B":  2
}

# 一致率表示のスケーリング
# YGv3_S_3_2_Color_OLED_154ms と同じ考え方
NORM_ALPHA = 1.10


def lab_dist(l1, a1, b1, l2, a2, b2):
    dl = l1 - l2
    da = a1 - a2
    db = b1 - b2
    return math.sqrt(dl * dl + da * da + db * db)


def compute_d_norm():
    keys = ["K", "R", "Y", "G", "B"]
    total = 0
    count = 0

    for i in range(len(keys)):
        for j in range(i + 1, len(keys)):
            l1, a1, b1 = REF_LAB[keys[i]]
            l2, a2, b2 = REF_LAB[keys[j]]

            total += lab_dist(l1, a1, b1, l2, a2, b2)
            count += 1

    if count > 0:
        return total / count
    else:
        return 1.0


D_NORM = compute_d_norm()


def distance_to_percent(d):
    denom = D_NORM * NORM_ALPHA
    if denom <= 0:
        denom = 1.0

    p = 100.0 * (1.0 - (d / denom))

    if p < 0:
        p = 0
    if p > 100:
        p = 100

    return p


def lab_match_rates(l, a, b_val):
    result = {}

    for key in ["K", "R", "Y", "G", "B"]:
        rl, ra, rb = REF_LAB[key]
        d = lab_dist(l, a, b_val, rl, ra, rb)
        result[key] = distance_to_percent(d)

    return result


def classify_by_lab_distance(l, a, b_val):
    best_key = None
    best_dist = None

    for key in ["K", "R", "Y", "G", "B"]:
        rl, ra, rb = REF_LAB[key]
        d = lab_dist(l, a, b_val, rl, ra, rb)

        if best_dist is None or d < best_dist:
            best_dist = d
            best_key = key

    return KEY_TO_CODE[best_key], best_key


while True:
    img = sensor.snapshot()
    blobs = img.find_blobs([WHITE_CIRCLE], pixels_threshold=400, invert=True)

    if not blobs:
        sum_history.clear()
        continue

    for b in blobs:
        if b.h() > 115 or b.roundness() < 0.6:
            continue

        cx, cy, h = b.cx(), b.cy(), b.h()

        y_top = b.y() + 1
        y_bottom = b.y() + (h / 2)
        scan_height = y_bottom - y_top

        # (色コード, ピクセル数, 平均L, 平均A, 平均B)
        detected_layers = []

        last_match = None
        color_counter = 0

        l_sum = 0
        a_sum = 0
        b_sum = 0

        for y_pos in range(int(y_top), int(y_bottom), 1):
            if 0 <= y_pos < img.height():
                stat = img.get_statistics(roi=(cx-1, y_pos-1, 3, 3))

                l = stat.l_mean()
                a = stat.a_mean()
                b_val = stat.b_mean()

                # ===== ここを LAB距離方式に変更 =====
                match, match_key = classify_by_lab_distance(l, a, b_val)
                # ==================================

                if y_pos == int(y_top):
                    last_match = match
                    color_counter = 1

                    l_sum = l
                    a_sum = a
                    b_sum = b_val

                else:
                    if match == last_match:
                        color_counter += 1

                        l_sum += l
                        a_sum += a
                        b_sum += b_val

                    else:
                        if color_counter >= 2:
                            percentage = (color_counter / scan_height) * 100

                            if percentage >= 30.0:
                                layer_count = 2
                            else:
                                layer_count = 1

                            avg_l = l_sum / color_counter
                            avg_a = a_sum / color_counter
                            avg_b = b_sum / color_counter

                            for _ in range(layer_count):
                                detected_layers.append((last_match, color_counter, avg_l, avg_a, avg_b))

                        last_match = match
                        color_counter = 1

                        l_sum = l
                        a_sum = a
                        b_sum = b_val

        # 最後の連続区間を処理
        if last_match is not None and color_counter >= 2:
            percentage = (color_counter / scan_height) * 100

            if percentage >= 90.0:
                layer_count = 5
            elif percentage >= 70.0:
                layer_count = 4
            elif percentage >= 50.0:
                layer_count = 3
            elif percentage >= 30.0:
                layer_count = 2
            else:
                layer_count = 1

            avg_l = l_sum / color_counter
            avg_a = a_sum / color_counter
            avg_b = b_sum / color_counter

            for _ in range(layer_count):
                detected_layers.append((last_match, color_counter, avg_l, avg_a, avg_b))

        if detected_layers:
            current_sum = sum(code for code, _, _, _, _ in detected_layers)

            sum_history.append(current_sum)
            if len(sum_history) > MAX_HISTORY:
                sum_history.pop(0)

            final_sum = max(set(sum_history), key=sum_history.count)

            layer_codes = [code for code, _, _, _, _ in detected_layers]
            layer_names = [COLOR_NAME.get(code, "UNKNOWN") for code, _, _, _, _ in detected_layers]
            layer_pixels = [cnt for _, cnt, _, _, _ in detected_layers]

            # 同じ色・同じピクセル数が連続している場合、
            # 同一区間を複数層に分けたものとして RATE を割って表示
            layer_rate_text = []

            i = 0
            while i < len(detected_layers):
                code_i, cnt_i, avg_l_i, avg_a_i, avg_b_i = detected_layers[i]

                same_count = 1
                j = i + 1

                while j < len(detected_layers):
                    code_j, cnt_j, avg_l_j, avg_a_j, avg_b_j = detected_layers[j]

                    if code_j == code_i and cnt_j == cnt_i:
                        same_count += 1
                        j += 1
                    else:
                        break

                rate = ((cnt_i / scan_height) * 100) / same_count

                for _ in range(same_count):
                    layer_rate_text.append("%.1f%%" % rate)

                i = j

            print("===================================")
            print("TARGET x=%d y=%d w=%d h=%d round=%.2f" %
                  (b.x(), b.y(), b.w(), b.h(), b.roundness()))

            print("SCAN y_top=%d y_bottom=%d height=%.1f" %
                  (int(y_top), int(y_bottom), scan_height))

            print("LAYER COLOR :", layer_names)
            print("LAYER CODE  :", layer_codes)
            print("LAYER PIXEL :", layer_pixels)
            print("LAYER RATE  :", layer_rate_text)

            print("LAYER LAB   :")
            for i in range(len(detected_layers)):
                code, cnt, avg_l, avg_a, avg_b = detected_layers[i]
                name = COLOR_NAME.get(code, "UNKNOWN")

                print("%d: %-6s L=%5.1f A=%6.1f B=%6.1f  PIXEL=%2d RATE=%s" %
                      (i + 1, name, avg_l, avg_a, avg_b, cnt, layer_rate_text[i]))

            print("DIST RATE   :")
            for i in range(len(detected_layers)):
                code, cnt, avg_l, avg_a, avg_b = detected_layers[i]
                rates = lab_match_rates(avg_l, avg_a, avg_b)

                print("%d: K=%3d%% R=%3d%% Y=%3d%% G=%3d%% B=%3d%%" %
                      (i + 1,
                       int(rates["K"] + 0.5),
                       int(rates["R"] + 0.5),
                       int(rates["Y"] + 0.5),
                       int(rates["G"] + 0.5),
                       int(rates["B"] + 0.5)))

            print("CURRENT SUM :", current_sum)
            print("HISTORY     :", sum_history)
            print("FINAL SUM   :", final_sum)
            print("-----------------------------------")

            print("合計値(SUM):", final_sum)
            print("-----------------------------------")

            img.draw_string(b.x(), b.y()-30, "SUM:%d" % final_sum, color=(0,255,0), scale=2)

            try:
                uart.write(bytes([255, final_sum & 0xFF]))
            except:
                pass
