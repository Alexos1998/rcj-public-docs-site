from gpiozero import DigitalInputDevice
from signal import pause

ingresso = DigitalInputDevice(25, pull_up=True)  # pull-down interno

while True:
    print(ingresso.value)   # 1 = HIGH, 0 = LOW