""" VL53L0X Sensor Interface Library """

import VL53L0X

class TOF_Sensor(object):
    def __init__(self, multiplexer_port: int, tof_id: str):
        self._multiplexer_port = multiplexer_port
        self._tof_id = tof_id
        self._class_inherited = VL53L0X.VL53L0X(tca9548a_num= multiplexer_port,
                                               tca9548a_addr=0x70)

    def init_sensor(self):
        try:
            self._class_inherited.open()
            self._class_inherited.start_ranging(VL53L0X.Vl53l0xAccuracyMode.BETTER)
        except Exception as e:
            TOF_Sensor.close_tof()
            return e
            

    def get_distance(self):
        try:
            distance = self._class_inherited.get_distance()
            return distance
        except Exception as e:
            TOF_Sensor.close_tof()
            return e
            

    def close_tof(self):
        self._class_inherited.stop_ranging()
        self._class_inherited.close()
    
if __name__ == "__main__":
    tof_2 = TOF_Sensor(2, "tof_2")
    tof_2.init_sensor()
    print(tof_2.get_distance())