""" LSMDS3_LISMOL Sensor Interface Library """

import time
import board
import math
import adafruit_tca9548a
from adafruit_lsm6ds.lsm6ds33 import LSM6DS33 as LSM6DS
import adafruit_lis3mdl
import numpy as np
import threading


CALIBRATION_SAMPLES: int = 500
CALIBRATION_DELAY: float = 0.01

Q = np.diag([
    0.0001,
    0.0001,
    0.0001,
    0.00001,
    0.00001,
    0.00001
])

R = np.diag([
    0.1,
    0.1,
    0.1
])


ACCELEROMETER_ZUPT_THRESHOLD: float = 0.5
GYROSCOPE_ZUPT_THRESHOLD: float = 0.05

class IMUManager(object):
    def __init__(self):

        self._roll: float = 0.0
        self._pitch: float = 0.0
        self._yaw: float = 0.0
        self._data_lock = threading.Lock()
        self._is_running = threading.Event()

        self._x = np.zeros(6)
        self._P = np.eye(6) * 10.0

        self._initialize_sensors()
        self._gyro_bias, self._orientation_offset = self._calibrate_sensors()
        self._initialize_orientation()

        self._is_running.set()
        self._thread = threading.Thread(target=self._processing_loop, daemon=True)
        self._thread.start()

    def _initialize_sensors(self):
        print("Initializing sensors...")
        try:
            i2c = board.I2C()
            i2c_multiplexer = adafruit_tca9548a.TCA9548A(i2c)
            i2c_channel_0 = i2c_multiplexer[0]
            self.accel_gyro = LSM6DS(i2c_channel_0)
            self.mag = adafruit_lis3mdl.LIS3MDL(i2c_channel_0)
            print("Sensors initialized successfully.")
        except Exception as e:
            print(f"Error initializing sensors: {e}")
            raise

    def _calibrate_sensors(self):
        print("\n--- Sensor Calibration ---")
        print("Calibrating Gyroscope. Please keep the sensor still...")
        gyro_sum = np.zeros(3)
        for _ in range(CALIBRATION_SAMPLES):
            gyro_data = self.accel_gyro.gyro
            gyro_sum += np.array(gyro_data)
            time.sleep(CALIBRATION_DELAY)

        gyro_bias = gyro_sum / CALIBRATION_SAMPLES
        print(f"Gyroscope bias calculated: X:{gyro_bias[0]:.4f}, Y:{gyro_bias[1]:.4f}, Z:{gyro_bias[2]:.4f} rad/s")

        print("\nSetting initial orientation. Hold sensor in its 'zero' position.")
        time.sleep(2)

        initial_acceleration = np.array(self.accel_gyro.acceleration)
        initial_roll_rad = math.atan2(initial_acceleration[1], initial_acceleration[2])
        initial_pitch_rad = math.atan2(-initial_acceleration[0], np.sqrt(initial_acceleration[1]**2 + initial_acceleration[2]**2))
        initial_yaw_rad = 0.0

        orientation_offset = {
            "roll": math.degrees(initial_roll_rad),
            "pitch": math.degrees(initial_pitch_rad),
            "yaw": math.degrees(initial_yaw_rad)
        }
        print(f"Initial orientation offsets set: Roll:{orientation_offset['roll']:.2f}°, Pitch:{orientation_offset['pitch']:.2f}°, Yaw:{orientation_offset['yaw']:.2f}°")
        print("--- Calibration Complete ---\n")
        return gyro_bias, orientation_offset

    def _initialize_orientation(self):
        initial_accel = np.array(self.accel_gyro.acceleration)
        initial_roll_rad = math.atan2(initial_accel[1], initial_accel[2])
        initial_pitch_rad = math.atan2(-initial_accel[0], np.sqrt(initial_accel[1]**2 + initial_accel[2]**2))

        self._x[0] = initial_roll_rad
        self._x[1] = initial_pitch_rad
        self._x[3:6] = self._gyro_bias

    def _processing_loop(self):
        last_time = time.monotonic()
        while self._is_running.is_set():
            current_time = time.monotonic()
            dt = current_time - last_time
            last_time = current_time

            acceleration = np.array(self.accel_gyro.acceleration)
            gyro = np.array(self.accel_gyro.gyro)

            self._x, self._P = self._kalman_filter_step(self._x, self._P, gyro, acceleration, dt)
            self._x, self._P = self._zero_velocity_update(self._x, self._P, gyro, acceleration)

            current_roll_deg = math.degrees(self._x[0])
            current_pitch_deg = math.degrees(self._x[1])
            current_yaw_deg = math.degrees(self._x[2])

            zeroed_roll = current_roll_deg - self._orientation_offset['roll']
            zeroed_pitch = current_pitch_deg - self._orientation_offset['pitch']
            zeroed_yaw = current_yaw_deg - self._orientation_offset['yaw']

            while zeroed_yaw > 180: zeroed_yaw -= 360
            while zeroed_yaw < -180: zeroed_yaw += 360

            with self._data_lock:
                self._roll = zeroed_roll
                self._pitch = zeroed_pitch
                self._yaw = zeroed_yaw

            time.sleep(0.01)

    def get_orientation(self):
        with self._data_lock:
            return (self._roll, self._pitch, self._yaw)

    def stop(self):
        print("Stopping IMU Manager...")
        self._is_running.clear()
        self._thread.join()
        print("IMU Manager stopped.")

    @staticmethod
    def _kalman_filter_step(x, P, gyro, accel, dt):
        F = np.eye(6)
        F[0:3, 3:6] = -np.eye(3) * dt

        x_pred = x.copy()
        x_pred[0] += (gyro[0] - x[3]) * dt
        x_pred[1] += (gyro[1] - x[4]) * dt
        x_pred[2] += (gyro[2] - x[5]) * dt

        P_pred = F @ P @ F.T + Q

        g = 9.80665
        accel_expected = np.array([
            -g * math.sin(x_pred[1]),
            g * math.cos(x_pred[1]) * math.sin(x_pred[0]),
            g * math.cos(x_pred[1]) * math.cos(x_pred[0])
        ])

        H = np.zeros((3, 6))
        H[0, 1] = -g * math.cos(x_pred[1])
        H[1, 0] = g * math.cos(x_pred[1]) * math.cos(x_pred[0])
        H[1, 1] = -g * math.sin(x_pred[1]) * math.sin(x_pred[0])
        H[2, 0] = -g * math.cos(x_pred[1]) * math.sin(x_pred[0])
        H[2, 1] = -g * math.sin(x_pred[1]) * math.cos(x_pred[0])

        S = H @ P_pred @ H.T + R
        K = P_pred @ H.T @ np.linalg.inv(S)

        innovation = accel - accel_expected
        x_new = x_pred + K @ innovation
        P_new = (np.eye(6) - K @ H) @ P_pred

        return x_new, P_new

    @staticmethod
    def _zero_velocity_update(x, P, gyro, accel):
        is_stationary = (
            np.linalg.norm(accel) > 9.8 - ACCELEROMETER_ZUPT_THRESHOLD and
            np.linalg.norm(accel) < 9.8 + ACCELEROMETER_ZUPT_THRESHOLD and
            np.linalg.norm(gyro) < GYROSCOPE_ZUPT_THRESHOLD
        )

        if is_stationary:
            x[2] = 0.0
            P[2, :] = 0.0
            P[:, 2] = 0.0
            P[2, 2] = 1e-9
        return x, P