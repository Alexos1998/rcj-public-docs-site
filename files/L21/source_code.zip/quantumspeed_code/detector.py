import cv2
import threading
from ultralytics import YOLO

class DetectorAI:
    def __init__(self, model_path="silver_e150_ncnn_model", target_class_id=0, conf_threshold=0.6):
        self.target_class_id = target_class_id
        self.conf_threshold = conf_threshold
        
        self.frame_counter = 0
        self.skip_frames = 4  
        
        self.last_state = False
        
        self.inference_lock = threading.Lock()
        
        print(f"[AI] Caricamento modello NCNN nativo a 640px {model_path}...")
        self.model = YOLO(model_path)
        print("[SISTEMA] Detector a salto di frame (Anti-Crash 640px) pronto.")

    def process_frame(self, raw_frame, show_preview=False):
        if raw_frame is None:
            return False, None

        self.frame_counter += 1
        annotated_frame = None

        if self.frame_counter % (self.skip_frames + 1) != 0:
            if show_preview:
                annotated_frame = cv2.resize(raw_frame, (480, 270), interpolation=cv2.INTER_AREA)
            return self.last_state, annotated_frame

        scaled_frame = cv2.resize(raw_frame, (480, 270), interpolation=cv2.INTER_AREA)

        object_detected = False

        with self.inference_lock:
            results = self.model(scaled_frame, conf=self.conf_threshold, imgsz=640, verbose=False)
            
            if results and len(results) > 0:
                res = results[0]
                detected_classes = res.boxes.cls.tolist()
                
                if self.target_class_id in detected_classes:
                    object_detected = True
                
                if show_preview:
                    annotated_frame = res.plot()

        self.last_state = object_detected

        return object_detected, annotated_frame

    def check_object(self, raw_frame, show_preview=False):
        return self.process_frame(raw_frame, show_preview)