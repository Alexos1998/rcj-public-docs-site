from gpiozero import Motor
import gpiozero
import time

class DCMotorLGPIO:
    def __init__(self, left_forward, left_backward, right_forward, right_backward):
        self.left_motor = Motor(forward=left_forward, backward=left_backward)
        self.right_motor = Motor(forward=right_forward, backward=right_backward)

        self.left_motor.stop()
        self.right_motor.stop()

    def set_motor_speed_direction(self, left_speed, left_dir, right_speed, right_dir):
        # Convert 0-100 to 0-1 for gpiozero
        left_speed = max(0, min(80, left_speed)) / 100
        right_speed = max(0, min(80, right_speed)) / 100
        
        if left_dir.upper() == 'FW':
            self.left_motor.backward(left_speed)
        elif left_dir.upper() == 'BW':
            self.left_motor.forward(left_speed)
        else:
            print("[ERROR] Invalid left motor direction. Use 'FW' or 'BW'.")

        if right_dir.upper() == 'FW':
            self.right_motor.forward(right_speed)
        elif right_dir.upper() == 'BW':
            self.right_motor.backward(right_speed)
        else:
            print("[ERROR] Invalid right motor direction. Use 'FW' or 'BW'.")

    
    
    def stop(self):
        try:
            
            if hasattr(self, 'left_motor') and self.left_motor:
                self.left_motor.value = 0
            if hasattr(self, 'right_motor') and self.right_motor:
                self.right_motor.value = 0
        except (gpiozero.exc.GPIODeviceClosed, AttributeError):
            
            pass

    def cleanup(self):
        print("[INFO] Rilascio risorse GPIO motori...")
        
        
        self.stop()
        
        
        if hasattr(self, 'left_motor') and self.left_motor:
            self.left_motor.close()
            self.left_motor = None
            
        if hasattr(self, 'right_motor') and self.right_motor:
            self.right_motor.close()
            self.right_motor = None

    def avanti(self, fast):
        self.right_motor.forward(fast)
        self.left_motor.backward(fast)

    def avanti_stanza(self, fast, fast2):
        self.right_motor.forward(fast)
        self.left_motor.backward(fast2)
    
    def avantigap(self, fast):
        self.right_motor.forward(fast+0.07)
        self.left_motor.backward(fast)
        

    def indietro(self, fast):
        self.right_motor.backward(fast)
        self.left_motor.forward(fast)

    def right(self, fast):
        self.right_motor.forward(fast)
        self.left_motor.forward(fast)

    def left(self, fast):
        self.right_motor.backward(fast)
        self.left_motor.backward(fast)


    def avanticm(self, cm):
        self.right_motor.forward(0.75)
        self.left_motor.backward(0.70)
        time.sleep(cm/12.3)
        self.left_motor.stop()
        self.right_motor.stop()
    
    def avanticm_lento(self, cm):
        self.right_motor.forward(0.3)
        self.left_motor.backward(0.3)
        time.sleep(cm/12.3)
        self.left_motor.stop()
        self.right_motor.stop()

    def avanticm_verde(self, cm, fast1, fast2):
        self.right_motor.forward(fast1)
        self.left_motor.backward(fast2)
        time.sleep(cm/12.3)
        self.left_motor.stop()
        self.right_motor.stop()

    def indietrocm(self, cm):
        self.right_motor.backward(0.75)
        self.left_motor.forward(0.75)
        time.sleep(cm/12.3)
        self.left_motor.stop()
        self.right_motor.stop()

    def indietrocm_verde(self, cm, fast1, fast2):
        self.right_motor.backward(fast1)
        self.left_motor.forward(fast2)
        time.sleep(cm/12.3)
        self.left_motor.stop()
        self.right_motor.stop()

    def only_right(self, fast):
        self.right_motor.forward(fast)
        self.left_motor.forward(0.1)

    def only_right_endreo(self, fast):
        self.right_motor.backward(fast)
        self.left_motor.backward(0.1)

    def only_right_green(self, fast1, fast2):
        self.right_motor.forward(fast1)
        self.left_motor.forward(fast2)

    def only_left(self, fast):
        self.right_motor.backward(0.1)
        self.left_motor.backward(fast)

    def only_left_obstacle(self, fast):
        self.right_motor.backward(fast)
        self.left_motor.backward(0.1)

    def only_left_green(self, fast1, fast2):
        self.right_motor.backward(fast2)
        self.left_motor.backward(fast1)

    def girodx(self, gradi):
        self.right_motor.forward(0.8)
        self.left_motor.forward(0.8)
        time.sleep(gradi/70)
        self.left_motor.stop()
        self.right_motor.stop()  

    def girosx(self, gradi):
        self.right_motor.backward(0.8)
        self.left_motor.backward(0.8)
        time.sleep(gradi/70)
        self.left_motor.stop()
        self.right_motor.stop()
    

if __name__ == "__main__":
    
    motor = DCMotorLGPIO(17, 23, 22, 27) #17, 23, 22, 27
    print("[ACTION] Left motor FW at 10%, right motor BW at 80% for 3 seconds.")
    #motor.set_motor_speed_direction(left_speed = 80, left_dir = 'BW', right_speed = 80, right_dir = 'BW')
    #time.sleep(2)
    time.sleep(1)
    while True:
        motor.indietrocm_verde(5, 0.7, 0.6)
    time.sleep(0.2)
    time.sleep(3)
    time.sleep(3)
    #motor.indietrocm(15)
    time.sleep(15)
    #while True:
        #motor.avanti(1)
    '''motor.avanticm(50)
    print('i')
    motor.indietrocm(50)
    print('i')
    motor.girodx(180)
    print('i')
    motor.girosx(180)'''

    print("[ACTION] Stopping motors.")
    #motor.stop()

    print("[INFO] Program completed.")
