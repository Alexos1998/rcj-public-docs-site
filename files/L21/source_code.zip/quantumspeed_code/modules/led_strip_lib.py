import time
from pi5neo import Pi5Neo


class LED_Strip(object):
   def __init__(self, LED_COUNT, id):
       self.LED_COUNT = LED_COUNT
       self.id = id
       self.SPI_SPEED_KHZ = 800
       self.inherited_class = Pi5Neo('/dev/spidev0.0', LED_COUNT, self.SPI_SPEED_KHZ)

   def fine(self):
        for i in range(32):
            self.inherited_class.set_led_color(i, 255, 200, 50)
        self.inherited_class.update_strip()

        for i in range(16):
            self.inherited_class.set_led_color(15-i, 0, 0, 0)
            self.inherited_class.set_led_color(16+i, 0, 0, 0)
            self.inherited_class.update_strip()
        
        for i in range(16):
            self.inherited_class.set_led_color(16+i, 255, 0, 0)
            self.inherited_class.set_led_color(i, 255, 0, 0)
            self.inherited_class.update_strip()
        

        

        
        '''a = 200
        b = 50
        color = (255, 200, 50)
        dimmed_color = tuple(int(c * 0.5) for c in color)

        for j in range (8, 0, -2):
            for i in range(7-j,j+7):
                a = max(0, a - int(220/7))
                b = max(0, b - int(56/7))
                color = (255, a, b)
                dimmed_color = tuple(int(c * 0.1) for c in color)
                dimmed_color2 = tuple(int(c * 0.2) for c in color)
                dimmed_color3 = tuple(int(c) for c in color)
                self.inherited_class.set_led_color(i, *dimmed_color2)
                self.inherited_class.set_led_color(i-1, *dimmed_color)
                self.inherited_class.set_led_color(i-2, 0, 0, 0)
                self.inherited_class.set_led_color(13-i, *dimmed_color2)
                self.inherited_class.set_led_color(13-i+1, *dimmed_color)
                self.inherited_class.set_led_color(13-i+2, 0, 0, 0)
                self.inherited_class.update_strip()

        for i in range(1,7):
            self.inherited_class.set_led_color(6-i, *dimmed_color2)
            self.inherited_class.set_led_color(7+i, *dimmed_color2)
            self.inherited_class.update_strip()
        
        for j in range(7):
            for i in range(7-j):
                self.inherited_class.set_led_color(i, *dimmed_color3)
                self.inherited_class.set_led_color(i-1, *dimmed_color2)
                self.inherited_class.set_led_color(14-i, *dimmed_color3)
                self.inherited_class.set_led_color(14-i+1, *dimmed_color2)
                self.inherited_class.update_strip()
        
        for j in range(2):
            for i in range(15):
                self.inherited_class.set_led_color(i, 0,0,0)
            self.inherited_class.update_strip()
            for i in range(15):
                self.inherited_class.set_led_color(i, *dimmed_color3)
            self.inherited_class.update_strip()
        
        a = 250
        for i in range(7):
            a = max(0, a - int(250/7))
            color = (a, 0, 0)
            dimmed_color = tuple(int(c * (a/250)) for c in color)
            for i in range(15):
                self.inherited_class.set_led_color(i, *dimmed_color)
            self.inherited_class.update_strip()'''

        
            
                       

   def set_leds(self, pattern, color, brightness = 255):
      
       brightness_factor = brightness / 255.0
       dimmed_color = tuple(int(c * brightness_factor) for c in color)


       for i in range(-2,self.inherited_class.num_leds):
           if pattern[i] == 1:
               self.inherited_class.set_led_color(i, *dimmed_color)
           else:
               self.inherited_class.set_led_color(i, 0, 0, 0)
          
       self.inherited_class.update_strip()


   def check_led_startup(self, color):
        brightness_factor = 255 / 255.0
        dimmed_color = tuple(int(c * brightness_factor) for c in color)


        for i in range(self.inherited_class.num_leds):
            if (1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1)[i] == 1:
                self.inherited_class.set_led_color(i, *dimmed_color)
            else:
                self.inherited_class.set_led_color(i, 0, 0, 0)
            
            self.inherited_class.update_strip()
        

        for i in range(3):
            for i in range(self.inherited_class.num_leds):
                if (0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)[i] == 1:
                    self.inherited_class.set_led_color(i, *dimmed_color)
                else:
                    self.inherited_class.set_led_color(i, 0, 0, 0)
                
            self.inherited_class.update_strip()

            time.sleep(0.1)

            for i in range(self.inherited_class.num_leds):
                if (1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1)[i] == 1:
                    self.inherited_class.set_led_color(i, *dimmed_color)
                else:
                    self.inherited_class.set_led_color(i, 0, 0, 0)
                
            self.inherited_class.update_strip()
   
   def video(self):
        

        # Spegne i LED dal centro verso l'esterno
        for i in range(16):
            self.inherited_class.set_led_color(15-i, 0, 0, 0)
            self.inherited_class.set_led_color(16+i, 0, 0, 0)
            self.inherited_class.update_strip()
        
        # Riaccende i LED con il nuovo colore (255, 255, 130) dall'interno verso l'esterno
        for i in range(16):
            self.inherited_class.set_led_color(16+i, 255, 255, 130)
            self.inherited_class.set_led_color(i, 255, 255, 130)
            self.inherited_class.update_strip()

        for i in range(3):
            led_mask = tuple([1] * 32)
            self.set_leds(led_mask, (255, 255, 130), 0)

            time.sleep(0.01)

            led_mask = tuple([1] * 32)
            self.set_leds(led_mask, (255, 255, 130), 255)

if __name__ == "__main__":
    led_strip = LED_Strip(32, "strip_1")
    led_mask = (1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1)
    led_strip.video()



