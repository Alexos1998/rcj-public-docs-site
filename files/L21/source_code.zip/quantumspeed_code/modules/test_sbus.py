import board
import busio
import adafruit_tca9548a

i2c = busio.I2C(board.SCL, board.SDA)
tca = adafruit_tca9548a.TCA9548A(i2c)

# Scan all 8 channels of the multiplexer
for channel in range(8):
    if tca[channel].try_lock():
        addresses = tca[channel].scan()
        tca[channel].unlock()
        if addresses:
            print(f"Channel {channel} found devices at: {[hex(addr) for addr in addresses]}")