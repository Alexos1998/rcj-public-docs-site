"""Library to interface with DC motors using lgpio"""

import lgpio
import time
import atexit

print("module imported")

class DCMotorLGPIO:
   def __init__(self, out_1: int, out_2: int, out_3: int, out_4: int):
       self.output_1 = out_1  # Left Motor Forward
       self.output_2 = out_2  # Left Motor Reverse
       self.output_3 = out_3  # Right Motor Reverse
       self.output_4 = out_4  # Right Motor Forward


       self.frequency = 10000
       self.chip = 0
       self.handle = None


   def initialize_motor(self):
       self.handle = lgpio.gpiochip_open(self.chip)


       # Claim pins and set LOW
       for pin in [self.output_1, self.output_2, self.output_3, self.output_4]:
           lgpio.gpio_claim_output(self.handle, pin)
           lgpio.gpio_write(self.handle, pin, 0)


       # Register cleanup on exit
       atexit.register(self.end)


   def direction(self, speed: int, dir: str):
       """Legacy unified direction control"""
       if speed > 100:
           speed = 100
       if speed < 0:
           speed = 0


       # Stop all PWM first
       for pin in [self.output_1, self.output_2, self.output_3, self.output_4]:
           lgpio.gpio_write(self.handle, pin, 0)


       if dir == "FW":
           lgpio.gpio_write(self.handle, self.output_2, 0)
           lgpio.tx_pwm(self.handle, self.output_1, self.frequency, speed)


           lgpio.gpio_write(self.handle, self.output_3, 0)
           lgpio.tx_pwm(self.handle, self.output_4, self.frequency, speed)


       elif dir == "BW":
           lgpio.gpio_write(self.handle, self.output_1, 0)
           lgpio.tx_pwm(self.handle, self.output_2, self.frequency, speed)


           lgpio.gpio_write(self.handle, self.output_4, 0)
           lgpio.tx_pwm(self.handle, self.output_3, self.frequency, speed)


       elif dir == "R":
           lgpio.gpio_write(self.handle, self.output_1, 0)
           lgpio.tx_pwm(self.handle, self.output_2, self.frequency, speed)


           lgpio.gpio_write(self.handle, self.output_3, 0)
           lgpio.tx_pwm(self.handle, self.output_4, self.frequency, speed)


       elif dir == "L":
           lgpio.gpio_write(self.handle, self.output_2, 0)
           lgpio.tx_pwm(self.handle, self.output_1, self.frequency, speed)


           lgpio.gpio_write(self.handle, self.output_4, 0)
           lgpio.tx_pwm(self.handle, self.output_3, self.frequency, speed)


       else:
           print("[ERROR] Invalid direction. Use: FW, BW, R, L")


   def set_motor_speed_direction(self, left_speed: int, left_dir: str, right_speed: int, right_dir: str):
       """Control each motor independently by speed and direction."""
       # Clamp speeds
       left_speed = max(0, min(100, left_speed))
       right_speed = max(0, min(100, right_speed))


       # Stop all PWM before setting new values
       for pin in [self.output_1, self.output_2, self.output_3, self.output_4]:
           lgpio.gpio_write(self.handle, pin, 0)


       # Left motor
       if left_dir.upper() == 'FW':
           lgpio.gpio_write(self.handle, self.output_2, 0)
           lgpio.tx_pwm(self.handle, self.output_1, self.frequency, left_speed)
       elif left_dir.upper() == 'BW':
           lgpio.gpio_write(self.handle, self.output_1, 0)
           lgpio.tx_pwm(self.handle, self.output_2, self.frequency, left_speed)
       else:
           print("[ERROR] Invalid left motor direction. Use 'FW' or 'BW'.")


       # Right motor
       if right_dir.upper() == 'FW':
           lgpio.gpio_write(self.handle, self.output_3, 0)
           lgpio.tx_pwm(self.handle, self.output_4, self.frequency, right_speed)
       elif right_dir.upper() == 'BW':
           lgpio.gpio_write(self.handle, self.output_4, 0)
           lgpio.tx_pwm(self.handle, self.output_3, self.frequency, right_speed)
       else:
           print("[ERROR] Invalid right motor direction. Use 'FW' or 'BW'.")
           
       print(right_speed,'a',left_speed)


   def end(self):
       # Stop all motors
       for pin in [self.output_1, self.output_2, self.output_3, self.output_4]:
           try:
               lgpio.gpio_write(self.handle, pin, 0)
           except Exception:
               pass


       # Close the chip
       try:
           if self.handle is not None:
               lgpio.gpiochip_close(self.handle)
               print("[INFO] GPIO chip closed.")
       except Exception as e:
           print(f"[ERROR] Cleanup failed: {e}")




if __name__ == "__main__":
   motor = DCMotorLGPIO(17, 18, 25, 24)
   motor.initialize_motor()


   print("[ACTION] Left motor FW at 80%, right motor BW at 60% for 3 seconds.")
   motor.set_motor_speed_direction(left_speed=10, left_dir='FW', right_speed=80, right_dir='BW')
   time.sleep(3)


   print("[ACTION] Stopping motors.")
   motor.end()


   print("[INFO] Program completed.")





