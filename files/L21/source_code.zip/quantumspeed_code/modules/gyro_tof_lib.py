import time
import board
import math
import threading
import busio
import smbus2
import os
import sys
import json 
import numpy as np
import adafruit_tca9548a
from adafruit_bus_device.i2c_device import I2CDevice
from adafruit_lsm6ds.lsm6ds33 import LSM6DS33
from adafruit_pca9685 import PCA9685
from adafruit_motor import servo
from dataclasses import dataclass
from typing import Optional, Dict


current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)


from DFRobot_TMF8x01 import DFRobot_TMF8801


i2c_hardware_lock = threading.Lock()


IMU_CALIB_FILE = os.path.join(current_dir, "imu_calibration.json")


class TMF8801_HardwareLight:
    def __init__(self, tca_channel, channel_num: int, bus_id=1):
        self.tca_channel = tca_channel
        self.bus_id = bus_id
        self.address = 0x41       
        self.channel_num = channel_num 
        self.mux_address = 0x70    
        
        self._last_valid_distance = 0
        self._init_sensor()

    def _force_mux_switch(self):
        """Forza lo switch del multiplexer scrivendo direttamente sul bus hardware tramite smbus2"""
        try:
            bus = smbus2.SMBus(self.bus_id)
            bus.write_byte(self.mux_address, 1 << self.channel_num)
            bus.close()
            time.sleep(0.010)  
        except Exception:
            pass

    def _init_sensor(self):
        """Verifica se il sensore è già attivo. In caso contrario, esegue il bootloader e scarica la RAM application"""
        cali_data = [0x41, 0x57, 0x01, 0xFD, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
        
        with i2c_hardware_lock:
            self._force_mux_switch()
            try:
                
                bus = smbus2.SMBus(self.bus_id)
                current_state = bus.read_byte_data(self.address, 0x1E)
                bus.close()
                
                if current_state == 0x55:
                    print(f"[TMF8801]: Canale {self.channel_num} già attivo e funzionante. Salto inizializzazione.")
                    return
            except Exception:
                
                pass
            
        with i2c_hardware_lock:
            self._force_mux_switch()
            try:
                tof = DFRobot_TMF8801(bus_id=self.bus_id, enPin=-1, intPin=-1)
                tentativi = 0
                while tof.begin() != 0:
                    time.sleep(0.05)
                    self._force_mux_switch()
                    tentativi += 1
                    if tentativi > 5:
                        print(f"[TMF8801]: Timeout inizializzazione sul canale MUX {self.channel_num}.")
                        return
                
                try:
                    tof.set_calibration_data(cali_data)
                except AttributeError:
                    tof.setCalibrationData(cali_data)
                    
                tof.start_measurement(1)
                print(f"[TMF8801]: Canale {self.channel_num} configurato ed avviato.")
            except Exception as e:
                print(f"[TMF8801 Errore]: Inizializzazione fallita sul canale MUX {self.channel_num}: {e}")

    def read_range(self):
        """Lettura atomica a basso livello protetta da Lock hardware"""
        with i2c_hardware_lock:
            try:
                bus = smbus2.SMBus(self.bus_id)
                bus.write_byte(self.mux_address, 1 << self.channel_num)
                time.sleep(0.003) 
                
                result = bus.read_i2c_block_data(self.address, 0x1D, 8)
                bus.close()
                
                val_contents = result[1]  # Registro 0x1E
                dist_low = result[5]      # Registro 0x22
                dist_high = result[6]     # Registro 0x23
                
                if val_contents == 0x55:
                    distanza = dist_low | (dist_high << 8)
                    if 0 < distanza <= 2500:
                        self._last_valid_distance = distanza
                        return distanza
                            
                return self._last_valid_distance
            except Exception:
                return self._last_valid_distance



CALIBRATION_SAMPLES = 500
CALIBRATION_DELAY = 0.01
Q = np.diag([0.0001, 0.0001, 0.0001, 0.00001, 0.00001, 0.00001])
R = np.diag([0.1, 0.1, 0.1])



@dataclass
class ServoJoint:
    name: str
    channel: int
    angle_riposo: int 
    angle_raccolta: Optional[int] = None
    angle_chiuso: Optional[int] = None
    angle_rilascio: Optional[int] = None
    actuation_range: int = 180
    min_pulse: int = 500
    max_pulse: int = 2500
    handler: Optional[servo.Servo] = None
    pca_tca_channel: int = 6         
    bus_id: int = 1

    def _safe_set_angle(self, angle_value):
        
        if self.handler and angle_value is not None:
            with i2c_hardware_lock:
                try:
                    
                    bus = smbus2.SMBus(self.bus_id)
                    bus.write_byte(0x70, 1 << self.pca_tca_channel)
                    bus.close()
                    time.sleep(0.003)  
                    
                    
                    
                    self.handler.angle = angle_value
                except OSError as e:
                    if e.errno == 121:
                        
                        print(f"[WARN] Glitch I2C intercettato sul servo '{self.name}'. Frame saltato.")
                    else:
                        raise e
                except Exception as e:
                    print(f"[ERROR] Eccezione sul movimento del servo '{self.name}': {e}")

    def riposo(self):
        self._safe_set_angle(self.angle_riposo)

    def raccolta(self):
        self._safe_set_angle(self.angle_raccolta)

    def rilascio(self):
        self._safe_set_angle(self.angle_rilascio)

    def chiusura(self):
        if self.angle_chiuso is not None: 
            self._safe_set_angle(self.angle_chiuso)
            return self.angle_chiuso
            
    def return_pos_raccolta(self):
        if self.angle_raccolta is not None: 
            return self.angle_raccolta

    def set_position(self, position):
        self._safe_set_angle(position)


class RobotSystem:
    def __init__(self, pca_tca_channel: int = 6):
        self.i2c = board.I2C()
        self.tca = adafruit_tca9548a.TCA9548A(self.i2c)
        
        print("Initializing IMU...")
        self.imu = LSM6DS33(self.tca[1])
        
        print("Initializing ToF Sensors (Direct Protocol TMF8801)...")
        self.tof_destra = TMF8801_HardwareLight(self.tca[0], channel_num=0)
        self.tof_lat    = TMF8801_HardwareLight(self.tca[2], channel_num=2)
        self.tof_sotto  = TMF8801_HardwareLight(self.tca[3], channel_num=3)
        self.tof_sopra  = TMF8801_HardwareLight(self.tca[4], channel_num=4)
        self.tof_dietro = TMF8801_HardwareLight(self.tca[5], channel_num=5)

        print(f"Initializing PCA9685...")
        self.pca = PCA9685(self.tca[pca_tca_channel])
        self.pca.frequency = 50
        
        
        self.joints: Dict[str, ServoJoint] = {
            "front_main": ServoJoint("front_main", 15, angle_riposo=5, angle_raccolta=210, angle_rilascio=5, actuation_range=270, pca_tca_channel=pca_tca_channel),
            "front_sx":   ServoJoint("front_sx",   9, angle_riposo=150, angle_raccolta=150, angle_chiuso=93, angle_rilascio=80, pca_tca_channel=pca_tca_channel),
            "front_dx":   ServoJoint("front_dx",   8,  angle_riposo=70,  angle_raccolta=70, angle_chiuso=137, angle_rilascio=146, pca_tca_channel=pca_tca_channel),
            "back_sx":    ServoJoint("back_sx",    13, angle_riposo=45, angle_rilascio=145, pca_tca_channel=pca_tca_channel),
            "back_dx":    ServoJoint("back_dx",    14,  angle_riposo=150, angle_rilascio=45, pca_tca_channel=pca_tca_channel)
        }

        for joint in self.joints.values():
            joint.handler = servo.Servo(self.pca.channels[joint.channel], 
                                      actuation_range=joint.actuation_range,
                                      min_pulse=joint.min_pulse, max_pulse=joint.max_pulse)


        self._roll = 0.0; self._pitch = 0.0; self._yaw = 0.0
        self._data_lock = threading.Lock()
        self._is_running = threading.Event()
        self._x = np.zeros(6); self._P = np.eye(6) * 10.0

        self._gyro_bias, self._offset = self._get_imu_calibration()
        self._initialize_orientation()
        self._is_running.set()
        self._thread = threading.Thread(target=self._update_loop, daemon=True)
        self._thread.start()


    def get_distance_lat(self):    return self.tof_lat.read_range()
    def get_distance_sopra(self):  return self.tof_sopra.read_range()
    def get_distance_sotto(self):  return self.tof_sotto.read_range()
    def get_distance_dietro(self): return self.tof_dietro.read_range()
    def get_distance_destra(self): return self.tof_destra.read_range()

    def get_angles(self):
        with self._data_lock: return (int(self._roll), int(self._pitch), int(self._yaw))

    def cleanup(self):
        self._is_running.clear()
        self.pca.deinit()


    def _get_imu_calibration(self):
        """Carica la calibrazione dal file system o la esegue da zero se non presente"""
        if os.path.exists(IMU_CALIB_FILE):
            print(f"[IMU]: Trovato file di calibrazione memorizzato in {IMU_CALIB_FILE}. Caricamento in corso...")
            try:
                with open(IMU_CALIB_FILE, 'r') as f:
                    data = json.load(f)
                bias = np.array(data["gyro_bias"])
                offset = data["offset"]
                return bias, offset
            except Exception as e:
                print(f"[IMU Errore]: Impossibile leggere il file calibrazione ({e}). Rieseguo taratura...")


        bias, offset = self._calibrate_imu()
        
        
        try:
            with open(IMU_CALIB_FILE, 'w') as f:
                json.dump({"gyro_bias": bias.tolist(), "offset": offset}, f)
            print(f"[IMU]: Calibrazione memorizzata con successo.")
        except Exception as e:
            print(f"[IMU Errore]: Impossibile salvare la calibrazione su file: {e}")
            
        return bias, offset


    def _calibrate_imu(self):
        print("Calibrating IMU...")
        gyro_sum = np.zeros(3)
        for _ in range(CALIBRATION_SAMPLES):
            with i2c_hardware_lock:
                try:
                    
                    bus = smbus2.SMBus(1)
                    bus.write_byte(0x70, 1 << 1)
                    bus.close()
                    time.sleep(0.003)
                    
                    g_data = np.array(self.imu.gyro)
                    a_data = np.array(self.imu.acceleration)
                except Exception:
                    g_data = np.zeros(3)
                    a_data = np.array([0, 0, 9.80665])
                    
            gyro_sum += g_data
            time.sleep(CALIBRATION_DELAY)
            
        bias = gyro_sum / CALIBRATION_SAMPLES
        init_roll = math.atan2(a_data[1], a_data[2])
        init_pitch = math.atan2(-a_data[0], math.sqrt(a_data[1]**2 + a_data[2]**2))
        return bias, {"roll": math.degrees(init_roll), "pitch": math.degrees(init_pitch), "yaw": 0.0}

    def _initialize_orientation(self):
        with i2c_hardware_lock:
            try:
                bus = smbus2.SMBus(1)
                bus.write_byte(0x70, 1 << 1)
                bus.close()
                time.sleep(0.003)
                accel = np.array(self.imu.acceleration)
            except Exception:
                accel = np.array([0, 0, 9.80665])
                
        self._x[0] = math.atan2(accel[1], accel[2])
        self._x[1] = math.atan2(-accel[0], math.sqrt(accel[1]**2 + accel[2]**2))
        self._x[3:6] = self._gyro_bias

    def _update_loop(self):
        last_time = time.monotonic()
        while self._is_running.is_set():
            dt = time.monotonic() - last_time
            last_time = time.monotonic()
            
            with i2c_hardware_lock:
                try:
                    
                    bus = smbus2.SMBus(1)
                    bus.write_byte(0x70, 1 << 1)
                    bus.close()
                    time.sleep(0.003)
                    
                    accel = np.array(self.imu.acceleration)
                    gyro = np.array(self.imu.gyro)
                except Exception:
                    time.sleep(0.005)
                    continue

            F = np.eye(6); F[0:3, 3:6] = -np.eye(3) * dt
            self._x[0:3] += (gyro - self._x[3:6]) * dt
            self._P = F @ self._P @ F.T + Q
            g = 9.80665; accel_exp = np.array([-g * math.sin(self._x[1]), g * math.cos(self._x[1]) * math.sin(self._x[0]), g * math.cos(self._x[1]) * math.cos(self._x[0])])
            H = np.zeros((3, 6)); H[0, 1] = -g * math.cos(self._x[1]); H[1, 0] = g * math.cos(self._x[1]) * math.cos(self._x[0]); H[1, 1] = -g * math.sin(self._x[1]) * math.sin(self._x[0]); H[2, 0] = -g * math.cos(self._x[1]) * math.sin(self._x[0]); H[2, 1] = -g * math.sin(self._x[1]) * math.cos(self._x[0])
            S = H @ self._P @ H.T + R; K = self._P @ H.T @ np.linalg.inv(S); self._x += K @ (accel - accel_exp); self._P = (np.eye(6) - K @ H) @ self._P
            
            with self._data_lock:
                self._roll = math.degrees(self._x[0]) - self._offset['roll']
                self._pitch = math.degrees(self._x[1]) - self._offset['pitch']
                self._yaw = math.degrees(self._x[2])
            time.sleep(0.01)


if __name__ == "__main__":
    robot = RobotSystem()
    try:
        while True:
            roll, pitch, yaw = robot.get_angles()
            print(
                f"\rDX: {robot.get_distance_destra():4d} mm | "
                f"LAT: {robot.get_distance_lat():4d} mm | "
                f"SOTTO: {robot.get_distance_sotto():4d} mm | "
                f"SOPRA: {robot.get_distance_sopra():4d} mm | "
                f"DIETRO: {robot.get_distance_dietro():4d} mm | "
                f"Roll: {roll:3d}° Pitch: {pitch:3d}°",
                end="", flush=True
            )
            print(robot.get_distance_lat())
            time.sleep(0.02)
    except KeyboardInterrupt:
        robot.cleanup()


