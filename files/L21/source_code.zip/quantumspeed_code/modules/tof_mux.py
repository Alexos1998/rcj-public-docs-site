import time
import smbus2
from DFRobot_TMF8x01 import DFRobot_TMF8801

# --- Configurazione Hardware ---
I2C_BUS_NUMBER = 1          # Bus I2C principale del Raspberry Pi 5
MUX_ADDRESS = 0x70          # Indirizzo del multiplexer (0x70)
TMF8801_ADDR = 0x41         # Indirizzo standard del chip TMF8801

# Mappatura canali Multiplexer
SENSORI_CONFIG = {
    "destra": 0,
    "lat": 2,
    "sotto": 3,
    "sopra": 4,
    "dietro": 5
}

def select_mux_channel(bus_id, mux_addr, channel):
    """Sposta il canale sul multiplexer TCA9548A"""
    try:
        temp_bus = smbus2.SMBus(bus_id)
        temp_bus.write_byte(mux_addr, 1 << channel)
        temp_bus.close()
        time.sleep(0.01)  # Ottimizzato a 10ms per la massima reattività
    except Exception as e:
        print(f"Errore switch MUX canale {channel}: {e}")


cali_data = [0x41, 0x57, 0x01, 0xFD, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
sensori_attivi = []

print("=== INIZIO INIZIALIZZAZIONE HARDWARE REAL-TIME ===")

for nome, canale in SENSORI_CONFIG.items():
    print(f"Boot '{nome}' (Canale MUX {canale})...")
    select_mux_channel(I2C_BUS_NUMBER, MUX_ADDRESS, canale)
    
    try:
        
        tof = DFRobot_TMF8801(bus_id=I2C_BUS_NUMBER, enPin=-1, intPin=-1)
        
        tentativi = 0
        while tof.begin() != 0:
            time.sleep(0.1)
            select_mux_channel(I2C_BUS_NUMBER, MUX_ADDRESS, canale)
            tentativi += 1
            if tentativi > 5:
                raise RuntimeError("Il chip non risponde")
                
        try:
            tof.set_calibration_data(cali_data)
        except AttributeError:
            tof.setCalibrationData(cali_data)
            
            
        tof.start_measurement(1)
        sensori_attivi.append(nome)
        print(f"-> Sensore '{nome}': Firmware RAM caricato.")
        
    except Exception as e:
        print(f"-> Impossibile avviare il sensore '{nome}': {e}")

print(f"\nSensori pronti per il loop: {sensori_attivi}")
print("========================================================\n")


print("Telemetria Real-Time Attiva. Premi CTRL+C per fermare.\n")

bus_I2C = smbus2.SMBus(I2C_BUS_NUMBER)


ultime_distanze = {nome: "---" for nome in SENSORI_CONFIG.keys()}

try:
    while True:
        for nome in sensori_attivi:
            canale = SENSORI_CONFIG[nome]
            
            
            try:
                bus_I2C.write_byte(MUX_ADDRESS, 1 << canale)
                time.sleep(0.005) # Delay minimo hardware
            except:
                continue
                
            try:
                
                reg_data = bus_I2C.read_i2c_block_data(TMF8801_ADDR, 0x1D, 8)
                
                val_contents = reg_data[1]
                dist_low = reg_data[5]
                dist_high = reg_data[6]
                
                
                if val_contents == 0x55:
                    distanza = dist_low | (dist_high << 8)
                    if 0 < distanza <= 2500:
                        ultime_distanze[nome] = f"{distanza:4d} mm"
                    else:
                        ultime_distanze[nome] = "  OUT "
            except:
                pass


        stringa_output = (
            f"\r[DX]: {ultime_distanze['destra']} | "
            f"[LAT]: {ultime_distanze['lat']} | "
            f"[SOTTO]: {ultime_distanze['sotto']} | "
            f"[SOPRA]: {ultime_distanze['sopra']} | "
            f"[DIETRO]: {ultime_distanze['dietro']}"
        )
        print(stringa_output, end="", flush=True)
        
        time.sleep(0.02)  # 20ms di pausa ciclo totale (~50Hz di telemetria complessiva)

except KeyboardInterrupt:
    print("\n\nTelemetria interrotta correttamente. Chiusura del bus I2C.")
finally:
    bus_I2C.close()