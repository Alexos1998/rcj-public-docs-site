import time
import smbus2

from DFRobot_TMF8x01 import DFRobot_TMF8801

# --- Configurazione Hardware ---
I2C_BUS_NUMBER = 1          # Bus I2C principale del Raspberry Pi 5
MUX_ADDRESS = 0x70          # Indirizzo del multiplexer (0x70)
MUX_CHANNEL = 2           # Il canale a cui è connesso il ToF SEN0430

def select_mux_channel(bus_id, mux_addr, channel):
    
    try:
        temp_bus = smbus2.SMBus(bus_id)
        temp_bus.write_byte(mux_addr, 1 << channel)
        temp_bus.close()
        time.sleep(0.01) 
    except Exception as e:
        print(f"Errore nello switch del multiplexer: {e}")


print(f"Abilitazione canale {MUX_CHANNEL} sul multiplexer...")
select_mux_channel(I2C_BUS_NUMBER, MUX_ADDRESS, MUX_CHANNEL)


try:
    
    tof = DFRobot_TMF8801(bus_id=I2C_BUS_NUMBER, enPin=-1, intPin=-1)
    
    print("Inizializzazione del sensore TMF8801 in corso...")
    
    while tof.begin() != 0:
        print("Inizializzazione fallita. Riprovo...")
        time.sleep(1)
        select_mux_channel(I2C_BUS_NUMBER, MUX_ADDRESS, MUX_CHANNEL)
        
    print("Sensore TMF8801 rilevato e inizializzato con successo!")
    
    
    cali_data = [0x41, 0x57, 0x01, 0xFD, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    
    try:
        tof.set_calibration_data(cali_data)
    except AttributeError:
        tof.setCalibrationData(cali_data)
    
    
    tof.start_measurement(1)

except Exception as e:
    print(f"Impossibile configurare il sensore: {e}")
    exit()


print("\nInizio lettura della distanza. Premi CTRL+C per fermare.\n")

try:
    while True:
        
        is_ready = False
        try:
            is_ready = tof.is_data_ready()
        except AttributeError:
            try:
                is_ready = tof.isDataReady()
            except AttributeError:
                is_ready = True
                
        if is_ready:
            try:
                distanza = tof.get_distance_mm()
            except AttributeError:
                distanza = tof.getDistanceMm()
            
            if distanza == 0:
                print("Fuori portata o segnale troppo debole.")
            else:
                print(f"Distanza: {distanza} mm ({distanza / 10:.1f} cm)")
                
        time.sleep(0.05) # Campionamento rapido (~20Hz)

except KeyboardInterrupt:
    print("\nProgramma interrotto dall'utente.")