import cv2  # https://docs.opencv.org/4.x/d3/d05/tutorial_py_table_of_contents_contours.html
import numpy as np
from numpy import arctan
from picamera2 import Picamera2
from libcamera import controls
import time
import random
import signal
import sys
import lgpio
from gpiozero import Button
import traceback
import math
from ultralytics import YOLO

try:
    from ai_edge_litert.interpreter import Interpreter
except ImportError:
    from tflite_runtime.interpreter import Interpreter

# from util import get_limits
from modules import *
from sensors import *
from utility import *
from calc import *

from detector import DetectorAI 

# Inizializza il detector (puoi cambiare ID classe e confidenza se vuoi)
detector = DetectorAI(model_path="silver_e150_ncnn_model", target_class_id=0, conf_threshold=0.6)


# Inizializzazione Log
stdout = Output_Files_Writer("_stdout")
stdout.create_file()
stderr = Output_Files_Writer("_stderr")
stderr.create_file()

stdout.write_log("stdout setup complete")
stderr.write_log("stderr setup complete")

# Inizializzazione led - motori - sensori
led_strip = LED_Strip(32, "strip_1")
led_mask = tuple([1] * 32)
led_strip.set_leds(led_mask, (255, 255, 130), 255)


robot = RobotSystem()
nodes = robot.joints 
for _ in range(10):
    ex_roll = robot.get_angles()[0]
    ex_roll2 = robot.get_angles()[0]
    ex_roll3 = robot.get_angles()[0]
    ex_roll4 = robot.get_angles()[0]
    ex_roll5 = robot.get_angles()[0]

motor = DCMotorLGPIO(17, 23, 22, 27)
motor.stop()


# ======================= VARIABILI GLOBALI  =====================
CONTASFERE_TOTALE = {
    "sf_g" : 0,
    "sf_n" : 0
}

CONTACONSEGNE_TOTALE = 0

try:
    valori = []
    with open("contasfere_lack.txt", "r") as file:
                for riga in file:
                    for parola in riga.split():
                            valori.append(parola)
    CONTASFERE_TOTALE["sf_g"] = int(valori[0])
    CONTASFERE_TOTALE["sf_n"] = int(valori[1])
    CONTACONSEGNE_TOTALE = int(valori[2])

    print(CONTASFERE_TOTALE)
    
except:
    print("nessun file trovato")

if CONTACONSEGNE_TOTALE == 2:
    CONTACONSEGNE_TOTALE -=1

TARGET_OBJECT = None
TEMPO_ULTIMA_CHIAMATA_FUNZIONE = 0

MOTOR_PINS = [17, 23, 22, 27]



def clean_shutdown(signum, frame):
    global MOTOR_PINS
    print("Ricevuto segnale di stop. Forzo i motori a ZERO...")
    h = lgpio.gpiochip_open(0)
    for pin in MOTOR_PINS:
        try:
            lgpio.gpio_write(h, pin, 0) # Forza lo zero prima di uscire
        except: pass
    lgpio.gpiochip_close(h)
    sys.exit(0)

# Registra i segnali
signal.signal(signal.SIGTERM, clean_shutdown)
signal.signal(signal.SIGINT, clean_shutdown)

try:
    #FUNZIONI STANZA

    def rest_position() -> None:
        try:
            for key in ["front_main", "front_sx", "front_dx", "back_sx", "back_dx"]:
                nodes[key].riposo()

            print("Servo rest successful")
            stdout.write_log("servo rest successful")
        except Exception as e:
            print(f"Failed to rest servos: {e}")    
            stderr.write_log(f"servo rest unsuccessful: {e}")

        #robot.release_all_servos()
        #robot.cleanup()

    rest_position()


    class ObjectDetector:
        def __init__(self, model_path="best(1).tflite"):
            # --- CONFIGURAZIONE DEFAULT ---
            self.CROP_TOP = 70
            self.default_threshold = 0.6
            self.default_tr_area = 8000
        
            # Range HSV (Calibrati per BGR)
            self.green_lower = np.array([35, 40, 50])
            self.green_upper = np.array([90, 255, 180])                                                                                                                                                                  
            self.red_lower1, self.red_upper1 = np.array([0, 70, 70]), np.array([10, 255, 255])
            self.red_lower2, self.red_upper2 = np.array([170, 70, 70]), np.array([180, 255, 255])


            # --- AI SETUP ---
            self.interpreter = Interpreter(model_path=model_path)
            self.interpreter.allocate_tensors()
            self.input_details = self.interpreter.get_input_details()
            self.output_details = self.interpreter.get_output_details()
            self.in_h = self.input_details[0]['shape'][1]
            self.in_w = self.input_details[0]['shape'][2]


            # --- CAMERA SETUP ---
            self.ez_camera = Picamera2(0)
            self.current_res = (640, 480)
            config = self.ez_camera.create_preview_configuration(main={"size": self.current_res, "format": "XRGB8888"})
            self.ez_camera.configure(config)
            self.ez_camera.start()
        
            self.prev_frame_time = time.time()

        def point_focus(self,coordinates):
            self.ez_camera.set_controls({
                "AfMode": controls.AfModeEnum.Auto,
                "AfRange": controls.AfRangeEnum.Normal,
                "AfSpeed": controls.AfSpeedEnum.Normal,
                "AfMetering": controls.AfMeteringEnum.Windows,
                "AfWindows": [coordinates],
                "AfTrigger": controls.AfTriggerEnum.Start  # Avvia un ciclo di AF
            })

        def set_fixed_focus_distance(self,dist_cm):
            dioptres = 100.0 / dist_cm
            
            self.ez_camera.set_controls({
                "AfMode": controls.AfModeEnum.Manual,
                "LensPosition": dioptres
            })


        def _switch_res(self, res):
            """Cambia la risoluzione fisica della camera se necessario"""
            if self.current_res != res:
                self.ez_camera.stop()
                config = self.ez_camera.create_preview_configuration(main={"size": res, "format": "XRGB8888"})
                self.ez_camera.configure(config)
                self.ez_camera.start()
                self.ez_camera.set_controls({
                    "AfMode": controls.AfModeEnum.Continuous,
                    "Brightness": 0.10,
                    "Contrast": 1.35
                })
                self.current_res = res


        def detect(self, target="all", sf_threshold=None, tr_min_area=None):
            target_res = (1920, 1080) if target == "triangoli" else (640, 480)
            self._switch_res(target_res)


            threshold = sf_threshold if sf_threshold is not None else self.default_threshold
            min_area = tr_min_area if tr_min_area is not None else self.default_tr_area

            frame_raw = self.ez_camera.capture_array()
            frame_raw = cv2.rotate(frame_raw, cv2.ROTATE_180)
        
           
            if self.current_res == (1920, 1080):
                frame_proc = cv2.resize(frame_raw, (960, 540), interpolation=cv2.INTER_NEAREST)
            else:
                frame_proc = frame_raw


            frame_roi = frame_proc[self.CROP_TOP:, :]
            H, W = frame_roi.shape[:2]


            display_frame = cv2.cvtColor(frame_roi, cv2.COLOR_BGRA2BGR)
            frame_rgb = cv2.cvtColor(frame_roi, cv2.COLOR_BGRA2RGB)
        
            new_frame_time = time.time()
            fps = 1 / (new_frame_time - self.prev_frame_time + 1e-6)
            self.prev_frame_time = new_frame_time


            rilevamenti = []


            # --- PARTE AI (sf_g, sf_n) ---
            if target in ["sfere", "all"]:
                input_frame = cv2.resize(frame_rgb, (self.in_w, self.in_h))
                input_data = np.expand_dims(input_frame.astype(np.uint8), axis=0)
                self.interpreter.set_tensor(self.input_details[0]['index'], input_data)
                self.interpreter.invoke()
            
                scores = self.interpreter.get_tensor(self.output_details[0]['index'])[0]
                boxes = self.interpreter.get_tensor(self.output_details[1]['index'])[0]
                classes = self.interpreter.get_tensor(self.output_details[3]['index'])[0]


                for i in range(len(scores)):
                    if scores[i] > threshold:
                        class_id = int(np.rint(classes[i]))
                        if class_id in [0, 1]:
                            name = "sf_g" if class_id == 0 else "sf_n"
                            ymin, xmin, ymax, xmax = boxes[i]
                            l, r, t, b = int(xmin * W), int(xmax * W), int(ymin * H), int(ymax * H)
                            cx, cy = (l + r) // 2, (t + b) // 2
                        
                            rilevamenti.append({
                                "name": name, "center": (cx, cy), "score": scores[i],
                                "x_min": l, "x_max": r, "y_min": t, "y_max": b
                            })
                        
                            cv2.rectangle(display_frame, (l, t), (r, b), (255, 255, 0), 2)
                            cv2.circle(display_frame, (cx, cy), 5, (0, 0, 255), -1)
                            cv2.putText(display_frame, f"{name} {int(scores[i]*100)}% C:({cx},{cy})",
                                        (l, t-10), 0, 0.5, (255, 255, 0), 1)


            # --- PARTE HSV (tr_r, tr_v) ---
            if target in ["triangoli", "all"]:
                hsv = cv2.cvtColor(display_frame, cv2.COLOR_BGR2HSV)
                
                curr_min_area = min_area if self.current_res == (640, 480) else min_area / 4
            
                mask_r = cv2.bitwise_or(cv2.inRange(hsv, self.red_lower1, self.red_upper1),
                                        cv2.inRange(hsv, self.red_lower2, self.red_upper2))
                mask_v = cv2.inRange(hsv, self.green_lower, self.green_upper)


                for mask, color_key, color_bgr in [(mask_r, "tr_r", (0,0,255)), (mask_v, "tr_v", (0,255,0))]:
                    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                    for cnt in contours:
                        area = cv2.contourArea(cnt)
                        if area > curr_min_area:
                            x, y, w, h = cv2.boundingRect(cnt)
                            cx, cy = x + w//2, y + h//2
                            x_max, y_max = x + w, y + h
                        
                            rilevamenti.append({
                                "name": color_key, "center": (cx, cy), "area": area,
                                "x_min": x, "x_max": x_max, "y_min": y, "y_max": y_max
                            })
                        
                            cv2.rectangle(display_frame, (x, y), (x_max, y_max), color_bgr, 2)
                            cv2.circle(display_frame, (cx, cy), 5, (0, 0, 255), -1)
                            cv2.putText(display_frame, f"{color_key} A:{int(area)} C:({cx},{cy})",
                                        (x, y-10), 0, 0.5, color_bgr, 1)


            # FPS Overlay
            cv2.putText(display_frame, f"FPS: {int(fps)} RES: {self.current_res}", (10, 30), 0, 0.7, (0, 255, 255), 2)
        
            return display_frame, rilevamenti


        def stop(self):
            self.ez_camera.stop()
            cv2.destroyAllWindows()




    

    # ======================= FUNZIONI STANZA =====================
    button = Button(16, pull_up=True)  #capire se morsa chiusa
    contatto_sfere = Button(12, pull_up = True) # capre se pallina conduce
    bottone_sx = Button(21, pull_up = True)
    bottone_dx = Button(6, pull_up = True)
    bottone_dx_esterno = Button(5, pull_up = True)
    bottone_sx_esterno = Button(20, pull_up = True)


    def girodx(gradi, fast = 0.6):
        yaw = robot.get_angles()[2]
        yaw2 = yaw
        while yaw - yaw2 < gradi:
            yaw2 = robot.get_angles()[2]
            motor.right(fast)
        motor.stop()


    def girosx(gradi, fast = 0.6):
        yaw = robot.get_angles()[2]
        yaw2 = yaw
        while yaw2 - yaw < gradi:
            yaw2 = robot.get_angles()[2]
            motor.left(fast)
        motor.stop()

    


    def check_sfera(controllo, ai_model):
        global TARGET_OBJECT, CONTASFERE_TOTALE


        print("SONO IN CHECK_SFERA")


        if controllo == "180" or controllo == "sx":
            girosx(80, 0.4)
        else:
            girodx(80, 0.4)
        
        
        

        #led_mask = tuple([1] * 32)
        #led_strip.set_leds(led_mask, (255, 255, 130), 110)


        fasi = {"180" : 180, "sx" : 90, "dx" : 90}
        angolo_iniziale = robot.get_angles()[2]
        print(fasi, controllo)
        print(fasi[controllo])
        while abs(robot.get_angles()[2] - angolo_iniziale) < fasi[controllo]:
            if controllo == "sx" or controllo == "180":
                motor.set_motor_speed_direction(40, "BW", 40, "FW")
            else:
                motor.set_motor_speed_direction(40, "FW", 40, "BW")


            frame, dati = ai_model.detect(target="sfere", sf_threshold=0.45, tr_min_area=100000)
            distances = {}
            
            possible_detections = []

            if CONTASFERE_TOTALE["sf_g"] < 2:
                possible_detections.append("sf_g")
            if CONTASFERE_TOTALE["sf_n"] < 2:
                possible_detections.append("sf_n")


            print("lunghezza",len(dati))
            if len(dati) != 0:
                if len(dati) == 1:
                    if dati[0]['name'] in possible_detections:
                        TARGET_OBJECT = dati[0]['name']
                else:
                    for detections in dati:
                        if detections['name'] in possible_detections:
                            dist = calc_distance(detections['x_max'], detections['x_min'])
                            print("append")
                            distances[detections["name"]] = dist
                    try:
                        TARGET_OBJECT = min(distances, key=distances.get)
                    except:
                        print("continuo ricerca")

                print("PRIMO RICONOSCIMENTO --->>> ", TARGET_OBJECT)
            
                # ======================= VERIFICA POSITIVITA MODELLO AI INGRESSO =====================
                print("VERIFICA POSITIVITA MODELLO AI INGRESSO")
                contatore_positivi = 0
                for i in range(0,13):
                    frame, dati = ai_model.detect(target="sfere", sf_threshold=0.45, tr_min_area=100000)
                    for detections in dati:
                        if detections['name'] == TARGET_OBJECT:
                            contatore_positivi += 1
                if contatore_positivi >= 3:
                    print("TARGET_OBJECT_INGRESSO_VERIFICATO  --->>> ", TARGET_OBJECT)
                    return TARGET_OBJECT
                else:
                    TARGET_OBJECT = None
                    if controllo == "180" or controllo == "sx":
                        girodx(5, 0.7)
                    else:
                        girosx(5, 0.7)


            #cv2.imshow("QuantumSpeed Class", frame)
            #if cv2.waitKey(1) & 0xFF == ord('q'):
            #        break


        return None  



    contatore_ricerche = 0
    sfera_nera_visibile = False
    sfera_grigia_visibile = False
    tempo_ricerca_verde = 0 
    una_sfera_grigia = False
    due_sfere_grigie = False

    def ricerca_oggetto(oggetto_da_ricercare, ai_model):
        global CONTACONSEGNE_TOTALE, CONTASFERE_TOTALE, TARGET_OBJECT, TEMPO_ULTIMA_CHIAMATA_FUNZIONE
        global stdout, stderr
        global contatore_ricerche, sfera_nera_visibile, sfera_grigia_visibile, tempo_ricerca_verde
        global una_sfera_grigia, due_sfere_grigie

        print("SONO IN RICERCA OGGETTO ")

        led_mask = tuple([1] * 32)
        led_strip.set_leds(led_mask, (255, 255, 130), 0)

        contatore_ricerche = 0
        numero_chimata = 0 

        

        if una_sfera_grigia == "Null":
            print(una_sfera_grigia, "cambio per una sfera grigia")
            oggetto_da_ricercare = "TRIANGOLI"
            una_sfera_grigia = False

        if tempo_ricerca_verde != 0 and abs(time.time() - tempo_ricerca_verde) > 10 and sfera_nera_visibile == True:
            print("cambio tuttooooo")
            oggetto_da_ricercare = "TRIANGOLI"
            sfera_nera_visibile = False

        if CONTASFERE_TOTALE["sf_g"] == 1 and sfera_nera_visibile == False and sfera_grigia_visibile == False:
            una_sfera_grigia = True
        elif CONTASFERE_TOTALE["sf_g"] == 2 and CONTACONSEGNE_TOTALE == 0 and sfera_nera_visibile == False and sfera_grigia_visibile == False:
            due_sfere_grigie = True
        else:
            due_sfere_grigie = False
        
        if abs(time.time() - TEMPO_ULTIMA_CHIAMATA_FUNZIONE) > 2:
            print("RESET ANGOLO PER RICERCA")
            angolo_iniziale = robot.get_angles()[2]
        else:
            angolo_iniziale = robot.get_angles()[2]
            girodx(10, 0.7)

        while TARGET_OBJECT == None:
            '''
            if contatore_ricerche >= 2 and numero_chimata == 0:
                print("contatore_ricerche", contatore_ricerche)
                tempo_ricerca_triangoli_sfere = time.time()
                TARGET_OBJECT = ricerca_triangoli_based(oggetto_da_ricercare, ai_model, tempo_ricerca_triangoli_sfere)
                contatore_ricerche = 0
                numero_chimata += 1
            elif numero_chimata > 0:
                CONTASFERE_TOTALE = {
                    "sf_g" : 2,
                    "sf_n" : 1
                }
                return
            '''
            print("CONTATORE RICERCHE: ", contatore_ricerche)
            if contatore_ricerche >= 5 and una_sfera_grigia == True:
                oggetto_da_ricercare = "TRIANGOLI"
                una_sfera_grigia = "Null"
                print("cambio oggetto da ricercare, una_sfera_grigia")

            elif contatore_ricerche >= 13:
                print("contatore_ricerche", contatore_ricerche)
                tempo_ricerca_triangoli_sfere = time.time()
                #TARGET_OBJECT = ricerca_triangoli_based(oggetto_da_ricercare, ai_model, tempo_ricerca_triangoli_sfere)
                contatore_ricerche = 0
                CONTASFERE_TOTALE = {
                    "sf_g" : 2,
                    "sf_n" : 1
                }
                return None
            
            #elif contatore_ricerche >= 2 and una_sfera_grigia == True and oggetto_da_ricercare == "SFERE":
             #   oggetto_da_ricercare = "TRIANGOLI"
            print(due_sfere_grigie)
            if due_sfere_grigie == True:
                oggetto_da_ricercare = "TRIANGOLI"
                print("og", oggetto_da_ricercare)
            
            if oggetto_da_ricercare == "SFERE":
                led_mask = tuple([1] * 32)
                #led_strip.set_leds(led_mask, (255, 255, 130), 110)
                sfere_possibili = []


                if CONTASFERE_TOTALE["sf_g"] < 2:
                    sfere_possibili.append("sf_g")
                if CONTASFERE_TOTALE["sf_n"] < 1:
                    sfere_possibili.append("sf_n")


                


                if abs(robot.get_angles()[2] - angolo_iniziale) < 350:
                
                    motor.set_motor_speed_direction(40, "BW", 40, "FW")


                    frame, dati = ai_model.detect(target="sfere", sf_threshold=0.55, tr_min_area=100000)
                    print("ricerco", sfere_possibili)
                    for detection in dati:
                        print(detection['name'])
                        if detection['name'] in sfere_possibili:
                            motor.stop()
                            TARGET_OBJECT = detection['name']
                            contatore_positivi = 0
                            for i in range(0,10):
                                frame, dati = ai_model.detect(target="sfere", sf_threshold=0.55, tr_min_area=100000)
                                for detections in dati:
                                    if detections['name'] == TARGET_OBJECT:
                                        contatore_positivi += 1


                            if contatore_positivi >= 5:
                                return TARGET_OBJECT
                            elif contatore_positivi >= 3:
                                motor.avanticm(2)
                            else:
                                TARGET_OBJECT = None
                                girodx(10, 0.7)
                
                else:
                    angolo_iniziale = robot.get_angles()[2]
                    contatore_ricerche += 1
                    #girosx(random.randint(0,40), 0.7)
                    girodx(90, 0.7)
                    time.sleep(0.1)
                    motor.avanticm(17)
                    time.sleep(0.1)
                    motor.indietrocm(5)




            if oggetto_da_ricercare == "TRIANGOLI":
                triangoli_possibili = []
                led_mask = tuple([1] * 32)
                led_strip.set_leds(led_mask, (255, 255, 130), 0)
                motor.set_motor_speed_direction(60, "BW", 60, "FW")

                #if una_sfera_grigia == True:
                 #   CONTACONSEGNE_TOTALE -= 1 

                if CONTACONSEGNE_TOTALE == 1:
                    triangoli_possibili.append("tr_r")
                elif due_sfere_grigie == True or CONTACONSEGNE_TOTALE == 0 or una_sfera_grigia == True:
                    triangoli_possibili.append("tr_v")
                    
                


                if abs(robot.get_angles()[2] - angolo_iniziale) < 400:
                    print("sono in ricerca triangoli")
                    motor.set_motor_speed_direction(60, "BW", 60, "FW")
                
                    
                    frame, dati = ai_model.detect(target="triangoli", sf_threshold=0.65, tr_min_area=10000)
                    print("ricerco triangoli", triangoli_possibili)
                    for detection in dati:
                        print(detection['name'])
                        if detection['name'] in triangoli_possibili:
                            motor.stop()
                            contatore_positivi = 0
                            if detection["y_max"] > 120:
                                TARGET_OBJECT = detection['name']
                                
                                for i in range(0,10):
                                    frame, dati = ai_model.detect(target="triangoli", sf_threshold=0.65, tr_min_area=10000)
                                    for detections in dati:
                                        if detections['name'] == TARGET_OBJECT:
                                            contatore_positivi += 1
                            elif detection["y_max"] > 100:
                                motor.avanticm(5)
                                motor.stop()


                            if contatore_positivi >= 5:
                                if detection["area"] > 95000:
                                    motor.indietrocm(13)
                                elif detection["x_min"] < 470 and detection["area"] > 800000:
                                    girosx(30, 0.7)
                                    motor.indietrocm(13)
                                elif detection["x_max"] > 550 and detection["area"] > 800000:
                                    girodx(30, 0.7)
                                    motor.indietrocm(13)

                                
                                if CONTASFERE_TOTALE["sf_n"] == 0:
                                    print("controllo positivita sfera nera")
                                    if detection["x_min"] < 470 :
                                        girosx(15, 0.7)
                                        
                                    elif detection["x_max"] > 550 :
                                        girodx(15, 0.7)
                                        motor.indietrocm(13)
                                        
                                    contatore_positivi = 0
                                    for i in range(0,13):
                                        frame, dati = ai_model.detect(target="sfere", sf_threshold=0.45, tr_min_area=100000)
                                        for detections in dati:
                                            if detections['name'] == "sf_n":
                                                contatore_positivi += 1
                                    if contatore_positivi >= 4:
                                        sfera_nera_visibile = True
                                        tempo_ricerca_verde = time.time()

                                        return None

                                if CONTASFERE_TOTALE["sf_g"] == 1 and una_sfera_grigia == True:
                                    print("controlllo positivita sfera nera")
                                    if detection["x_min"] < 470 :
                                        girosx(15, 0.7)
                                        
                                    elif detection["x_max"] > 550 :
                                        girodx(15, 0.7)
                                        motor.indietrocm(13)

                                    contatore_positivi = 0
                                    for i in range(0,13):
                                        frame, dati = ai_model.detect(target="sfere", sf_threshold=0.45, tr_min_area=100000)
                                        for detections in dati:
                                            if detections['name'] == "sf_g":
                                                contatore_positivi += 1
                                    if contatore_positivi >= 4:
                                        sfera_grigia_visibile = True

                                        return None
                                        
                                    else:
                                        return TARGET_OBJECT
                                else: return TARGET_OBJECT
                            elif contatore_positivi >= 3:
                                motor.avanticm(2)
                            else:
                                TARGET_OBJECT = None
                                girodx(10, 0.7)
                else:
                    angolo_iniziale = robot.get_angles()[2]
                    #contatore_ricerche += 1
                    #girosx(random.randint(0,40), 0.7)
                    girodx(90, 0.7)
                    time.sleep(0.1)
                    motor.avanticm(17)
                    time.sleep(0.1)
                    motor.indietrocm(5)

    def separa_sfere():
        global nodes, CONTASFERE_TOTALE, TARGET_OBJECT
        print("separa_sfere")
        motor.indietrocm(6)

        

        nodes["front_main"].raccolta()
        time.sleep(0.2)
        nodes["front_sx"]. set_position(nodes["front_sx"].chiusura())
        nodes["front_dx"]. set_position(nodes["front_dx"].chiusura())

        time.sleep(0.5)

        motor.avanticm(13)
        girodx(20, 0.7)

        time.sleep(0.3)
        nodes["front_dx"].riposo()
        nodes["front_sx"].riposo()
        time.sleep(0.5)

        for i in range(1,3):
            girosx((40 + i*9), 0.7)
            girodx((40 + i*9), 0.7)

        girosx(50, 0.7)
        motor.indietrocm(15)

        
        nodes["front_dx"].riposo()
        nodes["front_sx"].riposo()
        nodes["front_main"].rilascio()


    #button_argento_dx = Button(6, pull_up = True)
    #button_argento_sx = Button(5, pull_up = True)


    contatore_raccolte_errate = 0
    conta_palline_fake = 0 
    def pick_up(sphere_type: str) -> None:
            global nodes, CONTASFERE_TOTALE, TARGET_OBJECT, contatore_raccolte_errate
            global contatore_ricerche, conta_palline_fake
            print("SONO IN PICK UP")
            ### posizionamento raccolta ###

            

            motor.indietrocm(3)
            nodes["front_main"].set_position(180)
            nodes["front_sx"].raccolta()
            nodes["front_dx"].raccolta()

            time.sleep(0.7)

            #motor.avanticm(10)
            motor.stop()
            time.sleep(0.5)
            motor.avanticm_lento(15)

            nodes["front_main"].raccolta()

            for i in range(15):
                robot.get_distance_sopra()

            dist = robot.get_distance_sopra()
            if dist < 60 and dist!=0:
                motor.indietrocm(1)
            motor.indietrocm(0.1)


            
            pos_attuale_sx = nodes["front_sx"].return_pos_raccolta()
            target_sx = nodes["front_sx"].chiusura()
            passo_sx = -1 if target_sx < pos_attuale_sx else 1
            distanza_sx = abs(target_sx - pos_attuale_sx)

            
            pos_attuale_dx = nodes["front_dx"].return_pos_raccolta()
            target_dx = nodes["front_dx"].chiusura()
            passo_dx = -1 if target_dx < pos_attuale_dx else 1
            distanza_dx = abs(target_dx - pos_attuale_dx)

            
            passi_totali = max(distanza_sx, distanza_dx)

            ultimo_controllo_motor = 0  

            
            for passo in range(passi_totali):
                
                
                if pos_attuale_sx != target_sx:
                    nodes["front_sx"].set_position(pos_attuale_sx)
                    pos_attuale_sx += passo_sx

                
                if pos_attuale_dx != target_dx:
                    nodes["front_dx"].set_position(pos_attuale_dx)
                    pos_attuale_dx += passo_dx

                
                if passo - ultimo_controllo_motor >= 10:
                    motor.indietrocm(0.1)
                    motor.stop()
                    ultimo_controllo_motor = passo

                time.sleep(0.0001)
                motor.avanticm_lento(0.1) 
            


            time.sleep(1)

            time.sleep(0.6)
            motor.indietrocm(3)

            print("verifica chiusura")
            time.sleep(1)
            stato_bottone = False
            print(nodes["front_sx"].chiusura(), (nodes["front_sx"].chiusura() - 25))
            print(nodes["front_dx"].chiusura(), (nodes["front_dx"].chiusura() + 35))
            
            for i in range(nodes["front_sx"].chiusura() , nodes["front_sx"].chiusura() - 15, -1):
                print("stato bottone",button.is_pressed, i )
                if button.is_pressed == False:
                    print("cambio posizione")
                    nodes["front_sx"].set_position(i)
                    time.sleep(0.001)
                    
                else: 
                    stato_bottone = True
                    led_mask = tuple([1] * 32)
                    led_strip.set_leds(led_mask, (255, 255, 130), 110)
                    time.sleep(0.01)
                    led_mask = tuple([1] * 32)
                    led_strip.set_leds(led_mask, (255, 255, 130), 0)
                    break
                
            for i in range(nodes["front_dx"].chiusura(), (nodes["front_dx"].chiusura() + 20)):
                if button.is_pressed == False:
                    nodes["front_dx"].set_position(i)
                    time.sleep(0.001)
                
                else: 
                    stato_bottone = True
                    led_mask = tuple([1] * 32)
                    led_strip.set_leds(led_mask, (255, 255, 130), 110)
                    time.sleep(0.01)
                    led_mask = tuple([1] * 32)
                    led_strip.set_leds(led_mask, (255, 255, 130), 0)
                    break

            if stato_bottone == False:
                nodes["front_dx"].riposo()
                nodes["front_sx"].riposo()
                time.sleep(0.5)

            nodes["front_main"].rilascio()

            time.sleep(1.1)

            
            if sphere_type == "sf_g":
                
                if stato_bottone:    
                    CONTASFERE_TOTALE["sf_g"] += 1
                    contatore_raccolte_errate = 0
                    contatore_ricerche = 0
                    print("contasfere modificato")
                
                else:
                    contatore_raccolte_errate += 1
                    print("raccolta_fallita")

                
                nodes["front_dx"].riposo()
                nodes["front_sx"].rilascio()

                time.sleep(0.5)
                nodes["front_sx"].riposo()
                time.sleep(0.5)
                nodes["front_sx"].rilascio()
                time.sleep(0.2)
                
                


            elif sphere_type == "sf_n":
                if stato_bottone:
                    CONTASFERE_TOTALE["sf_n"] += 1
                    contatore_raccolte_errate = 0
                    contatore_ricerche = 0
                    print("contasfere modificato")
                else:
                    contatore_raccolte_errate += 1
                    print("raccolta_fallita")
                nodes["front_dx"].rilascio()
                nodes["front_sx"].riposo()

                time.sleep(0.5)
                nodes["front_dx"].riposo()
                time.sleep(0.5)
                nodes["front_dx"].rilascio()
                time.sleep(0.2)
                
                
        
            time.sleep(1)
            nodes["front_dx"].riposo()
            nodes["front_sx"].riposo()

            if contatore_raccolte_errate > 3:
                girodx(70, 0.7)
                motor.indietrocm(10)
                contatore_raccolte_errate = 0

            motor.avanticm(2)
            motor.stop()

            TARGET_OBJECT = None

    

    
    def check_contatti(n_contatti_sx, n_contatti_dx):
        if bottone_dx.is_pressed:
            motor.indietrocm(2)
            motor.girodx(15)
            motor.indietrocm(4)
            motor.girosx(15)

        if bottone_sx.is_pressed:
            motor.indietrocm(2)
            motor.girosx(15)
            motor.indietrocm(4)
            motor.girodx(15)

        if n_contatti_sx > 10:
            n_contatti_sx = 0
            motor.indietrocm(5)
            motor.girosx(90)
            motor.avanticm(15)
            motor.girodx(90)

        if n_contatti_dx > 10:
            n_contatti_sx = 0
            motor.indietrocm(5)
            motor.girodx(90)
            motor.avanticm(15)
            motor.girosx(90)
        


    def ricerca_sfere(ai_model):        
        global CONTACONSEGNE_TOTALE, CONTASFERE_TOTALE, TARGET_OBJECT, TEMPO_ULTIMA_CHIAMATA_FUNZIONE
        global stdout, stderr

        led_mask = tuple([1] * 32)
        led_strip.set_leds(led_mask, (255, 255, 130), 0)

        print("SONO IN RICERCA SFERE")


        last_detection = time.time()
        last_avanti = time.time()

        conta_avanti = 0
        status = "entered"

        n_contatti_sx = 0 
        n_contatti_dx = 0

        while abs(time.time() - last_detection) < 1:
            print("loop ricerca sfere")
            frame, dati = ai_model.detect(target="sfere", sf_threshold=0.55, tr_min_area=100000)

            print(abs(time.time() - last_detection))
            print(dati)
            print(status)   

            if dati != []:
                last_detection = time.time()
                


            for detection in dati:
                if len(detection) > 1 and status == "entered":
                    status = "locked"
                    position = detection['center'][0]
                    reference = position 

                if detection['name'] == TARGET_OBJECT and (abs(detection['center'][0] - reference) < 100 or len(detection) == 1):
                    position = detection['center'][0]
                    reference = position 

                    print("X_POSITION TARGET OBJECT --->>>  ", position)

                    coordinates = [dati[0]["x_min"], dati[0]["y_min"], (dati[0]["x_max"] - dati[0]["x_min"]), (dati[0]["y_max"] - dati[0]["y_min"]) ]
                    ai_model.point_focus(coordinates)

                    dist = calc_distance(detection['x_max'], detection['x_min'])

                    if abs(time.time() - last_avanti) > 2:
                        motor.stop()
                        time.sleep(1)
                        motor.avanticm(2)
                        girodx(10, 0.8)
                        last_detection = time.time()
                        last_avanti = time.time()

                    if len(dati) > 1:
                        if calc_distance(dati[0]["y_max"],dati[0]["y_min"] ) < 34:
                            centre_1 = ((dati[0]["x_max"] + dati[0]["x_min"])//2, (dati[0]["y_max"] + dati[0]["y_min"])//2)
                            centre_2 = ((dati[1]["x_max"] + dati[1]["x_min"])//2, (dati[1]["y_max"] + dati[1]["y_min"])//2)
                            centre_distance = ((centre_2[0] - centre_1[0])**2 + (centre_2[1] - centre_1[1])**2)**0.5
                            print("CENTER DISTANCE --->>> ", centre_distance)
                            cv2.line(frame, centre_1, centre_2, (0,255,0), 1, cv2.LINE_AA)

                            area_1 = (dati[0]["x_max"] - dati[0]["x_min"]) * (dati[0]["y_max"] - dati[0]["y_min"])
                            area_2 = (dati[1]["x_max"] - dati[1]["x_min"]) * (dati[1]["y_max"] - dati[1]["y_min"])
                            
                            diff = abs(area_2 - area_1)
                            print("differenza ---->>>",  diff)
                            if diff < 32000:
                                if centre_distance < 420:
                                    separa_sfere()
                                    TARGET_OBJECT = None
                                    return
                        
                            
                            
                    elif dist < 22:
                        print("distanza da raccolta")
                        motor.stop()
                        pick_up(TARGET_OBJECT)
                        return


                    range_min = 265
                    range_max = 365

                    check_contatti(n_contatti_sx, n_contatti_dx)
                    if (position >= range_min and position <= range_max):
                            motor.avanti(0.8)
                            conta_avanti += 1 
                            if conta_avanti > 10:
                                last_avanti = time.time()
                    elif(position < range_min):
                            motor.set_motor_speed_direction(30, "FW", 30, "BW")
                            conta_avanti = 0 
                    elif(position > range_max):
                            motor.set_motor_speed_direction(30, "BW", 30, "FW")
                            conta_avanti = 0 

            
        motor.indietrocm(8)
        return None            
    

    
    def deliver(sphere_type: str) -> None:
        global CONTACONSEGNE_TOTALE, TARGET_OBJECT, contatore_raccolte_errate


        print("SONO IN DELIVER")

        

        girodx(160, 0.7)


        motor.indietrocm(24)

        
        led_mask = tuple([1] * 32)
        led_strip.set_leds(led_mask, (255, 255, 130), 0)


        target_node = "back_dx" if sphere_type == "tr_v" else "back_sx"
    
        nodes[target_node].rilascio()


        time.sleep(1)
    
    
        for _ in range(8):
            motor.avanticm(1.5)
            motor.indietrocm(3)

        time.sleep(0.7)

        if TARGET_OBJECT == "tr_v":
            with open("contasfere_lack.txt", "w") as file:
                    file.write(f"{str(CONTASFERE_TOTALE["sf_g"])} 0 {CONTACONSEGNE_TOTALE}")
        else:
            with open("contasfere_lack.txt", "w") as file:
                file.write(f"{str(CONTASFERE_TOTALE["sf_g"])} {str(CONTASFERE_TOTALE["sf_n"])} {CONTACONSEGNE_TOTALE}")
        
        
        if CONTASFERE_TOTALE["sf_g"] == 2: CONTACONSEGNE_TOTALE += 1 
        


        time.sleep(1)
        nodes[target_node].riposo()


        if CONTACONSEGNE_TOTALE == 1:
            time.sleep(0.5)
            motor.avanticm(20)
    
        TARGET_OBJECT = None
    
    
    def ricerca_triangoli(ai_model):
        global CONTACONSEGNE_TOTALE, CONTASFERE_TOTALE, TARGET_OBJECT, TEMPO_ULTIMA_CHIAMATA_FUNZIONE
        global stdout, stderr, una_sfera_grigia

        led_mask = tuple([1] * 32)
        led_strip.set_leds(led_mask, (255, 255, 130), 0)


        print("SONO IN RICERCA TRIANGOLI")


        last_detection = time.time()
        last_avanti = time.time()
        conta_avanti = 0 


        while abs(time.time() - last_detection) < 1:
            print("avvicinamento triangolo")

            frame, dati = ai_model.detect(target="triangoli", sf_threshold=0.65, tr_min_area=10000)


            if dati != []:
                last_detection = time.time()


            for detection in dati:
                if detection['name'] == TARGET_OBJECT and detection["y_max"]>110:
                    position = detection['center'][0]
                    print("X_POSITION TARGET OBJECT --->>>  ", position)

                    coordinates = [dati[0]["x_min"], dati[0]["y_min"], (dati[0]["x_max"] - dati[0]["x_min"]), (dati[0]["y_max"] - dati[0]["y_min"]) ]
                    ai_model.point_focus(coordinates)


                    dist = calc_distance(detection["y_max"],detection["y_min"])
                    print("distanza triangolo --->>> ", dist)

                    print("diff" ,abs(time.time() - last_avanti))
                    if abs(time.time() - last_avanti) > 2.5:
                        motor.stop()
                        time.sleep(1)
                        motor.avanticm(5)
                        girodx(10, 0.8)
                        last_detection = time.time()
                        last_avanti = time.time()


                    if dist < 27.5:
                        motor.stop()
                        deliver(TARGET_OBJECT)
                        una_sfera_grigia = "finito"
                        return


                    range_min = 405
                    range_max = 555

                    print("contaavnti", conta_avanti)
                    if (position >= range_min and position <= range_max):
                            motor.avanti(0.8)
                            print("aggiorno last avanti")
                            conta_avanti += 1
                            if conta_avanti > 10:
                                last_avanti = time.time()
                                conta_avanti = 0 
                    elif(position < range_min):
                            motor.set_motor_speed_direction(35, "FW", 35, "BW")
                            conta_avanti = 0 
                    elif(position > range_max):
                            motor.set_motor_speed_direction(35, "BW", 35, "FW")
                            conta_avanti = 0 


        return None 


    def ricerca_triangoli_based(oggetto_da_ricercare, ai_model, tempo_ricerca_triangoli_sfere):
        global CONTACONSEGNE_TOTALE, CONTASFERE_TOTALE, TARGET_OBJECT, TEMPO_ULTIMA_CHIAMATA_FUNZIONE
        global stdout, stderr
        global contatore_ricerche

        angolo_iniziale = robot.get_angles()[2]

        while TARGET_OBJECT == None and time.time() - tempo_ricerca_triangoli_sfere < 20:
            
            if True:
                triangoli_possibili = []
                led_mask = tuple([1] * 32)
                led_strip.set_leds(led_mask, (255, 255, 130), 0)


                
                triangoli_possibili.append("tr_r")
                triangoli_possibili.append("tr_v")




                if abs(robot.get_angles()[2] - angolo_iniziale) < 400:
                
                    motor.set_motor_speed_direction(60, "BW", 60, "FW")


                    frame, dati = ai_model.detect(target="triangoli", sf_threshold=0.65, tr_min_area=10000)
                    print("ricerco", triangoli_possibili)
                    for detection in dati:
                        print(detection['name'])
                        if detection['name'] in triangoli_possibili:
                            motor.stop()
                            TARGET_OBJECT = detection['name']
                            contatore_positivi = 0
                            for i in range(0,10):
                                frame, dati = ai_model.detect(target="triangoli", sf_threshold=0.65, tr_min_area=10000)
                                for detections in dati:
                                    if detections['name'] == TARGET_OBJECT:
                                        contatore_positivi += 1


                            if contatore_positivi >= 5:
                                if detection["area"] > 95000:
                                    motor.indietrocm(13)
                                elif detection["x_min"] < 470 and area > 800000:
                                    girosx(30, 0.7)
                                    motor.indietrocm(13)
                                elif detection["x_max"] > 550 and area > 800000:
                                    girodx(30, 0.7)
                                    motor.indietrocm(13)

                                
                            elif contatore_positivi >= 3:
                                motor.avanticm(2)
                            else:
                                TARGET_OBJECT = None
                                girodx(10, 0.7)
                else:
                    angolo_iniziale = robot.get_angles()[2]
                    girodx(90, 0.7)
                    time.sleep(0.1)
                    motor.avanticm(17)
                    time.sleep(0.1)
                    motor.indietrocm(5)

        last_detection = time.time()
        if TARGET_OBJECT != None:
            while abs(time.time() - last_detection) < 1:
                    frame, dati = ai_model.detect(target="triangoli", sf_threshold=0.65, tr_min_area=10000)


                    if dati != []:
                        last_detection = time.time()


                    for detection in dati:
                        if detection['name'] == TARGET_OBJECT:
                            position = detection['center'][0]
                            print("X_POSITION TARGET OBJECT --->>>  ", position)

                            coordinates = [dati[0]["x_min"], dati[0]["y_min"], (dati[0]["x_max"] - dati[0]["x_min"]), (dati[0]["y_max"] - dati[0]["y_min"]) ]
                            ai_model.point_focus(coordinates)


                            dist = calc_distance(detection["y_max"],detection["y_min"])
                            print("distanza triangolo --->>> ", dist)


                            if dist < 26:
                                motor.indietrocm(15)
                                motor.stop()
                                return


                            range_min = 420
                            range_max = 540


                            if (position >= range_min and position <= range_max):
                                    motor.avanti(0.8)
                            elif(position < range_min):
                                    motor.set_motor_speed_direction(35, "FW", 35, "BW")
                            elif(position > range_max):
                                    motor.set_motor_speed_direction(35, "BW", 35, "FW")

        TARGET_OBJECT = None  
            







    def main_stanza():
        global CONTACONSEGNE_TOTALE, CONTASFERE_TOTALE, TARGET_OBJECT, TEMPO_ULTIMA_CHIAMATA_FUNZIONE
        global stdout, stderr

        if CONTASFERE_TOTALE["sf_g"] == 2:
            CONTACONSEGNE_TOTALE = 1


        print("SONO IN MAIN STANZA")


        print("<<<<<<< INIZIO CODICE STANZA >>>>>>>")


        ai_model = ObjectDetector()


        led_mask = tuple([1] * 32)
        led_strip.set_leds(led_mask, (255, 255, 130), 0)


        # ======================= RICONOSCIMENTO POSIZIONE INGRESSO  =====================


        motor.avanticm(25)
        time.sleep(0.01)
        motor.indietrocm(10)
        time.sleep(0.01)
        dist_dx = robot.get_distance_destra()
        time.sleep(0.01)
        dist_sx = robot.get_distance_lat()

        controllo = "180"

        


        if (CONTASFERE_TOTALE["sf_g"] + CONTASFERE_TOTALE["sf_n"]) >= 3:
            if controllo == "180" or controllo == "sx":
                girosx(45, 0.7)
                time.sleep(0.1)
                motor.avanticm(10)
                time.sleep(0.1)
            else:
                girodx(45, 0.7)
                time.sleep(0.1)
                motor.avanticm(10)
                time.sleep(0.1)
            
        else:
            TARGET_OBJECT = check_sfera(controllo, ai_model)
            


        if TARGET_OBJECT == None:
            if controllo == "180" or controllo == "sx":
                girosx(45, 0.7)
                time.sleep(0.1)
                motor.avanticm(10)
                time.sleep(0.1)
            else:
                girodx(45, 0.7)
                time.sleep(0.1)
                motor.avanticm(10)
                time.sleep(0.1)

    
        while True :
            print("SONO IN MAIN STANZA (CICLO WHILE)", TARGET_OBJECT)
            if TARGET_OBJECT != None and (TARGET_OBJECT == "sf_g" or TARGET_OBJECT == "sf_n"):
                TARGET_OBJECT = ricerca_sfere(ai_model)
            elif TARGET_OBJECT != None and (TARGET_OBJECT == "tr_v" or TARGET_OBJECT == "tr_r"):
                TARGET_OBJECT = ricerca_triangoli(ai_model)
            elif (CONTASFERE_TOTALE["sf_g"] + CONTASFERE_TOTALE["sf_n"]) < 3:
                TARGET_OBJECT = ricerca_oggetto("SFERE", ai_model)
                TEMPO_ULTIMA_CHIAMATA_FUNZIONE = time.time()
            elif CONTACONSEGNE_TOTALE <2:
                TARGET_OBJECT = ricerca_oggetto("TRIANGOLI", ai_model)
                TEMPO_ULTIMA_CHIAMATA_FUNZIONE = time.time()
            else:
                Uscita_stanza()
                return

    ##### FINE FUNZIONI STANZA ######

    KP = 0.25  #23          #0.23 #0.26 base   1#0.4 secco, ma nelle curve male 3# 0.35              #0.2 FINO ALLA FINE, ma un po' secco #0.24
    KI = 0.00001            #0.00001
    KD = 0.25  #18          #0.23 #0.17 base  2#0.25 mwglio nelle curve, ma troppo zigzag            #0.25
    KY = 0.00015 #(1/100)   #0.00006

    # 4608x2592
    base = 960
    high = 540
    pBlack = 0.75
    picam2 = Picamera2(1)
    picam2.configure(
        picam2.create_preview_configuration(
            main={"size": (base*2, high*2), "format": "RGB888"},
            lores={"size": (base, high), "format": "RGB888"}
        )
    )  
    picam2.start()
    picam2.set_controls(
        {
            "AfMode": controls.AfModeEnum.Continuous,
            "AfRange": controls.AfRangeEnum.Full,
        }
    )


    def girosolodx(gradi, fast = 60):
        yaw = robot.get_angles()[2]
        yaw2 = yaw
        while yaw - yaw2 < gradi:
            yaw2 = robot.get_angles()[2]
            motor.only_right(fast)
        motor.stop()  

    def girosolodx_verde(gradi, fast1 = 60, fast2 = 60):
        yaw = robot.get_angles()[2]
        yaw2 = yaw
        while yaw - yaw2 < gradi:
            yaw2 = robot.get_angles()[2]
            motor.only_right_green(fast1, fast2)
        motor.stop()  

    def girosolosx(gradi, fast = 60):
        yaw = robot.get_angles()[2]
        yaw2 = yaw
        while yaw2 - yaw < gradi:
            yaw2 = robot.get_angles()[2]
            motor.only_left(fast)
            time.sleep(0.1)
        motor.stop() 

    def girosolosxostacolo(gradi, fast = 60):
        yaw = robot.get_angles()[2]
        yaw2 = yaw
        while yaw2 - yaw < gradi:
            yaw2 = robot.get_angles()[2]
            motor.only_left_obstacle(fast)
            time.sleep(0.1)
        motor.stop() 

    def girosolosx_verde(gradi, fast1 = 60, fast2 = 60):
        yaw = robot.get_angles()[2]
        yaw2 = yaw
        while yaw2 - yaw < gradi:
            yaw2 = robot.get_angles()[2]
            motor.only_left_green(fast1, fast2)
            time.sleep(0.1)
        motor.stop() 

    def draw_contourn(bordo, colore):
        global frame
        cv2.drawContours(
            image=frame,
            contours=bordo,
            contourIdx=-1,
            color=colore,
            thickness=2,
            lineType=cv2.LINE_AA,
        )


    k1 = np.ones((12, 12), np.uint8)
    k2 = np.ones((25, 25), np.uint8)
    k3 = np.ones((5, 5), np.uint8)
    k4 = np.ones((5, 5), np.uint8)


    def findContourn(color, asseY, asseX):
        global frame, k1, k2

        silver_L = np.array([0, 0, 240])
        silver_U = np.array([180 , 5, 255])

        grayL = np.array([3, 40, 40])
        grayU = np.array([30, 200, 140])

        blackL = np.array([0, 0, 0])
        blackU = np.array([180, 255, 100]) #s:255

        blackLs = np.array([0, 0, 0])
        blackUs = np.array([180, 255, 100]) #s:255

        greenL = np.array([35, 40, 70])
        greenU = np.array([90, 255, 255])

        redL1 = np.array([170, 130, 100])
        redU1 = np.array([180, 255, 255])

        redL2 = np.array([0, 130, 100])
        redU2 = np.array([15, 255, 255])

        hsvImage = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        if len(asseY) == 1 and asseY[0] == 0:
            if not (len(asseX) == 1 and asseX == 0):
                if len(asseX) == 1:
                    hsvImage = hsvImage[:, asseX[0] :]
                else:
                    hsvImage = hsvImage[:, asseX[0]: asseX[1]]
        else:
            if len(asseX) == 1 and asseX == 0:
                if len(asseY) == 1:
                    hsvImage = hsvImage[asseY[0] :]
                else:
                    hsvImage = hsvImage[asseY[0] : asseY[1]]
            else:
                if len(asseX) == 1:
                    if len(asseY) == 1:
                        hsvImage = hsvImage[asseY[0] :, asseX[0] :]
                    else:
                        hsvImage = hsvImage[asseY[0] : asseY[1], asseX[0] :]
                else:
                    if len(asseY) == 1:
                        hsvImage = hsvImage[asseY[0] :, asseX[0] : asseX[1]]
                    else:
                        hsvImage = hsvImage[asseY[0] : asseY[1], asseX[0] : asseX[1]]

        if color == "black":
            mask = cv2.inRange(hsvImage, blackL, blackU)
            mask = cv2.erode(mask, k1, 1)
            mask = cv2.dilate(mask, k2, 1)

        elif color == "blacks":
            mask = cv2.inRange(hsvImage, blackL, blackU)

        elif color == "green":
            mask = cv2.inRange(hsvImage, greenL, greenU)

        elif color == "red":
            mask1 = cv2.inRange(hsvImage, redL1, redU1) 
            mask2 = cv2.inRange(hsvImage, redL2, redU2)

            mask = cv2.bitwise_or(mask1, mask2)

        elif color == "silver":
            mask = cv2.inRange(hsvImage, silver_L, silver_U)

        elif color == "gray":
            mask = cv2.inRange(hsvImage, grayL, grayU)
            mask = cv2.erode(mask, k3, 1)
            mask = cv2.dilate(mask, k4, 1)

        else:
            print("color missing")
            return
        
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

        contours, _ = cv2.findContours(
            image = mask, mode = cv2.RETR_TREE, method = cv2.CHAIN_APPROX_NONE
        )

        if color == "black":
            if contours:
                largest_contour = max(contours, key=cv2.contourArea)
                largest_mask = np.zeros_like(mask)
                cv2.drawContours(largest_mask, [largest_contour], -1, 255, thickness=cv2.FILLED)
            else:
                largest_mask = np.zeros_like(mask)
        
            contours, _ = cv2.findContours(
                image = largest_mask, mode = cv2.RETR_TREE, method = cv2.CHAIN_APPROX_NONE
            )

        return contours


    def findCenter(bordo):
        M = cv2.moments(bordo)
        if M["m00"] != 0:
            cx = int(M["m10"] / M["m00"])
            cy = int(M["m01"] / M["m00"])
            return cx, cy
        return None, None


    centroX = int(base / 2)
    ip = 0
    lastErrorp = 0


    def PID(cxb, centroX, cyb):
        global ip
        global lastErrorp
        baseSpeed = 100
        position = cxb

        error = (centroX - position)*2
        p = error
        ip = ip + error
        d = error - lastErrorp
        y = max(0, cyb - high * pBlack * 0.55) * 2
                    
        
        lastErrorp = error
        #print('yyyyyyyyyyyyyyyyyyyyyyy:', y)
        if y < 75: #75
            motorSpeed = int(p * KP + ip * KI + d * KD) * ((y**2.362) * KY + 1)#2.11 2.23 2.31 2.34 
        else:
            motorSpeed = int(p * KP + ip * KI + d * KD) * ((y**2.38) * KY + 1)#2.11 2.23 2.31 2.34 # 2.38
        
        roll, pitch, yaw = robot.get_angles()

        motorSpeedsx = int(baseSpeed + motorSpeed)
        motorSpeeddx = int(baseSpeed - motorSpeed)
        
        if pitch < -6:
            if roll < -5:
                motorSpeedsx = int(0.5*motorSpeedsx)
                motorSpeeddx = int(1.4*motorSpeeddx)
            elif roll > 5:
                motorSpeedsx = int(1.4*motorSpeedsx)
                motorSpeeddx = int(0.5*motorSpeeddx)

        elif pitch > 6:
            if roll > 5:
                motorSpeedsx = int(0.5*motorSpeedsx)
                motorSpeeddx = int(1.4*motorSpeeddx)
            elif roll < -5:
                motorSpeedsx = int(1.4*motorSpeedsx)
                motorSpeeddx = int(0.5*motorSpeeddx)
    

        #print(motorSpeedsx, motorSpeeddx)

        if motorSpeedsx >= 0:
            pwrSX = "FW"
        else:
            pwrSX = "BW"
            motorSpeedsx = -motorSpeedsx

        if motorSpeeddx >= 0:
            pwrDX = "FW"
        else:
            pwrDX = "BW"
            motorSpeeddx = -motorSpeeddx
        
        motor.set_motor_speed_direction(
            left_speed=motorSpeedsx,
            left_dir=pwrSX,
            right_speed=motorSpeeddx,
            right_dir=pwrDX,
        )
        

    lastErrorg = 0
    def PID_giu(cxb, centroX, cyb, cnt_giu):
        global ig
        global lastErrorg
        if cnt_giu < 3:
            baseSpeed = 35 #85
        elif cnt_giu < 7:
            baseSpeed = 35 #60
        else:
            baseSpeed = 35

        position = cxb
        error = (centroX - position)*2
        p = error
        d = error - lastErrorg
        y = max(0, cyb - high * pBlack * 0.55)*2
        #print(y**2 * KY + 1)
        lastErrorg = error 
        motorSpeed = int(p * 0.14 + d * 0.14) * (y**1.5 * KY + 1)#2.11
        motorSpeedsx = int(baseSpeed + motorSpeed)
        motorSpeeddx = int(baseSpeed - motorSpeed)

        if motorSpeedsx >= 0:
            pwrSX = "FW"
        else:
            pwrSX = "BW"
            motorSpeedsx = -motorSpeedsx

        if motorSpeeddx >= 0:
            pwrDX = "FW"
        else:
            pwrDX = "BW"
            motorSpeeddx = -motorSpeeddx
        # print(pwrDX,' ',motorSpeeddx,'   ',pwrSX, ' ', motorSpeedsx)
        
        motor.set_motor_speed_direction(
            left_speed=motorSpeedsx,
            left_dir=pwrSX,
            right_speed=motorSpeeddx,
            right_dir=pwrDX,
        )

    lastErrors = 0
    def PID_su(cxb, centroX, cyb):
        global lastErrors
        baseSpeed = 100
        position = cxb
        error = (centroX - position)*2
        p = error
        d = error - lastErrors
        y = max(0, cyb - high * pBlack * 0.55)*2
        #print(y**2 * KY + 1)
        lastErrors = error 
        motorSpeed = int(p * KP + d * KD) # motorSpeed = int(p * 0.1 + d * 0.00)# * (y**1.5 * KY + 1)/10)#2.11
        motorSpeedsx = int(baseSpeed + motorSpeed)
        motorSpeeddx = int(baseSpeed - motorSpeed)

        if motorSpeedsx >= 0:
            pwrSX = "FW"
        else:
            pwrSX = "BW"
            motorSpeedsx = -motorSpeedsx

        if motorSpeeddx >= 0:
            pwrDX = "FW"
        else:
            pwrDX = "BW"
            motorSpeeddx = -motorSpeeddx
        # print(pwrDX,' ',motorSpeeddx,'   ',pwrSX, ' ', motorSpeedsx)
        
        motor.set_motor_speed_direction(
            left_speed=motorSpeedsx,
            left_dir=pwrSX,
            right_speed=motorSpeeddx,
            right_dir=pwrDX,
        )

    lastErrorc = 0 
    def PID_contorno(dist):
        global lastErrorc
        dist_target = 75
        baseSpeed = 100

        error = (dist - dist_target)
        p = error
        d = error - lastErrorc
        lastErrorc = error 

        motorSpeed = int(p * 2 + d * 2.5)
        motorSpeedsx = int(baseSpeed + motorSpeed)
        motorSpeeddx = int(baseSpeed - motorSpeed)

        if motorSpeedsx >= 0:
            pwrSX = "FW"
        else:
            pwrSX = "BW"
            motorSpeedsx = -motorSpeedsx

        if motorSpeeddx >= 0:
            pwrDX = "FW"
        else:
            pwrDX = "BW"
            motorSpeeddx = -motorSpeeddx
        # print(pwrDX,' ',motorSpeeddx,'   ',pwrSX, ' ', motorSpeedsx)
        
        motor.set_motor_speed_direction(
            left_speed=motorSpeedsx,
            left_dir=pwrSX,
            right_speed=motorSpeeddx,
            right_dir=pwrDX,
        )


    def GAP(vero_gap):
        global frame, stato
        motor.stop()
        print(f"Inizio Gap {vero_gap}")

        led_mask = tuple([1] * 32)
        led_strip.set_leds(led_mask, (255, 255, 130), 255)
        time.sleep(0.15)
        motor.stop()
        time.sleep(0.2)

        if vero_gap ==  False or vero_gap == True:
            contoursGAPt = False
            while contoursGAPt == False:
                frame = picam2.capture_array("lores")
                contoursGAPt = findContourn("black", [high//8, high], [0])
                if contoursGAPt:
                    main_contourGAP = max(contoursGAPt, key=cv2.contourArea)
                    area_gap = cv2.contourArea(main_contourGAP)
                    if area_gap < area_min2:
                        print('gap_troppo_avanti')
                        motor.indietrocm(5)
                        time.sleep(0.3)
                        frame = picam2.capture_array("lores")
                        contoursGAPt = findContourn("black", [high//8, high], [0])
                        if contoursGAPt:
                            main_contourGAP = max(contoursGAPt, key=cv2.contourArea)

                    pax, pay = tuple(main_contourGAP[main_contourGAP[:, :, 1].argmin()][0])
                    pay += high//8
                    while pay > 3*high//5:
                        motor.indietro(0.2)
                        frame = picam2.capture_array("lores")
                        contoursGAP = findContourn("black", [high//8, high], [0])
                        if contoursGAP:
                            main_contourGAP = max(contoursGAP, key=cv2.contourArea)
                            pax, pay = tuple(main_contourGAP[main_contourGAP[:, :, 1].argmin()][0])
                            pay += high//8
                    motor.stop()
                    time.sleep(0.3)
                    frame = picam2.capture_array("lores")
                    contoursGAP = findContourn("black", [max(pay - 2,0) ,min(pay + 180, high)], [0])
                    if contoursGAP:
                        
                        main_contourGAP = max(contoursGAP, key=cv2.contourArea)
                        draw_contourn(main_contourGAP, (255,0,0))
                        rect = cv2.minAreaRect(main_contourGAP)
                        box = cv2.boxPoints(rect)
                        box = np.intp(box)
                        
                        #print(box)                        
                        cv2.drawContours(frame, [box], 0, (0, 255, 0), 2)
                        '''cv2.circle(frame, (box[0]), 3, (255,0,255), 1)
                        cv2.circle(frame, (box[1]), 3, (255,0,255), 2)
                        cv2.circle(frame, (box[2]), 3, (255,0,255), 3)
                        cv2.circle(frame, (box[3]), 3, (255,0,255), 4)'''
                        #cv2.imshow("frame", frame)
                        #if cv2.waitKey(1) & 0xFF == ord("q"):
                           # break
                        time.sleep(0.2)
                        destrer = box[0]
                        sinister = box[2]
                        alter = box[1]
                        
                        dist_destra = (destrer[0] - alter[0])**2 + (destrer[1]-alter[1])**2
                        dist_sinistra = (sinister[0] - alter[0])**2 + (sinister[1]-alter[1])**2
                        #dist_sinistra = (ay - aSy)**2 + (ax-aSx)**2
                        #print('distanze', dist_destra, dist_sinistra)
                        #cv2.putText(frame, "GAP", (25, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2, cv2.LINE_AA,)
                        cv2.circle(frame, (alter), 3, (255,0,255), 2)
                        if dist_destra < dist_sinistra:
                            dx = alter[0] - destrer[0]
                            dy = alter[1] - destrer[1]
                            cv2.circle(frame, (destrer), 3, (255,0,255), 2)
                        else:
                            dx = sinister[0] - alter[0]
                            dy = sinister[1] - alter[1]
                            cv2.circle(frame, (sinister), 3, (255,0,255), 2)
                        angolo_radianti = math.atan2(dy, dx)
                        angolo_gradi = math.degrees(angolo_radianti)
                        print('angolo:',angolo_gradi)
                        if abs(angolo_gradi) == 90.0:
                            angolo_gradi = 0
                        if abs(angolo_gradi) > 60:
                            motor.avanticm(2.7)
                        elif abs(angolo_gradi) > 45:
                            motor.avanticm(2.3)
                        else:
                            motor.avanticm(1)

                        if angolo_gradi < 0:
                            girosolosx(abs(angolo_gradi)//1.1, 0.35)
                        else:
                            girosolodx(abs(angolo_gradi)//1.1, 0.35)

                        #cv2.imshow("frame", frame)
                        #if cv2.waitKey(1) & 0xFF == ord("q"):
                           # break
                else:
                    motor.indietrocm(2)

        time.sleep(0.2)
        _, pitch, _ = robot.get_angles()
        if pitch < -10:
            girosx(15, 0.7)
        elif pitch > 10:
            girodx(15, 0.7)

        motor.avanticm(2)
        areagap = 0

        inizio = time.time()
        
        while areagap < 4000:
            ora = time.time()
            frame = picam2.capture_array("lores")
            contoursGAP = findContourn("blacks", [200, 500], [int(base/6), int(base*5/6)])
            contoursR = findContourn("red",[0], [int(base/8),int(base*7/8)])
            if (ora - inizio > 4.5) and False:
                print('stanza')
                motor.stop()
                time.sleep(0.1)
                motor.indietrocm(15)
                time.sleep(0.1)
                main_stanza() #----->>>>> codice stanza 
                motor.stop()
                return
            distance = robot.get_distance_sopra()
            #print('distanza', distance)

            if distance < 70 and distance != 0:
                distance = robot.get_distance_sopra()
                if distance < 70 and distance != 0:
                    motor.stop()
                    time.sleep(0.2)
                    
                    for _ in range(10):
                        distance = robot.get_distance_sopra()

                    while distance == 0:
                        distance = robot.get_distance_sopra()
                        motor.indietro(0.2)

                    motor.stop()
                    time.sleep(0.1)

                    if distance < 70 and distance != 0:
                        time.sleep(0.2)
                        for _ in range(10):
                            distance = robot.get_distance_sopra()

                        while distance == 0:
                            distance = robot.get_distance_sopra()
                            motor.indietro(0.2)

                        motor.stop()
                        time.sleep(0.1)

                        if distance < 70 and distance != 0:
                            distanza_des = robot.get_distance_destra()
                            distanza_sin = robot.get_distance_lat()
                            if distanza_sin < 300:
                                girostacolodx()
                            elif distanza_des < 300:
                                girostacolo()
                            else:
                                roll, pitch, yaw = robot.get_angles()
                                if pitch > 10:
                                    girostacolodx()
                                elif pitch < -10:
                                    girostacolo()
                                else:
                                    girostacolo()
                            
                            fine_ostacolo()
                            return    

            
            if contoursR and abs(robot.get_angles()[0]) < 4: #ne siamo sicuri, fare doppio controllo
                main_contourR = max(contoursR, key=cv2.contourArea)
                area = cv2.contourArea(main_contourR)
                if area > 80000: #9
                    print('ROSSO')
                    with open("contasfere_lack.txt", "w") as file:
                        file.write("0 0 0")
                    motor.avanticm(7)
                    led_strip.fine()
                    time.sleep(10)
                    led_strip.set_leds((1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1), (255, 255, 130), 255)

            if contoursGAP:
                main_contourGAP = max(contoursGAP, key=cv2.contourArea)
                areagap = cv2.contourArea(main_contourGAP)
                print('area gap', areagap)
                sxx, syy = tuple(main_contourGAP[main_contourGAP[:, :, 0].argmin()][0])
                dxx, dyy = tuple(main_contourGAP[main_contourGAP[:, :, 0].argmax()][0])
                print(dxx - sxx)
                if sxx < 5 or dxx > 2*base//3-5 or dxx - sxx > 300:
                    areagap = 300
                                
            motor.avantigap(0.7)

            cv2.putText(frame, "GAP", (25, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2, cv2.LINE_AA,)
            #cv2.imshow("frame", frame)
            #if cv2.waitKey(1) & 0xFF == ord("q"):
               # break
        
        motor.avanticm(3)
        print("Fine Gap")


    def girostacolo():
    #motor.indietrocm(1)
        global frame
        motor.indietrocm(1)
        girosx(68, 0.7)
        frame = picam2.capture_array("lores")
        contoursO = findContourn("blacks", [int(high//2), int(3*high//4)], [int(6*base//8), int(8*base//8)]) #cambiamento crazy
        areao = 0
            
        while areao < 4000:
            motor.indietrocm(1)
            girosx(6, 0.7)
            motor.avanticm(2)
            motor.only_right(0.45)
            primo_lungo = True

            
            tempo_inizio = time.time()
            while True:
                
                for _ in range(10):
                    last_dist = robot.get_distance_destra()
                #while last_dist > 100 or last_dist == 0:
                #    last_dist = robot.get_distance_destra()

                for _ in range(6):
                    frame = picam2.capture_array("lores")
                    cv2.line(frame, (int(6*base//8), int(high//2)), (int(8*base//8), int(high//2)), (0, 0, 0), 1)
                    cv2.line(frame, (int(6*base//8), int(7*high//8)), (int(8*base//8), int(7*high//8)), (0, 0, 0), 1)
                    cv2.line(frame, (int(6*base//8), int(high//2)), (int(6*base//8), int(3*high//4)), (0, 0, 0), 1)

                    contoursO = findContourn("blacks", [int(high//2), int(7*high//8)], [int(6*base//8), int(8*base//8)])
                    if contoursO:
                        main_contourO = max(contoursO, key=cv2.contourArea)
                        dxxx, dyyy = tuple(main_contourO[main_contourO[:, :, 0].argmax()][0])
                        #print(dxxx)
                        if (bottone_dx_esterno.is_pressed) or (bottone_dx.is_pressed):
                            motor.stop()
                            break
                        if dxxx > 2*base//8 - 10:
                            areao = cv2.contourArea(main_contourO)
                            if areao >= 4000:
                                motor.stop()
                                break
                        else:
                            areao = 0
                    else:
                        areao = 0
                    time.sleep(0.1)
                    now_dist = robot.get_distance_destra()
                    if now_dist < 100:
                        primo_lungo = False

                if (areao >= 4000) or (bottone_dx_esterno.is_pressed) or (bottone_dx.is_pressed):
                    motor.stop()
                    break

                now_dist = robot.get_distance_destra()
                if now_dist < 100:
                    primo_lungo = False

                if time.time() - tempo_inizio > 4:
                    motor.only_right(0.45)
                    time.sleep(time.time() - tempo_inizio)
                    motor.stop()
                    break

                    
                #cv2.imshow("frame", frame)
                print('area: ', areao, 'distanze: ', last_dist, now_dist, 'differenza: ', now_dist - last_dist)

                #if cv2.waitKey(1) & 0xFF == ord("q"):
                    #break
                if (now_dist - last_dist > 3 and primo_lungo == False and last_dist != 0 and now_dist != 0) or (bottone_dx_esterno.is_pressed) or (bottone_dx.is_pressed):
                    motor.stop()
                    break
            print('radrizzo')
        
        angolo_giusto = 75
        frame = picam2.capture_array("lores")
        contoursOdd = findContourn("blacks", [int(high//4), int(7*high//8)], [int(base-30), int(base)])
        if contoursOdd:
            main_contoursOdd = max(contoursOdd, key=cv2.contourArea)
            xdd, ydd = findCenter(main_contoursOdd)
            contoursOss = findContourn("blacks", [int(high//4), int(7*high//8)], [int(base-60), int(base-30)])
            if contoursOss:
                main_contoursOss = max(contoursOss, key=cv2.contourArea)
                xss, yss = findCenter(main_contoursOss)
                cv2.circle(frame, (xdd + 30, ydd), 3, (0, 255, 255), 3)
                cv2.circle(frame, (xss, yss), 3, (0, 255, 255), 3)
                dxx = xdd + 30 - xss
                dyy = ydd - yss 
                angolo_radiantite = math.atan2(dyy, dxx)
                angolo_gradite = math.degrees(angolo_radiantite)

                print('aaaa:',90 - angolo_gradite)
                if 90 - angolo_gradite > 0 and 90 - angolo_gradite < 145:
                    angolo_giusto = int(90 - angolo_gradite)
                #for _ in range(10):
                    #cv2.imshow("frame", frame)
                    #if cv2.waitKey(1) & 0xFF == ord("q"):
                       # break
                

        
        motor.avanticm(5)
        girodx(2, 0.7)
        motor.avanticm(2)
        time.sleep(0.1)
        girosx(angolo_giusto, 0.7)
        time.sleep(0.1)
        motor.indietrocm(5)
        time.sleep(0.1)

    def girostacolodx():
    #motor.indietrocm(1)
        global frame
        motor.indietrocm(1)
        girodx(68, 0.7)
        frame = picam2.capture_array("lores")
        contoursO = findContourn("blacks", [int(high//2), int(3*high//4)], [int(0), int(2*base//8)]) #cambiamento crazy
        areao = 0
            
        while areao < 4000:
            motor.indietrocm(1)
            girodx(6, 0.7)
            motor.avanticm(2)
            motor.only_left(0.45)
            primo_lungo = True

            
            tempo_inizio = time.time()
            while True:
                
                for _ in range(10):
                    last_dist = robot.get_distance_lat()
                #while last_dist > 100 or last_dist == 0:
                #    last_dist = robot.get_distance_destra()

                for _ in range(6):
                    frame = picam2.capture_array("lores")
                    cv2.line(frame, (int(2*base//8), int(high//2)), (int(0), int(high//2)), (0, 0, 0), 1)
                    cv2.line(frame, (int(2*base//8), int(7*high//8)), (int(0), int(7*high//8)), (0, 0, 0), 1)
                    cv2.line(frame, (int(2*base//8), int(high//2)), (int(2*base//8), int(3*high//4)), (0, 0, 0), 1)

                    contoursO = findContourn("blacks", [int(high//2), int(7*high//8)], [int(0), int(2*base//8)])
                    if contoursO:
                        main_contourO = max(contoursO, key=cv2.contourArea)
                        sxxx, syyy = tuple(main_contourO[main_contourO[:, :, 0].argmin()][0])
                        #print(dxxx)
                        if (bottone_sx_esterno.is_pressed) or (bottone_sx.is_pressed):
                            motor.stop()
                            break
                        if sxxx < 10:
                            areao = cv2.contourArea(main_contourO)
                            if areao >= 4000:
                                motor.stop()
                                break
                        else:
                            areao = 0
                    else:
                        areao = 0
                    time.sleep(0.1)
                    now_dist = robot.get_distance_lat()
                    if now_dist < 100:
                        primo_lungo = False

                if (areao >= 4000) or (bottone_sx_esterno.is_pressed) or (bottone_sx.is_pressed):
                    motor.stop()
                    break

                now_dist = robot.get_distance_lat()
                if now_dist < 100:
                    primo_lungo = False

                if time.time() - tempo_inizio > 4:
                    motor.only_left(0.45)
                    time.sleep(time.time() - tempo_inizio)
                    motor.stop()
                    break

                    
                #cv2.imshow("frame", frame)
                print('area: ', areao, 'distanze: ', last_dist, now_dist, 'differenza: ', now_dist - last_dist)

                #if cv2.waitKey(1) & 0xFF == ord("q"):
                    #break
                if (now_dist - last_dist > 3 and primo_lungo == False and last_dist != 0 and now_dist != 0) or (bottone_sx_esterno.is_pressed) or (bottone_sx.is_pressed):
                    motor.stop()
                    break
            print('radrizzo')
        
        angolo_giusto = 75
        frame = picam2.capture_array("lores")
        contoursOdd = findContourn("blacks", [int(high//4), int(7*high//8)], [int(0), int(30)])
        if contoursOdd:
            main_contoursOdd = max(contoursOdd, key=cv2.contourArea)
            xdd, ydd = findCenter(main_contoursOdd)
            contoursOss = findContourn("blacks", [int(high//4), int(7*high//8)], [30, 60])
            if contoursOss:
                main_contoursOss = max(contoursOss, key=cv2.contourArea)
                xss, yss = findCenter(main_contoursOss)
                cv2.circle(frame, (xdd + 30, ydd), 3, (0, 255, 255), 3)
                cv2.circle(frame, (xss, yss), 3, (0, 255, 255), 3)
                dxx = xss + 30 - xdd
                dyy = yss - ydd
                angolo_radiantite = math.atan2(dyy, dxx)
                angolo_gradite = math.degrees(angolo_radiantite)

                print('aaaa:',90 - angolo_gradite)
                if 90 - angolo_gradite > 0 and 90 - angolo_gradite < 145:
                    angolo_giusto = int(90 - angolo_gradite)
                #for _ in range(10):
                    #cv2.imshow("frame", frame)
                    #if cv2.waitKey(1) & 0xFF == ord("q"):
                       # break
                

        
        motor.avanticm(5)
        girosx(2, 0.7)
        motor.avanticm(2)
        time.sleep(0.1)
        girodx(angolo_giusto, 0.7)
        time.sleep(0.1)
        motor.indietrocm(5)
        time.sleep(0.1)

    area_min = 19000
    area_min2 = 7000

    def fine_ostacolo():
        global frame, high, base, area_min
        nero_dopo_ostacolo = False
        motor.stop()
        time.sleep(0.2)
        frame = picam2.capture_array("lores")
        contoursB = findContourn("black", [high//2, int(high * pBlack)], [0])
        if contoursB:
            main_contourb = max(contoursB, key=cv2.contourArea)
            area_nero = cv2.contourArea(main_contourb)
            if area_nero > area_min//2:
                cxb, _ = findCenter(main_contourb)
                '''if cxb is not None:
                    if cxb > base // 2:
                        while cxb > 2*base//3:
                            motor.right(0.3)
                            frame = picam2.capture_array("lores")
                            contoursB = findContourn("black", [high//2, int(high * pBlack)], [0])
                            if contoursB:
                                cxb, _ = findCenter(main_contourb)
                                if cxb is None:
                                    break
                            else:
                                break
                        
                    else:
                        while cxb < base//3:
                            motor.left(0.3)
                            frame = picam2.capture_array("lores")
                            contoursB = findContourn("black", [high//2, int(high * pBlack)], [0])
                            if contoursB:
                                cxb, _ = findCenter(main_contourb)
                                if cxb is None:
                                    break
                            else:
                                break
                    motor.stop()'''

                nero_dopo_ostacolo = True
            
        if nero_dopo_ostacolo == False: 
            girodx(45, 0.7)
            motor.stop()
            time.sleep(0.2)
            frame = picam2.capture_array("lores")
            contoursB = findContourn("black", [0, int(high * pBlack)], [0])
            if contoursB:
                main_contourb = max(contoursB, key=cv2.contourArea)
                area_nero = cv2.contourArea(main_contourb)
                if area_nero > area_min:
                    cxb, _ = findCenter(main_contourb)
                    '''if cxb is not None:
                        if cxb > base // 2:
                            while cxb > 2*base//3:
                                motor.right(0.3)
                                frame = picam2.capture_array("lores")
                                contoursB = findContourn("black", [high//2, int(high * pBlack)], [0])
                                if contoursB:
                                    cxb, _ = findCenter(main_contourb)
                                    if cxb is None:
                                        break
                                else:
                                    break
                            
                        else:
                            while cxb < base//3:
                                motor.left(0.3)
                                frame = picam2.capture_array("lores")
                                contoursB = findContourn("black", [high//2, int(high * pBlack)], [0])
                                if contoursB:
                                    cxb, _ = findCenter(main_contourb)
                                    if cxb is None:
                                        break
                                else:
                                    break
                        motor.stop()'''
                    nero_dopo_ostacolo = True
                #contoursGray = findContourn("gray", [0, int(high * 3/4)],[0])
            if nero_dopo_ostacolo == False:
                girosx(90, 0.7)
                motor.stop()
                time.sleep(0.2)
                frame = picam2.capture_array("lores")
                contoursB = findContourn("black", [0, int(high * pBlack)], [0])
                if contoursB:
                    main_contourb = max(contoursB, key=cv2.contourArea)
                    area_nero = cv2.contourArea(main_contourb)
                    if area_nero > area_min:
                        cxb, _ = findCenter(main_contourb)
                        '''if cxb is not None:
                            if cxb > base // 2:
                                while cxb > 2*base//3:
                                    motor.right(0.3)
                                    frame = picam2.capture_array("lores")
                                    contoursB = findContourn("black", [high//2, int(high * pBlack)], [0])
                                    if contoursB:
                                        cxb, _ = findCenter(main_contourb)
                                        if cxb is None:
                                            break
                                    else:
                                        break
                                    
                            else:
                                while cxb < base//3:
                                    motor.left(0.3)
                                    frame = picam2.capture_array("lores")
                                    contoursB = findContourn("black", [high//2, int(high * pBlack)], [0])
                                    if contoursB:
                                        cxb, _ = findCenter(main_contourb)
                                        if cxb is None:
                                            break
                                    else:
                                        break
                            motor.stop()'''
                        nero_dopo_ostacolo = True
                if nero_dopo_ostacolo == False:
                    girodx(45, 0.7)
                    motor.stop()
                    frame = picam2.capture_array("lores")
                    GAP(True)
                    frame = picam2.capture_array("lores")


    def ostacolosx():
        time.sleep(0.1)
        motor.indietrocm(2)
        time.sleep(0.2)
        girosx(82, 0.7)
        time.sleep(0.2)
        motor.avanticm(20)
        time.sleep(0.2)
        girodx(86, 0.7)
        time.sleep(0.2)
        motor.avanticm(38)
        time.sleep(0.2)
        girodx(89, 0.7)
        time.sleep(0.2)
        motor.avanticm(21.8)
        time.sleep(0.2)
        girosx(86, 0.7)
        time.sleep(0.2)
        motor.indietrocm(16)
        time.sleep(0.1)
        fine_ostacolo()

    def ostacolodx():
        time.sleep(0.1)
        motor.indietrocm(2)
        time.sleep(0.2)
        girodx(85, 0.7)
        time.sleep(0.2)
        motor.avanticm(20)
        time.sleep(0.2)
        girosx(80, 0.7)
        time.sleep(0.2)
        motor.avanticm(37)
        time.sleep(0.2)
        girosx(80, 0.7)
        time.sleep(0.2)
        motor.avanticm(29.8)
        time.sleep(0.2)
        girodx(86, 0.7)
        time.sleep(0.2)
        motor.indietrocm(15)
        time.sleep(0.1)
        girodx(3, 0.7)
        time.sleep(0.1)
        fine_ostacolo()

    

    def ricerca_bordo():
        global frame, high, base
        led_strip.set_leds((1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1), (255, 255, 130), 255)
        uscita = False
        girosx(88, 0.7)
        for j in range(10):
            dist_lat = robot.get_distance_lat()
        print('inizio', dist_lat)
        while (dist_lat > 150 and dist_lat < 1000) or (dist_lat == 0):
            dist_lat = robot.get_distance_lat()
            print('trosso', dist_lat)
            motor.avanti(0.7)

        motor.stop()
        time.sleep(0.2)
        girosolodx(44, 0.7)
        time.sleep(0.2)
        for _ in range(10):
            dist_lat = robot.get_distance_lat()

        while dist_lat == 0:
            dist_lat = robot.get_distance_lat()

        if dist_lat > 250:
            time.sleep(0.2)
            motor.avanticm(1)
            time.sleep(0.2)
            uscita = True
        

        while True:

            if uscita:
                while uscita:
                    #motor.avanticm(2)
                    print('USCENDO')
                    motor.stop()
                    uscita = False

                    time.sleep(0.2)
                    #motor.avanticm(1) #guarda se uscita
                    
                            
                    for j in range(10):
                        davanti = robot.get_distance_sopra()
                        sotto = robot.get_distance_sotto()
                    
                    while davanti == 0 or sotto == 0:
                        davanti = robot.get_distance_sopra()
                        sotto = robot.get_distance_sotto()

                    print('dopo uscita:', davanti, sotto)

                    if (davanti < 150 and davanti != 0):    #ANGOLO
                        print("angolo dopo uscita")
                        motor.stop()
                        motor.avanticm(1)
                        time.sleep(0.2)
                        girodx(86, 0.8)
                        time.sleep(0.2)

                        for j in range(10):
                            distanza = robot.get_distance_lat()
                            davanti = robot.get_distance_sopra()
                            sotto = robot.get_distance_sotto()

            
                    elif ((davanti != 0 and sotto != 0) and (davanti < 400 and davanti-sotto > 160)):  #TRIANGOLO
                        print("triangolo dopo uscita")
                        motor.avanticm(1)
                        motor.stop()
                        time.sleep(0.2)
                        girosolodx(44, 0.7)
                        time.sleep(0.2)
                        motor.avanticm(20)
                        time.sleep(0.2)
                        girosolodx(43, 0.7)
                        time.sleep(0.2)
                        
                        for j in range(10):
                            dist_lat = robot.get_distance_lat()

                        while dist_lat == 0:
                            dist_lat = robot.get_distance_lat()

                        if dist_lat > 250:
                            motor.avanticm(1)
                            time.sleep(0.2)
                            girosx(85, 0.7)

                            uscita = True

                        for j in range(10):
                            distanza = robot.get_distance_lat()
                            davanti = robot.get_distance_sopra()
                            sotto = robot.get_distance_sotto()

                    else:
                        print("dritto dopo uscita")
                        girodx(1, 0.7)
                        for _ in range(10):
                            dist_lat = robot.get_distance_lat()

                        while dist_lat == 0 or dist_lat > 240:
                            print('rientrando', dist_lat)
                            dist_lat = robot.get_distance_lat()
                            motor.avanti(0.7)
                        print("RIENTRATO", dist_lat)
                        motor.stop()
                        motor.avanticm(1.5)
                        time.sleep(0.2)

                        for j in range(10):
                            distanza = robot.get_distance_lat()
                            davanti = robot.get_distance_sopra()
                            sotto = robot.get_distance_sotto()


            else:
                distanza = robot.get_distance_lat()
                davanti = robot.get_distance_sopra()
                sotto = robot.get_distance_sotto()
                print(distanza, davanti, sotto)

                

                if distanza == 0:
                    distanza = 75
                
                
                if (distanza > 250):  #SPAZIO A LATO
                    print('uscita a lato o davanti?')
                    frame = picam2.capture_array("lores")
                    contoursB = findContourn("blacks", [0, int(7*high/8)], [0])
                    if contoursB:
                        main_contourB = max(contoursB, key=cv2.contourArea)
                        draw_contourn(main_contourB, (255, 0, 0))
                        area2 = cv2.contourArea(main_contourB)
                        print(area2)
                        if area2 > 7000:
                            time.sleep(0.1)
                            motor.indietrocm(9)
                            girodx(87, 0.7)
                            time.sleep(0.1)
                            print('davanti')
                            uscita = True

                    if uscita == False:
                        motor.stop()
                        time.sleep(1)
                        motor.avanticm(8)
                        '''while dietro < 300:
                            print('dietro',dietro)
                            motor.avanti(0.7)
                            dietro = robot.get_distance_dietro()'''

                        time.sleep(0.3)
                        uscita = True

                    for j in range(10):
                        distanza = robot.get_distance_lat()
                        davanti = robot.get_distance_sopra()
                        sotto = robot.get_distance_sotto()

                elif (davanti < 110 and davanti != 0):    #ANGOLO
                    print('angolo')
                    motor.stop()
                    motor.avanticm(0.5)
                    time.sleep(0.1)
                    girodx(90, 0.8)
                    time.sleep(0.2)
                    motor.indietrocm(10)
                    time.sleep(0.1)

                    for j in range(10):
                        distanza = robot.get_distance_lat()
                        davanti = robot.get_distance_sopra()
                        sotto = robot.get_distance_sotto()

                elif (davanti < 350 and davanti-sotto > 100 and davanti != 0 and sotto != 0):  #TRIANGOLO
                    print('triangolo')

                    motor.avanticm(1)
                    motor.stop()
                    time.sleep(0.2)
                    girosolodx(44, 0.7)
                    time.sleep(0.2)
                    motor.avanticm(19)
                    time.sleep(0.2)
                    girosolodx(43, 0.7)
                    time.sleep(0.2)
                    
                    for j in range(10):
                        dist_lat = robot.get_distance_lat()

                    while dist_lat == 0:
                        dist_lat = robot.get_distance_lat()

                    if dist_lat > 250:
                        motor.avanticm(2)
                        time.sleep(0.2)

                        uscita = True

                    for j in range(10):
                        distanza = robot.get_distance_lat()
                        davanti = robot.get_distance_sopra()
                        sotto = robot.get_distance_sotto()

                else:
                    PID_contorno(distanza)

    def Uscita_stanza():
        global frame, high, base
        led_strip.set_leds((1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1), (255, 255, 130), 255)
        uscita = False
        girosx(88, 0.5)
        for j in range(10):
            dist_lat = robot.get_distance_lat()
        print('inizio', dist_lat)
        inizio_triangolo_rosso = time.time()
        while (dist_lat > 180 and dist_lat < 1000) or (dist_lat == 0):
            for _ in range(3):
                dist_lat = robot.get_distance_lat()
            print('trosso', dist_lat)
            motor.avanti(0.4)
            if time.time() - inizio_triangolo_rosso > 3: #oppure bottone
                girosolodx(42, 0.7)
                motor.stop()
                time.sleep(0.1)
                break
        motor.stop()
        time.sleep(0.2)
        girosolodx(30, 0.6)
        distanza = robot.get_distance_lat()
        dietro = robot.get_distance_dietro()
        if distanza < 150:
            while dietro >= distanza:
                distanza = robot.get_distance_lat()
                dietro = robot.get_distance_dietro()
                motor.only_right(0.6)
        else:
           girosolodx(11, 0.6) 
        motor.stop()
        time.sleep(0.2)
        for _ in range(20):
            dist_lat = robot.get_distance_lat()
        while dist_lat == 0:
            dist_lat = robot.get_distance_lat()
        ex_dist = robot.get_distance_lat()
        if dist_lat > 200:
            time.sleep(0.2)
            motor.avanticm(0.5)
            time.sleep(0.2)
            girosx(87, 0.7)
            time.sleep(0.2)
            uscita = True
        for _ in range(20):
            distanza = robot.get_distance_lat()
            davanti = robot.get_distance_sopra()
            sotto = robot.get_distance_sotto()
            dietro = robot.get_distance_dietro()
        cnt1 = 0
        cnt2 = 0
        cnt3 = 0
        cnt4 = 0
        while True:
            if uscita:
                while uscita:
                    print('USCENDO')
                    motor.stop()
                    uscita = False
                    motor.indietrocm(3)
                    time.sleep(0.2)
                    #motor.avanticm(1) #guarda se uscita
                    tempo_uscita = time.time()
                    area_max_nero = 0
                    time.sleep(0.2)
                    led_mask = tuple([0] * 32)
                    led_strip.set_leds(led_mask, (255, 255, 130), 255)
                    time.sleep(0.4)
                    for _ in range(5):
                        frame = picam2.capture_array("lores")

                    while True:
                        motor.avanti(0.4)
                        frame = picam2.capture_array("lores")
                        contoursB_dubbio = findContourn("blacks", [int(4*high//15), int(7*high//15)], [0])
                        if contoursB_dubbio:
                            main_contoursB_dubbio = max(contoursB_dubbio, key=cv2.contourArea)
                            #draw_contourn(main_contourB, (255, 0, 0))
                            area2 = cv2.contourArea(main_contoursB_dubbio)
                            if area2 > area_max_nero:
                                area_max_nero = area2
                        print(area_max_nero)

                        #cv2.imshow("frame", frame)
                        #if cv2.waitKey(1) & 0xFF == ord("q"):
                         #   break

                        if bottone_dx.is_pressed:
                            tempo_bonus = time.time()
                            motor.indietrocm(3)
                            girosx(6, 0.6)
                            motor.avanticm(3)
                            tempo_uscita += time.time() - tempo_bonus
                            _, _, yaw = robot.get_angles()

                        elif bottone_sx.is_pressed:
                            tempo_bonus = time.time()
                            motor.indietrocm(3)
                            girodx(6, 0.6)
                            motor.avanticm(3)
                            tempo_uscita += time.time() - tempo_bonus
                            _, _, yaw = robot.get_angles()


                        if time.time() - tempo_uscita > 2.5:
                            print('area_nero',area_max_nero, 3 * area_min)
                            if area_max_nero > 3*area_min:
                                motor.avanticm(1)
                                led_mask = tuple([1] * 32)
                                led_strip.set_leds(led_mask, (255, 255, 130), 255)
                                motor.stop()
                                time.sleep(0.1)
                                return
                            else:
                                motor.indietrocm(7)
                                girodx(83, 0.6)
                                for _ in range(20):
                                    distanza = robot.get_distance_lat()
                                    davanti = robot.get_distance_sopra()
                                    sotto = robot.get_distance_sotto()
                                    dietro = robot.get_distance_dietro()
                                break

                            
                        #cv2.imshow("frame", frame)
                        #if cv2.waitKey(1) & 0xFF == ord("q"):
                         #   break
                    led_mask = tuple([1] * 32)
                    led_strip.set_leds(led_mask, (255, 255, 130), 255)
                    for _ in range(20):
                        davanti = robot.get_distance_sopra()
                        sotto = robot.get_distance_sotto()
                    while davanti == 0 or sotto == 0:
                        davanti = robot.get_distance_sopra()
                        sotto = robot.get_distance_sotto()
                    print('dopo uscita:',davanti, sotto)
                    if (davanti < 150 and davanti != 0):    #ANGOLO
                        motor.avanticm(1)
                        print('angolo')
                        motor.stop()
                        time.sleep(0.1)
                        girodx(87, 0.8)
                        time.sleep(0.2)
                        for j in range(20):
                            distanza = robot.get_distance_lat()
                            davanti = robot.get_distance_sopra()
                            sotto = robot.get_distance_sotto()
                            dietro = robot.get_distance_dietro()
                    elif (davanti < 430 and davanti-sotto > 80 and davanti != 0 and sotto != 0):  #TRIANGOLO
                        motor.avanticm(1)
                        print('triangolo')
                        motor.stop()
                        time.sleep(0.2)
                        girosolodx(44, 0.7)
                        time.sleep(0.2)
                        motor.avanticm(16)
                        time.sleep(0.2)
                        girosolodx(30, 0.6)
                        distanza = robot.get_distance_lat()
                        dietro = robot.get_distance_dietro()
                        if distanza < 150:
                            while dietro >= distanza - 2:
                                distanza = robot.get_distance_lat()
                                dietro = robot.get_distance_dietro()
                                motor.only_right(0.6)
                            motor.stop()
                        else:
                            girosolodx(13, 0.6)
                        time.sleep(0.2)
                        for j in range(10):
                            dist_lat = robot.get_distance_lat()
                        while dist_lat == 0:
                            dist_lat = robot.get_distance_lat()
                        if dist_lat > 250:
                            motor.avanticm(2)
                            time.sleep(0.2)
                            girosx(85, 0.7)
                            uscita = True
                        for _ in range(20):
                            distanza = robot.get_distance_lat()
                            davanti = robot.get_distance_sopra()
                            sotto = robot.get_distance_sotto()
                            dietro = robot.get_distance_dietro()
                    else:
                        print("dritto dopo uscita")
                        '''for _ in range(10):
                            dist_dietro = robot.get_distance_dietro()
                        while dist_dietro == 0 or dist_dietro > 240:
                            print('rientrando', dist_dietro)
                            dist_dietro = robot.get_distance_dietro()
                            motor.avanti(0.7)
                        print("RIENTRATO", dist_dietro)'''
                        motor.stop()
                        _, _, pitch = robot.get_angles()
                        motor.avanticm(17)
                        _, _, pitch1 = robot.get_angles()
                        if abs(pitch1 - pitch) > 4:
                            motor.stop()
                            time.sleep(0.2)
                            girosolodx(66, 0.7)
                            time.sleep(0.2)
                            motor.avanticm(17)
                            time.sleep(0.2)
                            girosolodx(30, 0.6)
                            distanza = robot.get_distance_lat()
                            dietro = robot.get_distance_dietro()
                            if distanza < 150:
                                while dietro >= distanza - 2:
                                    distanza = robot.get_distance_lat()
                                    dietro = robot.get_distance_dietro()
                                    motor.only_right(0.6)
                                motor.stop()
                            else:
                                girosolodx(13, 0.6)
                            time.sleep(0.2)
                            for j in range(10):
                                dist_lat = robot.get_distance_lat()
                            while dist_lat == 0:
                                dist_lat = robot.get_distance_lat()
                            if dist_lat > 250:
                                motor.avanticm(2)
                                time.sleep(0.2)
                                girosx(85, 0.7)
                                uscita = True
                            for _ in range(20):
                                distanza = robot.get_distance_lat()
                                davanti = robot.get_distance_sopra()
                                sotto = robot.get_distance_sotto()
                                dietro = robot.get_distance_dietro()
                            time.sleep(0.4)
                        for _ in range(20):
                            distanza = robot.get_distance_lat()
                            davanti = robot.get_distance_sopra()
                            sotto = robot.get_distance_sotto()
                            dietro = robot.get_distance_dietro()
            else:
                #print('0')
                distanza = robot.get_distance_lat()
                #print('1')
                davanti = robot.get_distance_sopra()
                #print('2')
                sotto = robot.get_distance_sotto()
                #print('3')
                dietro = robot.get_distance_dietro()
                #print('5')

                print(distanza, davanti, sotto, dietro)

                spazio_lato = False

                if dietro >= distanza - 15 and dietro < 150: #dritto
                    print('radrizzo uno')
                    while dietro >= distanza - 15:
                        motor.only_right_green(0.07,0.5)
                        distanza = robot.get_distance_lat()
                        dietro = robot.get_distance_dietro()
                    motor.stop()

                if distanza - dietro >= 50 and distanza < 150:
                    print('radrizzo due')
                    while distanza - dietro >= 50:
                        motor.only_left_obstacle(0.5)
                        distanza = robot.get_distance_lat()
                        dietro = robot.get_distance_dietro()
                    motor.stop()

                if (distanza > 200):  #SPAZIO A LATO
                    motor.stop()
                    time.sleep(0.5)

                    print('uscita a lato o davanti? normale')
                    motor.indietrocm_verde(16, 0.7, 0.6)
                    frame = picam2.capture_array("lores")
                    contoursB = findContourn("blacks", [0, int(6*high/7)], [0])
                    if contoursB:
                        main_contourB = max(contoursB, key=cv2.contourArea)
                        #draw_contourn(main_contourB, (255, 0, 0))
                        area2 = cv2.contourArea(main_contourB)
                        print('area nero:',area2)
                        if area2 > 5000:
                            time.sleep(0.1)
                            motor.indietrocm(7)
                            time.sleep(0.1)
                            print('davanti')
                            uscita = True

                    if uscita == False:
                        motor.stop()
                        time.sleep(0.5)
                        #motor.avanticm(8)
                        dietro = robot.get_distance_dietro()
                        if dietro > 150:
                            motor.avanticm(15)
                        else:
                            while dietro < 150:
                                print('dietro',dietro)
                                motor.avanti(0.2)
                                dietro = robot.get_distance_dietro()

                        time.sleep(0.3)
                        girosx(86, 0.7)
                        time.sleep(0.3)
                        uscita = True
                    motor.stop()
                    time.sleep(0.4)
                    for _ in range(20):
                        distanza = robot.get_distance_lat()
                        davanti = robot.get_distance_sopra()
                        sotto = robot.get_distance_sotto()
                        dietro = robot.get_distance_dietro()

                elif (davanti < 83 and davanti != 0):    #ANGOLO
                    motor.stop()
                    time.sleep(0.2)

                    for _ in range(20):
                        distanza = robot.get_distance_lat()

                    if distanza > 200:
                        spazio_lato = True
                        print('angolo, ma spazio lato')
                    else:
                        motor.avanticm(0.5)

                        print('angolo')
                        motor.stop()
                        time.sleep(0.1)
                        girodx(92, 0.8)
                        time.sleep(0.2)
                        motor.indietrocm(10)

                        time.sleep(0.5)

                        while davanti < 83:
                            distanza = robot.get_distance_lat()
                            davanti = robot.get_distance_sopra()
                            sotto = robot.get_distance_sotto()
                            dietro = robot.get_distance_dietro()

                    for _ in range(20):
                        distanza = robot.get_distance_lat()
                        davanti = robot.get_distance_sopra()
                        sotto = robot.get_distance_sotto()
                        dietro = robot.get_distance_dietro()

                elif (davanti < 400 and davanti-sotto > 110 and davanti != 0 and sotto != 0):  #TRIANGOLO
                    motor.stop()
                    time.sleep(0.2)
                    for _ in range(20):
                        davanti = robot.get_distance_sopra()
                        sotto = robot.get_distance_sotto()
                        distanza = robot.get_distance_lat()

                    if distanza > 200:
                        print('finto_triangolo')
                        spazio_lato = True

                    elif (davanti < 400 and davanti-sotto > 110 and davanti != 0 and sotto != 0):
                        print('triangolo_vero')
                        motor.stop()
                        print('triangolo')
                        time.sleep(0.2)
                        girosolodx(44, 0.7)
                        time.sleep(0.2)
                        motor.avanticm(16)
                        time.sleep(0.2)
                        girosolodx(30, 0.6)
                        motor.stop()
                        time.sleep(2)

                        for _ in range(20):
                            distanza = robot.get_distance_lat()
                            dietro = robot.get_distance_dietro()
                        print('dist_tria', distanza)
                        if distanza < 150:
                            while dietro >= distanza - 2:
                                distanza = robot.get_distance_lat()
                                dietro = robot.get_distance_dietro()
                                motor.only_right(0.6)
                            motor.stop()
                        else:
                            girosolodx(7, 0.6)
                            motor.avanticm(1.5)
                            time.sleep(0.2)
                            girosx(85, 0.7)
                            uscita = True

                        motor.stop()

                    time.sleep(0.4)

                    for _ in range(20):
                        distanza = robot.get_distance_lat()
                        davanti = robot.get_distance_sopra()
                        sotto = robot.get_distance_sotto()
                        dietro = robot.get_distance_dietro()

                elif spazio_lato:
                    uscita = False
                    spazio_lato = False
                    print('spazio a lato')
                    motor.stop()
                    time.sleep(0.2)

                    print('uscita a lato o davanti?')
                    motor.indietrocm_verde(13, 0.7, 0.6)
                    frame = picam2.capture_array("lores")
                    contoursB = findContourn("blacks", [0, int(6*high/7)], [0])
                    if contoursB:
                        main_contourB = max(contoursB, key=cv2.contourArea)
                        #draw_contourn(main_contourB, (255, 0, 0))
                        area2 = cv2.contourArea(main_contourB)
                        print('area nero:',area2)
                        if area2 > 5000:
                            time.sleep(0.1)
                            motor.indietrocm(7)
                            time.sleep(0.1)
                            print('davanti')
                            uscita = True

                    if uscita == False:
                        motor.stop()
                        time.sleep(0.5)
                        #motor.avanticm(8)
                        dietro = robot.get_distance_dietro()
                        while dietro < 150:
                            print('dietro',dietro)
                            motor.avanti(0.2)
                            dietro = robot.get_distance_dietro()
                        time.sleep(0.3)
                        girosx(86, 0.7)
                        time.sleep(0.3)
                        uscita = True
                    motor.stop()
                    time.sleep(0.4)
                    for _ in range(20):
                        distanza = robot.get_distance_lat()
                        davanti = robot.get_distance_sopra()
                        sotto = robot.get_distance_sotto()
                        dietro = robot.get_distance_dietro()

                else:
                    if distanza < 55 and distanza <= ex_dist:
                        fast1 = 0.65
                        fast2 = 0.5
                        cnt1 += 1
                        if cnt1 > 15:
                            fast1 = 0.85
                            fast2 = 0.45
                        elif cnt1 > 4:
                            fast1 = 0.75
                            fast2 = 0.5
                        cnt2 = 0
                        cnt3 = 0
                        cnt4 = 0
                    elif distanza < 67 and distanza < ex_dist:
                        fast1 = 0.65
                        fast2 = 0.5
                        cnt2 += 1
                        if cnt2 > 2:
                            fast1 = 0.725
                            fast2 = 0.5
                        cnt1 = 0
                        cnt3 = 0
                        cnt4 = 0
                    elif distanza > 110 and distanza >= ex_dist:
                        fast1 = 0.5
                        fast2 = 0.7
                        cnt3 += 1
                        if cnt4 > 15:
                            fast1 = 0.45
                            fast2 = 0.85
                        if cnt3 > 4:
                            fast1 = 0.5
                            fast2 = 0.8
                        cnt1 = 0
                        cnt2 = 0
                        cnt4 = 0
                    elif distanza > 98 and distanza > ex_dist:
                        fast1 = 0.5
                        fast2 = 0.6
                        cnt4 += 1
                        if cnt4 > 2:
                            fast1 = 0.5
                            fast2 = 0.75
                        cnt1 = 0
                        cnt2 = 0
                        cnt3 = 0
                    else:
                        fast1 = 0.5
                        fast2 = 0.5
                        cnt1 = 0
                        cnt2 = 0
                        cnt3 = 0
                        cnt4 = 0
                    ex_dist = distanza
                    #print('velocità:', fast1, fast2)
                    motor.avanti_stanza(fast1, fast2)


    #model_silver = YOLO("silver_e150.pt")



    x_verde = 200
    y_verde = 160
    deltaG = 50
    deltaGx = 90

    y_max = 600
    cxa = centroX
    cxb = None
    lastcx = None
    lastcy = None

    ex_centrox = 0

    cntgrigi = 1
    primogrigio = time.time()
    secondogrigio = 0

    cnt_non_nero = 0
    stato = 'pid'
    presenza_incrocio = False

    exareapiccolo2 = 1000000
    exareapiccolo = 1000000
    areapiccolo = 1000000
    exareagrande2 = 1000000
    exareagrande = 1000000
    areagrande = 1000000
    time_stanza = -30
    cnt_giu = 0
    cnt_stanza = 0

    while True:
       
        roll = robot.get_angles()[0] #altalena
        #print('roll', roll, roll - ex_roll)
        media = 0.2*(ex_roll  + ex_roll2 + ex_roll3 + ex_roll4 + ex_roll5)
        if roll - ex_roll > 20 and   stato == 'pid' and media < -14 and roll >= 0:
            print('|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||')
            motor.stop()
            motor.indietrocm(2)
            time.sleep(0.5)
            if robot.get_angles()[0] > 0:
                motor.indietrocm(8)
            time.sleep(0.1)

        ex_roll5 = ex_roll4
        ex_roll4 = ex_roll3
        ex_roll3 = ex_roll2
        ex_roll2 = ex_roll
        ex_roll = roll
        stato = 'pid'

        frame = picam2.capture_array("lores")
        # frame = cv2.flip(frame, -1)
        
        contoursB = findContourn("black", [0, int(high * pBlack)], [0])

        contoursBtot = findContourn("black", [0], [0])

        contoursR = findContourn("red", [0], [int(base/8), int(base*7/8)])

        contoursG = findContourn("green", [0], [0])

        contoursGray = findContourn("gray", [0, int(3*high//4)],[0])

        contoursCenter = findContourn('black', [100, high], [100, base-100])

        contoursBase = findContourn('blacks', [high - 50, high], [0, base])
                   

        cv2.line(frame, (150, 100), (base-150, 100), (0, 0, 0), 1) #linee
        cv2.line(frame, (150, 100), (150, high-135), (0, 0, 0), 1)
        cv2.line(frame, (base-150, 100), (base-150, high-135), (0, 0, 0), 1)
        cv2.line(frame, (0, int(high * pBlack)), (base, int(high * pBlack)), (50, 0, 50), 1)


        if contoursR and abs(robot.get_angles()[0]) < 4:
            draw_contourn(contoursR,(0,255,0))
            main_contourR = max(contoursR, key=cv2.contourArea)

            area = cv2.contourArea(main_contourR)
            if area > 90000:
                print('ROSSO')
                with open("contasfere_lack.txt", "w") as file:
                    file.write("0 0 0")
                draw_contourn(contoursR, (255, 255, 255))
                motor.avanticm(7)
                led_strip.fine()
                motor.stop()
                time.sleep(10)
                led_strip.set_leds((1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1), (255, 255, 130), 255)

        is_detected, frame_anteprima = detector.check_object(frame, show_preview=True)


        if is_detected and time.time() - time_stanza > 3 and cnt_stanza == 0:
            roll, pitch, _ = robot.get_angles()
            
            if abs(roll) < 5 and abs(pitch) < 5:
                motor.stop()
                led_mask = tuple([0] * 32)
                led_strip.set_leds(led_mask, (255, 255, 130), 255)
                _, _, yaw = robot.get_angles()
                tempo_ingresso_inizio = time.time()
                while time.time() - tempo_ingresso_inizio < 1.5:
                    _, _, yaw1 = robot.get_angles()
                    motor.avanti(0.5)
                    if bottone_dx.is_pressed:
                        tempo_bonus = time.time()
                        motor.indietrocm(3)
                        girosx(7, 0.6)
                        motor.avanticm(3)
                        tempo_ingresso_inizio += time.time() - tempo_bonus
                        _, _, yaw = robot.get_angles()

                    elif bottone_sx.is_pressed:
                        tempo_bonus = time.time()
                        motor.indietrocm(3)
                        girodx(7, 0.6)
                        motor.avanticm(3)
                        tempo_ingresso_inizio += time.time() - tempo_bonus
                        _, _, yaw = robot.get_angles()

                    elif yaw1 - yaw > 8:
                        tempo_bonus = time.time()
                        motor.indietrocm(3)
                        girodx(23, 0.5)
                        motor.avanticm_verde(5, 0.5, 0.5)
                        tempo_ingresso_inizio += time.time() - tempo_bonus
                        _, _, yaw = robot.get_angles()

                    elif yaw1 - yaw <  -8:
                        tempo_bonus = time.time()
                        motor.indietrocm(3)
                        girosx(23, 0.5)
                        motor.avanticm_verde(5, 0.5, 0.5)
                        tempo_ingresso_inizio += time.time() - tempo_bonus
                        _, _, yaw = robot.get_angles()
                    print('yaww', yaw1 - yaw)

                motor.stop()
                time.sleep(2)
                cnt_stanza += 1
                main_stanza()
                

                led_mask = tuple([1] * 32)
                led_strip.set_leds(led_mask, (255, 255, 130), 255)
                time.sleep(0.2)
                for _ in range(10):
                    frame = picam2.capture_array("lores")
            # frame = cv2.flip(frame, -1)
                contoursB = findContourn("black", [0, int(high * pBlack)], [0])
                contoursBtot = findContourn("black", [0], [0])
                contoursR = findContourn("red", [0], [int(base/8), int(base*7/8)])
                contoursG = findContourn("green", [0], [0])
                contoursGray = findContourn("gray", [0, int(3*high//4)],[0])
                contoursCenter = findContourn('black', [100, high], [100, base-100])
                contoursBase = findContourn('blacks', [high - 50, high], [0, base])
                is_detected, frame_anteprima = detector.check_object(frame, show_preview=True)

        if contoursBase:
            main_contoursBase = max(contoursBase, key=cv2.contourArea)
            areabase = cv2.contourArea(main_contoursBase)
            draw_contourn(main_contoursBase, (255, 0 , 0))
            #print('area_base 1', areabase)
            centro_nuovo = 100000000
            centro, _ = findCenter(main_contoursBase)
            
            if contoursB:
                main_contourb = max(contoursB, key=cv2.contourArea)
                xalto, yalto = tuple(main_contourb[main_contourb[:, :, 1].argmin()][0])
                if areabase > 5000: 
                    my_list = list(contoursBase)
                    new_list = [
                        arr for arr in my_list if not np.array_equal(arr, main_contoursBase)
                    ]
                    contoursBase2 = tuple(new_list)
                    if contoursBase2:
                        main_contoursBase2 = max(contoursBase2, key=cv2.contourArea)
                        #draw_contourn(main_contoursBase2, (0, 255 , 255))
                        areabase2 = cv2.contourArea(main_contoursBase2)
                        #print('area_base 1', areabase)
                        if areabase2 > 5000:
                            #motor.stop()
                            centro_nuovo, _ = findCenter(main_contoursBase2)
                            centro_finale = centro + centro_nuovo - ex_centrox
                            #cv2.imshow("frame", frame)
                            #if cv2.waitKey(1) & 0xFF == ord("q"):
                            #    break
                            #time.sleep(0.2)
                            #print('doppio nero, girone')
                            
                            #print('centro_vero', ex_centrox, 'centro_teoricamente centro', centro, 'centro_nuovo', centro_nuovo)
                            if yalto > 100:
                                motor.stop()
                                print('dooppio nero')
                                roll, pitch, yaw = robot.get_angles()
                                if roll < -10:
                                    motor.avanticm(7)

                                if centro_finale < ex_centrox:
                                    if roll < -10:
                                        girosx(20, 0.7)
                                        motor.avanticm(2)
                                        motor.stop()
                                        time.sleep(0.3)
                                        frame = picam2.capture_array("lores")
                                        contoursB_doppio = findContourn("black", [high//2, high], [0])
                                        if contoursB_doppio:
                                            main_contoursB_doppio = max(contoursB_doppio, key=cv2.contourArea)
                                            area_doppio = cv2.contourArea(main_contoursB_doppio)
                                            if area_doppio < 1.5*area_min:
                                                girodx(10, 0.7)
                                    else:
                                        girosx(60, 0.7)
                                        motor.avanticm(2)
                                        motor.stop()
                                        time.sleep(0.3)
                                        frame = picam2.capture_array("lores")
                                        contoursB_doppio = findContourn("black", [high//2, high], [0])
                                        if contoursB_doppio:
                                            main_contoursB_doppio = max(contoursB_doppio, key=cv2.contourArea)
                                            area_doppio = cv2.contourArea(main_contoursB_doppio)
                                            if area_doppio < 1.5*area_min:
                                                girodx(30, 0.7)
                                else:
                                    if roll < -10:
                                        girodx(20, 0.7)
                                        motor.avanticm(2)
                                        motor.stop()
                                        time.sleep(0.3)
                                        frame = picam2.capture_array("lores")
                                        contoursB_doppio = findContourn("black", [high//2, high], [0])
                                        if contoursB_doppio:
                                            main_contoursB_doppio = max(contoursB_doppio, key=cv2.contourArea)
                                            area_doppio = cv2.contourArea(main_contoursB_doppio)
                                            if area_doppio < 1.5*area_min:
                                                girosx(10, 0.7)
                                    else:
                                        girodx(60, 0.7)
                                        motor.avanticm(2)
                                        motor.stop()
                                        time.sleep(0.3)
                                        frame = picam2.capture_array("lores")
                                        contoursB_doppio = findContourn("black", [high//2, high], [0])
                                        if contoursB_doppio:
                                            main_contoursB_doppio = max(contoursB_doppio, key=cv2.contourArea)
                                            area_doppio = cv2.contourArea(main_contoursB_doppio)
                                            if area_doppio < 1.5*area_min:
                                                girosx(30, 0.7)
                            
                                motor.stop()
                                time.sleep(0.2)

                                frame = picam2.capture_array("lores")
                                contoursB = findContourn("black", [high//2, high], [0])
                                contoursBtot = findContourn("black", [0], [0])
                                contoursR = findContourn("red", [0], [int(base/8), int(base*7/8)])
                                contoursG = findContourn("green", [0], [0])
                                contoursGray = findContourn("gray", [0, int(3*high//4)],[0])
                                contoursCenter = findContourn('black', [100, high], [100, base-100])
                                contoursBase = findContourn('blacks', [int(high * pBlack - 50), int(high * pBlack)], [0, base])

            if abs(centro - ex_centrox) < abs(centro_nuovo - ex_centrox):
                ex_centrox = centro
            else:
                ex_centrox = centro_nuovo




        if contoursGray and abs(roll < 8) and False:
            draw_contourn(contoursGray, (255, 0, 0))
            main_contourGray = max(contoursGray, key=cv2.contourArea)

            area = cv2.contourArea(main_contourGray)
            print('area argento', area)
            if area > 30000: 
                motor.stop()
                time.sleep(0.1)
                motor.indietrocm(1.3)
                print('STANZA?' , area)
                time.sleep(1.1)
                frame = picam2.capture_array("lores")
                contoursGray = findContourn("gray", [0, int(3*high // 4)],[0])
                #cv2.imshow("frame", frame)
                if (contoursGray and robot.get_angles()[0] > -4) or cntgrigi >= 3:
                    main_contourGray = max(contoursGray, key=cv2.contourArea)
                    area = cv2.contourArea(main_contourGray)
                    print(area)
                    if area > 20000 or cntgrigi >= 3:
                        print('stanza')
                        #motor.avanticm(20)
                        led_mask = tuple([0] * 32)
                        led_strip.set_leds(led_mask, (255, 255, 130), 255)
                        time.sleep(1)
                        led_mask = tuple([1] * 32)
                        led_strip.set_leds(led_mask, (255, 255, 130), 255)
                        main_stanza() #----->>>>> codice stanza 
                        motor.stop()
                        frame = picam2.capture_array("lores")
                        contoursB = findContourn("black", [0, int(high * pBlack)], [0])
                        contoursBtot = findContourn("black", [0], [0])
                        contoursR = findContourn("red", [int(high/5), int(high * 4 / 5)], [int(base/4), int(base*3/4)])
                        contoursG = findContourn("green", [0], [0])
                        contoursGray = findContourn("gray", [0, int(3*high//4)],[0])
                        
                    else:
                        secondogrigio = time.time()
                        if secondogrigio - primogrigio < 10:
                            cntgrigi += 1
                        else:
                            cntgrigi = 1
                        primogrigio = secondogrigio
                        motor.indietrocm(5)     

                elif robot.get_angles()[0] > -4:
                    secondogrigio = time.time()
                    if secondogrigio - primogrigio < 15:
                        cntgrigi += 1
                    else:
                        cntgrigi = 1
                    primogrigio = secondogrigio
                    motor.indietrocm(4)

        if contoursBtot:
            main_contourbtot = max(contoursBtot, key=cv2.contourArea)

        if contoursB:
            main_contourb = max(contoursB, key=cv2.contourArea)
            #print(cv2.contourArea(main_contourb))
            draw_contourn(contoursB, (255, 0, 0))
            if contoursBtot:
                
                #print(cv2.contourArea(main_contourbtot))
                cxb, cyb = findCenter(main_contourb)
                if cxb is not None:
                    cnt_non_nero = 0
                    lastcx = cxb
                    lastcy = cyb
                    contoursTop = findContourn('black', [100, 150], [150, base-150])
                    draw_contourn(contoursTop,(255, 0, 0))

                    contoursRight = findContourn('black', [100, high-50], [base-150, base-135])
                    draw_contourn(contoursRight,(0, 255, 0))

                    contoursLeft = findContourn('black', [100, high-50], [150,165])
                    draw_contourn(contoursLeft,(0, 0, 255))

                    contoursBottom = findContourn('black', [int(high * pBlack), high], [0])
                    cv2.circle(frame, (cxb, cyb), 5, (0, 255, 0), -1)
                    #roll, _, _ = robot.get_angles()
                    #print('roll',roll)

                    if roll < 5: #7
                        cnt_giu = 0
                        PID(cxb, centroX, cyb)

                    else:
                        cnt_giu += 1
                        PID_giu(cxb, centroX, cyb, cnt_giu)

                    if contoursBottom:
                        main_contourBot = max(contoursBottom, key=cv2.contourArea)
                        
                        exareapiccolo2 = exareapiccolo
                        exareapiccolo = areapiccolo
                        areapiccolo = cv2.contourArea(main_contourb)
                        exareagrande2 = exareagrande
                        exareagrande = areagrande
                        areagrande = cv2.contourArea(main_contourBot)
                        media_piccolo = (areapiccolo + exareapiccolo + exareapiccolo2)//3
                        media_grande = (areagrande + exareagrande2 + exareagrande)//3
                        

                        if contoursCenter:
                            main_contoursCenter = max(contoursCenter, key=cv2.contourArea)
                            xxDx, _ = tuple(main_contoursCenter[main_contoursCenter[:, :, 0].argmax()][0])
                            xxSx, _ = tuple(main_contoursCenter[main_contoursCenter[:, :, 0].argmin()][0])
                            _, yyTop = tuple(main_contoursCenter[main_contoursCenter[:, :, 1].argmin()][0])
                            #print('coordinate', xxDx, xxSx, yyTop)
                            area_top = 0
                            if contoursTop:
                                main_contoursTop = max(contoursTop, key=cv2.contourArea)
                                area_top = cv2.contourArea(main_contoursTop)
                                Simone = 'ovetto kinder'
                            _, pitch, _ = robot.get_angles()

                            if (xxDx < 650 and xxSx > 10 and yyTop > 150 and area_top < 4000) or (xxSx > 10 and yyTop > 150 and area_top < 4000 and pitch > 10) or (xxDx < 650 and yyTop > 150 and area_top < 4000 and pitch < -10):
                                print('gap_aree',cv2.contourArea(main_contourb), cv2.contourArea(main_contourBot))
                                if (cv2.contourArea(main_contourb) < 45000 and cv2.contourArea(main_contourBot) < 25000 and cv2.contourArea(main_contourBot) > 1000):
                                    motor.stop()
                                    GAP(True)
                                    frame = picam2.capture_array("lores")
                                    contoursB = findContourn("black", [0, int(high * pBlack)], [0])
                                    contoursBtot = findContourn("black", [0], [0])
                                    contoursR = findContourn("red", [int(high/5), int(high * 4 / 5)], [int(base/4), int(base*3/4)])
                                    contoursG = findContourn("green", [0], [0])
                                    #contoursGray = findContourn("gray", [0, int(high * 3/4)],[0])
                                
                            #else:
                                #print('nero ai bordi')
                        
                        
                            
                else:
                    cnt_non_nero += 1
                    if cnt_non_nero > 50:
                        cnt_non_nero = 0
                        trovato_nero = False
                        time.sleep(0.5)
                        girodx(40, 0.7)
                        motor.stop()
                        time.sleep(0.1)
                        frame = picam2.capture_array("lores")
                        contoursB = findContourn("black", [0, int(high * pBlack)], [0])
                        if contoursB:
                            main_contourb = max(contoursB, key=cv2.contourArea)
                            area_nero = cv2.contourArea(main_contourb)
                            if area_nero > area_min:
                                contoursBtot = findContourn("black", [0], [0])
                                contoursR = findContourn("red", [int(high/5), int(high * 4 / 5)], [int(base/4), int(base*3/4)])
                                contoursG = findContourn("green", [0], [0])
                                trovato_nero = True
                            
                        if trovato_nero == False: 
                            girosx(80, 0.7)
                            motor.stop()
                            time.sleep(0.1)
                            frame = picam2.capture_array("lores")
                            contoursB = findContourn("black", [0, int(high * pBlack)], [0])
                            if contoursB:
                                main_contourb = max(contoursB, key=cv2.contourArea)
                                area_nero = cv2.contourArea(main_contourb)
                                if area_nero > area_min:
                                    contoursBtot = findContourn("black", [0], [0])
                                    contoursR = findContourn("red", [int(high/5), int(high * 4 / 5)], [int(base/4), int(base*3/4)])
                                    contoursG = findContourn("green", [0], [0])
                                    trovato_nero = True
                                #contoursGray = findContourn("gray", [0, int(high * 3/4)],[0])
                            if trovato_nero == False:
                                girodx(40, 0.7)
                                motor.stop()
                                frame = picam2.capture_array("lores")
                                GAP(True)
                        frame = picam2.capture_array("lores")
                        contoursB = findContourn("black", [0, int(high * pBlack)], [0])
                        contoursBtot = findContourn("black", [0], [0])
                        contoursR = findContourn("red", [int(high/5), int(high * 4 / 5)], [int(base/4), int(base*3/4)])
                        contoursG = findContourn("green", [0], [0])
            else:
                cnt_non_nero += 1
                if cnt_non_nero > 50:
                    cnt_non_nero = 0
                    trovato_nero = False
                    time.sleep(0.5)
                    girodx(40, 0.7)
                    motor.stop()
                    time.sleep(0.1)
                    frame = picam2.capture_array("lores")
                    contoursB = findContourn("black", [0, int(high * pBlack)], [0])
                    if contoursB:
                        main_contourb = max(contoursB, key=cv2.contourArea)
                        area_nero = cv2.contourArea(main_contourb)
                        if area_nero > area_min:
                            contoursBtot = findContourn("black", [0], [0])
                            contoursR = findContourn("red", [int(high/5), int(high * 4 / 5)], [int(base/4), int(base*3/4)])
                            contoursG = findContourn("green", [0], [0])
                            trovato_nero = True
                        
                    if trovato_nero == False: 
                        girosx(80, 0.7)
                        motor.stop()
                        time.sleep(0.1)
                        frame = picam2.capture_array("lores")
                        contoursB = findContourn("black", [0, int(high * pBlack)], [0])
                        if contoursB:
                            main_contourb = max(contoursB, key=cv2.contourArea)
                            area_nero = cv2.contourArea(main_contourb)
                            if area_nero > area_min:
                                contoursBtot = findContourn("black", [0], [0])
                                contoursR = findContourn("red", [int(high/5), int(high * 4 / 5)], [int(base/4), int(base*3/4)])
                                contoursG = findContourn("green", [0], [0])
                                trovato_nero = True
                            #contoursGray = findContourn("gray", [0, int(high * 3/4)],[0])
                        if trovato_nero == False:
                            girodx(40, 0.7)
                            motor.stop()
                            frame = picam2.capture_array("lores")
                            GAP(True)
                    frame = picam2.capture_array("lores")
                    contoursB = findContourn("black", [0, int(high * pBlack)], [0])
                    contoursBtot = findContourn("black", [0], [0])
                    contoursR = findContourn("red", [int(high/5), int(high * 4 / 5)], [int(base/4), int(base*3/4)])
                    contoursG = findContourn("green", [0], [0])

        else:
            cnt_non_nero += 1
            if cnt_non_nero > 50:
                cnt_non_nero = 0
                trovato_nero = False
                time.sleep(0.5)
                girodx(40, 0.7)
                motor.stop()
                time.sleep(0.1)
                frame = picam2.capture_array("lores")
                contoursB = findContourn("black", [0, int(high * pBlack)], [0])
                if contoursB:
                    main_contourb = max(contoursB, key=cv2.contourArea)
                    area_nero = cv2.contourArea(main_contourb)
                    if area_nero > area_min:
                        contoursBtot = findContourn("black", [0], [0])
                        contoursR = findContourn("red", [int(high/5), int(high * 4 / 5)], [int(base/4), int(base*3/4)])
                        contoursG = findContourn("green", [0], [0])
                        trovato_nero = True
                    
                if trovato_nero == False: 
                    girosx(80, 0.7)
                    motor.stop()
                    time.sleep(0.1)
                    frame = picam2.capture_array("lores")
                    contoursB = findContourn("black", [0, int(high * pBlack)], [0])
                    if contoursB:
                        main_contourb = max(contoursB, key=cv2.contourArea)
                        area_nero = cv2.contourArea(main_contourb)
                        if area_nero > area_min:
                            contoursBtot = findContourn("black", [0], [0])
                            contoursR = findContourn("red", [int(high/5), int(high * 4 / 5)], [int(base/4), int(base*3/4)])
                            contoursG = findContourn("green", [0], [0])
                            trovato_nero = True
                        #contoursGray = findContourn("gray", [0, int(high * 3/4)],[0])
                    if trovato_nero == False:
                        girodx(40, 0.7)
                        motor.stop()
                        frame = picam2.capture_array("lores")
                        GAP(True)
                frame = picam2.capture_array("lores")
                contoursB = findContourn("black", [0, int(high * pBlack)], [0])
                contoursBtot = findContourn("black", [0], [0])
                contoursR = findContourn("red", [int(high/5), int(high * 4 / 5)], [int(base/4), int(base*3/4)])
                contoursG = findContourn("green", [0], [0])

        direction = 'cazzi tuoi'
        if contoursG: #controllare con verdi di tonalità diversa
            direction = "cazzi tuoi"
            main_contourG = max(contoursG, key=cv2.contourArea)

            area = cv2.contourArea(main_contourG)
            roll, pitch, yaw = robot.get_angles()

            if pitch > 10 and area > area_min:
                girodx(30, 0.5)
                motor.avanticm(8.5)
                girosolosx(60, 0.4)
                motor.indietrocm_verde(10, 0.6, 0.8)
                frame = picam2.capture_array("lores")
                contoursB = findContourn("black", [0, int(high * pBlack)], [0])
                contoursBtot = findContourn("black", [0], [0])
                contoursR = findContourn("red", [int(high/5), int(high * 4 / 5)], [int(base/4), int(base*3/4)])
                contoursG = findContourn("green", [0], [0])
                if contoursG: #controllare con verdi di tonalità diversa
                    direction = "cazzi tuoi"
                    main_contourG = max(contoursG, key=cv2.contourArea)

                    area = cv2.contourArea(main_contourG)
                    roll, pitch, yaw = robot.get_angles()
                #cv2.imshow("frame", frame)
                #if cv2.waitKey(1) & 0xFF == ord("q"):
                    #break
                time.sleep(2)

            elif pitch < -10 and area > area_min:
                girosx(30, 0.5)
                motor.avanticm(9)
                girosolodx(60, 0.4)
                motor.indietrocm_verde(10, 0.6, 0.8)
                girosolosx_verde(15, 0.1, 0.6)
                frame = picam2.capture_array("lores")
                contoursB = findContourn("black", [0, int(high * pBlack)], [0])
                contoursBtot = findContourn("black", [0], [0])
                contoursR = findContourn("red", [int(high/5), int(high * 4 / 5)], [int(base/4), int(base*3/4)])
                contoursG = findContourn("green", [0], [0])
                if contoursG: #controllare con verdi di tonalità diversa
                    direction = "cazzi tuoi"
                    main_contourG = max(contoursG, key=cv2.contourArea)

                    area = cv2.contourArea(main_contourG)
                    roll, pitch, yaw = robot.get_angles()

                #cv2.imshow("frame", frame)
                #if cv2.waitKey(1) & 0xFF == ord("q"):
                   # break
                time.sleep(2)


            if area > area_min and contoursG:
                draw_contourn(main_contourG, (0, 255, 255))
                cxg, cyg = findCenter(main_contourG)
                if (cxg is not None and cyg > 125 and cxg < 6*base//7 and cxg > base//7) or (cxg is not None and cyg > 125 and abs(pitch) > 10) :
                    motor.stop()
                    cv2.circle(frame, (cxg, cyg), 5, (0, 255, 255), -1)

                    xDx, yDx = tuple(main_contourG[main_contourG[:, :, 0].argmax()][0])
                    xSx, ySx = tuple(main_contourG[main_contourG[:, :, 0].argmin()][0])
                    xBot, yBot = tuple(main_contourG[main_contourG[:, :, 1].argmax()][0])

                    cv2.circle(frame, (xDx + deltaG, cyg), 5, (0, 255, 255), -1)
                    cv2.circle(frame, (xSx - deltaG, cyg), 5, (0, 255, 255), -1)
                    cv2.circle(frame, (cxg + deltaGx, yBot + deltaG), 5, (0, 255, 255), -1)
                    cv2.circle(frame, (cxg - deltaGx, yBot + deltaG), 5, (0, 255, 255), -1)
                    
                    #frame = cv2.resize(frame, (base, high))
                    #cv2.imshow("frame", frame)
                   # if cv2.waitKey(1) & 0xFF == ord("q"):
                        #break
                    #time.sleep(2)

                    h1 = cv2.pointPolygonTest(
                        main_contourbtot, (cxg - deltaGx, int(yBot + deltaG)), False
                    )
                    h2 = cv2.pointPolygonTest(
                        main_contourbtot, (cxg + deltaGx, int(yBot + deltaG)), False
                    )
                    if (yBot + deltaG) >= y_max:
                        print('troppo basso', yBot + deltaG, y_max)

                    if (h1 == -1 or h2 == -1) and (yBot + deltaG) < y_max:
                        my_list = list(contoursG)
                        new_list = [
                            arr for arr in my_list if not np.array_equal(arr, main_contourG)
                        ]
                        contours2 = tuple(new_list)
                        if contours2:
                            main_contourG2 = max(contours2, key=cv2.contourArea)
                            area = cv2.contourArea(main_contourG2)
                            if area > area_min2:
                                print('DOPPIO', area, area_min2)
                            else:
                                print('SINGOLO', area, area_min2)
                            if area > area_min2:
                                draw_contourn(main_contourG2, (0, 255, 255))
                                cxg2, cyg2 = findCenter(main_contourG2)
                                if cyg2 is not None:
                                    print('DIF', cyg2 - cyg)
                                    roll, pitch, yaw = robot.get_angles()
                                    if (abs(cyg2 - cyg) < 100 and abs(pitch) < 10) or (abs(cyg2 - cyg) < 120 and abs(pitch)>= 10):
                                        cv2.circle(frame, (cxg2, cyg2), 5, (0, 255, 255), -1)
                                        if abs(pitch) < 13:
                                            motor.avanticm(4)
                                        #led_strip.set_leds((1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1), (0, 255, 0), 255)
                                        motor.stop()
                                        time.sleep(0.5)
                                        roll, pitch, yaw = robot.get_angles()
                                        print('2verde', roll, pitch, yaw)
                                        if roll < -13:
                                            motor.avanticm(12)
                                            girosx_salita(170, 0.4, 0.8)
                                            motor.indietrocm(10)

                                        elif roll > 13:
                                            motor.indietrocm(10)
                                            girosx(170, 0.7)
                                            motor.avanticm(10)
                                        
                                        elif pitch < -13:
                                            #motor.avanticm(1)
                                            girosolosx_verde(140, 0.7, 0.1)
                                            motor.indietrocm(4)

                                        elif pitch > 13:
                                            #motor.avanticm(1)
                                            girosolodx_verde(140, 0.7, 0.1)
                                            motor.indietrocm(4)

                                        else:
                                            girosx(170, 0.7)
                                            motor.indietrocm(1.3)

                                        motor.stop()
                                        #led_strip.set_leds((1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1), (255, 255, 130), 255)
                                        print("VERDE: indietro")
                                        direction = "indietro"
                                        stato = 'verde'

                        if direction != "indietro":
                            sx = cv2.pointPolygonTest(
                                main_contourbtot, (int(xSx - deltaG), cyg), False
                            )
                            dx = cv2.pointPolygonTest(
                                main_contourbtot, (int(xDx + deltaG), cyg), False
                            )

                        
                            motor.stop()

                            motor.avanticm(3.1)   # HO CAMBIATO QUESTO
                            
                            if dx == -1:
                                motor.stop()
                                time.sleep(0.5)
                                roll, pitch, yaw = robot.get_angles()
                                
                                if roll < -15:
                                    motor.avanticm(10)
                                    girosolodx_verde(80, 0.7, 0.2)
                                    motor.indietrocm(6)
                                elif roll > 15:
                                    motor.indietrocm(11)
                                    girosolodx_verde(80, 0.7, 0.2)
                                    motor.indietrocm(6)
                                elif pitch < -13:
                                    girosolodx_verde(80, 0.7, 0.2)
                                    motor.indietrocm(11)
                                elif pitch > 13:
                                    girosolodx_verde(80, 0.7, 0.2)
                                    motor.avanticm(2)
                                else:
                                    motor.avanticm(3)
                                    frame = picam2.capture_array("lores")
                                    contoursB_green = findContourn("black", [0, int(high * 0.5)], [0])
                                    
                                    x_max = 0
                                    time_inizio_verde = time.time()
                                    finito = 'tutto_apposto'
                                    while x_max < base - 10:
                                        if time.time() - time_inizio_verde > 1.3:
                                            motor.stop()
                                            finito = 'raddrizzato'
                                            girosx(40, 0.7)
                                            break
                                        frame = picam2.capture_array("lores")
                                        contoursB_green = findContourn("black", [0, int(high * 0.5)], [0])
                                        if contoursB_green:
                                            main_contoursB_green = max(contoursB_green, key=cv2.contourArea)
                                            areaa = cv2.contourArea(main_contoursB_green)
                                            if areaa > area_min:
                                                x_max, _ = tuple(main_contoursB_green[main_contoursB_green[:, :, 0].argmax()][0])
                                        motor.right(0.7)

                                        #cv2.imshow("frame", frame)
                                        #if cv2.waitKey(1) & 0xFF == ord("q"):
                                           # break

                                    if finito == 'tutto_apposto':
                                        girodx(30, 0.7)

                                        cx_green = base

                                        while cx_green > 3.2*base//5:
                                            frame = picam2.capture_array("lores")
                                            contoursB_green = findContourn("black", [0, int(high * 0.5)], [0])
                                            if contoursB_green:
                                                main_contoursB_green = max(contoursB_green, key=cv2.contourArea)
                                                areaa = cv2.contourArea(main_contoursB_green)
                                                if areaa > area_min:
                                                    cx_green, _ = findCenter(main_contoursB_green)
                                            motor.right(0.7)

                                            #cv2.imshow("frame", frame)
                                            #if cv2.waitKey(1) & 0xFF == ord("q"):
                                                #break

                                    motor.stop()

                                    
                                print('VERDE: dx')
                                stato = 'verde'
                                frame = picam2.capture_array("lores")
                                contoursGr = findContourn("black", [0, int(high*pBlack)], [0])

                                if contoursGr:
                                    main_contourGr = max(contoursGr, key=cv2.contourArea)
                                    area = cv2.contourArea(main_contourGr)
                                    cxGr, _ = findCenter(main_contourGr)
                                    if cxGr <= base/4 or cxGr is None or area < area_min:
                                        girosx(35,0.7)
                                else:
                                    girosx(35,0.7)
                            else:

                                motor.stop()
                                time.sleep(0.5)
                                roll, pitch, yaw = robot.get_angles()

                                if roll < -15:
                                    motor.avanticm(10)
                                    girosolosx_verde(80, 0.7, 0.2)
                                    motor.indietrocm(6)
                                elif roll > 15:
                                    motor.indietrocm(11)
                                    girosolosx_verde(80, 0.7, 0.2) 
                                    motor.indietrocm(6)
                                elif pitch < -13:
                                    girosolosx_verde(80, 0.7, 0.2)
                                    motor.avanticm(7)
                                elif pitch > 13:
                                    girosolosx_verde(80, 0.7, 0.2)
                                    motor.indietrocm(13)
                                else:
                                    motor.avanticm(3) #girosx(70, 0.7)
                                    frame = picam2.capture_array("lores")
                                    contoursB_green = findContourn("black", [0, int(high * 0.5)], [0])
                                    
                                    x_max = base
                                    time_inizio_verde = time.time()
                                    finito = 'tutto_apposto'
                                    while x_max > 10:
                                        print('time', time.time() - time_inizio_verde)
                                        if time.time() - time_inizio_verde > 1.3:
                                            motor.stop()
                                            finito = 'raddrizzato'
                                            girodx(40, 0.7)
                                            break
                                        frame = picam2.capture_array("lores")
                                        contoursB_green = findContourn("black", [0, int(high * 0.5)], [0])
                                        if contoursB_green:
                                            main_contoursB_green = max(contoursB_green, key=cv2.contourArea)
                                            areaa = cv2.contourArea(main_contoursB_green)
                                            if areaa > area_min:
                                                x_max, _ = tuple(main_contoursB_green[main_contoursB_green[:, :, 0].argmin()][0])
                                        motor.left(0.7)

                                        #cv2.imshow("frame", frame)
                                        #if cv2.waitKey(1) & 0xFF == ord("q"):
                                           # break

                                    if finito == 'tutto_apposto':
                                        girosx(30, 0.7)

                                        cx_green = base

                                        while cx_green < 1.8*base//5:
                                            frame = picam2.capture_array("lores")
                                            contoursB_green = findContourn("black", [0, int(high * 0.5)], [0])
                                            if contoursB_green:
                                                main_contoursB_green = max(contoursB_green, key=cv2.contourArea)
                                                areaa = cv2.contourArea(main_contoursB_green)
                                                if areaa > area_min:
                                                    cx_green, _ = findCenter(main_contoursB_green)
                                            motor.left(0.7)

                                            #cv2.imshow("frame", frame)
                                            #if cv2.waitKey(1) & 0xFF == ord("q"):
                                               # break

                                    motor.stop()
                                print('VERDE: sx')
                                stato = 'verde'

                                frame = picam2.capture_array("lores")
                                contoursGr = findContourn("black", [0, int(high*pBlack)], [0])
                                if contoursGr:
                                    main_contourGr = max(contoursGr, key=cv2.contourArea)
                                    area = cv2.contourArea(main_contourGr)
                                    cxGr, _ = findCenter(main_contourGr)
                                    if cxGr >= 3*base/4 or cxGr is None or area < area_min:
                                        girodx(35,0.7)
                                else:
                                    girodx(35,0.7)

                            
                            motor.stop()
                    else:
                        if cxg < base//8:
                            girosx(15, 0.7)
                        elif cxg > 7*base//8:
                            girodx(15, 0.7)

                        print('VERDE: avanti')
                        stato = 'verde'
                        motor.stop()
                        time.sleep(0.5)
                        roll, pitch, yaw = robot.get_angles()
                        if roll < -15:
                            motor.avanticm(7)
                        elif roll > 15:
                            motor.avanticm(4)
                        if pitch < -13:
                            motor.avanticm_verde(6, 0.4, 0.7)
                        elif pitch > 13:
                            motor.avanticm_verde(6, 0.7, 0.4)
                        else:
                            motor.avanticm(6)
                        frame = picam2.capture_array("lores")
                        contoursbl = findContourn("black", [int(high * pBlack)], [0])
                        if contoursbl:
                            main_contourbl = max(contoursbl, key=cv2.contourArea)
                            cxbl, cybl = findCenter(main_contourbl)
                            #print(abs(cxbl - base/2))
                            if cxbl - base/2 > 250:
                                girodx(15, 0.7)
                            elif cxbl - base/2 < -250:
                                girosx(15, 0.7)

                elif (cxg is not None and cxg >= 6*base//7):
                    motor.stop()
                    xBot, yBot = tuple(main_contourG[main_contourG[:, :, 1].argmax()][0])
                    h1 = cv2.pointPolygonTest(
                        main_contourbtot, (cxg - deltaGx, int(yBot + deltaG)), False
                    )
                    h2 = cv2.pointPolygonTest(
                        main_contourbtot, (cxg + deltaGx, int(yBot + deltaG)), False
                    )
                    if (h1 == -1 or h2 == -1) and (yBot + deltaG) < y_max:
                        deltax = -20
                        print('verde troppo destra')
                        frame = picam2.capture_array("lores")
                        contoursG = findContourn("green", [0], [0])
                        if contoursG:
                            main_contourG = max(contoursG, key=cv2.contourArea)
                            xBot, yBot = tuple(main_contourG[main_contourG[:, :, 1].argmax()][0])


                            contoursB1 = findContourn("black", [max(yBot+deltax,0), min(yBot+deltax+40, high)], [0])
                            if contoursB1:
                                main_contoursB1 = max(contoursB1, key=cv2.contourArea)
                                cxb1, cyb1 = findCenter(main_contoursB1)
                                if cxb1:
                                    contoursB2 = findContourn("black", [min(yBot+deltax+40, high-1), min(yBot+deltax+80, high)], [0])
                                    if contoursB2:
                                        main_contoursB2 = max(contoursB2, key=cv2.contourArea)
                                        cxb2, cyb2 = findCenter(main_contoursB2)
                                        dy = cyb2 + xBot + 20 - (cyb1 + xBot - 20)
                                        dx = cxb2 - cxb1
                                        angolo_radianti = math.atan2(dy, dx)
                                        angolo_gradi = math.degrees(angolo_radianti)
                                        angolo_gradi = angolo_gradi - 90
                                        motor.avanticm(8)
                                        print('ang', angolo_gradi)
                                        girodx(abs(angolo_gradi//1.6), 0.7)
                                        motor.indietrocm(9)


                                    else:
                                        print('fanculo')
                                
                                else:
                                    print('non cè centro')
                                    break
                            else:
                                print('non cè verde')
                                break
                        else:
                            print('non cè verde')
                    else:
                        motor.avanticm(6)
                        print('verde fuori dalle soglie')
                    
                    motor.stop()
                    stato = 'verde'

                elif (cxg is not None and cxg <= base//7):
                    motor.stop()
                    xBot, yBot = tuple(main_contourG[main_contourG[:, :, 1].argmax()][0])
                    h1 = cv2.pointPolygonTest(
                        main_contourbtot, (cxg - deltaGx, int(yBot + deltaG)), False
                    )
                    h2 = cv2.pointPolygonTest(
                        main_contourbtot, (cxg + deltaGx, int(yBot + deltaG)), False
                    )
                    if (h1 == -1 or h2 == -1) and (yBot + deltaG) < y_max:
                        print('verde troppo sinistra')
                        frame = picam2.capture_array("lores")
                        contoursG = findContourn("green", [0], [0])
                        if contoursG:
                            main_contourG = max(contoursG, key=cv2.contourArea)
                            xBot, yBot = tuple(main_contourG[main_contourG[:, :, 1].argmax()][0])


                            contoursB1 = findContourn("black", [max(yBot-20,0), min(yBot+20, high)], [0])
                            if contoursB1:
                                main_contoursB1 = max(contoursB1, key=cv2.contourArea)
                                cxb1, cyb1 = findCenter(main_contoursB1)
                                if cxb1:
                                    contoursB2 = findContourn("black", [min(yBot+20, high-1), min(yBot+60, high)], [0])
                                    if contoursB2:
                                        main_contoursB2 = max(contoursB2, key=cv2.contourArea)
                                        cxb2, cyb2 = findCenter(main_contoursB2)
                                        
                                        dy = cyb2 + xBot + 20 - (cyb1 + xBot - 20)
                                        dx = cxb2 - cxb1
                                        angolo_radianti = math.atan2(dy, dx)
                                        angolo_gradi = math.degrees(angolo_radianti)
                                        angolo_gradi = 90 - angolo_gradi
                                        print('ang', angolo_gradi)
                                        motor.stop()
                                        cv2.circle(frame, (cxb2, cyb2+xBot + 20), 2, (255, 255, 0), 2)
                                        cv2.circle(frame, (cxb1, cyb1+xBot - 20), 2, (255, 255, 0), 2)
                                        #cv2.imshow("frame", frame)
                                       # if cv2.waitKey(1) & 0xFF == ord("q"):
                                            #break
                                        time.sleep(0.1)
                                        motor.avanticm(8)
                                        girosx(abs(angolo_gradi//1.6), 0.7)
                                        motor.indietrocm(9)


                                    else:
                                        print('fanculo')
                                
                                else:
                                    print('non cè centro')
                                    break
                            else:
                                print('non cè verde')
                                break
                        else:
                            print('non cè verde3')
                    else:
                        motor.avanticm(6)
                        print('verde fuori soglia')
                    
                    motor.stop()
                    stato = 'verde'
                

        distance = robot.get_distance_sopra()
        #print('distanza', distance)

        if distance < 70 and distance != 0:
            distance = robot.get_distance_sopra()
            if distance < 70 and distance != 0:
                motor.stop()
                time.sleep(0.2)
                
                for _ in range(10):
                    distance = robot.get_distance_sopra()

                while distance == 0:
                    distance = robot.get_distance_sopra()
                    motor.indietro(0.2)

                motor.stop()
                time.sleep(0.1)

                if distance < 70 and distance != 0:
                    time.sleep(0.2)
                    for _ in range(10):
                        distance = robot.get_distance_sopra()

                    while distance == 0:
                        distance = robot.get_distance_sopra()
                        motor.indietro(0.2)

                    motor.stop()
                    time.sleep(0.1)

                    if distance < 70 and distance != 0:
                        distanza_des = robot.get_distance_destra()
                        distanza_sin = robot.get_distance_lat()
                        if distanza_sin < 300:
                            girostacolodx()
                        elif distanza_des < 300:
                            girostacolo()
                        else:
                            roll, pitch, yaw = robot.get_angles()
                            if pitch > 10:
                                girostacolodx()
                            elif pitch < -10:
                                girostacolo()
                            else:
                                girostacolo()
                        
                        fine_ostacolo()
                
        


        cv2.circle(frame, (centroX, int(high * pBlack * 0.55)), 2, (255, 255, 0), 2)
        cv2.circle(frame, (centroX, int(high * pBlack * 0.55)+80), 2, (255, 255, 0), 2)
        cv2.putText(
            frame, "PID", (25, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2, cv2.LINE_AA
        )
        #cv2.imshow("frame", frame)

        #if cv2.waitKey(1) & 0xFF == ord("q"):
            #break

    cv2.destroyAllWindows()

except Exception as e:
    print("--- Error Details ---")
    stdout.write_log(e)
    traceback.print_exc()
    motor.cleanup()

finally:
    motor.cleanup()