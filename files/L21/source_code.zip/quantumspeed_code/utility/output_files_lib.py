"""Library to interface with standard output files"""

from datetime import datetime
import pathlib

class Output_Files_Writer(object):
    
    def __init__(self, name: str):
        self.Tm = datetime.now().strftime("%Y%m%d %H%M%S%f")
        self.script_dir = pathlib.Path(__file__).parent
        self.file_path = None
        self.name = name
        self.CONSOLE_PRINT = True

    
    def create_file(self):
        self.file_path = self.script_dir / "output_files" / f"{self.Tm}{self.name}.txt"
        self.file_path.parent.mkdir(parents=True, exist_ok=True)

        with open(self.file_path, "w") as std:
            std.write(f"{self.name}_output_file_created\n")

    def write_log(self, message: str):
        if self.CONSOLE_PRINT == True:
            print(message)
        with open(self.file_path, "a") as std:
            tmp = datetime.now().strftime("%Y%m%d %H:%M:%S.%f")
            std.write(f"{tmp} --->>> {message}\n")

if __name__ == "__main__": 
    stdout = Output_Files_Writer("_stdout")
    stdout.create_file()
    stdout.write_log("Hello in stdout")

    stderr = Output_Files_Writer("_stderr")
    stderr.create_file()
    stderr.write_log("Hello in stderr")