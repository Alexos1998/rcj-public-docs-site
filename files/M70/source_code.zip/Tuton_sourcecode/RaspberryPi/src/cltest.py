from mazeUtils import mazeMap
from mazeUtils import moveTile
from mazeUtils.device import deviceConstraints, stm
from mazeUtils.device import LiDAR
from mazeUtils.device import arduinoNanoEvery
from mazeUtils.device import colorsensor
from mazeUtils.device import deviceEnums
from mazeUtils.device import buzzerSongs
from mazeUtils.device import camera
from mazeUtils.device import photoReflector
from mazeUtils import mazeEnums
from mazeUtils import mazeConstraints
import ydlidar
import time

ph = photoReflector.PhotoReflector()

while True:
    print(ph.isReflecting())
    time.sleep(0.1)