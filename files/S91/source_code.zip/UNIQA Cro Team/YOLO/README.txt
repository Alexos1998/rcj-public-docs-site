
YOLO model has to be in the directory:

C:\Users\Jelka