########################################################################################################################
# Imports
# Stuff for boot from cmd
import os  # uvoz modula za rad s putanjama i datotekama
import sys  # upravljanje Python putanjama pri pokretanju
pass
sys.path.insert(0, r'C:\Program Files\Webots\lib\controller\python')  # dodaj Webots Python controller direktorij u sys.path
import numpy as np  # numpy – numeričke operacije s matricama
from Lib import colorsys  # colorsys – pretvorba RGB↔HSV boja
from controller import Robot, Motor, DistanceSensor, InertialUnit, GPS, Emitter, Receiver, Camera, Lidar  # Webots klase: Robot, Motor, senzori, GPS, kamera, lidar
import math  # standardna matematička biblioteka
import copy  # modul za duboko kopiranje objekata
from typing import Tuple, Literal, List, Dict, Set  # tipovi za type annotations
import struct  # struct – pakiranje/raspakiranje binarnih podataka
# noinspection PyUnresolvedReferences
import cv2  # OpenCV – obrada slike (detekcija žrtvi, filteri boja)

# noinspection PyUnresolvedReferences
# Victim class inlined from Victim.py
import numpy as np  # numpy (drugi import, inline iz Victim.py)
import cv2 #Biblioteka za opencv, koristi se samo za crtanje trokuta prilikom debugiranja
from ultralytics import YOLO #Biblioteka za koristenje YOLO modela za detekciju zrtvi
import torch #Biblioteka za pokretanje graficke kartice, za ubrzavanje rada detekcije
from datetime import datetime  # datetime – timestampovi i mjerenje trajanja

import getpass as _gp  # getpass – dohvat korisničkog imena bez pitanja za lozinku

# Auto-detekcija putanja — radi na svakom računalu
_USER       = _gp.getuser()  # dohvati korisničko ime trenutnog korisnika OS-a
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))  # apsolutni put do direktorija ove skripte

def _find_model():  # traži YOLO model na više mogućih lokacija na disku
    cands = [
        os.path.join(_SCRIPT_DIR, 'best_erebus.pt'),
        os.path.join(_SCRIPT_DIR, '..', 'best_erebus.pt'),
        os.path.join(_SCRIPT_DIR, '..', '..', 'best_erebus.pt'),
        os.path.join('C:\\', 'Users', _USER, 'best_erebus.pt'),
        os.path.join('C:\\', 'Users', _USER, 'Desktop', 'best_erebus.pt'),
        os.path.join('C:\\', 'Users', _USER, 'Downloads', 'best_erebus.pt'),
    ]
    found = next((p for p in cands if os.path.isfile(p)), None)  # vrati prvu putanju koja postoji, ili None
    if found is None:
        pass
        return cands[3]  # vrati zadanu lokaciju ako model nije pronađen
    pass
    return found  # vrati pronađenu putanju

_MODEL_PATH = _find_model()  # pohrani pronađenu putanju do YOLO modela
_TEMP_R_IMG = os.path.join(_SCRIPT_DIR, 'right_img.jpg')  # privremena datoteka za snimanje slike desne kamere
_TEMP_L_IMG = os.path.join(_SCRIPT_DIR, 'left_img.jpg')  # privremena datoteka za snimanje slike lijeve kamere
_SAVE_DIR   = os.path.join('C:\\', 'Users', _USER, 'Documents', 'ErebusImages')  # direktorij za arhiviranje snimljenih slika
os.makedirs(_SAVE_DIR, exist_ok=True)  # kreiraj direktorij ako ne postoji

#################################
#Ovaj dio koda trazi postoji li neka valjana graficka kartica te ako postoji, pokrece ju za rad
device = "0" if torch.cuda.is_available() else "cpu"  # koristi GPU (CUDA) ako je dostupan, inače CPU

if device == "0":  # ako je GPU odabran, eksplicitno postavi uređaj 0
    torch.cuda.set_device(0)  # inicijaliziraj CUDA uređaj 0

#################################

#Klasa za zrtvu, trenutno sadrzi samo 1 potrebnu metodu, za vracanje tipa zrtve na slici
# import time uklonjen — cooldown je uklonjen

class Victim:
    ai = YOLO(_MODEL_PATH)  # auto-detekcija putanje
    # Cooldown uklonjen — duplo bodovanje sprječava prev_victims u main loopu
    classes_number = ai.names  # rječnik: indeks klase → naziv (npr. 0→'C')
    # Novi model - 7 klasa, indeksi: 0=C, 1=F, 2=H, 3=O, 4=P, 5=S, 6=U
    classes_number[0] = "C"  # klasa 0 = C (Corrosive hazmat)
    classes_number[1] = "F"  # klasa 1 = F (Flammable hazmat)
    classes_number[2] = "H"  # klasa 2 = H (Harmed – ozlijeđena osoba)
    classes_number[3] = "O"  # klasa 3 = O (Organic hazmat)
    classes_number[4] = "P"  # klasa 4 = P (Poison hazmat)
    classes_number[5] = "S"  # klasa 5 = S (Stable – stabilna osoba)
    classes_number[6] = "U"  # klasa 6 = U (Unharmed – neozlijeđena osoba)
    
    @staticmethod
    #Prima listu slika (uvijek saljemo listu s jednim elementom) i  stranu na kojoj se nalazi zrtva
    #Vracam tip zrtve(njenu oznaku), dio koji ide u poruku koju saljemo te gdje se nalazi u odnosu na robota zrtva (naprijed, centar, nazad)
    def predictionImg(images, camera):
        # -----------------------------------------------------------------------
        # PRE-FILTER (KORAK 0): Provjeri boju slike PRIJE nego pozovemo YOLO.
        # Ako je slika samo tamni ili cyan zid -> vrati None odmah, brzo i sigurno.
        # -----------------------------------------------------------------------
        _pre_img = cv2.imread(images[0])  # učitaj sliku s diska za pre-filter provjeru boje
        if Victim.is_wall_only_image(_pre_img):  # ako je slika samo boja zida → preskoči YOLO odmah
            return None, None, None  # vrati trojnu None (nema žrtve)

        results = Victim.ai.predict(images, verbose=False) #Daje nam popis detektiranih objekata na slici, objekt klase Results
        
        results_classes = [int(predicted_class) for predicted_class in results[0].boxes.cls] #Izvlacimo oznake klasa (npr. 0, 1, 2 do n) iz rezultata
        #results_box = [int(predicted_class) for predicted_class in results[0].boxes.xywh]
        
        _ts = datetime.now().strftime("%H:%M:%S")  # timestamp za logiranje detekcija (HH:MM:SS)

        if len(results_classes) > 0: #Ako postoji bar 1 zrtva, radi nesto, uvijek gledamo samo 1. detektiranu zrtvu (ako ih ima vise)
            prediction = Victim.classes_number[results_classes[0]] #Pretvaramo broj u oznaku na temelju gore navedene mape
            area = results[0].boxes.xywh[0][2] * results[0].boxes.xywh[0][3] #Izvlacimo povrsinu kvadratica koji okruzuje zrtvu
            conf = float(results[0].boxes.conf[0])  # confidence (sigurnost) prve detekcije (0.0–1.0)
            w = float(results[0].boxes.xywh[0][2])  # širina bounding boxa u pikselima
            h = float(results[0].boxes.xywh[0][3])  # visina bounding boxa u pikselima
            ratio = w / h if h != 0 else 0  # omjer širina/visina; izbjegni dijeljenje s nulom
            start_point = tuple(int(x) for x in results[0].boxes.xyxy[0][:2]) #Gornji lijevi kut zrtve
            end_point = tuple(int(x) for x in results[0].boxes.xyxy[0][2:]) #Donji desni kut zrtve
            image_center_x = (start_point[0] + end_point[0]) /2 #Srediste zrtve, x-os

            # Ispis svih detekcija s timestampom
            for i in range(len(results_classes)):
                cls_i = Victim.classes_number[results_classes[i]]
                conf_i = float(results[0].boxes.conf[i])
                w_i = float(results[0].boxes.xywh[i][2])
                h_i = float(results[0].boxes.xywh[i][3])
                area_i = w_i * h_i
                ratio_i = w_i / h_i if h_i != 0 else 0
#SPAM#                 print(f"[{_ts}] [{camera}][{i}] class={cls_i} conf={conf_i:.3f} area={area_i:.1f} w={w_i:.1f} h={h_i:.1f} ratio={ratio_i:.2f}")

            is_letter = prediction in ('H', 'S', 'U')  # slova (H, S, U) imaju drugačiji filter od hazmat znakova

            if is_letter:
                # FIX: area gornja granica podignuta na 1300 (U/trident ima area ~1111 kad je blizu i bio je odbijen)
                # FIX: conf snizen na 0.60 (U trident rijetko prelazi 0.65)
                passes = 80 < int(area) < 1300 and conf > 0.55 and 0.2 < ratio < 2.5  # filter za slova: površina, confidence i omjer moraju biti OK

                # --- BLACK-ON-WHITE CHECK za slova ---
                # Pravi H/S/U su crni simboli na bijeloj pozadini.
                # Cyan/tamni zid nema bijele pozadine -> odbaci ako nema dovoljno bijelog+crnog.
                if passes and _pre_img is not None:
                    x1, y1, x2, y2 = (int(v) for v in results[0].boxes.xyxy[0])  # izreži koordinate na granice slike
                    x1 = max(0, x1); y1 = max(0, y1)
                    x2 = min(_pre_img.shape[1], x2); y2 = min(_pre_img.shape[0], y2)
                    roi_l = _pre_img[y1:y2, x1:x2]  # izreži ROI (region of interest) iz slike
                    if roi_l.size > 0:
                        roi_l_gray = cv2.cvtColor(roi_l, cv2.COLOR_BGR2GRAY)  # pretvori ROI u sivu sliku za analizu piksela
                        roi_l_px = roi_l.shape[0] * roi_l.shape[1]  # ukupan broj piksela u ROI-u
                        _dark_l = cv2.countNonZero(cv2.inRange(roi_l_gray, np.array(0, dtype=np.uint8), np.array(80, dtype=np.uint8))) / roi_l_px  # udio tamnih piksela (V < 80) unutar ROI-a
                        _white_l = cv2.countNonZero(cv2.inRange(roi_l_gray, np.array(180, dtype=np.uint8), np.array(255, dtype=np.uint8))) / roi_l_px  # udio bijelih piksela (V > 180) unutar ROI-a
                        # Pravi victim (Φ/Ψ/Ω) na cyan zidu ima bijele piksele unutar simbola: white >= 0.25
                        # Lažni zidovi/kutovi nemaju bijelog: white <= 0.23 (provjereno iz svih logova)
                        # NIJE dark+white jer Φ ima dark samo 0.12 (cyan pozadina, ne tamna) → dark+white = 0.45 → lažno odbijanje!
                        if _white_l < 0.10:  # ako < 10% bijelih → nije pravi simbol na bijeloj podlozi → odbaci
                            passes = False
                            #SPAM# print(f"[{_ts}] BLACK-ON-WHITE filter: {prediction} odbijen"
                                  # f" (white={_white_l:.2f} < 0.10, nema bijelog unutar simbola)")
            else:
                # Hazmat znakovi: kvadratni oblik, razumna povrsina (MORA imati gornju granicu!)
                # Cyan zid detektiran kao hazmat ima area ~1200+ - blokira ga area < 900
                # Ratio blize 1.0 (kvadrat), visoki confidence
                # FIX: ratio povecano na 0.70 (pravi hazmat je kvadrat; ratio=0.62 je crni kriz na zidu)
                passes = 80 < int(area) < 1400 and conf > 0.65 and 0.50 < ratio < 2.0  # filter za hazmat: površina, confidence i omjer u rasponu

                # --- ROI COLOR CHECK ---
                # Problem: Crni kriz na cyan zidu detektiran kao C (conf=0.690, area=405, ratio=0.62)
                # Fix: Ako je bounding box pretezno crn + cyan -> to je zid, ne hazmat znak
                # Pravi hazmat znakovi (C/F/O/P) imaju vlastite boje (narancasta, crvena, zuta...)
                # FIX: threshold snizen s 0.65 na 0.50 jer je stari pustao krizeve na zidu
                if passes and _pre_img is not None:  # primijeni ROI color check samo ako slika postoji
                    x1, y1, x2, y2 = (int(v) for v in results[0].boxes.xyxy[0])
                    x1 = max(0, x1); y1 = max(0, y1)
                    x2 = min(_pre_img.shape[1], x2); y2 = min(_pre_img.shape[0], y2)
                    roi = _pre_img[y1:y2, x1:x2]  # izreži ROI u boji
                    if roi.size > 0:
                        roi_hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)  # pretvori u HSV za lakše filtriranje
                        roi_px  = roi.shape[0] * roi.shape[1]  # ukupan broj piksela u ROI-u
                        _dark_roi = cv2.countNonZero(  # udio tamnih piksela (V < 55 u HSV)
                            cv2.inRange(roi_hsv, np.array([0,   0,   0], dtype=np.uint8),
                                                  np.array([180, 255, 55], dtype=np.uint8))
                        ) / roi_px
                        _cyan_roi = cv2.countNonZero(  # udio cyan piksela (boja zida u Erebusu)
                            cv2.inRange(roi_hsv, np.array([80, 55,  50], dtype=np.uint8),
                                                  np.array([110, 255, 225], dtype=np.uint8))
                        ) / roi_px
                        if _dark_roi + _cyan_roi > 0.50:  # > 50% tamno+cyan → to je zid, odbaci
                            passes = False
                            pass

                # --- CENTERNESS CHECK ---
                # FIX: Ako je žrtva na rubu slike, robot je lateralno daleko od nje -> skip
                if passes and _pre_img is not None:
                    img_w = _pre_img.shape[1]
                    if not (0.20 * img_w < image_center_x < 0.80 * img_w):
                        passes = False  # dohvati širinu slike
                        pass  # žrtva mora biti u središnjih 20–80% slike (nije predaleko bočno)

            if passes:
                # Cooldown uklonjen — prev_victims u main loopu sprječava duplo bodovanje po poziciji
                pass
                message = f"The AI recognized the victim, {prediction}" #Napravi poruku za ispis
                #now = datetime.now()
                #date_time_str = now.strftime("%Y%m%d%H%M%S")
                #filename = "C:\\Program Files\\Webots\\lib\\controller\\python\\" + date_time_str + prediction + r".jpg"
                #image = cv2.imread(images[0], cv2.IMREAD_COLOR)
                #image = cv2.rectangle(image, start_point, end_point, (255, 0, 0), 2)
                #cv2.imwrite(filename, image)

                if camera == "right": #Provjera pozicije na slici u odnosu na robota, trenutno se ne koristi
                    if image_center_x <= 64 /3:
                        grid_position = "front"
                    elif image_center_x <= 128 /3:  # odredi poziciju žrtve (naprijed/sredina/nazad) po strani kamere
                        grid_position = "middle"
                    else:
                        grid_position = "back"
                else:
                    if image_center_x <= 64 /3:
                        grid_position = "back"
                    elif image_center_x <= 128 /3:
                        grid_position = "middle"
                    else:
                        grid_position = "front"



                #print(camera, grid_position)
                return prediction, message, grid_position #Vrati vrijednosti u glavni program
            
            else:
                return None, None, None #Inace nema zrtvi (nedovoljna povrsina) te vrati nista

        else:
            return None, None, None #Nema zrtvi

    @staticmethod
    def detectVictim(img, camera, is_turning): #Funkcija koja je vracala smijemo li sada obradivati sliku, posto koristimo YOLO, uvijek vraca True (smijemo uvijek)
        return True

    @staticmethod
    def is_wall_only_image(img_bgr) -> bool:  # uvijek True jer YOLO obrađuje svaki frame
        """
        Provjeri je li kamera snimila SAMO boju zida (tamnu ili cyan) bez ikakve zrtve.
        Blokira dvije problematicne boje iz Erebus okoline:
          - Tamni/crni zid  (Image 1): V kanal manji od 50
          - Cyan/teal zid   (Image 2): H oko 97 u OpenCV skali (0-180), S i V umjereni
        Vraca True -> odbaci sliku, False -> proslij YOLO-u.
        """
        if img_bgr is None or img_bgr.size == 0:
            return True

        hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)  # ako slika nije učitana → tretiramo kao 'samo zid'
        total_px = img_bgr.shape[0] * img_bgr.shape[1]

        # --- Tamni zid (gotovo crn): V < 50 u 0-255 skali ---
        dark_mask = cv2.inRange(hsv,  # ukupan broj piksela slike
                                np.array([0,   0,  0], dtype=np.uint8),
                                np.array([180, 255, 50], dtype=np.uint8))
        dark_ratio = cv2.countNonZero(dark_mask) / total_px  # maska tamnih piksela (V < 50 ≈ crn zid)

        # --- Cyan/teal zid: H u [80, 110] (OpenCV 0-180), S > 55, V u [50, 225] ---
        cyan_mask = cv2.inRange(hsv,  # udio tamnih piksela
                                np.array([80, 55, 50], dtype=np.uint8),
                                np.array([110, 255, 225], dtype=np.uint8))
        cyan_ratio = cv2.countNonZero(cyan_mask) / total_px  # maska cyan/teal zida (H 80–110)

        # Ako je vise od 60% slike jedna od boja zida -> sigurno nema zrtve -> odbaci
        wall_detected = dark_ratio > 0.90 or cyan_ratio > 0.90  # udio cyan piksela
        if wall_detected:
            _ts = datetime.now().strftime("%H:%M:%S")
            #SPAM# print(f"[{_ts}] WALL-COLOR filter: dark={dark_ratio:.2f} cyan={cyan_ratio:.2f} -> preskacemo")
            pass
        return wall_detected

from datetime import datetime


# Stuff for nice prints
# noinspection PyUnresolvedReferences
np.set_printoptions(threshold=sys.maxsize)

se = 0

# ── DEBUG FLAGOVI ─────────────────────────────────────────────────────────────
# DBG_VERBOSE = True  → logira SVE (spammy: FLOOR, CTE, BEST, CORNERS svaki korak)
# DBG_VERBOSE = False → samo bitni eventi (default)
DBG_VERBOSE = False
# ──────────────────────────────────────────────────────────────────────────────


########################################################################################################################
# Constants

# Frames/Updates in a second
timeStep = 32

# Max speed allowed by the engine
_MAX_VELOCITY = 6.28  # timeStep simulacije u ms (≈31.25 Hz)

# Prepare the message for lack of progress
_LoP = struct.pack('c', 'L'.encode())  # maksimalna brzina motora u rad/s
# Ćelije TRAJNO zabranjene kao explore ciljevi (fizičke zamke gdje se robot
# zaglavio i tražio LoP). removeToExploreArea nije dovoljan jer addCells
# kasnije ponovno dodaje te ćelije u to_explore pri svakom lidar skenu.
_BANNED_CELLS = set()

# If a sensor detects an obstacle within this distance, it will act as there is a wall there
_DANGER_ZONE_CLOSENESS = 0.04  # trajno zabranjene ćelije (zamke gdje se robot zaglavljivao)

# The layer of the lidar to take(top to bottom starting at 0)
_LIDAR_LAYER = 2  # minimalna udaljenost do prepreke za opasnu zonu (m)

# Lidar point detection min-max and angles
_LIDAR_LIMIT = {
    'R1': (0.04, 0.065),
    'R1.5': (0.08, 0.0975),
    'R2': (0.1025, 0.125),
    'R2.5': (0.14, 0.1575),
    'R3': (0.1625, 0.185),
    'K1': (0.04, 0.08),
    'K2': (0.1075, 0.145),
    'K3': (0.15, 0.1775),
    'C1.5': (0.09, 0.125),
    'C2': (0.115, 0.175),
    'C2.5': (0.17, 0.21),
    'C3': (0.205, 0.2375),
    'B1': (0.0625, 0.09),
    'B2': (0.145, 0.1725),
    'B3': (0.225, 0.265),
    'CK2': (0.12, 0.135),
    'CK2.5': (0.1325, 0.17),
    'CK3': (0.14, 0.19),
    'CB': (0.1925, 0.215),
    'CR': (0.1775, 0.21)
}
_LIDAR_ANGLES = {
    # https://www.desmos.com/calculator/flzivwznih
    'B': 45,
    'R': 90,
    'K1': 29,
    'K2': 19,
    'K3': 15,
    'C1.5': 31,
    'C2': 38,
    'C2.5': 38,
    'C3': 41,
    'CK2': 26,
    'CK2.5': 20,
    'CK3': 18,
    'CB': 33,
    'CR': 27
}

# Area 1-2-3 possible angles of movement
_MVMT_ANGLES = {0, 45, 90, 135, 180, 225, 270, 315}


class Dot:  # svi dozvoljeni smjerovi kretanja (0–315°, korak 45°)
    def __init__(self, value: int, color_range: Dict[Literal['min', 'max'], Tuple[int, float, float]]):
        self.val = value
        self.color_range = color_range

    def __str__(self):
        return str(self.val)

    def __repr__(self):
        return str(self.val)

    def __eq__(self, other):
        if isinstance(other, Dot) or issubclass(type(other), Dot):
            return self.val == other.val
        elif type(other) == int:
            return self.val == other
        else:
            pass
            return False


class Tunnel(Dot):
    def __init__(self, value: int, color_range: Dict[Literal['min', 'max'], Tuple[int, float, float]]):
        super().__init__(value, color_range)
        self.coord = None
        self.found = False

_UNDEFINED = -1
_EMPTY = Dot(value=0, color_range={'min': (0, 0, 0.85), 'max': (0, 0, 1.00)})
_WALL = 1
_HOLE = Dot(value=2, color_range={'min': (0, 0, 0.15), 'max': (0, 0, 0.20)})
_SWAMP = Dot(value=3, color_range={'min': (37, 0.40, 0.75), 'max': (47, 0.55, 0.95)})  # prazna slobodna pločica (bijela)
_CHECKPOINT = Dot(value=4, color_range={'min': (115, 0.00, 0.55), 'max': (245, 0.03, 0.95)})  # zid
_START = 5  # rupa (crna pločica)
_BLUE = Tunnel(value=6, color_range={'min': (230, 0.60, 0.75), 'max': (250, 1.00, 1.05)})  # movara (narandžasta)
_PURPLE = Tunnel(value=7, color_range={'min': (260, 0.55, 0.70), 'max': (285, 1.00, 1.00)})  # checkpoint (sivkasta)
_RED = Tunnel(value=8, color_range={'min': (0, 0.60, 0.65), 'max': (10, 1.00, 1.00)})  # startna pozicija
_GREEN = Tunnel(value=9, color_range={'min': (110, 0.65, 0.65), 'max': (130, 1.00, 1.00)})  # plavi tunel (soba 1↔2)
_YELLOW = Tunnel(value=13, color_range={'min': (50, 0.55, 0.75), 'max': (68, 1.00, 1.00)})  # ljubičasti tunel (soba 1↔3 ili 2↔3)
_ORANGE = Tunnel(value=14, color_range={'min': (15, 0.45, 0.55), 'max': (57, 1.00, 1.00)})  # FIX: max H=57 da NE hvata H=60 (žuta)
_BLUE2 = Tunnel(value=15, color_range={'min': (230, 0.60, 0.75), 'max': (250, 1.00, 1.05)})  # zeleni tunel (soba 1↔4)
_PURPLE2 = Tunnel(value=16, color_range={'min': (260, 0.55, 0.70), 'max': (285, 1.00, 1.00)})  # žuti tunel
_RED2 = Tunnel(value=17, color_range={'min': (0, 0.60, 0.65), 'max': (10, 1.00, 1.00)})  # narančasti tunel (max H=57 da ne hvata žutu H=60)
_GREEN2 = Tunnel(value=18, color_range={'min': (110, 0.65, 0.65), 'max': (130, 1.00, 1.00)})
_YELLOW2 = Tunnel(value=19, color_range={'min': (50, 0.55, 0.75), 'max': (68, 1.00, 1.00)})
_ORANGE2 = Tunnel(value=20, color_range={'min': (15, 0.45, 0.55), 'max': (57, 1.00, 1.00)})  # FIX: max H=57
_STRONG_EMPTY = 10
_TEMP_WALL = 11
_VOID = 12
_ROOM_4 = 21  # jako prazno – potvrđeno slobodno
_OBSTACLE_VAL = 22  # fizičke kutije → 'x' u mapi (postavlja se na c_t pozicije kao rupe)
_VICTIMS = {  # void – crni piksel izvan granica labirinta
    'H': 30,  # soba 4 (u finalnoj mapi → '*')
    30: 'H',
    31: 'S',
    32: 'U',
    33: 'C',
    34: 'F',
    35: 'O',
    36: 'P'
}

_TUNNELS = dict()


########################################################################################################################
# Main Classes



class Cell:
    # noinspection PyShadowingNames
    def __init__(self, explored=False, c_t=_EMPTY.val, rotation=-1, center=_UNDEFINED,
                 cc=_UNDEFINED, cf=_UNDEFINED, cr=_UNDEFINED, cb=_UNDEFINED, cl=_UNDEFINED,
                 dsf=_UNDEFINED, dsr=_UNDEFINED, dsb=_UNDEFINED, dsl=_UNDEFINED,
                 ds0=_UNDEFINED, ds1=_UNDEFINED, ds2=_UNDEFINED, ds3=_UNDEFINED,
                 ds4=_UNDEFINED, ds5=_UNDEFINED, ds6=_UNDEFINED, ds7=_UNDEFINED,
                 fr=_UNDEFINED, br=_UNDEFINED, fl=_UNDEFINED, bl=_UNDEFINED):
        """
        The new Cell's attributes are its actual cell, which is a 5x5 matrix with the composition shown below,
        and two booleans that determine proprieties of that particular cell

        @param explored: Boolean to tell if the cell is explored or not
        @param c_t: Cell type used to determine if it's a: swamp, hole, checkpoint, the start or a tunnel to a new area
        @param cc: The center of the cell
        @param cf: The front dot referenced to the center of the cell
        @param cr: The right dot referenced to the center of the cell
        @param cb: The back dot referenced to the center of the cell
        @param cl: The left dot referenced to the center of the cell
        @param dsf: The front distance sensor
        @param dsr: The right distance sensor
        @param dsb: The back distance sensor
        @param dsl: The left distance sensor
        @param fr: The front-right corner
        @param br: The back-left corner
        @param fl: The front-left corner
        @param bl: The back-left corner
        @param ds0: The distance sensor n°0
        @param ds1: The distance sensor n°1
        @param ds2: The distance sensor n°2
        @param ds3: The distance sensor n°3
        @param ds4: The distance sensor n°4
        @param ds5: The distance sensor n°5
        @param ds6: The distance sensor n°6
        @param ds7: The distance sensor n°7
        """
        if explored and center == _UNDEFINED:
            center = _STRONG_EMPTY

        if _EMPTY.val == cf == cr == cb == cl:  # istražena ćelija bez definiranog centra → postavi jako prazno
            cc = _EMPTY.val
        else:
            cf = center if cf == _UNDEFINED else cf  # svi susjedni pravci prazni → centar je i on prazan
            cr = center if cr == _UNDEFINED else cr
            cb = center if cb == _UNDEFINED else cb
            cl = center if cl == _UNDEFINED else cl
            cc = center if cc == _UNDEFINED else cc

        # Spaced weirdly to allow more readability
        # @formatter:off
        self.cell = [
            [fl, ds0, dsf, ds1, fr],
            [ds7, c_t, cf, c_t, ds2],
            [dsl, cl, cc, cr, dsr],
            [ds6, c_t, cb, c_t, ds3],
            [bl, ds5, dsb, ds4, br]
        ]
        # @formatter:on

        self.explored = explored
        self.room = None

        # Rotates the matrix, so it points always to the same directions
        rotation = getRotation() // 2 if rotation == -1 else rotation  # soba kojoj ćelija pripada (1–4, None = nepoznato)
        for _ in range(rotation):
            self.cell = [list(row)[::-1] for row in zip(*self.cell)]

    def __str__(self):
        """
        @return: Returns the cell in an understandable format
        """
        s = ''
        for row in self.cell:
            s += self.formatDot(str(row)) + '\n'
        return s

    @property
    def available(self) -> bool:
        """
        Checks if the center of the cell is a wall or if at least one of the cell types is a hole
        @return: True if the cell is determined to be available, otherwise False
        """

        for c in {(2, 2), (2, 1), (2, 3), (1, 2), (3, 2)}:
            if self.cell[c[0]][c[1]] == _WALL or self.cell[c[0]][c[1]] == _TEMP_WALL:
                return False

        return not self.isNearTunnel and not self.nearHole

    @property
    def nearHole(self) -> bool:  # ćelija nije dostupna ni ako je blizu tunela ili rupe
        """
        Broji kuteve ćelije koji sadrže rupu/void.
        ≥2 kuta = sama rupa ili rubno-susjedna ćelija (moguća neoznačena
        polovica iste rupe) → blokirano.
        Točno 1 kut = samo dijagonalno dodiruje rupu → robot prolazi centrom
        ćelije ~6cm od kuta rupe, sigurno → dostupno. Bez ovoga rupa uz vrata
        zaključa cijelu regiju (žrtve ostanu nesakupljene)!
        @return: True ako je ćelija rupa ili rubno uz rupu
        """
        _hole_corners = 0
        for row, col in [(1, 1), (3, 1), (1, 3), (3, 3)]:
            if self.cell[row][col] == _HOLE.val or self.cell[row][col] == _VOID:
                _hole_corners += 1  # broji kuteve koji sadrže rupu ili void
        return _hole_corners >= 2

    @property
    def canBeAvailable(self) -> bool:  # ≥ 2 kuta s rupom → ćelija je na rupi ili uz nju → blokiraj
        """
        Checks if the center of the cell is a wall or if at least one of the cell types is a hole
        @return: True if the cell is determined to be available, otherwise False
        """
        if self.cell[2][2] == 1:
            return False

        return not self.nearHole

    @property
    def isNearTunnel(self) -> bool:
        """
        Checks if at least one of the cell types is a tunnel
        @return: True if there's a tunnel, otherwise False  # True ako je kut ćelije zauzet pronađenim tunelom
        """
        for row, col in [(1, 1), (3, 1), (1, 3), (3, 3)]:
            if (self.cell[row][col] == _BLUE.val and _BLUE.found and _BLUE.coord) or \
                    (self.cell[row][col] == _BLUE2.val and _BLUE2.found and _BLUE2.coord) or \
                    (self.cell[row][col] == _PURPLE.val and _PURPLE.found and _PURPLE.coord) or \
                    (self.cell[row][col] == _PURPLE2.val and _PURPLE2.found and _PURPLE2.coord) or \
                    (self.cell[row][col] == _RED.val and _RED.found and _RED.coord) or \
                    (self.cell[row][col] == _RED2.val and _RED2.found and _RED2.coord) or \
                    (self.cell[row][col] == _GREEN.val and _GREEN.found and _GREEN.coord) or \
                    (self.cell[row][col] == _GREEN2.val and _GREEN2.found and _GREEN2.coord) or \
                    (self.cell[row][col] == _YELLOW.val and _YELLOW.found and _YELLOW.coord) or \
                    (self.cell[row][col] == _YELLOW2.val and _YELLOW2.found and _YELLOW2.coord) or \
                    (self.cell[row][col] == _ORANGE.val and _ORANGE.found and _ORANGE.coord) or \
                    (self.cell[row][col] == _ORANGE2.val and _ORANGE2.found and _ORANGE2.coord):
                return True

        return False

    @classmethod
    def formatDot(cls, dot) -> str:
        """
        Converts the dot or series of dots in a more visually understandable string

        @param dot: Either an int or a string
        @return: The formatted dot
        """
        placeholder = copy.copy(dot)
        if type(placeholder) == int:
            placeholder = str(placeholder)

        if type(placeholder) == str:
            # General formatting
            placeholder = placeholder.replace(',', '').replace('[', '').replace(']', '') \
                .replace(' [', '').replace('] ', '').replace('  ', ' ')

            # Used for visualize pathing
            placeholder = placeholder.replace('99', 'R').replace('91', 'ø').replace('90', 'o')

            # Replace victims   
            placeholder = placeholder.replace(str(_VICTIMS['H']), 'H').replace(str(_VICTIMS['S']), 'S') \
                .replace(str(_VICTIMS['U']), 'U').replace(str(_VICTIMS['C']), 'C').replace(str(_VICTIMS['F']), 'F') \
                .replace(str(_VICTIMS['O']), 'O').replace(str(_VICTIMS['P']), 'P')

            #print(f"Current placeholder\n{placeholder}")
            # Format the actual dots
            placeholder = placeholder.replace(str(_ROOM_4), '*').replace(str(_YELLOW), 'Y').replace(str(_ORANGE), 'O') \
                .replace(str(_BLUE2), 'B').replace(str(_PURPLE2), 'P').replace(str(_RED2), 'R') \
                .replace(str(_GREEN2), 'G').replace(str(_YELLOW2), 'Y').replace(str(_ORANGE2), 'O') \
                .replace(str(_STRONG_EMPTY), '░').replace(str(_TEMP_WALL), '▓') \
                .replace(str(_VOID), 'U').replace(str(_EMPTY), ' ').replace(str(_UNDEFINED), '?') \
                .replace(str(_WALL), '█').replace(str(_HOLE), 'u').replace(str(_SWAMP), '≈') \
                .replace(str(_CHECKPOINT), '©').replace(str(_START), 'S') \
                .replace(str(_BLUE), 'B').replace(str(_PURPLE), 'P').replace(str(_RED), 'R') \
                .replace(str(_GREEN), 'G')

            #print(f"Placeholder after changing tile types\n{placeholder}")
            return placeholder
        else:
            pass
            return ''

    def merge(self, other: 'Cell') -> 'Cell':
        """
        Merges two cell by combining their matrices by taking for each dot the greater one

        @param other: The other cell to be merged
        @return: The new, merged cell
        """
        if type(other) == type(self):
            for row in range(5):
                for col in range(5):
                    if not (self.cell[row][col] <= 0 and other.cell[row][col] >= 30 or
                            other.cell[row][col] <= 0 and self.cell[row][col] >= 30):
                        self.cell[row][col] = max(self.cell[row][col], other.cell[row][col])
        else:
            pass
        return self  # uzmi veću (informativniju) vrijednost za svaku točku

    def unmerge(self, other: 'Cell') -> 'Cell':
        """
        Merges two cell by combining their matrices by taking for each dot the greater one

        @param other: The other cell to be merged
        @return: The new, merged cell
        """
        if type(other) == type(self):
            for row in range(5):
                for col in range(5):
                    if self.cell[row][col] > other.cell[row][col]:
                        self.cell[row][col] = other.cell[row][col]
        else:
            pass  # obrni merge: uzmi manju vrijednost
        return self



class Net:
    def __init__(self, starting_coord: Tuple[int, int], starting_cell: Cell):
        """
        It creates a new net/map which has the {starting_coord: starting_cell} as its start.

        @param starting_coord: The starting coordinate
        @param starting_cell: The starting cell
        """
        self.current_room = 1
        self.map: Dict[Tuple[int, int]: Cell] = dict()
        self.start: Tuple[int, int] = starting_coord
        self.to_explore: Set[Tuple[int, int]] = {self.start}  # trenutna soba robota (1–4)
        self.__add__({starting_coord: starting_cell})  # rječnik {koordinata: ćelija}
        #print("---------------\n", self.start)

    def __add__(self, other):
        """
        Adds every specified cell to the map and its 24 neighbours
        For example, this is needed when the robot wants to check if a cell is available

        @param other: A dictionary of the cells to add and their coordinates
        @return: The final Net
        """

        if type(other) is dict:
            for coord, cell in other.items():
                if coord in list(self.map.keys()):
                    if cell.explored:
                        old_room = self.map[coord].room  # FIX: sačuvaj room prije merge-a
                        self.map[coord] = cell.merge(self.map[coord])  # ćelija postoji i nova je istražena → spoji ih
                        if old_room is not None:          # FIX: vrati room (merge ga briše)
                            self.map[coord].room = old_room  # sačuvaj sobu prije merge-a (merge je briše)
                    else:
                        self.map[coord].merge(cell)  # vrati sobu nazad nakon merge-a
                else:
                    self.map[coord] = cell

                # A wall in the main cell will influence ALL 24 neighbouring nodes(nodes: 'n', wall + node: 'N')
                #       ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?
                #       ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?
                #       ?  ?  n  ?  n  ?  n  ?  n  ?  n  ?  ?
                #       ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?
                #       ?  ?  n  ?  N     n     n  ?  n  ?  ?
                #       ?  ?  ?  ?  █              ?  ?  ?  ?
                #       ?  ?  n  ?  N           n  ?  n  ?  ?
                #       ?  ?  ?  ?  █              ?  ?  ?  ?
                #       ?  ?  n  ?  N     n     n  ?  n  ?  ?
                #       ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?
                #       ?  ?  n  ?  n  ?  n  ?  n  ?  n  ?  ?
                #       ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?
                #       ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?

                neighbourhood = []

                for row in range(13):
                    neighbourhood.append([])
                    for col in range(13):
                        neighbourhood[row].append(-1)

                for row in range(5):
                    for col in range(5):
                        neighbourhood[row + 4][col + 4] = self.map[coord].cell[row][col]
                neighbourhood = np.array(neighbourhood)

                np.rot90(neighbourhood)
                np.rot90(neighbourhood)
                np.flip(neighbourhood)

                # I created it 30 minutes ago and I already find it difficult to understand, good luck to the reader,
                # but basically it's the part that adds all the neighbours to the map
                for neighbour_x in range(-2, 3):
                    for neighbour_z in range(-2, 3):
                        neighbour_coord = (neighbour_x + coord[0], neighbour_z + coord[1])

                        # Create not existing cells
                        if neighbour_coord not in list(self.map.keys()):
                            self.map[neighbour_coord] = Cell()

                        first_el = [neighbour_x * 2 + 4, neighbour_z * 2 + 4]
                        last_el = [neighbour_x * 2 + 8, neighbour_z * 2 + 8]
                        cell_section = copy.copy(neighbourhood[first_el[1]:last_el[1] + 1, first_el[0]:last_el[0] + 1])

                        placeholder = Cell()
                        placeholder.cell = cell_section

                        self.map[neighbour_coord].merge(placeholder)

        return self

    def __iadd__(self, other) -> 'Net':
        return self.__add__(other)

    def __sub__(self, other):
        """
        Removes every specified cell from the map and its references in the 24 neighbours
        This is needed when you're teleported back to a checkpoint and you need to remove the previous position's cell

        @param other: A set of coordinates of the cells to remove
        @return: The final Net
        """
        if type(other) is set:

            add_to_explore = copy.copy(set())
            try:
                other.remove(None)
            except (Exception,):
                pass

            for coord in other:
                self.map[coord] = Cell()

                # A wall in the main cell will influence ALL 24 neighbouring nodes(nodes: 'n', wall + node: 'N')
                #       ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?
                #       ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?
                #       ?  ?  n  ?  n  ?  n  ?  n  ?  n  ?  ?
                #       ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?
                #       ?  ?  n  ?  N     n     n  ?  n  ?  ?
                #       ?  ?  ?  ?  █              ?  ?  ?  ?
                #       ?  ?  n  ?  N           n  ?  n  ?  ?
                #       ?  ?  ?  ?  █              ?  ?  ?  ?
                #       ?  ?  n  ?  N     n     n  ?  n  ?  ?
                #       ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?
                #       ?  ?  n  ?  n  ?  n  ?  n  ?  n  ?  ?
                #       ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?
                #       ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?  ?

                neighbourhood = []

                for row in range(13):
                    neighbourhood.append([])
                    for col in range(13):
                        neighbourhood[row].append(100)

                for row in range(5):
                    for col in range(5):
                        if not (row % 2 == 1 and col % 2 == 1):
                            neighbourhood[row + 4][col + 4] = -1

                neighbourhood = np.array(neighbourhood)

                # I created it 30 minutes ago and I already find it difficult to understand, good luck to the reader,
                # but basically it's the part that adds all the neighbours to the map
                for neighbour_x in range(-2, 3):
                    for neighbour_z in range(-2, 3):
                        neighbour_coord = (neighbour_x + coord[0], neighbour_z + coord[1])

                        # Create not existing cells
                        if neighbour_coord not in list(self.map.keys()):
                            self.map[neighbour_coord] = Cell()

                        first_el = [neighbour_x * 2 + 4, neighbour_z * 2 + 4]
                        last_el = [neighbour_x * 2 + 8, neighbour_z * 2 + 8]
                        cell_section = copy.copy(neighbourhood[first_el[1]:last_el[1] + 1, first_el[0]:last_el[0] + 1])

                        placeholder = Cell()
                        placeholder.cell = cell_section

                        self.map[neighbour_coord].unmerge(placeholder)

                for neighbour_x in range(-1, 2):
                    for neighbour_z in range(-1, 2):
                        neighbour_coord = (neighbour_x + coord[0], neighbour_z + coord[1])
                        add_to_explore.add(neighbour_coord)
                        self.map[neighbour_coord].explored = False

            self.updateToExplore(last_pos=None, curr_pos=None, next_to_explore=list(add_to_explore.union(other)))
            self.checkToExplore()

        return self

    def __isub__(self, other) -> 'Net':
        return self.__sub__(other)

    def __str__(self):
        return maze.getMap(nice_view=True)

    def updateToExplore(self, last_pos: Tuple[int, int], curr_pos: Tuple[int, int],
                        next_to_explore: List[Tuple[int, int]]):
        """
        Updates the current set of all the cells that need to be explored

        @param last_pos: The last position of the robot
        @param curr_pos: The current position of the robot
        @param next_to_explore: A list of all the cells that have the potential to be still unexplored
        """
        try:
            next_to_explore.remove(None)
        except (Exception,):
            pass

        next_to_explore = {next_pos for next_pos in next_to_explore if not self.map[next_pos].explored}

        self.to_explore = self.to_explore.union(next_to_explore)

        if last_pos in self.to_explore:
            self.to_explore.remove(last_pos)  # dodaj u skup za istraživanje
        if curr_pos in self.to_explore:
            self.to_explore.remove(curr_pos)  # makni prethodnu poziciju (već istražena)

    def removeToExploreArea(self, center_coord: Tuple[int, int], radius: int = 1):  # makni trenutnu poziciju (robot je tu)
        """
        Sets all the cell ina a square area(radius*2 +1) around the specified center to unexplored/ not to be explored

        @param center_coord: The center coordinate of the square
        @param radius: The radius of the area
        """
        for x in range(-radius, radius + 1):
            for y in range(-radius, radius + 1):
                try:
                    self.to_explore.remove((x + center_coord[0], y + center_coord[1]))
                except (Exception,):
                    pass

    def removeToExplore(self, *to_remove: Tuple[int, int]):
        """
        Sets all the specified cells to unexplored/ not to be explored

        @param to_remove: List/Coordinates to remove
        """
        for coord in to_remove:
            try:
                self.to_explore.remove(coord)
            except (Exception,):
                pass

    def checkToExplore(self):
        to_remove = []
        for cell in self.to_explore:
            if not maze.map[cell].available:
                to_remove.append(cell)
                if DBG_VERBOSE: pass

        for cell in to_remove:
            self.to_explore.remove(cell)

        if len(self.to_explore) != 1 and self.start in self.to_explore:
            self.to_explore.remove(self.start)

        cells_are_removed = True
        while cells_are_removed:
            cells_are_removed = False

            for cell in self.to_explore:
                count_explored_cells = 0
                for angle in {0, 90, 180, 270}:
                    neighbour_coord = getNearCoords(angle=angle + getRotation() * 45, from_coord=cell)

                    if maze.map[neighbour_coord].explored and maze.map[neighbour_coord].available:  # broji koliko susjednih u 4 smjera je istraženo
                        count_explored_cells += 1

                if count_explored_cells >= 3 and cell not in _TUNNELS:
                    to_remove.append(cell)
                    if DBG_VERBOSE: pass

            for cell in to_remove:
                try:
                    self.to_explore.remove(cell)
                    self.map[cell].explored = True
                    cells_are_removed = True
                except (Exception,):
                    pass

    def getCorners(self):
        """
        Get the two opposite corners of the map

        @return: A tuple consisting of the bottom corner and the top corner like this: (CornerBot(x,y), CornerTop(x,y))
        """
        corner_bot = [None, None]
        corner_top = [None, None]

        for coord, cell in self.map.items():
            if corner_bot[0] is None:
                corner_bot[0] = coord[0]
            elif corner_bot[0] > coord[0]:
                corner_bot[0] = coord[0]

            if corner_top[0] is None:
                corner_top[0] = coord[0]
            elif corner_top[0] < coord[0]:
                corner_top[0] = coord[0]

            if corner_bot[1] is None:
                corner_bot[1] = coord[1]
            elif corner_bot[1] > coord[1]:
                corner_bot[1] = coord[1]

            if corner_top[1] is None:
                corner_top[1] = coord[1]
            elif corner_top[1] < coord[1]:
                corner_top[1] = coord[1]

        corner_bot = tuple(corner_bot)
        corner_top = tuple(corner_top)
        if DBG_VERBOSE: pass
        return corner_bot, corner_top

    def getMap(self, nice_view=True):
        room_4_matrix = [[_ROOM_4, _ROOM_4, _ROOM_4, _ROOM_4, _ROOM_4],
                        [_ROOM_4, _ROOM_4, _ROOM_4, _ROOM_4, _ROOM_4],
                        [_ROOM_4, _ROOM_4, _ROOM_4, _ROOM_4, _ROOM_4],
                        [_ROOM_4, _ROOM_4, _ROOM_4, _ROOM_4, _ROOM_4],
                        [_ROOM_4, _ROOM_4, _ROOM_4, _ROOM_4, _ROOM_4]]
        """
        Get the actual map by ordering all the cells in the map in a nice 3D matrix, then unpack it and make it 2D
        and finally compact horizontally and vertically.
        If there are any undefined dots, they will be converted into _EMPTY dots. Note that this last part of the code
        is probably commented off during testing

        @param nice_view: If set to True, it will return a string,
            and if printed is way more understandable than the whole matrix
        @return: Either a string printable to the console or a 2D matrix with all the dots
        """

        corner_bot, corner_top = self.getCorners()

        # SUŽAVANJE KUTEVA NA SADRŽAJ (univerzalno): prazni Cell() placeholderi
        # (frontier prsten oko robota iz addCells) napuhuju matricu fantomskim
        # kolonama/redovima izvan svijeta (npr. 21x23 umjesto 21x19) i ruše
        # poravnanje pri bodovanju. Za OUTPUT brojimo samo ćelije koje su
        # istražene ili imaju ijedan stvarni podatak (zid/rupu/tile/žrtvu).
        _ct_keys = []
        for _ck, _cc in self.map.items():
            if getattr(_cc, 'explored', False):
                _ct_keys.append(_ck)
                continue
            _has_dot = False
            for _crow in _cc.cell:
                for _cd in _crow:
                    if _cd != _UNDEFINED and _cd != _EMPTY.val:
                        _has_dot = True
                        break
                if _has_dot:
                    break
            if _has_dot:
                _ct_keys.append(_ck)
        if _ct_keys:
            corner_bot = (min(k[0] for k in _ct_keys), min(k[1] for k in _ct_keys))
            corner_top = (max(k[0] for k in _ct_keys), max(k[1] for k in _ct_keys))
            pass

        # Get width and length of the maze
        # --- The +1 is to get every cell in the rectangle, otherwise it would have skipped the last row and column
        width = abs((corner_top[0]) - (corner_bot[0])) + 1
        height = abs((corner_top[1]) - (corner_bot[1])) + 1

        offset_w = -corner_bot[0]
        offset_h = -corner_bot[1]

        # Prepare the matrix to reorder the cells — pipeline izvučen u helper da
        # se identičan kod može pustiti i preko PROBE matrica (kalibracija
        # ćelija→matrica pozicija bez ikakvog nagađanja formule).
        def _assemblePipeline(_cell_at):
            _seg = []
            for row in range(width):
                _seg.append([])
                for col in range(height):
                    _seg[row].append(_cell_at(row, col))

            _cm = []
            for col in range(height):
                for line in range(5):
                    _cm.append([])
                    for row in range(width):
                        _cm[col * 5 + line].extend(_seg[row][col][line])

            # This merges all the cells to get a final grid: vertically first
            if height > 1:
                _cm = shiftMatrix(repeat=2, direction='up', old_list=_cm)
                for row in range(height - 1):
                    for line in range(3):  # spoji ćelije vertikalno
                        for dot in range(len(_cm[line])):
                            _cm[line][dot] = max(_cm[line][dot], _cm[line + 3][dot])
                    _cm = shiftMatrix(repeat=2, direction='up', old_list=_cm)
                    _cm.pop(1)
                    _cm.pop(1)
                    _cm.pop(1)
                _cm = shiftMatrix(repeat=3, direction='up', old_list=_cm)

            # And then horizontally
            if width > 1:
                _cm = shiftMatrix(repeat=2, direction='left', old_list=_cm)
                for col in range(width - 1):
                    for line in range(len(_cm)):  # spoji ćelije horizontalno
                        for dot in range(3):
                            _cm[line][dot] = max(_cm[line][dot], _cm[line][dot + 3])
                        _cm[line].pop(3)
                        _cm[line].pop(3)
                        _cm[line].pop(3)
                    _cm = shiftMatrix(repeat=2, direction='left', old_list=_cm)
                _cm = shiftMatrix(repeat=3, direction='left', old_list=_cm)

            margin_distance = 2
            return np.array(_cm)[margin_distance:-margin_distance, margin_distance:-margin_distance]

        def _realCellAt(row, col):  # izreži rubne margine (artefakti spajanja)
            if (row - offset_w, col - offset_h) in self.map:
                return self.map[(row - offset_w, col - offset_h)].cell
            return Cell().cell

        complete_map = _assemblePipeline(_realCellAt)

        # ── KALIBRACIJA ćelija→matrica (runtime, mjeri STVARNI pipeline) ─────
        # Probe matrice: centri (line/dot == 2) nose dominantnu vrijednost
        # BIG+index pa prežive max-merge; očitamo gdje je svaki završio.
        _CAL_BIG = 10_000_000
        _probe_r = _assemblePipeline(
            lambda r, c: [[(_CAL_BIG + c) if line == 2 else c] * 5 for line in range(5)])
        _probe_c = _assemblePipeline(
            lambda r, c: [[(_CAL_BIG + r) if dot == 2 else r for dot in range(5)] for _ in range(5)])
        _cal_row = {}
        for _pr in range(_probe_r.shape[0]):
            _pv = int(_probe_r[_pr, 0])
            if _pv >= _CAL_BIG:
                _cal_row[_pv - _CAL_BIG] = _pr
        _cal_col = {}
        for _pc in range(_probe_c.shape[1]):
            _pv = int(_probe_c[0, _pc])
            if _pv >= _CAL_BIG:
                _cal_col[_pv - _CAL_BIG] = _pc
        # (x, y) ćelija → (matrix_row, matrix_col) centra
        _cell_pos = {}
        for _ck in self.map.keys():
            _ci, _cj = _ck[0] + offset_w, _ck[1] + offset_h
            if _cj in _cal_row and _ci in _cal_col:
                _cell_pos[_ck] = (_cal_row[_cj], _cal_col[_ci])
        pass
        #print(f"Complete map:\n{complete_map}")
        if nice_view:
            nice_map = ''

            for row in complete_map:
                nice_map += Cell.formatDot(str(row).replace('\n', '').replace('[ ', '[')) + '\n'

            return nice_map

        # --- Correct some stuff
        # Handle strong empties and temp walls
        for row in range(len(complete_map)):
            for col in range(len(complete_map[row])):
                if complete_map[row, col] == _TEMP_WALL or complete_map[row, col] == _STRONG_EMPTY:
                    complete_map[row][col] = _EMPTY.val

        # Every undefined tile is set to empty
        for row in range(1, len(complete_map), 2):
            for col in range(1, len(complete_map[row]), 2):
                if complete_map[row, col] == _UNDEFINED:
                    complete_map[row, col] = _EMPTY.val

        # Reduce the map to a decent size
        corner_top = [float('inf'), float('inf')]
        corner_bot = [0, 0]
        for row_i, row in enumerate(complete_map):
            for col_i, col in enumerate(row):
                if col > 0:  # smanji matricu na najmanji relevantni pravokutnik
                    corner_top = [min(corner_top[0], row_i), min(corner_top[1], col_i)]
                    corner_bot = [max(corner_bot[0], row_i), max(corner_bot[1], col_i)]
        complete_map = np.array(complete_map)[corner_top[0]:corner_bot[0] + 1, corner_top[1]:corner_bot[1] + 1]

        # --- Mark unscanned wall/corner positions as walls ---
        # After the node-center loop above (which set odd,odd _UNDEFINED → _EMPTY),
        # any remaining _UNDEFINED is a wall/corner slot the robot never scanned.
        # Rule: "if the robot never passed next to it, or couldn't, treat it as a wall."
        # This fixes outer-boundary and diagonal-corner slots that stay -1 (unknown),
        # which the engine would otherwise output as 0 (empty) instead of 1 (wall).
        for _fix_row in range(len(complete_map)):
            for _fix_col in range(len(complete_map[_fix_row])):
                if complete_map[_fix_row, _fix_col] == _UNDEFINED:
                    complete_map[_fix_row][_fix_col] = _WALL

        # Fix: UNDEFINED→WALL above may incorrectly set positions inside
        # hazard-tile clusters (hole=2, swamp=3, checkpoint=4, start=5).
        # Between adjacent tiles of these types there is no physical wall → 0.
        _h_rows = len(complete_map)
        _h_cols = len(complete_map[0])
        _TILE_VALS = frozenset({_HOLE.val, _SWAMP.val, _CHECKPOINT.val, _START})
        _TILE_OR_EMPTY = _TILE_VALS | {_EMPTY.val}

        for _hr in range(_h_rows):
            for _hc in range(1, _h_cols - 1):
                if (complete_map[_hr, _hc] == _WALL and
                        complete_map[_hr, _hc - 1] in _TILE_VALS and
                        complete_map[_hr, _hc + 1] in _TILE_VALS and
                        complete_map[_hr, _hc - 1] == complete_map[_hr, _hc + 1]):
                    # ISTI marker s obje strane = fantomski zid UNUTAR tile-a.
                    # Različiti markeri (npr. '4' i '2') = PRAVI zid između
                    # checkpointa i rupe — NE brisati!
                    complete_map[_hr, _hc] = _EMPTY.val

        for _hr in range(1, _h_rows - 1):
            for _hc in range(_h_cols):
                if (complete_map[_hr, _hc] == _WALL and
                        complete_map[_hr - 1, _hc] in _TILE_VALS and
                        complete_map[_hr + 1, _hc] in _TILE_VALS and
                        complete_map[_hr - 1, _hc] == complete_map[_hr + 1, _hc]):
                    complete_map[_hr, _hc] = _EMPTY.val

        _hf_changed = True
        while _hf_changed:
            _hf_changed = False
            for _hr in range(1, _h_rows - 1):
                for _hc in range(1, _h_cols - 1):
                    if complete_map[_hr, _hc] == _WALL:  # iterativno briši izolirane WALL točke okružene tile/empty
                        _hf_ns = (complete_map[_hr - 1, _hc],
                                  complete_map[_hr + 1, _hc],
                                  complete_map[_hr, _hc - 1],
                                  complete_map[_hr, _hc + 1])
                        if all(_n in _TILE_OR_EMPTY for _n in _hf_ns):
                            complete_map[_hr, _hc] = _EMPTY.val
                            _hf_changed = True

        # ── ZATVARANJE RUPICA U ZIDOVIMA (univerzalno) ───────────────────────
        # Praznina od TOČNO 1 pozicije između dva kolinearna zida je lidar šum
        # ("polu zidovi"): legitimna vrata/otvori u Erebusu su široki cijeli
        # tile (≥3 matrične pozicije), pa je `1_1` → `111` uvijek sigurno.
        _gp_closed = 0
        for _hr in range(_h_rows):
            for _hc in range(2, _h_cols - 2):
                if (complete_map[_hr, _hc] == _EMPTY.val
                        and complete_map[_hr, _hc - 1] == _WALL == complete_map[_hr, _hc - 2]  # zatvori lidar-šumne praznine od 1 pozicije između zidova
                        and complete_map[_hr, _hc + 1] == _WALL == complete_map[_hr, _hc + 2]):
                    # Samo PRAVI nizovi (≥2 zida) s obje strane: `11_11` → `11111`.
                    # `1_1` je preslabo — šumni stupići `10101` bi se pojačali
                    # u pune fantomske zidove!
                    complete_map[_hr, _hc] = _WALL
                    _gp_closed += 1
        for _hr in range(2, _h_rows - 2):
            for _hc in range(_h_cols):
                if (complete_map[_hr, _hc] == _EMPTY.val
                        and complete_map[_hr - 1, _hc] == _WALL == complete_map[_hr - 2, _hc]
                        and complete_map[_hr + 1, _hc] == _WALL == complete_map[_hr + 2, _hc]):
                    complete_map[_hr, _hc] = _WALL
                    _gp_closed += 1
        if _gp_closed:
            pass

        # ── UNIVERZALNI FILTER POVEZANOSTI ───────────────────────────────────
        # Sadržaj mape koji NIJE povezan (kroz ne-zid pozicije) s istraženim
        # područjem je fantom izvan svijeta (npr. lidar artefakti iza vanjskog
        # zida — zapečaćene kutije koje službeno rješenje označava '0').
        # BFS od centara svih istraženih ćelija; zadržavamo dosegnute pozicije
        # + zidove/žrtve u 8-susjedstvu dosegnutih (rubni zidovi, kutevi).
        _cn_rows, _cn_cols = complete_map.shape
        _cn_block = {_WALL, _VOID} | {_v for _v in range(30, 37)}
        _cn_seeds = []
        for _cn_key, _cn_cell in self.map.items():
            if getattr(_cn_cell, 'explored', False) or _cn_key in _TUNNELS:  # BFS od istraženih ćelija; nedosegnuto je fantom
                if _cn_key not in _cell_pos:
                    continue
                _cn_r, _cn_c = _cell_pos[_cn_key]   # KALIBRIRANO
                if 0 <= _cn_r < _cn_rows and 0 <= _cn_c < _cn_cols:
                    _cn_seeds.append((_cn_r, _cn_c))
        if _cn_seeds:
            _cn_reached = [[False] * _cn_cols for _ in range(_cn_rows)]
            _cn_q = []
            for _cn_r, _cn_c in _cn_seeds:
                if not _cn_reached[_cn_r][_cn_c] and complete_map[_cn_r, _cn_c] not in _cn_block:
                    _cn_reached[_cn_r][_cn_c] = True
                    _cn_q.append((_cn_r, _cn_c))
            while _cn_q:
                _cn_r, _cn_c = _cn_q.pop()
                for _dr, _dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    _nr, _nc = _cn_r + _dr, _cn_c + _dc
                    if (0 <= _nr < _cn_rows and 0 <= _nc < _cn_cols
                            and not _cn_reached[_nr][_nc]
                            and complete_map[_nr, _nc] not in _cn_block):
                        _cn_reached[_nr][_nc] = True
                        _cn_q.append((_nr, _nc))
            _cn_dropped = 0
            for _cn_r in range(_cn_rows):
                for _cn_c in range(_cn_cols):
                    if complete_map[_cn_r, _cn_c] == _EMPTY.val or _cn_reached[_cn_r][_cn_c]:
                        continue
                    _cn_keep = False
                    for _dr in (-1, 0, 1):
                        for _dc in (-1, 0, 1):
                            _nr, _nc = _cn_r + _dr, _cn_c + _dc
                            if (0 <= _nr < _cn_rows and 0 <= _nc < _cn_cols
                                    and _cn_reached[_nr][_nc]):
                                _cn_keep = True
                                break
                        if _cn_keep:
                            break
                    if not _cn_keep:
                        complete_map[_cn_r, _cn_c] = _EMPTY.val
                        _cn_dropped += 1
            if _cn_dropped:
                pass


        # ── Post-process: mark room-4 positions as stars ─────────────────────────
        # Compute the tight bounding box of all non-tunnel room-4 cell centres in
        # the final map, then fill EVERY position inside that box with _ROOM_4.
        #
        # WHY TIGHT (no ±1 overspill):
        #   The rooms-1–3/room-4 boundary ODD positions (e.g. the 'g' in 'g0g')
        #   sit at box_min−1 / box_max+1 → outside the tight box → preserved. ✓
        #   An overspill of +1 would reach the RED tunnel center at row=box_max+1
        #   and incorrectly turn 'r0r' into 'r★r'. ✓ Tight avoids that.
        #
        # WHY UNCONDITIONAL (no value check):
        #   Inside the box, walls (1), checkpoints (4), secondary tunnel c_t
        #   values (17/18/20), voids (12), obstacles (22) etc. must ALL become ★.
        #   The competition's expected map replaces every position in room-4 with ★.
        #   Any value check (== 0, not-in-tunnel-set) leaves those positions wrong.
        #
        # Centre formula (rows = z-direction, cols = x-direction):
        #   final_row = 2*(gz + offset_h) − corner_top[0]
        #   final_col = 2*(gx + offset_w) − corner_top[1]
        _r4_rows = complete_map.shape[0]
        _r4_cols = complete_map.shape[1]
        _r4_centres_list: list = []
        _all_rooms_in_map = sorted(set(c.room for c in self.map.values() if c.room is not None))
        pass
        for _r4_key, _r4_cell_obj in self.map.items():
            if _r4_cell_obj.room == 4 and _r4_key not in _TUNNELS and _r4_key in _cell_pos:
                _r4_centres_list.append(_cell_pos[_r4_key])   # KALIBRIRANO (row, col)
        if _r4_centres_list:
            # 1) Tight bbox of explored room-4 cell centres
            _bb_rmin = min(r for r, _ in _r4_centres_list)
            _bb_rmax = max(r for r, _ in _r4_centres_list)
            _bb_cmin = min(c for _, c in _r4_centres_list)
            _bb_cmax = max(c for _, c in _r4_centres_list)
            # 2) Room 4 zauzima kut mape → strane bliže rubu šire se DO ruba
            #    (uključujući vanjski zid!), a unutarnje strane +2 (granični zid
            #    između sobe 4 i susjedne sobe također je ★ u službenom rješenju).
            _mid_r = (_r4_rows - 1) / 2.0
            _mid_c = (_r4_cols - 1) / 2.0
            _bb_centre_r = (_bb_rmin + _bb_rmax) / 2.0
            _bb_centre_c = (_bb_cmin + _bb_cmax) / 2.0
            _r4_rmin = 0 if _bb_centre_r < _mid_r else max(0, _bb_rmin - 2)
            _r4_rmax = _r4_rows if _bb_centre_r >= _mid_r else min(_r4_rows, _bb_rmax + 3)
            _r4_cmin = 0 if _bb_centre_c < _mid_c else max(0, _bb_cmin - 2)
            _r4_cmax = _r4_cols if _bb_centre_c >= _mid_c else min(_r4_cols, _bb_cmax + 3)
            pass
            pass
            # 3) Spremi original pa popuni ★
            _orig_map = complete_map.copy()
            complete_map[_r4_rmin:_r4_rmax, _r4_cmin:_r4_cmax] = _ROOM_4
            # 4) Vrati (zaštiti) footprinte istraženih ćelija soba 1-3 i SVIH
            #    tunela: te su ćelije normalno mapirane (npr. r0r RED tunela na
            #    granici 3↔4) i NE smiju postati ★.
            _prot_restored = 0
            for _p_key, _p_cell in self.map.items():
                _is_tunnel = _p_key in _TUNNELS
                _is_other_room = (_p_cell.room in (1, 2, 3)) and getattr(_p_cell, 'explored', False)
                if not (_is_tunnel or _is_other_room):
                    continue
                if _p_key not in _cell_pos:
                    continue
                _p_r, _p_c = _cell_pos[_p_key]   # KALIBRIRANO
                _f_rmin, _f_rmax = _p_r - 1, _p_r + 2
                _f_cmin, _f_cmax = _p_c - 1, _p_c + 2
                # Ako je footprint uz rub mape, zaštiti i sam rub (vanjski zid
                # uz mapirani sadržaj ostaje '1', ne ★)
                if _f_rmin <= 1: _f_rmin = 0
                if _f_rmax >= _r4_rows - 1: _f_rmax = _r4_rows
                if _f_cmin <= 1: _f_cmin = 0
                if _f_cmax >= _r4_cols - 1: _f_cmax = _r4_cols
                _f_rmin = max(0, _f_rmin); _f_rmax = min(_r4_rows, _f_rmax)
                _f_cmin = max(0, _f_cmin); _f_cmax = min(_r4_cols, _f_cmax)
                # Restore samo unutar fill regije
                for _fr in range(max(_f_rmin, _r4_rmin), min(_f_rmax, _r4_rmax)):
                    for _fc in range(max(_f_cmin, _r4_cmin), min(_f_cmax, _r4_cmax)):
                        if complete_map[_fr][_fc] == _ROOM_4:
                            complete_map[_fr][_fc] = _orig_map[_fr][_fc]
                            _prot_restored += 1
            pass
        else:
            pass


        if True:
            _star_count = int(np.sum(complete_map == _ROOM_4))
            pass
            engine_map = np.empty(shape=complete_map.shape, dtype=str)
            # Finally if an _UNDEFINED type dot is present, it will convert it into an _EMPTY.val str and, also, it will
            # convert to str every dot
            #print("-----------------")
            for row in range(len(complete_map)):
                for col in range(len(complete_map[row])):
                    if complete_map[row][col] == _UNDEFINED:
                        engine_map[row][col] = str(_EMPTY.val)
                    elif complete_map[row][col] == _ROOM_4:
                        engine_map[row][col] = '*'
                    elif complete_map[row][col] == _STRONG_EMPTY:
                        engine_map[row][col] = str(_EMPTY.val)
                    elif complete_map[row][col] == _TEMP_WALL:
                        engine_map[row][col] = str(_WALL)
                    elif complete_map[row][col] == _VOID:
                        engine_map[row][col] = str(_EMPTY.val)
                    elif complete_map[row][col] == _OBSTACLE_VAL:
                        engine_map[row][col] = 'x'
                    elif complete_map[row][col] in [_BLUE.val, _BLUE2.val] :
                        engine_map[row][col] = 'b'
                    elif complete_map[row][col] in [_GREEN.val, _GREEN2.val]:
                        engine_map[row][col] = 'g'
                    elif complete_map[row][col] in [_RED.val, _RED2.val]:
                        engine_map[row][col] = 'r'
                    elif complete_map[row][col] in [_PURPLE.val, _PURPLE2.val]:
                        engine_map[row][col] = 'p'
                    elif complete_map[row][col] == _YELLOW.val:
                        engine_map[row][col] = 'y'
                    elif complete_map[row][col] == _YELLOW2.val:
                        # Svaka boja ima SAMO JEDAN tunel u svijetu — "drugi žuti"
                        # je u stvarnosti krivo pročitani ORANGE (H=60 očitanje za oba)
                        engine_map[row][col] = 'o'
                    elif complete_map[row][col] in [_ORANGE.val, _ORANGE2.val]:
                        engine_map[row][col] = 'o'
                    # Žrtve: vrijednosti 30-36 → H, S, U, C, F, O, P
                    elif int(complete_map[row][col]) in _VICTIMS and isinstance(_VICTIMS[int(complete_map[row][col])], str):
                        engine_map[row][col] = _VICTIMS[int(complete_map[row][col])]

                    else:
                        engine_map[row][col] = str(complete_map[row][col])

                #print(engine_map[row])
            return engine_map


    def getBestPath(self, origin: Tuple[int, int] = None, view_map=False, relaxed=False):
        """
        The first part is used to avoid searching the path to all the possible destinations by looking for the ones that
        are next to the origin, the order it searches for is right, forward and left. If this first scanning fails it
        doesn't matter and will proceed as intended, since it's just used to cut some time.

        The second part creates a custom map that is easier to navigate for the A* algorithm

        The third part applies a slightly modified A* algorithm(based on the one that can be seen in the video below)
        to every possible destination and, when all the distances and paths are found, it takes the shortest path as the
        return value. Note that during the general search if it finds a path of length 2 it will take it, since is the
        shortest distance possible after 1.

        A* algorithm video: https://youtu.be/A60q6dcoCjw

        @param origin: Starting point, if None, it will set it to the current coordinates
        @param view_map: Use to view a representation of the map used to find the path
        @return:
        """

        if origin is None:
            origin = getCoords()

        maze.checkToExplore()
        possible_destinations = maze.to_explore

        ################################################################################################################

        corner_bot, corner_top = self.getCorners()

        # Get width and length of the maze
        # --- The +1 is to get every cell in the rectangle, otherwise it would have skipped the last row and column
        width = abs((corner_top[0]) - (corner_bot[0])) + 1
        height = abs((corner_top[1]) - (corner_bot[1])) + 1

        offset_w = -corner_bot[0]
        offset_h = -corner_bot[1]

        # Prepare the custom matrix
        segmented_map = []

        for row in range(width):
            segmented_map.append([])
            for col in range(height):
                if (row - offset_w, col - offset_h) in list(self.map.keys()):
                    _astar_coord = (row - offset_w, col - offset_h)
                    # Tunel-ćelije su uvijek prohodne u A* (isNearTunnel ih inače blokira
                    # pa A* ne može naći put iz sobe 3 → soba 1 prolazom kroz tunel-ćelije)
                    if _astar_coord in _TUNNELS:
                        segmented_map[row].append(_EMPTY.val)
                    else:
                        _c_obj = self.map[_astar_coord]
                        # RELAXED mod: ćelije koje je robot već POSJETIO dokazano
                        # su prohodne — koristi se kad uklještenje (zidovi s obje
                        # strane od lidara) blokira sve standardne putove.
                        _passable = _c_obj.available or (
                            relaxed and getattr(_c_obj, 'explored', False)
                            and _c_obj.cell[2][2] not in (_HOLE.val, _VOID))
                        segmented_map[row].append(_EMPTY.val if _passable else _WALL)
                else:
                    segmented_map[row].append(_WALL)

        segmented_map = np.array(segmented_map)
        segmented_map = np.rot90(segmented_map)
        segmented_map = np.flip(m=segmented_map, axis=0)

        segmented_map = np.pad(segmented_map, (1, 1), 'constant', constant_values=1)
        offset_w += 1
        offset_h += 1

        # KLJUČNO (univerzalno): ćelija na kojoj robot STOJI po definiciji je
        # prohodna — ako ju je lidar u međuvremenu "zazidao" (uklještenje uz
        # prepreku: zidovi s obje strane → available=False), A* bi umro na
        # startu i robot bi zauvijek prijavljivao "Nema puta". Forsiraj origin
        # otvorenim u A* gridu.
        if 0 <= origin[1] + offset_h < segmented_map.shape[0] and 0 <= origin[0] + offset_w < segmented_map.shape[1]:
            segmented_map[origin[1] + offset_h, origin[0] + offset_w] = _EMPTY.val

        if view_map:
            segmented_map[origin[1] + offset_h, origin[0] + offset_w] = 99

            for destination in possible_destinations:
                if segmented_map[destination[1] + offset_h, destination[0] + offset_w] == 0:
                    segmented_map[destination[1] + offset_h, destination[0] + offset_w] = 90

            nice_map = ''
            for row in segmented_map:
                nice_map += Cell.formatDot(str(row).replace('\n', '').replace('[ ', '[')) + '\n'
            #print(nice_map)

        ################################################################################################################

        # noinspection PyShadowingNames
        def pathAStar(curr_map, offset: Tuple[int, int], origin: Tuple[int, int], destination: Tuple[int, int]):
            # noinspection PyShadowingNames
            def potential(node: Tuple[int, int]):
                return math.sqrt((origin[0] - node[0]) ** 2 + (origin[1] - node[1]) ** 2)

            def distance(current: Tuple[int, int], following: Tuple[int, int], rotation: int):
                euclidian_distance = math.sqrt((current[0] - following[0]) ** 2 + (current[1] - following[1]) ** 2)

                weight = 0

                # Calculate the angle between the current node and the following
                angle = (math.atan2(current[0] - following[0], current[1] - following[1])) % (2 * math.pi)
                if angle > math.pi:
                    angle = 2 * math.pi - angle
                else:
                    angle = -angle
                # Convert the angle to degrees
                angle = (angle * 180 / math.pi)
                # Round the angle to 8th of a circle
                angle = (round(angle / 45) * 45) % 360
                # Get the actual angle considering the cell forward as 0°
                angle = angle - rotation

                if angle == 0:
                    weight += -.2

                elif angle == 45:
                    weight += 0.199

                elif angle == 315:
                    weight += .2

                elif angle == 90:
                    weight += .149

                elif angle == 270:
                    weight += .15

                elif angle == 135:
                    weight += .249

                elif angle == 225:
                    weight += .25

                else:
                    weight += .3

                return euclidian_distance + weight

            origin = origin[0] + offset[0], origin[1] + offset[1]
            destination = destination[0] + offset[0], destination[1] + offset[1]

            boundary_nodes = {origin}
            distances = {
                origin: {
                    'distance': 0,
                    'previous': None,
                    'angle': getRotation() * 45
                }
            }

            while len(boundary_nodes) > 0:
                lowest_f_cost = float('inf')
                curr_node = None
                for node in boundary_nodes:
                    if distances[node]['distance'] + potential(node) < lowest_f_cost:
                        lowest_f_cost = distances[node]['distance'] + potential(node)
                        curr_node = node

                boundary_nodes.remove(curr_node)

                ########################################################################################################
                if curr_node == destination:
                    returned_path = copy.copy(set())
                    while distances[curr_node]['previous'] is not None:
                        returned_path.add((curr_node[0] - offset[0], curr_node[1] - offset[1]))
                        curr_node = distances[curr_node]['previous']

                    if distances[destination]['distance'] == 1:
                        destination_potential = 0

                    # Check if the path leads to a hallway, which is preferred by the algorithm
                    elif getRotation() % 2 == 0 and \
                            ((curr_map[destination[0] - 1, destination[1]] == _WALL and
                              curr_map[destination[0] + 1, destination[1]] == _WALL)
                             or
                             (curr_map[destination[0], destination[1] - 1] == _WALL and
                              curr_map[destination[0], destination[1] + 1] == _WALL)):
                        destination_potential = -0.5
                    else:
                        destination_potential = 0

                    return returned_path, distances[destination]['distance'] + destination_potential
                ########################################################################################################

                for shift in {(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)}:
                    neighbour = (curr_node[0] + shift[0], curr_node[1] + shift[1])

                    if curr_map[neighbour[0], neighbour[1]] != _WALL:
                        proposed_distance = distances[curr_node]['distance'] + \
                                            distance(current=curr_node, following=neighbour,
                                                     rotation=distances[curr_node]['angle'])
                        if neighbour not in distances.keys() or distances[neighbour]['distance'] > proposed_distance:
                            distances[neighbour] = {
                                'distance': proposed_distance,
                                'previous': curr_node,
                                'angle': getRotation() * 45
                            }
                            boundary_nodes.add(neighbour)

            pass

            origin = origin[0] - offset[0], origin[1] - offset[1]
            destination = destination[0] - offset[0], destination[1] - offset[1]

            pass

            raise ValueError(destination)

        segmented_map = np.swapaxes(segmented_map, 0, 1)
        paths = dict()
        to_remove = list()

        # OTROVANI CILJ fix: ako je vlastita ćelija u to_explore (STUCK je zna
        # dodati), A* prema njoj vraća PRAZAN put s udaljenošću 0 koji pobjeđuje
        # svaki pravi put → best_path = prazan set → "Nema puta" iako putovi
        # postoje. Origin se NIKAD ne smije natjecati kao destinacija.
        try:
            self.to_explore.remove(origin)
        except (Exception,):
            pass
        # Trajno zabranjene ćelije (LoP zamke) ne smiju biti ciljevi
        for _bc in list(_BANNED_CELLS):
            try:
                self.to_explore.remove(_bc)
            except (Exception,):
                pass

        for destination in possible_destinations:
            if destination == origin or destination in _BANNED_CELLS:
                continue
            try:
                paths[destination] = pathAStar(curr_map=segmented_map, offset=(offset_w, offset_h), origin=origin,
                                               destination=destination)
            except Exception as exc:
                pass
                to_remove.append(exc.args[0])

        if len(to_remove) == len(self.to_explore) > 0:
            # NE šalji LoP odmah — samo obriši nedostupne ćelije i vrati None.
            # findBestPath tunnel fallback (GREEN, RED itd.) mora dobiti šansu pokrenuti se prije kraja.
            for unexplorable_cell in to_remove:
                try:
                    self.to_explore.remove(unexplorable_cell)
                except (Exception,):
                    pass
            pass
        else:
            for unexplorable_cell in to_remove:
                try:
                    self.to_explore.remove(unexplorable_cell)
                except Exception as exc:
                    pass

        if DBG_VERBOSE: pass
        best_path = None
        shortest_found = float('inf')
        for destination, path_dist in paths.items():
            if len(path_dist[0]) == 0:
                continue  # prazan put (cilj == origin) ne smije pobijediti
            if path_dist[1] < shortest_found:
                best_path = path_dist[0]
                shortest_found = path_dist[1]

        if best_path is not None:
            dest = [k for k,v in paths.items() if v[0] == best_path][0] if paths else '?'
            if DBG_VERBOSE: pass
        else:
            pass
        return best_path

    def changeCurrentRoom(self, tunnel_colour):
        # Normalna tablica prijelaza: tunel boja → odredišna soba
        change_from_1 = {"BLUE": 2, "YELLOW": 3, "GREEN": 4}
        change_from_2 = {"BLUE": 1, "PURPLE": 3, "ORANGE": 4}
        change_from_3 = {"YELLOW": 1, "PURPLE": 2, "RED": 4}
        change_from_4 = {"GREEN": 1, "ORANGE": 2, "RED": 3}
        lookup = {1: change_from_1, 2: change_from_2, 3: change_from_3, 4: change_from_4}  # soba 1 → može u 2, 3 ili 4 ovisno o boji tunela

        # Svaka boja tunela ima točno 2 krajnje sobe:
        _endpoints = {
            "BLUE": (1, 2), "YELLOW": (1, 3), "GREEN": (1, 4),  # odaberi tablicu prijelaza za trenutnu sobu
        }

        if self.current_room in lookup and tunnel_colour in lookup[self.current_room]:
            # Normalan prijelaz
            self.current_room = lookup[self.current_room][tunnel_colour]
        elif tunnel_colour in _endpoints:
            # Fallback: robot je u "krivoj" sobi (tracking pogreška) — koristi boju
            # tunela da se odredi odredišna soba bez obzira na trenutnu sobu.
            r1, r2 = _endpoints[tunnel_colour]
            if self.current_room == r1:
                self.current_room = r2
            elif self.current_room == r2:
                self.current_room = r1
            else:
                # Robot ni u jednoj od dviju soba ovog tunela → idemo u "dalju" sobu
                _old_room = self.current_room
                self.current_room = r2
                pass
        else:
            pass
            

########################################################################################################################
# Methods initialization

def getAngle() -> float:
    """
    Gets the current angle in radiants and converts it to normal degrees(0 is north and goes clockwise)

    @return: The direction you're looking at in degrees
    """
    angle = (inertial_unit.getRollPitchYaw()[2] * 180 / math.pi + 360) % 360
    if angle > 180:
        angle = 360 - angle
    else:
        angle = -angle  # dohvati kut iz IMU i pretvori u stupnjeve (0°=sjever, CW)
    return angle % 360


def getLidarValue(angle: int) -> float:
    global curr_cloud

    if curr_cloud is None:
        return float('inf')

    index_central_ray = round((angle % 360) * 1.422) - 1  # Multiply by the ratio 512 / 360
    # Get the 3 rays around that angle
    rays = [
        curr_cloud[(index_central_ray - 1) % 512],
        curr_cloud[index_central_ray % 512],  # pretvori kut u lidar indeks (512 zraka / 360°)
        curr_cloud[(index_central_ray + 1) % 512]
    ]  # uzmi 3 susjedne zrake radi otpornosti na šum
    average = sum(rays) / 3
    standard_deviation = math.sqrt(((rays[0] - average) ** 2 + (rays[1] - average) ** 2 + (rays[2] - average) ** 2) / 3)

    if standard_deviation >= 0.02:
        avg_left = (rays[0] + rays[1]) / 2  # srednja vrijednost 3 zrake
        sd_left = math.sqrt(((rays[0] - avg_left) ** 2 + (rays[1] - avg_left) ** 2) / 2)  # visoka devijacija → šum → traži stabilniju grupu

        avg_right = (rays[1] + rays[2]) / 2
        sd_right = math.sqrt(((rays[1] - avg_right) ** 2 + (rays[2] - avg_right) ** 2) / 2)

        if sd_left >= 0.02 and sd_right >= 0.02:
            return min(rays)
        elif sd_left < 0.02 and sd_right < 0.02:
            return average
        else:
            if sd_left < 0.02:
                return min(avg_left, rays[2])

            if sd_right < 0.02:
                return min(rays[0], avg_right)

    return average


def getMinLidarValue(angle, fov_indexs):
    true_lidar_values = lidar.range_image[512 * _LIDAR_LAYER:512 * (_LIDAR_LAYER + 1):]
    index_c_ray = round((angle % 360) * 1.422) - 1

    return min(true_lidar_values[ray % 512] for ray in range(-fov_indexs + index_c_ray, fov_indexs + 1 + index_c_ray))


def ckWallLidar(angle: int, limit: Literal[
    'R1', 'R1.5', 'R2', 'R2.5', 'R3',  # minimum unutar kutnog raspona
]):
    global _LIDAR_LIMIT
    
    if limit == "B1" or limit == "R1":
        lidar_val = getLidarValue(angle)
        if _LIDAR_LIMIT[limit][0] <= lidar_val <= _LIDAR_LIMIT[limit][1]:
            return 1
        elif lidar_val < _LIDAR_LIMIT[limit][0]:  # B1/R1: provjeri jednu zraku direktno
            return -1
        else:
            return 0

    elif limit == "CB" or limit == "CR":
        lidar_val = getLidarValue(angle)
        if  lidar_val <= _LIDAR_LIMIT[limit][0]:
            return 1
        else:  # CB/CR: provjeri samo donju granicu udaljenosti
            return 0
    else:
        counter_in_range = 0
        counter_lower = 0
        for i in range(angle - 2, angle + 3):
            lidar_val = getLidarValue(angle)
            if _LIDAR_LIMIT[limit][0] <= lidar_val <= _LIDAR_LIMIT[limit][1]:  # ostalo: provjeri 5 zraka u rasponu ±2° i glasaj
                counter_in_range += 1
            elif lidar_val < _LIDAR_LIMIT[limit][0]:
                counter_lower += 1
            else:
                pass

        if counter_in_range > 2:
            return 1
        elif counter_lower > 2:
            return -1
        else:  # ≥ 3 zrake u rasponu → zid (vraća 1)
            return 0


def getCoords(divisor: float = 6, round_to_int: bool = True) -> Tuple:
    """
    Gets the X and Z coordinates from the gps, since Y is basically useless. Gets the current coords in a grid like
    pattern if the params are set to default, you can do some nice stuff if you modify them.
    For clarity, the * 100 is needed to convert from meters to centimeters

    @param divisor: Is 6 by default, needed to have a more precise coordinate system based on half-tiles
    @param round_to_int: Is True by default, Needed to have a precise reading
    @return: Gets the current (X, Z) coordinates, in cm's
    """
    if round_to_int:
        return tuple(round(coord * 100 / divisor) for coord in gps.getValues()[::2])
    else:
        return tuple(round(coord * 100 / divisor, 3) for coord in gps.getValues()[::2])


def getRotation() -> int:  # ne zaokruži (precizne koordinate)
    """
    Gets the current angle in degrees and converts it to the number of 90°/45° rotations from north clockwise

    @return: The number of 90°/45° rotations from north clockwise
    """
    return round(getAngle() / 45) % 8


def getNearCoords(angle: int, distance=1, from_coord: Tuple[int, int] = None) \
        -> Tuple[int, int]:  # vrati indeks rotacije (0=N, 1=NE, 2=E, … 7=NW)
    """
    Gets the coordinate of a half-tile in the direction specified, with 0 meaning in front of it and going on clockwise

    @param from_coord: The current coordinates by default, the coordinates of the origin of motion
    @param angle: The turn the robot would need to do for it to get the coordinate in front
    @param distance: How many half-tiles to go in that direction
    @return: The coordinate of a half-tile in the direction specified
    """
    angle = abs(round(angle / 45) + getRotation() + 8) % 8

    if from_coord is None:
        from_coord = getCoords()

    def shiftCoord(coord: Tuple[int, int], direction: Literal[0, 1, 2, 3]):
        nonlocal distance
        direction = direction % 4
        if direction == 0:
            return coord[0], coord[1] - distance
        if direction == 1:
            return coord[0] + distance, coord[1]
        if direction == 2:
            return coord[0], coord[1] + distance
        if direction == 3:
            return coord[0] - distance, coord[1]

    returned_coord = shiftCoord(from_coord, angle // 2)

    if angle % 2 == 1:
        returned_coord = shiftCoord(returned_coord, (angle + 1) // 2)

    return returned_coord


def addCells(central_coords):
    _pre_size = len(maze.map)
    # (log at end of function - see below)
    #print("Current coords: ", central_coords)

    # --- Čitanje ravnih (perpendikularnoh) senzora zidova ---
    r_f = ckWallLidar(0,   'R1')   # naprijed
    r_r = ckWallLidar(90,  'R1')   # desno
    r_b = ckWallLidar(180, 'R1')   # nazad
    r_l = ckWallLidar(270, 'R1')   # lijevo

    # --- Čitanje dijagonalnih (kutnih) senzora ---
    b_fr = ckWallLidar(45,  'B1')  # naprijed-desno
    b_br = ckWallLidar(135, 'B1')  # nazad-desno
    b_bl = ckWallLidar(225, 'B1')  # nazad-lijevo
    b_fl = ckWallLidar(315, 'B1')  # naprijed-lijevo
    if len(maze.map) > _pre_size:  # provjeri dijagonale: FR, BR, BL, FL
        if DBG_VERBOSE or len(maze.map)-_pre_size > 5: pass

    # --- Inferencija kutnih zidova ---
    # Ako su OBA susjedna ravna zida detektirana (=1), geometrija jamči da je kutak zid.
    # Ovo popravlja slučajeve gdje dijagonalni lidar sken nije detektirao kutak (vratio 0),
    # a robot nije mogao proći pored njega (ili nije prošao).
    if b_fr == 0 and r_f == 1 and r_r == 1:  # zaključi kutni zid iz dva ravna zida (geometrija)
        b_fr = 1
    if b_br == 0 and r_b == 1 and r_r == 1:
        b_br = 1
    if b_bl == 0 and r_b == 1 and r_l == 1:
        b_bl = 1
    if b_fl == 0 and r_f == 1 and r_l == 1:
        b_fl = 1

    maze.__add__({
        central_coords:
            Cell(explored=True,   # FIX: sprječava phantom walls (_UNDEFINED→_WALL)
                 dsf=r_f, dsr=r_r,
                 dsb=r_b, dsl=r_l,  # dodaj skeniranu ćeliju i 8 susjednih polu-pločica u mapu
                 fr=b_fr, br=b_br,
                 bl=b_bl, fl=b_fl,
                 ds0=ckWallLidar(360 - _LIDAR_ANGLES['K1'], 'K1'), ds1=ckWallLidar(_LIDAR_ANGLES['K1'], 'K1'),
                 ds2=ckWallLidar(90 - _LIDAR_ANGLES['K1'], 'K1'), ds3=ckWallLidar(90 + _LIDAR_ANGLES['K1'], 'K1'),
                 ds4=ckWallLidar(180 - _LIDAR_ANGLES['K1'], 'K1'), ds5=ckWallLidar(180 + _LIDAR_ANGLES['K1'], 'K1'),
                 ds6=ckWallLidar(270 - _LIDAR_ANGLES['K1'], 'K1'), ds7=ckWallLidar(270 + _LIDAR_ANGLES['K1'], 'K1'),
                 ),
        getNearCoords(angle=0, distance=2, from_coord=central_coords):
            Cell(),
        getNearCoords(angle=45, distance=2, from_coord=central_coords):
            Cell(),
        getNearCoords(angle=90, distance=2, from_coord=central_coords):
            Cell(),
        getNearCoords(angle=135, distance=2, from_coord=central_coords):
            Cell(),
        getNearCoords(angle=180, distance=2, from_coord=central_coords):
            Cell(),
        getNearCoords(angle=225, distance=2, from_coord=central_coords):
            Cell(),
        getNearCoords(angle=270, distance=2, from_coord=central_coords):
            Cell(),
        getNearCoords(angle=315, distance=2, from_coord=central_coords):
            Cell()
    })


def bgra_to_hsv(bgra_color):
    # Normalize the RGB values to be in the range [0, 1]
    r = bgra_color[2] / 255.
    g = bgra_color[1] / 255.
    b = bgra_color[0] / 255.

    # Convert the RGB color to an HSV color
    h, s, v = colorsys.rgb_to_hsv(r, g, b)

    # Scale the hue value to be in the range [0, 360]
    h = int(h * 360)

    # Scale the saturation and value values to be in the range [0, 1]
    s, v = round(s, 3), round(v, 3)

    # Return the HSV color as a tuple
    return h, s, v


def getColor() -> Tuple[int, float, float]:
    """
    Gets the color from the color sensor, which points to a single pixel on the floor in front of the robot, and
    transform it to an BGRA tuple. Also note that the distance of the point is not following any type of grid

    @return: A tuple with HSV values
    """
    # noinspection PyUnresolvedReferences
    color = color_sensor.getImage()
    
    
    color = struct.unpack('BBBB', color)
    #print(color)
    return bgra_to_hsv(color)


def checkColor(color: Tuple[int, float, float], color_range: Dict[Literal['min', 'max'], Tuple[int, float, float]]) \
        -> bool:  # pretvori u HSV i vrati
    """
    Check if the color given is within the range given

    @param color: The color checked in HSV format
    @param color_range: A dictionary that follows this format: {'min': hsv(0, 0, 0), 'max': (360, 1, 1)}
    @return: True if every color is within the range, otherwise False
    """
    return all(color_range['min'][i] <= color[i] <= color_range['max'][i] for i in range(3))


def coordInGrid(coord: Tuple[int, int]) -> bool:
    """
    Check if the given coordinate is following the tile pattern and not the half-tile's

    @param coord: The coordinate to check
    @return: True if it does follow the tile pattern, otherwise False
    """
    return abs(coord[0]) % 2 == abs(maze.start[0]) % 2 and abs(coord[1]) % 2 == abs(maze.start[1]) % 2


def placeAndHandleHole(hole_coordinate: Tuple[int, int], possible_offset: int, is_void=False):
    # UNIVERZALNO PRAVILO: rupa NIKAD ne proširuje granice poznatog svijeta.
    # Crnilo IZA ruba svijeta senzorima izgleda identično rupi. Prava rupa
    # unutar svijeta uvijek je okružena poznatim ćelijama (pod/zidovi koje je
    # lidar već dodao u mapu), pa pada UNUTAR bbox-a svih ne-rupa ćelija.
    # Koordinata izvan bbox-a = rub svijeta → ne upisuj rupu (proširila bi
    # matricu i srušila poravnanje), samo prijavi prepreku.
    # NAPOMENA: ne pokušavamo "pametno" pomicati rupu na bližu ćeliju — kamera
    # legitimno vidi crnilo i 2 ćelije ispred preko još neistraženog poda, pa
    # bi pomicanje stvaralo fantomske rupe NA podu (blokira uske prolaze!).
    _hx, _hy = hole_coordinate
    _bb_keys = [k for k, c in maze.map.items() if c.cell[2][2] not in (_HOLE.val, _VOID)]
    if _bb_keys:
        _bxmin = min(k[0] for k in _bb_keys); _bxmax = max(k[0] for k in _bb_keys)
        _bymin = min(k[1] for k in _bb_keys); _bymax = max(k[1] for k in _bb_keys)
        if not (_bxmin <= _hx <= _bxmax and _bymin <= _hy <= _bymax):  # sve ćelije koje nisu rupe ili void
            pass
            return True  # bounding box poznatog svijeta
    pass
    # TODO: Add doc
    if not coordInGrid(hole_coordinate):
        hole_coordinate = getNearCoords(from_coord=hole_coordinate, angle=possible_offset)
    if not coordInGrid(hole_coordinate):
        hole_coordinate = getNearCoords(from_coord=hole_coordinate, angle=(possible_offset * 3) % 360)

    # LIDAR FIT-PROVJERA (univerzalno): prava rupa je ODSUTNOST — kroz nju
    # lidar vidi daleko (zid iza). Ako lidar vidi nešto ČVRSTO unutar raspona
    # navodne rupe, to je PREPREKA (crna kutija) ili zid → preskoči potpuno.
    _wp_fwd = None
    try:
        if True:
            _wp_rx, _wp_ry = getCoords()
            _wp_dx, _wp_dy = hole_coordinate[0] - _wp_rx, hole_coordinate[1] - _wp_ry
            _wp_dist = abs(_wp_dx) + abs(_wp_dy)
            if abs(_wp_dx) == 1 == abs(_wp_dy):
                # DIJAGONALNA detekcija: ćelija na ~8.5cm. Prava rupa → lidar
                # naprijed vidi daleko; čvrsto unutar ~10.5cm = prepreka.
                _wp_rays = sorted(
                    lidar.range_image[512 * _LIDAR_LAYER + (round((a % 360) * 1.422) - 1) % 512]
                    for a in (354, 356, 358, 0, 2, 4, 6)
                )
                if _wp_rays[3] < 0.105:
                    pass
                    return True
            elif getRotation() % 2 == 0 and _wp_dist in (1, 2) and (_wp_dx == 0 or _wp_dy == 0):
                _wp_rays = sorted(
                    lidar.range_image[512 * _LIDAR_LAYER + (round((a % 360) * 1.422) - 1) % 512]
                    for a in (354, 356, 358, 0, 2, 4, 6)
                )
                _wp_fwd = _wp_rays[3]  # median: zalutale zrake ne smetaju
                _wp_sx = (_wp_dx > 0) - (_wp_dx < 0)
                _wp_sy = (_wp_dy > 0) - (_wp_dy < 0)
                # Maks. udaljenost ćelije rupe koja STANE ispred zida na _wp_fwd:
                # ćelija na dist d zauzima [d*6-3, d*6+3]cm → d_max = (W-2.5cm)//6cm
                _wp_fit = int((_wp_fwd - 0.025) // 0.06)
                if _wp_fit < _wp_dist:
                    # Lidar vidi nešto ČVRSTO unutar raspona navodne rupe.
                    # Prava rupa je ODSUTNOST — kroz nju lidar vidi daleko.
                    # Čvrsta površina tu = PREPREKA (crna kutija) ili zid, NE
                    # rupa → ne upisuj ništa (premještanje bliže bi stvorilo
                    # fantomsku rupu na ćeliji prepreke i nearHole bi zaključao
                    # regiju!). Pravu rupu ionako označi sljedeća detekcija s
                    # valjane udaljenosti.
                    pass
                    return True
    except Exception as _wp_err:
        if DBG_VERBOSE: pass

    if is_void:
        maze.__add__({hole_coordinate: Cell(c_t=_VOID)})
    else:
        maze.__add__({hole_coordinate: Cell(c_t=_HOLE.val)})

    # Zid iza rupe: ako lidar vidi zid odmah iza rupe, upiši ga na suprotnu
    # stranu hole ćelije (robot se odmakne pa ga inače nikad ne mapira).
    try:
        if _wp_fwd is not None:
            _wp_dx, _wp_dy = hole_coordinate[0] - _wp_rx, hole_coordinate[1] - _wp_ry
            _wp_dist = abs(_wp_dx) + abs(_wp_dy)
            if _wp_dist in (1, 2) and (_wp_dx == 0 or _wp_dy == 0) and _wp_fwd < _wp_dist * 0.06 + 0.075:
                if _wp_dx > 0:
                    _wp_r, _wp_c, _wp_s = 2, 4, 'E'
                elif _wp_dx < 0:
                    _wp_r, _wp_c, _wp_s = 2, 0, 'W'
                elif _wp_dy > 0:
                    _wp_r, _wp_c, _wp_s = 4, 2, 'S'
                else:
                    _wp_r, _wp_c, _wp_s = 0, 2, 'N'
                maze.map[hole_coordinate].cell[_wp_r][_wp_c] = _WALL
                pass
    except Exception as _wp_err:
        if DBG_VERBOSE: pass

    if maze.map[hole_coordinate].nearHole:
        maze.removeToExploreArea(hole_coordinate)
        maze.map[hole_coordinate].explored = True
        return True
    else:
        return False


def checkAndPlaceTile(tile: Dot, color: Tuple[int, float, float]):
    if getRotation() % 2 == 1 or not checkColor(color, tile.color_range):
        return False
    if coordInGrid(getNearCoords(0)):
        maze.__add__({getNearCoords(0): Cell(c_t=tile.val)})
        _tname = {_CHECKPOINT.val:'CHECKPOINT', _SWAMP.val:'SWAMP', _START:'START'}.get(tile.val, str(tile.val))
        pass
        return True
    return False


def checkAndPlaceTunnel(tunnel: Tunnel, color: Tuple[int, float, float], color_name: str):
    # TODO: Add doc
    global obstruction_found, _BLUE, _RED, _YELLOW, _GREEN, _ORANGE, _PURPLE, _TUNNELS

    if tunnel.val == 15:
        if not tunnel.found and checkColor(color, tunnel.color_range) and coordInGrid(getNearCoords(0)) and _BLUE.found and \
        getNearCoords(0) not in _TUNNELS:
            pass
            tunnel.coord = getNearCoords(0)

            maze.__add__({tunnel.coord: Cell(c_t=tunnel.val, explored=True)})

            maze.removeToExploreArea(tunnel.coord)
            _TUNNELS[tunnel.coord] = color_name

            tunnel.found = True
            obstruction_found = False  # FIX: tunel nije prepreka - robot mora prijeći pločicu
            return True

    elif tunnel.val == 16:
        if not tunnel.found and checkColor(color, tunnel.color_range) and coordInGrid(getNearCoords(0)) and _PURPLE.found and \
        getNearCoords(0) not in _TUNNELS:
            pass
            tunnel.coord = getNearCoords(0)

            maze.__add__({tunnel.coord: Cell(c_t=tunnel.val, explored=True)})
            
            maze.removeToExploreArea(tunnel.coord)
            _TUNNELS[tunnel.coord] = color_name

            tunnel.found = True
            obstruction_found = False  # FIX: tunel nije prepreka - robot mora prijeći pločicu
            return True

    elif tunnel.val == 17:
        if not tunnel.found and checkColor(color, tunnel.color_range) and coordInGrid(getNearCoords(0)) and _RED.found and \
        getNearCoords(0) not in _TUNNELS:
            pass
            tunnel.coord = getNearCoords(0)

            maze.__add__({tunnel.coord: Cell(c_t=tunnel.val, explored=True)})
            
            maze.removeToExploreArea(tunnel.coord)
            _TUNNELS[tunnel.coord] = color_name

            tunnel.found = True
            obstruction_found = False  # FIX: tunel nije prepreka - robot mora prijeći pločicu
            return True

    elif tunnel.val == 18:
        if not tunnel.found and checkColor(color, tunnel.color_range) and coordInGrid(getNearCoords(0)) and _GREEN.found and \
        getNearCoords(0) not in _TUNNELS:
            pass
            tunnel.coord = getNearCoords(0)

            maze.__add__({tunnel.coord: Cell(c_t=tunnel.val, explored=True)})
            
            maze.removeToExploreArea(tunnel.coord)
            _TUNNELS[tunnel.coord] = color_name

            tunnel.found = True
            obstruction_found = False  # FIX: tunel nije prepreka - robot mora prijeći pločicu
            return True

    elif tunnel.val == 19:
        if not tunnel.found and checkColor(color, tunnel.color_range) and coordInGrid(getNearCoords(0)) and _YELLOW.found and \
        getNearCoords(0) not in _TUNNELS:
            pass
            tunnel.coord = getNearCoords(0)

            maze.__add__({tunnel.coord: Cell(c_t=tunnel.val, explored=True)})
            
            maze.removeToExploreArea(tunnel.coord)
            _TUNNELS[tunnel.coord] = color_name

            tunnel.found = True
            obstruction_found = False  # FIX: tunel nije prepreka - robot mora prijeći pločicu
            return True

    elif tunnel.val == 20:
        if not tunnel.found and checkColor(color, tunnel.color_range) and coordInGrid(getNearCoords(0)) and _ORANGE.found and \
        getNearCoords(0) not in _TUNNELS:
            pass
            tunnel.coord = getNearCoords(0)

            maze.__add__({tunnel.coord: Cell(c_t=tunnel.val, explored=True)})
            
            maze.removeToExploreArea(tunnel.coord)
            _TUNNELS[tunnel.coord] = color_name

            tunnel.found = True
            obstruction_found = False  # FIX: tunel nije prepreka - robot mora prijeći pločicu
            return True

    else:
        if not tunnel.found and checkColor(color, tunnel.color_range) and coordInGrid(getNearCoords(0)) \
                and getNearCoords(0) not in _TUNNELS:  # FIX: ne postavljaj na već poznati tunel
            pass
            tunnel.coord = getNearCoords(0)

            maze.__add__({tunnel.coord: Cell(c_t=tunnel.val, explored=True)})

            maze.removeToExploreArea(tunnel.coord)
            _TUNNELS[tunnel.coord] = color_name

            tunnel.found = True
            obstruction_found = False  # FIX: tunel nije prepreka - robot mora prijeći pločicu
            # Proaktivno dodaj tunel u to_explore - A* planira put do njega ODMAH
            pass
            maze.to_explore.add(tunnel.coord)
            # Dodaj i neistražene susjede (ćelije s druge strane tunela)
            for _pt_ang in (0, 90, 180, 270):
                _pt_nb = getNearCoords(angle=_pt_ang, from_coord=tunnel.coord)
                if _pt_nb in maze.map and not maze.map[_pt_nb].explored:
                    maze.to_explore.add(_pt_nb)
            return True
    return False


def insideSwamp() -> bool:
    """
    Checks if the robot is inside a cell within a swamp(it reduces speed by 32%)

    @return: True if the robot is in a swamp, otherwise False
    """
    return any(_SWAMP.val in row for row in maze.map[getCoords()].cell)


def shiftMatrix(direction: Literal['up', 'down', 'left', 'right'], repeat: int, old_list: List[List]):
    _row_lens = set(len(r) for r in old_list) if old_list else set()
    if len(_row_lens) > 1:
        pass
    """
    Cool function that shifts a matrix around its axis found at:
    https://stackoverflow.com/questions/19878280/efficient-way-to-shift-2d-matrices-in-both-directions
    The function is modified to match the needs of the code

    @param direction: The direction of the operation
    @param repeat: How many times the operation is needed
    @param old_list: The list to shift
    @return: The shifted list
    """
    height = len(old_list)
    width = len(old_list[0])
    if direction == "up":
        return [old_list[i % height] for i in range(repeat, repeat + height)]
    elif direction == "down":
        return [old_list[-i] for i in range(repeat, repeat - height, -1)]
    elif direction == "left":
        tlist = list(zip(*old_list))
        return list(map(list, zip(*[tlist[i % width] for i in range(repeat, repeat + width)])))
    elif direction == "right":
        tlist = list(zip(*old_list))
        return list(map(list, zip(*[tlist[-i] for i in range(repeat, repeat - width, -1)])))

    else:
        pass
        return old_list


def new_speed(multi: float = 1, incr: float = 0) -> float:
    """
    Multiplies the _MAX_VELOCITY to get a new adjusted speed

    @param multi: The speed multiplier
    @param incr: The speed increment
    @return: The new speed
    """
    global turn_multi
    return multi * _MAX_VELOCITY * turn_multi[0] + incr, multi * _MAX_VELOCITY * turn_multi[1] + incr


def is_turning() -> bool:
    return speeds[0] * speeds[1] < 0


def getLegalMoves() -> List[Tuple[int, int]]:  # vrati (brzina_lijevi, brzina_desni)
    """
    Gets all the coordinates the robot can move at the current position

    @return: A list of all the legal moves  # suprotni predznaci brzina ↔ okretanje
    """
    return [getNearCoords(angle) for angle in _MVMT_ANGLES if maze.map[getNearCoords(angle)].canBeAvailable]


def getLegalCoordAngle():
    legal_moves = {getNearCoords(angle): angle for angle in _MVMT_ANGLES
                   if maze.map[getNearCoords(angle)].canBeAvailable}
    for key in legal_moves.keys():
        corrected_angle = (math.atan2(getCoords(round_to_int=False)[0] - key[0],  # filtriraj dostupne susjede u svih 8 smjerova
                                      getCoords(round_to_int=False)[1] - key[1])) % (2 * math.pi)
        if corrected_angle > math.pi:
            corrected_angle = 2 * math.pi - corrected_angle
        else:
            corrected_angle = -corrected_angle
        legal_moves[key] = (corrected_angle * (180 / math.pi)) % 360
    return legal_moves


def chooseDirection(move: int = -1):
    """
    Chooses the new direction the robot needs to go towards

    @param move: If set, it contains the next move the robot needs to do, which probably was chosen by this very method
    @return: Doc needs revisit
    """
    global turn_multi, next_angle

    def stayPut():
        nonlocal next_rotation
        global turn_multi
        next_rotation = 0
        turn_multi = [1, 1]
        return 0

    def moveInDirection(direction: int):  # ostani na mjestu: resetiraj rotaciju i multiplikator
        """
        Given a direction to follow in degrees, it executes the corresponding function

        @param direction: The direction starting from 0 in front of the robot and going clockwise(-1 does nothing)
        @return: The result of the operation, 1 if it did something and 0 otherwise
        """
        if direction < 0:
            return stayPut()

        # For some reason left and right are inverted, the following 'if' statement handles that
        global turn_multi, next_move
        nonlocal next_rotation

        if direction == 0:
            turn_multi = [1, 1]
            next_rotation = 0
            next_move = -1
            return 1

        if (direction - getAngle()) % 360 >= 180:
            turn_multi = [1, -1]
        else:
            turn_multi = [-1, 1]

        next_move = 0
        next_rotation = direction

        return 1

    def findBestPath(possible_moves, recursive_counter: int = 0):
        if recursive_counter > 0:
            pass
        global curr_path, _BLUE, _BLUE2, _PURPLE, _PURPLE2, _RED, _RED2, _GREEN, _GREEN2, _YELLOW, _YELLOW2 \
        ,_ORANGE, _ORANGE2, curr_obj

        if recursive_counter > 1:
            if getCoords()[0] == maze.start[0] and getCoords()[1] == maze.start[1]:
                delay(500)
                initiateEndSequence()
                delay(500)
                return
            else:
                maze.checkToExplore()  # rekurzivna dubina > 1 → ili završi ili resetiraj explore

                try:
                    if len(possible_moves.keys()) == 1:
                        curr_path = {next(iter(possible_moves))}
                    elif recursive_counter <= 3 and struct.unpack('c', receiver.getBytes())[0].decode("utf-8") == 'L':
                        pass
                    elif recursive_counter > 2:
                        pass
                        pass
                        pass
                        initiateEndSequence()
                except (Exception,):
                    pass

        # If the robot currently doesn't have a path it will try to find a new one
        if curr_path is None or len(curr_path) == 0:
            try:
                curr_path = maze.getBestPath(view_map=False)
            except Exception as exc:
                pass

        # FIX: ako je robot NA tunel-ćeliji s praznom putanjom (pathAStar(X→X) = {}),
        # NE pokreći tunnel fallback (to bi povećalo recursive_counter do "Oh no" limita).
        # Fizički pomakni robota prema neistraženom susjedi (druga soba) ili u bilo koji smjer
        # koji nije odakle smo došli — to triggerira last_coords in _TUNNELS → changeCurrentRoom.
        if curr_path is not None and len(curr_path) == 0 and getCoords() in _TUNNELS:
            # Prioritet: neistraženi susjedi (strana druge sobe)
            for _tc, _td in possible_moves.items():
                if _tc in maze.map and not maze.map[_tc].explored:
                    pass
                    moveInDirection(_td)
                    return
            # Fallback: bilo koji smjer koji nije odakle smo došli
            for _tc, _td in possible_moves.items():
                if _tc != last_coords:
                    pass
                    moveInDirection(_td)
                    return
            return  # nema legalnih poteza

        # If the path to the nearest unexplored cell doesn't exist, these are the possibilities:
        # - The robot has fully explored the previous area and is now going to go to the next one
        # - The robot has fully explored the map and is now going to go to the starting tile
        if curr_path is None or len(curr_path) == 0:
            pass
            pass
            # FIX: dodaj i neistražene susjede tunela (ćelije s DRUGE strane), ne samo sam tunel.
            # Tunel sam može biti već "explored" ili biti uklonjen od checkToExplore jer ima 3+ istražena susjeda.
            # Susjed s druge strane ima samo 3 istražena susjeda (prag sada 4) → preživljava pruning.
            def _add_tunnel_target(t_coord):
                maze.to_explore.add(t_coord)  # sam tunel kao fallback
                for _ang in (0, 90, 180, 270):
                    _nb = getNearCoords(angle=_ang, from_coord=t_coord)
                    if _nb in maze.map and not maze.map[_nb].explored:
                        maze.to_explore.add(_nb)  # neistraženi susjed = ćelija u novoj sobi

            if _BLUE.coord is not None:
                _add_tunnel_target(_BLUE.coord)
                _BLUE.coord = None
            elif _BLUE2.coord is not None:
                _add_tunnel_target(_BLUE2.coord)
                _BLUE2.coord = None
            elif _PURPLE.coord is not None:
                _add_tunnel_target(_PURPLE.coord)
                _PURPLE.coord = None
            elif _PURPLE2.coord is not None:
                _add_tunnel_target(_PURPLE2.coord)
                _PURPLE2.coord = None
            elif _RED.coord is not None:
                _add_tunnel_target(_RED.coord)
                _RED.coord = None
            elif _RED2.coord is not None:
                _add_tunnel_target(_RED2.coord)
                _RED2.coord = None
            elif _GREEN.coord is not None:
                _add_tunnel_target(_GREEN.coord)
                _GREEN.coord = None
            elif _GREEN2.coord is not None:
                _add_tunnel_target(_GREEN2.coord)
                _GREEN2.coord = None
            elif _YELLOW.coord is not None:
                _add_tunnel_target(_YELLOW.coord)
                _YELLOW.coord = None
            elif _YELLOW2.coord is not None:
                _add_tunnel_target(_YELLOW2.coord)
                _YELLOW2.coord = None
            elif _ORANGE.coord is not None:
                _add_tunnel_target(_ORANGE.coord)
                _ORANGE.coord = None
            elif _ORANGE2.coord is not None:
                _add_tunnel_target(_ORANGE2.coord)
                _ORANGE2.coord = None
            else:
                if recursive_counter >= 1:
                    # AMNESTIJA ZIDOVA: "nema puta" uz nepraznu to_explore listu
                    # gotovo uvijek znači da su privremeni zidovi (prepreke /
                    # stuck handling) ZAZIDALI robota — npr. world3 kraj na
                    # t=59s s 26% mape. Obriši temp zidove i pokušaj ponovo;
                    # tek ako nema što brisati, stvarno završi.
                    _amn = globals().get('_WALL_AMNESTY_COUNT', 0)
                    _amn_cleared = 0
                    if _amn < 5:
                        globals()['_WALL_AMNESTY_COUNT'] = _amn + 1
                        for _amn_cell in maze.map.values():
                            for _ar in range(5):
                                for _ac in range(5):
                                    if _amn_cell.cell[_ar][_ac] == _TEMP_WALL:
                                        _amn_cell.cell[_ar][_ac] = _STRONG_EMPTY if (_ar, _ac) == (2, 2) else _UNDEFINED
                                        _amn_cleared += 1
                        pass
                    if _amn_cleared == 0:
                        # ZADNJA OBRANA: relaksirani A* kroz posjećene ćelije.
                        # Uklještenje uz prepreku (zidovi s obje strane) blokira
                        # standardnu dostupnost čak i za koridor kojim je robot
                        # DOŠAO — ali posjećene ćelije su dokazano prohodne.
                        _rx_path = None
                        try:
                            _rx_path = maze.getBestPath(relaxed=True)
                        except Exception as _rx_err:
                            pass
                        if _rx_path:
                            pass
                            curr_path = _rx_path
                            return
                        pass
                        pass
                        initiateEndSequence()
                        return
                maze.to_explore.add(maze.start)
                pass

            findBestPath(possible_moves=possible_moves, recursive_counter=recursive_counter + 1)
            return

        # Under normal circumstances the robot finds the current move that needs to be done by intersecting the legal
        # moves with the path to take
        curr_move = set(possible_moves.keys()).intersection(curr_path)

        try:
            curr_move = next(iter(curr_move))  # Takes the only element in the set
            moveInDirection(direction=possible_moves[curr_move])
            curr_obj = curr_move[0] * 6, curr_move[1] * 6
            curr_path.remove(curr_move)
        except (Exception,):
            # This is just a mess
            maze.checkToExplore()
            pass
            if maze.getBestPath() == None:
                delay(500)
                initiateEndSequence()
                delay(500)  # sjecište legalnih poteza s putanjom = sljedeći korak
                return
                
            elif len(curr_move) == 0 and len(curr_path.intersection(actual_path := maze.getBestPath())) < len(curr_path):  # kreni u smjeru jednog elementa skupa
                pass
                curr_path = actual_path
                findBestPath(possible_moves=possible_moves, recursive_counter=recursive_counter + 1)
                return
            elif receiver.getQueueLength() > 0:
                # Detects LoP
                if struct.unpack('c', receiver.getBytes())[0].decode("utf-8") == 'L':
                    pass
                    delay(500)
                    initiateEndSequence()
                    delay(500)
                    curr_path = maze.getBestPath()
                    findBestPath(possible_moves=getLegalCoordAngle(), recursive_counter=recursive_counter + 1)
                    receiver.nextPacket()
                    return
                receiver.nextPacket()  # Discard the current data packet

            pass
            raise ValueError('Should have executed rightFirst')

    # Have to put it here to set the default value
    next_rotation = 0

    if move == -1:
        findBestPath(possible_moves=getLegalCoordAngle())

        if (round(next_rotation / 45) - round(getAngle() / 45)) == 0:
            next_angle = (round(next_rotation / 45) * 45) % 360
        else:
            next_angle = next_rotation % 360
    else:
        moveInDirection(move)

    # Currently useless
    # if insideSwamp():
    #     turn_multi = turn_multi[0], turn_multi[1]

    if round(next_angle / 45) % 2 == 0:
        next_angle = round(next_angle / 45) * 45


def static_turn() -> int:
    """
    Establishes the direction and the speed of the rotation and stops at a precision of 0.001°.
    During the rotation the robot stays stationary, since the wheel speeds are opposite at all times

    @return: None
    """
    global turn_multi, speeds, next_move, next_angle

    # Whenever the next_angle or the current angle approaches the north direction(0° or 360°), it gives lots of problems
    # We decided to avoid this problem all together by adding 180 to it when we're pointing near it
    temp_curr_angle = getAngle()
    temp_next_angle = next_angle
    if abs(temp_curr_angle - temp_next_angle) > 180:
        temp_next_angle = (temp_next_angle + 180) % 360
        temp_curr_angle = (temp_curr_angle + 180) % 360

    # The statements below are needed to make almost perfect right angle turns(precise to the 0.001°)
    # --- This make it so that the position of the robot never leaves the actual grid
    # --- The robot will change turning direction when is getting over the threshold
    if abs(temp_curr_angle - temp_next_angle) < 0.001:
        # Reset the speed of the wheels
        turn_multi = [1, 1]
        speeds = new_speed()
        # Reset angle
        next_angle = -1  # spremi trenutni i ciljni kut

        chooseDirection(move=next_move)  # wraparound korekcija za kut
        next_move = -1

        motor_left.setVelocity(speeds[0])
        motor_right.setVelocity(speeds[1])
        robot.step(timeStep)
        return 1

    # Decides to invert the rotation
    if (temp_next_angle - temp_curr_angle < 0) ^ (turn_multi[0] > 0):
        turn_multi = [turn_multi[0] * -1, turn_multi[1] * -1]

    angular_distance = abs(temp_next_angle - temp_curr_angle)
    if angular_distance > 180:
        angular_distance = abs(angular_distance - 360)

    if angular_distance <= 0.2:
        speeds = new_speed(angular_distance / 10, 0.005)
        return 0

    if angular_distance <= 6:
        speeds = new_speed(math.sqrt(angular_distance / 90))
        return 0

    speeds = new_speed()
    return 0


def dynamic_turn(objective, current):
    global turn_multi

    angle = (math.atan2(current[0] - objective[0] * 6, current[1] - objective[1] * 6)) % (2 * math.pi)
    if angle > math.pi:
        angle = 2 * math.pi - angle
    else:  # umjereno blizu → proporcionalno usporavanje
        angle = -angle
    # Convert the angle to degrees
    angle = (angle * 180 / math.pi)
    # Round the angle to 8th of a circle
    angle = (round(angle / 45) * 45) % 360
    # Get the actual angle considering the cell forward as 0°
    angle = angle - getRotation() * 45

    temp_curr_angle = getAngle()
    temp_next_angle = angle
    if abs(temp_curr_angle - temp_next_angle) > 180:
        temp_next_angle = (temp_next_angle + 180) % 360
        temp_curr_angle = (temp_curr_angle + 180) % 360

    angular_distance = abs(temp_next_angle - temp_curr_angle)
    if angular_distance > 180:
        angular_distance = abs(angular_distance - 360)

    angular_distance /= 180

    # scale_factor = 0.33 + 1 / ((angular_distance + 1) * (angular_distance**3 + 1.5))
    scale_factor = 0.33 + math.e ** (-0.1 * angular_distance) - 0.33 * math.e ** (-0.3 * angular_distance)

    if (temp_curr_angle < temp_next_angle and turn_multi[0] < 0 and turn_multi[1] < 0) or \
            (temp_curr_angle > temp_next_angle and turn_multi[0] > 0 and turn_multi[1] > 0):
        turn_multi = turn_multi[0] * scale_factor, turn_multi[1]
    else:
        turn_multi = turn_multi[0], scale_factor * turn_multi[1]


def delay(ms):
    """
    Time idling necessary to score points
    @param ms : time to wait in ms

    """
    start_timer = robot.getTime()  # Store starting time (in seconds)
    while robot.step(timeStep) != -1 and (robot.getTime() - start_timer) * 1000.0 <= ms:
        pass


def scoreVictim(victim_type: Literal['H', 'S', 'U', 'C', 'F', 'O', 'P'], camera: Literal['left', 'right'], direction,
                msg):
    """
    Send the message to score the victim's point

    @param victim_type: Type of the victim
    @param camera: The camera that saw the victim
    @param direction: The position of the victim in the photo
    @param msg: The message to display if a victim is found
    @return: Boolean that determines the success of the operation
    """

    direction /= 2
    direction += -90 if camera == 'left' else 90
    direction = (direction + getAngle()) % 360

    # alpha = direction * math.pi / 180
    # robot_gps = max(abs(getCoords(divisor=1)[0] - getCoords(divisor=1, round_to_int=False)[0]),
    #                 abs(getCoords(divisor=1)[1] - getCoords(divisor=1, round_to_int=False)[1]))
    # avg_robot_victim = 6.25
    # gps_victim = math.sqrt(
    #     robot_gps ** 2 + avg_robot_victim ** 2 - 2 * robot_gps * avg_robot_victim * math.cos(alpha)
    # )
    # gamma = math.asin(math.sin(alpha) * robot_gps / gps_victim)
    # suppl_beta = ((alpha + gamma) % (2 * math.pi)) * 180 / math.pi

    is_letter = victim_type == 'S' or victim_type == 'H' or victim_type == 'U'

    half_fov_cam = left_camera.getFov() * 180 / math.pi / 2

    half_fov_cam *= 1.5 if getRotation() % 2 == 1 else 1

    for v in victim_pos:
        v_min_angle = (v[4] - half_fov_cam) % 360
        v_max_angle = (v[4] + half_fov_cam) % 360
        temp_dir = copy.copy(direction)

        if abs(v_min_angle - temp_dir) > 180 or abs(v_max_angle - temp_dir) > 180 \
                or abs(v_min_angle - v_max_angle) > 180:
            v_min_angle = (v_min_angle + 180) % 360
            v_max_angle = (v_max_angle + 180) % 360
            temp_dir = (temp_dir + 180) % 360

        if v_min_angle < temp_dir < v_max_angle and v[3] == is_letter and \
                math.sqrt((getCoords(divisor=1, round_to_int=False)[0] - v[0]) ** 2 +
                          (getCoords(divisor=1, round_to_int=False)[1] - v[1]) ** 2) < 10:
            return

        del temp_dir
    else:
        victim_pos.add((*getCoords(divisor=1, round_to_int=False), victim_type, is_letter, direction))
        

    motor_left.setVelocity(0)
    motor_right.setVelocity(0)
    delay(1400)

    victim_message = bytes(victim_type, 'utf-8')

    pos_x, pos_z = getCoords(divisor=1)
    pass

    victim_message = struct.pack('i i c', pos_x, pos_z, victim_message)

    #print(msg)
    # print((*getCoords(divisor=1, round_to_int=False), victim_type, is_letter, direction))

    emitter.send(victim_message)  # Send out the message
    robot.step(timeStep)



def _placeVictimInMap(coord: Tuple[int, int], camera: Literal['left', 'right'],
                     victim: str, grid_position: str) -> None:
    """
    Upisuje detektiranu žrtvu na odgovarajuće zidno mjesto u maze mapi.

    Piše SAMO kad je grid_position == 'middle' — robot je tada TOČNO ispred žrtve.
    'front' / 'back' su preuranjeni ili zakašnjeli prolasci, koji bi krivo upisali
    žrtvu u pogrešnu ćeliju i time povukli krive lažne pozitive u finalnoj mapi.

    Cell matrica je world-aligned (rotirana u __init__):
        North = cell[0][2], East = cell[2][4], South = cell[4][2], West = cell[2][0]
    """
    if victim not in _VICTIMS:
        return
    if grid_position != 'middle':   # ← ključna provjera: samo precizno poravnanje
        return

    victim_val = _VICTIMS[victim]

    # Globalni smjer zida (0=N, 90=E, 180=S, 270=W)
    angle = getAngle()
    wall_dir = (angle + 90) % 360 if camera == 'right' else (angle - 90 + 360) % 360

    # Pozicija zida u world-aligned Cell matrici
    if 315 <= wall_dir or wall_dir < 45:
        wr, wc = 0, 2   # North
    elif 45 <= wall_dir < 135:
        wr, wc = 2, 4   # East
    elif 135 <= wall_dir < 225:
        wr, wc = 4, 2   # South
    else:
        wr, wc = 2, 0   # West

    # Upiši u ćeliju (susjedna nije potrebna: max() u getMap() zadržava max vrijednost)
    if coord in maze.map:
        maze.map[coord].cell[wr][wc] = victim_val

def addToSeen(coord: Tuple[int, int], camera: Literal['left', 'right'], victim: str, grid_position: Literal["back", "middle", "front"]):
    pass
    opposite_camera = 'right' if camera == 'left' else 'left'
    #print(coord, camera, victim)
    #print(maze.map[coord])

    if getRotation() % 2 == 0:
        front_coord = getNearCoords(angle=0, from_coord=coord)
    else:
        if camera == 'left':
            front_coord = getNearCoords(angle=315, from_coord=coord)
        else:
            front_coord = getNearCoords(angle=45, from_coord=coord)

    # Upiši žrtvu u mapu PRIJE nuliranja coord (s originalnom pozicijom)
    _placeVictimInMap(coord if not isinstance(coord, list) else tuple(coord), camera, victim, grid_position)

    if (victim == 'S' or victim == 'H' or victim == 'U') and getRotation() % 2 == 0:
        coord = [None, None]

    prev_victims.add((*coord, getRotation(), camera))
    prev_victims.add((*coord, (getRotation() + 1) % 8, camera))
    prev_victims.add((*coord, (getRotation() - 1) % 8, camera))
    prev_victims.add((*front_coord, getRotation(), camera))
    prev_victims.add((*front_coord, (getRotation() + 1) % 8, camera))
    prev_victims.add((*front_coord, (getRotation() - 1) % 8, camera))

    prev_victims.add((*coord, (getRotation() + 4) % 8, opposite_camera))
    prev_victims.add((*coord, (getRotation() + 3) % 8, opposite_camera))
    prev_victims.add((*coord, (getRotation() + 5) % 8, opposite_camera))
    prev_victims.add((*front_coord, (getRotation() + 4) % 8, opposite_camera))
    prev_victims.add((*front_coord, (getRotation() + 3) % 8, opposite_camera))
    prev_victims.add((*front_coord, (getRotation() + 5) % 8, opposite_camera))


_END_SEQUENCE_DONE = False
def initiateEndSequence():
    global _TUNNELS, _END_SEQUENCE_DONE
    if _END_SEQUENCE_DONE:
        return  # već pozvano, ignoriraj
    _END_SEQUENCE_DONE = True
    pass

    # ── DIJAGNOSTIKA MAPE ─────────────────────────────────────────────────────
    _cb, _ct = maze.getCorners()
    pass
    _rooms_count = {}
    for _c in maze.map.values():
        _r_key = _c.room if _c.room is not None else -1
        _rooms_count[_r_key] = _rooms_count.get(_r_key, 0) + 1
    pass
    _r4 = [(k, v.explored) for k, v in maze.map.items() if v.room == 4]
    pass
    pass
    pass
    pass
    _star_cells = [(k,v.room) for k,v in maze.map.items() if v.room==4]
    _non_r4_with_star = [k for k,v in maze.map.items() if v.room != 4 and maze.map[k].cell[2][2] == _ROOM_4]
    if _non_r4_with_star:
        pass
    # ──────────────────────────────────────────────────────────────────────────

    # Očisti sve temp zidove prije submitta (ne smiju biti u finalnoj mapi)
    _tw_cleared = 0
    for _tw_k in list(maze.map.keys()):
        if maze.map[_tw_k].cell[2][2] == _TEMP_WALL:
            maze.map[_tw_k].cell[2][2] = _STRONG_EMPTY
            _tw_cleared += 1
    if _tw_cleared:
        pass
    delay(2000)
    map_matrix = maze.getMap(nice_view=False)
    pass
    _shape = map_matrix.shape
    _stars = int(sum(1 for v in map_matrix.flatten() if v == '*'))
    _walls = int(sum(1 for v in map_matrix.flatten() if v == '1'))
    _empty = int(sum(1 for v in map_matrix.flatten() if v == '0'))
    pass
    pass
    for _ri in range(map_matrix.shape[0]):
        _row_str = ''.join(map_matrix[_ri])
        if '*' in _row_str or any(c not in ('0','1') for c in _row_str):
            pass
    
    # Flatten the array with comma separators, then encode it with utf-8 and send it
    # - Get shape as bytes
    shape_bytes = struct.pack('2i', *map_matrix.shape)
    # - Flattening the matrix and join with commas, then encode it
    matrix_bytes = ','.join(map_matrix.flatten()).encode('utf-8')
    # - Prepare the shape + matrix bytes to get the full map message
    map_bytes = shape_bytes + matrix_bytes
    # - Send map data
    emitter.send(map_bytes)

    # Send map evaluate request to get the map multiplier
    map_evaluate_request = struct.pack('c', b'M')
    emitter.send(map_evaluate_request)

    # Send exit message to get the exit bonus
    exit_mes = struct.pack('c', b'E')
    delay(5000)
    emitter.send(exit_mes)

    robot.step(timeStep)

    pass
    delay(5000)
    exit()
    delay(5000)


########################################################################################################################
# Initialization variables

# Used for initiate and continue the turning process
turn_multi = [1, 1]

# When you move, you can give a 'next move' direction to say for example:
# --- Turn right, then turn right again(90) to turn around in a dead end
# --- Turn left, then go forward(0)
next_move: int = -1

curr_path = copy.copy(set())
curr_obj = None

# Initiates the sequence to avoid an in front of the robot(wall/obstacle/hole)
# - Added later, but it also counts going to another are as an 'obstruction', since it speeds up exploration
obstruction_found = False

# Store the position of the last obstacle found
last_obstacle_coord = None

# Needs to reach a chosen value(def=3) to recognize that there is a hole or a checkpoint,
# since the engine sometimes glitches out and gives a black screen
check_hole_color = 0  # idući potez nakon okretanja (-1 = nema)
check_hole_depth = 0

# If -1 it's undefined, it indicates the expected angle at the end of a right angle turn
next_angle = -1

# The speed is initially set to [0, 0] to waste the first frame
speeds = [0, 0]  # True kada je detektirana prepreka i treba se povući

# Set of stuff that says to not take a photo near a previously discovered letter(hazards never get recognized two times)
prev_victims = copy.copy(set())  # koordinata posljednje prepreke
# Set containing all the previously found victims and their coordinates
victim_pos = copy.copy(set())

########################################################################################################################
# Setup robot and its devices

robot = Robot()

# Initiate the emitter and receiver
receiver = Receiver('receiver')
emitter = Emitter("emitter")  # [0,0] = stoj u prvom frameu
receiver.enable(timeStep)  # Enable the receiver. Note that the emitter does not need to call enable()

# Just wheels
wheel_left = robot.getDevice("wheel1 motor")
wheel_right = robot.getDevice("wheel2 motor")  # skup koordinata svih otkrivenih žrtvi
motor_left = Motor("wheel1 motor")
motor_right = Motor("wheel2 motor")
motor_left.setPosition(float("inf"))
motor_right.setPosition(float("inf"))
motor_left.setVelocity(speeds[0])  # inicijalizacija Webots robot objekta
motor_right.setVelocity(speeds[1])

# The inertial unit gets the orientation of the robot
inertial_unit = InertialUnit('inertial_unit')
inertial_unit.enable(timeStep)  # aktiviraj receiver na svakom timestep-u

# The color sensor gets one pixel just in front of the robot, positioned to avoid black holes
color_sensor = robot.getDevice("color_sensor")
# noinspection PyUnresolvedReferences
color_sensor.enable(timeStep)  # inicijaliziraj Motor objekt za lijevi kotač

# The GPS gets the current position in the maze in meters
gps = GPS('gps')
gps.enable(timeStep)  # postavi inicijalnu brzinu na 0

# Cameras of robot
left_camera = Camera('left_camera')
right_camera = Camera('right_camera')  # inercijalna mjerna jedinica – daje orijentaciju robota
left_camera.enable(timeStep)
right_camera.enable(timeStep)

lidar = Lidar('lidar')
lidar.enable(timeStep)
lidar.enablePointCloud()

ds0 = DistanceSensor("ds0")
ds1 = DistanceSensor("ds1")  # GPS – daje poziciju robota u metrima
dsf = DistanceSensor("dsf")
ds0.enable(timeStep)
ds1.enable(timeStep)
dsf.enable(timeStep)  # lijeva kamera za detekciju žrtvi

depth_sensor = DistanceSensor("depth_sensor")
depth_sensor.enable(timeStep)

# The first frame is used to update all values from default
robot.step(timeStep)

curr_cloud = lidar.range_image[512 * _LIDAR_LAYER:512 * (_LIDAR_LAYER + 1):]
last_coords = getCoords()  # bočni senzori udaljenosti
last_positions = []

maze = Net(starting_coord=getCoords(), starting_cell=Cell(explored=True, c_t=_START))
_STUCK_NOMOVE = 0  # brojač STUCK-TURN manevara bez ikakvog pomaka (fizički zarobljen)
_PROX_CNT = 0      # uzastopni PROX okidaji na istom mjestu (zakrivljeni zid → eskalacija)
_PROX_LAST = None  # pozicija zadnjeg PROX okidaja
addCells(last_coords)  # dubinski senzor – detektira rupe ispred
maze.map[getCoords()].room = 1

########################################################################################################################
# Initialize movement

for node_angle in _MVMT_ANGLES:  # uzmi trenutni lidar layer (512 vrijednosti)
    if maze.map[getNearCoords(node_angle)].available:  # zabilježi startnu koordinatu
        maze.to_explore.add(getNearCoords(node_angle))

maze.checkToExplore()  # inicijaliziraj mapu sa startnom ćelijom
chooseDirection(move=next_move)
start_simul_time = robot.getTime() 
starting_time = datetime.now()
pass  # skeniraj prve ćelije oko starta

#emergency: If the robot doesn't have enough time to return back it will send the map 2-3 seconds before the time runs out in order to get map bonus points
def emergency_exit():
    current_time = datetime.now()
    time_difference = current_time - starting_time
    time_difference_int = time_difference.seconds  # za svaki smjer provjeri je li susjed dostupan za explore
    simul_time = robot.getTime() - start_simul_time
    if ((time_difference_int > 594 or simul_time > 470)): #and current_tile != starting_tile
        pass
        pass  # počisti listu za istraživanje od nedostupnih ćelija
        pass  # odaberi prvi smjer kretanja
        delay(500)  # zabilježi simulacijsko vrijeme starta
        initiateEndSequence()  # zabilježi realno vrijeme starta
        delay(500)


########################################################################################################################
# Main cycle

robot.step(timeStep)  # jedan step da se inicijalizira pozicija
pass  # proteklo simulacijsko vrijeme
pass  # ako je prekoračen limit → hitno pošalji mapu

while robot.step(timeStep) != -1:
 try:
    _dbg_step = getattr(robot, '_dbg_step', 0) + 1; robot._dbg_step = _dbg_step
    if _dbg_step % 150 == 1:
        pass
    ####################################################################################################################
    # Victim recognition with AI
    # Take a photo with the right camera if there's a wall and this camera hasn't found a victim in a wile
    emergency_exit()
    

    if not (*getCoords(), getRotation(), 'right') in prev_victims and getNearCoords(90) in maze.map and not maze.map[getNearCoords(90)].available and getRotation() % 2 == 0:
        # POPRAVAK: provjeri lidar-om je li zid zaista unutar 9cm dometa bodovanja.
        # Bez ove provjere robot prijavljuje zrtve koje vidi kroz hodnik s 30-80cm udaljenosti!
        # FIX: max() + širi raspon kutova [85-95°] - 7 kutova umjesto 5 → teže proći na uglu/otvoru
        _lidar_right = max(
            lidar.range_image[512 * _LIDAR_LAYER + (round((a % 360) * 1.422) - 1) % 512]  # interni step brojač za periodični status log
            for a in [85, 87, 89, 90, 91, 93, 95]
        )
        if _lidar_right < 0.07:
            right_camera.saveImage(_TEMP_R_IMG, 100)
            right_img = cv2.imread(_TEMP_R_IMG)
            now = datetime.now()  # provjeri vremenski limit → hitni izlaz ako prekoračen
            date_time_str = now.strftime("%Y%m%d%H%M%S")
            cv2.imwrite(os.path.join(_SAVE_DIR, f'R{date_time_str}.jpg'), right_img)

            if v_dir := Victim.detectVictim(img=right_img, camera=right_camera,
                                             is_turning=is_turning() or getRotation() % 2 == 1):
                prediction, message, grid_position = Victim.predictionImg([_TEMP_R_IMG], 'right')

                if prediction != None:
                    message = f'{message} on the right at {getCoords()}'
                    addToSeen(getCoords(), 'right', prediction, grid_position)
                    scoreVictim(prediction, 'right', v_dir, message)  # boduj samo ako je zid unutar 7cm
        else:  # spremi sliku desne kamere
            #SPAM# print(f"[RIGHT] Zid predaleko za bodovanje: lidar={_lidar_right:.3f}m >= 0.07m, preskacemo")
            pass
            pass

    # Take a photo with the left camera if there's a wall and this camera hasn't found a victim in a wile
    if not (*getCoords(), getRotation(), 'left') in prev_victims and getNearCoords(270) in maze.map and not maze.map[getNearCoords(270)].available and getRotation() % 2 == 0:
        # POPRAVAK: provjeri lidar-om je li zid zaista unutar 9cm dometa bodovanja.
        # Ista logika kao desna kamera - bez ove provjere robot boduje s prevelike udaljenosti!
        # FIX: max() + širi raspon kutova [265-275°] - 7 kutova umjesto 5 → teže proći na uglu/otvoru
        _lidar_left = max(  # ako je žrtva prepoznata → prijavi
            lidar.range_image[512 * _LIDAR_LAYER + (round((a % 360) * 1.422) - 1) % 512]
            for a in [265, 267, 269, 270, 271, 273, 275]
        )
        if _lidar_left < 0.07:
            left_camera.saveImage(_TEMP_L_IMG, 100)
            left_img = cv2.imread(_TEMP_L_IMG)
            now = datetime.now()
            date_time_str = now.strftime("%Y%m%d%H%M%S")
            cv2.imwrite(os.path.join(_SAVE_DIR, f'L{date_time_str}.jpg'), left_img)

            if v_dir := Victim.detectVictim(img=left_img, camera=left_camera,
                                             is_turning=is_turning() or getRotation() % 2 == 1):
                prediction, message, grid_position = Victim.predictionImg([_TEMP_L_IMG], 'left')

                if prediction != None:
                    message = f'{message} on the left at {getCoords()}'
                    addToSeen(getCoords(), 'left', prediction, grid_position)
                    scoreVictim(prediction, 'left', v_dir, message)  # boduj samo ako je zid unutar 7cm
        else:
            #SPAM# print(f"[LEFT] Zid predaleko za bodovanje: lidar={_lidar_left:.3f}m >= 0.07m, preskacemo")
            pass

    ####################################################################################################################
    # If every check fails, it just goes forward
    if curr_obj is not None and next_angle == -1:
        # turn_multi = [1, 1]
        # dynamic_turn(curr_obj, getCoords(divisor=1, round_to_int=False))
        speeds = new_speed()
    else:
        speeds = new_speed()

    ####################################################################################################################
    # If two seconds(or 64 frames) ago you were in the same position as now, it creates an obstacle
    
    last_positions.insert(0, (getCoords(divisor=1), getAngle()))
    if len(last_positions) > timeStep * 2:
        two_sec_ago_pos = last_positions.pop()
        if two_sec_ago_pos[0] == last_positions[0][0]:
            temp_prev_a = two_sec_ago_pos[1]  # idi naprijed ako ima cilj i nije u okretanju
            temp_curr_a = last_positions[0][1]
            # BUGFIX: original kod radio SAMO za kutove blizu 0° (wraparound uvjet pogrešan)
            # Ispravna usporedba kuta s wraparound-om:
            _diff = abs(temp_prev_a - temp_curr_a)
            if _diff > 180:
                _diff = 360 - _diff
            
            if _diff < 5:  # kut se jedva promijenio = robot zapeo
                obstruction_found = True
                obstacle_coord = getNearCoords(from_coord=last_coords, angle=0)  # spremi poziciju i kut u buffer (zadnje ~2 sekunde)
                last_obstacle_coord = obstacle_coord  # kada je buffer pun, usporedi s najstarijim zapisom
            
                if obstacle_coord in _TUNNELS:
                    maze.to_explore.add(obstacle_coord)
                else:
                    maze += {obstacle_coord: Cell(cc=_TEMP_WALL)}
                    maze.removeToExplore(obstacle_coord, getCoords())
                    if DBG_VERBOSE: pass  # razlika kutova s wraparound korekcijom
            
                pass
                pass
                curr_path = None  # kut se jedva promijenio (< 5°) → robot zapeo
                motor_left.setVelocity(0)  # aktiviraj obstruction_found flag
                motor_right.setVelocity(0)
                if se > 15:
                    delay(500)
                    initiateEndSequence()  # prepreka je tunel → dodaj u explore, ne zazidavaj
                    delay(500)
                else:
                    se = se + 1  # inače → postavi privremeni zid
                    if obstacle_coord in _TUNNELS:
                        if se % 2 == 1:
                            motor_left.setVelocity(_MAX_VELOCITY * 0.65)
                            motor_right.setVelocity(_MAX_VELOCITY * 0.65)
                            delay(800)
                            motor_left.setVelocity(0)  # resetiraj planiranu putanju
                            motor_right.setVelocity(0)
                        else:
                            motor_left.setVelocity(-_MAX_VELOCITY * 0.5)  # previše stuck eventa (> 15) → predaj mapu
                            motor_right.setVelocity(-_MAX_VELOCITY * 0.5)
                            delay(600)
                            motor_left.setVelocity(0)
                            motor_right.setVelocity(0)
                    else:
                        # Dodaj susjedne ćelije u to_explore (mogu ih CTE filtrirati!)
                        pass
                        for _ang in (90, 180, 270):
                            _nb = getNearCoords(angle=_ang)
                            _in_map = _nb in maze.map
                            _available = maze.map[_nb].available if _in_map else False
                            _explored  = maze.map[_nb].explored  if _in_map else False
                            _in_tun    = _nb in _TUNNELS
                            if DBG_VERBOSE: pass
                            if _in_map and _nb not in _BANNED_CELLS:
                                maze.to_explore.add(_nb)
                        pass
                        
                        
                        if se >= 3:
                            _pre_mv = getCoords()
                            pass
                            # checkToExplore() filtrira explored cells pa neighbor-add ne pomaže.
                            # Jedino rješenje: FIZIČKI pomakni robot u smjeru 90° od prepreke.
                            # Prepreka je east (90°) → okret desno = south → (3,-1) = RED tunel!
                            for _tw_k in list(maze.map.keys()):
                                if maze.map[_tw_k].cell[2][2] == _TEMP_WALL:
                                    maze.map[_tw_k].cell[2][2] = _STRONG_EMPTY
                            # 1) RIKVERC — izvuci se iz uklještenja. Robot je u zid
                            #    ušao vožnjom naprijed, pa je unatrag uvijek slobodno.
                            #    Trajanje eskalira s brojem pokušaja.
                            _rev_ms = 600 + 200 * min(se, 6)
                            motor_left.setVelocity(-_MAX_VELOCITY * 0.7)
                            motor_right.setVelocity(-_MAX_VELOCITY * 0.7)
                            delay(_rev_ms)
                            motor_left.setVelocity(0)
                            motor_right.setVelocity(0)
                            delay(100)
                            # 2) Okret ~90° — smjer ALTERNIRA po pokušaju (desno/lijevo)
                            #    da se ne ponavlja isti neuspješni manevar u beskraj.
                            _trn = 1 if (se % 2 == 1) else -1
                            motor_left.setVelocity(_MAX_VELOCITY * 0.5 * _trn)
                            motor_right.setVelocity(-_MAX_VELOCITY * 0.5 * _trn)
                            delay(1300)  # ~90° okret
                            motor_left.setVelocity(0)
                            motor_right.setVelocity(0)
                            delay(100)
                            # 3) Forward push u novom smjeru
                            motor_left.setVelocity(_MAX_VELOCITY * 0.7)
                            motor_right.setVelocity(_MAX_VELOCITY * 0.7)
                            delay(800)
                            motor_left.setVelocity(0)
                            motor_right.setVelocity(0)
                            pass
                            curr_path = None  # replan nakon fizičkog pomaka
                            # FIZIČKI ZAROBLJEN (npr. popeo se na krivuljasti zid):
                            # ako manevri uzastopno NE pomiču robota, nijedan motorički
                            # trik ga neće osloboditi → traži Lack of Progress relokaciju
                            # (teleport na zadnji checkpoint, -5 bodova).
                            if getCoords() == _pre_mv:
                                _STUCK_NOMOVE += 1
                            else:
                                _STUCK_NOMOVE = 0
                            if _STUCK_NOMOVE >= 4:
                                pass
                                # TRAJNO zabrani zamku i njenih 8 susjeda kao ciljeve —
                                # inače ih addCells vrati u to_explore i put opet vodi u zamku.
                                for _bdx in (-1, 0, 1):
                                    for _bdy in (-1, 0, 1):
                                        _BANNED_CELLS.add((_pre_mv[0] + _bdx, _pre_mv[1] + _bdy))
                                try:
                                    maze.removeToExploreArea(_pre_mv, 1)
                                except (Exception,):
                                    pass
                                # Temp zidovi nastali mlataranjem u zamci nakon teleporta
                                # ne odgovaraju robotovoj okolini — očisti ih za svjež start.
                                _tw_clr = 0
                                for _tw_k in list(maze.map.keys()):
                                    if maze.map[_tw_k].cell[2][2] == _TEMP_WALL:
                                        maze.map[_tw_k].cell[2][2] = _STRONG_EMPTY
                                        _tw_clr += 1
                                pass
                                emitter.send(_LoP)
                                _STUCK_NOMOVE = 0
                                se = 0
                        if se >= 5:
                            for _et in [_GREEN, _RED, _ORANGE, _GREEN2, _RED2, _ORANGE2,
                                        _BLUE, _PURPLE, _YELLOW, _BLUE2, _PURPLE2, _YELLOW2]:
                                if _et.coord is not None:
                                    maze.to_explore.add(_et.coord)
            else:
                se = 0

                
    ####################################################################################################################
    # FRONT PROXIMITY GUARD (univerzalno, anti-uklještenje): krivuljasti/kosi
    # zidovi ulaze u ćelije koje mapa smatra slobodnima — robot bi vozio
    # naprijed u suženje dok se fizički ne ukliješti (kotači na zidu, nijedan
    # manevar ga više ne miče → LoP -5). Ako lidar vidi zid na <5cm ravno
    # naprijed dok vozimo ravno, hitno stani + rikverc + zid u mapu + replan.
    # Legitimna vožnja nikad ne dovodi front ispod ~9cm (ciljna ćelija je
    # slobodna), pa 5cm prag ne stvara lažne alarme.
    if turn_multi == [1, 1] and speeds[0] > 0 and speeds[1] > 0:
        try:
            _fp_rays = sorted(lidar.range_image[512 * _LIDAR_LAYER + (round((_fa % 360) * 1.422) - 1) % 512]
                              for _fa in (354, 356, 358, 0, 2, 4, 6))
            if _fp_rays[3] < 0.05:
                # ESKALACIJA: na zakrivljenom zidu replan zna robota odmah
                # vratiti na istu krivulju → PROX okida 10+ puta i troši
                # 30+ sekundi. Brojimo uzastopne okidaje na istom mjestu
                # (±1 ćelija) i nakon 3. eskaliramo: zazidamo i bočne ćelije
                # uz prednju te se fizički okrenemo ~90° od krivulje.
                _pp = getCoords()
                if _PROX_LAST is not None and abs(_pp[0] - _PROX_LAST[0]) <= 1 and abs(_pp[1] - _PROX_LAST[1]) <= 1:
                    _PROX_CNT += 1
                else:
                    _PROX_CNT = 1
                _PROX_LAST = _pp
                pass
                _pg_rev = 500 + 150 * min(_PROX_CNT, 6)
                motor_left.setVelocity(-_MAX_VELOCITY * 0.6)
                motor_right.setVelocity(-_MAX_VELOCITY * 0.6)
                delay(_pg_rev)
                motor_left.setVelocity(0)
                motor_right.setVelocity(0)
                _pg_ahead = getNearCoords(angle=0)
                if _pg_ahead in maze.map:
                    maze.map[_pg_ahead].cell[2][2] = _TEMP_WALL
                if _PROX_CNT >= 3:
                    # Okreni se ~90° od zida, alternirajući smjer.
                    # NAPOMENA: bočne ćelije se NE zazidavaju — na world4 i
                    # mapping_example_3 su bočni temp zidovi zazidali jedini
                    # hodnik, A* je ostao bez puta i robot je predao mapu
                    # prerano (87% → 28%). Duži rikverc + okret su dovoljni.
                    _pg_trn = 1 if _PROX_CNT % 2 == 1 else -1
                    motor_left.setVelocity(_MAX_VELOCITY * 0.5 * _pg_trn)
                    motor_right.setVelocity(-_MAX_VELOCITY * 0.5 * _pg_trn)
                    delay(1300)
                    motor_left.setVelocity(0)
                    motor_right.setVelocity(0)
                    pass
                curr_path = None
        except (Exception,):
            pass

    ####################################################################################################################
    # Get the lidar distances
    if turn_multi[0] >= 0 and turn_multi[1] >= 0:
        curr_cloud = lidar.range_image[512 * _LIDAR_LAYER:512 * (_LIDAR_LAYER + 1):]
        if getRotation() % 2 == 1:
            curr_cloud = [float('inf')] * 512
    else:
        curr_cloud = [float('inf')] * 512

    ####################################################################################################################
    # Check for the colors on the ground

    # Stores the color of the ground in front of the robot to do checks on it
    curr_color = getColor()
    if maze.current_room == 3 and curr_color[0] <= 10 and curr_color[1] > 0.2:
        pass
    if curr_color[1] > 0.3 and curr_color[2] > 0.4:  # nešto zasićeno — log sve boje u sobi 3+
        _h, _s, _v = curr_color
        _closest = min([('BLUE',240),('RED',0),('YELLOW',60),('ORANGE',25),('PURPLE',270),('GREEN',120)],  # dijagonalni kut → lidar nije pouzdan
                        key=lambda t: min(abs(_h-t[1]), 360-abs(_h-t[1])))
        if maze.current_room >= 2:
            if DBG_VERBOSE: pass  # okretanje → lidar nije pouzdan
    # DEBUG boja poda - samo zasićene boje (S>0.30), filtrira sive/bijele pločice i checkpointove
    if curr_color[1] > 0.30:
        #SPAM# print(f"[FLOOR] HSV: H={curr_color[0]} S={curr_color[1]} V={curr_color[2]}")
        pass

    # Check if the color is the one of an empty tile and check if there's a chance of hole being there
    if depth_sensor.getValue() > 0.2:
        # The sensor has to find a good value for 6 times to assert that there's a hole
        # - This is necessary due to a glitch that makes tunnels have the same sensor collisions as holes
        if not check_hole_depth >= 6:
            check_hole_depth += 1
        else:
            obstruction_found = True
            if getRotation() % 2 == 1:
                obstruction_found = placeAndHandleHole(hole_coordinate=getNearCoords(from_coord=getCoords(), angle=0),
                                                       possible_offset=315, is_void=depth_sensor.getValue() > 0.75)
            else:
                obstruction_found = placeAndHandleHole(
                    hole_coordinate=getNearCoords(from_coord=getCoords(), angle=0, distance=2),
                    possible_offset=270, is_void=depth_sensor.getValue() > 0.75)
            check_hole_depth = 0  # dubinski senzor > 0.2m → rupa ispred

    else:
        check_hole_depth = 0  # senzor mora 6× potvrditi rupu (filtrira glitch)

    # Otherwise handle the colors as usual and reset the depth_sensor counter
    if not checkColor(curr_color, _EMPTY.color_range):  # 6+ potvrda → prijavi rupu
        if checkColor(curr_color, _HOLE.color_range):
            check_hole_depth = 0
            # The color black needs to be found 3 times to assert that there's a hole
            # - This is necessary since from time to time the sensor glitches out and gives a black pixel for no reason
            if not check_hole_color >= 3:
                check_hole_color += 1
            else:
                obstruction_found = True
                if getRotation() % 2 == 1:
                    placeAndHandleHole(hole_coordinate=getNearCoords(from_coord=getCoords(), angle=0),
                                       possible_offset=45)
                else:
                    placeAndHandleHole(hole_coordinate=getNearCoords(from_coord=getCoords(), angle=0, distance=2),
                                       possible_offset=90)  # provjeri ostale boje samo ako pod nije prazan
                check_hole_color = 0  # crna boja = rupa (senzorom boje)

        else:
            # If the color black is not found reset the color counter to 0 and check the other colors
            check_hole_color = 0  # crna boja mora 3× biti potvrđena

            # The chain of 'or's is useful since if one color is found the other ones are skipped
            checkAndPlaceTile(tile=_SWAMP, color=curr_color) or \
            checkAndPlaceTile(tile=_CHECKPOINT, color=curr_color) or \
            checkAndPlaceTunnel(tunnel=_BLUE, color=curr_color, color_name = "BLUE") or \
            checkAndPlaceTunnel(tunnel=_BLUE2, color=curr_color, color_name = "BLUE") or \
            checkAndPlaceTunnel(tunnel=_PURPLE, color=curr_color,  color_name = "PURPLE") or \
            checkAndPlaceTunnel(tunnel=_PURPLE2, color=curr_color, color_name = "PURPLE") or \
            checkAndPlaceTunnel(tunnel=_RED, color=curr_color, color_name = "RED") or \
            checkAndPlaceTunnel(tunnel=_RED2, color=curr_color, color_name = "RED") or \
            checkAndPlaceTunnel(tunnel=_GREEN, color=curr_color, color_name = "GREEN")or \
            checkAndPlaceTunnel(tunnel=_GREEN2, color=curr_color, color_name = "GREEN")or \
            checkAndPlaceTunnel(tunnel=_YELLOW, color=curr_color, color_name = "YELLOW") or \
            checkAndPlaceTunnel(tunnel=_YELLOW2, color=curr_color, color_name = "YELLOW") or \
            checkAndPlaceTunnel(tunnel=_ORANGE, color=curr_color, color_name = "ORANGE") or \
            checkAndPlaceTunnel(tunnel=_ORANGE2, color=curr_color, color_name = "ORANGE")

            if checkColor(color=curr_color, color_range=_GREEN.color_range) or \
               checkColor(color=curr_color, color_range=_GREEN2.color_range) or \
               checkColor(color=curr_color, color_range=_BLUE.color_range) or \
               checkColor(color=curr_color, color_range=_BLUE2.color_range) or \
               checkColor(color=curr_color, color_range=_PURPLE.color_range) or \
               checkColor(color=curr_color, color_range=_PURPLE2.color_range) or \
               checkColor(color=curr_color, color_range=_RED.color_range) or \
               checkColor(color=curr_color, color_range=_RED2.color_range) or \
               checkColor(color=curr_color, color_range=_YELLOW.color_range) or \
               checkColor(color=curr_color, color_range=_YELLOW2.color_range) or \
               checkColor(color=curr_color, color_range=_ORANGE.color_range) or \
               checkColor(color=curr_color, color_range=_ORANGE2.color_range):
                check_hole_depth = 0  # FIX: resetiraj za SVE tunelske pločice (ne samo zelenu)

    ####################################################################################################################
    # Check for obstacles dangerously near the robot

    if turn_multi[0] >= 0 and turn_multi[1] >= 0:
        # This is link that was used to search the correct angles:
        # https://www.desmos.com/calculator/ege55xeuim
        obstacle_search = lidar.range_image[512 * (_LIDAR_LAYER + 1) - 64:512 * (_LIDAR_LAYER + 1):] + \
                          lidar.range_image[512 * _LIDAR_LAYER:512 * _LIDAR_LAYER + 64:]

        if min(obstacle_search) < _DANGER_ZONE_CLOSENESS:
            #print("Obstacle found dangerously near the wall")
            #print(maze)
            obstruction_found = True
            obstacle_coord = getNearCoords(from_coord=last_coords, angle=0)
            last_obstacle_coord = obstacle_coord
            maze += {obstacle_coord: Cell(cc=_TEMP_WALL)}
            maze.removeToExplore(obstacle_coord, getCoords())

    ####################################################################################################################
    # Detect and adapt to LoP

    if receiver.getQueueLength() > 0:  # If receiver queue is not empty
        receivedData = receiver.getBytes()
        tup = struct.unpack('c', receivedData)  # Parse data into character
        if tup[0].decode("utf-8") == 'L':  # 'L' means lack of progress occurred
            pass
            turn_multi = [1, 1]
            speeds = new_speed(0)
            obstruction_found = False
            maze.updateToExplore(last_pos=None, curr_pos=None, next_to_explore={last_coords, last_obstacle_coord})
            curr_path = maze.getBestPath()
            try:
                chooseDirection()
            except (ValueError, StopIteration, Exception) as _nav_err:
                pass
                static_turn()  # provjeri LoP signal od supervisora
        receiver.nextPacket()  # Discard the current data packet

    ####################################################################################################################
    # If it's in a new node, do things

    if abs(abs(abs(getCoords(round_to_int=False, divisor=1)[0]) - abs(last_coords[0]) * 6) - 6) < 0.5 or \
            abs(abs(abs(getCoords(round_to_int=False, divisor=1)[1]) - abs(last_coords[1]) * 6) - 6) < 0.5:
        curr_coords = getCoords()

        # Add the cell the robot is standing on and its close neighbours
        addCells(curr_coords)
        
        #print(f"Previous coords: {last_coords}, current coords: {curr_coords}")
        #print(type(maze.map[curr_coords]).__name__)
        if last_coords in _TUNNELS:  # odbaci poruku iz reda
            previous_colour = _TUNNELS[last_coords]
            pass
            maze.changeCurrentRoom(previous_colour)
            pass

        if maze.map[curr_coords].explored == False:
            maze.map[curr_coords].explored = True
            if curr_coords not in _TUNNELS:
                maze.map[curr_coords].room = maze.current_room
                if maze.current_room == 4:  # skeniraj ćeliju i susjede
                    pass
                elif maze.current_room == 0:
                    pass

        else:
            pass

        # FIX: addCells može resetirati room na None jer kreira novi Cell(explored=True, room=None).
        # Ako ćelija nema sobu postavljenu, dodjeli joj trenutnu sobu.
        # NE dodjeljuj sobu tunnel ćelijama (inače se prikazuju kao * umjesto R/B/P...).
        if maze.map[curr_coords].room is None and maze.current_room is not None \
                and curr_coords not in _TUNNELS:
            maze.map[curr_coords].room = maze.current_room

        # UKLONJENO: Ne čitaj current_room iz pohranjena vrijednost ćelije.
        # Uzrokovalo je reset sobe kad robot posjeti ćeliju koja je imala staru sobu
        # (npr. soba 1 → soba 3, ćelija pohranjena s room=1 → current_room skače na 1 → GREEN vodi na 4 umjesto RED).
        # Soba se ispravno prati isključivo kroz tunnel prijelaze i obstruction recovery (linije ~2822-2823).
        maze.updateToExplore(last_pos=last_coords, curr_pos=curr_coords, next_to_explore=getLegalMoves())

        # Used to avoid bugs
        obstruction_found = False

        try:
            chooseDirection()
        except (ValueError, StopIteration, Exception) as _nav_err:
            pass
            static_turn()

        last_coords = curr_coords
        pass

        #print(maze)
        #print(f"{curr_coords} : {maze.map[curr_coords].room}")

        # The prints to get the state at the end of the 'movement' and 'choices' go below here
        # --- Turning is not considered a move, since the robot stays still at the same coordinate

    ####################################################################################################################
    # If the robot is turning, it will continue to do so until it finishes

    if (turn_multi[0] < 0) ^ (turn_multi[1] < 0):
        if static_turn() == 1 and getRotation() % 2 == 0:
            addCells(getCoords())  # ažuriraj last_coords
    else:
        next_angle = -1

    ####################################################################################################################
    # Otherwise if the robot is dangerously near to a wall/obstacle/hole/tunnel it will adapt & go back to the last node

    if obstruction_found:
        #print(f"Room before obstruction: {maze.current_room}")
        #print("Obstruction found")
        if maze.map[last_coords].room is not None:  # FIX: ne brisi sobu ako je None
            maze.current_room = maze.map[last_coords].room
        #print(f"Room after obstruction: {maze.current_room}")
        turn_multi = [-1, -1]

        dynamic_turn((last_coords[0] * 6, last_coords[1] * 6), getCoords(round_to_int=False, divisor=1))
        speeds = new_speed()

        if abs(abs(abs(getCoords(round_to_int=False, divisor=1)[0]) - abs(last_coords[0]) * 6)) < 1 and \
                abs(abs(abs(getCoords(round_to_int=False, divisor=1)[1]) - abs(last_coords[1]) * 6)) < 1:
            turn_multi = [1, 1]
            speeds = new_speed(0)  # obstruction_found → povuci se na prethodnu poziciju
            curr_path = None
            obstruction_found = False
            try:  # vrati sobu iz prethodne ćelije
                chooseDirection()
            except (ValueError, StopIteration, Exception) as _nav_err:
                pass  # kreni nazad

    ####################################################################################################################
    # Select final speed of the wheels at the end of the frames

    motor_left.setVelocity(speeds[0])  # provjeri je li robot stigao natrag (< 1cm)
    motor_right.setVelocity(speeds[1])


 except Exception as _loop_err:
    # UNIVERZALNI SAFETY NET: nijedan neočekivani error ne smije ubiti robota.
    # Logiraj, resetiraj putanju i nastavi. Nakon previše uzastopnih grešaka
    # spasi bodove slanjem mape (initiateEndSequence).
    import traceback as _tb
    _LOOP_ERR_COUNT = globals().get('_LOOP_ERR_COUNT', 0) + 1
    globals()['_LOOP_ERR_COUNT'] = _LOOP_ERR_COUNT
    try:
        pass
    except Exception:
        pass  # postavi finalnu brzinu lijevog motora
    _tb.print_exc()  # postavi finalnu brzinu desnog motora
    try:
        curr_path = None
        obstruction_found = False  # SAFETY NET: uhvati sve greške da robot ne stane
        speeds = new_speed()
        motor_left.setVelocity(speeds[0])
        motor_right.setVelocity(speeds[1])
    except Exception:
        pass
    if _LOOP_ERR_COUNT >= 40:
        pass
        try:
            initiateEndSequence()
        except Exception:
            _tb.print_exc()
 else:  # pokušaj resetirati navigacijska stanja
    globals()['_LOOP_ERR_COUNT'] = 0

