#!/usr/bin/env bash
set -Eeuo pipefail

CONTAINER_NAME="${CONTAINER_NAME:-erebus_controller}"
REMOVE_CONTAINER="${REMOVE_CONTAINER:-0}"

if docker ps -a --format '{{.Names}}' | grep -qx "$CONTAINER_NAME"; then
    echo "[INFO] Parando container: $CONTAINER_NAME"
    docker stop --time 10 "$CONTAINER_NAME" >/dev/null 2>&1 || true
    echo "[OK] Container parado: $CONTAINER_NAME"

    if [[ "$REMOVE_CONTAINER" == "1" ]]; then
        echo "[INFO] Removendo container: $CONTAINER_NAME"
        docker rm "$CONTAINER_NAME" >/dev/null 2>&1 || true
        echo "[OK] Container removido: $CONTAINER_NAME"
    fi
else
    echo "[INFO] Container não encontrado: $CONTAINER_NAME"
fi