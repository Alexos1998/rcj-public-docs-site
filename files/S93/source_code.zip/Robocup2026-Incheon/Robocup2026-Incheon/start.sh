#!/usr/bin/env bash
set -Eeo pipefail

# =========================================================
# DEFAULTS
# =========================================================

xhost +local:docker >/dev/null 2>&1 || true

BUILD_MODE="normal"
CONNECTION_MODE="local"
REMOTE_HOST=""

DEV_MODE="${DEV_MODE:-0}"
REBUILD_IMAGE="${REBUILD_IMAGE:-1}"

IMAGE_TAG="erebus_internal"
BASE_IMAGE_TAG="controller-base:24.04"
CONTAINER_NAME="erebus_controller"

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="${SCRIPT_DIR}/controller"
HOST_RVIZ_CONFIG="${HOST_RVIZ_CONFIG:-$PROJECT_DIR/ros2_ws/src/ros2_bridge/config/rviz.rviz}"
HOST_RVIZ_LEGACY_CONFIG="${HOST_RVIZ_LEGACY_CONFIG:-$PROJECT_DIR/ros2_ws/src/ros2_bridge/config/rviz_legacy.rviz}"
CONTAINER_RVIZ_CONFIG="/workspace/controller/ros2_ws/src/ros2_bridge/config/rviz.rviz"
CONTAINER_RVIZ_LEGACY_CONFIG="/workspace/controller/ros2_ws/src/ros2_bridge/config/rviz_legacy.rviz"

mkdir -p "$(dirname "$HOST_RVIZ_CONFIG")"
mkdir -p "$(dirname "$HOST_RVIZ_LEGACY_CONFIG")"

if [[ ! -f "$HOST_RVIZ_CONFIG" ]]; then
    cat > "$HOST_RVIZ_CONFIG" <<'EOF'
Panels:
  - Class: rviz_common/Displays
Visualization Manager:
  Class: ""
  Displays:
    - Class: rviz_default_plugins/TF
      Enabled: true
      Name: TF
    - Class: rviz_default_plugins/Map
      Enabled: true
      Name: Map
      Topic:
        Value: /map
  Fixed Frame: map
EOF
fi

# =========================================================
# HELP
# =========================================================

usage() {
    cat <<EOF

Uso:

  ./start.sh -build [normal|full] \\
             -connection [local|ethernet|remote] [ip]

Modos:

  Normal/prod:
    ./start.sh -build normal -connection local

  Dev:
    DEV_MODE=1 ./start.sh -build normal -connection local

Variáveis:

  DEV_MODE=0|1
    0 = usa imagem fechada
    1 = monta controller/ros2_ws como volume

  REBUILD_IMAGE=auto|0|1
    auto = em DEV_MODE só builda se imagem não existir
    0    = nunca builda imagem
    1    = força rebuild da imagem

  ROS2_DEV_AUTOBUILD=0|1
    usado pelo Ros.sh em DEV_MODE
    1 = roda colcon build incremental ao iniciar

  ROS2_DEV_PACKAGES="ros2_bridge ros2_vision ros2_bootstrap ros2_mapper ros2_navigation ros2_exploration ..."
    pacotes ROS para build incremental em DEV_MODE

  START_MAP_DATASET=0|1
    1 = cria/atualiza controller/mapsdataset ao finalizar a run

  MAP_DATASET_NO_COPY=0|1
    1 = referencia imagens/lidar dos logs sem duplicar arquivos grandes

  MAP_DATASET_LATEST=0|1
    1 = cria dataset somente de controller/logs/latest

  MAP_DATASET_DAY=YYYY-MM-DD
    filtra o dataset por dia

  MAP_DATASET_RUN=YYYY-MM-DD_HH-MM-SS
    filtra uma run especifica

  MAP_DATASET_WORLD="/workspace/controller/worlds/arquivo.wbt"
    usa ground truth de vitimas/targets sem gravar nome do mundo

  MAP_DATASET_RUN_WORLD_MAP="/workspace/controller/mapsdataset/run_worlds.csv"
    CSV run_id,world_path para ground truth por run

Exemplos:

  ./start.sh -build full -connection local

  DEV_MODE=1 REBUILD_IMAGE=1 ./start.sh -build normal -connection local

  DEV_MODE=1 ./start.sh -build normal -connection local

  DEV_MODE=1 ROS2_DEV_AUTOBUILD=0 ./start.sh -build normal -connection local

  START_MAP_DATASET=1 MAP_DATASET_LATEST=1 ./start.sh -build normal -connection local

EOF

    exit 1
}

# =========================================================
# PARSER
# =========================================================

while [[ $# -gt 0 ]]; do
    case "$1" in
        -build)
            BUILD_MODE="$2"
            shift 2
            ;;

        -connection)
            CONNECTION_MODE="$2"
            shift 2

            if [[ "$CONNECTION_MODE" == "remote" ]]; then
                if [[ $# -eq 0 ]]; then
                    echo "[ERRO] remote requer IP/host."
                    exit 1
                fi

                REMOTE_HOST="$1"
                shift
            fi
            ;;

        -h|--help)
            usage
            ;;

        *)
            echo "[ERRO] argumento inválido: $1"
            usage
            ;;
    esac
done

# =========================================================
# VALIDACOES
# =========================================================

if [[ "$BUILD_MODE" != "normal" && "$BUILD_MODE" != "full" ]]; then
    echo "[ERRO] build inválido."
    exit 1
fi

if [[ "$CONNECTION_MODE" != "local" &&
      "$CONNECTION_MODE" != "ethernet" &&
      "$CONNECTION_MODE" != "remote" ]]; then
    echo "[ERRO] connection inválida."
    exit 1
fi

if [[ "$DEV_MODE" != "0" && "$DEV_MODE" != "1" ]]; then
    echo "[ERRO] DEV_MODE inválido. Use 0 ou 1."
    exit 1
fi

if [[ "$REBUILD_IMAGE" != "auto" &&
      "$REBUILD_IMAGE" != "0" &&
      "$REBUILD_IMAGE" != "1" ]]; then
    echo "[ERRO] REBUILD_IMAGE inválido. Use auto, 0 ou 1."
    exit 1
fi

# =========================================================
# DEPENDENCIAS
# =========================================================

if ! command -v docker >/dev/null 2>&1; then
    echo "[ERRO] docker não encontrado."
    exit 1
fi

if ! docker buildx version >/dev/null 2>&1; then
    echo "[ERRO] docker buildx indisponível."
    exit 1
fi

docker buildx use default >/dev/null

# =========================================================
# DISCOVERY
# =========================================================

get_local_host() {
    if [[ -n "${LOCAL_WEBOTS_HOST:-}" ]]; then
        echo "$LOCAL_WEBOTS_HOST"
        return 0
    fi

    local listen
    listen="$(
        ss -ltnp 2>/dev/null \
            | awk '/webots-bin/ && /:1234[[:space:]]/ {print $4; exit}'
    )"

    if [[ -n "$listen" ]]; then
        case "$listen" in
            127.0.0.1:1234|localhost:1234)
                echo "127.0.0.1"
                return 0
                ;;
            "[::1]:1234")
                echo "::1"
                return 0
                ;;
            "*:1234"|"0.0.0.0:1234"|"[::]:1234")
                echo "127.0.0.1"
                return 0
                ;;
            *:1234)
                echo "${listen%:1234}"
                return 0
                ;;
        esac
    fi

    # Fallback antigo, mas só se não achou Webots ouvindo por ss.
    ip route show default 2>/dev/null | awk '{print $3; exit}'
}

get_ethernet_iface() {
    # Em WSL mirrored, a Ethernet física do Windows aparece como uma interface
    # com IP link-local 169.254.x.x. Exemplo: eth1 169.254.85.56/16.
    #
    # ETH_IFACE permite forçar manualmente:
    #   ETH_IFACE=eth1 ./start.sh -build normal -connection ethernet
    if [[ -n "${ETH_IFACE:-}" ]]; then
        echo "$ETH_IFACE"
        return
    fi

    ip -o -4 addr show \
        | awk '
            $2 !~ /docker|br-|veth/ && $4 ~ /^169\.254\./ {
                print $2
                exit
            }
        '
}

get_ethernet_host() {
    local iface
    iface="$(get_ethernet_iface)"

    if [[ -z "$iface" ]]; then
        echo "[ERRO] Interface ethernet 169.254.x.x não encontrada." >&2
        echo "[ERRO] Confirme se o WSL está em mirrored networking e se o cabo Ethernet está conectado." >&2
        echo "[ERRO] Verifique com: ip -o -4 addr show" >&2
        echo "[ERRO] Ou force manualmente:" >&2
        echo "       ETH_IFACE=eth1 ./start.sh -build normal -connection ethernet" >&2
        exit 1
    fi

    echo "[INFO] ETH_IFACE=$iface" >&2

    local subnet
    subnet=$(ip -o -4 addr show "$iface" \
        | awk '{print $4}' \
        | head -n1)

    if [[ -z "$subnet" ]]; then
        echo "[ERRO] Subnet não encontrada para interface $iface." >&2
        exit 1
    fi

    echo "[INFO] Ethernet subnet=$subnet" >&2

    if ! command -v nmap >/dev/null 2>&1; then
        echo "[ERRO] nmap necessário para ethernet." >&2
        echo "Instale com: sudo apt update && sudo apt install -y nmap" >&2
        exit 1
    fi

    local my_ip
    my_ip="$(echo "$subnet" | cut -d/ -f1)"

    echo "[INFO] Ethernet local IP=$my_ip" >&2
    echo "[INFO] Procurando host no outro lado da Ethernet..." >&2

    local host
    host=$(nmap -sn "$subnet" \
        | awk '/Nmap scan report/ {print $NF}' \
        | tr -d '()' \
        | grep -E '^[0-9]+(\.[0-9]+){3}$' \
        | grep -v "^${my_ip}$" \
        | head -n1)

    if [[ -z "$host" ]]; then
        echo "[ERRO] Nenhum host encontrado no outro lado da Ethernet." >&2
        echo "[ERRO] Teste manual:" >&2
        echo "       nmap -sn $subnet" >&2
        echo "[ERRO] Ou force o IP:" >&2
        echo "       EREBUS_SERVER_OVERRIDE=169.254.x.x ./start.sh -build normal -connection ethernet" >&2
        exit 1
    fi

    echo "$host"
}

resolve_server() {
    if [[ -n "${EREBUS_SERVER_OVERRIDE:-}" ]]; then
        echo "$EREBUS_SERVER_OVERRIDE"
        return
    fi

    case "$CONNECTION_MODE" in
        local)
            get_local_host
            ;;

        ethernet)
            get_ethernet_host
            ;;

        remote)
            echo "$REMOTE_HOST"
            ;;
    esac
}

EREBUS_SERVER="$(resolve_server)"

echo "[INFO] BUILD_MODE=$BUILD_MODE"
echo "[INFO] CONNECTION_MODE=$CONNECTION_MODE"
echo "[INFO] EREBUS_SERVER=$EREBUS_SERVER"
echo "[INFO] DEV_MODE=$DEV_MODE"
echo "[INFO] REBUILD_IMAGE=$REBUILD_IMAGE"

# =========================================================
# BUILD
# =========================================================

image_exists() {
    docker image inspect "$1" >/dev/null 2>&1
}

build_image() {
    local dockerfile="$1"
    local tag="$2"

    docker buildx build \
        --builder default \
        --load \
        -f "$dockerfile" \
        -t "$tag" \
        "$PROJECT_DIR"
}

should_build_app_image() {
    if [[ "$REBUILD_IMAGE" == "1" ]]; then
        return 0
    fi

    if [[ "$REBUILD_IMAGE" == "0" ]]; then
        return 1
    fi

    if [[ "$DEV_MODE" == "1" ]]; then
        if image_exists "$IMAGE_TAG"; then
            return 1
        fi

        return 0
    fi

    return 0
}

if [[ "$BUILD_MODE" == "full" ]]; then
    echo "[INFO] Build completo"

    build_image \
        "$PROJECT_DIR/docker/Dockerfile.base" \
        "$BASE_IMAGE_TAG"
else
    echo "[INFO] Build rápido"
fi

if should_build_app_image; then
    echo "[INFO] Build app image: $IMAGE_TAG"

    build_image \
        "$PROJECT_DIR/docker/Dockerfile.app" \
        "$IMAGE_TAG"
else
    echo "[INFO] Pulando build da app image"
fi

if ! image_exists "$IMAGE_TAG"; then
    echo "[ERRO] Imagem $IMAGE_TAG não existe."
    echo "[ERRO] Rode com REBUILD_IMAGE=1 primeiro."
    exit 1
fi

# =========================================================
# CLEANUP
# =========================================================

if docker ps -a --format '{{.Names}}' | grep -qx "$CONTAINER_NAME"; then
    echo "[INFO] Removendo container antigo: $CONTAINER_NAME"
    docker stop "$CONTAINER_NAME" >/dev/null 2>&1 || true
    docker rm "$CONTAINER_NAME" >/dev/null 2>&1 || true
fi

# =========================================================
# RUN ARGS
# =========================================================
is_wsl() {
    grep -qiE 'microsoft|wsl' /proc/sys/kernel/osrelease 2>/dev/null
}

add_volume_if_exists() {
    local host_path="$1"
    local container_path="$2"

    if [[ -e "$host_path" ]]; then
        RUN_ARGS+=(-v "$host_path:$container_path")
        echo "[INFO] Mount habilitado: $host_path:$container_path"
    else
        echo "[WARN] Mount pulado, path ausente: $host_path"
    fi
}

add_device_if_exists() {
    local device_path="$1"

    if [[ -e "$device_path" ]]; then
        RUN_ARGS+=(--device "$device_path")
        echo "[INFO] Device habilitado: $device_path"
    else
        echo "[WARN] Device pulado, ausente: $device_path"
    fi
}

# Logs do controlador principal ficam em controller/logs (antes era /tmp).
# Pode ser sobrescrito exportando HOST_LOG_DIR.
HOST_LOG_DIR="${HOST_LOG_DIR:-$PROJECT_DIR/logs}"
mkdir -p "$HOST_LOG_DIR"
echo "[INFO] HOST_LOG_DIR=$HOST_LOG_DIR"

# unique.log: log dedicado do UniqueLogger, na mesma pasta dos demais logs.
# O Ros.sh recria/trunca dentro do container (em $LOG_DIR=latest); aqui só
# garantimos que o arquivo já exista no host para tail/inspeção desde o início.
# Como o container roda como root, os logs de execuções anteriores ficam com
# dono root; o pré-touch/limpeza no host é best-effort e nunca aborta o start.
HOST_UNIQUE_LOG="$HOST_LOG_DIR/latest/unique.log"
mkdir -p "$HOST_LOG_DIR/latest" 2>/dev/null || true
: > "$HOST_UNIQUE_LOG" 2>/dev/null || true
echo "[INFO] UNIQUE_LOG=$HOST_UNIQUE_LOG"

HOST_XAUTHORITY="${XAUTHORITY:-$HOME/.Xauthority}"
CONTAINER_XAUTHORITY="/tmp/.docker.xauth"

EXPLORER_BACKEND_EFFECTIVE="${EXPLORER_BACKEND:-legacy}"
echo "[INFO] EXPLORER_BACKEND_EFFECTIVE=$EXPLORER_BACKEND_EFFECTIVE"

START_BRIDGE="${START_BRIDGE:-1}"
START_VISION="${START_VISION:-1}"
START_ROS2_VISION="${START_ROS2_VISION:-0}"
START_CONTROLLER="${START_CONTROLLER:-1}"
START_LOCALIZATION="${START_LOCALIZATION:-1}"
START_MAP_DATASET="${START_MAP_DATASET:-1}"
CONTAINER_RVIZ_CONFIG_EFFECTIVE="${RVIZ_CONFIG:-$CONTAINER_RVIZ_CONFIG}"

if [[ "$EXPLORER_BACKEND_EFFECTIVE" == "legacy" ]]; then
    START_BRIDGE="${START_BRIDGE:-1}"
    START_CONTROLLER="${START_CONTROLLER:-1}"
    START_LOCALIZATION="${START_LOCALIZATION:-1}"
    START_RVIZ="${START_RVIZ:-0}"
    PRINT_LOG_TERMINALS="${PRINT_LOG_TERMINALS:-0}"
    PRINT_CONTROLLER_EVENTS="${PRINT_CONTROLLER_EVENTS:-0}"
    DEBUG_TOPICS="${DEBUG_TOPICS:-0}"
    START_BOOTSTRAP="${START_BOOTSTRAP:-0}"
    START_MAPPER="${START_MAPPER:-1}"
    START_NAV2="${START_NAV2:-0}"
    START_EXPLORER="${START_EXPLORER:-0}"
    CONTAINER_RVIZ_CONFIG_EFFECTIVE="${RVIZ_CONFIG:-/workspace/controller/ros2_ws/src/ros2_bridge/config/rviz_legacy.rviz}"
    echo "[INFO] EXPLORER_BACKEND=legacy -> direct Webots legacy exploration"
    echo "[INFO] Keeping infrastructure: bridge=$START_BRIDGE controller=$START_CONTROLLER localization_noop=$START_LOCALIZATION rviz=$START_RVIZ logs=$PRINT_LOG_TERMINALS"
    echo "[INFO] Disabling ROS exploration/navigation: nav2=$START_NAV2 explorer=$START_EXPLORER bootstrap=$START_BOOTSTRAP mapper=$START_MAPPER"
else
    START_BOOTSTRAP="${START_BOOTSTRAP:-1}"
    START_MAPPER="${START_MAPPER:-1}"
    START_NAV2="${START_NAV2:-1}"
    START_EXPLORER="${START_EXPLORER:-1}"
    START_RVIZ="${START_RVIZ:-0}"
    PRINT_LOG_TERMINALS="${PRINT_LOG_TERMINALS:-0}"
    DEBUG_TOPICS="${DEBUG_TOPICS:-0}"
fi

RUN_ARGS=(
    --network host
    --name "$CONTAINER_NAME"

    --env "EREBUS_SERVER=$EREBUS_SERVER"
    --env "FASTDDS_BUILTIN_TRANSPORTS=UDPv4"

    --env "QT_OPENGL=software"
    --env "ROS_AUTOMATIC_DISCOVERY_RANGE=SUBNET"
    --env "LANG=C.UTF-8"
    --env "LC_ALL=C.UTF-8"

    --env "DEV_MODE=$DEV_MODE"
    --env "ROS2_DEV_AUTOBUILD=${ROS2_DEV_AUTOBUILD:-1}"
    --env ROS2_DEV_PACKAGES="${ROS2_DEV_PACKAGES:-ros2_bridge ros2_vision ros2_bootstrap ros2_mapper ros2_navigation ros2_exploration}"

    --env "RACE_MODE=${RACE_MODE:-1}"
    --env "START_BRIDGE=$START_BRIDGE"
    --env "START_VISION=$START_VISION"
    --env "START_ROS2_VISION=$START_ROS2_VISION"
    --env "VISION_TCP_HOST=${VISION_TCP_HOST:-127.0.0.1}"
    --env "VISION_FRAME_PORT=${VISION_FRAME_PORT:-5100}"
    --env "VISION_RESULT_PORT=${VISION_RESULT_PORT:-5101}"
    --env "VISION_SEND_EVERY_N=${VISION_SEND_EVERY_N:-2}"
    --env "VISION_IMAGE_ENCODING=${VISION_IMAGE_ENCODING:-BGR8}"
    --env "VISION_CLASSIFY_HOLD_S=${VISION_CLASSIFY_HOLD_S:-1.2}"
    --env "VISION_HOLD_AFTER_TILE_ADVANCE=${VISION_HOLD_AFTER_TILE_ADVANCE:-0}"
    --env "VISION_REPORT_DUPLICATE_SCOPE=${VISION_REPORT_DUPLICATE_SCOPE:-tile_kind_class}"
    --env "VISION_LIDAR_GATE_ENABLED=${VISION_LIDAR_GATE_ENABLED:-0}"
    --env "VISION_LIDAR_GATE_MIN_CONSECUTIVE_RAYS=${VISION_LIDAR_GATE_MIN_CONSECUTIVE_RAYS:-5}"
    --env "VISION_LIDAR_GATE_MAX_RANGE_M=${VISION_LIDAR_GATE_MAX_RANGE_M:-0.06}"
    --env "VISION_VALID_DETECTION_DISTANCE_M=${VISION_VALID_DETECTION_DISTANCE_M:-0.06}"
    --env "VISION_TARGET_LIDAR_GATE_ENABLED=${VISION_TARGET_LIDAR_GATE_ENABLED:-0}"
    --env "VISION_VICTIM_LIDAR_GATE_ENABLED=${VISION_VICTIM_LIDAR_GATE_ENABLED:-0}"
    --env "VISION_PIPELINE_LIDAR_GATE_MAX_RANGE_M=${VISION_PIPELINE_LIDAR_GATE_MAX_RANGE_M:-0.06}"
    --env "VISION_ALIGN_AJUST=${VISION_ALIGN_AJUST:-1}"
    --env "VISION_ALIGN_MAX_TIME_S=${VISION_ALIGN_MAX_TIME_S:-0.8}"
    --env "VISION_ALIGN_THRESHOLD_PX=${VISION_ALIGN_THRESHOLD_PX:-8}"
    --env "VISION_ALIGN_RESTORE_HEADING=${VISION_ALIGN_RESTORE_HEADING:-0}"
    --env "VISION_ALIGN_RESTORE_MAX_TIME_S=${VISION_ALIGN_RESTORE_MAX_TIME_S:-1.6}"
    --env "VISION_ALIGN_RESTORE_THRESHOLD_RAD=${VISION_ALIGN_RESTORE_THRESHOLD_RAD:-0.035}"
    --env "VISION_TARGET_GATE_SEARCH_ENABLED=${VISION_TARGET_GATE_SEARCH_ENABLED:-1}"
    --env "VISION_TARGET_GATE_SEARCH_TIME_S=${VISION_TARGET_GATE_SEARCH_TIME_S:-1.0}"
    --env "VISION_TARGET_GATE_SEARCH_ANGULAR_RAD_S=${VISION_TARGET_GATE_SEARCH_ANGULAR_RAD_S:-0.45}"
    --env "START_BOOTSTRAP=$START_BOOTSTRAP"
    --env "START_CONTROLLER=$START_CONTROLLER"
    --env "START_LOCALIZATION=$START_LOCALIZATION"
    --env "START_MAPPER=$START_MAPPER"
    --env "START_NAV2=$START_NAV2"
    --env "START_EXPLORER=$START_EXPLORER"
    --env "START_EXPLORER_GRAPH_VIZ=${START_EXPLORER_GRAPH_VIZ:-1}"
    --env "START_RVIZ=$START_RVIZ"
    --env "START_MAP_DATASET=$START_MAP_DATASET"
    --env "MAP_DATASET_NO_COPY=${MAP_DATASET_NO_COPY:-1}"
    --env "MAP_DATASET_LATEST=${MAP_DATASET_LATEST:-0}"
    --env "MAP_DATASET_INCLUDE_LATEST=${MAP_DATASET_INCLUDE_LATEST:-0}"
    --env "MAP_DATASET_DAY=${MAP_DATASET_DAY:-}"
    --env "MAP_DATASET_RUN=${MAP_DATASET_RUN:-}"
    --env "MAP_DATASET_WORLD=${MAP_DATASET_WORLD:-}"
    --env "MAP_DATASET_RUN_WORLD_MAP=${MAP_DATASET_RUN_WORLD_MAP:-}"
    --env "MAP_DATASET_LIMIT=${MAP_DATASET_LIMIT:-}"
    --env "RVIZ_CONFIG=$CONTAINER_RVIZ_CONFIG_EFFECTIVE"
    --env "PRINT_LOG_TERMINALS=$PRINT_LOG_TERMINALS"
    --env "PRINT_CONTROLLER_EVENTS=$PRINT_CONTROLLER_EVENTS"

    --env "EXPLORER_BACKEND=$EXPLORER_BACKEND_EFFECTIVE"
    --env "EXPLORER_AUTO_START=${EXPLORER_AUTO_START:-true}"

    --env "EXPLORATION_PARAMS_FILE=${EXPLORATION_PARAMS_FILE:-/workspace/controller/ros2_ws/src/ros2_exploration/config/explorer.yaml}"
    --env "EXPLORER_LOG_LEVEL=${EXPLORER_LOG_LEVEL:-info}"

    --env "ROS2_BRIDGE_DEBUG=${ROS2_BRIDGE_DEBUG:-false}"
    --env "DEBUG_TOPICS=$DEBUG_TOPICS"
    --env "DEBUG_TOPICS_INTERVAL=${DEBUG_TOPICS_INTERVAL:-3}"

    --env DISPLAY="${DISPLAY:-}"
    --env WAYLAND_DISPLAY="${WAYLAND_DISPLAY:-}"
    --env XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/tmp/runtime-root}"
    --env XAUTHORITY="$CONTAINER_XAUTHORITY"
    --env "LOG_ROOT=/host_tmp_logs"

    -v "$HOST_LOG_DIR:/host_tmp_logs"
    -v "$HOST_RVIZ_CONFIG:$CONTAINER_RVIZ_CONFIG"
    -v "$HOST_RVIZ_LEGACY_CONFIG:$CONTAINER_RVIZ_LEGACY_CONFIG"

    # Dataset de mapas do slam_toolbox: bind-mount vivo para o recorder.py
    # existir no container E o output (runs/, manifest.csv) persistir no host.
    -v "$PROJECT_DIR/mapsdataset:/workspace/controller/mapsdataset"
)

add_volume_if_exists /tmp/.X11-unix /tmp/.X11-unix

if [[ -f "$HOST_XAUTHORITY" ]]; then
    RUN_ARGS+=(-v "$HOST_XAUTHORITY:$CONTAINER_XAUTHORITY:ro")
    echo "[INFO] Mount habilitado: $HOST_XAUTHORITY:$CONTAINER_XAUTHORITY:ro"
else
    echo "[WARN] XAUTHORITY ausente; mount pulado: $HOST_XAUTHORITY"
fi

if [[ -n "${XDG_RUNTIME_DIR:-}" && -d "${XDG_RUNTIME_DIR:-}" ]]; then
    add_volume_if_exists "$XDG_RUNTIME_DIR" "$XDG_RUNTIME_DIR"
else
    echo "[WARN] XDG_RUNTIME_DIR vazio ou inexistente; mount pulado"
fi

if is_wsl; then
    echo "[INFO] HOST_OS=wsl"

    if [[ -d /mnt/wslg ]]; then
        echo "[INFO] WSLG_AVAILABLE=1"
        add_volume_if_exists /mnt/wslg /mnt/wslg
    else
        echo "[WARN] WSLG_AVAILABLE=0: /mnt/wslg ausente"
    fi

    add_device_if_exists /dev/dxg
else
    echo "[INFO] HOST_OS=linux"
    echo "[INFO] Ambiente não-WSL: pulando /mnt/wslg e /dev/dxg"
fi

if [[ "$DEV_MODE" == "1" ]]; then
    echo "[INFO] DEV_MODE=1 -> montando ros2_ws e target_legacy vivos"
    RUN_ARGS+=(
        -v "$PROJECT_DIR/ros2_ws:/workspace/controller/ros2_ws"
        -v "$PROJECT_DIR/target_legacy:/workspace/controller/target_legacy"
    )
fi

# =========================================================
# RUN
# =========================================================

docker run \
    "${RUN_ARGS[@]}" \
    "$IMAGE_TAG"
