#!/usr/bin/env bash
set -euo pipefail

log="/tmp/webots-restart.log"
: > "$log"

current_ws="$(hyprctl activeworkspace -j | jq -r '.id')"

target_ws="$(
  hyprctl clients -j | jq -r '
    .[]
    | select(
        ((.class // "") | ascii_downcase | test("webots"))
        or
        ((.initialClass // "") | ascii_downcase | test("webots"))
        or
        ((.title // "") | ascii_downcase | test("webots"))
      )
    | .workspace.id
  ' | grep -v '^-' | head -n1
)"

if [[ -z "${target_ws:-}" || "$target_ws" == "null" ]]; then
  target_ws="$current_ws"
fi

echo "Current workspace: $current_ws" >> "$log"
echo "Target workspace: $target_ws" >> "$log"

pkill -TERM -x webots-bin 2>/dev/null || true
pkill -TERM -x webots 2>/dev/null || true
sleep 1
pkill -KILL -x webots-bin 2>/dev/null || true
pkill -KILL -x webots 2>/dev/null || true

webots >> "$log" 2>&1 &

for i in {1..150}; do
  addrs="$(
    hyprctl clients -j | jq -r '
      .[]
      | select(
          ((.class // "") | ascii_downcase | test("webots"))
          or
          ((.initialClass // "") | ascii_downcase | test("webots"))
          or
          ((.title // "") | ascii_downcase | test("webots"))
        )
      | .address
    '
  )"

  if [[ -n "${addrs:-}" ]]; then
    while read -r addr; do
      [[ -z "$addr" || "$addr" == "null" ]] && continue
      echo "Moving Webots window: $addr" >> "$log"
      hyprctl dispatch "hl.dsp.window.move({ workspace = $target_ws, window = \"address:$addr\", follow = false })"
    done <<< "$addrs"

    exit 0
  fi

  sleep 0.1
done

echo "ERRO: janela do Webots não encontrada." >> "$log"
hyprctl clients -j | jq '.[] | {class, initialClass, title, address, pid, workspace}' >> "$log"
exit 1