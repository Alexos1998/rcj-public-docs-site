"""Compatibility entry point for ONNX export helpers."""

from notebooks.common.onnx_export import export_onnx_model

__all__ = ["export_onnx_model"]

