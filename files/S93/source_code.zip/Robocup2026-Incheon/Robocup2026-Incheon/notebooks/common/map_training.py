"""Fast, observable training utilities for the map specialists.

Adds three things the plain ``map_dataset`` helpers lack:

* **Parallelism** — the leave-one-run-out (LORO) loops are embarrassingly parallel
  across held-out runs, but ``map_dataset`` runs them serially (only the RF itself
  used ``n_jobs``). ``parallel_loro_predict`` / ``parallel_end2end`` spread the folds
  over processes with ``joblib``.
* **Optuna** — ``optuna_search`` replaces the hand-written ``sweep_pipeline`` grid
  with a TPE study (median pruner, persisted SQLite study, resumable) optimising the
  end-to-end headline macro-recall.
* **Progress / observability** — ``tqdm`` progress bars and a live best-trial plot so
  long runs are not "in the dark".

Everything degrades gracefully if ``optuna`` / ``tqdm`` are missing.
"""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import numpy as np

from . import map_dataset as md


# --------------------------------------------------------------------------- #
# optional deps
# --------------------------------------------------------------------------- #
def _tqdm(iterable, **kw):
    try:
        from tqdm.auto import tqdm
        return tqdm(iterable, **kw)
    except Exception:
        return iterable


def _n_jobs(n_jobs: int | None) -> int:
    import os
    if n_jobs and n_jobs > 0:
        return n_jobs
    return max(1, (os.cpu_count() or 2) - 1)


# --------------------------------------------------------------------------- #
# parallel LORO out-of-fold predictions for a single dataset
# --------------------------------------------------------------------------- #
def parallel_loro_predict(dataset: md.Dataset, cfg: md.MapRFConfig | None = None,
                          n_jobs: int | None = None, progress: bool = True,
                          backend: str = "threading") -> np.ndarray:
    """Same contract as ``md.cross_val_predict_grouped`` but folds run in parallel.

    Each held-out run is trained on a single core (``rf.n_jobs=1``) so the outer
    ``joblib`` parallelism over folds does not oversubscribe the CPU. ``backend``
    defaults to ``"threading"`` (RandomForest releases the GIL while building trees,
    so threads give a real speed-up and avoid the loky semaphore leaks seen on
    Python 3.14); pass ``"loky"`` for process isolation.
    """
    from joblib import Parallel, delayed
    from sklearn.model_selection import LeaveOneGroupOut

    cfg = cfg or md.MapRFConfig()
    fold_cfg = replace(cfg, n_jobs=1)
    X, y, groups = dataset.X, dataset.y, dataset.groups
    is_real = dataset.is_real if dataset.is_real is not None else np.ones(len(y), bool)
    pred = np.full_like(y, -1)
    if len(set(groups.tolist())) <= 1 or len(set(y.tolist())) <= 1:
        return pred

    folds = list(LeaveOneGroupOut().split(X, y, groups))

    def _fit_fold(tr_idx, te_idx):
        te_real = te_idx[is_real[te_idx]]
        if len(set(y[tr_idx].tolist())) < 2 or len(te_real) == 0:
            return te_real, None
        model = md._build_rf(fold_cfg)
        model.fit(X[tr_idx], y[tr_idx])
        return te_real, model.predict(X[te_real])

    results = Parallel(n_jobs=_n_jobs(n_jobs), backend=backend)(
        delayed(_fit_fold)(tr, te)
        for tr, te in _tqdm(folds, desc=f"LORO {dataset.task}", disable=not progress)
    )
    for te_real, p in results:
        if p is not None:
            pred[te_real] = p
    return pred


# --------------------------------------------------------------------------- #
# parallel end-to-end LORO evaluation
# --------------------------------------------------------------------------- #
def _eval_one_held(held, names, subs_by, tiles_by, loaded, rf, augment,
                   explored_thr, margins, gate, resolve, label_source):
    """Train the pipeline on every run but ``held`` and score the held-out run."""
    rf1 = replace(rf or md.MapRFConfig(), n_jobs=1)
    tr_sub = [s for n in names if n != held for s in subs_by[n]]
    tr_tile = [t for n in names if n != held for t in tiles_by[n]]
    pipe = md.MapPipeline.from_training(tr_sub, tr_tile, rf1, augment, explored_thr, margins)
    subs, sp, tiles, to, dt = md.collect_run(
        loaded[held], pipe, gate, resolve, label_source=label_source
    )
    rec = {"wt": [], "wp": [], "ct": [], "cp": [], "ot": [], "op": [],
           "overlap": 0, "n_sub": len(subs), "n_unexpl": 0, "time": dt}
    for s, p in zip(subs, sp):
        rec["n_unexpl"] += int(not p["explored"])
        for d in md.DIRS:
            if s.real.wall_wildcard.get(d):
                continue
            rec["wt"].append(s.real.walls[d]); rec["wp"].append(p["walls"][d])
        rec["ct"].append(s.real.curve); rec["cp"].append(p["curve"])
        if p["curve"] and any(p["walls"][d] for d in md.CURVE_EDGES.get(p["curve"], ())):
            rec["overlap"] += 1
    for t, o in zip(tiles, to):
        rec["ot"].append(t.obstacle); rec["op"].append(int(o))
    return rec


def parallel_end2end(runs=None, rf=None, augment=None, explored_thr=0.3,
                     margins=None, gate=True, resolve=True,
                     n_jobs: int | None = None, progress: bool = True,
                     label_source: str = "auto",
                     backend: str = "threading") -> dict:
    """Drop-in faster ``md.evaluate_pipeline_end2end`` (folds parallel over runs).

    ``backend`` defaults to ``"threading"`` (see ``parallel_loro_predict``)."""
    from joblib import Parallel, delayed

    run_dirs = list(runs) if runs is not None else md.list_runs()
    loaded = {rd.name: md.load_run(rd) for rd in run_dirs}
    subs_by = {
        n: md.build_run_subtiles(r, label_source=label_source)
        for n, r in loaded.items()
    }
    tiles_by = {
        n: md.build_run_tiles(r, label_source=label_source)
        for n, r in loaded.items()
    }
    names = sorted(loaded)

    recs = Parallel(n_jobs=_n_jobs(n_jobs), backend=backend)(
        delayed(_eval_one_held)(h, names, subs_by, tiles_by, loaded, rf, augment,
                                explored_thr, margins, gate, resolve, label_source)
        for h in _tqdm(names, desc="end2end LORO", disable=not progress)
    )

    wt = [v for r in recs for v in r["wt"]]; wp = [v for r in recs for v in r["wp"]]
    ct = [v for r in recs for v in r["ct"]]; cp = [v for r in recs for v in r["cp"]]
    ot = [v for r in recs for v in r["ot"]]; op = [v for r in recs for v in r["op"]]
    overlap = sum(r["overlap"] for r in recs)
    total_sub = sum(r["n_sub"] for r in recs)
    total_unexpl = sum(r["n_unexpl"] for r in recs)
    total_time = sum(r["time"] for r in recs)

    curve_present = sorted(set(ct) | set(cp))
    out = {
        "wall": md._class_metrics(wt, wp, [0, 1], ["no_wall", "wall"]),
        "curve": md._class_metrics(ct, cp, curve_present,
                                   [md.CURVE_LABELS[i] for i in curve_present]),
        "obstacle": md._class_metrics(ot, op, [0, 1], ["clear", "obstacle"]),
        "overlap_violations": int(overlap),
        "explored_coverage": float(1 - total_unexpl / total_sub) if total_sub else None,
        "us_per_subtile": float(total_time / total_sub * 1e6) if total_sub else None,
        "n_runs": len(names),
    }
    out["headline_macro_recall"] = float(np.mean([
        out["wall"].get("macro_recall", 0.0),
        out["curve"].get("macro_recall", 0.0),
        out["obstacle"].get("macro_recall", 0.0),
    ]))
    return out


# --------------------------------------------------------------------------- #
# Optuna hyper-parameter search (objective = end-to-end headline macro-recall)
# --------------------------------------------------------------------------- #
def optuna_search(n_trials: int = 40, runs=None, storage: str | None = None,
                  study_name: str = "map_pipeline", n_jobs: int | None = None,
                  base_augment=None, show_progress: bool = True,
                  label_source: str = "auto"):
    """TPE search over RF + mask margins + explored threshold + augmentation.

    Maximises the end-to-end headline macro-recall (the deployment metric). The
    study is persisted (``storage`` SQLite URL) so it is resumable; a median pruner
    drops dominated trials early. Returns ``(study, best_summary)``.
    """
    import optuna

    base_augment = base_augment if base_augment is not None else md.AUG_STRONG

    def objective(trial: "optuna.Trial") -> float:
        rf = md.MapRFConfig(
            n_estimators=trial.suggest_int("n_estimators", 120, 400, step=40),
            max_depth=trial.suggest_int("max_depth", 6, 20),
            min_samples_leaf=trial.suggest_int("min_samples_leaf", 1, 4),
            max_features=trial.suggest_categorical("max_features", ["sqrt", "log2", None]),
        )
        margins = {
            "parede": trial.suggest_float("margin_parede", 0.04, 0.14),
            "curva": trial.suggest_float("margin_curva", 0.06, 0.16),
            "obstaculo": trial.suggest_float("margin_obstaculo", 0.14, 0.28),
        }
        thr = trial.suggest_float("explored_thr", 0.2, 0.45)
        r = parallel_end2end(runs=runs, rf=rf, augment=base_augment,
                             explored_thr=thr, margins=margins,
                             n_jobs=n_jobs, progress=False,
                             label_source=label_source)
        trial.set_user_attr("wall", r["wall"].get("macro_recall"))
        trial.set_user_attr("curve", r["curve"].get("macro_recall"))
        trial.set_user_attr("obstacle", r["obstacle"].get("macro_recall"))
        trial.set_user_attr("overlap", r["overlap_violations"])
        return r["headline_macro_recall"]

    study = optuna.create_study(
        direction="maximize", study_name=study_name, storage=storage,
        load_if_exists=bool(storage),
        sampler=optuna.samplers.TPESampler(seed=42),
        pruner=optuna.pruners.MedianPruner(n_warmup_steps=5),
    )
    study.optimize(objective, n_trials=n_trials, show_progress_bar=show_progress)

    best = {
        "headline": study.best_value,
        "params": study.best_params,
        **{k: study.best_trial.user_attrs.get(k)
           for k in ("wall", "curve", "obstacle", "overlap")},
    }
    return study, best


def benchmark_models(task: str = "curva", treatments: dict | None = None,
                     models: dict | None = None, runs=None, augment=None,
                     n_jobs: int = 1, label_source: str = "auto") -> list[dict]:
    """Grid of (data treatment x classifier) for one specialist, ranked by LORO
    macro-recall. Lets you answer "is it the features or the model?" empirically.

    ``treatments`` maps name -> ``patch -> feature vector``; defaults compare the
    deployed features against a raw downsampled multi-channel patch and a polar
    occupancy profile. ``models`` maps name -> sklearn estimator (cloned per fold).

    NOTE: defaults to ``n_jobs=1`` everywhere — multi-threaded sklearn (RF n_jobs=-1,
    HistGradientBoosting's OpenMP) can deadlock on this Python 3.14 box; keep it 1.
    """
    from sklearn.base import clone
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.neighbors import KNeighborsClassifier, NearestCentroid
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import precision_recall_fscore_support, accuracy_score
    from sklearn.model_selection import LeaveOneGroupOut
    from . import map_features as mf

    run_dirs = list(runs) if runs is not None else md.list_runs()
    loaded = [md.load_run(rd) for rd in run_dirs]

    def _raw3ch(patch, k=10, lo=0.25, hi=0.75):
        s = patch.shape[0]; a, b = int(lo * s), int(hi * s); g = patch[a:b, a:b]
        i = np.linspace(0, g.shape[0] - 1, k).astype(int); g = g[np.ix_(i, i)]
        return np.concatenate([(g >= 65).ravel().astype(float),
                               ((g >= 0) & (g <= 25)).ravel().astype(float),
                               (g < 0).ravel().astype(float)])

    if task == "obstaculo":
        items = md.filter_explored(
            [t for r in loaded for t in md.build_run_tiles(r, label_source=label_source)])
        items = md._augment_tiles(items, augment or md.AugmentConfig(n_noise=1))
        labelfn = lambda it: it.obstacle
        deployed = mf.obstacle_features
        treatments = treatments or {"deployed": deployed,
                                    "raw3ch": lambda p: _raw3ch(p, 10, .15, .85)}
    else:  # curva
        all_subs = [
            s for r in loaded for s in md.build_run_subtiles(r, label_source=label_source)
        ]
        all_tiles = [
            t for r in loaded for t in md.build_run_tiles(r, label_source=label_source)
        ]
        # same domain the deployed pipeline presents to the curve model (explored,
        # no obstacle tiles) — so the benchmark matches runtime, not isolated training.
        subs = md.filter_pipeline_consistent(all_subs, all_tiles)
        items = md.augment_samples(subs, augment or md.AugmentConfig(n_noise=0))
        labelfn = lambda it: it.real.curve
        treatments = treatments or {
            "deployed(cur+polar)": mf.curve_features,
#            "raw3ch": lambda p: _raw3ch(p, 12),
            "polar": lambda p: mf.polar_occupancy(p, 8, 16)}

    if models is None:
        models = {
            "RF": RandomForestClassifier(n_estimators=200, max_depth=14, min_samples_leaf=1,
                                         class_weight="balanced", n_jobs=n_jobs, random_state=0),
            "kNN5": make_pipeline(StandardScaler(), KNeighborsClassifier(5, weights="distance", n_jobs=n_jobs)),
            "NCentroid": make_pipeline(StandardScaler(), NearestCentroid()),
            "LogReg": make_pipeline(StandardScaler(), LogisticRegression(max_iter=300, class_weight="balanced")),
        }

    groups = np.array([it.run_id for it in items])
    y = np.array([labelfn(it) for it in items])
    is_real = np.array([not it.augmented for it in items])
    folds = list(LeaveOneGroupOut().split(np.zeros(len(y)), y, groups))
    rows = []
    for tn, tf in treatments.items():
        X = np.ascontiguousarray([tf(it.patch) for it in items], dtype=np.float32)
        for mn, proto in _tqdm(list(models.items()), desc=tn):
            pred = np.full(len(y), -1)
            for tr, te in folds:
                ter = te[is_real[te]]
                if len(set(y[tr].tolist())) < 2 or len(ter) == 0:
                    continue
                est = clone(proto); est.fit(X[tr], y[tr]); pred[ter] = est.predict(X[ter])
            m = pred >= 0; yt, yp = y[m], pred[m]
            labs = sorted(set(yt.tolist()) | set(yp.tolist()))
            _, r, _, _ = precision_recall_fscore_support(yt, yp, labels=labs, zero_division=0)
            rows.append({"treatment": tn, "model": mn, "macro_recall": float(np.mean(r)),
                         "accuracy": float(accuracy_score(yt, yp)),
                         "fp_none": int(((yt == 0) & (yp > 0)).sum()), "dim": X.shape[1]})
    rows.sort(key=lambda d: -d["macro_recall"])
    return rows


def plot_optuna(study, title: str = "Optuna — headline macro-recall"):
    """Best-so-far curve + parameter importances (matplotlib, no plotly needed)."""
    import matplotlib.pyplot as plt

    vals = [t.value for t in study.trials if t.value is not None]
    best_so_far = np.maximum.accumulate(vals) if vals else []
    fig, axes = plt.subplots(1, 2, figsize=(12, 3.6))
    axes[0].plot(vals, ".", alpha=0.5, label="trial")
    axes[0].plot(best_so_far, "-", color="tab:red", label="best so far")
    axes[0].set_xlabel("trial"); axes[0].set_ylabel("headline macro-recall")
    axes[0].legend(); axes[0].set_title(title)
    try:
        import optuna
        imp = optuna.importance.get_param_importances(study)
        axes[1].barh(list(imp)[::-1], list(imp.values())[::-1])
        axes[1].set_title("param importance")
    except Exception as e:
        axes[1].text(0.1, 0.5, f"importance n/a\n{e}", fontsize=8)
        axes[1].axis("off")
    fig.tight_layout()
    return fig
