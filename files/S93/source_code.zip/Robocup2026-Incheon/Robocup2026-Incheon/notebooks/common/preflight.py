"""Pre-training validation helpers for VSCode notebooks."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

from .datasets import (
    circle_from_row,
    detect_circle_schema,
    detect_ellipse_schema,
    ellipse_from_row,
    read_csv_manifest,
)
from . import model_registry
from .train_config import (
    BBoxTrainConfig,
    BaseTrainConfig,
    CircleTrainConfig,
    ClassificationTrainConfig,
    EllipseTrainConfig,
)


REQUIRED_CLASSIFICATION_COLUMNS = {"split", "image_path", "label", "label_name"}
REQUIRED_BBOX_COLUMNS = REQUIRED_CLASSIFICATION_COLUMNS | {"xmin", "ymin", "xmax", "ymax"}
REQUIRED_CIRCLE_BASE_COLUMNS = {"split", "image_path"}
EXPECTED_LABELS = {
    "presence": ["none", "object"],
    "object_type": ["target", "victim"],
    "victim": ["harmed", "unharmed", "stable"],
    "victim_classification": ["harmed", "unharmed", "stable"],
}


@dataclass
class PreflightReport:
    ok: bool
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    task_name: str = ""
    status: str = "ready"
    skipped: bool = False
    dataset_root: Path | None = None
    manifest_root: Path | None = None
    manifest_path: Path | None = None
    num_rows: int = 0
    split_counts: dict[str, int] = field(default_factory=dict)
    class_counts: dict[str, int] = field(default_factory=dict)
    checked_image_count: int = 0
    missing_image_count: int = 0
    missing_images: list[str] = field(default_factory=list)
    expected_labels: list[str] = field(default_factory=list)
    duplicate_image_hash_count: int = 0
    duplicate_cross_split_image_hash_count: int = 0
    duplicate_image_hashes: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
            "task_name": self.task_name,
            "status": self.status,
            "skipped": self.skipped,
            "dataset_root": str(self.dataset_root) if self.dataset_root else None,
            "manifest_root": str(self.manifest_root) if self.manifest_root else None,
            "manifest_path": str(self.manifest_path) if self.manifest_path else None,
            "num_rows": self.num_rows,
            "split_counts": dict(self.split_counts),
            "class_counts": dict(self.class_counts),
            "checked_image_count": self.checked_image_count,
            "missing_image_count": self.missing_image_count,
            "missing_images": list(self.missing_images),
            "expected_labels": list(self.expected_labels),
            "duplicate_image_hash_count": self.duplicate_image_hash_count,
            "duplicate_cross_split_image_hash_count": self.duplicate_cross_split_image_hash_count,
            "duplicate_image_hashes": list(self.duplicate_image_hashes),
        }


def _is_bbox_config(cfg: BaseTrainConfig) -> bool:
    return isinstance(cfg, BBoxTrainConfig) or cfg.task_name == "victim_bbox"


def _is_circle_config(cfg: BaseTrainConfig) -> bool:
    return isinstance(cfg, CircleTrainConfig) or cfg.task_name in {
        "target_circle",
        "target_localization",
    }


def _is_ellipse_config(cfg: BaseTrainConfig) -> bool:
    return isinstance(cfg, EllipseTrainConfig) or cfg.task_name == "target_ellipse"


def _validate_ellipse_rows(rows: list[dict[str, str]], schema, errors: list[str]) -> None:
    invalid_rows = []
    for row_index, row in enumerate(rows, start=2):
        try:
            width = float(row.get("image_width", 64) or 64)
            height = float(row.get("image_height", 64) or 64)
            cx, cy, major, minor, sin_a, cos_a, ratio = ellipse_from_row(row, schema, width, height)
        except (KeyError, TypeError, ValueError):
            invalid_rows.append((row_index, "ellipse values must be numeric"))
            continue
        if any(value < 0 or value > 1 for value in (cx, cy)):
            invalid_rows.append((row_index, "center must be normalized to [0, 1]"))
        if major <= 0 or minor <= 0:
            invalid_rows.append((row_index, "radii must be > 0"))
        if not (0.0 <= ratio <= 1.0):
            invalid_rows.append((row_index, "perspective_ratio must be in [0, 1]"))
    if invalid_rows:
        preview = ", ".join(f"line {line}: {message}" for line, message in invalid_rows[:10])
        errors.append(f"Invalid ellipse rows. First issues: {preview}.")


def _validate_circle_rows(rows: list[dict[str, str]], schema, errors: list[str]) -> None:
    invalid_rows = []
    for row_index, row in enumerate(rows, start=2):
        try:
            cx, cy, radius = circle_from_row(row, schema)
        except (KeyError, TypeError, ValueError):
            invalid_rows.append((row_index, "circle values must be numeric"))
            continue
        if any(value < 0 or value > 1 for value in (cx, cy)):
            invalid_rows.append((row_index, "center must be normalized to [0, 1]"))
        if radius <= 0:
            invalid_rows.append((row_index, "radius must be > 0"))
        elif radius > 1:
            invalid_rows.append((row_index, "radius must be <= 1"))
    if invalid_rows:
        preview = ", ".join(f"line {line}: {message}" for line, message in invalid_rows[:10])
        errors.append(f"Invalid circle rows. First issues: {preview}.")


def _validate_predicted_crop(cfg: ClassificationTrainConfig, errors: list[str], warnings: list[str]) -> None:
    """Ensure a predicted-crop classifier can resolve its localization model.

    Predicted crops must never fall back silently to ground truth: if the
    upstream localization model cannot be resolved (or has no ONNX export), this
    is a hard error.
    """

    if not cfg.crop_task_name:
        errors.append("crop_mode='predicted' requires crop_task_name.")
        return
    try:
        bundle = model_registry.resolve_model_bundle(
            cfg.crop_task_name,
            selection=cfg.crop_model_selection,
            explicit_dir=cfg.crop_model_artifact_dir,
            require_onnx=True,
        )
    except (FileNotFoundError, ValueError) as exc:
        errors.append(
            f"crop_mode='predicted' could not resolve a '{cfg.crop_task_name}' localization "
            f"model: {exc}"
        )
        return
    if bundle.onnx_path is None or not Path(bundle.onnx_path).exists():
        errors.append(
            f"Resolved '{cfg.crop_task_name}' model has no ONNX export at {bundle.artifact_dir}; "
            "predicted crops require an ONNX model."
        )
        return
    warnings.append(
        f"predicted crops will be generated by {cfg.crop_task_name} model: {bundle.artifact_dir}"
    )


def run_pipeline_preflight(model_specs: list[Mapping[str, Any]]) -> PreflightReport:
    """Validate that every model required by the runtime pipeline resolves.

    ``model_specs`` is a list of dicts with keys ``task_name`` (required),
    ``selection`` ("latest"|"best_metric"|"explicit"), ``explicit_dir``,
    ``require_labels`` (bool). Checks the model resolves, has an ONNX export and
    -- when requested -- a non-empty ``labels.json``.
    """

    errors: list[str] = []
    warnings: list[str] = []
    for spec in model_specs:
        task_name = spec.get("task_name", "")
        if not task_name:
            errors.append("pipeline model spec missing task_name.")
            continue
        try:
            bundle = model_registry.resolve_model_bundle(
                task_name,
                selection=spec.get("selection", "latest"),
                explicit_dir=spec.get("explicit_dir", ""),
                require_onnx=True,
            )
        except (FileNotFoundError, ValueError) as exc:
            errors.append(f"[{task_name}] {exc}")
            continue
        if bundle.onnx_path is None or not Path(bundle.onnx_path).exists():
            errors.append(f"[{task_name}] no ONNX export under {bundle.artifact_dir}.")
        if spec.get("require_labels") and not bundle.labels:
            errors.append(f"[{task_name}] labels.json missing or empty under {bundle.artifact_dir}.")
        warnings.append(f"[{task_name}] resolved: {bundle.artifact_dir}")

    ok = not errors
    return PreflightReport(
        ok=ok,
        errors=errors,
        warnings=warnings,
        task_name="pipeline",
        status="ready" if ok else "failed",
    )


def _image_path(dataset_root: Path, row: Mapping[str, str]) -> Path:
    value = Path(row.get("image_path", ""))
    if value.is_absolute():
        return value
    return dataset_root / row.get("split", "") / value


def _split_counts(rows: list[dict[str, str]]) -> dict[str, int]:
    return {split: sum(row.get("split") == split for row in rows) for split in ("train", "validation", "test")}


def _class_counts(rows: list[dict[str, str]], labels: list[str]) -> dict[str, int]:
    if not labels:
        labels = sorted({row.get("label_name", "") for row in rows if row.get("label_name")})
    return {label: sum(row.get("label_name") == label for row in rows) for label in labels}


def _validate_label_contract(
    *,
    rows: list[dict[str, str]],
    labels: list[str],
    errors: list[str],
    warnings: list[str],
) -> None:
    expected = {label: index for index, label in enumerate(labels)}
    observed_labels = {row.get("label_name", "") for row in rows}
    unknown = sorted(label for label in observed_labels if label and label not in expected)
    if unknown:
        errors.append(f"Unexpected labels in manifest: {unknown}. Expected {labels}.")

    missing = [label for label in labels if label not in observed_labels]
    if missing:
        warnings.append(f"Expected labels not present in this manifest: {missing}.")

    bad_pairs = []
    for row_index, row in enumerate(rows, start=2):
        label_name = row.get("label_name", "")
        if label_name not in expected:
            continue
        try:
            label_value = int(row.get("label", ""))
        except ValueError:
            bad_pairs.append((row_index, row.get("label"), label_name))
            continue
        if label_value != expected[label_name]:
            bad_pairs.append((row_index, label_value, label_name))
    if bad_pairs:
        preview = ", ".join(f"line {line}: {value}/{name}" for line, value, name in bad_pairs[:10])
        errors.append(f"Label index/name contract is invalid. First mismatches: {preview}.")


def _validate_bbox_rows(rows: list[dict[str, str]], errors: list[str]) -> None:
    invalid_rows = []
    for row_index, row in enumerate(rows, start=2):
        try:
            xmin = float(row["xmin"])
            ymin = float(row["ymin"])
            xmax = float(row["xmax"])
            ymax = float(row["ymax"])
        except (KeyError, TypeError, ValueError):
            invalid_rows.append((row_index, "bbox values must be numeric"))
            continue

        values = (xmin, ymin, xmax, ymax)
        if any(value < 0 or value > 1 for value in values):
            invalid_rows.append((row_index, "bbox values must be normalized to [0, 1]"))
        if xmin > xmax:
            invalid_rows.append((row_index, "xmin must be <= xmax"))
        if ymin > ymax:
            invalid_rows.append((row_index, "ymin must be <= ymax"))

    if invalid_rows:
        preview = ", ".join(f"line {line}: {message}" for line, message in invalid_rows[:10])
        errors.append(f"Invalid bbox rows. First issues: {preview}.")


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _detect_duplicate_image_hashes(
    *,
    rows: list[dict[str, str]],
    dataset_root: Path,
    present_columns: set[str],
    errors: list[str],
    warnings: list[str],
) -> tuple[int, int, list[dict[str, Any]]]:
    if not rows or not dataset_root.exists() or not {"split", "image_path"} <= present_columns:
        return 0, 0, []

    hash_rows: dict[str, list[dict[str, Any]]] = {}
    for row_index, row in enumerate(rows, start=2):
        path = _image_path(dataset_root, row)
        if not path.exists():
            continue
        digest = _hash_file(path)
        hash_rows.setdefault(digest, []).append(
            {
                "line": row_index,
                "split": row.get("split"),
                "image_path": row.get("image_path"),
                "label_name": row.get("label_name"),
            }
        )

    duplicate_groups = [items for items in hash_rows.values() if len(items) > 1]
    cross_split_groups = [
        items for items in duplicate_groups if len({item["split"] for item in items}) > 1
    ]
    preview = [
        {"count": len(items), "items": items[:8]}
        for items in cross_split_groups[:5]
    ]

    if cross_split_groups:
        errors.append(
            "Exact duplicate image files appear in more than one split. "
            "This is data leakage; regenerate or clean the manifest. "
            f"Duplicate hash groups: {len(cross_split_groups)}."
        )
    elif duplicate_groups:
        warnings.append(
            "Exact duplicate image files appear within a split. "
            f"Duplicate hash groups: {len(duplicate_groups)}."
        )

    return len(duplicate_groups), len(cross_split_groups), preview


def run_preflight_check(cfg: BaseTrainConfig) -> PreflightReport:
    """Validate config, manifests, labels and image paths before training."""

    if not isinstance(cfg, BaseTrainConfig):
        raise TypeError("run_preflight_check expects a train_config object.")

    errors: list[str] = []
    warnings: list[str] = []
    errors.extend(cfg.validation_errors())

    is_bbox = _is_bbox_config(cfg)
    is_circle = _is_circle_config(cfg)
    is_ellipse = _is_ellipse_config(cfg)
    expected_labels = EXPECTED_LABELS.get(cfg.task_name, cfg.labels)
    manifest_missing = not cfg.manifest_path.exists()
    optional_bbox_missing = (
        (is_bbox or is_circle or is_ellipse)
        and getattr(cfg, "skip_if_missing", True)
        and manifest_missing
    )

    dataset_root = cfg.dataset_root
    manifest_root = cfg.manifest_root
    manifest_path = cfg.manifest_path

    if not dataset_root.exists() and not optional_bbox_missing:
        errors.append(f"Dataset root does not exist: {dataset_root}")
    elif not dataset_root.exists() and optional_bbox_missing:
        warnings.append(f"Dataset root does not exist, but bbox training will be skipped: {dataset_root}")

    if not manifest_root.exists() and not optional_bbox_missing:
        errors.append(f"Manifest root does not exist: {manifest_root}")
    elif not manifest_root.exists() and optional_bbox_missing:
        warnings.append(f"Manifest root does not exist, but bbox training will be skipped: {manifest_root}")

    if optional_bbox_missing:
        warnings.append(
            f"Skipping {cfg.task_name} training: {manifest_path} is missing. "
            "No labels will be invented."
        )
        return PreflightReport(
            ok=not errors,
            errors=errors,
            warnings=warnings,
            task_name=cfg.task_name,
            status="skipped" if not errors else "failed",
            skipped=True,
            dataset_root=dataset_root,
            manifest_root=manifest_root,
            manifest_path=manifest_path,
            expected_labels=list(expected_labels),
        )

    if manifest_missing:
        errors.append(f"Required CSV manifest does not exist: {manifest_path}")
        return PreflightReport(
            ok=False,
            errors=errors,
            warnings=warnings,
            task_name=cfg.task_name,
            status="failed",
            dataset_root=dataset_root,
            manifest_root=manifest_root,
            manifest_path=manifest_path,
            expected_labels=list(expected_labels),
        )

    rows = read_csv_manifest(manifest_path)
    present_columns = set(rows[0].keys()) if rows else set()
    circle_schema = detect_circle_schema(present_columns) if is_circle else None
    ellipse_schema = detect_ellipse_schema(present_columns) if is_ellipse else None
    if is_ellipse:
        required_columns = REQUIRED_CIRCLE_BASE_COLUMNS
    elif is_circle:
        required_columns = REQUIRED_CIRCLE_BASE_COLUMNS
    elif is_bbox:
        required_columns = REQUIRED_BBOX_COLUMNS
    else:
        required_columns = REQUIRED_CLASSIFICATION_COLUMNS
    missing_columns = sorted(required_columns - present_columns)
    if missing_columns:
        errors.append(f"Manifest is missing required columns: {missing_columns}.")
    if is_circle and rows and circle_schema is None:
        errors.append(
            "Circle manifest must contain one of (center_x, center_y, radius), "
            "(cx, cy, r) or bbox columns (xmin, ymin, xmax, ymax)."
        )
    if is_ellipse and rows and ellipse_schema is None:
        errors.append(
            "Ellipse manifest must contain the mask schema (mask_cx, mask_cy, "
            "mask_radius_major_px, mask_radius_minor_px, mask_angle_deg), the "
            "ellipse_* projection schema, or a legacy circle/bbox schema."
        )

    if not rows:
        errors.append(f"Manifest has no rows: {manifest_path}")

    split_counts = _split_counts(rows)
    class_counts = _class_counts(rows, list(expected_labels))

    if split_counts.get("train", 0) == 0:
        errors.append("Split 'train' is empty.")
    for split in ("validation", "test"):
        if split_counts.get(split, 0) == 0:
            warnings.append(f"Split '{split}' is missing or empty.")

    if is_ellipse:
        if ellipse_schema is not None:
            _validate_ellipse_rows(rows, ellipse_schema, errors)
    elif is_circle:
        if circle_schema is not None:
            _validate_circle_rows(rows, circle_schema, errors)
    elif not missing_columns:
        _validate_label_contract(rows=rows, labels=list(expected_labels), errors=errors, warnings=warnings)
        if is_bbox:
            _validate_bbox_rows(rows, errors)

    if isinstance(cfg, ClassificationTrainConfig) and cfg.crop_mode == "predicted":
        _validate_predicted_crop(cfg, errors, warnings)

    checked = 0
    missing_images: list[str] = []
    duplicate_hash_count = 0
    duplicate_cross_split_hash_count = 0
    duplicate_hash_preview: list[dict[str, Any]] = []
    if dataset_root.exists() and {"split", "image_path"} <= present_columns:
        for row in rows:
            checked += 1
            path = _image_path(dataset_root, row)
            if not path.exists():
                missing_images.append(str(path))
        if missing_images:
            errors.append(
                "Manifest image paths do not resolve. First missing paths:\n"
                + "\n".join(missing_images[:10])
            )
        duplicate_hash_count, duplicate_cross_split_hash_count, duplicate_hash_preview = (
            _detect_duplicate_image_hashes(
                rows=rows,
                dataset_root=dataset_root,
                present_columns=present_columns,
                errors=errors,
                warnings=warnings,
            )
        )

    ok = not errors
    return PreflightReport(
        ok=ok,
        errors=errors,
        warnings=warnings,
        task_name=cfg.task_name,
        status="ready" if ok else "failed",
        dataset_root=dataset_root,
        manifest_root=manifest_root,
        manifest_path=manifest_path,
        num_rows=len(rows),
        split_counts=split_counts,
        class_counts=class_counts,
        checked_image_count=checked,
        missing_image_count=len(missing_images),
        missing_images=missing_images[:25],
        expected_labels=list(expected_labels),
        duplicate_image_hash_count=duplicate_hash_count,
        duplicate_cross_split_image_hash_count=duplicate_cross_split_hash_count,
        duplicate_image_hashes=duplicate_hash_preview,
    )


def _display_markdown(markdown: str) -> None:
    try:
        from IPython.display import Markdown, display

        display(Markdown(markdown))
    except Exception:
        print(markdown)


def _display_table(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    try:
        import pandas as pd
        from IPython.display import display

        display(pd.DataFrame(rows))
    except Exception:
        headers = list(rows[0].keys())
        print("\t".join(headers))
        for row in rows:
            print("\t".join(str(row.get(header, "")) for header in headers))


def display_preflight_report(report: PreflightReport) -> None:
    """Render a notebook-friendly preflight report."""

    status = "OK" if report.ok else "FAILED"
    if report.skipped and report.ok:
        status = "SKIPPED"

    _display_markdown(
        "\n".join(
            [
                f"### Preflight: {status}",
                "",
                f"- Task: `{report.task_name}`",
                f"- Dataset root: `{report.dataset_root}`",
                f"- Manifest: `{report.manifest_path}`",
                f"- Rows: `{report.num_rows}`",
                f"- Images checked: `{report.checked_image_count}`",
                f"- Missing images: `{report.missing_image_count}`",
                f"- Duplicate image hashes: `{report.duplicate_image_hash_count}`",
                f"- Cross-split duplicate hashes: `{report.duplicate_cross_split_image_hash_count}`",
            ]
        )
    )

    if report.errors:
        _display_markdown("#### Errors\n\n" + "\n".join(f"- {message}" for message in report.errors))
    if report.warnings:
        _display_markdown("#### Warnings\n\n" + "\n".join(f"- {message}" for message in report.warnings))

    split_rows = [{"split": split, "count": count} for split, count in report.split_counts.items()]
    if split_rows:
        _display_markdown("#### Split counts")
        _display_table(split_rows)

    class_rows = [{"label": label, "count": count} for label, count in report.class_counts.items()]
    if class_rows:
        _display_markdown("#### Class counts")
        _display_table(class_rows)

    if report.missing_images:
        _display_markdown(
            "#### Missing image sample\n\n"
            + "\n".join(f"- `{path}`" for path in report.missing_images[:10])
        )
    if report.duplicate_image_hashes:
        rows = []
        for group_index, group in enumerate(report.duplicate_image_hashes, start=1):
            for item in group.get("items", []):
                rows.append(
                    {
                        "group": group_index,
                        "split": item.get("split"),
                        "label": item.get("label_name"),
                        "image": item.get("image_path"),
                    }
                )
        _display_markdown("#### Cross-split duplicate image sample")
        _display_table(rows)
