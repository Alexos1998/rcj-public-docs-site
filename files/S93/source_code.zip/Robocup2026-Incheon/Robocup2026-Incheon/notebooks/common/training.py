"""Training loop primitives for compact notebook experiments."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class EpochMetrics:
    epoch: int
    train_loss: float
    val_loss: float | None = None
    val_metric: float | None = None


def train_one_epoch(model, dataloader, optimizer, loss_fn, device):
    """Run one supervised training epoch with PyTorch."""

    model.train()
    total_loss = 0.0
    total_items = 0
    for images, targets in dataloader:
        images = images.to(device)
        targets = targets.to(device)
        optimizer.zero_grad(set_to_none=True)
        outputs = model(images)
        loss = loss_fn(outputs, targets)
        loss.backward()
        optimizer.step()
        batch_size = images.shape[0]
        total_loss += float(loss.detach().cpu()) * batch_size
        total_items += batch_size
    return total_loss / max(total_items, 1)


def evaluate_loss(model, dataloader, loss_fn, device):
    """Evaluate average loss without updating model weights."""

    try:
        import torch
    except ImportError as exc:
        raise RuntimeError("Install torch to run evaluation.") from exc

    model.eval()
    total_loss = 0.0
    total_items = 0
    with torch.no_grad():
        for images, targets in dataloader:
            images = images.to(device)
            targets = targets.to(device)
            outputs = model(images)
            loss = loss_fn(outputs, targets)
            batch_size = images.shape[0]
            total_loss += float(loss.detach().cpu()) * batch_size
            total_items += batch_size
    return total_loss / max(total_items, 1)

