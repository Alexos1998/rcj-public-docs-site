"""Reusable OpenCV utilities for the CognitiveTarget branch."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


def _require_cv2_np():
    try:
        import cv2
        import numpy as np
    except ImportError as exc:
        raise RuntimeError("Install opencv-python and numpy for target CV experiments.") from exc
    return cv2, np


@dataclass(frozen=True)
class TargetCvConfig:
    min_radius: int = 8
    max_radius: int = 180
    hough_dp: float = 1.4
    hough_min_dist: int = 40
    hough_param1: int = 90
    hough_param2: int = 24
    blur_kernel: int = 7
    morph_kernel: int = 3
    unwrap_width: int = 360
    unwrap_height: int | None = None
    n_bands: int = 5
    min_color_fraction: float = 0.04
    hsv_thresholds: dict[str, list[tuple[tuple[int, int, int], tuple[int, int, int]]]] = field(
        default_factory=lambda: {
            "K": [((0, 0, 0), (179, 255, 70))],
            "R": [((0, 70, 40), (12, 255, 255)), ((168, 70, 40), (179, 255, 255))],
            "Y": [((18, 70, 60), (38, 255, 255))],
            "G": [((40, 50, 40), (88, 255, 255))],
            "B": [((90, 50, 40), (132, 255, 255))],
        }
    )


def _normalize_image(image):
    cv2, np = _require_cv2_np()
    image = np.asarray(image)
    if image.ndim != 3:
        raise ValueError(f"Expected HWC image, got shape {image.shape}.")
    if image.shape[2] == 4:
        return cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)
    if image.shape[2] != 3:
        raise ValueError(f"Expected 3 or 4 channels, got shape {image.shape}.")
    return image


def _target_color_mask(bgr_image, config: TargetCvConfig):
    cv2, np = _require_cv2_np()
    hsv = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2HSV)
    mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
    for ranges in config.hsv_thresholds.values():
        for low, high in ranges:
            mask |= cv2.inRange(hsv, np.array(low, dtype=np.uint8), np.array(high, dtype=np.uint8))
    kernel = np.ones((config.morph_kernel, config.morph_kernel), dtype=np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    return mask


def estimate_target_circle(image, config: TargetCvConfig = TargetCvConfig()) -> dict:
    """Estimate target circle center/radius from visible target-colored pixels."""

    cv2, np = _require_cv2_np()
    bgr_image = _normalize_image(image)
    gray = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2GRAY)
    blur_kernel = config.blur_kernel if config.blur_kernel % 2 == 1 else config.blur_kernel + 1
    gray = cv2.GaussianBlur(gray, (blur_kernel, blur_kernel), 1.5)

    circles = cv2.HoughCircles(
        gray,
        cv2.HOUGH_GRADIENT,
        dp=config.hough_dp,
        minDist=config.hough_min_dist,
        param1=config.hough_param1,
        param2=config.hough_param2,
        minRadius=config.min_radius,
        maxRadius=config.max_radius,
    )
    if circles is not None:
        circles = np.around(circles[0]).astype(float)
        cx, cy, radius = max(circles, key=lambda circle: circle[2])
        return {
            "success": True,
            "center": (float(cx), float(cy)),
            "radius": float(radius),
            "method": "hough",
            "debug": {"num_circles": int(len(circles))},
        }

    mask = _target_color_mask(bgr_image, config)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return {
            "success": False,
            "center": None,
            "radius": None,
            "method": None,
            "debug": {"reason": "no_colored_contours", "mask": mask},
        }

    contour = max(contours, key=cv2.contourArea)
    (cx, cy), radius = cv2.minEnclosingCircle(contour)
    if radius < config.min_radius:
        return {
            "success": False,
            "center": None,
            "radius": None,
            "method": "contour",
            "debug": {"reason": "radius_too_small", "radius": float(radius), "mask": mask},
        }
    return {
        "success": True,
        "center": (float(cx), float(cy)),
        "radius": float(radius),
        "method": "contour",
        "debug": {"mask": mask, "contour_area": float(cv2.contourArea(contour))},
    }


def polar_unwrap_target(
    image,
    center: tuple[float, float],
    radius: float,
    output_shape: tuple[int, int] = (120, 360),
):
    """Unwrap a circular target into a rectangular polar image.

    `output_shape` is `(height, width)`. The width axis follows angle, which
    matches the legacy target notebook's five-band convention.
    """

    cv2, _ = _require_cv2_np()
    bgr_image = _normalize_image(image)
    height, width = output_shape
    unwrapped = cv2.warpPolar(
        bgr_image,
        (int(width), int(height)),
        (float(center[0]), float(center[1])),
        float(radius),
        cv2.WARP_POLAR_LINEAR | cv2.WARP_FILL_OUTLIERS,
    )
    return unwrapped


def split_target_bands(unwrapped, n_bands: int = 5) -> list:
    """Split the polar image into vertical angular bands."""

    _, np = _require_cv2_np()
    image = np.asarray(unwrapped)
    width = image.shape[1]
    edges = np.linspace(0, width, n_bands + 1).round().astype(int)
    return [image[:, edges[index] : edges[index + 1]] for index in range(n_bands)]


def classify_hsv_color(region, config: TargetCvConfig = TargetCvConfig()) -> str:
    """Return the dominant target color code in a BGR region: K, R, Y, G, or B."""

    cv2, np = _require_cv2_np()
    bgr_region = _normalize_image(region)
    if bgr_region.size == 0:
        return "?"
    hsv = cv2.cvtColor(bgr_region, cv2.COLOR_BGR2HSV)
    counts: dict[str, int] = {}
    for code, ranges in config.hsv_thresholds.items():
        mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
        for low, high in ranges:
            mask |= cv2.inRange(hsv, np.array(low, dtype=np.uint8), np.array(high, dtype=np.uint8))
        counts[code] = int(np.count_nonzero(mask))

    total = int(hsv.shape[0] * hsv.shape[1])
    if total <= 0:
        return "?"
    code, count = max(counts.items(), key=lambda item: item[1])
    return code if count / total >= config.min_color_fraction else "?"


def decode_target_sequence(image, config: TargetCvConfig = TargetCvConfig()) -> dict:
    """Decode the ordered K/R/Y/G/B target color sequence from an image."""

    circle = estimate_target_circle(image, config)
    if not circle["success"]:
        return {
            "success": False,
            "sequence": None,
            "center": None,
            "radius": None,
            "unwrapped": None,
            "bands": [],
            "band_colors": [],
            "debug": circle.get("debug", {}),
        }

    radius = float(circle["radius"])
    unwrap_height = config.unwrap_height or max(1, int(round(radius)))
    unwrapped = polar_unwrap_target(
        image,
        circle["center"],
        radius,
        output_shape=(unwrap_height, config.unwrap_width),
    )
    bands = split_target_bands(unwrapped, config.n_bands)
    band_colors = [classify_hsv_color(band, config) for band in bands]
    success = len(band_colors) == config.n_bands and "?" not in band_colors
    return {
        "success": success,
        "sequence": "".join(band_colors) if success else None,
        "center": circle["center"],
        "radius": radius,
        "unwrapped": unwrapped,
        "bands": bands,
        "band_colors": band_colors,
        "debug": {"circle": circle, "config": config},
    }


def draw_target_debug(image, result: dict) -> Any:
    """Draw center/radius and decoded sequence on a copy of the image."""

    cv2, np = _require_cv2_np()
    output = _normalize_image(image).copy()
    center = result.get("center")
    radius = result.get("radius")
    if center is not None and radius is not None:
        cx, cy = int(round(center[0])), int(round(center[1]))
        cv2.circle(output, (cx, cy), int(round(radius)), (0, 255, 0), 2)
        cv2.circle(output, (cx, cy), 3, (0, 0, 255), -1)
    sequence = result.get("sequence") or "".join(result.get("band_colors", [])) or "?"
    status = "ok" if result.get("success") else "fail"
    cv2.putText(output, f"{status}: {sequence}", (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
    return output


class TargetDecoder:
    """Small adapter so runtime prototypes can call `decode(frame)`."""

    def __init__(self, config: TargetCvConfig = TargetCvConfig()) -> None:
        self.config = config

    def decode(self, frame) -> dict:
        return decode_target_sequence(frame, self.config)


def save_debug_panel(path: str | Path, images: list, labels: list[str] | None = None) -> Path:
    """Save an easy-to-inspect horizontal debug panel."""

    cv2, np = _require_cv2_np()
    if not images:
        raise ValueError("At least one image is required for a debug panel.")
    normalized = [_normalize_image(image) for image in images]
    height = max(image.shape[0] for image in normalized)
    resized = []
    for image in normalized:
        if image.shape[0] != height:
            scale = height / image.shape[0]
            image = cv2.resize(image, (int(round(image.shape[1] * scale)), height))
        resized.append(image)
    panel = np.hstack(resized)
    if labels:
        x = 8
        for label, image in zip(labels, resized):
            cv2.putText(panel, label, (x, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            x += image.shape[1]
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(output_path), panel)
    return output_path



# --------------------------------------------------------------------------- #
# Ellipse geometry helpers (pure functions) for the trainable target branch.
# --------------------------------------------------------------------------- #
# These are runtime-safe (no ground-truth dependency) and operate on the
# normalized 7-value ellipse [cx, cy, major, minor, sin, cos, ratio].


def ellipse_to_bbox(
    cx: float,
    cy: float,
    major: float,
    minor: float,
    angle_rad: float,
    image_width: int,
    image_height: int,
    padding: float = 0.0,
) -> tuple[int, int, int, int]:
    """Pixel-space axis-aligned bbox ``(xmin, ymin, xmax, ymax)`` of an ellipse.

    Inputs are normalized (``cx, cy, major, minor`` in ``[0, 1]``); the result is
    clamped to the image and expanded by ``padding`` (fraction of each side).
    """

    import math

    half_w = math.hypot(major * math.cos(angle_rad), minor * math.sin(angle_rad))
    half_h = math.hypot(major * math.sin(angle_rad), minor * math.cos(angle_rad))
    half_w *= 1.0 + max(0.0, padding)
    half_h *= 1.0 + max(0.0, padding)
    xmin = int(round(max(0.0, cx - half_w) * image_width))
    ymin = int(round(max(0.0, cy - half_h) * image_height))
    xmax = int(round(min(1.0, cx + half_w) * image_width))
    ymax = int(round(min(1.0, cy + half_h) * image_height))
    if xmax <= xmin:
        xmin, xmax = 0, image_width
    if ymax <= ymin:
        ymin, ymax = 0, image_height
    return xmin, ymin, xmax, ymax


def _ellipse_angle_rad(ellipse) -> float:
    import math

    sin_a, cos_a = float(ellipse[4]), float(ellipse[5])
    return math.atan2(sin_a, cos_a)


def crop_target_from_ellipse(image, ellipse, padding: float = 0.05):
    """Crop the target region from a PIL/ndarray image using an ellipse bbox."""

    from PIL import Image

    pil = image if hasattr(image, "crop") else Image.fromarray(image)
    width, height = pil.size
    xmin, ymin, xmax, ymax = ellipse_to_bbox(
        float(ellipse[0]), float(ellipse[1]), float(ellipse[2]), float(ellipse[3]),
        _ellipse_angle_rad(ellipse), width, height, padding=padding,
    )
    return pil.crop((xmin, ymin, xmax, ymax))


def warp_ellipse_to_circle(image, ellipse, output_size: int = 64):
    """Warp the ellipse region to a fronto-parallel circular crop.

    Rotates by ``-angle``, scales the minor axis up to the major axis (undoing
    perspective foreshortening) and returns a square ``output_size`` crop. Pure
    PIL; falls back to a plain bbox crop if the ellipse is degenerate.
    """

    import math

    from PIL import Image

    pil = (image if hasattr(image, "crop") else Image.fromarray(image)).convert("RGB")
    width, height = pil.size
    cx, cy, major, minor = (float(ellipse[i]) for i in range(4))
    angle_deg = math.degrees(_ellipse_angle_rad(ellipse))
    if major <= 0 or minor <= 0:
        return pil.resize((output_size, output_size), Image.BILINEAR)
    rotated = pil.rotate(angle_deg, resample=Image.BILINEAR, center=(cx * width, cy * height))
    # After rotation the ellipse is axis-aligned; stretch minor axis to major.
    scale = major / minor
    new_h = max(1, int(round(height * scale)))
    stretched = rotated.resize((width, new_h), Image.BILINEAR)
    ccy = cy * scale
    half = major
    left = int(round(max(0.0, cx - half) * width))
    right = int(round(min(1.0, cx + half) * width))
    top = int(round(max(0.0, ccy - half) * new_h))
    bottom = int(round(min(1.0, ccy + half) * new_h))
    if right <= left or bottom <= top:
        return pil.resize((output_size, output_size), Image.BILINEAR)
    return stretched.crop((left, top, right, bottom)).resize((output_size, output_size), Image.BILINEAR)
