"""Resolution-aware, translation-robust features for the map specialists.

The original features in ``map_dataset`` collapse a ~37x37 (0.0033 m/px) patch into
coarse occupancy *ratios* over fixed bands. That throws away the fine geometry the
SLAM resolution actually provides and is fragile to the sub-cell mis-centring of the
crops. Measured separability on the collected runs:

* wall, single feature, fixed band vs. **profile-peak search**: AUC 0.928 -> 0.967;
* curve direction, zero-training nearest-angle on the occupancy **centroid**: 73%.

So instead of re-centring the crop (a global translation was measured to *hurt*),
each model gets features that *locate* its structure inside a small search window:

* ``wall``   : a 1-D occupancy profile across the (north-rotated) edge -> peak height,
  peak position, thickness, lateral coverage, inside/outside free.
* ``curve``  : occupancy centroid offset + angle (sin/cos) + radius, the 4 corner
  boxes and 4 edge bands (direction is read straight off the centroid angle).
* ``obstacle``: interior blob mass, centroid distance from the tile centre, peak and
  compactness (a central blob fires; edge walls do not).

All pure numpy, north-up patches, occupancy convention occ>=65 / free in [0,25] /
unknown <0 (same as ``map_dataset``).
"""

from __future__ import annotations

import numpy as np

from .map_dataset import SUB_LO, SUB_HI, _band, DIRS, _rot_for_dir

OCC, FREE_HI = 65, 25


# --------------------------------------------------------------------------- #
# small helpers
# --------------------------------------------------------------------------- #
def _occ(patch: np.ndarray) -> np.ndarray:
    return patch >= OCC


def _free_ratio(patch: np.ndarray, rs: slice, cs: slice) -> float:
    reg = patch[rs, cs]
    n = reg.size or 1
    return float(((reg >= 0) & (reg <= FREE_HI)).sum()) / n


def _occ_ratio(patch: np.ndarray, rs: slice, cs: slice) -> float:
    reg = patch[rs, cs]
    n = reg.size or 1
    return float((reg >= OCC).sum()) / n


# --------------------------------------------------------------------------- #
# WALL: 1-D profile across the north edge (translation-robust localization)
# --------------------------------------------------------------------------- #
WALL_FEATURE_NAMES = (
    "peak_occ",       # max occupancy of the wall line (localized, the strong cue)
    "peak_pos",       # where the peak sits vs the expected edge (cells, signed)
    "thickness",      # occupied profile width at half-peak (cells ~ wall thickness)
    "lateral_cover",  # fraction of the edge length covered at the peak row
    "inside_free",    # free ratio just inside the subtile
    "outside_free",   # free ratio just outside (neighbour)
    "edge_occ_fixed", # original fixed-band occupancy (cheap complement)
    "edge_grad",      # gradient magnitude across the edge
)


def wall_features(patch: np.ndarray, margin: float = 0.08, band: float = 0.06,
                  search: float = 0.14) -> np.ndarray:
    """Wall-on-NORTH-edge features from a perpendicular occupancy profile.

    The subtile occupies fraction [0.25, 0.75]; its north edge is at 0.25. We build
    the occupancy profile along the perpendicular (row) axis over a window around
    0.25, laterally restricted by ``margin`` to avoid corner arcs, and read off the
    peak height/position/thickness instead of a single fixed-band ratio.
    """
    s = patch.shape[0]
    cs = _band(s, SUB_LO + margin, SUB_HI - margin)
    occ = _occ(patch)

    lo = SUB_LO - search
    hi = SUB_LO + search
    r0, r1 = int(round(lo * s)), int(round(hi * s))
    r0, r1 = max(0, r0), min(s, r1)
    # per-row occupancy fraction across the (laterally restricted) edge
    prof = occ[r0:r1, cs].mean(axis=1) if r1 > r0 else np.zeros(1)
    if prof.size == 0:
        prof = np.zeros(1)

    peak_occ = float(prof.max())
    peak_i = int(prof.argmax())
    edge_row = SUB_LO * s - r0  # expected edge position within the profile window
    peak_pos = float(peak_i - edge_row)

    half = peak_occ * 0.5
    thickness = float((prof >= max(half, 0.05)).sum()) if peak_occ > 0 else 0.0

    # lateral coverage: of the cells along the peak row, how many are occupied
    peak_abs = r0 + peak_i
    lateral_cover = float(occ[peak_abs, cs].mean()) if 0 <= peak_abs < s else 0.0

    inside = _free_ratio(patch, _band(s, SUB_LO, SUB_LO + band), cs)
    outside = _free_ratio(patch, _band(s, SUB_LO - band, SUB_LO), cs)
    fixed = _occ_ratio(patch, _band(s, SUB_LO - band, SUB_LO + band), cs)

    known = np.where(patch < 0, 0.0, patch.astype(np.float32) / 100.0)
    sub = known[_band(s, SUB_LO - band, SUB_LO + band), cs]
    grad = 0.0
    if min(sub.shape) >= 2:
        gy, gx = np.gradient(sub)
        grad = float(np.sqrt(gx * gx + gy * gy).mean())

    return np.asarray(
        [peak_occ, peak_pos, thickness, lateral_cover, inside, outside, fixed, grad],
        np.float32,
    )


# --------------------------------------------------------------------------- #
# CURVE: occupancy centroid (direction) + corner boxes + edges
# --------------------------------------------------------------------------- #
# Polar occupancy profile: a quarter-arc (the curve proto) is a RING at a fixed
# radius from the subtile centre, so it is linearly separable in (radius, angle);
# a straight-wall 'L' corner is NOT. Adding this profile to the centroid features
# lifts curve macro-recall AND roughly halves the none->curve false positives
# (181 -> ~100 measured) — it is the single most effective curve treatment found.
CURVE_POLAR_NR = 6
CURVE_POLAR_NA = 12

CURVE_FEATURE_NAMES = (
    "cen_x", "cen_y",          # occupancy centroid offset within subtile (-1..1)
    "ang_sin", "ang_cos",      # centroid angle (continuous, no wraparound)
    "radius",                  # centroid distance from centre (arc -> toward a corner)
    "corner_nw", "corner_ne", "corner_sw", "corner_se",
    "edge_n", "edge_e", "edge_s", "edge_w",
    "center", "occ_total",
) + tuple(f"polar_r{r}a{a}" for r in range(CURVE_POLAR_NR) for a in range(CURVE_POLAR_NA))


def _subtile_slice(s: int) -> slice:
    return _band(s, SUB_LO, SUB_HI)


def polar_occupancy(patch: np.ndarray, nr: int = CURVE_POLAR_NR,
                    na: int = CURVE_POLAR_NA) -> np.ndarray:
    """Mean occupancy in a (radius x angle) polar grid centred on the patch.

    Returns an ``nr*na`` vector. An arc concentrates mass in one radius ring across a
    span of angles; a straight 'L' spreads mass along two radial spokes — so this
    representation separates curve-from-wall-corner where ratio features cannot.
    """
    s = patch.shape[0]
    c = (s - 1) / 2.0
    occ = (patch >= OCC).astype(np.float64)
    ys, xs = np.mgrid[0:s, 0:s]
    dy, dx = c - ys, xs - c
    r = np.clip((np.hypot(dx, dy) / (s * 0.5) * nr).astype(int), 0, nr - 1)
    a = np.clip(((np.arctan2(dy, dx) + np.pi) / (2 * np.pi) * na).astype(int), 0, na - 1)
    b = (r * na + a).ravel()
    tot = np.bincount(b, minlength=nr * na)
    ssum = np.bincount(b, weights=occ.ravel(), minlength=nr * na)
    return np.divide(ssum, tot, out=np.zeros_like(ssum), where=tot > 0).astype(np.float32)


def curve_features(patch: np.ndarray, margin: float = 0.10, corner: float = 0.18) -> np.ndarray:
    s = patch.shape[0]
    sub = _subtile_slice(s)
    block = patch[sub, sub]
    occ = block >= OCC
    n = block.shape[0]
    c = (n - 1) / 2.0
    if occ.sum() >= 1:
        ys, xs = np.where(occ)
        cen_x = (xs.mean() - c) / (c or 1)       # +east
        cen_y = (c - ys.mean()) / (c or 1)       # +north (image row grows south)
    else:
        cen_x = cen_y = 0.0
    ang = np.arctan2(cen_y, cen_x)
    radius = float(np.hypot(cen_x, cen_y))
    occ_total = float(occ.mean())

    lo, hi = SUB_LO, SUB_HI
    boxes = {
        "NW": (lo + margin, lo + margin + corner, lo + margin, lo + margin + corner),
        "NE": (lo + margin, lo + margin + corner, hi - margin - corner, hi - margin),
        "SW": (hi - margin - corner, hi - margin, lo + margin, lo + margin + corner),
        "SE": (hi - margin - corner, hi - margin, hi - margin - corner, hi - margin),
    }
    cb = [_occ_ratio(patch, _band(s, r0, r1), _band(s, c0, c1))
          for (r0, r1, c0, c1) in boxes.values()]

    cs = _band(s, lo, hi)
    rs = _band(s, lo, hi)
    eb = 0.06
    edge_n = _occ_ratio(patch, _band(s, lo - eb, lo + eb), cs)
    edge_e = _occ_ratio(patch, rs, _band(s, hi - eb, hi + eb))
    edge_s = _occ_ratio(patch, _band(s, hi - eb, hi + eb), cs)
    edge_w = _occ_ratio(patch, rs, _band(s, lo - eb, lo + eb))
    center = _occ_ratio(patch, _band(s, 0.4, 0.6), _band(s, 0.4, 0.6))

    base = np.asarray(
        [cen_x, cen_y, float(np.sin(ang)), float(np.cos(ang)), radius,
         cb[0], cb[1], cb[2], cb[3], edge_n, edge_e, edge_s, edge_w, center, occ_total],
        np.float32,
    )
    return np.concatenate([base, polar_occupancy(patch)])


# --------------------------------------------------------------------------- #
# OBSTACLE: central blob (mass, centrality, compactness)
# --------------------------------------------------------------------------- #
OBSTACLE_FEATURE_NAMES = (
    "interior_occ", "interior_free", "interior_unk",
    "center_occ", "blob_radius", "compactness", "interior_grad",
)


def obstacle_features(patch: np.ndarray, margin: float = 0.20) -> np.ndarray:
    s = patch.shape[0]
    rs = _band(s, margin, 1.0 - margin)
    cs = _band(s, margin, 1.0 - margin)
    reg = patch[rs, cs]
    n = reg.size or 1
    occ = reg >= OCC
    interior_occ = float(occ.sum()) / n
    interior_free = float(((reg >= 0) & (reg <= FREE_HI)).sum()) / n
    interior_unk = float((reg < 0).sum()) / n
    center_occ = _occ_ratio(patch, _band(s, 0.4, 0.6), _band(s, 0.4, 0.6))

    # blob centrality: distance of the occupied centroid from the interior centre.
    if occ.sum() >= 1:
        ys, xs = np.where(occ)
        cy, cx = (occ.shape[0] - 1) / 2.0, (occ.shape[1] - 1) / 2.0
        blob_radius = float(np.hypot(xs.mean() - cx, ys.mean() - cy) /
                            (np.hypot(cx, cy) or 1))
        # compactness: occupied mass / bbox area (a blob ~ high, a thin wall ~ low).
        bb = (ys.max() - ys.min() + 1) * (xs.max() - xs.min() + 1)
        compactness = float(occ.sum()) / (bb or 1)
    else:
        blob_radius = compactness = 0.0

    known = np.where(reg < 0, 0.0, reg.astype(np.float32) / 100.0)
    grad = 0.0
    if min(known.shape) >= 2:
        gy, gx = np.gradient(known)
        grad = float(np.sqrt(gx * gx + gy * gy).mean())

    return np.asarray(
        [interior_occ, interior_free, interior_unk, center_occ,
         blob_radius, compactness, grad], np.float32,
    )


# --------------------------------------------------------------------------- #
# Dispatch (mirrors map_dataset.features_for so it can be swapped in)
# --------------------------------------------------------------------------- #
FEATURE_NAMES_BY_TASK = {
    "parede": WALL_FEATURE_NAMES, "wall": WALL_FEATURE_NAMES,
    "curva": CURVE_FEATURE_NAMES, "curve": CURVE_FEATURE_NAMES,
    "obstaculo": OBSTACLE_FEATURE_NAMES, "obstacle": OBSTACLE_FEATURE_NAMES,
}


def features_for(task: str, patch: np.ndarray, margin: float) -> np.ndarray:
    if task in ("parede", "wall"):
        return wall_features(patch, margin)
    if task in ("curva", "curve"):
        return curve_features(patch, margin)
    if task in ("obstaculo", "obstacle"):
        return obstacle_features(patch, margin)
    raise ValueError(f"unknown task {task!r}")


def wall_features_all_dirs(patch: np.ndarray, margin: float = 0.08) -> np.ndarray:
    """Stack the 4 rotated edge feature vectors (for batched runtime)."""
    return np.stack([wall_features(_rot_for_dir(patch, d), margin) for d in DIRS])
