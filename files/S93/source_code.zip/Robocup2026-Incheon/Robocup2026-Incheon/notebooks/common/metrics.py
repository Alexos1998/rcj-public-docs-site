"""Metrics helpers that avoid notebook-specific implementations."""

from __future__ import annotations

import math
from collections import Counter
from statistics import mean, median
from typing import Sequence


def confusion_matrix(y_true: Sequence[str], y_pred: Sequence[str], classes: Sequence[str]) -> list[list[int]]:
    index = {label: idx for idx, label in enumerate(classes)}
    matrix = [[0 for _ in classes] for _ in classes]
    for true_label, pred_label in zip(y_true, y_pred):
        if true_label in index and pred_label in index:
            matrix[index[true_label]][index[pred_label]] += 1
    return matrix


def classification_report(y_true: Sequence[str], y_pred: Sequence[str], classes: Sequence[str]) -> dict[str, dict[str, float]]:
    matrix = confusion_matrix(y_true, y_pred, classes)
    report = {}
    for idx, label in enumerate(classes):
        tp = matrix[idx][idx]
        predicted = sum(row[idx] for row in matrix)
        actual = sum(matrix[idx])
        precision = tp / predicted if predicted else 0.0
        recall = tp / actual if actual else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        report[label] = {"precision": precision, "recall": recall, "f1": f1, "support": actual}
    report["accuracy"] = {"value": sum(matrix[i][i] for i in range(len(classes))) / max(len(y_true), 1)}
    return report


def label_distribution(items: Sequence[dict], label_key: str = "label") -> Counter:
    return Counter(str(item.get(label_key, "")) for item in items)


# --------------------------------------------------------------------------- #
# Binary mask segmentation metrics (operate on boolean arrays).
# --------------------------------------------------------------------------- #


def mask_confusion(pred, target) -> tuple[int, int, int, int]:
    """Return ``(tp, fp, fn, tn)`` pixel counts for two boolean masks."""

    pred = pred.astype(bool)
    target = target.astype(bool)
    tp = int((pred & target).sum())
    fp = int((pred & ~target).sum())
    fn = int((~pred & target).sum())
    tn = int((~pred & ~target).sum())
    return tp, fp, fn, tn


def mask_iou(pred, target) -> float:
    """Intersection-over-union of two boolean masks (1.0 when both empty)."""

    tp, fp, fn, _ = mask_confusion(pred, target)
    union = tp + fp + fn
    return 1.0 if union == 0 else tp / union


def mask_dice(pred, target) -> float:
    """Dice (F1) overlap of two boolean masks (1.0 when both empty)."""

    tp, fp, fn, _ = mask_confusion(pred, target)
    denom = 2 * tp + fp + fn
    return 1.0 if denom == 0 else (2 * tp) / denom


def mask_precision_recall(pred, target) -> tuple[float, float]:
    """Pixel precision and recall of ``pred`` against ``target``."""

    tp, fp, fn, _ = mask_confusion(pred, target)
    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    return precision, recall


def mask_metrics(pred, target) -> dict[str, float]:
    """Aggregate ``iou``/``dice``/``precision``/``recall`` for two boolean masks."""

    precision, recall = mask_precision_recall(pred, target)
    return {
        "iou": mask_iou(pred, target),
        "dice": mask_dice(pred, target),
        "precision": precision,
        "recall": recall,
    }


def boundary_iou(pred, target, dilation: int = 2) -> float:
    """IoU restricted to a thin band around each mask's boundary.

    Simple morphological boundary IoU: the boundary is the mask minus its
    erosion, dilated by ``dilation`` pixels. Falls back to volumetric IoU when
    OpenCV is unavailable.
    """

    try:
        import cv2
        import numpy as np
    except ImportError:  # pragma: no cover - environment guard
        return mask_iou(pred, target)

    def band(mask) -> "np.ndarray":
        mask = mask.astype("uint8")
        kernel = np.ones((3, 3), np.uint8)
        eroded = cv2.erode(mask, kernel, iterations=1)
        edge = mask - eroded
        return cv2.dilate(edge, kernel, iterations=max(0, dilation - 1)).astype(bool)

    return mask_iou(band(pred), band(target))


# --------------------------------------------------------------------------- #
# Ellipse localization metrics (pure-python, operate on 7-value vectors).
# --------------------------------------------------------------------------- #
# Ellipse vector layout: [cx, cy, radius_major, radius_minor, sin, cos, ratio].


def ellipse_angle_deg(sin_a: float, cos_a: float) -> float:
    """Orientation in degrees from a (possibly non-unit) sin/cos pair."""

    return math.degrees(math.atan2(sin_a, cos_a))


def _angle_diff_deg(a: float, b: float) -> float:
    """Smallest difference between two orientations, modulo 180 degrees."""

    diff = abs(a - b) % 180.0
    return min(diff, 180.0 - diff)


def ellipse_to_aabb(ellipse: Sequence[float]) -> tuple[float, float, float, float]:
    """Axis-aligned bbox ``(xmin, ymin, xmax, ymax)`` of a normalized ellipse."""

    cx, cy, major, minor, sin_a, cos_a = (float(v) for v in ellipse[:6])
    norm = math.hypot(sin_a, cos_a) or 1.0
    sin_a, cos_a = sin_a / norm, cos_a / norm
    half_w = math.hypot(major * cos_a, minor * sin_a)
    half_h = math.hypot(major * sin_a, minor * cos_a)
    return cx - half_w, cy - half_h, cx + half_w, cy + half_h


def _bbox_iou(a: tuple[float, float, float, float], b: tuple[float, float, float, float]) -> float:
    ix0, iy0 = max(a[0], b[0]), max(a[1], b[1])
    ix1, iy1 = min(a[2], b[2]), min(a[3], b[3])
    inter = max(0.0, ix1 - ix0) * max(0.0, iy1 - iy0)
    area_a = max(0.0, a[2] - a[0]) * max(0.0, a[3] - a[1])
    area_b = max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])
    union = area_a + area_b - inter
    return inter / union if union > 0 else 0.0


def ellipse_metrics(
    preds: Sequence[Sequence[float]], targets: Sequence[Sequence[float]]
) -> dict[str, float]:
    """Aggregate ellipse-localization metrics over ``preds``/``targets``.

    Returns center/axis/perspective errors, angle errors (deg, modulo 180) and
    the mean/median IoU of the axis-aligned bounding boxes of the ellipses.
    """

    if not preds:
        return {}
    center_err, major_err, minor_err, persp_err, angle_err, ious = [], [], [], [], [], []
    for pred, target in zip(preds, targets):
        center_err.append(math.hypot(pred[0] - target[0], pred[1] - target[1]))
        major_err.append(abs(pred[2] - target[2]))
        minor_err.append(abs(pred[3] - target[3]))
        persp_err.append(abs(pred[6] - target[6]))
        angle_err.append(
            _angle_diff_deg(ellipse_angle_deg(pred[4], pred[5]), ellipse_angle_deg(target[4], target[5]))
        )
        ious.append(_bbox_iou(ellipse_to_aabb(pred), ellipse_to_aabb(target)))
    return {
        "mean_center_error": mean(center_err),
        "median_center_error": median(center_err),
        "mean_major_error": mean(major_err),
        "mean_minor_error": mean(minor_err),
        "mean_perspective_error": mean(persp_err),
        "mean_angle_error_deg": mean(angle_err),
        "median_angle_error_deg": median(angle_err),
        "ellipse_bbox_iou": mean(ious),
        "median_ellipse_bbox_iou": median(ious),
    }

