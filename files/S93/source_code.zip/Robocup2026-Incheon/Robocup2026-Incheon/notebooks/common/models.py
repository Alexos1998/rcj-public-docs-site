"""Lightweight ONNX-friendly PyTorch models for perception notebooks."""

from __future__ import annotations

from typing import Iterable, Sequence

import torch
from torch import nn


def class_to_index(classes: tuple[str, ...]) -> dict[str, int]:
    return {name: index for index, name in enumerate(classes)}


def index_to_class(classes: tuple[str, ...]) -> dict[int, str]:
    return {index: name for index, name in enumerate(classes)}


def _as_hw(input_size: int | tuple[int, int]) -> tuple[int, int]:
    if isinstance(input_size, int):
        return input_size, input_size
    if len(input_size) != 2:
        raise ValueError("input_size must be an int or a (height, width) tuple.")
    return int(input_size[0]), int(input_size[1])


def _make_divisible(value: int, divisor: int = 8) -> int:
    return max(divisor, int(round(value / divisor) * divisor))


class DepthwiseSeparableConv(nn.Module):
    """Depthwise 3x3 convolution followed by pointwise 1x1 convolution."""

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 3,
        stride: int = 1,
        activation: type[nn.Module] = nn.ReLU,
    ) -> None:
        super().__init__()
        padding = kernel_size // 2
        self.block = nn.Sequential(
            nn.Conv2d(
                in_channels,
                in_channels,
                kernel_size=kernel_size,
                stride=stride,
                padding=padding,
                groups=in_channels,
                bias=False,
            ),
            nn.BatchNorm2d(in_channels),
            activation(inplace=True),
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(out_channels),
            activation(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class ResidualDepthwiseBlock(nn.Module):
    """Residual block built from ONNX-friendly depthwise separable convolutions."""

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        stride: int = 1,
        activation: type[nn.Module] = nn.ReLU,
    ) -> None:
        super().__init__()
        self.conv = DepthwiseSeparableConv(
            in_channels=in_channels,
            out_channels=out_channels,
            stride=stride,
            activation=activation,
        )
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(
                    in_channels, out_channels, kernel_size=1, stride=stride, bias=False
                ),
                nn.BatchNorm2d(out_channels),
            )
        else:
            self.shortcut = nn.Identity()
        self.activation = activation(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.activation(self.conv(x) + self.shortcut(x))


class LightweightChannelAttention(nn.Module):
    """Squeeze-and-excitation style channel attention using standard layers only."""

    def __init__(self, channels: int, reduction: int = 8) -> None:
        super().__init__()
        hidden_channels = max(4, channels // reduction)
        self.attention = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, hidden_channels, kernel_size=1, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_channels, channels, kernel_size=1, bias=True),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x * self.attention(x)


class _LightweightBackbone(nn.Module):
    """Shared feature extractor for classifier and bounding-box heads."""

    def __init__(
        self,
        input_size: int | tuple[int, int],
        base_channels: int = 24,
        attention_stages: Iterable[int] = (2, 3),
    ) -> None:
        super().__init__()
        self.input_size = _as_hw(input_size)
        c1 = _make_divisible(base_channels)
        c2 = _make_divisible(base_channels * 2)
        c3 = _make_divisible(base_channels * 4)
        c4 = _make_divisible(base_channels * 6)
        attention_stages = set(attention_stages)

        self.out_channels = c4
        self.stem = nn.Sequential(
            nn.Conv2d(3, c1, kernel_size=3, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(c1),
            nn.ReLU(inplace=True),
        )
        self.stage1 = nn.Sequential(
            ResidualDepthwiseBlock(c1, c1, stride=1),
            ResidualDepthwiseBlock(c1, c2, stride=2),
        )
        self.stage2 = nn.Sequential(
            ResidualDepthwiseBlock(c2, c2, stride=1),
            LightweightChannelAttention(c2) if 2 in attention_stages else nn.Identity(),
            ResidualDepthwiseBlock(c2, c3, stride=2),
        )
        self.stage3 = nn.Sequential(
            ResidualDepthwiseBlock(c3, c3, stride=1),
            LightweightChannelAttention(c3) if 3 in attention_stages else nn.Identity(),
            ResidualDepthwiseBlock(c3, c4, stride=2),
        )
        self.pool = nn.AdaptiveAvgPool2d(1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.stem(x)
        x = self.stage1(x)
        x = self.stage2(x)
        x = self.stage3(x)
        x = self.pool(x)
        return torch.flatten(x, 1)


class LightweightClassifier(nn.Module):
    """Lightweight classifier that returns raw logits."""

    def __init__(
        self,
        num_classes: int,
        input_size: int | tuple[int, int],
        dropout: float = 0.2,
        base_channels: int = 24,
    ) -> None:
        super().__init__()
        self.num_classes = num_classes
        self.input_size = _as_hw(input_size)
        self.backbone = _LightweightBackbone(
            input_size=input_size, base_channels=base_channels
        )
        self.head = nn.Sequential(
            nn.Dropout(p=dropout),
            nn.Linear(self.backbone.out_channels, _make_divisible(base_channels * 4)),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout),
            nn.Linear(_make_divisible(base_channels * 4), num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.head(self.backbone(x))


class LightweightBBoxRegressor(nn.Module):
    """Lightweight regressor that returns normalized [xmin, ymin, xmax, ymax]."""

    def __init__(
        self,
        input_size: int | tuple[int, int],
        dropout: float = 0.2,
        base_channels: int = 24,
    ) -> None:
        super().__init__()
        self.input_size = _as_hw(input_size)
        self.backbone = _LightweightBackbone(
            input_size=input_size, base_channels=base_channels
        )
        self.head = nn.Sequential(
            nn.Dropout(p=dropout),
            nn.Linear(self.backbone.out_channels, _make_divisible(base_channels * 4)),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout),
            nn.Linear(_make_divisible(base_channels * 4), 4),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        raw = torch.sigmoid(self.head(self.backbone(x)))
        x1y1 = torch.minimum(raw[:, 0:2], raw[:, 2:4])
        x2y2 = torch.maximum(raw[:, 0:2], raw[:, 2:4])
        return torch.cat([x1y1, x2y2], dim=1)


class LegacyColorAttention(nn.Module):
    """Channel attention block adapted from the old bbox notebook."""

    def __init__(self, channels: int, reduction: int = 8) -> None:
        super().__init__()
        hidden = max(4, channels // reduction)
        self.attention = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(1),
            nn.Linear(channels, hidden, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(hidden, channels, bias=False),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weights = self.attention(x).unsqueeze(-1).unsqueeze(-1)
        return x * weights


class LegacySpatialAttention(nn.Module):
    """Spatial attention block adapted from the old bbox notebook."""

    def __init__(self, kernel_size: int = 3) -> None:
        super().__init__()
        padding = kernel_size // 2
        self.conv = nn.Conv2d(2, 1, kernel_size=kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        avg_map = torch.mean(x, dim=1, keepdim=True)
        max_map, _ = torch.max(x, dim=1, keepdim=True)
        attention = torch.cat([avg_map, max_map], dim=1)
        attention = self.sigmoid(self.conv(attention))
        return x * attention


class LegacyDSConv(nn.Module):
    """Depthwise separable convolution used by the legacy bbox regressor."""

    def __init__(self, in_channels: int, out_channels: int, stride: int = 1, activation: str = "relu") -> None:
        super().__init__()
        self.use_residual = stride == 1 and in_channels == out_channels
        self.depthwise = nn.Conv2d(
            in_channels,
            in_channels,
            kernel_size=3,
            stride=stride,
            padding=1,
            groups=in_channels,
            bias=False,
        )
        self.pointwise = nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False)
        self.bn_depthwise = nn.BatchNorm2d(in_channels)
        self.bn_pointwise = nn.BatchNorm2d(out_channels)
        self.activation = nn.SiLU(inplace=True) if activation == "silu" else nn.ReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.depthwise(x)
        out = self.bn_depthwise(out)
        out = self.activation(out)
        out = self.pointwise(out)
        out = self.bn_pointwise(out)
        if self.use_residual:
            out = out + x
        return self.activation(out)


class LegacyBBoxRegressor(nn.Module):
    """BBox regressor inspired by ``classification_legacy.ipynb``.

    It keeps the old depthwise-convolution + color/spatial-attention layout, but
    constrains the head with sigmoid and coordinate sorting so the output is
    always a valid normalized ``[xmin, ymin, xmax, ymax]`` box.
    """

    def __init__(
        self,
        input_size: int | tuple[int, int] = 64,
        base_channels: int = 32,
        dropout: float = 0.0,
    ) -> None:
        super().__init__()
        self.input_size = _as_hw(input_size)
        c1 = _make_divisible(base_channels)
        c2 = _make_divisible(base_channels * 2)
        c3 = _make_divisible(base_channels * 4)
        c4 = _make_divisible(base_channels * 8)

        self.conv1 = LegacyDSConv(3, c1, stride=2, activation="relu")
        self.conv2 = LegacyDSConv(c1, c2, stride=2, activation="relu")
        self.conv3 = LegacyDSConv(c2, c3, stride=2, activation="relu")
        self.attention_c3 = nn.Sequential(LegacyColorAttention(c3), LegacySpatialAttention())
        self.conv4 = LegacyDSConv(c3, c3, stride=1, activation="silu")
        self.conv5 = LegacyDSConv(c3, c4, stride=1, activation="silu")
        self.attention_c4 = nn.Sequential(LegacyColorAttention(c4), LegacySpatialAttention())
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.dropout = nn.Dropout(p=dropout) if dropout > 0 else nn.Identity()
        self.regressor = nn.Linear(c4, 4)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.attention_c3(x)
        x = self.conv4(x)
        x = self.conv5(x)
        x = self.attention_c4(x)
        x = self.pool(x)
        x = torch.flatten(x, 1)
        raw = torch.sigmoid(self.regressor(self.dropout(x)))
        x1y1 = torch.minimum(raw[:, 0:2], raw[:, 2:4])
        x2y2 = torch.maximum(raw[:, 0:2], raw[:, 2:4])
        return torch.cat([x1y1, x2y2], dim=1)


def _circle_head_output(raw: torch.Tensor, min_radius: float) -> torch.Tensor:
    """Map raw sigmoid outputs to ``[cx, cy, r]`` with ``r`` in ``[min_radius, 1]``."""

    center = raw[:, 0:2]
    radius = min_radius + (1.0 - min_radius) * raw[:, 2:3]
    return torch.cat([center, radius], dim=1)


class LightweightCircleRegressor(nn.Module):
    """Lightweight regressor returning normalized ``[center_x, center_y, radius]``."""

    def __init__(
        self,
        input_size: int | tuple[int, int],
        dropout: float = 0.2,
        base_channels: int = 24,
        min_radius: float = 0.01,
    ) -> None:
        super().__init__()
        self.input_size = _as_hw(input_size)
        self.min_radius = float(min_radius)
        self.backbone = _LightweightBackbone(
            input_size=input_size, base_channels=base_channels
        )
        self.head = nn.Sequential(
            nn.Dropout(p=dropout),
            nn.Linear(self.backbone.out_channels, _make_divisible(base_channels * 4)),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout),
            nn.Linear(_make_divisible(base_channels * 4), 3),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        raw = torch.sigmoid(self.head(self.backbone(x)))
        return _circle_head_output(raw, self.min_radius)


class LegacyCircleRegressor(nn.Module):
    """Circle regressor reusing the legacy bbox backbone with a 3-value head.

    Output is a normalized ``[center_x, center_y, radius]`` triple. ``center_x``
    and ``center_y`` live in ``[0, 1]``; ``radius`` is clamped to
    ``[min_radius, 1]`` so it never collapses to zero.
    """

    def __init__(
        self,
        input_size: int | tuple[int, int] = 64,
        base_channels: int = 32,
        dropout: float = 0.0,
        min_radius: float = 0.01,
    ) -> None:
        super().__init__()
        self.input_size = _as_hw(input_size)
        self.min_radius = float(min_radius)
        c1 = _make_divisible(base_channels)
        c2 = _make_divisible(base_channels * 2)
        c3 = _make_divisible(base_channels * 4)
        c4 = _make_divisible(base_channels * 8)

        self.conv1 = LegacyDSConv(3, c1, stride=2, activation="relu")
        self.conv2 = LegacyDSConv(c1, c2, stride=2, activation="relu")
        self.conv3 = LegacyDSConv(c2, c3, stride=2, activation="relu")
        self.attention_c3 = nn.Sequential(LegacyColorAttention(c3), LegacySpatialAttention())
        self.conv4 = LegacyDSConv(c3, c3, stride=1, activation="silu")
        self.conv5 = LegacyDSConv(c3, c4, stride=1, activation="silu")
        self.attention_c4 = nn.Sequential(LegacyColorAttention(c4), LegacySpatialAttention())
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.dropout = nn.Dropout(p=dropout) if dropout > 0 else nn.Identity()
        self.regressor = nn.Linear(c4, 3)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.attention_c3(x)
        x = self.conv4(x)
        x = self.conv5(x)
        x = self.attention_c4(x)
        x = self.pool(x)
        x = torch.flatten(x, 1)
        raw = torch.sigmoid(self.regressor(self.dropout(x)))
        return _circle_head_output(raw, self.min_radius)


def _ellipse_head_output(raw: torch.Tensor, min_radius: float) -> torch.Tensor:
    """Map 7 raw outputs to ``[cx, cy, major, minor, sin, cos, ratio]``.

    ``cx, cy`` and ``ratio`` are sigmoid-bounded to ``[0, 1]``; the radii are
    bounded to ``[min_radius, 1]``; ``sin, cos`` are ``tanh``-bounded to
    ``[-1, 1]`` and are normalized to unit norm downstream.
    """

    center = torch.sigmoid(raw[:, 0:2])
    major = min_radius + (1.0 - min_radius) * torch.sigmoid(raw[:, 2:3])
    minor = min_radius + (1.0 - min_radius) * torch.sigmoid(raw[:, 3:4])
    sin_cos = torch.tanh(raw[:, 4:6])
    ratio = torch.sigmoid(raw[:, 6:7])
    return torch.cat([center, major, minor, sin_cos, ratio], dim=1)


class LightweightEllipseRegressor(nn.Module):
    """Lightweight regressor returning a 7-value normalized ellipse."""

    def __init__(
        self,
        input_size: int | tuple[int, int],
        dropout: float = 0.2,
        base_channels: int = 24,
        min_radius: float = 0.01,
    ) -> None:
        super().__init__()
        self.input_size = _as_hw(input_size)
        self.min_radius = float(min_radius)
        self.backbone = _LightweightBackbone(
            input_size=input_size, base_channels=base_channels
        )
        self.head = nn.Sequential(
            nn.Dropout(p=dropout),
            nn.Linear(self.backbone.out_channels, _make_divisible(base_channels * 4)),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout),
            nn.Linear(_make_divisible(base_channels * 4), 7),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return _ellipse_head_output(self.head(self.backbone(x)), self.min_radius)


class LegacyEllipseRegressor(nn.Module):
    """Ellipse regressor reusing the legacy bbox backbone with a 7-value head.

    Output is ``[center_x, center_y, radius_major, radius_minor, angle_sin,
    angle_cos, perspective_ratio]``.
    """

    def __init__(
        self,
        input_size: int | tuple[int, int] = 64,
        base_channels: int = 32,
        dropout: float = 0.0,
        min_radius: float = 0.01,
    ) -> None:
        super().__init__()
        self.input_size = _as_hw(input_size)
        self.min_radius = float(min_radius)
        c1 = _make_divisible(base_channels)
        c2 = _make_divisible(base_channels * 2)
        c3 = _make_divisible(base_channels * 4)
        c4 = _make_divisible(base_channels * 8)

        self.conv1 = LegacyDSConv(3, c1, stride=2, activation="relu")
        self.conv2 = LegacyDSConv(c1, c2, stride=2, activation="relu")
        self.conv3 = LegacyDSConv(c2, c3, stride=2, activation="relu")
        self.attention_c3 = nn.Sequential(LegacyColorAttention(c3), LegacySpatialAttention())
        self.conv4 = LegacyDSConv(c3, c3, stride=1, activation="silu")
        self.conv5 = LegacyDSConv(c3, c4, stride=1, activation="silu")
        self.attention_c4 = nn.Sequential(LegacyColorAttention(c4), LegacySpatialAttention())
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.dropout = nn.Dropout(p=dropout) if dropout > 0 else nn.Identity()
        self.regressor = nn.Linear(c4, 7)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.attention_c3(x)
        x = self.conv4(x)
        x = self.conv5(x)
        x = self.attention_c4(x)
        x = self.pool(x)
        x = torch.flatten(x, 1)
        return _ellipse_head_output(self.regressor(self.dropout(x)), self.min_radius)


class ForegroundBBoxRegressor(nn.Module):
    """Deterministic bbox extractor for synthetic sign images.

    The module is exported as ONNX and returns the normalized bbox of pixels that
    differ strongly from the border background color.
    """

    def __init__(
        self,
        input_size: int | tuple[int, int],
        threshold: float = 0.7,
        ignore_margin: float = 0.1,
        border: int = 2,
        score_mode: str = "l2",
        mean: Sequence[float] = (0.485, 0.456, 0.406),
        std: Sequence[float] = (0.229, 0.224, 0.225),
    ) -> None:
        super().__init__()
        height, width = _as_hw(input_size)
        self.input_size = (height, width)
        self.threshold = float(threshold)
        self.ignore_margin = float(ignore_margin)
        self.border = max(1, int(border))
        self.score_mode = score_mode

        self.register_buffer(
            "mean",
            torch.tensor(mean, dtype=torch.float32).view(1, 3, 1, 1),
            persistent=False,
        )
        self.register_buffer(
            "std",
            torch.tensor(std, dtype=torch.float32).view(1, 3, 1, 1),
            persistent=False,
        )
        x_left = torch.arange(width, dtype=torch.float32).view(1, 1, width) / float(width)
        x_right = (torch.arange(width, dtype=torch.float32).view(1, 1, width) + 1.0) / float(width)
        y_top = torch.arange(height, dtype=torch.float32).view(1, height, 1) / float(height)
        y_bottom = (torch.arange(height, dtype=torch.float32).view(1, height, 1) + 1.0) / float(height)
        self.register_buffer("x_left", x_left.expand(1, height, width), persistent=False)
        self.register_buffer("x_right", x_right.expand(1, height, width), persistent=False)
        self.register_buffer("y_top", y_top.expand(1, height, width), persistent=False)
        self.register_buffer("y_bottom", y_bottom.expand(1, height, width), persistent=False)

        valid_x = (x_left >= self.ignore_margin) & (x_right <= 1.0 - self.ignore_margin)
        valid_y = (y_top >= self.ignore_margin) & (y_bottom <= 1.0 - self.ignore_margin)
        self.register_buffer(
            "valid_mask",
            (valid_x & valid_y).expand(1, height, width),
            persistent=False,
        )
        self.register_buffer(
            "fallback",
            torch.tensor([0.0, 0.0, 1.0, 1.0], dtype=torch.float32).view(1, 4),
            persistent=False,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        image = x * self.std + self.mean
        border = min(self.border, self.input_size[0], self.input_size[1])
        top = image[:, :, :border, :].flatten(2)
        bottom = image[:, :, -border:, :].flatten(2)
        left = image[:, :, :, :border].flatten(2)
        right = image[:, :, :, -border:].flatten(2)
        background = torch.cat([top, bottom, left, right], dim=2).mean(dim=2).view(-1, 3, 1, 1)

        diff = torch.abs(image - background)
        if self.score_mode == "max":
            score = diff.amax(dim=1)
        elif self.score_mode == "l1":
            score = diff.mean(dim=1)
        else:
            score = torch.sqrt(torch.clamp(((image - background) ** 2).sum(dim=1), min=1.0e-12))

        mask = (score > self.threshold) & self.valid_mask
        ones = torch.ones_like(score)
        zeros = torch.zeros_like(score)
        xmin = torch.where(mask, self.x_left, ones).amin(dim=(1, 2))
        ymin = torch.where(mask, self.y_top, ones).amin(dim=(1, 2))
        xmax = torch.where(mask, self.x_right, zeros).amax(dim=(1, 2))
        ymax = torch.where(mask, self.y_bottom, zeros).amax(dim=(1, 2))
        bbox = torch.stack([xmin, ymin, xmax, ymax], dim=1)
        has_foreground = mask.flatten(1).any(dim=1).view(-1, 1)
        return torch.where(has_foreground, bbox, self.fallback.expand_as(bbox))


if __name__ == "__main__":
    x = torch.randn(1, 3, 64, 64)

    cls = LightweightClassifier(num_classes=3, input_size=64)
    bbox = LightweightBBoxRegressor(input_size=64)
    foreground_bbox = ForegroundBBoxRegressor(input_size=64)
    legacy_circle = LegacyCircleRegressor(input_size=64)
    light_circle = LightweightCircleRegressor(input_size=64)

    print("classifier:", cls(x).shape)
    print("bbox:", bbox(x).shape)
    print("foreground_bbox:", foreground_bbox(x).shape)
    print("legacy_circle:", legacy_circle(x).shape)
    print("light_circle:", light_circle(x).shape)
