"""Reusable helpers for the Robocup 2026 perception notebooks."""

