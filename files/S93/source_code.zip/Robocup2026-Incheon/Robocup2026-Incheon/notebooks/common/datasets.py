"""CSV manifest readers and PyTorch datasets for perception training."""

from __future__ import annotations

import csv
import json
import math
import random
from pathlib import Path
from typing import Iterable, Mapping, Sequence

try:
    import numpy as np
    from PIL import Image, ImageEnhance
except ImportError:
    np = None
    Image = None
    ImageEnhance = None

try:
    import torch
    from torch.utils.data import Dataset
except ImportError:
    torch = None

    class Dataset:  # type: ignore[no-redef]
        pass

from .config import DATA_MANIFESTS_DIR, VICTIM_CLASSES, get_dataset_root


DEFAULT_MEAN = (0.485, 0.456, 0.406)
DEFAULT_STD = (0.229, 0.224, 0.225)


def read_manifest(path: str | Path) -> list[dict]:
    """Load a JSONL, JSON, or CSV manifest into a list of dictionaries."""

    manifest_path = Path(path)
    suffix = manifest_path.suffix.lower()
    if suffix == ".jsonl":
        return [json.loads(line) for line in manifest_path.read_text().splitlines() if line.strip()]
    if suffix == ".json":
        data = json.loads(manifest_path.read_text())
        return data if isinstance(data, list) else data.get("items", [])
    if suffix == ".csv":
        return read_csv_manifest(manifest_path)
    raise ValueError(f"Unsupported manifest format: {manifest_path}")


def read_csv_manifest(path: str | Path) -> list[dict[str, str]]:
    with Path(path).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_jsonl_manifest(items: Iterable[dict], path: str | Path) -> Path:
    """Write manifest items as JSONL."""

    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as handle:
        for item in items:
            handle.write(json.dumps(item, sort_keys=True) + "\n")
    return output_path


def split_items(
    items: Sequence[dict],
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    seed: int = 2026,
) -> dict[str, list[dict]]:
    """Create deterministic train/val/test splits from manifest rows."""

    if not 0 < train_ratio < 1 or not 0 <= val_ratio < 1:
        raise ValueError("Ratios must be in the [0, 1] range and train_ratio must be non-zero.")
    shuffled = list(items)
    random.Random(seed).shuffle(shuffled)
    train_end = int(len(shuffled) * train_ratio)
    val_end = train_end + int(len(shuffled) * val_ratio)
    return {
        "train": shuffled[:train_end],
        "val": shuffled[train_end:val_end],
        "test": shuffled[val_end:],
    }


def validate_victim_labels(items: Iterable[dict], label_key: str = "label_name") -> None:
    """Fail if the current victim training stage includes unsupported labels."""

    allowed = set(VICTIM_CLASSES)
    unknown = sorted(
        {
            str(item.get(label_key))
            for item in items
            if item.get(label_key) is not None and item.get(label_key) not in allowed
        }
    )
    if unknown:
        raise ValueError(f"Unsupported victim labels for this stage: {unknown}. Fake is handled later with LiDAR.")


def _as_hw(input_size: int | tuple[int, int]) -> tuple[int, int]:
    if isinstance(input_size, int):
        return input_size, input_size
    if len(input_size) != 2:
        raise ValueError("input_size must be an int or a (height, width) tuple.")
    return int(input_size[0]), int(input_size[1])


def infer_dataset_root(manifest_path: str | Path) -> Path | None:
    """Infer extracted dataset root from data/manifests/<dataset_name>/<file>.csv."""

    path = Path(manifest_path).resolve()
    try:
        relative = path.parent.relative_to(DATA_MANIFESTS_DIR.resolve())
    except ValueError:
        return None
    if not relative.parts:
        return None
    return get_dataset_root(relative.parts[0])


def _resolve_image_path(
    path_value: str,
    split: str,
    manifest_path: Path,
    dataset_root: str | Path | None,
) -> Path:
    image_path = Path(path_value)
    if image_path.is_absolute():
        return image_path
    root = Path(dataset_root) if dataset_root is not None else infer_dataset_root(manifest_path)
    if root is not None:
        return root / split / image_path
    return manifest_path.parent / image_path


def _resolve_crop_path(crop_value: str, manifest_path: Path) -> Path:
    """Resolve a ``crop_path`` value relative to the crop manifest directory."""

    crop_path = Path(crop_value)
    if crop_path.is_absolute():
        return crop_path
    return Path(manifest_path).parent / crop_path


def _jitter_factor(amount: float) -> float:
    if amount <= 0:
        return 1.0
    return 1.0 + random.uniform(-amount, amount)


def _apply_image_augmentation(
    image,
    *,
    rotation_degrees: float = 0.0,
    brightness: float = 0.0,
    contrast: float = 0.0,
    translate: float = 0.0,
):
    if rotation_degrees > 0:
        angle = random.uniform(-rotation_degrees, rotation_degrees)
        fill = image.getpixel((0, 0))
        image = image.rotate(angle, resample=Image.BILINEAR, fillcolor=fill)
    if translate > 0:
        max_dx = int(round(image.size[0] * translate))
        max_dy = int(round(image.size[1] * translate))
        if max_dx > 0 or max_dy > 0:
            dx = random.randint(-max_dx, max_dx) if max_dx else 0
            dy = random.randint(-max_dy, max_dy) if max_dy else 0
            fill = image.getpixel((0, 0))
            shifted = Image.new(image.mode, image.size, fill)
            shifted.paste(image, (dx, dy))
            image = shifted
    if brightness > 0:
        image = ImageEnhance.Brightness(image).enhance(_jitter_factor(brightness))
    if contrast > 0:
        image = ImageEnhance.Contrast(image).enhance(_jitter_factor(contrast))
    return image


def _crop_normalized_bbox(
    image,
    bbox: Sequence[float],
    *,
    padding: float = 0.0,
):
    if len(bbox) != 4:
        return image

    xmin, ymin, xmax, ymax = [float(value) for value in bbox]
    xmin = max(0.0, min(1.0, xmin))
    ymin = max(0.0, min(1.0, ymin))
    xmax = max(0.0, min(1.0, xmax))
    ymax = max(0.0, min(1.0, ymax))
    if xmin >= xmax or ymin >= ymax:
        return image

    pad_x = (xmax - xmin) * max(float(padding), 0.0)
    pad_y = (ymax - ymin) * max(float(padding), 0.0)
    xmin = max(0.0, xmin - pad_x)
    ymin = max(0.0, ymin - pad_y)
    xmax = min(1.0, xmax + pad_x)
    ymax = min(1.0, ymax + pad_y)

    width, height = image.size
    left = max(0, int(xmin * width))
    top = max(0, int(ymin * height))
    right = min(width, max(left + 1, int(xmax * width + 0.9999)))
    bottom = min(height, max(top + 1, int(ymax * height + 0.9999)))
    return image.crop((left, top, right, bottom))


def load_image_tensor(
    image_path: str | Path,
    input_size: int | tuple[int, int],
    mean: Sequence[float] = DEFAULT_MEAN,
    std: Sequence[float] = DEFAULT_STD,
    augment: bool = False,
    augment_degrees: float = 0.0,
    augment_brightness: float = 0.0,
    augment_contrast: float = 0.0,
    augment_translate: float = 0.0,
    crop_box: Sequence[float] | None = None,
    crop_padding: float = 0.0,
) -> torch.Tensor:
    """Load an RGB image, resize it, normalize it, and return a CHW tensor."""

    if torch is None:
        raise RuntimeError("Install torch to use the PyTorch dataset helpers.")
    if np is None or Image is None:
        raise RuntimeError("Install numpy and pillow to load image tensors.")

    height, width = _as_hw(input_size)
    with Image.open(image_path) as image:
        image = image.convert("RGB")
        if crop_box is not None:
            image = _crop_normalized_bbox(image, crop_box, padding=crop_padding)
        if augment:
            image = _apply_image_augmentation(
                image,
                rotation_degrees=augment_degrees,
                brightness=augment_brightness,
                contrast=augment_contrast,
                translate=augment_translate,
            )
        image = image.resize((width, height), Image.BILINEAR)
        array = np.asarray(image, dtype=np.float32) / 255.0

    tensor = torch.from_numpy(array).permute(2, 0, 1)
    mean_tensor = torch.tensor(mean, dtype=torch.float32).view(3, 1, 1)
    std_tensor = torch.tensor(std, dtype=torch.float32).view(3, 1, 1)
    return (tensor - mean_tensor) / std_tensor


class ImageClassificationDataset(Dataset):
    """Dataset for manifests with split,image_path,label,label_name columns."""

    def __init__(
        self,
        manifest_path: str | Path,
        input_size: int | tuple[int, int],
        split: str | None = None,
        mean: Sequence[float] = DEFAULT_MEAN,
        std: Sequence[float] = DEFAULT_STD,
        dataset_root: str | Path | None = None,
        image_root: str | Path | None = None,
        augment: bool = False,
        augment_degrees: float = 0.0,
        augment_brightness: float = 0.0,
        augment_contrast: float = 0.0,
        augment_translate: float = 0.0,
        crop_boxes: Mapping[tuple[str, str], Sequence[float]] | None = None,
        crop_padding: float = 0.0,
        crop_path_column: str | None = None,
    ) -> None:
        if torch is None:
            raise RuntimeError("Install torch to use ImageClassificationDataset.")
        self.manifest_path = Path(manifest_path)
        self.input_size = input_size
        self.mean = mean
        self.std = std
        self.augment = augment
        self.augment_degrees = augment_degrees
        self.augment_brightness = augment_brightness
        self.augment_contrast = augment_contrast
        self.augment_translate = augment_translate
        self.crop_boxes = dict(crop_boxes or {})
        self.crop_padding = float(crop_padding)
        self.crop_path_column = crop_path_column
        self.dataset_root = dataset_root if dataset_root is not None else image_root
        rows = read_csv_manifest(self.manifest_path)
        self.rows = [row for row in rows if split is None or row.get("split") == split]
        if crop_path_column is not None:
            # Predicted-crop manifest: load the materialized crop directly. The
            # original ``image_path`` is preserved on each row for traceability.
            missing = [
                row for row in self.rows if not str(row.get(crop_path_column, "")).strip()
            ]
            if missing:
                raise ValueError(
                    f"{len(missing)}/{len(self.rows)} rows in {self.manifest_path} are missing "
                    f"a '{crop_path_column}' value; cannot load predicted crops."
                )
            self.image_paths = [
                _resolve_crop_path(row[crop_path_column], self.manifest_path)
                for row in self.rows
            ]
        else:
            self.image_paths = [
                _resolve_image_path(row["image_path"], row["split"], self.manifest_path, self.dataset_root)
                for row in self.rows
            ]

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, index: int) -> tuple[torch.Tensor, int]:
        row = self.rows[index]
        image = load_image_tensor(
            self.image_paths[index],
            self.input_size,
            self.mean,
            self.std,
            augment=self.augment,
            augment_degrees=self.augment_degrees,
            augment_brightness=self.augment_brightness,
            augment_contrast=self.augment_contrast,
            augment_translate=self.augment_translate,
            crop_box=self.crop_boxes.get((row.get("split", ""), row.get("image_path", ""))),
            crop_padding=self.crop_padding,
        )
        label = int(row["label"])
        return image, label


class BBoxRegressionDataset(Dataset):
    """Dataset for manifests with normalized bbox columns."""

    def __init__(
        self,
        manifest_path: str | Path,
        input_size: int | tuple[int, int],
        split: str | None = None,
        mean: Sequence[float] = DEFAULT_MEAN,
        std: Sequence[float] = DEFAULT_STD,
        dataset_root: str | Path | None = None,
        image_root: str | Path | None = None,
        augment: bool = False,
        augment_brightness: float = 0.0,
        augment_contrast: float = 0.0,
        horizontal_flip_p: float = 0.0,
        vertical_flip_p: float = 0.0,
    ) -> None:
        if torch is None:
            raise RuntimeError("Install torch to use BBoxRegressionDataset.")
        self.manifest_path = Path(manifest_path)
        self.input_size = input_size
        self.mean = mean
        self.std = std
        self.augment = bool(augment)
        self.augment_brightness = float(augment_brightness)
        self.augment_contrast = float(augment_contrast)
        self.horizontal_flip_p = float(horizontal_flip_p)
        self.vertical_flip_p = float(vertical_flip_p)
        self.dataset_root = dataset_root if dataset_root is not None else image_root
        rows = read_csv_manifest(self.manifest_path)
        self.rows = [row for row in rows if split is None or row.get("split") == split]
        self.image_paths = [
            _resolve_image_path(row["image_path"], row["split"], self.manifest_path, self.dataset_root)
            for row in self.rows
        ]

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, index: int) -> tuple[torch.Tensor, torch.Tensor]:
        row = self.rows[index]
        bbox = torch.tensor(
            [float(row[name]) for name in ("xmin", "ymin", "xmax", "ymax")],
            dtype=torch.float32,
        )
        if torch.any(bbox < 0) or torch.any(bbox > 1):
            raise ValueError(f"BBox values must be normalized to [0, 1]: {bbox.tolist()}")
        if bbox[0] >= bbox[2] or bbox[1] >= bbox[3]:
            raise ValueError(f"BBox coordinate order is invalid: {bbox.tolist()}")

        if not self.augment:
            image = load_image_tensor(self.image_paths[index], self.input_size, self.mean, self.std)
            return image, bbox

        if np is None or Image is None:
            raise RuntimeError("Install numpy and pillow to load image tensors.")

        height, width = _as_hw(self.input_size)
        with Image.open(self.image_paths[index]) as image_obj:
            image_obj = image_obj.convert("RGB")
            if self.horizontal_flip_p > 0 and random.random() < self.horizontal_flip_p:
                image_obj = image_obj.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
                xmin, ymin, xmax, ymax = bbox.tolist()
                bbox = torch.tensor([1.0 - xmax, ymin, 1.0 - xmin, ymax], dtype=torch.float32)
            if self.vertical_flip_p > 0 and random.random() < self.vertical_flip_p:
                image_obj = image_obj.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
                xmin, ymin, xmax, ymax = bbox.tolist()
                bbox = torch.tensor([xmin, 1.0 - ymax, xmax, 1.0 - ymin], dtype=torch.float32)
            if self.augment_brightness > 0:
                image_obj = ImageEnhance.Brightness(image_obj).enhance(_jitter_factor(self.augment_brightness))
            if self.augment_contrast > 0:
                image_obj = ImageEnhance.Contrast(image_obj).enhance(_jitter_factor(self.augment_contrast))
            image_obj = image_obj.resize((width, height), Image.BILINEAR)
            array = np.asarray(image_obj, dtype=np.float32) / 255.0

        image = torch.from_numpy(array).permute(2, 0, 1)
        mean_tensor = torch.tensor(self.mean, dtype=torch.float32).view(3, 1, 1)
        std_tensor = torch.tensor(self.std, dtype=torch.float32).view(3, 1, 1)
        image = (image - mean_tensor) / std_tensor
        return image, bbox


# Supported circle/center-radius column schemas, in priority order.
CIRCLE_COLUMN_SCHEMAS: tuple[tuple[str, str, str], ...] = (
    ("center_x", "center_y", "radius"),
    ("cx", "cy", "r"),
)
BBOX_COLUMNS = ("xmin", "ymin", "xmax", "ymax")


def detect_circle_schema(columns) -> tuple[str, ...] | None:
    """Return the circle column schema present in ``columns`` or ``None``.

    Detects ``(center_x, center_y, radius)``, ``(cx, cy, r)`` or a bbox
    ``(xmin, ymin, xmax, ymax)`` that can be converted to a circle.
    """

    present = set(columns)
    for schema in CIRCLE_COLUMN_SCHEMAS:
        if set(schema) <= present:
            return schema
    if set(BBOX_COLUMNS) <= present:
        return BBOX_COLUMNS
    return None


def circle_from_row(row: Mapping[str, str], schema: tuple[str, ...]) -> tuple[float, float, float]:
    """Extract a normalized ``(cx, cy, r)`` triple from a manifest row.

    When ``schema`` is a bbox, the circle is the one whose center is the bbox
    center and whose radius is the average half-width/half-height of the box.
    """

    if schema == BBOX_COLUMNS:
        xmin, ymin, xmax, ymax = (float(row[name]) for name in BBOX_COLUMNS)
        cx = (xmin + xmax) / 2.0
        cy = (ymin + ymax) / 2.0
        radius = ((xmax - xmin) + (ymax - ymin)) / 4.0
        return cx, cy, radius
    cx = float(row[schema[0]])
    cy = float(row[schema[1]])
    radius = float(row[schema[2]])
    return cx, cy, radius


class CircleRegressionDataset(Dataset):
    """Dataset returning ``(image, [cx, cy, r])`` for target circle localization.

    The manifest may provide ``center_x,center_y,radius``, ``cx,cy,r`` or a
    normalized bbox (``xmin,ymin,xmax,ymax``) that is converted to a circle.
    All values are expected to be normalized to ``[0, 1]``.
    """

    def __init__(
        self,
        manifest_path: str | Path,
        input_size: int | tuple[int, int],
        split: str | None = None,
        mean: Sequence[float] = DEFAULT_MEAN,
        std: Sequence[float] = DEFAULT_STD,
        dataset_root: str | Path | None = None,
        image_root: str | Path | None = None,
        augment: bool = False,
        augment_brightness: float = 0.0,
        augment_contrast: float = 0.0,
        horizontal_flip_p: float = 0.0,
        vertical_flip_p: float = 0.0,
    ) -> None:
        if torch is None:
            raise RuntimeError("Install torch to use CircleRegressionDataset.")
        self.manifest_path = Path(manifest_path)
        self.input_size = input_size
        self.mean = mean
        self.std = std
        self.augment = bool(augment)
        self.augment_brightness = float(augment_brightness)
        self.augment_contrast = float(augment_contrast)
        self.horizontal_flip_p = float(horizontal_flip_p)
        self.vertical_flip_p = float(vertical_flip_p)
        self.dataset_root = dataset_root if dataset_root is not None else image_root
        rows = read_csv_manifest(self.manifest_path)
        self.rows = [row for row in rows if split is None or row.get("split") == split]
        if rows:
            schema = detect_circle_schema(rows[0].keys())
            if schema is None:
                raise ValueError(
                    "Circle manifest must contain one of "
                    f"{[list(s) for s in CIRCLE_COLUMN_SCHEMAS]} or bbox columns "
                    f"{list(BBOX_COLUMNS)}; got {sorted(rows[0].keys())}."
                )
            self.schema = schema
        else:
            self.schema = CIRCLE_COLUMN_SCHEMAS[0]
        self.image_paths = [
            _resolve_image_path(row["image_path"], row["split"], self.manifest_path, self.dataset_root)
            for row in self.rows
        ]

    def __len__(self) -> int:
        return len(self.rows)

    def _circle_tensor(self, row: Mapping[str, str]) -> "torch.Tensor":
        cx, cy, radius = circle_from_row(row, self.schema)
        circle = torch.tensor([cx, cy, radius], dtype=torch.float32)
        if torch.any(circle[:2] < 0) or torch.any(circle[:2] > 1):
            raise ValueError(f"Circle center must be normalized to [0, 1]: {circle.tolist()}")
        if circle[2] <= 0:
            raise ValueError(f"Circle radius must be > 0: {circle.tolist()}")
        return circle

    def __getitem__(self, index: int) -> tuple["torch.Tensor", "torch.Tensor"]:
        row = self.rows[index]
        circle = self._circle_tensor(row)

        if not self.augment:
            image = load_image_tensor(self.image_paths[index], self.input_size, self.mean, self.std)
            return image, circle

        if np is None or Image is None:
            raise RuntimeError("Install numpy and pillow to load image tensors.")

        height, width = _as_hw(self.input_size)
        with Image.open(self.image_paths[index]) as image_obj:
            image_obj = image_obj.convert("RGB")
            cx, cy, radius = circle.tolist()
            if self.horizontal_flip_p > 0 and random.random() < self.horizontal_flip_p:
                image_obj = image_obj.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
                cx = 1.0 - cx
            if self.vertical_flip_p > 0 and random.random() < self.vertical_flip_p:
                image_obj = image_obj.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
                cy = 1.0 - cy
            circle = torch.tensor([cx, cy, radius], dtype=torch.float32)
            if self.augment_brightness > 0:
                image_obj = ImageEnhance.Brightness(image_obj).enhance(_jitter_factor(self.augment_brightness))
            if self.augment_contrast > 0:
                image_obj = ImageEnhance.Contrast(image_obj).enhance(_jitter_factor(self.augment_contrast))
            image_obj = image_obj.resize((width, height), Image.BILINEAR)
            array = np.asarray(image_obj, dtype=np.float32) / 255.0

        image = torch.from_numpy(array).permute(2, 0, 1)
        mean_tensor = torch.tensor(self.mean, dtype=torch.float32).view(3, 1, 1)
        std_tensor = torch.tensor(self.std, dtype=torch.float32).view(3, 1, 1)
        image = (image - mean_tensor) / std_tensor
        return image, circle


# --------------------------------------------------------------------------- #
# Ellipse / perspective target localization.
# --------------------------------------------------------------------------- #

# Ellipse output schema (7 values): center, axes, orientation (sin/cos), ratio.
ELLIPSE_OUTPUT_KEYS = (
    "cx", "cy", "radius_major", "radius_minor", "angle_sin", "angle_cos", "perspective_ratio",
)
ELLIPSE_OUTPUT_DIM = len(ELLIPSE_OUTPUT_KEYS)

# Pixel-space ellipse column schemas, in priority order. The mask schema is
# measured directly on the rendered mask and is preferred; the projection schema
# is the geometric fallback.
ELLIPSE_MASK_SCHEMA = (
    "mask_cx", "mask_cy", "mask_radius_major_px", "mask_radius_minor_px", "mask_angle_deg",
)
ELLIPSE_PROJECTION_SCHEMA = (
    "ellipse_cx", "ellipse_cy", "radius_major_px", "radius_minor_px", "ellipse_angle_deg",
)


def detect_ellipse_schema(columns) -> tuple[str, ...] | None:
    """Return the ellipse column schema present in ``columns``.

    Detects the pixel-space ``mask_*`` schema (preferred), the ``ellipse_*``
    projection schema, or a legacy circle/bbox schema (converted to a circle).
    """

    present = set(columns)
    if set(ELLIPSE_MASK_SCHEMA) <= present:
        return ELLIPSE_MASK_SCHEMA
    if set(ELLIPSE_PROJECTION_SCHEMA) <= present:
        return ELLIPSE_PROJECTION_SCHEMA
    return detect_circle_schema(columns)


def _mask_visible_ok(row: Mapping[str, str], min_visible: float) -> bool:
    try:
        return float(row.get("mask_visible_px", "inf")) >= min_visible
    except (TypeError, ValueError):
        return True


def ellipse_from_row(
    row: Mapping[str, str],
    schema: tuple[str, ...],
    width: float,
    height: float,
    *,
    min_radius: float = 1e-4,
) -> tuple[float, float, float, float, float, float, float]:
    """Extract a normalized ellipse ``(cx, cy, major, minor, sin, cos, ratio)``.

    ``mask_*``/``ellipse_*`` schemas are in pixel space and are normalized by
    ``width``/``height``. A legacy circle/bbox schema is read as a circle
    (major == minor, angle 0, ratio 1).
    """

    if schema in (CIRCLE_COLUMN_SCHEMAS[0], CIRCLE_COLUMN_SCHEMAS[1], BBOX_COLUMNS):
        cx, cy, radius = circle_from_row(row, schema)
        radius = max(min_radius, float(radius))
        return cx, cy, radius, radius, 0.0, 1.0, 1.0

    cx_px = float(row[schema[0]])
    cy_px = float(row[schema[1]])
    major_px = float(row[schema[2]])
    minor_px = float(row[schema[3]])
    angle_deg = float(row[schema[4]])

    cx = cx_px / width
    cy = cy_px / height
    major = max(min_radius, major_px / width)
    minor = max(min_radius, minor_px / height)
    # Enforce major >= minor; rotate orientation by 90 deg if axes are swapped.
    if minor > major:
        major, minor = minor, major
        angle_deg += 90.0
    angle_rad = math.radians(angle_deg)
    perspective = minor_px / major_px if major_px > 0 else 1.0
    perspective = max(0.0, min(1.0, perspective))
    return cx, cy, major, minor, math.sin(angle_rad), math.cos(angle_rad), perspective


class EllipseRegressionDataset(Dataset):
    """Dataset returning ``(image, ellipse[7])`` for target ellipse localization.

    The 7-vector is ``[cx, cy, radius_major, radius_minor, angle_sin, angle_cos,
    perspective_ratio]``, all normalized. The manifest may provide the pixel-space
    ``mask_*``/``ellipse_*`` columns or a legacy circle/bbox schema.
    """

    def __init__(
        self,
        manifest_path: str | Path,
        input_size: int | tuple[int, int],
        split: str | None = None,
        mean: Sequence[float] = DEFAULT_MEAN,
        std: Sequence[float] = DEFAULT_STD,
        dataset_root: str | Path | None = None,
        image_root: str | Path | None = None,
        augment: bool = False,
        augment_brightness: float = 0.0,
        augment_contrast: float = 0.0,
        horizontal_flip_p: float = 0.0,
        vertical_flip_p: float = 0.0,
        min_mask_visible_px: float = 0.0,
    ) -> None:
        if torch is None:
            raise RuntimeError("Install torch to use EllipseRegressionDataset.")
        self.manifest_path = Path(manifest_path)
        self.input_size = input_size
        self.mean = mean
        self.std = std
        self.augment = bool(augment)
        self.augment_brightness = float(augment_brightness)
        self.augment_contrast = float(augment_contrast)
        self.horizontal_flip_p = float(horizontal_flip_p)
        self.vertical_flip_p = float(vertical_flip_p)
        self.min_mask_visible_px = float(min_mask_visible_px)
        self.dataset_root = dataset_root if dataset_root is not None else image_root
        rows = read_csv_manifest(self.manifest_path)
        self.rows = [row for row in rows if split is None or row.get("split") == split]
        if rows:
            schema = detect_ellipse_schema(rows[0].keys())
            if schema is None:
                raise ValueError(
                    "Ellipse manifest must contain one of the mask schema "
                    f"{list(ELLIPSE_MASK_SCHEMA)}, projection schema "
                    f"{list(ELLIPSE_PROJECTION_SCHEMA)} or a legacy circle/bbox "
                    f"schema; got {sorted(rows[0].keys())}."
                )
            self.schema = schema
        else:
            self.schema = ELLIPSE_MASK_SCHEMA
        self.image_paths = [
            _resolve_image_path(row["image_path"], row["split"], self.manifest_path, self.dataset_root)
            for row in self.rows
        ]

    def __len__(self) -> int:
        return len(self.rows)

    def _ellipse_values(self, row: Mapping[str, str], width: float, height: float):
        values = ellipse_from_row(row, self.schema, width, height)
        cx, cy, major, minor, sin_a, cos_a, ratio = values
        if not (0.0 <= cx <= 1.0) or not (0.0 <= cy <= 1.0):
            raise ValueError(f"Ellipse center must be normalized to [0, 1]: {values}")
        if major <= 0 or minor <= 0:
            raise ValueError(f"Ellipse radii must be > 0: {values}")
        if not (0.0 <= ratio <= 1.0):
            raise ValueError(f"perspective_ratio must be in [0, 1]: {values}")
        if not (math.isfinite(sin_a) and math.isfinite(cos_a)):
            raise ValueError(f"angle sin/cos must be finite: {values}")
        return values

    def __getitem__(self, index: int):
        row = self.rows[index]
        if np is None or Image is None:
            raise RuntimeError("Install numpy and pillow to load image tensors.")
        height, width = _as_hw(self.input_size)
        with Image.open(self.image_paths[index]) as image_obj:
            image_obj = image_obj.convert("RGB")
            orig_w, orig_h = image_obj.size
            cx, cy, major, minor, sin_a, cos_a, ratio = self._ellipse_values(
                row, float(orig_w), float(orig_h)
            )
            if self.augment:
                if self.horizontal_flip_p > 0 and random.random() < self.horizontal_flip_p:
                    image_obj = image_obj.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
                    cx = 1.0 - cx
                    cos_a = -cos_a  # reflect orientation across the vertical axis
                if self.vertical_flip_p > 0 and random.random() < self.vertical_flip_p:
                    image_obj = image_obj.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
                    cy = 1.0 - cy
                    sin_a = -sin_a  # reflect orientation across the horizontal axis
                if self.augment_brightness > 0:
                    image_obj = ImageEnhance.Brightness(image_obj).enhance(_jitter_factor(self.augment_brightness))
                if self.augment_contrast > 0:
                    image_obj = ImageEnhance.Contrast(image_obj).enhance(_jitter_factor(self.augment_contrast))
            image_obj = image_obj.resize((width, height), Image.BILINEAR)
            array = np.asarray(image_obj, dtype=np.float32) / 255.0

        ellipse = torch.tensor([cx, cy, major, minor, sin_a, cos_a, ratio], dtype=torch.float32)
        image = torch.from_numpy(array).permute(2, 0, 1)
        mean_tensor = torch.tensor(self.mean, dtype=torch.float32).view(3, 1, 1)
        std_tensor = torch.tensor(self.std, dtype=torch.float32).view(3, 1, 1)
        image = (image - mean_tensor) / std_tensor
        return image, ellipse
