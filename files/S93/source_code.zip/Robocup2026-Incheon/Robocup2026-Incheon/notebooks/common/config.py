"""Shared paths and pipeline constants for the perception notebooks."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


NOTEBOOKS_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = NOTEBOOKS_DIR / "data"

DATA_TARS_DIR = DATA_DIR / "tars"
DATA_EXTRACTED_DIR = DATA_DIR / "extracted"
DATA_MANIFESTS_DIR = DATA_DIR / "manifests"

PROJECT_ROOT = NOTEBOOKS_DIR.parent
MODELS_DIR = PROJECT_ROOT / "models"
REPORTS_DIR = PROJECT_ROOT / "reports"

# Backward-compatible aliases for older notebooks/scripts.
NOTEBOOKS_ROOT = NOTEBOOKS_DIR
RAW_DATA_DIR = DATA_EXTRACTED_DIR
MANIFESTS_DIR = DATA_MANIFESTS_DIR

PRESENCE_CLASSES = ("none", "object")
OBJECT_TYPE_CLASSES = ("target", "victim")
VICTIM_CLASSES = ("harmed", "unharmed", "stable")

ONNX_MODELS = {
    "presence": "presence.onnx",
    "object_type": "object_type.onnx",
    "victim_bbox": "victim_bbox.onnx",
    "victim_cls": "victim_cls.onnx",
}


@dataclass(frozen=True)
class ModelArtifact:
    """Expected output produced by a training notebook."""

    key: str
    filename: str
    classes: tuple[str, ...] | None = None
    task: str = "classification"
    model_dir_name: str | None = None

    @property
    def path(self) -> Path:
        return get_model_dir(self.model_dir_name or self.key) / self.filename


ARTIFACTS = {
    "presence": ModelArtifact("presence", ONNX_MODELS["presence"], PRESENCE_CLASSES),
    "object_type": ModelArtifact("object_type", ONNX_MODELS["object_type"], OBJECT_TYPE_CLASSES),
    "victim_bbox": ModelArtifact("victim_bbox", ONNX_MODELS["victim_bbox"], task="bbox", model_dir_name="victim"),
    "victim_cls": ModelArtifact("victim_cls", ONNX_MODELS["victim_cls"], VICTIM_CLASSES, model_dir_name="victim"),
}


def get_dataset_root(dataset_name: str) -> Path:
    """Return the extracted dataset root for a dataset name."""

    if not dataset_name:
        raise ValueError("dataset_name must be a non-empty string.")
    return DATA_EXTRACTED_DIR / dataset_name


def get_manifest_root(dataset_name: str) -> Path:
    """Return the generated manifest directory for a dataset name."""

    if not dataset_name:
        raise ValueError("dataset_name must be a non-empty string.")
    return DATA_MANIFESTS_DIR / dataset_name


def get_model_dir(model_name: str) -> Path:
    """Return the model artifact directory for a model or branch name."""

    if not model_name:
        raise ValueError("model_name must be a non-empty string.")
    return MODELS_DIR / model_name


def get_report_dir(report_name: str) -> Path:
    """Return the report artifact directory for an experiment name."""

    if not report_name:
        raise ValueError("report_name must be a non-empty string.")
    return REPORTS_DIR / report_name


def ensure_notebook_dirs() -> None:
    """Create local output folders used by notebooks."""

    for path in (DATA_TARS_DIR, DATA_EXTRACTED_DIR, DATA_MANIFESTS_DIR, MODELS_DIR, REPORTS_DIR):
        path.mkdir(parents=True, exist_ok=True)
