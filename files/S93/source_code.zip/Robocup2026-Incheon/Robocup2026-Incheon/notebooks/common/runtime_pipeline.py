"""Testable Python prototype of the Robocup 2026 perception runtime pipeline.

Two layers live here:

* :class:`PerceptionPipeline` -- the original ONNX-session-driven prototype kept
  for backward compatibility (used by existing smoke tests).
* :func:`run_perception_pipeline` / :class:`PerceptionRuntime` -- the modern,
  registry-backed runtime that resolves every model via
  :mod:`notebooks.common.model_registry`, runs
  ``presence -> object_type -> localization -> crop -> classification`` and uses
  **predicted crops** (the same crops classification was trained on). The target
  branch uses the trainable target-localization model, not the legacy
  ``target_cv`` decoder.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


PRESENCE_LABELS = ("none", "object")
OBJECT_TYPE_LABELS = ("target", "victim")
VICTIM_LABELS = ("harmed", "unharmed", "stable", "none", "fake")


@dataclass(frozen=True)
class SessionOutput:
    values: "np.ndarray"


def _require_numpy():
    try:
        import numpy as np
    except ImportError as exc:
        raise RuntimeError("Install numpy to use the runtime pipeline prototype.") from exc
    return np


def _session_input_name(session) -> str:
    if hasattr(session, "get_inputs"):
        inputs = session.get_inputs()
        if inputs:
            return inputs[0].name
    return "input"


def _session_input_size(session, fallback: int | None = None) -> tuple[int, int] | None:
    if hasattr(session, "get_inputs"):
        shape = session.get_inputs()[0].shape
        if len(shape) == 4 and isinstance(shape[2], int) and isinstance(shape[3], int):
            return int(shape[2]), int(shape[3])
    if fallback is not None:
        return fallback, fallback
    return None


def _resize_image(image: np.ndarray, size: tuple[int, int]) -> np.ndarray:
    np = _require_numpy()
    height, width = size
    if image.shape[0] == height and image.shape[1] == width:
        return image
    try:
        from PIL import Image

        return np.asarray(Image.fromarray(image).resize((width, height), Image.BILINEAR))
    except ImportError:
        try:
            import cv2

            return cv2.resize(image, (width, height), interpolation=cv2.INTER_LINEAR)
        except ImportError as exc:
            raise RuntimeError("Install pillow or opencv-python to resize frames for ONNX sessions.") from exc


def _prepare_input(frame: np.ndarray, session) -> np.ndarray:
    np = _require_numpy()
    image = np.asarray(frame)
    if image.ndim != 3:
        raise ValueError(f"Expected an HWC image frame, got shape {image.shape}.")
    if image.shape[2] > 3:
        image = image[:, :, :3]
    input_size = _session_input_size(session)
    if input_size is not None:
        image = _resize_image(image, input_size)
    tensor = image.astype(np.float32) / 255.0
    tensor = np.transpose(tensor, (2, 0, 1))[None, ...]
    return tensor


def _run_session(session, frame: np.ndarray) -> np.ndarray:
    input_tensor = _prepare_input(frame, session)
    if hasattr(session, "run"):
        outputs = session.run(None, {_session_input_name(session): input_tensor})
    elif callable(session):
        outputs = session(input_tensor)
    else:
        raise TypeError("Session must be an ONNXRuntime-like object or callable.")
    if isinstance(outputs, SessionOutput):
        return outputs.values
    if isinstance(outputs, (tuple, list)):
        return np.asarray(outputs[0])
    return np.asarray(outputs)


def _argmax_label(values: np.ndarray, labels: tuple[str, ...]) -> tuple[str, int, list[float]]:
    np = _require_numpy()
    logits = np.asarray(values)
    if logits.ndim == 1:
        logits = logits[None, :]
    index = int(np.argmax(logits[0]))
    return labels[index], index, logits[0].astype(float).tolist()


def _crop_normalized_bbox(frame: np.ndarray, bbox: list[float]) -> np.ndarray:
    np = _require_numpy()
    height, width = frame.shape[:2]
    xmin, ymin, xmax, ymax = np.clip(np.asarray(bbox, dtype=float), 0.0, 1.0)
    x0 = int(round(xmin * width))
    y0 = int(round(ymin * height))
    x1 = int(round(xmax * width))
    y1 = int(round(ymax * height))
    x0, x1 = sorted((max(0, x0), min(width, x1)))
    y0, y1 = sorted((max(0, y0), min(height, y1)))
    if x1 <= x0 or y1 <= y0:
        return frame
    return frame[y0:y1, x0:x1]


def _target_decode(target_decoder, frame: np.ndarray) -> dict:
    if hasattr(target_decoder, "decode"):
        return target_decoder.decode(frame)
    if hasattr(target_decoder, "decode_target_sequence"):
        return target_decoder.decode_target_sequence(frame)
    if callable(target_decoder):
        return target_decoder(frame)
    raise TypeError("target_decoder must expose decode(frame) or be callable.")


def _distance_is_valid(distance_checker, branch: str, payload: dict, robot_state: Any) -> bool:
    if distance_checker is None:
        return True
    candidates = (
        f"is_valid_{branch}",
        f"valid_{branch}_distance",
        "is_valid",
        "check",
    )
    for name in candidates:
        method = getattr(distance_checker, name, None)
        if method is None:
            continue
        for args in (
            (payload, robot_state),
            (robot_state, payload),
            (payload,),
            (),
        ):
            try:
                return bool(method(*args))
            except TypeError:
                continue
    if callable(distance_checker):
        for args in (
            (branch, payload, robot_state),
            (payload, robot_state),
            (payload,),
        ):
            try:
                return bool(distance_checker(*args))
            except TypeError:
                continue
    return True


def _was_reported(tile_memory, tile_id) -> bool:
    if hasattr(tile_memory, "was_reported"):
        return bool(tile_memory.was_reported(tile_id))
    if hasattr(tile_memory, "__contains__"):
        return tile_id in tile_memory
    return False


def _mark_reported(tile_memory, tile_id) -> None:
    if hasattr(tile_memory, "mark_reported"):
        tile_memory.mark_reported(tile_id)
    elif hasattr(tile_memory, "add"):
        tile_memory.add(tile_id)


class PerceptionPipeline:
    def __init__(
        self,
        presence_session,
        object_type_session,
        victim_bbox_session,
        victim_cls_session,
        target_decoder,
        distance_checker,
        tile_memory,
    ):
        self.presence_session = presence_session
        self.object_type_session = object_type_session
        self.victim_bbox_session = victim_bbox_session
        self.victim_cls_session = victim_cls_session
        self.target_decoder = target_decoder
        self.distance_checker = distance_checker
        self.tile_memory = tile_memory

    def process_frame(self, frame, tile_id, robot_state) -> dict:
        if _was_reported(self.tile_memory, tile_id):
            return {"status": "ignored", "reason": "tile_already_reported"}

        presence_output = _run_session(self.presence_session, frame)
        presence_label, _, presence_scores = _argmax_label(presence_output, PRESENCE_LABELS)
        if presence_label == "none":
            return {
                "status": "ignored",
                "reason": "no_object",
                "presence_scores": presence_scores,
            }

        object_type_output = _run_session(self.object_type_session, frame)
        object_type_label, _, object_type_scores = _argmax_label(object_type_output, OBJECT_TYPE_LABELS)

        if object_type_label == "target":
            return self._process_target(frame, tile_id, robot_state, object_type_scores)
        if object_type_label == "victim":
            return self._process_victim(frame, tile_id, robot_state, object_type_scores)

        return {"status": "ignored", "reason": "unknown_object_type", "class": object_type_label}

    def _process_target(self, frame, tile_id, robot_state, object_type_scores: list[float]) -> dict:
        decoded = _target_decode(self.target_decoder, frame)
        if not decoded.get("success", False):
            return {"status": "ignored", "reason": "target_decode_failed", "tile_id": tile_id, "debug": decoded}

        result = {
            "status": "accepted",
            "branch": "target",
            "sequence": decoded.get("sequence"),
            "tile_id": tile_id,
            "center": decoded.get("center"),
            "radius": decoded.get("radius"),
            "object_type_scores": object_type_scores,
        }
        if not _distance_is_valid(self.distance_checker, "target", result, robot_state):
            return {**result, "status": "ignored", "reason": "distance_rejected"}

        _mark_reported(self.tile_memory, tile_id)
        return result

    def _process_victim(self, frame, tile_id, robot_state, object_type_scores: list[float]) -> dict:
        np = _require_numpy()
        bbox_output = np.asarray(_run_session(self.victim_bbox_session, frame))
        bbox = np.clip(bbox_output.reshape(-1, 4)[0], 0.0, 1.0).astype(float).tolist()
        crop = _crop_normalized_bbox(np.asarray(frame), bbox)
        victim_output = _run_session(self.victim_cls_session, crop)
        victim_label, _, victim_scores = _argmax_label(victim_output, VICTIM_LABELS)

        result = {
            "status": "accepted",
            "branch": "victim",
            "class": victim_label,
            "bbox": bbox,
            "tile_id": tile_id,
            "object_type_scores": object_type_scores,
            "victim_scores": victim_scores,
        }
        if not _distance_is_valid(self.distance_checker, "victim", result, robot_state):
            return {**result, "status": "ignored", "reason": "distance_rejected"}

        _mark_reported(self.tile_memory, tile_id)
        return result


# --------------------------------------------------------------------------- #
# Registry-backed runtime (presence -> object_type -> localization -> crop ->  #
# classification), using predicted crops.                                      #
# --------------------------------------------------------------------------- #


@dataclass
class PerceptionPipelineConfig:
    """Which models to load and how to crop for the registry-backed runtime."""

    presence_selection: str = "latest"
    object_type_selection: str = "latest"
    victim_bbox_selection: str = "latest"
    victim_cls_selection: str = "latest"
    target_ellipse_selection: str = "latest"
    target_circle_selection: str = "latest"
    target_cls_selection: str = "latest"
    # Mask-first radial target branch (preferred): segment the whole target, find
    # the center + radial contour and read the 5 rings by proportional sampling.
    # Falls back to the trainable ellipse localizer, then the circle model.
    prefer_target_radial: bool = True
    target_mask_model_path: str = ""  # joblib RF segmenter; "" -> default artifact
    target_radial_refine: bool = True
    prefer_target_ellipse: bool = True
    explicit_dirs: dict[str, str] = field(default_factory=dict)
    prefer_pointer: bool = True

    crop_padding: float = 0.05
    enable_victim: bool = True
    enable_target: bool = True
    require_target: bool = False  # when False, missing target models -> branch skipped

    # --- bbox proximity gate (replaces the distorted LiDAR distance) -----------
    # When ``use_bbox`` is on, a victim/target is only reported when its predicted
    # bounding box WIDTH (x) and HEIGHT (y) are at least the size an object has at
    # ``bbox_gate_max_distance_m`` -- a larger box means it is closer. Area is not
    # gated (it over-rejects). Thresholds come from the dataset, see
    # ``scripts/compute_bbox_gate_thresholds.py`` / ``evaluate_bbox_gate_xy.py``.
    use_bbox: bool = False
    bbox_gate_path: str = ""  # "" -> reports/bbox_gate_thresholds.json
    bbox_gate_max_distance_m: float = 0.06
    # Explicit normalized (min_width, min_height) overrides (None -> read file).
    victim_bbox_gate_wh: tuple[float, float] | None = None
    target_bbox_gate_wh: tuple[float, float] | None = None
    target_bbox_selection: str = "latest"

    save_pipeline_debug: bool = False
    pipeline_debug_dir: str = "reports/pipeline_debug"


def _to_pil(image):
    from PIL import Image

    if hasattr(image, "convert"):
        return image
    np = _require_numpy()
    return Image.fromarray(np.asarray(image).astype("uint8"))


def _argmax(values: list[float]) -> int:
    best_index = 0
    best_value = values[0]
    for index, value in enumerate(values):
        if value > best_value:
            best_value = value
            best_index = index
    return best_index


@dataclass
class _LoadedModel:
    predictor: Any  # crops.OnnxLocalizer
    labels: list[str]
    artifact_dir: str


# --------------------------------------------------------------------------- #
# Mask-first radial target decoder (no ring masks, no ellipse classification).  #
# --------------------------------------------------------------------------- #


def _default_target_mask_artifact() -> Path:
    from .config import PROJECT_ROOT

    return PROJECT_ROOT / "artifacts" / "target_mask" / "random_forest_target_mask.joblib"


def load_target_mask_segmenter(model_path: str = "") -> Any | None:
    """Load the RF whole-target segmenter from ``model_path`` (or the default)."""

    from .target_mask_rf import TargetMaskRandomForest

    path = Path(model_path) if model_path else _default_target_mask_artifact()
    if not path.exists():
        return None
    return TargetMaskRandomForest.load(path)


class TargetMaskRadialDecoder:
    """Segment the whole target, then read the 5 rings by radial sampling.

    ``decode(image)`` returns the runtime target payload -- ``predicted_texture``,
    ``center``, ``rays``/``ray_valid``, ``mask_confidence``, ``ring_confidence``
    and ``radial_coverage`` -- plus legacy ``sequence``/``success`` keys so the
    older :class:`PerceptionPipeline` keeps working. Ring masks are never used.
    """

    def __init__(self, segmenter, *, refine: bool = True) -> None:
        self.segmenter = segmenter
        self.refine = refine

    def decode(self, image) -> dict:
        np = _require_numpy()
        from .target_classification_radial import decode_target_from_mask

        rgb = np.asarray(image)
        if rgb.ndim == 3 and rgb.shape[2] > 3:
            rgb = rgb[:, :, :3]
        proba = self.segmenter.predict_proba_map(rgb)
        mask = proba >= self.segmenter.config.proba_threshold
        target_present = bool(mask.any())
        mask_confidence = float(proba[mask].mean()) if target_present else 0.0

        decoded = decode_target_from_mask(rgb, mask, refine=self.refine)
        success = bool(decoded.get("mask_valid")) and decoded.get("success", False)
        return {
            "success": success,
            "target_present": target_present,
            "predicted_texture": decoded["predicted_texture"],
            "sequence": decoded["predicted_texture"] if success else None,
            "center": decoded.get("center"),
            "rays": decoded.get("rays"),
            "ray_valid": decoded.get("ray_valid"),
            "mask_confidence": mask_confidence,
            "ring_confidence": decoded.get("ring_confidence"),
            "ring_coverage": decoded.get("ring_coverage"),
            "radial_coverage": decoded.get("radial_coverage"),
            "debug": {"mask_sum": int(mask.sum())},
        }


def _default_bbox_gate_path() -> Path:
    from .config import PROJECT_ROOT

    return PROJECT_ROOT / "reports" / "bbox_gate_thresholds.json"


def load_bbox_gate_thresholds(path: str = "") -> dict[str, tuple[float, float]]:
    """Return ``{"victim": (min_w, min_h), "target": (min_w, min_h)}`` gates.

    Reads the JSON produced by ``scripts/compute_bbox_gate_thresholds.py``. The
    gate is on WIDTH (x) and HEIGHT (y) -- the normalized bbox size an object has
    at the report distance; a larger predicted box means the object is closer and
    should be reported. Area is intentionally not used: it over-rejects. Missing
    files/branches yield an empty mapping (gate disabled).
    """

    gate_path = Path(path) if path else _default_bbox_gate_path()
    if not gate_path.exists():
        return {}
    try:
        payload = json.loads(gate_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    thresholds = payload.get("thresholds", {}) if isinstance(payload, dict) else {}
    gates: dict[str, tuple[float, float]] = {}
    for branch in ("victim", "target"):
        branch_data = thresholds.get(branch)
        if not isinstance(branch_data, dict):
            continue
        # Prefer the model-derived gate (scripts/evaluate_bbox_gate_xy.py) over the
        # raw GT boundary, since the trained model's box sizes differ from the GT.
        gate = branch_data.get("model_gate") or branch_data.get("gate")
        if isinstance(gate, dict) and gate.get("width_norm") is not None and gate.get("height_norm") is not None:
            gates[branch] = (float(gate["width_norm"]), float(gate["height_norm"]))
    return gates


def _bbox_wh_norm(bbox: list[float]) -> tuple[float, float]:
    """Normalized (width, height) of a clipped ``[xmin, ymin, xmax, ymax]`` box."""

    xmin, ymin, xmax, ymax = (max(0.0, min(1.0, float(v))) for v in bbox[:4])
    return (max(0.0, xmax - xmin), max(0.0, ymax - ymin))


class PerceptionRuntime:
    """Loads perception models once and runs the full pipeline per frame."""

    def __init__(self, config: PerceptionPipelineConfig | None = None) -> None:
        self.config = config or PerceptionPipelineConfig()
        self._load_models()

    def _resolve(self, task_name: str, selection: str, *, optional: bool):
        from . import model_registry

        try:
            return model_registry.resolve_model_bundle(
                task_name,
                selection=selection,
                explicit_dir=self.config.explicit_dirs.get(task_name, ""),
                prefer_pointer=self.config.prefer_pointer,
                require_onnx=True,
            )
        except (FileNotFoundError, ValueError):
            if optional:
                return None
            raise

    def _load(self, bundle, default_labels: tuple[str, ...]) -> _LoadedModel:
        from .crops import OnnxLocalizer

        labels = list(bundle.labels) if bundle.labels else list(default_labels)
        return _LoadedModel(OnnxLocalizer(bundle), labels, str(bundle.artifact_dir))

    def _load_models(self) -> None:
        cfg = self.config
        presence = self._resolve("presence", cfg.presence_selection, optional=False)
        object_type = self._resolve("object_type", cfg.object_type_selection, optional=False)
        self.presence = self._load(presence, PRESENCE_LABELS)
        self.object_type = self._load(object_type, OBJECT_TYPE_LABELS)

        # bbox proximity gate (only wired when use_bbox is on). Each entry is the
        # (min_width_norm, min_height_norm) gate for that branch.
        self.bbox_gates: dict[str, tuple[float, float]] = {}
        self.target_bbox = None
        if cfg.use_bbox:
            self.bbox_gates = load_bbox_gate_thresholds(cfg.bbox_gate_path)
            if cfg.victim_bbox_gate_wh is not None:
                self.bbox_gates["victim"] = tuple(float(v) for v in cfg.victim_bbox_gate_wh)
            if cfg.target_bbox_gate_wh is not None:
                self.bbox_gates["target"] = tuple(float(v) for v in cfg.target_bbox_gate_wh)

        self.victim_bbox = self.victim_cls = None
        if cfg.enable_victim:
            vb = self._resolve("victim_bbox", cfg.victim_bbox_selection, optional=False)
            vc = self._resolve("victim_cls", cfg.victim_cls_selection, optional=False)
            self.victim_bbox = self._load(vb, ("victim",))
            self.victim_cls = self._load(vc, VICTIM_LABELS)

        self.target_localizer = self.target_cls = None
        self.target_radial = None  # TargetMaskRadialDecoder
        self.target_kind = None  # "radial", "ellipse" or "circle"
        self.target_available = False
        if cfg.enable_target and cfg.prefer_target_radial:
            segmenter = load_target_mask_segmenter(cfg.target_mask_model_path)
            if segmenter is not None:
                self.target_radial = TargetMaskRadialDecoder(
                    segmenter, refine=cfg.target_radial_refine
                )
                self.target_kind = "radial"
                self.target_available = True

        if cfg.enable_target and self.target_kind != "radial":
            localizer_bundle = None
            if cfg.prefer_target_ellipse:
                localizer_bundle = self._resolve(
                    "target_ellipse", cfg.target_ellipse_selection, optional=True
                )
                if localizer_bundle is not None:
                    self.target_kind = "ellipse"
            if localizer_bundle is None:
                localizer_bundle = self._resolve(
                    "target_circle", cfg.target_circle_selection, optional=not cfg.require_target
                )
                if localizer_bundle is not None:
                    self.target_kind = "circle"
                    print("WARNING: target_ellipse unavailable; falling back to target_circle.")
            tk = self._resolve("target_cls", cfg.target_cls_selection, optional=not cfg.require_target)
            if localizer_bundle is not None and tk is not None:
                self.target_localizer = self._load(localizer_bundle, ("target",))
                self.target_cls = self._load(tk, ("target",))
                self.target_available = True

        # The radial target branch has no bbox, so load the trained target bbox
        # localizer to measure proximity when the gate is enabled.
        if cfg.use_bbox and cfg.enable_target and "target" in self.bbox_gates:
            tb = self._resolve("target_bbox", cfg.target_bbox_selection, optional=True)
            if tb is not None:
                self.target_bbox = self._load(tb, ("target",))
            else:
                print("WARNING: use_bbox is on but target_bbox model is unavailable; target gate disabled.")
                self.bbox_gates.pop("target", None)

    def _gate_result(self, result: dict, branch: str, bbox: list[float]) -> dict:
        """Attach bbox width/height and reject when both are too small (too far).

        Replaces the distorted LiDAR distance: a box narrower AND shorter than the
        dataset-derived (width, height) gate means the object is farther than the
        report distance (or the frame is empty), so the report is dropped.
        """

        width, height = _bbox_wh_norm(bbox)
        result["bbox"] = [max(0.0, min(1.0, float(v))) for v in bbox[:4]]
        result["bbox_wh_norm"] = [width, height]
        gate = self.bbox_gates.get(branch)
        if not self.config.use_bbox or gate is None:
            return result
        min_w, min_h = gate
        result["bbox_gate_wh_norm"] = [min_w, min_h]
        if width < min_w or height < min_h:
            result["status"] = "rejected"
            result["reason"] = "bbox_below_proximity_gate"
        return result

    def run(self, image, *, tile_id=None) -> dict:
        from .crops import (
            circle_to_bbox,
            crop_image_with_bbox,
            crop_image_with_circle,
            crop_image_with_ellipse,
            ellipse_to_bbox,
            normalize_ellipse,
        )
        from .metrics import ellipse_angle_deg

        pil = _to_pil(image).convert("RGB")
        timings: dict[str, float] = {}
        result: dict[str, Any] = {
            "tile_id": tile_id,
            "presence": False,
            "object_type": None,
            "localization": None,
            "crop": None,
            "classification": None,
            "timings_ms": timings,
        }

        t0 = time.perf_counter()
        presence_scores = self.presence.predictor.predict(pil)
        timings["presence"] = (time.perf_counter() - t0) * 1000
        presence_label = self.presence.labels[_argmax(presence_scores)]
        result["presence_label"] = presence_label
        if presence_label == "none":
            return result
        result["presence"] = True

        t0 = time.perf_counter()
        object_type_scores = self.object_type.predictor.predict(pil)
        timings["object_type"] = (time.perf_counter() - t0) * 1000
        object_type_label = self.object_type.labels[_argmax(object_type_scores)]
        result["object_type"] = object_type_label

        if object_type_label == "victim":
            if self.victim_bbox is None or self.victim_cls is None:
                result["status"] = "victim_models_unavailable"
                return result
            t0 = time.perf_counter()
            bbox = [max(0.0, min(1.0, v)) for v in self.victim_bbox.predictor.predict(pil)[:4]]
            timings["localization"] = (time.perf_counter() - t0) * 1000
            crop = crop_image_with_bbox(pil, bbox, padding=self.config.crop_padding)
            t0 = time.perf_counter()
            cls_scores = self.victim_cls.predictor.predict(crop)
            timings["classification"] = (time.perf_counter() - t0) * 1000
            result.update(
                {
                    "localization": {"type": "bbox", "bbox": bbox},
                    "crop": crop,
                    "classification": self.victim_cls.labels[_argmax(cls_scores)],
                    "classification_scores": cls_scores,
                }
            )
            self._gate_result(result, "victim", bbox)
            if result.get("status") == "rejected":
                if self.config.save_pipeline_debug:
                    self._save_debug(result, pil, tile_id)
                return result
        elif object_type_label == "target":
            if not self.target_available:
                result["status"] = "target_models_unavailable"
                return result
            if self.target_kind == "radial":
                np = _require_numpy()
                t0 = time.perf_counter()
                decoded = self.target_radial.decode(np.asarray(pil))
                timings["localization"] = (time.perf_counter() - t0) * 1000
                result.update(
                    {
                        "localization": {
                            "type": "radial",
                            "center": decoded.get("center"),
                            "rays": decoded.get("rays"),
                            "ray_valid": decoded.get("ray_valid"),
                            "radial_coverage": decoded.get("radial_coverage"),
                            "mask_confidence": decoded.get("mask_confidence"),
                        },
                        "classification": decoded.get("predicted_texture"),
                        "target_present": decoded.get("target_present"),
                        "predicted_texture": decoded.get("predicted_texture"),
                        "ring_confidence": decoded.get("ring_confidence"),
                        "radial_coverage": decoded.get("radial_coverage"),
                        "mask_confidence": decoded.get("mask_confidence"),
                    }
                )
                result["status"] = "accepted"
                self._apply_target_gate(result, pil)
                if self.config.save_pipeline_debug:
                    self._save_debug(result, pil, tile_id)
                return result
            t0 = time.perf_counter()
            raw = self.target_localizer.predictor.predict(pil)
            if self.target_kind == "ellipse":
                ellipse = normalize_ellipse(raw[:7])
                bbox = ellipse_to_bbox(ellipse)
                crop = crop_image_with_ellipse(pil, ellipse, padding=self.config.crop_padding)
                localization = {
                    "type": "ellipse",
                    "ellipse": ellipse,
                    "angle_deg": ellipse_angle_deg(ellipse[4], ellipse[5]),
                    "bbox": bbox,
                }
            else:
                circle = [max(0.0, min(1.0, raw[0])), max(0.0, min(1.0, raw[1])), max(0.0, float(raw[2]))]
                crop = crop_image_with_circle(pil, circle, padding=self.config.crop_padding)
                localization = {"type": "circle", "circle": circle, "bbox": circle_to_bbox(circle)}
            timings["localization"] = (time.perf_counter() - t0) * 1000
            t0 = time.perf_counter()
            cls_scores = self.target_cls.predictor.predict(crop)
            timings["classification"] = (time.perf_counter() - t0) * 1000
            result.update(
                {
                    "localization": localization,
                    "crop": crop,
                    "classification": self.target_cls.labels[_argmax(cls_scores)],
                    "classification_scores": cls_scores,
                }
            )

        result["status"] = "accepted"
        if object_type_label == "target":
            self._apply_target_gate(result, pil)
        if self.config.save_pipeline_debug:
            self._save_debug(result, pil, tile_id)
        return result

    def _apply_target_gate(self, result: dict, pil) -> None:
        """Measure the target bbox and reject the report when it is too far."""

        if not (self.config.use_bbox and self.target_bbox is not None and "target" in self.bbox_gates):
            return
        bbox = [max(0.0, min(1.0, v)) for v in self.target_bbox.predictor.predict(pil)[:4]]
        self._gate_result(result, "target", bbox)

    def _save_debug(self, result: dict, pil, tile_id) -> None:
        debug_dir = Path(self.config.pipeline_debug_dir)
        debug_dir.mkdir(parents=True, exist_ok=True)
        stem = f"tile_{tile_id}" if tile_id is not None else f"frame_{int(time.time()*1000)}"
        try:
            pil.save(debug_dir / f"{stem}_input.png")
            crop = result.get("crop")
            if crop is not None and hasattr(crop, "save"):
                crop.save(debug_dir / f"{stem}_crop.png")
        except Exception:  # noqa: BLE001 - debug must not break inference
            pass
        serializable = {
            key: value
            for key, value in result.items()
            if key != "crop" and not hasattr(value, "save")
        }
        (debug_dir / f"{stem}.json").write_text(
            json.dumps(serializable, indent=2, default=str), encoding="utf-8"
        )


def build_perception_runtime(config: PerceptionPipelineConfig | None = None) -> PerceptionRuntime:
    """Resolve and load all pipeline models once into a reusable runtime."""

    return PerceptionRuntime(config)


def run_perception_pipeline(image, config: PerceptionPipelineConfig | PerceptionRuntime | None = None, *, tile_id=None) -> dict:
    """Run the full perception pipeline on a single ``image``.

    ``config`` may be a :class:`PerceptionRuntime` (recommended -- models loaded
    once) or a :class:`PerceptionPipelineConfig` (models are loaded for this call).
    """

    runtime = config if isinstance(config, PerceptionRuntime) else build_perception_runtime(config)
    return runtime.run(image, tile_id=tile_id)
