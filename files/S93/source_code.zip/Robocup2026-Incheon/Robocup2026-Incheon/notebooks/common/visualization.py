"""Visualization helpers for training notebooks."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np


MetricPayload = Mapping[str, Any] | Any


def set_plot_defaults() -> None:
    """Apply readable matplotlib defaults for notebook dashboards."""

    import matplotlib.pyplot as plt

    plt.rcParams.update(
        {
            "figure.figsize": (9, 4.8),
            "figure.dpi": 110,
            "savefig.dpi": 160,
            "axes.grid": True,
            "grid.alpha": 0.25,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.titleweight": "bold",
            "axes.labelsize": 10,
            "legend.frameon": False,
        }
    )


def _as_payload(value: MetricPayload) -> dict[str, Any]:
    if hasattr(value, "to_dict"):
        return value.to_dict()
    if isinstance(value, Mapping):
        return dict(value)
    return {}


def _display_markdown(markdown: str) -> None:
    try:
        from IPython.display import Markdown, display

        display(Markdown(markdown))
    except Exception:
        print(markdown)


def _display_figure(fig) -> None:
    if fig is None:
        return
    try:
        from IPython.display import display

        display(fig)
    except Exception:
        import matplotlib.pyplot as plt

        plt.show()


def _display_table(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    try:
        import pandas as pd
        from IPython.display import display

        display(pd.DataFrame(rows))
    except Exception:
        headers = list(rows[0].keys())
        print("\t".join(headers))
        for row in rows:
            print("\t".join(str(row.get(header, "")) for header in headers))


def _warn(message: str) -> None:
    _display_markdown(f"**Aviso:** {message}")


def _fmt(value: Any, digits: int = 4) -> str:
    if value is None:
        return "-"
    if isinstance(value, float):
        return f"{value:.{digits}f}"
    return str(value)


def _read_manifest(cfg) -> list[dict[str, str]]:
    from .datasets import read_csv_manifest

    if not cfg.manifest_path.exists():
        return []
    return read_csv_manifest(cfg.manifest_path)


def _resolve_image_path(cfg, row: Mapping[str, str]) -> Path:
    path = Path(row.get("image_path", ""))
    if path.is_absolute():
        return path
    return cfg.dataset_root / row.get("split", "") / path


def _counts_from_rows(rows: Sequence[Mapping[str, str]], labels: Sequence[str] | None = None) -> tuple[dict[str, int], dict[str, int]]:
    split_counts = {split: sum(row.get("split") == split for row in rows) for split in ("train", "validation", "test")}
    ordered_labels = list(labels or sorted({row.get("label_name", "") for row in rows if row.get("label_name")}))
    class_counts = {label: sum(row.get("label_name") == label for row in rows) for label in ordered_labels}
    return split_counts, class_counts


def show_images(images, titles=None, columns: int = 4, figsize=(12, 8), cmap=None):
    """Display a compact image grid in notebooks."""

    import matplotlib.pyplot as plt

    if not images:
        _warn("No images to display.")
        return None
    titles = titles or [""] * len(images)
    rows = max((len(images) + columns - 1) // columns, 1)
    fig, axes = plt.subplots(rows, columns, figsize=figsize)
    axes = np.array(axes).reshape(-1)
    for axis, image, title in zip(axes, images, titles):
        axis.imshow(image, cmap=cmap)
        axis.set_title(title, fontsize=9)
        axis.axis("off")
    for axis in axes[len(images):]:
        axis.axis("off")
    fig.tight_layout()
    _display_figure(fig)
    return fig


def show_class_distribution(source, labels: Sequence[str] | None = None, title: str = "Class distribution"):
    """Show split and class distribution from a config, preflight report or metrics payload."""

    import matplotlib.pyplot as plt

    try:
        payload = _as_payload(source)
        if hasattr(source, "manifest_path"):
            rows = _read_manifest(source)
            split_counts, class_counts = _counts_from_rows(rows, labels or getattr(source, "labels", None))
        elif hasattr(source, "split_counts"):
            split_counts = dict(source.split_counts)
            class_counts = dict(source.class_counts)
        else:
            split_counts = dict(payload.get("split_counts") or (payload.get("dataset") or {}).get("splits") or {})
            class_counts = dict(payload.get("class_counts") or (payload.get("dataset") or {}).get("labels") or {})

        if not split_counts and not class_counts:
            _warn("Could not build distribution chart because no counts are available.")
            return None

        set_plot_defaults()
        fig, axes = plt.subplots(1, 2, figsize=(12, 4.2))
        if split_counts:
            axes[0].bar(list(split_counts.keys()), list(split_counts.values()), color="#3b82f6")
            axes[0].set_title("Splits")
            axes[0].set_ylabel("Images")
            for index, value in enumerate(split_counts.values()):
                axes[0].text(index, value, str(value), ha="center", va="bottom")
        else:
            axes[0].axis("off")

        if class_counts:
            names = list(class_counts.keys())
            values = [class_counts[name] for name in names]
            axes[1].bar(names, values, color="#14b8a6")
            axes[1].set_title(title)
            axes[1].set_ylabel("Images")
            axes[1].tick_params(axis="x", rotation=25)
            for index, value in enumerate(values):
                axes[1].text(index, value, str(value), ha="center", va="bottom")
        else:
            axes[1].axis("off")
        fig.tight_layout()
        _display_figure(fig)
        return fig
    except Exception as exc:
        _warn(f"Could not render class distribution: {exc}")
        return None


def plot_dataset_distribution(dataset_summary: Mapping[str, Any], labels: Sequence[str] | None = None):
    """Return a distribution figure without displaying it."""

    import matplotlib.pyplot as plt

    set_plot_defaults()
    splits = dataset_summary.get("splits") or {}
    label_counts = dataset_summary.get("labels") or {}
    if not splits and not label_counts:
        return None

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.2))
    if splits:
        axes[0].bar(list(splits.keys()), list(splits.values()), color="#3b82f6")
        axes[0].set_title("Split distribution")
        axes[0].set_ylabel("Images")
    else:
        axes[0].axis("off")

    if label_counts:
        ordered_labels = list(labels or label_counts.keys())
        values = [label_counts.get(label, 0) for label in ordered_labels]
        axes[1].bar(ordered_labels, values, color="#14b8a6")
        axes[1].set_title("Label distribution")
        axes[1].set_ylabel("Images")
        axes[1].tick_params(axis="x", rotation=25)
    else:
        axes[1].axis("off")

    fig.tight_layout()
    return fig


def _open_image(path: Path):
    from PIL import Image

    with Image.open(path) as image:
        return image.convert("RGB").copy()


def show_sample_images(cfg, max_images: int = 12, split: str | None = None):
    """Show real classification samples with label and split."""

    try:
        rows = _read_manifest(cfg)
        if split:
            rows = [row for row in rows if row.get("split") == split]
        if not rows:
            _warn("No manifest rows available for sample images.")
            return None
        selected = rows[:max_images]
        images = []
        titles = []
        for row in selected:
            path = _resolve_image_path(cfg, row)
            if not path.exists():
                continue
            images.append(_open_image(path))
            titles.append(f"{row.get('split')} | {row.get('label_name')}")
        if not images:
            _warn("No sample image paths resolved to existing files.")
            return None
        return show_images(images, titles=titles, columns=min(4, max_images))
    except Exception as exc:
        _warn(f"Could not show sample images: {exc}")
        return None


def _bbox_rect(bbox: Sequence[float], width: int, height: int) -> tuple[float, float, float, float]:
    xmin, ymin, xmax, ymax = [float(value) for value in bbox]
    x = xmin * width
    y = ymin * height
    return x, y, (xmax - xmin) * width, (ymax - ymin) * height


def show_bbox_samples(cfg, max_images: int = 8, split: str | None = None):
    """Show ground-truth bbox samples from a bbox manifest."""

    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle

    try:
        rows = _read_manifest(cfg)
        if split:
            rows = [row for row in rows if row.get("split") == split]
        if not rows:
            _warn("No bbox rows available for sample images.")
            return None
        selected = rows[:max_images]
        columns = min(4, max_images)
        fig_rows = max((len(selected) + columns - 1) // columns, 1)
        fig, axes = plt.subplots(fig_rows, columns, figsize=(3.2 * columns, 3.3 * fig_rows))
        axes = np.array(axes).reshape(-1)
        shown = 0
        for axis, row in zip(axes, selected):
            path = _resolve_image_path(cfg, row)
            if not path.exists():
                axis.axis("off")
                continue
            image = _open_image(path)
            width, height = image.size
            bbox = [float(row[name]) for name in ("xmin", "ymin", "xmax", "ymax")]
            axis.imshow(image)
            axis.add_patch(Rectangle(_bbox_rect(bbox, width, height)[:2], *_bbox_rect(bbox, width, height)[2:], fill=False, edgecolor="#22c55e", linewidth=2))
            axis.set_title(f"{row.get('split')} | {row.get('label_name')}", fontsize=9)
            axis.axis("off")
            shown += 1
        for axis in axes[len(selected):]:
            axis.axis("off")
        fig.tight_layout()
        if shown == 0:
            _warn("No bbox sample image paths resolved to existing files.")
            return None
        _display_figure(fig)
        return fig
    except Exception as exc:
        _warn(f"Could not show bbox samples: {exc}")
        return None


def _history_columns(history: Any) -> dict[str, list[Any]]:
    if isinstance(history, Mapping):
        return {key: list(value) for key, value in history.items()}
    if not history:
        return {}
    columns: dict[str, list[Any]] = {
        "epoch": [],
        "lr": [],
        "train_loss": [],
        "val_loss": [],
        "train_accuracy": [],
        "val_accuracy": [],
        "train_mean_iou": [],
        "val_mean_iou": [],
        "train_circle_iou": [],
        "val_circle_iou": [],
    }
    for index, item in enumerate(history):
        train = item.get("train") or {}
        val = item.get("validation") or {}
        columns["epoch"].append(item.get("epoch", index + 1))
        columns["lr"].append(item.get("lr"))
        columns["train_loss"].append(train.get("loss"))
        columns["val_loss"].append(val.get("loss"))
        columns["train_accuracy"].append(train.get("accuracy"))
        columns["val_accuracy"].append(val.get("accuracy"))
        columns["train_mean_iou"].append(train.get("mean_iou"))
        columns["val_mean_iou"].append(val.get("mean_iou"))
        columns["train_circle_iou"].append(train.get("circle_iou"))
        columns["val_circle_iou"].append(val.get("circle_iou"))
    return columns


def _has_values(values: Sequence[Any]) -> bool:
    return any(value is not None for value in values)


def plot_training_history(result: MetricPayload, title: str | None = None):
    """Plot loss and task metrics from a TrainingResult or metrics dict."""

    import matplotlib.pyplot as plt

    try:
        payload = _as_payload(result)
        history = _history_columns(payload.get("history") or getattr(result, "history", {}))
        if not history:
            _warn("No training history available.")
            return None

        epochs = history.get("epoch") or list(range(1, len(history.get("train_loss", [])) + 1))
        is_classification = _has_values(history.get("train_accuracy", [])) or _has_values(history.get("val_accuracy", []))
        is_circle = _has_values(history.get("train_circle_iou", [])) or _has_values(history.get("val_circle_iou", []))
        if is_classification:
            metric_keys = ("train_accuracy", "val_accuracy")
            metric_title = "Accuracy"
        elif is_circle:
            metric_keys = ("train_circle_iou", "val_circle_iou")
            metric_title = "Circle IoU"
        else:
            metric_keys = ("train_mean_iou", "val_mean_iou")
            metric_title = "IoU"

        has_lr = _has_values(history.get("lr", []))
        n_panels = 3 if has_lr else 2

        set_plot_defaults()
        fig, axes = plt.subplots(1, n_panels, figsize=(6 * n_panels, 4.3))
        fig.suptitle(title or "Training history", fontweight="bold")

        for key, label in (("train_loss", "train"), ("val_loss", "validation")):
            values = history.get(key, [])
            if _has_values(values):
                axes[0].plot(epochs, values, marker="o", linewidth=1.8, label=label)
        axes[0].set_title("Loss")
        axes[0].set_xlabel("Epoch")
        axes[0].set_ylabel("Loss")
        axes[0].legend()

        for key in metric_keys:
            values = history.get(key, [])
            if _has_values(values):
                axes[1].plot(epochs, values, marker="o", linewidth=1.8, label=key)
        axes[1].set_title(metric_title)
        axes[1].set_xlabel("Epoch")
        axes[1].set_ylim(bottom=0)
        axes[1].legend()

        if has_lr:
            axes[2].plot(epochs, history.get("lr", []), marker="o", linewidth=1.8, color="#f59e0b")
            axes[2].set_title("Learning rate")
            axes[2].set_xlabel("Epoch")
            axes[2].set_ylabel("LR")

        fig.tight_layout()
        return fig
    except Exception as exc:
        _warn(f"Could not plot training history: {exc}")
        return None


def plot_confusion_matrix_counts(
    matrix: Sequence[Sequence[int | float]],
    labels: Sequence[str],
    *,
    normalize: bool = False,
    title: str | None = None,
):
    """Return a classification confusion matrix figure."""

    import matplotlib.pyplot as plt

    set_plot_defaults()
    values = np.array(matrix, dtype=float)
    if values.size == 0:
        return None
    if normalize:
        row_totals = values.sum(axis=1, keepdims=True)
        values = np.divide(values, row_totals, out=np.zeros_like(values), where=row_totals != 0)

    fig_size = max(4.8, 0.75 * len(labels) + 3)
    fig, ax = plt.subplots(figsize=(fig_size, fig_size * 0.82))
    image = ax.imshow(values, cmap="Blues", vmin=0)
    ax.set_title(title or ("Normalized confusion matrix" if normalize else "Confusion matrix"))
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_xticks(range(len(labels)), labels, rotation=25, ha="right")
    ax.set_yticks(range(len(labels)), labels)

    raw_values = np.array(matrix)
    threshold = float(values.max()) / 2 if values.size and values.max() else 0
    for row_index in range(values.shape[0]):
        for col_index in range(values.shape[1]):
            text = f"{values[row_index, col_index]:.2f}" if normalize else str(raw_values[row_index, col_index])
            color = "white" if values[row_index, col_index] > threshold else "black"
            ax.text(col_index, row_index, text, ha="center", va="center", color=color, fontsize=9)

    fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    return fig


def show_confusion_matrix(result: MetricPayload, labels: Sequence[str] | None = None, normalize: bool = False):
    """Display a confusion matrix when it is available."""

    try:
        payload = _as_payload(result)
        matrix = payload.get("confusion_matrix")
        labels = list(labels or payload.get("labels") or [])
        if not matrix or not labels:
            _warn("No confusion matrix available.")
            return None
        fig = plot_confusion_matrix_counts(matrix, labels, normalize=normalize)
        _display_figure(fig)
        return fig
    except Exception as exc:
        _warn(f"Could not show confusion matrix: {exc}")
        return None


def _plot_bbox_predictions(result: MetricPayload, max_images: int = 8):
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle

    payload = _as_payload(result)
    examples = (payload.get("prediction_examples") or [])[:max_images]
    if not examples:
        return None

    columns = min(4, max_images)
    rows = max((len(examples) + columns - 1) // columns, 1)
    fig, axes = plt.subplots(rows, columns, figsize=(3.3 * columns, 3.4 * rows))
    axes = np.array(axes).reshape(-1)
    shown = 0
    for axis, example in zip(axes, examples):
        path = Path(example.get("image_path", ""))
        if not path.exists():
            axis.axis("off")
            continue
        image = _open_image(path)
        width, height = image.size
        axis.imshow(image)
        target = example.get("target_bbox")
        pred = example.get("pred_bbox")
        if target:
            x, y, w, h = _bbox_rect(target, width, height)
            axis.add_patch(Rectangle((x, y), w, h, fill=False, edgecolor="#22c55e", linewidth=2, label="gt"))
        if pred:
            x, y, w, h = _bbox_rect(pred, width, height)
            axis.add_patch(Rectangle((x, y), w, h, fill=False, edgecolor="#ef4444", linewidth=2, linestyle="--", label="pred"))
        axis.set_title(f"IoU {_fmt(example.get('iou'), 3)}", fontsize=9)
        axis.axis("off")
        shown += 1
    for axis in axes[len(examples):]:
        axis.axis("off")
    fig.tight_layout()
    if shown == 0:
        import matplotlib.pyplot as plt

        plt.close(fig)
        return None
    return fig


def show_bbox_predictions(result: MetricPayload, max_images: int = 8):
    """Show predicted bbox versus ground truth examples saved in TrainingResult."""

    try:
        fig = _plot_bbox_predictions(result, max_images=max_images)
        if fig is None:
            _warn("No bbox prediction examples available.")
            return None
        _display_figure(fig)
        return fig
    except Exception as exc:
        _warn(f"Could not show bbox predictions: {exc}")
        return None


def _plot_circle_predictions(result: MetricPayload, max_images: int = 8):
    import matplotlib.pyplot as plt
    from matplotlib.patches import Circle

    payload = _as_payload(result)
    examples = (payload.get("prediction_examples") or [])[:max_images]
    if not examples:
        return None

    columns = min(4, max_images)
    rows = max((len(examples) + columns - 1) // columns, 1)
    fig, axes = plt.subplots(rows, columns, figsize=(3.3 * columns, 3.4 * rows))
    axes = np.array(axes).reshape(-1)
    shown = 0
    for axis, example in zip(axes, examples):
        path = Path(example.get("image_path", ""))
        if not path.exists():
            axis.axis("off")
            continue
        image = _open_image(path)
        width, height = image.size
        axis.imshow(image)
        target = example.get("target_circle")
        pred = example.get("pred_circle")
        if target:
            cx, cy, r = (float(v) for v in target)
            axis.add_patch(
                Circle((cx * width, cy * height), r * (width + height) / 2,
                       fill=False, edgecolor="#22c55e", linewidth=2, label="gt")
            )
        if pred:
            cx, cy, r = (float(v) for v in pred)
            axis.add_patch(
                Circle((cx * width, cy * height), r * (width + height) / 2,
                       fill=False, edgecolor="#ef4444", linewidth=2, linestyle="--", label="pred")
            )
        axis.set_title(f"IoU {_fmt(example.get('circle_iou'), 3)}", fontsize=9)
        axis.axis("off")
        shown += 1
    for axis in axes[len(examples):]:
        axis.axis("off")
    fig.tight_layout()
    if shown == 0:
        plt.close(fig)
        return None
    return fig


def show_circle_predictions(result: MetricPayload, max_images: int = 8):
    """Show predicted vs ground-truth circles saved in a circle TrainingResult."""

    try:
        fig = _plot_circle_predictions(result, max_images=max_images)
        if fig is None:
            _warn("No circle prediction examples available.")
            return None
        _display_figure(fig)
        return fig
    except Exception as exc:
        _warn(f"Could not show circle predictions: {exc}")
        return None


def display_circle_debug_table(result: MetricPayload, limit: int = 12) -> None:
    """Render a table of circle predictions: errors, IoU, target/pred circle."""

    payload = _as_payload(result)
    examples = payload.get("prediction_examples") or []
    if not examples:
        return
    rows = []
    for example in examples[:limit]:
        rows.append(
            {
                "split": example.get("split"),
                "circle_iou": _fmt(example.get("circle_iou"), 3),
                "center_error": _fmt(example.get("center_error"), 4),
                "radius_error": _fmt(example.get("radius_error"), 4),
                "target_circle": [round(float(v), 3) for v in example.get("target_circle", [])],
                "pred_circle": [round(float(v), 3) for v in example.get("pred_circle", [])],
                "image_path": example.get("image_path"),
            }
        )
    _display_markdown("### Circle prediction debug")
    _display_table(rows)


def _is_circle_payload(payload: Mapping[str, Any]) -> bool:
    if payload.get("task") == "circle":
        return True
    examples = payload.get("prediction_examples") or []
    return bool(examples) and "pred_circle" in examples[0]


def display_optuna_summary(result: MetricPayload) -> None:
    """Show Optuna best params/value when a study was run."""

    payload = _as_payload(result)
    optuna = payload.get("optuna") or {}
    best_params = optuna.get("best_params") or payload.get("optuna_best_params")
    if not best_params:
        return
    rows = [{"param": key, "value": value} for key, value in best_params.items()]
    best_value = optuna.get("best_value")
    title = "### Optuna best params"
    if best_value is not None:
        title += f" (best value = {_fmt(best_value, 4)})"
    _display_markdown(title)
    _display_table(rows)


def _classification_report_table(report: Mapping[str, Any]) -> str:
    rows = ["| Class | Precision | Recall | F1 | Support |", "| --- | ---: | ---: | ---: | ---: |"]
    for label, values in report.items():
        if label == "accuracy":
            continue
        rows.append(
            "| {label} | {precision} | {recall} | {f1} | {support} |".format(
                label=label,
                precision=_fmt(values.get("precision"), 3),
                recall=_fmt(values.get("recall"), 3),
                f1=_fmt(values.get("f1"), 3),
                support=values.get("support", "-"),
            )
        )
    accuracy = (report.get("accuracy") or {}).get("value")
    if accuracy is not None:
        rows.append(f"| **accuracy** |  |  | **{_fmt(accuracy, 3)}** |  |")
    return "\n".join(rows)


def display_classification_report(result: MetricPayload) -> None:
    payload = _as_payload(result)
    report = payload.get("classification_report") or payload.get("test_report")
    if report:
        _display_markdown("### Classification report\n\n" + _classification_report_table(report))


def display_error_examples(result: MetricPayload, limit: int = 12) -> None:
    payload = _as_payload(result)
    errors = payload.get("errors") or []
    if not errors:
        return
    rows = []
    for index, error in enumerate(errors[:limit], start=1):
        rows.append(
            {
                "#": index,
                "true": error.get("true"),
                "pred": error.get("pred"),
                "image": error.get("image_path"),
            }
        )
    _display_markdown("### Misclassified examples")
    _display_table(rows)


def display_artifact_links(result: MetricPayload) -> None:
    payload = _as_payload(result)
    artifacts = payload.get("artifacts") or {}
    rows = [{"artifact": key, "path": value} for key, value in artifacts.items() if value]
    if rows:
        _display_markdown("### Artifacts")
        _display_table(rows)


def display_config_table(config: Mapping[str, Any], title: str = "Config") -> None:
    rows = [{"parameter": key, "value": value} for key, value in config.items()]
    _display_markdown(f"### {title}")
    _display_table(rows)


def display_training_summary(result: MetricPayload, title: str | None = None) -> None:
    """Display the final run summary requested by the notebooks."""

    payload = _as_payload(result)
    config = payload.get("config") or {}
    rows = [
        {"field": "model", "value": payload.get("task_name") or payload.get("task")},
        {"field": "dataset", "value": payload.get("dataset_name")},
        {"field": "status", "value": payload.get("status")},
        {"field": "best_epoch", "value": payload.get("best_epoch")},
        {"field": "best_metric", "value": _fmt(payload.get("best_metric"), 4)},
        {"field": "checkpoint", "value": payload.get("checkpoint_path")},
        {"field": "onnx", "value": payload.get("onnx_path")},
        {"field": "metrics_json", "value": payload.get("metrics_path")},
        {"field": "device", "value": payload.get("device")},
        {"field": "total_time_seconds", "value": _fmt(payload.get("total_time_seconds"), 2)},
        {"field": "output_mode", "value": config.get("output_mode")},
    ]
    _display_markdown(f"### {title or 'Training summary'}")
    _display_table(rows)
    warnings = payload.get("warnings") or []
    if warnings:
        _display_markdown("#### Warnings\n\n" + "\n".join(f"- {message}" for message in warnings))


def display_run_summary(metrics: MetricPayload, title: str | None = None) -> None:
    display_training_summary(metrics, title=title)


def display_pipeline_summary(rows_or_results: Sequence[Any]) -> None:
    """Display final pipeline status rows."""

    rows: list[dict[str, Any]] = []
    for item in rows_or_results:
        if isinstance(item, Mapping) and "model" in item:
            rows.append(dict(item))
            continue
        payload = _as_payload(item)
        rows.append(
            {
                "modelo": payload.get("task_name"),
                "status": payload.get("status"),
                "melhor_epoca": payload.get("best_epoch"),
                "melhor_metrica": payload.get("best_metric"),
                "checkpoint_salvo": payload.get("checkpoint_path"),
                "onnx_salvo": payload.get("onnx_path"),
                "metrics_json_salvo": payload.get("metrics_path"),
                "observacoes": "; ".join(payload.get("warnings") or []),
            }
        )
    _display_markdown("### Pipeline summary")
    _display_table(rows)


def display_training_dashboard(result: MetricPayload, *, title: str | None = None, show_errors: bool = True) -> None:
    """Display summary, curves, matrices, bbox examples and artifact paths."""

    payload = _as_payload(result)
    display_training_summary(payload, title=title)
    if payload.get("status") == "skipped" or payload.get("skipped"):
        return

    dataset_fig = plot_dataset_distribution(payload.get("dataset") or {}, payload.get("labels"))
    _display_figure(dataset_fig)

    history_fig = plot_training_history(payload, title="Training curves")
    _display_figure(history_fig)

    if payload.get("confusion_matrix"):
        show_confusion_matrix(payload, normalize=False)

    display_classification_report(payload)
    if show_errors:
        display_error_examples(payload)
    if payload.get("prediction_examples"):
        if _is_circle_payload(payload):
            show_circle_predictions(payload)
            display_circle_debug_table(payload)
        else:
            show_bbox_predictions(payload)
    display_optuna_summary(payload)
    display_artifact_links(payload)


def save_figure(fig, output_path: str | Path) -> Path | None:
    """Save a figure and close it. Returns the path when a figure exists."""

    if fig is None:
        return None
    import matplotlib.pyplot as plt

    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return path


def save_training_visuals(metrics: MetricPayload, output_dir: str | Path) -> dict[str, str]:
    """Save standard report plots for a training metrics payload."""

    payload = _as_payload(metrics)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    artifacts: dict[str, str] = {}

    if payload.get("status") == "skipped" or payload.get("skipped"):
        return artifacts

    history_path = save_figure(plot_training_history(payload), output_dir / "training_history.png")
    if history_path:
        artifacts["training_history_plot"] = str(history_path)

    distribution_path = save_figure(
        plot_dataset_distribution(payload.get("dataset") or {}, payload.get("labels")),
        output_dir / "dataset_distribution.png",
    )
    if distribution_path:
        artifacts["dataset_distribution_plot"] = str(distribution_path)

    matrix = payload.get("confusion_matrix")
    labels = payload.get("labels") or []
    if matrix and labels:
        cm_path = save_figure(
            plot_confusion_matrix_counts(matrix, labels, normalize=False, title="Confusion matrix"),
            output_dir / "confusion_matrix.png",
        )
        norm_path = save_figure(
            plot_confusion_matrix_counts(matrix, labels, normalize=True, title="Normalized confusion matrix"),
            output_dir / "confusion_matrix_normalized.png",
        )
        if cm_path:
            artifacts["confusion_matrix_plot"] = str(cm_path)
        if norm_path:
            artifacts["confusion_matrix_normalized_plot"] = str(norm_path)

    if payload.get("prediction_examples"):
        if _is_circle_payload(payload):
            circle_fig = _plot_circle_predictions(payload)
            circle_path = save_figure(circle_fig, output_dir / "circle_predictions.png")
            if circle_path:
                artifacts["circle_predictions_plot"] = str(circle_path)
        else:
            bbox_fig = _plot_bbox_predictions(payload)
            bbox_path = save_figure(bbox_fig, output_dir / "bbox_predictions.png")
            if bbox_path:
                artifacts["bbox_predictions_plot"] = str(bbox_path)

    return artifacts
