"""Notebook-first training configuration objects."""

from __future__ import annotations

from dataclasses import asdict, dataclass, fields
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping, Sequence

from .config import get_dataset_root, get_manifest_root, get_model_dir


ALLOWED_DEVICES = {"auto", "cuda", "cpu"}
ALLOWED_OUTPUT_MODES = {"overwrite", "timestamped", "fail_if_exists"}
ALLOWED_BBOX_MODEL_TYPES = {"cnn", "foreground_mask", "legacy_cnn"}
ALLOWED_FOREGROUND_SCORE_MODES = {"l1", "l2", "max"}
ALLOWED_OPTIMIZERS = {"adam", "adamw", "sgd"}
ALLOWED_SCHEDULERS = {"none", "cosine", "plateau", "onecycle"}
ALLOWED_OPTUNA_DIRECTIONS = {"maximize", "minimize"}
ALLOWED_OPTUNA_PRUNERS = {"none", "median", "successive_halving"}
ALLOWED_CIRCLE_MODEL_TYPES = {"cnn", "legacy_cnn"}
ALLOWED_ELLIPSE_MODEL_TYPES = {"cnn", "legacy_cnn"}
ALLOWED_BBOX_LOSSES = {"saiou", "smooth_l1", "giou", "combined", "shape_combined"}
ALLOWED_CIRCLE_LOSSES = {"smooth_l1", "combined"}
ALLOWED_ELLIPSE_LOSSES = {"smooth_l1", "combined"}
ALLOWED_MODEL_SELECTIONS = {"latest", "best_metric", "explicit"}
ALLOWED_CROP_MODES = {"none", "ground_truth", "predicted"}


def _coerce_int_tuple(values: Any) -> tuple[int, ...]:
    if values is None:
        return ()
    if isinstance(values, (str, bytes)):
        values = [values]
    return tuple(int(value) for value in values)


def _timestamp() -> str:
    return datetime.now().strftime("%Y-%m-%d_%H-%M-%S_%f")


def _model_dir_for_task(task_name: str) -> str:
    if task_name in {"victim", "victim_cls", "victim_bbox", "victim_classification"}:
        return "victim"
    if task_name in {
        "target", "target_circle", "target_ellipse", "target_localization", "target_cls"
    }:
        return "target"
    return task_name


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "y", "on"}
    return bool(value)


def _select_known_fields(cls, values: Mapping[str, Any]) -> dict[str, Any]:
    names = {field.name for field in fields(cls)}
    return {key: value for key, value in values.items() if key in names}


def _coerce_sequence(values: Sequence[str] | None) -> list[str]:
    return [str(value) for value in values or []]


@dataclass
class BaseTrainConfig:
    """Shared knobs used by all training notebooks."""

    task_name: str
    dataset_name: str
    labels: list[str]
    manifest_filename: str

    input_size: int = 64
    batch_size: int = 32
    epochs: int = 20
    learning_rate: float = 0.001
    weight_decay: float = 0.0001

    num_workers: int = 0
    dropout: float = 0.15
    base_channels: int = 32
    seed: int = 42

    augment: bool = False
    augment_degrees: float = 0.0
    augment_brightness: float = 0.0
    augment_contrast: float = 0.0
    augment_translate: float = 0.0

    # Optimizer
    optimizer_name: str = "adamw"  # "adam", "adamw", "sgd"
    adam_beta1: float = 0.9
    adam_beta2: float = 0.999
    optimizer_eps: float = 1e-8
    sgd_momentum: float = 0.9

    # Scheduler
    scheduler_name: str = "cosine"  # "none", "cosine", "plateau", "onecycle"
    scheduler_eta_min: float = 1e-6
    scheduler_factor: float = 0.5
    scheduler_patience: int = 60
    scheduler_min_lr: float = 1e-6
    onecycle_pct_start: float = 0.1

    # Optuna
    use_optuna: bool = False
    optuna_n_trials: int = 30
    optuna_epochs: int = 120
    optuna_timeout: int | None = None
    optuna_direction: str = "maximize"
    optuna_pruner: str = "median"  # "none", "median", "successive_halving"
    optuna_study_name: str = ""
    optuna_storage: str = ""
    optuna_seed: int = 42
    optuna_metric: str = "val_mean_iou"
    optuna_final_train: bool = True

    # Optuna search spaces
    optuna_lr_min: float = 1e-4
    optuna_lr_max: float = 2e-3
    optuna_weight_decay_min: float = 1e-6
    optuna_weight_decay_max: float = 5e-4
    optuna_dropout_min: float = 0.05
    optuna_dropout_max: float = 0.20
    optuna_base_channels_choices: tuple[int, ...] = (32, 48, 64)
    optuna_batch_size_choices: tuple[int, ...] = (32, 64)
    optuna_input_size_choices: tuple[int, ...] = (64, 96, 128)

    device: str = "auto"
    output_mode: str = "overwrite"

    # Model registry / latest.json pointer
    update_latest: bool = False
    model_selection: str = "latest"  # "latest", "best_metric", "explicit"
    explicit_model_dir: str = ""

    checkpoint_name: str = ""
    onnx_name: str = ""
    model_dir_name: str | None = None
    run_id: str = ""

    show_samples: bool = True
    show_training_plots: bool = True
    save_metrics_json: bool = True

    def __post_init__(self) -> None:
        self.labels = _coerce_sequence(self.labels)
        if not self.model_dir_name:
            self.model_dir_name = _model_dir_for_task(self.task_name)
        if not self.run_id:
            self.run_id = _timestamp()
        self.input_size = int(self.input_size)
        self.batch_size = int(self.batch_size)
        self.epochs = int(self.epochs)
        self.learning_rate = float(self.learning_rate)
        self.weight_decay = float(self.weight_decay)
        self.num_workers = int(self.num_workers)
        self.dropout = float(self.dropout)
        self.base_channels = int(self.base_channels)
        self.seed = int(self.seed)
        self.augment = _as_bool(self.augment)
        self.augment_degrees = float(self.augment_degrees)
        self.augment_brightness = float(self.augment_brightness)
        self.augment_contrast = float(self.augment_contrast)
        self.augment_translate = float(self.augment_translate)
        self.optimizer_name = str(self.optimizer_name).strip().lower()
        self.adam_beta1 = float(self.adam_beta1)
        self.adam_beta2 = float(self.adam_beta2)
        self.optimizer_eps = float(self.optimizer_eps)
        self.sgd_momentum = float(self.sgd_momentum)
        self.scheduler_name = str(self.scheduler_name).strip().lower()
        self.scheduler_eta_min = float(self.scheduler_eta_min)
        self.scheduler_factor = float(self.scheduler_factor)
        self.scheduler_patience = int(self.scheduler_patience)
        self.scheduler_min_lr = float(self.scheduler_min_lr)
        self.onecycle_pct_start = float(self.onecycle_pct_start)
        self.use_optuna = _as_bool(self.use_optuna)
        self.optuna_n_trials = int(self.optuna_n_trials)
        self.optuna_epochs = int(self.optuna_epochs)
        self.optuna_timeout = (
            None if self.optuna_timeout in (None, "", 0) else int(self.optuna_timeout)
        )
        self.optuna_direction = str(self.optuna_direction).strip().lower()
        self.optuna_pruner = str(self.optuna_pruner).strip().lower()
        self.optuna_study_name = str(self.optuna_study_name)
        self.optuna_storage = str(self.optuna_storage)
        self.optuna_seed = int(self.optuna_seed)
        self.optuna_metric = str(self.optuna_metric).strip()
        self.optuna_final_train = _as_bool(self.optuna_final_train)
        self.optuna_lr_min = float(self.optuna_lr_min)
        self.optuna_lr_max = float(self.optuna_lr_max)
        self.optuna_weight_decay_min = float(self.optuna_weight_decay_min)
        self.optuna_weight_decay_max = float(self.optuna_weight_decay_max)
        self.optuna_dropout_min = float(self.optuna_dropout_min)
        self.optuna_dropout_max = float(self.optuna_dropout_max)
        self.optuna_base_channels_choices = _coerce_int_tuple(self.optuna_base_channels_choices)
        self.optuna_batch_size_choices = _coerce_int_tuple(self.optuna_batch_size_choices)
        self.optuna_input_size_choices = _coerce_int_tuple(self.optuna_input_size_choices)
        self.update_latest = _as_bool(self.update_latest)
        self.model_selection = str(self.model_selection).strip().lower()
        self.explicit_model_dir = str(self.explicit_model_dir)
        self.show_samples = _as_bool(self.show_samples)
        self.show_training_plots = _as_bool(self.show_training_plots)
        self.save_metrics_json = _as_bool(self.save_metrics_json)
        self.validate()

    @property
    def dataset_root(self) -> Path:
        return get_dataset_root(self.dataset_name)

    @property
    def manifest_root(self) -> Path:
        return get_manifest_root(self.dataset_name)

    @property
    def manifest_path(self) -> Path:
        return self.manifest_root / self.manifest_filename

    @property
    def model_dir(self) -> Path:
        return get_model_dir(str(self.model_dir_name))

    @property
    def artifact_dir(self) -> Path:
        if self.output_mode == "timestamped":
            return self.model_dir / "runs" / self.run_id
        return self.model_dir

    @property
    def checkpoint_path(self) -> Path:
        return self.artifact_dir / self.checkpoint_name

    @property
    def onnx_path(self) -> Path:
        return self.artifact_dir / self.onnx_name

    @property
    def metrics_path(self) -> Path:
        return self.artifact_dir / "metrics.json"

    @property
    def labels_path(self) -> Path:
        return self.artifact_dir / "labels.json"

    def validate(self) -> None:
        errors = self.validation_errors()
        if errors:
            raise ValueError("Invalid training config:\n- " + "\n- ".join(errors))

    def validation_errors(self) -> list[str]:
        errors: list[str] = []
        if not self.task_name:
            errors.append("task_name must be non-empty.")
        if not self.dataset_name:
            errors.append("dataset_name must be non-empty.")
        if not self.manifest_filename:
            errors.append("manifest_filename must be non-empty.")
        if self.input_size <= 0:
            errors.append("input_size must be > 0.")
        if self.batch_size <= 0:
            errors.append("batch_size must be > 0.")
        if self.epochs <= 0:
            errors.append("epochs must be > 0.")
        if self.learning_rate <= 0:
            errors.append("learning_rate must be > 0.")
        if self.weight_decay < 0:
            errors.append("weight_decay must be >= 0.")
        if self.num_workers < 0:
            errors.append("num_workers must be >= 0.")
        if not 0 <= self.dropout < 1:
            errors.append("dropout must be >= 0 and < 1.")
        if self.base_channels <= 0:
            errors.append("base_channels must be > 0.")
        if self.augment_degrees < 0:
            errors.append("augment_degrees must be >= 0.")
        if self.augment_brightness < 0:
            errors.append("augment_brightness must be >= 0.")
        if self.augment_contrast < 0:
            errors.append("augment_contrast must be >= 0.")
        if self.augment_translate < 0:
            errors.append("augment_translate must be >= 0.")
        if self.output_mode not in ALLOWED_OUTPUT_MODES:
            errors.append(f"output_mode must be one of {sorted(ALLOWED_OUTPUT_MODES)}.")
        if self.device not in ALLOWED_DEVICES:
            errors.append(f"device must be one of {sorted(ALLOWED_DEVICES)}.")
        if self.model_selection not in ALLOWED_MODEL_SELECTIONS:
            errors.append(f"model_selection must be one of {sorted(ALLOWED_MODEL_SELECTIONS)}.")
        if self.model_selection == "explicit" and not self.explicit_model_dir:
            errors.append("explicit_model_dir must be set when model_selection='explicit'.")
        if not self.checkpoint_name:
            errors.append("checkpoint_name must be non-empty.")
        if not self.onnx_name:
            errors.append("onnx_name must be non-empty.")
        # Optimizer
        if self.optimizer_name not in ALLOWED_OPTIMIZERS:
            errors.append(f"optimizer_name must be one of {sorted(ALLOWED_OPTIMIZERS)}.")
        if not 0 < self.adam_beta1 < 1:
            errors.append("adam_beta1 must be > 0 and < 1.")
        if not 0 < self.adam_beta2 < 1:
            errors.append("adam_beta2 must be > 0 and < 1.")
        if self.optimizer_eps <= 0:
            errors.append("optimizer_eps must be > 0.")
        if self.sgd_momentum < 0:
            errors.append("sgd_momentum must be >= 0.")
        # Scheduler
        if self.scheduler_name not in ALLOWED_SCHEDULERS:
            errors.append(f"scheduler_name must be one of {sorted(ALLOWED_SCHEDULERS)}.")
        if self.scheduler_eta_min < 0:
            errors.append("scheduler_eta_min must be >= 0.")
        if not 0 < self.scheduler_factor < 1:
            errors.append("scheduler_factor must be > 0 and < 1.")
        if self.scheduler_patience <= 0:
            errors.append("scheduler_patience must be > 0.")
        if self.scheduler_min_lr < 0:
            errors.append("scheduler_min_lr must be >= 0.")
        if not 0 < self.onecycle_pct_start < 1:
            errors.append("onecycle_pct_start must be > 0 and < 1.")
        # Optuna
        if self.optuna_n_trials <= 0:
            errors.append("optuna_n_trials must be > 0.")
        if self.optuna_epochs <= 0:
            errors.append("optuna_epochs must be > 0.")
        if self.optuna_direction not in ALLOWED_OPTUNA_DIRECTIONS:
            errors.append(f"optuna_direction must be one of {sorted(ALLOWED_OPTUNA_DIRECTIONS)}.")
        if self.optuna_pruner not in ALLOWED_OPTUNA_PRUNERS:
            errors.append(f"optuna_pruner must be one of {sorted(ALLOWED_OPTUNA_PRUNERS)}.")
        if not self.optuna_metric:
            errors.append("optuna_metric must be non-empty.")
        return errors

    def ensure_output_allowed(self) -> None:
        if self.output_mode != "fail_if_exists":
            return
        existing = [
            path
            for path in (self.checkpoint_path, self.onnx_path, self.metrics_path)
            if path.exists()
        ]
        if existing:
            joined = "\n".join(str(path) for path in existing)
            raise FileExistsError(
                "output_mode='fail_if_exists' blocked training because these artifacts already exist:\n"
                + joined
            )

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data.update(
            {
                "dataset_root": str(self.dataset_root),
                "manifest_root": str(self.manifest_root),
                "manifest_path": str(self.manifest_path),
                "model_dir": str(self.model_dir),
                "artifact_dir": str(self.artifact_dir),
                "checkpoint_path": str(self.checkpoint_path),
                "onnx_path": str(self.onnx_path),
                "metrics_path": str(self.metrics_path),
            }
        )
        return data


@dataclass
class ClassificationTrainConfig(BaseTrainConfig):
    """Configuration for classification notebooks."""

    show_confusion_matrix: bool = True

    # Cropping. ``crop_mode`` is the modern knob:
    #   "none"          -> classify full images.
    #   "ground_truth"  -> crop with GT bbox from ``crop_manifest_filename`` (legacy crop_with_bbox).
    #   "predicted"     -> crop with bbox/circle predicted by a localization model (runtime parity).
    crop_mode: str = "none"
    crop_with_bbox: bool = False  # legacy alias: True -> crop_mode="ground_truth"
    crop_manifest_filename: str = "victim_bbox.csv"
    crop_padding: float = 0.0

    # Predicted-crop options (crop_mode="predicted").
    crop_task_name: str = ""  # e.g. "victim_bbox", "target_circle"
    crop_model_selection: str = "latest"  # "latest", "best_metric", "explicit"
    crop_model_artifact_dir: str = ""
    regenerate_crops: bool = False
    crop_output_dir_name: str = "predicted_crops"

    def __post_init__(self) -> None:
        self.show_confusion_matrix = _as_bool(self.show_confusion_matrix)
        self.crop_mode = str(self.crop_mode).strip().lower()
        self.crop_with_bbox = _as_bool(self.crop_with_bbox)
        self.crop_manifest_filename = str(self.crop_manifest_filename)
        self.crop_padding = float(self.crop_padding)
        self.crop_task_name = str(self.crop_task_name).strip()
        self.crop_model_selection = str(self.crop_model_selection).strip().lower()
        self.crop_model_artifact_dir = str(self.crop_model_artifact_dir)
        self.regenerate_crops = _as_bool(self.regenerate_crops)
        self.crop_output_dir_name = str(self.crop_output_dir_name)
        # Back-compat: legacy crop_with_bbox maps to the new ground_truth crop mode.
        if self.crop_with_bbox and self.crop_mode == "none":
            self.crop_mode = "ground_truth"
        # Keep the legacy flag in sync so older call sites still observe it.
        self.crop_with_bbox = self.crop_mode == "ground_truth"
        super().__post_init__()
        if not self.labels:
            raise ValueError("ClassificationTrainConfig requires at least one label.")

    def validation_errors(self) -> list[str]:
        errors = super().validation_errors()
        if self.crop_mode not in ALLOWED_CROP_MODES:
            errors.append(f"crop_mode must be one of {sorted(ALLOWED_CROP_MODES)}.")
        if self.crop_mode == "ground_truth" and not self.crop_manifest_filename:
            errors.append("crop_manifest_filename must be non-empty when crop_mode='ground_truth'.")
        if self.crop_mode == "predicted" and not self.crop_task_name:
            errors.append("crop_task_name must be set when crop_mode='predicted'.")
        if self.crop_model_selection not in ALLOWED_MODEL_SELECTIONS:
            errors.append(f"crop_model_selection must be one of {sorted(ALLOWED_MODEL_SELECTIONS)}.")
        if self.crop_model_selection == "explicit" and not self.crop_model_artifact_dir:
            errors.append("crop_model_artifact_dir must be set when crop_model_selection='explicit'.")
        if self.crop_padding < 0:
            errors.append("crop_padding must be >= 0.")
        return errors

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
        *,
        task_name: str,
        labels: Sequence[str],
        manifest_filename: str,
        checkpoint_name: str,
        onnx_name: str,
        model_dir_name: str | None = None,
    ) -> "ClassificationTrainConfig":
        values = dict(data)
        values.update(
            {
                "task_name": task_name,
                "labels": list(labels),
                "manifest_filename": manifest_filename,
                "checkpoint_name": checkpoint_name,
                "onnx_name": onnx_name,
                "model_dir_name": model_dir_name or _model_dir_for_task(task_name),
            }
        )
        return cls(**_select_known_fields(cls, values))

    @classmethod
    def from_legacy_kwargs(cls, kwargs: Mapping[str, Any]) -> "ClassificationTrainConfig":
        task_name = str(
            kwargs.get("model_name")
            or kwargs.get("report_dir_name")
            or kwargs.get("model_dir_name")
            or "classification"
        )
        values = dict(kwargs)
        values["checkpoint_name"] = values.pop("checkpoint_filename", values.get("checkpoint_name", "best.pt"))
        values["onnx_name"] = values.pop("onnx_filename", values.get("onnx_name", "model.onnx"))
        values["task_name"] = task_name
        values["labels"] = list(values.get("labels") or [])
        values["manifest_filename"] = values.get("manifest_filename", "")
        values["model_dir_name"] = values.get("model_dir_name") or _model_dir_for_task(task_name)
        return cls(**_select_known_fields(cls, values))


@dataclass
class BBoxTrainConfig(BaseTrainConfig):
    """Configuration for victim bbox localization notebooks."""

    skip_if_missing: bool = True
    bbox_model_type: str = "cnn"
    foreground_threshold: float = 0.7
    foreground_ignore_margin: float = 0.1
    foreground_border: int = 2
    foreground_score_mode: str = "l2"

    # Loss
    bbox_loss_name: str = "saiou"  # "saiou", "smooth_l1", "giou", "combined", "shape_combined"
    saiou_lambda_center: float = 1.529124973633597
    saiou_lambda_corner: float = 1.151321268161352
    combined_saiou_weight: float = 1.0
    combined_smooth_l1_weight: float = 0.25
    shape_size_weight: float = 1.0
    shape_aspect_weight: float = 0.5

    # Optuna search spaces for the bbox loss
    optuna_saiou_lambda_center_min: float = 0.25
    optuna_saiou_lambda_center_max: float = 2.0
    optuna_saiou_lambda_corner_min: float = 0.75
    optuna_saiou_lambda_corner_max: float = 3.0

    def __post_init__(self) -> None:
        self.skip_if_missing = _as_bool(self.skip_if_missing)
        self.bbox_model_type = str(self.bbox_model_type)
        self.foreground_threshold = float(self.foreground_threshold)
        self.foreground_ignore_margin = float(self.foreground_ignore_margin)
        self.foreground_border = int(self.foreground_border)
        self.foreground_score_mode = str(self.foreground_score_mode)
        self.bbox_loss_name = str(self.bbox_loss_name).strip().lower()
        self.saiou_lambda_center = float(self.saiou_lambda_center)
        self.saiou_lambda_corner = float(self.saiou_lambda_corner)
        self.combined_saiou_weight = float(self.combined_saiou_weight)
        self.combined_smooth_l1_weight = float(self.combined_smooth_l1_weight)
        self.shape_size_weight = float(self.shape_size_weight)
        self.shape_aspect_weight = float(self.shape_aspect_weight)
        self.optuna_saiou_lambda_center_min = float(self.optuna_saiou_lambda_center_min)
        self.optuna_saiou_lambda_center_max = float(self.optuna_saiou_lambda_center_max)
        self.optuna_saiou_lambda_corner_min = float(self.optuna_saiou_lambda_corner_min)
        self.optuna_saiou_lambda_corner_max = float(self.optuna_saiou_lambda_corner_max)
        super().__post_init__()

    def validation_errors(self) -> list[str]:
        errors = super().validation_errors()
        if self.bbox_model_type not in ALLOWED_BBOX_MODEL_TYPES:
            errors.append(f"bbox_model_type must be one of {sorted(ALLOWED_BBOX_MODEL_TYPES)}.")
        if self.foreground_threshold < 0:
            errors.append("foreground_threshold must be >= 0.")
        if not 0 <= self.foreground_ignore_margin < 0.5:
            errors.append("foreground_ignore_margin must be >= 0 and < 0.5.")
        if self.foreground_border <= 0:
            errors.append("foreground_border must be > 0.")
        if self.foreground_score_mode not in ALLOWED_FOREGROUND_SCORE_MODES:
            errors.append(
                f"foreground_score_mode must be one of {sorted(ALLOWED_FOREGROUND_SCORE_MODES)}."
            )
        if self.bbox_loss_name not in ALLOWED_BBOX_LOSSES:
            errors.append(f"bbox_loss_name must be one of {sorted(ALLOWED_BBOX_LOSSES)}.")
        if self.saiou_lambda_center < 0:
            errors.append("saiou_lambda_center must be >= 0.")
        if self.saiou_lambda_corner < 0:
            errors.append("saiou_lambda_corner must be >= 0.")
        if self.combined_saiou_weight < 0:
            errors.append("combined_saiou_weight must be >= 0.")
        if self.combined_smooth_l1_weight < 0:
            errors.append("combined_smooth_l1_weight must be >= 0.")
        if self.shape_size_weight < 0:
            errors.append("shape_size_weight must be >= 0.")
        if self.shape_aspect_weight < 0:
            errors.append("shape_aspect_weight must be >= 0.")
        return errors

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
        *,
        task_name: str = "victim_bbox",
        labels: Sequence[str] | None = None,
        manifest_filename: str = "victim_bbox.csv",
        checkpoint_name: str = "victim_bbox_best.pt",
        onnx_name: str = "victim_bbox.onnx",
        model_dir_name: str | None = "victim",
    ) -> "BBoxTrainConfig":
        values = dict(data)
        if "skip_bbox_if_missing" in values and "skip_if_missing" not in values:
            values["skip_if_missing"] = values["skip_bbox_if_missing"]
        values.update(
            {
                "task_name": task_name,
                "labels": list(labels or ["harmed", "unharmed", "stable"]),
                "manifest_filename": manifest_filename,
                "checkpoint_name": checkpoint_name,
                "onnx_name": onnx_name,
                "model_dir_name": model_dir_name or _model_dir_for_task(task_name),
            }
        )
        return cls(**_select_known_fields(cls, values))

    @classmethod
    def from_legacy_kwargs(cls, kwargs: Mapping[str, Any]) -> "BBoxTrainConfig":
        values = dict(kwargs)
        values.setdefault("task_name", "victim_bbox")
        values.setdefault("dataset_name", kwargs.get("dataset_name", ""))
        values.setdefault("labels", ["harmed", "unharmed", "stable"])
        values.setdefault("manifest_filename", "victim_bbox.csv")
        values.setdefault("checkpoint_name", "victim_bbox_best.pt")
        values.setdefault("onnx_name", "victim_bbox.onnx")
        values.setdefault("model_dir_name", "victim")
        return cls(**_select_known_fields(cls, values))


@dataclass
class CircleTrainConfig(BaseTrainConfig):
    """Configuration for target circle localization notebooks.

    The model predicts a normalized ``[center_x, center_y, radius]`` triple.
    """

    skip_if_missing: bool = True
    circle_model_type: str = "legacy_cnn"  # "cnn", "legacy_cnn"
    circle_min_radius: float = 0.01

    # Loss
    circle_loss_name: str = "smooth_l1"  # "smooth_l1", "combined"
    circle_center_weight: float = 1.0
    circle_radius_weight: float = 1.0
    combined_circle_iou_weight: float = 1.0

    def __post_init__(self) -> None:
        self.skip_if_missing = _as_bool(self.skip_if_missing)
        self.circle_model_type = str(self.circle_model_type).strip().lower()
        self.circle_min_radius = float(self.circle_min_radius)
        self.circle_loss_name = str(self.circle_loss_name).strip().lower()
        self.circle_center_weight = float(self.circle_center_weight)
        self.circle_radius_weight = float(self.circle_radius_weight)
        self.combined_circle_iou_weight = float(self.combined_circle_iou_weight)
        # Circle localization is scored by IoU like bbox; keep a sane optuna metric default.
        if self.optuna_metric == "val_mean_iou":
            self.optuna_metric = "val_circle_iou"
        super().__post_init__()

    def validation_errors(self) -> list[str]:
        errors = super().validation_errors()
        if self.circle_model_type not in ALLOWED_CIRCLE_MODEL_TYPES:
            errors.append(f"circle_model_type must be one of {sorted(ALLOWED_CIRCLE_MODEL_TYPES)}.")
        if not 0 <= self.circle_min_radius < 1:
            errors.append("circle_min_radius must be >= 0 and < 1.")
        if self.circle_loss_name not in ALLOWED_CIRCLE_LOSSES:
            errors.append(f"circle_loss_name must be one of {sorted(ALLOWED_CIRCLE_LOSSES)}.")
        if self.circle_center_weight < 0:
            errors.append("circle_center_weight must be >= 0.")
        if self.circle_radius_weight < 0:
            errors.append("circle_radius_weight must be >= 0.")
        if self.combined_circle_iou_weight < 0:
            errors.append("combined_circle_iou_weight must be >= 0.")
        return errors

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
        *,
        task_name: str = "target_circle",
        labels: Sequence[str] | None = None,
        manifest_filename: str = "target_localization.csv",
        checkpoint_name: str = "target_circle_best.pt",
        onnx_name: str = "target_circle.onnx",
        model_dir_name: str | None = "target",
    ) -> "CircleTrainConfig":
        values = dict(data)
        if "skip_circle_if_missing" in values and "skip_if_missing" not in values:
            values["skip_if_missing"] = values["skip_circle_if_missing"]
        values.update(
            {
                "task_name": task_name,
                "labels": list(labels or ["target"]),
                "manifest_filename": manifest_filename,
                "checkpoint_name": checkpoint_name,
                "onnx_name": onnx_name,
                "model_dir_name": model_dir_name or _model_dir_for_task(task_name),
            }
        )
        return cls(**_select_known_fields(cls, values))

    @classmethod
    def from_legacy_kwargs(cls, kwargs: Mapping[str, Any]) -> "CircleTrainConfig":
        values = dict(kwargs)
        values.setdefault("task_name", "target_circle")
        values.setdefault("dataset_name", kwargs.get("dataset_name", ""))
        values.setdefault("labels", ["target"])
        values.setdefault("manifest_filename", "target_localization.csv")
        values.setdefault("checkpoint_name", "target_circle_best.pt")
        values.setdefault("onnx_name", "target_circle.onnx")
        values.setdefault("model_dir_name", "target")
        return cls(**_select_known_fields(cls, values))


@dataclass
class EllipseTrainConfig(BaseTrainConfig):
    """Configuration for target ellipse/perspective localization notebooks.

    The model predicts a normalized 7-vector
    ``[center_x, center_y, radius_major, radius_minor, angle_sin, angle_cos,
    perspective_ratio]``.
    """

    skip_if_missing: bool = True
    ellipse_model_type: str = "legacy_cnn"  # "cnn", "legacy_cnn"
    ellipse_min_radius: float = 0.01
    min_mask_visible_px: float = 0.0

    # Loss
    ellipse_loss_name: str = "smooth_l1"  # "smooth_l1", "combined"
    ellipse_center_weight: float = 1.0
    ellipse_radius_weight: float = 1.0
    ellipse_angle_weight: float = 1.0
    ellipse_perspective_weight: float = 1.0
    ellipse_axis_order_weight: float = 0.5
    ellipse_unit_angle_weight: float = 0.1
    combined_ellipse_iou_weight: float = 1.0

    def __post_init__(self) -> None:
        self.skip_if_missing = _as_bool(self.skip_if_missing)
        self.ellipse_model_type = str(self.ellipse_model_type).strip().lower()
        self.ellipse_min_radius = float(self.ellipse_min_radius)
        self.min_mask_visible_px = float(self.min_mask_visible_px)
        self.ellipse_loss_name = str(self.ellipse_loss_name).strip().lower()
        self.ellipse_center_weight = float(self.ellipse_center_weight)
        self.ellipse_radius_weight = float(self.ellipse_radius_weight)
        self.ellipse_angle_weight = float(self.ellipse_angle_weight)
        self.ellipse_perspective_weight = float(self.ellipse_perspective_weight)
        self.ellipse_axis_order_weight = float(self.ellipse_axis_order_weight)
        self.ellipse_unit_angle_weight = float(self.ellipse_unit_angle_weight)
        self.combined_ellipse_iou_weight = float(self.combined_ellipse_iou_weight)
        # Ellipse localization is scored by bbox IoU; keep a sane optuna metric.
        if self.optuna_metric == "val_mean_iou":
            self.optuna_metric = "val_ellipse_iou"
        super().__post_init__()

    def validation_errors(self) -> list[str]:
        errors = super().validation_errors()
        if self.ellipse_model_type not in ALLOWED_ELLIPSE_MODEL_TYPES:
            errors.append(f"ellipse_model_type must be one of {sorted(ALLOWED_ELLIPSE_MODEL_TYPES)}.")
        if not 0 <= self.ellipse_min_radius < 1:
            errors.append("ellipse_min_radius must be >= 0 and < 1.")
        if self.min_mask_visible_px < 0:
            errors.append("min_mask_visible_px must be >= 0.")
        if self.ellipse_loss_name not in ALLOWED_ELLIPSE_LOSSES:
            errors.append(f"ellipse_loss_name must be one of {sorted(ALLOWED_ELLIPSE_LOSSES)}.")
        for name in (
            "ellipse_center_weight", "ellipse_radius_weight", "ellipse_angle_weight",
            "ellipse_perspective_weight", "ellipse_axis_order_weight", "ellipse_unit_angle_weight",
        ):
            if float(getattr(self, name)) < 0:
                errors.append(f"{name} must be >= 0.")
        return errors

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
        *,
        task_name: str = "target_ellipse",
        labels: Sequence[str] | None = None,
        manifest_filename: str = "target_projection_labels.csv",
        checkpoint_name: str = "target_ellipse_best.pt",
        onnx_name: str = "target_ellipse.onnx",
        model_dir_name: str | None = "target",
    ) -> "EllipseTrainConfig":
        values = dict(data)
        if "skip_ellipse_if_missing" in values and "skip_if_missing" not in values:
            values["skip_if_missing"] = values["skip_ellipse_if_missing"]
        values.update(
            {
                "task_name": task_name,
                "labels": list(labels or ["target"]),
                "manifest_filename": manifest_filename,
                "checkpoint_name": checkpoint_name,
                "onnx_name": onnx_name,
                "model_dir_name": model_dir_name or _model_dir_for_task(task_name),
            }
        )
        return cls(**_select_known_fields(cls, values))

    @classmethod
    def from_legacy_kwargs(cls, kwargs: Mapping[str, Any]) -> "EllipseTrainConfig":
        values = dict(kwargs)
        values.setdefault("task_name", "target_ellipse")
        values.setdefault("dataset_name", kwargs.get("dataset_name", ""))
        values.setdefault("labels", ["target"])
        values.setdefault("manifest_filename", "target_projection_labels.csv")
        values.setdefault("checkpoint_name", "target_ellipse_best.pt")
        values.setdefault("onnx_name", "target_ellipse.onnx")
        values.setdefault("model_dir_name", "target")
        return cls(**_select_known_fields(cls, values))
