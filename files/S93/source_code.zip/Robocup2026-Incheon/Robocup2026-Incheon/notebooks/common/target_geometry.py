"""Mask-first geometry for the CognitiveTarget branch.

Pure functions (numpy + OpenCV only, no ground-truth-at-runtime dependency) that
turn the **whole-target** mask into a center and a radial contour ``R(theta)``.
This is the localization representation the new target pipeline is built on --
*not* the legacy circle/ellipse fit in :mod:`notebooks.common.target_cv`.

Conventions
-----------
* The **whole-target** mask has a WHITE (255) background and a DARK target. When
  the generator ships a *multiclass* mask the rings are encoded as ``0..4`` and
  the background stays ``255`` -- so ``target_binary = mask != 255`` recovers the
  whole silhouette without ever touching the per-ring split.
* **Ring masks** (``..._ring<N>_...``) are white-on-dark and encode the answer;
  they are *ignored* everywhere here -- see :data:`RING_RE`.
* ``center`` is ``(x, y)`` in pixels; ``rays``/``ray_valid`` are length ``n_rays``
  arrays sampled at ``theta = 2*pi*i/n_rays`` (``i = 0..n_rays-1``). ``rays`` are
  distances to the contour in **pixels**.
"""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np

# Background value for the whole-target mask (white).
BACKGROUND_VALUE = 255
# Ring masks are the per-band answer key; never used for localization.
RING_RE = re.compile(r"_ring\d+_", re.IGNORECASE)
# Texture letter -> uppercase color code used across the project.
COLOR_CODES = ("K", "R", "Y", "G", "B")


def _require_cv2():
    try:
        import cv2
    except ImportError as exc:  # pragma: no cover - environment guard
        raise RuntimeError("Install opencv-python for target geometry.") from exc
    return cv2


def is_ring_mask(path: str | Path) -> bool:
    """True for per-ring answer-key masks, which must be ignored."""

    return RING_RE.search(Path(path).name) is not None


# --------------------------------------------------------------------------- #
# Mask loading / cleaning
# --------------------------------------------------------------------------- #


def load_target_binary_mask(mask_path: str | Path) -> np.ndarray:
    """Load a whole-target mask as a boolean array (``True`` = target).

    Handles three layouts automatically:

    * **multiclass** ``{0..4, 255}`` -> ``mask != 255`` (rings collapse to target);
    * **binary** ``{0, 255}`` (dark target on white) -> ``mask != 255``;
    * **anti-aliased grayscale** -> threshold the dark pixels, auto-inverting if
      the resulting foreground covers most of the frame (proportion guard).
    """

    from PIL import Image

    with Image.open(mask_path) as handle:
        arr = np.asarray(handle.convert("L"))

    uniques = np.unique(arr)
    has_white_bg = BACKGROUND_VALUE in uniques
    # Tight value set (multiclass labels or pure binary): treat white as bg.
    compact = uniques.size <= 8 or uniques[uniques != BACKGROUND_VALUE].max(initial=0) <= 16
    if has_white_bg and compact:
        return arr != BACKGROUND_VALUE

    # Grayscale fallback: dark pixels are the target, with a proportion guard.
    binary = arr < 128
    if binary.mean() > 0.6:
        binary = ~binary
    return binary


def clean_largest_component(binary: np.ndarray) -> np.ndarray:
    """Keep only the largest connected foreground component."""

    cv2 = _require_cv2()
    mask = np.ascontiguousarray(binary.astype(np.uint8))
    count, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    if count <= 1:
        return np.zeros_like(binary, dtype=bool)
    # Label 0 is background; pick the largest remaining by area.
    largest = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return labels == largest


def touches_border(binary: np.ndarray) -> bool:
    """True if the foreground reaches any image edge (clipped target)."""

    if not binary.any():
        return False
    return bool(
        binary[0, :].any() or binary[-1, :].any() or binary[:, 0].any() or binary[:, -1].any()
    )


def mask_bbox(binary: np.ndarray) -> tuple[int, int, int, int] | None:
    """Tight ``(xmin, ymin, xmax, ymax)`` bbox (``xmax``/``ymax`` exclusive)."""

    ys, xs = np.nonzero(binary)
    if xs.size == 0:
        return None
    return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1


# --------------------------------------------------------------------------- #
# Center + radial contour
# --------------------------------------------------------------------------- #


def _outer_contour_points(binary: np.ndarray, drop_border: bool = True) -> np.ndarray | None:
    """Outer-contour points of the target, optionally dropping image-border pixels.

    Border points belong to the *clip cut*, not the real ring edge; dropping them
    lets a circle fit recover the true ring center from the visible arc.
    """

    cv2 = _require_cv2()
    mask = np.ascontiguousarray(binary.astype(np.uint8))
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not contours:
        return None
    points = max(contours, key=cv2.contourArea).reshape(-1, 2).astype(np.float64)
    if drop_border and points.shape[0] >= 8:
        height, width = binary.shape[:2]
        on_border = (
            (points[:, 0] <= 0)
            | (points[:, 0] >= width - 1)
            | (points[:, 1] <= 0)
            | (points[:, 1] >= height - 1)
        )
        interior = points[~on_border]
        if interior.shape[0] >= 5:
            return interior
    return points


def _fit_circle_center(points: np.ndarray) -> tuple[float, float] | None:
    """Algebraic (Kasa) circle fit -> ``(cx, cy)`` of the best-fit circle."""

    if points is None or points.shape[0] < 3:
        return None
    x, y = points[:, 0], points[:, 1]
    a_matrix = np.column_stack((2.0 * x, 2.0 * y, np.ones_like(x)))
    rhs = x**2 + y**2
    try:
        solution, *_ = np.linalg.lstsq(a_matrix, rhs, rcond=None)
    except np.linalg.LinAlgError:
        return None
    cx, cy = float(solution[0]), float(solution[1])
    if not (np.isfinite(cx) and np.isfinite(cy)):
        return None
    return cx, cy


def estimate_target_center(binary: np.ndarray) -> tuple[float, float]:
    """Robust ``(x, y)`` center of the concentric rings.

    The rings are concentric, so the most accurate center is the center of the
    circle fitted to the **outer ring edge** (the non-border contour points).
    This stays correct even when the target is clipped, where the distance
    transform's inscribed-circle center drifts badly (measured ~4px vs ~10px
    error on this dataset). Falls back to the distance-transform plateau centroid
    and finally the plain centroid for degenerate masks.
    """

    cv2 = _require_cv2()
    height, width = binary.shape[:2]
    if not binary.any():
        return (width - 1) / 2.0, (height - 1) / 2.0

    fitted = _fit_circle_center(_outer_contour_points(binary, drop_border=True))
    if fitted is not None:
        cx, cy = fitted
        # Reject a wild fit (degenerate arc): keep it only near the visible mask.
        if -width <= cx <= 2 * width and -height <= cy <= 2 * height:
            return cx, cy

    mask = np.ascontiguousarray(binary.astype(np.uint8))
    dist = cv2.distanceTransform(mask, cv2.DIST_L2, 5)
    if dist.max() > 0:
        plateau = dist >= dist.max() * 0.9
        ys, xs = np.nonzero(plateau)
        return float(xs.mean()), float(ys.mean())

    ys, xs = np.nonzero(binary)
    return float(xs.mean()), float(ys.mean())


def extract_radial_contour(
    binary: np.ndarray,
    center: tuple[float, float],
    n_rays: int = 64,
    step: float = 0.5,
    min_radius: float = 2.0,
) -> tuple[np.ndarray, np.ndarray]:
    """Cast ``n_rays`` rays from ``center`` to the target contour.

    For each angle the ray marches outward until it leaves the target. The
    distance to that target->background transition is ``R(theta)``. A ray is
    **invalid** when it reaches the image border before finding background (the
    target is clipped in that direction) or when ``R < min_radius``.

    Returns ``(rays, ray_valid)`` -- ``rays`` are pixel distances (length
    ``n_rays``), ``ray_valid`` is a boolean mask of the same length.
    """

    height, width = binary.shape[:2]
    cx, cy = float(center[0]), float(center[1])
    angles = np.arange(n_rays) * (2.0 * np.pi / n_rays)
    max_reach = float(np.hypot(width, height))
    radii = np.arange(step, max_reach + step, step)  # (R,)

    xs = cx + np.cos(angles)[:, None] * radii[None, :]  # (A, R)
    ys = cy + np.sin(angles)[:, None] * radii[None, :]
    xi = np.round(xs).astype(np.intp)
    yi = np.round(ys).astype(np.intp)
    in_bounds = (xi >= 0) & (xi < width) & (yi >= 0) & (yi < height)
    inside = np.zeros_like(in_bounds)
    inside[in_bounds] = binary[yi[in_bounds], xi[in_bounds]]

    n_steps = radii.shape[0]
    idx = np.arange(n_steps)
    background = in_bounds & ~inside  # in-frame background pixel -> real contour

    def _first_true(matrix: np.ndarray) -> np.ndarray:
        has = matrix.any(axis=1)
        return np.where(has, matrix.argmax(axis=1), n_steps)

    first_bg = _first_true(background)
    first_oob = _first_true(~in_bounds)
    stop = np.minimum(first_bg, first_oob)
    found_bg = first_bg < first_oob

    before_stop = inside & (idx[None, :] < stop[:, None])
    has_inside = before_stop.any(axis=1)
    last_idx = np.where(has_inside, (before_stop * idx[None, :]).max(axis=1), 0)
    rays = np.where(has_inside, radii[last_idx], 0.0)
    valid = found_bg & has_inside & (rays >= min_radius)
    return rays.astype(np.float64), valid


def radial_coverage(ray_valid: np.ndarray) -> float:
    """Fraction of valid rays (0..1)."""

    ray_valid = np.asarray(ray_valid)
    return float(ray_valid.mean()) if ray_valid.size else 0.0


# --------------------------------------------------------------------------- #
# Per-image geometry summary + manifest builder
# --------------------------------------------------------------------------- #


def texture_from_name(name: str) -> str:
    """Extract the uppercase 5-color texture from an image/mask filename.

    ``image_target_brrrg_victim0_p0000_brrrg_00001.png`` -> ``"BRRRG"``.
    """

    parts = Path(name).stem.split("_")
    for token in parts[2:]:
        candidate = token.upper()
        if len(candidate) == 5 and all(c in COLOR_CODES for c in candidate):
            return candidate
    return ""


def capture_id_from_name(name: str) -> str:
    """Build a stable capture id ``<victim>_<position>_<TEXTURE>`` when possible."""

    parts = Path(name).stem.split("_")
    victim = next((p for p in parts if p.lower().startswith("victim")), "")
    position = next((p for p in parts if re.fullmatch(r"p\d+", p)), "")
    texture = texture_from_name(name)
    pieces = [p for p in (victim, position, texture) if p]
    return "_".join(pieces) if pieces else Path(name).stem


def compute_mask_geometry(binary: np.ndarray, n_rays: int = 64) -> dict:
    """Summarize a whole-target binary mask into center + radial geometry."""

    cleaned = clean_largest_component(binary)
    visible = int(cleaned.sum())
    if visible == 0:
        return {
            "valid_mask": False,
            "visible_area_px": 0,
            "bbox": None,
            "center": None,
            "clipped": False,
            "rays": np.zeros(n_rays),
            "ray_valid": np.zeros(n_rays, dtype=bool),
            "radial_coverage": 0.0,
            "contour_points": 0,
        }
    center = estimate_target_center(cleaned)
    rays, valid = extract_radial_contour(cleaned, center, n_rays=n_rays)
    return {
        "valid_mask": True,
        "visible_area_px": visible,
        "bbox": mask_bbox(cleaned),
        "center": center,
        "clipped": touches_border(cleaned),
        "rays": rays,
        "ray_valid": valid,
        "radial_coverage": radial_coverage(valid),
        "contour_points": int(valid.sum()),
    }


def _resolve_whole_mask(image_path: Path, mask_dir: Path) -> Path | None:
    """Resolve an image's whole-target mask, never a ring mask."""

    exact = mask_dir / image_path.name.replace("image_", "mask_", 1)
    if exact.exists() and not is_ring_mask(exact):
        return exact
    match = re.search(r"_(\d+)\.[A-Za-z]+$", image_path.name)
    frame = match.group(1) if match else None
    if frame is None:
        return None
    for candidate in sorted(mask_dir.glob(f"*_{frame}.png")):
        if not is_ring_mask(candidate):
            return candidate
    return None


def build_target_mask_manifest(
    dataset_root: str | Path,
    output_csv: str | Path,
    n_rays: int = 64,
    splits: tuple[str, ...] = ("train", "validation", "test"),
    min_coverage_for_classification: float = 0.50,
) -> Path:
    """Write ``target_mask_manifest.csv`` from the whole-target masks.

    One row per target image. Ring masks are skipped explicitly. Returns the
    output path. Raises ``FileNotFoundError`` if no target images are found.
    """

    import csv

    dataset_root = Path(dataset_root)
    output_csv = Path(output_csv)
    output_csv.parent.mkdir(parents=True, exist_ok=True)

    ray_r_cols = [f"ray_r_{i:03d}" for i in range(n_rays)]
    ray_valid_cols = [f"ray_valid_{i:03d}" for i in range(n_rays)]
    base_cols = [
        "split", "image_path", "target_mask_path", "capture_id", "texture",
        "image_width", "image_height", "valid_mask", "visible_area_px",
        "bbox_xmin", "bbox_ymin", "bbox_xmax", "bbox_ymax",
        "center_x", "center_y", "center_x_norm", "center_y_norm",
        "clipped", "contour_points", "radial_coverage", "valid_for_classification",
    ]
    fieldnames = base_cols + ray_r_cols + ray_valid_cols

    rows: list[dict] = []
    skipped: list[str] = []
    for split in splits:
        image_dir = dataset_root / split / "cognitive" / "images"
        mask_dir = dataset_root / split / "cognitive" / "masks"
        if not image_dir.is_dir():
            continue
        for image_path in sorted(image_dir.glob("*.png")):
            mask_path = _resolve_whole_mask(image_path, mask_dir)
            if mask_path is None:
                skipped.append(f"{split}/{image_path.name} (no whole mask)")
                continue
            from PIL import Image

            with Image.open(image_path) as handle:
                width, height = handle.size
            binary = load_target_binary_mask(mask_path)
            geo = compute_mask_geometry(binary, n_rays=n_rays)

            bbox = geo["bbox"] or (0, 0, 0, 0)
            center = geo["center"] or (0.0, 0.0)
            valid_for_cls = bool(
                geo["valid_mask"] and geo["radial_coverage"] >= min_coverage_for_classification
            )
            row = {
                "split": split,
                "image_path": f"cognitive/images/{image_path.name}",
                "target_mask_path": f"cognitive/masks/{mask_path.name}",
                "capture_id": capture_id_from_name(image_path.name),
                "texture": texture_from_name(image_path.name),
                "image_width": width,
                "image_height": height,
                "valid_mask": int(geo["valid_mask"]),
                "visible_area_px": geo["visible_area_px"],
                "bbox_xmin": bbox[0], "bbox_ymin": bbox[1],
                "bbox_xmax": bbox[2], "bbox_ymax": bbox[3],
                "center_x": f"{center[0]:.4f}", "center_y": f"{center[1]:.4f}",
                "center_x_norm": f"{center[0] / width:.6f}",
                "center_y_norm": f"{center[1] / height:.6f}",
                "clipped": int(geo["clipped"]),
                "contour_points": geo["contour_points"],
                "radial_coverage": f"{geo['radial_coverage']:.4f}",
                "valid_for_classification": int(valid_for_cls),
            }
            for col, value in zip(ray_r_cols, geo["rays"]):
                row[col] = f"{float(value):.3f}"
            for col, value in zip(ray_valid_cols, geo["ray_valid"]):
                row[col] = int(bool(value))
            rows.append(row)

    if not rows:
        raise FileNotFoundError(
            f"No target images found under {dataset_root}/<split>/cognitive/images."
        )

    with output_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"wrote {output_csv} ({len(rows)} rows)")
    print("split counts:", {s: sum(r["split"] == s for r in rows) for s in splits})
    if skipped:
        print(f"skipped {len(skipped)} images. First few:")
        for item in skipped[:5]:
            print("  -", item)
    return output_csv
