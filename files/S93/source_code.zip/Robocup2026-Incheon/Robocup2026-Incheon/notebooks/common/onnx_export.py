"""ONNX export helpers for Robocup 2026 perception models."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Sequence


def _as_list(values) -> list:
    if values is None:
        return []
    return list(values)


def _metadata_path(output_path: Path) -> Path:
    return output_path.with_suffix(".metadata.json")


def export_onnx_model(
    model,
    output_path: str | Path,
    input_shape: Sequence[int],
    input_names: Sequence[str] = ("input",),
    output_names: Sequence[str] = ("logits",),
    opset_version: int = 13,
    dynamic_batch: bool = True,
    labels: Sequence[str] | None = None,
    mean: Sequence[float] | None = None,
    std: Sequence[float] | None = None,
    model_name: str | None = None,
    extra_metadata: dict | None = None,
) -> Path:
    """Export a PyTorch model to ONNX and write sidecar metadata.

    ``extra_metadata`` is merged into the sidecar JSON (e.g. ``output_schema``,
    ``task_name``, ``dataset_name``) without overwriting the core fields.
    """

    try:
        import torch
    except ImportError as exc:
        raise RuntimeError("Install torch to export ONNX models.") from exc

    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    input_shape = [int(dim) for dim in input_shape]
    input_names = list(input_names)
    output_names = list(output_names)
    if not input_names:
        raise ValueError("At least one input name is required.")
    if not output_names:
        raise ValueError("At least one output name is required.")

    dynamic_axes = None
    if dynamic_batch:
        dynamic_axes = {
            name: {0: "batch"} for name in [*input_names, *output_names]
        }

    model.eval()
    dummy_input = torch.randn(*input_shape)
    with torch.no_grad():
        torch.onnx.export(
            model,
            dummy_input,
            path,
            export_params=True,
            opset_version=opset_version,
            do_constant_folding=True,
            input_names=input_names,
            output_names=output_names,
            dynamic_axes=dynamic_axes,
            dynamo=False,
        )

    metadata = {
        "model_name": model_name or path.stem,
        "onnx_path": str(path),
        "input_shape": input_shape,
        "input_names": input_names,
        "output_names": output_names,
        "opset_version": opset_version,
        "dynamic_batch": dynamic_batch,
        "labels": _as_list(labels),
        "mean": _as_list(mean) if mean is not None else [0.0, 0.0, 0.0],
        "std": _as_list(std) if std is not None else [1.0, 1.0, 1.0],
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    if extra_metadata:
        for key, value in extra_metadata.items():
            metadata.setdefault(key, value)
    with _metadata_path(path).open("w", encoding="utf-8") as handle:
        json.dump(metadata, handle, indent=2, sort_keys=True)
        handle.write("\n")

    return path


def export_torch_model_to_onnx(
    model,
    sample_input,
    output_path: str | Path,
    input_name: str = "input",
    output_name: str = "logits",
    opset_version: int = 13,
) -> Path:
    """Backward-compatible wrapper around :func:`export_onnx_model`."""

    return export_onnx_model(
        model=model,
        output_path=output_path,
        input_shape=tuple(sample_input.shape),
        input_names=(input_name,),
        output_names=(output_name,),
        opset_version=opset_version,
    )
