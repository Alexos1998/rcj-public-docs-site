"""Per-run sub-cell registration of the tile lattice against the occupancy grid.

Why this exists
---------------
``map_dataset.sample_patch`` crops occupancy patches around world coordinates that
assume the start tile sits exactly at world ``(0, 0)`` (anchor from the matrix
``'5'`` token). Measured on the collected runs this assumption is wrong:

* a **constant** ~1-cell vertical bias appears in *every* run, and
* the horizontal phase **drifts by several cells from run to run**.

Because the per-model features are coarse occupancy ratios, a mis-centred crop
smears the signal and *more data does not help* — each new run is just another
differently-misaligned example. This module estimates the offset that best lines
the predicted tile/wall lattice up with the actual occupied cells, **without using
the hand labels** (it correlates against the maze-wall lattice, which is visible in
the grid itself and is therefore reproducible at deployment time).

The estimate is returned as an integer ``(off_row, off_col)`` cell shift and folded
into the map origin so the existing ``sample_patch`` lines up with no other change.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .map_dataset import (
    DEFAULT_RES,
    TILE_SIZE_M,
    find_anchor_tile,
    matrix_rows,
)

OCC_THR = 65  # occupancy value at/above which a cell counts as a wall


@dataclass
class Alignment:
    off_row: int          # cell shift to ADD to the sampled grid row
    off_col: int          # cell shift to ADD to the sampled grid col
    score_before: float   # wall-lattice occupancy mass at offset (0, 0)
    score_after: float    # ... at the chosen offset
    period: float         # tile lattice period in cells

    @property
    def gain(self) -> float:
        return self.score_after - self.score_before


def _wall_line_phase(proj: np.ndarray, period: float, phase0: float,
                     search: int) -> tuple[int, float, float]:
    """Best integer shift of a 1-D wall lattice against an occupancy projection.

    ``proj[i]`` is the occupied-cell count in grid row/col ``i``. Wall lines are
    predicted at ``phase0 + k*period``; we slide that comb by an integer offset in
    ``[-search, search]`` and pick the offset whose lines collect the most mass.
    Returns ``(best_offset, score_at_zero, best_score)``.
    """
    n = len(proj)
    lines0 = np.arange(phase0 % period, n, period)

    def mass(shift: int) -> float:
        idx = np.round(lines0 + shift).astype(int)
        idx = idx[(idx >= 0) & (idx < n)]
        return float(proj[idx].sum()) if len(idx) else 0.0

    base = mass(0)
    best_off, best = 0, base
    for s in range(-search, search + 1):
        m = mass(s)
        if m > best:
            best, best_off = m, s
    return best_off, base, best


def estimate_alignment(run: dict, res: float | None = None) -> Alignment:
    """Estimate the sub-cell ``(off_row, off_col)`` correction for one run.

    Label-free: correlates the maze-wall lattice (period = tile size) against the
    occupancy projections. The lattice *phase* comes from the start-tile anchor
    (available at runtime via the submission matrix), so the same correction is
    reproducible without ground truth.
    """
    grid = run["grid"]
    meta = run["meta"]
    res = float(res if res is not None else meta["map"]["resolution"]) or DEFAULT_RES
    ox = float(meta["map"]["origin"]["x"])
    oy = float(meta["map"]["origin"]["y"])
    period = TILE_SIZE_M / res
    search = int(round(period / 2))  # never move more than half a tile

    rows = matrix_rows(run.get("submission", "")) or matrix_rows(run.get("real", ""))
    anchor = find_anchor_tile(rows) if rows else None

    occ = (grid >= OCC_THR)
    proj_col = occ.sum(axis=0).astype(np.float64)  # mass per grid column (x / east)
    proj_row = occ.sum(axis=1).astype(np.float64)  # mass per grid row    (y / north)

    # Predicted wall lines sit halfway between tile centres. The start tile centre
    # is world (0,0) -> grid col0 = (0-ox)/res, row0 = (0-oy)/res; walls at +period/2.
    col0 = (0.0 - ox) / res + period / 2.0
    row0 = (0.0 - oy) / res + period / 2.0

    off_col, base_c, best_c = _wall_line_phase(proj_col, period, col0, search)
    off_row, base_r, best_r = _wall_line_phase(proj_row, period, row0, search)

    return Alignment(
        off_row=off_row,
        off_col=off_col,
        score_before=base_c + base_r,
        score_after=best_c + best_r,
        period=period,
    )


def aligned_meta(meta: dict, align: Alignment, res: float | None = None) -> dict:
    """Return a shallow-copied ``meta`` whose origin is shifted so that the existing
    ``sample_patch`` rounds to the registered cells (adds ``off_row/off_col``)."""
    res = float(res if res is not None else meta["map"]["resolution"]) or DEFAULT_RES
    m = dict(meta)
    m["map"] = dict(meta["map"])
    m["map"]["origin"] = dict(meta["map"]["origin"])
    # sample_patch: col_c = round((wx - ox)/res); to add off_col we lower ox by off*res.
    m["map"]["origin"]["x"] = float(meta["map"]["origin"]["x"]) - align.off_col * res
    m["map"]["origin"]["y"] = float(meta["map"]["origin"]["y"]) - align.off_row * res
    return m


def align_run(run: dict) -> dict:
    """Return a shallow-copied run with a registered (origin-corrected) ``meta`` and
    an ``alignment`` field. Builders that read ``run['meta']`` get aligned crops."""
    align = estimate_alignment(run)
    out = dict(run)
    out["meta"] = aligned_meta(run["meta"], align)
    out["alignment"] = align
    return out
