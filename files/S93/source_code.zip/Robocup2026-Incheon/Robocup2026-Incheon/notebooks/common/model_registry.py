"""Resolve trained model artifacts without hardcoding paths in notebooks.

Models are written to ``models/<model_dir>/runs/<timestamp>/`` (when
``output_mode="timestamped"``) or directly to ``models/<model_dir>/`` (when
``output_mode="overwrite"``). This module locates the latest / best run for a
task, reads and writes ``latest.json`` pointers, and packages the result as a
:class:`ModelBundle` that downstream code (predicted crops, runtime pipeline)
can consume.

Every resolver raises a clear error when nothing can be resolved -- it never
falls back silently to an unexpected model.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Sequence

from .config import get_model_dir

LATEST_POINTER_NAME = "latest.json"
RUN_TIMESTAMP_FORMAT = "%Y-%m-%d_%H-%M-%S_%f"


@dataclass(frozen=True)
class TaskSpec:
    """Default artifact filenames + model directory for a known task."""

    task_name: str
    model_dir_name: str
    checkpoint_name: str
    onnx_name: str


# Known perception tasks and their default artifact filenames.
TASK_SPECS: dict[str, TaskSpec] = {
    "presence": TaskSpec("presence", "presence", "presence_best.pt", "presence.onnx"),
    "object_presence": TaskSpec(
        "object_presence", "object_presence", "object_presence_best.pt", "object_presence.onnx"
    ),
    "object_type": TaskSpec(
        "object_type", "object_type", "object_type_best.pt", "object_type.onnx"
    ),
    "victim_bbox": TaskSpec("victim_bbox", "victim", "victim_bbox_best.pt", "victim_bbox.onnx"),
    "victim_cls": TaskSpec("victim_cls", "victim", "victim_cls_best.pt", "victim_cls.onnx"),
    "target_bbox": TaskSpec(
        "target_bbox", "target", "target_bbox_best.pt", "target_bbox.onnx"
    ),
    "target_circle": TaskSpec(
        "target_circle", "target", "target_circle_best.pt", "target_circle.onnx"
    ),
    "target_ellipse": TaskSpec(
        "target_ellipse", "target", "target_ellipse_best.pt", "target_ellipse.onnx"
    ),
    "target_cls": TaskSpec("target_cls", "target", "target_cls_best.pt", "target_cls.onnx"),
}

# Localization tasks whose predicted output is used to crop classification inputs.
LOCALIZATION_TASKS = {
    "victim_bbox": "bbox",
    "target_bbox": "bbox",
    "target_circle": "circle",
    "target_ellipse": "ellipse",
}


def get_task_spec(task_name: str) -> TaskSpec | None:
    return TASK_SPECS.get(task_name)


@dataclass(frozen=True)
class ModelBundle:
    """A resolved set of artifacts for one trained model."""

    task_name: str
    artifact_dir: Path
    checkpoint_path: Path | None = None
    onnx_path: Path | None = None
    metrics_path: Path | None = None
    labels: list[str] = field(default_factory=list)
    created_at: str | None = None
    best_metric: float | None = None
    best_epoch: int | None = None

    @property
    def metadata_path(self) -> Path | None:
        if self.onnx_path is None:
            return None
        candidate = self.onnx_path.with_suffix(".metadata.json")
        return candidate if candidate.exists() else None

    def load_metadata(self) -> dict:
        path = self.metadata_path
        if path is None:
            return {}
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}

    def to_pointer_dict(self) -> dict:
        return {
            "task_name": self.task_name,
            "artifact_dir": str(self.artifact_dir),
            "checkpoint_path": str(self.checkpoint_path) if self.checkpoint_path else None,
            "onnx_path": str(self.onnx_path) if self.onnx_path else None,
            "metrics_path": str(self.metrics_path) if self.metrics_path else None,
            "labels": list(self.labels),
            "created_at": self.created_at or datetime.now(timezone.utc).isoformat(),
            "best_metric": self.best_metric,
            "best_epoch": self.best_epoch,
        }


def _read_json(path: Path) -> dict:
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _run_dirs(model_dir: Path) -> list[Path]:
    """Timestamped run directories under ``<model_dir>/runs``, oldest first."""

    runs_root = Path(model_dir) / "runs"
    if not runs_root.is_dir():
        return []
    return sorted(path for path in runs_root.iterdir() if path.is_dir())


def _has_files(directory: Path, required: Sequence[str] | None) -> bool:
    return all((directory / name).exists() for name in (required or ()))


def find_latest_run(model_dir: str | Path, required_files: Sequence[str] | None = None) -> Path | None:
    """Return the most recent run directory containing all ``required_files``.

    Timestamped run directories are tried newest-first; if none qualify, the
    ``model_dir`` itself (``output_mode="overwrite"`` layout) is considered.
    Returns ``None`` when nothing matches.
    """

    model_dir = Path(model_dir)
    for directory in reversed(_run_dirs(model_dir)):
        if _has_files(directory, required_files):
            return directory
    if model_dir.is_dir() and _has_files(model_dir, required_files):
        return model_dir
    return None


def _bundle_from_dir(task_name: str, spec: TaskSpec | None, artifact_dir: Path) -> ModelBundle:
    artifact_dir = Path(artifact_dir)
    checkpoint_name = spec.checkpoint_name if spec else f"{task_name}_best.pt"
    onnx_name = spec.onnx_name if spec else f"{task_name}.onnx"
    checkpoint_path = artifact_dir / checkpoint_name
    onnx_path = artifact_dir / onnx_name
    metrics_path = artifact_dir / "metrics.json"
    labels_path = artifact_dir / "labels.json"

    labels: list[str] = []
    if labels_path.exists():
        loaded = _read_json(labels_path)
        if isinstance(loaded, list):
            labels = [str(item) for item in loaded]

    metrics = _read_json(metrics_path) if metrics_path.exists() else {}
    return ModelBundle(
        task_name=task_name,
        artifact_dir=artifact_dir,
        checkpoint_path=checkpoint_path if checkpoint_path.exists() else None,
        onnx_path=onnx_path if onnx_path.exists() else None,
        metrics_path=metrics_path if metrics_path.exists() else None,
        labels=labels,
        created_at=metrics.get("created_at"),
        best_metric=metrics.get("best_metric"),
        best_epoch=metrics.get("best_epoch"),
    )


def _resolve_names(
    task_name: str,
    model_dir_name: str | None,
    checkpoint_name: str | None,
    onnx_name: str | None,
) -> tuple[str, str, str, TaskSpec | None]:
    spec = get_task_spec(task_name)
    model_dir_name = model_dir_name or (spec.model_dir_name if spec else task_name)
    checkpoint_name = checkpoint_name or (spec.checkpoint_name if spec else f"{task_name}_best.pt")
    onnx_name = onnx_name or (spec.onnx_name if spec else f"{task_name}.onnx")
    return model_dir_name, checkpoint_name, onnx_name, spec


def _required_files(checkpoint_name: str, onnx_name: str, require_onnx: bool, require_checkpoint: bool) -> list[str]:
    required: list[str] = []
    if require_onnx:
        required.append(onnx_name)
    if require_checkpoint:
        required.append(checkpoint_name)
    return required


def find_latest_model_bundle(
    task_name: str,
    model_dir_name: str | None = None,
    checkpoint_name: str | None = None,
    onnx_name: str | None = None,
    *,
    require_onnx: bool = True,
    require_checkpoint: bool = False,
) -> ModelBundle | None:
    """Resolve the newest run for a task, or ``None`` when none is available."""

    model_dir_name, checkpoint_name, onnx_name, spec = _resolve_names(
        task_name, model_dir_name, checkpoint_name, onnx_name
    )
    model_dir = get_model_dir(model_dir_name)
    required = _required_files(checkpoint_name, onnx_name, require_onnx, require_checkpoint)
    run = find_latest_run(model_dir, required or None)
    if run is None:
        return None
    return _bundle_from_dir(task_name, spec, run)


def find_best_metric_bundle(
    task_name: str,
    model_dir_name: str | None = None,
    checkpoint_name: str | None = None,
    onnx_name: str | None = None,
    *,
    direction: str = "maximize",
    require_onnx: bool = True,
    require_checkpoint: bool = False,
) -> ModelBundle | None:
    """Resolve the run with the best ``best_metric`` across all runs."""

    model_dir_name, checkpoint_name, onnx_name, spec = _resolve_names(
        task_name, model_dir_name, checkpoint_name, onnx_name
    )
    model_dir = get_model_dir(model_dir_name)
    required = _required_files(checkpoint_name, onnx_name, require_onnx, require_checkpoint)

    best_bundle: ModelBundle | None = None
    candidates = [*_run_dirs(model_dir), model_dir]
    for directory in candidates:
        if not _has_files(directory, required):
            continue
        bundle = _bundle_from_dir(task_name, spec, directory)
        if bundle.best_metric is None:
            continue
        if best_bundle is None or best_bundle.best_metric is None:
            best_bundle = bundle
            continue
        if direction == "minimize":
            if bundle.best_metric < best_bundle.best_metric:
                best_bundle = bundle
        elif bundle.best_metric > best_bundle.best_metric:
            best_bundle = bundle
    return best_bundle


def read_latest_pointer(
    model_dir_name: str,
    task_name: str | None = None,
) -> ModelBundle | None:
    """Read ``<model_dir>/latest.json`` and rebuild a :class:`ModelBundle`."""

    model_dir = get_model_dir(model_dir_name)
    pointer_path = model_dir / LATEST_POINTER_NAME
    if not pointer_path.exists():
        return None
    data = _read_json(pointer_path)
    artifact_dir = data.get("artifact_dir")
    if not artifact_dir:
        return None
    pointer_task = data.get("task_name")
    # A model dir can host several tasks (e.g. victim_bbox + victim_cls) that all
    # share one latest.json. When a specific task is requested, only honor the
    # pointer if it belongs to that task; otherwise let the caller fall back to
    # per-task run resolution so we never return the wrong task's artifacts.
    if task_name and pointer_task and pointer_task != task_name:
        return None
    resolved_task = pointer_task or task_name or model_dir_name
    spec = get_task_spec(resolved_task)
    bundle = _bundle_from_dir(resolved_task, spec, Path(artifact_dir))
    # Guard against a stale/mislabelled pointer whose artifact dir lacks this
    # task's ONNX file (the caller then resolves the correct timestamped run).
    if task_name and spec is not None and not (Path(artifact_dir) / spec.onnx_name).exists():
        return None
    return bundle


def write_latest_pointer(model_dir_name: str, bundle: ModelBundle) -> Path:
    """Write/refresh ``<model_dir>/latest.json`` for a resolved bundle."""

    model_dir = get_model_dir(model_dir_name)
    model_dir.mkdir(parents=True, exist_ok=True)
    pointer_path = model_dir / LATEST_POINTER_NAME
    pointer_path.write_text(
        json.dumps(bundle.to_pointer_dict(), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return pointer_path


def resolve_model_bundle(
    task_name: str,
    *,
    selection: str = "latest",
    explicit_dir: str | Path = "",
    model_dir_name: str | None = None,
    checkpoint_name: str | None = None,
    onnx_name: str | None = None,
    direction: str = "maximize",
    require_onnx: bool = True,
    require_checkpoint: bool = False,
    prefer_pointer: bool = False,
) -> ModelBundle:
    """Resolve a model bundle for ``task_name`` using ``selection`` strategy.

    ``selection``:
      * ``"latest"`` -- newest timestamped run (or the curated ``latest.json``
        pointer first when ``prefer_pointer=True``).
      * ``"best_metric"`` -- run with the best ``best_metric`` across all runs.
      * ``"explicit"`` -- use ``explicit_dir`` directly.

    Raises a clear error when nothing resolves; never falls back silently.
    """

    selection = (selection or "latest").strip().lower()
    model_dir_name, checkpoint_name, onnx_name, spec = _resolve_names(
        task_name, model_dir_name, checkpoint_name, onnx_name
    )
    model_dir = get_model_dir(model_dir_name)

    if selection == "explicit":
        explicit_path = Path(explicit_dir)
        if not str(explicit_dir):
            raise ValueError(
                f"model_selection='explicit' for task '{task_name}' requires explicit_model_dir."
            )
        if not explicit_path.is_dir():
            raise FileNotFoundError(
                f"Explicit model dir for task '{task_name}' does not exist: {explicit_path}"
            )
        bundle = _bundle_from_dir(task_name, spec, explicit_path)
    elif selection == "best_metric":
        bundle = find_best_metric_bundle(
            task_name,
            model_dir_name,
            checkpoint_name,
            onnx_name,
            direction=direction,
            require_onnx=require_onnx,
            require_checkpoint=require_checkpoint,
        )
        if bundle is None:
            # Fall back to latest run so 'best_metric' still resolves when no run
            # has recorded a best_metric yet.
            bundle = find_latest_model_bundle(
                task_name,
                model_dir_name,
                checkpoint_name,
                onnx_name,
                require_onnx=require_onnx,
                require_checkpoint=require_checkpoint,
            )
    elif selection == "latest":
        bundle = None
        if prefer_pointer:
            bundle = read_latest_pointer(model_dir_name, task_name)
        if bundle is None:
            bundle = find_latest_model_bundle(
                task_name,
                model_dir_name,
                checkpoint_name,
                onnx_name,
                require_onnx=require_onnx,
                require_checkpoint=require_checkpoint,
            )
    else:
        raise ValueError(
            f"Unknown model_selection '{selection}'. Use 'latest', 'best_metric' or 'explicit'."
        )

    if bundle is None:
        required = _required_files(checkpoint_name, onnx_name, require_onnx, require_checkpoint)
        raise FileNotFoundError(
            f"Could not resolve a '{task_name}' model under {model_dir} "
            f"(selection='{selection}', required files: {required or 'any run dir'}). "
            "Train the model first or pass an explicit model dir."
        )
    return bundle
