"""Generate *predicted* crops from localization models for classification.

At runtime the perception pipeline crops each frame using the bbox/circle
predicted by a localization model, then classifies that crop. To avoid a
train/runtime mismatch, classification must train on the **same** predicted
crops -- not on ground-truth crops. This module runs a resolved localization
:class:`~notebooks.common.model_registry.ModelBundle` (ONNX) over a base
classification manifest, materializes the predicted crops to disk, and writes a
``predicted_crops.csv`` manifest consumed by the classification dataset.

The crop manifest columns follow the perception spec::

    split, image_path, crop_path, label, label_name, source_image_path,
    pred_xmin, pred_ymin, pred_xmax, pred_ymax,
    pred_center_x, pred_center_y, pred_radius,
    localization_iou_if_available,
    localization_model_path, localization_model_artifact_dir
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence

from .datasets import (
    BBOX_COLUMNS,
    DEFAULT_MEAN,
    DEFAULT_STD,
    _crop_normalized_bbox,
    _resolve_image_path,
    circle_from_row,
    detect_circle_schema,
    detect_ellipse_schema,
    ellipse_from_row,
    read_csv_manifest,
)
from .metrics import ellipse_to_aabb
from .model_registry import LOCALIZATION_TASKS, ModelBundle

CROP_MANIFEST_COLUMNS = (
    "split",
    "image_path",
    "crop_path",
    "label",
    "label_name",
    "source_image_path",
    "pred_xmin",
    "pred_ymin",
    "pred_xmax",
    "pred_ymax",
    "pred_center_x",
    "pred_center_y",
    "pred_radius",
    "localization_iou_if_available",
    "localization_model_path",
    "localization_model_artifact_dir",
)


def _require_numpy():
    try:
        import numpy as np
    except ImportError as exc:  # pragma: no cover - exercised only without numpy
        raise RuntimeError("Install numpy to generate predicted crops.") from exc
    return np


def _require_pillow():
    try:
        from PIL import Image
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("Install pillow to generate predicted crops.") from exc
    return Image


def task_kind_for_bundle(bundle: ModelBundle, explicit: str | None = None) -> str:
    """Return ``"bbox"`` or ``"circle"`` for a localization bundle."""

    if explicit in ("bbox", "circle"):
        return explicit
    kind = LOCALIZATION_TASKS.get(bundle.task_name)
    if kind is None:
        raise ValueError(
            f"Cannot infer localization kind for task '{bundle.task_name}'. "
            "Pass task_kind='bbox' or 'circle' explicitly."
        )
    return kind


class OnnxLocalizer:
    """Run an ONNX localization model and return its raw output vector."""

    def __init__(self, bundle: ModelBundle) -> None:
        if bundle.onnx_path is None or not Path(bundle.onnx_path).exists():
            raise FileNotFoundError(
                f"Localization bundle for '{bundle.task_name}' has no ONNX model "
                f"(artifact_dir={bundle.artifact_dir}). Predicted crops require an ONNX export."
            )
        try:
            import onnxruntime as ort
        except ImportError as exc:
            raise RuntimeError(
                "Install onnxruntime to generate predicted crops: pip install onnxruntime"
            ) from exc
        np = _require_numpy()
        self.session = ort.InferenceSession(
            str(bundle.onnx_path), providers=["CPUExecutionProvider"]
        )
        metadata = bundle.load_metadata()
        input_shape = metadata.get("input_shape") or [1, 3, 64, 64]
        self.height = int(input_shape[2]) if len(input_shape) == 4 else 64
        self.width = int(input_shape[3]) if len(input_shape) == 4 else 64
        self.mean = np.asarray(metadata.get("mean") or DEFAULT_MEAN, dtype=np.float32).reshape(3, 1, 1)
        self.std = np.asarray(metadata.get("std") or DEFAULT_STD, dtype=np.float32).reshape(3, 1, 1)
        self.input_name = self.session.get_inputs()[0].name

    def predict(self, image) -> "list[float]":
        np = _require_numpy()
        Image = _require_pillow()
        rgb = image.convert("RGB").resize((self.width, self.height), Image.BILINEAR)
        array = np.asarray(rgb, dtype=np.float32) / 255.0
        tensor = np.transpose(array, (2, 0, 1))
        tensor = (tensor - self.mean) / self.std
        outputs = self.session.run(None, {self.input_name: tensor[None].astype(np.float32)})
        return np.asarray(outputs[0]).reshape(-1).astype(float).tolist()


def load_localizer(bundle: ModelBundle) -> OnnxLocalizer:
    """Load an ONNX localizer for a resolved bundle."""

    return OnnxLocalizer(bundle)


def _clamp01(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


def circle_to_bbox(circle: Sequence[float]) -> list[float]:
    """Convert a normalized ``[cx, cy, r]`` circle to a clamped bbox."""

    cx, cy, radius = (float(value) for value in circle)
    xmin = _clamp01(cx - radius)
    ymin = _clamp01(cy - radius)
    xmax = _clamp01(cx + radius)
    ymax = _clamp01(cy + radius)
    if xmax <= xmin or ymax <= ymin:
        return [0.0, 0.0, 1.0, 1.0]
    return [xmin, ymin, xmax, ymax]


def normalize_ellipse(raw: Sequence[float], min_radius: float = 1e-3) -> list[float]:
    """Clamp/normalize a raw 7-value ellipse prediction.

    Ensures ``cx, cy, ratio`` in ``[0, 1]``, positive radii with
    ``major >= minor`` and unit-norm ``(sin, cos)``.
    """

    import math as _math

    cx, cy = _clamp01(raw[0]), _clamp01(raw[1])
    major = max(min_radius, float(raw[2]))
    minor = max(min_radius, float(raw[3]))
    if minor > major:
        major, minor = minor, major
    sin_a, cos_a = float(raw[4]), float(raw[5])
    norm = _math.hypot(sin_a, cos_a) or 1.0
    sin_a, cos_a = sin_a / norm, cos_a / norm
    ratio = _clamp01(raw[6]) if len(raw) > 6 else _clamp01(minor / major if major > 0 else 1.0)
    return [cx, cy, major, minor, sin_a, cos_a, ratio]


def ellipse_to_bbox(ellipse: Sequence[float]) -> list[float]:
    """Convert a normalized 7-value ellipse to a clamped axis-aligned bbox."""

    xmin, ymin, xmax, ymax = ellipse_to_aabb(ellipse)
    xmin, ymin, xmax, ymax = _clamp01(xmin), _clamp01(ymin), _clamp01(xmax), _clamp01(ymax)
    if xmax <= xmin or ymax <= ymin:
        return [0.0, 0.0, 1.0, 1.0]
    return [xmin, ymin, xmax, ymax]


def _gt_value(row: Mapping[str, str], task_kind: str, schema) -> list[float] | None:
    """Ground-truth bbox/circle/ellipse from a base manifest row, if present."""

    if task_kind == "bbox":
        if not set(BBOX_COLUMNS) <= set(row.keys()):
            return None
        try:
            return [float(row[name]) for name in BBOX_COLUMNS]
        except (TypeError, ValueError):
            return None
    if schema is None:
        return None
    if task_kind == "ellipse":
        try:
            width = float(row.get("image_width", 64) or 64)
            height = float(row.get("image_height", 64) or 64)
            return list(ellipse_from_row(row, schema, width, height))
        except (TypeError, ValueError, KeyError):
            return None
    try:
        return list(circle_from_row(row, schema))
    except (TypeError, ValueError, KeyError):
        return None


def _iou(pred: list[float], gt: list[float], task_kind: str) -> float | None:
    if task_kind == "ellipse":
        a, b = ellipse_to_aabb(pred), ellipse_to_aabb(gt)
        ix0, iy0 = max(a[0], b[0]), max(a[1], b[1])
        ix1, iy1 = min(a[2], b[2]), min(a[3], b[3])
        inter = max(0.0, ix1 - ix0) * max(0.0, iy1 - iy0)
        area_a = max(0.0, a[2] - a[0]) * max(0.0, a[3] - a[1])
        area_b = max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])
        union = area_a + area_b - inter
        return inter / union if union > 0 else 0.0
    try:
        import torch
    except ImportError:
        return None
    from .losses import bbox_iou, circle_iou

    pred_tensor = torch.tensor([pred], dtype=torch.float32)
    gt_tensor = torch.tensor([gt], dtype=torch.float32)
    if task_kind == "bbox":
        return float(bbox_iou(pred_tensor, gt_tensor)[0])
    return float(circle_iou(pred_tensor, gt_tensor)[0])


def _safe_crop_name(split: str, image_path: str) -> str:
    stem = image_path.replace("\\", "/").replace("/", "__")
    return f"{split}__{stem}"


def predict_bboxes_for_manifest(
    manifest_path: str | Path,
    bundle: ModelBundle,
    *,
    dataset_root: str | Path | None = None,
    splits: Sequence[str] | None = None,
) -> dict[tuple[str, str], list[float]]:
    """Predict a normalized bbox per ``(split, image_path)`` row."""

    return _predict_for_manifest(manifest_path, bundle, "bbox", dataset_root, splits)


def predict_circles_for_manifest(
    manifest_path: str | Path,
    bundle: ModelBundle,
    *,
    dataset_root: str | Path | None = None,
    splits: Sequence[str] | None = None,
) -> dict[tuple[str, str], list[float]]:
    """Predict a normalized ``[cx, cy, r]`` per ``(split, image_path)`` row."""

    return _predict_for_manifest(manifest_path, bundle, "circle", dataset_root, splits)


def predict_ellipses_for_manifest(
    manifest_path: str | Path,
    bundle: ModelBundle,
    *,
    dataset_root: str | Path | None = None,
    splits: Sequence[str] | None = None,
) -> dict[tuple[str, str], list[float]]:
    """Predict a normalized 7-value ellipse per ``(split, image_path)`` row."""

    return _predict_for_manifest(manifest_path, bundle, "ellipse", dataset_root, splits)


def _predict_for_manifest(
    manifest_path, bundle, task_kind, dataset_root, splits
) -> dict[tuple[str, str], list[float]]:
    Image = _require_pillow()
    manifest_path = Path(manifest_path)
    localizer = load_localizer(bundle)
    rows = read_csv_manifest(manifest_path)
    selected = set(splits) if splits else None
    predictions: dict[tuple[str, str], list[float]] = {}
    for row in rows:
        split = row.get("split", "")
        if selected is not None and split not in selected:
            continue
        image_path = _resolve_image_path(row["image_path"], split, manifest_path, dataset_root)
        with Image.open(image_path) as image:
            raw = localizer.predict(image)
        if task_kind == "bbox":
            predictions[(split, row["image_path"])] = [_clamp01(v) for v in raw[:4]]
        elif task_kind == "ellipse":
            predictions[(split, row["image_path"])] = normalize_ellipse(raw[:7])
        else:
            cx, cy, radius = raw[0], raw[1], raw[2]
            predictions[(split, row["image_path"])] = [_clamp01(cx), _clamp01(cy), max(0.0, float(radius))]
    return predictions


def crop_image_with_bbox(image, bbox: Sequence[float], padding: float = 0.0):
    """Return the cropped PIL image for a normalized bbox."""

    return _crop_normalized_bbox(image.convert("RGB"), list(bbox), padding=padding)


def crop_image_with_circle(image, circle: Sequence[float], padding: float = 0.0):
    """Return the cropped PIL image for a normalized circle (via its bbox)."""

    return _crop_normalized_bbox(image.convert("RGB"), circle_to_bbox(circle), padding=padding)


def crop_image_with_ellipse(image, ellipse: Sequence[float], padding: float = 0.0):
    """Return the cropped PIL image for a normalized ellipse (via its bbox)."""

    return _crop_normalized_bbox(
        image.convert("RGB"), ellipse_to_bbox(normalize_ellipse(ellipse)), padding=padding
    )


@dataclass
class CropGenerationReport:
    manifest_path: Path
    num_crops: int
    num_errors: int
    errors: list[str]
    splits: dict[str, int]
    localization_task: str
    localization_model_path: str
    localization_model_artifact_dir: str
    reused_existing: bool
    mean_iou: float | None = None

    def to_dict(self) -> dict:
        return {
            "crop_manifest_path": str(self.manifest_path),
            "num_crops": self.num_crops,
            "num_errors": self.num_errors,
            "errors": self.errors,
            "splits": self.splits,
            "localization_task": self.localization_task,
            "localization_model_path": self.localization_model_path,
            "localization_model_artifact_dir": self.localization_model_artifact_dir,
            "reused_existing": self.reused_existing,
            "mean_iou": self.mean_iou,
        }


def load_crop_manifest(path: str | Path) -> list[dict[str, str]]:
    """Load a previously generated ``predicted_crops.csv`` manifest."""

    return read_csv_manifest(path)


def generate_predicted_crop_manifest(
    base_manifest_path: str | Path,
    bundle: ModelBundle,
    output_dir: str | Path,
    *,
    task_kind: str | None = None,
    dataset_root: str | Path | None = None,
    padding: float = 0.05,
    regenerate: bool = False,
    manifest_filename: str = "predicted_crops.csv",
    splits: Sequence[str] | None = None,
) -> CropGenerationReport:
    """Run a localization bundle over a manifest and materialize predicted crops.

    Crops are written under ``<output_dir>/crops/`` for every split; the manifest
    is written to ``<output_dir>/<manifest_filename>`` with ``crop_path`` stored
    relative to that manifest. When the manifest already exists and
    ``regenerate`` is ``False``, it is reused as-is.
    """

    Image = _require_pillow()
    base_manifest_path = Path(base_manifest_path)
    output_dir = Path(output_dir)
    manifest_path = output_dir / manifest_filename
    kind = task_kind_for_bundle(bundle, task_kind)
    model_path = str(bundle.onnx_path) if bundle.onnx_path else ""
    artifact_dir = str(bundle.artifact_dir)

    if manifest_path.exists() and not regenerate:
        existing = read_csv_manifest(manifest_path)
        split_counts: dict[str, int] = {}
        for row in existing:
            split_counts[row.get("split", "")] = split_counts.get(row.get("split", ""), 0) + 1
        return CropGenerationReport(
            manifest_path=manifest_path,
            num_crops=len(existing),
            num_errors=0,
            errors=[],
            splits=split_counts,
            localization_task=kind,
            localization_model_path=model_path,
            localization_model_artifact_dir=artifact_dir,
            reused_existing=True,
        )

    localizer = load_localizer(bundle)
    rows = read_csv_manifest(base_manifest_path)
    if rows and kind == "circle":
        schema = detect_circle_schema(rows[0].keys())
    elif rows and kind == "ellipse":
        schema = detect_ellipse_schema(rows[0].keys())
    else:
        schema = None

    crops_dir = output_dir / "crops"
    crops_dir.mkdir(parents=True, exist_ok=True)

    selected = set(splits) if splits else None
    out_rows: list[dict[str, object]] = []
    errors: list[str] = []
    split_counts = {}
    ious: list[float] = []

    for row in rows:
        split = row.get("split", "")
        if selected is not None and split not in selected:
            continue
        rel_image = row.get("image_path", "")
        source_path = _resolve_image_path(rel_image, split, base_manifest_path, dataset_root)
        try:
            with Image.open(source_path) as image:
                rgb = image.convert("RGB")
                raw = localizer.predict(rgb)
                ellipse_value = None
                if kind == "bbox":
                    bbox = [_clamp01(v) for v in raw[:4]]
                    circle = [None, None, None]
                elif kind == "ellipse":
                    ellipse_value = normalize_ellipse(raw[:7])
                    bbox = ellipse_to_bbox(ellipse_value)
                    # Report center + major axis through the circle columns.
                    circle = [ellipse_value[0], ellipse_value[1], ellipse_value[2]]
                else:
                    circle = [_clamp01(raw[0]), _clamp01(raw[1]), max(0.0, float(raw[2]))]
                    bbox = circle_to_bbox(circle)
                crop = _crop_normalized_bbox(rgb, bbox, padding=padding)
                crop_name = _safe_crop_name(split, rel_image)
                if not crop_name.lower().endswith((".png", ".jpg", ".jpeg")):
                    crop_name += ".png"
                crop_abs = crops_dir / crop_name
                crop.save(crop_abs)
        except Exception as exc:  # noqa: BLE001 - report any per-row failure clearly
            errors.append(f"{split}/{rel_image}: {exc}")
            continue

        gt = _gt_value(row, kind, schema)
        if gt and kind == "bbox":
            iou = _iou(bbox, gt, "bbox")
        elif gt and kind == "circle":
            iou = _iou(circle, gt, "circle")
        elif gt and kind == "ellipse":
            iou = _iou(ellipse_value, gt, "ellipse")
        else:
            iou = None
        if iou is not None:
            ious.append(iou)

        out_rows.append(
            {
                "split": split,
                "image_path": rel_image,
                "crop_path": str(crop_abs.relative_to(output_dir)),
                "label": row.get("label", ""),
                "label_name": row.get("label_name", ""),
                "source_image_path": str(source_path),
                "pred_xmin": f"{bbox[0]:.6f}",
                "pred_ymin": f"{bbox[1]:.6f}",
                "pred_xmax": f"{bbox[2]:.6f}",
                "pred_ymax": f"{bbox[3]:.6f}",
                "pred_center_x": "" if circle[0] is None else f"{circle[0]:.6f}",
                "pred_center_y": "" if circle[1] is None else f"{circle[1]:.6f}",
                "pred_radius": "" if circle[2] is None else f"{circle[2]:.6f}",
                "localization_iou_if_available": "" if iou is None else f"{iou:.6f}",
                "localization_model_path": model_path,
                "localization_model_artifact_dir": artifact_dir,
            }
        )
        split_counts[split] = split_counts.get(split, 0) + 1

    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    with manifest_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(CROP_MANIFEST_COLUMNS))
        writer.writeheader()
        writer.writerows(out_rows)

    return CropGenerationReport(
        manifest_path=manifest_path,
        num_crops=len(out_rows),
        num_errors=len(errors),
        errors=errors,
        splits=split_counts,
        localization_task=kind,
        localization_model_path=model_path,
        localization_model_artifact_dir=artifact_dir,
        reused_existing=False,
        mean_iou=(sum(ious) / len(ious)) if ious else None,
    )
