"""Small synthetic dataset helper used by the smoke-test notebook."""

from __future__ import annotations

import csv
import random
from pathlib import Path

import numpy as np

from .config import get_dataset_root, get_manifest_root


SPLITS = ("train", "validation", "test")
VICTIM_LABELS = ("harmed", "unharmed", "stable")
ALL_LABELS = ("none", "harmed", "unharmed", "stable", "cognitive")
SAMPLES_PER_SPLIT = {"train": 6, "validation": 2, "test": 2}


def _has_images(dataset_root: Path) -> bool:
    return dataset_root.exists() and any(dataset_root.glob("*/*/images/*.png"))


def _write_csv(path: Path, fieldnames: tuple[str, ...], rows: list[dict[str, str | int | float]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _base_canvas(input_size: int):
    from PIL import Image, ImageDraw

    image = Image.new("RGB", (input_size, input_size), (18, 18, 18))
    draw = ImageDraw.Draw(image)
    for y in range(0, input_size, 8):
        tone = 24 + (y % 16)
        draw.rectangle((0, y, input_size, min(input_size - 1, y + 7)), fill=(tone, tone, tone))
    return image


def _draw_none(image):
    from PIL import ImageDraw

    draw = ImageDraw.Draw(image)
    draw.rectangle((6, 6, image.width - 7, image.height - 7), outline=(42, 42, 42), width=1)
    return image, None


def _victim_bbox(index: int, input_size: int) -> tuple[int, int, int, int]:
    offsets = [(14, 14), (18, 16), (12, 20), (20, 12), (16, 18)]
    scale = input_size / 64
    x1, y1 = offsets[index % len(offsets)]
    size = 28
    return int(x1 * scale), int(y1 * scale), int((x1 + size) * scale), int((y1 + size) * scale)


def _draw_victim(image, color: tuple[int, int, int], index: int):
    from PIL import ImageDraw

    x1, y1, x2, y2 = _victim_bbox(index, image.width)
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((x1, y1, x2, y2), radius=6, fill=color, outline=(240, 240, 240), width=2)
    draw.line((x1 + 7, y1 + 10, x2 - 7, y2 - 10), fill=(255, 255, 255), width=2)
    bbox = (x1 / image.width, y1 / image.height, x2 / image.width, y2 / image.height)
    return image, bbox


def _draw_target(image, index: int):
    from PIL import ImageDraw

    draw = ImageDraw.Draw(image)
    cx = image.width // 2 + ((index % 3) - 1) * 2
    cy = image.height // 2 + (((index // 3) % 3) - 1) * 2
    rings = [
        (14, (0, 0, 0)),
        (11, (210, 40, 40)),
        (8, (235, 210, 50)),
        (5, (50, 170, 80)),
        (2, (60, 110, 220)),
    ]
    scale = image.width / 64
    for radius, color in rings:
        radius = int(radius * scale)
        draw.ellipse((cx - radius, cy - radius, cx + radius, cy + radius), fill=color)
    return image, None


def _noise(image, seed: int):
    from PIL import Image

    rng = np.random.default_rng(seed)
    array = np.asarray(image, dtype=np.int16)
    jitter = rng.integers(-6, 7, size=array.shape, endpoint=False)
    array = np.clip(array + jitter, 0, 255).astype(np.uint8)
    return Image.fromarray(array, mode="RGB")


def ensure_smoke_dataset(dataset_name: str = "smoke_dataset_v001", input_size: int = 64, overwrite: bool = False) -> Path:
    """Create a tiny local smoke dataset when it is not already present."""

    dataset_root = get_dataset_root(dataset_name)
    manifest_root = get_manifest_root(dataset_name)
    expected_manifests = [
        manifest_root / "presence.csv",
        manifest_root / "object_type.csv",
        manifest_root / "victim_classification.csv",
        manifest_root / "victim_bbox.csv",
    ]
    if not overwrite and _has_images(dataset_root) and all(path.exists() for path in expected_manifests):
        return dataset_root

    dataset_root.mkdir(parents=True, exist_ok=True)
    manifest_root.mkdir(parents=True, exist_ok=True)

    presence_rows: list[dict[str, str | int | float]] = []
    object_type_rows: list[dict[str, str | int | float]] = []
    victim_rows: list[dict[str, str | int | float]] = []
    bbox_rows: list[dict[str, str | int | float]] = []
    colors = {
        "harmed": (220, 70, 70),
        "unharmed": (70, 190, 95),
        "stable": (70, 110, 220),
    }
    generator = random.Random(2026)

    for split in SPLITS:
        for label_name in ALL_LABELS:
            image_dir = dataset_root / split / label_name / "images"
            image_dir.mkdir(parents=True, exist_ok=True)
            for sample_index in range(SAMPLES_PER_SPLIT[split]):
                image = _base_canvas(input_size)
                global_index = generator.randint(0, 10_000)
                bbox = None
                if label_name == "none":
                    image, bbox = _draw_none(image)
                elif label_name == "cognitive":
                    image, bbox = _draw_target(image, global_index)
                else:
                    image, bbox = _draw_victim(image, colors[label_name], global_index)
                image = _noise(image, global_index)
                image_name = f"{label_name}_{sample_index:03d}.png"
                image.save(image_dir / image_name)
                rel_path = f"{label_name}/images/{image_name}"

                presence_rows.append(
                    {
                        "split": split,
                        "image_path": rel_path,
                        "label": 0 if label_name == "none" else 1,
                        "label_name": "none" if label_name == "none" else "object",
                    }
                )
                if label_name != "none":
                    object_type_rows.append(
                        {
                            "split": split,
                            "image_path": rel_path,
                            "label": 0 if label_name == "cognitive" else 1,
                            "label_name": "target" if label_name == "cognitive" else "victim",
                        }
                    )
                if label_name in VICTIM_LABELS:
                    label_index = VICTIM_LABELS.index(label_name)
                    victim_rows.append(
                        {
                            "split": split,
                            "image_path": rel_path,
                            "label": label_index,
                            "label_name": label_name,
                        }
                    )
                    if bbox is None:
                        raise RuntimeError("Internal smoke dataset error: victim bbox is missing.")
                    bbox_rows.append(
                        {
                            "split": split,
                            "image_path": rel_path,
                            "label": label_index,
                            "label_name": label_name,
                            "xmin": f"{bbox[0]:.6f}",
                            "ymin": f"{bbox[1]:.6f}",
                            "xmax": f"{bbox[2]:.6f}",
                            "ymax": f"{bbox[3]:.6f}",
                        }
                    )

    _write_csv(manifest_root / "presence.csv", ("split", "image_path", "label", "label_name"), presence_rows)
    _write_csv(manifest_root / "object_type.csv", ("split", "image_path", "label", "label_name"), object_type_rows)
    _write_csv(manifest_root / "victim_classification.csv", ("split", "image_path", "label", "label_name"), victim_rows)
    _write_csv(
        manifest_root / "victim_bbox.csv",
        ("split", "image_path", "label", "label_name", "xmin", "ymin", "xmax", "ymax"),
        bbox_rows,
    )
    return dataset_root
