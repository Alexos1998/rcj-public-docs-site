"""ONNX graph validation and ONNXRuntime parity checks."""

from __future__ import annotations

from pathlib import Path
from typing import Sequence


def validate_onnx_structure(onnx_path: str | Path) -> dict:
    """Validate ONNX graph structure and print model IO names."""

    try:
        import onnx
    except ImportError as exc:
        raise RuntimeError("Install onnx to validate exported models.") from exc

    path = Path(onnx_path)
    model = onnx.load(path)
    onnx.checker.check_model(model)
    input_names = [node.name for node in model.graph.input]
    output_names = [node.name for node in model.graph.output]
    print("ONNX input names:", input_names)
    print("ONNX output names:", output_names)
    return {"path": path, "input_names": input_names, "output_names": output_names}


def _torch_outputs_to_numpy(outputs) -> list:
    if not isinstance(outputs, (tuple, list)):
        outputs = [outputs]
    return [output.detach().cpu().numpy() for output in outputs]


def compare_pytorch_onnx(
    model,
    onnx_path: str | Path,
    input_shape: Sequence[int],
    atol: float = 1e-4,
    rtol: float = 1e-3,
) -> dict:
    """Compare PyTorch model outputs against ONNXRuntime outputs."""

    try:
        import numpy as np
        import onnxruntime as ort
        import torch
    except ImportError as exc:
        raise RuntimeError("Install torch, numpy, and onnxruntime to compare model outputs.") from exc

    structure = validate_onnx_structure(onnx_path)
    session = ort.InferenceSession(str(onnx_path), providers=["CPUExecutionProvider"])
    input_name = session.get_inputs()[0].name
    input_shape = [int(dim) for dim in input_shape]
    dummy_input = torch.randn(*input_shape)

    model.eval()
    with torch.no_grad():
        torch_outputs = _torch_outputs_to_numpy(model(dummy_input))
    onnx_outputs = session.run(None, {input_name: dummy_input.cpu().numpy().astype(np.float32)})

    if len(torch_outputs) != len(onnx_outputs):
        raise AssertionError(
            f"Output count mismatch: PyTorch={len(torch_outputs)} ONNXRuntime={len(onnx_outputs)}"
        )

    max_abs_differences = []
    passed_outputs = []
    for torch_output, onnx_output in zip(torch_outputs, onnx_outputs):
        diff = float(np.max(np.abs(torch_output - onnx_output))) if torch_output.size else 0.0
        max_abs_differences.append(diff)
        passed_outputs.append(bool(np.allclose(torch_output, onnx_output, atol=atol, rtol=rtol)))

    first_torch_shape = list(torch_outputs[0].shape)
    first_onnx_shape = list(onnx_outputs[0].shape)
    max_abs_difference = max(max_abs_differences) if max_abs_differences else 0.0
    passed = all(passed_outputs)

    print("PyTorch output shape:", first_torch_shape)
    print("ONNX output shape:", first_onnx_shape)
    print("max absolute difference:", max_abs_difference)
    print("comparison passed:", passed)

    return {
        **structure,
        "pytorch_output_shape": first_torch_shape,
        "onnx_output_shape": first_onnx_shape,
        "max_abs_difference": max_abs_difference,
        "all_max_abs_differences": max_abs_differences,
        "passed": passed,
        "atol": atol,
        "rtol": rtol,
    }


def check_onnx_model(path: str | Path) -> Path:
    """Backward-compatible structural validation helper."""

    validate_onnx_structure(path)
    return Path(path)


def run_onnxruntime(path: str | Path, input_array):
    """Execute an ONNX model once with onnxruntime."""

    try:
        import onnxruntime as ort
    except ImportError as exc:
        raise RuntimeError("Install onnxruntime to run exported models.") from exc

    session = ort.InferenceSession(str(path), providers=["CPUExecutionProvider"])
    input_name = session.get_inputs()[0].name
    return session.run(None, {input_name: input_array})

