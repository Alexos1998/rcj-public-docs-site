"""Lightweight CNN fallback for whole-target mask segmentation.

Only used when the Random Forest baseline cannot reach the acceptance IoU (or
``--force-cnn`` is set). :class:`MiniTargetMaskNet` is a small full-resolution
conv net (3x64x64 -> 1x64x64 logits, depthwise-separable blocks, no big U-Net)
that exports cleanly to ONNX. :class:`TargetMaskCNN` wraps it with the same
``predict_proba_map`` / ``predict_mask`` / ``save`` / ``load`` interface as
:class:`~notebooks.common.target_mask_rf.TargetMaskRandomForest`, so the runtime
and selection code treat the two segmenters interchangeably.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


def _require_torch():
    try:
        import torch
    except ImportError as exc:  # pragma: no cover - environment guard
        raise RuntimeError("Install torch to train/use the CNN target segmenter.") from exc
    return torch


def _build_net(base_channels: int = 16):
    import torch.nn as nn

    def dw_block(cin: int, cout: int) -> nn.Sequential:
        return nn.Sequential(
            nn.Conv2d(cin, cin, 3, padding=1, groups=cin, bias=False),
            nn.Conv2d(cin, cout, 1, bias=False),
            nn.BatchNorm2d(cout),
            nn.ReLU(inplace=True),
        )

    class MiniTargetMaskNet(nn.Module):
        """3x64x64 -> 1x64x64 binary-target logits (resolution preserved)."""

        def __init__(self, base: int = base_channels) -> None:
            super().__init__()
            self.stem = nn.Sequential(
                nn.Conv2d(3, base, 3, padding=1, bias=False),
                nn.BatchNorm2d(base),
                nn.ReLU(inplace=True),
            )
            self.block1 = dw_block(base, base * 2)
            self.block2 = dw_block(base * 2, base * 2)
            self.block3 = dw_block(base * 2, base)
            self.head = nn.Conv2d(base, 1, 1)

        def forward(self, x):
            x = self.stem(x)
            x = self.block1(x)
            x = self.block2(x)
            x = self.block3(x)
            return self.head(x)

    return MiniTargetMaskNet()


@dataclass
class TargetMaskCNNConfig:
    epochs: int = 20
    lr: float = 1e-3
    batch_size: int = 16
    base_channels: int = 16
    dice_weight: float = 1.0
    proba_threshold: float = 0.5
    postprocess: bool = True
    device: str = "auto"
    random_state: int = 42


def _dice_loss(probs, target, eps: float = 1e-6):
    intersection = (probs * target).sum(dim=(1, 2, 3))
    union = probs.sum(dim=(1, 2, 3)) + target.sum(dim=(1, 2, 3))
    return (1.0 - (2.0 * intersection + eps) / (union + eps)).mean()


class TargetMaskCNN:
    """Train/predict a whole-target binary mask with :class:`MiniTargetMaskNet`."""

    def __init__(self, config: TargetMaskCNNConfig | None = None, model=None) -> None:
        self.config = config or TargetMaskCNNConfig()
        self.model = model

    def _device(self):
        torch = _require_torch()
        if self.config.device != "auto":
            return torch.device(self.config.device)
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")

    @staticmethod
    def _to_tensor_image(image, torch):
        arr = np.asarray(image)[:, :, :3].astype(np.float32) / 255.0
        return torch.from_numpy(arr).permute(2, 0, 1)

    def fit(self, images, masks) -> "TargetMaskCNN":
        torch = _require_torch()
        import torch.nn.functional as F

        torch.manual_seed(self.config.random_state)
        device = self._device()
        x = torch.stack([self._to_tensor_image(im, torch) for im in images])
        y = torch.stack(
            [torch.from_numpy(np.asarray(m).astype(np.float32))[None, ...] for m in masks]
        )
        self.model = _build_net(self.config.base_channels).to(device)
        optimizer = torch.optim.Adam(self.model.parameters(), lr=self.config.lr)
        n = x.shape[0]
        self.model.train()
        for _ in range(self.config.epochs):
            perm = torch.randperm(n)
            for start in range(0, n, self.config.batch_size):
                idx = perm[start : start + self.config.batch_size]
                xb, yb = x[idx].to(device), y[idx].to(device)
                logits = self.model(xb)
                loss = F.binary_cross_entropy_with_logits(logits, yb)
                loss = loss + self.config.dice_weight * _dice_loss(torch.sigmoid(logits), yb)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
        self.model.eval()
        return self

    def predict_proba_map(self, image) -> np.ndarray:
        torch = _require_torch()
        if self.model is None:
            raise RuntimeError("Model is not trained or loaded.")
        device = self._device()
        self.model.to(device).eval()
        with torch.no_grad():
            tensor = self._to_tensor_image(image, torch)[None, ...].to(device)
            proba = torch.sigmoid(self.model(tensor))[0, 0].cpu().numpy()
        return proba

    def predict_mask(self, image, postprocess: bool | None = None) -> np.ndarray:
        from .target_mask_rf import TargetMaskRandomForest

        proba = self.predict_proba_map(image)
        mask = proba >= self.config.proba_threshold
        do_post = self.config.postprocess if postprocess is None else postprocess
        if do_post and mask.any():
            mask = TargetMaskRandomForest._postprocess(mask)
        return mask

    # -- persistence -------------------------------------------------------- #

    def save(self, path) -> "Path":
        from pathlib import Path

        torch = _require_torch()
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        torch.save({"config": self.config, "state_dict": self.model.state_dict()}, path)
        return path

    @classmethod
    def load(cls, path) -> "TargetMaskCNN":
        torch = _require_torch()
        payload = torch.load(path, map_location="cpu", weights_only=False)
        config = payload.get("config", TargetMaskCNNConfig())
        instance = cls(config)
        instance.model = _build_net(config.base_channels)
        instance.model.load_state_dict(payload["state_dict"])
        instance.model.eval()
        return instance

    def export_onnx(self, path) -> "Path":
        from .onnx_export import export_onnx_model

        self.model.to("cpu").eval()
        return export_onnx_model(
            self.model,
            path,
            input_shape=(1, 3, 64, 64),
            input_names=("input",),
            output_names=("mask_logits",),
            extra_metadata={"task_name": "target_mask", "output_schema": "binary_mask_logits_1x64x64"},
        )

    @property
    def model_size_bytes(self) -> int:
        torch = _require_torch()
        import io

        buffer = io.BytesIO()
        torch.save(self.model.state_dict(), buffer)
        return buffer.tell()
