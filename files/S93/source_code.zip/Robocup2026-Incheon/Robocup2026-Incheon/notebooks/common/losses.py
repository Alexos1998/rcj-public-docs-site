"""Loss functions and IoU helpers for localization models.

Kept in one module so training routines and the Optuna trials build losses the
same way from a config. ``SAIoULoss`` preserves the legacy behaviour (default
lambdas unchanged) while everything is now configurable through factories.
"""

from __future__ import annotations

import math
from typing import Any

try:
    import torch
    import torch.nn.functional as F
    from torch import nn
except ImportError:  # pragma: no cover - torch required at training time
    torch = None
    F = None  # type: ignore[assignment]

    class nn:  # type: ignore[no-redef]
        class Module:  # minimal shim so the module imports without torch
            pass


def bbox_iou(preds, targets, eps: float = 1e-7):
    """Vectorised IoU for normalized ``[xmin, ymin, xmax, ymax]`` boxes."""

    x1 = torch.maximum(preds[:, 0], targets[:, 0])
    y1 = torch.maximum(preds[:, 1], targets[:, 1])
    x2 = torch.minimum(preds[:, 2], targets[:, 2])
    y2 = torch.minimum(preds[:, 3], targets[:, 3])
    inter = (x2 - x1).clamp(min=0) * (y2 - y1).clamp(min=0)
    pred_area = (preds[:, 2] - preds[:, 0]).clamp(min=0) * (
        preds[:, 3] - preds[:, 1]
    ).clamp(min=0)
    target_area = (targets[:, 2] - targets[:, 0]).clamp(min=0) * (
        targets[:, 3] - targets[:, 1]
    ).clamp(min=0)
    union = pred_area + target_area - inter
    return inter / (union + eps)


def circle_iou(preds, targets, eps: float = 1e-7):
    """Analytic IoU between two circles given ``[cx, cy, r]`` per sample.

    Differentiable everywhere except at the degenerate boundaries, where the
    ``acos`` arguments are clamped away from ``±1``.
    """

    cx0, cy0, r0 = preds[:, 0], preds[:, 1], preds[:, 2].clamp(min=eps)
    cx1, cy1, r1 = targets[:, 0], targets[:, 1], targets[:, 2].clamp(min=eps)
    d = torch.sqrt(((cx0 - cx1) ** 2 + (cy0 - cy1) ** 2).clamp(min=0) + eps)

    area0 = math.pi * r0 ** 2
    area1 = math.pi * r1 ** 2

    # Lens (overlap) area of two circles, computed for the general case and then
    # corrected for the fully-contained / fully-separate cases.
    cos0 = ((d ** 2 + r0 ** 2 - r1 ** 2) / (2 * d * r0)).clamp(-1 + 1e-6, 1 - 1e-6)
    cos1 = ((d ** 2 + r1 ** 2 - r0 ** 2) / (2 * d * r1)).clamp(-1 + 1e-6, 1 - 1e-6)
    alpha = torch.acos(cos0)
    beta = torch.acos(cos1)
    tri = 0.5 * torch.sqrt(
        ((-d + r0 + r1) * (d + r0 - r1) * (d - r0 + r1) * (d + r0 + r1)).clamp(min=0) + eps
    )
    lens = r0 ** 2 * alpha + r1 ** 2 * beta - tri

    contained = torch.minimum(area0, area1)
    separate = torch.zeros_like(d)
    inter = torch.where(d <= (r0 - r1).abs(), contained, lens)
    inter = torch.where(d >= (r0 + r1), separate, inter)

    union = area0 + area1 - inter
    return (inter / (union + eps)).clamp(0.0, 1.0)


class SAIoULoss(nn.Module):
    """Legacy-inspired bbox loss: IoU penalty plus center and corner distances."""

    def __init__(
        self,
        lambda_center: float = 1.529124973633597,
        lambda_corner: float = 1.151321268161352,
    ) -> None:
        super().__init__()
        self.lambda_center = float(lambda_center)
        self.lambda_corner = float(lambda_corner)

    def forward(self, preds, targets):
        iou = bbox_iou(preds, targets, eps=1.0e-6)
        pred_center = (preds[:, :2] + preds[:, 2:]) / 2.0
        target_center = (targets[:, :2] + targets[:, 2:]) / 2.0
        center_distance = torch.linalg.vector_norm(pred_center - target_center, ord=2, dim=1)
        pred_corners = torch.stack([preds[:, :2], preds[:, 2:]], dim=1)
        target_corners = torch.stack([targets[:, :2], targets[:, 2:]], dim=1)
        corner_distance = torch.linalg.vector_norm(
            pred_corners - target_corners, ord=2, dim=2
        ).mean(dim=1)
        loss = (
            1.0 - iou
            + self.lambda_center * center_distance
            + self.lambda_corner * corner_distance
        )
        return loss.mean()


class GIoULoss(nn.Module):
    """Generalized IoU loss for normalized ``[xmin, ymin, xmax, ymax]`` boxes."""

    def __init__(self, eps: float = 1e-7) -> None:
        super().__init__()
        self.eps = float(eps)

    def forward(self, preds, targets):
        eps = self.eps
        x1 = torch.maximum(preds[:, 0], targets[:, 0])
        y1 = torch.maximum(preds[:, 1], targets[:, 1])
        x2 = torch.minimum(preds[:, 2], targets[:, 2])
        y2 = torch.minimum(preds[:, 3], targets[:, 3])
        inter = (x2 - x1).clamp(min=0) * (y2 - y1).clamp(min=0)
        pred_area = (preds[:, 2] - preds[:, 0]).clamp(min=0) * (
            preds[:, 3] - preds[:, 1]
        ).clamp(min=0)
        target_area = (targets[:, 2] - targets[:, 0]).clamp(min=0) * (
            targets[:, 3] - targets[:, 1]
        ).clamp(min=0)
        union = pred_area + target_area - inter + eps
        iou = inter / union

        # Smallest enclosing box.
        cx1 = torch.minimum(preds[:, 0], targets[:, 0])
        cy1 = torch.minimum(preds[:, 1], targets[:, 1])
        cx2 = torch.maximum(preds[:, 2], targets[:, 2])
        cy2 = torch.maximum(preds[:, 3], targets[:, 3])
        enclosing = (cx2 - cx1).clamp(min=0) * (cy2 - cy1).clamp(min=0) + eps
        giou = iou - (enclosing - union) / enclosing
        return (1.0 - giou).mean()


class CombinedBBoxLoss(nn.Module):
    """Weighted sum of :class:`SAIoULoss` and ``SmoothL1Loss``."""

    def __init__(
        self,
        saiou_weight: float = 1.0,
        smooth_l1_weight: float = 0.25,
        lambda_center: float = 1.529124973633597,
        lambda_corner: float = 1.151321268161352,
    ) -> None:
        super().__init__()
        self.saiou_weight = float(saiou_weight)
        self.smooth_l1_weight = float(smooth_l1_weight)
        self.saiou = SAIoULoss(lambda_center=lambda_center, lambda_corner=lambda_corner)
        self.smooth_l1 = nn.SmoothL1Loss()

    def forward(self, preds, targets):
        return (
            self.saiou_weight * self.saiou(preds, targets)
            + self.smooth_l1_weight * self.smooth_l1(preds, targets)
        )


class BBoxShapeLoss(nn.Module):
    """SAIoU + SmoothL1 on coords, size, and aspect ratio.

    The aspect loss uses log-ratio so that e.g. 2:1 and 1:2 are equally penalized.
    """

    def __init__(
        self,
        saiou_weight: float = 1.0,
        smooth_l1_weight: float = 0.25,
        size_weight: float = 1.0,
        aspect_weight: float = 0.5,
        lambda_center: float = 1.529124973633597,
        lambda_corner: float = 1.151321268161352,
    ) -> None:
        super().__init__()
        self.saiou = SAIoULoss(lambda_center=lambda_center, lambda_corner=lambda_corner)
        self.smooth_l1 = nn.SmoothL1Loss()
        self.saiou_weight = float(saiou_weight)
        self.smooth_l1_weight = float(smooth_l1_weight)
        self.size_weight = float(size_weight)
        self.aspect_weight = float(aspect_weight)

    def forward(self, preds, targets):
        pred_w = (preds[:, 2] - preds[:, 0]).clamp(min=1e-6)
        pred_h = (preds[:, 3] - preds[:, 1]).clamp(min=1e-6)
        target_w = (targets[:, 2] - targets[:, 0]).clamp(min=1e-6)
        target_h = (targets[:, 3] - targets[:, 1]).clamp(min=1e-6)

        coord_loss = self.smooth_l1(preds, targets)
        size_loss = F.smooth_l1_loss(
            torch.stack([pred_w, pred_h], dim=1),
            torch.stack([target_w, target_h], dim=1),
        )
        pred_ratio = torch.log(pred_w / pred_h)
        target_ratio = torch.log(target_w / target_h)
        aspect_loss = F.smooth_l1_loss(pred_ratio, target_ratio)

        return (
            self.saiou_weight * self.saiou(preds, targets)
            + self.smooth_l1_weight * coord_loss
            + self.size_weight * size_loss
            + self.aspect_weight * aspect_loss
        )


def build_bbox_loss(cfg: Any):
    """Build the bbox loss from ``cfg.bbox_loss_name`` and its hyperparameters."""

    name = str(getattr(cfg, "bbox_loss_name", "saiou")).lower()
    if name == "saiou":
        return SAIoULoss(
            lambda_center=float(cfg.saiou_lambda_center),
            lambda_corner=float(cfg.saiou_lambda_corner),
        )
    if name == "smooth_l1":
        return nn.SmoothL1Loss()
    if name == "giou":
        return GIoULoss()
    if name == "combined":
        return CombinedBBoxLoss(
            saiou_weight=float(cfg.combined_saiou_weight),
            smooth_l1_weight=float(cfg.combined_smooth_l1_weight),
            lambda_center=float(cfg.saiou_lambda_center),
            lambda_corner=float(cfg.saiou_lambda_corner),
        )
    if name == "shape_combined":
        return BBoxShapeLoss(
            saiou_weight=float(cfg.combined_saiou_weight),
            smooth_l1_weight=float(cfg.combined_smooth_l1_weight),
            size_weight=float(cfg.shape_size_weight),
            aspect_weight=float(cfg.shape_aspect_weight),
            lambda_center=float(cfg.saiou_lambda_center),
            lambda_corner=float(cfg.saiou_lambda_corner),
        )
    raise ValueError(f"Unsupported bbox_loss_name: {cfg.bbox_loss_name!r}")


class CircleLoss(nn.Module):
    """Center + radius regression loss for ``[cx, cy, r]`` targets.

    ``combined`` adds a ``(1 - circle_iou)`` term on top of the SmoothL1 terms.
    """

    def __init__(
        self,
        center_weight: float = 1.0,
        radius_weight: float = 1.0,
        iou_weight: float = 0.0,
    ) -> None:
        super().__init__()
        self.center_weight = float(center_weight)
        self.radius_weight = float(radius_weight)
        self.iou_weight = float(iou_weight)
        self.smooth_l1 = nn.SmoothL1Loss()

    def forward(self, preds, targets):
        loss = (
            self.center_weight * self.smooth_l1(preds[:, :2], targets[:, :2])
            + self.radius_weight * self.smooth_l1(preds[:, 2:], targets[:, 2:])
        )
        if self.iou_weight > 0:
            loss = loss + self.iou_weight * (1.0 - circle_iou(preds, targets).mean())
        return loss


def build_circle_loss(cfg: Any):
    """Build the circle loss from ``cfg.circle_loss_name`` and its weights."""

    name = str(getattr(cfg, "circle_loss_name", "smooth_l1")).lower()
    if name == "smooth_l1":
        return CircleLoss(
            center_weight=float(cfg.circle_center_weight),
            radius_weight=float(cfg.circle_radius_weight),
            iou_weight=0.0,
        )
    if name == "combined":
        return CircleLoss(
            center_weight=float(cfg.circle_center_weight),
            radius_weight=float(cfg.circle_radius_weight),
            iou_weight=float(getattr(cfg, "combined_circle_iou_weight", 1.0)),
        )
    raise ValueError(f"Unsupported circle_loss_name: {cfg.circle_loss_name!r}")


# --------------------------------------------------------------------------- #
# Ellipse / perspective target localization.
# --------------------------------------------------------------------------- #


def ellipse_to_bbox(ellipse, eps: float = 1e-7):
    """Axis-aligned bbox ``[xmin, ymin, xmax, ymax]`` of normalized ellipses.

    ``ellipse`` is ``[..., 7]`` = ``[cx, cy, major, minor, sin, cos, ratio]``.
    Orientation ``(sin, cos)`` is normalized to unit norm before use.
    """

    cx, cy = ellipse[:, 0], ellipse[:, 1]
    major, minor = ellipse[:, 2], ellipse[:, 3]
    sin_a, cos_a = ellipse[:, 4], ellipse[:, 5]
    norm = torch.sqrt(sin_a ** 2 + cos_a ** 2 + eps)
    sin_a, cos_a = sin_a / norm, cos_a / norm
    half_w = torch.sqrt((major * cos_a) ** 2 + (minor * sin_a) ** 2 + eps)
    half_h = torch.sqrt((major * sin_a) ** 2 + (minor * cos_a) ** 2 + eps)
    return torch.stack([cx - half_w, cy - half_h, cx + half_w, cy + half_h], dim=1)


def ellipse_bbox_iou(preds, targets, eps: float = 1e-7):
    """IoU of the axis-aligned bounding boxes of two ellipse batches."""

    return bbox_iou(ellipse_to_bbox(preds, eps), ellipse_to_bbox(targets, eps), eps)


class EllipseLoss(nn.Module):
    """Regression loss for the 7-value ellipse target.

    Combines SmoothL1 terms for center, axes, orientation (sin/cos) and
    perspective ratio, plus optional penalties for axis ordering
    (``minor > major``) and non-unit orientation norm. ``combined`` adds a
    ``(1 - ellipse_bbox_iou)`` term.
    """

    def __init__(
        self,
        center_weight: float = 1.0,
        radius_weight: float = 1.0,
        angle_weight: float = 1.0,
        perspective_weight: float = 1.0,
        axis_order_weight: float = 0.5,
        unit_angle_weight: float = 0.1,
        iou_weight: float = 0.0,
    ) -> None:
        super().__init__()
        self.center_weight = float(center_weight)
        self.radius_weight = float(radius_weight)
        self.angle_weight = float(angle_weight)
        self.perspective_weight = float(perspective_weight)
        self.axis_order_weight = float(axis_order_weight)
        self.unit_angle_weight = float(unit_angle_weight)
        self.iou_weight = float(iou_weight)
        self.smooth_l1 = nn.SmoothL1Loss()

    def forward(self, preds, targets):
        loss = (
            self.center_weight * self.smooth_l1(preds[:, 0:2], targets[:, 0:2])
            + self.radius_weight * self.smooth_l1(preds[:, 2:4], targets[:, 2:4])
            + self.angle_weight * self.smooth_l1(preds[:, 4:6], targets[:, 4:6])
            + self.perspective_weight * self.smooth_l1(preds[:, 6:7], targets[:, 6:7])
        )
        if self.axis_order_weight > 0:
            loss = loss + self.axis_order_weight * torch.relu(preds[:, 3] - preds[:, 2]).mean()
        if self.unit_angle_weight > 0:
            norm = torch.sqrt(preds[:, 4] ** 2 + preds[:, 5] ** 2 + 1e-7)
            loss = loss + self.unit_angle_weight * ((norm - 1.0) ** 2).mean()
        if self.iou_weight > 0:
            loss = loss + self.iou_weight * (1.0 - ellipse_bbox_iou(preds, targets).mean())
        return loss


def build_ellipse_loss(cfg: Any):
    """Build the ellipse loss from ``cfg.ellipse_loss_name`` and its weights."""

    name = str(getattr(cfg, "ellipse_loss_name", "smooth_l1")).lower()
    kwargs = dict(
        center_weight=float(getattr(cfg, "ellipse_center_weight", 1.0)),
        radius_weight=float(getattr(cfg, "ellipse_radius_weight", 1.0)),
        angle_weight=float(getattr(cfg, "ellipse_angle_weight", 1.0)),
        perspective_weight=float(getattr(cfg, "ellipse_perspective_weight", 1.0)),
        axis_order_weight=float(getattr(cfg, "ellipse_axis_order_weight", 0.5)),
        unit_angle_weight=float(getattr(cfg, "ellipse_unit_angle_weight", 0.1)),
    )
    if name == "smooth_l1":
        return EllipseLoss(**kwargs, iou_weight=0.0)
    if name == "combined":
        return EllipseLoss(**kwargs, iou_weight=float(getattr(cfg, "combined_ellipse_iou_weight", 1.0)))
    raise ValueError(f"Unsupported ellipse_loss_name: {cfg.ellipse_loss_name!r}")
