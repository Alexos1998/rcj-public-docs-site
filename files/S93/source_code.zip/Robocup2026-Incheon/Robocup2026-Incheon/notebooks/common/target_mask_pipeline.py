"""Orchestration for the mask-first CognitiveTarget pipeline.

Ties together the pieces so notebooks and scripts stay thin:

* load the whole-target images + GT binary masks from a split;
* train / evaluate the :class:`TargetMaskRandomForest` segmenter (IoU, Dice, ...);
* run the radial classifier with the **GT** mask and with a **predicted** mask;
* pick the production segmenter (RF unless its IoU < the acceptance threshold) and
  write ``artifacts/target_mask/model_selection.json``.

Ring masks are never read here -- the GT mask is the whole-target silhouette and
the classification ground truth is the filename texture.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from . import metrics
from .config import PROJECT_ROOT, get_dataset_root, get_manifest_root
from .target_classification_radial import COLOR_CODES, decode_target_from_mask
from .target_geometry import load_target_binary_mask
from .target_mask_cnn import TargetMaskCNN, TargetMaskCNNConfig
from .target_mask_rf import TargetMaskRandomForest, TargetMaskRFConfig

ARTIFACTS_ROOT = PROJECT_ROOT / "artifacts" / "target_mask"
DEBUG_RF_DIR = PROJECT_ROOT / "artifacts" / "debug_target_mask_rf"
DEBUG_RADIAL_DIR = PROJECT_ROOT / "artifacts" / "debug_target_radial"

ACCEPTANCE_IOU = 0.95
SPLITS = ("train", "validation", "test")
MANIFEST_NAME = "target_mask_manifest.csv"


@dataclass
class TargetRecord:
    split: str
    image: np.ndarray  # HxWx3 uint8 RGB
    gt_mask: np.ndarray  # HxW bool
    texture: str
    clipped: bool
    radial_coverage: float
    image_name: str


def _load_manifest(dataset_name: str):
    import pandas as pd

    path = get_manifest_root(dataset_name) / MANIFEST_NAME
    if not path.exists():
        raise FileNotFoundError(
            f"{path} not found. Run notebooks/scripts/export_target_mask_manifest.py first."
        )
    return pd.read_csv(path)


def load_records(dataset_name: str, split: str) -> list[TargetRecord]:
    """Load images + GT binary masks for a split from the mask manifest."""

    from PIL import Image

    df = _load_manifest(dataset_name)
    df = df[df["split"] == split]
    root = get_dataset_root(dataset_name) / split
    records: list[TargetRecord] = []
    for _, row in df.iterrows():
        image = np.asarray(Image.open(root / row["image_path"]).convert("RGB"))
        gt_mask = load_target_binary_mask(root / row["target_mask_path"])
        records.append(
            TargetRecord(
                split=split,
                image=image,
                gt_mask=gt_mask,
                texture=str(row["texture"]),
                clipped=bool(row["clipped"]),
                radial_coverage=float(row["radial_coverage"]),
                image_name=Path(row["image_path"]).name,
            )
        )
    return records


# --------------------------------------------------------------------------- #
# Segmentation
# --------------------------------------------------------------------------- #


def train_rf_segmenter(
    dataset_name: str, config: TargetMaskRFConfig | None = None, train_split: str = "train"
) -> TargetMaskRandomForest:
    """Train the RF/ExtraTrees segmenter on a split's whole-target masks."""

    records = load_records(dataset_name, train_split)
    segmenter = TargetMaskRandomForest(config)
    segmenter.fit([r.image for r in records], [r.gt_mask for r in records])
    return segmenter


def train_cnn_segmenter(
    dataset_name: str, config: TargetMaskCNNConfig | None = None, train_split: str = "train"
) -> TargetMaskCNN:
    """Train the MiniTargetMaskNet fallback segmenter on whole-target masks."""

    records = load_records(dataset_name, train_split)
    segmenter = TargetMaskCNN(config)
    segmenter.fit([r.image for r in records], [r.gt_mask for r in records])
    return segmenter


def evaluate_segmenter(segmenter: TargetMaskRandomForest, records: list[TargetRecord]) -> dict:
    """Aggregate mask IoU/Dice/precision/recall/boundary-IoU + latency."""

    ious, dices, precisions, recalls, biou = [], [], [], [], []
    ious_clip, ious_noclip = [], []
    start = time.perf_counter()
    for record in records:
        pred = segmenter.predict_mask(record.image)
        stats = metrics.mask_metrics(pred, record.gt_mask)
        ious.append(stats["iou"])
        dices.append(stats["dice"])
        precisions.append(stats["precision"])
        recalls.append(stats["recall"])
        biou.append(metrics.boundary_iou(pred, record.gt_mask))
        (ious_clip if record.clipped else ious_noclip).append(stats["iou"])
    elapsed = time.perf_counter() - start
    n = max(len(records), 1)
    return {
        "n": len(records),
        "mask_iou": float(np.mean(ious)) if ious else 0.0,
        "mask_iou_median": float(np.median(ious)) if ious else 0.0,
        "mask_dice": float(np.mean(dices)) if dices else 0.0,
        "precision": float(np.mean(precisions)) if precisions else 0.0,
        "recall": float(np.mean(recalls)) if recalls else 0.0,
        "boundary_iou": float(np.mean(biou)) if biou else 0.0,
        "mask_iou_clipped": float(np.mean(ious_clip)) if ious_clip else None,
        "mask_iou_non_clipped": float(np.mean(ious_noclip)) if ious_noclip else None,
        "latency_ms_per_image": (elapsed / n) * 1000.0,
        "fps": n / elapsed if elapsed > 0 else 0.0,
        "model_size_bytes": segmenter.model_size_bytes,
    }


# --------------------------------------------------------------------------- #
# Radial classification evaluation (GT mask vs predicted mask)
# --------------------------------------------------------------------------- #


def evaluate_radial(
    records: list[TargetRecord],
    segmenter: TargetMaskRandomForest | None = None,
    mask_source: str = "gt",
    refine: bool = True,
) -> dict:
    """Run the radial classifier and score it against the filename texture.

    ``mask_source='gt'`` uses the GT mask; otherwise the ``segmenter`` predicts
    the mask. Reports exact-texture accuracy, per-ring accuracy, unknown rate,
    clipped vs non-clipped accuracy, a per-color confusion matrix and accuracy by
    radial-coverage bucket.
    """

    exact = 0
    ring_total = ring_correct = unknown = 0
    per_ring_correct = [0] * 5
    per_ring_total = [0] * 5
    true_colors: list[str] = []
    pred_colors: list[str] = []
    clip_exact = clip_n = noclip_exact = noclip_n = 0
    coverage_buckets: dict[str, list[int]] = {"0.0-0.5": [], "0.5-0.8": [], "0.8-1.0": []}
    decoded: list[dict] = []

    for record in records:
        if mask_source == "gt":
            mask = record.gt_mask
        else:
            if segmenter is None:
                raise ValueError("segmenter is required when mask_source != 'gt'.")
            mask = segmenter.predict_mask(record.image)
        result = decode_target_from_mask(record.image, mask, refine=refine)
        decoded.append({"record": record, "result": result})
        gt = record.texture
        pred = result["predicted_texture"]
        is_exact = pred == gt
        exact += int(is_exact)
        for j in range(5):
            ring_total += 1
            per_ring_total[j] += 1
            predicted = result["ring_colors"][j]
            actual = gt[j] if j < len(gt) else "?"
            if predicted == "?":
                unknown += 1
            elif predicted == actual:
                ring_correct += 1
                per_ring_correct[j] += 1
            true_colors.append(actual)
            pred_colors.append(predicted)
        if record.clipped:
            clip_n += 1
            clip_exact += int(is_exact)
        else:
            noclip_n += 1
            noclip_exact += int(is_exact)
        cov = record.radial_coverage
        bucket = "0.0-0.5" if cov < 0.5 else "0.5-0.8" if cov < 0.8 else "0.8-1.0"
        coverage_buckets[bucket].append(int(is_exact))

    n = max(len(records), 1)
    confusion_classes = list(COLOR_CODES) + ["?"]
    confusion = metrics.confusion_matrix(true_colors, pred_colors, confusion_classes)
    return {
        "mask_source": mask_source,
        "n": len(records),
        "texture_exact_accuracy": exact / n,
        "per_ring_accuracy": ring_correct / max(ring_total, 1),
        "per_ring_position_accuracy": [
            per_ring_correct[j] / max(per_ring_total[j], 1) for j in range(5)
        ],
        "unknown_rate": unknown / max(ring_total, 1),
        "accuracy_on_clipped": (clip_exact / clip_n) if clip_n else None,
        "accuracy_on_non_clipped": (noclip_exact / noclip_n) if noclip_n else None,
        "accuracy_by_radial_coverage_bucket": {
            k: (sum(v) / len(v) if v else None) for k, v in coverage_buckets.items()
        },
        "per_color_confusion_matrix": {
            "classes": confusion_classes,
            "matrix": confusion,
        },
        "_decoded": decoded,
    }


# --------------------------------------------------------------------------- #
# Overlays
# --------------------------------------------------------------------------- #


def save_rf_overlays(
    segmenter: TargetMaskRandomForest,
    records: list[TargetRecord],
    out_dir: Path = DEBUG_RF_DIR,
    limit: int = 24,
) -> Path:
    """Save RGB | GT mask | predicted mask | contour-overlay panels."""

    import cv2

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    for record in records[:limit]:
        pred = segmenter.predict_mask(record.image)
        rgb = cv2.cvtColor(record.image[:, :, :3], cv2.COLOR_RGB2BGR)
        gt_vis = cv2.cvtColor((record.gt_mask.astype(np.uint8) * 255), cv2.COLOR_GRAY2BGR)
        pred_vis = cv2.cvtColor((pred.astype(np.uint8) * 255), cv2.COLOR_GRAY2BGR)
        overlay = rgb.copy()
        for mask, color in ((record.gt_mask, (0, 255, 0)), (pred, (0, 0, 255))):
            contours, _ = cv2.findContours(
                mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
            )
            cv2.drawContours(overlay, contours, -1, color, 1)
        panel = np.hstack([rgb, gt_vis, pred_vis, overlay])
        cv2.imwrite(str(out_dir / f"{Path(record.image_name).stem}.png"), panel)
    return out_dir


def save_radial_overlays(
    decoded: list[dict], out_dir: Path = DEBUG_RADIAL_DIR, limit: int = 24
) -> Path:
    """Save RGB with center + radial contour + predicted/GT texture annotation."""

    import cv2

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    for item in decoded[:limit]:
        record: TargetRecord = item["record"]
        result = item["result"]
        rgb = cv2.cvtColor(record.image[:, :, :3], cv2.COLOR_RGB2BGR)
        scale = 6
        canvas = cv2.resize(rgb, (rgb.shape[1] * scale, rgb.shape[0] * scale), interpolation=cv2.INTER_NEAREST)
        center = result.get("center")
        if center is not None:
            cx, cy = int(center[0] * scale), int(center[1] * scale)
            cv2.circle(canvas, (cx, cy), 3, (0, 0, 255), -1)
            rays = np.asarray(result["rays"])
            valid = np.asarray(result["ray_valid"], dtype=bool)
            angles = np.arange(len(rays)) * (2 * np.pi / len(rays))
            for i in np.nonzero(valid)[0]:
                ex = int((center[0] + rays[i] * np.cos(angles[i])) * scale)
                ey = int((center[1] + rays[i] * np.sin(angles[i])) * scale)
                cv2.circle(canvas, (ex, ey), 1, (0, 255, 0), -1)
        ok = result["predicted_texture"] == record.texture
        label = f"gt={record.texture} pred={result['predicted_texture']} {'OK' if ok else 'X'}"
        cv2.putText(canvas, label, (6, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                    (0, 255, 0) if ok else (0, 0, 255), 1)
        cv2.imwrite(str(out_dir / f"{Path(record.image_name).stem}.png"), canvas)
    return out_dir


# --------------------------------------------------------------------------- #
# Model selection + report
# --------------------------------------------------------------------------- #


def _strip_decoded(report: dict) -> dict:
    return {k: v for k, v in report.items() if k != "_decoded"}


def run_model_selection(
    dataset_name: str = "imagens_larc",
    rf_config: TargetMaskRFConfig | None = None,
    cnn_config: TargetMaskCNNConfig | None = None,
    acceptance_iou: float = ACCEPTANCE_IOU,
    force_cnn: bool = False,
    save_overlays: bool = True,
    write_report: bool = True,
) -> dict:
    """Train RF, evaluate masks + radial classifier and write model_selection.json.

    Returns the report dict. The CNN fallback is *not* trained here -- if RF is
    below ``acceptance_iou`` (or ``force_cnn``) the report flags that a CNN is
    needed and ``selected_mask_model`` stays ``random_forest`` until the CNN is
    trained by :mod:`notebooks.common.target_mask_cnn`.
    """

    ARTIFACTS_ROOT.mkdir(parents=True, exist_ok=True)
    segmenter = train_rf_segmenter(dataset_name, rf_config)
    model_path = segmenter.save(ARTIFACTS_ROOT / "random_forest_target_mask.joblib")

    records = {split: load_records(dataset_name, split) for split in SPLITS}
    seg_metrics = {split: evaluate_segmenter(segmenter, records[split]) for split in SPLITS}
    val_iou = seg_metrics["validation"]["mask_iou"]
    test_iou = seg_metrics["test"]["mask_iou"]

    gt_radial = {s: evaluate_radial(records[s], mask_source="gt") for s in SPLITS}
    rf_radial = {s: evaluate_radial(records[s], segmenter, mask_source="rf") for s in SPLITS}

    rf_passes = min(val_iou, test_iou) >= acceptance_iou
    needs_cnn = (not rf_passes) or force_cnn

    # Train the CNN fallback only when RF is below acceptance (or forced); then
    # keep whichever segmenter has the higher *validation* IoU.
    cnn_val_iou = cnn_seg_metrics = cnn_radial = None
    selected = "random_forest"
    selected_segmenter = segmenter
    selected_radial = rf_radial
    if needs_cnn:
        cnn = train_cnn_segmenter(dataset_name, cnn_config)
        cnn.save(ARTIFACTS_ROOT / "mini_target_mask_best.pt")
        cnn.export_onnx(ARTIFACTS_ROOT / "mini_target_mask.onnx")
        cnn_seg_metrics = {s: evaluate_segmenter(cnn, records[s]) for s in SPLITS}
        cnn_val_iou = cnn_seg_metrics["validation"]["mask_iou"]
        cnn_radial = {s: evaluate_radial(records[s], cnn, mask_source="cnn") for s in SPLITS}
        if cnn_val_iou > val_iou:
            selected = "mini_cnn"
            selected_segmenter = cnn
            selected_radial = cnn_radial

    if rf_passes and not force_cnn:
        reason = (
            f"RF val/test IoU {val_iou:.4f}/{test_iou:.4f} >= {acceptance_iou}; "
            "kept as production segmenter, CNN not trained."
        )
    else:
        reason = (
            f"RF val IoU {val_iou:.4f} vs CNN val IoU {cnn_val_iou:.4f}; "
            f"selected '{selected}' (higher validation IoU)."
        )

    if save_overlays:
        save_rf_overlays(selected_segmenter, records["test"])
        save_radial_overlays(selected_radial["test"]["_decoded"])

    report = {
        "dataset": dataset_name,
        "acceptance_iou": acceptance_iou,
        "rf_mask_iou": val_iou,
        "rf_mask_iou_test": test_iou,
        "rf_mask_dice": seg_metrics["validation"]["mask_dice"],
        "cnn_mask_iou": cnn_val_iou,
        "selected_mask_model": selected,
        "needs_cnn": needs_cnn,
        "reason": reason,
        "rf_model_path": str(model_path),
        "cnn_model_path": str(ARTIFACTS_ROOT / "mini_target_mask_best.pt") if cnn_val_iou is not None else None,
        "segmentation_metrics": seg_metrics,
        "cnn_segmentation_metrics": cnn_seg_metrics,
        "gt_mask_radial_texture_accuracy": {s: gt_radial[s]["texture_exact_accuracy"] for s in SPLITS},
        "selected_mask_radial_texture_accuracy": {s: selected_radial[s]["texture_exact_accuracy"] for s in SPLITS},
        "gt_mask_radial": {s: _strip_decoded(gt_radial[s]) for s in SPLITS},
        "rf_mask_radial": {s: _strip_decoded(rf_radial[s]) for s in SPLITS},
        "cnn_mask_radial": {s: _strip_decoded(cnn_radial[s]) for s in SPLITS} if cnn_radial else None,
        "per_ring_accuracy": selected_radial["test"]["per_ring_accuracy"],
        "unknown_rate": selected_radial["test"]["unknown_rate"],
        "recommended_changes": _recommend(gt_radial["test"], selected_radial["test"], rf_passes),
    }

    if write_report:
        out = ARTIFACTS_ROOT / "model_selection.json"
        out.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
        print(f"wrote {out}")
    return report


def _recommend(gt_test: dict, rf_test: dict, rf_passes: bool) -> list[str]:
    notes: list[str] = []
    if not rf_passes:
        notes.append("RF below acceptance IoU -> train MiniTargetMaskNet fallback.")
    gt_acc = gt_test["texture_exact_accuracy"]
    rf_acc = rf_test["texture_exact_accuracy"]
    if gt_acc < 0.85:
        notes.append(
            "Radial accuracy with GT mask is limited -> color/sampling issue "
            "(tune classify_pixel_color, ring bands, or center refinement); "
            "small/far targets are resolution-bound at ~2px ring width."
        )
    if gt_acc - rf_acc > 0.1:
        notes.append("Large GT-vs-predicted gap -> improve the mask segmenter.")
    if gt_test.get("accuracy_on_non_clipped") is not None and gt_test["accuracy_on_non_clipped"] < 0.6:
        notes.append(
            "Non-clipped (small) targets dominate the error; consider rejecting "
            "targets below a minimum visible radius at runtime."
        )
    if not notes:
        notes.append("RF segmenter + radial classifier meet targets; no changes needed.")
    return notes
