"""Optimizer and learning-rate scheduler factories shared by training runs.

These helpers keep the optimizer/scheduler construction in one place so every
training routine (classification, bbox, circle) and the Optuna trials build them
the same way from a :class:`BaseTrainConfig`.
"""

from __future__ import annotations

from typing import Any

try:
    import torch
except ImportError:  # pragma: no cover - torch is required at training time
    torch = None


def _require_torch() -> None:
    if torch is None:
        raise RuntimeError("Install torch before building optimizers/schedulers.")


def metric_mode(cfg: Any) -> str:
    """Return "max" when the tracked metric improves upward, else "min".

    IoU / accuracy style metrics improve when they grow; loss-style metrics
    improve when they shrink. We key off ``optuna_metric`` so the plateau
    scheduler watches the validation metric in the right direction.
    """

    metric = str(getattr(cfg, "optuna_metric", "") or "").lower()
    direction = str(getattr(cfg, "optuna_direction", "maximize") or "").lower()
    if any(token in metric for token in ("iou", "accuracy", "acc", "f1", "score")):
        return "max"
    if any(token in metric for token in ("loss", "error", "err", "distance")):
        return "min"
    return "max" if direction == "maximize" else "min"


def build_optimizer(model, cfg: Any):
    """Build an optimizer from ``cfg.optimizer_name`` and related fields."""

    _require_torch()
    params = model.parameters()
    name = str(getattr(cfg, "optimizer_name", "adamw")).lower()
    lr = float(cfg.learning_rate)
    weight_decay = float(cfg.weight_decay)
    if name == "adamw":
        return torch.optim.AdamW(
            params,
            lr=lr,
            betas=(float(cfg.adam_beta1), float(cfg.adam_beta2)),
            eps=float(cfg.optimizer_eps),
            weight_decay=weight_decay,
        )
    if name == "adam":
        return torch.optim.Adam(
            params,
            lr=lr,
            betas=(float(cfg.adam_beta1), float(cfg.adam_beta2)),
            eps=float(cfg.optimizer_eps),
            weight_decay=weight_decay,
        )
    if name == "sgd":
        return torch.optim.SGD(
            params,
            lr=lr,
            momentum=float(cfg.sgd_momentum),
            weight_decay=weight_decay,
            nesterov=float(cfg.sgd_momentum) > 0,
        )
    raise ValueError(f"Unsupported optimizer_name: {cfg.optimizer_name!r}")


def build_scheduler(optimizer, cfg: Any, steps_per_epoch: int | None = None):
    """Build an LR scheduler. Returns ``None`` when ``scheduler_name == 'none'``.

    All schedulers are designed to be stepped **once per epoch** via
    :func:`scheduler_step`. ``OneCycleLR`` is configured with the given
    ``steps_per_epoch`` (defaulting to 1) so its total step count matches how
    often :func:`scheduler_step` is called.
    """

    _require_torch()
    name = str(getattr(cfg, "scheduler_name", "cosine")).lower()
    if name == "none":
        return None
    epochs = max(1, int(cfg.epochs))
    if name == "cosine":
        return torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=epochs, eta_min=float(cfg.scheduler_eta_min)
        )
    if name == "plateau":
        return torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode=metric_mode(cfg),
            factor=float(cfg.scheduler_factor),
            patience=int(cfg.scheduler_patience),
            min_lr=float(cfg.scheduler_min_lr),
        )
    if name == "onecycle":
        return torch.optim.lr_scheduler.OneCycleLR(
            optimizer,
            max_lr=float(cfg.learning_rate),
            total_steps=epochs,
            pct_start=float(cfg.onecycle_pct_start),
            anneal_strategy="cos",
        )
    raise ValueError(f"Unsupported scheduler_name: {cfg.scheduler_name!r}")


def is_plateau(scheduler) -> bool:
    _require_torch()
    return isinstance(scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau)


def scheduler_step(scheduler, cfg: Any, metric: float | None = None) -> None:
    """Advance the scheduler once per epoch.

    ``ReduceLROnPlateau`` needs the monitored validation metric; the other
    schedulers ignore ``metric``.
    """

    if scheduler is None:
        return
    if is_plateau(scheduler):
        if metric is None:
            return
        scheduler.step(metric)
    else:
        scheduler.step()


def current_lr(optimizer) -> float:
    """Return the learning rate of the first param group."""

    for group in optimizer.param_groups:
        return float(group.get("lr", 0.0))
    return 0.0
