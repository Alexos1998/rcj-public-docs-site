"""Webots .wbt parser and geometry helpers for map-training labels.

The parser intentionally looks only for real node starts in the world file, so it
does not confuse ``EXTERNPROTO "../protos/halfTile.proto"`` with an actual tile.
"""

from __future__ import annotations

import re
import warnings
from collections import Counter
from pathlib import Path

# WBT curve value -> CURVE_LABELS index
_WBT_CURVE_TO_LABEL: dict[int, int] = {0: 0, 1: 3, 2: 4, 3: 1, 4: 2}

# Quarter -> index into the WBT curve[4] array (lt, rt, lb, rb = NW, NE, SW, SE)
_QUARTER_CURVE_IDX: dict[str, int] = {"NW": 0, "NE": 1, "SW": 2, "SE": 3}

_EXTERNAL_DIRS: dict[str, tuple[str, str]] = {
    "NW": ("N", "W"),
    "NE": ("N", "E"),
    "SW": ("S", "W"),
    "SE": ("S", "E"),
}

_DIR_OFFSET: dict[str, tuple[int, int]] = {
    "N": (-1, 0),
    "E": (0, 1),
    "S": (1, 0),
    "W": (0, -1),
}

_DIRS = ("N", "E", "S", "W")

_NODE_START_RE = re.compile(
    r"^\s*(?:DEF\s+\w+\s+)?(?P<kind>worldTile|halfTile)\s*\{",
    re.MULTILINE,
)


def _brace_block(text: str, start: int) -> tuple[int, int]:
    """Return (open_brace_idx, close_brace_idx) for the block starting near *start*."""
    j = text.find("{", start)
    if j == -1:
        return -1, -1
    depth = 0
    k = j
    while k < len(text):
        if text[k] == "{":
            depth += 1
        elif text[k] == "}":
            depth -= 1
            if depth == 0:
                return j, k
        k += 1
    return j, -1


def _int_field(block: str, field: str, default: int = 0) -> int:
    m = re.search(rf"\b{re.escape(field)}\s+(-?\d+)\b", block)
    return int(m.group(1)) if m else default


def _bool_field(block: str, field: str) -> bool:
    m = re.search(rf"\b{re.escape(field)}\s+(TRUE|FALSE)\b", block, re.IGNORECASE)
    return bool(m) and m.group(1).upper() == "TRUE"


def _int4_field(block: str, field: str) -> tuple[int, int, int, int]:
    m = re.search(rf"\b{re.escape(field)}\s*\[\s*([\s\S]*?)\]", block)
    if not m:
        return (0, 0, 0, 0)
    nums = re.findall(r"-?\d+", m.group(1))
    if len(nums) < 4:
        return (0, 0, 0, 0)
    return tuple(int(v) for v in nums[:4])  # type: ignore[return-value]


def resolve_wbt_path(source: Path | str) -> Path | None:
    """Resolve *source* into a concrete ``.wbt`` path.

    * If *source* is already a ``.wbt`` file, return it.
    * If *source* is a run directory, read ``map_path.txt`` from it.
    * If *source* is a ``map_path.txt`` file, read it directly.
    """
    path = Path(source)
    if path.is_file() and path.suffix.lower() == ".wbt":
        return path
    if path.is_file() and path.name == "map_path.txt":
        raw = path.read_text(encoding="utf-8", errors="replace").strip()
        return Path(raw) if raw else None
    if path.is_dir():
        return resolve_wbt_path(path / "map_path.txt")
    return None


def parse_wbt(wbt_path: str | Path) -> list[dict]:
    """Parse a Webots ``.wbt`` world file into tile dicts."""
    wbt_path = Path(wbt_path)
    text = wbt_path.read_text(encoding="utf-8", errors="replace")
    tiles: list[dict] = []

    for match in _NODE_START_RE.finditer(text):
        kind = match.group("kind")
        open_b, close_b = _brace_block(text, match.start())
        if open_b == -1 or close_b == -1:
            raise ValueError(f"Unclosed {kind} block in {wbt_path}")
        block = text[open_b + 1:close_b]
        tiles.append(
            {
                "type": kind,
                "xPos": _int_field(block, "xPos", 0),
                "zPos": _int_field(block, "zPos", 0),
                "topWall": _int_field(block, "topWall", 0),
                "rightWall": _int_field(block, "rightWall", 0),
                "bottomWall": _int_field(block, "bottomWall", 0),
                "leftWall": _int_field(block, "leftWall", 0),
                "tile1_walls": _int4_field(block, "tile1Walls"),
                "tile2_walls": _int4_field(block, "tile2Walls"),
                "tile3_walls": _int4_field(block, "tile3Walls"),
                "tile4_walls": _int4_field(block, "tile4Walls"),
                "curve": _int4_field(block, "curve"),
                "trap": _bool_field(block, "trap"),
                "swamp": _bool_field(block, "swamp"),
                "checkpoint": _bool_field(block, "checkpoint"),
                "start": _bool_field(block, "start"),
                "obstacle": _bool_field(block, "obstacle"),
                "room": _int_field(block, "room", 1),
                # Field dimensions (constant across all tiles of a world). Needed to
                # recover a tile's absolute Webots-world position from its xPos/zPos:
                #   x_world = xPos*0.3*scale - width *0.3*scale/2   (see worldTile.proto)
                "width": _int_field(block, "width", 0),
                "height": _int_field(block, "height", 0),
            }
        )

    return tiles


# Physical tile size in metres: the proto places tiles on a 0.3 m grid scaled by 0.4.
TILE_SCALE = 0.4
TILE_M = 0.3 * TILE_SCALE  # 0.12 m, matches map_dataset.TILE_SIZE_M

_OBSTACLE_RE = re.compile(
    r"DEF OBSTACLE\d+ Solid \{\s*translation\s+([-\d.eE]+)\s+([-\d.eE]+)\s+([-\d.eE]+)"
    r"([\s\S]*?)name\s+\"obstacle",
)
_BOX_SIZE_RE = re.compile(r"Box \{\s*size\s+([-\d.eE]+)\s+([-\d.eE]+)\s+([-\d.eE]+)")
_ROT_RE = re.compile(r"rotation\s+[-\d.eE]+\s+[-\d.eE]+\s+[-\d.eE]+\s+([-\d.eE]+)")


def parse_obstacle_nodes(wbt_path: str | Path) -> list[dict]:
    """Parse ``DEF OBSTACLE# Solid`` nodes (physical obstacles placed on the field).

    These are the real, occupancy-visible obstacles the competition scores ("which
    tile holds the obstacle centre"), distinct from trap/swamp floor hazards. Returns
    a list of dicts with the Webots-world centre ``x``/``z``, footprint ``size_x``/
    ``size_z`` (metres) and ``yaw`` (rotation about the vertical axis, radians).
    """
    text = Path(wbt_path).read_text(encoding="utf-8", errors="replace")
    out: list[dict] = []
    for m in _OBSTACLE_RE.finditer(text):
        x, z = float(m.group(1)), float(m.group(3))
        body = m.group(4)
        sz = _BOX_SIZE_RE.search(body)
        size_x, size_z = (float(sz.group(1)), float(sz.group(3))) if sz else (0.03, 0.03)
        rot = _ROT_RE.search(body)
        yaw = float(rot.group(1)) if rot else 0.0
        out.append({"x": x, "z": z, "size_x": size_x, "size_z": size_z, "yaw": yaw})
    return out


class WbtTileGrid:
    """Tile grid indexed by coordinates relative to the start tile.

    Webots NUE coordinates:
      * ``xPos`` grows north.
      * ``zPos`` grows east.

    Grid coordinates:
      * ``tile_r = start_xPos - xPos`` grows south.
      * ``tile_c = zPos - start_zPos`` grows east.
    """

    def __init__(self, tiles: list[dict], obstacles: list[dict] | None = None) -> None:
        starts = [t for t in tiles if t.get("start")]
        if len(starts) != 1:
            raise ValueError(f"Expected exactly one start tile, found {len(starts)}")

        self._start_tile = dict(starts[0])
        self._xs = int(self._start_tile["xPos"])
        self._zs = int(self._start_tile["zPos"])
        # Field dimensions (constant per world) anchor the absolute Webots placement.
        self._field_w = int(self._start_tile.get("width", 0)) or max(
            (int(t.get("width", 0)) for t in tiles), default=0
        )
        self._field_h = int(self._start_tile.get("height", 0)) or max(
            (int(t.get("height", 0)) for t in tiles), default=0
        )
        self._obstacles = list(obstacles or [])
        self._grid: dict[tuple[int, int], dict] = {}
        self._kind_counts = Counter()

        for tile in tiles:
            self._kind_counts[str(tile.get("type", "unknown"))] += 1
            rc = self._to_rc(int(tile["xPos"]), int(tile["zPos"]))
            prev = self._grid.get(rc)
            if prev is not None:
                raise ValueError(
                    "Duplicate WBT tile coordinate "
                    f"{rc} from ({prev.get('type')}, xPos={prev.get('xPos')}, zPos={prev.get('zPos')}) "
                    f"and ({tile.get('type')}, xPos={tile.get('xPos')}, zPos={tile.get('zPos')})"
                )
            self._grid[rc] = dict(tile)

    def _to_rc(self, xPos: int, zPos: int) -> tuple[int, int]:
        return (self._xs - xPos, zPos - self._zs)

    @property
    def anchor(self) -> tuple[int, int]:
        return (0, 0)

    @property
    def all_coords(self) -> list[tuple[int, int]]:
        return sorted(self._grid)

    @property
    def start_tile(self) -> dict:
        return dict(self._start_tile)

    def kind_counts(self) -> dict[str, int]:
        return dict(self._kind_counts)

    def bounds(self) -> tuple[int, int, int, int]:
        rows = [rc[0] for rc in self._grid]
        cols = [rc[1] for rc in self._grid]
        return (min(rows), max(rows), min(cols), max(cols))

    def matrix_anchor(self) -> tuple[int, int]:
        min_r, _, min_c, _ = self.bounds()
        return (-min_r, -min_c)

    def to_matrix_rc(self, wbt_r: int, wbt_c: int) -> tuple[int, int]:
        min_r, _, min_c, _ = self.bounds()
        return (wbt_r - min_r, wbt_c - min_c)

    def from_matrix_rc(self, mat_r: int, mat_c: int) -> tuple[int, int]:
        min_r, _, min_c, _ = self.bounds()
        return (mat_r + min_r, mat_c + min_c)

    def iter_matrix_tiles(self):
        for wbt_r, wbt_c in sorted(self._grid):
            mat_r, mat_c = self.to_matrix_rc(wbt_r, wbt_c)
            yield (mat_r, mat_c, wbt_r, wbt_c, dict(self._grid[(wbt_r, wbt_c)]))

    def get(self, tile_r: int, tile_c: int) -> dict | None:
        return self._grid.get((tile_r, tile_c))

    def is_area4(self, tile_r: int, tile_c: int) -> bool:
        tile = self.get(tile_r, tile_c)
        return tile is not None and int(tile.get("room", 1)) == 4

    def is_obstacle(self, tile_r: int, tile_c: int) -> bool:
        tile = self.get(tile_r, tile_c)
        return bool(tile) and (
            bool(tile.get("trap"))
            or bool(tile.get("swamp"))
            or bool(tile.get("obstacle"))
        )

    def curve_label(self, tile_r: int, tile_c: int, quarter: str) -> int:
        tile = self.get(tile_r, tile_c)
        if tile is None or tile.get("type") != "halfTile":
            return 0
        wbt_val = int(tile.get("curve", (0, 0, 0, 0))[_QUARTER_CURVE_IDX[quarter]])
        return _WBT_CURVE_TO_LABEL.get(wbt_val, 0)

    def wall_flags(self, tile_r: int, tile_c: int, quarter: str) -> dict[str, bool]:
        tile = self.get(tile_r, tile_c)
        north = self.get(tile_r - 1, tile_c)
        south = self.get(tile_r + 1, tile_c)
        west = self.get(tile_r, tile_c - 1)
        east = self.get(tile_r, tile_c + 1)

        def outer(src: dict | None, field: str) -> bool:
            return bool(src) and int(src.get(field, 0)) > 0

        def inner(src: dict | None, quarter_num: int, dir_idx: int) -> bool:
            if not src:
                return False
            vals = src.get(f"tile{quarter_num}_walls", (0, 0, 0, 0))
            return int(vals[dir_idx]) > 0

        if quarter == "NW":
            wN = outer(tile, "topWall") or outer(north, "bottomWall") or inner(tile, 1, 0)
            wE = inner(tile, 1, 1) or inner(tile, 2, 3)
            wS = inner(tile, 1, 2) or inner(tile, 3, 0)
            wW = outer(tile, "leftWall") or outer(west, "rightWall") or inner(tile, 1, 3)
        elif quarter == "NE":
            wN = outer(tile, "topWall") or outer(north, "bottomWall") or inner(tile, 2, 0)
            wE = outer(tile, "rightWall") or outer(east, "leftWall") or inner(tile, 2, 1)
            wS = inner(tile, 2, 2) or inner(tile, 4, 0)
            wW = inner(tile, 2, 3) or inner(tile, 1, 1)
        elif quarter == "SW":
            wN = inner(tile, 3, 0) or inner(tile, 1, 2)
            wE = inner(tile, 3, 1) or inner(tile, 4, 3)
            wS = outer(tile, "bottomWall") or outer(south, "topWall") or inner(tile, 3, 2)
            wW = outer(tile, "leftWall") or outer(west, "rightWall") or inner(tile, 3, 3)
        else:
            wN = inner(tile, 4, 0) or inner(tile, 2, 2)
            wE = outer(tile, "rightWall") or outer(east, "leftWall") or inner(tile, 4, 1)
            wS = outer(tile, "bottomWall") or outer(south, "topWall") or inner(tile, 4, 2)
            wW = inner(tile, 4, 3) or inner(tile, 3, 1)

        return {"N": wN, "E": wE, "S": wS, "W": wW}

    def wall_wildcard(self, tile_r: int, tile_c: int, quarter: str) -> dict[str, int]:
        ext = _EXTERNAL_DIRS[quarter]
        out: dict[str, int] = {}
        for direction in _DIRS:
            if direction in ext:
                dr, dc = _DIR_OFFSET[direction]
                out[direction] = int(self.is_area4(tile_r + dr, tile_c + dc))
            else:
                out[direction] = 0
        return out

    # ------------------------------------------------------------------ #
    # Physical obstacles (DEF OBSTACLE# Solid nodes)
    # ------------------------------------------------------------------ #
    def _webots_to_wbt_rc(self, x_w: float, z_w: float) -> tuple[float, float]:
        """Convert an absolute Webots-world (x, z) to continuous WBT grid coords.

        Inverts the worldTile proto placement
        ``x_world = xPos*TILE_M - width*TILE_M/2`` (and likewise for z), then maps to
        the start-relative grid frame used by :meth:`get` (``wbt_r = xs - xPos``).
        """
        xpos_f = x_w / TILE_M + self._field_w / 2.0
        zpos_f = z_w / TILE_M + self._field_h / 2.0
        return (self._xs - xpos_f, zpos_f - self._zs)

    def obstacle_cells(self) -> list[dict]:
        """Physical obstacles as continuous WBT grid coords (``wbt_r``, ``wbt_c``).

        ``map_dataset`` turns these into SLAM/occupancy world metres with the same
        ``wx = -wbt_r*TILE, wy = -wbt_c*TILE`` convention used for tiles, so obstacle
        centres land on the occupied cells the LiDAR scanned. ``size_r``/``size_c`` are
        the footprint extents (metres) along the grid row/col axes.
        """
        out: list[dict] = []
        for ob in self._obstacles:
            wbt_r, wbt_c = self._webots_to_wbt_rc(ob["x"], ob["z"])
            out.append(
                {
                    "wbt_r": wbt_r,
                    "wbt_c": wbt_c,
                    # Webots x(north)->grid row, z(east)->grid col; footprint extents.
                    "size_r": float(ob.get("size_x", 0.03)),
                    "size_c": float(ob.get("size_z", 0.03)),
                    "yaw": float(ob.get("yaw", 0.0)),
                }
            )
        return out

    @property
    def n_obstacles(self) -> int:
        return len(self._obstacles)


def load_wbt_grid(source: Path | str, *, strict: bool = False) -> WbtTileGrid | None:
    """Load a ``WbtTileGrid`` from a run dir, ``map_path.txt`` or explicit ``.wbt``."""
    wbt_path = resolve_wbt_path(source)
    if wbt_path is None:
        if strict:
            raise FileNotFoundError(f"No WBT path found for {source}")
        return None
    if not wbt_path.is_file():
        msg = f"WBT path does not exist: {wbt_path}"
        if strict:
            raise FileNotFoundError(msg)
        warnings.warn(msg)
        return None
    try:
        tiles = parse_wbt(wbt_path)
        obstacles = parse_obstacle_nodes(wbt_path)
        return WbtTileGrid(tiles, obstacles) if tiles else None
    except Exception as exc:
        if strict:
            raise
        warnings.warn(f"Failed to parse WBT labels from {wbt_path}: {exc}")
        return None
