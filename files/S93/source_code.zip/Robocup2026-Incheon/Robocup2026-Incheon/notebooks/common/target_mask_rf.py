"""Random Forest / ExtraTrees pixel segmentation of the whole CognitiveTarget.

This is the **mandatory classical baseline** for the mask-first target pipeline:
a per-pixel binary classifier (target vs background) trained on the whole-target
masks only -- never the per-ring masks, never the texture. If it reaches the
acceptance IoU it stays the production segmenter and no CNN is trained.

Features per pixel are cheap and local: normalized RGB, HSV, Lab, the pixel's
normalized ``(x, y)``, a 3x3 local mean and a Sobel gradient magnitude. The
trained estimator + config round-trip through joblib.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

FEATURE_NAMES: tuple[str, ...] = (
    "r", "g", "b",
    "h", "s", "v",
    "lab_l", "lab_a", "lab_b",
    "x_norm", "y_norm",
    "local_mean", "grad_mag",
)


def _require_cv2():
    try:
        import cv2
    except ImportError as exc:  # pragma: no cover - environment guard
        raise RuntimeError("Install opencv-python for RF target segmentation.") from exc
    return cv2


def extract_pixel_features(image_rgb: np.ndarray) -> np.ndarray:
    """Return an ``(H*W, F)`` float32 feature matrix for every pixel.

    Channel order matches :data:`FEATURE_NAMES`. All features are scaled to
    roughly ``[0, 1]`` so trees split on comparable ranges.
    """

    cv2 = _require_cv2()
    image = np.asarray(image_rgb)
    if image.ndim != 3 or image.shape[2] < 3:
        raise ValueError(f"Expected an HxWx3 RGB image, got shape {image.shape}.")
    rgb = image[:, :, :3].astype(np.uint8)
    height, width = rgb.shape[:2]

    rgb_f = rgb.astype(np.float32) / 255.0
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV).astype(np.float32)
    hsv[..., 0] /= 179.0
    hsv[..., 1:] /= 255.0
    lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB).astype(np.float32) / 255.0

    ys, xs = np.mgrid[0:height, 0:width]
    x_norm = (xs / max(width - 1, 1)).astype(np.float32)
    y_norm = (ys / max(height - 1, 1)).astype(np.float32)

    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY).astype(np.float32) / 255.0
    local_mean = cv2.blur(gray, (3, 3))
    grad_x = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
    grad_mag = np.sqrt(grad_x**2 + grad_y**2)
    grad_mag /= (grad_mag.max() + 1e-6)

    stack = np.dstack(
        [
            rgb_f,
            hsv,
            lab,
            x_norm[..., None],
            y_norm[..., None],
            local_mean[..., None],
            grad_mag[..., None],
        ]
    ).astype(np.float32)
    return stack.reshape(-1, stack.shape[2])


@dataclass
class TargetMaskRFConfig:
    """Hyper-parameters for the RF/ExtraTrees pixel segmenter."""

    model_type: str = "random_forest"  # or "extra_trees"
    n_estimators: int = 200
    max_depth: int | None = 16
    min_samples_leaf: int = 2
    max_features: str = "sqrt"
    class_weight: str | None = "balanced"
    n_jobs: int = -1
    random_state: int = 42
    pixels_per_class: int = 600  # sampled per image per class at fit time
    proba_threshold: float = 0.5
    postprocess: bool = True  # keep largest component + close small holes


class TargetMaskRandomForest:
    """Train/predict a whole-target binary mask with RF/ExtraTrees."""

    def __init__(self, config: TargetMaskRFConfig | None = None) -> None:
        self.config = config or TargetMaskRFConfig()
        self.model = None

    def _build_model(self):
        from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier

        cfg = self.config
        kwargs = dict(
            n_estimators=cfg.n_estimators,
            max_depth=cfg.max_depth,
            min_samples_leaf=cfg.min_samples_leaf,
            max_features=cfg.max_features,
            class_weight=cfg.class_weight,
            n_jobs=cfg.n_jobs,
            random_state=cfg.random_state,
        )
        if cfg.model_type == "extra_trees":
            return ExtraTreesClassifier(**kwargs)
        return RandomForestClassifier(**kwargs)

    def _sample_image(
        self, image_rgb: np.ndarray, mask_binary: np.ndarray, rng: np.random.Generator
    ) -> tuple[np.ndarray, np.ndarray]:
        features = extract_pixel_features(image_rgb)
        labels = mask_binary.astype(np.uint8).reshape(-1)
        per_class = self.config.pixels_per_class
        chosen: list[np.ndarray] = []
        for value in (0, 1):
            idx = np.nonzero(labels == value)[0]
            if idx.size == 0:
                continue
            take = min(per_class, idx.size)
            chosen.append(rng.choice(idx, size=take, replace=False))
        if not chosen:
            return np.empty((0, features.shape[1]), np.float32), np.empty((0,), np.uint8)
        sel = np.concatenate(chosen)
        return features[sel], labels[sel]

    def fit(self, images, masks) -> "TargetMaskRandomForest":
        """Fit on balanced per-image pixel samples from ``images``/``masks``."""

        rng = np.random.default_rng(self.config.random_state)
        feats: list[np.ndarray] = []
        labs: list[np.ndarray] = []
        for image, mask in zip(images, masks):
            f, l = self._sample_image(np.asarray(image), np.asarray(mask), rng)
            if f.size:
                feats.append(f)
                labs.append(l)
        if not feats:
            raise ValueError("No training pixels sampled; check images/masks.")
        x = np.concatenate(feats)
        y = np.concatenate(labs)
        self.model = self._build_model()
        self.model.fit(x, y)
        return self

    def predict_proba_map(self, image_rgb: np.ndarray) -> np.ndarray:
        """Per-pixel target probability as an ``(H, W)`` float array."""

        if self.model is None:
            raise RuntimeError("Model is not trained or loaded.")
        image = np.asarray(image_rgb)
        height, width = image.shape[:2]
        features = extract_pixel_features(image)
        proba = self.model.predict_proba(features)
        classes = list(self.model.classes_)
        target_col = classes.index(1) if 1 in classes else proba.shape[1] - 1
        return proba[:, target_col].reshape(height, width)

    def predict_mask(self, image_rgb: np.ndarray, postprocess: bool | None = None) -> np.ndarray:
        """Predict a boolean whole-target mask for ``image_rgb``."""

        proba = self.predict_proba_map(image_rgb)
        mask = proba >= self.config.proba_threshold
        do_post = self.config.postprocess if postprocess is None else postprocess
        if do_post and mask.any():
            mask = self._postprocess(mask)
        return mask

    @staticmethod
    def _postprocess(mask: np.ndarray) -> np.ndarray:
        cv2 = _require_cv2()
        from .target_geometry import clean_largest_component

        kernel = np.ones((3, 3), np.uint8)
        closed = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_CLOSE, kernel)
        cleaned = clean_largest_component(closed.astype(bool))
        return cleaned if cleaned.any() else mask

    # -- persistence -------------------------------------------------------- #

    def save(self, path: str | Path) -> Path:
        import joblib

        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({"config": self.config, "model": self.model, "features": FEATURE_NAMES}, path)
        return path

    @classmethod
    def load(cls, path: str | Path) -> "TargetMaskRandomForest":
        import joblib

        payload = joblib.load(path)
        instance = cls(payload.get("config"))
        instance.model = payload.get("model")
        return instance

    @property
    def model_size_bytes(self) -> int:
        """Serialized model size on disk-ish (via an in-memory joblib dump)."""

        import io

        import joblib

        buffer = io.BytesIO()
        joblib.dump(self.model, buffer)
        return buffer.tell()
