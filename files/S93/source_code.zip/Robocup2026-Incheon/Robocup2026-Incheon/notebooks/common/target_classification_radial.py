"""Radial, proportional reading of the 5 CognitiveTarget rings.

Given the RGB image, a ``center`` and a radial contour ``R(theta)`` (from
:mod:`notebooks.common.target_geometry`), this samples each ring at a *fraction*
of its own radius. Because the rings are concentric and equally spaced, the same
``rho`` band lands on the same ring regardless of scale or (mild) perspective --
so no ellipse/perspective model is needed.

The 5-color answer is read from the **RGB image** (never from ring masks). Ring 0
is the innermost ring and maps to the first texture letter, ring 4 is the outer
ring -- so ``predicted_texture`` is directly comparable to the filename texture.

The mask center is refined by a small local search that maximises per-ring color
purity (:func:`refine_center`): the rings are concentric, so the true center is
the one that makes each proportional band a single color. This recovers the
~1px center the inner rings need even when the target is clipped, where a purely
geometric center is off by several pixels.
"""

from __future__ import annotations

from collections import Counter

import numpy as np

from .target_geometry import clean_largest_component, estimate_target_center, extract_radial_contour

COLOR_CODES: tuple[str, ...] = ("K", "R", "Y", "G", "B")

# Pure prototype colors (RGB 0..255) of the LARC target rings.
COLOR_PROTOTYPES: dict[str, tuple[int, int, int]] = {
    "K": (0, 0, 0),
    "R": (207, 0, 0),
    "Y": (207, 207, 0),
    "G": (0, 207, 0),
    "B": (0, 0, 207),
}

# Inner radial band per ring (fraction of R). Kept away from ring borders so a
# small center/contour error never samples the neighbouring ring.
DEFAULT_RING_BANDS: tuple[tuple[float, float], ...] = (
    (0.04, 0.16),  # ring 0 (center)
    (0.24, 0.36),  # ring 1
    (0.44, 0.56),  # ring 2
    (0.64, 0.76),  # ring 3
    (0.84, 0.96),  # ring 4 (outer)
)

# Below this value a pixel is treated as the black ring regardless of hue.
BLACK_VALUE_MAX = 60


def classify_pixel_color(
    rgb,
    prototypes: dict[str, tuple[int, int, int]] = COLOR_PROTOTYPES,
    black_value_max: int = BLACK_VALUE_MAX,
) -> str:
    """Classify a single RGB pixel to ``K/R/Y/G/B`` (nearest prototype).

    A dedicated low-brightness rule claims very dark pixels for ``K`` before the
    nearest-prototype vote, so a dark-but-tinted pixel is not pulled to a hue.
    """

    pixel = np.asarray(rgb, dtype=np.float64).reshape(1, 3)
    return _classify_pixels(pixel, prototypes, black_value_max)[0]


def _classify_pixels(
    pixels: np.ndarray,
    prototypes: dict[str, tuple[int, int, int]],
    black_value_max: int,
) -> list[str]:
    """Vectorized nearest-prototype classification of an ``(N, 3)`` RGB array."""

    if pixels.size == 0:
        return []
    pixels = pixels.astype(np.float64)
    codes = list(prototypes)
    proto = np.asarray([prototypes[c] for c in codes], dtype=np.float64)
    distances = np.linalg.norm(pixels[:, None, :] - proto[None, :, :], axis=2)
    nearest = np.argmin(distances, axis=1)
    is_black = pixels.max(axis=1) <= black_value_max
    if "K" in codes:
        nearest[is_black] = codes.index("K")
    return [codes[i] for i in nearest]


def _bilinear_sample(image: np.ndarray, xs: np.ndarray, ys: np.ndarray) -> np.ndarray:
    """Bilinearly sample ``image`` (HxWx3 float) at float coords ``xs``/``ys``."""

    height, width = image.shape[:2]
    xs = np.clip(xs, 0.0, width - 1.0)
    ys = np.clip(ys, 0.0, height - 1.0)
    x0 = np.floor(xs).astype(np.intp)
    y0 = np.floor(ys).astype(np.intp)
    x1 = np.minimum(x0 + 1, width - 1)
    y1 = np.minimum(y0 + 1, height - 1)
    fx = (xs - x0)[:, None]
    fy = (ys - y0)[:, None]
    return (
        image[y0, x0] * (1 - fx) * (1 - fy)
        + image[y0, x1] * fx * (1 - fy)
        + image[y1, x0] * (1 - fx) * fy
        + image[y1, x1] * fx * fy
    )


def _sample_ring_pixels(
    image: np.ndarray,
    center: tuple[float, float],
    rays: np.ndarray,
    valid_idx: np.ndarray,
    angles: np.ndarray,
    band: tuple[float, float],
    samples_per_ring: int,
) -> tuple[np.ndarray, int]:
    """Bilinearly sample one ring band over all valid rays. Returns (pixels, attempted)."""

    cx, cy = center
    rhos = np.linspace(band[0], band[1], samples_per_ring)
    r_valid = rays[valid_idx]
    theta = angles[valid_idx]
    cos_t, sin_t = np.cos(theta), np.sin(theta)
    xs = (cx + rhos[:, None] * r_valid[None, :] * cos_t[None, :]).reshape(-1)
    ys = (cy + rhos[:, None] * r_valid[None, :] * sin_t[None, :]).reshape(-1)
    attempted = xs.size
    height, width = image.shape[:2]
    in_frame = (xs >= 0) & (xs <= width - 1) & (ys >= 0) & (ys <= height - 1)
    if not in_frame.any():
        return np.empty((0, 3), np.float32), attempted
    pixels = _bilinear_sample(image.astype(np.float32), xs[in_frame], ys[in_frame])
    return pixels, attempted


def classify_target_radial(
    image_rgb: np.ndarray,
    center: tuple[float, float],
    rays: np.ndarray,
    ray_valid: np.ndarray,
    n_rings: int = 5,
    colors: tuple[str, ...] = COLOR_CODES,
    samples_per_ring: int = 5,
    ring_bands: tuple[tuple[float, float], ...] = DEFAULT_RING_BANDS,
    min_ring_coverage: float = 0.15,
    prototypes: dict[str, tuple[int, int, int]] = COLOR_PROTOTYPES,
    black_value_max: int = BLACK_VALUE_MAX,
) -> dict:
    """Read the 5 ring colors by proportional radial sampling.

    Samples every valid ray inside each ring's :data:`DEFAULT_RING_BANDS` band
    (bilinear), classifies each sample and takes a per-ring majority vote. Rings
    with too few in-frame samples return ``"?"``.

    Returns a dict with ``predicted_texture`` (e.g. ``"KRYGB"``), per-ring
    ``ring_colors``/``ring_confidence``/``ring_coverage``, the raw vote ``scores``
    and a scalar ``consistency`` (sum of per-ring majority fractions) used to
    score candidate centers.
    """

    image = np.asarray(image_rgb)
    if image.ndim != 3 or image.shape[2] < 3:
        raise ValueError(f"Expected an HxWx3 RGB image, got shape {image.shape}.")
    image = image[:, :, :3]
    cx, cy = float(center[0]), float(center[1])
    rays = np.asarray(rays, dtype=np.float64)
    ray_valid = np.asarray(ray_valid, dtype=bool)
    n_rays = rays.shape[0]
    angles = np.arange(n_rays) * (2.0 * np.pi / n_rays)
    valid_idx = np.nonzero(ray_valid)[0]

    bands = ring_bands[:n_rings]
    ring_colors: list[str] = []
    ring_confidence: list[float] = []
    ring_coverage: list[float] = []
    scores: list[dict[str, int]] = []
    consistency = 0.0

    for band in bands:
        pixels, attempted = (
            _sample_ring_pixels(image, (cx, cy), rays, valid_idx, angles, band, samples_per_ring)
            if valid_idx.size
            else (np.empty((0, 3), np.float32), 0)
        )
        coverage = (pixels.shape[0] / attempted) if attempted else 0.0
        ring_coverage.append(float(coverage))
        if pixels.shape[0] == 0 or coverage < min_ring_coverage:
            ring_colors.append("?")
            ring_confidence.append(0.0)
            scores.append({c: 0 for c in colors})
            continue
        labels = _classify_pixels(pixels, prototypes, black_value_max)
        votes = Counter(labels)
        scores.append({c: int(votes.get(c, 0)) for c in colors})
        best_color, best_count = max(votes.items(), key=lambda kv: kv[1])
        ring_colors.append(best_color)
        fraction = float(best_count) / float(len(labels))
        ring_confidence.append(fraction)
        consistency += fraction

    return {
        "predicted_texture": "".join(ring_colors),
        "ring_colors": ring_colors,
        "ring_confidence": ring_confidence,
        "ring_coverage": ring_coverage,
        "scores": scores,
        "consistency": consistency,
        "success": "?" not in ring_colors,
        "center": (cx, cy),
    }


def refine_center(
    image_rgb: np.ndarray,
    binary: np.ndarray,
    center0: tuple[float, float],
    n_rays: int = 48,
    coarse_radius: float = 6.0,
    coarse_step: float = 1.5,
    fine_radius: float = 1.0,
    fine_step: float = 0.34,
    samples_per_ring: int = 3,
) -> tuple[float, float]:
    """Refine ``center0`` to maximise ring-color purity (concentricity).

    Two passes (coarse then fine) of a local grid search; each candidate is
    scored by the radial classifier's ``consistency``. Returns the best center.
    """

    image = np.asarray(image_rgb)[:, :, :3].astype(np.float32)

    def score(center: tuple[float, float]) -> float:
        rays, valid = extract_radial_contour(binary, center, n_rays=n_rays)
        if int(valid.sum()) < 3:
            return -1.0
        result = classify_target_radial(
            image, center, rays, valid, samples_per_ring=samples_per_ring
        )
        return result["consistency"]

    def search(c0: tuple[float, float], radius: float, step: float) -> tuple[float, float]:
        offsets = np.arange(-radius, radius + 1e-6, step)
        best_center, best_score = c0, -1.0
        for dx in offsets:
            for dy in offsets:
                candidate = (c0[0] + dx, c0[1] + dy)
                value = score(candidate)
                if value > best_score:
                    best_score, best_center = value, candidate
        return best_center

    coarse = search(center0, coarse_radius, coarse_step)
    return search(coarse, fine_radius, fine_step)


def decode_target_from_mask(
    image_rgb: np.ndarray,
    binary_mask: np.ndarray,
    n_rays: int = 64,
    refine: bool = True,
    samples_per_ring: int = 5,
) -> dict:
    """End-to-end target decode from an RGB image + a whole-target binary mask.

    Cleans the mask, estimates and (optionally) refines the center, casts the
    radial contour and reads the 5 ring colors. This is the single entry point
    shared by the notebooks and the runtime pipeline. Returns the radial-classify
    dict plus ``center``, ``rays``, ``ray_valid``, ``radial_coverage`` and
    ``mask_valid``.
    """

    image = np.asarray(image_rgb)[:, :, :3]
    cleaned = clean_largest_component(np.asarray(binary_mask).astype(bool))
    if not cleaned.any():
        return {
            "predicted_texture": "?????",
            "ring_colors": ["?"] * 5,
            "ring_confidence": [0.0] * 5,
            "ring_coverage": [0.0] * 5,
            "success": False,
            "mask_valid": False,
            "center": None,
            "rays": np.zeros(n_rays),
            "ray_valid": np.zeros(n_rays, dtype=bool),
            "radial_coverage": 0.0,
        }
    center = estimate_target_center(cleaned)
    if refine:
        center = refine_center(image, cleaned, center)
    rays, valid = extract_radial_contour(cleaned, center, n_rays=n_rays)
    result = classify_target_radial(image, center, rays, valid, samples_per_ring=samples_per_ring)
    result.update(
        {
            "mask_valid": True,
            "center": (float(center[0]), float(center[1])),
            "rays": rays,
            "ray_valid": valid,
            "radial_coverage": float(valid.mean()) if valid.size else 0.0,
        }
    )
    return result
