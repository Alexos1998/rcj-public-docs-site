"""Optuna helpers shared by the training routines.

Optuna is an **optional** dependency. Nothing here is imported at module load
time; :func:`ensure_optuna` raises a clear, actionable error only when the user
actually asks for ``use_optuna=True`` without the package installed.

The objective function itself lives in ``training_runs`` (it needs torch and the
per-task epoch loops); this module owns study/pruner construction, the
hyperparameter search spaces and artifact serialization.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable


INSTALL_MESSAGE = "use_optuna=True requires optuna. Install with: pip install optuna"


def optuna_available() -> bool:
    try:
        import optuna  # noqa: F401
    except ImportError:
        return False
    return True


def ensure_optuna():
    """Return the optuna module or raise a clear error if missing."""

    try:
        import optuna
    except ImportError as exc:  # pragma: no cover - exercised when optuna absent
        raise RuntimeError(INSTALL_MESSAGE) from exc
    return optuna


def build_pruner(cfg: Any):
    optuna = ensure_optuna()
    name = str(getattr(cfg, "optuna_pruner", "median")).lower()
    if name == "none":
        return optuna.pruners.NopPruner()
    if name == "median":
        return optuna.pruners.MedianPruner()
    if name == "successive_halving":
        return optuna.pruners.SuccessiveHalvingPruner()
    raise ValueError(f"Unsupported optuna_pruner: {cfg.optuna_pruner!r}")


def build_study(cfg: Any):
    optuna = ensure_optuna()
    sampler = optuna.samplers.TPESampler(seed=int(cfg.optuna_seed))
    study_name = cfg.optuna_study_name or f"{cfg.task_name}_{cfg.run_id}"
    storage = cfg.optuna_storage or None
    return optuna.create_study(
        study_name=study_name,
        direction=cfg.optuna_direction,
        sampler=sampler,
        pruner=build_pruner(cfg),
        storage=storage,
        load_if_exists=bool(storage),
    )


def _suggest_common(trial, cfg: Any) -> dict[str, Any]:
    overrides: dict[str, Any] = {}
    overrides["learning_rate"] = trial.suggest_float(
        "learning_rate", float(cfg.optuna_lr_min), float(cfg.optuna_lr_max), log=True
    )
    overrides["weight_decay"] = trial.suggest_float(
        "weight_decay",
        float(cfg.optuna_weight_decay_min),
        float(cfg.optuna_weight_decay_max),
        log=True,
    )
    overrides["dropout"] = trial.suggest_float(
        "dropout", float(cfg.optuna_dropout_min), float(cfg.optuna_dropout_max)
    )
    if cfg.optuna_base_channels_choices:
        overrides["base_channels"] = trial.suggest_categorical(
            "base_channels", list(cfg.optuna_base_channels_choices)
        )
    if cfg.optuna_batch_size_choices:
        overrides["batch_size"] = trial.suggest_categorical(
            "batch_size", list(cfg.optuna_batch_size_choices)
        )
    if cfg.optuna_input_size_choices:
        overrides["input_size"] = trial.suggest_categorical(
            "input_size", list(cfg.optuna_input_size_choices)
        )
    overrides["optimizer_name"] = trial.suggest_categorical(
        "optimizer_name", ["adam", "adamw", "sgd"]
    )
    overrides["adam_beta1"] = trial.suggest_float("adam_beta1", 0.8, 0.95)
    overrides["adam_beta2"] = trial.suggest_float("adam_beta2", 0.9, 0.9999)
    overrides["scheduler_name"] = trial.suggest_categorical(
        "scheduler_name", ["none", "cosine", "plateau", "onecycle"]
    )
    return overrides


def _suggest_bbox(trial, cfg: Any) -> dict[str, Any]:
    overrides: dict[str, Any] = {}
    overrides["bbox_loss_name"] = trial.suggest_categorical(
        "bbox_loss_name", ["saiou", "smooth_l1", "giou", "combined", "shape_combined"]
    )
    overrides["saiou_lambda_center"] = trial.suggest_float(
        "saiou_lambda_center",
        float(cfg.optuna_saiou_lambda_center_min),
        float(cfg.optuna_saiou_lambda_center_max),
    )
    overrides["saiou_lambda_corner"] = trial.suggest_float(
        "saiou_lambda_corner",
        float(cfg.optuna_saiou_lambda_corner_min),
        float(cfg.optuna_saiou_lambda_corner_max),
    )
    overrides["combined_smooth_l1_weight"] = trial.suggest_float(
        "combined_smooth_l1_weight", 0.05, 1.0
    )
    overrides["shape_size_weight"] = trial.suggest_float("shape_size_weight", 0.25, 2.5)
    overrides["shape_aspect_weight"] = trial.suggest_float("shape_aspect_weight", 0.0, 2.0)
    overrides["augment_brightness"] = trial.suggest_float("augment_brightness", 0.0, 0.4)
    overrides["augment_contrast"] = trial.suggest_float("augment_contrast", 0.0, 0.4)
    return overrides


def _suggest_circle(trial, cfg: Any) -> dict[str, Any]:
    overrides: dict[str, Any] = {}
    overrides["circle_center_weight"] = trial.suggest_float("circle_center_weight", 0.25, 4.0)
    overrides["circle_radius_weight"] = trial.suggest_float("circle_radius_weight", 0.25, 4.0)
    overrides["augment_brightness"] = trial.suggest_float("augment_brightness", 0.0, 0.4)
    overrides["augment_contrast"] = trial.suggest_float("augment_contrast", 0.0, 0.4)
    return overrides


def _suggest_ellipse(trial, cfg: Any) -> dict[str, Any]:
    overrides: dict[str, Any] = {}
    overrides["ellipse_center_weight"] = trial.suggest_float("ellipse_center_weight", 0.25, 4.0)
    overrides["ellipse_radius_weight"] = trial.suggest_float("ellipse_radius_weight", 0.25, 4.0)
    overrides["ellipse_angle_weight"] = trial.suggest_float("ellipse_angle_weight", 0.25, 4.0)
    overrides["ellipse_perspective_weight"] = trial.suggest_float("ellipse_perspective_weight", 0.25, 4.0)
    overrides["augment_brightness"] = trial.suggest_float("augment_brightness", 0.0, 0.4)
    overrides["augment_contrast"] = trial.suggest_float("augment_contrast", 0.0, 0.4)
    return overrides


def _suggest_classification(trial, cfg: Any) -> dict[str, Any]:
    overrides: dict[str, Any] = {}
    overrides["augment_brightness"] = trial.suggest_float("augment_brightness", 0.0, 0.4)
    overrides["augment_contrast"] = trial.suggest_float("augment_contrast", 0.0, 0.4)
    overrides["augment_degrees"] = trial.suggest_float("augment_degrees", 0.0, 15.0)
    overrides["augment_translate"] = trial.suggest_float("augment_translate", 0.0, 0.2)
    return overrides


_TASK_SUGGESTERS: dict[str, Callable[[Any, Any], dict[str, Any]]] = {
    "bbox": _suggest_bbox,
    "circle": _suggest_circle,
    "ellipse": _suggest_ellipse,
    "classification": _suggest_classification,
}


def suggest_overrides(trial, cfg: Any, task: str) -> dict[str, Any]:
    """Suggest a full set of hyperparameter overrides for ``task``."""

    overrides = _suggest_common(trial, cfg)
    task_suggester = _TASK_SUGGESTERS.get(task)
    if task_suggester is not None:
        overrides.update(task_suggester(trial, cfg))
    return overrides


def run_study(cfg: Any, objective: Callable[[Any], float]):
    """Create a study and optimize ``objective`` according to ``cfg``."""

    optuna = ensure_optuna()  # noqa: F841 - validates availability early
    study = build_study(cfg)
    study.optimize(
        objective,
        n_trials=int(cfg.optuna_n_trials),
        timeout=cfg.optuna_timeout,
        gc_after_trial=True,
    )
    return study


def _trials_table(study) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for trial in study.trials:
        row = {
            "number": trial.number,
            "value": trial.value,
            "state": str(trial.state),
        }
        for key, value in trial.params.items():
            row[f"param_{key}"] = value
        rows.append(row)
    return rows


def save_optuna_artifacts(study, artifact_dir: str | Path) -> dict[str, str]:
    """Persist best params, trial table and a study summary; plots when possible."""

    artifact_dir = Path(artifact_dir)
    artifact_dir.mkdir(parents=True, exist_ok=True)
    artifacts: dict[str, str] = {}

    best_params_path = artifact_dir / "optuna_best_params.json"
    best_params_path.write_text(
        json.dumps(
            {
                "best_value": study.best_value,
                "best_trial": study.best_trial.number,
                "best_params": study.best_params,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    artifacts["optuna_best_params"] = str(best_params_path)

    rows = _trials_table(study)
    trials_path = artifact_dir / "optuna_trials.csv"
    if rows:
        import csv

        fieldnames: list[str] = []
        for row in rows:
            for key in row:
                if key not in fieldnames:
                    fieldnames.append(key)
        with trials_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
        artifacts["optuna_trials"] = str(trials_path)

    study_path = artifact_dir / "optuna_study.json"
    study_path.write_text(
        json.dumps(
            {
                "study_name": study.study_name,
                "direction": str(study.direction),
                "n_trials": len(study.trials),
                "best_value": study.best_value,
                "best_params": study.best_params,
                "trials": rows,
            },
            indent=2,
            sort_keys=True,
            default=str,
        )
        + "\n",
        encoding="utf-8",
    )
    artifacts["optuna_study"] = str(study_path)

    artifacts.update(_save_optuna_plots(study, artifact_dir))
    return artifacts


def _save_optuna_plots(study, artifact_dir: Path) -> dict[str, str]:
    artifacts: dict[str, str] = {}
    try:
        import optuna.visualization.matplotlib as ov
        import matplotlib.pyplot as plt
    except Exception:
        return artifacts

    plots = {
        "optuna_history_plot": ("plot_optimization_history", "optuna_history.png"),
        "optuna_importances_plot": ("plot_param_importances", "optuna_param_importances.png"),
    }
    for key, (func_name, filename) in plots.items():
        try:
            ax = getattr(ov, func_name)(study)
            fig = ax.figure
            path = artifact_dir / filename
            fig.savefig(path, bbox_inches="tight")
            plt.close(fig)
            artifacts[key] = str(path)
        except Exception:
            continue
    return artifacts
