"""Notebook-first training/export routines for perception models."""

from __future__ import annotations

import copy
import dataclasses
import html
import json
import random
import sys
import time
from collections.abc import Iterator, Mapping
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Sequence

import numpy as np

try:
    import torch
    from torch import nn
    from torch.utils.data import DataLoader
except ImportError:
    torch = None
    nn = None
    DataLoader = None

from .datasets import (
    DEFAULT_MEAN,
    DEFAULT_STD,
    BBoxRegressionDataset,
    CircleRegressionDataset,
    EllipseRegressionDataset,
    ImageClassificationDataset,
    read_csv_manifest,
)
from .losses import (
    SAIoULoss,
    bbox_iou as _bbox_iou,
    build_bbox_loss,
    build_circle_loss,
    build_ellipse_loss,
    circle_iou as _circle_iou,
    ellipse_bbox_iou as _ellipse_bbox_iou,
)
from .metrics import classification_report as build_classification_report
from .metrics import ellipse_angle_deg as _ellipse_angle_deg
from . import crops as crops_module
from . import model_registry
from .onnx_export import export_onnx_model
from .optim import build_optimizer, build_scheduler, current_lr, scheduler_step
from .preflight import PreflightReport, run_preflight_check
from .train_config import (
    BBoxTrainConfig,
    BaseTrainConfig,
    CircleTrainConfig,
    ClassificationTrainConfig,
    EllipseTrainConfig,
)
from . import optuna_tuning
from .visualization import save_training_visuals


def _require_torch() -> None:
    if torch is None or nn is None or DataLoader is None:
        raise RuntimeError("Install torch before running training.")


def seed_everything(seed: int = 42) -> None:
    _require_torch()
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def resolve_device(device: str = "auto") -> tuple[torch.device, list[str]]:
    _require_torch()
    warnings: list[str] = []
    if device not in {"auto", "cuda", "cpu"}:
        raise ValueError("device must be one of: auto, cuda, cpu.")

    if device == "cpu":
        resolved = torch.device("cpu")
    elif device == "cuda":
        if torch.cuda.is_available():
            resolved = torch.device("cuda")
        else:
            warnings.append(
                "CUDA was requested but is not available; falling back to CPU."
            )
            resolved = torch.device("cpu")
    else:
        resolved = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print("DEVICE:", resolved.type)
    if resolved.type == "cuda":
        print("GPU:", torch.cuda.get_device_name(0))
    elif device in {"auto", "cuda"}:
        print("WARNING: CUDA is not available; running on CPU.")
    if resolved.type == "cpu":
        # Avoid CPU thread oversubscription on small 64x64 batches.
        torch.set_num_threads(min(max(1, torch.get_num_threads()), 4))
    return resolved, warnings


@dataclass
class TrainingResult(Mapping[str, Any]):
    """Structured result returned by notebook training functions."""

    history: dict[str, list[Any]]
    best_epoch: int | None
    best_metric: float | None
    checkpoint_path: Path | None
    onnx_path: Path | None
    metrics_path: Path | None
    total_time_seconds: float
    status: str
    warnings: list[str]
    config: BaseTrainConfig
    metrics: dict[str, Any] = field(default_factory=dict)
    model: Any | None = field(default=None, repr=False)

    def to_dict(self) -> dict[str, Any]:
        payload = dict(self.metrics)
        payload.update(
            {
                "history": self.history,
                "best_epoch": self.best_epoch,
                "best_metric": self.best_metric,
                "checkpoint_path": str(self.checkpoint_path)
                if self.checkpoint_path
                else None,
                "onnx_path": str(self.onnx_path) if self.onnx_path else None,
                "metrics_path": str(self.metrics_path) if self.metrics_path else None,
                "total_time_seconds": self.total_time_seconds,
                "status": self.status,
                "warnings": list(self.warnings),
                "config": self.config.to_dict(),
            }
        )
        return _json_safe(payload)

    def __getitem__(self, key: str) -> Any:
        return self.to_dict()[key]

    def __iter__(self) -> Iterator[str]:
        return iter(self.to_dict())

    def __len__(self) -> int:
        return len(self.to_dict())

    def get(self, key: str, default: Any = None) -> Any:
        return self.to_dict().get(key, default)


def _created_at() -> str:
    return datetime.now(timezone.utc).isoformat()


def _loader(
    dataset,
    batch_size: int,
    num_workers: int,
    device: torch.device,
    shuffle: bool = False,
):
    _require_torch()
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=(device.type == "cuda"),
    )


def _split_counts(rows: list[dict[str, str]]) -> dict[str, int]:
    return {
        split: sum(row.get("split") == split for row in rows)
        for split in ("train", "validation", "test")
    }


def _label_counts(rows: list[dict[str, str]], labels: Sequence[str]) -> dict[str, int]:
    return {
        label: sum(row.get("label_name") == label for row in rows) for label in labels
    }


def _dataset_summary(
    *,
    cfg: BaseTrainConfig,
    rows: list[dict[str, str]],
    report: PreflightReport,
) -> dict[str, Any]:
    return {
        "name": cfg.dataset_name,
        "root": str(cfg.dataset_root),
        "manifest": str(cfg.manifest_path),
        "rows": len(rows),
        "splits": report.split_counts or _split_counts(rows),
        "labels": report.class_counts or _label_counts(rows, cfg.labels),
        "checked_image_count": report.checked_image_count,
        "missing_image_count": report.missing_image_count,
    }


def _bbox_crop_lookup(manifest_path: Path) -> dict[tuple[str, str], list[float]]:
    lookup: dict[tuple[str, str], list[float]] = {}
    for row in read_csv_manifest(manifest_path):
        try:
            bbox = [float(row[name]) for name in ("xmin", "ymin", "xmax", "ymax")]
        except (KeyError, TypeError, ValueError):
            continue
        if bbox[0] >= bbox[2] or bbox[1] >= bbox[3]:
            continue
        lookup[(row.get("split", ""), row.get("image_path", ""))] = bbox
    return lookup


def _classification_crop_preprocessing(
    cfg: ClassificationTrainConfig,
    rows: list[dict[str, str]],
    warnings: list[str],
) -> tuple[Path, dict[str, Any], dict[str, Any] | None]:
    """Resolve which manifest + dataset kwargs classification should train on.

    Returns ``(dataset_manifest_path, dataset_kwargs, preprocessing_payload)``:
      * ``crop_mode="none"``         -> base manifest, full images.
      * ``crop_mode="ground_truth"`` -> base manifest + GT bbox ``crop_boxes``.
      * ``crop_mode="predicted"``    -> generated predicted-crop manifest read via ``crop_path``.
    """

    if cfg.crop_mode == "none":
        return cfg.manifest_path, {}, {"crop_mode": "none"}

    if cfg.crop_mode == "ground_truth":
        crop_manifest_path = cfg.manifest_root / cfg.crop_manifest_filename
        if not crop_manifest_path.exists():
            warning = (
                f"crop_mode='ground_truth', but bbox manifest was not found: {crop_manifest_path}; "
                "classification will use full images."
            )
            warnings.append(warning)
            print("WARNING:", warning)
            return cfg.manifest_path, {}, {
                "crop_mode": "ground_truth",
                "crop_with_bbox": False,
                "reason": "bbox manifest not found",
                "crop_manifest": str(crop_manifest_path),
            }
        crop_boxes = _bbox_crop_lookup(crop_manifest_path)
        matched = sum(
            (row.get("split", ""), row.get("image_path", "")) in crop_boxes for row in rows
        )
        if matched != len(rows):
            warnings.append(
                f"bbox crop manifest matched {matched}/{len(rows)} classification rows."
            )
        print("bbox crop manifest:", crop_manifest_path)
        print("bbox crop rows matched:", f"{matched}/{len(rows)}")
        return cfg.manifest_path, {
            "crop_boxes": crop_boxes,
            "crop_padding": cfg.crop_padding,
        }, {
            "crop_mode": "ground_truth",
            "crop_with_bbox": True,
            "crop_manifest": str(crop_manifest_path),
            "crop_padding": cfg.crop_padding,
            "matched_rows": matched,
            "total_rows": len(rows),
        }

    # crop_mode == "predicted": resolve the upstream localization model and
    # generate (or reuse) a predicted-crop manifest read via the crop_path column.
    bundle = model_registry.resolve_model_bundle(
        cfg.crop_task_name,
        selection=cfg.crop_model_selection,
        explicit_dir=cfg.crop_model_artifact_dir,
    )
    print("localization model:", bundle.artifact_dir)
    print("localization onnx:", bundle.onnx_path)
    output_dir = cfg.artifact_dir / cfg.crop_output_dir_name
    report = crops_module.generate_predicted_crop_manifest(
        cfg.manifest_path,
        bundle,
        output_dir,
        dataset_root=cfg.dataset_root,
        padding=cfg.crop_padding,
        regenerate=cfg.regenerate_crops,
    )
    print("predicted crop manifest:", report.manifest_path)
    print("predicted crops:", report.num_crops, "errors:", report.num_errors)
    for message in report.errors[:5]:
        warnings.append(f"predicted crop error: {message}")
    payload = {
        "crop_mode": "predicted",
        "crop_task_name": cfg.crop_task_name,
        "crop_manifest_path": str(report.manifest_path),
        "crop_padding": cfg.crop_padding,
        "num_crops": report.num_crops,
        "num_crop_errors": report.num_errors,
        "crop_errors": report.errors,
        "crop_split_counts": report.splits,
        "crop_mean_iou": report.mean_iou,
        "localization_model": {
            "task_name": bundle.task_name,
            "artifact_dir": str(bundle.artifact_dir),
            "onnx_path": str(bundle.onnx_path) if bundle.onnx_path else None,
            "checkpoint_path": str(bundle.checkpoint_path) if bundle.checkpoint_path else None,
            "best_metric": bundle.best_metric,
            "best_epoch": bundle.best_epoch,
        },
    }
    return report.manifest_path, {"crop_path_column": "crop_path"}, payload


def _labels_from_indices(values: Sequence[int], labels: Sequence[str]) -> list[str]:
    return [labels[int(index)] for index in values]


def _json_safe(value):
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if torch is not None and isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    return value


def _write_json(path: Path, payload: dict | list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(_json_safe(payload), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def _write_metrics_json(cfg: BaseTrainConfig, payload: dict[str, Any]) -> Path:
    _write_json(cfg.metrics_path, payload)
    task_metrics_path = cfg.metrics_path.with_name(f"metrics_{cfg.task_name}.json")
    if task_metrics_path != cfg.metrics_path:
        _write_json(task_metrics_path, payload)


def _maybe_update_latest_pointer(
    cfg: BaseTrainConfig, best_metric: float | None, best_epoch: int | None
) -> Path | None:
    """Write ``<model_dir>/latest.json`` for the just-trained run when requested.

    Only runs when ``cfg.update_latest`` is True; never overwrites pointers
    silently. Failures are downgraded to warnings so training still succeeds.
    """

    if not getattr(cfg, "update_latest", False):
        return None
    try:
        bundle = model_registry.ModelBundle(
            task_name=cfg.task_name,
            artifact_dir=cfg.artifact_dir,
            checkpoint_path=cfg.checkpoint_path if cfg.checkpoint_path.exists() else None,
            onnx_path=cfg.onnx_path if cfg.onnx_path.exists() else None,
            metrics_path=cfg.metrics_path if cfg.metrics_path.exists() else None,
            labels=list(cfg.labels),
            created_at=_created_at(),
            best_metric=best_metric,
            best_epoch=best_epoch,
        )
        pointer = model_registry.write_latest_pointer(str(cfg.model_dir_name), bundle)
        print("updated latest pointer:", pointer)
        return pointer
    except Exception as exc:  # noqa: BLE001 - pointer update must never fail a run
        print("WARNING: could not update latest pointer:", exc)
        return None
    return task_metrics_path


def _format_duration(seconds: float) -> str:
    seconds = max(float(seconds), 0.0)
    minutes, sec = divmod(int(seconds), 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours:d}:{minutes:02d}:{sec:02d}"
    return f"{minutes:02d}:{sec:02d}"


def _format_progress(current: int, total: int | None) -> str:
    if not total:
        return f"{current}"
    width = 24
    ratio = min(max(current / max(total, 1), 0.0), 1.0)
    filled = int(round(width * ratio))
    bar = "#" * filled + "." * (width - filled)
    return f"[{bar}] {current}/{total} ({ratio * 100:5.1f}%)"


def _format_live_metrics(metrics: Mapping[str, Any], task_type: str) -> str:
    parts = [f"loss={float(metrics.get('loss', 0.0)):.4f}"]
    if task_type == "classification":
        parts.append(f"acc={float(metrics.get('accuracy', 0.0)):.3f}")
    elif task_type == "circle":
        parts.append(f"iou={float(metrics.get('circle_iou', 0.0)):.3f}")
    elif task_type == "ellipse":
        parts.append(f"iou={float(metrics.get('ellipse_iou', 0.0)):.3f}")
    else:
        parts.append(f"iou={float(metrics.get('mean_iou', 0.0)):.3f}")
    return " ".join(parts)


def _loader_len(loader) -> int | None:
    try:
        return len(loader)
    except TypeError:
        return None


class _LiveTrainingLogger:
    """Small display-id logger that behaves well in VS Code and terminals."""

    def __init__(
        self,
        *,
        task_name: str,
        task_type: str,
        epochs: int,
        update_interval: float = 0.5,
    ) -> None:
        self.task_name = task_name
        self.task_type = task_type
        self.epochs = epochs
        self.update_interval = update_interval
        self.started_at = time.perf_counter()
        self.last_update_at = 0.0
        self.latest_epoch_line = "waiting for first epoch..."
        self.status_line = "starting"
        self.best_line = ""
        self._handle = None
        self._html_cls = None
        self._last_terminal_width = 0
        self._init_display()
        self.render(force=True)

    def _init_display(self) -> None:
        try:
            from IPython import get_ipython
            from IPython.display import HTML, display

            if get_ipython() is None:
                return
            self._html_cls = HTML
            self._handle = display(self._html(self._text()), display_id=True)
        except Exception:
            self._handle = None
            self._html_cls = None

    def _html(self, text: str):
        if self._html_cls is None:
            return text
        escaped = html.escape(text)
        return self._html_cls(
            "<pre style=\"white-space:pre-wrap; margin:0; "
            "font-family:ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; "
            "font-size:12px; line-height:1.35;\">"
            f"{escaped}</pre>"
        )

    def _text(self) -> str:
        elapsed = _format_duration(time.perf_counter() - self.started_at)
        lines = [
            f"{self.task_name} training",
            f"status: {self.status_line}",
            f"latest: {self.latest_epoch_line}",
        ]
        if self.best_line:
            lines.append(f"best: {self.best_line}")
        lines.append(f"elapsed: {elapsed}")
        return "\n".join(lines)

    def render(self, *, force: bool = False) -> None:
        now = time.perf_counter()
        if not force and now - self.last_update_at < self.update_interval:
            return
        self.last_update_at = now
        text = self._text()
        if self._handle is not None:
            try:
                self._handle.update(self._html(text))
                return
            except Exception:
                self._handle = None

        terminal_line = " | ".join(text.splitlines())
        padding = " " * max(self._last_terminal_width - len(terminal_line), 0)
        self._last_terminal_width = len(terminal_line)
        sys.stdout.write("\r" + terminal_line + padding)
        sys.stdout.flush()

    def start_epoch(self, epoch: int) -> None:
        self.status_line = f"epoch {epoch:03d}/{self.epochs:03d} starting"
        self.render(force=True)

    def update_batch(
        self,
        *,
        epoch: int,
        phase: str,
        batch_index: int,
        total_batches: int | None,
        metrics: Mapping[str, Any],
    ) -> None:
        progress = _format_progress(batch_index, total_batches)
        metric_text = _format_live_metrics(metrics, self.task_type)
        self.status_line = (
            f"epoch {epoch:03d}/{self.epochs:03d} {phase} {progress} {metric_text}"
        )
        self.render()

    def complete_epoch(
        self,
        *,
        epoch: int,
        line: str,
        best_epoch: int,
        best_metric: float,
        metric_name: str,
    ) -> None:
        self.latest_epoch_line = line
        self.best_line = f"epoch {best_epoch:03d} {metric_name}={best_metric:.4f}"
        self.status_line = f"epoch {epoch:03d}/{self.epochs:03d} complete"
        self.render(force=True)
        if self._handle is None:
            sys.stdout.write("\n")
        print(line, flush=True)

    def finish(self, message: str) -> None:
        self.status_line = message
        self.render(force=True)
        if self._handle is None:
            sys.stdout.write("\n")


def _history_init(task: str) -> dict[str, list[Any]]:
    common: dict[str, list[Any]] = {
        "epoch": [],
        "train_loss": [],
        "val_loss": [],
        "lr": [],
        "duration_sec": [],
    }
    if task == "classification":
        common.update({"train_accuracy": [], "val_accuracy": []})
    elif task == "circle":
        common.update(
            {
                "train_circle_iou": [],
                "val_circle_iou": [],
                "train_median_circle_iou": [],
                "val_median_circle_iou": [],
            }
        )
    elif task == "ellipse":
        common.update(
            {
                "train_ellipse_iou": [],
                "val_ellipse_iou": [],
                "train_median_ellipse_iou": [],
                "val_median_ellipse_iou": [],
            }
        )
    else:
        common.update(
            {
                "train_mean_iou": [],
                "val_mean_iou": [],
                "train_median_iou": [],
                "val_median_iou": [],
            }
        )
    return common


def _append_classification_history(
    history: dict[str, list[Any]],
    *,
    epoch: int,
    duration_sec: float,
    train_metrics: dict[str, Any],
    val_metrics: dict[str, Any] | None,
    lr: float | None = None,
) -> None:
    history["epoch"].append(epoch)
    history["duration_sec"].append(duration_sec)
    history["lr"].append(lr)
    history["train_loss"].append(train_metrics["loss"])
    history["train_accuracy"].append(train_metrics["accuracy"])
    history["val_loss"].append(val_metrics["loss"] if val_metrics else None)
    history["val_accuracy"].append(val_metrics["accuracy"] if val_metrics else None)


def _append_bbox_history(
    history: dict[str, list[Any]],
    *,
    epoch: int,
    duration_sec: float,
    train_metrics: dict[str, Any],
    val_metrics: dict[str, Any] | None,
    lr: float | None = None,
) -> None:
    history["epoch"].append(epoch)
    history["duration_sec"].append(duration_sec)
    history["lr"].append(lr)
    history["train_loss"].append(train_metrics["loss"])
    history["train_mean_iou"].append(train_metrics["mean_iou"])
    history["train_median_iou"].append(train_metrics["median_iou"])
    history["val_loss"].append(val_metrics["loss"] if val_metrics else None)
    history["val_mean_iou"].append(val_metrics["mean_iou"] if val_metrics else None)
    history["val_median_iou"].append(val_metrics["median_iou"] if val_metrics else None)


def _append_circle_history(
    history: dict[str, list[Any]],
    *,
    epoch: int,
    duration_sec: float,
    train_metrics: dict[str, Any],
    val_metrics: dict[str, Any] | None,
    lr: float | None = None,
) -> None:
    history["epoch"].append(epoch)
    history["duration_sec"].append(duration_sec)
    history["lr"].append(lr)
    history["train_loss"].append(train_metrics["loss"])
    history["train_circle_iou"].append(train_metrics["circle_iou"])
    history["train_median_circle_iou"].append(train_metrics["median_circle_iou"])
    history["val_loss"].append(val_metrics["loss"] if val_metrics else None)
    history["val_circle_iou"].append(val_metrics["circle_iou"] if val_metrics else None)
    history["val_median_circle_iou"].append(
        val_metrics["median_circle_iou"] if val_metrics else None
    )


def _append_ellipse_history(
    history: dict[str, list[Any]],
    *,
    epoch: int,
    duration_sec: float,
    train_metrics: dict[str, Any],
    val_metrics: dict[str, Any] | None,
    lr: float | None = None,
) -> None:
    history["epoch"].append(epoch)
    history["duration_sec"].append(duration_sec)
    history["lr"].append(lr)
    history["train_loss"].append(train_metrics["loss"])
    history["train_ellipse_iou"].append(train_metrics["ellipse_iou"])
    history["train_median_ellipse_iou"].append(train_metrics["median_ellipse_iou"])
    history["val_loss"].append(val_metrics["loss"] if val_metrics else None)
    history["val_ellipse_iou"].append(val_metrics["ellipse_iou"] if val_metrics else None)
    history["val_median_ellipse_iou"].append(
        val_metrics["median_ellipse_iou"] if val_metrics else None
    )


def _classification_epoch(
    model,
    loader,
    loss_fn,
    device: torch.device,
    optimizer=None,
    *,
    progress: _LiveTrainingLogger | None = None,
    epoch: int | None = None,
    phase: str = "train",
) -> dict[str, Any]:
    is_train = optimizer is not None
    model.train(is_train)
    total_loss = 0.0
    total = 0
    correct = 0
    y_true: list[int] = []
    y_pred: list[int] = []
    total_batches = _loader_len(loader)

    for batch_index, (images, labels) in enumerate(loader, start=1):
        images = images.to(device)
        labels = labels.to(device, dtype=torch.long)
        if is_train:
            optimizer.zero_grad(set_to_none=True)
        with torch.set_grad_enabled(is_train):
            logits = model(images)
            loss = loss_fn(logits, labels)
            if is_train:
                loss.backward()
                optimizer.step()

        preds = logits.argmax(dim=1)
        batch_size = labels.numel()
        total_loss += float(loss.detach().cpu()) * batch_size
        total += batch_size
        correct += int((preds == labels).sum().detach().cpu())
        y_true.extend(labels.detach().cpu().tolist())
        y_pred.extend(preds.detach().cpu().tolist())
        if progress is not None and epoch is not None:
            progress.update_batch(
                epoch=epoch,
                phase=phase,
                batch_index=batch_index,
                total_batches=total_batches,
                metrics={
                    "loss": total_loss / max(total, 1),
                    "accuracy": correct / max(total, 1),
                },
            )

    return {
        "loss": total_loss / max(total, 1),
        "accuracy": correct / max(total, 1),
        "total": total,
        "y_true": y_true,
        "y_pred": y_pred,
    }


def _confusion_matrix(
    y_true: Sequence[int], y_pred: Sequence[int], num_classes: int
) -> list[list[int]]:
    matrix = np.zeros((num_classes, num_classes), dtype=int)
    for truth, pred in zip(y_true, y_pred):
        matrix[int(truth), int(pred)] += 1
    return matrix.tolist()


def _collect_classification_errors(
    model, dataset, labels: Sequence[str], device: torch.device, limit: int = 100
) -> list[dict[str, Any]]:
    errors = []
    model.eval()
    with torch.no_grad():
        for index in range(len(dataset)):
            image, label = dataset[index]
            logits = model(image.unsqueeze(0).to(device))
            pred = int(logits.argmax(dim=1).cpu().item())
            if pred != int(label):
                errors.append(
                    {
                        "image_path": str(dataset.image_paths[index]),
                        "true": labels[int(label)],
                        "pred": labels[pred],
                        "logits": logits.squeeze(0).detach().cpu().tolist(),
                    }
                )
                if len(errors) >= limit:
                    break
    return errors


def _classification_split_payload(
    metrics: dict[str, Any] | None, labels: Sequence[str]
) -> dict[str, Any] | None:
    if not metrics:
        return None
    y_true = metrics.get("y_true") or []
    y_pred = metrics.get("y_pred") or []
    payload = {
        key: value
        for key, value in metrics.items()
        if key not in {"y_true", "y_pred"}
    }
    payload["confusion_matrix"] = _confusion_matrix(y_true, y_pred, len(labels))
    payload["classification_report"] = build_classification_report(
        _labels_from_indices(y_true, labels),
        _labels_from_indices(y_pred, labels),
        labels,
    )
    return payload



def _bbox_epoch(
    model,
    loader,
    loss_fn,
    device: torch.device,
    optimizer=None,
    *,
    progress: _LiveTrainingLogger | None = None,
    epoch: int | None = None,
    phase: str = "train",
) -> dict[str, Any]:
    is_train = optimizer is not None
    model.train(is_train)
    total_loss = 0.0
    total = 0
    iou_sum = 0.0
    all_ious: list[float] = []
    total_batches = _loader_len(loader)

    for batch_index, (images, targets) in enumerate(loader, start=1):
        images = images.to(device)
        targets = targets.to(device, dtype=torch.float32)
        if is_train:
            optimizer.zero_grad(set_to_none=True)
        with torch.set_grad_enabled(is_train):
            preds = model(images)
            loss = loss_fn(preds, targets)
            if is_train:
                loss.backward()
                optimizer.step()

        ious = _bbox_iou(preds.detach(), targets.detach())
        batch_size = images.shape[0]
        total_loss += float(loss.detach().cpu()) * batch_size
        total += batch_size
        iou_values = ious.detach().cpu()
        iou_sum += float(iou_values.sum())
        all_ious.extend(iou_values.tolist())
        if progress is not None and epoch is not None:
            progress.update_batch(
                epoch=epoch,
                phase=phase,
                batch_index=batch_index,
                total_batches=total_batches,
                metrics={
                    "loss": total_loss / max(total, 1),
                    "mean_iou": iou_sum / max(total, 1),
                },
            )

    ious_np = np.array(all_ious, dtype=float)
    return {
        "loss": total_loss / max(total, 1),
        "mean_iou": float(ious_np.mean()) if ious_np.size else 0.0,
        "median_iou": float(np.median(ious_np)) if ious_np.size else 0.0,
        "total": total,
    }


def _collect_bbox_predictions(
    model, dataset, device: torch.device, limit: int | None = 12
) -> list[dict[str, Any]]:
    examples: list[dict[str, Any]] = []
    count = len(dataset) if limit is None else min(len(dataset), limit)
    model.eval()
    with torch.no_grad():
        for index in range(count):
            image, target = dataset[index]
            pred = model(image.unsqueeze(0).to(device)).squeeze(0).detach().cpu()
            target_cpu = target.detach().cpu()

            target_w = float((target_cpu[2] - target_cpu[0]).clamp(min=1e-6))
            target_h = float((target_cpu[3] - target_cpu[1]).clamp(min=1e-6))
            pred_w = float((pred[2] - pred[0]).clamp(min=1e-6))
            pred_h = float((pred[3] - pred[1]).clamp(min=1e-6))

            target_cx = float((target_cpu[0] + target_cpu[2]) / 2)
            target_cy = float((target_cpu[1] + target_cpu[3]) / 2)
            pred_cx = float((pred[0] + pred[2]) / 2)
            pred_cy = float((pred[1] + pred[3]) / 2)

            examples.append(
                {
                    "image_path": str(dataset.image_paths[index]),
                    "split": dataset.rows[index].get("split"),
                    "label_name": dataset.rows[index].get("label_name"),
                    "target_bbox": target_cpu.tolist(),
                    "pred_bbox": pred.tolist(),
                    "iou": float(_bbox_iou(pred.unsqueeze(0), target_cpu.unsqueeze(0)).item()),
                    "target_width": target_w,
                    "target_height": target_h,
                    "pred_width": pred_w,
                    "pred_height": pred_h,
                    "target_aspect_ratio": target_w / target_h,
                    "pred_aspect_ratio": pred_w / pred_h,
                    "center_error": float(((pred_cx - target_cx) ** 2 + (pred_cy - target_cy) ** 2) ** 0.5),
                    "width_error": abs(pred_w - target_w),
                    "height_error": abs(pred_h - target_h),
                    "aspect_error": abs((pred_w / pred_h) - (target_w / target_h)),
                    "area_ratio": (pred_w * pred_h) / max(target_w * target_h, 1e-9),
                }
            )
    return examples


def _bbox_split_payload(metrics: dict[str, Any] | None) -> dict[str, Any] | None:
    if not metrics:
        return None
    return dict(metrics)


def _circle_epoch(
    model,
    loader,
    loss_fn,
    device: torch.device,
    optimizer=None,
    *,
    progress: _LiveTrainingLogger | None = None,
    epoch: int | None = None,
    phase: str = "train",
) -> dict[str, Any]:
    is_train = optimizer is not None
    model.train(is_train)
    total_loss = 0.0
    total = 0
    iou_sum = 0.0
    center_error_sum = 0.0
    radius_error_sum = 0.0
    all_ious: list[float] = []
    all_center_errors: list[float] = []
    all_radius_errors: list[float] = []
    total_batches = _loader_len(loader)

    for batch_index, (images, targets) in enumerate(loader, start=1):
        images = images.to(device)
        targets = targets.to(device, dtype=torch.float32)
        if is_train:
            optimizer.zero_grad(set_to_none=True)
        with torch.set_grad_enabled(is_train):
            preds = model(images)
            loss = loss_fn(preds, targets)
            if is_train:
                loss.backward()
                optimizer.step()

        preds_detached = preds.detach()
        targets_detached = targets.detach()
        ious = _circle_iou(preds_detached, targets_detached).detach().cpu()
        center_errors = torch.linalg.vector_norm(
            preds_detached[:, :2] - targets_detached[:, :2], ord=2, dim=1
        ).cpu()
        radius_errors = torch.abs(preds_detached[:, 2] - targets_detached[:, 2]).cpu()

        batch_size = images.shape[0]
        total_loss += float(loss.detach().cpu()) * batch_size
        total += batch_size
        iou_sum += float(ious.sum())
        center_error_sum += float(center_errors.sum())
        radius_error_sum += float(radius_errors.sum())
        all_ious.extend(ious.tolist())
        all_center_errors.extend(center_errors.tolist())
        all_radius_errors.extend(radius_errors.tolist())
        if progress is not None and epoch is not None:
            progress.update_batch(
                epoch=epoch,
                phase=phase,
                batch_index=batch_index,
                total_batches=total_batches,
                metrics={
                    "loss": total_loss / max(total, 1),
                    "circle_iou": iou_sum / max(total, 1),
                },
            )

    ious_np = np.array(all_ious, dtype=float)
    center_np = np.array(all_center_errors, dtype=float)
    radius_np = np.array(all_radius_errors, dtype=float)
    return {
        "loss": total_loss / max(total, 1),
        "circle_iou": float(ious_np.mean()) if ious_np.size else 0.0,
        "median_circle_iou": float(np.median(ious_np)) if ious_np.size else 0.0,
        "mean_center_error": float(center_np.mean()) if center_np.size else 0.0,
        "median_center_error": float(np.median(center_np)) if center_np.size else 0.0,
        "mean_radius_error": float(radius_np.mean()) if radius_np.size else 0.0,
        "median_radius_error": float(np.median(radius_np)) if radius_np.size else 0.0,
        "total": total,
    }


def _collect_circle_predictions(
    model, dataset, device: torch.device, limit: int | None = 12
) -> list[dict[str, Any]]:
    examples: list[dict[str, Any]] = []
    count = len(dataset) if limit is None else min(len(dataset), limit)
    model.eval()
    with torch.no_grad():
        for index in range(count):
            image, target = dataset[index]
            pred = model(image.unsqueeze(0).to(device)).squeeze(0).detach().cpu()
            target_cpu = target.detach().cpu()
            center_error = float(
                torch.linalg.vector_norm(pred[:2] - target_cpu[:2], ord=2).item()
            )
            radius_error = float(torch.abs(pred[2] - target_cpu[2]).item())
            examples.append(
                {
                    "image_path": str(dataset.image_paths[index]),
                    "split": dataset.rows[index].get("split"),
                    "label_name": dataset.rows[index].get("label_name"),
                    "target_circle": target_cpu.tolist(),
                    "pred_circle": pred.tolist(),
                    "circle_iou": float(
                        _circle_iou(pred.unsqueeze(0), target_cpu.unsqueeze(0)).item()
                    ),
                    "center_error": center_error,
                    "radius_error": radius_error,
                }
            )
    return examples


def _ellipse_angle_error_deg(preds, targets):
    """Per-sample orientation error in degrees (modulo 180) as a CPU tensor."""

    pred_deg = torch.rad2deg(torch.atan2(preds[:, 4], preds[:, 5]))
    target_deg = torch.rad2deg(torch.atan2(targets[:, 4], targets[:, 5]))
    diff = torch.abs(pred_deg - target_deg) % 180.0
    return torch.minimum(diff, 180.0 - diff).cpu()


def _ellipse_epoch(
    model,
    loader,
    loss_fn,
    device: torch.device,
    optimizer=None,
    *,
    progress: _LiveTrainingLogger | None = None,
    epoch: int | None = None,
    phase: str = "train",
) -> dict[str, Any]:
    is_train = optimizer is not None
    model.train(is_train)
    total_loss = 0.0
    total = 0
    iou_sum = 0.0
    all_ious: list[float] = []
    all_center_errors: list[float] = []
    all_major_errors: list[float] = []
    all_minor_errors: list[float] = []
    all_perspective_errors: list[float] = []
    all_angle_errors: list[float] = []
    total_batches = _loader_len(loader)

    for batch_index, (images, targets) in enumerate(loader, start=1):
        images = images.to(device)
        targets = targets.to(device, dtype=torch.float32)
        if is_train:
            optimizer.zero_grad(set_to_none=True)
        with torch.set_grad_enabled(is_train):
            preds = model(images)
            loss = loss_fn(preds, targets)
            if is_train:
                loss.backward()
                optimizer.step()

        preds_d = preds.detach()
        targets_d = targets.detach()
        ious = _ellipse_bbox_iou(preds_d, targets_d).detach().cpu()
        center_errors = torch.linalg.vector_norm(
            preds_d[:, :2] - targets_d[:, :2], ord=2, dim=1
        ).cpu()
        major_errors = torch.abs(preds_d[:, 2] - targets_d[:, 2]).cpu()
        minor_errors = torch.abs(preds_d[:, 3] - targets_d[:, 3]).cpu()
        perspective_errors = torch.abs(preds_d[:, 6] - targets_d[:, 6]).cpu()
        angle_errors = _ellipse_angle_error_deg(preds_d, targets_d)

        batch_size = images.shape[0]
        total_loss += float(loss.detach().cpu()) * batch_size
        total += batch_size
        iou_sum += float(ious.sum())
        all_ious.extend(ious.tolist())
        all_center_errors.extend(center_errors.tolist())
        all_major_errors.extend(major_errors.tolist())
        all_minor_errors.extend(minor_errors.tolist())
        all_perspective_errors.extend(perspective_errors.tolist())
        all_angle_errors.extend(angle_errors.tolist())
        if progress is not None and epoch is not None:
            progress.update_batch(
                epoch=epoch,
                phase=phase,
                batch_index=batch_index,
                total_batches=total_batches,
                metrics={"loss": total_loss / max(total, 1), "ellipse_iou": iou_sum / max(total, 1)},
            )

    def _m(values):
        arr = np.array(values, dtype=float)
        return (float(arr.mean()), float(np.median(arr))) if arr.size else (0.0, 0.0)

    iou_mean, iou_median = _m(all_ious)
    center_mean, center_median = _m(all_center_errors)
    angle_mean, angle_median = _m(all_angle_errors)
    return {
        "loss": total_loss / max(total, 1),
        "ellipse_iou": iou_mean,
        "median_ellipse_iou": iou_median,
        "mean_center_error": center_mean,
        "median_center_error": center_median,
        "mean_major_error": _m(all_major_errors)[0],
        "mean_minor_error": _m(all_minor_errors)[0],
        "mean_perspective_error": _m(all_perspective_errors)[0],
        "mean_angle_error_deg": angle_mean,
        "median_angle_error_deg": angle_median,
        "total": total,
    }


def _collect_ellipse_predictions(
    model, dataset, device: torch.device, limit: int | None = 12
) -> list[dict[str, Any]]:
    examples: list[dict[str, Any]] = []
    count = len(dataset) if limit is None else min(len(dataset), limit)
    model.eval()
    with torch.no_grad():
        for index in range(count):
            image, target = dataset[index]
            pred = model(image.unsqueeze(0).to(device)).squeeze(0).detach().cpu()
            target_cpu = target.detach().cpu()
            center_error = float(torch.linalg.vector_norm(pred[:2] - target_cpu[:2], ord=2).item())
            angle_error = float(
                _ellipse_angle_error_deg(pred.unsqueeze(0), target_cpu.unsqueeze(0))[0].item()
            )
            examples.append(
                {
                    "image_path": str(dataset.image_paths[index]),
                    "split": dataset.rows[index].get("split"),
                    "label_name": dataset.rows[index].get("label_name"),
                    "target_ellipse": target_cpu.tolist(),
                    "pred_ellipse": pred.tolist(),
                    "ellipse_iou": float(
                        _ellipse_bbox_iou(pred.unsqueeze(0), target_cpu.unsqueeze(0)).item()
                    ),
                    "center_error": center_error,
                    "major_error": float(torch.abs(pred[2] - target_cpu[2]).item()),
                    "minor_error": float(torch.abs(pred[3] - target_cpu[3]).item()),
                    "perspective_error": float(torch.abs(pred[6] - target_cpu[6]).item()),
                    "angle_error_deg": angle_error,
                }
            )
    return examples


def _shape_from_value_info(value_info) -> list[Any]:
    dims = []
    for dim in value_info.type.tensor_type.shape.dim:
        if dim.dim_value:
            dims.append(int(dim.dim_value))
        elif dim.dim_param:
            dims.append(str(dim.dim_param))
        else:
            dims.append(None)
    return dims


def _validate_onnx_contract(
    *,
    onnx_path: Path,
    input_size: int,
    output_name: str,
    output_width: int,
) -> tuple[dict[str, Any], list[str]]:
    warnings: list[str] = []
    if not onnx_path.exists() or onnx_path.stat().st_size == 0:
        raise RuntimeError(f"ONNX export failed or produced an empty file: {onnx_path}")

    try:
        import onnx
    except ImportError:
        warnings.append(
            "ONNX file exists, but package 'onnx' is not installed for structural validation."
        )
        return {"path": str(onnx_path), "checked": False, "passed": True}, warnings

    model = onnx.load(onnx_path)
    onnx.checker.check_model(model)
    input_infos = list(model.graph.input)
    output_infos = list(model.graph.output)
    input_names = [item.name for item in input_infos]
    output_names = [item.name for item in output_infos]
    input_shape = _shape_from_value_info(input_infos[0]) if input_infos else []
    output_shape = _shape_from_value_info(output_infos[0]) if output_infos else []

    errors = []
    if input_names != ["input"]:
        errors.append(f"expected input name ['input'], got {input_names}")
    if output_names != [output_name]:
        errors.append(f"expected output name ['{output_name}'], got {output_names}")
    if len(input_shape) != 4:
        errors.append(f"expected input rank 4, got {input_shape}")
    elif input_shape[1:] != [3, input_size, input_size]:
        errors.append(
            f"expected input shape [batch, 3, {input_size}, {input_size}], got {input_shape}"
        )
    if len(output_shape) != 2:
        errors.append(f"expected output rank 2, got {output_shape}")
    elif output_shape[1] != output_width:
        errors.append(f"expected output width {output_width}, got {output_shape}")
    if errors:
        raise RuntimeError("ONNX contract validation failed: " + "; ".join(errors))

    return {
        "path": str(onnx_path),
        "checked": True,
        "passed": True,
        "input_names": input_names,
        "output_names": output_names,
        "input_shape": input_shape,
        "output_shape": output_shape,
    }, warnings


def _count_model_parameters(model) -> dict[str, int]:
    total = sum(int(parameter.numel()) for parameter in model.parameters())
    trainable = sum(
        int(parameter.numel()) for parameter in model.parameters() if parameter.requires_grad
    )
    return {"total": total, "trainable": trainable}


def _benchmark_onnx_runtime(
    *,
    onnx_path: Path,
    input_size: int,
    warmup_runs: int = 5,
    timed_runs: int = 50,
) -> tuple[dict[str, Any] | None, list[str]]:
    warnings: list[str] = []
    try:
        import onnxruntime as ort
    except ImportError:
        warnings.append(
            "ONNXRuntime is not installed; inference latency benchmark was skipped."
        )
        return None, warnings

    providers = ort.get_available_providers()
    provider = (
        "CPUExecutionProvider"
        if "CPUExecutionProvider" in providers
        else providers[0]
        if providers
        else None
    )
    if provider is None:
        warnings.append("ONNXRuntime has no available execution providers.")
        return None, warnings

    session = ort.InferenceSession(str(onnx_path), providers=[provider])
    input_name = session.get_inputs()[0].name
    rng = np.random.default_rng(2026)
    sample = rng.standard_normal((1, 3, input_size, input_size), dtype=np.float32)

    for _ in range(warmup_runs):
        session.run(None, {input_name: sample})

    durations_ms: list[float] = []
    for _ in range(timed_runs):
        started_at = time.perf_counter()
        session.run(None, {input_name: sample})
        durations_ms.append((time.perf_counter() - started_at) * 1000.0)

    values = np.array(durations_ms, dtype=float)
    return {
        "checked": True,
        "provider": provider,
        "available_providers": providers,
        "device": "CPU" if provider == "CPUExecutionProvider" else provider,
        "batch_size": 1,
        "input_shape": [1, 3, int(input_size), int(input_size)],
        "warmup_runs": warmup_runs,
        "timed_runs": timed_runs,
        "mean_ms": float(values.mean()),
        "p95_ms": float(np.percentile(values, 95)),
        "min_ms": float(values.min()),
        "max_ms": float(values.max()),
    }, warnings


def _base_metrics_payload(
    *,
    cfg: BaseTrainConfig,
    report: PreflightReport,
    task_type: str,
    rows: list[dict[str, str]],
    history: dict[str, list[Any]],
    best_epoch: int | None,
    best_metric: float | None,
    checkpoint_path: Path | None,
    onnx_path: Path | None,
    metrics_path: Path | None,
    device: torch.device | None,
    total_time_seconds: float,
    status: str,
    warnings: list[str],
) -> dict[str, Any]:
    dataset_summary = (
        _dataset_summary(cfg=cfg, rows=rows, report=report)
        if rows
        else {
            "name": cfg.dataset_name,
            "root": str(cfg.dataset_root),
            "manifest": str(cfg.manifest_path),
            "rows": 0,
            "splits": report.split_counts,
            "labels": report.class_counts,
            "checked_image_count": report.checked_image_count,
            "missing_image_count": report.missing_image_count,
        }
    )
    return {
        "created_at": _created_at(),
        "task": task_type,
        "task_name": cfg.task_name,
        "dataset_name": cfg.dataset_name,
        "labels": list(cfg.labels),
        "config": cfg.to_dict(),
        "dataset": dataset_summary,
        "split_counts": dict(report.split_counts),
        "class_counts": dict(report.class_counts),
        "history": history,
        "best_epoch": best_epoch,
        "best_metric": best_metric,
        "best_score": best_metric,
        "checkpoint_path": str(checkpoint_path) if checkpoint_path else None,
        "onnx_path": str(onnx_path) if onnx_path else None,
        "metrics_path": str(metrics_path) if metrics_path else None,
        "device": device.type if device else None,
        "total_time_seconds": total_time_seconds,
        "status": status,
        "warnings": list(warnings),
        "artifacts": {
            "checkpoint": str(checkpoint_path) if checkpoint_path else None,
            "onnx": str(onnx_path) if onnx_path else None,
            "metrics": str(metrics_path) if metrics_path else None,
        },
    }


def _write_skipped_result(
    cfg: BaseTrainConfig, report: PreflightReport, started_at: float, task_type: str = "bbox"
) -> TrainingResult:
    if cfg.output_mode == "fail_if_exists" and cfg.metrics_path.exists():
        raise FileExistsError(
            "output_mode='fail_if_exists' blocked writing skipped metrics because this file already exists:\n"
            + str(cfg.metrics_path)
        )
    cfg.artifact_dir.mkdir(parents=True, exist_ok=True)
    total_time_seconds = time.perf_counter() - started_at
    history = _history_init(task_type)
    payload = _base_metrics_payload(
        cfg=cfg,
        report=report,
        task_type=task_type,
        rows=[],
        history=history,
        best_epoch=None,
        best_metric=None,
        checkpoint_path=None,
        onnx_path=None,
        metrics_path=cfg.metrics_path,
        device=None,
        total_time_seconds=total_time_seconds,
        status="skipped",
        warnings=report.warnings,
    )
    payload["skipped"] = True
    payload["reason"] = "; ".join(report.warnings) or "Skipped."
    if cfg.save_metrics_json:
        _write_metrics_json(cfg, payload)
    print(payload["reason"])
    return TrainingResult(
        history=history,
        best_epoch=None,
        best_metric=None,
        checkpoint_path=None,
        onnx_path=None,
        metrics_path=cfg.metrics_path if cfg.save_metrics_json else None,
        total_time_seconds=total_time_seconds,
        status="skipped",
        warnings=list(report.warnings),
        config=cfg,
        metrics=payload,
    )


def _raise_preflight_errors(report: PreflightReport) -> None:
    if report.ok:
        return
    message = "Preflight failed. Fix the errors before training:\n- " + "\n- ".join(
        report.errors
    )
    if report.warnings:
        message += "\nWarnings:\n- " + "\n- ".join(report.warnings)
    raise RuntimeError(message)


def _coerce_classification_config(
    cfg: ClassificationTrainConfig | Mapping[str, Any] | None,
    kwargs: Mapping[str, Any],
) -> ClassificationTrainConfig:
    if isinstance(cfg, ClassificationTrainConfig):
        return cfg
    if cfg is None:
        return ClassificationTrainConfig.from_legacy_kwargs(kwargs)
    if isinstance(cfg, Mapping):
        return ClassificationTrainConfig(**dict(cfg))
    raise TypeError(
        "run_classification_training expects a ClassificationTrainConfig or legacy keyword arguments."
    )


def _coerce_bbox_config(
    cfg: BBoxTrainConfig | Mapping[str, Any] | None, kwargs: Mapping[str, Any]
) -> BBoxTrainConfig:
    if isinstance(cfg, BBoxTrainConfig):
        return cfg
    if cfg is None:
        return BBoxTrainConfig.from_legacy_kwargs(kwargs)
    if isinstance(cfg, Mapping):
        return BBoxTrainConfig(**dict(cfg))
    raise TypeError(
        "run_bbox_training expects a BBoxTrainConfig or legacy keyword arguments."
    )


def _coerce_circle_config(
    cfg: CircleTrainConfig | Mapping[str, Any] | None, kwargs: Mapping[str, Any]
) -> CircleTrainConfig:
    if isinstance(cfg, CircleTrainConfig):
        return cfg
    if cfg is None:
        return CircleTrainConfig.from_legacy_kwargs(kwargs)
    if isinstance(cfg, Mapping):
        return CircleTrainConfig(**dict(cfg))
    raise TypeError(
        "run_circle_training expects a CircleTrainConfig or legacy keyword arguments."
    )


def _coerce_ellipse_config(
    cfg: EllipseTrainConfig | Mapping[str, Any] | None, kwargs: Mapping[str, Any]
) -> EllipseTrainConfig:
    if isinstance(cfg, EllipseTrainConfig):
        return cfg
    if cfg is None:
        return EllipseTrainConfig.from_legacy_kwargs(kwargs)
    if isinstance(cfg, Mapping):
        return EllipseTrainConfig(**dict(cfg))
    raise TypeError(
        "run_ellipse_training expects an EllipseTrainConfig or legacy keyword arguments."
    )


# --------------------------------------------------------------------------- #
# Optuna hyperparameter search (optional dependency).
# --------------------------------------------------------------------------- #

_EPOCH_FN = {
    "bbox": "_bbox_epoch",
    "circle": "_circle_epoch",
    "ellipse": "_ellipse_epoch",
    "classification": "_classification_epoch",
}


def _value_for_metric(metrics: dict[str, Any] | None, optuna_metric: str) -> float | None:
    """Resolve the objective value from a metrics dict by metric name."""

    if not metrics:
        return None
    key = optuna_metric
    for prefix in ("val_", "train_"):
        if key.startswith(prefix):
            key = key[len(prefix):]
            break
    if key in metrics and metrics[key] is not None:
        return float(metrics[key])
    for fallback in ("ellipse_iou", "circle_iou", "mean_iou", "accuracy"):
        if metrics.get(fallback) is not None:
            return float(metrics[fallback])
    if metrics.get("loss") is not None:
        return -float(metrics["loss"])
    return None


def _make_optuna_datasets(cfg: BaseTrainConfig, task: str):
    root = cfg.dataset_root
    flip_h = 0.5 if cfg.augment else 0.0
    flip_v = 0.1 if cfg.augment else 0.0
    if task == "bbox":
        train = BBoxRegressionDataset(
            cfg.manifest_path, cfg.input_size, split="train", dataset_root=root,
            augment=cfg.augment, augment_brightness=cfg.augment_brightness,
            augment_contrast=cfg.augment_contrast, horizontal_flip_p=flip_h, vertical_flip_p=0.0,
        )
        val = BBoxRegressionDataset(cfg.manifest_path, cfg.input_size, split="validation", dataset_root=root)
    elif task == "circle":
        train = CircleRegressionDataset(
            cfg.manifest_path, cfg.input_size, split="train", dataset_root=root,
            augment=cfg.augment, augment_brightness=cfg.augment_brightness,
            augment_contrast=cfg.augment_contrast, horizontal_flip_p=flip_h, vertical_flip_p=flip_v,
        )
        val = CircleRegressionDataset(cfg.manifest_path, cfg.input_size, split="validation", dataset_root=root)
    elif task == "ellipse":
        train = EllipseRegressionDataset(
            cfg.manifest_path, cfg.input_size, split="train", dataset_root=root,
            augment=cfg.augment, augment_brightness=cfg.augment_brightness,
            augment_contrast=cfg.augment_contrast, horizontal_flip_p=flip_h, vertical_flip_p=flip_v,
            min_mask_visible_px=getattr(cfg, "min_mask_visible_px", 0.0),
        )
        val = EllipseRegressionDataset(cfg.manifest_path, cfg.input_size, split="validation", dataset_root=root)
    else:
        # Honor crop_mode so Optuna trials train on the same (predicted/GT) crops
        # as the final run. Crops are generated once and reused across trials.
        manifest_path = cfg.manifest_path
        crop_kwargs: dict[str, Any] = {}
        if isinstance(cfg, ClassificationTrainConfig) and cfg.crop_mode != "none":
            manifest_path, crop_kwargs, _ = _classification_crop_preprocessing(
                cfg, read_csv_manifest(cfg.manifest_path), []
            )
        train = ImageClassificationDataset(
            manifest_path, cfg.input_size, split="train", dataset_root=root,
            augment=cfg.augment, augment_degrees=cfg.augment_degrees,
            augment_brightness=cfg.augment_brightness, augment_contrast=cfg.augment_contrast,
            augment_translate=cfg.augment_translate, **crop_kwargs,
        )
        val = ImageClassificationDataset(
            manifest_path, cfg.input_size, split="validation", dataset_root=root, **crop_kwargs
        )
    return train, val


def _make_optuna_model(cfg: BaseTrainConfig, task: str, device):
    from .models import (
        LegacyBBoxRegressor,
        LegacyCircleRegressor,
        LegacyEllipseRegressor,
        LightweightBBoxRegressor,
        LightweightCircleRegressor,
        LightweightEllipseRegressor,
        LightweightClassifier,
    )

    if task == "bbox":
        if cfg.bbox_model_type == "legacy_cnn":
            model = LegacyBBoxRegressor(input_size=cfg.input_size, dropout=cfg.dropout, base_channels=cfg.base_channels)
        else:
            model = LightweightBBoxRegressor(input_size=cfg.input_size, dropout=cfg.dropout, base_channels=cfg.base_channels)
    elif task == "circle":
        if cfg.circle_model_type == "legacy_cnn":
            model = LegacyCircleRegressor(
                input_size=cfg.input_size, base_channels=cfg.base_channels,
                dropout=cfg.dropout, min_radius=cfg.circle_min_radius,
            )
        else:
            model = LightweightCircleRegressor(
                input_size=cfg.input_size, dropout=cfg.dropout,
                base_channels=cfg.base_channels, min_radius=cfg.circle_min_radius,
            )
    elif task == "ellipse":
        if cfg.ellipse_model_type == "legacy_cnn":
            model = LegacyEllipseRegressor(
                input_size=cfg.input_size, base_channels=cfg.base_channels,
                dropout=cfg.dropout, min_radius=cfg.ellipse_min_radius,
            )
        else:
            model = LightweightEllipseRegressor(
                input_size=cfg.input_size, dropout=cfg.dropout,
                base_channels=cfg.base_channels, min_radius=cfg.ellipse_min_radius,
            )
    else:
        model = LightweightClassifier(
            num_classes=len(cfg.labels), input_size=cfg.input_size,
            dropout=cfg.dropout, base_channels=cfg.base_channels,
        )
    return model.to(device)


def _make_optuna_loss(cfg: BaseTrainConfig, task: str):
    if task == "bbox":
        return build_bbox_loss(cfg)
    if task == "circle":
        return build_circle_loss(cfg)
    if task == "ellipse":
        return build_ellipse_loss(cfg)
    return nn.CrossEntropyLoss()


def _apply_overrides(cfg: BaseTrainConfig, overrides: Mapping[str, Any], **extra) -> BaseTrainConfig:
    field_names = {field.name for field in dataclasses.fields(cfg)}
    payload = {key: value for key, value in {**overrides, **extra}.items() if key in field_names}
    return dataclasses.replace(cfg, **payload)


def _lightweight_train(cfg: BaseTrainConfig, task: str, trial) -> float:
    """Train ``cfg`` for ``optuna_epochs`` and return the best validation metric."""

    optuna = optuna_tuning.ensure_optuna()
    seed_everything(cfg.seed)
    device, _ = resolve_device(cfg.device)
    train_ds, val_ds = _make_optuna_datasets(cfg, task)
    if not len(train_ds):
        raise optuna.TrialPruned()
    train_loader = _loader(train_ds, cfg.batch_size, cfg.num_workers, device, shuffle=True)
    val_loader = _loader(val_ds, cfg.batch_size, cfg.num_workers, device) if len(val_ds) else None

    model = _make_optuna_model(cfg, task, device)
    loss_fn = _make_optuna_loss(cfg, task)
    optimizer = build_optimizer(model, cfg)
    scheduler = build_scheduler(optimizer, cfg, steps_per_epoch=_loader_len(train_loader))
    epoch_fn = globals()[_EPOCH_FN[task]]
    maximize = cfg.optuna_direction == "maximize"

    best: float | None = None
    for epoch in range(1, cfg.epochs + 1):
        epoch_fn(model, train_loader, loss_fn, device, optimizer=optimizer)
        eval_metrics = (
            epoch_fn(model, val_loader, loss_fn, device)
            if val_loader is not None
            else epoch_fn(model, train_loader, loss_fn, device)
        )
        metric = _value_for_metric(eval_metrics, cfg.optuna_metric)
        if metric is None:
            metric = 0.0
        scheduler_step(scheduler, cfg, metric=metric)
        trial.report(metric, epoch)
        if best is None or (maximize and metric > best) or (not maximize and metric < best):
            best = metric
        if trial.should_prune():
            raise optuna.TrialPruned()
    return best if best is not None else 0.0


def _run_optuna_search(cfg: BaseTrainConfig, task: str):
    optuna_tuning.ensure_optuna()
    print(
        f"[optuna] tuning {cfg.task_name}: {cfg.optuna_n_trials} trials x "
        f"{cfg.optuna_epochs} epochs (metric={cfg.optuna_metric}, direction={cfg.optuna_direction})",
        flush=True,
    )

    def objective(trial):
        overrides = optuna_tuning.suggest_overrides(trial, cfg, task)
        trial_cfg = _apply_overrides(cfg, overrides, epochs=cfg.optuna_epochs, use_optuna=False)
        return _lightweight_train(trial_cfg, task, trial)

    study = optuna_tuning.run_study(cfg, objective)
    cfg.artifact_dir.mkdir(parents=True, exist_ok=True)
    artifacts = optuna_tuning.save_optuna_artifacts(study, cfg.artifact_dir)
    print(f"[optuna] best value={study.best_value:.4f}", flush=True)
    print(f"[optuna] best params={study.best_params}", flush=True)
    return study, artifacts


def _optuna_summary_result(cfg: BaseTrainConfig, study, artifacts, started_at: float) -> TrainingResult:
    payload = {
        "status": "optuna",
        "task_name": cfg.task_name,
        "optuna_best_params": study.best_params,
        "optuna_best_value": study.best_value,
        "artifacts": dict(artifacts),
    }
    return TrainingResult(
        history={},
        best_epoch=None,
        best_metric=float(study.best_value),
        checkpoint_path=None,
        onnx_path=None,
        metrics_path=None,
        total_time_seconds=time.perf_counter() - started_at,
        status="optuna",
        warnings=[],
        config=cfg,
        metrics=payload,
    )


def _maybe_optuna(cfg: BaseTrainConfig, task: str, run_fn) -> TrainingResult | None:
    """If ``cfg.use_optuna`` is set, run a study and (optionally) the final train.

    Returns ``None`` when Optuna is disabled so the caller proceeds normally.
    """

    if not getattr(cfg, "use_optuna", False):
        return None
    if task == "bbox" and getattr(cfg, "bbox_model_type", "") == "foreground_mask":
        print("[optuna] foreground_mask has no trainable parameters; skipping Optuna.", flush=True)
        return None

    started_at = time.perf_counter()
    study, optuna_artifacts = _run_optuna_search(cfg, task)
    if not cfg.optuna_final_train:
        return _optuna_summary_result(cfg, study, optuna_artifacts, started_at)

    print("[optuna] training final model with best params...", flush=True)
    final_cfg = _apply_overrides(cfg, study.best_params, use_optuna=False)
    result = run_fn(final_cfg)
    optuna_payload = {
        "best_params": study.best_params,
        "best_value": study.best_value,
        "artifacts": dict(optuna_artifacts),
    }
    result.metrics["optuna"] = optuna_payload
    result.metrics["optuna_best_params"] = study.best_params
    result.metrics.setdefault("artifacts", {}).update(optuna_artifacts)
    if final_cfg.save_metrics_json and result.metrics_path is not None:
        _write_metrics_json(final_cfg, result.metrics)
    return result


def run_classification_training(
    cfg: ClassificationTrainConfig | Mapping[str, Any] | None = None,
    **kwargs,
) -> TrainingResult:
    """Train, evaluate and export a classification model from a notebook config."""

    cfg = _coerce_classification_config(cfg, kwargs)
    optuna_result = _maybe_optuna(cfg, "classification", run_classification_training)
    if optuna_result is not None:
        return optuna_result
    print(f"starting training: {cfg.task_name}", flush=True)
    started_at = time.perf_counter()
    print("running preflight check...", flush=True)
    report = run_preflight_check(cfg)
    _raise_preflight_errors(report)
    print("preflight check passed.", flush=True)
    cfg.ensure_output_allowed()
    cfg.artifact_dir.mkdir(parents=True, exist_ok=True)

    _require_torch()
    from .models import LightweightClassifier

    seed_everything(cfg.seed)
    device, device_warnings = resolve_device(cfg.device)
    warnings = [*report.warnings, *device_warnings]

    rows = read_csv_manifest(cfg.manifest_path)
    dataset_summary = _dataset_summary(cfg=cfg, rows=rows, report=report)
    print("dataset root:", cfg.dataset_root)
    print("manifest:", cfg.manifest_path)
    print("rows:", dataset_summary["rows"])
    print("splits:", dataset_summary["splits"])
    print("labels:", dataset_summary["labels"])
    dataset_manifest_path, crop_options, preprocessing_payload = _classification_crop_preprocessing(
        cfg, rows, warnings
    )

    train_dataset = ImageClassificationDataset(
        dataset_manifest_path,
        cfg.input_size,
        split="train",
        dataset_root=cfg.dataset_root,
        augment=cfg.augment,
        augment_degrees=cfg.augment_degrees,
        augment_brightness=cfg.augment_brightness,
        augment_contrast=cfg.augment_contrast,
        augment_translate=cfg.augment_translate,
        **crop_options,
    )
    val_dataset = ImageClassificationDataset(
        dataset_manifest_path,
        cfg.input_size,
        split="validation",
        dataset_root=cfg.dataset_root,
        **crop_options,
    )
    test_dataset = ImageClassificationDataset(
        dataset_manifest_path,
        cfg.input_size,
        split="test",
        dataset_root=cfg.dataset_root,
        **crop_options,
    )

    train_loader = _loader(
        train_dataset, cfg.batch_size, cfg.num_workers, device, shuffle=True
    )
    val_loader = _loader(val_dataset, cfg.batch_size, cfg.num_workers, device)
    test_loader = _loader(test_dataset, cfg.batch_size, cfg.num_workers, device)

    model = LightweightClassifier(
        num_classes=len(cfg.labels),
        input_size=cfg.input_size,
        dropout=cfg.dropout,
        base_channels=cfg.base_channels,
    ).to(device)
    model_parameters = _count_model_parameters(model)
    loss_fn = nn.CrossEntropyLoss()
    optimizer = build_optimizer(model, cfg)
    scheduler = build_scheduler(optimizer, cfg, steps_per_epoch=_loader_len(train_loader))

    history = _history_init("classification")
    best_state = copy.deepcopy(model.state_dict())
    best_metric = float("-inf")
    best_loss = float("inf")
    best_epoch = 0
    logger = _LiveTrainingLogger(
        task_name=cfg.task_name, task_type="classification", epochs=cfg.epochs
    )
    try:
        for epoch in range(1, cfg.epochs + 1):
            logger.start_epoch(epoch)
            epoch_started_at = time.perf_counter()
            train_metrics = _classification_epoch(
                model,
                train_loader,
                loss_fn,
                device,
                optimizer=optimizer,
                progress=logger,
                epoch=epoch,
                phase="train",
            )
            val_metrics = (
                _classification_epoch(
                    model,
                    val_loader,
                    loss_fn,
                    device,
                    progress=logger,
                    epoch=epoch,
                    phase="validation",
                )
                if len(val_dataset)
                else None
            )
            metric = (
                val_metrics["accuracy"] if val_metrics else train_metrics["accuracy"]
            )
            metric_loss = val_metrics["loss"] if val_metrics else train_metrics["loss"]
            if metric > best_metric or (
                abs(metric - best_metric) <= 1e-12 and metric_loss < best_loss
            ):
                best_metric = metric
                best_loss = metric_loss
                best_epoch = epoch
                best_state = copy.deepcopy(model.state_dict())
            epoch_lr = current_lr(optimizer)
            scheduler_step(scheduler, cfg, metric=metric)
            duration_sec = time.perf_counter() - epoch_started_at
            _append_classification_history(
                history,
                epoch=epoch,
                duration_sec=duration_sec,
                train_metrics=train_metrics,
                val_metrics=val_metrics,
                lr=epoch_lr,
            )
            val_text = (
                f" val_loss={val_metrics['loss']:.4f} val_acc={val_metrics['accuracy']:.3f}"
                if val_metrics
                else ""
            )
            message = (
                f"epoch {epoch:03d}/{cfg.epochs}: "
                f"train_loss={train_metrics['loss']:.4f} "
                f"train_acc={train_metrics['accuracy']:.3f}"
                f"{val_text} "
                f"time={duration_sec:.1f}s"
            )
            logger.complete_epoch(
                epoch=epoch,
                line=message,
                best_epoch=best_epoch,
                best_metric=float(best_metric),
                metric_name="val_acc" if val_metrics else "train_acc",
            )
    except Exception:
        logger.finish("failed")
        raise
    logger.finish("training complete; evaluating and exporting artifacts")

    model.load_state_dict(best_state)
    train_eval_metrics = _classification_epoch(model, train_loader, loss_fn, device)
    val_metrics = (
        _classification_epoch(model, val_loader, loss_fn, device)
        if len(val_dataset)
        else None
    )
    test_metrics = (
        _classification_epoch(model, test_loader, loss_fn, device)
        if len(test_dataset)
        else None
    )
    eval_metrics = test_metrics or val_metrics
    eval_split = "test" if test_metrics else "validation" if val_metrics else "train"
    if eval_metrics is None:
        eval_metrics = train_eval_metrics

    matrix = _confusion_matrix(
        eval_metrics["y_true"], eval_metrics["y_pred"], len(cfg.labels)
    )
    report_payload = build_classification_report(
        _labels_from_indices(eval_metrics["y_true"], cfg.labels),
        _labels_from_indices(eval_metrics["y_pred"], cfg.labels),
        cfg.labels,
    )
    errors = (
        _collect_classification_errors(
            model,
            test_dataset if len(test_dataset) else val_dataset,
            cfg.labels,
            device,
        )
        if (len(test_dataset) or len(val_dataset))
        else []
    )

    torch.save(
        {
            "model_state_dict": model.state_dict(),
            "labels": list(cfg.labels),
            "input_size": cfg.input_size,
            "base_channels": cfg.base_channels,
            "dropout": cfg.dropout,
            "config": cfg.to_dict(),
        },
        cfg.checkpoint_path,
    )
    _write_json(cfg.labels_path, list(cfg.labels))

    model_cpu = model.cpu()
    export_onnx_model(
        model=model_cpu,
        output_path=cfg.onnx_path,
        input_shape=[1, 3, cfg.input_size, cfg.input_size],
        input_names=("input",),
        output_names=("logits",),
        opset_version=13,
        dynamic_batch=True,
        labels=cfg.labels,
        mean=DEFAULT_MEAN,
        std=DEFAULT_STD,
        model_name=cfg.task_name,
    )
    onnx_validation, onnx_warnings = _validate_onnx_contract(
        onnx_path=cfg.onnx_path,
        input_size=cfg.input_size,
        output_name="logits",
        output_width=len(cfg.labels),
    )
    warnings.extend(onnx_warnings)
    onnx_runtime, runtime_warnings = _benchmark_onnx_runtime(
        onnx_path=cfg.onnx_path,
        input_size=cfg.input_size,
    )
    warnings.extend(runtime_warnings)

    total_time_seconds = time.perf_counter() - started_at
    payload = _base_metrics_payload(
        cfg=cfg,
        report=report,
        task_type="classification",
        rows=rows,
        history=history,
        best_epoch=best_epoch,
        best_metric=float(best_metric),
        checkpoint_path=cfg.checkpoint_path,
        onnx_path=cfg.onnx_path,
        metrics_path=cfg.metrics_path,
        device=device,
        total_time_seconds=total_time_seconds,
        status="trained",
        warnings=warnings,
    )
    train_payload = _classification_split_payload(train_eval_metrics, cfg.labels)
    validation_payload = _classification_split_payload(val_metrics, cfg.labels)
    test_payload = _classification_split_payload(test_metrics, cfg.labels)
    payload.update(
        {
            "architecture": "LightweightClassifier",
            "preprocessing": preprocessing_payload,
            "model_parameters": model_parameters,
            "best_loss": best_loss if best_epoch else None,
            "train": train_payload,
            "validation": validation_payload,
            "test": test_payload,
            "split_metrics": {
                "train": train_payload,
                "validation": validation_payload,
                "test": test_payload,
            },
            "evaluation_split": eval_split,
            "confusion_matrix": matrix,
            "classification_report": report_payload,
            "errors": errors,
            "onnx_validation": onnx_validation,
            "onnx_runtime": onnx_runtime,
        }
    )
    try:
        payload["artifacts"].update(save_training_visuals(payload, cfg.artifact_dir))
    except Exception as exc:
        warning = f"Could not save training visuals: {exc}"
        warnings.append(warning)
        payload["warnings"] = warnings
        print("WARNING:", warning)
    if cfg.save_metrics_json:
        _write_metrics_json(cfg, payload)
    torch.save(
        {
            "model_state_dict": model_cpu.state_dict(),
            "labels": list(cfg.labels),
            "input_size": cfg.input_size,
            "base_channels": cfg.base_channels,
            "dropout": cfg.dropout,
            "config": cfg.to_dict(),
            "metrics": payload,
        },
        cfg.checkpoint_path,
    )

    print("saved checkpoint:", cfg.checkpoint_path)
    print("exported onnx:", cfg.onnx_path)
    if cfg.save_metrics_json:
        print("saved metrics:", cfg.metrics_path)
    _maybe_update_latest_pointer(cfg, float(best_metric), best_epoch)
    return TrainingResult(
        history=history,
        best_epoch=best_epoch,
        best_metric=float(best_metric),
        checkpoint_path=cfg.checkpoint_path,
        onnx_path=cfg.onnx_path,
        metrics_path=cfg.metrics_path if cfg.save_metrics_json else None,
        total_time_seconds=total_time_seconds,
        status="trained",
        warnings=warnings,
        config=cfg,
        metrics=payload,
        model=model_cpu,
    )


def run_bbox_training(
    cfg: BBoxTrainConfig | Mapping[str, Any] | None = None,
    **kwargs,
) -> TrainingResult:
    """Train, evaluate and export the victim bbox model from a notebook config."""

    cfg = _coerce_bbox_config(cfg, kwargs)
    optuna_result = _maybe_optuna(cfg, "bbox", run_bbox_training)
    if optuna_result is not None:
        return optuna_result
    print(f"starting training: {cfg.task_name}", flush=True)
    started_at = time.perf_counter()
    print("running preflight check...", flush=True)
    report = run_preflight_check(cfg)
    if report.skipped and report.ok:
        print("preflight check skipped optional bbox training.", flush=True)
        return _write_skipped_result(cfg, report, started_at)
    _raise_preflight_errors(report)
    print("preflight check passed.", flush=True)
    cfg.ensure_output_allowed()
    cfg.artifact_dir.mkdir(parents=True, exist_ok=True)

    _require_torch()
    from .models import ForegroundBBoxRegressor, LegacyBBoxRegressor, LightweightBBoxRegressor

    seed_everything(cfg.seed)
    device, device_warnings = resolve_device(cfg.device)
    warnings = [*report.warnings, *device_warnings]

    rows = read_csv_manifest(cfg.manifest_path)
    dataset_summary = _dataset_summary(cfg=cfg, rows=rows, report=report)
    print("dataset root:", cfg.dataset_root)
    print("manifest:", cfg.manifest_path)
    print("rows:", dataset_summary["rows"])
    print("splits:", dataset_summary["splits"])
    print("labels:", dataset_summary["labels"])

    train_dataset = BBoxRegressionDataset(
        cfg.manifest_path,
        cfg.input_size,
        split="train",
        dataset_root=cfg.dataset_root,
        augment=cfg.augment,
        augment_brightness=cfg.augment_brightness,
        augment_contrast=cfg.augment_contrast,
        horizontal_flip_p=0.5 if cfg.augment else 0.0,
        vertical_flip_p=0.0,
    )
    val_dataset = BBoxRegressionDataset(
        cfg.manifest_path,
        cfg.input_size,
        split="validation",
        dataset_root=cfg.dataset_root,
    )
    test_dataset = BBoxRegressionDataset(
        cfg.manifest_path, cfg.input_size, split="test", dataset_root=cfg.dataset_root
    )

    train_loader = _loader(
        train_dataset, cfg.batch_size, cfg.num_workers, device, shuffle=True
    )
    val_loader = _loader(val_dataset, cfg.batch_size, cfg.num_workers, device)
    test_loader = _loader(test_dataset, cfg.batch_size, cfg.num_workers, device)

    if cfg.bbox_model_type == "foreground_mask":
        model = ForegroundBBoxRegressor(
            input_size=cfg.input_size,
            threshold=cfg.foreground_threshold,
            ignore_margin=cfg.foreground_ignore_margin,
            border=cfg.foreground_border,
            score_mode=cfg.foreground_score_mode,
            mean=DEFAULT_MEAN,
            std=DEFAULT_STD,
        ).to(device)
        model_parameters = _count_model_parameters(model)
        loss_fn = nn.SmoothL1Loss()
        history = _history_init("bbox")

        train_eval_metrics = _bbox_epoch(model, train_loader, loss_fn, device)
        val_metrics = (
            _bbox_epoch(model, val_loader, loss_fn, device)
            if len(val_dataset)
            else None
        )
        test_metrics = (
            _bbox_epoch(model, test_loader, loss_fn, device)
            if len(test_dataset)
            else None
        )
        eval_metrics = val_metrics or train_eval_metrics
        best_metric = float(eval_metrics["mean_iou"])
        best_loss = float(eval_metrics["loss"])
        prediction_dataset = (
            test_dataset
            if len(test_dataset)
            else val_dataset
            if len(val_dataset)
            else train_dataset
        )
        all_prediction_examples = _collect_bbox_predictions(
            model, prediction_dataset, device, limit=None
        )
        best_prediction_examples = sorted(
            all_prediction_examples, key=lambda item: item.get("iou", 0.0), reverse=True
        )[:6]
        worst_prediction_examples = sorted(
            all_prediction_examples, key=lambda item: item.get("iou", 0.0)
        )[:6]
        prediction_examples = best_prediction_examples + worst_prediction_examples

        model_cpu = model.cpu()
        torch.save(
            {
                "model_state_dict": model_cpu.state_dict(),
                "labels": list(cfg.labels),
                "input_size": cfg.input_size,
                "architecture": "ForegroundBBoxRegressor",
                "config": cfg.to_dict(),
            },
            cfg.checkpoint_path,
        )
        _write_json(cfg.labels_path, list(cfg.labels))

        export_onnx_model(
            model=model_cpu,
            output_path=cfg.onnx_path,
            input_shape=[1, 3, cfg.input_size, cfg.input_size],
            input_names=("input",),
            output_names=("bbox",),
            opset_version=13,
            dynamic_batch=True,
            mean=DEFAULT_MEAN,
            std=DEFAULT_STD,
            model_name=cfg.task_name,
        )
        onnx_validation, onnx_warnings = _validate_onnx_contract(
            onnx_path=cfg.onnx_path,
            input_size=cfg.input_size,
            output_name="bbox",
            output_width=4,
        )
        warnings.extend(onnx_warnings)
        onnx_runtime, runtime_warnings = _benchmark_onnx_runtime(
            onnx_path=cfg.onnx_path,
            input_size=cfg.input_size,
        )
        warnings.extend(runtime_warnings)

        total_time_seconds = time.perf_counter() - started_at
        payload = _base_metrics_payload(
            cfg=cfg,
            report=report,
            task_type="bbox",
            rows=rows,
            history=history,
            best_epoch=0,
            best_metric=best_metric,
            checkpoint_path=cfg.checkpoint_path,
            onnx_path=cfg.onnx_path,
            metrics_path=cfg.metrics_path,
            device=device,
            total_time_seconds=total_time_seconds,
            status="exported",
            warnings=warnings,
        )
        train_payload = _bbox_split_payload(train_eval_metrics)
        validation_payload = _bbox_split_payload(val_metrics)
        test_payload = _bbox_split_payload(test_metrics)
        payload.update(
            {
                "architecture": "ForegroundBBoxRegressor",
                "model_parameters": model_parameters,
                "best_loss": best_loss,
                "train": train_payload,
                "validation": validation_payload,
                "test": test_payload,
                "split_metrics": {
                    "train": train_payload,
                    "validation": validation_payload,
                    "test": test_payload,
                },
                "prediction_examples": prediction_examples,
                "best_prediction_examples": best_prediction_examples,
                "worst_prediction_examples": worst_prediction_examples,
                "onnx_validation": onnx_validation,
                "onnx_runtime": onnx_runtime,
            }
        )
        try:
            payload["artifacts"].update(save_training_visuals(payload, cfg.artifact_dir))
        except Exception as exc:
            warning = f"Could not save training visuals: {exc}"
            warnings.append(warning)
            payload["warnings"] = warnings
            print("WARNING:", warning)
        if cfg.save_metrics_json:
            _write_metrics_json(cfg, payload)
        torch.save(
            {
                "model_state_dict": model_cpu.state_dict(),
                "labels": list(cfg.labels),
                "input_size": cfg.input_size,
                "architecture": "ForegroundBBoxRegressor",
                "config": cfg.to_dict(),
                "metrics": payload,
            },
            cfg.checkpoint_path,
        )
        print("saved checkpoint:", cfg.checkpoint_path)
        print("exported onnx:", cfg.onnx_path)
        if cfg.save_metrics_json:
            print("saved metrics:", cfg.metrics_path)
        return TrainingResult(
            history=history,
            best_epoch=0,
            best_metric=best_metric,
            checkpoint_path=cfg.checkpoint_path,
            onnx_path=cfg.onnx_path,
            metrics_path=cfg.metrics_path if cfg.save_metrics_json else None,
            total_time_seconds=total_time_seconds,
            status="exported",
            warnings=warnings,
            config=cfg,
            metrics=payload,
            model=model_cpu,
        )

    if cfg.bbox_model_type == "legacy_cnn":
        model = LegacyBBoxRegressor(
            input_size=cfg.input_size,
            dropout=cfg.dropout,
            base_channels=cfg.base_channels,
        ).to(device)
        architecture_name = "LegacyBBoxRegressor"
    else:
        model = LightweightBBoxRegressor(
            input_size=cfg.input_size,
            dropout=cfg.dropout,
            base_channels=cfg.base_channels,
        ).to(device)
        architecture_name = "LightweightBBoxRegressor"
    loss_fn = build_bbox_loss(cfg)
    model_parameters = _count_model_parameters(model)
    optimizer = build_optimizer(model, cfg)
    scheduler = build_scheduler(optimizer, cfg, steps_per_epoch=_loader_len(train_loader))

    history = _history_init("bbox")
    best_state = copy.deepcopy(model.state_dict())
    best_metric = float("-inf")
    best_loss = float("inf")
    best_epoch = 0
    logger = _LiveTrainingLogger(
        task_name=cfg.task_name, task_type="bbox", epochs=cfg.epochs
    )
    try:
        for epoch in range(1, cfg.epochs + 1):
            logger.start_epoch(epoch)
            epoch_started_at = time.perf_counter()
            train_metrics = _bbox_epoch(
                model,
                train_loader,
                loss_fn,
                device,
                optimizer=optimizer,
                progress=logger,
                epoch=epoch,
                phase="train",
            )
            val_metrics = (
                _bbox_epoch(
                    model,
                    val_loader,
                    loss_fn,
                    device,
                    progress=logger,
                    epoch=epoch,
                    phase="validation",
                )
                if len(val_dataset)
                else None
            )
            metric = (
                val_metrics["mean_iou"] if val_metrics else train_metrics["mean_iou"]
            )
            metric_loss = val_metrics["loss"] if val_metrics else train_metrics["loss"]
            if metric > best_metric or (
                abs(metric - best_metric) <= 1e-12 and metric_loss < best_loss
            ):
                best_metric = metric
                best_loss = metric_loss
                best_epoch = epoch
                best_state = copy.deepcopy(model.state_dict())
            epoch_lr = current_lr(optimizer)
            scheduler_step(scheduler, cfg, metric=metric)
            duration_sec = time.perf_counter() - epoch_started_at
            _append_bbox_history(
                history,
                epoch=epoch,
                duration_sec=duration_sec,
                train_metrics=train_metrics,
                val_metrics=val_metrics,
                lr=epoch_lr,
            )
            val_text = (
                f" val_loss={val_metrics['loss']:.4f} val_iou={val_metrics['mean_iou']:.3f}"
                if val_metrics
                else ""
            )
            message = (
                f"epoch {epoch:03d}/{cfg.epochs}: "
                f"train_loss={train_metrics['loss']:.4f} "
                f"train_iou={train_metrics['mean_iou']:.3f}"
                f"{val_text} "
                f"time={duration_sec:.1f}s"
            )
            logger.complete_epoch(
                epoch=epoch,
                line=message,
                best_epoch=best_epoch,
                best_metric=float(best_metric),
                metric_name="val_iou" if val_metrics else "train_iou",
            )
    except Exception:
        logger.finish("failed")
        raise
    logger.finish("training complete; evaluating and exporting artifacts")

    model.load_state_dict(best_state)
    train_eval_metrics = _bbox_epoch(model, train_loader, loss_fn, device)
    val_metrics = (
        _bbox_epoch(model, val_loader, loss_fn, device) if len(val_dataset) else None
    )
    test_metrics = (
        _bbox_epoch(model, test_loader, loss_fn, device) if len(test_dataset) else None
    )
    prediction_dataset = (
        test_dataset
        if len(test_dataset)
        else val_dataset
        if len(val_dataset)
        else train_dataset
    )
    all_prediction_examples = _collect_bbox_predictions(
        model, prediction_dataset, device, limit=None
    )
    best_prediction_examples = sorted(
        all_prediction_examples, key=lambda item: item.get("iou", 0.0), reverse=True
    )[:6]
    worst_prediction_examples = sorted(
        all_prediction_examples, key=lambda item: item.get("iou", 0.0)
    )[:6]
    prediction_examples = best_prediction_examples + worst_prediction_examples

    torch.save(
        {
            "model_state_dict": model.state_dict(),
            "labels": list(cfg.labels),
            "input_size": cfg.input_size,
            "base_channels": cfg.base_channels,
            "dropout": cfg.dropout,
            "config": cfg.to_dict(),
        },
        cfg.checkpoint_path,
    )
    _write_json(cfg.labels_path, list(cfg.labels))

    model_cpu = model.cpu()
    export_onnx_model(
        model=model_cpu,
        output_path=cfg.onnx_path,
        input_shape=[1, 3, cfg.input_size, cfg.input_size],
        input_names=("input",),
        output_names=("bbox",),
        opset_version=13,
        dynamic_batch=True,
        mean=DEFAULT_MEAN,
        std=DEFAULT_STD,
        model_name=cfg.task_name,
    )
    onnx_validation, onnx_warnings = _validate_onnx_contract(
        onnx_path=cfg.onnx_path,
        input_size=cfg.input_size,
        output_name="bbox",
        output_width=4,
    )
    warnings.extend(onnx_warnings)
    onnx_runtime, runtime_warnings = _benchmark_onnx_runtime(
        onnx_path=cfg.onnx_path,
        input_size=cfg.input_size,
    )
    warnings.extend(runtime_warnings)

    total_time_seconds = time.perf_counter() - started_at
    payload = _base_metrics_payload(
        cfg=cfg,
        report=report,
        task_type="bbox",
        rows=rows,
        history=history,
        best_epoch=best_epoch,
        best_metric=float(best_metric),
        checkpoint_path=cfg.checkpoint_path,
        onnx_path=cfg.onnx_path,
        metrics_path=cfg.metrics_path,
        device=device,
        total_time_seconds=total_time_seconds,
        status="trained",
        warnings=warnings,
    )
    train_payload = _bbox_split_payload(train_eval_metrics)
    validation_payload = _bbox_split_payload(val_metrics)
    test_payload = _bbox_split_payload(test_metrics)
    payload.update(
        {
            "architecture": architecture_name,
            "model_parameters": model_parameters,
            "best_loss": best_loss if best_epoch else None,
            "train": train_payload,
            "validation": validation_payload,
            "test": test_payload,
            "split_metrics": {
                "train": train_payload,
                "validation": validation_payload,
                "test": test_payload,
            },
            "prediction_examples": prediction_examples,
            "best_prediction_examples": best_prediction_examples,
            "worst_prediction_examples": worst_prediction_examples,
            "onnx_validation": onnx_validation,
            "onnx_runtime": onnx_runtime,
        }
    )
    try:
        payload["artifacts"].update(save_training_visuals(payload, cfg.artifact_dir))
    except Exception as exc:
        warning = f"Could not save training visuals: {exc}"
        warnings.append(warning)
        payload["warnings"] = warnings
        print("WARNING:", warning)
    if cfg.save_metrics_json:
        _write_metrics_json(cfg, payload)
    torch.save(
        {
            "model_state_dict": model_cpu.state_dict(),
            "labels": list(cfg.labels),
            "input_size": cfg.input_size,
            "base_channels": cfg.base_channels,
            "dropout": cfg.dropout,
            "config": cfg.to_dict(),
            "metrics": payload,
        },
        cfg.checkpoint_path,
    )

    print("saved checkpoint:", cfg.checkpoint_path)
    print("exported onnx:", cfg.onnx_path)
    if cfg.save_metrics_json:
        print("saved metrics:", cfg.metrics_path)

    _maybe_update_latest_pointer(cfg, float(best_metric), best_epoch)
    return TrainingResult(
        history=history,
        best_epoch=best_epoch,
        best_metric=float(best_metric),
        checkpoint_path=cfg.checkpoint_path,
        onnx_path=cfg.onnx_path,
        metrics_path=cfg.metrics_path if cfg.save_metrics_json else None,
        total_time_seconds=total_time_seconds,
        status="trained",
        warnings=warnings,
        config=cfg,
        metrics=payload,
        model=model_cpu,
    )


def run_circle_training(
    cfg: CircleTrainConfig | Mapping[str, Any] | None = None,
    **kwargs,
) -> TrainingResult:
    """Train, evaluate and export the target circle model from a notebook config.

    Predicts a normalized ``[center_x, center_y, radius]`` triple and exports an
    ONNX graph whose single output is named ``"circle"`` with shape ``[batch, 3]``.
    """

    cfg = _coerce_circle_config(cfg, kwargs)
    optuna_result = _maybe_optuna(cfg, "circle", run_circle_training)
    if optuna_result is not None:
        return optuna_result
    print(f"starting training: {cfg.task_name}", flush=True)
    started_at = time.perf_counter()
    print("running preflight check...", flush=True)
    report = run_preflight_check(cfg)
    if report.skipped and report.ok:
        print("preflight check skipped optional circle training.", flush=True)
        return _write_skipped_result(cfg, report, started_at, task_type="circle")
    _raise_preflight_errors(report)
    print("preflight check passed.", flush=True)
    cfg.ensure_output_allowed()
    cfg.artifact_dir.mkdir(parents=True, exist_ok=True)

    _require_torch()
    from .models import LegacyCircleRegressor, LightweightCircleRegressor

    seed_everything(cfg.seed)
    device, device_warnings = resolve_device(cfg.device)
    warnings = [*report.warnings, *device_warnings]

    rows = read_csv_manifest(cfg.manifest_path)
    dataset_summary = _dataset_summary(cfg=cfg, rows=rows, report=report)
    print("dataset root:", cfg.dataset_root)
    print("manifest:", cfg.manifest_path)
    print("rows:", dataset_summary["rows"])
    print("splits:", dataset_summary["splits"])

    train_dataset = CircleRegressionDataset(
        cfg.manifest_path,
        cfg.input_size,
        split="train",
        dataset_root=cfg.dataset_root,
        augment=cfg.augment,
        augment_brightness=cfg.augment_brightness,
        augment_contrast=cfg.augment_contrast,
        horizontal_flip_p=0.5 if cfg.augment else 0.0,
        vertical_flip_p=0.1 if cfg.augment else 0.0,
    )
    val_dataset = CircleRegressionDataset(
        cfg.manifest_path, cfg.input_size, split="validation", dataset_root=cfg.dataset_root
    )
    test_dataset = CircleRegressionDataset(
        cfg.manifest_path, cfg.input_size, split="test", dataset_root=cfg.dataset_root
    )

    train_loader = _loader(train_dataset, cfg.batch_size, cfg.num_workers, device, shuffle=True)
    val_loader = _loader(val_dataset, cfg.batch_size, cfg.num_workers, device)
    test_loader = _loader(test_dataset, cfg.batch_size, cfg.num_workers, device)

    if cfg.circle_model_type == "legacy_cnn":
        model = LegacyCircleRegressor(
            input_size=cfg.input_size,
            base_channels=cfg.base_channels,
            dropout=cfg.dropout,
            min_radius=cfg.circle_min_radius,
        ).to(device)
        architecture_name = "LegacyCircleRegressor"
    else:
        model = LightweightCircleRegressor(
            input_size=cfg.input_size,
            dropout=cfg.dropout,
            base_channels=cfg.base_channels,
            min_radius=cfg.circle_min_radius,
        ).to(device)
        architecture_name = "LightweightCircleRegressor"
    loss_fn = build_circle_loss(cfg)
    model_parameters = _count_model_parameters(model)
    optimizer = build_optimizer(model, cfg)
    scheduler = build_scheduler(optimizer, cfg, steps_per_epoch=_loader_len(train_loader))

    history = _history_init("circle")
    best_state = copy.deepcopy(model.state_dict())
    best_metric = float("-inf")
    best_loss = float("inf")
    best_epoch = 0
    logger = _LiveTrainingLogger(task_name=cfg.task_name, task_type="circle", epochs=cfg.epochs)
    try:
        for epoch in range(1, cfg.epochs + 1):
            logger.start_epoch(epoch)
            epoch_started_at = time.perf_counter()
            train_metrics = _circle_epoch(
                model, train_loader, loss_fn, device,
                optimizer=optimizer, progress=logger, epoch=epoch, phase="train",
            )
            val_metrics = (
                _circle_epoch(
                    model, val_loader, loss_fn, device,
                    progress=logger, epoch=epoch, phase="validation",
                )
                if len(val_dataset)
                else None
            )
            metric = val_metrics["circle_iou"] if val_metrics else train_metrics["circle_iou"]
            metric_loss = val_metrics["loss"] if val_metrics else train_metrics["loss"]
            if metric > best_metric or (
                abs(metric - best_metric) <= 1e-12 and metric_loss < best_loss
            ):
                best_metric = metric
                best_loss = metric_loss
                best_epoch = epoch
                best_state = copy.deepcopy(model.state_dict())
            epoch_lr = current_lr(optimizer)
            scheduler_step(scheduler, cfg, metric=metric)
            duration_sec = time.perf_counter() - epoch_started_at
            _append_circle_history(
                history,
                epoch=epoch,
                duration_sec=duration_sec,
                train_metrics=train_metrics,
                val_metrics=val_metrics,
                lr=epoch_lr,
            )
            val_text = (
                f" val_loss={val_metrics['loss']:.4f} val_iou={val_metrics['circle_iou']:.3f}"
                if val_metrics
                else ""
            )
            message = (
                f"epoch {epoch:03d}/{cfg.epochs}: "
                f"train_loss={train_metrics['loss']:.4f} "
                f"train_iou={train_metrics['circle_iou']:.3f}"
                f"{val_text} "
                f"time={duration_sec:.1f}s"
            )
            logger.complete_epoch(
                epoch=epoch,
                line=message,
                best_epoch=best_epoch,
                best_metric=float(best_metric),
                metric_name="val_circle_iou" if val_metrics else "train_circle_iou",
            )
    except Exception:
        logger.finish("failed")
        raise
    logger.finish("training complete; evaluating and exporting artifacts")

    model.load_state_dict(best_state)
    train_eval_metrics = _circle_epoch(model, train_loader, loss_fn, device)
    val_metrics = _circle_epoch(model, val_loader, loss_fn, device) if len(val_dataset) else None
    test_metrics = _circle_epoch(model, test_loader, loss_fn, device) if len(test_dataset) else None
    prediction_dataset = (
        test_dataset if len(test_dataset)
        else val_dataset if len(val_dataset)
        else train_dataset
    )
    all_prediction_examples = _collect_circle_predictions(
        model, prediction_dataset, device, limit=None
    )
    best_prediction_examples = sorted(
        all_prediction_examples, key=lambda item: item.get("circle_iou", 0.0), reverse=True
    )[:6]
    worst_prediction_examples = sorted(
        all_prediction_examples, key=lambda item: item.get("circle_iou", 0.0)
    )[:6]
    prediction_examples = best_prediction_examples + worst_prediction_examples

    torch.save(
        {
            "model_state_dict": model.state_dict(),
            "labels": list(cfg.labels),
            "input_size": cfg.input_size,
            "base_channels": cfg.base_channels,
            "dropout": cfg.dropout,
            "architecture": architecture_name,
            "config": cfg.to_dict(),
        },
        cfg.checkpoint_path,
    )
    _write_json(cfg.labels_path, list(cfg.labels))

    model_cpu = model.cpu()
    export_onnx_model(
        model=model_cpu,
        output_path=cfg.onnx_path,
        input_shape=[1, 3, cfg.input_size, cfg.input_size],
        input_names=("input",),
        output_names=("circle",),
        opset_version=13,
        dynamic_batch=True,
        mean=DEFAULT_MEAN,
        std=DEFAULT_STD,
        model_name=cfg.task_name,
    )
    onnx_validation, onnx_warnings = _validate_onnx_contract(
        onnx_path=cfg.onnx_path,
        input_size=cfg.input_size,
        output_name="circle",
        output_width=3,
    )
    warnings.extend(onnx_warnings)
    onnx_runtime, runtime_warnings = _benchmark_onnx_runtime(
        onnx_path=cfg.onnx_path, input_size=cfg.input_size
    )
    warnings.extend(runtime_warnings)

    total_time_seconds = time.perf_counter() - started_at
    payload = _base_metrics_payload(
        cfg=cfg,
        report=report,
        task_type="circle",
        rows=rows,
        history=history,
        best_epoch=best_epoch,
        best_metric=float(best_metric),
        checkpoint_path=cfg.checkpoint_path,
        onnx_path=cfg.onnx_path,
        metrics_path=cfg.metrics_path,
        device=device,
        total_time_seconds=total_time_seconds,
        status="trained",
        warnings=warnings,
    )
    train_payload = _bbox_split_payload(train_eval_metrics)
    validation_payload = _bbox_split_payload(val_metrics)
    test_payload = _bbox_split_payload(test_metrics)
    payload.update(
        {
            "architecture": architecture_name,
            "model_parameters": model_parameters,
            "best_loss": best_loss if best_epoch else None,
            "train": train_payload,
            "validation": validation_payload,
            "test": test_payload,
            "split_metrics": {
                "train": train_payload,
                "validation": validation_payload,
                "test": test_payload,
            },
            "prediction_examples": prediction_examples,
            "best_prediction_examples": best_prediction_examples,
            "worst_prediction_examples": worst_prediction_examples,
            "onnx_validation": onnx_validation,
            "onnx_runtime": onnx_runtime,
        }
    )
    try:
        payload["artifacts"].update(save_training_visuals(payload, cfg.artifact_dir))
    except Exception as exc:
        warning = f"Could not save training visuals: {exc}"
        warnings.append(warning)
        payload["warnings"] = warnings
        print("WARNING:", warning)
    if cfg.save_metrics_json:
        _write_metrics_json(cfg, payload)
    torch.save(
        {
            "model_state_dict": model_cpu.state_dict(),
            "labels": list(cfg.labels),
            "input_size": cfg.input_size,
            "base_channels": cfg.base_channels,
            "dropout": cfg.dropout,
            "architecture": architecture_name,
            "config": cfg.to_dict(),
            "metrics": payload,
        },
        cfg.checkpoint_path,
    )

    print("saved checkpoint:", cfg.checkpoint_path)
    print("exported onnx:", cfg.onnx_path)
    if cfg.save_metrics_json:
        print("saved metrics:", cfg.metrics_path)

    _maybe_update_latest_pointer(cfg, float(best_metric), best_epoch)
    return TrainingResult(
        history=history,
        best_epoch=best_epoch,
        best_metric=float(best_metric),
        checkpoint_path=cfg.checkpoint_path,
        onnx_path=cfg.onnx_path,
        metrics_path=cfg.metrics_path if cfg.save_metrics_json else None,
        total_time_seconds=total_time_seconds,
        status="trained",
        warnings=warnings,
        config=cfg,
        metrics=payload,
        model=model_cpu,
    )


def run_ellipse_training(
    cfg: EllipseTrainConfig | Mapping[str, Any] | None = None,
    **kwargs,
) -> TrainingResult:
    """Train, evaluate and export the target ellipse model from a notebook config.

    Predicts a normalized 7-vector ``[cx, cy, radius_major, radius_minor,
    angle_sin, angle_cos, perspective_ratio]`` and exports an ONNX graph whose
    single output is named ``"ellipse"`` with shape ``[batch, 7]``.
    """

    from .datasets import ELLIPSE_OUTPUT_KEYS

    cfg = _coerce_ellipse_config(cfg, kwargs)
    optuna_result = _maybe_optuna(cfg, "ellipse", run_ellipse_training)
    if optuna_result is not None:
        return optuna_result
    print(f"starting training: {cfg.task_name}", flush=True)
    started_at = time.perf_counter()
    print("running preflight check...", flush=True)
    report = run_preflight_check(cfg)
    if report.skipped and report.ok:
        print("preflight check skipped optional ellipse training.", flush=True)
        return _write_skipped_result(cfg, report, started_at, task_type="ellipse")
    _raise_preflight_errors(report)
    print("preflight check passed.", flush=True)
    cfg.ensure_output_allowed()
    cfg.artifact_dir.mkdir(parents=True, exist_ok=True)

    _require_torch()
    from .models import LegacyEllipseRegressor, LightweightEllipseRegressor

    seed_everything(cfg.seed)
    device, device_warnings = resolve_device(cfg.device)
    warnings = [*report.warnings, *device_warnings]

    rows = read_csv_manifest(cfg.manifest_path)
    dataset_summary = _dataset_summary(cfg=cfg, rows=rows, report=report)
    print("dataset root:", cfg.dataset_root)
    print("manifest:", cfg.manifest_path)
    print("rows:", dataset_summary["rows"])
    print("splits:", dataset_summary["splits"])

    train_dataset = EllipseRegressionDataset(
        cfg.manifest_path, cfg.input_size, split="train", dataset_root=cfg.dataset_root,
        augment=cfg.augment, augment_brightness=cfg.augment_brightness,
        augment_contrast=cfg.augment_contrast,
        horizontal_flip_p=0.5 if cfg.augment else 0.0,
        vertical_flip_p=0.1 if cfg.augment else 0.0,
        min_mask_visible_px=cfg.min_mask_visible_px,
    )
    val_dataset = EllipseRegressionDataset(
        cfg.manifest_path, cfg.input_size, split="validation", dataset_root=cfg.dataset_root
    )
    test_dataset = EllipseRegressionDataset(
        cfg.manifest_path, cfg.input_size, split="test", dataset_root=cfg.dataset_root
    )

    train_loader = _loader(train_dataset, cfg.batch_size, cfg.num_workers, device, shuffle=True)
    val_loader = _loader(val_dataset, cfg.batch_size, cfg.num_workers, device)
    test_loader = _loader(test_dataset, cfg.batch_size, cfg.num_workers, device)

    if cfg.ellipse_model_type == "legacy_cnn":
        model = LegacyEllipseRegressor(
            input_size=cfg.input_size, base_channels=cfg.base_channels,
            dropout=cfg.dropout, min_radius=cfg.ellipse_min_radius,
        ).to(device)
        architecture_name = "LegacyEllipseRegressor"
    else:
        model = LightweightEllipseRegressor(
            input_size=cfg.input_size, dropout=cfg.dropout,
            base_channels=cfg.base_channels, min_radius=cfg.ellipse_min_radius,
        ).to(device)
        architecture_name = "LightweightEllipseRegressor"

    loss_fn = build_ellipse_loss(cfg)
    model_parameters = _count_model_parameters(model)
    optimizer = build_optimizer(model, cfg)
    scheduler = build_scheduler(optimizer, cfg, steps_per_epoch=_loader_len(train_loader))

    history = _history_init("ellipse")
    best_state = copy.deepcopy(model.state_dict())
    best_metric = float("-inf")
    best_loss = float("inf")
    best_epoch = 0
    logger = _LiveTrainingLogger(task_name=cfg.task_name, task_type="ellipse", epochs=cfg.epochs)
    try:
        for epoch in range(1, cfg.epochs + 1):
            logger.start_epoch(epoch)
            epoch_started_at = time.perf_counter()
            train_metrics = _ellipse_epoch(
                model, train_loader, loss_fn, device,
                optimizer=optimizer, progress=logger, epoch=epoch, phase="train",
            )
            val_metrics = (
                _ellipse_epoch(
                    model, val_loader, loss_fn, device,
                    progress=logger, epoch=epoch, phase="validation",
                )
                if len(val_dataset)
                else None
            )
            metric = val_metrics["ellipse_iou"] if val_metrics else train_metrics["ellipse_iou"]
            metric_loss = val_metrics["loss"] if val_metrics else train_metrics["loss"]
            if metric > best_metric or (
                abs(metric - best_metric) <= 1e-12 and metric_loss < best_loss
            ):
                best_metric = metric
                best_loss = metric_loss
                best_epoch = epoch
                best_state = copy.deepcopy(model.state_dict())
            epoch_lr = current_lr(optimizer)
            scheduler_step(scheduler, cfg, metric=metric)
            duration_sec = time.perf_counter() - epoch_started_at
            _append_ellipse_history(
                history, epoch=epoch, duration_sec=duration_sec,
                train_metrics=train_metrics, val_metrics=val_metrics, lr=epoch_lr,
            )
            val_text = (
                f" val_loss={val_metrics['loss']:.4f} val_iou={val_metrics['ellipse_iou']:.3f}"
                if val_metrics else ""
            )
            message = (
                f"epoch {epoch:03d}/{cfg.epochs}: "
                f"train_loss={train_metrics['loss']:.4f} "
                f"train_iou={train_metrics['ellipse_iou']:.3f}"
                f"{val_text} time={duration_sec:.1f}s"
            )
            logger.complete_epoch(
                epoch=epoch, line=message, best_epoch=best_epoch,
                best_metric=float(best_metric),
                metric_name="val_ellipse_iou" if val_metrics else "train_ellipse_iou",
            )
    except Exception:
        logger.finish("failed")
        raise
    logger.finish("training complete; evaluating and exporting artifacts")

    model.load_state_dict(best_state)
    train_eval_metrics = _ellipse_epoch(model, train_loader, loss_fn, device)
    val_metrics = _ellipse_epoch(model, val_loader, loss_fn, device) if len(val_dataset) else None
    test_metrics = _ellipse_epoch(model, test_loader, loss_fn, device) if len(test_dataset) else None
    prediction_dataset = (
        test_dataset if len(test_dataset)
        else val_dataset if len(val_dataset)
        else train_dataset
    )
    all_prediction_examples = _collect_ellipse_predictions(model, prediction_dataset, device, limit=None)
    best_prediction_examples = sorted(
        all_prediction_examples, key=lambda item: item.get("ellipse_iou", 0.0), reverse=True
    )[:6]
    worst_prediction_examples = sorted(
        all_prediction_examples, key=lambda item: item.get("ellipse_iou", 0.0)
    )[:6]
    prediction_examples = best_prediction_examples + worst_prediction_examples

    torch.save(
        {
            "model_state_dict": model.state_dict(), "labels": list(cfg.labels),
            "input_size": cfg.input_size, "base_channels": cfg.base_channels,
            "dropout": cfg.dropout, "architecture": architecture_name, "config": cfg.to_dict(),
        },
        cfg.checkpoint_path,
    )
    _write_json(cfg.labels_path, list(cfg.labels))

    model_cpu = model.cpu()
    export_onnx_model(
        model=model_cpu, output_path=cfg.onnx_path,
        input_shape=[1, 3, cfg.input_size, cfg.input_size],
        input_names=("input",), output_names=("ellipse",), opset_version=13,
        dynamic_batch=True, mean=DEFAULT_MEAN, std=DEFAULT_STD, model_name=cfg.task_name,
        extra_metadata={
            "task_name": cfg.task_name, "output_schema": list(ELLIPSE_OUTPUT_KEYS),
            "dataset_name": cfg.dataset_name, "manifest_filename": cfg.manifest_filename,
        },
    )
    onnx_validation, onnx_warnings = _validate_onnx_contract(
        onnx_path=cfg.onnx_path, input_size=cfg.input_size, output_name="ellipse", output_width=7,
    )
    warnings.extend(onnx_warnings)
    onnx_runtime, runtime_warnings = _benchmark_onnx_runtime(onnx_path=cfg.onnx_path, input_size=cfg.input_size)
    warnings.extend(runtime_warnings)

    total_time_seconds = time.perf_counter() - started_at
    payload = _base_metrics_payload(
        cfg=cfg, report=report, task_type="ellipse", rows=rows, history=history,
        best_epoch=best_epoch, best_metric=float(best_metric),
        checkpoint_path=cfg.checkpoint_path, onnx_path=cfg.onnx_path,
        metrics_path=cfg.metrics_path, device=device,
        total_time_seconds=total_time_seconds, status="trained", warnings=warnings,
    )
    train_payload = _bbox_split_payload(train_eval_metrics)
    validation_payload = _bbox_split_payload(val_metrics)
    test_payload = _bbox_split_payload(test_metrics)
    payload.update(
        {
            "architecture": architecture_name, "model_parameters": model_parameters,
            "best_loss": best_loss if best_epoch else None,
            "output_schema": list(ELLIPSE_OUTPUT_KEYS),
            "train": train_payload, "validation": validation_payload, "test": test_payload,
            "split_metrics": {"train": train_payload, "validation": validation_payload, "test": test_payload},
            "prediction_examples": prediction_examples,
            "best_prediction_examples": best_prediction_examples,
            "worst_prediction_examples": worst_prediction_examples,
            "onnx_validation": onnx_validation, "onnx_runtime": onnx_runtime,
        }
    )
    try:
        payload["artifacts"].update(save_training_visuals(payload, cfg.artifact_dir))
    except Exception as exc:
        warning = f"Could not save training visuals: {exc}"
        warnings.append(warning)
        payload["warnings"] = warnings
        print("WARNING:", warning)
    if cfg.save_metrics_json:
        _write_metrics_json(cfg, payload)
    torch.save(
        {
            "model_state_dict": model_cpu.state_dict(), "labels": list(cfg.labels),
            "input_size": cfg.input_size, "base_channels": cfg.base_channels,
            "dropout": cfg.dropout, "architecture": architecture_name,
            "config": cfg.to_dict(), "metrics": payload,
        },
        cfg.checkpoint_path,
    )

    print("saved checkpoint:", cfg.checkpoint_path)
    print("exported onnx:", cfg.onnx_path)
    if cfg.save_metrics_json:
        print("saved metrics:", cfg.metrics_path)

    _maybe_update_latest_pointer(cfg, float(best_metric), best_epoch)
    return TrainingResult(
        history=history, best_epoch=best_epoch, best_metric=float(best_metric),
        checkpoint_path=cfg.checkpoint_path, onnx_path=cfg.onnx_path,
        metrics_path=cfg.metrics_path if cfg.save_metrics_json else None,
        total_time_seconds=total_time_seconds, status="trained", warnings=warnings,
        config=cfg, metrics=payload, model=model_cpu,
    )
