"""Map (occupancy-grid) subtile dataset + lightweight RF training utilities.

Turns the SLAM map snapshots collected in ``controller/mapsdataset/runs/`` into
per-subtile (quarter-tile, 0.06 m) training samples for lightweight specialist
classifiers (RandomForest): wall presence per edge, curve direction, obstacle,
and an "explored" support signal.

Design notes
------------
* LABELS come from ``real_matrix.txt`` (hand-filled ground truth) by reverse
  engineering the 5x5-per-tile submission-matrix encoding produced by
  ``ros2_mapper/src/submission_matrix_builder.cpp``. This is exact and does not
  depend on grid alignment.
* INPUT patches come from ``occupancy_grid.npy``. Grid<->matrix alignment is
  anchored on the start tile (token ``'5'`` ~= world origin, because the mapper
  uses ``origin_mode: auto_first_pose`` + ``mark_origin_tile_as_start``).
* Area-4 subtiles (token ``'*'``) are skipped. Victim codes on an edge count as
  a wall (the rules place victims on the wall cell).

Everything here is pure numpy + (lazily imported) sklearn/matplotlib so it can be
driven from thin notebooks or the smoke script.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict, replace
from pathlib import Path
from typing import Iterable

import numpy as np

from .config import PROJECT_ROOT
from .map_wbt import WbtTileGrid, load_wbt_grid, resolve_wbt_path

# --------------------------------------------------------------------------- #
# Geometry / encoding constants
# --------------------------------------------------------------------------- #
RUNS_DIR = PROJECT_ROOT / "controller" / "mapsdataset" / "runs"

TILE_SIZE_M = 0.12
SUBTILE_M = 0.06
QUARTER_OFFSET_M = 0.03  # subtile center offset from tile center
DEFAULT_RES = 0.0033

VICTIM_CODES = frozenset("HSUFPCO")
AREA4_TOKEN = "*"
OBSTACLE_TOKEN = "x"
START_TOKEN = "5"

# Quarter local 5x5 center cells (row, col); row 0 == north (top of matrix).
QUARTER_CENTERS = {
    "NW": (1, 1),
    "NE": (1, 3),
    "SW": (3, 1),
    "SE": (3, 3),
}
QUARTER_ORDER = ("NW", "NE", "SW", "SE")

# Edge direction order used everywhere: North, East, South, West.
DIRS = ("N", "E", "S", "W")

# Curve direction codes (match curveProtoTranslationWebots in the builder):
#   1 = SW corner, 2 = NW corner, 3 = NE corner, 4 = SE corner.
CURVE_LABELS = ("none", "SW", "NW", "NE", "SE")

# Feature region layout (3x3 over a north-up patch).
REGION_NAMES = (
    "nw",
    "n",
    "ne",
    "w",
    "c",
    "e",
    "sw",
    "s",
    "se",
)

FEATURE_NAMES: tuple[str, ...] = tuple(
    f"{region}_{kind}" for region in REGION_NAMES for kind in ("occ", "free", "unk")
) + ("occ_global", "free_global", "unk_global", "grad_mean")


# --------------------------------------------------------------------------- #
# Loading
# --------------------------------------------------------------------------- #
def list_runs(runs_dir: Path | str | None = None) -> list[Path]:
    """Return run folders (chronological) that contain an occupancy grid."""
    root = Path(runs_dir) if runs_dir is not None else RUNS_DIR
    if not root.is_dir():
        return []
    return [
        p
        for p in sorted(root.iterdir())
        if p.is_dir() and (p / "occupancy_grid.npy").is_file()
    ]


def load_run(run_dir: Path | str) -> dict:
    """Load one snapshot folder: grid, metadata, submission + real matrices."""
    run_dir = Path(run_dir)
    grid = np.load(run_dir / "occupancy_grid.npy")

    with open(run_dir / "metadata.json") as fh:
        meta = json.load(fh)

    def _read(name: str) -> str:
        path = run_dir / name
        return path.read_text() if path.is_file() else ""

    return {
        "run_id": run_dir.name,
        "run_dir": run_dir,
        "grid": grid,
        "meta": meta,
        "submission": _read("submission_matrix.txt"),
        "real": _read("real_matrix.txt"),
        "wbt_path": resolve_wbt_path(run_dir),
    }


# --------------------------------------------------------------------------- #
# Matrix parsing -> per-subtile labels
# --------------------------------------------------------------------------- #
def matrix_rows(text: str) -> list[str]:
    """Split matrix text into non-empty rows."""
    return [r for r in text.split("\n") if r != ""]


def _char_at(rows: list[str], r: int, c: int) -> str:
    if 0 <= r < len(rows) and 0 <= c < len(rows[r]):
        return rows[r][c]
    return "0"


def _is_wall(ch: str) -> bool:
    return ch == "1" or ch in VICTIM_CODES


def find_anchor_tile(rows: list[str]) -> tuple[int, int] | None:
    """Return the (tile_row, tile_col) of the start tile (token '5'), or None."""
    for r, row in enumerate(rows):
        for c, ch in enumerate(row):
            if ch == START_TOKEN:
                return r // 4, c // 4
    return None


@dataclass
class SubtileLabel:
    walls: dict[str, int]  # {'N':0/1,'E':..,'S':..,'W':..}
    curve: int  # 0..4
    obstacle: int  # 0/1
    value: str  # quarter-center token
    is_area4: bool
    # Per-edge area-4 wildcard ('*'): the edge is shared with an area-4 tile, so
    # its true geometry is a don't-care and must be EXCLUDED from wall train/eval.
    wall_wildcard: dict = field(default_factory=lambda: {d: 0 for d in DIRS})


def _subtile_label(
    rows: list[str], tile_r: int, tile_c: int, quarter: str
) -> SubtileLabel:
    lr, lc = QUARTER_CENTERS[quarter]
    gr = 4 * tile_r + lr
    gc = 4 * tile_c + lc
    center = _char_at(rows, gr, gc)

    n = _char_at(rows, gr - 1, gc)
    s = _char_at(rows, gr + 1, gc)
    w = _char_at(rows, gr, gc - 1)
    e = _char_at(rows, gr, gc + 1)
    walls = {
        "N": int(_is_wall(n)),
        "E": int(_is_wall(e)),
        "S": int(_is_wall(s)),
        "W": int(_is_wall(w)),
    }
    # An edge shared with an area-4 tile reads '*' (area 4 wins the shared cell).
    wildcard = {
        "N": int(n == AREA4_TOKEN),
        "E": int(e == AREA4_TOKEN),
        "S": int(s == AREA4_TOKEN),
        "W": int(w == AREA4_TOKEN),
    }

    # Curve: the two edges of a corner are walls, the OTHER two edges are OPEN, and
    # the corner vertex stays '0' (the arc cuts it off). Requiring the opposite edges
    # to be free is what makes the label match the geometry: a curvedWall has exactly
    # two walls and two open sides (the arc bulges into the open space). Without it the
    # detection mis-fired on fully-walled cells (dead-ends/corridors) and produced
    # spurious curves — up to 4 per tile — that disagreed with the occupancy.
    nw_v = _char_at(rows, gr - 1, gc - 1)
    ne_v = _char_at(rows, gr - 1, gc + 1)
    sw_v = _char_at(rows, gr + 1, gc - 1)
    se_v = _char_at(rows, gr + 1, gc + 1)
    w = walls
    curve = 0
    if w["S"] and w["W"] and not w["N"] and not w["E"] and sw_v == "0":
        curve = 1  # SW
    elif w["N"] and w["W"] and not w["S"] and not w["E"] and nw_v == "0":
        curve = 2  # NW
    elif w["N"] and w["E"] and not w["S"] and not w["W"] and ne_v == "0":
        curve = 3  # NE
    elif w["S"] and w["E"] and not w["N"] and not w["W"] and se_v == "0":
        curve = 4  # SE

    return SubtileLabel(
        walls=walls,
        curve=curve,
        obstacle=int(center == OBSTACLE_TOKEN),
        value=center,
        is_area4=(center == AREA4_TOKEN),
        wall_wildcard=wildcard,
    )


def _wbt_subtile_label(
    wbt: WbtTileGrid, wbt_r: int, wbt_c: int, quarter: str
) -> SubtileLabel:
    walls = {d: int(v) for d, v in wbt.wall_flags(wbt_r, wbt_c, quarter).items()}
    wildcard = dict(wbt.wall_wildcard(wbt_r, wbt_c, quarter))
    obstacle = int(wbt.is_obstacle(wbt_r, wbt_c))
    is_area4 = wbt.is_area4(wbt_r, wbt_c)
    if is_area4:
        value = AREA4_TOKEN
    elif obstacle:
        value = OBSTACLE_TOKEN
    else:
        value = "0"
    return SubtileLabel(
        walls=walls,
        curve=int(wbt.curve_label(wbt_r, wbt_c, quarter)),
        obstacle=obstacle,
        value=value,
        is_area4=is_area4,
        wall_wildcard=wildcard,
    )


def _resolve_label_source(run: dict, label_source: str) -> str:
    if label_source not in {"auto", "wbt", "matrix"}:
        raise ValueError(f"Unknown label_source={label_source!r}")
    if label_source != "auto":
        return label_source
    return "wbt" if run.get("wbt_path") else "matrix"


def _load_run_wbt_grid(run: dict, *, strict: bool) -> WbtTileGrid | None:
    source = run.get("wbt_path") or run.get("run_dir")
    return load_wbt_grid(source, strict=strict) if source else None


def _matrix_tile_dims(rows: list[str]) -> tuple[int, int]:
    if not rows:
        return (0, 0)
    return ((len(rows) - 1) // 4, (max(len(r) for r in rows) - 1) // 4)


# --------------------------------------------------------------------------- #
# Alignment + patch sampling
# --------------------------------------------------------------------------- #
def _quarter_world_offset(quarter: str) -> tuple[float, float]:
    lr, lc = QUARTER_CENTERS[quarter]
    dx = (lc - 2) * QUARTER_OFFSET_M
    dy = (2 - lr) * QUARTER_OFFSET_M  # row grows south
    return dx, dy


def subtile_world_center(
    tile_r: int, tile_c: int, quarter: str, anchor: tuple[int, int]
) -> tuple[float, float]:
    """World (map-frame) center of a subtile given the start-tile anchor."""
    tr0, tc0 = anchor
    x = (tile_c - tc0) * TILE_SIZE_M
    y = (tr0 - tile_r) * TILE_SIZE_M  # tile_r grows south
    dx, dy = _quarter_world_offset(quarter)
    return x + dx, y + dy


def sample_patch(
    grid: np.ndarray, meta: dict, wx: float, wy: float, half_extent_m: float = SUBTILE_M
) -> np.ndarray:
    """Extract a square, north-up occupancy patch centered at world (wx, wy).

    Returns int16 array (2*hc+1, 2*hc+1); out-of-bounds filled with -1 (unknown).
    Row 0 == north, col 0 == west.
    """
    res = float(meta["map"]["resolution"]) or DEFAULT_RES
    ox = float(meta["map"]["origin"]["x"])
    oy = float(meta["map"]["origin"]["y"])
    h, w = grid.shape

    col_c = int(round((wx - ox) / res))
    row_c = int(round((wy - oy) / res))  # grid row grows north
    hc = max(1, int(round(half_extent_m / res)))
    size = 2 * hc + 1

    out = np.full((size, size), -1, dtype=np.int16)
    for i in range(size):
        gr = row_c - hc + i
        if gr < 0 or gr >= h:
            continue
        for j in range(size):
            gc = col_c - hc + j
            if 0 <= gc < w:
                out[i, j] = grid[gr, gc]
    # grid row grows north -> flip so row 0 is north (north-up).
    return out[::-1, :]


# --------------------------------------------------------------------------- #
# Features
# --------------------------------------------------------------------------- #
def _region_slices(size: int) -> list[tuple[slice, slice]]:
    a = size // 3
    b = size - a
    rows = [(0, a), (a, b), (b, size)]
    cols = [(0, a), (a, b), (b, size)]
    return [(slice(r0, r1), slice(c0, c1)) for (r0, r1) in rows for (c0, c1) in cols]


def patch_features(patch: np.ndarray) -> np.ndarray:
    """Return the FEATURE_NAMES vector for a north-up patch."""
    occ = patch >= 65
    free = (patch >= 0) & (patch <= 25)
    unk = patch < 0

    feats: list[float] = []
    for rs, cs in _region_slices(patch.shape[0]):
        reg_n = patch[rs, cs].size
        feats.append(float(occ[rs, cs].sum()) / reg_n)
        feats.append(float(free[rs, cs].sum()) / reg_n)
        feats.append(float(unk[rs, cs].sum()) / reg_n)

    total = patch.size
    feats.append(float(occ.sum()) / total)
    feats.append(float(free.sum()) / total)
    feats.append(float(unk.sum()) / total)

    # Gradient magnitude (treat unknown as 0 occupancy for a stable edge cue).
    known = np.where(unk, 0.0, patch.astype(np.float32) / 100.0)
    gy, gx = np.gradient(known)
    feats.append(float(np.sqrt(gx * gx + gy * gy).mean()))

    return np.asarray(feats, dtype=np.float32)


def core_unknown_ratio(patch: np.ndarray) -> float:
    """Unknown ratio in the central third of the patch (subtile core)."""
    s = patch.shape[0]
    a, b = s // 3, s - s // 3
    core = patch[a:b, a:b]
    return float((core < 0).sum()) / core.size


# --------------------------------------------------------------------------- #
# Masked, model-specific features (each model only looks at its own region)
# --------------------------------------------------------------------------- #
# A 0.12 m window centered on the subtile/tile puts the subtile in the central
# half: fraction [0.25, 0.75]; its edges sit at 0.25 (N/W) and 0.75 (S/E). The
# masks below give each model a focused view, which kills the cross-model overlap
# (wall firing on the central obstacle blob or on a corner arc, etc.).
SUB_LO, SUB_HI = 0.25, 0.75


def _band(size: int, lo: float, hi: float) -> slice:
    a = int(round(lo * size))
    b = int(round(hi * size))
    a = max(0, min(a, size - 1))
    b = max(a + 1, min(b, size))
    return slice(a, b)


def _ratios(patch: np.ndarray, rs: slice, cs: slice) -> tuple[float, float, float]:
    reg = patch[rs, cs]
    n = reg.size or 1
    occ = float((reg >= 65).sum()) / n
    free = float(((reg >= 0) & (reg <= 25)).sum()) / n
    unk = float((reg < 0).sum()) / n
    return occ, free, unk


def _grad_mean(patch: np.ndarray, rs: slice, cs: slice) -> float:
    known = np.where(patch < 0, 0.0, patch.astype(np.float32) / 100.0)[rs, cs]
    if min(known.shape) < 2:
        return 0.0
    gy, gx = np.gradient(known)
    return float(np.sqrt(gx * gx + gy * gy).mean())


WALL_FEATURE_NAMES = (
    "edge_occ", "edge_free", "edge_unk",
    "inside_occ", "inside_free", "inside_unk",
    "outside_occ", "outside_free", "outside_unk",
    "edge_grad",
)


def wall_features(patch: np.ndarray, margin: float = 0.08, band: float = 0.12) -> np.ndarray:
    """Wall-on-NORTH-edge features. The patch is pre-rotated so the target edge is
    north; we only look at a rectangle straddling that edge (inside/outside strips),
    inset laterally by ``margin`` to avoid corner arcs. Ignores center/other edges."""
    s = patch.shape[0]
    cs = _band(s, SUB_LO + margin, SUB_HI - margin)
    edge = SUB_LO
    f: list[float] = []
    f += list(_ratios(patch, _band(s, edge - band, edge + band), cs))   # straddling edge
    f += list(_ratios(patch, _band(s, edge, edge + band), cs))          # inside (subtile)
    f += list(_ratios(patch, _band(s, edge - band, edge), cs))          # outside (neighbor)
    f.append(_grad_mean(patch, _band(s, edge - band, edge + band), cs))
    return np.asarray(f, np.float32)


CURVE_FEATURE_NAMES = (
    "corner_nw", "corner_ne", "corner_sw", "corner_se",
    "edge_n", "edge_e", "edge_s", "edge_w", "center",
)


def curve_features(patch: np.ndarray, margin: float = 0.10, corner: float = 0.18) -> np.ndarray:
    """Curve (0..4) features: occupancy in the 4 corner-INTERIOR diagonal boxes (an
    arc occupies the diagonal; a straight 'L' leaves the corner interior free),
    inset from the edges by ``margin``, plus the 4 edge-band occupancies + center."""
    s = patch.shape[0]
    lo, hi = SUB_LO, SUB_HI
    boxes = {
        "NW": (lo + margin, lo + margin + corner, lo + margin, lo + margin + corner),
        "NE": (lo + margin, lo + margin + corner, hi - margin - corner, hi - margin),
        "SW": (hi - margin - corner, hi - margin, lo + margin, lo + margin + corner),
        "SE": (hi - margin - corner, hi - margin, hi - margin - corner, hi - margin),
    }
    f: list[float] = []
    for k in ("NW", "NE", "SW", "SE"):
        r0, r1, c0, c1 = boxes[k]
        f.append(_ratios(patch, _band(s, r0, r1), _band(s, c0, c1))[0])
    cs = _band(s, lo, hi)
    rs = _band(s, lo, hi)
    eb = 0.06
    f.append(_ratios(patch, _band(s, lo - eb, lo + eb), cs)[0])  # N
    f.append(_ratios(patch, rs, _band(s, hi - eb, hi + eb))[0])  # E
    f.append(_ratios(patch, _band(s, hi - eb, hi + eb), cs)[0])  # S
    f.append(_ratios(patch, rs, _band(s, lo - eb, lo + eb))[0])  # W
    f.append(_ratios(patch, _band(s, 0.4, 0.6), _band(s, 0.4, 0.6))[0])  # center
    return np.asarray(f, np.float32)


OBSTACLE_FEATURE_NAMES = (
    "interior_occ", "interior_free", "interior_unk", "center_occ", "interior_grad",
)


def obstacle_features(patch: np.ndarray, margin: float = 0.20) -> np.ndarray:
    """Obstacle (per TILE) features: occupancy of the tile INTERIOR (edges excluded
    by ``margin`` so walls don't trigger it) + a central square + interior gradient.
    A blob in the middle fires; edge walls do not."""
    s = patch.shape[0]
    rs = _band(s, margin, 1.0 - margin)
    cs = _band(s, margin, 1.0 - margin)
    f = list(_ratios(patch, rs, cs))
    f.append(_ratios(patch, _band(s, 0.4, 0.6), _band(s, 0.4, 0.6))[0])
    f.append(_grad_mean(patch, rs, cs))
    return np.asarray(f, np.float32)


def mask_for(kind: str, size: int, margin: float = 0.10) -> np.ndarray:
    """Boolean mask of the region a model looks at (for visualization)."""
    m = np.zeros((size, size), bool)
    if kind == "wall":
        cs = _band(size, SUB_LO + margin, SUB_HI - margin)
        m[_band(size, SUB_LO - 0.12, SUB_LO + 0.12), cs] = True
    elif kind == "curve":
        lo, hi, corner = SUB_LO, SUB_HI, 0.18
        for (r0, r1, c0, c1) in [
            (lo + margin, lo + margin + corner, lo + margin, lo + margin + corner),
            (lo + margin, lo + margin + corner, hi - margin - corner, hi - margin),
            (hi - margin - corner, hi - margin, lo + margin, lo + margin + corner),
            (hi - margin - corner, hi - margin, hi - margin - corner, hi - margin),
        ]:
            m[_band(size, r0, r1), _band(size, c0, c1)] = True
    elif kind == "obstacle":
        m[_band(size, margin, 1.0 - margin), _band(size, margin, 1.0 - margin)] = True
    return m


# --------------------------------------------------------------------------- #
# Per-run subtile records (cached input for every builder)
# --------------------------------------------------------------------------- #
@dataclass
class SubtileSample:
    run_id: str
    tile_r: int
    tile_c: int
    quarter: str
    patch: np.ndarray  # north-up occupancy patch
    real: SubtileLabel
    submission: SubtileLabel
    augmented: bool = False  # True for rotation/flip/noise variants


def _matrix_anchor_or_default(
    real_rows: list[str], sub_rows: list[str]
) -> tuple[int, int] | None:
    anchor = find_anchor_tile(real_rows) or find_anchor_tile(sub_rows)
    if anchor is not None:
        return anchor
    if not real_rows:
        return None
    return (len(real_rows) // 8, len(real_rows[0]) // 8)


def _build_run_subtiles_matrix(
    run: dict, half_extent_m: float = SUBTILE_M
) -> list[SubtileSample]:
    real_rows = matrix_rows(run["real"]) or matrix_rows(run["submission"])
    sub_rows = matrix_rows(run["submission"])
    if not real_rows:
        return []

    anchor = _matrix_anchor_or_default(real_rows, sub_rows)
    if anchor is None:
        return []
    tile_h, tile_w = _matrix_tile_dims(real_rows)

    samples: list[SubtileSample] = []
    for tr in range(tile_h):
        for tc in range(tile_w):
            for quarter in QUARTER_ORDER:
                real = _subtile_label(real_rows, tr, tc, quarter)
                if real.is_area4:
                    continue  # ignore area 4
                sub = _subtile_label(sub_rows, tr, tc, quarter) if sub_rows else real
                wx, wy = subtile_world_center(tr, tc, quarter, anchor)
                patch = sample_patch(run["grid"], run["meta"], wx, wy, half_extent_m)
                samples.append(
                    SubtileSample(
                        run_id=run["run_id"],
                        tile_r=tr,
                        tile_c=tc,
                        quarter=quarter,
                        patch=patch,
                        real=real,
                        submission=sub,
                    )
                )
    return samples


def _build_run_subtiles_wbt(
    run: dict, half_extent_m: float = SUBTILE_M, strict: bool = False
) -> list[SubtileSample]:
    wbt = _load_run_wbt_grid(run, strict=strict)
    if wbt is None:
        return []

    sub_rows = matrix_rows(run["submission"])
    sub_anchor = find_anchor_tile(sub_rows)
    samples: list[SubtileSample] = []

    for mat_r, mat_c, wbt_r, wbt_c, _tile in wbt.iter_matrix_tiles():
        for quarter in QUARTER_ORDER:
            real = _wbt_subtile_label(wbt, wbt_r, wbt_c, quarter)
            if real.is_area4:
                continue

            if sub_rows and sub_anchor is not None:
                sub_tr = sub_anchor[0] + wbt_r
                sub_tc = sub_anchor[1] + wbt_c
                submission = _subtile_label(sub_rows, sub_tr, sub_tc, quarter)
            else:
                submission = real

            dx, dy = _quarter_world_offset(quarter)
            # SLAM/occupancy frame is the Webots field rotated 90° (the recorder always
            # starts the robot in the same heading): SLAM-east = Webots-north (wbt_r),
            # SLAM-north = -Webots-east (wbt_c). Hence the swap+negate below. The curve
            # and wall labels come out already in this frame, so only the patch position
            # is rotated. Verified by occupancy-centroid agreement (SW/NW/NE/SE separate
            # cleanly) across every recorded run.
            wx = -wbt_r * TILE_SIZE_M + dx
            wy = -wbt_c * TILE_SIZE_M + dy
            patch = sample_patch(run["grid"], run["meta"], wx, wy, half_extent_m)
            samples.append(
                SubtileSample(
                    run_id=run["run_id"],
                    tile_r=mat_r,
                    tile_c=mat_c,
                    quarter=quarter,
                    patch=patch,
                    real=real,
                    submission=submission,
                )
            )
    return samples


def build_run_subtiles(
    run: dict, half_extent_m: float = SUBTILE_M, label_source: str = "auto"
) -> list[SubtileSample]:
    """Parse one run into per-subtile samples.

    ``label_source="auto"`` uses WBT labels when available and falls back to the
    legacy matrix labels otherwise.
    """
    source = _resolve_label_source(run, label_source)
    if source == "matrix":
        return _build_run_subtiles_matrix(run, half_extent_m)
    if source == "wbt":
        if label_source == "wbt":
            return _build_run_subtiles_wbt(run, half_extent_m, strict=True)
        samples = _build_run_subtiles_wbt(run, half_extent_m, strict=False)
        return samples if samples else _build_run_subtiles_matrix(run, half_extent_m)
    raise AssertionError(f"Unhandled label_source={label_source!r}")


def load_all_subtiles(
    runs_dir: Path | str | None = None, label_source: str = "auto"
) -> list[SubtileSample]:
    """Convenience: parse every run under ``runs_dir`` into subtile samples."""
    out: list[SubtileSample] = []
    for run_dir in list_runs(runs_dir):
        out.extend(build_run_subtiles(load_run(run_dir), label_source=label_source))
    return out


# --------------------------------------------------------------------------- #
# Tile-level samples (obstacles span a whole tile, not a quarter)
# --------------------------------------------------------------------------- #
@dataclass
class TileSample:
    run_id: str
    tile_r: int
    tile_c: int
    patch: np.ndarray  # full-tile north-up occupancy crop
    obstacle: int  # 1 if any quarter of the tile holds 'x'
    submission_obstacle: int  # baseline from the submission matrix
    is_area4: bool
    augmented: bool = False


def _tile_obstacle(rows: list[str], tile_r: int, tile_c: int) -> tuple[int, int]:
    """Return (obstacle, area4) for a tile by scanning its 4 quarter centers."""
    obstacle = area4 = 0
    for quarter in QUARTER_ORDER:
        lr, lc = QUARTER_CENTERS[quarter]
        ch = _char_at(rows, 4 * tile_r + lr, 4 * tile_c + lc)
        obstacle |= int(ch == OBSTACLE_TOKEN)
        area4 |= int(ch == AREA4_TOKEN)
    return obstacle, area4


def _build_run_tiles_matrix(
    run: dict, half_extent_m: float = TILE_SIZE_M / 2
) -> list[TileSample]:
    real_rows = matrix_rows(run["real"]) or matrix_rows(run["submission"])
    sub_rows = matrix_rows(run["submission"])
    if not real_rows:
        return []
    anchor = _matrix_anchor_or_default(real_rows, sub_rows)
    if anchor is None:
        return []
    tile_h, tile_w = _matrix_tile_dims(real_rows)

    out: list[TileSample] = []
    for tr in range(tile_h):
        for tc in range(tile_w):
            obstacle, area4 = _tile_obstacle(real_rows, tr, tc)
            if area4:
                continue
            sub_obst = _tile_obstacle(sub_rows, tr, tc)[0] if sub_rows else obstacle
            wx = (tc - anchor[1]) * TILE_SIZE_M  # tile center (quarter offset 0)
            wy = (anchor[0] - tr) * TILE_SIZE_M
            patch = sample_patch(run["grid"], run["meta"], wx, wy, half_extent_m)
            out.append(
                TileSample(run["run_id"], tr, tc, patch, obstacle, sub_obst, area4)
            )
    return out


def _build_run_tiles_wbt(
    run: dict, half_extent_m: float = TILE_SIZE_M / 2, strict: bool = False
) -> list[TileSample]:
    wbt = _load_run_wbt_grid(run, strict=strict)
    if wbt is None:
        return []

    sub_rows = matrix_rows(run["submission"])
    sub_anchor = find_anchor_tile(sub_rows)
    out: list[TileSample] = []

    for mat_r, mat_c, wbt_r, wbt_c, _tile in wbt.iter_matrix_tiles():
        area4 = bool(wbt.is_area4(wbt_r, wbt_c))
        if area4:
            continue
        obstacle = int(wbt.is_obstacle(wbt_r, wbt_c))
        if sub_rows and sub_anchor is not None:
            sub_obst = _tile_obstacle(
                sub_rows, sub_anchor[0] + wbt_r, sub_anchor[1] + wbt_c
            )[0]
        else:
            sub_obst = obstacle
        # Same 90° SLAM/Webots frame rotation as the subtile builder (see note there).
        wx = -wbt_r * TILE_SIZE_M
        wy = -wbt_c * TILE_SIZE_M
        patch = sample_patch(run["grid"], run["meta"], wx, wy, half_extent_m)
        out.append(
            TileSample(
                run["run_id"],
                mat_r,
                mat_c,
                patch,
                obstacle,
                sub_obst,
                area4,
            )
        )
    return out


def build_run_tiles(
    run: dict, half_extent_m: float = TILE_SIZE_M / 2, label_source: str = "auto"
) -> list[TileSample]:
    """Parse one run into per-tile samples with optional WBT ground truth."""
    source = _resolve_label_source(run, label_source)
    if source == "matrix":
        return _build_run_tiles_matrix(run, half_extent_m)
    if source == "wbt":
        if label_source == "wbt":
            return _build_run_tiles_wbt(run, half_extent_m, strict=True)
        tiles = _build_run_tiles_wbt(run, half_extent_m, strict=False)
        return tiles if tiles else _build_run_tiles_matrix(run, half_extent_m)
    raise AssertionError(f"Unhandled label_source={label_source!r}")


def load_all_tiles(
    runs_dir: Path | str | None = None, label_source: str = "auto"
) -> list[TileSample]:
    """Convenience: parse every run under ``runs_dir`` into tile samples."""
    out: list[TileSample] = []
    for run_dir in list_runs(runs_dir):
        out.extend(build_run_tiles(load_run(run_dir), label_source=label_source))
    return out


# --------------------------------------------------------------------------- #
# Physical-obstacle 2x2-tile blocks (detection + centre localisation)
# --------------------------------------------------------------------------- #
# The competition scores "which tile holds the obstacle centre". A physical obstacle
# (DEF OBSTACLE node) is small and can sit anywhere, so the models look at a 2x2 tile
# window (0.24 m) for context: a DETECTION model says whether the window holds an
# obstacle, then a LOCALISATION model regresses the obstacle CENTRE (correcting the
# LiDAR's bias: it only scans the robot-facing faces, so the raw occupied centroid is
# pulled toward the robot). The block is a sliding window (stride 1 tile) anchored at
# its NW tile, covering tiles {r,r+1}x{c,c+1}.
BLOCK_HALF_EXTENT_M = TILE_SIZE_M  # 0.12 m half-extent -> 0.24 m (2x2 tiles)
_BLOCK_GRID = 10  # coarse occupancy grid side appended to the block features

OBSTACLE_BLOCK_FEATURE_NAMES: tuple[str, ...] = (
    "occ_cx", "occ_cy",            # occupied centroid within block (-1..1), naive centre
    "occ_radius", "occ_total", "unk_total",
    # Interior isolated blob (occupied component NOT touching the block border): the
    # obstacle signature. Its centroid is a far better centre estimate than the raw
    # occupied centroid (walls bias the latter). Walls/curves connect to the border.
    "blob_size", "blob_comp", "blob_cx", "blob_cy", "blob_n", "shadow_unk",
    "interior_occ", "center_occ",
) + tuple(f"{r}_occ" for r in REGION_NAMES) + tuple(
    f"grid_{i}" for i in range(_BLOCK_GRID * _BLOCK_GRID)
)


def _interior_blob(occ: np.ndarray) -> tuple[float, float, float, float, int]:
    """Largest occupied connected component not touching the border.

    Returns ``(size_frac, compactness, cx, cy, n_interior_blobs)`` where ``cx``/``cy``
    are the blob centroid in [-1,1] (+east/+north), or zeros if none.
    """
    if occ.sum() == 0:
        return 0.0, 0.0, 0.0, 0.0, 0
    try:
        from scipy.ndimage import label as _label
        lbl, n = _label(occ)
    except Exception:
        return 0.0, 0.0, 0.0, 0.0, 0
    h, w = occ.shape
    c = (h - 1) / 2.0
    best_size = 0
    best = (0.0, 0.0, 0.0, 0.0)
    n_interior = 0
    for i in range(1, n + 1):
        ys, xs = np.where(lbl == i)
        if ys.min() == 0 or xs.min() == 0 or ys.max() == h - 1 or xs.max() == w - 1:
            continue  # touches border -> wall/edge, not an obstacle
        n_interior += 1
        size = len(ys)
        bb = (ys.max() - ys.min() + 1) * (xs.max() - xs.min() + 1)
        if size > best_size:
            best_size = size
            cx = (xs.mean() - c) / (c or 1)
            cy = (c - ys.mean()) / (c or 1)
            best = (size / occ.size, size / (bb or 1), cx, cy)
    return (*best, n_interior)


def obstacle_block_features(patch: np.ndarray) -> np.ndarray:
    """Features for a 2x2-tile block tuned to spot a small interior obstacle blob."""
    occ = patch >= 65
    unk = patch < 0
    n = patch.shape[0]
    c = (n - 1) / 2.0
    if occ.sum() >= 1:
        ys, xs = np.where(occ)
        cx = (xs.mean() - c) / (c or 1)
        cy = (c - ys.mean()) / (c or 1)
    else:
        cx = cy = 0.0
    blob_size, blob_comp, blob_cx, blob_cy, blob_n = _interior_blob(occ)
    # LiDAR shadow: unknown cells directly behind occupied ones (obstacles cast it).
    shadow = float((unk & np.roll(occ, 1, axis=0)).sum()) / (occ.sum() or 1)
    lo, hi = int(n * 0.25), int(n * 0.75)
    interior_occ = float(occ[lo:hi, lo:hi].mean())
    cc = int(n * 0.4), int(n * 0.6)
    center_occ = float(occ[cc[0]:cc[1], cc[0]:cc[1]].mean())
    feats = [cx, cy, float(np.hypot(cx, cy)), float(occ.mean()), float(unk.mean()),
             blob_size, blob_comp, blob_cx, blob_cy, float(blob_n) / 4.0, shadow,
             interior_occ, center_occ]
    for rs, cs in _region_slices(n):
        feats.append(float(occ[rs, cs].mean()))
    # Coarse occupied-fraction grid: preserves the spatial layout so the RF can tell a
    # compact interior blob (obstacle) from edge-aligned wall lines.
    k = _BLOCK_GRID
    occ_f = occ.astype(np.float32)
    for i in range(k):
        for j in range(k):
            feats.append(float(occ_f[i * n // k:(i + 1) * n // k,
                                     j * n // k:(j + 1) * n // k].mean()))
    return np.asarray(feats, np.float32)


def localize_obstacle_center(patch: np.ndarray) -> tuple[float, float] | None:
    """Centre of the obstacle as a block-relative offset ``(east, north)`` in [-1,1].

    Uses the centroid of the largest interior occupied blob (the scanned obstacle
    shell). The full flood-fill of the unknown interior is NOT used for the centre: in
    a SLAM grid the unknown region is unbounded behind walls, so when the LiDAR only
    saw part of the shell the flood leaks out and biases the centroid. Returns ``None``
    when no interior blob is present (obstacle unscanned / at the block border)."""
    occ = patch >= 65
    size, _comp, cx, cy, n_blobs = _interior_blob(occ)
    if n_blobs == 0 or size == 0.0:
        return None
    return (float(cx), float(cy))


@dataclass
class ObstacleBlock:
    run_id: str
    tile_r: int                       # matrix coords of the NW-anchor tile
    tile_c: int
    patch: np.ndarray                 # north-up SLAM occupancy, 0.24 m (2x2 tiles)
    has_obstacle: int                 # 1 if an obstacle centre falls in the 2x2 block
    center_off: tuple[float, float] | None  # (ndx, ndy) in [-1,1], None if no obstacle
    center_tile: tuple[int, int] | None     # matrix (tile_r,tile_c) holding the centre
    augmented: bool = False


def build_run_obstacle_blocks(run: dict, strict: bool = False) -> list[ObstacleBlock]:
    """Sliding 2x2-tile blocks for one run, labelled from the .wbt OBSTACLE nodes."""
    wbt = _load_run_wbt_grid(run, strict=strict)
    if wbt is None:
        return []
    obstacles = wbt.obstacle_cells()
    wbt_to_mat = {
        (wr, wc): (mr, mc) for mr, mc, wr, wc, _t in wbt.iter_matrix_tiles()
    }
    out: list[ObstacleBlock] = []
    for (wr, wc), (mr, mc) in wbt_to_mat.items():
        bcx = -(wr + 0.5) * TILE_SIZE_M  # SLAM centre of the 2x2 block
        bcy = -(wc + 0.5) * TILE_SIZE_M
        patch = sample_patch(run["grid"], run["meta"], bcx, bcy, BLOCK_HALF_EXTENT_M)
        in_block = [
            ob for ob in obstacles
            if wr - 0.5 <= ob["wbt_r"] <= wr + 1.5
            and wc - 0.5 <= ob["wbt_c"] <= wc + 1.5
        ]
        if in_block:
            ob = min(
                in_block,
                key=lambda o: (o["wbt_r"] - (wr + 0.5)) ** 2
                + (o["wbt_c"] - (wc + 0.5)) ** 2,
            )
            # Centre offset from block centre, normalised to [-1,1] over the block
            # half-width (1 tile). +ndx = obstacle further north, +ndy = further west,
            # matching the patch's north-up/(west=+) row/col axes.
            ndx = (wr + 0.5) - ob["wbt_r"]
            ndy = (wc + 0.5) - ob["wbt_c"]
            cr, cc = int(round(ob["wbt_r"])), int(round(ob["wbt_c"]))
            center_tile = (mr + (cr - wr), mc + (cc - wc))
            out.append(ObstacleBlock(run["run_id"], mr, mc, patch, 1,
                                     (float(ndx), float(ndy)), center_tile))
        else:
            out.append(ObstacleBlock(run["run_id"], mr, mc, patch, 0, None, None))
    return out


def load_all_obstacle_blocks(runs_dir: Path | str | None = None) -> list[ObstacleBlock]:
    out: list[ObstacleBlock] = []
    for run_dir in list_runs(runs_dir):
        out.extend(build_run_obstacle_blocks(load_run(run_dir)))
    return out


def filter_explored_blocks(blocks: Iterable[ObstacleBlock], thr: float = 0.5) -> list:
    """Keep blocks whose core is sufficiently observed (so detection isn't asked to
    decide on unscanned windows). Positive blocks are always kept (the obstacle was
    placed there even if partially scanned)."""
    return [b for b in blocks if b.has_obstacle or core_unknown_ratio(b.patch) < thr]


def _rot_flip_offset(off: tuple[float, float], k: int, flip: bool) -> tuple[float, float]:
    """Transform a centre offset ``(east, north)`` under ``np.rot90(k)`` + optional
    ``np.fliplr`` so it stays consistent with the rotated/flipped patch."""
    x, y = off
    for _ in range(k % 4):
        x, y = -y, x          # np.rot90 (CCW): (east,north) -> (-north,east)
    if flip:
        x = -x                # np.fliplr mirrors the east axis
    return (x, y)


def augment_obstacle_blocks(
    blocks: Iterable[ObstacleBlock], cfg: AugmentConfig
) -> list[ObstacleBlock]:
    """Dihedral (rot90/flip) variants of blocks; centre offset transformed to match."""
    geoms = [(0, False)]
    if cfg.rotations:
        geoms += [(1, False), (2, False), (3, False)]
    if cfg.flips:
        geoms += [(0, True)] + ([(1, True), (2, True), (3, True)] if cfg.rotations else [])
    out: list[ObstacleBlock] = []
    for b in blocks:
        for k, flip in geoms:
            p = np.rot90(b.patch, k % 4)
            if flip:
                p = np.fliplr(p)
            aug = (k % 4 != 0) or flip
            off = _rot_flip_offset(b.center_off, k, flip) if b.center_off else None
            out.append(replace(b, patch=np.ascontiguousarray(p), center_off=off,
                               augmented=b.augmented or aug))
    return out


def build_obstacle_detection_dataset(
    blocks: Iterable[ObstacleBlock], augment: AugmentConfig | None = None
) -> Dataset:
    """Per-block binary dataset: does this 2x2 window hold an obstacle centre?"""
    src = augment_obstacle_blocks(blocks, augment) if augment is not None else list(blocks)
    X, y, g, b_, P, R = [], [], [], [], [], []
    for blk in src:
        X.append(obstacle_block_features(blk.patch))
        y.append(int(blk.has_obstacle))
        g.append(blk.run_id)
        b_.append(-1)
        P.append(None if blk.augmented else blk.patch)
        R.append(not blk.augmented)
    return _finish(X, y, g, b_, P, R, ("clear", "obstacle"), "obstacle_block",
                   OBSTACLE_BLOCK_FEATURE_NAMES)


def build_obstacle_localization_arrays(
    blocks: Iterable[ObstacleBlock], augment: AugmentConfig | None = None
) -> dict:
    """Arrays for the centre-regression model (positive blocks only).

    Returns ``X`` (features), ``Y`` (n,2 centre offset in [-1,1], (east,north)),
    ``groups`` (run id), ``patches`` (None for augmented), ``is_real`` mask.
    """
    pos = [b for b in blocks if b.has_obstacle]
    src = augment_obstacle_blocks(pos, augment) if augment is not None else pos
    X, Y, g, P, R = [], [], [], [], []
    for blk in src:
        X.append(obstacle_block_features(blk.patch))
        Y.append(blk.center_off)
        g.append(blk.run_id)
        P.append(None if blk.augmented else blk.patch)
        R.append(not blk.augmented)
    return {
        "X": np.asarray(X, np.float32),
        "Y": np.asarray(Y, np.float32),
        "groups": np.asarray(g),
        "patches": P,
        "is_real": np.asarray(R, bool),
        "feature_names": OBSTACLE_BLOCK_FEATURE_NAMES,
    }


def obstacle_blob_mask(patch: np.ndarray, seed_rc: tuple[int, int] | None = None,
                       max_radius_cells: int | None = None) -> np.ndarray:
    """Flood-fill the obstacle footprint (secondary to the centre).

    The LiDAR never sees *inside* a solid obstacle, so its interior stays UNKNOWN
    ringed by OCCUPIED cells. Starting from the block centre (or ``seed_rc``), grow
    through unknown/occupied cells, stopping at free cells — that connected blob is
    the obstacle. Returns a boolean mask the size of ``patch``.
    """
    h, w = patch.shape[:2]
    if seed_rc is None:
        seed_rc = (h // 2, w // 2)
    free = (patch >= 0) & (patch <= 25)
    mask = np.zeros((h, w), bool)
    from collections import deque
    sr, sc = seed_rc
    if not (0 <= sr < h and 0 <= sc < w) or free[sr, sc]:
        return mask
    dq = deque([(sr, sc)])
    mask[sr, sc] = True
    while dq:
        r, c = dq.popleft()
        if max_radius_cells is not None and abs(r - sr) + abs(c - sc) > max_radius_cells:
            continue
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nr, nc = r + dr, c + dc
            if 0 <= nr < h and 0 <= nc < w and not mask[nr, nc] and not free[nr, nc]:
                mask[nr, nc] = True
                dq.append((nr, nc))
    return mask


def train_obstacle_detector(
    blocks: Iterable[ObstacleBlock],
    augment: AugmentConfig | None = None,
    n_estimators: int = 400,
    max_depth: int = 16,
    **rf_kw,
):
    """Fit the block-level obstacle DETECTION RandomForest (class-balanced)."""
    from sklearn.ensemble import RandomForestClassifier

    ds = build_obstacle_detection_dataset(blocks, augment=augment)
    clf = RandomForestClassifier(
        n_estimators=n_estimators, max_depth=max_depth, class_weight="balanced",
        n_jobs=-1, random_state=42, **rf_kw,
    )
    clf.fit(ds.X, ds.y)
    return clf


def obstacle_block_center_tile(
    block: ObstacleBlock, offset: tuple[float, float]
) -> tuple[int, int]:
    """Matrix tile holding a localised centre ``offset`` (east,north) in a block.

    Mirrors the rounding in :func:`build_run_obstacle_blocks` so prediction and ground
    truth agree: the centre tile is the block's NW anchor shifted by ``round(0.5-off)``
    along each axis (the 2x2 block's NW anchor is ``(block.tile_r, block.tile_c)``)."""
    e, n = offset
    return (block.tile_r + int(np.rint(0.5 - e)), block.tile_c + int(np.rint(0.5 - n)))


def obstacle_pipeline_report(run: dict, detector, thr: float = 0.4) -> dict:
    """Slide the detector over a run, localise centres, dedupe to obstacle tiles.

    Returns ``predicted_tiles`` (set), ``truth_tiles`` (set from the .wbt) and the
    per-tile best ``detections`` ``{tile: (proba, offset)}``. A block only counts when
    it both fires (proba >= ``thr``) and has a localisable interior blob.
    """
    blocks = filter_explored_blocks(build_run_obstacle_blocks(run))
    dets: dict[tuple[int, int], tuple[float, tuple[float, float]]] = {}
    for b in blocks:
        x = obstacle_block_features(b.patch).reshape(1, -1)
        p = float(detector.predict_proba(x)[0, 1])
        if p < thr:
            continue
        off = localize_obstacle_center(b.patch)
        if off is None:
            continue
        tile = obstacle_block_center_tile(b, off)
        if tile not in dets or p > dets[tile][0]:
            dets[tile] = (p, off)
    truth = {b.center_tile for b in blocks if b.has_obstacle}
    return {"predicted_tiles": set(dets), "truth_tiles": truth, "detections": dets}


def _matrix_relative_tile_key(
    run: dict, sample: SubtileSample
) -> tuple[int, int, str]:
    rows = matrix_rows(run["real"]) or matrix_rows(run["submission"])
    sub_rows = matrix_rows(run["submission"])
    anchor = _matrix_anchor_or_default(rows, sub_rows) or (0, 0)
    return (sample.tile_r - anchor[0], sample.tile_c - anchor[1], sample.quarter)


def _wbt_relative_tile_key(wbt: WbtTileGrid, sample: SubtileSample) -> tuple[int, int, str]:
    wbt_r, wbt_c = wbt.from_matrix_rc(sample.tile_r, sample.tile_c)
    return (wbt_r, wbt_c, sample.quarter)


def compare_wbt_vs_matrix(run: dict) -> dict:
    """Compare WBT-derived subtile labels against the legacy matrix labels."""
    wbt = _load_run_wbt_grid(run, strict=True)
    assert wbt is not None

    wbt_samples = build_run_subtiles(run, label_source="wbt")
    matrix_samples = build_run_subtiles(run, label_source="matrix")

    wbt_by = {_wbt_relative_tile_key(wbt, s): s for s in wbt_samples}
    matrix_by = {_matrix_relative_tile_key(run, s): s for s in matrix_samples}
    keys = sorted(set(wbt_by) | set(matrix_by))

    wall_dir = {d: 0 for d in DIRS}
    curve_examples: list[dict] = []
    wall_examples: list[dict] = []
    obstacle_examples: list[dict] = []
    area4_examples: list[dict] = []
    wildcard_examples: list[dict] = []

    curve_mismatches = 0
    obstacle_mismatches = 0
    area4_mismatches = 0
    wildcard_mismatches = 0
    missing_in_wbt = 0
    missing_in_matrix = 0

    matrix_curve_count = sum(int(s.real.curve > 0) for s in matrix_samples)
    wbt_curve_count = sum(int(s.real.curve > 0) for s in wbt_samples)

    for key in keys:
        ms = matrix_by.get(key)
        ws = wbt_by.get(key)
        wbt_r, wbt_c, quarter = key
        if ms is None:
            missing_in_matrix += 1
            continue
        if ws is None:
            missing_in_wbt += 1
            continue

        for direction in DIRS:
            if ms.real.walls[direction] != ws.real.walls[direction]:
                wall_dir[direction] += 1
                if len(wall_examples) < 50:
                    wall_examples.append(
                        {
                            "run_id": run["run_id"],
                            "tile_r": ws.tile_r,
                            "tile_c": ws.tile_c,
                            "quarter": quarter,
                            "direction": direction,
                            "matrix_wall": ms.real.walls[direction],
                            "wbt_wall": ws.real.walls[direction],
                        }
                    )

        if ms.real.curve != ws.real.curve:
            curve_mismatches += 1
            if len(curve_examples) < 50:
                curve_examples.append(
                    {
                        "run_id": run["run_id"],
                        "tile_r": ws.tile_r,
                        "tile_c": ws.tile_c,
                        "quarter": quarter,
                        "matrix_curve": CURVE_LABELS[ms.real.curve],
                        "wbt_curve": CURVE_LABELS[ws.real.curve],
                    }
                )

        if ms.real.obstacle != ws.real.obstacle:
            obstacle_mismatches += 1
            if len(obstacle_examples) < 50:
                obstacle_examples.append(
                    {
                        "run_id": run["run_id"],
                        "tile_r": ws.tile_r,
                        "tile_c": ws.tile_c,
                        "quarter": quarter,
                        "matrix_obstacle": ms.real.obstacle,
                        "wbt_obstacle": ws.real.obstacle,
                    }
                )

        if ms.real.is_area4 != ws.real.is_area4:
            area4_mismatches += 1
            if len(area4_examples) < 50:
                area4_examples.append(
                    {
                        "run_id": run["run_id"],
                        "tile_r": ws.tile_r,
                        "tile_c": ws.tile_c,
                        "quarter": quarter,
                        "matrix_area4": ms.real.is_area4,
                        "wbt_area4": ws.real.is_area4,
                    }
                )

        if any(ms.real.wall_wildcard[d] != ws.real.wall_wildcard[d] for d in DIRS):
            wildcard_mismatches += 1
            if len(wildcard_examples) < 50:
                wildcard_examples.append(
                    {
                        "run_id": run["run_id"],
                        "tile_r": ws.tile_r,
                        "tile_c": ws.tile_c,
                        "quarter": quarter,
                        "matrix_wildcard": dict(ms.real.wall_wildcard),
                        "wbt_wildcard": dict(ws.real.wall_wildcard),
                    }
                )

    return {
        "run_id": run["run_id"],
        "matrix_curve_count": matrix_curve_count,
        "wbt_curve_count": wbt_curve_count,
        "curve_mismatches": curve_mismatches,
        "wall_direction_mismatches": wall_dir,
        "wall_mismatches_total": int(sum(wall_dir.values())),
        "obstacle_mismatches": obstacle_mismatches,
        "area4_mismatches": area4_mismatches,
        "wildcard_mismatches": wildcard_mismatches,
        "missing_in_wbt": missing_in_wbt,
        "missing_in_matrix": missing_in_matrix,
        "curve_examples": curve_examples,
        "wall_examples": wall_examples,
        "obstacle_examples": obstacle_examples,
        "area4_examples": area4_examples,
        "wildcard_examples": wildcard_examples,
    }


def print_wbt_matrix_report(run: dict, max_examples: int = 20) -> None:
    """Print a concise WBT-vs-matrix mismatch report for one run."""
    report = compare_wbt_vs_matrix(run)
    print(f"run_id: {report['run_id']}")
    print(f"matrix_curve_count: {report['matrix_curve_count']}")
    print(f"wbt_curve_count: {report['wbt_curve_count']}")
    print(f"curve_mismatches: {report['curve_mismatches']}")
    print(f"wall_direction_mismatches: {report['wall_direction_mismatches']}")
    print(f"obstacle_mismatches: {report['obstacle_mismatches']}")
    print(f"area4_mismatches: {report['area4_mismatches']}")
    print(f"wildcard_mismatches: {report['wildcard_mismatches']}")
    print(f"missing_in_wbt: {report['missing_in_wbt']}")
    print(f"missing_in_matrix: {report['missing_in_matrix']}")

    for name in (
        "curve_examples",
        "wall_examples",
        "obstacle_examples",
        "area4_examples",
        "wildcard_examples",
    ):
        examples = report[name][:max_examples]
        if not examples:
            continue
        print(f"{name}:")
        for row in examples:
            print(f"  {row}")


def summarize_label_sources(
    runs_dir: Path | str | None = None, label_source: str = "auto"
) -> dict:
    """Return dataset-level counts of WBT usage vs matrix fallback."""
    summary = {
        "requested_label_source": label_source,
        "n_runs": 0,
        "runs_with_wbt_path": 0,
        "runs_using_wbt": 0,
        "runs_using_matrix": 0,
        "runs_falling_back_to_matrix": 0,
        "curves_from_wbt": 0,
    }
    for run_dir in list_runs(runs_dir):
        run = load_run(run_dir)
        summary["n_runs"] += 1
        has_wbt = bool(run.get("wbt_path"))
        summary["runs_with_wbt_path"] += int(has_wbt)
        resolved = _resolve_label_source(run, label_source)
        used_wbt = False
        if resolved == "wbt":
            wbt_subs = _build_run_subtiles_wbt(run, strict=(label_source == "wbt"))
            if wbt_subs:
                used_wbt = True
                summary["curves_from_wbt"] += sum(int(s.real.curve > 0) for s in wbt_subs)
        summary["runs_using_wbt"] += int(used_wbt)
        summary["runs_using_matrix"] += int(not used_wbt)
        if label_source == "auto" and has_wbt and not used_wbt:
            summary["runs_falling_back_to_matrix"] += 1
    return summary


# --------------------------------------------------------------------------- #
# Augmentation (label-correct geometric variants + occupancy noise)
# --------------------------------------------------------------------------- #
# The wall/curve geometry is made of identical physical objects, so different
# SLAM runs vary little. Augmentation expands variety far more cheaply than
# collecting more identical runs:
#   * 90deg rotations / mirror -> new orientations (labels transformed exactly);
#     also matches the rule "maps may be stored in any 90deg rotation".
#   * occupancy noise (jitter / dilate-erode / salt-pepper) -> SLAM robustness.

# One CCW 90deg rotation (np.rot90 k=1) maps edges/curves like this:
_WALL_ROT = {"N": "E", "E": "S", "S": "W", "W": "N"}  # new[d] = old[_WALL_ROT[d]]
_CURVE_ROT = {0: 0, 1: 4, 2: 1, 3: 2, 4: 3}  # old code -> new code
# Left-right mirror (np.fliplr):
_WALL_FLIP = {"N": "N", "S": "S", "E": "W", "W": "E"}
_CURVE_FLIP = {0: 0, 1: 4, 2: 3, 3: 2, 4: 1}


@dataclass
class AugmentConfig:
    rotations: bool = True  # add 90/180/270 rotations
    flips: bool = True  # add left-right mirror (x rotations)
    n_noise: int = 1  # noisy copies per geometric variant
    jitter_cells: int = 2  # max +/- cell translation
    p_morph: float = 0.5  # prob of a dilate/erode on occupied cells
    p_saltpepper: float = 0.01  # per-cell free<->occ flip prob
    seed: int = 42


def _transform_label(src: SubtileLabel, k: int, flip: bool) -> SubtileLabel:
    walls, curve = dict(src.walls), src.curve
    wild = dict(src.wall_wildcard) if src.wall_wildcard else {d: 0 for d in DIRS}
    for _ in range(k % 4):
        walls = {d: walls[_WALL_ROT[d]] for d in DIRS}
        wild = {d: wild[_WALL_ROT[d]] for d in DIRS}
        curve = _CURVE_ROT[curve]
    if flip:
        walls = {d: walls[_WALL_FLIP[d]] for d in DIRS}
        wild = {d: wild[_WALL_FLIP[d]] for d in DIRS}
        curve = _CURVE_FLIP[curve]
    return SubtileLabel(
        walls=walls,
        curve=curve,
        obstacle=src.obstacle,
        value=src.value,
        is_area4=src.is_area4,
        wall_wildcard=wild,
    )


def _transform_sample(s: SubtileSample, k: int, flip: bool) -> SubtileSample:
    patch = s.patch
    for _ in range(k % 4):
        patch = np.rot90(patch, 1)
    if flip:
        patch = np.fliplr(patch)
    aug = s.augmented or (k % 4 != 0) or flip
    return replace(
        s,
        patch=np.ascontiguousarray(patch),
        augmented=aug,
        real=_transform_label(s.real, k, flip),
        submission=_transform_label(s.submission, k, flip),
    )


def _translate(patch: np.ndarray, dy: int, dx: int) -> np.ndarray:
    out = np.full_like(patch, -1)
    h, w = patch.shape
    sy0, sy1 = max(0, dy), min(h, h + dy)
    sx0, sx1 = max(0, dx), min(w, w + dx)
    dy0, dy1 = max(0, -dy), min(h, h - dy)
    dx0, dx1 = max(0, -dx), min(w, w - dx)
    out[sy0:sy1, sx0:sx1] = patch[dy0:dy1, dx0:dx1]
    return out


def _morph(mask: np.ndarray, grow: bool) -> np.ndarray:
    out = mask.copy()
    for dr in (-1, 0, 1):
        for dc in (-1, 0, 1):
            shifted = np.roll(np.roll(mask, dr, 0), dc, 1)
            out = (out | shifted) if grow else (out & shifted)
    return out


def _noise_patch(
    patch: np.ndarray, rng: np.random.Generator, cfg: AugmentConfig
) -> np.ndarray:
    p = patch.copy()
    if cfg.jitter_cells:
        dy = int(rng.integers(-cfg.jitter_cells, cfg.jitter_cells + 1))
        dx = int(rng.integers(-cfg.jitter_cells, cfg.jitter_cells + 1))
        if dy or dx:
            p = _translate(p, dy, dx)
    if rng.random() < cfg.p_morph:
        occ = p >= 65
        grow = rng.random() < 0.5
        new = _morph(occ, grow)
        if grow:
            p[new & ~occ] = 100
        else:
            p[occ & ~new] = 0
    if cfg.p_saltpepper > 0:
        known = p >= 0
        flip = (rng.random(p.shape) < cfg.p_saltpepper) & known
        p[flip] = np.where(p[flip] >= 50, 0, 100)
    return p


def augment_samples(
    samples: Iterable[SubtileSample], cfg: AugmentConfig
) -> list[SubtileSample]:
    """Expand samples with label-correct geometric variants + noise copies.

    Originals keep ``augmented=False`` (used for honest evaluation); every variant
    is flagged ``augmented=True`` and carries the source ``run_id`` so grouped CV
    stays leak-free.
    """
    rng = np.random.default_rng(cfg.seed)
    geoms: list[tuple[int, bool]] = [(0, False)]
    if cfg.rotations:
        geoms += [(1, False), (2, False), (3, False)]
    if cfg.flips:
        geoms += [(0, True)]
        if cfg.rotations:
            geoms += [(1, True), (2, True), (3, True)]

    out: list[SubtileSample] = []
    for s in samples:
        for k, flip in geoms:
            base = _transform_sample(s, k, flip)
            out.append(base)
            for _ in range(cfg.n_noise):
                out.append(
                    replace(
                        base, patch=_noise_patch(base.patch, rng, cfg), augmented=True
                    )
                )
    return out


# --------------------------------------------------------------------------- #
# Dataset builders -> (X, y, groups, baseline, patches, is_real)
# --------------------------------------------------------------------------- #
@dataclass
class Dataset:
    X: np.ndarray
    y: np.ndarray
    groups: np.ndarray  # run_id per row (for grouped CV)
    baseline: np.ndarray  # submission-matrix prediction per row (or -1)
    labels: tuple[str, ...]
    feature_names: tuple[str, ...]
    task: str
    patches: list = field(
        default_factory=list
    )  # north-oriented patch per REAL row (None if augmented)
    is_real: np.ndarray | None = None  # True for non-augmented rows

    def __len__(self) -> int:
        return len(self.y)


def _rot_for_dir(patch: np.ndarray, direction: str) -> np.ndarray:
    """Rotate a north-up patch so ``direction`` edge sits at the north band."""
    return np.rot90(patch, k=DIRS.index(direction))


def _expand(
    samples: Iterable[SubtileSample], augment: AugmentConfig | None
) -> list[SubtileSample]:
    return augment_samples(samples, augment) if augment is not None else list(samples)


def _finish(X, y, g, b, P, R, labels, task, feature_names=FEATURE_NAMES) -> Dataset:
    return Dataset(
        X=np.asarray(X, np.float32),
        y=np.asarray(y, np.int64),
        groups=np.asarray(g),
        baseline=np.asarray(b, np.int64),
        labels=labels,
        feature_names=feature_names,
        task=task,
        patches=P,
        is_real=np.asarray(R, bool),
    )


def build_wall_dataset(
    samples: Iterable[SubtileSample],
    augment: AugmentConfig | None = None,
    margin: float = 0.08,
) -> Dataset:
    """Edge model + rotation: one row per (subtile, direction). Masked wall_features
    look only at the (rotated-to-north) target edge band."""
    X, y, g, b, P, R = [], [], [], [], [], []
    for s in _expand(samples, augment):
        for d in DIRS:
            if s.real.wall_wildcard.get(d):
                continue  # edge shared with area 4 -> don't-care, skip it
            rp = _rot_for_dir(s.patch, d)
            X.append(wall_features(rp, margin))
            y.append(s.real.walls[d])
            g.append(s.run_id)
            b.append(s.submission.walls[d])
            P.append(None if s.augmented else rp)
            R.append(not s.augmented)
    return _finish(X, y, g, b, P, R, ("no_wall", "wall"), "wall", WALL_FEATURE_NAMES)


def build_curve_dataset(
    samples: Iterable[SubtileSample],
    augment: AugmentConfig | None = None,
    margin: float = 0.10,
) -> Dataset:
    X, y, g, b, P, R = [], [], [], [], [], []
    for s in _expand(samples, augment):
        X.append(curve_features(s.patch, margin))
        y.append(s.real.curve)
        g.append(s.run_id)
        b.append(s.submission.curve)
        P.append(None if s.augmented else s.patch)
        R.append(not s.augmented)
    return _finish(X, y, g, b, P, R, CURVE_LABELS, "curve", CURVE_FEATURE_NAMES)


def _augment_tiles(tiles: Iterable[TileSample], cfg: AugmentConfig) -> list[TileSample]:
    """Geometric + noise variants of tile crops. Obstacle label is invariant to
    rotation/flip/noise, so only the patch changes."""
    rng = np.random.default_rng(cfg.seed)
    geoms = [(0, False)]
    if cfg.rotations:
        geoms += [(1, False), (2, False), (3, False)]
    if cfg.flips:
        geoms += [(0, True)] + (
            [(1, True), (2, True), (3, True)] if cfg.rotations else []
        )
    out: list[TileSample] = []
    for t in tiles:
        for k, flip in geoms:
            p = t.patch
            for _ in range(k % 4):
                p = np.rot90(p, 1)
            if flip:
                p = np.fliplr(p)
            aug = (k % 4 != 0) or flip
            base = replace(
                t, patch=np.ascontiguousarray(p), augmented=t.augmented or aug
            )
            out.append(base)
            for _ in range(cfg.n_noise):
                out.append(
                    replace(
                        base, patch=_noise_patch(base.patch, rng, cfg), augmented=True
                    )
                )
    return out


def build_obstacle_dataset(
    tiles: Iterable[TileSample],
    augment: AugmentConfig | None = None,
    margin: float = 0.20,
) -> Dataset:
    """Per-TILE obstacle dataset (full-tile crop). Masked obstacle_features look at
    the tile interior only (edges/walls excluded)."""
    items = _augment_tiles(tiles, augment) if augment is not None else list(tiles)
    X, y, g, b, P, R = [], [], [], [], [], []
    for t in items:
        X.append(obstacle_features(t.patch, margin))
        y.append(t.obstacle)
        g.append(t.run_id)
        b.append(t.submission_obstacle)
        P.append(None if t.augmented else t.patch)
        R.append(not t.augmented)
    return _finish(X, y, g, b, P, R, ("clear", "obstacle"), "obstacle", OBSTACLE_FEATURE_NAMES)


def build_explored_dataset(
    samples: Iterable[SubtileSample],
    augment: AugmentConfig | None = None,
    unknown_thr: float = 0.3,
) -> Dataset:
    """Support model: was the subtile core sufficiently observed?"""
    X, y, g, b, P, R = [], [], [], [], [], []
    for s in _expand(samples, augment):
        X.append(patch_features(s.patch))
        y.append(int(core_unknown_ratio(s.patch) < unknown_thr))
        g.append(s.run_id)
        b.append(-1)
        P.append(None if s.augmented else s.patch)
        R.append(not s.augmented)
    return _finish(X, y, g, b, P, R, ("unexplored", "explored"), "explored")


BUILDERS = {
    "parede": build_wall_dataset,
    "curva": build_curve_dataset,
    "obstaculo": build_obstacle_dataset,
    "explorado": build_explored_dataset,
}

# Empirically-tuned default augmentation per specialist (on the initial 9 runs;
# re-check with compare_augmentation as the dataset grows):
#   * curva: full dihedral rotations + flips give genuinely new orientations and
#     lift CV ~0.93 -> ~0.96 (scarce positives benefit most).
#   * parede: the edge model already rotates each subtile to all 4 edges and has
#     plenty of data, so extra augmentation only adds noise -> default None.
#   * obstaculo: positives are too rare and the blob is destroyed by noise; both
#     geometric and noisy augmentation hurt -> default None.
#   * explorado: trivial gate -> None.
DEFAULT_AUGMENT: dict[str, AugmentConfig | None] = {
    "parede": None,
    "curva": AugmentConfig(rotations=True, flips=True, n_noise=0),
    "obstaculo": None,
    "explorado": None,
}

# Masked-region margins per model (hyperparameters, tuned by sweep_pipeline).
DEFAULT_MARGINS = {"parede": 0.08, "curva": 0.10, "obstaculo": 0.20}

# Edges a curve replaces (so the pipeline suppresses those straight walls):
#   1=SW -> S,W   2=NW -> N,W   3=NE -> N,E   4=SE -> S,E
CURVE_EDGES = {1: ("S", "W"), 2: ("N", "W"), 3: ("N", "E"), 4: ("S", "E")}


def features_for(task: str, patch: np.ndarray, margin: float) -> np.ndarray:
    """Model-specific masked features (explored uses the global features)."""
    if task in ("parede", "wall"):
        return wall_features(patch, margin)
    if task in ("curva", "curve"):
        return curve_features(patch, margin)
    if task in ("obstaculo", "obstacle"):
        return obstacle_features(patch, margin)
    return patch_features(patch)


def resolve_overlaps(subtiles, subtile_preds, tiles, tile_obstacle):
    """Apply the anti-overlap policy in place: obstacle (tile) suppresses walls +
    curve in the tile's subtiles; a curve suppresses the straight walls on its own
    edges. Returns the (mutated) subtile_preds."""
    obst_coords = {
        (t.tile_r, t.tile_c) for t, o in zip(tiles, tile_obstacle) if int(o)
    }
    for s, p in zip(subtiles, subtile_preds):
        if (s.tile_r, s.tile_c) in obst_coords:
            p["walls"] = {d: 0 for d in DIRS}
            p["curve"] = 0
        elif p.get("curve"):
            for d in CURVE_EDGES.get(p["curve"], ()):
                p["walls"][d] = 0
    return subtile_preds


# --------------------------------------------------------------------------- #
# RandomForest training + evaluation
# --------------------------------------------------------------------------- #
@dataclass
class MapRFConfig:
    n_estimators: int = 200
    max_depth: int | None = 12
    min_samples_leaf: int = 2
    max_features: str = "sqrt"
    class_weight: str | None = "balanced"
    n_jobs: int = -1
    random_state: int = 42


def _build_rf(cfg: MapRFConfig):
    from sklearn.ensemble import RandomForestClassifier

    return RandomForestClassifier(
        n_estimators=cfg.n_estimators,
        max_depth=cfg.max_depth,
        min_samples_leaf=cfg.min_samples_leaf,
        max_features=cfg.max_features,
        class_weight=cfg.class_weight,
        n_jobs=cfg.n_jobs,
        random_state=cfg.random_state,
    )


def cross_val_predict_grouped(
    dataset: Dataset, cfg: MapRFConfig | None = None
) -> np.ndarray:
    """Leave-one-run-out out-of-fold predictions.

    Trains on every other run (augmented rows included) and predicts only the
    held-out run's REAL rows, so the estimate reflects real-patch performance.
    Returns an array aligned to dataset rows; non-evaluated rows are -1.
    """
    from sklearn.model_selection import LeaveOneGroupOut

    cfg = cfg or MapRFConfig()
    X, y, groups = dataset.X, dataset.y, dataset.groups
    is_real = dataset.is_real if dataset.is_real is not None else np.ones(len(y), bool)
    pred = np.full_like(y, -1)
    if len(set(groups.tolist())) > 1 and len(set(y.tolist())) > 1:
        logo = LeaveOneGroupOut()
        for tr_idx, te_idx in logo.split(X, y, groups):
            te_real = te_idx[is_real[te_idx]]
            if len(set(y[tr_idx].tolist())) < 2 or len(te_real) == 0:
                continue
            model = _build_rf(cfg)
            model.fit(X[tr_idx], y[tr_idx])
            pred[te_real] = model.predict(X[te_real])
    return pred


def train_rf(dataset: Dataset, cfg: MapRFConfig | None = None) -> dict:
    """Leave-one-run-out CV for honest metrics + a final model fit on all data.

    Returns a dict with the fitted model, CV metrics (accuracy, confusion,
    per-class report), feature importances, the submission baseline accuracy, and
    the out-of-fold predictions (``cv_pred``) for error analysis.
    """
    from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

    cfg = cfg or MapRFConfig()
    X, y, groups = dataset.X, dataset.y, dataset.groups
    is_real = dataset.is_real if dataset.is_real is not None else np.ones(len(y), bool)
    n_groups = len(set(groups.tolist()))

    cv_pred = cross_val_predict_grouped(dataset, cfg)
    valid = cv_pred >= 0

    label_idx = list(range(len(dataset.labels)))
    real_y = y[is_real]
    present = sorted(set(int(v) for v in real_y))
    metrics: dict = {
        "task": dataset.task,
        "labels": list(dataset.labels),
        "n_samples": int(len(y)),
        "n_real": int(is_real.sum()),
        "n_runs": int(n_groups),
        "class_counts": {dataset.labels[c]: int((real_y == c).sum()) for c in present},
    }
    if valid.any():
        metrics["cv_accuracy"] = float(accuracy_score(y[valid], cv_pred[valid]))
        metrics["cv_confusion"] = confusion_matrix(
            y[valid], cv_pred[valid], labels=label_idx
        ).tolist()
        metrics["cv_report"] = classification_report(
            y[valid],
            cv_pred[valid],
            labels=label_idx,
            target_names=dataset.labels,
            output_dict=True,
            zero_division=0,
        )
    else:
        metrics["cv_accuracy"] = None
        metrics["cv_confusion"] = None
        metrics["cv_report"] = None

    # Baseline: submission-matrix labels vs ground truth (real rows only).
    bmask = is_real & (dataset.baseline >= 0)
    if bmask.any():
        metrics["baseline_accuracy"] = float(
            accuracy_score(y[bmask], dataset.baseline[bmask])
        )
    else:
        metrics["baseline_accuracy"] = None

    # Final model on ALL data (augmented included) for saving / deployment.
    final = _build_rf(cfg)
    final.fit(X, y)
    metrics["feature_importances"] = {
        name: float(imp)
        for name, imp in zip(dataset.feature_names, final.feature_importances_)
    }

    return {
        "model": final,
        "metrics": metrics,
        "config": cfg,
        "dataset": dataset,
        "cv_pred": cv_pred,
    }


def save_model(result: dict, model_name: str) -> dict[str, Path]:
    """Persist the RF (joblib) + metrics.json under ``models/<model_name>/``."""
    import joblib
    from .config import get_model_dir

    out_dir = get_model_dir(model_name)
    out_dir.mkdir(parents=True, exist_ok=True)
    ds: Dataset = result["dataset"]

    model_path = out_dir / "model.joblib"
    joblib.dump(
        {
            "model": result["model"],
            "config": asdict(result["config"]),
            "feature_names": list(ds.feature_names),
            "labels": list(ds.labels),
            "task": ds.task,
        },
        model_path,
    )

    metrics_path = out_dir / "metrics.json"
    with open(metrics_path, "w") as fh:
        json.dump(result["metrics"], fh, indent=2)

    return {"model": model_path, "metrics": metrics_path}


# --------------------------------------------------------------------------- #
# Error analysis & visualization
# --------------------------------------------------------------------------- #
def _patch_rgb(patch: np.ndarray) -> np.ndarray:
    """Colorize a patch: free=white, occupied=black, unknown=gray."""
    h, w = patch.shape
    rgb = np.full((h, w, 3), 160, np.uint8)  # mid (uncertain)
    rgb[patch < 0] = 110  # unknown gray
    rgb[(patch >= 0) & (patch <= 25)] = 255  # free white
    rgb[patch >= 65] = 0  # occupied black
    return rgb


def error_summary(dataset: Dataset, cv_pred: np.ndarray) -> dict:
    """Where is the model wrong? Per-class confusions + unknown-coverage effect."""
    mask = cv_pred >= 0
    idx = np.where(mask)[0]
    y, p = dataset.y[idx], cv_pred[idx]
    err = y != p
    summary: dict = {
        "task": dataset.task,
        "evaluated": int(mask.sum()),
        "errors": int(err.sum()),
        "error_rate": float(err.mean()) if len(err) else None,
    }
    # Per (true -> predicted) confusion among errors.
    pairs: dict[str, int] = {}
    for t, q in zip(y[err], p[err]):
        key = f"{dataset.labels[t]}->{dataset.labels[q]}"
        pairs[key] = pairs.get(key, 0) + 1
    summary["top_confusions"] = dict(sorted(pairs.items(), key=lambda kv: -kv[1])[:8])
    # Error rate split by patch unknown coverage (proxy for "poorly observed").
    unk = np.array([float((dataset.patches[i] < 0).mean()) for i in idx])
    hi = unk >= 0.15
    summary["error_rate_low_unknown"] = float(err[~hi].mean()) if (~hi).any() else None
    summary["error_rate_high_unknown"] = float(err[hi].mean()) if hi.any() else None
    return summary


def plot_error_gallery(
    dataset: Dataset,
    cv_pred: np.ndarray,
    *,
    max_examples: int = 24,
    cols: int = 6,
    seed: int = 0,
    title: str | None = None,
):
    """Grid of misclassified REAL subtiles: occupancy patch + true vs predicted.

    For the wall task each patch is oriented so the edge in question is at the
    top (yellow line); the title shows ``t=<truth> p=<prediction>``.
    """
    import matplotlib.pyplot as plt

    idx = np.where((cv_pred >= 0) & (cv_pred != dataset.y))[0]
    idx = np.array([i for i in idx if dataset.patches[i] is not None])
    if len(idx) == 0:
        print("Sem erros para mostrar.")
        return None
    rng = np.random.default_rng(seed)
    if len(idx) > max_examples:
        idx = np.sort(rng.choice(idx, max_examples, replace=False))

    rows = int(np.ceil(len(idx) / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 2.0, rows * 2.3))
    axes = np.atleast_1d(axes).ravel()
    for ax in axes:
        ax.axis("off")
    import matplotlib.patches as _mpatches
    for ax, i in zip(axes, idx):
        patch = dataset.patches[i]
        s = patch.shape[0]
        ax.imshow(_patch_rgb(patch), origin="upper")  # row 0 = north at top
        ax.set_title(
            f"t={dataset.labels[dataset.y[i]]}\np={dataset.labels[cv_pred[i]]}",
            fontsize=7,
        )
        # Subtile box [0.25, 0.75]: the patch is a FULL TILE (0.12 m) wide, but the
        # subtile is only its central half — so a correctly-aligned wall sits on this
        # box's edge (looks "central"), NOT on the patch border.
        ax.add_patch(_mpatches.Rectangle(
            (0.25 * s, 0.25 * s), 0.5 * s, 0.5 * s,
            fill=False, edgecolor="deepskyblue", lw=1.0, ls="--"))
        if dataset.task == "wall":
            ax.axhline(s * 0.25, color="gold", lw=1.2)  # the subtile north edge
    fig.suptitle(
        title
        or f"Erros (CV) — {dataset.task}: {len(idx)} de "
        f"{int((cv_pred >= 0).sum())} subtiles reais"
    )
    fig.tight_layout()
    return fig


def compare_augmentation(
    samples,
    specialist: str,
    rf: "MapRFConfig | None" = None,
    augment: "AugmentConfig | None" = None,
) -> dict:
    """Train the specialist with and without augmentation; return CV accuracies."""
    builder = BUILDERS[specialist]
    aug = augment if augment is not None else DEFAULT_AUGMENT[specialist]
    base = train_rf(builder(samples), rf)["metrics"]
    augd = train_rf(builder(samples, augment=aug), rf)["metrics"]
    return {
        "specialist": specialist,
        "baseline_submission": base.get("baseline_accuracy"),
        "cv_no_aug": base.get("cv_accuracy"),
        "cv_with_aug": augd.get("cv_accuracy"),
    }


# --------------------------------------------------------------------------- #
# Diagnostics
# --------------------------------------------------------------------------- #
def plot_alignment(
    run: dict, half_extent_m: float = SUBTILE_M, label_source: str = "matrix"
):
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D

    grid = run["grid"]
    meta = run["meta"]
    res = float(meta["map"]["resolution"]) or DEFAULT_RES  # 0.12 m/pixel
    ox = float(meta["map"]["origin"]["x"])
    oy = float(meta["map"]["origin"]["y"])
    h, w = grid.shape

    bg = np.full((h, w), 0.5)
    bg[(grid >= 0) & (grid <= 25)] = 1.0
    bg[grid >= 65] = 0.0

    fig, ax = plt.subplots(figsize=(9, 9))
    ax.imshow(bg, cmap="gray", origin="lower", vmin=0, vmax=1)

    step_012 = TILE_SIZE_M / res  # = 0.12 / 0.12 = 1.0 pixel
    step_006 = SUBTILE_M / res  # = 0.06 / 0.12 = 0.5 pixel

    # Grid 0.12 m — linhas a cada tile inteiro
    for x in np.arange(-0.5, w, step_012):
        ax.axvline(x, color="blue", lw=0.5, alpha=0.5)
    for y in np.arange(-0.5, h, step_012):
        ax.axhline(y, color="blue", lw=0.5, alpha=0.5)

    # Grid 0.06 m — linhas a cada meio tile (subtile)
    for x in np.arange(-0.5, w, step_006):
        ax.axvline(x, color="cyan", lw=0.3, alpha=0.35)
    for y in np.arange(-0.5, h, step_006):
        ax.axhline(y, color="cyan", lw=0.3, alpha=0.35)

    effective_source = label_source
    wbt = None
    if label_source != "matrix":
        wbt = _load_run_wbt_grid(run, strict=False)
        if wbt is None:
            effective_source = "matrix"

    # Subtiles da matriz/WBT com paredes/obstáculos
    xs, ys = [], []
    anchor = find_anchor_tile(matrix_rows(run["real"])) or (0, 0)
    for s in build_run_subtiles(run, half_extent_m, label_source=effective_source):
        if any(s.real.walls.values()) or s.real.obstacle:
            if effective_source == "matrix":
                wx, wy = subtile_world_center(s.tile_r, s.tile_c, s.quarter, anchor)
            else:
                if wbt is None:
                    continue
                wbt_r, wbt_c = wbt.from_matrix_rc(s.tile_r, s.tile_c)
                dx, dy = _quarter_world_offset(s.quarter)
                wx = wbt_c * TILE_SIZE_M + dx
                wy = -wbt_r * TILE_SIZE_M + dy
            xs.append((wx - ox) / res)
            ys.append((wy - oy) / res)

    ax.scatter(
        xs,
        ys,
        s=10,
        c="red",
        alpha=0.8,
        zorder=5,
        label="matrix wall/obstacle subtiles",
    )

    handles = [
        ax.get_legend_handles_labels()[0][0],  # scatter
        Line2D(
            [0], [0], color="blue", lw=1.5, label=f"grid 0.12 m (step={step_012:.2f}px)"
        ),
        Line2D(
            [0], [0], color="cyan", lw=1.5, label=f"grid 0.06 m (step={step_006:.2f}px)"
        ),
    ]
    ax.legend(handles=handles, loc="upper right", fontsize=8)
    ax.set_title(
        f"Alignment overlay — {run['run_id']}\n"
        f"res={res} m/px · Azul=tile(0.12 m) · Ciano=subtile(0.06 m) · Vermelho=paredes/obst"
    )
    ax.set_xlabel("grid col (east →)")
    ax.set_ylabel("grid row (north →)")
    return fig


# --------------------------------------------------------------------------- #
# Runtime pipeline: explored gate first, then geometry specialists
# --------------------------------------------------------------------------- #
SPECIALIST_NAMES = ("explorado", "parede", "curva", "obstaculo")


def geometry_of(label: SubtileLabel) -> dict:
    """Subtile geometry view (walls + curve). Obstacle is a tile-level property."""
    return {"walls": dict(label.walls), "curve": label.curve}


def filter_explored(samples: Iterable, thr: float = 0.3) -> list:
    """Keep only sufficiently-observed samples (core unknown ratio < thr).

    Works for subtiles and tiles (both carry ``.patch``). This is how we "ignore
    empties": geometry models train on observed cells only, so poorly-cropped /
    unexplored cells stop polluting them.
    """
    return [s for s in samples if core_unknown_ratio(s.patch) < thr]


def obstacle_tile_keys(tiles: Iterable["TileSample"]) -> set:
    """`(run_id, tile_r, tile_c)` of every tile that holds an obstacle (real label).

    Used to drop subtiles the runtime pipeline overrides: ``resolve_overlaps`` forces
    walls=0 and curve=0 on every subtile of an obstacle tile, so the wall/curve
    specialists never actually decide there.
    """
    return {(t.run_id, t.tile_r, t.tile_c) for t in tiles if t.obstacle}


def filter_pipeline_consistent(
    subtiles: Iterable["SubtileSample"],
    tiles: Iterable["TileSample"],
    explored_thr: float = 0.3,
    drop_obstacle_tiles: bool = True,
) -> list:
    """Restrict subtiles to the domain the deployed pipeline actually presents to the
    wall/curve specialists, so the individual notebooks train/evaluate on the same
    cases (the models "converse"):

    * **explored gate** — keep only observed subtiles (core unknown < ``explored_thr``),
      exactly what ``MapPipeline`` trains wall/curve on;
    * **obstacle suppression** — drop subtiles whose TILE holds an obstacle, because
      ``resolve_overlaps`` zeroes walls/curve there at runtime (this is why curve was
      "firing on obstacle tiles" in the isolated notebook).

    Without this, a specialist learns and is scored on situations it never decides in
    the real pipeline.
    """
    obst = obstacle_tile_keys(tiles) if drop_obstacle_tiles else set()
    return [
        s for s in subtiles
        if core_unknown_ratio(s.patch) < explored_thr
        and (s.run_id, s.tile_r, s.tile_c) not in obst
    ]


def run_feature_counts(samples: Iterable[SubtileSample]) -> dict[str, dict]:
    """Per-run richness of geometry features (for picking diverse demo maps)."""
    from collections import defaultdict

    out: dict[str, dict] = defaultdict(
        lambda: {"curves": 0, "obstacles": 0, "walls": 0, "subtiles": 0}
    )
    for s in samples:
        c = out[s.run_id]
        c["subtiles"] += 1
        c["curves"] += int(s.real.curve > 0)
        c["obstacles"] += int(s.real.obstacle)
        c["walls"] += sum(1 for v in s.real.walls.values() if v)
    return dict(out)


def pick_diverse_runs(samples: Iterable[SubtileSample], k: int = 3) -> list[str]:
    """Pick up to k runs that best showcase curves, obstacles and walls."""
    counts = run_feature_counts(samples)
    picks: list[str] = []
    for key in ("obstacles", "curves", "walls"):
        for run in sorted(counts, key=lambda r: -counts[r][key]):
            if counts[run][key] > 0 and run not in picks:
                picks.append(run)
                break
        if len(picks) >= k:
            return picks[:k]
    for run in sorted(counts, key=lambda r: -counts[r]["subtiles"]):
        if run not in picks:
            picks.append(run)
        if len(picks) >= k:
            break
    return picks[:k]


class MapPipeline:
    """Runs the gated map pipeline: explored gate -> wall/curve/obstacle.

    Holds one sklearn estimator per specialist. Build it from freshly trained
    models (``from_training``) or from the exported joblib artifacts
    (``from_dir``) to validate the runtime before the C++ port.
    """

    def __init__(self, models: dict, margins: dict | None = None,
                 explored_thr: float = 0.3):
        self.models = models
        self.margins = dict(DEFAULT_MARGINS) if margins is None else dict(margins)
        self.explored_thr = explored_thr

    @classmethod
    def from_training(
        cls,
        subtiles,
        tiles,
        rf: MapRFConfig | None = None,
        augment: dict | None = None,
        explored_thr: float = 0.3,
        margins: dict | None = None,
    ) -> "MapPipeline":
        """Train the pipeline. ``explorado`` learns on all subtiles; wall/curve on
        observed subtiles; ``obstaculo`` on observed full-TILE crops. Masked
        features per model use ``margins`` (defaults from DEFAULT_MARGINS)."""
        augment = augment if augment is not None else DEFAULT_AUGMENT
        mg = dict(DEFAULT_MARGINS) if margins is None else dict(margins)
        subtiles = list(subtiles)
        tiles = list(tiles)
        obs_tiles = filter_explored(tiles, explored_thr)
        # wall/curve only ever decide on explored, non-obstacle-tile subtiles (the
        # runtime resolve_overlaps zeroes them on obstacle tiles), so train them on
        # exactly that domain — keeps the specialists from learning/being scored on
        # cases they never decide (e.g. curve firing on an obstacle blob).
        geo_sub = filter_pipeline_consistent(subtiles, tiles, explored_thr)
        models = {
            "explorado": train_rf(
                build_explored_dataset(
                    subtiles, augment=augment.get("explorado"), unknown_thr=explored_thr
                ), rf
            )["model"],
            "parede": train_rf(
                build_wall_dataset(geo_sub, augment=augment.get("parede"), margin=mg["parede"]), rf
            )["model"],
            "curva": train_rf(
                build_curve_dataset(geo_sub, augment=augment.get("curva"), margin=mg["curva"]), rf
            )["model"],
            "obstaculo": train_rf(
                build_obstacle_dataset(
                    obs_tiles, augment=augment.get("obstaculo"), margin=mg["obstaculo"]
                ), rf
            )["model"],
        }
        return cls(models, margins=mg, explored_thr=explored_thr)

    @classmethod
    def from_dir(cls, root: Path | str | None = None) -> "MapPipeline":
        import joblib
        from .config import get_model_dir

        models, margins, thr = {}, dict(DEFAULT_MARGINS), 0.3
        for name in SPECIALIST_NAMES:
            path = (
                (Path(root) / name / "model.joblib")
                if root
                else get_model_dir(f"map/{name}") / "model.joblib"
            )
            payload = joblib.load(path)
            models[name] = payload["model"]
            if name in margins and "margin" in payload:
                margins[name] = payload["margin"]
            thr = payload.get("explored_thr", thr)
        return cls(models, margins=margins, explored_thr=thr)

    _LABELS_BY_TASK = {
        "explorado": ("unexplored", "explored"),
        "parede": ("no_wall", "wall"),
        "curva": CURVE_LABELS,
        "obstaculo": ("clear", "obstacle"),
    }
    _FEATURE_NAMES_BY_TASK = {
        "explorado": FEATURE_NAMES,
        "parede": WALL_FEATURE_NAMES,
        "curva": CURVE_FEATURE_NAMES,
        "obstaculo": OBSTACLE_FEATURE_NAMES,
    }

    def save(self, root: Path | str | None = None) -> dict:
        """Export each specialist to ``<root or models/map>/<name>/model.joblib``.

        Self-describing payloads (model + feature_names + labels + task + margin +
        explored_thr) so the same artifacts drive this runtime and the C++ port."""
        import joblib
        from .config import get_model_dir

        paths = {}
        for name, model in self.models.items():
            d = (Path(root) / name) if root else get_model_dir(f"map/{name}")
            d.mkdir(parents=True, exist_ok=True)
            path = d / "model.joblib"
            joblib.dump(
                {
                    "model": model,
                    "feature_names": list(self._FEATURE_NAMES_BY_TASK[name]),
                    "labels": list(self._LABELS_BY_TASK[name]),
                    "task": name,
                    "margin": self.margins.get(name),
                    "explored_thr": self.explored_thr,
                },
                path,
            )
            paths[name] = path
        return paths

    def predict_subtiles(self, subtiles, explored_gate: bool = True) -> list[dict]:
        """Batched gated inference -> per-subtile {explored, walls, curve}. Each
        model uses its own masked features."""
        subtiles = list(subtiles)
        if not subtiles:
            return []
        cm, wm = self.margins["curva"], self.margins["parede"]
        explored = self.models["explorado"].predict(
            np.array([patch_features(s.patch) for s in subtiles]))
        curve = self.models["curva"].predict(
            np.array([curve_features(s.patch, cm) for s in subtiles]))
        wall_feats = np.array(
            [wall_features(_rot_for_dir(s.patch, d), wm) for s in subtiles for d in DIRS]
        )
        wpred = self.models["parede"].predict(wall_feats).reshape(len(subtiles), 4)

        out = []
        for i in range(len(subtiles)):
            gated = (not explored_gate) or bool(explored[i])
            walls = {DIRS[j]: (int(wpred[i, j]) if gated else 0) for j in range(4)}
            out.append(
                {
                    "explored": int(explored[i]),
                    "walls": walls,
                    "curve": int(curve[i]) if gated else 0,
                }
            )
        return out

    def predict_tiles(self, tiles) -> np.ndarray:
        """Batched obstacle inference on full-TILE crops -> int array (0/1)."""
        tiles = list(tiles)
        if not tiles:
            return np.zeros(0, dtype=int)
        om = self.margins["obstaculo"]
        feats = np.array([obstacle_features(t.patch, om) for t in tiles])
        return self.models["obstaculo"].predict(feats).astype(int)


_COUNT_KEYS = (
    "wall_ok",
    "wall_n",
    "curve_ok",
    "curve_n",
    "obst_ok",
    "obst_n",
    "exact_ok",
    "exact_n",
    "expl_n",
    "scored",
    "total",
)


def _score_subtile(c: dict, p: dict, r: SubtileLabel) -> None:
    c["scored"] += 1
    wall_ok = True
    for d in DIRS:
        if r.wall_wildcard.get(d):
            continue  # area-4 edge -> don't-care, not scored
        ok = int(p["walls"][d] == r.walls[d])
        c["wall_ok"] += ok
        c["wall_n"] += 1
        wall_ok = wall_ok and bool(ok)
    c["curve_ok"] += int(p["curve"] == r.curve)
    c["curve_n"] += 1
    c["exact_ok"] += int(wall_ok and p["curve"] == r.curve)
    c["exact_n"] += 1


def evaluate_pipeline(
    run: dict,
    pipeline: MapPipeline,
    explored_thr: float = 0.3,
    label_source: str = "auto",
) -> dict:
    """Score the pipeline vs the real matrix for BOTH gate modes (geometry only).

    Subtile walls/curve are scored per subtile; obstacle per TILE. ``on`` skips
    cells the gate marks unobserved (deployment behaviour), ``off`` scores all.
    Returns ``{"on": counts, "off": counts}`` so runs can be pooled.
    """
    subs = build_run_subtiles(run, label_source=label_source)
    tiles = build_run_tiles(run, label_source=label_source)
    sp = pipeline.predict_subtiles(subs, explored_gate=False)
    to = pipeline.predict_tiles(tiles)
    counts = {"on": {k: 0 for k in _COUNT_KEYS}, "off": {k: 0 for k in _COUNT_KEYS}}
    for s, p in zip(subs, sp):
        for gate in ("on", "off"):
            counts[gate]["total"] += 1
            counts[gate]["expl_n"] += p["explored"]
        if p["explored"]:
            _score_subtile(counts["on"], p, s.real)
        _score_subtile(counts["off"], p, s.real)
    for t, o in zip(tiles, to):
        observed = core_unknown_ratio(t.patch) < explored_thr
        for gate, cond in (("on", observed), ("off", True)):
            if cond:
                counts[gate]["obst_ok"] += int(int(o) == t.obstacle)
                counts[gate]["obst_n"] += 1
    return counts


def _accuracies(c: dict) -> dict:
    def r(a, b):
        return float(a) / b if b else None

    return {
        "wall_acc": r(c["wall_ok"], c["wall_n"]),
        "curve_acc": r(c["curve_ok"], c["curve_n"]),
        "obstacle_acc": r(c["obst_ok"], c["obst_n"]),
        "subtile_exact": r(c["exact_ok"], c["exact_n"]),
        "explored_coverage": r(c["expl_n"], c["total"]),
        "scored": c["scored"],
        "total": c["total"],
    }


def evaluate_pipeline_cv(
    runs=None,
    rf: MapRFConfig | None = None,
    augment: dict | None = None,
    explored_thr: float = 0.3,
    label_source: str = "auto",
) -> dict:
    """Leave-one-run-out pipeline test against the real matrices (geometry only).

    For each held-out run, trains the whole pipeline (subtile geometry + tile
    obstacle) on the other runs and scores it for both gate modes. ``runs`` is a
    list of run dirs (defaults to all). Returns per-run + pooled accuracies as
    ``{"per_run": {run: {"on":acc,"off":acc}}, "aggregate": {"on":acc,"off":acc}}``.
    """
    run_dirs = list(runs) if runs is not None else list_runs()
    loaded = {rd.name: load_run(rd) for rd in run_dirs}
    subs = {
        n: build_run_subtiles(r, label_source=label_source)
        for n, r in loaded.items()
    }
    tiles = {
        n: build_run_tiles(r, label_source=label_source)
        for n, r in loaded.items()
    }
    names = sorted(loaded)

    per_run = {}
    pooled = {g: {k: 0 for k in _COUNT_KEYS} for g in ("on", "off")}
    for held in names:
        tr_sub = [s for n in names if n != held for s in subs[n]]
        tr_tile = [t for n in names if n != held for t in tiles[n]]
        pipe = MapPipeline.from_training(tr_sub, tr_tile, rf, augment, explored_thr)
        counts = evaluate_pipeline(
            loaded[held], pipe, explored_thr, label_source=label_source
        )
        per_run[held] = {g: _accuracies(counts[g]) for g in ("on", "off")}
        for g in ("on", "off"):
            for k in _COUNT_KEYS:
                pooled[g][k] += counts[g][k]
    return {
        "per_run": per_run,
        "aggregate": {g: _accuracies(pooled[g]) for g in ("on", "off")},
    }


# --------------------------------------------------------------------------- #
# End-to-end evaluation (resolved geometry, per-class, macro-recall, overlap)
# --------------------------------------------------------------------------- #
def collect_run(
    run: dict,
    pipeline: MapPipeline,
    gate: bool = True,
    resolve: bool = True,
    label_source: str = "auto",
):
    """Predict + (optionally) resolve overlaps for one run; returns
    (subs, subtile_preds, tiles, tile_obstacle, predict_seconds)."""
    import time

    subs = build_run_subtiles(run, label_source=label_source)
    tiles = build_run_tiles(run, label_source=label_source)
    t0 = time.perf_counter()
    sp = pipeline.predict_subtiles(subs, explored_gate=gate)
    to = pipeline.predict_tiles(tiles)
    dt = time.perf_counter() - t0
    if resolve:
        resolve_overlaps(subs, sp, tiles, to)
    return subs, sp, tiles, to, dt


def _class_metrics(y_true, y_pred, labels, names) -> dict:
    from sklearn.metrics import (
        precision_recall_fscore_support,
        confusion_matrix,
        accuracy_score,
    )

    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    if len(y_true) == 0:
        return {}
    p, r, f, sup = precision_recall_fscore_support(
        y_true, y_pred, labels=labels, zero_division=0
    )
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_recall": float(np.mean(r)),
        "macro_f1": float(np.mean(f)),
        "per_class": {
            names[i]: {"precision": float(p[i]), "recall": float(r[i]),
                       "f1": float(f[i]), "support": int(sup[i])}
            for i in range(len(labels))
        },
        "confusion": confusion_matrix(y_true, y_pred, labels=labels).tolist(),
        "labels": list(names),
    }


def evaluate_pipeline_end2end(
    runs=None,
    rf: MapRFConfig | None = None,
    augment: dict | None = None,
    explored_thr: float = 0.3,
    margins: dict | None = None,
    gate: bool = True,
    resolve: bool = True,
    label_source: str = "auto",
) -> dict:
    """Leave-one-run-out evaluation of the FINAL resolved geometry vs real.

    Reports per-class precision/recall/F1 + macro-recall (immune to class
    dominance), the cross-model overlap rate (should be ~0 after resolution),
    explored coverage and inference time. This is the metric that matters at
    runtime (not per-model accuracy)."""
    run_dirs = list(runs) if runs is not None else list_runs()
    loaded = {rd.name: load_run(rd) for rd in run_dirs}
    subs_by = {
        n: build_run_subtiles(r, label_source=label_source)
        for n, r in loaded.items()
    }
    tiles_by = {
        n: build_run_tiles(r, label_source=label_source)
        for n, r in loaded.items()
    }
    names = sorted(loaded)

    wt, wp = [], []      # wall true/pred (per non-wildcard edge)
    ct, cp = [], []      # curve true/pred
    ot, op = [], []      # obstacle true/pred (per tile)
    overlap = 0          # resolved subtiles still mixing curve + its-edge wall
    total_sub = total_unexpl = 0
    total_time = 0.0

    for held in names:
        tr_sub = [s for n in names if n != held for s in subs_by[n]]
        tr_tile = [t for n in names if n != held for t in tiles_by[n]]
        pipe = MapPipeline.from_training(
            tr_sub, tr_tile, rf, augment, explored_thr, margins
        )
        subs, sp, tiles, to, dt = collect_run(
            loaded[held], pipe, gate, resolve, label_source=label_source
        )
        total_time += dt
        total_sub += len(subs)
        for s, p in zip(subs, sp):
            total_unexpl += int(not p["explored"])
            for d in DIRS:
                if s.real.wall_wildcard.get(d):
                    continue
                wt.append(s.real.walls[d])
                wp.append(p["walls"][d])
            ct.append(s.real.curve)
            cp.append(p["curve"])
            if p["curve"] and any(p["walls"][d] for d in CURVE_EDGES.get(p["curve"], ())):
                overlap += 1
        for t, o in zip(tiles, to):
            ot.append(t.obstacle)
            op.append(int(o))

    curve_present = sorted(set(ct) | set(cp))
    out = {
        "wall": _class_metrics(wt, wp, [0, 1], ["no_wall", "wall"]),
        "curve": _class_metrics(ct, cp, curve_present,
                                [CURVE_LABELS[i] for i in curve_present]),
        "obstacle": _class_metrics(ot, op, [0, 1], ["clear", "obstacle"]),
        "overlap_violations": int(overlap),
        "explored_coverage": float(1 - total_unexpl / total_sub) if total_sub else None,
        "us_per_subtile": float(total_time / total_sub * 1e6) if total_sub else None,
        "n_runs": len(names),
    }
    out["headline_macro_recall"] = float(np.mean([
        out["wall"].get("macro_recall", 0.0),
        out["curve"].get("macro_recall", 0.0),
        out["obstacle"].get("macro_recall", 0.0),
    ]))
    return out


# Stronger augmentation preset: multiply the scarce curve/obstacle positives.
AUG_STRONG: dict[str, AugmentConfig | None] = {
    "parede": None,
    "curva": AugmentConfig(rotations=True, flips=True, n_noise=1),
    "obstaculo": AugmentConfig(rotations=True, flips=True, n_noise=2),
    "explorado": None,
}


def sweep_pipeline(grid: list[dict], runs=None, base_rf: MapRFConfig | None = None,
                   augment: dict | None = None) -> list[dict]:
    """Run the end-to-end LORO evaluation for each config in ``grid`` and rank by
    headline macro-recall (overlap≈0 as a sanity check).

    Each config dict may override: ``margins`` (per-model), ``explored_thr``,
    ``rf`` (MapRFConfig kwargs), ``augment`` (per-model dict). Returns the ranked
    summaries (best first)."""
    base_rf = base_rf or MapRFConfig()
    rows = []
    for cfg in grid:
        m = {**DEFAULT_MARGINS, **cfg.get("margins", {})}
        thr = cfg.get("explored_thr", 0.3)
        rfc = replace(base_rf, **cfg["rf"]) if cfg.get("rf") else base_rf
        aug = cfg.get("augment", augment)
        r = evaluate_pipeline_end2end(
            runs=runs, rf=rfc, augment=aug, explored_thr=thr, margins=m
        )
        rows.append({
            "config": cfg,
            "headline": r["headline_macro_recall"],
            "wall": r["wall"].get("macro_recall"),
            "curve": r["curve"].get("macro_recall"),
            "obstacle": r["obstacle"].get("macro_recall"),
            "overlap": r["overlap_violations"],
            "coverage": r["explored_coverage"],
        })
    rows.sort(key=lambda x: -x["headline"])
    return rows


# --------------------------------------------------------------------------- #
# Visualization: masks, class metrics, crop galleries
# --------------------------------------------------------------------------- #
def plot_mask_examples(items, kind: str, *, label_fn, want, margin: float = 0.10,
                       n: int = 8, cols: int = 4, seed: int = 0, title: str | None = None):
    """Gallery of crops (patch + the model's MASK outlined) for samples matching a
    target label. ``label_fn(item)`` -> label; keep where label==want. ``items`` are
    SubtileSample (wall/curve) or TileSample (obstacle)."""
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches

    picked = [it for it in items if label_fn(it) == want]
    rng = np.random.default_rng(seed)
    if len(picked) > n:
        picked = list(rng.choice(picked, n, replace=False))
    if not picked:
        print(f"sem exemplos de {kind}={want}")
        return None
    rows = int(np.ceil(len(picked) / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 2.2, rows * 2.4))
    axes = np.atleast_1d(axes).ravel()
    for ax in axes:
        ax.axis("off")
    for ax, it in zip(axes, picked):
        patch = it.patch
        ax.imshow(_patch_rgb(patch), origin="upper")
        m = mask_for(kind, patch.shape[0], margin)
        ys, xs = np.where(m)
        if len(xs):
            ax.add_patch(mpatches.Rectangle((xs.min(), ys.min()),
                         xs.max() - xs.min(), ys.max() - ys.min(),
                         fill=False, edgecolor="gold", lw=1.4))
        ax.set_title(f"{kind}={want}", fontsize=7)
    fig.suptitle(title or f"Crops + máscara — {kind}={want}")
    fig.tight_layout()
    return fig


def plot_class_metrics(end2end: dict, title: str = "Precision / Recall por classe"):
    """Grouped P/R bars per class across the three geometry tasks."""
    import matplotlib.pyplot as plt

    tasks = [("parede", end2end["wall"]), ("curva", end2end["curve"]),
             ("obstaculo", end2end["obstacle"])]
    fig, axes = plt.subplots(1, 3, figsize=(13, 3.4))
    for ax, (name, m) in zip(axes, tasks):
        pc = m.get("per_class", {})
        labels = list(pc)
        x = np.arange(len(labels))
        ax.bar(x - 0.2, [pc[k]["precision"] for k in labels], 0.4, label="P")
        ax.bar(x + 0.2, [pc[k]["recall"] for k in labels], 0.4, label="R")
        ax.set_xticks(x, labels, rotation=30, ha="right", fontsize=7)
        ax.set_ylim(0, 1)
        ax.set_title(f"{name} (macroR={m.get('macro_recall', 0):.2f})", fontsize=9)
        ax.legend(fontsize=7)
    fig.suptitle(title)
    fig.tight_layout()
    return fig


# --------------------------------------------------------------------------- #
# Pipeline visualization: real vs predicted subtile geometry
# --------------------------------------------------------------------------- #
def plt_rect(x, y, w, h, **kw):
    import matplotlib.patches as mpatches

    return mpatches.Rectangle((x, y), w, h, **kw)


def _draw_geometry(
    ax,
    samples,
    geoms,
    tile_h,
    tile_w,
    mismatches=None,
    obstacles=None,
    obst_mismatch=None,
    title="",
):
    """Draw subtile walls (lines) + curves (corner dot) and TILE obstacles (red
    square at tile center). North is up; mismatched subtiles/tiles get red."""
    mismatches = mismatches or set()
    obstacles = obstacles or set()
    obst_mismatch = obst_mismatch or set()
    qrc = {"NW": (0, 0), "NE": (0, 1), "SW": (1, 0), "SE": (1, 1)}
    for s, g in zip(samples, geoms):
        qr, qc = qrc[s.quarter]
        gx = s.tile_c * 2 + qc
        gy = (tile_h * 2 - 1) - (s.tile_r * 2 + qr)  # north up
        if (s.tile_r, s.tile_c, s.quarter) in mismatches:
            ax.add_patch(plt_rect(gx, gy, 1, 1, color=(1, 0.8, 0.8)))
        ax.add_patch(
            plt_rect(gx, gy, 1, 1, fill=False, edgecolor=(0.85, 0.85, 0.85), lw=0.5)
        )
        if g["walls"]["N"]:
            ax.plot([gx, gx + 1], [gy + 1, gy + 1], "k-", lw=2)
        if g["walls"]["S"]:
            ax.plot([gx, gx + 1], [gy, gy], "k-", lw=2)
        if g["walls"]["W"]:
            ax.plot([gx, gx], [gy, gy + 1], "k-", lw=2)
        if g["walls"]["E"]:
            ax.plot([gx + 1, gx + 1], [gy, gy + 1], "k-", lw=2)
        if g["curve"]:
            corner = {
                1: (gx, gy),
                2: (gx, gy + 1),
                3: (gx + 1, gy + 1),
                4: (gx + 1, gy),
            }[g["curve"]]
            ax.plot([corner[0]], [corner[1]], marker="o", color="tab:blue", ms=4)
    # Tile-level obstacles: red square spanning the tile center.
    for tr, tc in obstacles:
        cx, cy = tc * 2 + 1, (tile_h * 2 - 1) - tr * 2
        ax.plot([cx], [cy], marker="s", color="tab:red", ms=9)
    for tr, tc in obst_mismatch:
        ax.add_patch(
            plt_rect(
                tc * 2,
                (tile_h * 2 - 2) - tr * 2,
                2,
                2,
                fill=False,
                edgecolor="red",
                lw=1.5,
            )
        )
    ax.set_xlim(-0.5, tile_w * 2 + 0.5)
    ax.set_ylim(-0.5, tile_h * 2 + 0.5)
    ax.set_aspect("equal")
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_title(title)


def plot_pipeline_comparison(
    run: dict,
    pipeline: MapPipeline,
    explored_gate: bool = True,
    resolve: bool = True,
    label_source: str = "auto",
):
    """Side-by-side: real vs predicted geometry. Walls/curve per subtile,
    obstacle per tile; divergences highlighted in red. ``resolve`` applies the
    anti-overlap policy (matches the deployed pipeline)."""
    import matplotlib.pyplot as plt

    subs = build_run_subtiles(run, label_source=label_source)
    tiles = build_run_tiles(run, label_source=label_source)
    real_geom = [geometry_of(s.real) for s in subs]
    sp = pipeline.predict_subtiles(subs, explored_gate)
    to = pipeline.predict_tiles(tiles)
    if resolve:
        resolve_overlaps(subs, sp, tiles, to)
    pred_geom = [{"walls": p["walls"], "curve": p["curve"]} for p in sp]

    all_rows = [s.tile_r for s in subs] + [t.tile_r for t in tiles]
    all_cols = [s.tile_c for s in subs] + [t.tile_c for t in tiles]
    tile_h = (max(all_rows) + 1) if all_rows else 0
    tile_w = (max(all_cols) + 1) if all_cols else 0

    mism = set()
    for s, rg, pg in zip(subs, real_geom, pred_geom):
        wall_diff = any(
            rg["walls"][d] != pg["walls"][d]
            for d in DIRS
            if not s.real.wall_wildcard.get(d)
        )
        if wall_diff or rg["curve"] != pg["curve"]:
            mism.add((s.tile_r, s.tile_c, s.quarter))

    real_obst = {(t.tile_r, t.tile_c) for t in tiles if t.obstacle}
    pred_obst = {(t.tile_r, t.tile_c) for t, o in zip(tiles, to) if int(o)}
    obst_mism = {
        (t.tile_r, t.tile_c) for t, o in zip(tiles, to) if int(o) != t.obstacle
    }

    fig, axes = plt.subplots(1, 2, figsize=(2 + tile_w * 1.3, 1 + tile_h * 0.7))
    _draw_geometry(
        axes[0],
        subs,
        real_geom,
        tile_h,
        tile_w,
        obstacles=real_obst,
        title="REAL (ground truth)",
    )
    _draw_geometry(
        axes[1],
        subs,
        pred_geom,
        tile_h,
        tile_w,
        mism,
        obstacles=pred_obst,
        obst_mismatch=obst_mism,
        title=f"PREDITO (gate={'on' if explored_gate else 'off'}) — "
        f"{len(mism)} subtiles + {len(obst_mism)} tiles-obst divergentes",
    )
    fig.suptitle(f"Pipeline geometry — {run['run_id']}")
    fig.tight_layout()
    return fig


# --------------------------------------------------------------------------- #
# Resolution-aware features (default) — see notebooks/common/map_features.py
# --------------------------------------------------------------------------- #
# The original ratio features above collapse the patch into coarse band ratios and
# are fragile to the crops' sub-cell mis-centring. Measured on the collected runs,
# the resolution-aware features (profile-peak wall localization, occupancy centroid
# + angle for curves, central-blob obstacle) separate better:
#   wall single-feature AUC 0.928 -> 0.967; curve direction nearest-angle 73%;
#   LORO macro-recall: curve +3.4 pts, obstacle +3.2 pts, wall ~tie.
# They are adopted as the default here so the builders, MapPipeline and the export
# all use them uniformly. The originals stay available with the ``_legacy`` suffix
# for parity checks / A-B comparison via ``compare_feature_sets``.
wall_features_legacy = wall_features
curve_features_legacy = curve_features
obstacle_features_legacy = obstacle_features
WALL_FEATURE_NAMES_LEGACY = WALL_FEATURE_NAMES
CURVE_FEATURE_NAMES_LEGACY = CURVE_FEATURE_NAMES
OBSTACLE_FEATURE_NAMES_LEGACY = OBSTACLE_FEATURE_NAMES

from . import map_features as _mf  # noqa: E402  (all needed names defined above)

wall_features = _mf.wall_features
curve_features = _mf.curve_features
obstacle_features = _mf.obstacle_features
WALL_FEATURE_NAMES = _mf.WALL_FEATURE_NAMES
CURVE_FEATURE_NAMES = _mf.CURVE_FEATURE_NAMES
OBSTACLE_FEATURE_NAMES = _mf.OBSTACLE_FEATURE_NAMES

# MapPipeline captured the old tuples at class-definition time; refresh them.
MapPipeline._FEATURE_NAMES_BY_TASK = {
    "explorado": FEATURE_NAMES,
    "parede": WALL_FEATURE_NAMES,
    "curva": CURVE_FEATURE_NAMES,
    "obstaculo": OBSTACLE_FEATURE_NAMES,
}


def use_legacy_features() -> None:
    """Swap the module back to the original ratio features (for parity tests)."""
    global wall_features, curve_features, obstacle_features
    global WALL_FEATURE_NAMES, CURVE_FEATURE_NAMES, OBSTACLE_FEATURE_NAMES
    wall_features, curve_features, obstacle_features = (
        wall_features_legacy, curve_features_legacy, obstacle_features_legacy)
    WALL_FEATURE_NAMES = WALL_FEATURE_NAMES_LEGACY
    CURVE_FEATURE_NAMES = CURVE_FEATURE_NAMES_LEGACY
    OBSTACLE_FEATURE_NAMES = OBSTACLE_FEATURE_NAMES_LEGACY
    MapPipeline._FEATURE_NAMES_BY_TASK.update({
        "parede": WALL_FEATURE_NAMES, "curva": CURVE_FEATURE_NAMES,
        "obstaculo": OBSTACLE_FEATURE_NAMES})


def use_resolution_features() -> None:
    """Swap the module to the resolution-aware features (the default)."""
    global wall_features, curve_features, obstacle_features
    global WALL_FEATURE_NAMES, CURVE_FEATURE_NAMES, OBSTACLE_FEATURE_NAMES
    wall_features, curve_features, obstacle_features = (
        _mf.wall_features, _mf.curve_features, _mf.obstacle_features)
    WALL_FEATURE_NAMES = _mf.WALL_FEATURE_NAMES
    CURVE_FEATURE_NAMES = _mf.CURVE_FEATURE_NAMES
    OBSTACLE_FEATURE_NAMES = _mf.OBSTACLE_FEATURE_NAMES
    MapPipeline._FEATURE_NAMES_BY_TASK.update({
        "parede": WALL_FEATURE_NAMES, "curva": CURVE_FEATURE_NAMES,
        "obstaculo": OBSTACLE_FEATURE_NAMES})


def compare_feature_sets(samples, tiles, specialist: str,
                         rf: "MapRFConfig | None" = None, augment=None) -> dict:
    """LORO macro-recall of one specialist with legacy vs resolution-aware features."""
    from sklearn.metrics import precision_recall_fscore_support, accuracy_score

    builder = {"parede": build_wall_dataset, "curva": build_curve_dataset,
               "obstaculo": build_obstacle_dataset}[specialist]
    items = tiles if specialist == "obstaculo" else samples
    aug = augment if augment is not None else DEFAULT_AUGMENT[specialist]

    def _mr() -> tuple[float | None, float | None]:
        ds = builder(items, augment=aug)
        pred = cross_val_predict_grouped(ds, rf)
        m = pred >= 0
        if not m.any():
            return None, None
        y, p = ds.y[m], pred[m]
        labs = sorted(set(y.tolist()) | set(p.tolist()))
        _, r, _, _ = precision_recall_fscore_support(y, p, labels=labs, zero_division=0)
        return float(accuracy_score(y, p)), float(np.mean(r))

    use_legacy_features()
    acc_old, mr_old = _mr()
    use_resolution_features()
    acc_new, mr_new = _mr()
    return {"specialist": specialist, "acc_legacy": acc_old, "acc_new": acc_new,
            "macro_recall_legacy": mr_old, "macro_recall_new": mr_new}
