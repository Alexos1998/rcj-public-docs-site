"""Visualization helpers for exploration experiments."""

from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib")

import matplotlib.pyplot as plt
import pandas as pd

from .exploration_sim import ExplorationGraph, SimulationResult, compare_algorithms, compare_tile_center_explorers


def summarize_worlds(worlds: list[Path]) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Run baseline + tile-center explorers for every valid world."""
    rows: list[dict] = []
    errors: list[dict] = []
    for world in worlds:
        try:
            table, _ = compare_tile_center_explorers(world)
            baseline, _ = compare_algorithms(world)
        except Exception as exc:
            errors.append({"world": world.name, "error": str(exc)})
            continue
        legacy = float(
            baseline.set_index("run").loc["legacy_window_006", "total_time_s"]
        )
        for row in table.to_dict("records"):
            row = dict(row)
            row["world"] = world.name
            row["legacy_window_006_s"] = legacy
            row["speedup_vs_legacy_006"] = legacy / float(row["total_time_s"])
            rows.append(row)
    return pd.DataFrame(rows), pd.DataFrame(errors)


def best_by_world(results: pd.DataFrame) -> pd.DataFrame:
    if results.empty:
        return results
    return (
        results.sort_values(["world", "total_time_s"])
        .groupby("world", as_index=False)
        .first()
        .sort_values("speedup_vs_legacy_006", ascending=False)
        .reset_index(drop=True)
    )


def plot_best_speedups(best: pd.DataFrame, *, top_n: int = 20):
    fig, ax = plt.subplots(figsize=(10, max(4, 0.32 * min(top_n, len(best)))))
    data = best.head(top_n).sort_values("speedup_vs_legacy_006")
    ax.barh(data["world"], data["speedup_vs_legacy_006"], color="#2f7d6d")
    ax.axvline(1.0, color="#333333", linewidth=1)
    ax.set_xlabel("speedup vs legacy 0.06")
    ax.set_ylabel("")
    ax.set_title("Melhor explorador de centros reais por mundo")
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    return fig, ax


def plot_method_wins(best: pd.DataFrame):
    counts = best["run"].value_counts().sort_values()
    fig, ax = plt.subplots(figsize=(9, max(3, 0.38 * len(counts))))
    ax.barh(counts.index, counts.values, color="#4569a0")
    ax.set_xlabel("mundos vencidos")
    ax.set_ylabel("")
    ax.set_title("Vitorias por metodo")
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    return fig, ax


def plot_graph(graph: ExplorationGraph, *, ax=None, title: str | None = None):
    if ax is None:
        _, ax = plt.subplots(figsize=(7, 7))
    xs = [c for _, c in graph.nodes]
    ys = [-r for r, _ in graph.nodes]
    ax.scatter(xs, ys, s=28, color="#d8d8d8", edgecolor="#555555", linewidth=0.4)
    for node, dirs in graph.edges.items():
        x0, y0 = node[1], -node[0]
        for direction in dirs:
            nxt = {
                "N": (node[0] - 1, node[1]),
                "E": (node[0], node[1] + 1),
                "S": (node[0] + 1, node[1]),
                "W": (node[0], node[1] - 1),
                "NE": (node[0] - 1, node[1] + 1),
                "SE": (node[0] + 1, node[1] + 1),
                "SW": (node[0] + 1, node[1] - 1),
                "NW": (node[0] - 1, node[1] - 1),
            }[direction]
            if nxt not in graph.nodes:
                continue
            x1, y1 = nxt[1], -nxt[0]
            ax.plot([x0, x1], [y0, y1], color="#b0b0b0", linewidth=0.8, zorder=0)
    ax.scatter([graph.start[1]], [-graph.start[0]], s=80, marker="s", color="#d1495b", label="start")
    ax.set_aspect("equal")
    ax.set_title(title or graph.name)
    ax.set_xlabel("col")
    ax.set_ylabel("-row")
    ax.grid(alpha=0.2)
    return ax


def plot_path(result: SimulationResult, *, ax=None, title: str | None = None):
    if ax is None:
        _, ax = plt.subplots(figsize=(7, 7))
    moves = result.moves_frame()
    if moves.empty:
        ax.set_title(title or result.algorithm)
        return ax
    coords = [moves.iloc[0]["current"], *moves["target"].tolist()]
    xs = [c for _, c in coords]
    ys = [-r for r, _ in coords]
    ax.plot(xs, ys, color="#2f7d6d", linewidth=1.4, alpha=0.85)
    ax.scatter(xs, ys, s=14, color="#2f7d6d", alpha=0.75)
    ax.scatter([xs[0]], [ys[0]], s=70, marker="s", color="#d1495b")
    ax.set_aspect("equal")
    ax.set_title(title or f"{result.algorithm}: {result.total_time_s:.1f}s")
    ax.set_xlabel("col")
    ax.set_ylabel("-row")
    ax.grid(alpha=0.2)
    return ax
