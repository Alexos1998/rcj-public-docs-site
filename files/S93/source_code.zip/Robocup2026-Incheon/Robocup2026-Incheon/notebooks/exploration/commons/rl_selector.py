"""Exploration method benchmarking utilities."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from .exploration_sim import compare_tile_center_explorers, load_world_graphs


DEFAULT_ACTIONS = (
    "tile_dfs_diag_backtrack_sqrt2",
    "tile_dfs_cardinal",
    "tile_dfs_cardinal_first",
    "tile_dfs_left_hand",
    "tile_dfs_right_hand",
    "tile_global_frontier_time",
    "tile_global_frontier_gain",
)


def _state_key(state: tuple[str, str, str]) -> str:
    return "|".join(state)


def world_state(world: Path) -> tuple[str, str, str]:
    graph = load_world_graphs(world)["tile_centers_012"]
    reachable = graph.reachable_nodes(True)
    n = len(reachable)
    degrees = [len(graph.edges.get(node, set())) for node in reachable]
    avg_degree = sum(degrees) / len(degrees) if degrees else 0.0
    deadend_ratio = sum(1 for d in degrees if d <= 1) / len(degrees) if degrees else 0.0
    size_bin = "small" if n < 45 else "medium" if n < 90 else "large"
    degree_bin = "open" if avg_degree >= 4.0 else "mixed" if avg_degree >= 2.7 else "tight"
    deadend_bin = "branchy" if deadend_ratio >= 0.2 else "smooth"
    return (size_bin, degree_bin, deadend_bin)


def benchmark_actions(worlds: list[Path], actions: tuple[str, ...] = DEFAULT_ACTIONS) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows: list[dict] = []
    errors: list[dict] = []
    for world in worlds:
        try:
            table, _ = compare_tile_center_explorers(world)
            state = _state_key(world_state(world))
        except Exception as exc:
            errors.append({"world": world.name, "error": str(exc)})
            continue
        by_run = table.set_index("run")
        best_time = float(table["total_time_s"].min())
        for action in actions:
            if action not in by_run.index:
                continue
            elapsed = float(by_run.loc[action, "total_time_s"])
            rows.append(
                {
                    "world": world.name,
                    "state": state,
                    "action": action,
                    "total_time_s": elapsed,
                    "reward": best_time / elapsed,
                    "regret_s": elapsed - best_time,
                }
            )
    return pd.DataFrame(rows), pd.DataFrame(errors)


