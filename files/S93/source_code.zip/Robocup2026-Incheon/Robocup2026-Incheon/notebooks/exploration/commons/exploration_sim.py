"""Fast, deterministic exploration simulator for WBT maps.

The goal is not physics fidelity. It is a cheap way to compare exploration ideas
before spending minutes in Webots. The simulator mirrors the relevant legacy
choices:

* direct DFS to the first unknown open neighbor, ordered by heading alignment;
* weighted backtracking to a known tile that still has an unknown open neighbor;
* optional diagonal moves;
* the current 0.06 m "moving window" lattice versus 0.12 m real tile centers.
"""

from __future__ import annotations

import heapq
import math
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

import pandas as pd

from notebooks.common import map_wbt


Coord = tuple[int, int]

DIRS8: tuple[str, ...] = ("N", "E", "S", "W", "NE", "SE", "SW", "NW")
DIRS4: tuple[str, ...] = ("N", "E", "S", "W")
DELTAS: dict[str, Coord] = {
    "N": (-1, 0),
    "E": (0, 1),
    "S": (1, 0),
    "W": (0, -1),
    "NE": (-1, 1),
    "SE": (1, 1),
    "SW": (1, -1),
    "NW": (-1, -1),
}
YAW: dict[str, float] = {
    "N": 0.0,
    "E": -math.pi / 2.0,
    "S": math.pi,
    "W": math.pi / 2.0,
    "NE": -math.pi / 4.0,
    "SE": -3.0 * math.pi / 4.0,
    "SW": 3.0 * math.pi / 4.0,
    "NW": math.pi / 4.0,
}
OPPOSITE: dict[str, str] = {
    "N": "S",
    "E": "W",
    "S": "N",
    "W": "E",
    "NE": "SW",
    "SE": "NW",
    "SW": "NE",
    "NW": "SE",
}
DIAGONAL_CARDINAL: dict[str, str] = {
    "NE": "N",
    "SE": "E",
    "SW": "S",
    "NW": "W",
}
DIAGONAL_COMPONENTS: dict[str, tuple[str, str]] = {
    "NE": ("N", "E"),
    "SE": ("S", "E"),
    "SW": ("S", "W"),
    "NW": ("N", "W"),
}
# WbtTileGrid coords are (start_xPos - xPos, zPos - start_zPos). In the proto,
# right/left are +/-x and bottom/top are +/-z, so this table intentionally looks
# rotated compared with the matrix row/col labels.
OUTER_WALL_FIELDS: dict[str, tuple[str, str]] = {
    "N": ("rightWall", "leftWall"),
    "E": ("bottomWall", "topWall"),
    "S": ("leftWall", "rightWall"),
    "W": ("topWall", "bottomWall"),
}


def _add(a: Coord, b: Coord) -> Coord:
    return (a[0] + b[0], a[1] + b[1])


def _norm_angle(angle: float) -> float:
    while angle > math.pi:
        angle -= 2.0 * math.pi
    while angle < -math.pi:
        angle += 2.0 * math.pi
    return angle


def _angle_delta(target: float, current: float) -> float:
    return _norm_angle(target - current)


def _is_cardinal(direction: str) -> bool:
    return direction in DIRS4


def _direction_between(a: Coord, b: Coord) -> str:
    delta = (b[0] - a[0], b[1] - a[1])
    for direction, d in DELTAS.items():
        if d == delta:
            return direction
    raise ValueError(f"Non-neighbor move from {a} to {b}")


def _rotate_cardinal(direction: str, quarter_turns: int) -> str:
    idx = DIRS4.index(direction)
    return DIRS4[(idx + quarter_turns) % len(DIRS4)]


def _direction_order(
    heading: str,
    allow_diagonal: bool,
    mode: str = "heading",
) -> list[str]:
    directions = list(DIRS8 if allow_diagonal else DIRS4)
    heading_yaw = YAW[heading]
    if mode == "heading":
        return sorted(directions, key=lambda d: (abs(_angle_delta(YAW[d], heading_yaw)), DIRS8.index(d)))
    if mode == "cardinal_first":
        return sorted(
            directions,
            key=lambda d: (
                0 if _is_cardinal(d) else 1,
                abs(_angle_delta(YAW[d], heading_yaw)),
                DIRS8.index(d),
            ),
        )
    if mode in {"left_hand", "right_hand"}:
        # Cheap wall-following flavored ordering. Diagonals are still allowed, but
        # only after the cardinal preference loop has a chance to choose.
        if heading not in DIRS4:
            heading = DIAGONAL_CARDINAL.get(heading, "N")
        turns = (-1, 0, 1, 2) if mode == "left_hand" else (1, 0, -1, 2)
        order = [_rotate_cardinal(heading, q) for q in turns]
        if allow_diagonal:
            rest = [d for d in _direction_order(heading, True, "heading") if d not in order]
            order.extend(rest)
        return [d for d in order if d in directions]
    raise ValueError(f"Unknown direct_order={mode!r}")


def _tile_blocked(tile: dict | None, *, block_swamps: bool) -> bool:
    if tile is None:
        return True
    return bool(tile.get("trap")) or bool(tile.get("obstacle")) or (
        block_swamps and bool(tile.get("swamp"))
    )


def _tile_edge_wall(
    wbt: map_wbt.WbtTileGrid,
    coord: Coord,
    direction: str,
    *,
    wall_policy: str,
) -> bool:
    tile = wbt.get(*coord)
    other = wbt.get(*_add(coord, DELTAS[direction]))
    if tile is None or other is None:
        return True
    field, other_field = OUTER_WALL_FIELDS[direction]
    current_wall = int(tile.get(field, 0)) > 0
    other_wall = int(other.get(other_field, 0)) > 0
    if wall_policy == "either":
        return current_wall or other_wall
    if wall_policy == "current":
        return current_wall
    if wall_policy == "both":
        return current_wall and other_wall
    raise ValueError(f"Unknown wall_policy={wall_policy!r}")


@dataclass(frozen=True)
class MotionConfig:
    """Motion timing constants copied from the current legacy setup."""

    tile_size_m: float = 0.06
    linear_speed_mps: float = 0.125
    diagonal_linear_speed_mps: float = 0.11
    wheel_radius_m: float = 0.02
    axle_length_m: float = 0.052
    max_wheel_speed_rad_s: float = 6.27
    min_turn_speed_rad_s: float = 1.5
    turn_gain: float = 90.0
    turn_tolerance_rad: float = 0.006
    max_turn_duration_s: float = 1.2
    turn_dt_s: float = 0.002

    def with_tile_size(self, tile_size_m: float) -> "MotionConfig":
        return MotionConfig(
            tile_size_m=tile_size_m,
            linear_speed_mps=self.linear_speed_mps,
            diagonal_linear_speed_mps=self.diagonal_linear_speed_mps,
            wheel_radius_m=self.wheel_radius_m,
            axle_length_m=self.axle_length_m,
            max_wheel_speed_rad_s=self.max_wheel_speed_rad_s,
            min_turn_speed_rad_s=self.min_turn_speed_rad_s,
            turn_gain=self.turn_gain,
            turn_tolerance_rad=self.turn_tolerance_rad,
            max_turn_duration_s=self.max_turn_duration_s,
            turn_dt_s=self.turn_dt_s,
        )

    def turn_time(self, from_heading: str, to_direction: str) -> float:
        """Integrate the legacy P turn controller against ideal yaw dynamics."""
        error = abs(_angle_delta(YAW[to_direction], YAW[from_heading]))
        elapsed = 0.0
        while error > self.turn_tolerance_rad and elapsed < self.max_turn_duration_s:
            wheel = min(
                self.max_wheel_speed_rad_s,
                max(self.min_turn_speed_rad_s, error * self.turn_gain),
            )
            yaw_rate = 2.0 * self.wheel_radius_m * wheel / self.axle_length_m
            error = max(0.0, error - yaw_rate * self.turn_dt_s)
            elapsed += self.turn_dt_s
        return min(elapsed, self.max_turn_duration_s)

    def drive_time(self, direction: str) -> float:
        if _is_cardinal(direction):
            return self.tile_size_m / self.linear_speed_mps
        return self.tile_size_m * math.sqrt(2.0) / self.diagonal_linear_speed_mps

    def drive_distance(self, direction: str) -> float:
        return self.tile_size_m if _is_cardinal(direction) else self.tile_size_m * math.sqrt(2.0)


@dataclass
class ExplorationGraph:
    name: str
    tile_size_m: float
    start: Coord
    nodes: set[Coord]
    edges: dict[Coord, set[str]]
    node_kind: dict[Coord, str] = field(default_factory=dict)

    def neighbors(self, coord: Coord, allow_diagonal: bool = True) -> list[tuple[str, Coord]]:
        directions = DIRS8 if allow_diagonal else DIRS4
        return [
            (direction, _add(coord, DELTAS[direction]))
            for direction in directions
            if direction in self.edges.get(coord, set())
        ]

    def reachable_nodes(self, allow_diagonal: bool = True) -> set[Coord]:
        seen = {self.start}
        queue = deque([self.start])
        while queue:
            current = queue.popleft()
            for _, nxt in self.neighbors(current, allow_diagonal):
                if nxt not in seen:
                    seen.add(nxt)
                    queue.append(nxt)
        return seen


@dataclass
class MoveRecord:
    step: int
    phase: str
    planner: str
    current: Coord
    target: Coord
    direction: str
    backtracking: bool
    turn_s: float
    drive_s: float
    distance_m: float
    heading_before: str
    heading_after: str


@dataclass
class SimulationResult:
    algorithm: str
    graph_name: str
    finished: bool
    returned_to_start: bool
    total_time_s: float
    turn_time_s: float
    drive_time_s: float
    distance_m: float
    moves: int
    cardinal_moves: int
    diagonal_moves: int
    backtracking_moves: int
    visited_nodes: int
    known_nodes: int
    reachable_nodes: int
    final: Coord
    records: list[MoveRecord]

    def summary(self) -> dict:
        return {
            "algorithm": self.algorithm,
            "graph": self.graph_name,
            "finished": self.finished,
            "returned": self.returned_to_start,
            "total_time_s": self.total_time_s,
            "turn_time_s": self.turn_time_s,
            "drive_time_s": self.drive_time_s,
            "distance_m": self.distance_m,
            "moves": self.moves,
            "cardinal": self.cardinal_moves,
            "diagonal": self.diagonal_moves,
            "backtracking": self.backtracking_moves,
            "visited_nodes": self.visited_nodes,
            "known_nodes": self.known_nodes,
            "reachable_nodes": self.reachable_nodes,
            "coverage": self.known_nodes / self.reachable_nodes if self.reachable_nodes else 0.0,
            "final": self.final,
        }

    def moves_frame(self) -> pd.DataFrame:
        return pd.DataFrame([r.__dict__ for r in self.records])


def resolve_world_path(source: str | Path) -> Path:
    """Resolve a run, map_path.txt, .wbt, or bare world name into a WBT file."""
    direct = map_wbt.resolve_wbt_path(source)
    if direct and direct.is_file():
        return direct

    path = Path(source).expanduser()
    candidates: list[Path] = []
    if path.suffix.lower() == ".wbt":
        candidates.append(path)
    else:
        candidates.extend(
            [
                path,
                path.with_suffix(".wbt"),
                path.parent / f"{path.name} - 2026.wbt",
                path.parent / f"{path.name} - 2026 - fakes.wbt",
            ]
        )
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(f"Could not resolve WBT world from {source!r}")


def _load_wbt(source: str | Path) -> map_wbt.WbtTileGrid:
    path = resolve_world_path(source)
    tiles = map_wbt.parse_wbt(path)
    obstacles = map_wbt.parse_obstacle_nodes(path)
    return map_wbt.WbtTileGrid(tiles, obstacles)


def _add_edge(edges: dict[Coord, set[str]], src: Coord, direction: str) -> None:
    edges.setdefault(src, set()).add(direction)


def _finalize_edges(nodes: set[Coord], edges: dict[Coord, set[str]]) -> dict[Coord, set[str]]:
    out = {node: set() for node in nodes}
    for src, dirs in edges.items():
        if src not in nodes:
            continue
        for direction in dirs:
            dst = _add(src, DELTAS[direction])
            if dst in nodes:
                out[src].add(direction)
    return out


def build_tile_center_graph(
    wbt: map_wbt.WbtTileGrid,
    *,
    include_diagonal: bool = True,
    block_swamps: bool = False,
    include_area4: bool = False,
    wall_policy: str = "either",
) -> ExplorationGraph:
    """Graph whose nodes are only real 0.12 m tile centers."""
    nodes: set[Coord] = set()
    node_kind: dict[Coord, str] = {}
    for coord in wbt.all_coords:
        tile = wbt.get(*coord)
        if tile is None:
            continue
        if not include_area4 and wbt.is_area4(*coord):
            continue
        if _tile_blocked(tile, block_swamps=block_swamps):
            continue
        nodes.add(coord)
        node_kind[coord] = "tile_center"

    edges: dict[Coord, set[str]] = {node: set() for node in nodes}
    for node in nodes:
        for direction in DIRS4:
            dst = _add(node, DELTAS[direction])
            if dst in nodes and not _tile_edge_wall(wbt, node, direction, wall_policy=wall_policy):
                _add_edge(edges, node, direction)
        if include_diagonal:
            for direction, (a, b) in DIAGONAL_COMPONENTS.items():
                dst = _add(node, DELTAS[direction])
                via_a = _add(node, DELTAS[a])
                via_b = _add(node, DELTAS[b])
                path_a = (
                    via_a in nodes
                    and dst in nodes
                    and a in edges.get(node, set())
                    and b in edges.get(via_a, set())
                )
                path_b = (
                    via_b in nodes
                    and dst in nodes
                    and b in edges.get(node, set())
                    and a in edges.get(via_b, set())
                )
                if path_a or path_b:
                    _add_edge(edges, node, direction)

    name = "real_tile_centers_012_diag" if include_diagonal else "real_tile_centers_012_cardinal"
    return ExplorationGraph(
        name=name,
        tile_size_m=map_wbt.TILE_M,
        start=wbt.anchor,
        nodes=nodes,
        edges=_finalize_edges(nodes, edges),
        node_kind=node_kind,
    )


def _half_node_passable(
    wbt: map_wbt.WbtTileGrid,
    node: Coord,
    *,
    block_swamps: bool,
    include_area4: bool,
    wall_policy: str,
) -> bool:
    hr, hc = node
    even_r = hr % 2 == 0
    even_c = hc % 2 == 0
    r0 = math.floor(hr / 2)
    c0 = math.floor(hc / 2)

    def ok(coord: Coord) -> bool:
        tile = wbt.get(*coord)
        if tile is None:
            return False
        if not include_area4 and wbt.is_area4(*coord):
            return False
        return not _tile_blocked(tile, block_swamps=block_swamps)

    if even_r and even_c:
        return ok((hr // 2, hc // 2))
    if not even_r and even_c:
        north = (r0, hc // 2)
        south = (r0 + 1, hc // 2)
        return ok(north) and ok(south) and not _tile_edge_wall(
            wbt, north, "S", wall_policy=wall_policy
        )
    if even_r and not even_c:
        west = (hr // 2, c0)
        east = (hr // 2, c0 + 1)
        return ok(west) and ok(east) and not _tile_edge_wall(
            wbt, west, "E", wall_policy=wall_policy
        )

    nw = (r0, c0)
    ne = (r0, c0 + 1)
    sw = (r0 + 1, c0)
    se = (r0 + 1, c0 + 1)
    if not all(ok(coord) for coord in (nw, ne, sw, se)):
        return False
    shared_open = (
        not _tile_edge_wall(wbt, nw, "E", wall_policy=wall_policy)
        and not _tile_edge_wall(wbt, sw, "E", wall_policy=wall_policy)
        and not _tile_edge_wall(wbt, nw, "S", wall_policy=wall_policy)
        and not _tile_edge_wall(wbt, ne, "S", wall_policy=wall_policy)
    )
    return shared_open


def build_half_step_graph(
    wbt: map_wbt.WbtTileGrid,
    *,
    include_diagonal: bool = True,
    block_swamps: bool = False,
    include_area4: bool = False,
    wall_policy: str = "either",
) -> ExplorationGraph:
    """Graph for the current 0.06 m moving-window behavior.

    Even-even nodes are real tile centers. Odd coordinates are halfway between
    tile centers, including the between-four-tiles centers that we want to avoid
    as primary exploration targets.
    """
    min_r, max_r, min_c, max_c = wbt.bounds()
    nodes: set[Coord] = set()
    node_kind: dict[Coord, str] = {}
    for hr in range(2 * min_r, 2 * max_r + 1):
        for hc in range(2 * min_c, 2 * max_c + 1):
            node = (hr, hc)
            if not _half_node_passable(
                wbt,
                node,
                block_swamps=block_swamps,
                include_area4=include_area4,
                wall_policy=wall_policy,
            ):
                continue
            nodes.add(node)
            if hr % 2 == 0 and hc % 2 == 0:
                node_kind[node] = "tile_center"
            elif hr % 2 == 1 and hc % 2 == 1:
                node_kind[node] = "between_four_tiles"
            else:
                node_kind[node] = "edge_midpoint"

    edges: dict[Coord, set[str]] = {node: set() for node in nodes}
    for node in nodes:
        for direction in DIRS4:
            if _add(node, DELTAS[direction]) in nodes:
                _add_edge(edges, node, direction)
        if include_diagonal:
            for direction, (a, b) in DIAGONAL_COMPONENTS.items():
                dst = _add(node, DELTAS[direction])
                if dst not in nodes:
                    continue
                if _add(node, DELTAS[a]) in nodes and _add(node, DELTAS[b]) in nodes:
                    _add_edge(edges, node, direction)

    return ExplorationGraph(
        name="legacy_window_006_diag" if include_diagonal else "legacy_window_006_cardinal",
        tile_size_m=map_wbt.TILE_M / 2.0,
        start=(0, 0),
        nodes=nodes,
        edges=_finalize_edges(nodes, edges),
        node_kind=node_kind,
    )


def load_world_graphs(source: str | Path, *, wall_policy: str = "either") -> dict[str, ExplorationGraph]:
    wbt = _load_wbt(source)
    graphs = {
        "legacy_window_006": build_half_step_graph(
            wbt, include_diagonal=True, wall_policy=wall_policy
        ),
        "tile_centers_012": build_tile_center_graph(
            wbt, include_diagonal=True, wall_policy=wall_policy
        ),
        "tile_centers_012_cardinal": build_tile_center_graph(
            wbt, include_diagonal=False, wall_policy=wall_policy
        ),
    }
    return graphs


def _open_mask(graph: ExplorationGraph, coord: Coord, allow_diagonal: bool) -> set[str]:
    return {direction for direction, _ in graph.neighbors(coord, allow_diagonal)}


def _has_unknown_open_neighbor(
    graph: ExplorationGraph,
    known: dict[Coord, set[str]],
    coord: Coord,
    allow_diagonal: bool,
) -> bool:
    for direction in known.get(coord, set()):
        if not allow_diagonal and direction not in DIRS4:
            continue
        nxt = _add(coord, DELTAS[direction])
        if nxt in graph.nodes and nxt not in known:
            return True
    return False


def _direct_dfs_decision(
    graph: ExplorationGraph,
    known: dict[Coord, set[str]],
    current: Coord,
    heading: str,
    allow_diagonal: bool,
    direct_order: str,
) -> tuple[Coord, str] | None:
    mask = known.get(current, set())
    for direction in _direction_order(heading, allow_diagonal, direct_order):
        if direction not in mask:
            continue
        nxt = _add(current, DELTAS[direction])
        if nxt in graph.nodes and nxt not in known:
            return nxt, direction
    return None


def _legacy_backtracking_decision(
    graph: ExplorationGraph,
    wallbits: dict[Coord, set[str]],
    known: dict[Coord, set[str]],
    current: Coord,
    allow_diagonal: bool,
    diagonal_penalty: float,
) -> tuple[Coord, str] | None:
    queue: list[tuple[float, Coord]] = [(0.0, current)]
    dist = {current: 0.0}
    parent: dict[Coord, Coord] = {}
    target: Coord | None = None

    while queue:
        d, tile = heapq.heappop(queue)
        if d > dist[tile]:
            continue
        if tile != current and _has_unknown_open_neighbor(graph, known, tile, allow_diagonal):
            target = tile
            break
        for direction in wallbits.get(tile, set()):
            if not allow_diagonal and direction not in DIRS4:
                continue
            nxt = _add(tile, DELTAS[direction])
            if nxt not in graph.nodes:
                continue
            cost = 1.0 if _is_cardinal(direction) else diagonal_penalty
            nd = d + cost
            if nd < dist.get(nxt, math.inf):
                dist[nxt] = nd
                parent[nxt] = tile
                heapq.heappush(queue, (nd, nxt))

    if target is None:
        return None
    first = target
    while parent.get(first) is not None and parent[first] != current:
        first = parent[first]
    if first == current:
        return None
    return first, _direction_between(current, first)


def _nearest_frontier_decision(
    graph: ExplorationGraph,
    wallbits: dict[Coord, set[str]],
    known: dict[Coord, set[str]],
    current: Coord,
    heading: str,
    allow_diagonal: bool,
    motion: MotionConfig,
) -> tuple[Coord, str] | None:
    current_unknowns = []
    for direction in known.get(current, set()):
        if not allow_diagonal and direction not in DIRS4:
            continue
        nxt = _add(current, DELTAS[direction])
        if nxt in graph.nodes and nxt not in known:
            current_unknowns.append((motion.turn_time(heading, direction) + motion.drive_time(direction), nxt, direction))
    if current_unknowns:
        _, nxt, direction = min(current_unknowns)
        return nxt, direction

    queue: list[tuple[float, Coord]] = [(0.0, current)]
    dist = {current: 0.0}
    parent: dict[Coord, Coord] = {}
    target: Coord | None = None
    while queue:
        d, tile = heapq.heappop(queue)
        if d > dist[tile]:
            continue
        if tile != current and _has_unknown_open_neighbor(graph, known, tile, allow_diagonal):
            target = tile
            break
        for direction in wallbits.get(tile, set()):
            if not allow_diagonal and direction not in DIRS4:
                continue
            nxt = _add(tile, DELTAS[direction])
            if nxt not in graph.nodes:
                continue
            nd = d + motion.drive_time(direction)
            if nd < dist.get(nxt, math.inf):
                dist[nxt] = nd
                parent[nxt] = tile
                heapq.heappush(queue, (nd, nxt))
    if target is None:
        return None
    first = target
    while parent.get(first) is not None and parent[first] != current:
        first = parent[first]
    if first == current:
        return None
    return first, _direction_between(current, first)


def _frontier_candidates(
    graph: ExplorationGraph,
    known: dict[Coord, set[str]],
    allow_diagonal: bool,
) -> list[tuple[Coord, int]]:
    out: list[tuple[Coord, int]] = []
    for tile in known:
        gain = 0
        for direction in known.get(tile, set()):
            if not allow_diagonal and direction not in DIRS4:
                continue
            nxt = _add(tile, DELTAS[direction])
            if nxt in graph.nodes and nxt not in known:
                gain += 1
        if gain:
            out.append((tile, gain))
    return out


def _shortest_known_paths(
    graph: ExplorationGraph,
    wallbits: dict[Coord, set[str]],
    current: Coord,
    allow_diagonal: bool,
    motion: MotionConfig,
    metric: str,
) -> tuple[dict[Coord, float], dict[Coord, Coord]]:
    queue: list[tuple[float, Coord]] = [(0.0, current)]
    dist = {current: 0.0}
    parent: dict[Coord, Coord] = {}
    while queue:
        d, tile = heapq.heappop(queue)
        if d > dist[tile]:
            continue
        for direction in sorted(wallbits.get(tile, set()), key=lambda d: DIRS8.index(d)):
            if not allow_diagonal and direction not in DIRS4:
                continue
            nxt = _add(tile, DELTAS[direction])
            if nxt not in graph.nodes:
                continue
            if metric == "steps":
                edge_cost = 1.0 if _is_cardinal(direction) else math.sqrt(2.0)
            elif metric == "manhattan":
                edge_cost = 1.0 if _is_cardinal(direction) else 2.0
            elif metric == "time":
                edge_cost = motion.drive_time(direction)
            else:
                raise ValueError(f"Unknown metric={metric!r}")
            nd = d + edge_cost
            if nd < dist.get(nxt, math.inf):
                dist[nxt] = nd
                parent[nxt] = tile
                heapq.heappush(queue, (nd, nxt))
    return dist, parent


def _first_step_from_parent(parent: dict[Coord, Coord], current: Coord, target: Coord) -> Coord | None:
    first = target
    while parent.get(first) is not None and parent[first] != current:
        first = parent[first]
    if first == current:
        return None
    return first


def _scored_frontier_decision(
    graph: ExplorationGraph,
    wallbits: dict[Coord, set[str]],
    known: dict[Coord, set[str]],
    current: Coord,
    heading: str,
    allow_diagonal: bool,
    motion: MotionConfig,
    *,
    metric: str,
    gain_weight: float = 0.0,
    turn_weight: float = 0.0,
) -> tuple[Coord, str] | None:
    candidates = _frontier_candidates(graph, known, allow_diagonal)
    if not candidates:
        return None
    dist, parent = _shortest_known_paths(graph, wallbits, current, allow_diagonal, motion, metric)

    best: tuple[float, Coord, str] | None = None
    for tile, gain in candidates:
        if tile not in dist:
            continue
        first = _first_step_from_parent(parent, current, tile) if tile != current else current
        if first is None:
            continue
        if first == current:
            unknown_steps = []
            for direction in _direction_order(heading, allow_diagonal, "heading"):
                if direction not in known.get(current, set()):
                    continue
                nxt = _add(current, DELTAS[direction])
                if nxt in graph.nodes and nxt not in known:
                    unknown_steps.append((direction, nxt))
            for direction, nxt in unknown_steps:
                score = motion.turn_time(heading, direction) * turn_weight - gain_weight * gain
                candidate = (score, nxt, direction)
                if best is None or candidate < best:
                    best = candidate
            continue
        direction = _direction_between(current, first)
        score = dist[tile] + motion.turn_time(heading, direction) * turn_weight - gain_weight * gain
        candidate = (score, first, direction)
        if best is None or candidate < best:
            best = candidate

    if best is None:
        return None
    _, nxt, direction = best
    return nxt, direction


def _parent_return_path(parent: dict[Coord, Coord], current: Coord, start: Coord) -> list[Coord] | None:
    path: list[Coord] = []
    tile = current
    guard = len(parent) + 2
    while tile != start and guard > 0:
        guard -= 1
        if tile not in parent:
            return None
        tile = parent[tile]
        path.append(tile)
    return path if tile == start else None


def _bfs_return_path(
    graph: ExplorationGraph,
    visited: set[Coord],
    current: Coord,
    start: Coord,
) -> list[Coord] | None:
    seen = {current}
    parent: dict[Coord, Coord] = {}
    queue = deque([current])
    while queue:
        tile = queue.popleft()
        if tile == start:
            break
        for direction in DIRS4:
            nxt = _add(tile, DELTAS[direction])
            if nxt not in graph.nodes or nxt not in visited or nxt in seen:
                continue
            seen.add(nxt)
            parent[nxt] = tile
            queue.append(nxt)
    if start not in seen:
        return None
    rev: list[Coord] = []
    tile = start
    while tile != current:
        rev.append(tile)
        tile = parent[tile]
    rev.reverse()
    return rev


def simulate(
    graph: ExplorationGraph,
    *,
    algorithm: str = "legacy_dfs",
    allow_diagonal: bool = True,
    direct_order: str = "heading",
    macro_tile_marking: bool = False,
    return_to_start: bool = True,
    diagonal_backtrack_penalty: float = 5.0,
    frontier_metric: str = "time",
    frontier_gain_weight: float = 0.0,
    frontier_turn_weight: float = 0.0,
    max_steps: int = 20000,
    motion: MotionConfig | None = None,
) -> SimulationResult:
    """Run one exploration simulation on a graph."""
    if graph.start not in graph.nodes:
        raise ValueError(f"Start {graph.start} is not passable in graph {graph.name}")
    motion = (motion or MotionConfig()).with_tile_size(graph.tile_size_m)

    current = graph.start
    heading = "N"
    known: dict[Coord, set[str]] = {}
    wallbits: dict[Coord, set[str]] = {}
    visited: set[Coord] = set()
    parent: dict[Coord, Coord] = {}
    records: list[MoveRecord] = []
    total_turn = 0.0
    total_drive = 0.0
    total_distance = 0.0
    backtracking_moves = 0
    phase = "exploring"
    return_path: list[Coord] = []

    def sense(tile: Coord) -> None:
        visited.add(tile)
        mask = _open_mask(graph, tile, allow_diagonal)
        known[tile] = set(mask)
        wallbits.setdefault(tile, set()).update(mask)
        if macro_tile_marking:
            ox = (tile[0] // 2) * 2
            oy = (tile[1] // 2) * 2
            dx = tile[0] - ox
            dy = tile[1] - oy
            companions = [
                ((ox + (1 - dx), oy + dy), "S" if dx == 0 else "N"),
                ((ox + dx, oy + (1 - dy)), "E" if dy == 0 else "W"),
                (
                    (ox + (1 - dx), oy + (1 - dy)),
                    "SE" if (dx, dy) == (0, 0) else "SW" if dx == 0 else "NE" if dy == 0 else "NW",
                ),
            ]
            for companion, direction in companions:
                if companion in graph.nodes and direction in mask:
                    visited.add(companion)
                    parent.setdefault(companion, tile)

    def execute(target: Coord, direction: str, backtracking: bool, planner_name: str) -> None:
        nonlocal current, heading, total_turn, total_drive, total_distance, backtracking_moves
        heading_before = heading
        turn_s = motion.turn_time(heading, direction)
        drive_s = motion.drive_time(direction)
        distance_m = motion.drive_distance(direction)
        total_turn += turn_s
        total_drive += drive_s
        total_distance += distance_m
        if backtracking:
            backtracking_moves += 1
        if not backtracking and direction in known.get(current, set()):
            known[current].discard(direction)
        wallbits.setdefault(target, set()).add(OPPOSITE[direction])
        parent.setdefault(target, current)
        current_before = current
        current = target
        visited.add(current)
        if direction in DIAGONAL_CARDINAL:
            total_turn += motion.turn_time(direction, DIAGONAL_CARDINAL[direction])
            heading = DIAGONAL_CARDINAL[direction]
        else:
            heading = direction
        records.append(
            MoveRecord(
                step=len(records) + 1,
                phase=phase,
                planner=planner_name,
                current=current_before,
                target=target,
                direction=direction,
                backtracking=backtracking,
                turn_s=turn_s,
                drive_s=drive_s,
                distance_m=distance_m,
                heading_before=heading_before,
                heading_after=heading,
            )
        )

    finished = False
    for _ in range(max_steps):
        if phase == "returning":
            if current == graph.start:
                finished = True
                break
            if not return_path:
                return_path = _parent_return_path(parent, current, graph.start) or []
                if not return_path:
                    return_path = _bfs_return_path(graph, visited, current, graph.start) or []
                if not return_path:
                    finished = True
                    break
            nxt = return_path.pop(0)
            execute(nxt, _direction_between(current, nxt), True, "return_to_start")
            continue

        sense(current)
        local_order = direct_order
        if algorithm == "dfs_cardinal_first":
            local_order = "cardinal_first"
        elif algorithm == "dfs_left_hand":
            local_order = "left_hand"
        elif algorithm == "dfs_right_hand":
            local_order = "right_hand"

        decision = _direct_dfs_decision(graph, known, current, heading, allow_diagonal, local_order)
        planner_name = "direct_dfs"
        backtracking = False
        if decision is None:
            if algorithm == "nearest_frontier":
                decision = _nearest_frontier_decision(
                    graph, wallbits, known, current, heading, allow_diagonal, motion
                )
                planner_name = "nearest_frontier"
            elif algorithm in {"frontier_score", "frontier_gain", "frontier_manhattan"}:
                metric = "manhattan" if algorithm == "frontier_manhattan" else frontier_metric
                gain_weight = frontier_gain_weight if algorithm != "frontier_gain" else max(frontier_gain_weight, 0.35)
                decision = _scored_frontier_decision(
                    graph,
                    wallbits,
                    known,
                    current,
                    heading,
                    allow_diagonal,
                    motion,
                    metric=metric,
                    gain_weight=gain_weight,
                    turn_weight=frontier_turn_weight,
                )
                planner_name = algorithm
            else:
                decision = _legacy_backtracking_decision(
                    graph,
                    wallbits,
                    known,
                    current,
                    allow_diagonal,
                    diagonal_backtrack_penalty,
                )
                planner_name = "legacy_backtrack"
            backtracking = decision is not None

        if decision is None:
            if return_to_start and current != graph.start:
                phase = "returning"
                continue
            finished = True
            break

        target, direction = decision
        execute(target, direction, backtracking, planner_name)
    else:
        finished = False

    reachable = graph.reachable_nodes(allow_diagonal)
    return SimulationResult(
        algorithm=algorithm,
        graph_name=graph.name,
        finished=finished,
        returned_to_start=(current == graph.start),
        total_time_s=total_turn + total_drive,
        turn_time_s=total_turn,
        drive_time_s=total_drive,
        distance_m=total_distance,
        moves=len(records),
        cardinal_moves=sum(1 for r in records if _is_cardinal(r.direction)),
        diagonal_moves=sum(1 for r in records if not _is_cardinal(r.direction)),
        backtracking_moves=backtracking_moves,
        visited_nodes=len(visited & reachable),
        known_nodes=len(set(known) & reachable),
        reachable_nodes=len(reachable),
        final=current,
        records=records,
    )


def compare_algorithms(
    source: str | Path, *, wall_policy: str = "either"
) -> tuple[pd.DataFrame, dict[str, SimulationResult]]:
    """Load one WBT world and run the default comparison matrix."""
    graphs = load_world_graphs(source, wall_policy=wall_policy)
    runs = {
        "legacy_window_006": simulate(
            graphs["legacy_window_006"],
            algorithm="legacy_dfs",
            allow_diagonal=True,
            macro_tile_marking=True,
        ),
        "tile_centers_012_dfs": simulate(
            graphs["tile_centers_012"],
            algorithm="legacy_dfs",
            allow_diagonal=True,
        ),
        "tile_centers_012_cardinal": simulate(
            graphs["tile_centers_012_cardinal"],
            algorithm="legacy_dfs",
            allow_diagonal=False,
        ),
        "tile_centers_012_frontier_time": simulate(
            graphs["tile_centers_012"],
            algorithm="nearest_frontier",
            allow_diagonal=True,
        ),
    }
    frame = pd.DataFrame([result.summary() for result in runs.values()])
    frame.insert(0, "run", list(runs))
    return frame.sort_values("total_time_s").reset_index(drop=True), runs


def compare_tile_center_explorers(
    source: str | Path, *, wall_policy: str = "either"
) -> tuple[pd.DataFrame, dict[str, SimulationResult]]:
    """Compare only explorers whose primary targets are real 0.12 m tile centers."""
    graphs = load_world_graphs(source, wall_policy=wall_policy)
    diag = graphs["tile_centers_012"]
    cardinal = graphs["tile_centers_012_cardinal"]
    runs = {
        "tile_dfs_diag_backtrack5": simulate(
            diag,
            algorithm="legacy_dfs",
            allow_diagonal=True,
            diagonal_backtrack_penalty=5.0,
        ),
        "tile_dfs_diag_backtrack_sqrt2": simulate(
            diag,
            algorithm="legacy_dfs",
            allow_diagonal=True,
            diagonal_backtrack_penalty=math.sqrt(2.0),
        ),
        "tile_dfs_diag_backtrack1": simulate(
            diag,
            algorithm="legacy_dfs",
            allow_diagonal=True,
            diagonal_backtrack_penalty=1.0,
        ),
        "tile_dfs_cardinal": simulate(
            cardinal,
            algorithm="legacy_dfs",
            allow_diagonal=False,
        ),
        "tile_dfs_cardinal_first": simulate(
            diag,
            algorithm="dfs_cardinal_first",
            allow_diagonal=True,
            diagonal_backtrack_penalty=math.sqrt(2.0),
        ),
        "tile_dfs_left_hand": simulate(
            diag,
            algorithm="dfs_left_hand",
            allow_diagonal=True,
            diagonal_backtrack_penalty=math.sqrt(2.0),
        ),
        "tile_dfs_right_hand": simulate(
            diag,
            algorithm="dfs_right_hand",
            allow_diagonal=True,
            diagonal_backtrack_penalty=math.sqrt(2.0),
        ),
        "tile_frontier_time_diag": simulate(
            diag,
            algorithm="nearest_frontier",
            allow_diagonal=True,
        ),
        "tile_frontier_time_cardinal": simulate(
            cardinal,
            algorithm="nearest_frontier",
            allow_diagonal=False,
        ),
        "tile_global_frontier_time": simulate(
            diag,
            algorithm="frontier_score",
            allow_diagonal=True,
            frontier_metric="time",
            frontier_turn_weight=1.0,
        ),
        "tile_global_frontier_gain": simulate(
            diag,
            algorithm="frontier_gain",
            allow_diagonal=True,
            frontier_metric="time",
            frontier_gain_weight=0.35,
            frontier_turn_weight=0.5,
        ),
        "tile_global_frontier_manhattan": simulate(
            cardinal,
            algorithm="frontier_manhattan",
            allow_diagonal=False,
            frontier_metric="manhattan",
        ),
    }
    frame = pd.DataFrame([result.summary() for result in runs.values()])
    frame.insert(0, "run", list(runs))
    return frame.sort_values("total_time_s").reset_index(drop=True), runs
