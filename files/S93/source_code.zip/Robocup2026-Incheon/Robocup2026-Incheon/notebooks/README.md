# Robocup 2026 Perception Notebooks

## Dataset Flow

Datasets are local artifacts, not source files.

- Dataset archives live in `notebooks/data/tars/`.
- Extracted datasets live in `notebooks/data/extracted/<dataset_name>/`.
- Generated CSV manifests live in `notebooks/data/manifests/<dataset_name>/`.
- Versioned source scripts live in `notebooks/scripts/`.

Do not write generated images into `notebooks/scripts/`. Do not commit extracted datasets, generated manifests, trained models, or reports unless explicitly requested.

Expected extracted dataset layout:

```text
notebooks/data/extracted/<dataset_name>/
├── train/
│   ├── harmed/images/*.png
│   ├── unharmed/images/*.png
│   ├── stable/images/*.png
│   ├── none/images/*.png
│   └── cognitive/images/*.png
├── validation/
└── test/
```

Generate manifests:

```bash
python notebooks/scripts/prepare_dataset.py --dataset-name dataset_v001
python notebooks/scripts/export_dataset_manifest.py --dataset-name dataset_v001
```

With bbox annotations:

```bash
python notebooks/scripts/export_dataset_manifest.py --dataset-name dataset_v001 --bbox-annotations /path/to/bboxes.csv
```

The bbox CSV must contain `image_path,xmin,ymin,xmax,ymax` with normalized coordinates. Bounding boxes are never inferred.

## Pipeline Overview

The runtime pipeline processes each camera frame as follows:

1. Check if the current tile was already reported.
2. Run `presence`.
3. If no object is present, discard the frame.
4. Run `object_type`.
5. If target, run `target_circle` localization, crop the **predicted** circle, then run `target_cls`.
6. If victim, run `victim_bbox` localization, crop the **predicted** bbox, then run `victim_cls`.

The registry-backed runtime is `notebooks.common.runtime_pipeline.run_perception_pipeline`
(or `build_perception_runtime` to load models once). It resolves every model via
`notebooks/common/model_registry.py` and **always crops with the predicted
bbox/circle** — the same crops the classifiers were trained on.

## Training Order

Train and regenerate in this order so every downstream stage consumes the latest
upstream model:

```text
1. Train presence classification.            (presence/classification.ipynb)
2. Train object_type classification.         (object_type/classification.ipynb)
3. Train victim localization.                (victim/localization.ipynb)
4. Train target ellipse localization.        (target/localization.ipynb)  [needs target_projection_labels.csv]
5. Train victim classification on predicted crops from the latest victim localization.
                                             (victim/classification.ipynb, crop_mode="predicted")
6. Train target/algorithm classification on predicted crops from the latest target ellipse.
                                             (target/classification.ipynb)  [needs target_classification.csv]
7. Run the pipeline notebook.                (pipeline/pipeline.ipynb)
```

### Predicted crops, not ground-truth crops

Classification **must not** train on ground-truth crops by default: at runtime the
crop comes from a *predicted* bbox/circle, so training on perfect GT crops creates a
train/runtime mismatch. The classification notebooks default to
`crop_mode="predicted"`. The legacy `crop_with_bbox=True` (mapped to
`crop_mode="ground_truth"`) and `crop_mode="none"` remain available for comparison.

Enable predicted crops in a classification `CONFIG`:

```python
"crop_mode": "predicted",
"crop_task_name": "victim_bbox",   # or "target_circle"
"crop_model_selection": "latest",  # "latest" | "best_metric" | "explicit"
"crop_padding": 0.05,
"regenerate_crops": False,
```

`run_classification_training` resolves the upstream localization model, generates a
`predicted_crops.csv` manifest (with `crop_path` + predicted coordinates) under the
run's `predicted_crops/` folder, trains on those crops, and records the localization
model and crop counts in `metrics.json` under `preprocessing`.

### Model registry & `latest.json`

`notebooks/common/model_registry.py` resolves the latest/best run for a task without
hardcoding paths. Set `"update_latest": True` in any training `CONFIG` to refresh the
curated pointer `models/<task>/latest.json` after a successful run (off by default;
pointers are never overwritten silently).

### Optuna

Every trainable notebook accepts `"use_optuna": True` (search → best params → final
train). Optuna trials honor the same `crop_mode` as the final run. If Optuna is not
installed, an `import optuna` error is raised with install instructions.

## ONNX Model Contracts

Classification models:

| Model | Input | Output | Labels |
| --- | --- | --- | --- |
| `presence.onnx` | `input` `[batch, 3, input_size, input_size]` | `logits` `[batch, 2]` | `none`, `object` |
| `object_type.onnx` | `input` `[batch, 3, input_size, input_size]` | `logits` `[batch, 2]` | `target`, `victim` |
| `victim_cls.onnx` | `input` `[batch, 3, input_size, input_size]` | `logits` `[batch, 3]` | `harmed`, `unharmed`, `stable` |
| `target_cls.onnx` | `input` `[batch, 3, input_size, input_size]` | `logits` `[batch, n]` | target/algorithm labels (manifest-defined) |

Localization models:

| Model | Input | Output |
| --- | --- | --- |
| `victim_bbox.onnx` | `input` `[batch, 3, input_size, input_size]` | `bbox` `[batch, 4]` normalized `[xmin, ymin, xmax, ymax]` |
| `target_ellipse.onnx` | `input` `[batch, 3, input_size, input_size]` | `ellipse` `[batch, 7]` `[cx, cy, radius_major, radius_minor, angle_sin, angle_cos, perspective_ratio]` |
| `target_circle.onnx` (legacy) | `input` `[batch, 3, input_size, input_size]` | `circle` `[batch, 3]` normalized `[center_x, center_y, radius]` |

Each export writes a sidecar metadata file next to the ONNX file, for example:

```text
models/presence/presence.onnx
models/presence/presence.metadata.json
```

## Dataset Manifests

Manifest root:

```text
notebooks/data/manifests/<dataset_name>/
```

Files:

- `presence.csv`: `none -> none`; `harmed`, `unharmed`, `stable`, `cognitive`, `obstacle -> object`.
- `object_type.csv`: `cognitive -> target`; `harmed`, `unharmed`, `stable -> victim`; excludes `none`, `obstacle`, and `fake`.
- `victim_classification.csv`: `harmed`, `unharmed`, `stable`; excludes `none`, `cognitive`, `obstacle`, and `fake`.
- `victim_bbox.csv`: only `harmed`, `unharmed`, `stable`; created only when bbox annotations exist.

CSV `image_path` values are relative to the split folder, such as:

```text
harmed/images/example.png
```

Training datasets resolve images as:

```python
dataset_root / row["split"] / row["image_path"]
```

## Target Branch

The **primary** target branch is trainable and predicts the projected **ellipse**
(perspective), mirroring the victim branch:

1. `target_ellipse` localization predicts a normalized 7-vector
   `[center_x, center_y, radius_major, radius_minor, angle_sin, angle_cos, perspective_ratio]`
   and exports `target_ellipse.onnx` (output `ellipse [N, 7]`).
2. The runtime crops the **predicted** ellipse (axis-aligned bbox of the ellipse).
3. `target_cls` classifies the predicted crop.

The legacy `target_circle` model (output `[cx, cy, r]`) is kept for comparison and as
a runtime fallback; the classical `target_cv` decoder is debug-only.

### Manifests

- `target_projection_labels.csv` (ellipse) — generated by the dataset supervisor and
  normalized into the manifests dir by
  `python -m notebooks.scripts.export_target_projection_manifest --dataset-name <name>`.
  Label source priority: `mask_*` columns (measured on the rendered mask) →
  `ellipse_*` projection → legacy circle. Pixel columns are normalized by
  `image_width`/`image_height`.
- `target_localization.csv` (legacy circle) — `export_target_localization.py`.
- `target_classification.csv` — `split,image_path,label,label_name` (the target
  algorithm/sequence label). **Does not exist yet**; until it does,
  `target/classification.ipynb` **skips cleanly** (no data is invented).

The ellipse 7-vector normalization:

```text
ellipse_cx_norm  = cx_px / image_width
ellipse_cy_norm  = cy_px / image_height
radius_major_norm = radius_major_px / image_width
radius_minor_norm = radius_minor_px / image_height
angle_sin, angle_cos = sin/cos(angle_rad)   # normalized to unit norm in post-processing
perspective_ratio = radius_minor_px / radius_major_px   (clamped to [0, 1])
```

### Pure ellipse helpers

`notebooks/common/crops.py` and `notebooks/common/target_cv.py` provide
`normalize_ellipse`, `ellipse_to_bbox`, `crop_image_with_ellipse`,
`crop_target_from_ellipse` and `warp_ellipse_to_circle` (fronto-parallel warp).

### Legacy classical-CV target decoder

The previous classical OpenCV approach is kept **for debug/comparison only**, not as
the main pipeline path. The reusable implementation is in
`notebooks/common/target_cv.py`:

- estimate center and radius;
- unwrap the circular target into a polar rectangle;
- split the unwrapped image into five bands;
- classify each band by dominant HSV color;
- return an ordered sequence using `K`, `R`, `Y`, `G`, `B`.

Debug panels are saved under:

```text
reports/target_cv/debug/
```

## Victim Branch

The victim branch uses two ONNX models:

1. `victim_bbox.onnx` predicts the normalized bbox.
2. The runtime crops the predicted victim region.
3. `victim_cls.onnx` classifies the crop as `harmed`, `unharmed`, or `stable`.

Fake victims are not part of this stage. Fake detection will be handled later using LiDAR data.

## Outputs

Model artifacts:

```text
models/presence/presence_best.pt
models/presence/presence.onnx
models/object_type/object_type_best.pt
models/object_type/object_type.onnx
models/victim/victim_bbox_best.pt
models/victim/victim_bbox.onnx
models/victim/victim_cls_best.pt
models/victim/victim_cls.onnx
```

Reports:

```text
reports/presence/
reports/object_type/
reports/victim_bbox/
reports/victim_cls/
reports/target_cv/
```

## Smoke Tests

Asset/manifest checks:

```bash
python notebooks/scripts/smoke_test_pipeline_assets.py --dataset-name dataset_v001
```

Localization + Optuna refactor (configs, losses, optimizers, schedulers, ONNX,
2-epoch bbox/circle training):

```bash
.venv/bin/python notebooks/scripts/smoke_localization_refactor.py
```

Full predicted-crop pipeline (registry, predicted crops, classification on predicted
crops, victim/target localization training, runtime pipeline on real frames, ONNX).
All artifacts go to timestamped run dirs that are removed afterwards, so real models
are never touched:

```bash
.venv/bin/python notebooks/scripts/smoke_full_pipeline.py
```

Target ellipse refactor (dataset/model/loss/metrics, 2-epoch ellipse training + ONNX
[N,7], predicted crops, runtime ellipse branch + circle fallback):

```bash
.venv/bin/python notebooks/scripts/smoke_target_ellipse.py
```

Each prints `N/N checks passed`.

## Development Rule

Notebooks should be thin execution layers. Reusable code belongs in `notebooks/common/`.

## Training Notebook Visualization

The executable training notebooks are notebook-first and follow the same shape:

1. **CONFIG**: edit dataset, hyperparameters, device and `output_mode` in the first code cell.
2. **Setup**: instantiate `ClassificationTrainConfig` or `BBoxTrainConfig`.
3. **Preflight**: validate paths, manifests, labels, image resolution and bbox contracts before training.
4. **Samples**: display class distribution and real dataset examples.
5. **Training**: call `run_classification_training(cfg)` or `run_bbox_training(cfg)`.
6. **Metrics**: show curves, confusion matrix for classifiers, bbox predictions for localization and final summaries.
7. **ONNX quick check**: validate exported input/output names and shapes.

Artifacts are controlled by `output_mode`:

- `overwrite`: writes final files under `models/<branch>/`.
- `timestamped`: writes files under `models/<branch>/runs/<timestamp>/`.
- `fail_if_exists`: aborts before training if the destination checkpoint, ONNX or `metrics.json` exists.

Each run writes `metrics.json` next to the produced model artifacts. Standard
visual report PNGs, when generated, are also saved in that same artifact folder.

Reusable visualization code lives in `notebooks/common/visualization.py`. Keep
notebook-specific plotting out of the individual notebooks unless it is an
exploratory debug view.
