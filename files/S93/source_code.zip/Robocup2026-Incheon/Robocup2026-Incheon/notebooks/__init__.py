"""Notebook support package for Robocup 2026 perception experiments."""

