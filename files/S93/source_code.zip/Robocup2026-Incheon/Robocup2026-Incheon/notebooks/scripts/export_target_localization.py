"""Generate target_localization.csv from the cognitive/target mask files.

Target (``cognitive``) images ship with two kinds of masks under
``<split>/cognitive/masks/``:

* **Full-target masks** (e.g. ``mask_target_<seq>_..._<frame>.png``): a WHITE
  background with the DARK target silhouette. These are used here -- the bbox is
  the tight box around the **dark** pixels.
* **Ring masks** (``..._ring<N>_...``): white rings on a dark background. These
  encode the per-band algorithm sequence and are **ignored** for localization.

This is **not** invented data: the circle is the tight bbox of the rendered
target silhouette, converted to a center+radius. Images without a usable full
mask are skipped and reported.

Run with:
    .venv/bin/python notebooks/scripts/export_target_localization.py --dataset-name imagens_larc
"""

from __future__ import annotations

import argparse
import csv
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common.config import get_dataset_root, get_manifest_root

SPLITS = ("train", "validation", "test")
FRAME_RE = re.compile(r"_(\d+)\.[A-Za-z]+$")
RING_RE = re.compile(r"_ring\d+_")
# Pixels darker than this (0=black, 255=white) are the target silhouette.
DARK_THRESHOLD = 128


def _frame_id(name: str) -> str | None:
    match = FRAME_RE.search(name)
    return match.group(1) if match else None


def _full_mask_index(mask_dir: Path) -> dict[str, Path]:
    """Index full-target (non-ring) masks by frame id."""

    index: dict[str, Path] = {}
    if not mask_dir.is_dir():
        return index
    for mask in mask_dir.glob("*.png"):
        if RING_RE.search(mask.name):
            continue  # skip ring masks
        fid = _frame_id(mask.name)
        if fid is not None:
            index.setdefault(fid, mask)
    return index


def _resolve_full_mask(image: Path, mask_dir: Path, by_frame: dict[str, Path]) -> Path | None:
    """Prefer the exact image->mask name; fall back to non-ring frame match."""

    exact = mask_dir / image.name.replace("image_", "mask_", 1)
    if exact.exists() and not RING_RE.search(exact.name):
        return exact
    fid = _frame_id(image.name)
    return by_frame.get(fid) if fid else None


def bbox_from_dark_mask(mask_path: Path) -> tuple[float, float, float, float] | None:
    """Tight normalized bbox around the DARK pixels of a white-background mask."""

    import numpy as np
    from PIL import Image

    with Image.open(mask_path) as mask:
        array = np.asarray(mask.convert("L"))
    foreground_y, foreground_x = np.nonzero(array < DARK_THRESHOLD)
    if foreground_x.size == 0 or foreground_y.size == 0:
        return None
    height, width = array.shape[:2]
    xmin = float(foreground_x.min()) / width
    ymin = float(foreground_y.min()) / height
    xmax = float(foreground_x.max() + 1) / width
    ymax = float(foreground_y.max() + 1) / height
    return (xmin, ymin, xmax, ymax)


def generate(dataset_name: str) -> Path:
    dataset_root = get_dataset_root(dataset_name)
    out_path = get_manifest_root(dataset_name) / "target_localization.csv"
    out_path.parent.mkdir(parents=True, exist_ok=True)

    rows: list[list] = []
    skipped: list[str] = []
    for split in SPLITS:
        image_dir = dataset_root / split / "cognitive" / "images"
        mask_dir = dataset_root / split / "cognitive" / "masks"
        by_frame = _full_mask_index(mask_dir)
        if not image_dir.is_dir():
            continue
        for image in sorted(image_dir.glob("*.png")):
            mask = _resolve_full_mask(image, mask_dir, by_frame)
            if mask is None:
                skipped.append(f"{split}/{image.name} (no full mask)")
                continue
            bbox = bbox_from_dark_mask(mask)
            if bbox is None:
                skipped.append(f"{split}/{image.name} (empty/all-white mask)")
                continue
            xmin, ymin, xmax, ymax = bbox
            cx = (xmin + xmax) / 2.0
            cy = (ymin + ymax) / 2.0
            radius = ((xmax - xmin) + (ymax - ymin)) / 4.0
            if radius <= 0:
                skipped.append(f"{split}/{image.name} (degenerate radius)")
                continue
            rel = f"cognitive/images/{image.name}"
            rows.append([split, rel, 0, "target", f"{cx:.6f}", f"{cy:.6f}", f"{radius:.6f}"])

    with out_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["split", "image_path", "label", "label_name", "center_x", "center_y", "radius"])
        writer.writerows(rows)

    print(f"wrote {out_path} ({len(rows)} rows)")
    by_split = {s: sum(r[0] == s for r in rows) for s in SPLITS}
    print("split counts:", by_split)
    if skipped:
        print(f"skipped {len(skipped)} images (no/empty mask). First few:")
        for item in skipped[:5]:
            print("  -", item)
    return out_path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="imagens_larc")
    args = parser.parse_args()
    generate(args.dataset_name)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
