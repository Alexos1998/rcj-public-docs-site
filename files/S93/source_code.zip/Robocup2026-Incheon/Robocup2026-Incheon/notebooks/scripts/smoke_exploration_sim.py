#!/usr/bin/env python3
"""Smoke test for the fast WBT exploration simulator."""

from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.exploration.commons import (
    compare_algorithms,
    compare_tile_center_explorers,
    resolve_world_path,
)
WORLDS = [
    ROOT / "controller/mapsdataset/runs/2026-06-23_15-01-09_169778/map_path.txt",
    Path("/home/isaac/Documents/erebus/game/worlds/Day1_1 - 2026 - fakes.wbt"),
    Path("/home/isaac/Documents/erebus/game/worlds/RS2025D2_4 - 2026 - fakes.wbt"),
]


def check(name: str, condition: bool) -> None:
    status = "OK" if condition else "FAIL"
    print(f"[{status}] {name}")
    if not condition:
        raise SystemExit(1)


def main() -> None:
    for source in WORLDS:
        world = resolve_world_path(source)
        table, runs = compare_algorithms(world)
        print(f"\n{world.name}")
        print(
            table[
                [
                    "run",
                    "total_time_s",
                    "moves",
                    "known_nodes",
                    "reachable_nodes",
                    "coverage",
                    "returned",
                ]
            ].to_string(index=False)
        )
        for run_name, result in runs.items():
            check(f"{world.name} {run_name} finished", result.finished)
            check(f"{world.name} {run_name} returned", result.returned_to_start)
            check(f"{world.name} {run_name} full coverage", abs(result.summary()["coverage"] - 1.0) < 1e-9)
            check(f"{world.name} {run_name} has reachable start", result.reachable_nodes >= 1)

        tile_table, tile_runs = compare_tile_center_explorers(world)
        print("\nTile-center explorers")
        print(
            tile_table[
                [
                    "run",
                    "total_time_s",
                    "moves",
                    "known_nodes",
                    "reachable_nodes",
                    "coverage",
                    "returned",
                ]
            ].to_string(index=False)
        )
        for run_name, result in tile_runs.items():
            check(f"{world.name} {run_name} finished", result.finished)
            check(f"{world.name} {run_name} returned", result.returned_to_start)
            check(f"{world.name} {run_name} full coverage", abs(result.summary()["coverage"] - 1.0) < 1e-9)

    new_passages, _ = compare_algorithms(WORLDS[0])
    legacy_time = float(
        new_passages.loc[new_passages["run"] == "legacy_window_006", "total_time_s"].iloc[0]
    )
    tile_time = float(
        new_passages.loc[new_passages["run"] == "tile_centers_012_dfs", "total_time_s"].iloc[0]
    )
    check("NewPassages tile centers are faster than 0.06 baseline", tile_time < legacy_time)


if __name__ == "__main__":
    main()
