"""End-to-end smoke tests for the predicted-crop perception pipeline.

Run with: .venv/bin/python notebooks/scripts/smoke_full_pipeline.py

Exercises the full refactor: model registry resolution, predicted-crop
generation, classification training on predicted crops, victim/target
localization training, the registry-backed runtime pipeline, and ONNX export.

All trained artifacts go to timestamped run dirs that are removed in a
``finally`` block, so existing real models in ``models/`` are never touched.
Prints ``N/N checks passed`` at the end.
"""

from __future__ import annotations

import csv
import shutil
import sys
import tempfile
from pathlib import Path

import numpy as np
import torch
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common import crops as crops_module
from notebooks.common import model_registry
from notebooks.common.config import get_dataset_root, get_manifest_root
from notebooks.common.models import (
    LegacyBBoxRegressor,
    LegacyCircleRegressor,
    LightweightClassifier,
)
from notebooks.common.onnx_export import export_onnx_model
from notebooks.common.optim import build_optimizer, build_scheduler, scheduler_step
from notebooks.common.preflight import run_pipeline_preflight
from notebooks.common.runtime_pipeline import (
    PerceptionPipelineConfig,
    build_perception_runtime,
)
from notebooks.common.train_config import (
    BBoxTrainConfig,
    CircleTrainConfig,
    ClassificationTrainConfig,
)
from notebooks.common.training_runs import (
    run_bbox_training,
    run_circle_training,
    run_classification_training,
)

DATASET = "imagens_larc"
PASSED: list[str] = []
CREATED_DIRS: list[Path] = []


def check(name: str, condition: bool) -> None:
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {name}")
    PASSED.append(name if condition else f"FAILED:{name}")
    if not condition:
        raise AssertionError(name)


def _short(**overrides) -> dict:
    base = {
        "dataset_name": DATASET,
        "epochs": 2,
        "input_size": 64,
        "batch_size": 32,
        "output_mode": "timestamped",
        "show_samples": False,
        "show_training_plots": False,
    }
    base.update(overrides)
    return base


# --------------------------------------------------------------------------- #
# 1-3: configs, optimizers, schedulers, model forward passes.
# --------------------------------------------------------------------------- #


def test_configs() -> None:
    cls = ClassificationTrainConfig.from_dict(
        {"dataset_name": DATASET, "crop_mode": "predicted", "crop_task_name": "victim_bbox"},
        task_name="victim_cls",
        labels=["harmed", "unharmed", "stable"],
        manifest_filename="victim_classification.csv",
        checkpoint_name="victim_cls_best.pt",
        onnx_name="victim_cls.onnx",
        model_dir_name="victim",
    )
    check("ClassificationTrainConfig predicted crop_mode", cls.crop_mode == "predicted")
    check("ClassificationTrainConfig registry fields", cls.model_selection == "latest" and cls.update_latest is False)
    legacy = ClassificationTrainConfig.from_dict(
        {"dataset_name": DATASET, "crop_with_bbox": True},
        task_name="victim_cls", labels=["a"], manifest_filename="m.csv",
        checkpoint_name="b.pt", onnx_name="b.onnx",
    )
    check("legacy crop_with_bbox -> ground_truth", legacy.crop_mode == "ground_truth")
    BBoxTrainConfig.from_dict({"dataset_name": DATASET})
    CircleTrainConfig.from_dict({"dataset_name": DATASET})
    check("bbox/circle configs build", True)


def test_optimizers_schedulers() -> None:
    model = LegacyBBoxRegressor(input_size=64)
    for name in ("adam", "adamw", "sgd"):
        opt = build_optimizer(model, BBoxTrainConfig.from_dict({"dataset_name": "x", "optimizer_name": name}))
        check(f"optimizer {name}", opt is not None)
    for name in ("none", "cosine", "plateau", "onecycle"):
        c = BBoxTrainConfig.from_dict({"dataset_name": "x", "scheduler_name": name, "epochs": 5})
        opt = build_optimizer(model, c)
        sch = build_scheduler(opt, c, steps_per_epoch=3)
        check(f"scheduler {name}", (sch is None) == (name == "none"))
        if sch is not None:
            opt.zero_grad(set_to_none=True)
            (sum(p.sum() for p in model.parameters())).backward()
            opt.step()
            scheduler_step(sch, c, metric=0.5)


def test_models_forward() -> None:
    x = torch.randn(2, 3, 64, 64)
    check("classifier forward", tuple(LightweightClassifier(num_classes=3, input_size=64)(x).shape) == (2, 3))
    check("bbox forward", tuple(LegacyBBoxRegressor(input_size=64)(x).shape) == (2, 4))
    check("circle forward", tuple(LegacyCircleRegressor(input_size=64)(x).shape) == (2, 3))


def test_onnx_export(tmp_dir: Path) -> None:
    path = tmp_dir / "cls.onnx"
    export_onnx_model(
        LightweightClassifier(num_classes=3, input_size=64), path, [1, 3, 64, 64],
        output_names=("logits",), labels=["a", "b", "c"],
    )
    check("onnx export", path.exists() and path.stat().st_size > 0)


# --------------------------------------------------------------------------- #
# 4: registry resolution + predicted crop generation.
# --------------------------------------------------------------------------- #


def test_registry() -> None:
    bundle = model_registry.resolve_model_bundle("victim_bbox", selection="latest")
    check("registry resolves victim_bbox onnx", bundle.onnx_path is not None and bundle.onnx_path.exists())
    check("registry reads best_metric", bundle.best_metric is not None)


def test_predicted_crops(tmp_dir: Path) -> dict:
    bundle = model_registry.resolve_model_bundle("victim_bbox", selection="latest")
    base = get_manifest_root(DATASET) / "victim_classification.csv"
    report = crops_module.generate_predicted_crop_manifest(
        base, bundle, tmp_dir / "crops_out", dataset_root=get_dataset_root(DATASET),
        padding=0.05, splits=["validation"],
    )
    check("predicted crops generated", report.num_crops > 0 and report.num_errors == 0)
    rows = crops_module.load_crop_manifest(report.manifest_path)
    check("crop manifest columns", set(crops_module.CROP_MANIFEST_COLUMNS) <= set(rows[0].keys()))
    check("crop files exist", (tmp_dir / "crops_out" / rows[0]["crop_path"]).exists())
    return {"bundle": bundle}


# --------------------------------------------------------------------------- #
# 5-6: classification training on predicted crops.
# --------------------------------------------------------------------------- #


def test_train_classification_predicted() -> Path:
    cfg = ClassificationTrainConfig.from_dict(
        _short(crop_mode="predicted", crop_task_name="victim_bbox", crop_padding=0.05),
        task_name="victim_cls",
        labels=["harmed", "unharmed", "stable"],
        manifest_filename="victim_classification.csv",
        checkpoint_name="victim_cls_best.pt",
        onnx_name="victim_cls.onnx",
        model_dir_name="victim",
    )
    CREATED_DIRS.append(cfg.artifact_dir)
    result = run_classification_training(cfg)
    check("victim_cls trained on predicted crops", result.status == "trained")
    pre = result.metrics["preprocessing"]
    check("metrics record predicted crop_mode", pre["crop_mode"] == "predicted")
    check("metrics record localization model", "localization_model" in pre and pre["num_crops"] > 0)
    check("victim_cls onnx validated", result.metrics["onnx_validation"].get("passed"))
    return cfg.artifact_dir


# --------------------------------------------------------------------------- #
# 7-8: localization training (bbox + circle).
# --------------------------------------------------------------------------- #


def test_train_bbox() -> None:
    cfg = BBoxTrainConfig.from_dict(_short(bbox_model_type="legacy_cnn", bbox_loss_name="combined"))
    CREATED_DIRS.append(cfg.artifact_dir)
    result = run_bbox_training(cfg)
    check("victim bbox trained", result.status == "trained")


def test_train_circle() -> None:
    if not (get_manifest_root(DATASET) / "target_localization.csv").exists():
        print("[skip] no target_localization.csv; skipping circle training")
        return
    cfg = CircleTrainConfig.from_dict(_short(circle_model_type="legacy_cnn"))
    CREATED_DIRS.append(cfg.artifact_dir)
    result = run_circle_training(cfg)
    check("target circle trained", result.status == "trained")


def _make_synthetic_target_manifest() -> Path | None:
    """Create a temporary target_localization.csv only if a real one is absent.

    Returns the path only when this function created it (so the caller deletes
    it). If a real target_localization.csv already exists, returns None and
    leaves it untouched.
    """

    out = get_manifest_root(DATASET) / "target_localization.csv"
    if out.exists():
        return None
    bbox_csv = get_manifest_root(DATASET) / "victim_bbox.csv"
    if not bbox_csv.exists():
        return None
    with bbox_csv.open() as handle:
        rows = list(csv.DictReader(handle))
    with out.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["split", "image_path", "label", "label_name", "center_x", "center_y", "radius"])
        for row in rows:
            xmin, ymin, xmax, ymax = (float(row[k]) for k in ("xmin", "ymin", "xmax", "ymax"))
            writer.writerow([
                row["split"], row["image_path"], 0, "target",
                (xmin + xmax) / 2, (ymin + ymax) / 2, ((xmax - xmin) + (ymax - ymin)) / 4,
            ])
    return out


# --------------------------------------------------------------------------- #
# 9: full runtime pipeline on real frames (using temp victim_cls model).
# --------------------------------------------------------------------------- #


def test_pipeline(victim_cls_dir: Path) -> None:
    specs = [
        {"task_name": "presence", "require_labels": True},
        {"task_name": "object_type", "require_labels": True},
        {"task_name": "victim_bbox"},
        {"task_name": "victim_cls", "selection": "explicit", "explicit_dir": str(victim_cls_dir), "require_labels": True},
    ]
    report = run_pipeline_preflight(specs)
    check("pipeline preflight ok", report.ok)

    cfg = PerceptionPipelineConfig(
        enable_target=False,
        victim_cls_selection="explicit",
        explicit_dirs={"victim_cls": str(victim_cls_dir)},
    )
    runtime = build_perception_runtime(cfg)
    root = get_dataset_root(DATASET)
    samples = {
        "victim": next((root / "test" / "harmed" / "images").glob("*.png")),
        "target": next((root / "test" / "cognitive" / "images").glob("*.png")),
        "none": next((root / "test" / "none" / "images").glob("*.png")),
    }
    results = {}
    for name, path in samples.items():
        arr = np.asarray(Image.open(path).convert("RGB"))
        results[name] = runtime.run(arr, tile_id=name)
    check("pipeline none -> no object", results["none"]["presence"] is False)
    check("pipeline victim -> victim branch", results["victim"]["object_type"] == "victim")
    check("victim crop + classification produced",
          results["victim"]["crop"] is not None and results["victim"]["classification"] in {"harmed", "unharmed", "stable"})
    check("pipeline target routed", results["target"]["object_type"] == "target")
    check("pipeline records timings", "presence" in results["victim"]["timings_ms"])


def main() -> int:
    tmp_dir = Path(tempfile.mkdtemp(prefix="smoke_full_"))
    synthetic_manifest: Path | None = None
    try:
        test_configs()
        test_optimizers_schedulers()
        test_models_forward()
        test_onnx_export(tmp_dir)
        test_registry()
        test_predicted_crops(tmp_dir)
        victim_cls_dir = test_train_classification_predicted()
        test_train_bbox()
        synthetic_manifest = _make_synthetic_target_manifest()
        test_train_circle()
        test_pipeline(victim_cls_dir)
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        for directory in CREATED_DIRS:
            shutil.rmtree(directory, ignore_errors=True)
        if synthetic_manifest is not None:
            synthetic_manifest.unlink(missing_ok=True)

    failures = [name for name in PASSED if name.startswith("FAILED:")]
    print(f"\n{len(PASSED) - len(failures)}/{len(PASSED)} checks passed")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
