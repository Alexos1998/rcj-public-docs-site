"""Smoke tests for the target ellipse/perspective localization refactor.

Run with: .venv/bin/python notebooks/scripts/smoke_target_ellipse.py

Exercises the ellipse dataset/model/loss/metrics, 2-epoch ellipse training +
ONNX [N,7] export, predicted-crop generation from the ellipse model, the runtime
post-processing helpers, the registry-backed runtime target branch (ellipse), and
the circle fallback. Trained artifacts go to timestamped run dirs that are removed
in a finally block. Prints ``N/N checks passed``.
"""

from __future__ import annotations

import shutil
import sys
import tempfile
from pathlib import Path

import numpy as np
import torch
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common import crops as crops_module
from notebooks.common import model_registry
from notebooks.common.config import get_dataset_root, get_manifest_root
from notebooks.common.datasets import ELLIPSE_OUTPUT_DIM, EllipseRegressionDataset
from notebooks.common.losses import EllipseLoss, build_ellipse_loss, ellipse_bbox_iou
from notebooks.common.metrics import ellipse_metrics
from notebooks.common.models import LegacyEllipseRegressor, LightweightEllipseRegressor, LightweightClassifier
from notebooks.common.onnx_export import export_onnx_model
from notebooks.common.runtime_pipeline import PerceptionPipelineConfig, build_perception_runtime
from notebooks.common.train_config import CircleTrainConfig, EllipseTrainConfig
from notebooks.common.training_runs import run_circle_training, run_ellipse_training

DATASET = "imagens_larc"
MANIFEST = "target_projection_labels.csv"
PASSED: list[str] = []
CREATED: list[Path] = []


def check(name: str, condition: bool) -> None:
    print(f"[{'PASS' if condition else 'FAIL'}] {name}")
    PASSED.append(name if condition else f"FAILED:{name}")
    if not condition:
        raise AssertionError(name)


def _short(**ov) -> dict:
    base = {
        "dataset_name": DATASET, "epochs": 2, "input_size": 64, "batch_size": 32,
        "output_mode": "timestamped", "show_samples": False, "show_training_plots": False,
    }
    base.update(ov)
    return base


def test_dataset_model_loss() -> None:
    m = get_manifest_root(DATASET) / MANIFEST
    ds = EllipseRegressionDataset(m, 64, split="train", dataset_root=get_dataset_root(DATASET))
    check("ellipse manifest present", m.exists() and len(ds) > 0)
    img, target = ds[0]
    check("ellipse dataset shapes", tuple(img.shape) == (3, 64, 64) and tuple(target.shape) == (ELLIPSE_OUTPUT_DIM,))
    x = torch.randn(4, 3, 64, 64)
    for M in (LegacyEllipseRegressor, LightweightEllipseRegressor):
        out = M(input_size=64)(x)
        check(f"{M.__name__} -> [N,7]", tuple(out.shape) == (4, 7))
    p = torch.tensor([[0.5, 0.5, 0.4, 0.3, 0.0, 1.0, 0.75]])
    t = torch.tensor([[0.52, 0.48, 0.42, 0.28, 0.1, 0.99, 0.67]])
    check("EllipseLoss scalar", EllipseLoss()(p, t).dim() == 0)
    cfg = EllipseTrainConfig.from_dict({"dataset_name": DATASET, "ellipse_loss_name": "combined"})
    check("build_ellipse_loss combined", build_ellipse_loss(cfg)(p, t).dim() == 0)
    check("ellipse_bbox_iou in [0,1]", 0.0 <= float(ellipse_bbox_iou(p, t)[0]) <= 1.0)
    metrics = ellipse_metrics(p.tolist(), t.tolist())
    check("ellipse_metrics keys", {"mean_center_error", "mean_angle_error_deg", "ellipse_bbox_iou"} <= set(metrics))


def test_onnx_export(tmp_dir: Path) -> None:
    path = tmp_dir / "ellipse.onnx"
    export_onnx_model(
        LegacyEllipseRegressor(input_size=64), path, [1, 3, 64, 64],
        output_names=("ellipse",), extra_metadata={"output_schema": ["cx", "cy"]},
    )
    check("ellipse onnx exported", path.exists() and path.stat().st_size > 0)


def test_train_ellipse() -> Path:
    cfg = EllipseTrainConfig.from_dict(_short(ellipse_model_type="legacy_cnn", ellipse_loss_name="combined"))
    CREATED.append(cfg.artifact_dir)
    result = run_ellipse_training(cfg)
    check("ellipse trained", result.status == "trained")
    ov = result.metrics["onnx_validation"]
    check("ellipse onnx [batch,7]", ov.get("output_names") == ["ellipse"] and ov.get("output_shape", [None, None])[1] == 7)
    check("ellipse metrics.json schema", result.metrics.get("output_schema") and len(result.metrics["output_schema"]) == 7)
    check("ellipse history iou", "val_ellipse_iou" in result.history)
    return cfg.artifact_dir


def test_predicted_crops(ellipse_dir: Path, tmp_dir: Path) -> None:
    bundle = model_registry.resolve_model_bundle("target_ellipse", selection="explicit", explicit_dir=str(ellipse_dir))
    report = crops_module.generate_predicted_crop_manifest(
        get_manifest_root(DATASET) / MANIFEST, bundle, tmp_dir / "ell_crops",
        dataset_root=get_dataset_root(DATASET), padding=0.05, splits=["validation"],
    )
    check("ellipse predicted crops", report.num_crops > 0 and report.num_errors == 0)
    check("ellipse crop IoU recorded", report.mean_iou is not None)
    rows = crops_module.load_crop_manifest(report.manifest_path)
    check("ellipse crop files exist", (tmp_dir / "ell_crops" / rows[0]["crop_path"]).exists())


def test_runtime_helpers() -> None:
    raw = [0.6, 0.4, 0.5, 0.9, 2.0, 0.0, 1.5]  # unnormalized, minor>major, ratio>1
    e = crops_module.normalize_ellipse(raw)
    check("normalize_ellipse major>=minor", e[2] >= e[3])
    check("normalize_ellipse ratio in [0,1]", 0.0 <= e[6] <= 1.0)
    check("normalize_ellipse unit angle", abs((e[4] ** 2 + e[5] ** 2) ** 0.5 - 1.0) < 1e-5)
    bbox = crops_module.ellipse_to_bbox(e)
    check("ellipse_to_bbox in [0,1]", all(0.0 <= v <= 1.0 for v in bbox) and bbox[2] > bbox[0] and bbox[3] > bbox[1])
    img = Image.fromarray((np.random.rand(80, 80, 3) * 255).astype("uint8"))
    crop = crops_module.crop_image_with_ellipse(img, e, padding=0.1)
    check("ellipse crop within image", 0 < crop.size[0] <= 80 and 0 < crop.size[1] <= 80)


def _make_dummy_target_cls(tmp_dir: Path) -> Path:
    """Export a tiny target_cls model + labels into an explicit run dir."""

    out = tmp_dir / "target_cls_run"
    out.mkdir(parents=True, exist_ok=True)
    export_onnx_model(
        LightweightClassifier(num_classes=2, input_size=64), out / "target_cls.onnx",
        [1, 3, 64, 64], output_names=("logits",), labels=["alpha", "beta"],
    )
    (out / "labels.json").write_text('["alpha", "beta"]')
    return out


def test_runtime_pipeline(ellipse_dir: Path, tmp_dir: Path) -> None:
    cls_dir = _make_dummy_target_cls(tmp_dir)
    cfg = PerceptionPipelineConfig(
        enable_victim=False, enable_target=True, prefer_target_radial=False,
        target_ellipse_selection="explicit", target_cls_selection="explicit",
        explicit_dirs={"target_ellipse": str(ellipse_dir), "target_cls": str(cls_dir)},
    )
    runtime = build_perception_runtime(cfg)
    check("runtime prefers ellipse", runtime.target_kind == "ellipse" and runtime.target_available)
    root = get_dataset_root(DATASET)
    target_img = next((root / "test" / "cognitive" / "images").glob("*.png"))
    res = runtime.run(np.asarray(Image.open(target_img).convert("RGB")), tile_id="t")
    check("runtime target routed", res["object_type"] == "target")
    if res["object_type"] == "target":
        loc = res["localization"]
        check("runtime ellipse localization", loc and loc["type"] == "ellipse" and "angle_deg" in loc)
        check("runtime target crop+class", res["crop"] is not None and res["classification"] in {"alpha", "beta"})


def test_circle_fallback(tmp_dir: Path) -> None:
    # Train a quick circle model (legacy center_x/center_y/radius columns exist).
    circle_cfg = CircleTrainConfig.from_dict(
        _short(circle_model_type="legacy_cnn"), manifest_filename=MANIFEST
    )
    CREATED.append(circle_cfg.artifact_dir)
    run_circle_training(circle_cfg)
    cls_dir = _make_dummy_target_cls(tmp_dir)
    cfg = PerceptionPipelineConfig(
        enable_victim=False, enable_target=True, prefer_target_ellipse=True,
        prefer_target_radial=False,
        target_ellipse_selection="explicit", explicit_dirs={
            "target_ellipse": str(tmp_dir / "does_not_exist"),
            "target_circle": str(circle_cfg.artifact_dir),
            "target_cls": str(cls_dir),
        },
        target_circle_selection="explicit", target_cls_selection="explicit",
    )
    runtime = build_perception_runtime(cfg)
    check("runtime falls back to circle", runtime.target_kind == "circle" and runtime.target_available)


def main() -> int:
    tmp_dir = Path(tempfile.mkdtemp(prefix="smoke_ellipse_"))
    try:
        test_dataset_model_loss()
        test_onnx_export(tmp_dir)
        ellipse_dir = test_train_ellipse()
        test_predicted_crops(ellipse_dir, tmp_dir)
        test_runtime_helpers()
        test_runtime_pipeline(ellipse_dir, tmp_dir)
        test_circle_fallback(tmp_dir)
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        for directory in CREATED:
            shutil.rmtree(directory, ignore_errors=True)
    failures = [n for n in PASSED if n.startswith("FAILED:")]
    print(f"\n{len(PASSED) - len(failures)}/{len(PASSED)} checks passed")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
