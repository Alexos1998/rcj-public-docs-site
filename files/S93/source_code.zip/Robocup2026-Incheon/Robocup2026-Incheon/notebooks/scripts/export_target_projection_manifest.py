"""Build target_projection_labels.csv (ellipse) manifest for target localization.

The dataset generator (``dataset_supervisor``) writes a geometric CSV
``target_projection_labels.csv`` next to the extracted dataset. This script
normalizes it into the project manifest convention
(``data/manifests/<dataset>/target_projection_labels.csv``):

* ``image_path`` is rewritten relative to its split folder (e.g.
  ``cognitive/images/foo.png``) and a ``split`` column is kept.
* ``label``/``label_name`` columns are added (single ``target`` class).
* ``image_width``/``image_height`` are recorded from the real PNG.
* Legacy ``center_x,center_y,radius`` (normalized, from the mask) are added so the
  same manifest also trains the legacy circle model.

The geometry columns (``mask_*`` measured on the 64x64 mask and the ``ellipse_*``
projection) are copied through. **No labels are invented**: if the source CSV is
missing, this fails with a clear error.

Run with:
    .venv/bin/python notebooks/scripts/export_target_projection_manifest.py --dataset-name imagens_larc
or:  python -m notebooks.scripts.export_target_projection_manifest --dataset-name imagens_larc
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common.config import get_dataset_root, get_manifest_root

SOURCE_NAME = "target_projection_labels.csv"
SPLITS = ("train", "validation", "test")

# Geometry columns copied straight through from the source CSV.
MASK_COLUMNS = (
    "mask_cx", "mask_cy", "mask_radius_major_px", "mask_radius_minor_px",
    "mask_angle_deg", "mask_perspective_ratio", "mask_visible_px",
)
ELLIPSE_COLUMNS = (
    "ellipse_cx", "ellipse_cy", "radius_major_px", "radius_minor_px",
    "ellipse_angle_deg", "perspective_ratio",
)

OUTPUT_COLUMNS = (
    "split", "image_path", "label", "label_name", "image_width", "image_height",
    "center_x", "center_y", "radius",
    *MASK_COLUMNS, *ELLIPSE_COLUMNS,
)


def _find_source(dataset_root: Path) -> Path | None:
    candidates = [
        dataset_root / SOURCE_NAME,
        dataset_root.parent / SOURCE_NAME,
        dataset_root / "labels" / SOURCE_NAME,
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def _split_relative(image_path: str, split: str) -> str:
    """Strip a leading ``<split>/`` prefix so paths follow project convention."""

    path = image_path.replace("\\", "/")
    prefix = f"{split}/"
    return path[len(prefix):] if path.startswith(prefix) else path


def _image_size(dataset_root: Path, split: str, rel_path: str) -> tuple[int, int]:
    from PIL import Image

    full = dataset_root / split / rel_path
    if not full.exists():
        full = dataset_root / rel_path
    with Image.open(full) as image:
        return image.size  # (width, height)


def generate(dataset_name: str) -> Path:
    dataset_root = get_dataset_root(dataset_name)
    source = _find_source(dataset_root)
    if source is None:
        raise FileNotFoundError(
            f"{SOURCE_NAME} not found for dataset '{dataset_name}'. Looked under "
            f"{dataset_root} and its parent. The geometric CSV is produced by the "
            "dataset generator; it is never invented here."
        )

    out_path = get_manifest_root(dataset_name) / SOURCE_NAME
    out_path.parent.mkdir(parents=True, exist_ok=True)

    src_rows = list(csv.DictReader(source.open(encoding="utf-8")))
    if not src_rows:
        raise ValueError(f"Source manifest is empty: {source}")

    out_rows: list[dict[str, object]] = []
    skipped: list[str] = []
    for row in src_rows:
        split = row.get("split", "")
        rel = _split_relative(row.get("image_path", ""), split)
        try:
            width, height = _image_size(dataset_root, split, rel)
        except FileNotFoundError:
            skipped.append(f"{split}/{rel} (image missing)")
            continue

        def _f(name: str) -> float | None:
            value = row.get(name, "")
            try:
                return float(value)
            except (TypeError, ValueError):
                return None

        # Legacy circle (normalized) derived from the mask ellipse.
        mask_cx, mask_cy = _f("mask_cx"), _f("mask_cy")
        mask_major, mask_minor = _f("mask_radius_major_px"), _f("mask_radius_minor_px")
        if None not in (mask_cx, mask_cy, mask_major) and mask_major > 0:
            center_x = max(0.0, min(1.0, mask_cx / width))
            center_y = max(0.0, min(1.0, mask_cy / height))
            radius = max(1e-4, mask_major / width)
        else:
            center_x = center_y = radius = ""

        out = {
            "split": split,
            "image_path": rel,
            "label": 0,
            "label_name": "target",
            "image_width": width,
            "image_height": height,
            "center_x": center_x if center_x == "" else f"{center_x:.6f}",
            "center_y": center_y if center_y == "" else f"{center_y:.6f}",
            "radius": radius if radius == "" else f"{radius:.6f}",
        }
        for name in (*MASK_COLUMNS, *ELLIPSE_COLUMNS):
            out[name] = row.get(name, "")
        out_rows.append(out)

    with out_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(OUTPUT_COLUMNS))
        writer.writeheader()
        writer.writerows(out_rows)

    print(f"wrote {out_path} ({len(out_rows)} rows)")
    print("split counts:", {s: sum(r["split"] == s for r in out_rows) for s in SPLITS})
    if skipped:
        print(f"skipped {len(skipped)} rows. First few:")
        for item in skipped[:5]:
            print("  -", item)
    return out_path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="imagens_larc")
    args = parser.parse_args()
    generate(args.dataset_name)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
