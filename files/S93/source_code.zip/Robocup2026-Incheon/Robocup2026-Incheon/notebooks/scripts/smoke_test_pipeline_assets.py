#!/usr/bin/env python3
"""Smoke-test local dataset/manifests/models for the perception notebooks."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from tempfile import TemporaryDirectory

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from notebooks.common.config import OBJECT_TYPE_CLASSES, PRESENCE_CLASSES, VICTIM_CLASSES, get_dataset_root, get_manifest_root
from notebooks.common.datasets import BBoxRegressionDataset, ImageClassificationDataset, read_csv_manifest
from notebooks.common.onnx_export import export_onnx_model
from notebooks.common.onnx_validate import compare_pytorch_onnx


CLASSIFICATION_MANIFESTS = {
    "presence": "presence.csv",
    "object_type": "object_type.csv",
    "victim_classification": "victim_classification.csv",
}

EXPECTED_PAIRS = {
    "presence": {(0, "none"), (1, "object")},
    "object_type": {(0, "target"), (1, "victim")},
    "victim_classification": {(0, "harmed"), (1, "unharmed"), (2, "stable")},
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def check_manifest(manifest_path: Path) -> list[dict[str, str]]:
    require(manifest_path.exists(), f"Missing manifest: {manifest_path}")
    rows = read_csv_manifest(manifest_path)
    require(len(rows) > 0, f"Manifest has no rows: {manifest_path}")
    return rows


def check_image_paths(dataset_root: Path, manifest_path: Path, rows: list[dict[str, str]]) -> None:
    missing = []
    for row in rows[:50]:
        image_path = dataset_root / row["split"] / row["image_path"]
        if not image_path.exists():
            missing.append(str(image_path))
    require(
        not missing,
        "Manifest image paths do not resolve. First missing paths:\n" + "\n".join(missing[:10]),
    )
    print(f"image paths ok: {manifest_path.name} ({min(len(rows), 50)} checked)")


def check_label_contract(key: str, rows: list[dict[str, str]]) -> None:
    pairs = {(int(row["label"]), row["label_name"]) for row in rows}
    unexpected = sorted(pairs.difference(EXPECTED_PAIRS[key]))
    require(not unexpected, f"{key} has unexpected label pairs: {unexpected}")
    print(f"label contract ok: {key} -> {sorted(pairs)}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", required=True, help="Dataset name under notebooks/data/extracted/.")
    parser.add_argument("--input-size", type=int, default=64)
    args = parser.parse_args()

    dataset_root = get_dataset_root(args.dataset_name)
    manifest_root = get_manifest_root(args.dataset_name)
    require(dataset_root.exists(), f"Missing extracted dataset root: {dataset_root}")
    require(manifest_root.exists(), f"Missing manifest root: {manifest_root}")
    print("dataset root:", dataset_root)
    print("manifest root:", manifest_root)

    manifest_rows = {}
    for key, filename in CLASSIFICATION_MANIFESTS.items():
        manifest_path = manifest_root / filename
        rows = check_manifest(manifest_path)
        check_image_paths(dataset_root, manifest_path, rows)
        check_label_contract(key, rows)
        manifest_rows[key] = rows

    presence_dataset = ImageClassificationDataset(
        manifest_root / "presence.csv",
        input_size=args.input_size,
        split="train",
        dataset_root=dataset_root,
    )
    require(len(presence_dataset) > 0, "Presence training dataset is empty.")
    image, label = presence_dataset[0]
    require(tuple(image.shape) == (3, args.input_size, args.input_size), f"Unexpected image tensor shape: {image.shape}")
    require(isinstance(int(label), int), f"Classification label is not integer-like: {label}")
    print("classification dataset ok:", tuple(image.shape), int(label))

    bbox_manifest = manifest_root / "victim_bbox.csv"
    if bbox_manifest.exists():
        rows = check_manifest(bbox_manifest)
        check_image_paths(dataset_root, bbox_manifest, rows)
        bbox_dataset = BBoxRegressionDataset(
            bbox_manifest,
            input_size=args.input_size,
            split="train",
            dataset_root=dataset_root,
        )
        require(len(bbox_dataset) > 0, "BBox training dataset is empty.")
        bbox_image, bbox = bbox_dataset[0]
        require(tuple(bbox_image.shape) == (3, args.input_size, args.input_size), f"Unexpected bbox image tensor shape: {bbox_image.shape}")
        require(tuple(bbox.shape) == (4,), f"Unexpected bbox tensor shape: {bbox.shape}")
        print("bbox dataset ok:", tuple(bbox_image.shape), bbox.tolist())
    else:
        print(
            "bbox dataset skipped: victim_bbox.csv is missing. "
            "Provide bbox annotations to export_dataset_manifest.py; boxes are not inferred."
        )

    try:
        import torch
    except ImportError as exc:
        raise RuntimeError("Install torch before running model/ONNX smoke tests.") from exc
    from notebooks.common.models import LightweightBBoxRegressor, LightweightClassifier

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("DEVICE:", device.type)
    if device.type == "cuda":
        print("GPU:", torch.cuda.get_device_name(0))
    else:
        print("WARNING: CUDA is not available; smoke test is using CPU.")

    x = torch.randn(1, 3, args.input_size, args.input_size, device=device)
    presence_model = LightweightClassifier(num_classes=len(PRESENCE_CLASSES), input_size=args.input_size).to(device)
    object_type_model = LightweightClassifier(num_classes=len(OBJECT_TYPE_CLASSES), input_size=args.input_size).to(device)
    victim_cls_model = LightweightClassifier(num_classes=len(VICTIM_CLASSES), input_size=args.input_size).to(device)
    bbox_model = LightweightBBoxRegressor(input_size=args.input_size).to(device)
    presence_out = presence_model(x)
    object_type_out = object_type_model(x)
    victim_cls_out = victim_cls_model(x)
    bbox_out = bbox_model(x)
    require(tuple(presence_out.shape) == (1, 2), f"Unexpected presence output shape: {presence_out.shape}")
    require(tuple(object_type_out.shape) == (1, 2), f"Unexpected object_type output shape: {object_type_out.shape}")
    require(tuple(victim_cls_out.shape) == (1, 3), f"Unexpected victim_cls output shape: {victim_cls_out.shape}")
    require(tuple(bbox_out.shape) == (1, 4), f"Unexpected bbox output shape: {bbox_out.shape}")
    print("model forward ok:", tuple(presence_out.shape), tuple(object_type_out.shape), tuple(victim_cls_out.shape), tuple(bbox_out.shape))

    with TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        export_onnx_model(
            presence_model.cpu(),
            tmp_path / "smoke_presence.onnx",
            input_shape=[1, 3, args.input_size, args.input_size],
            input_names=("input",),
            output_names=("logits",),
            labels=["none", "object"],
            model_name="smoke_presence",
        )
        compare_pytorch_onnx(presence_model.cpu(), tmp_path / "smoke_presence.onnx", [1, 3, args.input_size, args.input_size])
        export_onnx_model(
            bbox_model.cpu(),
            tmp_path / "smoke_victim_bbox.onnx",
            input_shape=[1, 3, args.input_size, args.input_size],
            input_names=("input",),
            output_names=("bbox",),
            model_name="smoke_victim_bbox",
        )
        compare_pytorch_onnx(bbox_model.cpu(), tmp_path / "smoke_victim_bbox.onnx", [1, 3, args.input_size, args.input_size])
    print("ONNX export/runtime comparison ok")


if __name__ == "__main__":
    try:
        main()
    except RuntimeError as exc:
        raise SystemExit(str(exc)) from exc
