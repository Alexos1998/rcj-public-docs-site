"""Smoke test for the mask-first radial CognitiveTarget pipeline.

Path-independent (resolves the project root from this file) end-to-end check:

* manifest builder ignores ring masks and emits the radial columns;
* geometry (center via circle fit, radial contour R(theta));
* Random Forest segmenter trains and reaches a high IoU;
* radial classifier runs with GT mask and predicted mask;
* MiniTargetMaskNet fallback trains + exports ONNX (same interface as RF);
* runtime decoder + full PerceptionRuntime take the radial target path.

Run with:
    .venv/bin/python notebooks/scripts/smoke_target_mask_radial.py
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common import metrics
from notebooks.common.config import get_dataset_root, get_manifest_root
from notebooks.common.target_classification_radial import (
    classify_pixel_color,
    decode_target_from_mask,
)
from notebooks.common.target_geometry import (
    build_target_mask_manifest,
    clean_largest_component,
    estimate_target_center,
    extract_radial_contour,
    is_ring_mask,
    load_target_binary_mask,
    texture_from_name,
)
from notebooks.common.target_mask_pipeline import (
    evaluate_radial,
    evaluate_segmenter,
    load_records,
    train_rf_segmenter,
)
from notebooks.common.target_mask_rf import TargetMaskRFConfig

DATASET = "imagens_larc"
PASSED = 0
FAILED = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global PASSED, FAILED
    if condition:
        PASSED += 1
        print(f"[PASS] {name}")
    else:
        FAILED += 1
        print(f"[FAIL] {name} {detail}")


def test_color_classifier() -> None:
    check("color K (black)", classify_pixel_color((5, 5, 5)) == "K")
    check("color R", classify_pixel_color((200, 10, 10)) == "R")
    check("color Y", classify_pixel_color((200, 200, 10)) == "Y")
    check("color G", classify_pixel_color((10, 200, 10)) == "G")
    check("color B", classify_pixel_color((10, 10, 200)) == "B")


def test_ring_filter_and_texture() -> None:
    check("ring mask detected", is_ring_mask("mask_target_brrrg_v0_p0_brrrg_ring2_00001.png"))
    check("whole mask not flagged", not is_ring_mask("mask_target_brrrg_v0_p0_brrrg_00001.png"))
    check("texture parse", texture_from_name("image_target_brrrg_victim0_p0000_brrrg_00001.png") == "BRRRG")


def test_manifest(tmp_dir: Path) -> None:
    out = tmp_dir / "target_mask_manifest.csv"
    build_target_mask_manifest(get_dataset_root(DATASET), out, n_rays=64)
    import csv

    rows = list(csv.DictReader(out.open()))
    check("manifest rows == 320", len(rows) == 320, f"got {len(rows)}")
    header = rows[0].keys()
    check("manifest has radial cols", "ray_r_000" in header and "ray_valid_063" in header)
    check("manifest center cols", {"center_x", "center_y", "center_x_norm", "clipped"} <= set(header))
    # No ring mask ever referenced as the whole-target mask.
    check("no ring masks referenced", all(not is_ring_mask(r["target_mask_path"]) for r in rows))
    check("textures length 5", all(len(r["texture"]) == 5 for r in rows))


def test_geometry() -> None:
    records = load_records(DATASET, "test")
    rec = next(r for r in records if not r.clipped)
    binary = clean_largest_component(rec.gt_mask)
    cx, cy = estimate_target_center(binary)
    h, w = binary.shape
    check("center inside frame", 0 <= cx < w and 0 <= cy < h)
    rays, valid = extract_radial_contour(binary, (cx, cy), n_rays=64)
    check("rays length 64", rays.shape == (64,) and valid.shape == (64,))
    check("non-clipped fully covered", valid.mean() > 0.9, f"coverage={valid.mean():.2f}")


def test_segmenter_and_radial() -> None:
    cfg = TargetMaskRFConfig(n_estimators=80, pixels_per_class=400)
    segmenter = train_rf_segmenter(DATASET, cfg)
    test_records = load_records(DATASET, "test")
    seg = evaluate_segmenter(segmenter, test_records)
    check("RF mask IoU >= 0.95", seg["mask_iou"] >= 0.95, f"IoU={seg['mask_iou']:.4f}")

    gt = evaluate_radial(test_records, mask_source="gt")
    rf = evaluate_radial(test_records, segmenter, mask_source="rf")
    check("GT-mask radial exact > 0.7", gt["texture_exact_accuracy"] > 0.7,
          f"acc={gt['texture_exact_accuracy']:.3f}")
    check("RF-mask radial close to GT", abs(gt["texture_exact_accuracy"] - rf["texture_exact_accuracy"]) < 0.15,
          f"gt={gt['texture_exact_accuracy']:.3f} rf={rf['texture_exact_accuracy']:.3f}")
    check("clipped radial accuracy high", (rf["accuracy_on_clipped"] or 0) > 0.85,
          f"clip_acc={rf['accuracy_on_clipped']}")
    check("unknown rate low", rf["unknown_rate"] < 0.1, f"unk={rf['unknown_rate']:.3f}")
    return segmenter


def test_cnn_fallback() -> None:
    from notebooks.common.target_mask_cnn import TargetMaskCNN, TargetMaskCNNConfig

    records = load_records(DATASET, "train")[:60]
    cnn = TargetMaskCNN(TargetMaskCNNConfig(epochs=8)).fit(
        [r.image for r in records], [r.gt_mask for r in records]
    )
    val = load_records(DATASET, "validation")[:10]
    iou = np.mean([metrics.mask_iou(cnn.predict_mask(r.image), r.gt_mask) for r in val])
    check("CNN trains + predicts", iou > 0.6, f"IoU={iou:.3f}")
    with tempfile.TemporaryDirectory() as td:
        onnx = cnn.export_onnx(Path(td) / "mini.onnx")
        check("CNN ONNX exported", onnx.exists())


def test_runtime(segmenter) -> None:
    from notebooks.common.runtime_pipeline import TargetMaskRadialDecoder

    records = load_records(DATASET, "test")[:5]
    decoder = TargetMaskRadialDecoder(segmenter)
    spec_keys = {
        "target_present", "center", "rays", "ray_valid", "mask_confidence",
        "predicted_texture", "ring_confidence", "radial_coverage",
    }
    out = decoder.decode(records[0].image)
    check("runtime decoder spec keys", spec_keys <= set(out), f"missing={spec_keys - set(out)}")
    check("runtime decoder present", out["target_present"] is True)
    check("runtime decoder texture len 5", len(out["predicted_texture"]) == 5)


def main() -> int:
    test_color_classifier()
    test_ring_filter_and_texture()
    with tempfile.TemporaryDirectory() as td:
        test_manifest(Path(td))
    test_geometry()
    segmenter = test_segmenter_and_radial()
    test_cnn_fallback()
    test_runtime(segmenter)
    print(f"\n{PASSED}/{PASSED + FAILED} checks passed")
    return 1 if FAILED else 0


if __name__ == "__main__":
    raise SystemExit(main())
