#!/usr/bin/env python3
"""Extract a local dataset archive into notebooks/data/extracted/<dataset_name>."""

from __future__ import annotations

import argparse
import shutil
import sys
import tarfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from notebooks.common.config import DATA_TARS_DIR, get_dataset_root


ARCHIVE_SUFFIXES = (".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2", ".tar.xz", ".txz")
SPLITS = ("train", "validation", "test")


def find_archive(dataset_name: str) -> Path:
    candidates = [DATA_TARS_DIR / f"{dataset_name}{suffix}" for suffix in ARCHIVE_SUFFIXES]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise FileNotFoundError(
        f"No archive found for {dataset_name!r} in {DATA_TARS_DIR}. "
        f"Expected one of: {', '.join(path.name for path in candidates)}"
    )


def safe_extract(archive_path: Path, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    output_root = output_dir.resolve()
    with tarfile.open(archive_path) as archive:
        for member in archive.getmembers():
            target = (output_dir / member.name).resolve()
            if output_root not in (target, *target.parents):
                raise RuntimeError(f"Unsafe archive member path: {member.name}")
        archive.extractall(output_dir)


def infer_dataset_name(archive_path: Path) -> str:
    """Infer a dataset name by removing a supported tar suffix."""

    name = archive_path.name
    for suffix in ARCHIVE_SUFFIXES:
        if name.endswith(suffix):
            return name[: -len(suffix)]
    return archive_path.stem


def normalize_dataset_root(output_dir: Path) -> None:
    """Flatten archives that contain one extra top-level dataset directory."""

    if any((output_dir / split).is_dir() for split in SPLITS):
        return

    nested_dirs = [path for path in output_dir.iterdir() if path.is_dir()]
    if len(nested_dirs) != 1:
        return

    nested_root = nested_dirs[0]
    if not any((nested_root / split).is_dir() for split in SPLITS):
        return

    for child in nested_root.iterdir():
        destination = output_dir / child.name
        if destination.exists():
            raise RuntimeError(f"Cannot normalize dataset root; destination already exists: {destination}")
        shutil.move(str(child), destination)
    nested_root.rmdir()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default=None, help="Dataset name under notebooks/data/extracted/.")
    parser.add_argument("--archive", "--tar", dest="archive", type=Path, default=None, help="Optional explicit archive path.")
    parser.add_argument("--out", type=Path, default=None, help="Optional explicit output directory.")
    parser.add_argument("--force", "--overwrite", dest="force", action="store_true", help="Remove an existing extracted dataset first.")
    args = parser.parse_args()

    if args.dataset_name is None and args.archive is None:
        raise SystemExit("Provide --dataset-name or --archive/--tar.")

    archive_path = (args.archive or find_archive(args.dataset_name)).resolve()
    dataset_name = args.dataset_name or (args.out.name if args.out else infer_dataset_name(archive_path))
    output_dir = (args.out or get_dataset_root(dataset_name)).resolve()

    if output_dir.exists() and any(output_dir.iterdir()):
        if not args.force:
            raise SystemExit(f"Extracted dataset already exists: {output_dir}. Use --force to replace it.")
        shutil.rmtree(output_dir)

    safe_extract(archive_path, output_dir)
    normalize_dataset_root(output_dir)
    print(f"Extracted {archive_path} to {output_dir}")


if __name__ == "__main__":
    main()
