"""Smoke test for the map (occupancy-grid) subtile RF training pipeline.

Run with: .venv/bin/python notebooks/scripts/smoke_map_training.py

Exercises the full path: load real runs from controller/mapsdataset/runs,
parse the real_matrix into per-subtile labels, build the 4 specialist datasets
(parede/curva/obstaculo/explorado), train short RandomForests with
leave-one-run-out CV, and write metrics.json to temp model dirs (real models in
models/ are never touched). Falls back to a synthetic run if no data exists.

Prints ``N/N checks passed`` at the end.
"""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common import map_dataset as md

LABEL_SOURCE = "auto"


def _synthetic_run() -> dict:
    """A tiny 2x2-tile run with a known wall layout, for when no data exists."""
    # 9x9 matrix = 2x2 tiles. Border walls + a start tile at top-left.
    rows = [
        "111111111",
        "151000000",
        "101000000",
        "151000000",
        "100000001",
        "100000001",
        "100000001",
        "100000001",
        "111111111",
    ]
    text = "\n".join(rows)
    grid = np.full((80, 80), 0, dtype=np.int8)   # all free
    grid[:3, :] = 100                            # a wall band
    meta = {"map": {"resolution": md.DEFAULT_RES, "origin": {"x": 0.0, "y": 0.0}}}
    return {"run_id": "synthetic", "run_dir": Path("."), "grid": grid,
            "meta": meta, "submission": text, "real": text}


def main() -> int:
    checks: list[tuple[str, bool]] = []

    def check(name: str, cond: bool) -> None:
        checks.append((name, bool(cond)))
        print(f"[{'OK' if cond else 'FAIL'}] {name}")

    runs = md.list_runs()
    if runs:
        samples = md.load_all_subtiles(label_source=LABEL_SOURCE)
        tiles = md.load_all_tiles(label_source=LABEL_SOURCE)
        source = f"{len(runs)} real run(s)"
    else:
        syn = _synthetic_run()
        samples = md.build_run_subtiles(syn, label_source=LABEL_SOURCE)
        tiles = md.build_run_tiles(syn, label_source=LABEL_SOURCE)
        source = "synthetic run (no real data found)"
    print(f"[INFO] source: {source}; {len(samples)} subtiles, {len(tiles)} tiles")

    check("subtile samples non-empty", len(samples) > 0)
    check("tile samples non-empty", len(tiles) > 0)
    check("area-4 subtiles excluded", all(not s.real.is_area4 for s in samples))
    check("patch is square 2D", samples[0].patch.ndim == 2 and
          samples[0].patch.shape[0] == samples[0].patch.shape[1])

    cfg = md.MapRFConfig(n_estimators=40, max_depth=8)
    # Obstacle is a TILE-level model (full-tile crop); the rest are per-subtile.
    units = {"parede": samples, "curva": samples, "explorado": samples, "obstaculo": tiles}

    with tempfile.TemporaryDirectory() as tmp:
        import notebooks.common.config as cfgmod
        orig_models = cfgmod.MODELS_DIR
        cfgmod.MODELS_DIR = Path(tmp)  # redirect saves away from real models/
        try:
            for name, builder in md.BUILDERS.items():
                ds = builder(units[name])
                check(f"{name}: dataset built (X={ds.X.shape})", len(ds) > 0)
                check(f"{name}: feature width == {len(ds.feature_names)} (masked)",
                      ds.X.shape[1] == len(ds.feature_names))
                result = md.train_rf(ds, cfg)
                check(f"{name}: model fitted", hasattr(result["model"], "predict"))
                paths = md.save_model(result, f"map/{name}")
                metrics = json.loads(paths["metrics"].read_text())
                check(f"{name}: metrics.json written", "task" in metrics)

            # Full gated pipeline (subtiles + tiles) end-to-end + overlap resolution.
            pipe = md.MapPipeline.from_training(samples, tiles, cfg)
            sp = pipe.predict_subtiles(samples[:8])
            tp = pipe.predict_tiles(tiles[:8])
            check("pipeline predict_subtiles", len(sp) == len(samples[:8]))
            check("pipeline predict_tiles", len(tp) == len(tiles[:8]))
            md.resolve_overlaps(samples[:8], sp, tiles[:8], tp)
            check("overlap resolution: no curve+own-edge wall",
                  all(not (p["curve"] and any(p["walls"][d]
                      for d in md.CURVE_EDGES.get(p["curve"], ()))) for p in sp))
        finally:
            cfgmod.MODELS_DIR = orig_models

    passed = sum(1 for _, ok in checks if ok)
    print(f"\n{passed}/{len(checks)} checks passed")
    return 0 if passed == len(checks) else 1


if __name__ == "__main__":
    raise SystemExit(main())
