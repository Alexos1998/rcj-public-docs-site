"""Evaluate lightweight target mask strategies with target/none/victim rows."""

from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from notebooks.common.config import get_dataset_root, get_manifest_root, get_model_dir
from notebooks.common.metrics import boundary_iou, mask_metrics
from notebooks.common.target_geometry import clean_largest_component, load_target_binary_mask, mask_bbox
from notebooks.common.target_mask_rf import TargetMaskRFConfig, TargetMaskRandomForest

SPLITS = ("train", "validation", "test")


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def load_rgb(path: Path) -> np.ndarray:
    return np.asarray(Image.open(path).convert("RGB"))


def resolve_image(dataset_root: Path, row: dict[str, str]) -> Path:
    return dataset_root / row["split"] / row["image_path"]


def bbox_iou(a: tuple[int, int, int, int] | None, b: tuple[int, int, int, int] | None) -> float:
    if a is None and b is None:
        return 1.0
    if a is None or b is None:
        return 0.0
    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b
    ix0, iy0 = max(ax0, bx0), max(ay0, by0)
    ix1, iy1 = min(ax1, bx1), min(ay1, by1)
    inter = max(0, ix1 - ix0) * max(0, iy1 - iy0)
    area_a = max(0, ax1 - ax0) * max(0, ay1 - ay0)
    area_b = max(0, bx1 - bx0) * max(0, by1 - by0)
    union = area_a + area_b - inter
    return float(inter / union) if union else 0.0


def metrics(pred: np.ndarray, target: np.ndarray) -> dict[str, float]:
    out = mask_metrics(pred.astype(bool), target.astype(bool))
    out["boundary_iou"] = boundary_iou(pred.astype(bool), target.astype(bool))
    out["mask_bbox_iou"] = bbox_iou(mask_bbox(pred), mask_bbox(target))
    out["pred_area"] = float(pred.sum())
    out["target_area"] = float(target.sum())
    out["has_prediction"] = float(mask_bbox(pred) is not None)
    return out


def aggregate(rows: list[dict[str, float]]) -> dict[str, float]:
    if not rows:
        return {}
    return {key: float(np.mean([row[key] for row in rows])) for key in rows[0]}


def postprocess(mask: np.ndarray, min_area: int) -> np.ndarray:
    if mask.any():
        mask = clean_largest_component(mask)
    if mask.sum() < min_area:
        return np.zeros_like(mask, dtype=bool)
    return mask.astype(bool)


def grabcut(image: np.ndarray, rect: tuple[int, int, int, int], min_area: int, iterations: int = 2) -> np.ndarray:
    import cv2

    x0, y0, x1, y1 = rect
    rect_cv = (x0, y0, max(1, x1 - x0), max(1, y1 - y0))
    gc_mask = np.zeros(image.shape[:2], dtype=np.uint8)
    bgd = np.zeros((1, 65), np.float64)
    fgd = np.zeros((1, 65), np.float64)
    try:
        cv2.grabCut(image, gc_mask, rect_cv, bgd, fgd, iterations, cv2.GC_INIT_WITH_RECT)
    except cv2.error:
        return np.zeros(image.shape[:2], dtype=bool)
    pred = (gc_mask == cv2.GC_FGD) | (gc_mask == cv2.GC_PR_FGD)
    return postprocess(pred, min_area)


def load_records(dataset_root: Path, target_manifest: Path, negative_manifest: Path):
    positives = read_csv(target_manifest)
    negative_keys = {(row["split"], row["image_path"]): row for row in read_csv(negative_manifest)
                     if row.get("label_name") == "none"}
    records: dict[str, list[tuple[dict[str, str], np.ndarray, np.ndarray, bool]]] = {s: [] for s in SPLITS}
    for row in positives:
        image = load_rgb(resolve_image(dataset_root, row))
        mask = load_target_binary_mask(dataset_root / row["split"] / row["target_mask_path"])
        records.setdefault(row["split"], []).append((row, image, mask, True))
    for row in negative_keys.values():
        image = load_rgb(resolve_image(dataset_root, row))
        mask = np.zeros(image.shape[:2], dtype=bool)
        records.setdefault(row["split"], []).append((row, image, mask, False))
    return records


def save_debug(path: Path, image: np.ndarray, target: np.ndarray, pred: np.ndarray, title: str) -> None:
    base = Image.fromarray(image)
    overlay = base.convert("RGBA")
    layer = Image.new("RGBA", base.size, (0, 0, 0, 0))
    pixels = layer.load()
    for y, x in np.argwhere(target):
        pixels[int(x), int(y)] = (0, 220, 0, 100)
    for y, x in np.argwhere(pred):
        old = pixels[int(x), int(y)]
        pixels[int(x), int(y)] = (220, 0, 0, 120) if old[3] == 0 else (230, 200, 0, 150)
    overlay.alpha_composite(layer)
    ImageDraw.Draw(overlay).text((2, 2), title, fill=(255, 255, 255, 255))
    path.parent.mkdir(parents=True, exist_ok=True)
    overlay.convert("RGB").save(path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-name", default="imagens_larc")
    parser.add_argument("--target-manifest", default="target_mask_manifest.csv")
    parser.add_argument("--negative-manifest", default="target_localization_with_none.csv")
    parser.add_argument("--threshold", type=float, default=0.8)
    parser.add_argument("--min-area", type=int, default=50)
    parser.add_argument("--pixels-per-class", type=int, default=450)
    parser.add_argument("--n-estimators", type=int, default=160)
    parser.add_argument("--max-depth", type=int, default=18)
    parser.add_argument("--debug-examples", type=int, default=12)
    args = parser.parse_args()

    dataset_root = get_dataset_root(args.dataset_name)
    manifest_root = get_manifest_root(args.dataset_name)
    records = load_records(dataset_root, manifest_root / args.target_manifest, manifest_root / args.negative_manifest)

    cfg = TargetMaskRFConfig(
        model_type="extra_trees",
        n_estimators=args.n_estimators,
        max_depth=args.max_depth,
        min_samples_leaf=1,
        pixels_per_class=args.pixels_per_class,
        proba_threshold=args.threshold,
        postprocess=True,
        random_state=42,
    )
    train_images = [image for _, image, _, _ in records["train"]]
    train_masks = [mask for _, _, mask, _ in records["train"]]
    start = time.perf_counter()
    rf = TargetMaskRandomForest(cfg).fit(train_images, train_masks)
    fit_s = time.perf_counter() - start

    out_dir = get_model_dir("target_mask_eval")
    out_dir.mkdir(parents=True, exist_ok=True)
    model_path = rf.save(out_dir / "target_full_mask_rf_with_negatives.joblib")

    summary = {}
    rows_out = []
    worst_rf = []
    for split, split_records in records.items():
        buckets = {
            "rf_pos": [], "rf_neg": [],
            "grabcut_full_pos": [], "grabcut_full_neg": [],
            "grabcut_gt_bbox_pos": [],
        }
        for row, image, target, is_positive in split_records:
            h, w = image.shape[:2]
            rf_pred = postprocess(rf.predict_mask(image), args.min_area)
            full_rect = (1, 1, w - 1, h - 1)
            gc_full = grabcut(image, full_rect, args.min_area)
            gt_bbox = mask_bbox(target)
            gc_gt = grabcut(image, gt_bbox, args.min_area) if gt_bbox is not None else np.zeros((h, w), dtype=bool)

            rf_m = metrics(rf_pred, target)
            gc_full_m = metrics(gc_full, target)
            gc_gt_m = metrics(gc_gt, target)
            key_suffix = "pos" if is_positive else "neg"
            buckets[f"rf_{key_suffix}"].append(rf_m)
            buckets[f"grabcut_full_{key_suffix}"].append(gc_full_m)
            if is_positive:
                buckets["grabcut_gt_bbox_pos"].append(gc_gt_m)
                worst_rf.append((rf_m["mask_bbox_iou"], row["image_path"], image, target, rf_pred))
            rows_out.append({
                "split": split,
                "image_path": row["image_path"],
                "is_positive": int(is_positive),
                "rf_iou": rf_m["iou"],
                "rf_bbox_iou": rf_m["mask_bbox_iou"],
                "rf_has_prediction": rf_m["has_prediction"],
                "grabcut_full_iou": gc_full_m["iou"],
                "grabcut_full_bbox_iou": gc_full_m["mask_bbox_iou"],
                "grabcut_full_has_prediction": gc_full_m["has_prediction"],
                "grabcut_gt_bbox_iou": gc_gt_m["iou"],
                "grabcut_gt_bbox_bbox_iou": gc_gt_m["mask_bbox_iou"],
            })

        def agg(name: str, metric: str, default=0.0):
            return aggregate(buckets[name]).get(metric, default)

        summary[split] = {
            "count": float(len(split_records)),
            "positive_count": float(sum(1 for *_, pos in split_records if pos)),
            "negative_count": float(sum(1 for *_, pos in split_records if not pos)),
            "rf_iou_positive": agg("rf_pos", "iou"),
            "rf_bbox_iou_positive": agg("rf_pos", "mask_bbox_iou"),
            "rf_negative_false_positive_rate": agg("rf_neg", "has_prediction"),
            "grabcut_full_iou_positive": agg("grabcut_full_pos", "iou"),
            "grabcut_full_bbox_iou_positive": agg("grabcut_full_pos", "mask_bbox_iou"),
            "grabcut_full_negative_false_positive_rate": agg("grabcut_full_neg", "has_prediction"),
            "grabcut_gt_bbox_iou_positive": agg("grabcut_gt_bbox_pos", "iou"),
            "grabcut_gt_bbox_bbox_iou_positive": agg("grabcut_gt_bbox_pos", "mask_bbox_iou"),
        }

    examples_path = out_dir / "target_mask_variant_examples.csv"
    with examples_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows_out[0]))
        writer.writeheader()
        writer.writerows(rows_out)

    for idx, (score, image_path, image, target, pred) in enumerate(sorted(worst_rf, key=lambda x: x[0])[:args.debug_examples]):
        save_debug(out_dir / "debug_rf" / f"worst_{idx:02d}.png", image, target, pred,
                   f"bboxIoU={score:.3f} {Path(image_path).name}")

    payload = {
        "dataset_name": args.dataset_name,
        "target_manifest": str(manifest_root / args.target_manifest),
        "negative_manifest": str(manifest_root / args.negative_manifest),
        "model_path": str(model_path),
        "fit_seconds": fit_s,
        "config": asdict(cfg),
        "min_area": args.min_area,
        "summary": summary,
        "examples_path": str(examples_path),
        "debug_dir": str(out_dir / "debug_rf"),
    }
    metrics_path = out_dir / "target_mask_variant_metrics.json"
    metrics_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
