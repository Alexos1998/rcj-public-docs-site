#!/usr/bin/env python3
"""Retrain victim classification with an explicit ``none`` class.

This script uses the existing ``victim_classification_with_none.csv`` manifest
and appends supervisor-aligned hard negatives from
``controller/logs/latest/analysis/vision_safe_training_manifest.csv``.
"""

from __future__ import annotations

import argparse
import csv
import json
import shutil
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common.config import get_dataset_root, get_manifest_root
from notebooks.common.train_config import ClassificationTrainConfig
from notebooks.common.training_runs import run_classification_training


LABELS = ["harmed", "unharmed", "stable", "none"]
LABEL_INDEX = {name: index for index, name in enumerate(LABELS)}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, str]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def crop_camera_debug_image(src: Path, bbox: tuple[int, int, int, int], dest: Path) -> None:
    """Extract the camera panel bbox from a debug image and save as a 64x64 sample."""

    image = Image.open(src).convert("RGB")
    # Debug images render the original 64x64 camera at 4x scale on the left.
    scale = 4
    x, y, w, h = bbox
    pad = max(2, int(round(max(w, h) * 0.15)))
    left = max(0, (x - pad) * scale)
    top = max(0, (y - pad) * scale)
    right = min(64 * scale, (x + w + pad) * scale)
    bottom = min(64 * scale, (y + h + pad) * scale)
    if right <= left or bottom <= top:
        left, top, right, bottom = 0, 0, 64 * scale, 64 * scale
    crop = image.crop((left, top, right, bottom)).resize((64, 64), Image.Resampling.BILINEAR)
    dest.parent.mkdir(parents=True, exist_ok=True)
    crop.save(dest)


def build_manifest(dataset_name: str, base_manifest: str, safe_manifest: Path, output_manifest: str) -> Path:
    manifest_root = get_manifest_root(dataset_name)
    dataset_root = get_dataset_root(dataset_name)
    base_path = manifest_root / base_manifest
    output_path = manifest_root / output_manifest
    rows = read_csv(base_path)

    normalized: list[dict[str, str]] = []
    for row in rows:
        label_name = row["label_name"]
        if label_name not in LABEL_INDEX:
            continue
        normalized.append(
            {
                "split": row["split"],
                "image_path": row["image_path"],
                "label": str(LABEL_INDEX[label_name]),
                "label_name": label_name,
                "source": row.get("negative_source", "") or "base",
            }
        )

    alignment_path = safe_manifest.parent / "vision_supervisor_alignment.csv"
    alignment = {int(row["seq"]): row for row in read_csv(alignment_path)}
    hard_rows = [row for row in read_csv(safe_manifest) if row["task"] == "victim_cls_negative"]
    for row in hard_rows:
        seq = int(row["seq"])
        aligned = alignment.get(seq)
        if not aligned:
            continue
        bbox = tuple(int(value) for value in aligned["bbox"].split(","))
        src = Path(row["path"])
        rel = Path("supervisor_hard_none") / "images" / f"hard_none_seq{seq:08d}.png"
        dest = dataset_root / "train" / rel
        crop_camera_debug_image(src, bbox, dest)
        normalized.append(
            {
                "split": "train",
                "image_path": rel.as_posix(),
                "label": str(LABEL_INDEX["none"]),
                "label_name": "none",
                "source": "supervisor_victim_misid",
            }
        )

    write_csv(output_path, normalized, ["split", "image_path", "label", "label_name", "source"])
    counts = Counter(row["label_name"] for row in normalized)
    split_counts = Counter(row["split"] for row in normalized)
    print(f"wrote manifest: {output_path}")
    print(f"rows={len(normalized)} labels={dict(counts)} splits={dict(split_counts)}")
    return output_path


def backup_and_copy(src: Path, dest: Path) -> Path | None:
    if not src.exists():
        raise FileNotFoundError(src)
    backup = None
    if dest.exists():
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = dest.with_name(f"{dest.stem}.backup_{stamp}{dest.suffix}")
        shutil.copy2(dest, backup)
    shutil.copy2(src, dest)
    return backup


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-name", default="imagens_larc")
    parser.add_argument("--base-manifest", default="victim_classification_with_none.csv")
    parser.add_argument("--output-manifest", default="victim_classification_supervisor_hard_none.csv")
    parser.add_argument(
        "--safe-manifest",
        type=Path,
        default=ROOT / "controller/logs/latest/analysis/vision_safe_training_manifest.csv",
    )
    parser.add_argument("--epochs", type=int, default=120)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--run-id", default="")
    parser.add_argument("--deploy", action="store_true")
    args = parser.parse_args()

    manifest_path = build_manifest(
        args.dataset_name, args.base_manifest, args.safe_manifest, args.output_manifest
    )

    cfg = ClassificationTrainConfig(
        task_name="victim_cls_with_none",
        dataset_name=args.dataset_name,
        labels=LABELS,
        manifest_filename=manifest_path.name,
        input_size=96,
        batch_size=64,
        epochs=args.epochs,
        learning_rate=0.001,
        weight_decay=0.0001,
        num_workers=0,
        dropout=0.2,
        base_channels=64,
        seed=42,
        augment=True,
        augment_degrees=90.0,
        augment_brightness=0.18,
        augment_contrast=0.18,
        augment_translate=0.12,
        device=args.device,
        output_mode="timestamped",
        update_latest=False,
        model_dir_name="victim",
        checkpoint_name="victim_cls_best.pt",
        onnx_name="victim_cls.onnx",
        run_id=args.run_id,
        show_samples=False,
        show_training_plots=True,
    )
    result = run_classification_training(cfg)

    deploy_info = {}
    if args.deploy:
        controller_models = ROOT / "controller/models"
        controller_models.mkdir(parents=True, exist_ok=True)
        for src in (result.onnx_path, result.onnx_path.with_suffix(".metadata.json")):
            dest = controller_models / src.name
            backup = backup_and_copy(src, dest)
            deploy_info[dest.name] = {"source": str(src), "backup": str(backup) if backup else None}

    summary = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "manifest": str(manifest_path),
        "labels": LABELS,
        "checkpoint": str(result.checkpoint_path),
        "onnx": str(result.onnx_path),
        "metrics": str(result.metrics_path) if result.metrics_path else None,
        "best_epoch": result.best_epoch,
        "best_metric": result.best_metric,
        "deployed": deploy_info,
    }
    summary_path = result.config.artifact_dir / "retrain_victim_cls_with_none_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"summary: {summary_path}")


if __name__ == "__main__":
    main()
