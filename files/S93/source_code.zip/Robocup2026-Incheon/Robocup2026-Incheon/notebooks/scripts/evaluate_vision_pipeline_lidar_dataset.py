#!/usr/bin/env python3
"""Evaluate deployed/latest vision ONNX models on camera + fake/lidar manifests."""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common import model_registry
from notebooks.common.config import REPORTS_DIR, get_dataset_root, get_manifest_root
from notebooks.common.datasets import DEFAULT_MEAN, DEFAULT_STD, read_csv_manifest


def _require_runtime():
    try:
        import numpy as np
        import onnxruntime as ort
        from PIL import Image
    except ImportError as exc:
        raise RuntimeError("Install numpy, pillow and onnxruntime before evaluation.") from exc
    return np, ort, Image


def _softmax(np, values):
    values = np.asarray(values, dtype=np.float32)
    values = values - np.max(values)
    exp = np.exp(values)
    total = np.sum(exp)
    return exp / total if total > 0 else exp


class OnnxClassifier:
    def __init__(self, task_name: str):
        np, ort, Image = _require_runtime()
        self.np = np
        self.Image = Image
        bundle = model_registry.resolve_model_bundle(task_name)
        if bundle.onnx_path is None:
            raise RuntimeError(f"no ONNX found for {task_name}")
        self.bundle = bundle
        self.session = ort.InferenceSession(str(bundle.onnx_path), providers=["CPUExecutionProvider"])
        self.input_name = self.session.get_inputs()[0].name
        metadata = bundle.load_metadata()
        shape = metadata.get("input_shape") or self.session.get_inputs()[0].shape
        self.input_size = int(shape[-1]) if shape and isinstance(shape[-1], int) else 64
        self.labels = list(metadata.get("labels") or bundle.labels)
        self.mean = np.asarray(metadata.get("mean") or DEFAULT_MEAN, dtype=np.float32).reshape(1, 1, 3)
        self.std = np.asarray(metadata.get("std") or DEFAULT_STD, dtype=np.float32).reshape(1, 1, 3)

    def predict(self, image_path: Path) -> tuple[str, float, list[float]]:
        with self.Image.open(image_path) as image:
            image = image.convert("RGB").resize((self.input_size, self.input_size), self.Image.BILINEAR)
            array = self.np.asarray(image, dtype=self.np.float32) / 255.0
        array = (array - self.mean) / self.std
        tensor = self.np.transpose(array, (2, 0, 1))[None, ...].astype(self.np.float32)
        output = self.session.run(None, {self.input_name: tensor})[0][0]
        probs = _softmax(self.np, output)
        index = int(self.np.argmax(probs))
        label = self.labels[index] if index < len(self.labels) else str(index)
        return label, float(probs[index]), probs.astype(float).tolist()


def resolve_image(dataset_root: Path, row: dict[str, str]) -> Path:
    return dataset_root / row["split"] / row["image_path"]


def classification_metrics(rows: list[dict[str, str]], predictions: list[str]) -> dict[str, Any]:
    labels = sorted({row["label_name"] for row in rows} | set(predictions))
    confusion: dict[str, dict[str, int]] = {label: {other: 0 for other in labels} for label in labels}
    correct = 0
    for row, pred in zip(rows, predictions):
        truth = row["label_name"]
        confusion[truth][pred] += 1
        correct += int(truth == pred)
    per_class = {}
    for label in labels:
        tp = confusion[label][label]
        fp = sum(confusion[other][label] for other in labels if other != label)
        fn = sum(confusion[label][other] for other in labels if other != label)
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        per_class[label] = {"precision": precision, "recall": recall, "support": sum(confusion[label].values())}
    return {
        "rows": len(rows),
        "accuracy": correct / len(rows) if rows else 0.0,
        "per_class": per_class,
        "confusion": confusion,
    }


def evaluate_classifier(
    classifier: OnnxClassifier,
    dataset_root: Path,
    rows: list[dict[str, str]],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    predictions = []
    details = []
    missing = 0
    for row in rows:
        image_path = resolve_image(dataset_root, row)
        if not image_path.exists():
            missing += 1
            predictions.append("__missing__")
            continue
        label, confidence, probs = classifier.predict(image_path)
        predictions.append(label)
        details.append({"row": row, "prediction": label, "confidence": confidence, "probabilities": probs})
    metrics = classification_metrics(rows, predictions)
    metrics["missing_images"] = missing
    metrics["model"] = str(classifier.bundle.onnx_path)
    metrics["labels"] = classifier.labels
    return metrics, details


def summarize_fake_lidar(fake_rows: list[dict[str, str]], fake_details: list[dict[str, Any]], threshold: float) -> dict[str, Any]:
    distances = []
    close_rays = []
    npz_status = Counter()
    high_conf_fake = 0
    fake_pred = 0
    for detail in fake_details:
        row = detail["row"]
        pred = detail["prediction"]
        conf = float(detail["confidence"])
        if pred == "fake":
            fake_pred += 1
        if pred == "fake" and conf >= threshold:
            high_conf_fake += 1
        try:
            distances.append(float(row.get("real_distance_xz_m", "nan")))
        except ValueError:
            pass
        try:
            close_rays.append(int(row.get("lidar_object_bbox_close_rays", "0")))
        except ValueError:
            close_rays.append(0)
        npz_status[row.get("lidar_npz_exists", "")] += 1
    finite_dist = [value for value in distances if math.isfinite(value)]
    return {
        "rows": len(fake_rows),
        "fake_predicted": fake_pred,
        "fake_predicted_rate": fake_pred / len(fake_rows) if fake_rows else 0.0,
        "high_confidence_fake": high_conf_fake,
        "high_confidence_fake_rate": high_conf_fake / len(fake_rows) if fake_rows else 0.0,
        "fake_confidence_threshold": threshold,
        "distance_xz_m": {
            "min": min(finite_dist) if finite_dist else None,
            "max": max(finite_dist) if finite_dist else None,
            "mean": sum(finite_dist) / len(finite_dist) if finite_dist else None,
            "within_0p06": sum(value <= 0.06 for value in finite_dist),
            "within_0p06_rate": sum(value <= 0.06 for value in finite_dist) / len(finite_dist) if finite_dist else 0.0,
        },
        "lidar_npz_status": dict(npz_status),
        "lidar_bbox_close_rays": {
            "min": min(close_rays) if close_rays else None,
            "max": max(close_rays) if close_rays else None,
            "mean": sum(close_rays) / len(close_rays) if close_rays else None,
            "at_least_5": sum(value >= 5 for value in close_rays),
            "at_least_5_rate": sum(value >= 5 for value in close_rays) / len(close_rays) if close_rays else 0.0,
        },
    }


def split_counts(rows: list[dict[str, str]]) -> dict[str, int]:
    return dict(Counter(row.get("split", "") for row in rows))


def label_counts(rows: list[dict[str, str]]) -> dict[str, int]:
    return dict(Counter(row.get("label_name", "") for row in rows))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="imagens_larc")
    parser.add_argument("--fake-confidence-threshold", type=float, default=0.90)
    parser.add_argument("--split", action="append", default=["validation", "test"])
    args = parser.parse_args()

    dataset_root = get_dataset_root(args.dataset_name)
    manifest_root = get_manifest_root(args.dataset_name)
    split_set = set(args.split)

    object_rows = [
        row for row in read_csv_manifest(manifest_root / "object_presence_with_fake.csv")
        if row.get("split") in split_set
    ]
    victim_rows = [
        row for row in read_csv_manifest(manifest_root / "victim_classification_with_fake.csv")
        if row.get("split") in split_set
    ]
    fake_rows = [
        row for row in read_csv_manifest(manifest_root / "fake_lidar.csv")
        if row.get("split") in split_set
    ]

    object_classifier = OnnxClassifier("object_presence")
    victim_classifier = OnnxClassifier("victim_cls")
    object_metrics, object_details = evaluate_classifier(object_classifier, dataset_root, object_rows)
    victim_metrics, victim_details = evaluate_classifier(victim_classifier, dataset_root, victim_rows)
    fake_details = [detail for detail in victim_details if detail["row"].get("label_name") == "fake"]
    fake_lidar = summarize_fake_lidar(fake_rows, fake_details, args.fake_confidence_threshold)

    branch_fake = [
        detail for detail in object_details
        if detail["row"].get("object_kind") == "fake" or detail["row"].get("label_name") == "victim" and "../fakes/" in detail["row"].get("image_path", "")
    ]
    branch_victim = sum(1 for detail in branch_fake if detail["prediction"] == "victim")
    report = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "dataset": args.dataset_name,
        "splits": sorted(split_set),
        "object_presence": object_metrics,
        "victim_cls": victim_metrics,
        "fake_camera_lidar": fake_lidar,
        "fake_object_branch": {
            "rows": len(branch_fake),
            "predicted_victim": branch_victim,
            "predicted_victim_rate": branch_victim / len(branch_fake) if branch_fake else 0.0,
        },
        "manifest_counts": {
            "object_presence_with_fake": {"splits": split_counts(object_rows), "labels": label_counts(object_rows)},
            "victim_classification_with_fake": {"splits": split_counts(victim_rows), "labels": label_counts(victim_rows)},
            "fake_lidar": {"splits": split_counts(fake_rows), "labels": label_counts(fake_rows)},
        },
    }

    out = REPORTS_DIR / "vision_pipeline_lidar_eval.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print("report:", out)
    print(json.dumps({
        "object_presence_accuracy": object_metrics["accuracy"],
        "victim_cls_accuracy": victim_metrics["accuracy"],
        "fake_camera_lidar": fake_lidar,
        "fake_object_branch": report["fake_object_branch"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
