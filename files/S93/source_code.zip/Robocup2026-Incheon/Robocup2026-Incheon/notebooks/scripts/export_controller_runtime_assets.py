"""Export the validated perception models into ``controller/models`` for the C++ runtime.

The C++ controller must run **without Python / sklearn / joblib**, so the
scikit-learn Random Forest target segmenter is re-trained as an OpenCV
``cv::ml::RTrees`` model (same 13 per-pixel features) and saved as a YAML that
``TargetMaskRF`` loads directly. The ONNX models are copied through unchanged.

Outputs (under ``controller/models/``):
    presence.onnx, object_presence.onnx, object_type.onnx, victim_bbox.onnx,
    target_bbox.onnx, victim_cls.onnx
    *.metadata.json             (ONNX input/output shape, labels, normalization)
    target_mask_rf.yml            (cv::ml::RTrees)
    target_mask_features.yml      (feature schema: names, order, normalization)
    model_manifest.json           (names, SHA256, per-model input shape, schema, thresholds,
                                   export time, selected-model metrics)

The feature extraction here is byte-for-byte the same OpenCV pipeline implemented
in ``controller/.../target_mask_rf.cpp`` (RGB→features), so Python-trained and
C++-loaded predictions match.

Run with:
    .venv/bin/python notebooks/scripts/export_controller_runtime_assets.py --dataset-name imagens_larc
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common import metrics
from notebooks.common.target_mask_rf import FEATURE_NAMES, extract_pixel_features
from notebooks.common.target_mask_pipeline import ARTIFACTS_ROOT, load_records

CONTROLLER_MODELS = ROOT / "controller" / "models"

# Acceptance / runtime thresholds shipped in the manifest (kept in sync with vision.yaml).
RUNTIME_THRESHOLDS = {
    "min_presence_confidence": 0.55,
    "min_type_confidence": 0.60,
    "min_victim_cls_confidence": 0.5,
    "valid_detection_distance_m": 0.06,
    "use_bbox_gate": True,
    # Camera-only proximity gate on WIDTH (x) and HEIGHT (y); area non-blocking (0).
    # VICTIM gate OFF (0): a fake is the same size as a victim, so bbox size can't
    # separate them -- the classifier does. TARGET gate ON, model-derived from
    # scripts/evaluate_bbox_gate_xy.py (kept in sync with vision.yaml).
    "victim_bbox_gate_min_area_px": 0.0,
    "victim_bbox_gate_min_width_px": 0.0,
    "victim_bbox_gate_min_height_px": 0.0,
    "target_bbox_gate_min_area_px": 0.0,
    "target_bbox_gate_min_width_px": 36.0,
    "target_bbox_gate_min_height_px": 41.0,
    "min_radial_coverage": 0.25,
    "min_ring_confidence": 0.34,
    "min_mask_area_px": 60,
    "rf_proba_threshold": 0.5,
}

ONNX_MODELS = {
    "presence": "presence.onnx",
    "object_presence": "object_presence.onnx",
    "object_type": "object_type.onnx",
    "victim_bbox": "victim_bbox.onnx",
    "target_bbox": "target_bbox.onnx",
    "victim_cls": "victim_cls.onnx",
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 16), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _sample_pixels(records, pixels_per_class: int, seed: int = 42):
    rng = np.random.default_rng(seed)
    feats, labs = [], []
    for rec in records:
        features = extract_pixel_features(rec.image)
        labels = rec.gt_mask.astype(np.uint8).reshape(-1)
        for value in (0, 1):
            idx = np.nonzero(labels == value)[0]
            if idx.size == 0:
                continue
            take = min(pixels_per_class, idx.size)
            chosen = rng.choice(idx, size=take, replace=False)
            feats.append(features[chosen])
            labs.append(labels[chosen])
    return np.concatenate(feats).astype(np.float32), np.concatenate(labs).astype(np.int32)


def _train_rtrees(samples: np.ndarray, responses: np.ndarray):
    import cv2

    n_features = samples.shape[1]
    var_type = np.array([cv2.ml.VAR_NUMERICAL] * n_features + [cv2.ml.VAR_CATEGORICAL], np.uint8)
    train_data = cv2.ml.TrainData_create(samples, cv2.ml.ROW_SAMPLE, responses, varType=var_type)
    rtrees = cv2.ml.RTrees_create()
    rtrees.setMaxDepth(16)
    rtrees.setMinSampleCount(2)
    rtrees.setCalculateVarImportance(False)
    rtrees.setActiveVarCount(0)  # 0 -> sqrt(n_features)
    rtrees.setTermCriteria((cv2.TERM_CRITERIA_MAX_ITER + cv2.TERM_CRITERIA_EPS, 200, 1e-3))
    rtrees.train(train_data)
    return rtrees


def _predict_mask(rtrees, image_rgb: np.ndarray) -> np.ndarray:
    import cv2

    h, w = image_rgb.shape[:2]
    features = extract_pixel_features(image_rgb).astype(np.float32)
    _, results = rtrees.predict(features)
    mask = results.reshape(h, w) >= 0.5
    mask = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8)).astype(bool)
    return mask


def _evaluate(rtrees, records) -> dict:
    ious = [metrics.mask_iou(_predict_mask(rtrees, r.image), r.gt_mask) for r in records]
    dices = [metrics.mask_dice(_predict_mask(rtrees, r.image), r.gt_mask) for r in records]
    return {"n": len(records), "mask_iou": float(np.mean(ious)), "mask_dice": float(np.mean(dices))}


def _copy_onnx() -> dict[str, dict]:
    """Resolve the latest trained ONNX from the registry; fall back to existing files."""

    from notebooks.common import model_registry

    info: dict[str, dict] = {}
    for task, filename in ONNX_MODELS.items():
        dest = CONTROLLER_MODELS / filename
        metadata_dest = dest.with_suffix(".metadata.json")
        copied_from = None
        metadata = {}
        try:
            bundle = model_registry.resolve_model_bundle(task, require_onnx=True)
            src = Path(bundle.onnx_path) if getattr(bundle, "onnx_path", None) else None
            if src and src.exists():
                shutil.copy2(src, dest)
                copied_from = str(src)
                metadata = bundle.load_metadata()
                if bundle.metadata_path and bundle.metadata_path.exists():
                    shutil.copy2(bundle.metadata_path, metadata_dest)
        except Exception as exc:  # noqa: BLE001 - registry optional; keep existing file
            copied_from = f"<kept existing: {type(exc).__name__}>"
            if metadata_dest.exists():
                try:
                    metadata = json.loads(metadata_dest.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    metadata = {}
        if not dest.exists():
            raise FileNotFoundError(f"{dest} missing and could not be resolved from the registry.")
        model_info = {"file": filename, "sha256": _sha256(dest), "source": copied_from}
        if metadata_dest.exists():
            model_info["metadata_file"] = metadata_dest.name
        if metadata.get("input_shape"):
            model_info["input_shape"] = metadata["input_shape"]
        if metadata.get("labels"):
            model_info["labels"] = metadata["labels"]
        info[task] = model_info
    return info


def _write_feature_schema(path: Path, input_size: int) -> None:
    import cv2

    lines = [
        "# Per-pixel feature schema for target_mask_rf.yml (cv::ml::RTrees).",
        "# Computed from the RGB image; the C++ runtime must reproduce this order/normalization.",
        "feature_schema:",
        f"  input_width: {input_size}",
        f"  input_height: {input_size}",
        "  color_input_order: \"RGB\"  # convert BGR->RGB before feature extraction",
        f"  num_features: {len(FEATURE_NAMES)}",
        "  features:",
    ]
    spec = {
        "r": "R/255", "g": "G/255", "b": "B/255",
        "h": "OpenCV RGB2HSV H / 179", "s": "S/255", "v": "V/255",
        "lab_l": "OpenCV RGB2Lab L / 255", "lab_a": "a/255", "lab_b": "b/255",
        "x_norm": "x/(W-1)", "y_norm": "y/(H-1)",
        "local_mean": "blur(gray,3x3); gray=RGB2GRAY/255",
        "grad_mag": "sqrt(Sobelx^2+Sobely^2) on gray, /(max+1e-6)",
    }
    for i, name in enumerate(FEATURE_NAMES):
        lines.append(f"    - {{index: {i}, name: \"{name}\", normalization: \"{spec[name]}\"}}")
    lines += [
        "  opencv_version: \"" + cv2.__version__ + "\"",
        "  notes: \"Sobel ksize=3; local_mean kernel 3x3; HSV H in [0,179]; Lab 8-bit.\"",
        "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")


def generate(dataset_name: str, pixels_per_class: int = 600, input_size: int = 64) -> dict:
    CONTROLLER_MODELS.mkdir(parents=True, exist_ok=True)
    manifest_path = CONTROLLER_MODELS / "model_manifest.json"
    existing_manifest = {}
    if manifest_path.exists():
        try:
            existing_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            existing_manifest = {}

    print("loading dataset records ...")
    train = load_records(dataset_name, "train")
    val = load_records(dataset_name, "validation")
    test = load_records(dataset_name, "test")

    print(f"training cv::ml::RTrees on {len(train)} images ...")
    samples, responses = _sample_pixels(train, pixels_per_class)
    rtrees = _train_rtrees(samples, responses)

    rf_path = CONTROLLER_MODELS / "target_mask_rf.yml"
    rtrees.save(str(rf_path))
    val_metrics = _evaluate(rtrees, val)
    test_metrics = _evaluate(rtrees, test)
    print(f"RTrees IoU val={val_metrics['mask_iou']:.4f} test={test_metrics['mask_iou']:.4f}")

    features_path = CONTROLLER_MODELS / "target_mask_features.yml"
    _write_feature_schema(features_path, input_size)

    onnx_info = _copy_onnx()

    selected_metrics = {}
    selection_json = ARTIFACTS_ROOT / "model_selection.json"
    if selection_json.exists():
        sel = json.loads(selection_json.read_text())
        selected_metrics = {
            "selected_mask_model": sel.get("selected_mask_model"),
            "sklearn_rf_mask_iou": sel.get("rf_mask_iou"),
            "radial_texture_accuracy": sel.get("selected_mask_radial_texture_accuracy"),
            "per_ring_accuracy": sel.get("per_ring_accuracy"),
        }

    manifest = {
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "dataset": dataset_name,
        "input_size": {"width": input_size, "height": input_size},
        "thresholds": RUNTIME_THRESHOLDS,
        "onnx_models": onnx_info,
        "target_mask_rf": {
            "file": "target_mask_rf.yml",
            "type": "opencv_ml_rtrees",
            "sha256": _sha256(rf_path),
            "feature_config": "target_mask_features.yml",
            "feature_schema": list(FEATURE_NAMES),
            "metrics": {"val": val_metrics, "test": test_metrics},
        },
        "target_mask_features": {"file": "target_mask_features.yml", "sha256": _sha256(features_path)},
        "selected_model_metrics": selected_metrics,
        "color_values": {"K": -2, "R": -1, "Y": 0, "G": 1, "B": 2},
        "target_sum_to_class": {"0": "F", "1": "P", "2": "C", "3": "O"},
    }
    if "map_geometry" in existing_manifest:
        manifest["map_geometry"] = existing_manifest["map_geometry"]
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print(f"\nwrote {rf_path}")
    print(f"wrote {features_path}")
    print(f"wrote {manifest_path}")
    print("ONNX models:", {k: v["file"] for k, v in onnx_info.items()})
    if val_metrics["mask_iou"] < 0.95:
        print(f"WARNING: RTrees val IoU {val_metrics['mask_iou']:.4f} < 0.95")
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="imagens_larc")
    parser.add_argument("--pixels-per-class", type=int, default=600)
    parser.add_argument("--input-size", type=int, default=64)
    args = parser.parse_args()
    generate(args.dataset_name, args.pixels_per_class, args.input_size)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
