#!/usr/bin/env python3
"""Smoke checks for the 2x2-block obstacle pipeline (detection + centre localisation).

Run with:
    python notebooks/scripts/smoke_obstacle_blocks.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common import map_dataset as md
from notebooks.common import map_wbt as mw

PASS, FAIL = 0, 0


def check(cond: bool, msg: str) -> None:
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"[OK] {msg}")
    else:
        FAIL += 1
        print(f"[FAIL] {msg}")


def main() -> int:
    runs = md.list_runs()
    check(bool(runs), f"found {len(runs)} runs")

    # --- obstacle parsing from .wbt ---
    runs_with_obs = []
    for rd in runs:
        wbt = md.load_wbt_grid(rd)
        if wbt is not None and wbt.n_obstacles > 0:
            runs_with_obs.append(rd)
    check(bool(runs_with_obs), f"{len(runs_with_obs)} runs expose OBSTACLE nodes")

    wbt = md.load_wbt_grid(runs_with_obs[0])
    cells = wbt.obstacle_cells()
    check(len(cells) == wbt.n_obstacles, "obstacle_cells count matches n_obstacles")
    check(all({"wbt_r", "wbt_c", "size_r", "size_c"} <= set(c) for c in cells),
          "obstacle cells carry continuous coords + footprint size")

    # --- obstacle centres land on occupied cells (mostly; some are unexplored) ---
    tot = good = 0
    for rd in runs_with_obs:
        run = md.load_run(rd)
        for ob in md.load_wbt_grid(rd).obstacle_cells():
            wx, wy = -ob["wbt_r"] * md.TILE_SIZE_M, -ob["wbt_c"] * md.TILE_SIZE_M
            patch = md.sample_patch(run["grid"], run["meta"], wx, wy, 0.04)
            tot += 1
            good += (patch >= 65).mean() > 0.05
    check(good >= 0.7 * tot, f"obstacle centres on occupancy: {good}/{tot} (>=70%)")

    # --- block dataset ---
    blocks = md.filter_explored_blocks(md.load_all_obstacle_blocks(), thr=0.5)
    pos = [b for b in blocks if b.has_obstacle]
    check(len(blocks) > 0 and len(pos) > 0, f"{len(blocks)} blocks, {len(pos)} positive")
    check(all(b.center_off is not None and b.center_tile is not None for b in pos),
          "positive blocks carry centre offset + centre tile")
    check(all(-1.001 <= o <= 1.001 for b in pos for o in b.center_off),
          "centre offsets within [-1,1]")

    # --- features + detection model fit ---
    feat = md.obstacle_block_features(pos[0].patch)
    check(len(feat) == len(md.OBSTACLE_BLOCK_FEATURE_NAMES),
          f"feature width == {len(md.OBSTACLE_BLOCK_FEATURE_NAMES)}")
    detector = md.train_obstacle_detector(blocks, augment=None, n_estimators=60)
    check(hasattr(detector, "predict_proba"), "detector fitted")

    # --- localisation accuracy (interior-blob centroid) ---
    errs = []
    for b in pos:
        off = md.localize_obstacle_center(b.patch)
        if off is not None:
            errs.append(np.hypot(off[0] - b.center_off[0],
                                 off[1] - b.center_off[1]) * md.TILE_SIZE_M)
    check(len(errs) > 0 and np.median(errs) < 0.05,
          f"localisation median centre error {np.median(errs):.4f} m (<0.05)")

    # --- flood-fill mask + pipeline report ---
    mask = md.obstacle_blob_mask(pos[0].patch, max_radius_cells=pos[0].patch.shape[0] // 3)
    check(mask.shape == pos[0].patch.shape[:2], "blob mask matches patch shape")

    rep = md.obstacle_pipeline_report(md.load_run(runs_with_obs[0]), detector, thr=0.3)
    check({"predicted_tiles", "truth_tiles", "detections"} <= set(rep),
          "pipeline report returns predicted/truth tiles")
    check(len(rep["truth_tiles"]) > 0, "pipeline report has ground-truth obstacle tiles")

    print(f"\n{PASS}/{PASS + FAIL} checks passed")
    return 0 if FAIL == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
