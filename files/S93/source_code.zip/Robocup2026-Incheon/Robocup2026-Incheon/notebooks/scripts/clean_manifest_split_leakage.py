#!/usr/bin/env python3
"""Remove exact duplicate image rows across splits from dataset manifests."""

from __future__ import annotations

import argparse
import csv
import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common.config import get_dataset_root, get_manifest_root

SPLIT_PRIORITY = {"train": 0, "validation": 1, "test": 2}
DEFAULT_MANIFESTS = [
    "presence.csv",
    "object_presence.csv",
    "object_type.csv",
    "victim_classification.csv",
    "victim_classification_with_none.csv",
    "victim_bbox.csv",
    "victim_bbox_with_none.csv",
    "target_localization.csv",
    "target_localization_with_none.csv",
    "target_mask_manifest.csv",
    "target_projection_labels.csv",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 16), b""):
            digest.update(chunk)
    return digest.hexdigest()


def image_path_for_row(dataset_root: Path, row: dict[str, str]) -> Path:
    return dataset_root / row["split"] / row["image_path"]


def clean_manifest(dataset_root: Path, manifest_path: Path) -> tuple[int, int]:
    if not manifest_path.exists():
        return 0, 0
    with manifest_path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        fieldnames = reader.fieldnames or []
        rows = list(reader)
    if not rows or not {"split", "image_path"} <= set(fieldnames):
        return len(rows), 0

    indexed = []
    for index, row in enumerate(rows):
        path = image_path_for_row(dataset_root, row)
        if not path.exists():
            indexed.append((index, row, f"missing:{index}"))
            continue
        indexed.append((index, row, sha256(path)))

    best_for_hash: dict[str, tuple[int, dict[str, str], int]] = {}
    for index, row, digest in indexed:
        rank = SPLIT_PRIORITY.get(row.get("split", ""), 99)
        current = best_for_hash.get(digest)
        if current is None or (rank, index) < (SPLIT_PRIORITY.get(current[1].get("split", ""), 99), current[0]):
            best_for_hash[digest] = (index, row, rank)

    keep_indexes = {item[0] for item in best_for_hash.values()}
    out_rows = [row for index, row, _ in indexed if index in keep_indexes]
    removed = len(rows) - len(out_rows)
    if removed:
        with manifest_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(out_rows)
    return len(out_rows), removed


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="imagens_larc")
    parser.add_argument("--manifest", action="append", default=[])
    args = parser.parse_args()

    dataset_root = get_dataset_root(args.dataset_name)
    manifest_root = get_manifest_root(args.dataset_name)
    names = args.manifest or DEFAULT_MANIFESTS
    total_removed = 0
    for name in names:
        rows, removed = clean_manifest(dataset_root, manifest_root / name)
        total_removed += removed
        print(f"{name}: rows={rows} removed_duplicates={removed}")
    print(f"total_removed={total_removed}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
