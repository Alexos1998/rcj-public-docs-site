"""Train/evaluate a lightweight victim mask segmenter.

Two modes are supported:

* crop: uses the victim localization bbox as the runtime crop source, trains a
  tiny pixel classifier inside those crops, reconstructs the full-image mask,
  and compares it with the rendered victim mask.
* full: trains the same classifier on complete images, using real victim masks
  for victims and empty masks for none/opposite-object rows.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from dataclasses import asdict, replace
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from notebooks.common.config import get_dataset_root, get_manifest_root, get_model_dir
from notebooks.common.metrics import boundary_iou, mask_metrics
from notebooks.common.target_geometry import clean_largest_component
from notebooks.common.target_mask_rf import TargetMaskRFConfig, TargetMaskRandomForest


SPLITS = ("train", "validation", "test")


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def resolve_image(dataset_root: Path, row: dict[str, str]) -> Path:
    return dataset_root / row["split"] / row["image_path"]


def resolve_mask(dataset_root: Path, row: dict[str, str]) -> Path | None:
    image_path = Path(row["image_path"])
    mask_dir = dataset_root / row["split"] / image_path.parent.parent / "masks"
    binary = mask_dir / image_path.name.replace("image_", "mask_binary_", 1)
    if binary.exists():
        return binary
    regular = mask_dir / image_path.name.replace("image_", "mask_", 1)
    if regular.exists():
        return regular
    return None


def is_victim_row(row: dict[str, str]) -> bool:
    return row.get("label_name") in {"harmed", "unharmed", "stable", "victim"}


def load_rgb(path: Path) -> np.ndarray:
    return np.asarray(Image.open(path).convert("RGB"))


def load_victim_mask(path: Path) -> np.ndarray:
    arr = np.asarray(Image.open(path).convert("L"))
    if "mask_binary_" in path.name:
        return arr > 127
    return arr < 128


def bbox_from_mask(mask: np.ndarray) -> tuple[int, int, int, int] | None:
    ys, xs = np.nonzero(mask.astype(bool))
    if xs.size == 0:
        return None
    return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1


def bbox_iou(a: tuple[int, int, int, int] | None, b: tuple[int, int, int, int] | None) -> float:
    if a is None and b is None:
        return 1.0
    if a is None or b is None:
        return 0.0
    ax0, ay0, ax1, ay1 = a
    bx0, by0, bx1, by1 = b
    ix0, iy0 = max(ax0, bx0), max(ay0, by0)
    ix1, iy1 = min(ax1, bx1), min(ay1, by1)
    inter = max(0, ix1 - ix0) * max(0, iy1 - iy0)
    area_a = max(0, ax1 - ax0) * max(0, ay1 - ay0)
    area_b = max(0, bx1 - bx0) * max(0, by1 - by0)
    union = area_a + area_b - inter
    return float(inter / union) if union else 0.0


def bbox_pixels(row: dict[str, str], width: int, height: int, padding: float) -> tuple[int, int, int, int]:
    xmin, ymin, xmax, ymax = (float(row[k]) for k in ("xmin", "ymin", "xmax", "ymax"))
    pad_x = (xmax - xmin) * padding
    pad_y = (ymax - ymin) * padding
    x0 = int(np.floor(max(0.0, xmin - pad_x) * width))
    y0 = int(np.floor(max(0.0, ymin - pad_y) * height))
    x1 = int(np.ceil(min(1.0, xmax + pad_x) * width))
    y1 = int(np.ceil(min(1.0, ymax + pad_y) * height))
    x0 = max(0, min(width - 1, x0))
    y0 = max(0, min(height - 1, y0))
    x1 = max(x0 + 1, min(width, x1))
    y1 = max(y0 + 1, min(height, y1))
    return x0, y0, x1, y1


def crop_pair(image: np.ndarray, mask: np.ndarray, row: dict[str, str], padding: float) -> tuple[np.ndarray, np.ndarray, tuple[int, int, int, int]]:
    height, width = image.shape[:2]
    x0, y0, x1, y1 = bbox_pixels(row, width, height, padding)
    return image[y0:y1, x0:x1], mask[y0:y1, x0:x1], (x0, y0, x1, y1)


def paste_crop_mask(crop_mask: np.ndarray, shape: tuple[int, int], bbox: tuple[int, int, int, int]) -> np.ndarray:
    out = np.zeros(shape, dtype=bool)
    x0, y0, x1, y1 = bbox
    out[y0:y1, x0:x1] = crop_mask.astype(bool)
    return out


def bbox_mask(shape: tuple[int, int], bbox: tuple[int, int, int, int]) -> np.ndarray:
    out = np.zeros(shape, dtype=bool)
    x0, y0, x1, y1 = bbox
    out[y0:y1, x0:x1] = True
    return out


def grabcut_mask(image: np.ndarray, bbox: tuple[int, int, int, int], iterations: int = 2) -> np.ndarray:
    import cv2

    x0, y0, x1, y1 = bbox
    rect = (x0, y0, max(1, x1 - x0), max(1, y1 - y0))
    gc_mask = np.zeros(image.shape[:2], dtype=np.uint8)
    bgd = np.zeros((1, 65), np.float64)
    fgd = np.zeros((1, 65), np.float64)
    try:
        cv2.grabCut(image, gc_mask, rect, bgd, fgd, iterations, cv2.GC_INIT_WITH_RECT)
    except cv2.error:
        return bbox_mask(image.shape[:2], bbox)
    pred = (gc_mask == cv2.GC_FGD) | (gc_mask == cv2.GC_PR_FGD)
    pred &= bbox_mask(image.shape[:2], bbox)
    return clean_largest_component(pred)


def evaluate_masks(pred: np.ndarray, target: np.ndarray) -> dict[str, float]:
    out = mask_metrics(pred.astype(bool), target.astype(bool))
    out["boundary_iou"] = boundary_iou(pred.astype(bool), target.astype(bool))
    out["pred_area"] = float(pred.sum())
    out["target_area"] = float(target.sum())
    return out


def aggregate(rows: list[dict[str, float]]) -> dict[str, float]:
    if not rows:
        return {}
    keys = [k for k in rows[0] if k not in {"split", "image_path"}]
    return {k: float(np.mean([float(r[k]) for r in rows])) for k in keys}


def save_debug_panel(path: Path, image: np.ndarray, target: np.ndarray, pred: np.ndarray,
                     bbox: tuple[int, int, int, int], title: str) -> None:
    base = Image.fromarray(image)
    overlay = base.convert("RGBA")
    layer = Image.new("RGBA", base.size, (0, 0, 0, 0))
    pixels = layer.load()
    for y, x in np.argwhere(target):
        pixels[int(x), int(y)] = (0, 220, 0, 105)
    for y, x in np.argwhere(pred):
        old = pixels[int(x), int(y)]
        pixels[int(x), int(y)] = (220, 0, 0, 120) if old[3] == 0 else (230, 200, 0, 150)
    overlay.alpha_composite(layer)
    draw = ImageDraw.Draw(overlay)
    draw.rectangle(bbox, outline=(255, 255, 255, 255), width=1)
    draw.text((2, 2), title, fill=(255, 255, 255, 255))
    path.parent.mkdir(parents=True, exist_ok=True)
    overlay.convert("RGB").save(path)


def load_full_records(dataset_root: Path, rows: list[dict[str, str]]) -> tuple[
    dict[str, list[tuple[dict[str, str], np.ndarray, np.ndarray]]], list[str]
]:
    records: dict[str, list[tuple[dict[str, str], np.ndarray, np.ndarray]]] = {split: [] for split in SPLITS}
    skipped: list[str] = []
    for row in rows:
        image_path = resolve_image(dataset_root, row)
        if not image_path.exists():
            skipped.append(row["image_path"])
            continue
        image = load_rgb(image_path)
        if is_victim_row(row):
            mask_path = resolve_mask(dataset_root, row)
            if mask_path is None:
                skipped.append(row["image_path"])
                continue
            mask = load_victim_mask(mask_path)
        else:
            mask = np.zeros(image.shape[:2], dtype=bool)
        records.setdefault(row["split"], []).append((row, image, mask))
    return records, skipped


def run_full_mode(args, dataset_root: Path, manifest_path: Path, rows: list[dict[str, str]]) -> dict:
    records, skipped = load_full_records(dataset_root, rows)
    train_images = [rec[1] for rec in records.get("train", [])]
    train_masks = [rec[2] for rec in records.get("train", [])]
    if not train_images:
        raise RuntimeError("No full-image training records were found.")

    cfg = TargetMaskRFConfig(
        model_type="extra_trees",
        n_estimators=args.n_estimators,
        max_depth=args.max_depth,
        min_samples_leaf=1,
        pixels_per_class=args.pixels_per_class,
        proba_threshold=args.threshold,
        postprocess=True,
        random_state=42,
    )
    start = time.perf_counter()
    model = TargetMaskRandomForest(cfg).fit(train_images, train_masks)
    fit_s = time.perf_counter() - start

    out_dir = get_model_dir("victim_mask")
    out_dir.mkdir(parents=True, exist_ok=True)
    model_path = model.save(out_dir / "victim_full_mask_rf.joblib")

    per_example: list[dict[str, object]] = []
    summary: dict[str, dict[str, float]] = {}
    debug_candidates: list[tuple[float, str, np.ndarray, np.ndarray, np.ndarray, tuple[int, int, int, int]]] = []

    for split, split_records in records.items():
        all_metrics: list[dict[str, float]] = []
        pos_metrics: list[dict[str, float]] = []
        neg_metrics: list[dict[str, float]] = []
        for row, image, target in split_records:
            pred = model.predict_mask(image)
            if pred.sum() < args.min_pred_area:
                pred = np.zeros_like(pred, dtype=bool)
            m = evaluate_masks(pred, target)
            target_bbox = bbox_from_mask(target)
            pred_bbox = bbox_from_mask(pred)
            m["mask_bbox_iou"] = bbox_iou(pred_bbox, target_bbox)
            m["has_prediction"] = float(pred_bbox is not None)
            m["is_positive"] = float(is_victim_row(row))
            all_metrics.append(m)
            if is_victim_row(row):
                pos_metrics.append(m)
            else:
                neg_metrics.append(m)
            per_example.append({
                "split": split,
                "image_path": row["image_path"],
                "label_name": row.get("label_name", ""),
                "rf_iou": m["iou"],
                "rf_dice": m["dice"],
                "rf_precision": m["precision"],
                "rf_recall": m["recall"],
                "mask_bbox_iou": m["mask_bbox_iou"],
                "has_prediction": m["has_prediction"],
                "pred_area": m["pred_area"],
                "target_area": m["target_area"],
            })
            if is_victim_row(row):
                debug_bbox = pred_bbox or target_bbox or (0, 0, image.shape[1], image.shape[0])
                debug_candidates.append((m["mask_bbox_iou"], row["image_path"], image, target, pred, debug_bbox))

        all_agg = aggregate(all_metrics)
        pos_agg = aggregate(pos_metrics)
        neg_agg = aggregate(neg_metrics)
        summary[split] = {
            "count": float(len(split_records)),
            "positive_count": float(len(pos_metrics)),
            "negative_count": float(len(neg_metrics)),
            "rf_iou_all": all_agg.get("iou", 0.0),
            "rf_iou_positive": pos_agg.get("iou", 0.0),
            "rf_dice_positive": pos_agg.get("dice", 0.0),
            "rf_boundary_iou_positive": pos_agg.get("boundary_iou", 0.0),
            "mask_bbox_iou_positive": pos_agg.get("mask_bbox_iou", 0.0),
            "negative_false_positive_rate": neg_agg.get("has_prediction", 0.0),
        }

    per_example_path = out_dir / "victim_full_mask_examples.csv"
    with per_example_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(per_example[0].keys()))
        writer.writeheader()
        writer.writerows(per_example)

    worst = sorted(debug_candidates, key=lambda item: item[0])[: args.debug_examples]
    for idx, (iou, image_path, image, target, pred, bbox) in enumerate(worst):
        save_debug_panel(
            out_dir / "debug_full" / f"worst_{idx:02d}.png",
            image,
            target,
            pred,
            bbox,
            f"bboxIoU={iou:.3f} {Path(image_path).name}",
        )

    return {
        "mode": "full",
        "dataset_name": args.dataset_name,
        "manifest": str(manifest_path),
        "fit_seconds": fit_s,
        "skipped": skipped[:50],
        "skipped_count": len(skipped),
        "model_path": str(model_path),
        "config": asdict(cfg),
        "min_pred_area": args.min_pred_area,
        "summary": summary,
        "per_example_path": str(per_example_path),
        "debug_dir": str(out_dir / "debug_full"),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-name", default="imagens_larc")
    parser.add_argument("--manifest-name", default="victim_bbox.csv")
    parser.add_argument("--mode", choices=("crop", "full"), default="crop")
    parser.add_argument("--crop-padding", type=float, default=0.35)
    parser.add_argument("--pixels-per-class", type=int, default=450)
    parser.add_argument("--n-estimators", type=int, default=160)
    parser.add_argument("--max-depth", type=int, default=18)
    parser.add_argument("--threshold", type=float, default=0.50)
    parser.add_argument("--min-pred-area", type=int, default=0)
    parser.add_argument("--debug-examples", type=int, default=16)
    args = parser.parse_args()

    dataset_root = get_dataset_root(args.dataset_name)
    manifest_path = get_manifest_root(args.dataset_name) / args.manifest_name
    rows = read_csv(manifest_path)
    if args.mode == "full":
        payload = run_full_mode(args, dataset_root, manifest_path, rows)
        metrics_path = get_model_dir("victim_mask") / "victim_full_mask_metrics.json"
        metrics_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        print(json.dumps(payload, indent=2))
        return

    rows = [r for r in rows if is_victim_row(r)]

    records: dict[str, list[tuple[dict[str, str], np.ndarray, np.ndarray, tuple[int, int, int, int]]]] = {
        split: [] for split in SPLITS
    }
    skipped: list[str] = []
    for row in rows:
        mask_path = resolve_mask(dataset_root, row)
        image_path = resolve_image(dataset_root, row)
        if mask_path is None or not image_path.exists():
            skipped.append(row["image_path"])
            continue
        image = load_rgb(image_path)
        mask = load_victim_mask(mask_path)
        crop_img, crop_mask, bbox = crop_pair(image, mask, row, args.crop_padding)
        if crop_mask.any():
            records.setdefault(row["split"], []).append((row, crop_img, crop_mask, bbox))

    train_images = [rec[1] for rec in records.get("train", [])]
    train_masks = [rec[2] for rec in records.get("train", [])]
    if not train_images:
        raise RuntimeError("No training crops with masks were found.")

    cfg = TargetMaskRFConfig(
        model_type="extra_trees",
        n_estimators=args.n_estimators,
        max_depth=args.max_depth,
        min_samples_leaf=1,
        pixels_per_class=args.pixels_per_class,
        proba_threshold=args.threshold,
        postprocess=True,
        random_state=42,
    )
    start = time.perf_counter()
    model = TargetMaskRandomForest(cfg).fit(train_images, train_masks)
    fit_s = time.perf_counter() - start

    out_dir = get_model_dir("victim_mask")
    out_dir.mkdir(parents=True, exist_ok=True)
    model_path = model.save(out_dir / "victim_crop_mask_rf.joblib")

    per_example: list[dict[str, object]] = []
    summary: dict[str, dict[str, float]] = {}
    debug_candidates: list[tuple[float, str, np.ndarray, np.ndarray, np.ndarray, tuple[int, int, int, int]]] = []

    for split, split_records in records.items():
        rf_metrics: list[dict[str, float]] = []
        bbox_metrics: list[dict[str, float]] = []
        grabcut_metrics: list[dict[str, float]] = []
        for row, crop_img, crop_mask, bbox in split_records:
            full_image = load_rgb(resolve_image(dataset_root, row))
            mask_path = resolve_mask(dataset_root, row)
            if mask_path is None:
                continue
            full_mask = load_victim_mask(mask_path)

            pred_crop = model.predict_mask(crop_img)
            pred_rf = paste_crop_mask(pred_crop, full_image.shape[:2], bbox)
            pred_bbox = bbox_mask(full_image.shape[:2], bbox)
            pred_grabcut = grabcut_mask(full_image, bbox)

            rf = evaluate_masks(pred_rf, full_mask)
            bb = evaluate_masks(pred_bbox, full_mask)
            gc = evaluate_masks(pred_grabcut, full_mask)
            rf_metrics.append(rf)
            bbox_metrics.append(bb)
            grabcut_metrics.append(gc)
            per_example.append({
                "split": split,
                "image_path": row["image_path"],
                "bbox_iou": bb["iou"],
                "grabcut_iou": gc["iou"],
                "rf_iou": rf["iou"],
                "rf_dice": rf["dice"],
                "rf_precision": rf["precision"],
                "rf_recall": rf["recall"],
            })
            debug_candidates.append((rf["iou"], row["image_path"], full_image, full_mask, pred_rf, bbox))

        summary[split] = {
            "count": float(len(split_records)),
            "bbox_iou": aggregate(bbox_metrics).get("iou", 0.0),
            "grabcut_iou": aggregate(grabcut_metrics).get("iou", 0.0),
            "rf_iou": aggregate(rf_metrics).get("iou", 0.0),
            "rf_dice": aggregate(rf_metrics).get("dice", 0.0),
            "rf_precision": aggregate(rf_metrics).get("precision", 0.0),
            "rf_recall": aggregate(rf_metrics).get("recall", 0.0),
            "rf_boundary_iou": aggregate(rf_metrics).get("boundary_iou", 0.0),
        }

    per_example_path = out_dir / "victim_mask_refinement_examples.csv"
    with per_example_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(per_example[0].keys()))
        writer.writeheader()
        writer.writerows(per_example)

    worst = sorted(debug_candidates, key=lambda item: item[0])[: args.debug_examples]
    for idx, (iou, image_path, image, target, pred, bbox) in enumerate(worst):
        save_debug_panel(
            out_dir / "debug" / f"worst_{idx:02d}.png",
            image,
            target,
            pred,
            bbox,
            f"IoU={iou:.3f} {Path(image_path).name}",
        )

    payload = {
        "mode": "crop",
        "dataset_name": args.dataset_name,
        "manifest": str(manifest_path),
        "crop_padding": args.crop_padding,
        "fit_seconds": fit_s,
        "skipped": skipped[:50],
        "skipped_count": len(skipped),
        "model_path": str(model_path),
        "config": asdict(cfg),
        "summary": summary,
        "per_example_path": str(per_example_path),
        "debug_dir": str(out_dir / "debug"),
    }
    metrics_path = out_dir / "victim_mask_refinement_metrics.json"
    metrics_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
