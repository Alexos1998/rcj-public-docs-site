"""Train + evaluate the Random Forest whole-target mask segmenter.

Mandatory classical baseline for the mask-first CognitiveTarget pipeline. Trains
on the whole-target masks only (never ring masks / texture), evaluates mask IoU /
Dice / precision / recall, runs the radial classifier with both GT and predicted
masks, and writes ``artifacts/target_mask/model_selection.json`` plus debug
overlays. If RF reaches the acceptance IoU the CNN fallback is skipped.

Run with:
    .venv/bin/python notebooks/scripts/train_target_mask_rf.py --dataset-name imagens_larc
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common.target_mask_pipeline import ACCEPTANCE_IOU, run_model_selection
from notebooks.common.target_mask_rf import TargetMaskRFConfig


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="imagens_larc")
    parser.add_argument("--model-type", default="random_forest", choices=("random_forest", "extra_trees"))
    parser.add_argument("--n-estimators", type=int, default=200)
    parser.add_argument("--max-depth", type=int, default=16)
    parser.add_argument("--pixels-per-class", type=int, default=600)
    parser.add_argument("--acceptance-iou", type=float, default=ACCEPTANCE_IOU)
    parser.add_argument("--force-cnn", action="store_true")
    parser.add_argument("--no-overlays", action="store_true")
    args = parser.parse_args()

    config = TargetMaskRFConfig(
        model_type=args.model_type,
        n_estimators=args.n_estimators,
        max_depth=args.max_depth,
        pixels_per_class=args.pixels_per_class,
    )
    report = run_model_selection(
        dataset_name=args.dataset_name,
        rf_config=config,
        acceptance_iou=args.acceptance_iou,
        force_cnn=args.force_cnn,
        save_overlays=not args.no_overlays,
    )

    print("\n=== Mask segmentation (RF) ===")
    for split, m in report["segmentation_metrics"].items():
        print(
            f"  {split:11s} IoU={m['mask_iou']:.4f} Dice={m['mask_dice']:.4f} "
            f"P={m['precision']:.3f} R={m['recall']:.3f} bIoU={m['boundary_iou']:.3f} "
            f"{m['latency_ms_per_image']:.1f}ms/img"
        )
    print("\n=== Radial texture accuracy (GT mask vs RF mask) ===")
    for split in ("train", "validation", "test"):
        print(
            f"  {split:11s} GT={report['gt_mask_radial_texture_accuracy'][split]:.3f} "
            f"RF={report['selected_mask_radial_texture_accuracy'][split]:.3f}"
        )
    print(f"\nselected_mask_model = {report['selected_mask_model']}  (needs_cnn={report['needs_cnn']})")
    print("reason:", report["reason"])
    print("recommended_changes:", json.dumps(report["recommended_changes"], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
