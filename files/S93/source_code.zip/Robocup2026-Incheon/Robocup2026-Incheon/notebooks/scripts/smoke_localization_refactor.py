"""Smoke tests for the localization/optuna refactor.

Run with: .venv/bin/python notebooks/scripts/smoke_localization_refactor.py

Exercises configs, optimizer/scheduler/loss factories, model forward passes,
the circle dataset, ONNX export, and short end-to-end bbox/circle training runs
(2 epochs each, written to timestamped run dirs so real artifacts are untouched).
"""

from __future__ import annotations

import csv
import shutil
import sys
from pathlib import Path

import torch
from torch import nn

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common import optuna_tuning
from notebooks.common.config import get_dataset_root, get_manifest_root
from notebooks.common.datasets import CircleRegressionDataset, detect_circle_schema
from notebooks.common.losses import (
    BBoxShapeLoss,
    CircleLoss,
    GIoULoss,
    SAIoULoss,
    build_bbox_loss,
    build_circle_loss,
)
from notebooks.common.models import LegacyBBoxRegressor, LegacyCircleRegressor
from notebooks.common.optim import build_optimizer, build_scheduler, scheduler_step
from notebooks.common.onnx_export import export_onnx_model
from notebooks.common.train_config import BBoxTrainConfig, CircleTrainConfig
from notebooks.common.training_runs import run_bbox_training, run_circle_training

PASSED: list[str] = []


def check(name: str, condition: bool) -> None:
    status = "PASS" if condition else "FAIL"
    print(f"[{status}] {name}")
    PASSED.append(name) if condition else PASSED.append(f"FAILED:{name}")
    if not condition:
        raise AssertionError(name)


def test_configs() -> None:
    cfg = BBoxTrainConfig.from_dict(
        {"dataset_name": "imagens_larc", "bbox_model_type": "legacy_cnn", "bbox_loss_name": "combined"}
    )
    check("BBoxTrainConfig new fields", cfg.optimizer_name == "adamw" and cfg.scheduler_name == "cosine")
    check("BBoxTrainConfig use_optuna default False", cfg.use_optuna is False)
    circle = CircleTrainConfig.from_dict({"dataset_name": "imagens_larc"})
    check("CircleTrainConfig metric", circle.optuna_metric == "val_circle_iou")


def test_optimizers_schedulers() -> None:
    cfg = BBoxTrainConfig.from_dict({"dataset_name": "x", "epochs": 5})
    model = LegacyBBoxRegressor(input_size=64)
    for name in ("adam", "adamw", "sgd"):
        opt = build_optimizer(model, BBoxTrainConfig.from_dict({"dataset_name": "x", "optimizer_name": name}))
        check(f"optimizer {name}", opt is not None)
    for name in ("none", "cosine", "plateau", "onecycle"):
        c = BBoxTrainConfig.from_dict({"dataset_name": "x", "scheduler_name": name, "epochs": 5})
        opt = build_optimizer(model, c)
        sch = build_scheduler(opt, c, steps_per_epoch=3)
        check(
            f"scheduler {name}",
            (sch is None) == (name == "none") or sch is not None,
        )
        if sch is not None:
            opt.zero_grad(set_to_none=True)
            dummy = sum(parameter.sum() for parameter in model.parameters())
            dummy.backward()
            opt.step()
            scheduler_step(sch, c, metric=0.5)


def test_models_forward() -> None:
    x = torch.randn(4, 3, 64, 64)
    bbox = LegacyBBoxRegressor(input_size=64)(x)
    circle = LegacyCircleRegressor(input_size=64, min_radius=0.02)(x)
    check("LegacyBBoxRegressor [N,4]", tuple(bbox.shape) == (4, 4))
    check("LegacyCircleRegressor [N,3]", tuple(circle.shape) == (4, 3))
    check("circle radius >= min_radius", bool((circle[:, 2] >= 0.02 - 1e-6).all()))


def test_losses() -> None:
    p = torch.tensor([[0.1, 0.1, 0.5, 0.5], [0.2, 0.2, 0.8, 0.8]])
    t = torch.tensor([[0.15, 0.1, 0.55, 0.5], [0.2, 0.2, 0.7, 0.7]])
    check("SAIoULoss scalar", SAIoULoss()(p, t).dim() == 0)
    check("GIoULoss scalar", GIoULoss()(p, t).dim() == 0)
    c = BBoxTrainConfig.from_dict({"dataset_name": "x", "bbox_loss_name": "combined"})
    check("combined bbox loss", build_bbox_loss(c)(p, t).dim() == 0)
    check("BBoxShapeLoss scalar", BBoxShapeLoss()(p, t).dim() == 0)
    sc = BBoxTrainConfig.from_dict({
        "dataset_name": "x", "bbox_loss_name": "shape_combined",
        "shape_size_weight": 1.0, "shape_aspect_weight": 0.5,
    })
    check("shape_combined build_bbox_loss", build_bbox_loss(sc)(p, t).dim() == 0)
    # Narrow-aspect box: w << h, should not crash
    p_narrow = torch.tensor([[0.1, 0.1, 0.2, 0.9]])
    t_narrow = torch.tensor([[0.12, 0.05, 0.18, 0.95]])
    check("BBoxShapeLoss narrow box", BBoxShapeLoss()(p_narrow, t_narrow).dim() == 0)
    cp = torch.tensor([[0.5, 0.5, 0.2], [0.3, 0.3, 0.1]])
    ct = torch.tensor([[0.5, 0.5, 0.25], [0.32, 0.3, 0.12]])
    check("CircleLoss scalar", CircleLoss()(cp, ct).dim() == 0)
    cc = CircleTrainConfig.from_dict({"dataset_name": "x", "circle_loss_name": "combined"})
    check("combined circle loss", build_circle_loss(cc)(cp, ct).dim() == 0)


def test_onnx_export(tmp_dir: Path) -> None:
    bbox_path = tmp_dir / "bbox.onnx"
    circle_path = tmp_dir / "circle.onnx"
    export_onnx_model(LegacyBBoxRegressor(input_size=64), bbox_path, [1, 3, 64, 64],
                      output_names=("bbox",))
    export_onnx_model(LegacyCircleRegressor(input_size=64), circle_path, [1, 3, 64, 64],
                      output_names=("circle",))
    check("bbox onnx file", bbox_path.exists() and bbox_path.stat().st_size > 0)
    check("circle onnx file", circle_path.exists() and circle_path.stat().st_size > 0)


def _make_circle_manifest(dataset_name: str) -> Path:
    bbox_csv = get_manifest_root(dataset_name) / "victim_bbox.csv"
    rows = list(csv.DictReader(bbox_csv.open()))
    out = get_manifest_root(dataset_name) / "target_localization.csv"
    with out.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["split", "image_path", "label", "label_name", "center_x", "center_y", "radius"])
        for row in rows:
            xmin, ymin, xmax, ymax = (float(row[k]) for k in ("xmin", "ymin", "xmax", "ymax"))
            cx = (xmin + xmax) / 2
            cy = (ymin + ymax) / 2
            r = ((xmax - xmin) + (ymax - ymin)) / 4
            writer.writerow([row["split"], row["image_path"], 0, "target", cx, cy, r])
    return out


def test_circle_dataset(dataset_name: str) -> None:
    manifest = get_manifest_root(dataset_name) / "target_localization.csv"
    ds = CircleRegressionDataset(manifest, 64, split="train", dataset_root=get_dataset_root(dataset_name))
    check("circle schema detected", detect_circle_schema(["center_x", "center_y", "radius"]) is not None)
    if len(ds):
        image, target = ds[0]
        check("circle dataset item", tuple(image.shape) == (3, 64, 64) and tuple(target.shape) == (3,))


def test_optuna_requires_install() -> None:
    raised = False
    try:
        optuna_tuning.ensure_optuna()
    except RuntimeError as exc:
        raised = "pip install optuna" in str(exc)
    check("optuna clear error when missing", raised or optuna_tuning.optuna_available())


def test_end_to_end(dataset_name: str) -> None:
    bbox_cfg = BBoxTrainConfig.from_dict(
        {"dataset_name": dataset_name, "bbox_model_type": "legacy_cnn", "epochs": 2,
         "input_size": 64, "batch_size": 32, "output_mode": "timestamped",
         "show_samples": False, "show_training_plots": False}
    )
    result = run_bbox_training(bbox_cfg)
    check("bbox training trained", result.status == "trained")
    check("bbox onnx validated", result.metrics.get("onnx_validation", {}).get("passed"))
    check("bbox history has lr", "lr" in result.history and len(result.history["lr"]) == 2)
    shutil.rmtree(bbox_cfg.artifact_dir, ignore_errors=True)

    circle_cfg = CircleTrainConfig.from_dict(
        {"dataset_name": dataset_name, "circle_model_type": "legacy_cnn", "epochs": 2,
         "input_size": 64, "batch_size": 32, "output_mode": "timestamped",
         "show_samples": False, "show_training_plots": False}
    )
    result = run_circle_training(circle_cfg)
    check("circle training trained", result.status == "trained")
    onnx_val = result.metrics.get("onnx_validation", {})
    check("circle onnx output name+width", onnx_val.get("output_names") == ["circle"]
          and onnx_val.get("output_shape", [None, None])[1] == 3)
    check("circle history has circle_iou", "val_circle_iou" in result.history)
    shutil.rmtree(circle_cfg.artifact_dir, ignore_errors=True)


def main() -> int:
    dataset_name = "imagens_larc"
    tmp_dir = ROOT / "models" / "_smoke_tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    created_manifest: Path | None = None
    try:
        test_configs()
        test_optimizers_schedulers()
        test_models_forward()
        test_losses()
        test_onnx_export(tmp_dir)
        test_optuna_requires_install()
        target_csv = get_manifest_root(dataset_name) / "target_localization.csv"
        if target_csv.exists():
            # Use the real manifest; do not create/delete it.
            test_circle_dataset(dataset_name)
            test_end_to_end(dataset_name)
        elif (get_manifest_root(dataset_name) / "victim_bbox.csv").exists():
            created_manifest = _make_circle_manifest(dataset_name)
            test_circle_dataset(dataset_name)
            test_end_to_end(dataset_name)
        else:
            print("[skip] dataset not available; skipped dataset + end-to-end tests")
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        if created_manifest is not None:
            created_manifest.unlink(missing_ok=True)
    failures = [name for name in PASSED if name.startswith("FAILED:")]
    print(f"\n{len(PASSED) - len(failures)}/{len(PASSED)} checks passed")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
