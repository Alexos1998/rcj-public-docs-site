"""Export the map-geometry RandomForest specialists as OpenCV RTrees .yml for C++.

Mirrors notebooks/scripts/export_controller_runtime_assets.py: each sklearn-trained
specialist is *re-trained* as a ``cv2.ml.RTrees`` on the identical feature matrix and
saved as YAML that ``cv::ml::RTrees::load`` reads natively. Each specialist uses its
own feature set (explored -> patch_features 31; parede -> wall_features 8 on the
rotated patch; curva -> curve_features 87; obstaculo -> obstacle_features 7), which the
C++ mapper reproduces (see controller/.../map_geometry_models.cpp), validated by a
parity test against ``map_parity_reference.yml``.

Outputs into controller/models/:
    map_explorado.yml  map_parede.yml  map_curva.yml  map_obstaculo.yml  (cv::ml::RTrees)
    map_features.yml         (per-task feature schema + patch params for C++ parity)
    map_parity_reference.yml (sample patches -> per-task features + predictions)
    model_manifest.json      (adds a "map_geometry" section)

Run: .venv/bin/python notebooks/scripts/export_map_runtime_models.py
"""

from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common import map_dataset as md  # noqa: E402

CONTROLLER_MODELS = ROOT / "controller" / "models"
RF = md.MapRFConfig(n_estimators=200, max_depth=12, min_samples_leaf=2)
EXPLORED_THR = 0.3
LABEL_SOURCE = "auto"

MODEL_FILES = {
    "explorado": "map_explorado.yml",
    "parede": "map_parede.yml",
    "curva": "map_curva.yml",
    "obstaculo": "map_obstaculo.yml",
}


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _train_rtrees(X: np.ndarray, y: np.ndarray):
    """Train a cv2.ml.RTrees classifier mirroring the vision export hyper-params."""
    import cv2

    X = np.ascontiguousarray(X, dtype=np.float32)
    y = np.ascontiguousarray(y, dtype=np.int32)
    n = X.shape[1]
    var_type = np.array([cv2.ml.VAR_NUMERICAL] * n + [cv2.ml.VAR_CATEGORICAL], np.uint8)
    td = cv2.ml.TrainData_create(X, cv2.ml.ROW_SAMPLE, y, varType=var_type)
    rt = cv2.ml.RTrees_create()
    rt.setMaxDepth(RF.max_depth or 12)
    rt.setMinSampleCount(RF.min_samples_leaf)
    rt.setActiveVarCount(0)  # 0 -> sqrt(n_features), matches sklearn max_features="sqrt"
    rt.setCalculateVarImportance(False)
    rt.setTermCriteria((cv2.TERM_CRITERIA_MAX_ITER + cv2.TERM_CRITERIA_EPS,
                        RF.n_estimators, 1e-3))
    rt.train(td)
    return rt


def _rtrees_predict(rt, X: np.ndarray) -> np.ndarray:
    _, results = rt.predict(np.ascontiguousarray(X, dtype=np.float32))
    return results.ravel().astype(int)


def _build_datasets(subtiles, tiles):
    """Same units/filtering as MapPipeline.from_training (final, all-data models)."""
    aug = md.DEFAULT_AUGMENT
    obs_sub = md.filter_explored(subtiles, EXPLORED_THR)
    obs_tiles = md.filter_explored(tiles, EXPLORED_THR)
    return {
        "explorado": md.build_explored_dataset(subtiles, augment=aug.get("explorado")),
        "parede": md.build_wall_dataset(obs_sub, augment=aug.get("parede")),
        "curva": md.build_curve_dataset(obs_sub, augment=aug.get("curva")),
        "obstaculo": md.build_obstacle_dataset(obs_tiles, augment=aug.get("obstaculo")),
    }


def _feature_names_by_task() -> dict:
    """Per-specialist feature names (resolution-aware set; explored stays global)."""
    return {
        "explorado": list(md.FEATURE_NAMES),       # patch_features (31)
        "parede": list(md.WALL_FEATURE_NAMES),     # map_features.wall_features (8)
        "curva": list(md.CURVE_FEATURE_NAMES),     # map_features.curve_features (87)
        "obstaculo": list(md.OBSTACLE_FEATURE_NAMES),  # map_features.obstacle_features (7)
    }


def _write_feature_schema(path: Path) -> None:
    import cv2

    by_task = _feature_names_by_task()
    lines = [
        "# Occupancy-patch feature schema for the map RTrees models.",
        "# Each specialist uses its OWN feature set; the C++ mapper",
        "# (map_geometry_models.cpp) must reproduce each one exactly.",
        "feature_schema:",
        f"  half_extent_m: {md.SUBTILE_M}        # subtile and tile both crop a 0.12 m window",
        f"  tile_size_m: {md.TILE_SIZE_M}",
        f"  quarter_offset_m: {md.QUARTER_OFFSET_M}",
        "  free_thresh: 25          # cell <= 25 -> free",
        "  occ_thresh: 65           # cell >= 65 -> occupied",
        "  unknown: \"value < 0\"",
        "  patch: \"north-up; row0=north, col0=west; out-of-bounds = -1\"",
        "  subtile_band: \"[0.25, 0.75] of the patch (SUB_LO, SUB_HI)\"",
        "  margins: {parede: 0.08, curva: 0.10, obstaculo: 0.20}",
        "  grad_mean: \"np.gradient over (unk?0:v/100); mean of sqrt(gx^2+gy^2)\"",
        "  wall_rotation: \"rot90 CCW; edge order N,E,S,W -> k=0,1,2,3 (target edge to north)\"",
        f"  curve_labels: {list(md.CURVE_LABELS)}",
        f"  curve_polar: {{nr: {6}, na: {12}}}  # 6 radius x 12 angle bins (72)",
        "  num_features:",
    ]
    for task, names in by_task.items():
        lines.append(f"    {task}: {len(names)}")
    lines.append("  feature_names:")
    for task, names in by_task.items():
        lines.append(f"    {task}:")
        for i, name in enumerate(names):
            lines.append(f"      - {{index: {i}, name: \"{name}\"}}")
    lines += [
        "  models:",
        "    explorado: \"map_explorado.yml\"   # gate: 1=observed (patch_features, 31)",
        "    parede: \"map_parede.yml\"         # per rotated patch: 1=wall on north edge (8)",
        "    curva: \"map_curva.yml\"           # 0=none,1=SW,2=NW,3=NE,4=SE (87)",
        "    obstaculo: \"map_obstaculo.yml\"   # per TILE: 1=obstacle (7)",
        f"  opencv_version: \"{cv2.__version__}\"",
        "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")


def _write_parity_reference(path: Path, models: dict, subtiles, tiles,
                            n_sub: int = 16, n_tile: int = 8) -> None:
    """cv::FileStorage reference: patches + expected PER-TASK features + RAW labels.

    Each specialist uses its own feature set (explored -> patch_features 31;
    parede -> wall_features 8 on the rotated patch; curva -> curve_features 87;
    obstaculo -> obstacle_features 7). Predictions are ungated (per-model) so the
    C++ test validates feature parity + each model's predict() independently of
    the pipeline's gating logic.
    """
    import cv2

    wm = md.DEFAULT_MARGINS["parede"]
    cm = md.DEFAULT_MARGINS["curva"]
    om = md.DEFAULT_MARGINS["obstaculo"]

    rng = np.random.default_rng(7)
    rich = [s for s in subtiles if any(s.real.walls.values()) or s.real.curve]
    pick_sub = list(rng.choice(rich, min(n_sub - 4, len(rich)), replace=False)) + \
        list(rng.choice(subtiles, 4, replace=False))
    rich_t = [t for t in tiles if t.obstacle]
    pick_tile = list(rich_t[:n_tile // 2]) + \
        list(rng.choice(tiles, max(0, n_tile - len(rich_t[:n_tile // 2])), replace=False))

    fs = cv2.FileStorage(str(path), cv2.FILE_STORAGE_WRITE)
    fs.write("n_sub", len(pick_sub))
    fs.write("n_tile", len(pick_tile))
    for i, s in enumerate(pick_sub):
        efeat = md.patch_features(s.patch).astype(np.float32)        # explored (31)
        cfeat = md.curve_features(s.patch, cm).astype(np.float32)    # curve (87)
        wfeat = np.stack([md.wall_features(md._rot_for_dir(s.patch, d), wm)
                          for d in md.DIRS]).astype(np.float32)      # (4, 8)
        walls = np.array([int(_rtrees_predict(models["parede"], wfeat[j][None, :])[0])
                          for j in range(4)], np.int32)
        fs.write(f"sub_{i}_patch", s.patch.astype(np.int16))
        fs.write(f"sub_{i}_efeat", efeat.reshape(1, -1))
        fs.write(f"sub_{i}_cfeat", cfeat.reshape(1, -1))
        fs.write(f"sub_{i}_wfeat", wfeat)
        fs.write(f"sub_{i}_explored", int(_rtrees_predict(models["explorado"], efeat[None, :])[0]))
        fs.write(f"sub_{i}_curve", int(_rtrees_predict(models["curva"], cfeat[None, :])[0]))
        fs.write(f"sub_{i}_walls", walls.reshape(1, -1))
    for i, t in enumerate(pick_tile):
        ofeat = md.obstacle_features(t.patch, om).astype(np.float32)  # obstacle (7)
        fs.write(f"tile_{i}_patch", t.patch.astype(np.int16))
        fs.write(f"tile_{i}_ofeat", ofeat.reshape(1, -1))
        fs.write(f"tile_{i}_obstacle", int(_rtrees_predict(models["obstaculo"], ofeat[None, :])[0]))
    fs.release()


def generate() -> dict:
    CONTROLLER_MODELS.mkdir(parents=True, exist_ok=True)
    print("loading runs ...")
    subtiles = md.load_all_subtiles(label_source=LABEL_SOURCE)
    tiles = md.load_all_tiles(label_source=LABEL_SOURCE)
    assert subtiles and tiles, "no runs found in controller/mapsdataset/runs/"
    print(f"  {len(subtiles)} subtiles | {len(tiles)} tiles")

    datasets = _build_datasets(subtiles, tiles)
    models, metrics = {}, {}
    for name, ds in datasets.items():
        rt = _train_rtrees(ds.X, ds.y)
        path = CONTROLLER_MODELS / MODEL_FILES[name]
        rt.save(str(path))
        models[name] = rt
        sk_cv = md.train_rf(ds, RF)["metrics"]["cv_accuracy"]      # sklearn LOO-CV (reference)
        rt_resub = float((_rtrees_predict(rt, ds.X) == ds.y).mean())  # RTrees sanity
        metrics[name] = {"sklearn_cv_accuracy": sk_cv, "rtrees_resub_accuracy": rt_resub,
                         "n_samples": int(len(ds)), "labels": list(ds.labels)}
        print(f"  {name:10s} sklearn_cv={sk_cv!r} rtrees_resub={rt_resub:.4f} -> {path.name}")

    feats_path = CONTROLLER_MODELS / "map_features.yml"
    _write_feature_schema(feats_path)

    parity_path = CONTROLLER_MODELS / "map_parity_reference.yml"
    _write_parity_reference(parity_path, models, subtiles, tiles)

    # Merge into the existing manifest (keep vision sections intact).
    manifest_path = CONTROLLER_MODELS / "model_manifest.json"
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
    manifest["map_geometry"] = {
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "feature_config": "map_features.yml",
        "feature_config_sha256": _sha256(feats_path),
        "parity_reference": "map_parity_reference.yml",
        "num_features": {name: len(names) for name, names in _feature_names_by_task().items()},
        "models": {
            name: {"file": MODEL_FILES[name], "type": "opencv_ml_rtrees",
                   "num_features": len(_feature_names_by_task()[name]),
                   "sha256": _sha256(CONTROLLER_MODELS / MODEL_FILES[name]),
                   "metrics": metrics[name]}
            for name in MODEL_FILES
        },
    }
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print(f"wrote {feats_path.name}, {parity_path.name}, model_manifest.json")
    return manifest


if __name__ == "__main__":
    generate()
