"""Build localization manifests with explicit negative rows.

The legacy manifests train victim and target localizers only on positives. That
works in notebooks, but in runtime a branch can be entered after a wrong
presence/type decision and the localizer has no learned "nothing here" output.

This script keeps the original manifests intact and writes alternate manifests:

* victim_bbox_with_none.csv: victim positives + none/target negatives as a tiny bbox
* victim_classification_with_none.csv: H/S/U positives + none/target negatives
* target_localization_with_none.csv: target positives + none/victim negatives as a tiny circle
"""

from __future__ import annotations

import argparse
import csv
import sys
from collections import Counter
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from notebooks.common.config import get_manifest_root


TINY_BBOX = {
    "xmin": "0.484375",
    "ymin": "0.484375",
    "xmax": "0.515625",
    "ymax": "0.515625",
}
TINY_CIRCLE = {
    "center_x": "0.500000",
    "center_y": "0.500000",
    "radius": "0.015625",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open("r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def image_key(row: dict[str, str]) -> tuple[str, str]:
    return row["split"], row["image_path"]


def dedupe(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    seen: set[tuple[str, str]] = set()
    out: list[dict[str, str]] = []
    for row in rows:
        key = image_key(row)
        if key in seen:
            continue
        seen.add(key)
        out.append(row)
    return out


def build_victim_bbox(victim_bbox: list[dict[str, str]],
                      target_loc: list[dict[str, str]],
                      presence: list[dict[str, str]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for row in victim_bbox:
        rows.append({
            "split": row["split"],
            "image_path": row["image_path"],
            "label": "1",
            "label_name": "victim",
            "negative_source": "",
            "xmin": row["xmin"],
            "ymin": row["ymin"],
            "xmax": row["xmax"],
            "ymax": row["ymax"],
        })
    for row in target_loc:
        rows.append({
            "split": row["split"],
            "image_path": row["image_path"],
            "label": "0",
            "label_name": "none",
            "negative_source": "target",
            **TINY_BBOX,
        })
    for row in presence:
        if row.get("label_name") != "none":
            continue
        rows.append({
            "split": row["split"],
            "image_path": row["image_path"],
            "label": "0",
            "label_name": "none",
            "negative_source": "none",
            **TINY_BBOX,
        })
    return dedupe(rows)


def build_victim_classification(victim_cls: list[dict[str, str]],
                                target_loc: list[dict[str, str]],
                                presence: list[dict[str, str]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for row in victim_cls:
        rows.append({
            "split": row["split"],
            "image_path": row["image_path"],
            "label": row["label"],
            "label_name": row["label_name"],
            "negative_source": "",
        })
    for row in target_loc:
        rows.append({
            "split": row["split"],
            "image_path": row["image_path"],
            "label": "3",
            "label_name": "none",
            "negative_source": "target",
        })
    for row in presence:
        if row.get("label_name") != "none":
            continue
        rows.append({
            "split": row["split"],
            "image_path": row["image_path"],
            "label": "3",
            "label_name": "none",
            "negative_source": "none",
        })
    return dedupe(rows)


def build_target_localization(target_loc: list[dict[str, str]],
                              victim_bbox: list[dict[str, str]],
                              presence: list[dict[str, str]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for row in target_loc:
        rows.append({
            "split": row["split"],
            "image_path": row["image_path"],
            "label": "1",
            "label_name": "target",
            "negative_source": "",
            "center_x": row["center_x"],
            "center_y": row["center_y"],
            "radius": row["radius"],
        })
    for row in victim_bbox:
        rows.append({
            "split": row["split"],
            "image_path": row["image_path"],
            "label": "0",
            "label_name": "none",
            "negative_source": "victim",
            **TINY_CIRCLE,
        })
    for row in presence:
        if row.get("label_name") != "none":
            continue
        rows.append({
            "split": row["split"],
            "image_path": row["image_path"],
            "label": "0",
            "label_name": "none",
            "negative_source": "none",
            **TINY_CIRCLE,
        })
    return dedupe(rows)


def summarize(name: str, rows: list[dict[str, str]]) -> str:
    labels = Counter(row["label_name"] for row in rows)
    sources = Counter(row.get("negative_source", "") or "positive" for row in rows)
    return f"{name}: {len(rows)} rows labels={dict(labels)} sources={dict(sources)}"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-name", default="imagens_larc")
    args = parser.parse_args()

    root = get_manifest_root(args.dataset_name)
    victim_bbox = read_csv(root / "victim_bbox.csv")
    victim_cls = read_csv(root / "victim_classification.csv")
    target_loc = read_csv(root / "target_localization.csv")
    presence = read_csv(root / "presence.csv")

    victim_bbox_rows = build_victim_bbox(victim_bbox, target_loc, presence)
    victim_cls_rows = build_victim_classification(victim_cls, target_loc, presence)
    target_loc_rows = build_target_localization(target_loc, victim_bbox, presence)

    write_csv(
        root / "victim_bbox_with_none.csv",
        ["split", "image_path", "label", "label_name", "negative_source", "xmin", "ymin", "xmax", "ymax"],
        victim_bbox_rows,
    )
    write_csv(
        root / "victim_classification_with_none.csv",
        ["split", "image_path", "label", "label_name", "negative_source"],
        victim_cls_rows,
    )
    write_csv(
        root / "target_localization_with_none.csv",
        ["split", "image_path", "label", "label_name", "negative_source", "center_x", "center_y", "radius"],
        target_loc_rows,
    )

    print(summarize("victim_bbox_with_none.csv", victim_bbox_rows))
    print(summarize("victim_classification_with_none.csv", victim_cls_rows))
    print(summarize("target_localization_with_none.csv", target_loc_rows))


if __name__ == "__main__":
    main()
