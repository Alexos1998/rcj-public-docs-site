"""Train the fused none/target/victim classifier and compare it against the
existing two-stage presence(none/object) -> object_type(target/victim) chain.

Run from the repo root:
    python notebooks/scripts/train_object_presence_fused.py --epochs 25

Outputs:
    notebooks/models/object_presence/object_presence.onnx (+ metadata/metrics)
    A side-by-side test-split accuracy table (fused vs. chained baseline).
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import cv2
import numpy as np
import onnxruntime as ort


def find_project_root(start: Path) -> Path:
    for path in (start, *start.parents):
        if (path / "notebooks" / "common").exists():
            return path
    raise RuntimeError("Could not find project root.")


PROJECT_ROOT = find_project_root(Path(__file__).resolve())
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from notebooks.common.config import ensure_notebook_dirs  # noqa: E402
from notebooks.common.train_config import ClassificationTrainConfig  # noqa: E402
from notebooks.common.training_runs import run_classification_training  # noqa: E402

FUSED_LABELS = ["none", "target", "victim"]
MANIFEST_DIR = PROJECT_ROOT / "notebooks" / "data" / "manifests" / "imagens_larc"
DATASET_ROOT = PROJECT_ROOT / "notebooks" / "data" / "extracted" / "imagens_larc"
CONTROLLER_MODELS = PROJECT_ROOT / "controller" / "models"


# --------------------------------------------------------------------------- #
# Baseline: run the two existing ONNX models chained on the fused test split.
# --------------------------------------------------------------------------- #
def _preprocess(img_bgr: np.ndarray, size: int, mean, std) -> np.ndarray:
    resized = cv2.resize(img_bgr, (size, size), interpolation=cv2.INTER_LINEAR)
    rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    rgb = (rgb - np.array(mean, np.float32)) / np.array(std, np.float32)
    return rgb.transpose(2, 0, 1)[None, ...].astype(np.float32)


def _softmax_argmax(logits: np.ndarray) -> int:
    return int(np.argmax(logits.ravel()))


def _load_meta(name: str):
    import json

    meta = json.load((CONTROLLER_MODELS / f"{name}.metadata.json").open())
    size = int(meta["input_shape"][-1])
    return size, meta["mean"], meta["std"], meta["labels"]


def evaluate_chained_baseline(test_rows: list[dict]) -> dict:
    p_size, p_mean, p_std, p_labels = _load_meta("presence")
    t_size, t_mean, t_std, t_labels = _load_meta("object_type")
    presence = ort.InferenceSession(str(CONTROLLER_MODELS / "presence.onnx"))
    otype = ort.InferenceSession(str(CONTROLLER_MODELS / "object_type.onnx"))
    p_in = presence.get_inputs()[0].name
    t_in = otype.get_inputs()[0].name

    correct = 0
    per_class = {c: [0, 0] for c in FUSED_LABELS}  # [correct, total]
    for row in test_rows:
        img = cv2.imread(str(DATASET_ROOT / "train" / row["image_path"]))
        if img is None:
            # split subdir depends on manifest; try test/validation dirs too
            for sub in ("test", "validation", "train"):
                cand = DATASET_ROOT / sub / row["image_path"]
                if cand.exists():
                    img = cv2.imread(str(cand))
                    break
        if img is None:
            continue
        gt = row["label_name"]
        p_logits = presence.run(None, {p_in: _preprocess(img, p_size, p_mean, p_std)})[0]
        p_idx = _softmax_argmax(p_logits)
        if p_labels[p_idx] == "none":
            pred = "none"
        else:
            t_logits = otype.run(None, {t_in: _preprocess(img, t_size, t_mean, t_std)})[0]
            pred = t_labels[_softmax_argmax(t_logits)]
        per_class[gt][1] += 1
        if pred == gt:
            correct += 1
            per_class[gt][0] += 1
    total = sum(v[1] for v in per_class.values())
    return {
        "overall": correct / total if total else 0.0,
        "total": total,
        "per_class": {c: (v[0] / v[1] if v[1] else 0.0, v[1]) for c, v in per_class.items()},
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=25)
    parser.add_argument("--input-size", type=int, default=48)
    parser.add_argument("--base-channels", type=int, default=24)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--lr", type=float, default=0.001)
    args = parser.parse_args()

    ensure_notebook_dirs()

    config = {
        "dataset_name": "imagens_larc",
        "input_size": args.input_size,
        "batch_size": args.batch_size,
        "epochs": args.epochs,
        "learning_rate": args.lr,
        "weight_decay": 0.0001,
        "num_workers": 0,
        "dropout": 0.08,
        "base_channels": args.base_channels,
        "seed": 42,
        "device": "auto",
        "output_mode": "timestamped",
        "augment": True,
        "update_latest": False,
    }
    cfg = ClassificationTrainConfig.from_dict(
        config,
        task_name="object_presence",
        labels=FUSED_LABELS,
        manifest_filename="object_presence.csv",
        checkpoint_name="object_presence_best.pt",
        onnx_name="object_presence.onnx",
        model_dir_name="object_presence",
    )

    print("=== training fused object_presence (none/target/victim) ===")
    result = run_classification_training(cfg)
    print("status:", result.status)
    payload = result.to_dict()
    fused_eval = payload.get("eval_metrics") or {}
    fused_acc = fused_eval.get("accuracy")
    print("fused onnx:", cfg.onnx_path)

    # --- Baseline comparison on the same test split ---
    with (MANIFEST_DIR / "object_presence.csv").open(newline="") as handle:
        rows = [r for r in csv.DictReader(handle) if r["split"] == "test"]
    print("\n=== chained baseline (presence -> object_type) on test split ===")
    baseline = evaluate_chained_baseline(rows)

    print("\n================ COMPARISON (test split) ================")
    print(f"fused 3-class accuracy   : {fused_acc}")
    print(f"chained baseline accuracy: {baseline['overall']:.4f}  (n={baseline['total']})")
    print("per-class (baseline):")
    for c, (acc, n) in baseline["per_class"].items():
        print(f"  {c:<7}: {acc:.4f}  (n={n})")
    print("metrics json:", cfg.metrics_path)


if __name__ == "__main__":
    main()
