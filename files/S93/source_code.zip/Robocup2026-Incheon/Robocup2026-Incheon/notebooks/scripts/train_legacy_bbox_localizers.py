#!/usr/bin/env python3
"""Train legacy-CNN ONNX bbox localizers for victim and target."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common.train_config import BBoxTrainConfig
from notebooks.common.training_runs import run_bbox_training
from notebooks.scripts.export_legacy_bbox_localization_manifests import generate


def _bbox_cfg(
    *,
    task_name: str,
    labels: list[str],
    manifest_filename: str,
    model_dir_name: str,
    checkpoint_name: str,
    onnx_name: str,
    args: argparse.Namespace,
) -> BBoxTrainConfig:
    return BBoxTrainConfig(
        task_name=task_name,
        dataset_name=args.dataset_name,
        labels=labels,
        manifest_filename=manifest_filename,
        input_size=args.input_size,
        batch_size=args.batch_size,
        epochs=args.epochs,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        num_workers=args.num_workers,
        dropout=args.dropout,
        base_channels=args.base_channels,
        seed=args.seed,
        augment=True,
        augment_brightness=args.augment_brightness,
        augment_contrast=args.augment_contrast,
        optimizer_name="adamw",
        scheduler_name="cosine",
        device=args.device,
        output_mode="timestamped",
        update_latest=True,
        model_dir_name=model_dir_name,
        checkpoint_name=checkpoint_name,
        onnx_name=onnx_name,
        bbox_model_type="legacy_cnn",
        bbox_loss_name="combined",
        combined_saiou_weight=args.combined_saiou_weight,
        combined_smooth_l1_weight=args.combined_smooth_l1_weight,
        use_optuna=args.optuna_trials > 0,
        optuna_n_trials=args.optuna_trials,
        optuna_epochs=args.optuna_epochs,
        optuna_timeout=args.optuna_timeout,
        optuna_metric="val_mean_iou",
        optuna_direction="maximize",
        optuna_final_train=True,
        optuna_input_size_choices=(args.input_size,),
        optuna_batch_size_choices=(args.batch_size,),
        show_samples=False,
        show_training_plots=True,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="imagens_larc")
    parser.add_argument("--which", choices=("both", "victim", "target"), default="both")
    parser.add_argument("--epochs", type=int, default=160)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--input-size", type=int, default=96)
    parser.add_argument("--base-channels", type=int, default=48)
    parser.add_argument("--dropout", type=float, default=0.10)
    parser.add_argument("--learning-rate", type=float, default=0.001)
    parser.add_argument("--weight-decay", type=float, default=0.0001)
    parser.add_argument("--combined-saiou-weight", type=float, default=1.0)
    parser.add_argument("--combined-smooth-l1-weight", type=float, default=0.25)
    parser.add_argument("--augment-brightness", type=float, default=0.10)
    parser.add_argument("--augment-contrast", type=float, default=0.15)
    parser.add_argument("--optuna-trials", type=int, default=0)
    parser.add_argument("--optuna-epochs", type=int, default=60)
    parser.add_argument("--optuna-timeout", type=int, default=None)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    generate(args.dataset_name)

    results = []
    if args.which in {"both", "victim"}:
        results.append(
            run_bbox_training(
                _bbox_cfg(
                    task_name="victim_bbox",
                    labels=["none", "victim"],
                    manifest_filename="victim_bbox_legacy_balanced.csv",
                    model_dir_name="victim",
                    checkpoint_name="victim_bbox_best.pt",
                    onnx_name="victim_bbox.onnx",
                    args=args,
                )
            )
        )

    if args.which in {"both", "target"}:
        results.append(
            run_bbox_training(
                _bbox_cfg(
                    task_name="target_bbox",
                    labels=["none", "target"],
                    manifest_filename="target_bbox_legacy_balanced.csv",
                    model_dir_name="target",
                    checkpoint_name="target_bbox_best.pt",
                    onnx_name="target_bbox.onnx",
                    args=args,
                )
            )
        )

    print("\ntrained localizers:")
    for result in results:
        print(f"- {result.config.task_name}: best={result.best_metric:.4f}")
        print(f"  onnx={result.onnx_path}")
        print(f"  metrics={result.metrics_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
