"""Build the fused none/target/victim classification manifest.

Fuses the two staged manifests into a single 3-class task so one model can
replace the presence (none/object) + object_type (target/victim) chain:

    none    <- presence.csv rows labelled 'none'
    target  <- object_type.csv rows labelled 'target'
    victim  <- object_type.csv rows labelled 'victim'

Splits are preserved from the source manifests. The integer ``label`` column is
rewritten to match the fused label order [none, target, victim] = [0, 1, 2].
"""

from __future__ import annotations

import csv
import sys
from pathlib import Path

FUSED_LABELS = ["none", "target", "victim"]
LABEL_TO_INDEX = {name: i for i, name in enumerate(FUSED_LABELS)}


def _read(path: Path) -> list[dict[str, str]]:
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def build(manifest_dir: Path) -> Path:
    presence = _read(manifest_dir / "presence.csv")
    object_type = _read(manifest_dir / "object_type.csv")

    rows: list[dict[str, str]] = []
    for row in presence:
        if row["label_name"] == "none":
            rows.append(row | {"label_name": "none"})
    for row in object_type:
        if row["label_name"] in ("target", "victim"):
            rows.append(dict(row))

    out_rows = []
    for row in rows:
        name = row["label_name"]
        out_rows.append(
            {
                "split": row["split"],
                "image_path": row["image_path"],
                "label": str(LABEL_TO_INDEX[name]),
                "label_name": name,
            }
        )

    out_path = manifest_dir / "object_presence.csv"
    with out_path.open("w", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=["split", "image_path", "label", "label_name"]
        )
        writer.writeheader()
        writer.writerows(out_rows)

    # Report distribution.
    from collections import Counter

    by_split = Counter((r["split"], r["label_name"]) for r in out_rows)
    print(f"wrote {out_path} ({len(out_rows)} rows)")
    for key in sorted(by_split):
        print(f"  {key[0]:>10} / {key[1]:<7}: {by_split[key]}")
    return out_path


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    manifest_dir = root / "data" / "manifests" / "imagens_larc"
    if len(sys.argv) > 1:
        manifest_dir = Path(sys.argv[1])
    build(manifest_dir)
