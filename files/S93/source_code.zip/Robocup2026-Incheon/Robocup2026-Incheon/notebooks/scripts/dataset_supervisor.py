# -*- coding: utf-8 -*-
import sys

sys.stdout.reconfigure(encoding="utf-8")

# ────────────────────────────────────────────────────────────────
#
# DEPENDÊNCIAS
#
# ────────────────────────────────────────────────────────────────

import json
from pathlib import Path
import random
import traceback
import hashlib
import shutil
from controller import Supervisor
from tqdm import tqdm  # type: ignore
import math
import logging
import numpy as np  # type: ignore
from itertools import product
import cv2  # type: ignore

# ────────────────────────────────────────────────────────────────
#
# CONFIGURAÇÕES INICIAIS
#
# ────────────────────────────────────────────────────────────────

RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

TRAIN_SPLIT, TEST_SPLIT, VALID_SPLIT = 0.65, 0.25, 0.1
if not math.isclose(TRAIN_SPLIT + TEST_SPLIT + VALID_SPLIT, 1.0, rel_tol=1e-5):
    raise ValueError("As proporções de divisão devem somar 1.0")

# ── Tipos por PROTO ──────────────────────────────────────────────
VICTIM_TYPES = ["harmed", "unharmed", "stable"]
COLORS = ["K", "R", "Y", "G", "B"]  # 5 cores do CognitiveTarget

# Cores visuais das faces do CognitiveTarget
APP_COLOR_MAP = {
    "K": (0.0, 0.0, 0.0),
    "R": (1.0, 0.0, 0.0),
    "Y": (1.0, 1.0, 0.0),
    "G": (0.0, 1.0, 0.0),
    "B": (0.0, 0.0, 1.0),
}

# Mapeamento das cores de reconhecimento do PROTO
SEGMENT_LABELS = {
    (255, 0, 0): 0,  # center
    (0, 255, 0): 1,  # ring2
    (0, 0, 255): 2,  # ring3
    (255, 255, 0): 3,  # ring4
    (255, 0, 255): 4,  # ring5
}

N_COGNITIVE = 5  # amostras aleatórias por posição

# Todas as combinações possíveis das 5 cores (5^5 = 3125) — usadas para amostrar
ALL_COGNITIVE_TEXTURES = ["".join(p) for p in product(COLORS, repeat=5)]

CONTROLLER_DIR = Path(__file__).parent.resolve()
ROOT_DIR = CONTROLLER_DIR / "imagens_larc"
ROOT_DIR.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    filename=(ROOT_DIR / "dataset_generator.log"),
    filemode="w",
    level=logging.INFO,
    format="%(asctime)s %(levelname)s: %(message)s",
)

# ── Configurações específicas por modo ──────────────────────────
MODE_CONFIG = {
    "victim": {
        "json": "imgs_pos_victim.json",
        "classes": ["harmed", "unharmed", "stable", "none"],
        "description": "Vítimas (harmed/unharmed/stable) + none",
    },
    "target": {
        "json": "imgs_pos_target.json",
        "classes": ["cognitive"],
        "description": "Apenas CognitiveTargets com texturas aleatórias",
    },
    "obstacle": {
        "json": "imgs_pos_obstacle.json",
        "classes": ["obstacle"],
        "description": "Obstáculos com dimensões e cores aleatórias",
    },
}
# ────────────────────────────────────────────────────────────────
#
# SELEÇÃO DE MODO
#
# ────────────────────────────────────────────────────────────────
#
# IMPORTANTE:
# Não use input() em controller Webots.
# input() pode bloquear o controller antes de Supervisor/câmera iniciarem.
#
# Como escolher:
#   1) Edite DEFAULT_CHOICE para '1', '2' ou '3'; ou
#   2) Passe argumento na execução:
#        python dataset_supervisor.py 1
#        python dataset_supervisor.py 2
#        python dataset_supervisor.py 3
#
# Mapeamento:
#   '1' -> victim
#   '2' -> target
#   '3' -> obstacle

DEFAULT_CHOICE = "1"  # altere aqui: '1' victim, '2' target, '3' obstacle


def select_mode():
    mode_map = {
        "1": "victim",
        "2": "target",
        "3": "obstacle",
    }

    print()
    print("=" * 60)
    print("GERADOR DE DATASET")
    print("=" * 60)
    print()
    print("Tipo de dataset:")
    print("1 - victim")
    print("2 - target")
    print("3 - obstacle")
    print("=" * 60)

    if len(sys.argv) > 1 and sys.argv[1].strip() in mode_map:
        choice = sys.argv[1].strip()
        print()
        print(f"✓ Modo recebido por argumento: {choice}")
    else:
        choice = DEFAULT_CHOICE
        print()
        print(f"✓ Modo definido por DEFAULT_CHOICE: {choice}")

    if choice not in mode_map:
        raise ValueError(
            "Opção inválida. Use '1', '2' ou '3' em DEFAULT_CHOICE ou argv."
        )

    return mode_map[choice]


MODE = select_mode()
config = MODE_CONFIG[MODE]
JSON_PATH = CONTROLLER_DIR / config["json"]

print()
print(f"✓ Modo selecionado: {MODE.upper()}")
print(f"✓ Descrição: {config['description']}")
print(f"✓ Arquivo JSON: {JSON_PATH}")

CLASSES = config["classes"]

DATA_DIRS = {s: ROOT_DIR / s for s in ("train", "test", "validation")}


def _sanitize_token(value):
    text = str(value).strip().lower()
    clean = []
    for char in text:
        if char.isalnum() or char in ("-", "_"):
            clean.append(char)
        else:
            clean.append("_")
    return "".join(clean).strip("_") or "item"


def _mode_classes_for_cleanup():
    if MODE == "victim":
        return ["harmed", "unharmed", "stable", "none"]
    if MODE == "target":
        return ["cognitive"]
    return CLASSES


def _reset_mode_output_dirs():
    """Clear only the classes generated by the active mode.

    This keeps the dataset root relative to the script, while preventing reruns
    of one mode from silently mixing stale files into training manifests.
    """

    for split_dir in DATA_DIRS.values():
        for cls in _mode_classes_for_cleanup():
            class_dir = split_dir / cls
            if class_dir.exists():
                shutil.rmtree(class_dir)
            (class_dir / "images").mkdir(parents=True, exist_ok=True)
            (class_dir / "masks").mkdir(parents=True, exist_ok=True)


for path in DATA_DIRS.values():
    path.mkdir(parents=True, exist_ok=True)
    for cls in CLASSES:
        (path / cls / "images").mkdir(parents=True, exist_ok=True)
        (path / cls / "masks").mkdir(parents=True, exist_ok=True)

_reset_mode_output_dirs()

# ────────────────────────────────────────────────────────────────
#
# WEBOTS — INICIALIZAÇÃO
#
# ────────────────────────────────────────────────────────────────

sup = Supervisor()
print("Controller iniciado")

timestep = int(sup.getBasicTimeStep())
print("Timestep:", timestep)

cam = sup.getDevice("camera1")
FOV_MAX = 1.50
cam.setFov(FOV_MAX)
if cam is None:
    raise RuntimeError("Câmera 'camera1' não encontrada.")
cam.enable(timestep)
cam.recognitionEnable(timestep)
cam.enableRecognitionSegmentation()
H, W = cam.getHeight(), cam.getWidth()
print("Câmera inicializada")
print("Resolução:", W, "x", H)

robot = sup.getSelf() or sup.getFromDef("ROBOT0")
if robot:
    translation_field = robot.getField("translation")
    rotation_field = robot.getField("rotation")
    initial_position = list(translation_field.getSFVec3f())
    initial_rotation = list(rotation_field.getSFRotation())
    logging.info("Posição inicial do robô salva.")
else:
    logging.warning("Nó do robô não encontrado.")

img_number = 0

# ────────────────────────────────────────────────────────────────
#
# CARREGAMENTO DE CENA
#
# ────────────────────────────────────────────────────────────────

print("\n" + "-" * 60)
print("INICIALIZANDO CENA")
print("-" * 60)

# Randomiza cores das paredes
try:
    print("Randomizando cores das paredes...")
    wall_field = sup.getFromDef("WALLTILES").getField("children")
    for i in range(wall_field.getCount()):
        tile = wall_field.getMFNode(i)
        if random.random() > 0.6:
            rr, rg, rb = (round(random.random(), 3) for _ in range(3))
            r = 1 if rr > 0.5 else (0.5 if rr > 0.3 else 0)
            g = 1 if rg > 0.7 else (0.5 if rg > 0.6 else 0)
            b = 1 if rb > 0.7 else (0.5 if rb > 0.6 else 0)
        else:
            r = g = b = 0.635
        tile.getField("tileColor").setSFColor([r, g, b])
        sup.step(timestep)
    logging.info("Cores das paredes randomizadas.")
    print("Randomização das paredes finalizada")
except Exception as e:
    logging.error(f"Erro em WALLTILES: {e}")

# Carrega Victims
nodesDict = {}
human_meta = []

if MODE in ("victim", "target"):
    try:
        human_field = sup.getFromDef("HUMANGROUP").getField("children")
        for i in range(human_field.getCount()):
            node = human_field.getMFNode(i)
            if node.getTypeName() != "Victim":
                continue
            name = node.getField("name").getSFString()
            human_meta.append(
                {
                    "name": name,
                    "type": node.getField("type").getSFString(),
                    "position": node.getField("translation").getSFVec3f(),
                    "rotation": node.getField("rotation").getSFRotation(),
                    "found": node.getField("found").getSFBool(),
                }
            )
            nodesDict[name] = node
        logging.info(f"{len(human_meta)} Victims carregados.")
        print("Victims carregados:", len(human_meta))
    except Exception as e:
        logging.error(f"Erro ao carregar HUMANGROUP: {e}")
else:
    try:
        obstacle_field = sup.getFromDef("OBSTACLES").getField("children")
        for i in range(obstacle_field.getCount()):
            node = obstacle_field.getMFNode(i)
            name = node.getField("id").getSFString()
            human_meta.append(
                {
                    "name": name,
                    "position": node.getField("translation").getSFVec3f(),
                    "rotation": node.getField("rotation").getSFRotation(),
                    "node": node,
                }
            )
            nodesDict[name] = node
        logging.info(f"{len(human_meta)} Obstáculos carregados.")
        print("Obstáculos carregados:", len(human_meta))
    except Exception as e:
        logging.error(f"Erro ao carregar OBSTACLES: {e}")


# Carrega posições de câmera
def load_camera_positions(path):
    try:
        with open(path) as f:
            data = json.load(f)
        logging.info(f"{len(data)} entradas carregadas de {path}")
        return data
    except Exception as e:
        logging.error(f"Erro ao ler {path}: {e}")
        return []


camera_positions = load_camera_positions(JSON_PATH)
print("Entradas de câmera:", len(camera_positions))

# ────────────────────────────────────────────────────────────────
#
# CAPTURA DE IMAGEM
#
# ────────────────────────────────────────────────────────────────


def split_for_capture_group(group_key):
    """Assign one deterministic split per scene/position group.

    This prevents near-duplicate captures from the same setup from leaking into
    train/validation/test simultaneously.
    """

    digest = hashlib.sha256(f"{RANDOM_SEED}:{group_key}".encode("utf-8")).digest()
    threshold = int.from_bytes(digest[:8], "big") / float(2**64)
    if threshold < TRAIN_SPLIT:
        return "train"
    if threshold < TRAIN_SPLIT + VALID_SPLIT:
        return "validation"
    return "test"


def get_image(cls_folder, classe, tipo, split, capture_id):
    """Captura imagem + máscara e salva com nome estruturado."""
    global img_number
    img_number += 1
    sup.step(timestep)

    img_name = f"image_{_sanitize_token(classe)}_{_sanitize_token(tipo)}_{_sanitize_token(capture_id)}_{img_number:05d}.png"
    mask_name = f"mask_{_sanitize_token(classe)}_{_sanitize_token(tipo)}_{_sanitize_token(capture_id)}_{img_number:05d}.png"

    img_path = ROOT_DIR / split / cls_folder / "images" / img_name
    mask_path = ROOT_DIR / split / cls_folder / "masks" / mask_name

    try:
        cam.saveImage(str(img_path), quality=100)
        logging.info(f"Imagem salva: {img_path}")

        if cls_folder == "cognitive":
            raw = cam.getRecognitionSegmentationImageArray()
            seg = np.array(raw, dtype=np.uint8).reshape(H, W, 3)

            label_mask = np.full((H, W), 255, dtype=np.uint8)  # 255 = fundo/ignore

            for rgb, label in SEGMENT_LABELS.items():
                rgb_arr = np.array(rgb, dtype=np.uint8)
                matches = np.all(seg[:, :, :3] == rgb_arr, axis=-1)
                label_mask[matches] = label

            cv2.imwrite(str(mask_path), label_mask)
            logging.info(f"Máscara cognitiva salva: {mask_path}")

            for ring_id in range(5):
                binary_mask = (label_mask == ring_id).astype(np.uint8) * 255

                ring_mask_name = f"mask_{_sanitize_token(classe)}_{_sanitize_token(tipo)}_{_sanitize_token(capture_id)}_ring{ring_id}_{img_number:05d}.png"
                ring_mask_path = (
                    ROOT_DIR / split / cls_folder / "masks" / ring_mask_name
                )
                cv2.imwrite(str(ring_mask_path), binary_mask)
                logging.info(f"Máscara da ring{ring_id} salva: {ring_mask_path}")

    except Exception as e:
        logging.error(f"Erro ao capturar imagem ({cls_folder}): {e}")
        traceback.print_exc()


# ────────────────────────────────────────────────────────────────
#
# FUNÇÕES DE CRIAÇÃO / REMOÇÃO DE NÓS
#
# ────────────────────────────────────────────────────────────────


def _insert_node(group_def, proto_str):
    group = sup.getFromDef(group_def)

    if group is None:
        print("ERRO: grupo não existe:", group_def)
        return None

    field = group.getField("children")

    count_before = field.getCount()

    if False:
        print("DEBUG proto:")
        print(proto_str)

    field.importMFNodeFromString(-1, proto_str)

    sup.step(timestep)

    count_after = field.getCount()

    if count_after <= count_before:
        print("ERRO: nó não foi inserido")
        return None

    node = field.getMFNode(count_after - 1)

    print("DEBUG node criado:", node)

    return node


def _remove_node(node, label="nó"):
    try:
        node.remove()
        logging.info(f"{label} removido.")
    except Exception as e:
        logging.error(f"Falha ao remover {label}: {e}")


# ── CognitiveTarget ───────────────────────────────────────────────
def create_cognitive(position, rotation, texture, name):
    """
    texture: string com 5 chars, por exemplo 'KRYGB'
    ordem: center, ring2, ring3, ring4, ring5
    """
    if len(texture) != 5:
        raise ValueError(
            f"Texture inválida: {texture}. Esperado exatamente 5 caracteres."
        )

    ax, ay, az, angle = rotation

    c0 = APP_COLOR_MAP[texture[0]]
    c1 = APP_COLOR_MAP[texture[1]]
    c2 = APP_COLOR_MAP[texture[2]]
    c3 = APP_COLOR_MAP[texture[3]]
    c4 = APP_COLOR_MAP[texture[4]]

    proto = (
        f"CognitiveTarget {{ "
        f"translation {position[0]} {position[1]} {position[2]} "
        f"rotation {ax} {ay} {az} {angle} "
        f"centerColor {c0[0]} {c0[1]} {c0[2]} "
        f"ring2Color {c1[0]} {c1[1]} {c1[2]} "
        f"ring3Color {c2[0]} {c2[1]} {c2[2]} "
        f"ring4Color {c3[0]} {c3[1]} {c3[2]} "
        f"ring5Color {c4[0]} {c4[1]} {c4[2]} "
        f"}}"
    )

    node = _insert_node("TARGETGROUP", proto)

    if node:
        node.getField("translation").setSFVec3f(position)
        node.getField("rotation").setSFRotation([ax, ay, az, angle])
        sup.step(timestep)

    return node


# ── Obstacle ───────────────────────────────────────────────────────
def create_obstacle(position, rotation, name, width=None, depth=None, height=None):
    """
    Cria um obstáculo com dimensões opcionais aleatórias.

    Args:
        position: [x, y, z]
        rotation: [ax, ay, az, angle]
        name: identificador único
        width, depth, height: dimensões (se None, usa aleatória)
    """
    # Dimensões aleatórias dentro da margem
    w = width if width is not None else round(random.uniform(0.15, 0.35), 3)
    d = depth if depth is not None else round(random.uniform(0.15, 0.35), 3)
    h = height if height is not None else round(random.uniform(0.15, 0.35), 3)

    # Escolhe forma
    shape = random.choice(["rectangular", "cylindrical", "conical", "spherical"])

    rectangular = "TRUE" if shape == "rectangular" else "FALSE"
    cylindrical = "TRUE" if shape == "cylindrical" else "FALSE"
    conical = "TRUE" if shape == "conical" else "FALSE"
    spherical = "TRUE" if shape == "spherical" else "FALSE"

    # Cores aleatórias para o obstáculo
    COLORS = [
        (1, 0, 0),  # vermelho
        (0, 1, 0),  # verde
        (0, 0, 1),  # azul
        (1, 1, 0),  # amarelo
        (1, 0, 1),  # magenta
        (0, 1, 1),  # ciano
        (1, 1, 1),  # branco
        (0, 0, 0),  # preto
    ]

    r, g, b = random.choice(COLORS)

    proto = (
        f"obstacle {{ "
        f"translation {position[0]} {position[1]} {position[2]} "
        f"rotation {rotation[0]} {rotation[1]} {rotation[2]} {rotation[3]} "
        f"width {w} depth {d} height {h} "
        f'id "{name}" '
        f"rectangular {rectangular} "
        f"cylindrical {cylindrical} "
        f"conical {conical} "
        f"spherical {spherical} "
        f"color {r} {g} {b} "
        f"}}"
    )

    return _insert_node("OBSTACLES", proto)


def pipeline_victim(entry, victim, positions, rotations):
    """
    Pipeline para modo VICTIM:
    - Captura 3 tipos de vítimas (harmed/unharmed/stable)
    - Captura 1 imagem 'none' (sem objeto)
    - NÃO cria nem fotografa CognitiveTarget
    """
    node_name = entry["nodename"]
    orig_trans = list(victim.getField("translation").getSFVec3f())
    orig_rot = list(victim.getField("rotation").getSFRotation())
    orig_type = victim.getField("type").getSFString()

    victim_trans = victim.getField("translation")
    victim_rot = victim.getField("rotation")

    updates = 0

    for idx, (pos_values, rot_values) in enumerate(zip(positions, rotations)):
        capture_group = f"{MODE}:{node_name}:position:{idx}"
        split = split_for_capture_group(capture_group)

        # Move câmera para posição de captura
        translation_field.setSFVec3f(pos_values)
        rotation_field.setSFRotation(rot_values)
        sup.step(timestep)
        logging.info(f"[{node_name}] posição {idx}: {pos_values} / {rot_values}")

        # ── FASE 1: Victim (harmed / unharmed / stable) ──────────
        for vtype in VICTIM_TYPES:
            victim.getField("type").setSFString(vtype)
            sup.step(timestep)
            capture_id = f"{node_name}_p{idx:04d}_{vtype}"
            get_image(vtype, "victim", vtype, split, capture_id)
            updates += 1
            yield updates

        # Restaura tipo original
        victim.getField("type").setSFString(orig_type)

        # ── FASE 2: Imagem 'none' (sem objeto) ──────────────────
        victim_trans.setSFVec3f([orig_trans[0], orig_trans[1] + 10, orig_trans[2]])
        sup.step(timestep)
        capture_id = f"{node_name}_p{idx:04d}_none"
        get_image("none", "none", "none", split, capture_id)
        updates += 1
        yield updates

        # ── Restaura vítima ao estado original ──────────────────
        victim_trans.setSFVec3f(orig_trans)
        victim_rot.setSFRotation(orig_rot)
        victim.getField("type").setSFString(orig_type)
        sup.step(timestep)
        logging.info(f"[{node_name}] restaurado.")


def pipeline_target(entry, positions, rotations):
    """
    Pipeline para modo TARGET:
    - Apenas CognitiveTargets
    - Cria e remove dinamicamente
    - Amostra aleatória de texturas por posição
    """
    node_name = entry["nodename"]

    victim = nodesDict.get(node_name)
    if not victim:
        logging.error(f"[{node_name}] Vítima não encontrada para TARGET — pulando.")
        return

    orig_trans = list(victim.getField("translation").getSFVec3f())
    orig_rot = list(victim.getField("rotation").getSFRotation())

    victim_trans = victim.getField("translation")
    victim_rot = victim.getField("rotation")

    updates = 0

    for idx, (pos_values, rot_values) in enumerate(zip(positions, rotations)):
        capture_group = f"{MODE}:{node_name}:position:{idx}"
        split = split_for_capture_group(capture_group)
        texture_rng = random.Random(f"{RANDOM_SEED}:{node_name}:{idx}:cognitive")
        cognitive_sample = texture_rng.sample(ALL_COGNITIVE_TEXTURES, k=N_COGNITIVE)

        # Move câmera para posição de captura
        translation_field.setSFVec3f(pos_values)
        rotation_field.setSFRotation(rot_values)
        sup.step(timestep)
        logging.info(f"[{node_name}] posição {idx}: {pos_values} / {rot_values}")

        victim_trans.setSFVec3f([orig_trans[0], orig_trans[1] + 10, orig_trans[2]])
        sup.step(timestep)

        # ── FASE: CognitiveTarget (N_COGNITIVE texturas) ────────
        for texture in cognitive_sample:
            cog_node = create_cognitive(
                position=orig_trans,
                rotation=orig_rot,
                texture=texture,
                name=f"cog_{id(entry)}_{idx}_{texture}",
            )

            sup.step(timestep)

            if cog_node:
                capture_id = f"{node_name}_p{idx:04d}_{texture}"
                get_image("cognitive", "target", texture, split, capture_id)
                cog_node.remove()
                sup.step(timestep)

            updates += 1
            yield updates

        victim_trans.setSFVec3f(orig_trans)
        victim_rot.setSFRotation(orig_rot)
        sup.step(timestep)

        logging.info(f"[{node_name}] restaurado.")


def pipeline_obstacle(entry, positions, rotations):
    """
    Pipeline para modo OBSTACLE:
    - Cria obstáculos com dimensões aleatórias
    - Captura imagem
    - Remove o objeto
    """
    node_name = entry["nodename"]
    meta = next((m for m in human_meta if m["name"] == entry["nodename"]), None)

    if meta is None:
        logging.error(f"[{node_name}] Meta não encontrada — pulando.")
        return

    orig_pos = meta["position"]
    orig_rot = meta["rotation"]

    updates = 0

    for idx, (pos_values, rot_values) in enumerate(zip(positions, rotations)):
        # Move câmera para posição de captura
        translation_field.setSFVec3f(pos_values)
        rotation_field.setSFRotation(rot_values)
        sup.step(timestep)
        logging.info(f"[{node_name}] posição {idx}: {pos_values} / {rot_values}")

        # ── FASE: Obstacles (com dimensões aleatórias) ─────────
        # Gera 5 obstáculos diferentes por posição (similar a N_COGNITIVE)
        for obs_idx in range(N_COGNITIVE):
            obs_node = create_obstacle(
                position=orig_pos,
                rotation=orig_rot,
                name=f"obs_{id(entry)}_{idx}_{obs_idx}",
            )

            sup.step(timestep)

            if obs_node:
                get_image("obstacle", "obstacle", "default")
                obs_node.remove()
                sup.step(timestep)

            updates += 1
            yield updates


# ────────────────────────────────────────────────────────────────
#
# ESTIMATIVA E CONFIRMAÇÃO
#
# ────────────────────────────────────────────────────────────────

positions_count = sum(len(e["positions"]) for e in camera_positions)

if MODE == "victim":
    imgs_per_pos = len(VICTIM_TYPES) + 1  # harmed/unharmed/stable + none
elif MODE == "target":
    imgs_per_pos = N_COGNITIVE
elif MODE == "obstacle":
    imgs_per_pos = N_COGNITIVE
else:
    imgs_per_pos = 0

est_total_imgs = positions_count * imgs_per_pos
est_total_mb = est_total_imgs * (11.0 / 336.0)

print("\n" + "-" * 60)
print("ESTIMATIVA")
print("-" * 60)
print(f"Posições de câmera: {positions_count}")
print(f"Imagens por posição: {imgs_per_pos}")
print(f"Total estimado: {est_total_imgs} imagens")
print(f"Espaço estimado: {est_total_mb:.2f} MB")
print("-" * 60)

# ────────────────────────────────────────────────────────────────
#
# LOOP PRINCIPAL
#
# ────────────────────────────────────────────────────────────────

print(f"\nIniciando geração de dataset (modo: {MODE.upper()})...\n")

bar = tqdm(
    total=est_total_imgs,
    unit="imgs",
    desc="Gerando dataset",
    ncols=80,
    bar_format="{l_bar}{bar}| ETA: {remaining}",
)

for idxloop, entry in enumerate(camera_positions):
    print(f"\n[{idxloop + 1}/{len(camera_positions)}] Processando: {entry['nodename']}")

    node_name = entry["nodename"]
    positions = entry["positions"]
    rotations = entry["rotations"]

    if not positions or not rotations or len(positions) != len(rotations):
        logging.error(f"[{node_name}] Dados inválidos — pulando.")
        continue

    # Executa pipeline apropriado
    if MODE == "victim":
        victim = nodesDict.get(node_name)
        if not victim:
            logging.error(f"[{node_name}] Vítima não encontrada — pulando.")
            continue
        generator = pipeline_victim(entry, victim, positions, rotations)

    elif MODE == "target":
        generator = pipeline_target(entry, positions, rotations)

    elif MODE == "obstacle":
        generator = pipeline_obstacle(entry, positions, rotations)

    # Itera sobre gerador para atualizar barra de progresso
    try:
        for _ in generator:
            bar.update(1)
    except Exception as e:
        logging.error(f"Erro ao processar {node_name}: {e}")
        traceback.print_exc()

# ── Restaura robô ────────────────────────────────────────────────
if robot:
    robot.getField("translation").setSFVec3f(initial_position)
    robot.getField("rotation").setSFRotation(initial_rotation)

bar.close()

print("\n" + "=" * 60)
print("GERAÇÃO CONCLUÍDA")
print("=" * 60)
logging.info("Geração de dataset concluída.")
logging.shutdown()
