"""Train victim localization baseline (1200 epochs, no Optuna).

Run: .venv/bin/python notebooks/scripts/train_victim_baseline.py
"""
from __future__ import annotations
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common.train_config import BBoxTrainConfig
from notebooks.common.training_runs import run_bbox_training

CONFIG = {
    "dataset_name": "imagens_larc",

    "input_size": 96,
    "batch_size": 64,
    "epochs": 1200,

    "bbox_model_type": "legacy_cnn",
    "bbox_loss_name": "combined",
    "saiou_lambda_center": 1.529124973633597,
    "saiou_lambda_corner": 1.151321268161352,
    "combined_saiou_weight": 1.0,
    "combined_smooth_l1_weight": 0.25,

    "optimizer_name": "adamw",
    "learning_rate": 0.001,
    "weight_decay": 0.0001,
    "adam_beta1": 0.9,
    "adam_beta2": 0.999,

    "scheduler_name": "cosine",
    "scheduler_eta_min": 1e-6,

    "dropout": 0.10,
    "base_channels": 48,

    "augment": True,
    "augment_brightness": 0.10,
    "augment_contrast": 0.15,
    "augment_degrees": 0.0,
    "augment_translate": 0.0,

    "use_optuna": False,

    "device": "auto",
    "output_mode": "timestamped",
    "skip_if_missing": True,

    "show_samples": False,
    "show_training_plots": False,
    "save_metrics_json": True,
}
CONFIG["checkpoint_name"] = "victim_bbox_best.pt"
CONFIG["onnx_name"] = "victim_bbox.onnx"

cfg = BBoxTrainConfig.from_dict(CONFIG)
print(f"artifact_dir: {cfg.artifact_dir}")
result = run_bbox_training(cfg)

print("\n=== TRAINING RESULT ===")
print(f"status:        {result.status}")
print(f"artifact_dir:  {result.artifact_dir}")
print(f"checkpoint:    {result.checkpoint_path}")
print(f"onnx:          {result.onnx_path}")
print(f"best_epoch:    {result.metrics.get('best_epoch')}")
print(f"best_metric:   {result.metrics.get('best_metric')}")

split_m = result.metrics.get("split_metrics", {})
if split_m:
    for split_name in ("train", "validation", "test"):
        sm = split_m.get(split_name, {})
        print(f"{split_name}.mean_iou:   {sm.get('mean_iou', 'N/A')}")
        print(f"{split_name}.median_iou: {sm.get('median_iou', 'N/A')}")

worst = result.metrics.get("worst_prediction_examples", [])
print(f"\nworst {len(worst)} examples:")
for ex in worst[:5]:
    print(f"  {ex}")

print("\n=== FULL METRICS JSON ===")
print(json.dumps(result.metrics, indent=2, default=str))
