# -*- coding: utf-8 -*-
import sys

sys.stdout.reconfigure(encoding="utf-8")

from controller import Supervisor, Robot, Keyboard
import json
import random


# ============================================================
# Inicialização original
# ============================================================

sup = Supervisor()
timestep = int(sup.getBasicTimeStep())

kb = sup.getKeyboard()
kb.enable(timestep)

leftMotor = sup.getDevice("wheel1 motor")
rightMotor = sup.getDevice("wheel2 motor")
gps = sup.getDevice("gps")
lidar = sup.getDevice("lidar")

leftMotor.setPosition(float("inf"))
rightMotor.setPosition(float("inf"))
leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)

MAXSPEED = 6.27

APP_COLOR_MAP = {
    "K": (0.0, 0.0, 0.0),
    "R": (1.0, 0.0, 0.0),
    "Y": (1.0, 1.0, 0.0),
    "G": (0.0, 1.0, 0.0),
    "B": (0.0, 0.0, 1.0),
}

# Referência ao nó do Supervisor para obter posição/rotação do robô
robot = sup.getFromDef("ROBOT0")
if robot is None:
    raise RuntimeError("DEF ROBOT0 não encontrado.")

trans_field = robot.getField("translation")
rot_field = robot.getField("rotation")

# Câmera
cam = sup.getDevice("camera1")
cam.enable(timestep)

lidar.enable(timestep)
gps.enable(timestep)


# ============================================================
# Configuração
# ============================================================

# Se quiser forçar modo sem teclado:
#   FORCED_CHOICE = '1'
#   FORCED_CHOICE = '2'
#   FORCED_CHOICE = '3'
FORCED_CHOICE = None

# Em modo target, o código vai usar estes grupos como pontos-base.
# Isso replica a ideia do seu código original:
#   HUMANGROUP + TARGETGROUP
TARGET_SOURCE_GROUPS = ["HUMANGROUP", "TARGETGROUP"]

# Remove objetos originais antes de inserir CognitiveTarget.
# Isso evita target em cima de vítima.
REMOVE_SOURCE_OBJECTS_IN_TARGET_MODE = True

# Em modo victim, remove targets existentes para não ficarem sobrepondo/aparecendo.
REMOVE_TARGETS_IN_VICTIM_MODE = True

# Em modo obstacle, limpa vítimas e targets da cena.
REMOVE_NON_OBSTACLES_IN_OBSTACLE_MODE = True

# Evita criar dois CognitiveTarget no mesmo lugar caso HUMANGROUP e TARGETGROUP
# tenham nós na mesma posição.
DEDUPLICATE_TARGET_SOURCE_POSITIONS = True
DEDUP_DECIMALS = 4


# ============================================================
# Funções auxiliares
# ============================================================


def wait_key_release(target_key):
    while sup.step(timestep) != -1:
        if kb.getKey() != target_key:
            break


def choose_mode_by_keyboard():
    print("")
    print("Escolha o tipo de coleta clicando na janela da simulação:")
    print("1 - Victim")
    print("2 - Target")
    print("3 - Obstacle")
    print("Aguardando tecla 1, 2 ou 3...")

    if FORCED_CHOICE in ["1", "2", "3"]:
        print(f"Modo forçado por FORCED_CHOICE = {FORCED_CHOICE}")
        return FORCED_CHOICE

    if len(sys.argv) > 1 and sys.argv[1] in ["1", "2", "3"]:
        print(f"Modo recebido por argumento: {sys.argv[1]}")
        return sys.argv[1]

    while sup.step(timestep) != -1:
        key = kb.getKey()

        if key == ord("1"):
            wait_key_release(ord("1"))
            return "1"

        if key == ord("2"):
            wait_key_release(ord("2"))
            return "2"

        if key == ord("3"):
            wait_key_release(ord("3"))
            return "3"

    raise RuntimeError("Simulação encerrada antes da escolha do modo.")


def get_children_field(def_name):
    group = sup.getFromDef(def_name)

    if group is None:
        print(f"Aviso: DEF {def_name} não encontrado.")
        return None

    children = group.getField("children")

    if children is None:
        print(f"Aviso: DEF {def_name} não tem campo children.")
        return None

    return children


def get_node_name(node, index):
    field = node.getField("name")
    if field is not None:
        try:
            value = field.getSFString()
            if value:
                return value
        except Exception:
            pass

    field = node.getField("id")
    if field is not None:
        try:
            value = field.getSFString()
            if value:
                return value
        except Exception:
            pass

    try:
        value = node.getDef()
        if value:
            return value
    except Exception:
        pass

    return f"node_{index}"


def get_node_pose(node):
    pos_field = node.getField("translation")
    rot_field_node = node.getField("rotation")

    if pos_field is None:
        return None

    pos = pos_field.getSFVec3f()

    if rot_field_node is not None:
        rot = rot_field_node.getSFRotation()
    else:
        rot = [0.0, 1.0, 0.0, 0.0]

    return pos, rot


def remove_all_children(def_name):
    children = get_children_field(def_name)
    if children is None:
        return

    for i in reversed(range(children.getCount())):
        node = children.getMFNode(i)
        node.remove()

    sup.step(timestep)


def collect_nodes_from_group(def_name, only_named=False, only_def=False):
    nodes = []
    children = get_children_field(def_name)

    if children is None:
        return nodes

    print(f"{def_name}: {children.getCount()} filhos encontrados.")

    for i in range(children.getCount()):
        node = children.getMFNode(i)

        if only_named:
            name_field = node.getField("name")
            if name_field is None:
                continue

            try:
                if not name_field.getSFString():
                    continue
            except Exception:
                continue

        if only_def:
            try:
                if not node.getDef():
                    continue
            except Exception:
                continue

        nodes.append(node)

    return nodes


def snapshot_nodes_from_group(def_name, only_named=False, only_def=False):
    snapshots = []
    children = get_children_field(def_name)

    if children is None:
        return snapshots

    print(f"{def_name}: {children.getCount()} filhos encontrados.")

    for i in range(children.getCount()):
        node = children.getMFNode(i)

        if only_named:
            name_field = node.getField("name")
            if name_field is None:
                continue

            try:
                if not name_field.getSFString():
                    continue
            except Exception:
                continue

        if only_def:
            try:
                if not node.getDef():
                    continue
            except Exception:
                continue

        pose = get_node_pose(node)
        if pose is None:
            continue

        pos, rot = pose

        snapshots.append(
            {
                "source_group": def_name,
                "source_index": i,
                "name": get_node_name(node, len(snapshots)),
                "position": pos,
                "rotation": rot,
            }
        )

    return snapshots


def deduplicate_snapshots_by_position(snapshots):
    if not DEDUPLICATE_TARGET_SOURCE_POSITIONS:
        return snapshots

    seen = set()
    deduped = []

    for item in snapshots:
        pos = item["position"]
        key = (
            round(pos[0], DEDUP_DECIMALS),
            round(pos[1], DEDUP_DECIMALS),
            round(pos[2], DEDUP_DECIMALS),
        )

        if key in seen:
            print(f"Ignorando duplicado em posição {key}: {item['name']}")
            continue

        seen.add(key)
        deduped.append(item)

    return deduped


def create_cognitive_target_proto(pos, rot):
    colors = list(APP_COLOR_MAP.values())
    c0, c1, c2, c3, c4 = random.sample(colors, 5)

    proto = (
        f"CognitiveTarget {{ "
        f"translation {pos[0]} {pos[1]} {pos[2]} "
        f"rotation {rot[0]} {rot[1]} {rot[2]} {rot[3]} "
        f"centerColor {c0[0]} {c0[1]} {c0[2]} "
        f"ring2Color {c1[0]} {c1[1]} {c1[2]} "
        f"ring3Color {c2[0]} {c2[1]} {c2[2]} "
        f"ring4Color {c3[0]} {c3[1]} {c3[2]} "
        f"ring5Color {c4[0]} {c4[1]} {c4[2]} "
        f"}}"
    )

    return proto


def create_targets_from_snapshots(snapshots):
    target_field = get_children_field("TARGETGROUP")

    if target_field is None:
        raise RuntimeError(
            "DEF TARGETGROUP não encontrado. Não é possível importar CognitiveTarget."
        )

    created_nodes = []
    created_names = []

    for item in snapshots:
        pos = item["position"]
        rot = item["rotation"]

        proto = create_cognitive_target_proto(pos, rot)

        target_field.importMFNodeFromString(-1, proto)
        sup.step(timestep)

        new_node = target_field.getMFNode(target_field.getCount() - 1)

        created_nodes.append(new_node)
        created_names.append(item["name"])

        print(
            f"CognitiveTarget criado em "
            f"{pos[0]:.3f}, {pos[1]:.3f}, {pos[2]:.3f} "
            f"a partir de {item['source_group']} / {item['name']}"
        )

    return created_nodes, created_names


# ============================================================
# Escolha do modo
# ============================================================

choice = choose_mode_by_keyboard()

if choice == "1":
    MODE = "victim"
    POSITIONS_PER_NODE = 8
    OUTPUT_FILE = "imgs_pos_victim.json"

elif choice == "2":
    MODE = "target"
    POSITIONS_PER_NODE = 4
    OUTPUT_FILE = "imgs_pos_target.json"

elif choice == "3":
    MODE = "obstacle"
    POSITIONS_PER_NODE = 1
    OUTPUT_FILE = "imgs_pos_obstacle.json"

else:
    raise ValueError("Opção inválida.")


# ============================================================
# Coleta/criação correta dos nós por modo
# ============================================================

nodes = []
node_names = []

if MODE == "victim":
    # Modo 1:
    # Coleta somente vítimas.
    # Não cria targets.
    nodes = collect_nodes_from_group("HUMANGROUP", only_named=True)
    node_names = [get_node_name(node, i) for i, node in enumerate(nodes)]

    if REMOVE_TARGETS_IN_VICTIM_MODE:
        remove_all_children("TARGETGROUP")

elif MODE == "target":
    # Modo 2:
    # Usa os nós-base de HUMANGROUP + TARGETGROUP, como no código original.
    # Depois remove os objetos originais e coloca CognitiveTarget nas posições.
    target_sources = []

    for group_name in TARGET_SOURCE_GROUPS:
        source_items = snapshot_nodes_from_group(group_name)
        target_sources.extend(source_items)

    target_sources = deduplicate_snapshots_by_position(target_sources)

    print(f"Total de posições-base para targets: {len(target_sources)}")

    if REMOVE_SOURCE_OBJECTS_IN_TARGET_MODE:
        for group_name in TARGET_SOURCE_GROUPS:
            remove_all_children(group_name)

    nodes, node_names = create_targets_from_snapshots(target_sources)

elif MODE == "obstacle":
    # Modo 3:
    # Coleta somente obstáculos.
    if REMOVE_NON_OBSTACLES_IN_OBSTACLE_MODE:
        remove_all_children("HUMANGROUP")
        remove_all_children("TARGETGROUP")

    nodes = collect_nodes_from_group("OBSTACLES")
    node_names = [get_node_name(node, i) for i, node in enumerate(nodes)]


total_nodes = len(nodes)

print("")
print(f"Modo selecionado: {MODE}")
print(f"Encontrados {total_nodes} nós.")
print(f"Use setas para mover, 'P' para salvar posições ({POSITIONS_PER_NODE}/nó).")

if total_nodes <= 0:
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump([], f, indent=2, ensure_ascii=False)

    print(f"Nenhum nó encontrado. Arquivo vazio salvo em {OUTPUT_FILE}.")
    sys.exit(0)


print(f"Agora: nó 1/{total_nodes}: {node_names[0]} (0/{POSITIONS_PER_NODE})")


# ============================================================
# Loop principal
# ============================================================

data = []
node_index = 0
count_in_node = 0

while sup.step(timestep) != -1:
    key = kb.getKey()

    # Controle via motores
    if key == kb.UP:
        leftMotor.setVelocity(MAXSPEED)
        rightMotor.setVelocity(MAXSPEED)

    elif key == kb.DOWN:
        leftMotor.setVelocity(-MAXSPEED)
        rightMotor.setVelocity(-MAXSPEED)

    elif key == kb.LEFT:
        leftMotor.setVelocity(MAXSPEED / 2)
        rightMotor.setVelocity(-MAXSPEED / 2)

    elif key == kb.RIGHT:
        leftMotor.setVelocity(-MAXSPEED / 2)
        rightMotor.setVelocity(MAXSPEED / 2)

    else:
        leftMotor.setVelocity(0)
        rightMotor.setVelocity(0)

    # Tecla P: salva posição atual do ROBOT0
    if key == ord("P") or key == ord("p"):
        name = node_names[node_index]

        if count_in_node == 0:
            data.append({"nodename": name, "positions": [], "rotations": []})

        data[-1]["positions"].append(trans_field.getSFVec3f())
        data[-1]["rotations"].append(rot_field.getSFRotation())

        count_in_node += 1

        print(f"{name}: posição {count_in_node}/{POSITIONS_PER_NODE} salva.")

        wait_key_release(key)

        if count_in_node >= POSITIONS_PER_NODE:
            node_index += 1
            count_in_node = 0

            if node_index >= total_nodes:
                break

            print(
                f"Passando ao nó {node_index + 1}/{total_nodes}: "
                f"{node_names[node_index]} "
                f"(0/{POSITIONS_PER_NODE})"
            )


# ============================================================
# Salvar JSON final
# ============================================================

leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)

print(f"Arquivo {OUTPUT_FILE} salvo com {len(data)} nós coletados.")
