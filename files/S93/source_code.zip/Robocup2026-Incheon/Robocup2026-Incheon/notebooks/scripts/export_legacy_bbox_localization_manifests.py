#!/usr/bin/env python3
"""Build legacy-style bbox localization manifests for victims and targets.

The legacy notebook trained bbox regressors with a tiny central bbox for
``none`` examples. This script extends that idea with cross-object hard
negatives:

* victim bbox positives + none + target-as-negative
* target bbox positives + none + victim-as-negative

All negative rows keep ``label_name=none`` so the existing bbox training
preflight accepts the manifest. ``negative_source`` records where the negative
came from.

Run with:
    .venv/bin/python notebooks/scripts/export_legacy_bbox_localization_manifests.py
"""

from __future__ import annotations

import argparse
import csv
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common.config import get_manifest_root

SPLITS = ("train", "validation", "test")
SMALL_BBOX = (31.0 / 64.0, 31.0 / 64.0, 33.0 / 64.0, 33.0 / 64.0)
FIELDNAMES = [
    "split",
    "image_path",
    "label",
    "label_name",
    "negative_source",
    "xmin",
    "ymin",
    "xmax",
    "ymax",
]


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _small_bbox_strings() -> tuple[str, str, str, str]:
    return tuple(f"{value:.6f}" for value in SMALL_BBOX)


def _negative_row(row: dict[str, str], source: str) -> dict[str, str]:
    xmin, ymin, xmax, ymax = _small_bbox_strings()
    return {
        "split": row["split"],
        "image_path": row["image_path"],
        "label": "0",
        "label_name": "none",
        "negative_source": source,
        "xmin": xmin,
        "ymin": ymin,
        "xmax": xmax,
        "ymax": ymax,
    }


def _victim_positive_rows(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    for row in rows:
        out.append(
            {
                "split": row["split"],
                "image_path": row["image_path"],
                "label": "1",
                "label_name": "victim",
                "negative_source": "",
                "xmin": row["xmin"],
                "ymin": row["ymin"],
                "xmax": row["xmax"],
                "ymax": row["ymax"],
            }
        )
    return out


def _target_positive_rows(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    for row in rows:
        width = float(row.get("image_width") or 64.0)
        height = float(row.get("image_height") or 64.0)
        xmin = float(row["bbox_xmin"]) / width
        ymin = float(row["bbox_ymin"]) / height
        xmax = float(row["bbox_xmax"]) / width
        ymax = float(row["bbox_ymax"]) / height
        if not (0.0 <= xmin < xmax <= 1.0 and 0.0 <= ymin < ymax <= 1.0):
            continue
        out.append(
            {
                "split": row["split"],
                "image_path": row["image_path"],
                "label": "1",
                "label_name": "target",
                "negative_source": "",
                "xmin": f"{xmin:.6f}",
                "ymin": f"{ymin:.6f}",
                "xmax": f"{xmax:.6f}",
                "ymax": f"{ymax:.6f}",
            }
        )
    return out


def _subsample_per_split(rows: list[dict[str, str]], per_split: dict[str, int],
                         seed: int) -> list[dict[str, str]]:
    """Deterministically keep at most ``per_split[split]`` rows of ``rows``."""
    import random

    by_split: dict[str, list[dict[str, str]]] = {}
    for row in rows:
        by_split.setdefault(row["split"], []).append(row)
    out: list[dict[str, str]] = []
    for split, split_rows in by_split.items():
        keep = per_split.get(split, 0)
        if keep >= len(split_rows):
            out.extend(split_rows)
            continue
        rng = random.Random(f"{seed}:{split}")
        out.extend(rng.sample(split_rows, max(0, keep)))
    return out


def _balanced_rows(positives: list[dict[str, str]], none_neg: list[dict[str, str]],
                   cross_pos: list[dict[str, str]], cross_source: str,
                   none_frac: float = 0.06, cross_frac: float = 0.02,
                   seed: int = 42) -> list[dict[str, str]]:
    """All positives + a per-split MINORITY of none and cross-object negatives.

    ``none_frac``/``cross_frac`` are counts relative to the positive count in the
    same split, so negatives never dominate any split and the localizer keeps
    learning to place a real box on positives while still shrinking to the tiny
    ``none`` box when the frame is empty/too far.
    """
    pos_per_split: dict[str, int] = {}
    for row in positives:
        pos_per_split[row["split"]] = pos_per_split.get(row["split"], 0) + 1
    none_counts = {s: round(n * none_frac) for s, n in pos_per_split.items()}
    cross_counts = {s: round(n * cross_frac) for s, n in pos_per_split.items()}
    none_sample = _subsample_per_split(none_neg, none_counts, seed)
    cross_rows = [_negative_row(row, cross_source) for row in cross_pos]
    cross_sample = _subsample_per_split(cross_rows, cross_counts, seed + 1)
    return [*positives, *none_sample, *cross_sample]


def _none_rows(object_presence_rows: list[dict[str, str]]) -> list[dict[str, str]]:
    return [
        _negative_row(row, "none")
        for row in object_presence_rows
        if row.get("label_name") == "none"
    ]


def _write(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = sorted(rows, key=lambda row: (row["split"], row["label_name"], row["image_path"]))
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(rows)


def _print_summary(path: Path, rows: list[dict[str, str]]) -> None:
    by_split = Counter(row["split"] for row in rows)
    by_label = Counter(row["label_name"] for row in rows)
    by_source = Counter(row["negative_source"] or "positive" for row in rows)
    print(f"wrote {path} ({len(rows)} rows)")
    print("  splits:", dict(by_split))
    print("  labels:", dict(by_label))
    print("  sources:", dict(by_source))


def generate(dataset_name: str) -> tuple[Path, Path]:
    manifest_root = get_manifest_root(dataset_name)
    victim_rows = _read_csv(manifest_root / "victim_bbox.csv")
    target_rows = _read_csv(manifest_root / "target_mask_manifest.csv")
    object_presence_rows = _read_csv(manifest_root / "object_presence.csv")

    victim_pos = _victim_positive_rows(victim_rows)
    target_pos = _target_positive_rows(target_rows)
    none_neg = _none_rows(object_presence_rows)

    victim_manifest_rows = [
        *victim_pos,
        *none_neg,
        *(_negative_row(row, "target_as_false") for row in target_pos),
    ]
    target_manifest_rows = [
        *target_pos,
        *none_neg,
        *(_negative_row(row, "victim_as_false") for row in victim_pos),
    ]

    victim_out = manifest_root / "victim_bbox_legacy_with_none_false.csv"
    target_out = manifest_root / "target_bbox_legacy_with_none_false.csv"
    _write(victim_out, victim_manifest_rows)
    _write(target_out, target_manifest_rows)
    _print_summary(victim_out, victim_manifest_rows)
    _print_summary(target_out, target_manifest_rows)

    # Balanced manifests. The bbox localizer runs *after* object_type routes the
    # frame, so the ``none`` box only has to teach "nothing/too-far -> tiny box"
    # for the proximity gate -- it must stay a MINORITY. With the full
    # ``with_none_false`` manifest the identical central ``none`` box is ~81% of
    # rows, so the victim regressor collapses onto it (predicts the tiny box for
    # real victims too). The legacy notebook that "worked well" kept negatives a
    # small minority (~240 none rows). We reproduce that: keep every positive and
    # subsample the negatives to a fraction of the positives, per split.
    victim_balanced = _balanced_rows(victim_pos, none_neg, target_pos, "target_as_false")
    target_balanced = _balanced_rows(target_pos, none_neg, victim_pos, "victim_as_false")
    victim_bal_out = manifest_root / "victim_bbox_legacy_balanced.csv"
    target_bal_out = manifest_root / "target_bbox_legacy_balanced.csv"
    _write(victim_bal_out, victim_balanced)
    _write(target_bal_out, target_balanced)
    _print_summary(victim_bal_out, victim_balanced)
    _print_summary(target_bal_out, target_balanced)
    return victim_out, target_out


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="imagens_larc")
    args = parser.parse_args()
    generate(args.dataset_name)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
