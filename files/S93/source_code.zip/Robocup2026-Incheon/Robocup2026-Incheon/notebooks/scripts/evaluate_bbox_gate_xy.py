#!/usr/bin/env python3
"""Evaluate + tune the camera-only bbox proximity gate on X (width) and Y (height).

The LiDAR distance is unreliable, so the victim/target bbox size is the proximity
signal: a close object projects a large box; a far/empty frame a tiny one (the
minority ``none`` rows in training teach the tiny box). This script runs the
trained ``victim_bbox`` / ``target_bbox`` ONNX models over the dataset and, for
the predicted box WIDTH and HEIGHT separately, measures how well each separates:

  * close positives (distance <= --max-distance-m) -> want PASS  (recall)
  * far   positives (distance >  --max-distance-m) -> want REJECT
  * none  frames    (no object in view)            -> want REJECT

It then picks, per branch, a width gate (Youden's J with a recall floor) and a
height floor (kept below the close boxes so it only culls tiny/none boxes) and
writes them back into ``reports/bbox_gate_thresholds.json`` under ``model_gate``
so the runtime + controller read model-derived thresholds. Re-run after any
bbox retrain. Usage:

    .venv/bin/python notebooks/scripts/evaluate_bbox_gate_xy.py
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common import model_registry
from notebooks.common.config import get_dataset_root, get_manifest_root
from notebooks.common.crops import OnnxLocalizer

FRAME_PX = 64.0


def _collect(kind: str, task: str, dataset_name: str, max_distance_m: float,
             limit_none: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    dataset_root = get_dataset_root(dataset_name)
    manifest_root = get_manifest_root(dataset_name)
    localizer = OnnxLocalizer(
        model_registry.resolve_model_bundle(task, selection="latest", require_onnx=True)
    )

    def wh(path: Path) -> tuple[float, float]:
        box = localizer.predict(Image.open(path).convert("RGB"))[:4]
        x0, y0, x1, y1 = (max(0.0, min(1.0, float(v))) for v in box)
        return ((x1 - x0) * FRAME_PX, (y1 - y0) * FRAME_PX)

    close: list[tuple[float, float]] = []
    far: list[tuple[float, float]] = []
    for path in dataset_root.glob("*/*/lidar/*.json"):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if payload.get("object_kind") != kind:
            continue
        distance = (payload.get("distance") or {}).get("robot_object_xz_m")
        image_path = payload.get("image_path")
        if distance is None or not image_path:
            continue
        full = dataset_root / image_path
        if full.exists():
            (close if float(distance) <= max_distance_m else far).append(wh(full))

    none: list[tuple[float, float]] = []
    presence = manifest_root / "object_presence.csv"
    if presence.exists():
        with presence.open(newline="", encoding="utf-8") as handle:
            for row in csv.DictReader(handle):
                if row.get("label_name") != "none":
                    continue
                full = dataset_root / row["split"] / row["image_path"]
                if full.exists():
                    none.append(wh(full))
                if len(none) >= limit_none:
                    break
    return np.array(close), np.array(far), np.array(none)


def _tune(close: np.ndarray, far: np.ndarray, none: np.ndarray,
          recall_floor: float) -> dict[str, float]:
    """Pick a width gate (Youden J, recall floor) and a non-blocking height floor."""

    def rates(arr: np.ndarray, axis: int, thr: float) -> float:
        return float((arr[:, axis] >= thr).mean()) if len(arr) else 0.0

    # Width: maximise close_recall + far_reject subject to a recall floor.
    best_w, best_j = 4.0, -1.0
    for thr in range(4, 61):
        recall = rates(close, 0, thr)
        far_reject = 1.0 - rates(far, 0, thr)
        if recall < recall_floor:
            continue
        j = recall + far_reject - 1.0
        if j > best_j:
            best_j, best_w = j, float(thr)
    # Height floor: the largest threshold that still passes >=98% of close boxes,
    # so height only culls tiny/none boxes and never fights width on recall.
    best_h = 4.0
    for thr in range(4, 61):
        if rates(close, 1, thr) >= 0.98:
            best_h = float(thr)
    return {"width_px": best_w, "height_px": best_h}


def _metrics(close, far, none, mw: float, mh: float) -> dict[str, float]:
    def passes(arr):
        return (arr[:, 0] >= mw) & (arr[:, 1] >= mh) if len(arr) else np.array([])
    return {
        "close_recall": float(passes(close).mean()) if len(close) else float("nan"),
        "far_reject": float(1.0 - passes(far).mean()) if len(far) else float("nan"),
        "none_reject": float(1.0 - passes(none).mean()) if len(none) else float("nan"),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="imagens_larc")
    parser.add_argument("--max-distance-m", type=float, default=0.06)
    parser.add_argument("--gate-path", default="reports/bbox_gate_thresholds.json")
    parser.add_argument("--recall-floor", type=float, default=0.80)
    parser.add_argument("--limit-none", type=int, default=400)
    parser.add_argument("--write", action="store_true", default=True)
    parser.add_argument("--no-write", dest="write", action="store_false")
    args = parser.parse_args()

    gate_file = ROOT / args.gate_path
    payload = json.loads(gate_file.read_text(encoding="utf-8")) if gate_file.exists() else {"thresholds": {}}
    thresholds = payload.setdefault("thresholds", {})

    for kind, task in (("victim", "victim_bbox"), ("target", "target_bbox")):
        close, far, none = _collect(kind, task, args.dataset_name, args.max_distance_m, args.limit_none)
        picked = _tune(close, far, none, args.recall_floor)
        mw, mh = picked["width_px"], picked["height_px"]
        m = _metrics(close, far, none, mw, mh)
        print(f"\n==================== {kind.upper()} ====================")
        print(f"  samples: close={len(close)} far={len(far)} none={len(none)}")
        for axis, i in (("width", 0), ("height", 1)):
            if not len(close):
                continue
            print(f"  {axis:6s}: close p10={np.percentile(close[:,i],10):5.1f} p50={np.percentile(close[:,i],50):5.1f} "
                  f"| far p50={np.percentile(far[:,i],50):5.1f} | none p50={np.percentile(none[:,i],50):5.1f}")
        print(f"  PICKED gate: width>={mw:.0f}px  height>={mh:.0f}px  ->  "
              f"close-recall={m['close_recall']:.1%} far-reject={m['far_reject']:.1%} none-reject={m['none_reject']:.1%}")
        entry = thresholds.setdefault(kind, {})
        entry["model_gate"] = {
            "width_px": mw,
            "height_px": mh,
            "width_norm": mw / FRAME_PX,
            "height_norm": mh / FRAME_PX,
            **m,
        }

    if args.write:
        payload["max_distance_m"] = args.max_distance_m
        gate_file.parent.mkdir(parents=True, exist_ok=True)
        gate_file.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(f"\nwrote model-derived gates -> {gate_file}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
