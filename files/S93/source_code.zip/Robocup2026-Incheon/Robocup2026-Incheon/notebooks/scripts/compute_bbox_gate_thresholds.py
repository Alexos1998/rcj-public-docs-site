#!/usr/bin/env python3
"""Compute bbox-size gates for close reportable objects.

The runtime bbox gate uses the average bbox size for rows whose
``distance.robot_object_xz_m`` is at or below the report distance. The JSON
LiDAR metadata provides the distance; the bbox manifests provide the labels.
"""

from __future__ import annotations

import argparse
import csv
import json
import statistics
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common.config import get_dataset_root, get_manifest_root


def _distance_index(dataset_root: Path) -> dict[str, float]:
    index: dict[str, float] = {}
    for path in dataset_root.glob("*/*/lidar/*.json"):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        image_path = str(payload.get("image_path") or "")
        distance = (payload.get("distance") or {}).get("robot_object_xz_m")
        if not image_path or distance is None:
            continue
        value = float(distance)
        index[image_path] = value
        parts = Path(image_path).parts
        if len(parts) >= 2:
            index[str(Path(*parts[1:]))] = value
    return index


FRAME_PX = 64.0  # manifests are authored on 64x64 frames.


def _summary(values: list[tuple[float, float, float]]) -> dict[str, float | int]:
    widths = [item[0] for item in values]
    heights = [item[1] for item in values]
    areas = [item[2] for item in values]
    return {
        "count": len(values),
        "mean_width_px": statistics.mean(widths),
        "mean_height_px": statistics.mean(heights),
        "mean_area_px": statistics.mean(areas),
        "median_width_px": statistics.median(widths),
        "median_height_px": statistics.median(heights),
        "median_area_px": statistics.median(areas),
    }


def _gate(
    rows: list[tuple[float, float, float]], max_distance_m: float
) -> dict[str, float | int]:
    """Resolution-independent bbox gate at the ``max_distance_m`` boundary.

    ``rows`` are ``(distance_m, width_norm, height_norm)`` tuples. The gate is the
    *normalized* bbox size an object has at exactly ``max_distance_m`` (estimated
    with the median over a +-10% distance band). Because projected size grows as
    the robot approaches, ``size >= gate`` means ``distance <= max_distance_m``.
    """

    lo, hi = max_distance_m * 0.9, max_distance_m * 1.1
    band = [r for r in rows if lo <= r[0] <= hi]
    if not band:  # fall back to everything at/inside the threshold
        band = [r for r in rows if r[0] <= max_distance_m]
    areas = [w * h for _, w, h in band]
    widths = [w for _, w, _ in band]
    heights = [h for _, _, h in band]
    min_sides = [min(w, h) for _, w, h in band]
    area_norm = statistics.median(areas)
    width_norm = statistics.median(widths)
    height_norm = statistics.median(heights)
    return {
        "boundary_count": len(band),
        "area_norm": area_norm,
        "width_norm": width_norm,
        "height_norm": height_norm,
        "min_side_norm": statistics.median(min_sides),
        # Pixel gates on the 64x64 authoring frame, ready to drop into
        # vision.yaml / the controller runtime manifest.
        "area_px": area_norm * FRAME_PX * FRAME_PX,
        "width_px": width_norm * FRAME_PX,
        "height_px": height_norm * FRAME_PX,
    }


def compute(dataset_name: str, max_distance_m: float) -> dict[str, dict[str, object]]:
    manifest_root = get_manifest_root(dataset_name)
    distances = _distance_index(get_dataset_root(dataset_name))

    # (distance_m, width_norm, height_norm) for every labelled row that has a
    # known distance, so we can both summarise the <= threshold set and estimate
    # the size right at the boundary.
    victim_all: list[tuple[float, float, float]] = []
    with (manifest_root / "victim_bbox.csv").open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            distance = distances.get(f"{row['split']}/{row['image_path']}") or distances.get(row["image_path"])
            if distance is None:
                continue
            width = float(row["xmax"]) - float(row["xmin"])
            height = float(row["ymax"]) - float(row["ymin"])
            victim_all.append((distance, width, height))

    target_all: list[tuple[float, float, float]] = []
    with (manifest_root / "target_mask_manifest.csv").open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            distance = distances.get(f"{row['split']}/{row['image_path']}") or distances.get(row["image_path"])
            if distance is None:
                continue
            width = (float(row["bbox_xmax"]) - float(row["bbox_xmin"])) / FRAME_PX
            height = (float(row["bbox_ymax"]) - float(row["bbox_ymin"])) / FRAME_PX
            target_all.append((distance, width, height))

    if not victim_all:
        raise RuntimeError("No victim bbox rows with a known distance.")
    if not target_all:
        raise RuntimeError("No target bbox rows with a known distance.")

    result: dict[str, dict[str, object]] = {}
    for name, rows in (("victim", victim_all), ("target", target_all)):
        close = [(w, h, w * h) for d, w, h in rows if d <= max_distance_m]
        if not close:
            raise RuntimeError(f"No {name} rows with distance <= threshold.")
        summary = _summary([(w * FRAME_PX, h * FRAME_PX, a * FRAME_PX * FRAME_PX) for w, h, a in close])
        result[name] = {**summary, "gate": _gate(rows, max_distance_m)}
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="imagens_larc")
    parser.add_argument("--max-distance-m", type=float, default=0.06)
    parser.add_argument("--output", default="reports/bbox_gate_thresholds.json")
    args = parser.parse_args()

    payload = {
        "dataset_name": args.dataset_name,
        "max_distance_m": args.max_distance_m,
        "thresholds": compute(args.dataset_name, args.max_distance_m),
    }
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
