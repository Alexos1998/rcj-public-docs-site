#!/usr/bin/env python3
"""Validate camera-to-LiDAR projection and distance labels in extracted datasets."""

from __future__ import annotations

import argparse
import json
import math
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common.config import REPORTS_DIR, get_dataset_root


def _require_numpy():
    try:
        import numpy as np
    except ImportError as exc:
        raise RuntimeError("Install numpy before validating LiDAR projection.") from exc
    return np


def _json_load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _finite_float(value: Any) -> float | None:
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    return out if math.isfinite(out) else None


def _is_full_circle(n: int, angle_increment: float) -> bool:
    return n > 0 and angle_increment > 0.0 and abs(n * angle_increment - 2.0 * math.pi) < 0.05 * 2.0 * math.pi


def _angle_to_scan_index(theta: float, n: int, angle_min: float, angle_increment: float) -> int:
    if n <= 0 or not angle_increment > 0.0 or not math.isfinite(theta):
        return -1
    idx = round((theta - angle_min) / angle_increment)
    if 0 <= idx < n:
        return int(idx)
    if _is_full_circle(n, angle_increment):
        return int(idx % n)
    return -1


def _pixel_to_robot_angle(x: float, image_width: int, hfov_rad: float, yaw_offset_rad: float) -> float:
    fx = image_width / (2.0 * math.tan(hfov_rad / 2.0))
    cx = (image_width - 1) * 0.5
    return yaw_offset_rad + math.atan((x - cx) / fx)


def _project_indices(
    *,
    xmin: float,
    xmax: float,
    image_width: int,
    hfov_rad: float,
    yaw_offset_rad: float,
    scan_count: int,
    angle_min: float,
    angle_increment: float,
    extra: int,
) -> list[int]:
    xmin = max(0.0, min(float(xmin), float(image_width - 1)))
    xmax = max(0.0, min(float(xmax), float(image_width - 1)))
    if xmax < xmin:
        xmin, xmax = xmax, xmin
    i0 = _angle_to_scan_index(
        _pixel_to_robot_angle(xmin, image_width, hfov_rad, yaw_offset_rad),
        scan_count,
        angle_min,
        angle_increment,
    )
    i1 = _angle_to_scan_index(
        _pixel_to_robot_angle(xmax, image_width, hfov_rad, yaw_offset_rad),
        scan_count,
        angle_min,
        angle_increment,
    )
    if i0 < 0 and i1 < 0:
        return []

    full_circle = _is_full_circle(scan_count, angle_increment)
    indices: list[int] = []

    def add(idx: int) -> None:
        if full_circle:
            idx %= scan_count
        elif idx < 0 or idx >= scan_count:
            return
        if not indices or indices[-1] != idx:
            indices.append(idx)

    if i0 >= 0 and i1 >= 0:
        if full_circle:
            forward = (i1 - i0 + scan_count) % scan_count
            backward = (i0 - i1 + scan_count) % scan_count
            start = i0 if forward <= backward else i1
            span = min(forward, backward)
            for d in range(-extra, span + extra + 1):
                add(start + d)
        else:
            for idx in range(min(i0, i1) - extra, max(i0, i1) + extra + 1):
                add(idx)
    else:
        center = i0 if i0 >= 0 else i1
        for d in range(-extra, extra + 1):
            add(center + d)
    return indices


def _central_interval(box: dict[str, Any], image_width: int, fraction: float) -> tuple[float, float]:
    xmin = float(box["xmin"])
    xmax = float(box["xmax"])
    width = max(1.0, xmax - xmin)
    center = xmin + 0.5 * max(0.0, width - 1.0)
    half = max(1.0, width * max(0.05, min(fraction, 1.0)) * 0.5)
    return max(0.0, center - half), min(float(image_width - 1), center + half)


def _close_run(np, ranges, indices: list[int], max_close_range: float, min_consecutive: int) -> dict[str, Any]:
    valid = 0
    close = 0
    current = 0
    max_run = 0
    current_samples: list[float] = []
    best_samples: list[float] = []
    close_samples: list[float] = []
    for idx in indices:
        r = float(ranges[idx])
        is_valid = math.isfinite(r) and 0.01 <= r <= 1.0
        if is_valid:
            valid += 1
        is_close = is_valid and r <= max_close_range
        if is_close:
            close += 1
            current += 1
            current_samples.append(r)
            close_samples.append(r)
            if current > max_run:
                max_run = current
                best_samples = list(current_samples)
        else:
            current = 0
            current_samples.clear()

    samples = best_samples if max_run >= min_consecutive else close_samples
    distance = float(np.median(samples)) if samples else None
    return {
        "pass": max_run >= min_consecutive,
        "distance": distance,
        "valid_rays": valid,
        "close_rays": close,
        "max_consecutive": max_run,
    }


def _percentile_distance(np, ranges, indices: list[int], percentile: float) -> float | None:
    samples = [float(ranges[idx]) for idx in indices if math.isfinite(float(ranges[idx])) and 0.01 <= float(ranges[idx]) <= 1.0]
    if not samples:
        return None
    return float(np.percentile(np.asarray(samples, dtype=float), percentile, method="nearest"))


def _summarize(values: list[float]) -> dict[str, Any]:
    np = _require_numpy()
    finite = np.asarray([value for value in values if math.isfinite(value)], dtype=float)
    if finite.size == 0:
        return {"count": 0}
    return {
        "count": int(finite.size),
        "mean": float(finite.mean()),
        "median": float(np.median(finite)),
        "p10": float(np.percentile(finite, 10)),
        "p90": float(np.percentile(finite, 90)),
        "abs_le_0p02_rate": float(np.mean(np.abs(finite) <= 0.02)),
        "abs_le_0p05_rate": float(np.mean(np.abs(finite) <= 0.05)),
    }


def validate_one(path: Path, *, central_fraction: float, max_close_range: float, min_consecutive: int) -> dict[str, Any] | None:
    np = _require_numpy()
    payload = _json_load(path)
    npz_path = path.with_suffix(".npz")
    if not npz_path.exists():
        return None
    data = np.load(npz_path)
    scan = data["ros_scan_selected_layer"] if "ros_scan_selected_layer" in data else data["ros_scan_layers"][int(data["selected_layer"])]
    angles = data["angles_ros_like_rad"]
    image_width = int(payload.get("camera", {}).get("width", 64))
    hfov_rad = float(payload.get("camera", {}).get("hfov_rad", 1.5))
    yaw_offset = float(payload.get("camera", {}).get("yaw_offset_rad", 0.0))
    angle_min = float(angles[0])
    angle_increment = float(angles[1] - angles[0])
    sync = payload.get("sync", {})
    box = sync.get("object_bbox")
    interval = sync.get("object_bbox_pixel_interval") or [0, image_width - 1]
    xmin = float(box["xmin"]) if isinstance(box, dict) else float(interval[0])
    xmax = float(box["xmax"]) if isinstance(box, dict) else float(interval[1])
    full_indices = _project_indices(
        xmin=xmin,
        xmax=xmax,
        image_width=image_width,
        hfov_rad=hfov_rad,
        yaw_offset_rad=yaw_offset,
        scan_count=int(scan.shape[0]),
        angle_min=angle_min,
        angle_increment=angle_increment,
        extra=1,
    )
    stored_indices = data["object_bbox_indices"].astype(int).tolist() if "object_bbox_indices" in data else []
    central_indices: list[int] = []
    if isinstance(box, dict):
        cxmin, cxmax = _central_interval(box, image_width, central_fraction)
        central_indices = _project_indices(
            xmin=cxmin,
            xmax=cxmax,
            image_width=image_width,
            hfov_rad=hfov_rad,
            yaw_offset_rad=yaw_offset,
            scan_count=int(scan.shape[0]),
            angle_min=angle_min,
            angle_increment=angle_increment,
            extra=1,
        )

    real_distance = _finite_float(payload.get("distance", {}).get("robot_object_xz_m"))
    full_distance = _percentile_distance(np, scan, full_indices, 20.0)
    central_close = _close_run(np, scan, central_indices or full_indices, max_close_range, min_consecutive)
    return {
        "path": str(path),
        "object_kind": payload.get("object_kind", ""),
        "class": payload.get("class", ""),
        "split": str(path.relative_to(path.parents[5] if "fakes" in path.parts else path.parents[3])).split("/", 1)[0] if len(path.parts) else "",
        "has_object_bbox": isinstance(box, dict),
        "stored_indices_count": len(stored_indices),
        "full_indices_count": len(full_indices),
        "full_indices_match_stored": full_indices == stored_indices,
        "central_indices_count": len(central_indices),
        "central_subset_of_stored": set(central_indices).issubset(stored_indices) if stored_indices else False,
        "real_distance_xz_m": real_distance,
        "full_distance_p20_m": full_distance,
        "full_distance_error_m": None if real_distance is None or full_distance is None else full_distance - real_distance,
        "central_close": central_close,
        "central_distance_error_m": None if real_distance is None or central_close["distance"] is None else central_close["distance"] - real_distance,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="imagens_larc")
    parser.add_argument("--central-fraction", type=float, default=0.50)
    parser.add_argument("--max-close-range-m", type=float, default=0.06)
    parser.add_argument("--min-consecutive-rays", type=int, default=5)
    parser.add_argument("--limit", type=int, default=0)
    args = parser.parse_args()

    dataset_root = get_dataset_root(args.dataset_name)
    paths = sorted(dataset_root.rglob("lidar/*.json"))
    if args.limit > 0:
        paths = paths[: args.limit]

    rows = [
        row for row in (
            validate_one(
                path,
                central_fraction=args.central_fraction,
                max_close_range=args.max_close_range_m,
                min_consecutive=args.min_consecutive_rays,
            )
            for path in paths
        )
        if row is not None
    ]

    by_kind: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_kind[str(row["object_kind"])].append(row)

    def group_summary(group: list[dict[str, Any]]) -> dict[str, Any]:
        with_real = [row for row in group if row["real_distance_xz_m"] is not None]
        return {
            "rows": len(group),
            "with_real_distance": len(with_real),
            "full_indices_match_rate": sum(row["full_indices_match_stored"] for row in group) / len(group) if group else 0.0,
            "central_subset_rate": sum(row["central_subset_of_stored"] for row in group if row["has_object_bbox"]) / max(1, sum(row["has_object_bbox"] for row in group)),
            "full_distance_error_m": _summarize([row["full_distance_error_m"] for row in with_real if row["full_distance_error_m"] is not None]),
            "central_distance_error_m": _summarize([row["central_distance_error_m"] for row in with_real if row["central_distance_error_m"] is not None]),
            "central_close_pass_rate": sum(row["central_close"]["pass"] for row in group) / len(group) if group else 0.0,
            "central_close_rays_mean": sum(row["central_close"]["close_rays"] for row in group) / len(group) if group else 0.0,
            "classes": dict(Counter(str(row["class"]) for row in group)),
        }

    report = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "dataset": args.dataset_name,
        "config": {
            "central_fraction": args.central_fraction,
            "max_close_range_m": args.max_close_range_m,
            "min_consecutive_rays": args.min_consecutive_rays,
        },
        "total_rows": len(rows),
        "by_kind": {kind: group_summary(group) for kind, group in sorted(by_kind.items())},
        "bad_examples": [
            {
                "path": row["path"],
                "object_kind": row["object_kind"],
                "class": row["class"],
                "real_distance_xz_m": row["real_distance_xz_m"],
                "full_distance_p20_m": row["full_distance_p20_m"],
                "full_distance_error_m": row["full_distance_error_m"],
                "central_close": row["central_close"],
                "central_distance_error_m": row["central_distance_error_m"],
            }
            for row in rows
            if row["real_distance_xz_m"] is not None
            and row["full_distance_error_m"] is not None
            and abs(row["full_distance_error_m"]) > 0.05
        ][:25],
    }

    out = REPORTS_DIR / "lidar_distance_projection_validation.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print("report:", out)
    print(json.dumps({kind: summary for kind, summary in report["by_kind"].items()}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
