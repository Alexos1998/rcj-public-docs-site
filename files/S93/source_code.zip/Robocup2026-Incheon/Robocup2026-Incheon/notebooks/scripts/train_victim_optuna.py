"""Train victim localization with Optuna (30 trials × 150 epochs) + final 1200-epoch train.

Run: .venv/bin/python notebooks/scripts/train_victim_optuna.py
"""
from __future__ import annotations
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common.train_config import BBoxTrainConfig
from notebooks.common.training_runs import run_bbox_training

CONFIG = {
    "dataset_name": "imagens_larc",

    "input_size": 96,
    "batch_size": 64,
    "epochs": 1200,

    "bbox_model_type": "legacy_cnn",
    "bbox_loss_name": "combined",
    "saiou_lambda_center": 1.529124973633597,
    "saiou_lambda_corner": 1.151321268161352,
    "combined_saiou_weight": 1.0,
    "combined_smooth_l1_weight": 0.25,

    "optimizer_name": "adamw",
    "learning_rate": 0.001,
    "weight_decay": 0.0001,
    "adam_beta1": 0.9,
    "adam_beta2": 0.999,

    "scheduler_name": "cosine",
    "scheduler_eta_min": 1e-6,

    "dropout": 0.10,
    "base_channels": 48,

    "augment": True,
    "augment_brightness": 0.10,
    "augment_contrast": 0.15,
    "augment_degrees": 0.0,
    "augment_translate": 0.0,

    # Optuna
    "use_optuna": True,
    "optuna_n_trials": 30,
    "optuna_epochs": 150,
    "optuna_final_train": True,
    "optuna_pruner": "median",
    "optuna_metric": "val_mean_iou",
    "optuna_direction": "maximize",

    "optuna_lr_min": 3e-4,
    "optuna_lr_max": 2e-3,
    "optuna_weight_decay_min": 1e-6,
    "optuna_weight_decay_max": 5e-4,
    "optuna_dropout_min": 0.05,
    "optuna_dropout_max": 0.20,
    "optuna_base_channels_choices": (32, 48, 64),
    "optuna_batch_size_choices": (32, 64),
    "optuna_input_size_choices": (64, 96, 128),

    "optuna_saiou_lambda_center_min": 0.5,
    "optuna_saiou_lambda_center_max": 2.5,
    "optuna_saiou_lambda_corner_min": 0.5,
    "optuna_saiou_lambda_corner_max": 2.5,

    "device": "auto",
    "output_mode": "timestamped",
    "skip_if_missing": True,

    "show_samples": False,
    "show_training_plots": False,
    "save_metrics_json": True,
}
CONFIG["checkpoint_name"] = "victim_bbox_best.pt"
CONFIG["onnx_name"] = "victim_bbox.onnx"

cfg = BBoxTrainConfig.from_dict(CONFIG)
print(f"artifact_dir will be: {cfg.artifact_dir}")
result = run_bbox_training(cfg)

print("\n=== OPTUNA + FINAL TRAINING RESULT ===")
print(f"status:      {result.status}")
m = result.metrics

best_params_file = Path(cfg.artifact_dir) / "optuna_best_params.json"
if best_params_file.exists():
    bp = json.loads(best_params_file.read_text())
    print("\nOptuna best params:")
    print(json.dumps(bp, indent=2))

print(f"\nbest_epoch:  {m.get('best_epoch')}")
print(f"best_metric: {m.get('best_metric')}")

sm = m.get("split_metrics", {})
for split_name in ("train", "validation", "test"):
    s = sm.get(split_name, {})
    print(f"{split_name}.mean_iou:   {s.get('mean_iou', 'N/A')}")
    print(f"{split_name}.median_iou: {s.get('median_iou', 'N/A')}")

onnx_val = m.get("onnx_validation", {})
print(f"\nonnx_passed: {onnx_val.get('passed')}")

worst = m.get("worst_prediction_examples", [])
print(f"\nworst {len(worst)} examples:")
for ex in worst[:5]:
    print(f"  iou={round(ex['iou'], 4)} label={ex['label_name']} img={Path(ex['image_path']).name}")

print("\nCheckpoint:", m.get("artifacts", {}).get("checkpoint"))
print("ONNX:      ", m.get("artifacts", {}).get("onnx"))
print("Metrics:   ", m.get("artifacts", {}).get("metrics"))
