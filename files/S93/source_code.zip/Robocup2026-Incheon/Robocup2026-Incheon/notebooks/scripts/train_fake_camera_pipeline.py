#!/usr/bin/env python3
"""Retrain the camera pipeline pieces that need fake-victim awareness."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common.train_config import ClassificationTrainConfig
from notebooks.common.training_runs import run_classification_training
from notebooks.scripts import export_controller_runtime_assets


def run_step(cmd: list[str]) -> None:
    print("\n$", " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=ROOT, check=True)


def train_object_presence(args: argparse.Namespace):
    return run_classification_training(
        ClassificationTrainConfig(
            task_name="object_presence",
            dataset_name=args.dataset_name,
            labels=["none", "target", "victim"],
            manifest_filename="object_presence_with_fake.csv",
            input_size=48,
            batch_size=args.batch_size,
            epochs=args.object_presence_epochs,
            learning_rate=0.001,
            weight_decay=0.0001,
            num_workers=args.num_workers,
            dropout=0.08,
            base_channels=24,
            seed=args.seed,
            augment=True,
            augment_degrees=8.0,
            augment_brightness=0.12,
            augment_contrast=0.12,
            augment_translate=0.05,
            device=args.device,
            output_mode="timestamped",
            update_latest=True,
            model_dir_name="object_presence",
            checkpoint_name="object_presence_best.pt",
            onnx_name="object_presence.onnx",
            show_samples=False,
            show_training_plots=False,
        )
    )


def train_victim_cls(args: argparse.Namespace):
    return run_classification_training(
        ClassificationTrainConfig(
            task_name="victim_cls",
            dataset_name=args.dataset_name,
            labels=["harmed", "unharmed", "stable", "none", "fake"],
            manifest_filename=args.victim_manifest,
            input_size=96,
            batch_size=args.batch_size,
            epochs=args.victim_epochs,
            learning_rate=0.001,
            weight_decay=0.0001,
            num_workers=args.num_workers,
            dropout=0.18,
            base_channels=64,
            seed=args.seed,
            augment=True,
            augment_degrees=90.0,
            augment_brightness=0.18,
            augment_contrast=0.18,
            augment_translate=0.10,
            device=args.device,
            output_mode="timestamped",
            update_latest=True,
            model_dir_name="victim",
            checkpoint_name="victim_cls_best.pt",
            onnx_name="victim_cls.onnx",
            show_samples=False,
            show_training_plots=False,
        )
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="imagens_larc")
    parser.add_argument("--object-presence-epochs", type=int, default=80)
    parser.add_argument("--victim-epochs", type=int, default=140)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--skip-manifest-export", action="store_true")
    parser.add_argument("--skip-object-presence", action="store_true")
    parser.add_argument("--victim-manifest", default="victim_classification_with_fake_balanced.csv")
    parser.add_argument("--deploy", action="store_true")
    args = parser.parse_args()

    if not args.skip_manifest_export:
        run_step([sys.executable, "notebooks/scripts/export_fake_lidar_manifests.py", "--dataset-name", args.dataset_name])

    results = {}
    if not args.skip_object_presence:
        results["object_presence"] = train_object_presence(args)
    results["victim_cls"] = train_victim_cls(args)
    if args.deploy:
        export_controller_runtime_assets.generate(args.dataset_name)

    summary = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "dataset": args.dataset_name,
        "results": {
            name: {
                "status": result.status,
                "best_epoch": result.best_epoch,
                "best_metric": result.best_metric,
                "onnx": str(result.onnx_path) if result.onnx_path else None,
                "metrics": str(result.metrics_path) if result.metrics_path else None,
                "test": result.metrics.get("test"),
                "validation": result.metrics.get("validation"),
            }
            for name, result in results.items()
        },
    }
    out = ROOT / "models" / "fake_camera_pipeline_training_summary.json"
    out.write_text(json.dumps(summary, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
    print("\nsummary:", out)
    print(json.dumps(summary["results"], indent=2, sort_keys=True, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
