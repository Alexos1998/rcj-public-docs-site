#!/usr/bin/env python3
"""Export perception CSV manifests from a supervisor-generated image dataset."""

from __future__ import annotations

import argparse
import csv
import sys
from dataclasses import dataclass
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from notebooks.common.config import get_dataset_root, get_manifest_root


IMAGE_SUFFIXES = {".bmp", ".jpeg", ".jpg", ".png", ".webp"}
SPLITS = ("train", "validation", "test")

PRESENCE_MAPPING = {
    "none": (0, "none"),
    "harmed": (1, "object"),
    "unharmed": (1, "object"),
    "stable": (1, "object"),
    "cognitive": (1, "object"),
    "obstacle": (1, "object"),
}

OBJECT_TYPE_MAPPING = {
    "cognitive": (0, "target"),
    "harmed": (1, "victim"),
    "unharmed": (1, "victim"),
    "stable": (1, "victim"),
}

VICTIM_CLASSIFICATION_MAPPING = {
    "harmed": (0, "harmed"),
    "unharmed": (1, "unharmed"),
    "stable": (2, "stable"),
}

VICTIM_CLASSES = frozenset(VICTIM_CLASSIFICATION_MAPPING)


class MissingBBoxAnnotationsError(RuntimeError):
    """Raised when victim bbox export is requested without annotations."""


@dataclass(frozen=True)
class ImageRecord:
    split: str
    class_name: str
    image_path: Path
    relative_path: Path


def scan_dataset(dataset_root: Path) -> list[ImageRecord]:
    records: list[ImageRecord] = []
    for split in SPLITS:
        split_dir = dataset_root / split
        if not split_dir.exists():
            continue
        for class_dir in sorted(path for path in split_dir.iterdir() if path.is_dir()):
            class_name = class_dir.name.lower()
            image_root = class_dir / "images"
            search_root = image_root if image_root.exists() else class_dir
            for image_path in sorted(search_root.rglob("*")):
                if image_path.is_file() and image_path.suffix.lower() in IMAGE_SUFFIXES:
                    if "masks" in image_path.relative_to(class_dir).parts:
                        continue
                    records.append(
                        ImageRecord(
                            split=split,
                            class_name=class_name,
                            image_path=image_path.resolve(),
                            relative_path=image_path.relative_to(split_dir),
                        )
                    )
    return records


def write_classification_manifest(
    records: list[ImageRecord],
    mapping: dict[str, tuple[int, str]],
    output_path: Path,
) -> int:
    rows = []
    for record in records:
        if record.class_name not in mapping:
            continue
        label, label_name = mapping[record.class_name]
        rows.append(
            {
                "split": record.split,
                "image_path": record.relative_path.as_posix(),
                "label": label,
                "label_name": label_name,
            }
        )
    write_csv(output_path, ["split", "image_path", "label", "label_name"], rows)
    return len(rows)


def load_bbox_annotations(path: Path) -> dict[str, tuple[float, float, float, float]]:
    """Load bbox annotations keyed by image path, filename, or relative path.

    Required columns: image_path, xmin, ymin, xmax, ymax.
    Coordinates must already be normalized to [0, 1].
    """

    annotations: dict[str, tuple[float, float, float, float]] = {}
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        required = {"image_path", "xmin", "ymin", "xmax", "ymax"}
        missing = required.difference(reader.fieldnames or ())
        if missing:
            raise ValueError(f"BBox annotation CSV is missing columns: {sorted(missing)}")

        for row in reader:
            bbox = tuple(float(row[name]) for name in ("xmin", "ymin", "xmax", "ymax"))
            validate_normalized_bbox(bbox, row["image_path"])
            key = row["image_path"]
            annotations[key] = bbox
            annotations[Path(key).as_posix()] = bbox
            annotations[Path(key).name] = bbox
            try:
                annotations[str(Path(key).resolve())] = bbox
            except OSError:
                pass
    return annotations


def find_mask_for_image(image_path: Path) -> Path | None:
    """Return a paired mask path for an image when a real mask file exists."""

    if image_path.parent.name == "images":
        class_dir = image_path.parent.parent
    else:
        class_dir = image_path.parent
    mask_dir = class_dir / "masks"
    if not mask_dir.exists():
        return None

    candidates = []
    if image_path.stem.startswith("image_"):
        stem_without_prefix = image_path.stem[len("image_") :]
        candidates.append(mask_dir / f"mask_binary_{stem_without_prefix}{image_path.suffix}")
        candidates.append(mask_dir / f"mask_{stem_without_prefix}{image_path.suffix}")
    candidates.append(mask_dir / image_path.name)
    candidates.append(mask_dir / f"{image_path.stem.replace('image_', 'mask_', 1)}{image_path.suffix}")

    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def bbox_from_mask(mask_path: Path) -> tuple[float, float, float, float] | None:
    """Convert a non-empty binary/label mask into a normalized bounding box."""

    try:
        import numpy as np
        from PIL import Image
    except ImportError as exc:
        raise RuntimeError("Install numpy and pillow to derive bbox annotations from masks.") from exc

    with Image.open(mask_path) as mask:
        array = np.asarray(mask.convert("L"))

    foreground_y, foreground_x = np.nonzero(array > 0)
    if foreground_x.size == 0 or foreground_y.size == 0:
        return None

    height, width = array.shape[:2]
    xmin = float(foreground_x.min()) / width
    ymin = float(foreground_y.min()) / height
    xmax = float(foreground_x.max() + 1) / width
    ymax = float(foreground_y.max() + 1) / height
    bbox = (xmin, ymin, xmax, ymax)
    validate_normalized_bbox(bbox, str(mask_path))
    return bbox


def load_mask_bbox_annotations(
    records: list[ImageRecord],
    dataset_root: Path,
) -> dict[str, tuple[float, float, float, float]]:
    """Load victim bbox annotations from paired real mask files."""

    annotations: dict[str, tuple[float, float, float, float]] = {}
    missing_images: list[str] = []
    found = 0

    for record in records:
        if record.class_name not in VICTIM_CLASSES:
            continue
        mask_path = find_mask_for_image(record.image_path)
        if mask_path is None:
            missing_images.append(str(record.image_path))
            continue
        bbox = bbox_from_mask(mask_path)
        if bbox is None:
            missing_images.append(f"{record.image_path} (empty mask: {mask_path})")
            continue
        found += 1
        annotations[record_key(dataset_root, record.image_path)] = bbox
        annotations[record.image_path.name] = bbox
        annotations[str(record.image_path)] = bbox
        annotations[str(record.image_path.resolve())] = bbox
        annotations[record.image_path.relative_to(dataset_root).as_posix()] = bbox

    if found == 0:
        raise MissingBBoxAnnotationsError(
            "No paired non-empty victim mask files were found. "
            "victim_bbox.csv will not be generated; bounding boxes are not inferred."
        )
    if missing_images:
        preview = "\n".join(missing_images[:10])
        raise MissingBBoxAnnotationsError(
            f"Found paired victim masks for {found} images, but {len(missing_images)} victim images "
            f"were missing usable mask annotations. First missing paths:\n{preview}"
        )

    return annotations


def find_bbox(
    annotations: dict[str, tuple[float, float, float, float]],
    dataset_root: Path,
    image_path: Path,
) -> tuple[float, float, float, float] | None:
    keys = (
        record_key(dataset_root, image_path),
        str(image_path),
        str(image_path.resolve()),
        image_path.relative_to(dataset_root).as_posix(),
        image_path.name,
    )
    for key in keys:
        if key in annotations:
            return annotations[key]
    return None


def record_key(dataset_root: Path, image_path: Path) -> str:
    relative_to_dataset = image_path.relative_to(dataset_root)
    if len(relative_to_dataset.parts) > 1 and relative_to_dataset.parts[0] in SPLITS:
        return Path(*relative_to_dataset.parts[1:]).as_posix()
    return relative_to_dataset.as_posix()


def write_victim_bbox_manifest(
    records: list[ImageRecord],
    dataset_root: Path,
    output_path: Path,
    bbox_annotations: Path | None,
) -> int:
    annotations = (
        load_bbox_annotations(bbox_annotations)
        if bbox_annotations is not None
        else load_mask_bbox_annotations(records, dataset_root)
    )
    rows = []
    missing_images = []
    for record in records:
        if record.class_name not in VICTIM_CLASSES:
            continue
        bbox = find_bbox(annotations, dataset_root, record.image_path)
        if bbox is None:
            missing_images.append(str(record.image_path))
            continue
        xmin, ymin, xmax, ymax = bbox
        label, label_name = VICTIM_CLASSIFICATION_MAPPING[record.class_name]
        rows.append(
            {
                "split": record.split,
                "image_path": record.relative_path.as_posix(),
                "label": label,
                "xmin": xmin,
                "ymin": ymin,
                "xmax": xmax,
                "ymax": ymax,
                "label_name": label_name,
            }
        )

    if missing_images:
        preview = "\n".join(missing_images[:10])
        raise MissingBBoxAnnotationsError(
            f"Missing bbox annotations for {len(missing_images)} victim images. First missing paths:\n{preview}"
        )

    write_csv(output_path, ["split", "image_path", "label", "label_name", "xmin", "ymin", "xmax", "ymax"], rows)
    return len(rows)


def validate_normalized_bbox(bbox: tuple[float, float, float, float], source: str) -> None:
    xmin, ymin, xmax, ymax = bbox
    if not all(0.0 <= value <= 1.0 for value in bbox):
        raise ValueError(f"BBox for {source} is not normalized to [0, 1]: {bbox}")
    if xmin >= xmax or ymin >= ymax:
        raise ValueError(f"BBox for {source} has invalid coordinate order: {bbox}")


def write_csv(output_path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "dataset_root",
        nargs="?",
        type=Path,
        help="Dataset root containing train/validation/test folders. Defaults to data/extracted/<dataset-name>.",
    )
    parser.add_argument(
        "--dataset-root",
        dest="dataset_root_option",
        type=Path,
        default=None,
        help="Dataset root containing train/validation/test folders.",
    )
    parser.add_argument(
        "--dataset-name",
        default=None,
        help="Dataset name used for default extracted and manifest directories.",
    )
    parser.add_argument(
        "--output-dir",
        "--manifest-root",
        dest="output_dir",
        type=Path,
        default=None,
        help="Directory where manifest CSV files will be written. Defaults to data/manifests/<dataset-name>.",
    )
    parser.add_argument(
        "--bbox-annotations",
        type=Path,
        default=None,
        help="CSV with image_path,xmin,ymin,xmax,ymax for victim bbox training.",
    )
    args = parser.parse_args()

    dataset_root_arg = args.dataset_root_option or args.dataset_root
    dataset_name = args.dataset_name or (dataset_root_arg.name if dataset_root_arg else None)
    if dataset_name is None:
        raise SystemExit("Provide either dataset_root or --dataset-name.")

    dataset_root = (dataset_root_arg or get_dataset_root(dataset_name)).resolve()
    records = scan_dataset(dataset_root)
    if not records:
        raise SystemExit(f"No images found under {dataset_root} with splits {SPLITS}.")

    output_dir = (args.output_dir or get_manifest_root(dataset_name)).resolve()
    counts = {
        "presence.csv": write_classification_manifest(records, PRESENCE_MAPPING, output_dir / "presence.csv"),
        "object_type.csv": write_classification_manifest(records, OBJECT_TYPE_MAPPING, output_dir / "object_type.csv"),
        "victim_classification.csv": write_classification_manifest(
            records,
            VICTIM_CLASSIFICATION_MAPPING,
            output_dir / "victim_classification.csv",
        ),
    }

    bbox_path = output_dir / "victim_bbox.csv"
    if bbox_path.exists():
        bbox_path.unlink()
    try:
        bbox_count = write_victim_bbox_manifest(
            records,
            dataset_root,
            bbox_path,
            args.bbox_annotations,
        )
        counts["victim_bbox.csv"] = bbox_count
    except MissingBBoxAnnotationsError as exc:
        print(
            "WARNING: victim_bbox.csv skipped because real bbox annotations were unavailable. "
            f"{exc}"
        )

    for filename, count in counts.items():
        print(f"Wrote {count} rows to {output_dir / filename}")


if __name__ == "__main__":
    main()
