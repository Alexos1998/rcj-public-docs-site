#!/usr/bin/env python3
"""Build camera/lidar manifests for fake victims.

The fake captures live under ``notebooks/data/extracted/<dataset>/fakes`` with
one JSON and one NPZ per camera frame. This script keeps those files in place
and writes training manifests that the existing image loaders can resolve via
``dataset_root / split / image_path`` by using ``../fakes/...`` relative paths.
"""

from __future__ import annotations

import argparse
import csv
import json
import random
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common.config import get_dataset_root, get_manifest_root
from notebooks.common.datasets import read_csv_manifest

VICTIM_LABELS = ["harmed", "unharmed", "stable", "none", "fake"]
OBJECT_PRESENCE_LABELS = ["none", "target", "victim"]


def _float(value: Any, default: float = float("nan")) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _load_npz_stats(path: Path, threshold_m: float) -> dict[str, str]:
    if not path.exists():
        return {
            "lidar_npz_exists": "false",
            "lidar_selected_layer": "",
            "lidar_count": "0",
            "lidar_min_range_m": "",
            "lidar_object_bbox_min_m": "",
            "lidar_object_bbox_close_rays": "0",
        }
    try:
        import numpy as np

        data = np.load(path)
        selected_layer = int(data["selected_layer"]) if "selected_layer" in data else 2
        scan = data["ros_scan_selected_layer"] if "ros_scan_selected_layer" in data else data["ros_scan_layers"][selected_layer]
        finite_scan = scan[np.isfinite(scan)]
        bbox_ranges = data["object_bbox_ranges_layers"]
        if bbox_ranges.ndim == 2:
            bbox_ranges = bbox_ranges[selected_layer]
        finite_bbox = bbox_ranges[np.isfinite(bbox_ranges)]
        return {
            "lidar_npz_exists": "true",
            "lidar_selected_layer": str(selected_layer),
            "lidar_count": str(int(scan.size)),
            "lidar_min_range_m": f"{float(finite_scan.min()):.9f}" if finite_scan.size else "",
            "lidar_object_bbox_min_m": f"{float(finite_bbox.min()):.9f}" if finite_bbox.size else "",
            "lidar_object_bbox_close_rays": str(int((finite_bbox <= threshold_m).sum())),
        }
    except Exception as exc:  # pragma: no cover - diagnostics for local datasets.
        return {
            "lidar_npz_exists": "error",
            "lidar_selected_layer": "",
            "lidar_count": "0",
            "lidar_min_range_m": "",
            "lidar_object_bbox_min_m": "",
            "lidar_object_bbox_close_rays": "0",
            "lidar_error": str(exc),
        }


def _fake_row(json_path: Path, fake_root: Path, threshold_m: float) -> dict[str, str]:
    payload = json.loads(json_path.read_text(encoding="utf-8"))
    split = str(payload["image_path"]).split("/", 1)[0]
    image_path = f"../fakes/{payload['image_path']}"
    mask_path = f"../fakes/{payload.get('mask_path', '')}" if payload.get("mask_path") else ""
    npz_rel = payload.get("npz_path", "")
    npz_path = fake_root / npz_rel if npz_rel else Path()
    bbox = payload.get("sync", {}).get("object_bbox", {})
    distance = payload.get("distance", {})
    row = {
        "split": split,
        "image_path": image_path,
        "label": "4",
        "label_name": "fake",
        "negative_source": "fake_camera_lidar",
        "fake_class": str(payload.get("class", "")),
        "object_kind": str(payload.get("object_kind", "fake")),
        "capture_id": str(payload.get("capture_id", "")),
        "json_path": f"../fakes/{json_path.relative_to(fake_root)}",
        "npz_path": f"../fakes/{npz_rel}" if npz_rel else "",
        "mask_path": mask_path,
        "camera_name": str(payload.get("camera", {}).get("name", "")),
        "real_distance_xz_m": f"{_float(distance.get('robot_object_xz_m')):.9f}",
        "real_distance_3d_m": f"{_float(distance.get('robot_object_3d_m')):.9f}",
        "bbox_xmin": str(bbox.get("xmin", "")),
        "bbox_ymin": str(bbox.get("ymin", "")),
        "bbox_xmax": str(bbox.get("xmax", "")),
        "bbox_ymax": str(bbox.get("ymax", "")),
        "bbox_area_px": str(bbox.get("area_px", "")),
    }
    row.update(_load_npz_stats(npz_path, threshold_m))
    return row


def _write_csv(path: Path, rows: list[dict[str, str]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _normalize_existing_victim_rows(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    label_to_id = {label: str(index) for index, label in enumerate(VICTIM_LABELS)}
    out = []
    for row in rows:
        item = dict(row)
        label_name = item.get("label_name", "")
        if label_name in label_to_id:
            item["label"] = label_to_id[label_name]
        out.append(item)
    return out


def _balanced_victim_rows(rows: list[dict[str, str]], seed: int) -> list[dict[str, str]]:
    """Keep every scarce H/U/S row and downsample abundant none/fake per split."""

    rng = random.Random(seed)
    out = []
    for split in ("train", "validation", "test"):
        split_rows = [row for row in rows if row.get("split") == split]
        by_label = {label: [row for row in split_rows if row.get("label_name") == label] for label in VICTIM_LABELS}
        real_counts = [len(by_label[label]) for label in ("harmed", "unharmed", "stable") if by_label[label]]
        cap = min(real_counts) if real_counts else 0
        for label in VICTIM_LABELS:
            candidates = list(by_label[label])
            if label in {"none", "fake"} and cap > 0 and len(candidates) > cap:
                candidates = rng.sample(candidates, cap)
            out.extend(candidates)
    return sorted(out, key=lambda row: (row.get("split", ""), row.get("label", ""), row.get("image_path", "")))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="imagens_larc")
    parser.add_argument("--distance-threshold-m", type=float, default=0.06)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    dataset_root = get_dataset_root(args.dataset_name)
    manifest_root = get_manifest_root(args.dataset_name)
    fake_root = dataset_root / "fakes"
    if not fake_root.exists():
        raise SystemExit(f"fake dataset not found: {fake_root}")

    fake_rows = [
        _fake_row(path, fake_root, args.distance_threshold_m)
        for path in sorted(fake_root.rglob("*.json"))
    ]
    if not fake_rows:
        raise SystemExit(f"no fake json files found under {fake_root}")

    fake_fields = list(fake_rows[0].keys())
    _write_csv(manifest_root / "fake_lidar.csv", fake_rows, fake_fields)

    victim_base = _normalize_existing_victim_rows(
        read_csv_manifest(manifest_root / "victim_classification_with_none.csv")
    )
    victim_fields = list(dict.fromkeys([*(victim_base[0].keys() if victim_base else []), *fake_fields]))
    _write_csv(
        manifest_root / "victim_classification_with_fake.csv",
        victim_base + fake_rows,
        victim_fields,
    )
    balanced_victim = _balanced_victim_rows(victim_base + fake_rows, args.seed)
    _write_csv(
        manifest_root / "victim_classification_with_fake_balanced.csv",
        balanced_victim,
        victim_fields,
    )

    presence_base = read_csv_manifest(manifest_root / "object_presence.csv")
    presence_fake_rows = []
    for row in fake_rows:
        item = dict(row)
        item["label"] = str(OBJECT_PRESENCE_LABELS.index("victim"))
        item["label_name"] = "victim"
        presence_fake_rows.append(item)
    presence_fields = list(dict.fromkeys([*(presence_base[0].keys() if presence_base else []), *fake_fields]))
    _write_csv(
        manifest_root / "object_presence_with_fake.csv",
        presence_base + presence_fake_rows,
        presence_fields,
    )

    print(f"fake_lidar rows={len(fake_rows)}")
    print(f"victim_classification_with_fake rows={len(victim_base) + len(fake_rows)}")
    print(f"victim_classification_with_fake_balanced rows={len(balanced_victim)}")
    print(f"object_presence_with_fake rows={len(presence_base) + len(fake_rows)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
