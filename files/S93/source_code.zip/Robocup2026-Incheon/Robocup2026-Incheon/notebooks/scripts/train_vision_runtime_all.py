#!/usr/bin/env python3
"""Train and deploy the camera-only vision runtime models.

This script is intentionally independent from controller/mapsdataset. It uses
the supervisor/notebook manifests under notebooks/data/manifests/<dataset>.
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common.train_config import BBoxTrainConfig, ClassificationTrainConfig
from notebooks.common.training_runs import run_bbox_training, run_classification_training
from notebooks.scripts import export_controller_runtime_assets


def run_step(cmd: list[str]) -> None:
    print("\n$", " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=ROOT, check=True)


def backup_file(path: Path) -> str | None:
    if not path.exists():
        return None
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = path.with_name(f"{path.stem}.backup_{stamp}{path.suffix}")
    shutil.copy2(path, backup)
    return str(backup)


def copy_deploy(src: Path, dest: Path) -> dict:
    if not src.exists():
        raise FileNotFoundError(src)
    dest.parent.mkdir(parents=True, exist_ok=True)
    backup = backup_file(dest)
    shutil.copy2(src, dest)
    return {"source": str(src), "dest": str(dest), "backup": backup}


def train_object_presence(args: argparse.Namespace):
    cfg = ClassificationTrainConfig(
        task_name="object_presence",
        dataset_name=args.dataset_name,
        labels=["none", "target", "victim"],
        manifest_filename="object_presence.csv",
        input_size=48,
        batch_size=args.batch_size,
        epochs=args.classification_epochs,
        learning_rate=0.001,
        weight_decay=0.0001,
        num_workers=args.num_workers,
        dropout=0.08,
        base_channels=24,
        seed=args.seed,
        augment=True,
        augment_degrees=8.0,
        augment_brightness=0.12,
        augment_contrast=0.12,
        augment_translate=0.05,
        device=args.device,
        output_mode="timestamped",
        update_latest=True,
        model_dir_name="object_presence",
        checkpoint_name="object_presence_best.pt",
        onnx_name="object_presence.onnx",
        show_samples=False,
        show_training_plots=True,
    )
    return run_classification_training(cfg)


def train_presence(args: argparse.Namespace):
    cfg = ClassificationTrainConfig(
        task_name="presence",
        dataset_name=args.dataset_name,
        labels=["none", "object"],
        manifest_filename="presence.csv",
        input_size=48,
        batch_size=args.batch_size,
        epochs=args.classification_epochs,
        learning_rate=0.001,
        weight_decay=0.0001,
        num_workers=args.num_workers,
        dropout=0.08,
        base_channels=24,
        seed=args.seed,
        augment=True,
        augment_degrees=8.0,
        augment_brightness=0.12,
        augment_contrast=0.12,
        augment_translate=0.05,
        device=args.device,
        output_mode="timestamped",
        update_latest=True,
        model_dir_name="presence",
        checkpoint_name="presence_best.pt",
        onnx_name="presence.onnx",
        show_samples=False,
        show_training_plots=True,
    )
    return run_classification_training(cfg)


def train_object_type(args: argparse.Namespace):
    cfg = ClassificationTrainConfig(
        task_name="object_type",
        dataset_name=args.dataset_name,
        labels=["target", "victim"],
        manifest_filename="object_type.csv",
        input_size=32,
        batch_size=args.batch_size,
        epochs=args.classification_epochs,
        learning_rate=0.001,
        weight_decay=0.0001,
        num_workers=args.num_workers,
        dropout=0.08,
        base_channels=24,
        seed=args.seed,
        augment=True,
        augment_degrees=8.0,
        augment_brightness=0.12,
        augment_contrast=0.12,
        augment_translate=0.05,
        device=args.device,
        output_mode="timestamped",
        update_latest=True,
        model_dir_name="object_type",
        checkpoint_name="object_type_best.pt",
        onnx_name="object_type.onnx",
        show_samples=False,
        show_training_plots=True,
    )
    return run_classification_training(cfg)


def train_victim_cls(args: argparse.Namespace):
    cfg = ClassificationTrainConfig(
        task_name="victim_cls",
        dataset_name=args.dataset_name,
        labels=["harmed", "unharmed", "stable", "none"],
        manifest_filename="victim_classification_with_none.csv",
        input_size=96,
        batch_size=args.batch_size,
        epochs=args.victim_epochs,
        learning_rate=0.001,
        weight_decay=0.0001,
        num_workers=args.num_workers,
        dropout=0.18,
        base_channels=64,
        seed=args.seed,
        augment=True,
        augment_degrees=90.0,
        augment_brightness=0.18,
        augment_contrast=0.18,
        augment_translate=0.10,
        device=args.device,
        output_mode="timestamped",
        update_latest=True,
        model_dir_name="victim",
        checkpoint_name="victim_cls_best.pt",
        onnx_name="victim_cls.onnx",
        show_samples=False,
        show_training_plots=True,
    )
    return run_classification_training(cfg)


def train_victim_bbox(args: argparse.Namespace):
    cfg = BBoxTrainConfig(
        task_name="victim_bbox",
        dataset_name=args.dataset_name,
        labels=["none", "victim"],
        manifest_filename="victim_bbox_with_none.csv",
        input_size=96,
        batch_size=args.batch_size,
        epochs=args.bbox_epochs,
        learning_rate=0.001,
        weight_decay=0.0001,
        num_workers=args.num_workers,
        dropout=0.10,
        base_channels=48,
        seed=args.seed,
        augment=True,
        augment_brightness=0.10,
        augment_contrast=0.15,
        device=args.device,
        output_mode="timestamped",
        update_latest=True,
        model_dir_name="victim",
        checkpoint_name="victim_bbox_best.pt",
        onnx_name="victim_bbox.onnx",
        bbox_model_type="legacy_cnn",
        bbox_loss_name="combined",
        combined_saiou_weight=1.0,
        combined_smooth_l1_weight=0.25,
        show_samples=False,
        show_training_plots=True,
    )
    return run_bbox_training(cfg)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="imagens_larc")
    parser.add_argument("--classification-epochs", type=int, default=90)
    parser.add_argument("--victim-epochs", type=int, default=140)
    parser.add_argument("--bbox-epochs", type=int, default=180)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--skip-manifest-refresh", action="store_true")
    parser.add_argument("--skip-object-presence", action="store_true")
    parser.add_argument("--skip-target-rf", action="store_true")
    parser.add_argument("--skip-legacy-chain", action="store_true")
    parser.add_argument("--deploy", action="store_true")
    args = parser.parse_args()

    py = sys.executable
    if not args.skip_manifest_refresh:
        run_step([py, "notebooks/scripts/export_dataset_manifest.py", "--dataset-name", args.dataset_name])
        run_step([py, "notebooks/scripts/export_target_localization.py", "--dataset-name", args.dataset_name])
        run_step([py, "notebooks/scripts/export_target_projection_manifest.py", "--dataset-name", args.dataset_name])
        run_step([py, "notebooks/scripts/export_target_mask_manifest.py", "--dataset-name", args.dataset_name])
        run_step([py, "notebooks/scripts/export_negative_localization_manifests.py", "--dataset-name", args.dataset_name])
        run_step([py, "notebooks/scripts/build_object_presence_manifest.py"])
        run_step([py, "notebooks/scripts/clean_manifest_split_leakage.py", "--dataset-name", args.dataset_name])

    results = {}
    if not args.skip_object_presence:
        results["object_presence"] = train_object_presence(args)
    results["victim_cls"] = train_victim_cls(args)
    results["victim_bbox"] = train_victim_bbox(args)
    if not args.skip_legacy_chain:
        results["presence"] = train_presence(args)
        results["object_type"] = train_object_type(args)
    if not args.skip_target_rf:
        run_step([
            py,
            "notebooks/scripts/train_target_mask_rf.py",
            "--dataset-name",
            args.dataset_name,
            "--no-overlays",
        ])

    deploy_info = {}
    if args.deploy:
        controller_models = ROOT / "controller" / "models"
        for name in ("object_presence", "presence", "object_type", "victim_bbox", "victim_cls"):
            result = results.get(name)
            if result is None:
                continue
            deploy_info[f"{name}.onnx"] = copy_deploy(
                Path(result.onnx_path), controller_models / f"{name}.onnx"
            )
            metadata = Path(result.onnx_path).with_suffix(".metadata.json")
            if metadata.exists():
                deploy_info[f"{name}.metadata.json"] = copy_deploy(
                    metadata, controller_models / f"{name}.metadata.json"
                )
        export_controller_runtime_assets.generate(args.dataset_name)

    summary = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "dataset": args.dataset_name,
        "deploy": deploy_info,
        "results": {
            name: {
                "status": result.status,
                "best_epoch": result.best_epoch,
                "best_metric": result.best_metric,
                "onnx": str(result.onnx_path),
                "metrics": str(result.metrics_path) if result.metrics_path else None,
                "test": result.metrics.get("test"),
                "validation": result.metrics.get("validation"),
            }
            for name, result in results.items()
        },
    }
    out = ROOT / "models" / "vision_runtime_training_summary.json"
    out.write_text(json.dumps(summary, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
    print("\nsummary:", out)
    print(json.dumps(summary["results"], indent=2, sort_keys=True, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
