#!/usr/bin/env python3
"""Smoke checks for WBT-backed map labels.

Run with:
    python notebooks/scripts/smoke_wbt_labels.py
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common import map_dataset as md
from notebooks.common import map_wbt as mw


def _find_example_wbt() -> Path | None:
    candidates = [
        Path("/home/isaac/Documents/erebus/game/worlds/Day1_1 - 2026 - fakes.wbt"),
        Path("/home/isaac/Documents/erebus/game/worlds/Day_1-1 - 2026 - fakes.wbt"),
    ]
    for path in candidates:
        if path.is_file():
            return path
    return None


def _synthetic_run() -> dict:
    rows = [
        "111111111",
        "151000000",
        "101000000",
        "151000000",
        "100000001",
        "100000001",
        "100000001",
        "100000001",
        "111111111",
    ]
    text = "\n".join(rows)
    grid = np.full((80, 80), 0, dtype=np.int8)
    grid[:3, :] = 100
    meta = {"map": {"resolution": md.DEFAULT_RES, "origin": {"x": 0.0, "y": 0.0}}}
    return {
        "run_id": "synthetic",
        "run_dir": Path("."),
        "grid": grid,
        "meta": meta,
        "submission": text,
        "real": text,
        "wbt_path": None,
    }


def _subtile_fingerprint(samples) -> list[tuple]:
    return [
        (
            s.tile_r,
            s.tile_c,
            s.quarter,
            tuple(s.real.walls[d] for d in md.DIRS),
            s.real.curve,
            s.real.obstacle,
            s.real.is_area4,
        )
        for s in samples
    ]


def _tile_fingerprint(samples) -> list[tuple]:
    return [
        (t.tile_r, t.tile_c, t.obstacle, t.submission_obstacle, t.is_area4)
        for t in samples
    ]


def main() -> int:
    checks: list[tuple[str, bool]] = []

    def check(name: str, cond: bool) -> None:
        checks.append((name, bool(cond)))
        print(f"[{'OK' if cond else 'FAIL'}] {name}")

    # Parser should ignore EXTERNPROTO path mentions.
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "externproto_test.wbt"
        path.write_text(
            '#VRML_SIM R2023b utf8\n'
            'EXTERNPROTO "../protos/halfTile.proto"\n'
            'EXTERNPROTO "../protos/worldTile.proto"\n'
            "DEF START_TILE worldTile {\n"
            "  start TRUE\n"
            "  xPos 0\n"
            "  zPos 0\n"
            "  room 1\n"
            "}\n",
            encoding="utf-8",
        )
        tiles = mw.parse_wbt(path)
        check("parser ignores EXTERNPROTO", len(tiles) == 1 and tiles[0]["type"] == "worldTile")
        grid = mw.WbtTileGrid(tiles)
        check("no phantom tile at start from EXTERNPROTO", len(grid.all_coords) == 1 and grid.anchor == (0, 0))

    example_wbt = _find_example_wbt()
    if example_wbt is not None:
        tiles = mw.parse_wbt(example_wbt)
        check("example Day1_1 has 49 real tiles", len(tiles) == 49)
        check("example Day1_1 has exactly one start tile", sum(int(t["start"]) for t in tiles) == 1)
        grid = mw.WbtTileGrid(tiles)
        min_r, max_r, min_c, max_c = grid.bounds()
        check("WbtTileGrid.anchor == (0, 0)", grid.anchor == (0, 0))
        check(
            "matrix_anchor matches bounds",
            grid.matrix_anchor() == (-min_r, -min_c),
        )
    else:
        print("[WARN] example Day1_1 world not found; skipping example-world checks")

    curve_grid = mw.WbtTileGrid(
        [
            {
                "type": "halfTile",
                "xPos": 0,
                "zPos": 0,
                "topWall": 0,
                "rightWall": 0,
                "bottomWall": 0,
                "leftWall": 0,
                "tile1_walls": (0, 0, 0, 0),
                "tile2_walls": (0, 0, 0, 0),
                "tile3_walls": (0, 0, 0, 0),
                "tile4_walls": (0, 0, 0, 0),
                "curve": (4, 1, 3, 2),
                "trap": False,
                "swamp": False,
                "checkpoint": False,
                "start": True,
                "obstacle": False,
                "room": 1,
            }
        ]
    )
    check("curve map WBT 1 -> NE", curve_grid.curve_label(0, 0, "NE") == 3)
    check("curve map WBT 2 -> SE", curve_grid.curve_label(0, 0, "SE") == 4)
    check("curve map WBT 3 -> SW", curve_grid.curve_label(0, 0, "SW") == 1)
    check("curve map WBT 4 -> NW", curve_grid.curve_label(0, 0, "NW") == 2)

    syn = _synthetic_run()
    syn_auto = md.build_run_subtiles(syn)
    syn_matrix = md.build_run_subtiles(syn, label_source="matrix")
    check(
        "build_run_subtiles(matrix) preserves legacy behavior without WBT",
        _subtile_fingerprint(syn_auto) == _subtile_fingerprint(syn_matrix),
    )

    syn_auto_tiles = md.build_run_tiles(syn)
    syn_matrix_tiles = md.build_run_tiles(syn, label_source="matrix")
    check(
        "build_run_tiles(matrix) preserves legacy behavior without WBT",
        _tile_fingerprint(syn_auto_tiles) == _tile_fingerprint(syn_matrix_tiles),
    )

    real_runs = [md.load_run(rd) for rd in md.list_runs()]
    run_with_wbt = next((r for r in real_runs if r.get("wbt_path")), None)
    if run_with_wbt is not None:
        auto_subs = md.build_run_subtiles(run_with_wbt, label_source="auto")
        wbt_subs = md.build_run_subtiles(run_with_wbt, label_source="wbt")
        auto_tiles = md.build_run_tiles(run_with_wbt, label_source="auto")
        wbt_tiles = md.build_run_tiles(run_with_wbt, label_source="wbt")
        check(
            "build_run_subtiles(auto) uses WBT when map_path.txt exists",
            _subtile_fingerprint(auto_subs) == _subtile_fingerprint(wbt_subs),
        )
        check(
            "build_run_tiles(auto) uses WBT when available",
            _tile_fingerprint(auto_tiles) == _tile_fingerprint(wbt_tiles),
        )
    else:
        print("[WARN] no run with WBT path found; skipping auto/WBT dataset checks")

    passed = sum(int(ok) for _, ok in checks)
    print(f"\n{passed}/{len(checks)} checks passed")
    return 0 if passed == len(checks) else 1


if __name__ == "__main__":
    raise SystemExit(main())
