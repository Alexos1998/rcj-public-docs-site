#!/usr/bin/env python3
"""Bootstrap a minimal synthetic dataset and run perception training smoke tests."""

from __future__ import annotations

import argparse
import csv
import os
import random
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
mpl_dir = PROJECT_ROOT / ".cache" / "matplotlib"
mpl_dir.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", str(mpl_dir))

import numpy as np
from PIL import Image, ImageDraw

if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from notebooks.common.config import get_dataset_root, get_manifest_root
from notebooks.common.training_runs import run_bbox_training, run_classification_training
from notebooks.scripts.smoke_test_pipeline_assets import main as smoke_test_main


INPUT_SIZE = 64
SPLITS = ("train", "validation", "test")
VICTIM_LABELS = ("harmed", "unharmed", "stable")
ALL_DATASET_LABELS = ("none", "harmed", "unharmed", "stable", "cognitive")
SAMPLES_PER_SPLIT = {
    "train": 6,
    "validation": 2,
    "test": 2,
}


def _ensure_env() -> None:
    mpl_dir.mkdir(parents=True, exist_ok=True)


def _rng(seed: int = 2026) -> random.Random:
    return random.Random(seed)


def _base_canvas() -> Image.Image:
    image = Image.new("RGB", (INPUT_SIZE, INPUT_SIZE), (18, 18, 18))
    draw = ImageDraw.Draw(image)
    for y in range(0, INPUT_SIZE, 8):
        tone = 24 + (y % 16)
        draw.rectangle((0, y, INPUT_SIZE, min(INPUT_SIZE - 1, y + 7)), fill=(tone, tone, tone))
    return image


def _presence_none(image: Image.Image) -> Image.Image:
    draw = ImageDraw.Draw(image)
    draw.rectangle((6, 6, 57, 57), outline=(42, 42, 42), width=1)
    return image


def _victim_bbox_for_index(index: int) -> tuple[int, int, int, int]:
    offsets = [(14, 14), (18, 16), (12, 20), (20, 12), (16, 18)]
    x1, y1 = offsets[index % len(offsets)]
    return x1, y1, x1 + 28, y1 + 28


def _draw_victim(image: Image.Image, color: tuple[int, int, int], index: int) -> tuple[Image.Image, tuple[float, float, float, float]]:
    x1, y1, x2, y2 = _victim_bbox_for_index(index)
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((x1, y1, x2, y2), radius=6, fill=color, outline=(240, 240, 240), width=2)
    draw.line((x1 + 7, y1 + 10, x2 - 7, y2 - 10), fill=(255, 255, 255), width=2)
    bbox = (x1 / INPUT_SIZE, y1 / INPUT_SIZE, x2 / INPUT_SIZE, y2 / INPUT_SIZE)
    return image, bbox


def _draw_target(image: Image.Image, index: int) -> Image.Image:
    draw = ImageDraw.Draw(image)
    cx = 32 + ((index % 3) - 1) * 2
    cy = 32 + (((index // 3) % 3) - 1) * 2
    rings = [
        (14, (0, 0, 0)),
        (11, (210, 40, 40)),
        (8, (235, 210, 50)),
        (5, (50, 170, 80)),
        (2, (60, 110, 220)),
    ]
    for radius, color in rings:
        draw.ellipse((cx - radius, cy - radius, cx + radius, cy + radius), fill=color)
    return image


def _noise(image: Image.Image, seed: int) -> Image.Image:
    rng = np.random.default_rng(seed)
    array = np.asarray(image, dtype=np.int16)
    jitter = rng.integers(-6, 7, size=array.shape, endpoint=False)
    array = np.clip(array + jitter, 0, 255).astype(np.uint8)
    return Image.fromarray(array, mode="RGB")


def create_synthetic_dataset(dataset_name: str) -> None:
    dataset_root = get_dataset_root(dataset_name)
    manifest_root = get_manifest_root(dataset_name)
    dataset_root.mkdir(parents=True, exist_ok=True)
    manifest_root.mkdir(parents=True, exist_ok=True)

    presence_rows: list[dict[str, str | int | float]] = []
    object_type_rows: list[dict[str, str | int | float]] = []
    victim_rows: list[dict[str, str | int | float]] = []
    bbox_rows: list[dict[str, str | int | float]] = []

    victim_specs = {
        "harmed": (220, 70, 70),
        "unharmed": (70, 190, 95),
        "stable": (70, 110, 220),
    }

    generator = _rng()
    for split in SPLITS:
        for label_name in ALL_DATASET_LABELS:
            image_dir = dataset_root / split / label_name / "images"
            image_dir.mkdir(parents=True, exist_ok=True)
            for sample_index in range(SAMPLES_PER_SPLIT[split]):
                image = _base_canvas()
                global_index = generator.randint(0, 10_000)
                bbox = None
                if label_name == "none":
                    image = _presence_none(image)
                elif label_name == "cognitive":
                    image = _draw_target(image, global_index)
                else:
                    image, bbox = _draw_victim(image, victim_specs[label_name], global_index)
                image = _noise(image, seed=global_index)
                image_name = f"{label_name}_{sample_index:03d}.png"
                image_path = image_dir / image_name
                image.save(image_path)
                rel_path = f"{label_name}/images/{image_name}"

                presence_rows.append(
                    {
                        "split": split,
                        "image_path": rel_path,
                        "label": 0 if label_name == "none" else 1,
                        "label_name": "none" if label_name == "none" else "object",
                    }
                )
                if label_name != "none":
                    object_type_rows.append(
                        {
                            "split": split,
                            "image_path": rel_path,
                            "label": 0 if label_name == "cognitive" else 1,
                            "label_name": "target" if label_name == "cognitive" else "victim",
                        }
                    )
                if label_name in VICTIM_LABELS:
                    victim_label = VICTIM_LABELS.index(label_name)
                    victim_rows.append(
                        {
                            "split": split,
                            "image_path": rel_path,
                            "label": victim_label,
                            "label_name": label_name,
                        }
                    )
                    assert bbox is not None
                    bbox_rows.append(
                        {
                            "split": split,
                            "image_path": rel_path,
                            "label": victim_label,
                            "label_name": label_name,
                            "xmin": f"{bbox[0]:.6f}",
                            "ymin": f"{bbox[1]:.6f}",
                            "xmax": f"{bbox[2]:.6f}",
                            "ymax": f"{bbox[3]:.6f}",
                        }
                    )

    _write_csv(
        manifest_root / "presence.csv",
        ("split", "image_path", "label", "label_name"),
        presence_rows,
    )
    _write_csv(
        manifest_root / "object_type.csv",
        ("split", "image_path", "label", "label_name"),
        object_type_rows,
    )
    _write_csv(
        manifest_root / "victim_classification.csv",
        ("split", "image_path", "label", "label_name"),
        victim_rows,
    )
    _write_csv(
        manifest_root / "victim_bbox.csv",
        ("split", "image_path", "label", "label_name", "xmin", "ymin", "xmax", "ymax"),
        bbox_rows,
    )


def _write_csv(path: Path, fieldnames: tuple[str, ...], rows: list[dict[str, str | int | float]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def run_smoke_test(dataset_name: str) -> None:
    argv = sys.argv[:]
    try:
        sys.argv = ["smoke_test_pipeline_assets.py", "--dataset-name", dataset_name, "--input-size", str(INPUT_SIZE)]
        smoke_test_main()
    finally:
        sys.argv = argv


def run_training(dataset_name: str, epochs: int, batch_size: int, num_workers: int) -> None:
    common = {
        "dataset_name": dataset_name,
        "input_size": INPUT_SIZE,
        "batch_size": batch_size,
        "epochs": epochs,
        "learning_rate": 1e-3,
        "num_workers": num_workers,
    }
    run_classification_training(
        **common,
        manifest_filename="presence.csv",
        model_dir_name="presence",
        report_dir_name="presence",
        checkpoint_filename="presence_best.pt",
        onnx_filename="presence.onnx",
        model_name="presence",
        labels=("none", "object"),
    )
    run_classification_training(
        **common,
        manifest_filename="object_type.csv",
        model_dir_name="object_type",
        report_dir_name="object_type",
        checkpoint_filename="object_type_best.pt",
        onnx_filename="object_type.onnx",
        model_name="object_type",
        labels=("target", "victim"),
    )
    run_classification_training(
        **common,
        manifest_filename="victim_classification.csv",
        model_dir_name="victim",
        report_dir_name="victim_cls",
        checkpoint_filename="victim_cls_best.pt",
        onnx_filename="victim_cls.onnx",
        model_name="victim_cls",
        labels=VICTIM_LABELS,
    )
    run_bbox_training(**common)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="smoke_dataset_v001")
    parser.add_argument("--epochs", type=int, default=1)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--skip-generate", action="store_true")
    args = parser.parse_args()

    _ensure_env()
    if not args.skip_generate:
        create_synthetic_dataset(args.dataset_name)
    run_smoke_test(args.dataset_name)
    run_training(args.dataset_name, args.epochs, args.batch_size, args.num_workers)


if __name__ == "__main__":
    main()
