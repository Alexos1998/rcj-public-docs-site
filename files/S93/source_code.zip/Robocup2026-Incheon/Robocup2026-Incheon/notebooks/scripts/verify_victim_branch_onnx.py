#!/usr/bin/env python3
"""Validate victim-branch ONNX artifacts and metadata."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from notebooks.common.config import get_manifest_root, get_model_dir
from notebooks.common.datasets import read_csv_manifest


EXPECTED = {
    "presence": {
        "path": get_model_dir("presence") / "presence.onnx",
        "input": "input",
        "output": "logits",
        "output_width": 2,
        "labels": ["none", "object"],
    },
    "object_type": {
        "path": get_model_dir("object_type") / "object_type.onnx",
        "input": "input",
        "output": "logits",
        "output_width": 2,
        "labels": ["target", "victim"],
    },
    "victim_cls": {
        "path": get_model_dir("victim") / "victim_cls.onnx",
        "input": "input",
        "output": "logits",
        "output_width": 3,
        "labels": ["harmed", "unharmed", "stable"],
    },
    "victim_bbox": {
        "path": get_model_dir("victim") / "victim_bbox.onnx",
        "input": "input",
        "output": "bbox",
        "output_width": 4,
        "labels": [],
    },
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def has_bbox_manifest(dataset_name: str) -> bool:
    manifest_path = get_manifest_root(dataset_name) / "victim_bbox.csv"
    return manifest_path.exists() and len(read_csv_manifest(manifest_path)) > 0


def verify_one(name: str, spec: dict) -> None:
    try:
        import numpy as np
        import onnx
        import onnxruntime as ort
    except ImportError as exc:
        raise RuntimeError("Install numpy, onnx, and onnxruntime to verify ONNX artifacts.") from exc

    onnx_path = spec["path"]
    metadata_path = onnx_path.with_suffix(".metadata.json")
    require(onnx_path.exists(), f"Missing ONNX artifact for {name}: {onnx_path}")
    require(metadata_path.exists(), f"Missing metadata JSON for {name}: {metadata_path}")

    model = onnx.load(onnx_path)
    onnx.checker.check_model(model)
    graph_inputs = [node.name for node in model.graph.input]
    graph_outputs = [node.name for node in model.graph.output]
    require(graph_inputs == [spec["input"]], f"{name} inputs {graph_inputs} != {[spec['input']]}")
    require(graph_outputs == [spec["output"]], f"{name} outputs {graph_outputs} != {[spec['output']]}")

    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    require(metadata.get("input_names") == [spec["input"]], f"{name} metadata input_names mismatch")
    require(metadata.get("output_names") == [spec["output"]], f"{name} metadata output_names mismatch")
    if spec["labels"]:
        require(metadata.get("labels") == spec["labels"], f"{name} metadata labels mismatch: {metadata.get('labels')}")

    input_shape = metadata.get("input_shape") or [1, 3, 64, 64]
    input_size = int(input_shape[-1])
    dummy = np.random.randn(2, 3, input_size, input_size).astype(np.float32)
    session = ort.InferenceSession(str(onnx_path), providers=["CPUExecutionProvider"])
    ort_inputs = session.get_inputs()
    ort_outputs = session.get_outputs()
    require(ort_inputs[0].name == spec["input"], f"{name} ORT input name mismatch: {ort_inputs[0].name}")
    require(ort_outputs[0].name == spec["output"], f"{name} ORT output name mismatch: {ort_outputs[0].name}")
    outputs = session.run(None, {spec["input"]: dummy})
    output_shape = list(outputs[0].shape)
    require(output_shape == [2, spec["output_width"]], f"{name} output shape {output_shape} != {[2, spec['output_width']]}")

    print(f"{name}: ok")
    print(f"  onnx: {onnx_path}")
    print(f"  input: {ort_inputs[0].name} {list(ort_inputs[0].shape)}")
    print(f"  output: {ort_outputs[0].name} {output_shape}")
    print(f"  metadata: {metadata_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", required=True)
    args = parser.parse_args()

    names = ["presence", "object_type", "victim_cls"]
    if has_bbox_manifest(args.dataset_name):
        names.append("victim_bbox")
    else:
        print("victim_bbox: skipped because victim_bbox.csv is missing or empty.")

    for name in names:
        verify_one(name, EXPECTED[name])


if __name__ == "__main__":
    try:
        main()
    except RuntimeError as exc:
        raise SystemExit(str(exc)) from exc
