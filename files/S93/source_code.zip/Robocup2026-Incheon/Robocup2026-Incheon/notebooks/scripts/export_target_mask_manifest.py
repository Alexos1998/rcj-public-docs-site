"""Build ``target_mask_manifest.csv`` from the WHOLE-target cognitive masks.

Mask-first localization manifest for the CognitiveTarget branch. One row per
target image, derived **only** from the whole-target silhouette mask:

* Ring masks (``..._ring<N>_...``) are skipped explicitly -- they are the
  per-band answer key, never an input or ground truth here.
* Multiclass masks (``0..4`` rings + ``255`` background) collapse to the binary
  target via ``mask != 255``; pure binary / grayscale masks are handled too.

Columns include the bbox, robust center (largest inscribed circle), clipped
flag, radial coverage and the per-ray contour ``ray_r_000..ray_r_063`` /
``ray_valid_000..ray_valid_063``. The heavy lifting lives in
:mod:`notebooks.common.target_geometry`; this is a thin, path-safe CLI.

Run with:
    .venv/bin/python notebooks/scripts/export_target_mask_manifest.py --dataset-name imagens_larc
or:  python -m notebooks.scripts.export_target_mask_manifest --dataset-name imagens_larc
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common.config import get_dataset_root, get_manifest_root
from notebooks.common.target_geometry import build_target_mask_manifest

OUTPUT_NAME = "target_mask_manifest.csv"


def generate(dataset_name: str, n_rays: int = 64) -> Path:
    dataset_root = get_dataset_root(dataset_name)
    output_csv = get_manifest_root(dataset_name) / OUTPUT_NAME
    return build_target_mask_manifest(dataset_root, output_csv, n_rays=n_rays)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset-name", default="imagens_larc")
    parser.add_argument("--n-rays", type=int, default=64)
    args = parser.parse_args()
    generate(args.dataset_name, n_rays=args.n_rays)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
