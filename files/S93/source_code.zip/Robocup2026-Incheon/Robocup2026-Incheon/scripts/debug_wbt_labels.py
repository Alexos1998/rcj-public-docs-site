#!/usr/bin/env python3
"""Inspect WBT-derived map labels without requiring Webots."""

from __future__ import annotations

import argparse
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from notebooks.common import map_dataset as md
from notebooks.common.map_wbt import WbtTileGrid, load_wbt_grid


def _summary_for_grid(wbt: WbtTileGrid) -> dict:
    curve_counts = Counter({label: 0 for label in md.CURVE_LABELS})
    wall_counts = Counter({d: 0 for d in md.DIRS})
    area4_tiles = 0
    obstacle_tiles = 0

    for _mat_r, _mat_c, wbt_r, wbt_c, _tile in wbt.iter_matrix_tiles():
        area4 = wbt.is_area4(wbt_r, wbt_c)
        area4_tiles += int(area4)
        obstacle_tiles += int(wbt.is_obstacle(wbt_r, wbt_c))
        if area4:
            continue
        for quarter in md.QUARTER_ORDER:
            curve_counts[md.CURVE_LABELS[wbt.curve_label(wbt_r, wbt_c, quarter)]] += 1
            for direction, present in wbt.wall_flags(wbt_r, wbt_c, quarter).items():
                wall_counts[direction] += int(present)

    return {
        "tiles": len(wbt.all_coords),
        "bounds": wbt.bounds(),
        "matrix_anchor": wbt.matrix_anchor(),
        "kind_counts": wbt.kind_counts(),
        "area4_tiles": area4_tiles,
        "obstacle_tiles": obstacle_tiles,
        "curve_counts": dict(curve_counts),
        "wall_counts": dict(wall_counts),
        "start_tile": wbt.start_tile,
    }


def _print_summary(summary: dict) -> None:
    print(f"tiles: {summary['tiles']}")
    print(f"bounds: {summary['bounds']}")
    print(f"matrix_anchor: {summary['matrix_anchor']}")
    print(f"kind_counts: {summary['kind_counts']}")
    print(f"area4_tiles: {summary['area4_tiles']}")
    print(f"obstacle_tiles: {summary['obstacle_tiles']}")
    print(f"curve_counts: {summary['curve_counts']}")
    print(f"wall_counts: {summary['wall_counts']}")
    print(
        "start_tile: "
        f"(xPos={summary['start_tile']['xPos']}, zPos={summary['start_tile']['zPos']})"
    )


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument("--wbt", type=Path, help="Path to a .wbt file")
    group.add_argument("--run", type=Path, help="Run dir under controller/mapsdataset/runs")
    ap.add_argument(
        "--compare-matrix",
        action="store_true",
        help="When used with --run, print WBT-vs-matrix mismatch diagnostics",
    )
    args = ap.parse_args()

    if args.wbt is not None:
        wbt = load_wbt_grid(args.wbt, strict=True)
        assert wbt is not None
        _print_summary(_summary_for_grid(wbt))
        return 0

    run = md.load_run(args.run)
    wbt = load_wbt_grid(run.get("wbt_path") or run["run_dir"], strict=True)
    assert wbt is not None
    _print_summary(_summary_for_grid(wbt))
    if args.compare_matrix:
        print()
        md.print_wbt_matrix_report(run)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
