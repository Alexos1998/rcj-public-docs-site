// Standalone test for LidarCameraProjector. Build (no ROS needed):
//   g++ -std=c++17 -I include test/test_lidar_projection.cpp src/lidar_camera_projector.cpp -o /tmp/test_lidar
//   /tmp/test_lidar

#include <cmath>
#include <cstdio>
#include <limits>
#include <vector>

#include "ros2_vision/lidar_camera_projector.hpp"

namespace {
int g_passed = 0;
int g_failed = 0;
void check(const char* name, bool ok)
{
  std::printf("[%s] %s\n", ok ? "PASS" : "FAIL", name);
  ok ? ++g_passed : ++g_failed;
}
constexpr double kPi = 3.14159265358979323846;
}  // namespace

int main()
{
  using ros2_vision::LidarCameraProjector;
  LidarCameraProjector proj(LidarCameraProjector::Config{20.0f, 1, false});

  const int width = 64;
  const double hfov = 1.0;
  const double left_yaw = kPi / 2.0;   // left camera looks +90 deg
  const int n = 512;
  const double angle_min = -kPi;
  const double angle_inc = 2.0 * kPi / n;

  // Center pixel -> angle ~= yaw offset.
  const double a_center = proj.pixelToRobotAngle((width - 1) * 0.5, width, hfov, left_yaw);
  check("center pixel angle ~= yaw offset", std::abs(a_center - left_yaw) < 1e-6);

  // Left/right pixels straddle the yaw offset by ~hfov/2.
  const double a_left = proj.pixelToRobotAngle(0, width, hfov, left_yaw);
  const double a_right = proj.pixelToRobotAngle(width - 1, width, hfov, left_yaw);
  check("left pixel angle < center", a_left < a_center);
  check("right pixel angle > center", a_right > a_center);
  check("hfov span ~ atan-consistent", std::abs((a_right - a_left) - 2.0 * std::atan((width - 1) * 0.5 /
        (width / (2.0 * std::tan(hfov / 2.0))))) < 1e-6);

  // angleToScanIndex maps yaw offset to the expected bin.
  const int idx_center = proj.angleToScanIndex(left_yaw, n, angle_min, angle_inc);
  const int expected = static_cast<int>(std::lround((left_yaw - angle_min) / angle_inc));
  check("scan index for center", idx_center == expected);

  // A scan where the only valid ranges are near the camera yaw -> distance found.
  std::vector<float> ranges(n, std::numeric_limits<float>::infinity());
  for (int d = -3; d <= 3; ++d) {
    ranges[(expected + d + n) % n] = 0.05f;  // 5 cm
  }
  int valid_rays = 0;
  const float dist = proj.estimateDistanceForPixelInterval(
    ranges, width, static_cast<float>(hfov), static_cast<float>(left_yaw),
    static_cast<float>(angle_min), static_cast<float>(angle_inc), 0.01f, 1.0f,
    width * 0.3f, width * 0.7f, &valid_rays);
  check("distance estimated ~0.05", std::isfinite(dist) && std::abs(dist - 0.05f) < 1e-3);
  check("valid rays counted", valid_rays > 0);

  // Out-of-range / non-finite ranges are ignored -> NaN.
  std::vector<float> bad(n, std::numeric_limits<float>::quiet_NaN());
  bad[expected] = 5.0f;  // beyond range_max
  const float dist_bad = proj.estimateDistanceForPixelInterval(
    bad, width, static_cast<float>(hfov), static_cast<float>(left_yaw),
    static_cast<float>(angle_min), static_cast<float>(angle_inc), 0.01f, 1.0f,
    width * 0.3f, width * 0.7f, nullptr);
  check("invalid/oob ranges -> NaN", !std::isfinite(dist_bad));

  // Pixel interval outside the image is clamped (no crash, still finite here).
  const float dist_clamped = proj.estimateDistanceForPixelInterval(
    ranges, width, static_cast<float>(hfov), static_cast<float>(left_yaw),
    static_cast<float>(angle_min), static_cast<float>(angle_inc), 0.01f, 1.0f,
    -100.0f, 9999.0f, nullptr);
  check("out-of-image interval clamped (no crash)", std::isfinite(dist_clamped) || std::isnan(dist_clamped));

  // Non-360 scan: angle outside coverage returns -1 (no wrap).
  const int small_n = 100;
  const double small_inc = (kPi / 2.0) / small_n;  // covers only 90 deg from angle_min
  const int oob = proj.angleToScanIndex(kPi, small_n, -kPi / 4.0, small_inc);
  check("non-360 out-of-coverage -> -1", oob == -1);

  std::printf("\n%d/%d projector checks passed\n", g_passed, g_passed + g_failed);
  return g_failed == 0 ? 0 : 1;
}
