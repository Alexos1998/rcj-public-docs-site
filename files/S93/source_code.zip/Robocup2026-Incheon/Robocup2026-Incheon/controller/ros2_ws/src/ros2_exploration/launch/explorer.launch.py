import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def _runtime_params_list(context):
    """Return [runtime_params_file] when it points at an existing file, else []."""
    path = LaunchConfiguration("runtime_params_file").perform(context)
    return [path] if path and os.path.exists(path) else []


def launch_setup(context, *args, **kwargs):
    del args, kwargs

    params_file = LaunchConfiguration("params_file")
    use_sim_time = LaunchConfiguration("use_sim_time")
    autostart = LaunchConfiguration("autostart")
    log_level = LaunchConfiguration("log_level")

    return [
        Node(
            package="ros2_exploration",
            executable="ros2_explorer",
            name="ros2_explorer",
            output="screen",
            emulate_tty=True,
            # Runtime override file is appended LAST so it wins over the base YAML.
            parameters=[
                params_file,
                {"use_sim_time": ParameterValue(use_sim_time, value_type=bool)},
                {"autostart": ParameterValue(autostart, value_type=bool)},
                *_runtime_params_list(context),
            ],
            arguments=["--ros-args", "--log-level", log_level],
        )
    ]


def generate_launch_description():
    pkg_share = get_package_share_directory("ros2_exploration")
    default_params_file = os.path.join(pkg_share, "config", "explorer.yaml")

    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "params_file",
                default_value=default_params_file,
                description="Path to ros2_exploration parameter YAML.",
            ),
            DeclareLaunchArgument(
                "use_sim_time",
                default_value="false",
                description="Use simulation clock.",
            ),
            DeclareLaunchArgument(
                "autostart",
                default_value="true",
                description="Allow ros2_explorer to send goals. False keeps debug graph publishing only.",
            ),
            DeclareLaunchArgument(
                "log_level",
                default_value="info",
                description="ROS log level for ros2_explorer.",
            ),
            DeclareLaunchArgument(
                "runtime_params_file",
                default_value="",
                description="Optional runtime YAML override loaded last (timing/use_sim_time).",
            ),
            OpaqueFunction(function=launch_setup),
        ]
    )
