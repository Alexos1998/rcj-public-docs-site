#pragma once

#include <chrono>
#include <functional>
#include <mutex>
#include <string>

#include "geometry_msgs/msg/pose_stamped.hpp"
#include "nav2_msgs/action/navigate_to_pose.hpp"
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"

namespace ros2_exploration
{

class Nav2GoalManager
{
public:
  using NavigateToPose = nav2_msgs::action::NavigateToPose;
  using NavigateToPoseClient = rclcpp_action::Client<NavigateToPose>;
  using GoalHandle = rclcpp_action::ClientGoalHandle<NavigateToPose>;
  using GoalResponseCallback = std::function<void(GoalHandle::SharedPtr)>;
  using ResultCallback = std::function<void(const GoalHandle::WrappedResult &)>;

  Nav2GoalManager(rclcpp::Node * node, std::string action_name);

  bool actionServerReady(std::chrono::milliseconds timeout) const;
  void sendGoal(
    const geometry_msgs::msg::PoseStamped & pose,
    GoalResponseCallback goal_response_callback,
    ResultCallback result_callback);
  bool cancelActiveGoal();
  const std::string & actionName() const;

private:
  std::string action_name_;
  NavigateToPoseClient::SharedPtr client_;
  mutable std::mutex mutex_;
  GoalHandle::SharedPtr active_goal_handle_;
};

}  // namespace ros2_exploration
