#include "ros2_vision/vision_node.hpp"

#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <unistd.h>

#include <chrono>
#include <algorithm>
#include <cerrno>
#include <cstdlib>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <limits>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <set>
#include <vector>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

namespace ros2_vision {
namespace {

template <typename T>
T declareNested(rclcpp::Node& node, const std::string& name, const T& value)
{
  return node.declare_parameter<T>(name, value);
}

std::string jsonEscape(const std::string& input)
{
  std::ostringstream oss;
  for (char c : input) {
    if (c == '"' || c == '\\') {
      oss << '\\' << c;
    } else if (c == '\n') {
      oss << "\\n";
    } else {
      oss << c;
    }
  }
  return oss.str();
}

std::string sanitizeFileToken(const std::string& input)
{
  std::string out;
  out.reserve(input.size());
  for (char c : input) {
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') || c == '_' || c == '-') {
      out.push_back(c);
    } else {
      out.push_back('_');
    }
  }
  return out.empty() ? std::string("none") : out;
}

std::string defaultClassificationImageDir()
{
  if (const char* raw = std::getenv("VISION_CLASSIFICATION_IMAGE_DIR")) {
    if (*raw != '\0') {
      return std::string(raw);
    }
  }
  if (const char* unique_log = std::getenv("UNIQUE_LOG_PATH")) {
    if (*unique_log != '\0') {
      return (std::filesystem::path(unique_log).parent_path() / "images").string();
    }
  }
  return "/tmp/controller-logs/latest/images";
}

constexpr double kTwoPi = 2.0 * M_PI;

struct LidarDebugRay {
  int index = -1;
  float range = std::numeric_limits<float>::quiet_NaN();
  double angle = 0.0;
  double pixel_x = 0.0;
  bool valid = false;
};

bool lidarFullCircle(int n, double angle_increment)
{
  return n > 0 && angle_increment > 0.0 &&
         std::abs(static_cast<double>(n) * angle_increment - kTwoPi) < 0.05 * kTwoPi;
}

double pixelToRobotAngle(double x, int image_width, double hfov_rad, double yaw_offset)
{
  const double fx = image_width / (2.0 * std::tan(hfov_rad / 2.0));
  const double cx = (image_width - 1) * 0.5;
  return yaw_offset + std::atan((x - cx) / fx);
}

int angleToScanIndex(double theta, int n, double angle_min, double angle_increment)
{
  if (n <= 0 || !(angle_increment > 0.0) || !std::isfinite(theta)) {
    return -1;
  }
  long idx = std::lround((theta - angle_min) / angle_increment);
  if (idx >= 0 && idx < n) {
    return static_cast<int>(idx);
  }
  if (lidarFullCircle(n, angle_increment)) {
    idx %= n;
    if (idx < 0) {
      idx += n;
    }
    return static_cast<int>(idx);
  }
  return -1;
}

double scanIndexToPixel(int index, const VisionFrame& frame)
{
  if (frame.bgr.cols <= 1 || !(frame.camera_hfov_rad > 0.0f)) {
    return std::numeric_limits<double>::quiet_NaN();
  }
  const double theta = frame.lidar_angle_min +
    static_cast<double>(index) * frame.lidar_angle_increment;
  const double rel = theta - frame.camera_yaw_offset_rad;
  const double fx = frame.bgr.cols / (2.0 * std::tan(frame.camera_hfov_rad / 2.0));
  const double cx = (frame.bgr.cols - 1) * 0.5;
  return cx + fx * std::tan(rel);
}

std::vector<LidarDebugRay> selectedLidarRays(const VisionFrame& frame,
                                            float xmin,
                                            float xmax,
                                            int extra)
{
  std::vector<LidarDebugRay> out;
  const int n = static_cast<int>(frame.scan.size());
  if (n <= 0 || frame.bgr.cols <= 1 || !(frame.lidar_angle_increment > 0.0f) ||
      !(frame.camera_hfov_rad > 0.0f)) {
    return out;
  }
  xmin = std::max(0.0f, std::min(xmin, static_cast<float>(frame.bgr.cols - 1)));
  xmax = std::max(0.0f, std::min(xmax, static_cast<float>(frame.bgr.cols - 1)));
  if (xmax < xmin) {
    std::swap(xmin, xmax);
  }
  const int i0 = angleToScanIndex(
    pixelToRobotAngle(xmin, frame.bgr.cols, frame.camera_hfov_rad, frame.camera_yaw_offset_rad),
    n, frame.lidar_angle_min, frame.lidar_angle_increment);
  const int i1 = angleToScanIndex(
    pixelToRobotAngle(xmax, frame.bgr.cols, frame.camera_hfov_rad, frame.camera_yaw_offset_rad),
    n, frame.lidar_angle_min, frame.lidar_angle_increment);
  if (i0 < 0 && i1 < 0) {
    return out;
  }

  const bool full_circle = lidarFullCircle(n, frame.lidar_angle_increment);
  extra = std::max(0, extra);
  std::set<int> indices;
  auto add_index = [&](int idx) {
    if (full_circle) {
      idx %= n;
      if (idx < 0) {
        idx += n;
      }
    } else if (idx < 0 || idx >= n) {
      return;
    }
    indices.insert(idx);
  };

  if (i0 >= 0 && i1 >= 0) {
    if (full_circle) {
      const int forward = (i1 - i0 + n) % n;
      const int backward = (i0 - i1 + n) % n;
      const int start = (forward <= backward) ? i0 : i1;
      const int span = std::min(forward, backward);
      for (int d = -extra; d <= span + extra; ++d) {
        add_index(start + d);
      }
    } else {
      for (int idx = std::min(i0, i1) - extra; idx <= std::max(i0, i1) + extra; ++idx) {
        add_index(idx);
      }
    }
  } else {
    const int center = i0 >= 0 ? i0 : i1;
    for (int d = -extra; d <= extra; ++d) {
      add_index(center + d);
    }
  }

  out.reserve(indices.size());
  for (int idx : indices) {
    const float r = frame.scan[static_cast<std::size_t>(idx)];
    LidarDebugRay ray;
    ray.index = idx;
    ray.range = r;
    ray.angle = frame.lidar_angle_min + static_cast<double>(idx) * frame.lidar_angle_increment;
    ray.pixel_x = scanIndexToPixel(idx, frame);
    ray.valid = std::isfinite(r) && r >= frame.lidar_range_min && r <= frame.lidar_range_max;
    out.push_back(ray);
  }
  return out;
}

}  // namespace

class ResultLineServer {
public:
  ResultLineServer(std::string host, int port)
    : host_(std::move(host)), port_(port)
  {
  }

  ~ResultLineServer()
  {
    stop();
  }

  bool start()
  {
    if (running_.exchange(true)) {
      return true;
    }
    listen_fd_ = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_fd_ < 0) {
      running_ = false;
      return false;
    }

    int yes = 1;
    setsockopt(listen_fd_, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(static_cast<std::uint16_t>(port_));
    if (inet_pton(AF_INET, host_.c_str(), &addr.sin_addr) != 1) {
      addr.sin_addr.s_addr = INADDR_ANY;
    }

    if (bind(listen_fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) != 0 ||
        listen(listen_fd_, 1) != 0) {
      closeListen();
      running_ = false;
      return false;
    }

    thread_ = std::thread(&ResultLineServer::run, this);
    return true;
  }

  void stop()
  {
    running_ = false;
    closeListen();
    {
      std::lock_guard<std::mutex> lock(mutex_);
      closeClient();
    }
    if (thread_.joinable()) {
      thread_.join();
    }
  }

  bool sendLine(const std::string& line)
  {
    std::lock_guard<std::mutex> lock(mutex_);
    if (client_fd_ < 0) {
      return false;
    }
    std::string wire = line;
    wire.push_back('\n');
    std::size_t total = 0;
    while (total < wire.size()) {
      const ssize_t n = send(client_fd_, wire.data() + total, wire.size() - total, MSG_DONTWAIT | MSG_NOSIGNAL);
      if (n > 0) {
        total += static_cast<std::size_t>(n);
        continue;
      }
      if (n < 0 && errno == EINTR) {
        continue;
      }
      closeClient();
      return false;
    }
    return true;
  }

private:
  void run()
  {
    while (running_) {
      sockaddr_in client_addr{};
      socklen_t len = sizeof(client_addr);
      const int fd = accept(listen_fd_, reinterpret_cast<sockaddr*>(&client_addr), &len);
      if (fd < 0) {
        if (running_) {
          std::this_thread::sleep_for(std::chrono::milliseconds(50));
        }
        continue;
      }
      int flag = 1;
      setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag));
      std::lock_guard<std::mutex> lock(mutex_);
      closeClient();
      client_fd_ = fd;
    }
  }

  void closeListen()
  {
    if (listen_fd_ >= 0) {
      shutdown(listen_fd_, SHUT_RDWR);
      close(listen_fd_);
      listen_fd_ = -1;
    }
  }

  void closeClient()
  {
    if (client_fd_ >= 0) {
      shutdown(client_fd_, SHUT_RDWR);
      close(client_fd_);
      client_fd_ = -1;
    }
  }

  std::string host_;
  int port_;
  int listen_fd_ = -1;
  int client_fd_ = -1;
  std::atomic<bool> running_{false};
  std::thread thread_;
  std::mutex mutex_;
};

VisionNode::VisionNode()
  : rclcpp::Node("ros2_vision")
{
  const std::string host = declareNested(*this, "tcp.host", std::string("0.0.0.0"));
  const int frame_port = declareNested(*this, "tcp.frame_port", 5100);
  const int result_port = declareNested(*this, "tcp.result_port", 5101);
  const int recv_buffer_bytes = declareNested(*this, "tcp.recv_buffer_bytes", 1048576);
  (void)declareNested(*this, "tcp.latest_frame_only", true);

  save_classification_images_ = declareNested(*this, "debug.save_classification_images", true);
  save_rejected_images_ = declareNested(*this, "debug.save_rejected_images", true);
  classification_image_dir_ = declareNested(*this, "debug.classification_image_dir", defaultClassificationImageDir());
  if (save_classification_images_) {
    std::error_code ec;
    std::filesystem::create_directories(classification_image_dir_, ec);
    if (ec) {
      RCLCPP_WARN(get_logger(),
                  "ROBOT_EVENT node=ros2_vision event=classification_image_dir_failed path=%s error=%s",
                  classification_image_dir_.c_str(),
                  ec.message().c_str());
    } else {
      RCLCPP_INFO(get_logger(),
                  "ROBOT_EVENT node=ros2_vision event=classification_image_dir_ready path=%s",
                  classification_image_dir_.c_str());
    }
  }

  const std::string presence_model = declareNested(*this, "models.presence_model", std::string("/workspace/controller/models/presence.onnx"));
  const std::string type_model = declareNested(*this, "models.type_model", std::string("/workspace/controller/models/object_type.onnx"));
  const std::string victim_bbox_model = declareNested(*this, "models.victim_bbox_model", std::string("/workspace/controller/models/victim_bbox.onnx"));
  const std::string target_bbox_model = declareNested(*this, "models.target_bbox_model", std::string("/workspace/controller/models/target_bbox.onnx"));
  const std::string victim_cls_model = declareNested(*this, "models.victim_cls_model", std::string("/workspace/controller/models/victim_cls.onnx"));
  const std::string object_presence_model = declareNested(*this, "models.object_presence_model", std::string("/workspace/controller/models/object_presence.onnx"));
  const std::string target_mask_rf_model = declareNested(*this, "models.target_mask_rf_model", std::string("/workspace/controller/models/target_mask_rf.yml"));
  const std::string target_mask_feature_config = declareNested(*this, "models.target_mask_feature_config", std::string("/workspace/controller/models/target_mask_features.yml"));

  LarcVisionPipeline::Config cfg;
  cfg.process_every_n = declareNested(*this, "runtime.process_every_n", 1);
  process_every_n_ = std::max(1, cfg.process_every_n);
  cfg.min_presence_confidence = static_cast<float>(declareNested(*this, "runtime.min_presence_confidence", 0.55));
  cfg.min_type_confidence = static_cast<float>(declareNested(*this, "runtime.min_type_confidence", 0.60));
  cfg.type_fallback_enabled = declareNested(*this, "runtime.type_fallback_enabled", false);
  cfg.use_fused_object_model = declareNested(*this, "runtime.use_fused_object_model", true);
  cfg.min_victim_cls_confidence = static_cast<float>(declareNested(*this, "runtime.min_victim_cls_confidence", 0.5));
  cfg.victim_crop_padding = static_cast<float>(declareNested(*this, "runtime.victim_crop_padding", 0.05));
  cfg.victim_classify_full_frame = declareNested(*this, "runtime.victim_classify_full_frame", true);
  cfg.use_bbox_gate = declareNested(*this, "runtime.use_bbox_gate", true);
  cfg.victim_bbox_gate_min_area_px =
    static_cast<float>(declareNested(*this, "runtime.victim_bbox_gate_min_area_px", 30.0));
  cfg.victim_bbox_gate_min_width_px =
    static_cast<float>(declareNested(*this, "runtime.victim_bbox_gate_min_width_px", 6.0));
  cfg.victim_bbox_gate_min_height_px =
    static_cast<float>(declareNested(*this, "runtime.victim_bbox_gate_min_height_px", 5.0));
  cfg.target_bbox_gate_min_area_px =
    static_cast<float>(declareNested(*this, "runtime.target_bbox_gate_min_area_px", 0.0));
  cfg.target_bbox_gate_min_width_px =
    static_cast<float>(declareNested(*this, "runtime.target_bbox_gate_min_width_px", 12.0));
  cfg.target_bbox_gate_min_height_px =
    static_cast<float>(declareNested(*this, "runtime.target_bbox_gate_min_height_px", 8.0));
  cfg.victim_min_bbox_area_px = declareNested(*this, "victim.min_bbox_area_px", 16);
  cfg.victim_min_bbox_axis_px = declareNested(*this, "victim.min_bbox_axis_px", 3);
  max_inference_ms_warn_ = declareNested(*this, "runtime.max_inference_ms_warn", 80.0);
  cfg.projector.robust_percentile = static_cast<float>(declareNested(*this, "lidar.robust_percentile", 20.0));
  cfg.projector.window_extra_rays = declareNested(*this, "lidar.window_extra_rays", 1);
  lidar_window_extra_rays_ = cfg.projector.window_extra_rays;
  cfg.projector.use_min_range = declareNested(*this, "lidar.use_min_range", false);
  cfg.use_lidar_distance_gate = declareNested(*this, "lidar.use_distance_gate", false);
  cfg.use_target_lidar_distance_gate =
    declareNested(*this, "lidar.use_target_distance_gate", false);
  cfg.use_victim_lidar_distance_gate =
    declareNested(*this, "lidar.use_victim_distance_gate", false);
  cfg.lidar_gate_enabled = declareNested(*this, "lidar.gate_enabled", false);
  cfg.lidar_gate_min_consecutive_rays = declareNested(*this, "lidar.gate_min_consecutive_rays", 5);
  cfg.lidar_gate_max_range_m = static_cast<float>(declareNested(*this, "lidar.gate_max_range_m", 0.06));
  cfg.lidar_bbox_min_consecutive_rays = declareNested(*this, "lidar.bbox_min_consecutive_rays", 5);
  cfg.lidar_bbox_center_fraction =
    static_cast<float>(declareNested(*this, "lidar.bbox_center_fraction", 0.50));

  // Single acceptance distance (legacy *_max_distance_m kept for back-compat -> same semantics).
  const double legacy_target_max = declareNested(*this, "acceptance.target_max_distance_m", 0.06);
  (void)declareNested(*this, "acceptance.victim_max_distance_m", legacy_target_max);
  cfg.valid_detection_distance_m =
    static_cast<float>(declareNested(*this, "acceptance.valid_detection_distance_m", legacy_target_max));
  cfg.victim_min_distance_m = static_cast<float>(declareNested(*this, "acceptance.victim_min_distance_m", 0.0));
  // The current victim classifier has an explicit camera fake class. Keep the
  // rejection configurable, but default it on so fake victims are stopped before
  // report generation.
  cfg.reject_fake_victims = declareNested(*this, "acceptance.reject_fake_victims", true);
  cfg.fake_min_confidence =
    static_cast<float>(declareNested(*this, "acceptance.fake_min_confidence", 0.90));
  cfg.dedup_debug_images = declareNested(*this, "debug.dedup_debug_images", true);
  cfg.duplicate_scope = declareNested(*this, "acceptance.duplicate_scope", std::string("tile"));

  // Target (mask-first / radial) configuration.
  cfg.target_detector.mode = declareNested(*this, "target.detector_mode", std::string("rf_radial"));
  cfg.target_detector.allow_legacy_fallback = declareNested(*this, "target.allow_legacy_fallback", true);
  cfg.target_detector.rf_model_path = target_mask_rf_model;
  cfg.target_detector.rf_feature_config_path = target_mask_feature_config;
  cfg.target_detector.radial.n_rays = declareNested(*this, "target.n_rays", 64);
  cfg.target_detector.min_mask_area_px = declareNested(*this, "target.min_mask_area_px", 60);
  cfg.min_mask_area_px = cfg.target_detector.min_mask_area_px;
  cfg.min_radial_coverage = static_cast<float>(declareNested(*this, "target.min_radial_coverage", 0.25));
  cfg.min_ring_confidence = static_cast<float>(declareNested(*this, "target.min_ring_confidence", 0.34));
  cfg.min_mask_confidence = static_cast<float>(declareNested(*this, "target.min_mask_confidence", 0.0));
  cfg.target_detector.legacy.min_edge_points = declareNested(*this, "target.min_edge_points", 40);
  cfg.target_detector.legacy.min_target_axis_px = declareNested(*this, "target.min_target_axis_px", 25);
  cfg.target_detector.legacy.max_target_axis_px = declareNested(*this, "target.max_target_axis_px", 180);
  cfg.target_detector.legacy.min_component_area_px = declareNested(*this, "target.min_component_area_px", 120);
  cfg.target_detector.legacy.min_fill_ratio = declareNested(*this, "target.min_fill_ratio", 0.08);
  cfg.target_detector.legacy.polar_width = declareNested(*this, "target.polar_width", 720);
  cfg.target_detector.legacy.polar_height = declareNested(*this, "target.polar_height", 360);
  cfg.target_detector.legacy.max_fit_error = declareNested(*this, "target.max_fit_error", 0.85);
  cfg.target_detector.legacy.band_count = declareNested(*this, "target.band_count", 5);
  cfg.event_logger = [this](const std::string& event) {
    RCLCPP_INFO(this->get_logger(), "%s", event.c_str());
  };
  cfg.debug_image_logger = [this](const VisionFrame& frame, const VisionDebugImage& debug) {
    this->saveVisionDebugImage(frame, debug);
  };

  const int camera_width = declareNested(*this, "camera.width", 64);
  const int camera_height = declareNested(*this, "camera.height", 64);
  (void)declareNested(*this, "camera.hfov_rad", 1.0);
  (void)declareNested(*this, "camera.vfov_rad", 1.0);
  (void)declareNested(*this, "camera.left_yaw_offset_rad", 1.57079632679);
  (void)declareNested(*this, "camera.right_yaw_offset_rad", -1.57079632679);
  (void)declareNested(*this, "lidar.scan_count", 512);
  (void)declareNested(*this, "lidar.angle_min", -3.14159265359);
  (void)declareNested(*this, "lidar.angle_max", 3.14159265359);
  (void)declareNested(*this, "lidar.range_min", 0.01);
  (void)declareNested(*this, "lidar.range_max", 1.0);
  OnnxRunner::Options base_onnx_options;
  base_onnx_options.input_width = camera_width;
  base_onnx_options.input_height = camera_height;

  // Keep model input sizes explicit. The camera frame is currently 64x64, but
  // the exported ONNX models can have independent training sizes.
  OnnxRunner::Options presence_options = base_onnx_options;
  presence_options.input_width = declareNested(*this, "models.presence_input_width", 48);
  presence_options.input_height = declareNested(*this, "models.presence_input_height", 48);

  OnnxRunner::Options type_options = base_onnx_options;
  type_options.input_width = declareNested(*this, "models.type_input_width", 32);
  type_options.input_height = declareNested(*this, "models.type_input_height", 32);

  OnnxRunner::Options victim_bbox_options = base_onnx_options;
  victim_bbox_options.input_width = declareNested(*this, "models.victim_bbox_input_width", 96);
  victim_bbox_options.input_height = declareNested(*this, "models.victim_bbox_input_height", 96);

  OnnxRunner::Options target_bbox_options = base_onnx_options;
  target_bbox_options.input_width = declareNested(*this, "models.target_bbox_input_width", 96);
  target_bbox_options.input_height = declareNested(*this, "models.target_bbox_input_height", 96);

  OnnxRunner::Options victim_cls_options = base_onnx_options;
  victim_cls_options.input_width = declareNested(*this, "models.victim_cls_input_width", 96);
  victim_cls_options.input_height = declareNested(*this, "models.victim_cls_input_height", 96);

  OnnxRunner::Options object_presence_options = base_onnx_options;
  object_presence_options.input_width = declareNested(*this, "models.object_presence_input_width", 48);
  object_presence_options.input_height = declareNested(*this, "models.object_presence_input_height", 48);

  auto presence_runner = std::make_shared<OnnxRunner>(presence_model, presence_options);
  auto type_runner = std::make_shared<OnnxRunner>(type_model, type_options);
  // Fused none/target/victim runner: only loaded (and only replaces the two-stage
  // chain) when runtime.use_fused_object_model is enabled.
  if (cfg.use_fused_object_model) {
    cfg.object_presence_runner =
      std::make_shared<OnnxRunner>(object_presence_model, object_presence_options);
  }
  auto victim_bbox_runner = std::make_shared<OnnxRunner>(victim_bbox_model, victim_bbox_options);
  auto target_bbox_runner = std::make_shared<OnnxRunner>(target_bbox_model, target_bbox_options);
  auto victim_cls_runner = std::make_shared<OnnxRunner>(victim_cls_model, victim_cls_options);
  pipeline_ = std::make_unique<LarcVisionPipeline>(presence_runner,
                                                   type_runner,
                                                   victim_bbox_runner,
                                                   target_bbox_runner,
                                                   victim_cls_runner,
                                                   cfg);

  detections_pub_ = create_publisher<std_msgs::msg::String>("/vision/detections", 10);
  debug_pub_ = create_publisher<std_msgs::msg::String>("/vision/debug", 10);

  frame_server_ = std::make_unique<TcpFrameServer>(host, frame_port, static_cast<std::size_t>(recv_buffer_bytes));
  result_server_ = std::make_unique<ResultLineServer>(host, result_port);
  if (!frame_server_->start()) {
    throw std::runtime_error("failed to start vision frame TCP server");
  }
  if (!result_server_->start()) {
    throw std::runtime_error("failed to start vision result TCP server");
  }

  running_ = true;
  worker_ = std::thread(&VisionNode::workerLoop, this);

  RCLCPP_INFO(get_logger(),
              "ROBOT_EVENT node=ros2_vision event=started frame_port=%d result_port=%d host=%s fused_object_model=%s reject_fake_victims=%s fake_min_confidence=%.3f",
              frame_port,
              result_port,
              host.c_str(),
              cfg.use_fused_object_model ? "true" : "false",
              cfg.reject_fake_victims ? "true" : "false",
              cfg.fake_min_confidence);
  RCLCPP_INFO(get_logger(),
              "ROBOT_EVENT node=ros2_vision event=bbox_gate_config enabled=%s victim_area=%.1f victim_w=%.1f victim_h=%.1f target_area=%.1f target_w=%.1f target_h=%.1f target_lidar_gate=%s victim_lidar_gate=%s target_model=%s",
              cfg.use_bbox_gate ? "true" : "false",
              cfg.victim_bbox_gate_min_area_px,
              cfg.victim_bbox_gate_min_width_px,
              cfg.victim_bbox_gate_min_height_px,
              cfg.target_bbox_gate_min_area_px,
              cfg.target_bbox_gate_min_width_px,
              cfg.target_bbox_gate_min_height_px,
              cfg.use_target_lidar_distance_gate ? "true" : "false",
              cfg.use_victim_lidar_distance_gate ? "true" : "false",
              target_bbox_model.c_str());
  if (pipeline_->targetUsesRandomForest()) {
    RCLCPP_INFO(get_logger(),
                "ROBOT_EVENT node=ros2_vision event=target_rf_radial_loaded mode=%s rf_model=%s n_rays=%d valid_distance_m=%.3f bbox_min_consecutive=%d bbox_center_fraction=%.2f",
                cfg.target_detector.mode.c_str(),
                target_mask_rf_model.c_str(),
                cfg.target_detector.radial.n_rays,
                cfg.valid_detection_distance_m,
                cfg.lidar_bbox_min_consecutive_rays,
                cfg.lidar_bbox_center_fraction);
  } else {
    RCLCPP_WARN(get_logger(),
                "ROBOT_EVENT node=ros2_vision event=target_rf_unavailable mode=%s fallback=%s error=%s",
                cfg.target_detector.mode.c_str(),
                cfg.target_detector.allow_legacy_fallback ? "legacy" : "none",
                pipeline_->targetLoadError().empty() ? "n/a" : pipeline_->targetLoadError().c_str());
  }
}

VisionNode::~VisionNode()
{
  running_ = false;
  if (worker_.joinable()) {
    worker_.join();
  }
  result_server_.reset();
  frame_server_.reset();
}

void VisionNode::workerLoop()
{
  while (running_ && rclcpp::ok()) {
    VisionFrame frame;
    if (!frame_server_ || !frame_server_->getLatestFrame(frame)) {
      std::this_thread::sleep_for(std::chrono::milliseconds(2));
      continue;
    }

    ++worker_counter_;
    // Logged for EVERY received frame (before any subsample/skip) so both the
    // left and right cameras are always visible in the logs -- even when a frame
    // is later subsampled, rejected, or skipped as an already-reported tile.
    RCLCPP_INFO(get_logger(),
                "ROBOT_EVENT node=ros2_vision event=frame_received seq=%lu camera=%s camera_id=%d tile_x=%d tile_y=%d width=%d height=%d channels=%d heading_rad=%.3f",
                static_cast<unsigned long>(frame.seq),
                frame.camera_name.c_str(),
                frame.camera_id,
                frame.tile_x,
                frame.tile_y,
                frame.bgr.cols,
                frame.bgr.rows,
                frame.bgr.channels(),
                frame.robot_yaw);

    // Subsample per camera so process_every_n never starves one side.
    const std::uint64_t camera_count = ++camera_frame_counter_[frame.camera_id];
    if (camera_count % static_cast<std::uint64_t>(process_every_n_) != 0) {
      RCLCPP_INFO(get_logger(),
                  "ROBOT_EVENT node=ros2_vision event=frame_subsampled seq=%lu camera=%s tile_x=%d tile_y=%d process_every_n=%d",
                  static_cast<unsigned long>(frame.seq),
                  frame.camera_name.c_str(),
                  frame.tile_x,
                  frame.tile_y,
                  process_every_n_);
      continue;
    }

    const auto t0 = std::chrono::steady_clock::now();
    std::string reject_reason;
    auto detection = pipeline_->process(frame, reject_reason);
    const auto t1 = std::chrono::steady_clock::now();
    const double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    RCLCPP_INFO(get_logger(),
                "ROBOT_EVENT node=ros2_vision event=inference_timing seq=%lu elapsed_ms=%.3f warn=%s",
                static_cast<unsigned long>(frame.seq),
                ms,
                ms > max_inference_ms_warn_ ? "true" : "false");

    if (detection) {
      RCLCPP_INFO(get_logger(),
                  "ROBOT_EVENT node=ros2_vision event=detection_accepted seq=%lu camera=%s kind=%s class=%s confidence=%.3f distance=%.3f tile_x=%d tile_y=%d",
                  static_cast<unsigned long>(detection->seq),
                  detection->camera_name.c_str(),
                  detection->kind.c_str(),
                  detection->class_name.c_str(),
                  detection->confidence,
                  detection->distance,
                  detection->tile_x,
                  detection->tile_y);
      publishDetection(*detection);
    } else {
      RCLCPP_INFO(get_logger(),
                  "ROBOT_EVENT node=ros2_vision event=detection_rejected seq=%lu reason=%s camera=%s tile_x=%d tile_y=%d",
                  static_cast<unsigned long>(frame.seq),
                  reject_reason.c_str(),
                  frame.camera_name.c_str(),
                  frame.tile_x,
                  frame.tile_y);
      publishDebug("rejected seq=" + std::to_string(frame.seq) + " reason=" + reject_reason);
    }
  }
}

void VisionNode::publishDebug(const std::string& text)
{
  std_msgs::msg::String msg;
  msg.data = text;
  debug_pub_->publish(msg);
}

void VisionNode::publishDetection(const VisionDetection& detection)
{
  std_msgs::msg::String msg;
  msg.data = detectionToJson(detection);
  detections_pub_->publish(msg);
  if (result_server_) {
    const std::string line = detectionToResultLine(detection);
    const bool sent = result_server_->sendLine(line);
    RCLCPP_INFO(get_logger(),
                "ROBOT_EVENT node=ros2_vision event=%s seq=%lu camera=%s kind=%s class=%s",
                sent ? "vision_result_line_sent" : "vision_result_line_dropped",
                static_cast<unsigned long>(detection.seq),
                detection.camera_name.c_str(),
                detection.kind.c_str(),
                detection.class_name.c_str());
  }
}

void VisionNode::saveVisionDebugImage(const VisionFrame& frame, const VisionDebugImage& debug) const
{
  const bool classified = debug.status == "classified";
  if ((classified && !save_classification_images_) ||
      (!classified && !save_rejected_images_) ||
      frame.bgr.empty() ||
      classification_image_dir_.empty()) {
    return;
  }

  cv::Mat bgr;
  if (frame.bgr.channels() == 1) {
    cv::cvtColor(frame.bgr, bgr, cv::COLOR_GRAY2BGR);
  } else if (frame.bgr.channels() == 4) {
    cv::cvtColor(frame.bgr, bgr, cv::COLOR_BGRA2BGR);
  } else {
    bgr = frame.bgr.clone();
  }

  constexpr int scale = 4;
  cv::Mat view;
  cv::resize(bgr, view, cv::Size(bgr.cols * scale, bgr.rows * scale), 0, 0, cv::INTER_NEAREST);

  const cv::Scalar draw_color = classified ? cv::Scalar(0, 220, 0) : cv::Scalar(0, 0, 255);
  const cv::Rect image_rect(0, 0, bgr.cols, bgr.rows);
  const cv::Rect clipped = debug.bbox & image_rect;
  if (clipped.width > 0 && clipped.height > 0) {
    cv::rectangle(view,
                  cv::Rect(clipped.x * scale, clipped.y * scale, clipped.width * scale, clipped.height * scale),
                  draw_color,
                  2);
  }
  if (std::isfinite(debug.center_x) && std::isfinite(debug.center_y)) {
    cv::circle(view,
               cv::Point(static_cast<int>(std::round(debug.center_x * scale)),
                         static_cast<int>(std::round(debug.center_y * scale))),
               4,
               draw_color,
               cv::FILLED);
  }
  if (debug.kind == "target" && clipped.width > 0 && clipped.height > 0) {
    const int radius = std::max(2, static_cast<int>(std::round(std::max(clipped.width, clipped.height) * 0.5 * scale)));
    cv::circle(view,
               cv::Point(static_cast<int>(std::round(debug.center_x * scale)),
                         static_cast<int>(std::round(debug.center_y * scale))),
               radius,
               cv::Scalar(0, 180, 255),
               1);
  }

  std::vector<LidarDebugRay> rays;
  if (debug.lidar_xmax > debug.lidar_xmin && !frame.scan.empty()) {
    const int x0 = static_cast<int>(std::round(debug.lidar_xmin * scale));
    const int x1 = static_cast<int>(std::round(debug.lidar_xmax * scale));
    cv::line(view, cv::Point(x0, 0), cv::Point(x0, view.rows - 1), cv::Scalar(255, 255, 0), 1);
    cv::line(view, cv::Point(x1, 0), cv::Point(x1, view.rows - 1), cv::Scalar(255, 255, 0), 1);
    rays = selectedLidarRays(frame, debug.lidar_xmin, debug.lidar_xmax, lidar_window_extra_rays_);
    for (const auto& ray : rays) {
      if (!std::isfinite(ray.pixel_x) || ray.pixel_x < 0.0 || ray.pixel_x > frame.bgr.cols - 1) {
        continue;
      }
      const int x = static_cast<int>(std::round(ray.pixel_x * scale));
      cv::line(view, cv::Point(x, 0), cv::Point(x, view.rows - 1),
               ray.valid ? cv::Scalar(255, 0, 255) : cv::Scalar(80, 80, 80), 1);
    }
  }

  cv::Mat panel(std::max(view.rows, 360), 500, CV_8UC3, cv::Scalar(20, 20, 20));
  auto put = [&](int row, const std::string& text, double font_scale = 0.45) {
    cv::putText(panel, text, cv::Point(12, row), cv::FONT_HERSHEY_SIMPLEX, font_scale,
                cv::Scalar(230, 230, 230), 1, cv::LINE_AA);
  };

  const std::string reason = debug.reason.empty() ? "none" : debug.reason;
  const std::string chosen = debug.kind == "target"
    ? debug.class_name + "/" + debug.target_pattern
    : debug.class_name;
  put(24, "VISION " + debug.status + ": " + debug.kind);
  put(48, "reason: " + reason);
  put(72, "chosen: " + chosen);
  put(96, "camera: " + frame.camera_name + "  seq: " + std::to_string(frame.seq));
  put(120, "tile: (" + std::to_string(frame.tile_x) + "," + std::to_string(frame.tile_y) + ")");
  {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(3)
        << "confidence=" << debug.confidence << " distance_m=" << debug.distance;
    put(144, oss.str());
  }
  {
    std::ostringstream oss;
    oss << "bbox_px=(" << debug.bbox.x << "," << debug.bbox.y << ","
        << debug.bbox.width << "," << debug.bbox.height << ")";
    put(168, oss.str());
  }
  {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(3)
        << "lidar_px=[" << debug.lidar_xmin << "," << debug.lidar_xmax << "]"
        << " valid=" << debug.valid_lidar_rays << "/" << rays.size();
    put(192, oss.str());
  }
  {
    std::ostringstream oss;
    oss << "scan_count=" << frame.scan.size()
        << " range=[" << frame.lidar_range_min << "," << frame.lidar_range_max << "]";
    put(216, oss.str());
  }
  {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(3)
        << "robot_m=(" << frame.robot_x << "," << frame.robot_y << ") yaw=" << frame.robot_yaw;
    put(240, oss.str());
  }
  if (debug.kind == "target") {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(3)
        << "pattern=" << debug.target_pattern << " sum=" << debug.target_sum
        << " radial=" << debug.radial_coverage << " mask=" << debug.mask_confidence;
    put(264, oss.str());
  }

  int row = debug.kind == "target" ? 288 : 264;
  put(row, "selected lidar rays:", 0.43);
  row += 22;
  std::ostringstream ray_line;
  int count_on_line = 0;
  int shown = 0;
  for (const auto& ray : rays) {
    if (shown >= 24) {
      break;
    }
    if (count_on_line > 0) {
      ray_line << "  ";
    }
    ray_line << ray.index << ":";
    if (std::isfinite(ray.range)) {
      ray_line << std::fixed << std::setprecision(3) << ray.range;
    } else {
      ray_line << "nan";
    }
    if (!ray.valid) {
      ray_line << "!";
    }
    ++shown;
    ++count_on_line;
    if (count_on_line == 4) {
      put(row, ray_line.str(), 0.40);
      row += 20;
      ray_line.str("");
      ray_line.clear();
      count_on_line = 0;
    }
  }
  if (count_on_line > 0) {
    put(row, ray_line.str(), 0.40);
  }

  if (panel.rows != view.rows) {
    cv::Mat adjusted(panel.rows, view.cols, CV_8UC3, cv::Scalar(0, 0, 0));
    view.copyTo(adjusted(cv::Rect(0, 0, view.cols, view.rows)));
    view = adjusted;
  }
  cv::Mat canvas;
  cv::hconcat(view, panel, canvas);

  std::filesystem::path dir = std::filesystem::path(classification_image_dir_);
  if (classified) {
    dir /= "classified";
    dir /= sanitizeFileToken(debug.kind);
  } else {
    dir /= "rejected";
    dir /= sanitizeFileToken(reason);
  }
  std::error_code ec;
  std::filesystem::create_directories(dir, ec);
  if (ec) {
    RCLCPP_WARN(get_logger(),
                "ROBOT_EVENT node=ros2_vision event=vision_debug_image_dir_failed path=%s error=%s",
                dir.string().c_str(),
                ec.message().c_str());
    return;
  }

  std::ostringstream stem;
  stem << debug.status << "_seq" << std::setw(8) << std::setfill('0') << frame.seq
       << "_tile" << frame.tile_x << "_" << frame.tile_y
       << "_" << sanitizeFileToken(frame.camera_name)
       << "_" << sanitizeFileToken(debug.kind)
       << "_" << sanitizeFileToken(chosen)
       << "_" << sanitizeFileToken(reason);
  const std::filesystem::path png_path = dir / (stem.str() + ".png");
  if (!cv::imwrite(png_path.string(), canvas)) {
    RCLCPP_WARN(get_logger(),
                "ROBOT_EVENT node=ros2_vision event=vision_debug_image_write_failed path=%s",
                png_path.string().c_str());
    return;
  }

  // Also save the RAW camera frame (unscaled, unannotated) next to the debug
  // panel so rejected images -- fake, too_far, no_object, etc. -- can be folded
  // straight back into the dataset to retrain / diagnose the models later.
  const std::filesystem::path raw_path = dir / (stem.str() + ".frame.png");
  cv::imwrite(raw_path.string(), bgr);

  const std::filesystem::path lidar_path = dir / (stem.str() + ".lidar.txt");
  std::ofstream lidar(lidar_path);
  if (lidar.good()) {
    lidar << std::fixed << std::setprecision(6)
          << "seq=" << frame.seq << "\n"
          << "status=" << debug.status << "\n"
          << "kind=" << debug.kind << "\n"
          << "class=" << debug.class_name << "\n"
          << "reason=" << reason << "\n"
          << "camera=" << frame.camera_name << "\n"
          << "tile_x=" << frame.tile_x << "\n"
          << "tile_y=" << frame.tile_y << "\n"
          << "lidar_xmin=" << debug.lidar_xmin << "\n"
          << "lidar_xmax=" << debug.lidar_xmax << "\n"
          << "selected_count=" << rays.size() << "\n"
          << "index angle_rad range_m selected valid pixel_x\n";
    std::set<int> selected;
    for (const auto& ray : rays) {
      selected.insert(ray.index);
    }
    for (std::size_t i = 0; i < frame.scan.size(); ++i) {
      const int idx = static_cast<int>(i);
      const float range = frame.scan[i];
      const bool valid = std::isfinite(range) &&
        range >= frame.lidar_range_min &&
        range <= frame.lidar_range_max;
      lidar << idx << " "
            << frame.lidar_angle_min + static_cast<double>(idx) * frame.lidar_angle_increment << " "
            << range << " "
            << (selected.count(idx) ? 1 : 0) << " "
            << (valid ? 1 : 0) << " "
            << scanIndexToPixel(idx, frame) << "\n";
    }
  }

  RCLCPP_INFO(get_logger(),
              "ROBOT_EVENT node=ros2_vision event=vision_debug_image_saved status=%s reason=%s path=%s lidar_path=%s seq=%lu kind=%s class=%s",
              debug.status.c_str(),
              reason.c_str(),
              png_path.string().c_str(),
              lidar_path.string().c_str(),
              static_cast<unsigned long>(frame.seq),
              debug.kind.c_str(),
              debug.class_name.c_str());
}

void VisionNode::saveClassificationImage(const VisionFrame& frame,
                                         const VisionDetection& detection,
                                         double inference_ms) const
{
  (void)inference_ms;
  VisionDebugImage debug;
  debug.status = "classified";
  debug.kind = detection.kind;
  debug.class_name = detection.class_name;
  debug.confidence = detection.confidence;
  debug.distance = detection.distance;
  debug.bbox = detection.bbox;
  debug.center_x = detection.center_x;
  debug.center_y = detection.center_y;
  debug.target_pattern = detection.target_pattern;
  debug.target_sum = detection.target_sum;
  debug.radial_coverage = detection.radial_coverage;
  debug.mask_confidence = detection.mask_confidence;
  saveVisionDebugImage(frame, debug);
}

std::string VisionNode::detectionToJson(const VisionDetection& detection) const
{
  std::ostringstream oss;
  oss << std::fixed << std::setprecision(3)
      << "{"
      << "\"seq\":" << detection.seq << ","
      << "\"camera\":\"" << jsonEscape(detection.camera_name) << "\","
      << "\"tile_x\":" << detection.tile_x << ","
      << "\"tile_y\":" << detection.tile_y << ","
      << "\"kind\":\"" << jsonEscape(detection.kind) << "\","
      << "\"class\":\"" << jsonEscape(detection.class_name) << "\","
      << "\"confidence\":" << detection.confidence << ","
      << "\"distance\":" << detection.distance << ","
      << "\"center_x\":" << detection.center_x << ","
      << "\"center_y\":" << detection.center_y << ","
      << "\"bbox_x\":" << detection.bbox.x << ","
      << "\"bbox_y\":" << detection.bbox.y << ","
      << "\"bbox_w\":" << detection.bbox.width << ","
      << "\"bbox_h\":" << detection.bbox.height << ","
      << "\"target_pattern\":\"" << jsonEscape(detection.target_pattern) << "\","
      << "\"target_sum\":" << detection.target_sum << ","
      << "\"radial_coverage\":" << detection.radial_coverage << ","
      << "\"mask_confidence\":" << detection.mask_confidence << ","
      << "\"target_radius_px\":" << detection.target_radius_px << ","
      << "\"target_major_radius_px\":" << detection.target_major_radius_px << ","
      << "\"target_minor_radius_px\":" << detection.target_minor_radius_px << ","
      << "\"target_angle_deg\":" << detection.target_angle_deg << ","
      << "\"target_fit_error\":" << detection.target_fit_error
      << "}";
  return oss.str();
}

std::string VisionNode::detectionToResultLine(const VisionDetection& detection) const
{
  std::ostringstream oss;
  oss << std::fixed << std::setprecision(3)
      << "VISION_RESULT|"
      << detection.seq << '|'
      << detection.camera_name << '|'
      << detection.tile_x << '|'
      << detection.tile_y << '|'
      << detection.kind << '|'
      << detection.class_name << '|'
      << detection.confidence << '|'
      << detection.distance << '|'
      << static_cast<int>(std::round(detection.center_x)) << '|'
      << static_cast<int>(std::round(detection.center_y)) << '|'
      << detection.bbox.x << '|'
      << detection.bbox.y << '|'
      << detection.bbox.width << '|'
      << detection.bbox.height << '|'
      << detection.target_pattern << '|'
      << detection.target_sum << '|'
      << detection.radial_coverage;
  return oss.str();
}

}  // namespace ros2_vision
