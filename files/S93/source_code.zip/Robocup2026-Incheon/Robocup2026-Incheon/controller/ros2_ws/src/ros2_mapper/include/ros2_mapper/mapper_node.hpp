#ifndef ROS2_MAPPER__MAPPER_NODE_HPP_
#define ROS2_MAPPER__MAPPER_NODE_HPP_

#include "ros2_mapper/map_geometry_models.hpp"
#include "ros2_mapper/phantom_tile_map.hpp"
#include "ros2_mapper/slam_map_sampler.hpp"
#include "ros2_mapper/submission_matrix_builder.hpp"
#include "ros2_mapper/tile_map.hpp"
#include "ros2_mapper/tile_math.hpp"

#include <builtin_interfaces/msg/time.hpp>
#include <nav_msgs/msg/occupancy_grid.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <rclcpp/rclcpp.hpp>
#include <rcl_interfaces/msg/set_parameters_result.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>
#include <visualization_msgs/msg/marker.hpp>
#include <visualization_msgs/msg/marker_array.hpp>
#include <std_msgs/msg/string.hpp>

#include <deque>
#include <array>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

namespace ros2_mapper
{

class MapperNode : public rclcpp::Node
{
public:
  MapperNode();

private:
  enum class EventLevel
  {
    Info,
    Warn,
    Error,
    Debug
  };

  struct PendingScan
  {
    sensor_msgs::msg::LaserScan::SharedPtr scan;
    rclcpp::Time stamp;
    rclcpp::Time received_at;
  };

  struct InterpolatedOdomResult
  {
    nav_msgs::msg::Odometry odom;
    double delta_before_s = 0.0;
    double delta_after_s = 0.0;
    double bracket_gap_s = 0.0;
    bool interpolated = false;
  };

  struct PendingTransitionCrossing
  {
    TileCoord tile;
    FloorColorClass color = FloorColorClass::Unknown;
    std::optional<TileCoord> entry_tile;
    bool robot_entered_transition = false;
  };

  struct VisionVictimObservation
  {
    TileCoord tile;
    SubmissionVictimMark mark;
    std::string camera;
    double confidence = 0.0;
  };

  struct PendingHoleCandidate
  {
    TileCoord tile;
    double confidence = 0.0;
    int hits = 0;
    rclcpp::Time first_seen;
    rclcpp::Time last_seen;
    std::string sources;
  };

  void loadParameters();
  void validateParameters() const;
  rcl_interfaces::msg::SetParametersResult onDynamicParameters(
    const std::vector<rclcpp::Parameter> & parameters);

  void odomCallback(nav_msgs::msg::Odometry::SharedPtr msg);
  void scanCallback(sensor_msgs::msg::LaserScan::SharedPtr msg);
  void slamMapCallback(nav_msgs::msg::OccupancyGrid::SharedPtr msg);
  void bridgeReadyCallback(const std_msgs::msg::String::SharedPtr msg);
  void publishTimerCallback();

  void integrateLidarPhantomObservations(
    const sensor_msgs::msg::LaserScan & scan,
    const nav_msgs::msg::Odometry & odom,
    const rclcpp::Time & stamp);
  TileQuadrant tileQuadrantForPoint(
    double x,
    double y,
    const TileCoord & coord) const;
  int supportBinIndexForPoint(
    double x,
    double y,
    const TileCoord & coord) const;
  SubtileIndex subtileForPoint(
    double x,
    double y,
    const TileCoord & coord) const;
  std::vector<CanonicalSegmentKey> canonicalSegmentsNearPoint(
    double x,
    double y,
    const TileCoord & coord,
    double tolerance) const;
  void recordRayModelPrimitiveObservations(
    const TileCoord & coord,
    SubtileIndex subtile,
    double ray_origin_x,
    double ray_origin_y,
    double ray_dir_x,
    double ray_dir_y,
    double endpoint_range,
    bool hit_valid,
    bool allow_positive_hit,
    const rclcpp::Time & stamp);
  bool isTileWithinCurrentRadius(const TileCoord & coord, int radius) const;

  void initializeOriginFromPose(double x, double y);
  void detectTeleportIfNeeded(const nav_msgs::msg::Odometry & odom);
  void updateCurrentTile(const nav_msgs::msg::Odometry & odom);
  nav_msgs::msg::Odometry::SharedPtr findClosestOdom(
    const rclcpp::Time & stamp,
    double * delta_s) const;
  bool interpolateOdomForStamp(
    const rclcpp::Time & stamp,
    InterpolatedOdomResult * result) const;
  void processPendingScans();
  bool processSingleScanWithOdom(
    const sensor_msgs::msg::LaserScan::SharedPtr & scan,
    const rclcpp::Time & scan_stamp,
    const nav_msgs::msg::Odometry & odom);
  void reevaluateRaceMappingActivation(const rclcpp::Time & stamp);
  void clearPreReadyRuntimeBuffers();

  void floorColorCallback(const std_msgs::msg::String::SharedPtr msg);
  void holeDetectionCallback(const std_msgs::msg::String::SharedPtr msg);
  void visionClassificationCallback(const std_msgs::msg::String::SharedPtr msg);

  void applyFloorColorObservation(
    FloorColorClass color_class,
    double confidence,
    const rclcpp::Time & stamp);

  static FloorColorClass parseFloorColorClass(const std::string & value);
  static const char * tileAreaToString(TileArea area);
  static const char * tileKindToString(TileKind kind);
  static const char * hazardStateToString(HazardState state);
  static const char * hazardTypeToString(HazardType type);
  static const char * hazardSourceToString(HazardSource source);
  static const char * hazardEdgeToString(HazardEdge edge);
  static std::string tileCoordToJson(const TileCoord & coord);
  std::string hazardJson(const TileRecord & record, const rclcpp::Time & stamp) const;
  std::string tileRecordToJson(
    const TileRecord & record,
    const rclcpp::Time & stamp,
    const geometry_msgs::msg::TransformStamped * semantic_to_map) const;
  std::string phantomRecordToJson(
    const PhantomTileEvidence & evidence,
    const rclcpp::Time & stamp,
    const geometry_msgs::msg::TransformStamped * semantic_to_map) const;
  std::string phantomMapJson(
    const rclcpp::Time & stamp,
    const geometry_msgs::msg::TransformStamped * semantic_to_map) const;
  std::string slamRegionStatsToJson(const SlamRegionStats & stats) const;
  std::string slamRegionStatsToJson(
    const SlamRegionStats & stats,
    const EdgeEvidence * edge_evidence,
    const rclcpp::Time & stamp) const;
  std::string edgeEvidenceJson(
    const EdgeEvidence & evidence,
    const rclcpp::Time & stamp) const;
  EdgeEvidence & tileEdgeEvidence(
    const TileCoord & coord,
    SlamCardinalDirection direction) const;
  EdgeEvidence & phantomEdgeEvidence(
    const TileCoord & coord,
    SlamCardinalDirection direction) const;
  void updateEdgeEvidence(
    EdgeEvidence & evidence,
    const SlamRegionStats & stats,
    const rclcpp::Time & stamp) const;
  static bool hasSemanticState(const TileRecord & record);
  static std::string stampToJson(const rclcpp::Time & stamp);
  std::optional<geometry_msgs::msg::TransformStamped> lookupTransformToSlamMapFrame(
    const std::string & source_frame) const;
  std::string slamGeometryStatusJson(const rclcpp::Time & stamp) const;
  std::string currentTileJson(const TileRecord & record, const rclcpp::Time & stamp) const;
  std::string semanticMapJson(const rclcpp::Time & stamp) const;
  std::string mapperStatusJson(const rclcpp::Time & stamp) const;
  void maybeLogSlamGeometryStatus(const rclcpp::Time & stamp);
  void publishCurrentTile(const TileRecord & record, const rclcpp::Time & stamp) const;
  void publishSemanticMapJson(const rclcpp::Time & stamp);
  void maybePublishSemanticMapJson(const rclcpp::Time & stamp);
  SubmissionResolvedWalls buildSubmissionResolvedWalls(const rclcpp::Time & stamp) const;
  SubmissionResolvedTileModels buildSubmissionResolvedTileModels(const rclcpp::Time & stamp);
  // Adds tiles the explored RF model reads off the SLAM grid but that have no
  // tile record (never physically visited). Extends the submission matrix to
  // everything actually mapped instead of only tiles driven over.
  int addModelExploredTiles(SubmissionResolvedTileModels & models);
  void publishSubmissionMatrix(const rclcpp::Time & stamp);
  void publishSubmissionGeometryMarkers(
    const SubmissionResolvedTileModels & resolved_models,
    const rclcpp::Time & stamp);
  void publishMapperStatus(const rclcpp::Time & stamp);  void maybePublishMapperStatus(const rclcpp::Time & stamp);
  void publishMapperEvent(const std::string & json) const;
  void logRobotEvent(
    EventLevel level,
    const std::string & event,
    const std::vector<std::pair<std::string, std::string>> & fields = {}) const;
  void logRobotEvent(
    const std::string & event,
    const std::vector<std::pair<std::string, std::string>> & fields = {}) const;
  std::string tileChangedEventJson(
    const TileCoord & previous_coord,
    const TileRecord & record,
    const rclcpp::Time & stamp) const;
  std::string semanticEventJson(
    const char * event,
    const TileRecord & record,
    const rclcpp::Time & stamp) const;
  std::string hazardEventJson(
    const char * event,
    const TileRecord & record,
    const rclcpp::Time & stamp,
    const std::optional<TileCoord> & robot_tile,
    double heading_yaw,
    double robot_x,
    double robot_y,
    double sensor_x,
    double sensor_y) const;
  std::string teleportEventJson(
    double distance_delta,
    double yaw_delta,
    const TileCoord & coord,
    const rclcpp::Time & stamp) const;
  void updateCurrentAreaFromRecord(const TileRecord & record, const rclcpp::Time & stamp);
  void updateCurrentAreaFromTransition(FloorColorClass color_class, const rclcpp::Time & stamp);
  void beginPendingTransitionCrossing(
    TileCoord transition_tile,
    FloorColorClass color,
    TileCoord robot_tile);
  void updatePendingTransitionCrossing(
    TileCoord previous_tile,
    TileCoord new_tile,
    const rclcpp::Time & stamp);
  void clearPendingTransitionCrossing();
  void assignCurrentAreaToRecord(TileRecord & record, const rclcpp::Time & stamp);
  bool useArea4GeometryForTile(TileArea area) const;

  visualization_msgs::msg::MarkerArray buildTileMarkers(
    const nav_msgs::msg::Odometry & odom) const;
  visualization_msgs::msg::Marker buildVisitedTileMarker(
    const TileRecord & record,
    const rclcpp::Time & stamp) const;
  visualization_msgs::msg::Marker buildCurrentTileMarker(
    const geometry_msgs::msg::Point & center,
    const rclcpp::Time & stamp) const;
  visualization_msgs::msg::Marker buildCurrentTileCenterMarker(
    const geometry_msgs::msg::Point & center,
    const rclcpp::Time & stamp) const;
  builtin_interfaces::msg::Time markerStamp(const rclcpp::Time & stamp) const;
  visualization_msgs::msg::Marker buildLidarDebugMarker(
    const nav_msgs::msg::Odometry & odom,
    const sensor_msgs::msg::LaserScan & scan) const;
  visualization_msgs::msg::MarkerArray buildPhantomTileMarkers(
    const rclcpp::Time & stamp);

  void applyVisitedTileColor(
    const TileRecord & record,
    visualization_msgs::msg::Marker & marker) const;
  bool updateHazardFromFloorColor(
    TileRecord & record,
    FloorColorClass color_class,
    double confidence,
    const rclcpp::Time & stamp) const;

  static double yawFromQuaternion(const geometry_msgs::msg::Quaternion & q);
  static double normalizeAngle(double angle);

  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr scan_sub_;
  rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr slam_map_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr bridge_ready_sub_;
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr tile_markers_pub_;
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr phantom_tile_markers_pub_;
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr submission_geometry_marker_pub_;
  rclcpp::Publisher<visualization_msgs::msg::Marker>::SharedPtr lidar_points_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr current_tile_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr tile_semantic_map_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr submission_matrix_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr mapper_events_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr mapper_status_pub_;  rclcpp::TimerBase::SharedPtr publish_timer_;
  rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr parameter_callback_handle_;
  std::unique_ptr<tf2_ros::Buffer> tf_buffer_;
  std::shared_ptr<tf2_ros::TransformListener> tf_listener_;

  nav_msgs::msg::Odometry::SharedPtr latest_odom_;
  sensor_msgs::msg::LaserScan::SharedPtr latest_scan_;
  std::deque<nav_msgs::msg::Odometry::SharedPtr> odom_buffer_;
  std::deque<PendingScan> pending_scans_;
  nav_msgs::msg::Odometry::SharedPtr latest_lidar_debug_odom_;
  sensor_msgs::msg::LaserScan::SharedPtr latest_lidar_debug_scan_;
  rclcpp::Time lidar_integration_blocked_until_;
  rclcpp::Time last_integrated_scan_stamp_;
  rclcpp::Time last_semantic_map_publish_stamp_;
  rclcpp::Time last_status_publish_stamp_;
  rclcpp::Time last_map_validity_summary_log_stamp_;
  rclcpp::Time last_odom_received_stamp_;
  // Tracks scan receipt time, not necessarily successful delayed integration time.
  rclcpp::Time last_scan_received_stamp_;
  rclcpp::Time last_slam_map_received_stamp_;
  rclcpp::Time last_valid_slam_map_stamp_;
  bool has_last_integrated_scan_stamp_ = false;
  bool has_last_semantic_map_publish_stamp_ = false;
  bool has_last_status_publish_stamp_ = false;
  bool has_last_map_validity_summary_log_stamp_ = false;
  bool has_last_odom_received_stamp_ = false;
  bool has_last_scan_received_stamp_ = false;
  bool has_slam_map_received_ = false;
  bool has_valid_slam_map_ = false;
  nav_msgs::msg::OccupancyGrid last_valid_slam_map_;
  SlamMapSampler slam_map_sampler_;

  // RandomForest (RTrees) geometry specialists: explored gate -> wall/curve per
  // subtile, obstacle per tile. Replace the legacy confidence-based detection.
  MapGeometryModels map_geometry_models_;
  std::string map_model_explorado_path_;
  std::string map_model_parede_path_;
  std::string map_model_curva_path_;
  std::string map_model_obstaculo_path_;
  rclcpp::Time last_slam_geometry_log_stamp_;
  bool has_last_slam_geometry_log_stamp_ = false;
  mutable std::unordered_map<TileCoord, std::array<EdgeEvidence, 4>, TileCoordHash>
  tile_edge_evidence_;
  mutable std::unordered_map<TileCoord, std::array<EdgeEvidence, 4>, TileCoordHash>
  phantom_edge_evidence_;
  TileMap tile_map_;
  PhantomTileMap phantom_tile_map_;
  std::optional<TileCoord> previous_current_tile_;
  std::optional<TileCoord> tile_before_current_tile_;

  TileArea current_area_ = TileArea::Unknown;
  bool current_area_known_ = false;
  rclcpp::Time last_area_update_stamp_;

  std::optional<TileCoord> active_transition_tile_;
  FloorColorClass active_transition_color_ = FloorColorClass::Unknown;
  std::optional<PendingTransitionCrossing> pending_transition_crossing_;
  std::optional<TileCoord> last_applied_transition_tile_;
  FloorColorClass last_applied_transition_color_ = FloorColorClass::Unknown;
  rclcpp::Time last_applied_transition_stamp_;
  std::string odom_topic_;
  std::string scan_topic_;
  std::string bridge_ready_topic_;
  std::string tile_markers_topic_;
  std::string lidar_points_topic_;
  std::string phantom_tiles_topic_;
  std::string submission_geometry_topic_;
  std::string marker_frame_;

  bool publish_submission_geometry_ = true;
  std::string submission_curve_visual_transform_ = "rotate_180";
  double submission_min_wall_confidence_ = 0.5;

  bool use_area4_all_ = false;
  bool submission_model_explored_tiles_ = true;
  bool submission_area4_flood_fill_ = true;
  double tile_size_;
  std::string origin_mode_;
  double origin_x_;
  double origin_y_;
  bool origin_initialized_;
  bool auto_start_ = false;
  bool mapping_active_ = false;
  bool origin_initialization_after_activation_pending_ = false;
  bool origin_require_scan_before_init_ = true;
  double origin_require_scan_timeout_s_ = 5.0;
  bool race_wait_for_bridge_ready_ = false;
  bool race_require_scan_after_ready_ = true;
  bool race_require_odom_after_ready_ = true;
  bool bridge_ready_ = false;
  bool scan_seen_after_bridge_ready_ = false;
  bool odom_seen_after_bridge_ready_ = false;
  bool race_waiting_for_fresh_scan_after_activation_ = false;
  bool has_bridge_connection_id_ = false;
  std::uint64_t bridge_connection_id_ = 0;

  bool marker_use_latest_tf_stamp_ = true;
  double marker_publish_rate_hz_;
  double current_tile_marker_z_;
  double current_tile_marker_height_;
  double current_tile_alpha_;
  double current_tile_color_r_;
  double current_tile_color_g_;
  double current_tile_color_b_;
  double current_tile_center_z_;
  double current_tile_center_radius_;

  bool publish_visited_tiles_;
  double visited_tile_marker_z_;
  double visited_tile_marker_height_;
  double visited_tile_alpha_;
  double visited_tile_color_r_;
  double visited_tile_color_g_;
  double visited_tile_color_b_;
  bool log_tile_changes_;
  bool mark_origin_tile_as_start_;
  bool publish_semantic_tile_colors_;
  double semantic_tile_alpha_;
  bool publish_semantic_map_json_ = true;
  double semantic_map_publish_period_s_ = 0.5;
  int semantic_map_max_tiles_ = 500;
  double status_publish_period_s_ = 0.5;
  double map_validity_summary_log_period_s_ = 1.0;
  std::string last_map_validity_summary_signature_;
  double odom_recent_timeout_s_ = 1.0;
  double scan_recent_timeout_s_ = 1.0;
  double slam_map_recent_timeout_s_ = 3.0;
  SlamMapSamplerConfig slam_geometry_config_;
  bool edge_evidence_enabled_ = true;
  double edge_evidence_wall_update_gain_ = 0.85;
  double edge_evidence_open_update_gain_ = 0.65;
  double edge_evidence_conflict_decay_ = 0.35;
  double edge_evidence_unknown_ema_alpha_ = 0.30;
  double edge_evidence_min_log_odds_ = -4.0;
  double edge_evidence_max_log_odds_ = 4.0;
  double edge_evidence_confirmed_wall_log_odds_ = 2.2;
  double edge_evidence_likely_wall_log_odds_ = 1.0;
  double edge_evidence_confirmed_open_log_odds_ = 2.0;
  double edge_evidence_likely_open_log_odds_ = 0.9;
  double edge_evidence_conflict_log_odds_delta_ = 0.75;
  double edge_evidence_stale_after_sec_ = 3.0;

  bool publish_lidar_debug_points_;
  int lidar_debug_point_stride_;
  double lidar_debug_point_size_;
  double lidar_debug_z_;
  double lidar_debug_min_range_;
  double lidar_debug_max_range_;

  bool enable_lidar_phantom_observations_ = true;
  double lidar_observation_max_range_ = 0.55;
  double lidar_ray_step_m_ = 0.015;
  double lidar_ray_grid_step_m_ = 0.005;
  double lidar_range_weight_scale_m_ = 0.5;
  double lidar_range_sigma_m_ = 0.003;
  double lidar_evidence_decay_half_life_s_ = 8.0;
  double lidar_positive_evidence_max_ = 12.0;
  double lidar_negative_evidence_max_ = 12.0;
  double lidar_conflict_weight_ = 2.0;
  double lidar_skip_after_teleport_s_ = 0.50;
  double odom_buffer_duration_s_ = 1.0;
  double scan_odom_match_max_delta_s_ = 0.12;
  bool enable_delayed_scan_processing_ = true;
  double scan_processing_delay_s_ = 0.10;
  double scan_pending_max_age_s_ = 0.50;
  bool require_odom_bracket_for_scan_ = true;
  double odom_interpolation_max_gap_s_ = 0.20;
  double max_scan_odom_time_delta_s_ = 0.15;
  bool reject_non_monotonic_scan_stamps_ = true;

  bool teleport_detection_enabled_;
  double teleport_distance_threshold_m_;
  double teleport_yaw_threshold_rad_;

  bool publish_phantom_tiles_ = true;
  std::string phantom_visual_mode_ = "summary";
  bool publish_phantom_tile_background_ = false;
  bool publish_phantom_quadrant_debug_ = false;
  bool publish_phantom_free_summary_ = false;
  int phantom_update_max_tile_radius_ = 4;
  int phantom_mask_max_tile_radius_ = 3;
  double phantom_tile_marker_z_ = 0.035;
  double phantom_tile_marker_height_ = 0.003;
  double phantom_tile_marker_alpha_ = 0.02;
  double phantom_quadrant_marker_z_ = 0.038;
  double phantom_quadrant_marker_height_ = 0.004;
  double phantom_quadrant_marker_alpha_min_ = 0.01;
  double phantom_quadrant_marker_alpha_max_ = 0.08;

  bool enable_quarter_edge_evidence_ = true;
  double quarter_edge_hit_tolerance_m_ = 0.012;
  double quarter_edge_free_conflict_tolerance_m_ = 0.010;
  int quarter_edge_min_visibility_rays_ = 3;
  double quarter_edge_hit_weight_ = 1.0;
  double quarter_edge_conflict_weight_ = 2.0;
  bool publish_quarter_edge_debug_ = false;
  double quarter_edge_marker_z_ = 0.052;
  double quarter_edge_marker_thickness_ = 0.006;
  double quarter_edge_marker_alpha_min_ = 0.04;
  double quarter_edge_marker_alpha_max_ = 0.25;
  double mask_supported_segment_min_score_ = 0.5;
  double mask_conflict_segment_max_score_ = -0.5;
  double mask_complexity_penalty_ = 0.15;
  double mask_unsupported_segment_penalty_ = 0.25;
  double mask_min_confidence_ = 0.0;
  bool publish_phantom_mask_debug_ = false;
  double phantom_mask_marker_z_ = 0.060;
  double phantom_mask_marker_thickness_ = 0.009;
  double phantom_mask_marker_alpha_min_ = 0.08;
  double phantom_mask_marker_alpha_max_ = 0.45;
  double phantom_summary_min_confidence_ = 0.20;
  double phantom_summary_marker_alpha_min_ = 0.08;
  double phantom_summary_marker_alpha_max_ = 0.50;
  double phantom_free_summary_alpha_max_ = 0.12;

  bool enable_ray_model_primitives_ = true;
  double primitive_wall_thickness_m_ = 0.010;
  double primitive_wall_margin_m_ = 0.006;
  double primitive_base_tolerance_m_ = 0.006;
  double primitive_yaw_sigma_rad_ = 0.035;
  double primitive_hit_tolerance_max_m_ = 0.008;
  bool primitive_allow_multi_positive_per_ray_ = false;
  double primitive_positive_min_incidence_ = 0.40;
  double primitive_positive_min_hit_score_ = 0.20;
  double primitive_endpoint_exclusion_ratio_ = 0.10;
  double primitive_positive_log_odds_update_ = 0.25;
  double primitive_negative_log_odds_update_ = 0.90;
  double primitive_log_odds_min_ = -4.0;
  double primitive_log_odds_max_ = 4.0;
  int primitive_min_visibility_rays_ = 8;
  bool publish_primitive_debug_ = true;
  double primitive_debug_min_confidence_ = 0.40;
  double primitive_debug_marker_z_ = 0.070;
  double primitive_debug_marker_alpha_min_ = 0.08;
  double primitive_debug_marker_alpha_max_ = 0.65;
  double primitive_debug_marker_thickness_ = 0.008;
  double primitive_debug_color_r_ = 0.20;
  double primitive_debug_color_g_ = 0.95;
  double primitive_debug_color_b_ = 1.00;
  bool publish_primitive_negative_debug_ = false;
  double primitive_negative_debug_min_confidence_ = 0.30;
  double primitive_negative_debug_color_r_ = 1.00;
  double primitive_negative_debug_color_g_ = 0.15;
  double primitive_negative_debug_color_b_ = 0.15;
  double primitive_negative_debug_marker_alpha_min_ = 0.04;
  double primitive_negative_debug_marker_alpha_max_ = 0.25;

  bool enable_obstacle_primitives_ = false;
  int obstacle_grid_bins_per_tile_ = kObstacleGridBinsPerTile;
  double obstacle_bin_hit_weight_ = 1.0;
  double obstacle_bin_free_weight_ = 2.0;
  double obstacle_bin_occupied_threshold_ = 3.0;
  double obstacle_bin_free_margin_ = 1.0;
  int obstacle_min_cluster_bins_ = 8;
  int obstacle_min_total_hits_ = 10;
  double obstacle_min_confidence_ = 0.70;
  double obstacle_debug_min_confidence_ = 0.70;
  double obstacle_max_free_ratio_ = 0.30;
  double obstacle_min_distance_from_tile_edge_m_ = 0.015;
  double obstacle_min_box_size_m_ = 0.015;
  double obstacle_max_box_size_m_ = 0.085;
  double obstacle_box_padding_m_ = 0.005;
  int obstacle_surrounding_ring_bins_ = 2;
  double obstacle_min_surrounding_free_ratio_ = 0.45;
  double obstacle_wall_overlap_penalty_ = 2.0;
  double obstacle_edge_proximity_penalty_ = 1.5;
  double obstacle_temporal_decay_half_life_s_ = 6.0;
  bool publish_obstacle_grid_debug_ = false;

  double subtile_wall_center_mask_ratio_ = 0.65;
  double subtile_curve_center_mask_ratio_ = 0.80;
  double floor_color_center_mask_ratio_ = 0.70;
  double transition_reassociation_boundary_margin_m_ = 0.006;
  double transition_center_max_distance_m_ = 0.068;
  double checkpoint_center_max_distance_m_ = 0.055;
  double transition_same_color_cooldown_s_ = 6.0;
  double black_hole_projection_boundary_margin_m_ = 0.012;
  double semantic_observation_max_abs_world_m_ = 50.0;
  int semantic_observation_max_tile_distance_ = 2;
  int hole_duplicate_association_radius_tiles_ = 1;
  double hole_duplicate_association_max_center_distance_m_ = 0.17;
  int hole_confirmation_required_hits_ = 2;
  double hole_confirmation_window_s_ = 2.0;
  double hole_confirm_immediate_confidence_ = 0.95;
  double hole_candidate_min_confidence_ = 0.75;

  bool enable_curve_primitives_ = true;
  double curve_proto_inner_radius_ = 0.055;
  double curve_proto_outer_radius_ = 0.065;
  double curve_proto_tile_size_ = 0.300;
  double curve_wall_margin_m_ = 0.0015;
  double curve_base_tolerance_m_ = 0.006;
  double curve_hit_tolerance_max_m_ = 0.01875;
  double curve_yaw_sigma_rad_ = 0.035;
  double curve_subtile_containment_tolerance_m_ = 0.0015;
  double curve_radius_offset_m_ = -0.002;
  double curve_radial_center_tolerance_m_ = 0.004;
  double curve_radial_center_power_ = 2.0;
  double curve_angular_center_power_ = 2.5;
  double curve_positive_weight_scale_ = 1.00;
  double curve_negative_weight_scale_ = 0.70;
  double curve_subtile_containment_required_fraction_ = 0.98;
  double curve_positive_min_incidence_ = 0.40;
  double curve_positive_min_hit_score_ = 0.20;
  double curve_endpoint_exclusion_ratio_ = 0.10;
  int curve_min_visibility_rays_ = 8;
  double curve_min_confidence_ = 0.20;
  double curve_min_best_margin_ = 0.05;
  double curve_edge_ambiguity_ratio_ = 0.70;
  int curve_coverage_bins_ = 16;
  double curve_min_coverage_score_ = 0.20;
  bool publish_curve_debug_ = true;
  bool publish_curve_geometry_debug_ = true;
  double curve_debug_min_confidence_ = 0.05;
  bool curve_debug_log_scores_ = false;
  double curve_debug_log_period_s_ = 2.0;
  double curve_debug_marker_z_ = 0.078;
  double curve_debug_marker_alpha_min_ = 0.08;
  double curve_debug_marker_alpha_max_ = 0.65;
  double curve_debug_color_r_ = 0.20;
  double curve_debug_color_g_ = 0.95;
  double curve_debug_color_b_ = 1.00;

  bool enable_floor_color_observations_ = true;
  std::string floor_color_topic_ = "/floor_color/classification";
  double color_sensor_forward_offset_ = 0.035;
  double color_sensor_lateral_offset_ = 0.0;
  double floor_color_min_confidence_ = 0.5;
  double floor_color_update_margin_m_ = 0.005;
  bool floor_color_allow_normal_correction_ = true;
  bool hazard_preserve_confirmed_black_hole_ = true;
  std::string hole_detection_topic_ = "/hazard/hole_detection";
  std::string vision_classification_topic_ = "/vision/classification";
  double legacy_hole_projection_distance_m_ = 0.06;
  double controller_hole_weak_distance_travel_m_ = 0.005;
  double controller_hole_normal_clear_center_distance_m_ = 0.025;
  int controller_hole_normal_clear_hits_ = 2;
  double area_hint_max_lidar_distance_m_ = 0.25;
  bool area_assignment_requires_visit_ = true;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr floor_color_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr hole_detection_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr vision_classification_sub_;
  std::vector<VisionVictimObservation> vision_victims_;
  std::unordered_map<TileCoord, PendingHoleCandidate, TileCoordHash> pending_hole_candidates_;
};

}  // namespace ros2_mapper

#endif  // ROS2_MAPPER__MAPPER_NODE_HPP_
