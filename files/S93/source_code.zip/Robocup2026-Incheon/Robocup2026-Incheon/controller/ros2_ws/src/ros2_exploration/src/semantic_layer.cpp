#include "ros2_exploration/semantic_layer.hpp"

namespace ros2_exploration
{

void SemanticLayer::setEnabled(bool enabled)
{
  enabled_ = enabled;
}

bool SemanticLayer::enabled() const
{
  return enabled_;
}

double SemanticLayer::scoreBias(const Frontier & frontier) const
{
  (void)frontier;
  return 0.0;
}

}  // namespace ros2_exploration
