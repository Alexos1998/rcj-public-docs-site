import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import LifecycleNode, Node
from launch_ros.parameter_descriptions import ParameterValue


def _runtime_params_list(context):
    """Return [runtime_params_file] when it points at an existing file, else []."""
    path = LaunchConfiguration("runtime_params_file").perform(context)
    return [path] if path and os.path.exists(path) else []


def launch_setup(context, *args, **kwargs):
    del args, kwargs

    pkg_share = get_package_share_directory("ros2_mapper")
    mapper_mode = LaunchConfiguration("mapper_mode")
    use_sim_time = LaunchConfiguration("use_sim_time")
    use_area4_all = LaunchConfiguration("use_area4_all")
    auto_start = LaunchConfiguration("auto_start")
    race_wait_for_bridge_ready = LaunchConfiguration("race_wait_for_bridge_ready")

    slam_params_file = os.path.join(pkg_share, "config", "slam_toolbox.yaml")
    mapper_config = os.path.join(pkg_share, "config", "mapper.yaml")

    # Runtime override file is appended LAST so it wins over the base YAMLs.
    runtime_params = _runtime_params_list(context)

    return [
        LogInfo(
            msg=[
                "mapper_mode='",
                mapper_mode,
                "' is deprecated and ignored; unified mapper starts SLAM Toolbox + ros2_mapper_node.",
            ]
        ),
        Node(
            package="ros2_mapper",
            executable="scan_runtime_filter",
            name="scan_runtime_filter",
            output="screen",
            parameters=[{"use_sim_time": use_sim_time}, *runtime_params],
        ),
        LifecycleNode(
            package="slam_toolbox",
            executable="async_slam_toolbox_node",
            name="slam_toolbox",
            namespace="",
            output="screen",
            parameters=[slam_params_file, {"use_sim_time": use_sim_time}, *runtime_params],
        ),
        Node(
            package="nav2_lifecycle_manager",
            executable="lifecycle_manager",
            name="lifecycle_manager_slam_toolbox",
            output="screen",
            parameters=[
                {
                    "use_sim_time": use_sim_time,
                    "autostart": True,
                    "node_names": ["slam_toolbox"],
                    # slam_toolbox (async node) does not keep its lifecycle bond
                    # alive reliably under load in this build: the manager kept
                    # reporting "unable to be reached ... by bond / Failed to
                    # bring up" even though slam_toolbox stays Active and
                    # publishes a valid /map. bond_timeout=0.0 disables bond
                    # monitoring so bringup is deterministic and the log is not
                    # polluted with false failures.
                    "bond_timeout": 0.0,
                }
            ],
        ),
        Node(
            package="ros2_mapper",
            executable="ros2_mapper_node",
            name="ros2_mapper",
            output="screen",
            emulate_tty=True,
            parameters=[
                mapper_config,
                {
                    "use_sim_time": use_sim_time,
                    "use_area4_all": use_area4_all,
                    "auto_start": ParameterValue(auto_start, value_type=bool),
                    "race_wait_for_bridge_ready": ParameterValue(
                        race_wait_for_bridge_ready,
                        value_type=bool,
                    ),
                },
                *runtime_params,
            ],
        ),
    ]


def generate_launch_description():
    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "mapper_mode",
                default_value="semantic",
                description="Deprecated compatibility argument; unified mapper always starts SLAM + semantic node.",
            ),
            DeclareLaunchArgument(
                "use_sim_time",
                default_value="false",
                description="Use simulation clock.",
            ),
            DeclareLaunchArgument(
                "use_area4_all",
                default_value="false",
                description="Apply Area 4 geometry mode hook to all tile areas.",
            ),
            DeclareLaunchArgument(
                "auto_start",
                default_value="false",
                description="Allow ros2_mapper to initialize and integrate the semantic TileMap.",
            ),
            DeclareLaunchArgument(
                "race_wait_for_bridge_ready",
                default_value="false",
                description="Gate semantic mapping until /ros2_bridge/ready reports real sensors.",
            ),
            DeclareLaunchArgument(
                "runtime_params_file",
                default_value="",
                description="Optional runtime YAML override loaded last (timing/use_sim_time).",
            ),
            OpaqueFunction(function=launch_setup),
        ]
    )
