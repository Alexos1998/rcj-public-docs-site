// Standalone test: full C++ target decode (RF mask -> radial rings -> sum/class)
// vs the Python-exported patterns. Build (no ROS needed):
//   g++ -std=c++17 -I include test/test_target_radial.cpp src/target_mask_rf.cpp \
//       src/target_radial_classifier.cpp $(pkg-config --cflags --libs opencv4) -o /tmp/test_target_radial
//   /tmp/test_target_radial <models_dir> <fixtures_dir>

#include <cstdio>
#include <fstream>
#include <string>
#include <vector>

#include <opencv2/imgcodecs.hpp>

#include "ros2_vision/target_mask_rf.hpp"
#include "ros2_vision/target_radial_classifier.hpp"

namespace {

std::vector<std::string> jsonStrings(const std::string& content, const std::string& key)
{
  std::vector<std::string> out;
  const std::string token = "\"" + key + "\":";
  std::size_t pos = 0;
  while ((pos = content.find(token, pos)) != std::string::npos) {
    const std::size_t q1 = content.find('"', pos + token.size());
    const std::size_t q2 = content.find('"', q1 + 1);
    if (q1 == std::string::npos || q2 == std::string::npos) {
      break;
    }
    out.push_back(content.substr(q1 + 1, q2 - q1 - 1));
    pos = q2 + 1;
  }
  return out;
}

}  // namespace

int main(int argc, char** argv)
{
  const std::string models_dir = argc > 1 ? argv[1] : "../../../models";
  const std::string fixtures_dir = argc > 2 ? argv[2] : "test/fixtures";

  ros2_vision::TargetMaskRF rf;
  if (!rf.load(models_dir + "/target_mask_rf.yml", models_dir + "/target_mask_features.yml")) {
    std::fprintf(stderr, "[FAIL] could not load target_mask_rf.yml\n");
    return 1;
  }

  std::ifstream in(fixtures_dir + "/expected.json");
  std::string content((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
  const auto images = jsonStrings(content, "image");
  const auto gts = jsonStrings(content, "gt_texture");
  const auto py = jsonStrings(content, "py_pattern");
  if (images.empty() || images.size() != py.size()) {
    std::fprintf(stderr, "[FAIL] bad fixtures json\n");
    return 1;
  }

  int passed = 0;
  int failed = 0;
  for (std::size_t i = 0; i < images.size(); ++i) {
    const cv::Mat bgr = cv::imread(fixtures_dir + "/" + images[i], cv::IMREAD_COLOR);
    if (bgr.empty()) {
      std::fprintf(stderr, "[FAIL] missing %s\n", images[i].c_str());
      ++failed;
      continue;
    }
    const cv::Mat mask = rf.predictMask(bgr);
    const ros2_vision::RadialTargetResult r = ros2_vision::decodeTargetFromMask(bgr, mask);

    const bool pattern_len = r.pattern.size() == 5;
    const bool matches_py = r.pattern == py[i];
    const bool class_ok = !r.class_name.empty() &&
                          std::string("FPCO").find(r.class_name) != std::string::npos;
    const bool ok = pattern_len && matches_py && (r.sum_valid ? class_ok : true);
    std::printf("[%s] %-22s C++=%s class=%-2s sum=%d cov=%.2f | py=%s gt=%s\n",
                ok ? "PASS" : "FAIL", images[i].c_str(), r.pattern.c_str(),
                r.class_name.empty() ? "-" : r.class_name.c_str(), r.sum_value,
                r.radial_coverage, py[i].c_str(), gts[i].c_str());
    ok ? ++passed : ++failed;
  }
  std::printf("\n%d/%d radial-decode checks passed\n", passed, passed + failed);
  return failed == 0 ? 0 : 1;
}
