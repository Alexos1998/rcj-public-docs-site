import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def _runtime_params_list(context):
    """Return [runtime_params_file] when it points at an existing file, else []."""
    path = LaunchConfiguration("runtime_params_file").perform(context)
    return [path] if path and os.path.exists(path) else []


def launch_setup(context, *args, **kwargs):
    del args, kwargs

    pkg_share = get_package_share_directory("ros2_bootstrap")
    params_file = os.path.join(pkg_share, "config", "bootstrap.yaml")

    bootstrap_yaw = LaunchConfiguration("bootstrap_yaw")
    use_sim_time = LaunchConfiguration("use_sim_time")

    # Runtime override file is appended LAST so it wins over the base YAML.
    parameters = [
        params_file,
        {
            "bootstrap_yaw": ParameterValue(bootstrap_yaw, value_type=float),
            "use_sim_time": ParameterValue(use_sim_time, value_type=bool),
        },
        *_runtime_params_list(context),
    ]

    return [
        Node(
            package="ros2_bootstrap",
            executable="race_bootstrap",
            name="race_bootstrap",
            output="screen",
            parameters=parameters,
        ),
    ]


def generate_launch_description():
    default_yaw = os.environ.get("RACE_BOOTSTRAP_YAW", "0.0")

    return LaunchDescription([
        DeclareLaunchArgument(
            "bootstrap_yaw",
            default_value=default_yaw,
            description="Yaw used by dummy IMU before the real Webots controller handoff.",
        ),
        DeclareLaunchArgument(
            "use_sim_time",
            default_value="false",
            description="Use simulation clock.",
        ),
        DeclareLaunchArgument(
            "runtime_params_file",
            default_value="",
            description="Optional runtime YAML override loaded last (timing/use_sim_time).",
        ),
        OpaqueFunction(function=launch_setup),
    ])
