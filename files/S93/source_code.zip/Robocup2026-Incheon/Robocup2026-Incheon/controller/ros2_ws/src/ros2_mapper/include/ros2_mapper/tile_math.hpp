#ifndef ROS2_MAPPER__TILE_MATH_HPP_
#define ROS2_MAPPER__TILE_MATH_HPP_

#include <geometry_msgs/msg/point.hpp>

#include <cstddef>
#include <vector>

namespace ros2_mapper
{

struct TileCoord
{
  int x;
  int y;
};

bool operator==(const TileCoord & lhs, const TileCoord & rhs);

struct TileCoordHash
{
  std::size_t operator()(const TileCoord & coord) const;
};

TileCoord computeTileCoord(
  double x,
  double y,
  double origin_x,
  double origin_y,
  double tile_size);

geometry_msgs::msg::Point tileCenter(
  TileCoord coord,
  double origin_x,
  double origin_y,
  double tile_size);

std::vector<TileCoord> adjacentTileCoordsNearBoundary(
  TileCoord coord,
  double x,
  double y,
  double origin_x,
  double origin_y,
  double tile_size,
  double boundary_margin);

bool areOppositeTileNeighbors(
  TileCoord center,
  TileCoord entry,
  TileCoord exit);

}  // namespace ros2_mapper

#endif  // ROS2_MAPPER__TILE_MATH_HPP_
