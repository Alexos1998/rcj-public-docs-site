#include "ros2_exploration/nav2_goal_manager.hpp"

#include <utility>

namespace ros2_exploration
{

Nav2GoalManager::Nav2GoalManager(rclcpp::Node * node, std::string action_name)
: action_name_(std::move(action_name))
{
  client_ = rclcpp_action::create_client<NavigateToPose>(node, action_name_);
}

bool Nav2GoalManager::actionServerReady(std::chrono::milliseconds timeout) const
{
  return client_ && client_->wait_for_action_server(timeout);
}

void Nav2GoalManager::sendGoal(
  const geometry_msgs::msg::PoseStamped & pose,
  GoalResponseCallback goal_response_callback,
  ResultCallback result_callback)
{
  {
    std::lock_guard<std::mutex> lock(mutex_);
    active_goal_handle_.reset();
  }

  NavigateToPose::Goal goal;
  goal.pose = pose;

  NavigateToPoseClient::SendGoalOptions options;
  options.goal_response_callback =
    [this, callback = std::move(goal_response_callback)](GoalHandle::SharedPtr goal_handle) {
      {
        std::lock_guard<std::mutex> lock(mutex_);
        active_goal_handle_ = goal_handle;
      }
      callback(goal_handle);
    };
  options.result_callback =
    [callback = std::move(result_callback)](const GoalHandle::WrappedResult & result) {
      callback(result);
    };

  client_->async_send_goal(goal, options);
}

bool Nav2GoalManager::cancelActiveGoal()
{
  GoalHandle::SharedPtr goal_handle;
  {
    std::lock_guard<std::mutex> lock(mutex_);
    goal_handle = active_goal_handle_;
  }

  if (!client_ || !goal_handle) {
    return false;
  }

  client_->async_cancel_goal(goal_handle);
  return true;
}

const std::string & Nav2GoalManager::actionName() const
{
  return action_name_;
}

}  // namespace ros2_exploration
