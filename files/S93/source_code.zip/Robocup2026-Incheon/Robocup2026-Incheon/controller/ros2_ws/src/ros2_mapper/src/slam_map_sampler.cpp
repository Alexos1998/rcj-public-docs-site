#include "ros2_mapper/slam_map_sampler.hpp"

#include <algorithm>
#include <cmath>
#include <functional>
#include <queue>
#include <limits>
#include <utility>
#include <vector>

namespace ros2_mapper
{

namespace
{

constexpr double kHalfPi = 1.57079632679489661923;

double yawFromQuaternion(const geometry_msgs::msg::Quaternion & q)
{
  const double siny_cosp = 2.0 * (q.w * q.z + q.x * q.y);
  const double cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z);
  return std::atan2(siny_cosp, cosy_cosp);
}

bool finitePositive(double value)
{
  return std::isfinite(value) && value > 0.0;
}

}  // namespace

const char * slamGeometryStateToString(SlamGeometryState state)
{
  switch (state) {
    case SlamGeometryState::Unknown:
      return "unknown";
    case SlamGeometryState::LikelyOpen:
      return "likely_open";
    case SlamGeometryState::ConfirmedOpen:
      return "confirmed_open";
    case SlamGeometryState::LikelyWall:
      return "likely_wall";
    case SlamGeometryState::ConfirmedWall:
      return "confirmed_wall";
    case SlamGeometryState::Conflicted:
      return "conflicted";
  }

  return "unknown";
}

void SlamMapSampler::configure(const SlamMapSamplerConfig & config)
{
  config_ = config;
  if (has_received_map_) {
    analyzeMap();
  }
}

const SlamMapSamplerConfig & SlamMapSampler::config() const
{
  return config_;
}

void SlamMapSampler::reset()
{
  map_ = nav_msgs::msg::OccupancyGrid{};
  received_at_ = rclcpp::Time{};
  has_received_map_ = false;
  has_structurally_valid_map_ = false;
  static_map_real_ = false;
  rejection_reason_ = "no_map";
  clearance_m_.clear();
  clearance_valid_ = false;
  total_cells_ = 0;
  known_cells_ = 0;
  free_cells_ = 0;
  occupied_cells_ = 0;
  unknown_cells_ = 0;
}

void SlamMapSampler::updateMap(
  const nav_msgs::msg::OccupancyGrid & map,
  const rclcpp::Time & received_at)
{
  map_ = map;
  received_at_ = received_at;
  has_received_map_ = true;
  analyzeMap();
}

SlamMapStatus SlamMapSampler::status(const rclcpp::Time & now) const
{
  SlamMapStatus status;
  status.enabled = config_.enabled;
  status.map_available = has_structurally_valid_map_;
  status.map_recent = mapRecent(now, &status.age_sec);
  status.map_real = config_.enabled && static_map_real_ && status.map_recent;
  status.rejection_reason = status.map_real ? "none" : rejection_reason_;

  if (has_structurally_valid_map_) {
    status.width = map_.info.width;
    status.height = map_.info.height;
    status.resolution = static_cast<double>(map_.info.resolution);
    status.frame_id = map_.header.frame_id;
  }

  status.total_cells = total_cells_;
  status.known_cells = known_cells_;
  status.free_cells = free_cells_;
  status.occupied_cells = occupied_cells_;
  status.unknown_cells = unknown_cells_;

  const double total = static_cast<double>(std::max(total_cells_, 1));
  status.known_ratio = static_cast<double>(known_cells_) / total;
  status.free_ratio = static_cast<double>(free_cells_) / total;
  status.occupied_ratio = static_cast<double>(occupied_cells_) / total;
  status.unknown_ratio = static_cast<double>(unknown_cells_) / total;

  if (!config_.enabled) {
    status.map_real = false;
    status.rejection_reason = "disabled";
  } else if (static_map_real_ && !status.map_recent) {
    status.rejection_reason = "stale";
  }

  return status;
}

bool SlamMapSampler::hasSampleableMap(const rclcpp::Time & now) const
{
  const auto current_status = status(now);
  return current_status.map_available && current_status.map_real;
}

SlamGeometryState SlamMapSampler::classifyRegion(const SlamRegionStats & stats) const
{
  if (
    !stats.map_real ||
    !stats.map_recent ||
    stats.sample_count < config_.min_region_samples)
  {
    return SlamGeometryState::Unknown;
  }

  if (
    stats.occupied_ratio >= config_.likely_wall_occupied_ratio &&
    stats.free_ratio >= config_.likely_open_free_ratio)
  {
    return SlamGeometryState::Conflicted;
  }

  if (stats.occupied_ratio >= config_.confirmed_wall_occupied_ratio) {
    return SlamGeometryState::ConfirmedWall;
  }

  const bool clearance_blocks_confirmed_open =
    stats.clearance_available &&
    stats.clearance_sample_count > 0 &&
    stats.clearance_min_m < config_.clearance_min_passage_clearance_m;

  if (
    stats.free_ratio >= config_.confirmed_open_free_ratio &&
    stats.occupied_ratio <= config_.max_open_occupied_ratio &&
    stats.unknown_ratio <= config_.max_confirmed_open_unknown_ratio &&
    !clearance_blocks_confirmed_open)
  {
    return SlamGeometryState::ConfirmedOpen;
  }

  if (stats.occupied_ratio >= config_.likely_wall_occupied_ratio) {
    return SlamGeometryState::LikelyWall;
  }

  if (
    stats.free_ratio >= config_.likely_open_free_ratio &&
    stats.occupied_ratio <= config_.max_open_occupied_ratio)
  {
    return SlamGeometryState::LikelyOpen;
  }

  return SlamGeometryState::Unknown;
}

SlamRegionStats SlamMapSampler::sampleAxisAlignedBox(
  double center_x,
  double center_y,
  double size_x_m,
  double size_y_m,
  const rclcpp::Time & now,
  const geometry_msgs::msg::TransformStamped * region_to_map) const
{
  SlamRectRegion region;
  region.center_x = center_x;
  region.center_y = center_y;
  region.yaw_rad = 0.0;
  region.length_m = size_x_m;
  region.width_m = size_y_m;
  return sampleOrientedBox(region, now, region_to_map);
}

SlamRegionStats SlamMapSampler::sampleOrientedBox(
  const SlamRectRegion & region,
  const rclcpp::Time & now,
  const geometry_msgs::msg::TransformStamped * region_to_map) const
{
  auto stats = unavailableStats(now);
  if (!stats.map_real || !finitePositive(region.length_m) || !finitePositive(region.width_m)) {
    return stats;
  }

  const double resolution = static_cast<double>(map_.info.resolution);
  const int samples_x = std::max(1, static_cast<int>(std::ceil(region.length_m / resolution)));
  const int samples_y = std::max(1, static_cast<int>(std::ceil(region.width_m / resolution)));
  const double cos_yaw = std::cos(region.yaw_rad);
  const double sin_yaw = std::sin(region.yaw_rad);
  const bool clearance_sampleable =
    config_.clearance_enabled && clearance_valid_ && clearanceRecent(now);
  stats.clearance_available = clearance_sampleable;
  stats.clearance_threshold_m = config_.clearance_min_passage_clearance_m;

  for (int iy = 0; iy < samples_y; ++iy) {
    const double local_y =
      -0.5 * region.width_m +
      (static_cast<double>(iy) + 0.5) * region.width_m / static_cast<double>(samples_y);
    for (int ix = 0; ix < samples_x; ++ix) {
      const double local_x =
        -0.5 * region.length_m +
        (static_cast<double>(ix) + 0.5) * region.length_m / static_cast<double>(samples_x);
      const double region_x = region.center_x + cos_yaw * local_x - sin_yaw * local_y;
      const double region_y = region.center_y + sin_yaw * local_x + cos_yaw * local_y;

      double map_x = region_x;
      double map_y = region_y;
      applyTransform(region_x, region_y, region_to_map, &map_x, &map_y);

      int cell_x = 0;
      int cell_y = 0;
      if (!worldToCell(map_x, map_y, &cell_x, &cell_y)) {
        stats.out_of_bounds_count += 1;
        continue;
      }

      const auto width = static_cast<int>(map_.info.width);
      const auto index = static_cast<std::size_t>(cell_y * width + cell_x);
      if (index >= map_.data.size()) {
        stats.out_of_bounds_count += 1;
        continue;
      }

      const int value = static_cast<int>(map_.data[index]);
      stats.sample_count += 1;
      if (value < 0) {
        stats.unknown_count += 1;
      } else if (value <= config_.free_threshold) {
        stats.free_count += 1;
      } else if (value >= config_.occupied_threshold) {
        stats.occupied_count += 1;
      }

      if (clearance_sampleable && index < clearance_m_.size()) {
        const double clearance = clearance_m_[index];
        if (std::isfinite(clearance)) {
          if (stats.clearance_sample_count == 0) {
            stats.clearance_min_m = clearance;
          } else {
            stats.clearance_min_m = std::min(stats.clearance_min_m, clearance);
          }
          stats.clearance_sum_m += clearance;
          stats.clearance_sample_count += 1;
          if (clearance >= config_.clearance_min_passage_clearance_m) {
            stats.clearance_ok_count += 1;
          }
        }
      }
    }
  }

  finalizeStats(&stats);
  return stats;
}

SlamRegionStats SlamMapSampler::sampleCorridor(
  double start_x,
  double start_y,
  double end_x,
  double end_y,
  double width_m,
  const rclcpp::Time & now,
  const geometry_msgs::msg::TransformStamped * region_to_map) const
{
  const double dx = end_x - start_x;
  const double dy = end_y - start_y;
  const double length = std::hypot(dx, dy);
  SlamRectRegion region;
  region.center_x = 0.5 * (start_x + end_x);
  region.center_y = 0.5 * (start_y + end_y);
  region.yaw_rad = std::atan2(dy, dx);
  region.length_m = length;
  region.width_m = width_m;
  return sampleOrientedBox(region, now, region_to_map);
}

SlamRegionStats SlamMapSampler::sampleEdgeStrip(
  double tile_center_x,
  double tile_center_y,
  double tile_size_m,
  SlamCardinalDirection direction,
  double strip_length_m,
  double strip_width_m,
  const rclcpp::Time & now,
  const geometry_msgs::msg::TransformStamped * region_to_map) const
{
  SlamRectRegion region;
  region.center_x = tile_center_x;
  region.center_y = tile_center_y;
  region.length_m = strip_length_m;
  region.width_m = strip_width_m;

  const double half_tile = 0.5 * tile_size_m;
  switch (direction) {
    case SlamCardinalDirection::North:
      region.center_y += half_tile;
      region.yaw_rad = 0.0;
      break;
    case SlamCardinalDirection::South:
      region.center_y -= half_tile;
      region.yaw_rad = 0.0;
      break;
    case SlamCardinalDirection::East:
      region.center_x += half_tile;
      region.yaw_rad = kHalfPi;
      break;
    case SlamCardinalDirection::West:
      region.center_x -= half_tile;
      region.yaw_rad = kHalfPi;
      break;
  }

  return sampleOrientedBox(region, now, region_to_map);
}

void SlamMapSampler::analyzeMap()
{
  has_structurally_valid_map_ = false;
  static_map_real_ = false;
  rejection_reason_ = "invalid";
  clearance_m_.clear();
  clearance_valid_ = false;
  total_cells_ = 0;
  known_cells_ = 0;
  free_cells_ = 0;
  occupied_cells_ = 0;
  unknown_cells_ = 0;

  if (!config_.enabled) {
    rejection_reason_ = "disabled";
    return;
  }

  if (map_.info.width == 0U) {
    rejection_reason_ = "zero_width";
    return;
  }
  if (map_.info.height == 0U) {
    rejection_reason_ = "zero_height";
    return;
  }
  if (!finitePositive(static_cast<double>(map_.info.resolution))) {
    rejection_reason_ = "invalid_resolution";
    return;
  }
  if (map_.header.frame_id.empty()) {
    rejection_reason_ = "empty_frame_id";
    return;
  }

  const auto expected_size =
    static_cast<std::size_t>(map_.info.width) * static_cast<std::size_t>(map_.info.height);
  if (map_.data.size() != expected_size) {
    rejection_reason_ = "data_size_mismatch";
    return;
  }

  has_structurally_valid_map_ = true;
  total_cells_ = static_cast<int>(expected_size);

  for (const auto raw_value : map_.data) {
    const int value = static_cast<int>(raw_value);
    if (value < 0) {
      unknown_cells_ += 1;
      continue;
    }

    known_cells_ += 1;
    if (value <= config_.free_threshold) {
      free_cells_ += 1;
    }
    if (value >= config_.occupied_threshold) {
      occupied_cells_ += 1;
    }
  }

  if (
    config_.resolution_tolerance_m >= 0.0 &&
    std::fabs(
      static_cast<double>(map_.info.resolution) - config_.expected_resolution_m) >
    config_.resolution_tolerance_m)
  {
    rejection_reason_ = "unexpected_resolution";
    return;
  }

  if (config_.reject_all_unknown_maps && unknown_cells_ == total_cells_) {
    rejection_reason_ = "all_unknown";
    return;
  }

  if (known_cells_ < config_.min_known_cells) {
    rejection_reason_ = "too_few_known_cells";
    return;
  }

  const double known_ratio =
    total_cells_ > 0 ? static_cast<double>(known_cells_) / static_cast<double>(total_cells_) : 0.0;
  if (known_ratio < config_.min_known_ratio) {
    rejection_reason_ = "known_ratio_too_low";
    return;
  }

  if (config_.reject_all_free_maps && unknown_cells_ == 0 && occupied_cells_ == 0) {
    rejection_reason_ = "all_free_or_no_occupied_cells";
    return;
  }

  if (occupied_cells_ < config_.min_occupied_cells) {
    rejection_reason_ = "too_few_occupied_cells";
    return;
  }

  static_map_real_ = true;
  rejection_reason_ = "none";
  rebuildClearanceField();
}

void SlamMapSampler::rebuildClearanceField()
{
  clearance_m_.clear();
  clearance_valid_ = false;
  if (!config_.clearance_enabled || !has_structurally_valid_map_ || !static_map_real_) {
    return;
  }

  const int width = static_cast<int>(map_.info.width);
  const int height = static_cast<int>(map_.info.height);
  const int cell_count = width * height;
  if (width <= 0 || height <= 0 || cell_count <= 0) {
    return;
  }

  const double resolution = static_cast<double>(map_.info.resolution);
  if (!finitePositive(resolution)) {
    return;
  }

  clearance_m_.assign(
    static_cast<std::size_t>(cell_count),
    std::numeric_limits<double>::infinity());
  using QueueEntry = std::pair<double, int>;
  std::priority_queue<QueueEntry, std::vector<QueueEntry>, std::greater<QueueEntry>> queue;

  for (int index = 0; index < cell_count; ++index) {
    const int value = static_cast<int>(map_.data[static_cast<std::size_t>(index)]);
    const bool occupied = value >= config_.clearance_occupied_threshold;
    const bool unknown_obstacle = value < 0 && config_.clearance_unknown_as_obstacle;
    if (!occupied && !unknown_obstacle) {
      continue;
    }
    clearance_m_[static_cast<std::size_t>(index)] = 0.0;
    queue.emplace(0.0, index);
  }

  if (queue.empty()) {
    clearance_m_.clear();
    return;
  }

  constexpr int kNeighborCount = 8;
  const int dx[kNeighborCount] = {1, -1, 0, 0, 1, 1, -1, -1};
  const int dy[kNeighborCount] = {0, 0, 1, -1, 1, -1, 1, -1};

  while (!queue.empty()) {
    const auto [distance, index] = queue.top();
    queue.pop();
    if (distance > clearance_m_[static_cast<std::size_t>(index)]) {
      continue;
    }

    const int x = index % width;
    const int y = index / width;
    for (int i = 0; i < kNeighborCount; ++i) {
      const int nx = x + dx[i];
      const int ny = y + dy[i];
      if (nx < 0 || ny < 0 || nx >= width || ny >= height) {
        continue;
      }

      const int neighbor_index = ny * width + nx;
      const double step = (dx[i] == 0 || dy[i] == 0) ? resolution : resolution * std::sqrt(2.0);
      const double candidate = distance + step;
      auto & stored = clearance_m_[static_cast<std::size_t>(neighbor_index)];
      if (candidate >= stored) {
        continue;
      }

      stored = candidate;
      queue.emplace(candidate, neighbor_index);
    }
  }

  clearance_valid_ = true;
}

bool SlamMapSampler::mapRecent(const rclcpp::Time & now, double * age_sec) const
{
  if (!has_received_map_) {
    if (age_sec != nullptr) {
      *age_sec = 0.0;
    }
    return false;
  }

  const double age = (now - received_at_).seconds();
  if (age_sec != nullptr) {
    *age_sec = age;
  }

  return age >= 0.0 && age <= config_.max_map_age_sec;
}

bool SlamMapSampler::clearanceRecent(const rclcpp::Time & now) const
{
  if (!has_received_map_) {
    return false;
  }
  const double age = (now - received_at_).seconds();
  return age >= 0.0 && age <= config_.clearance_stale_after_sec;
}

bool SlamMapSampler::worldToCell(double world_x, double world_y, int * cell_x, int * cell_y) const
{
  if (!has_structurally_valid_map_ || cell_x == nullptr || cell_y == nullptr) {
    return false;
  }

  const double dx = world_x - map_.info.origin.position.x;
  const double dy = world_y - map_.info.origin.position.y;
  const double yaw = yawFromQuaternion(map_.info.origin.orientation);
  const double cos_yaw = std::cos(yaw);
  const double sin_yaw = std::sin(yaw);
  const double grid_x = cos_yaw * dx + sin_yaw * dy;
  const double grid_y = -sin_yaw * dx + cos_yaw * dy;
  const double resolution = static_cast<double>(map_.info.resolution);

  if (!std::isfinite(grid_x) || !std::isfinite(grid_y) || !finitePositive(resolution)) {
    return false;
  }

  const int mx = static_cast<int>(std::floor(grid_x / resolution));
  const int my = static_cast<int>(std::floor(grid_y / resolution));
  if (
    mx < 0 || my < 0 ||
    mx >= static_cast<int>(map_.info.width) ||
    my >= static_cast<int>(map_.info.height))
  {
    return false;
  }

  *cell_x = mx;
  *cell_y = my;
  return true;
}

void SlamMapSampler::applyTransform(
  double x,
  double y,
  const geometry_msgs::msg::TransformStamped * transform,
  double * transformed_x,
  double * transformed_y) const
{
  if (transformed_x == nullptr || transformed_y == nullptr) {
    return;
  }

  if (transform == nullptr) {
    *transformed_x = x;
    *transformed_y = y;
    return;
  }

  const double yaw = yawFromQuaternion(transform->transform.rotation);
  const double cos_yaw = std::cos(yaw);
  const double sin_yaw = std::sin(yaw);
  *transformed_x = transform->transform.translation.x + cos_yaw * x - sin_yaw * y;
  *transformed_y = transform->transform.translation.y + sin_yaw * x + cos_yaw * y;
}

SlamRegionStats SlamMapSampler::unavailableStats(const rclcpp::Time & now) const
{
  const auto current_status = status(now);
  SlamRegionStats stats;
  stats.map_available = current_status.map_available;
  stats.map_real = current_status.map_real;
  stats.map_recent = current_status.map_recent;
  return stats;
}

void SlamMapSampler::finalizeStats(SlamRegionStats * stats) const
{
  if (stats == nullptr || stats->sample_count <= 0) {
    return;
  }

  const double samples = static_cast<double>(stats->sample_count);
  stats->free_ratio = static_cast<double>(stats->free_count) / samples;
  stats->occupied_ratio = static_cast<double>(stats->occupied_count) / samples;
  stats->unknown_ratio = static_cast<double>(stats->unknown_count) / samples;
  const double known_ratio = 1.0 - stats->unknown_ratio;
  const double coverage_ratio =
    samples / std::max(samples + static_cast<double>(stats->out_of_bounds_count), 1.0);
  stats->confidence = std::clamp(known_ratio * coverage_ratio, 0.0, 1.0);

  if (stats->clearance_sample_count > 0) {
    const double clearance_samples = static_cast<double>(stats->clearance_sample_count);
    stats->clearance_mean_m = stats->clearance_sum_m / clearance_samples;
    stats->clearance_ratio_ok =
      static_cast<double>(stats->clearance_ok_count) / clearance_samples;
  } else {
    stats->clearance_available = false;
    stats->clearance_min_m = 0.0;
    stats->clearance_mean_m = 0.0;
    stats->clearance_ratio_ok = 0.0;
  }
}

}  // namespace ros2_mapper
