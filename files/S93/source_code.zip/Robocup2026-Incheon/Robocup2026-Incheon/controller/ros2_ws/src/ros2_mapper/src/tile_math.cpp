#include "ros2_mapper/tile_math.hpp"

#include <cstddef>
#include <cmath>
#include <functional>
#include <stdexcept>
#include <vector>

namespace ros2_mapper
{

namespace
{

void validateTileSize(double tile_size)
{
  if (tile_size <= 0.0) {
    throw std::invalid_argument("tile_size must be greater than zero");
  }
}

}  // namespace

bool operator==(const TileCoord & lhs, const TileCoord & rhs)
{
  return lhs.x == rhs.x && lhs.y == rhs.y;
}

std::size_t TileCoordHash::operator()(const TileCoord & coord) const
{
  const auto x_hash = std::hash<int>{}(coord.x);
  const auto y_hash = std::hash<int>{}(coord.y);
  return x_hash ^ (y_hash + 0x9e3779b9U + (x_hash << 6U) + (x_hash >> 2U));
}

TileCoord computeTileCoord(
  double x,
  double y,
  double origin_x,
  double origin_y,
  double tile_size)
{
  validateTileSize(tile_size);

  return TileCoord{
    static_cast<int>(std::lround((x - origin_x) / tile_size)),
    static_cast<int>(std::lround((y - origin_y) / tile_size)),
  };
}

geometry_msgs::msg::Point tileCenter(
  TileCoord coord,
  double origin_x,
  double origin_y,
  double tile_size)
{
  validateTileSize(tile_size);

  geometry_msgs::msg::Point point;
  point.x = origin_x + static_cast<double>(coord.x) * tile_size;
  point.y = origin_y + static_cast<double>(coord.y) * tile_size;
  point.z = 0.0;
  return point;
}

std::vector<TileCoord> adjacentTileCoordsNearBoundary(
  TileCoord coord,
  double x,
  double y,
  double origin_x,
  double origin_y,
  double tile_size,
  double boundary_margin)
{
  validateTileSize(tile_size);
  if (boundary_margin < 0.0 || boundary_margin > tile_size * 0.5) {
    throw std::invalid_argument(
            "boundary_margin must be in range [0, tile_size / 2]");
  }

  const auto center = tileCenter(coord, origin_x, origin_y, tile_size);
  const double local_x = x - center.x;
  const double local_y = y - center.y;
  const double half_tile = tile_size * 0.5;

  std::vector<TileCoord> neighbors;
  neighbors.reserve(2);

  if (half_tile - std::fabs(local_x) <= boundary_margin) {
    neighbors.push_back(TileCoord{coord.x + (local_x >= 0.0 ? 1 : -1), coord.y});
  }
  if (half_tile - std::fabs(local_y) <= boundary_margin) {
    neighbors.push_back(TileCoord{coord.x, coord.y + (local_y >= 0.0 ? 1 : -1)});
  }

  return neighbors;
}

bool areOppositeTileNeighbors(
  TileCoord center,
  TileCoord entry,
  TileCoord exit)
{
  const int entry_dx = entry.x - center.x;
  const int entry_dy = entry.y - center.y;
  const int exit_dx = exit.x - center.x;
  const int exit_dy = exit.y - center.y;

  const bool entry_is_cardinal_neighbor =
    std::abs(entry_dx) + std::abs(entry_dy) == 1;
  const bool exit_is_cardinal_neighbor =
    std::abs(exit_dx) + std::abs(exit_dy) == 1;

  return
    entry_is_cardinal_neighbor &&
    exit_is_cardinal_neighbor &&
    exit_dx == -entry_dx &&
    exit_dy == -entry_dy;
}

}  // namespace ros2_mapper
