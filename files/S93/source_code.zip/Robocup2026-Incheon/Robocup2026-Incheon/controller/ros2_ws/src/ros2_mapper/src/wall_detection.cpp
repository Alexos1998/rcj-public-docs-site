#include "ros2_mapper/wall_detection.hpp"

#include <visualization_msgs/msg/marker.hpp>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <functional>
#include <limits>
#include <unordered_map>

namespace ros2_mapper
{

namespace
{

constexpr double kPi = 3.14159265358979323846;

int positiveMarkerId(const WallSegmentKey & key)
{
  return static_cast<int>(WallSegmentKeyHash{}(key) & 0x7fffffffu);
}

double tileCenterCoordinate(double origin, int tile_index, double tile_size)
{
  return origin + static_cast<double>(tile_index) * tile_size;
}

double boundaryCoordinate(double origin, int edge_index, double tile_size)
{
  return origin + (static_cast<double>(edge_index) - 0.5) * tile_size;
}

int binsPerSegment(const WallDetectionConfig & config)
{
  const int rounded = static_cast<int>(
    std::lround(config.segment_length_m / config.support_bin_size_m));
  return std::clamp(rounded, 1, 8);
}

int popcount8(uint8_t value)
{
  int count = 0;
  while (value != 0u) {
    count += static_cast<int>(value & 1u);
    value = static_cast<uint8_t>(value >> 1u);
  }
  return count;
}

uint16_t incrementSaturating(uint16_t value)
{
  if (value == std::numeric_limits<uint16_t>::max()) {
    return value;
  }
  return static_cast<uint16_t>(value + 1u);
}

}  // namespace

bool WallSegmentKey::operator==(const WallSegmentKey & other) const noexcept
{
  return shape == other.shape &&
    axis == other.axis &&
    edge_i == other.edge_i &&
    edge_j == other.edge_j &&
    sub == other.sub &&
    aux == other.aux;
}

std::size_t WallSegmentKeyHash::operator()(const WallSegmentKey & key) const noexcept
{
  std::size_t seed = 0x9e3779b97f4a7c15ull;

  const auto mix = [&seed](std::size_t value) {
      seed ^= value + 0x9e3779b97f4a7c15ull + (seed << 6u) + (seed >> 2u);
    };

  mix(static_cast<std::size_t>(key.shape));
  mix(static_cast<std::size_t>(key.axis));
  mix(std::hash<int>{}(key.edge_i));
  mix(std::hash<int>{}(key.edge_j));
  mix(static_cast<std::size_t>(key.sub));
  mix(static_cast<std::size_t>(key.aux));

  return seed;
}

WallDetection::WallDetection(WallDetectionConfig config)
: config_(config)
{
}

void WallDetection::setConfig(WallDetectionConfig config)
{
  config_ = config;
}

void WallDetection::reset()
{
  evidence_.clear();
  has_last_integrated_pose_ = false;
  last_integrated_pose_ = Pose2D{};
}

const WallEvidenceMap & WallDetection::evidence() const noexcept
{
  return evidence_;
}

void WallDetection::integrateScan(
  const sensor_msgs::msg::LaserScan & scan,
  const Pose2D & sensor_pose_odom,
  const rclcpp::Time & stamp)
{
  if (has_last_integrated_pose_) {
    const double dx = sensor_pose_odom.x - last_integrated_pose_.x;
    const double dy = sensor_pose_odom.y - last_integrated_pose_.y;
    const double dp = std::hypot(dx, dy);
    const double dyaw = std::fabs(
      normalizeAngle(sensor_pose_odom.yaw - last_integrated_pose_.yaw));

    if (dp < config_.min_pose_delta_m && dyaw < config_.min_pose_delta_yaw_rad) {
      return;
    }
  }

  std::unordered_map<WallSegmentKey, SegmentScanStats, WallSegmentKeyHash> scan_stats;

  const double c = std::cos(sensor_pose_odom.yaw);
  const double s = std::sin(sensor_pose_odom.yaw);
  const int bin_count = binsPerSegment(config_);

  for (std::size_t i = 0; i < scan.ranges.size(); ++i) {
    const double range = scan.ranges[i];
    if (!std::isfinite(range) || range <= 0.0) {
      continue;
    }
    if (scan.range_min > 0.0f && range < static_cast<double>(scan.range_min)) {
      continue;
    }
    if (scan.range_max > 0.0f && range > static_cast<double>(scan.range_max)) {
      continue;
    }

    const double angle = static_cast<double>(scan.angle_min) +
      static_cast<double>(i) * static_cast<double>(scan.angle_increment);
    const double local_x = range * std::cos(angle);
    const double local_y = range * std::sin(angle);

    const double world_x = sensor_pose_odom.x + c * local_x - s * local_y;
    const double world_y = sensor_pose_odom.y + s * local_x + c * local_y;

    SegmentProjection best_projection;

    for (const auto & candidate :
      enumerateCandidateSegmentsAroundPoint(
        world_x,
        world_y,
        config_.candidate_tile_radius))
    {
      const auto endpoints = segmentEndpoints(candidate);
      const double ux = endpoints.bx - endpoints.ax;
      const double uy = endpoints.by - endpoints.ay;
      const double len2 = ux * ux + uy * uy;
      if (len2 <= 0.0) {
        continue;
      }

      const double px = world_x - endpoints.ax;
      const double py = world_y - endpoints.ay;
      const double t = (px * ux + py * uy) / len2;
      if (t < 0.0 || t > 1.0) {
        continue;
      }

      const double projected_x = endpoints.ax + t * ux;
      const double projected_y = endpoints.ay + t * uy;
      const double distance = std::hypot(world_x - projected_x, world_y - projected_y);
      if (distance > config_.snap_perp_tolerance_m) {
        continue;
      }

      const double segment_length = std::sqrt(len2);
      const double along = t * segment_length;
      if (
        along < config_.endpoint_guard_m ||
        along > segment_length - config_.endpoint_guard_m)
      {
        continue;
      }

      int bin = static_cast<int>(std::floor(t * static_cast<double>(bin_count)));
      bin = std::clamp(bin, 0, bin_count - 1);
      const uint8_t bin_mask = static_cast<uint8_t>(1u << bin);

      if (!best_projection.accepted || distance < best_projection.distance_m) {
        best_projection.key = candidate;
        best_projection.t = t;
        best_projection.distance_m = distance;
        best_projection.bin_mask = bin_mask;
        best_projection.accepted = true;
      }
    }

    if (!best_projection.accepted) {
      continue;
    }

    auto & stats = scan_stats[best_projection.key];
    stats.hit_errors.push_back(best_projection.distance_m);
    stats.hit_bin_mask = static_cast<uint8_t>(stats.hit_bin_mask | best_projection.bin_mask);
  }

  for (auto & entry : scan_stats) {
    auto & stats = entry.second;
    if (static_cast<int>(stats.hit_errors.size()) < config_.hit_min_points_per_scan) {
      continue;
    }

    const double percentile_error = percentile(stats.hit_errors, config_.hit_error_percentile);
    if (!std::isfinite(percentile_error)) {
      continue;
    }

    const double coverage =
      static_cast<double>(popcount8(stats.hit_bin_mask)) / static_cast<double>(bin_count);
    const double quality =
      std::max(0.0, 1.0 - percentile_error / config_.snap_perp_tolerance_m) * coverage;

    if (quality <= 0.0) {
      continue;
    }

    auto & evidence = evidence_[entry.first];
    if (evidence.occ_supports == 0u && evidence.free_supports == 0u) {
      evidence.first_seen = stamp;
    }

    evidence.last_seen = stamp;
    evidence.log_odds = static_cast<float>(
      std::clamp(
        static_cast<double>(evidence.log_odds) + config_.hit_logodds_inc * quality,
        config_.logodds_min,
        config_.logodds_max));
    evidence.hit_bin_mask = static_cast<uint8_t>(evidence.hit_bin_mask | stats.hit_bin_mask);
    evidence.occ_supports = incrementSaturating(evidence.occ_supports);
    evidence.best_p25_error_m = std::min(
      evidence.best_p25_error_m,
      static_cast<float>(percentile_error));
    evidence.phantom_occ = evidence.log_odds >= config_.phantom_occ_threshold;
    evidence.confirmed_occ = false;
  }

  last_integrated_pose_ = sensor_pose_odom;
  has_last_integrated_pose_ = true;
}

std::vector<WallSegmentKey> WallDetection::enumerateTileSegments(
  int tile_x,
  int tile_y) const
{
  std::vector<WallSegmentKey> segments;
  segments.reserve(8);

  for (uint8_t sub = 0; sub < 2; ++sub) {
    segments.push_back(
      WallSegmentKey{
        WallShape::Straight,
        WallAxis::Horizontal,
        tile_x,
        tile_y + 1,
        sub,
        0u,
      });
    segments.push_back(
      WallSegmentKey{
        WallShape::Straight,
        WallAxis::Horizontal,
        tile_x,
        tile_y,
        sub,
        0u,
      });
    segments.push_back(
      WallSegmentKey{
        WallShape::Straight,
        WallAxis::Vertical,
        tile_x + 1,
        tile_y,
        sub,
        0u,
      });
    segments.push_back(
      WallSegmentKey{
        WallShape::Straight,
        WallAxis::Vertical,
        tile_x,
        tile_y,
        sub,
        0u,
      });
  }

  return segments;
}

std::vector<WallSegmentKey> WallDetection::enumerateCandidateSegmentsAroundPoint(
  double x,
  double y,
  int tile_radius) const
{
  const int center_tile_x = static_cast<int>(
    std::lround((x - config_.origin_x) / config_.tile_size_m));
  const int center_tile_y = static_cast<int>(
    std::lround((y - config_.origin_y) / config_.tile_size_m));
  const int radius = std::max(tile_radius, 0);

  std::unordered_map<WallSegmentKey, bool, WallSegmentKeyHash> seen;

  for (int tile_y = center_tile_y - radius; tile_y <= center_tile_y + radius; ++tile_y) {
    for (int tile_x = center_tile_x - radius; tile_x <= center_tile_x + radius; ++tile_x) {
      for (const auto & segment : enumerateTileSegments(tile_x, tile_y)) {
        seen.emplace(segment, true);
      }
    }
  }

  std::vector<WallSegmentKey> segments;
  segments.reserve(seen.size());
  for (const auto & entry : seen) {
    segments.push_back(entry.first);
  }

  std::sort(
    segments.begin(),
    segments.end(),
    [](const WallSegmentKey & a, const WallSegmentKey & b) {
      if (a.shape != b.shape) {
        return static_cast<uint8_t>(a.shape) < static_cast<uint8_t>(b.shape);
      }
      if (a.axis != b.axis) {
        return static_cast<uint8_t>(a.axis) < static_cast<uint8_t>(b.axis);
      }
      if (a.edge_i != b.edge_i) {
        return a.edge_i < b.edge_i;
      }
      if (a.edge_j != b.edge_j) {
        return a.edge_j < b.edge_j;
      }
      if (a.sub != b.sub) {
        return a.sub < b.sub;
      }
      return a.aux < b.aux;
    });

  return segments;
}

SegmentEndpoints WallDetection::segmentEndpoints(const WallSegmentKey & key) const
{
  SegmentEndpoints endpoints;

  if (key.axis == WallAxis::Horizontal) {
    const double west_x =
      tileCenterCoordinate(config_.origin_x, key.edge_i, config_.tile_size_m) -
      config_.tile_size_m * 0.5;
    const double y = boundaryCoordinate(config_.origin_y, key.edge_j, config_.tile_size_m);
    const double ax = west_x + static_cast<double>(key.sub) * config_.segment_length_m;

    endpoints.ax = ax;
    endpoints.ay = y;
    endpoints.bx = ax + config_.segment_length_m;
    endpoints.by = y;
    return endpoints;
  }

  const double south_y =
    tileCenterCoordinate(config_.origin_y, key.edge_j, config_.tile_size_m) -
    config_.tile_size_m * 0.5;
  const double x = boundaryCoordinate(config_.origin_x, key.edge_i, config_.tile_size_m);
  const double ay = south_y + static_cast<double>(key.sub) * config_.segment_length_m;

  endpoints.ax = x;
  endpoints.ay = ay;
  endpoints.bx = x;
  endpoints.by = ay + config_.segment_length_m;
  return endpoints;
}

visualization_msgs::msg::MarkerArray WallDetection::buildPhantomMarkers(
  const std::string & frame_id,
  const rclcpp::Time & stamp) const
{
  visualization_msgs::msg::MarkerArray markers;

  for (const auto & entry : evidence_) {
    const auto & key = entry.first;
    const auto & evidence = entry.second;

    if (!evidence.phantom_occ && !evidence.confirmed_occ) {
      continue;
    }

    const auto endpoints = segmentEndpoints(key);

    visualization_msgs::msg::Marker marker;
    marker.header.frame_id = frame_id;
    marker.header.stamp = stamp;
    marker.ns = "phantom_walls";
    marker.id = positiveMarkerId(key);
    marker.type = visualization_msgs::msg::Marker::CUBE;
    marker.action = visualization_msgs::msg::Marker::ADD;
    marker.pose.position.x = (endpoints.ax + endpoints.bx) * 0.5;
    marker.pose.position.y = (endpoints.ay + endpoints.by) * 0.5;
    marker.pose.position.z = config_.phantom_marker_z;
    marker.pose.orientation.w = 1.0;

    if (key.axis == WallAxis::Horizontal) {
      marker.scale.x = config_.segment_length_m;
      marker.scale.y = config_.phantom_marker_thickness;
    } else {
      marker.scale.x = config_.phantom_marker_thickness;
      marker.scale.y = config_.segment_length_m;
    }
    marker.scale.z = config_.phantom_marker_thickness;

    if (evidence.confirmed_occ) {
      marker.color.r = 0.0f;
      marker.color.g = 0.85f;
      marker.color.b = 1.0f;
      marker.color.a = 0.95f;
    } else {
      marker.color.r = 1.0f;
      marker.color.g = 0.55f;
      marker.color.b = 0.05f;
      marker.color.a = static_cast<float>(config_.phantom_marker_alpha);
    }

    markers.markers.push_back(marker);
  }

  return markers;
}

double WallDetection::normalizeAngle(double angle)
{
  while (angle > kPi) {
    angle -= 2.0 * kPi;
  }
  while (angle < -kPi) {
    angle += 2.0 * kPi;
  }
  return angle;
}

double WallDetection::percentile(std::vector<double> values, double p)
{
  if (values.empty()) {
    return std::numeric_limits<double>::infinity();
  }

  std::sort(values.begin(), values.end());

  const double clamped_p = std::clamp(p, 0.0, 1.0);
  const auto index = static_cast<std::size_t>(
    std::floor(clamped_p * static_cast<double>(values.size() - 1)));
  return values[index];
}

}  // namespace ros2_mapper
