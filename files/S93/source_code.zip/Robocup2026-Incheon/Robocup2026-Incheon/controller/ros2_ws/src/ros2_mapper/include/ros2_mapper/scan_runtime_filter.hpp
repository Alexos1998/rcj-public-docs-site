#ifndef ROS2_MAPPER__SCAN_RUNTIME_FILTER_HPP_
#define ROS2_MAPPER__SCAN_RUNTIME_FILTER_HPP_

#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <std_msgs/msg/string.hpp>
#include <mutex>

namespace ros2_mapper
{

class ScanRuntimeFilter : public rclcpp::Node
{
public:
  explicit ScanRuntimeFilter(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  void scanCallback(const sensor_msgs::msg::LaserScan::SharedPtr msg);
  void readyCallback(const std_msgs::msg::String::SharedPtr msg);
  void logRobotEvent(const std::string & event, const std::vector<std::pair<std::string, std::string>> & fields = {}) const;

  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr scan_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr ready_sub_;
  rclcpp::Publisher<sensor_msgs::msg::LaserScan>::SharedPtr scan_pub_;

  mutable std::mutex mutex_;
  bool ready_ {false};
  uint64_t connection_id_ {0};
  uint64_t dropped_count_ {0};
  bool first_scan_logged_ {false};
};

}  // namespace ros2_mapper

#endif  // ROS2_MAPPER__SCAN_RUNTIME_FILTER_HPP_
