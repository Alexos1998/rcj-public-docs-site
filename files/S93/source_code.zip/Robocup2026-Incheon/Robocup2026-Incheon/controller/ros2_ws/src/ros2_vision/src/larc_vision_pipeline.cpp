#include "ros2_vision/larc_vision_pipeline.hpp"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iterator>
#include <sstream>
#include <tuple>
#include <utility>

namespace ros2_vision {
namespace {

constexpr double kPi = 3.14159265358979323846;

double wrapPi(double angle)
{
  while (angle > kPi) {
    angle -= 2.0 * kPi;
  }
  while (angle < -kPi) {
    angle += 2.0 * kPi;
  }
  return angle;
}

float sigmoid(float x)
{
  return 1.0f / (1.0f + std::exp(-x));
}

std::vector<float> softmax(const std::vector<float>& values)
{
  if (values.empty()) {
    return {};
  }
  const float max_value = *std::max_element(values.begin(), values.end());
  std::vector<float> probabilities;
  probabilities.reserve(values.size());
  float sum = 0.0f;
  for (float value : values) {
    const float e = std::exp(value - max_value);
    probabilities.push_back(e);
    sum += e;
  }
  if (sum <= 0.0f || !std::isfinite(sum)) {
    return values;
  }
  for (float& value : probabilities) {
    value /= sum;
  }
  return probabilities;
}

std::pair<float, float> centralBboxInterval(const cv::Rect& box,
                                            float center_x,
                                            float fraction,
                                            int image_width)
{
  const float clamped_fraction = std::max(0.05f, std::min(fraction, 1.0f));
  const float width = box.width > 0 ? static_cast<float>(box.width) : 2.0f;
  const float center = box.width > 0
    ? static_cast<float>(box.x) + 0.5f * static_cast<float>(box.width - 1)
    : center_x;
  const float half = std::max(1.0f, width * clamped_fraction * 0.5f);
  const float max_x = static_cast<float>(std::max(0, image_width - 1));
  float xmin = std::max(0.0f, center - half);
  float xmax = std::min(max_x, center + half);
  if (xmax < xmin) {
    std::swap(xmin, xmax);
  }
  return {xmin, xmax};
}

cv::Rect decodeBboxOutput(const std::vector<float>& output, const cv::Size& size)
{
  if (output.size() < 4 || size.width <= 0 || size.height <= 0) {
    return {};
  }

  float x0 = output[0];
  float y0 = output[1];
  float x1 = output[2];
  float y1 = output[3];
  const bool normalized =
    std::fabs(x0) <= 1.5f && std::fabs(y0) <= 1.5f &&
    std::fabs(x1) <= 1.5f && std::fabs(y1) <= 1.5f;
  if (normalized) {
    x0 *= size.width;
    x1 *= size.width;
    y0 *= size.height;
    y1 *= size.height;
  }
  if (x1 < x0) {
    std::swap(x0, x1);
  }
  if (y1 < y0) {
    std::swap(y0, y1);
  }

  const int left = static_cast<int>(std::floor(x0));
  const int top = static_cast<int>(std::floor(y0));
  const int right = static_cast<int>(std::ceil(x1));
  const int bottom = static_cast<int>(std::ceil(y1));
  return cv::Rect(left, top, right - left, bottom - top) &
         cv::Rect(0, 0, size.width, size.height);
}

bool bboxSizePasses(const cv::Rect& bbox, float min_area, float min_width, float min_height)
{
  return bbox.width > 0 && bbox.height > 0 &&
         static_cast<float>(bbox.area()) >= min_area &&
         static_cast<float>(bbox.width) >= min_width &&
         static_cast<float>(bbox.height) >= min_height;
}

}  // namespace

LarcVisionPipeline::LarcVisionPipeline(std::shared_ptr<OnnxRunner> presence_runner,
                                       std::shared_ptr<OnnxRunner> type_runner,
                                       std::shared_ptr<OnnxRunner> victim_bbox_runner,
                                       std::shared_ptr<OnnxRunner> target_bbox_runner,
                                       std::shared_ptr<OnnxRunner> victim_cls_runner,
                                       Config config)
  : presence_runner_(std::move(presence_runner)),
    type_runner_(std::move(type_runner)),
    target_bbox_runner_(std::move(target_bbox_runner)),
    target_detector_(config.target_detector),
    victim_detector_(std::move(victim_bbox_runner),
                     std::move(victim_cls_runner),
                     VictimDetector::Config{config.min_victim_cls_confidence,
                                            config.reject_fake_victims,
                                            config.fake_min_confidence,
                                            config.victim_crop_padding,
                                            config.victim_classify_full_frame}),
    projector_(config.projector),
    duplicate_filter_(config.duplicate_scope),
    config_(std::move(config))
{
}

std::optional<VisionDetection> LarcVisionPipeline::process(const VisionFrame& frame,
                                                           std::string& reject_reason)
{
  if (frame.bgr.empty()) {
    reject_reason = "empty_frame";
    logEvent("ROBOT_EVENT node=ros2_vision event=frame_invalid reason=empty_frame camera=" +
             frame.camera_name);
    logDebugImage(frame, VisionDebugImage{"rejected", "frame", "none", reject_reason});
    return std::nullopt;
  }

  const std::string ctx = frameContext(frame);

  if (config_.lidar_gate_enabled) {
    int close_rays = 0;
    int max_run = 0;
    if (!lidarGatePasses(frame, &close_rays, &max_run)) {
      reject_reason = "lidar_gate_no_close_surface";
      std::ostringstream oss;
      oss << "ROBOT_EVENT node=ros2_vision event=lidar_gate_rejected " << ctx
          << " reason=" << reject_reason
          << " close_rays=" << close_rays
          << " max_consecutive=" << max_run
          << " required_consecutive=" << config_.lidar_gate_min_consecutive_rays
          << " max_range=" << config_.lidar_gate_max_range_m;
      logEvent(oss.str());
      VisionDebugImage debug;
      debug.status = "rejected";
      debug.kind = "lidar_gate";
      debug.reason = reject_reason;
      debug.valid_lidar_rays = close_rays;
      logDebugImage(frame, debug);
      return std::nullopt;
    }
  }

  // 2+3) Presence + object type. One fused model, or the legacy two-stage chain.
  float presence = 0.0f;
  std::string kind;
  float type_confidence = 0.0f;
  if (!decodeObjectStage(frame, ctx, presence, kind, type_confidence, reject_reason)) {
    return std::nullopt;
  }

  auto run_branch = [&](const std::string& branch, float branch_confidence,
                        std::string& branch_reject,
                        VisionDebugImage& branch_debug) -> std::optional<VisionDetection> {
    if (branch == "target") {
      return processTarget(frame, presence, branch_confidence, branch_reject, branch_debug);
    }
    return processVictim(frame, presence, branch_confidence, branch_reject, branch_debug);
  };

  // The branch handlers no longer write images themselves; process() logs exactly
  // one image per frame here so a type-fallback can never leave both a rejected
  // (primary) and a classified (fallback) picture behind for the same frame.
  VisionDebugImage primary_debug;
  auto result = run_branch(kind, type_confidence, reject_reason, primary_debug);
  if (result || !config_.type_fallback_enabled) {
    logDebugImage(frame, primary_debug);
    return result;
  }

  const std::string primary_kind = kind;
  const std::string primary_reject = reject_reason;
  const std::string fallback_kind = primary_kind == "target" ? "victim" : "target";
  const float fallback_confidence = std::max(0.0f, std::min(1.0f, 1.0f - type_confidence));
  {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(3)
        << "ROBOT_EVENT node=ros2_vision event=branch_fallback " << ctx
        << " primary=" << primary_kind
        << " fallback=" << fallback_kind
        << " primary_reject=" << primary_reject
        << " fallback_type_confidence=" << fallback_confidence;
    logEvent(oss.str());
  }

  std::string fallback_reject;
  VisionDebugImage fallback_debug;
  result = run_branch(fallback_kind, fallback_confidence, fallback_reject, fallback_debug);
  if (!result) {
    reject_reason = primary_reject + ";fallback_" + fallback_kind + "=" + fallback_reject;
    // Keep the more-informative primary rejection image; drop the fallback's.
    logDebugImage(frame, primary_debug);
  } else {
    logDebugImage(frame, fallback_debug);
  }
  return result;
}

bool LarcVisionPipeline::decodeObjectStage(const VisionFrame& frame, const std::string& ctx,
                                           float& presence, std::string& kind,
                                           float& type_confidence,
                                           std::string& reject_reason) const
{
  const bool fused = config_.use_fused_object_model && config_.object_presence_runner &&
                     config_.object_presence_runner->valid();

  if (fused) {
    // Single none/target/victim model: one inference replaces presence + type.
    const auto output = config_.object_presence_runner->run(frame.bgr);
    if (output.size() < 3) {
      reject_reason = "fused_object_output";
      logEvent("ROBOT_EVENT node=ros2_vision event=presence_rejected " + ctx +
               " stage=fused reason=fused_object_output");
      logDebugImage(frame, VisionDebugImage{"rejected", "presence", "none", reject_reason});
      return false;
    }
    const auto probs = softmax(output);
    const float p_none = probs[0];
    const float p_target = probs[1];
    const float p_victim = probs[2];
    presence = 1.0f - p_none;
    if (presence < config_.min_presence_confidence) {
      reject_reason = "no_object";
      std::ostringstream oss;
      oss << std::fixed << std::setprecision(3)
          << "ROBOT_EVENT node=ros2_vision event=presence_rejected " << ctx
          << " stage=fused confidence=" << presence
          << " threshold=" << config_.min_presence_confidence << " reason=no_object";
      logEvent(oss.str());
      VisionDebugImage debug;
      debug.status = "rejected";
      debug.kind = "presence";
      debug.reason = reject_reason;
      debug.confidence = presence;
      logDebugImage(frame, debug);
      return false;
    }
    kind = p_target >= p_victim ? "target" : "victim";
    // Confidence of the chosen branch relative to the two object classes only.
    const float object_mass = std::max(1e-6f, p_target + p_victim);
    type_confidence = (kind == "target" ? p_target : p_victim) / object_mass;
    if (type_confidence < config_.min_type_confidence) {
      reject_reason = "type_confidence";
      std::ostringstream oss;
      oss << std::fixed << std::setprecision(3)
          << "ROBOT_EVENT node=ros2_vision event=type_rejected " << ctx
          << " stage=fused branch=" << kind << " confidence=" << type_confidence
          << " threshold=" << config_.min_type_confidence << " reason=type_confidence";
      logEvent(oss.str());
      VisionDebugImage debug;
      debug.status = "rejected";
      debug.kind = "type";
      debug.class_name = kind;
      debug.reason = reject_reason;
      debug.confidence = type_confidence;
      logDebugImage(frame, debug);
      return false;
    }
  } else {
    // Legacy two-stage: dedicated presence (none/object) then object_type.
    if (!presence_runner_ || !presence_runner_->valid()) {
      reject_reason = "presence_runner_unavailable";
      logEvent("ROBOT_EVENT node=ros2_vision event=presence_rejected " + ctx +
               " stage=presence reason=presence_runner_unavailable");
      logDebugImage(frame, VisionDebugImage{"rejected", "presence", "none", reject_reason});
      return false;
    }
    const auto presence_output = presence_runner_->run(frame.bgr);
    if (presence_output.empty()) {
      reject_reason = "presence_empty_output";
      logEvent("ROBOT_EVENT node=ros2_vision event=presence_rejected " + ctx +
               " stage=presence reason=presence_empty_output");
      logDebugImage(frame, VisionDebugImage{"rejected", "presence", "none", reject_reason});
      return false;
    }
    presence = decodeConfidence(presence_output);
    if (presence < config_.min_presence_confidence) {
      reject_reason = "no_object";
      std::ostringstream oss;
      oss << std::fixed << std::setprecision(3)
          << "ROBOT_EVENT node=ros2_vision event=presence_rejected " << ctx
          << " stage=presence confidence=" << presence
          << " threshold=" << config_.min_presence_confidence << " reason=no_object";
      logEvent(oss.str());
      VisionDebugImage debug;
      debug.status = "rejected";
      debug.kind = "presence";
      debug.reason = reject_reason;
      debug.confidence = presence;
      logDebugImage(frame, debug);
      return false;
    }

    if (!type_runner_ || !type_runner_->valid()) {
      reject_reason = "type_runner_unavailable";
      logEvent("ROBOT_EVENT node=ros2_vision event=type_rejected " + ctx +
               " stage=type reason=type_runner_unavailable");
      logDebugImage(frame, VisionDebugImage{"rejected", "type", "none", reject_reason});
      return false;
    }
    const auto type_output = type_runner_->run(frame.bgr);
    if (type_output.empty()) {
      reject_reason = "type_empty_output";
      logEvent("ROBOT_EVENT node=ros2_vision event=type_rejected " + ctx +
               " stage=type reason=type_empty_output");
      logDebugImage(frame, VisionDebugImage{"rejected", "type", "none", reject_reason});
      return false;
    }
    std::tie(kind, type_confidence) = decodeType(type_output);
    if (type_confidence < config_.min_type_confidence) {
      reject_reason = "type_confidence";
      std::ostringstream oss;
      oss << std::fixed << std::setprecision(3)
          << "ROBOT_EVENT node=ros2_vision event=type_rejected " << ctx
          << " stage=type branch=" << kind << " confidence=" << type_confidence
          << " threshold=" << config_.min_type_confidence << " reason=type_confidence";
      logEvent(oss.str());
      VisionDebugImage debug;
      debug.status = "rejected";
      debug.kind = "type";
      debug.class_name = kind;
      debug.reason = reject_reason;
      debug.confidence = type_confidence;
      logDebugImage(frame, debug);
      return false;
    }
  }

  std::ostringstream oss;
  oss << std::fixed << std::setprecision(3)
      << "ROBOT_EVENT node=ros2_vision event=branch_selected " << ctx
      << " branch=" << kind << " presence=" << presence
      << " type_confidence=" << type_confidence << " threshold=" << config_.min_type_confidence
      << " fused=" << (fused ? "true" : "false");
  logEvent(oss.str());
  return true;
}

std::string LarcVisionPipeline::frameContext(const VisionFrame& frame) const
{
  std::ostringstream oss;
  oss << std::fixed << std::setprecision(3)
      << "camera=" << frame.camera_name
      << " camera_id=" << frame.camera_id
      << " seq=" << frame.seq
      << " tile_x=" << frame.tile_x << " tile_y=" << frame.tile_y
      << " heading_rad=" << frame.robot_yaw
      << " w=" << frame.bgr.cols << " h=" << frame.bgr.rows
      << " ch=" << frame.bgr.channels();
  return oss.str();
}

std::optional<VisionDetection> LarcVisionPipeline::processTarget(const VisionFrame& frame,
                                                                 float presence,
                                                                 float type_confidence,
                                                                 std::string& reject_reason,
                                                                 VisionDebugImage& out_debug)
{
  TargetResult target = target_detector_.detect(frame.bgr);

  const std::string ctx = frameContext(frame);
  {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(3)
        << "ROBOT_EVENT node=ros2_vision event=target_candidate " << ctx
        << " center=(" << target.center_x << "," << target.center_y << ")"
        << " pattern=" << target.pattern
        << " class=" << target.class_name
        << " sum=" << target.sum_value
        << " radial_coverage=" << target.radial_coverage
        << " mask_area=" << target.mask_area_px
        << " mask_conf=" << target.mask_confidence;
    logEvent(oss.str());
  }

  auto make_debug = [&](const std::string& status, const std::string& reason) {
    VisionDebugImage debug;
    debug.status = status;
    debug.kind = "target";
    debug.class_name = target.class_name;
    debug.reason = reason;
    debug.confidence = target.mask_confidence;
    debug.bbox = target.visible_bbox;
    debug.center_x = target.center_x;
    debug.center_y = target.center_y;
    debug.target_pattern = target.pattern;
    debug.target_sum = target.sum_value;
    debug.radial_coverage = target.radial_coverage;
    debug.mask_confidence = target.mask_confidence;
    return debug;
  };

  auto reject = [&](const std::string& reason, const std::string& extra = "") {
    reject_reason = reason;
    logEvent("ROBOT_EVENT node=ros2_vision event=target_rejected " + ctx +
             " reason=" + reason + extra);
    out_debug = make_debug("rejected", reason);
    return std::optional<VisionDetection>(std::nullopt);
  };

  if (config_.use_bbox_gate) {
    if (!target_bbox_runner_ || !target_bbox_runner_->valid()) {
      return reject("target_bbox_runner_unavailable");
    }
    const cv::Rect gate_bbox = decodeBboxOutput(target_bbox_runner_->run(frame.bgr), frame.bgr.size());
    const bool pass = bboxSizePasses(
      gate_bbox,
      config_.target_bbox_gate_min_area_px,
      config_.target_bbox_gate_min_width_px,
      config_.target_bbox_gate_min_height_px);
    {
      std::ostringstream e;
      e << std::fixed << std::setprecision(3)
        << "ROBOT_EVENT node=ros2_vision event=bbox_gate"
        << " branch=target " << ctx
        << " pass=" << (pass ? "true" : "false")
        << " bbox=(" << gate_bbox.x << "," << gate_bbox.y << ","
        << gate_bbox.width << "," << gate_bbox.height << ")"
        << " area=" << gate_bbox.area()
        << " min_area=" << config_.target_bbox_gate_min_area_px
        << " min_width=" << config_.target_bbox_gate_min_width_px
        << " min_height=" << config_.target_bbox_gate_min_height_px;
      logEvent(e.str());
    }
    if (!pass) {
      std::ostringstream e;
      e << " bbox_area=" << gate_bbox.area()
        << " bbox_width=" << gate_bbox.width
        << " bbox_height=" << gate_bbox.height
        << " min_area=" << config_.target_bbox_gate_min_area_px
        << " min_width=" << config_.target_bbox_gate_min_width_px
        << " min_height=" << config_.target_bbox_gate_min_height_px;
      out_debug = make_debug("rejected", "target_bbox_gate");
      out_debug.bbox = gate_bbox;
      return reject("target_bbox_gate", e.str());
    }
  }

  if (target.mask_area_px < config_.min_mask_area_px) {
    return reject("target_low_mask_area", " mask_area=" + std::to_string(target.mask_area_px));
  }
  if (target.radial_coverage < config_.min_radial_coverage) {
    std::ostringstream e;
    e << " radial_coverage=" << std::fixed << std::setprecision(3) << target.radial_coverage;
    return reject("target_low_radial_coverage", e.str());
  }
  float min_ring_conf = 1.0f;
  for (float c : target.ring_confidence) {
    min_ring_conf = std::min(min_ring_conf, c);
  }
  if (min_ring_conf < config_.min_ring_confidence || target.pattern.find('?') != std::string::npos) {
    std::ostringstream e;
    e << " min_ring_conf=" << std::fixed << std::setprecision(3) << min_ring_conf;
    return reject("target_ring_confidence", e.str());
  }
  if (!target.sum_valid) {
    return reject("target_invalid_sum", " sum=" + std::to_string(target.sum_value));
  }

  // LiDAR acceptance over the center of the clean-mask visible bbox.
  const cv::Rect& box = target.visible_bbox;
  const auto [xmin, xmax] = centralBboxInterval(
    box, target.center_x, config_.lidar_bbox_center_fraction, frame.bgr.cols);
  const auto lidar_check = projector_.closeRunForPixelInterval(
    frame.scan, frame.bgr.cols, frame.camera_hfov_rad, frame.camera_yaw_offset_rad,
    frame.lidar_angle_min, frame.lidar_angle_increment, frame.lidar_range_min,
    frame.lidar_range_max, xmin, xmax, config_.valid_detection_distance_m,
    config_.lidar_bbox_min_consecutive_rays);
  const float distance = lidar_check.distance;
  const int valid_rays = lidar_check.valid_rays;
  logLidar("target", frame, xmin, xmax, distance, valid_rays);

  // LiDAR target distance is diagnostic by default. The branch gate remains
  // available through config, but production acceptance is camera-only.
  const bool target_lidar_gate =
    config_.use_lidar_distance_gate || config_.use_target_lidar_distance_gate;
  if (target_lidar_gate &&
      (!lidar_check.pass || !std::isfinite(distance) ||
       distance > config_.valid_detection_distance_m)) {
    std::ostringstream e;
    e << std::fixed << std::setprecision(3) << " distance=" << distance
      << " max=" << config_.valid_detection_distance_m
      << " close_rays=" << lidar_check.close_rays
      << " max_consecutive=" << lidar_check.max_consecutive
      << " required_consecutive=" << config_.lidar_bbox_min_consecutive_rays;
    reject_reason = "target_distance";
    logEvent("ROBOT_EVENT node=ros2_vision event=target_rejected " + ctx +
             " reason=target_distance" + e.str());
    out_debug = make_debug("rejected", reject_reason);
    out_debug.distance = distance;
    out_debug.lidar_xmin = xmin;
    out_debug.lidar_xmax = xmax;
    out_debug.valid_lidar_rays = lidar_check.close_rays;
    return std::nullopt;
  }

  VisionDetection detection;
  detection.seq = frame.seq;
  detection.camera_id = frame.camera_id;
  detection.camera_name = frame.camera_name;
  detection.tile_x = frame.tile_x;
  detection.tile_y = frame.tile_y;
  detection.kind = "target";
  detection.class_name = target.class_name;  // F/P/C/O (never "target")
  detection.confidence = std::min({presence, type_confidence, target.mask_confidence, min_ring_conf});
  detection.distance = distance;
  detection.center_x = target.center_x;
  detection.center_y = target.center_y;
  detection.bbox = target.visible_bbox;
  detection.target_pattern = target.pattern;
  detection.target_sum = target.sum_value;
  detection.radial_coverage = target.radial_coverage;
  detection.mask_confidence = target.mask_confidence;

  duplicate_filter_.mark(frame.tile_x, frame.tile_y, frame.camera_id, detection.kind, detection.class_name);

  std::ostringstream oss;
  oss << std::fixed << std::setprecision(3)
      << "ROBOT_EVENT node=ros2_vision event=target_accepted"
      << " class=" << detection.class_name
      << " pattern=" << detection.target_pattern
      << " sum=" << detection.target_sum
      << " distance=" << detection.distance
      << " confidence=" << detection.confidence;
  logEvent(oss.str());
  out_debug = make_debug("classified", "none");
  out_debug.class_name = detection.class_name;
  out_debug.confidence = detection.confidence;
  out_debug.distance = detection.distance;
  out_debug.lidar_xmin = xmin;
  out_debug.lidar_xmax = xmax;
  out_debug.valid_lidar_rays = lidar_check.close_rays;
  return detection;
}

std::optional<VisionDetection> LarcVisionPipeline::processVictim(const VisionFrame& frame,
                                                                 float presence,
                                                                 float type_confidence,
                                                                 std::string& reject_reason,
                                                                 VisionDebugImage& out_debug)
{
  VictimResult victim = victim_detector_.detect(frame.bgr);
  auto make_debug = [&](const std::string& status, const std::string& reason) {
    VisionDebugImage debug;
    debug.status = status;
    debug.kind = "victim";
    debug.class_name = victim.class_name;
    debug.reason = reason;
    debug.confidence = victim.confidence;
    debug.bbox = victim.bbox;
    debug.center_x = victim.center_x;
    debug.center_y = victim.center_y;
    return debug;
  };
  {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(3)
        << "ROBOT_EVENT node=ros2_vision event=victim_candidate " << frameContext(frame)
        << " class=" << victim.class_name
        << " confidence=" << victim.confidence
        << " bbox=(" << victim.bbox.x << "," << victim.bbox.y << ","
        << victim.bbox.width << "," << victim.bbox.height << ")"
        << " bbox_valid=" << (victim.bbox_valid ? "true" : "false")
        << " crop_valid=" << (victim.crop_valid ? "true" : "false")
        << " valid=" << (victim.valid ? "true" : "false");
    logEvent(oss.str());
  }
  if (victim.bbox_valid &&
      (victim.bbox.area() < config_.victim_min_bbox_area_px ||
       victim.bbox.width < config_.victim_min_bbox_axis_px ||
       victim.bbox.height < config_.victim_min_bbox_axis_px)) {
    reject_reason = "victim_tiny_bbox";
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(3)
        << "ROBOT_EVENT node=ros2_vision event=victim_rejected " << frameContext(frame)
        << " reason=victim_tiny_bbox"
        << " bbox_area=" << victim.bbox.area()
        << " min_area=" << config_.victim_min_bbox_area_px
        << " min_axis=" << config_.victim_min_bbox_axis_px;
    logEvent(oss.str());
    out_debug = make_debug("rejected", reject_reason);
    return std::nullopt;
  }
  if (config_.use_bbox_gate && victim.bbox_valid) {
    const bool pass = bboxSizePasses(
      victim.bbox,
      config_.victim_bbox_gate_min_area_px,
      config_.victim_bbox_gate_min_width_px,
      config_.victim_bbox_gate_min_height_px);
    {
      std::ostringstream oss;
      oss << std::fixed << std::setprecision(3)
          << "ROBOT_EVENT node=ros2_vision event=bbox_gate"
          << " branch=victim " << frameContext(frame)
          << " pass=" << (pass ? "true" : "false")
          << " bbox=(" << victim.bbox.x << "," << victim.bbox.y << ","
          << victim.bbox.width << "," << victim.bbox.height << ")"
          << " area=" << victim.bbox.area()
          << " min_area=" << config_.victim_bbox_gate_min_area_px
          << " min_width=" << config_.victim_bbox_gate_min_width_px
          << " min_height=" << config_.victim_bbox_gate_min_height_px;
      logEvent(oss.str());
    }
    if (!pass) {
      reject_reason = "victim_bbox_gate";
      std::ostringstream oss;
      oss << std::fixed << std::setprecision(3)
          << "ROBOT_EVENT node=ros2_vision event=victim_rejected " << frameContext(frame)
          << " reason=victim_bbox_gate"
          << " bbox_area=" << victim.bbox.area()
          << " bbox_width=" << victim.bbox.width
          << " bbox_height=" << victim.bbox.height
          << " min_area=" << config_.victim_bbox_gate_min_area_px
          << " min_width=" << config_.victim_bbox_gate_min_width_px
          << " min_height=" << config_.victim_bbox_gate_min_height_px;
      logEvent(oss.str());
      out_debug = make_debug("rejected", reject_reason);
      return std::nullopt;
    }
  }
  if (!victim.valid) {
    reject_reason = victim.reject_reason;
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(3)
        << "ROBOT_EVENT node=ros2_vision event=victim_rejected " << frameContext(frame)
        << " reason=" << victim.reject_reason
        << " confidence=" << victim.confidence
        << " threshold=" << config_.min_victim_cls_confidence;
    logEvent(oss.str());
    out_debug = make_debug("rejected", victim.reject_reason);
    return std::nullopt;
  }

  const auto [central_min, central_max] = centralBboxInterval(
    victim.bbox, victim.center_x, config_.lidar_bbox_center_fraction, frame.bgr.cols);
  const auto lidar_check = projector_.closeRunForPixelInterval(
    frame.scan, frame.bgr.cols, frame.camera_hfov_rad, frame.camera_yaw_offset_rad,
    frame.lidar_angle_min, frame.lidar_angle_increment, frame.lidar_range_min,
    frame.lidar_range_max, central_min, central_max, config_.valid_detection_distance_m,
    config_.lidar_bbox_min_consecutive_rays);
  const float distance = lidar_check.distance;
  const int valid_rays = lidar_check.valid_rays;
  logLidar("victim", frame, central_min, central_max, distance, valid_rays);

  // LiDAR victim distance is diagnostic by default. The branch gate remains
  // available through config, but production acceptance is camera-only.
  const bool victim_lidar_gate =
    config_.use_lidar_distance_gate || config_.use_victim_lidar_distance_gate;
  if (victim_lidar_gate &&
      (!lidar_check.pass || !std::isfinite(distance) || distance < config_.victim_min_distance_m ||
       distance > config_.valid_detection_distance_m)) {
    reject_reason = "victim_distance";
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(3)
        << "ROBOT_EVENT node=ros2_vision event=victim_rejected reason=victim_distance"
        << " distance=" << distance
        << " max=" << config_.valid_detection_distance_m
        << " close_rays=" << lidar_check.close_rays
        << " max_consecutive=" << lidar_check.max_consecutive
        << " required_consecutive=" << config_.lidar_bbox_min_consecutive_rays;
    logEvent(oss.str());
    out_debug = make_debug("rejected", reject_reason);
    out_debug.distance = distance;
    out_debug.lidar_xmin = central_min;
    out_debug.lidar_xmax = central_max;
    out_debug.valid_lidar_rays = lidar_check.close_rays;
    return std::nullopt;
  }

  VisionDetection detection;
  detection.seq = frame.seq;
  detection.camera_id = frame.camera_id;
  detection.camera_name = frame.camera_name;
  detection.tile_x = frame.tile_x;
  detection.tile_y = frame.tile_y;
  detection.kind = "victim";
  detection.class_name = victim.class_name;
  detection.confidence = std::min({presence, type_confidence, victim.confidence});
  detection.distance = distance;
  detection.center_x = victim.center_x;
  detection.center_y = victim.center_y;
  detection.bbox = victim.bbox;
  detection.target_pattern = "none";

  duplicate_filter_.mark(frame.tile_x, frame.tile_y, frame.camera_id, detection.kind, detection.class_name);

  std::ostringstream oss;
  oss << std::fixed << std::setprecision(3)
      << "ROBOT_EVENT node=ros2_vision event=victim_accepted"
      << " class=" << detection.class_name
      << " distance=" << detection.distance
      << " confidence=" << detection.confidence;
  logEvent(oss.str());
  out_debug = make_debug("classified", "none");
  out_debug.confidence = detection.confidence;
  out_debug.distance = detection.distance;
  out_debug.lidar_xmin = central_min;
  out_debug.lidar_xmax = central_max;
  out_debug.valid_lidar_rays = lidar_check.close_rays;
  return detection;
}

void LarcVisionPipeline::logLidar(const std::string& branch, const VisionFrame& frame,
                                  float xmin, float xmax, float distance, int valid_rays) const
{
  std::ostringstream oss;
  oss << std::fixed << std::setprecision(3)
      << "ROBOT_EVENT node=ros2_vision event=lidar_distance_estimate"
      << " branch=" << branch
      << " camera=" << frame.camera_name
      << " distance=" << distance
      << " xmin=" << xmin << " xmax=" << xmax
      << " valid_rays=" << valid_rays
      << " percentile=" << config_.projector.robust_percentile;
  logEvent(oss.str());
}

bool LarcVisionPipeline::lidarGatePasses(const VisionFrame& frame, int* close_rays, int* max_run) const
{
  if (close_rays) {
    *close_rays = 0;
  }
  if (max_run) {
    *max_run = 0;
  }
  if (frame.scan.empty() || !(frame.lidar_angle_increment > 0.0f) ||
      !(frame.camera_hfov_rad > 0.0f)) {
    return false;
  }

  const double half_fov = static_cast<double>(frame.camera_hfov_rad) * 0.5;
  int total_close = 0;
  int current_run = 0;
  int best_run = 0;
  for (std::size_t i = 0; i < frame.scan.size(); ++i) {
    const double angle = static_cast<double>(frame.lidar_angle_min) +
      static_cast<double>(i) * static_cast<double>(frame.lidar_angle_increment);
    const bool in_camera_fov =
      std::abs(wrapPi(angle - static_cast<double>(frame.camera_yaw_offset_rad))) <= half_fov;
    const float range = frame.scan[i];
    const bool close =
      in_camera_fov &&
      std::isfinite(range) &&
      range >= frame.lidar_range_min &&
      range <= config_.lidar_gate_max_range_m;
    if (close) {
      ++total_close;
      ++current_run;
      best_run = std::max(best_run, current_run);
    } else if (in_camera_fov) {
      current_run = 0;
    }
  }

  if (close_rays) {
    *close_rays = total_close;
  }
  if (max_run) {
    *max_run = best_run;
  }
  return best_run >= std::max(1, config_.lidar_gate_min_consecutive_rays);
}

float LarcVisionPipeline::decodeConfidence(const std::vector<float>& output) const
{
  if (output.empty()) {
    return 0.0f;
  }
  float confidence = output.front();
  if (output.size() > 1) {
    const auto probabilities = softmax(output);
    confidence = probabilities.size() > 1 ? probabilities[1] : 0.0f;  // labels: none, object
  }
  if (confidence < 0.0f || confidence > 1.0f) {
    confidence = sigmoid(confidence);
  }
  return std::max(0.0f, std::min(confidence, 1.0f));
}

std::pair<std::string, float> LarcVisionPipeline::decodeType(const std::vector<float>& output) const
{
  if (output.empty()) {
    return {"victim", 0.0f};
  }
  if (output.size() == 1) {
    const float p = decodeConfidence(output);
    return {p >= 0.5f ? "target" : "victim", std::max(p, 1.0f - p)};
  }

  const auto probabilities = softmax(output);
  const auto max_it = std::max_element(probabilities.begin(), probabilities.end());
  const std::size_t idx = static_cast<std::size_t>(std::distance(probabilities.begin(), max_it));
  float confidence = *max_it;
  if (confidence < 0.0f || confidence > 1.0f) {
    confidence = sigmoid(confidence);
  }
  return {idx == 0 ? "target" : "victim", std::max(0.0f, std::min(confidence, 1.0f))};
}

void LarcVisionPipeline::logEvent(const std::string& event) const
{
  if (config_.event_logger) {
    config_.event_logger(event);
  }
}

std::string LarcVisionPipeline::debugImageKey(const VisionFrame& frame,
                                              const VisionDebugImage& debug) const
{
  std::ostringstream oss;
  // Per (tile, camera) so both cameras and genuinely new outcomes still get one
  // representative image, but a stationary robot staring at the same wall does
  // not keep re-writing identical PNGs every frame.
  oss << frame.tile_x << '|' << frame.tile_y << '|' << frame.camera_id << '|'
      << debug.status << '|' << debug.kind << '|';
  if (debug.status == "classified") {
    oss << debug.class_name << '|' << debug.target_pattern;
  } else {
    oss << debug.reason;
  }
  return oss.str();
}

void LarcVisionPipeline::logDebugImage(const VisionFrame& frame, const VisionDebugImage& debug) const
{
  if (!config_.debug_image_logger) {
    return;
  }
  // Collapse repeated identical outcomes for the same tile/camera. A brand-new
  // classified class or a new rejection reason on the same tile still produces
  // exactly one image; frame-after-frame duplicates are dropped.
  if (config_.dedup_debug_images) {
    const std::string key = debugImageKey(frame, debug);
    if (!logged_debug_keys_.insert(key).second) {
      return;
    }
  }
  config_.debug_image_logger(frame, debug);
}

}  // namespace ros2_vision
