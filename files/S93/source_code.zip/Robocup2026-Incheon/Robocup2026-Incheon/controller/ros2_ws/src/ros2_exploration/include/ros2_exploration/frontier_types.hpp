#pragma once

#include <cstddef>
#include <string>
#include <vector>

#include "geometry_msgs/msg/point.hpp"

namespace ros2_exploration
{

struct GridIndex
{
  int x{0};
  int y{0};
};

bool operator==(const GridIndex & lhs, const GridIndex & rhs);
bool operator!=(const GridIndex & lhs, const GridIndex & rhs);

struct FrontierCell
{
  GridIndex index;
  geometry_msgs::msg::Point world;
};

struct Frontier
{
  std::vector<FrontierCell> cells;
  geometry_msgs::msg::Point centroid;
  double score{0.0};
  std::string source{"occupancy_grid"};
};

std::size_t frontierSize(const Frontier & frontier);
bool frontierEmpty(const Frontier & frontier);

}  // namespace ros2_exploration
