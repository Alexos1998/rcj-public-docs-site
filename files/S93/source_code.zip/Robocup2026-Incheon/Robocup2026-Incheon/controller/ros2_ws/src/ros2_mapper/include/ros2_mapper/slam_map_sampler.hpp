#ifndef ROS2_MAPPER__SLAM_MAP_SAMPLER_HPP_
#define ROS2_MAPPER__SLAM_MAP_SAMPLER_HPP_

#include <geometry_msgs/msg/transform_stamped.hpp>
#include <nav_msgs/msg/occupancy_grid.hpp>
#include <rclcpp/time.hpp>

#include <cstdint>
#include <string>
#include <vector>

namespace ros2_mapper
{

enum class SlamGeometryState
{
  Unknown,
  LikelyOpen,
  ConfirmedOpen,
  LikelyWall,
  ConfirmedWall,
  Conflicted
};

enum class SlamCardinalDirection
{
  North,
  East,
  South,
  West
};

struct SlamRegionStats
{
  int sample_count = 0;
  int free_count = 0;
  int occupied_count = 0;
  int unknown_count = 0;
  int out_of_bounds_count = 0;
  double free_ratio = 0.0;
  double occupied_ratio = 0.0;
  double unknown_ratio = 0.0;
  double confidence = 0.0;
  bool map_available = false;
  bool map_real = false;
  bool map_recent = false;
  bool clearance_available = false;
  int clearance_sample_count = 0;
  int clearance_ok_count = 0;
  double clearance_min_m = 0.0;
  double clearance_mean_m = 0.0;
  double clearance_ratio_ok = 0.0;
  double clearance_threshold_m = 0.0;
  double clearance_sum_m = 0.0;
};

struct SlamMapSamplerConfig
{
  bool enabled = true;
  std::string map_topic = "/map";
  double expected_resolution_m = 0.005;
  double resolution_tolerance_m = 0.002;
  double max_map_age_sec = 1.0;
  int min_known_cells = 200;
  int min_occupied_cells = 20;
  double min_known_ratio = 0.001;
  bool reject_all_free_maps = true;
  bool reject_all_unknown_maps = true;
  int free_threshold = 20;
  int occupied_threshold = 65;
  double debug_log_period_sec = 2.0;
  double confirmed_wall_occupied_ratio = 0.45;
  double likely_wall_occupied_ratio = 0.25;
  double likely_open_free_ratio = 0.60;
  double confirmed_open_free_ratio = 0.80;
  double max_open_occupied_ratio = 0.10;
  double max_confirmed_open_unknown_ratio = 0.25;
  int min_region_samples = 8;
  double tile_interior_ratio = 0.60;
  double edge_strip_length_ratio = 0.70;
  double edge_strip_min_width_m = 0.025;
  double corridor_width_m = 0.10;
  double phantom_support_free_ratio = 0.60;
  double phantom_conflict_occupied_ratio = 0.25;
  double phantom_confirmed_conflict_occupied_ratio = 0.45;
  double phantom_max_supported_occupied_ratio = 0.10;
  int phantom_min_region_samples = 8;
  double phantom_tile_sample_scale = 0.60;
  double phantom_corridor_width_m = 0.09;
  bool clearance_enabled = true;
  int clearance_occupied_threshold = 65;
  bool clearance_unknown_as_obstacle = false;
  double clearance_robot_radius_m = 0.035;
  double clearance_safety_margin_m = 0.015;
  double clearance_min_passage_clearance_m = 0.050;
  double clearance_stale_after_sec = 1.0;
};

struct SlamMapStatus
{
  bool enabled = true;
  bool map_available = false;
  bool map_real = false;
  bool map_recent = false;
  std::uint32_t width = 0U;
  std::uint32_t height = 0U;
  double resolution = 0.0;
  std::string frame_id;
  int total_cells = 0;
  int known_cells = 0;
  int free_cells = 0;
  int occupied_cells = 0;
  int unknown_cells = 0;
  double known_ratio = 0.0;
  double free_ratio = 0.0;
  double occupied_ratio = 0.0;
  double unknown_ratio = 0.0;
  double age_sec = 0.0;
  std::string rejection_reason = "no_map";
};

struct SlamRectRegion
{
  double center_x = 0.0;
  double center_y = 0.0;
  double yaw_rad = 0.0;
  double length_m = 0.0;
  double width_m = 0.0;
};

const char * slamGeometryStateToString(SlamGeometryState state);

class SlamMapSampler
{
public:
  void configure(const SlamMapSamplerConfig & config);
  const SlamMapSamplerConfig & config() const;

  void reset();
  void updateMap(const nav_msgs::msg::OccupancyGrid & map, const rclcpp::Time & received_at);

  SlamMapStatus status(const rclcpp::Time & now) const;
  bool hasSampleableMap(const rclcpp::Time & now) const;
  SlamGeometryState classifyRegion(const SlamRegionStats & stats) const;

  SlamRegionStats sampleAxisAlignedBox(
    double center_x,
    double center_y,
    double size_x_m,
    double size_y_m,
    const rclcpp::Time & now,
    const geometry_msgs::msg::TransformStamped * region_to_map = nullptr) const;

  SlamRegionStats sampleOrientedBox(
    const SlamRectRegion & region,
    const rclcpp::Time & now,
    const geometry_msgs::msg::TransformStamped * region_to_map = nullptr) const;

  SlamRegionStats sampleCorridor(
    double start_x,
    double start_y,
    double end_x,
    double end_y,
    double width_m,
    const rclcpp::Time & now,
    const geometry_msgs::msg::TransformStamped * region_to_map = nullptr) const;

  SlamRegionStats sampleEdgeStrip(
    double tile_center_x,
    double tile_center_y,
    double tile_size_m,
    SlamCardinalDirection direction,
    double strip_length_m,
    double strip_width_m,
    const rclcpp::Time & now,
    const geometry_msgs::msg::TransformStamped * region_to_map = nullptr) const;

private:
  void analyzeMap();
  void rebuildClearanceField();
  bool mapRecent(const rclcpp::Time & now, double * age_sec = nullptr) const;
  bool clearanceRecent(const rclcpp::Time & now) const;
  bool worldToCell(double world_x, double world_y, int * cell_x, int * cell_y) const;
  void applyTransform(
    double x,
    double y,
    const geometry_msgs::msg::TransformStamped * transform,
    double * transformed_x,
    double * transformed_y) const;
  SlamRegionStats unavailableStats(const rclcpp::Time & now) const;
  void finalizeStats(SlamRegionStats * stats) const;

  SlamMapSamplerConfig config_;
  nav_msgs::msg::OccupancyGrid map_;
  rclcpp::Time received_at_;
  bool has_received_map_ = false;
  bool has_structurally_valid_map_ = false;
  bool static_map_real_ = false;
  std::string rejection_reason_ = "no_map";
  std::vector<double> clearance_m_;
  bool clearance_valid_ = false;
  int total_cells_ = 0;
  int known_cells_ = 0;
  int free_cells_ = 0;
  int occupied_cells_ = 0;
  int unknown_cells_ = 0;
};

}  // namespace ros2_mapper

#endif  // ROS2_MAPPER__SLAM_MAP_SAMPLER_HPP_
