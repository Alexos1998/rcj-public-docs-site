#ifndef ROS2_MAPPER__TILE_MAP_HPP_
#define ROS2_MAPPER__TILE_MAP_HPP_

#include "ros2_mapper/tile_semantics.hpp"
#include "ros2_mapper/tile_math.hpp"

#include <geometry_msgs/msg/point.hpp>
#include <rclcpp/time.hpp>

#include <cstddef>
#include <limits>
#include <unordered_map>

namespace ros2_mapper
{

struct TileRecord
{
  TileCoord coord;
  geometry_msgs::msg::Point center;
  bool visited;
  int visit_count;
  rclcpp::Time first_seen;
  rclcpp::Time last_seen;
  int marker_id;

  TileArea area = TileArea::Unknown;
  TileKind kind = TileKind::Unknown;
  FloorColorClass floor_color = FloorColorClass::Unknown;
  bool is_start = false;
  bool is_checkpoint = false;
  bool is_swamp = false;
  bool is_hole = false;
  bool has_black_hole_border = false;
  bool is_blocked = false;
  bool is_transition = false;
  bool has_obstacle = false;
  HazardState hazard_state = HazardState::None;
  HazardType hazard_type = HazardType::Unknown;
  HazardSource hazard_source = HazardSource::Unknown;
  HazardEdge hazard_edge = HazardEdge::Unknown;
  double hazard_confidence = 0.0;
  int hazard_hit_count = 0;
  int hazard_normal_hit_count = 0;
  double hazard_ttl_sec = 0.0;
  rclcpp::Time hazard_last_seen;
  double floor_color_center_distance_m = std::numeric_limits<double>::infinity();
  double floor_color_geometric_confidence = 0.0;
  TransitionInfo transition;
  EdgeWalls walls;
  EdgeWallStats wall_stats;

  // Future semantic extensions:
  // - 4x4 subcells for areas 2/3
  // - quarter-tile walls
  // - area 3 curves
  // - victims/targets attached to walls
  // - area 4 auxiliary metric representation
};

class TileMap
{
public:
  TileRecord & getOrCreateTile(
    TileCoord coord,
    geometry_msgs::msg::Point center,
    rclcpp::Time stamp);

  TileRecord & markVisited(
    TileCoord coord,
    geometry_msgs::msg::Point center,
    rclcpp::Time stamp);

  TileRecord & markStart(
    TileCoord coord,
    geometry_msgs::msg::Point center,
    rclcpp::Time stamp);

  WallState getWallState(TileCoord coord, WallDirection direction) const;
  int getWallVotes(TileCoord coord, WallDirection direction) const;

  void addWallVote(
    TileCoord coord,
    geometry_msgs::msg::Point center,
    WallDirection direction,
    rclcpp::Time stamp,
    int max_votes);

  void setWallState(
    TileCoord coord,
    geometry_msgs::msg::Point center,
    WallDirection direction,
    WallState state,
    rclcpp::Time stamp);

  bool hasTile(TileCoord coord) const;
  std::size_t visitedCount() const;

  const std::unordered_map<TileCoord, TileRecord, TileCoordHash> & records() const;

private:
  std::unordered_map<TileCoord, TileRecord, TileCoordHash> records_;
  int next_marker_id_ = 0;
};

}  // namespace ros2_mapper

#endif  // ROS2_MAPPER__TILE_MAP_HPP_
