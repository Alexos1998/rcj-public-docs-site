#pragma once

#include <cstddef>
#include <vector>

#include "nav_msgs/msg/occupancy_grid.hpp"

#include "ros2_exploration/frontier_types.hpp"

namespace ros2_exploration
{

class FrontierDetector
{
public:
  FrontierDetector(int occupied_threshold, std::size_t min_frontier_size);

  std::vector<Frontier> detect(const nav_msgs::msg::OccupancyGrid & map) const;

  void setOccupiedThreshold(int occupied_threshold);
  void setMinFrontierSize(std::size_t min_frontier_size);

private:
  bool isFrontierCell(const nav_msgs::msg::OccupancyGrid & map, const GridIndex & index) const;
  Frontier buildFrontier(
    const nav_msgs::msg::OccupancyGrid & map,
    const GridIndex & seed,
    std::vector<bool> & visited) const;

  int occupied_threshold_{65};
  std::size_t min_frontier_size_{3};
};

}  // namespace ros2_exploration
