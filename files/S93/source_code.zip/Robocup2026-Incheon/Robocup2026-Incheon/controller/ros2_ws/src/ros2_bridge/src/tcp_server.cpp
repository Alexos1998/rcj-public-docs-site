#include "ros2_bridge/tcp_server.hpp"

#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cerrno>
#include <cstring>
#include <sstream>
#include <utility>
#include <vector>

namespace ros2_bridge
{

namespace
{

std::string errnoMessage(const char * context)
{
  std::ostringstream oss;
  oss << context << ": " << std::strerror(errno);
  return oss.str();
}

}  // namespace

TcpServer::TcpServer(
  std::string host,
  int port,
  std::size_t max_line_bytes,
  std::size_t recv_buffer_bytes,
  LineCallback on_line,
  LogCallback on_info,
  LogCallback on_warn,
  LogCallback on_error,
  ConnectionCallback on_connect,
  DisconnectionCallback on_disconnect)
: host_(std::move(host)),
  port_(port),
  max_line_bytes_(max_line_bytes),
  recv_buffer_bytes_(recv_buffer_bytes),
  on_line_(std::move(on_line)),
  on_info_(std::move(on_info)),
  on_warn_(std::move(on_warn)),
  on_error_(std::move(on_error)),
  on_connect_(std::move(on_connect)),
  on_disconnect_(std::move(on_disconnect))
{
}

TcpServer::~TcpServer()
{
  stop();
}

void TcpServer::start()
{
  if (running_.exchange(true)) {
    return;
  }

  io_thread_ = std::thread(&TcpServer::acceptLoop, this);
}

void TcpServer::stop()
{
  if (!running_.exchange(false)) {
    return;
  }

  closeClient();
  closeServer();

  if (io_thread_.joinable()) {
    io_thread_.join();
  }
}

bool TcpServer::sendLine(const std::string & line)
{
  std::lock_guard<std::mutex> lock(socket_mutex_);

  if (client_fd_ < 0) {
    return false;
  }

  const char * data = line.data();
  std::size_t remaining = line.size();

  while (remaining > 0) {
#ifdef MSG_NOSIGNAL
    const ssize_t sent = send(client_fd_, data, remaining, MSG_NOSIGNAL);
#else
    const ssize_t sent = send(client_fd_, data, remaining, 0);
#endif
    if (sent <= 0) {
      return false;
    }

    data += sent;
    remaining -= static_cast<std::size_t>(sent);
  }

  return true;
}

bool TcpServer::connected() const
{
  return connected_.load();
}

void TcpServer::acceptLoop()
{
  server_fd_ = socket(AF_INET, SOCK_STREAM, 0);
  if (server_fd_ < 0) {
    on_error_(errnoMessage("Failed to create TCP server socket"));
    running_ = false;
    return;
  }

  int opt = 1;
  if (setsockopt(server_fd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
    on_warn_(errnoMessage("Failed to set SO_REUSEADDR"));
  }

  sockaddr_in addr{};
  addr.sin_family = AF_INET;
  addr.sin_port = htons(static_cast<uint16_t>(port_));

  if (inet_pton(AF_INET, host_.c_str(), &addr.sin_addr) != 1) {
    on_error_("Invalid TCP bind host: " + host_);
    closeServer();
    running_ = false;
    return;
  }

  if (bind(server_fd_, reinterpret_cast<sockaddr *>(&addr), sizeof(addr)) < 0) {
    on_error_(errnoMessage("Failed to bind TCP server"));
    closeServer();
    running_ = false;
    return;
  }

  if (listen(server_fd_, 4) < 0) {
    on_error_(errnoMessage("Failed to listen on TCP server"));
    closeServer();
    running_ = false;
    return;
  }

  {
    std::ostringstream oss;
    oss << "ros2_bridge TCP server listening on " << host_ << ":" << port_;
    on_info_(oss.str());
  }

  while (running_) {
    sockaddr_in client_addr{};
    socklen_t client_len = sizeof(client_addr);
    const int accepted_fd =
      accept(server_fd_, reinterpret_cast<sockaddr *>(&client_addr), &client_len);

    if (accepted_fd < 0) {
      if (running_) {
        on_warn_(errnoMessage("TCP accept failed"));
      }
      continue;
    }

    int tcp_nodelay = 1;
    if (setsockopt(accepted_fd, IPPROTO_TCP, TCP_NODELAY, &tcp_nodelay, sizeof(tcp_nodelay)) < 0) {
      on_warn_(errnoMessage("Failed to set TCP_NODELAY on accepted TCP client"));
    }

    {
      std::lock_guard<std::mutex> lock(socket_mutex_);
      if (client_fd_ >= 0) {
        close(client_fd_);
      }
      client_fd_ = accepted_fd;
      connected_ = true;
    }

    char client_ip[INET_ADDRSTRLEN] = {};
    inet_ntop(AF_INET, &client_addr.sin_addr, client_ip, sizeof(client_ip));
    std::ostringstream remote;
    remote << client_ip << ":" << ntohs(client_addr.sin_port);
    on_info_(std::string("Webots TCP client connected from ") + remote.str());
    if (on_connect_) {
      on_connect_(remote.str());
    }

    readClient(accepted_fd);
    const bool report_disconnect = running_.load();
    closeClient();
    if (report_disconnect && on_disconnect_) {
      on_disconnect_();
    }
    on_info_("Webots TCP client disconnected");
  }

  closeServer();
}

void TcpServer::readClient(int client_fd)
{
  std::vector<char> recv_buffer(recv_buffer_bytes_);
  std::string rx_buffer;

  while (running_) {
    const ssize_t received = recv(client_fd, recv_buffer.data(), recv_buffer.size(), 0);

    if (received <= 0) {
      break;
    }

    rx_buffer.append(recv_buffer.data(), static_cast<std::size_t>(received));

    if (rx_buffer.size() > max_line_bytes_) {
      on_warn_("TCP receive buffer exceeded max_line_bytes; dropping buffered data");
      rx_buffer.clear();
      continue;
    }

    std::size_t newline_pos = std::string::npos;
    while ((newline_pos = rx_buffer.find('\n')) != std::string::npos) {
      std::string line = rx_buffer.substr(0, newline_pos);
      rx_buffer.erase(0, newline_pos + 1);

      if (!line.empty() && line.back() == '\r') {
        line.pop_back();
      }

      if (line.size() > max_line_bytes_) {
        on_warn_("Dropping TCP line exceeding max_line_bytes");
        continue;
      }

      if (!line.empty()) {
        on_line_(line);
      }
    }
  }
}

void TcpServer::closeClient()
{
  std::lock_guard<std::mutex> lock(socket_mutex_);

  if (client_fd_ >= 0) {
    shutdown(client_fd_, SHUT_RDWR);
    close(client_fd_);
    client_fd_ = -1;
  }

  connected_ = false;
}

void TcpServer::closeServer()
{
  std::lock_guard<std::mutex> lock(socket_mutex_);

  if (server_fd_ >= 0) {
    shutdown(server_fd_, SHUT_RDWR);
    close(server_fd_);
    server_fd_ = -1;
  }
}

const std::string & TcpServer::host() const
{
  return host_;
}

int TcpServer::port() const
{
  return port_;
}

}  // namespace ros2_bridge
