#include "ros2_mapper/map_geometry_models.hpp"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <utility>
#include <vector>

namespace ros2_mapper
{

namespace
{
constexpr int kFreeThresh = 25;    // cell <= 25 -> free
constexpr int kOccThresh = 65;     // cell >= 65 -> occupied
constexpr int kNumFeatures = 31;   // patch_features() -> explored model

// Subtile occupies fraction [SUB_LO, SUB_HI] of the 0.12 m patch.
constexpr double kSubLo = 0.25;
constexpr double kSubHi = 0.75;

// Per-task margins/params (mirror map_features.py defaults + DEFAULT_MARGINS).
constexpr double kWallMargin = 0.08;
constexpr double kWallBand = 0.06;
constexpr double kWallSearch = 0.14;
constexpr double kCurveMargin = 0.10;
constexpr double kCurveCorner = 0.18;
constexpr double kCurveEdgeBand = 0.06;
constexpr double kObstacleMargin = 0.20;
constexpr int kCurvePolarNr = 6;
constexpr int kCurvePolarNa = 12;
constexpr double kPi = 3.14159265358979323846;

// Python int(round(x)): round half to even (numpy / built-in round semantics).
// std::nearbyint uses the default FE_TONEAREST rounding mode (ties-to-even).
int pyRound(double x)
{
  return static_cast<int>(std::nearbyint(x));
}

// _band(size, lo, hi) from map_dataset.py: [a, b) with a in [0,size-1], b>a.
std::pair<int, int> band(int size, double lo, double hi)
{
  int a = pyRound(lo * size);
  int b = pyRound(hi * size);
  a = std::max(0, std::min(a, size - 1));
  b = std::max(a + 1, std::min(b, size));
  return {a, b};
}

double occRatio(const cv::Mat & p, int r0, int r1, int c0, int c1)
{
  long occ = 0;
  const long n = static_cast<long>(r1 - r0) * (c1 - c0);
  for (int i = r0; i < r1; ++i) {
    for (int j = c0; j < c1; ++j) {
      occ += p.at<int16_t>(i, j) >= kOccThresh;
    }
  }
  return n > 0 ? static_cast<double>(occ) / n : 0.0;
}

double freeRatio(const cv::Mat & p, int r0, int r1, int c0, int c1)
{
  long fr = 0;
  const long n = static_cast<long>(r1 - r0) * (c1 - c0);
  for (int i = r0; i < r1; ++i) {
    for (int j = c0; j < c1; ++j) {
      const int16_t v = p.at<int16_t>(i, j);
      fr += (v >= 0 && v <= kFreeThresh);
    }
  }
  return n > 0 ? static_cast<double>(fr) / n : 0.0;
}

// np.gradient magnitude mean over the [r0,r1)x[c0,c1) sub-block of known :=
// (unk ? 0 : v/100). Central differences interior, one-sided at the sub-block
// borders. Returns 0 when the sub-block is thinner than 2 in either axis.
double gradMeanSub(const cv::Mat & p, int r0, int r1, int c0, int c1)
{
  const int h = r1 - r0;
  const int w = c1 - c0;
  if (std::min(h, w) < 2) {
    return 0.0;
  }
  std::vector<float> k(static_cast<std::size_t>(h) * w);
  for (int i = 0; i < h; ++i) {
    for (int j = 0; j < w; ++j) {
      const int16_t v = p.at<int16_t>(r0 + i, c0 + j);
      k[static_cast<std::size_t>(i) * w + j] = (v < 0) ? 0.0f : static_cast<float>(v) / 100.0f;
    }
  }
  const auto at = [&](int i, int j) {return k[static_cast<std::size_t>(i) * w + j];};
  double sum = 0.0;
  for (int i = 0; i < h; ++i) {
    for (int j = 0; j < w; ++j) {
      float gy;
      if (i == 0) {
        gy = at(1, j) - at(0, j);
      } else if (i == h - 1) {
        gy = at(h - 1, j) - at(h - 2, j);
      } else {
        gy = (at(i + 1, j) - at(i - 1, j)) * 0.5f;
      }
      float gx;
      if (j == 0) {
        gx = at(i, 1) - at(i, 0);
      } else if (j == w - 1) {
        gx = at(i, w - 1) - at(i, w - 2);
      } else {
        gx = (at(i, j + 1) - at(i, j - 1)) * 0.5f;
      }
      sum += std::sqrt(static_cast<double>(gx) * gx + static_cast<double>(gy) * gy);
    }
  }
  return sum / (static_cast<double>(h) * w);
}

bool loadOne(cv::Ptr<cv::ml::RTrees> & out, const std::string & path)
{
  out.reset();
  std::ifstream probe(path);
  if (!probe.good()) {
    return false;
  }
  try {
    out = cv::ml::RTrees::load(path);
  } catch (const cv::Exception &) {
    out.reset();
    return false;
  }
  return out && out->isTrained();
}
}  // namespace

bool MapGeometryModels::load(
  const std::string & explored_path,
  const std::string & wall_path,
  const std::string & curve_path,
  const std::string & obstacle_path)
{
  loaded_ =
    loadOne(explored_, explored_path) &&
    loadOne(wall_, wall_path) &&
    loadOne(curve_, curve_path) &&
    loadOne(obstacle_, obstacle_path);
  if (!loaded_) {
    explored_.reset();
    wall_.reset();
    curve_.reset();
    obstacle_.reset();
  }
  return loaded_;
}

cv::Mat MapGeometryModels::extractPatch(
  const int8_t * data, int width, int height,
  double resolution, double origin_x, double origin_y,
  double wx, double wy, double half_extent_m) const
{
  const double res = resolution > 0.0 ? resolution : 0.0033;

  const int col_c = static_cast<int>(std::lround((wx - origin_x) / res));
  const int row_c = static_cast<int>(std::lround((wy - origin_y) / res));
  const int hc = std::max(1, static_cast<int>(std::lround(half_extent_m / res)));
  const int size = 2 * hc + 1;

  // pre: grid row increases north -> row 0 here is the southern edge.
  cv::Mat pre(size, size, CV_16S, cv::Scalar(-1));
  for (int i = 0; i < size; ++i) {
    const int gr = row_c - hc + i;
    if (gr < 0 || gr >= height) {
      continue;
    }
    for (int j = 0; j < size; ++j) {
      const int gc = col_c - hc + j;
      if (gc < 0 || gc >= width) {
        continue;
      }
      pre.at<int16_t>(i, j) = static_cast<int16_t>(data[static_cast<std::size_t>(gr) * width + gc]);
    }
  }
  // Flip vertically so row 0 = north (matches Python sample_patch out[::-1]).
  cv::Mat patch;
  cv::flip(pre, patch, 0);
  return patch;
}

cv::Mat MapGeometryModels::rot90ccw(const cv::Mat & patch, int k)
{
  cv::Mat out = patch.clone();
  for (int i = 0; i < (k % 4 + 4) % 4; ++i) {
    // np.rot90(m, 1) == flipud(transpose(m)) for a square matrix.
    cv::Mat t;
    cv::transpose(out, t);
    cv::flip(t, out, 0);
  }
  return out;
}

cv::Mat MapGeometryModels::features(const cv::Mat & patch) const
{
  const int size = patch.rows;
  // Masks.
  const auto is_occ = [](int16_t v) {return v >= kOccThresh;};
  const auto is_free = [](int16_t v) {return v >= 0 && v <= kFreeThresh;};
  const auto is_unk = [](int16_t v) {return v < 0;};

  const int a = size / 3;
  const int b = size - a;
  const int rb[3][2] = {{0, a}, {a, b}, {b, size}};
  const int cb[3][2] = {{0, a}, {a, b}, {b, size}};

  std::vector<float> feats;
  feats.reserve(kNumFeatures);

  long occ_total = 0, free_total = 0, unk_total = 0;
  // 9 regions in order nw,n,ne,w,c,e,sw,s,se -> occ,free,unk ratio each.
  for (int r = 0; r < 3; ++r) {
    for (int c = 0; c < 3; ++c) {
      long occ = 0, fr = 0, unk = 0, n = 0;
      for (int i = rb[r][0]; i < rb[r][1]; ++i) {
        for (int j = cb[c][0]; j < cb[c][1]; ++j) {
          const int16_t v = patch.at<int16_t>(i, j);
          occ += is_occ(v);
          fr += is_free(v);
          unk += is_unk(v);
          ++n;
        }
      }
      const double d = n > 0 ? static_cast<double>(n) : 1.0;
      feats.push_back(static_cast<float>(occ / d));
      feats.push_back(static_cast<float>(fr / d));
      feats.push_back(static_cast<float>(unk / d));
    }
  }

  // Global ratios.
  for (int i = 0; i < size; ++i) {
    for (int j = 0; j < size; ++j) {
      const int16_t v = patch.at<int16_t>(i, j);
      occ_total += is_occ(v);
      free_total += is_free(v);
      unk_total += is_unk(v);
    }
  }
  const double total = static_cast<double>(size) * size;
  feats.push_back(static_cast<float>(occ_total / total));
  feats.push_back(static_cast<float>(free_total / total));
  feats.push_back(static_cast<float>(unk_total / total));

  // Gradient mean over known := (unk ? 0 : v/100), via np.gradient (central
  // differences interior, one-sided first order at the borders).
  cv::Mat known(size, size, CV_32F);
  for (int i = 0; i < size; ++i) {
    for (int j = 0; j < size; ++j) {
      const int16_t v = patch.at<int16_t>(i, j);
      known.at<float>(i, j) = (v < 0) ? 0.0f : static_cast<float>(v) / 100.0f;
    }
  }
  double grad_sum = 0.0;
  for (int i = 0; i < size; ++i) {
    for (int j = 0; j < size; ++j) {
      float gy;
      if (i == 0) {
        gy = known.at<float>(1, j) - known.at<float>(0, j);
      } else if (i == size - 1) {
        gy = known.at<float>(size - 1, j) - known.at<float>(size - 2, j);
      } else {
        gy = (known.at<float>(i + 1, j) - known.at<float>(i - 1, j)) * 0.5f;
      }
      float gx;
      if (j == 0) {
        gx = known.at<float>(i, 1) - known.at<float>(i, 0);
      } else if (j == size - 1) {
        gx = known.at<float>(i, size - 1) - known.at<float>(i, size - 2);
      } else {
        gx = (known.at<float>(i, j + 1) - known.at<float>(i, j - 1)) * 0.5f;
      }
      grad_sum += std::sqrt(static_cast<double>(gx) * gx + static_cast<double>(gy) * gy);
    }
  }
  feats.push_back(static_cast<float>(grad_sum / total));

  cv::Mat row(1, kNumFeatures, CV_32F);
  for (int i = 0; i < kNumFeatures; ++i) {
    row.at<float>(0, i) = feats[static_cast<std::size_t>(i)];
  }
  return row;
}

cv::Mat MapGeometryModels::wallFeatures(const cv::Mat & patch) const
{
  // Mirrors map_features.wall_features (margin 0.08, band 0.06, search 0.14):
  // a 1-D occupancy profile across the (north-rotated) edge -> peak height /
  // position / thickness / lateral coverage, plus inside/outside free, the
  // fixed-band occupancy and the edge gradient.
  const int s = patch.rows;
  const auto [c0, c1] = band(s, kSubLo + kWallMargin, kSubHi - kWallMargin);

  int r0 = pyRound((kSubLo - kWallSearch) * s);
  int r1 = pyRound((kSubLo + kWallSearch) * s);
  r0 = std::max(0, r0);
  r1 = std::min(s, r1);

  std::vector<double> prof;
  if (r1 > r0) {
    const double width = c1 - c0;
    for (int i = r0; i < r1; ++i) {
      long occ = 0;
      for (int j = c0; j < c1; ++j) {
        occ += patch.at<int16_t>(i, j) >= kOccThresh;
      }
      prof.push_back(static_cast<double>(occ) / width);
    }
  }
  if (prof.empty()) {
    prof.push_back(0.0);
  }

  double peak_occ = prof[0];
  int peak_i = 0;
  for (int k = 1; k < static_cast<int>(prof.size()); ++k) {
    if (prof[static_cast<std::size_t>(k)] > peak_occ) {   // first-max (np.argmax)
      peak_occ = prof[static_cast<std::size_t>(k)];
      peak_i = k;
    }
  }

  const double edge_row = kSubLo * s - r0;
  const double peak_pos = peak_i - edge_row;

  double thickness = 0.0;
  if (peak_occ > 0.0) {
    const double thr = std::max(peak_occ * 0.5, 0.05);
    for (double v : prof) {
      thickness += (v >= thr);
    }
  }

  const int peak_abs = r0 + peak_i;
  double lateral_cover = 0.0;
  if (peak_abs >= 0 && peak_abs < s) {
    long occ = 0;
    for (int j = c0; j < c1; ++j) {
      occ += patch.at<int16_t>(peak_abs, j) >= kOccThresh;
    }
    lateral_cover = static_cast<double>(occ) / (c1 - c0);
  }

  const auto [ir0, ir1] = band(s, kSubLo, kSubLo + kWallBand);
  const double inside = freeRatio(patch, ir0, ir1, c0, c1);
  const auto [our0, our1] = band(s, kSubLo - kWallBand, kSubLo);
  const double outside = freeRatio(patch, our0, our1, c0, c1);
  const auto [fr0, fr1] = band(s, kSubLo - kWallBand, kSubLo + kWallBand);
  const double fixed = occRatio(patch, fr0, fr1, c0, c1);
  const double grad = gradMeanSub(patch, fr0, fr1, c0, c1);

  cv::Mat row(1, 8, CV_32F);
  const double f[8] = {peak_occ, peak_pos, thickness, lateral_cover,
    inside, outside, fixed, grad};
  for (int i = 0; i < 8; ++i) {
    row.at<float>(0, i) = static_cast<float>(f[i]);
  }
  return row;
}

cv::Mat MapGeometryModels::curveFeatures(const cv::Mat & patch) const
{
  // Mirrors map_features.curve_features (margin 0.10, corner 0.18): occupancy
  // centroid offset + angle + radius, 4 corner boxes, 4 edge bands, center,
  // total, then a 6x12 polar occupancy grid (72 bins) = 87 features.
  const int s = patch.rows;
  const auto [sl0, sl1] = band(s, kSubLo, kSubHi);
  const int nb = sl1 - sl0;
  const double c = (nb - 1) / 2.0;

  double sumx = 0.0, sumy = 0.0;
  long n_occ = 0;
  for (int i = sl0; i < sl1; ++i) {
    for (int j = sl0; j < sl1; ++j) {
      if (patch.at<int16_t>(i, j) >= kOccThresh) {
        sumy += i - sl0;
        sumx += j - sl0;
        ++n_occ;
      }
    }
  }
  double cen_x = 0.0, cen_y = 0.0;
  if (n_occ >= 1) {
    const double denom = (c != 0.0) ? c : 1.0;
    cen_x = (sumx / n_occ - c) / denom;   // +east
    cen_y = (c - sumy / n_occ) / denom;   // +north
  }
  const double ang = std::atan2(cen_y, cen_x);
  const double radius = std::hypot(cen_x, cen_y);
  const double occ_total = static_cast<double>(n_occ) / (static_cast<double>(nb) * nb);

  const double lo = kSubLo, hi = kSubHi, m = kCurveMargin, cor = kCurveCorner;
  const auto occBox = [&](double r0, double r1, double c0, double c1) {
    const auto [a, b] = band(s, r0, r1);
    const auto [d, e] = band(s, c0, c1);
    return occRatio(patch, a, b, d, e);
  };
  const double corner_nw = occBox(lo + m, lo + m + cor, lo + m, lo + m + cor);
  const double corner_ne = occBox(lo + m, lo + m + cor, hi - m - cor, hi - m);
  const double corner_sw = occBox(hi - m - cor, hi - m, lo + m, lo + m + cor);
  const double corner_se = occBox(hi - m - cor, hi - m, hi - m - cor, hi - m);

  const auto [cs0, cs1] = band(s, lo, hi);
  const double eb = kCurveEdgeBand;
  const auto [n0, n1] = band(s, lo - eb, lo + eb);
  const auto [se0, se1] = band(s, hi - eb, hi + eb);
  const double edge_n = occRatio(patch, n0, n1, cs0, cs1);
  const double edge_e = occRatio(patch, cs0, cs1, se0, se1);
  const double edge_s = occRatio(patch, se0, se1, cs0, cs1);
  const double edge_w = occRatio(patch, cs0, cs1, n0, n1);
  const double center = occBox(0.4, 0.6, 0.4, 0.6);

  cv::Mat row(1, 15 + kCurvePolarNr * kCurvePolarNa, CV_32F);
  const double base[15] = {cen_x, cen_y, std::sin(ang), std::cos(ang), radius,
    corner_nw, corner_ne, corner_sw, corner_se,
    edge_n, edge_e, edge_s, edge_w, center, occ_total};
  for (int i = 0; i < 15; ++i) {
    row.at<float>(0, i) = static_cast<float>(base[i]);
  }

  // Polar occupancy: mean occupancy in a (radius x angle) grid centred on patch.
  const int nr = kCurvePolarNr, na = kCurvePolarNa;
  const double cc = (s - 1) / 2.0;
  std::vector<double> ssum(static_cast<std::size_t>(nr) * na, 0.0);
  std::vector<long> tot(static_cast<std::size_t>(nr) * na, 0);
  for (int i = 0; i < s; ++i) {
    for (int j = 0; j < s; ++j) {
      const double dy = cc - i;   // +north
      const double dx = j - cc;   // +east
      int r = static_cast<int>(std::hypot(dx, dy) / (s * 0.5) * nr);   // trunc
      r = std::max(0, std::min(r, nr - 1));
      int a = static_cast<int>((std::atan2(dy, dx) + kPi) / (2 * kPi) * na);
      a = std::max(0, std::min(a, na - 1));
      const std::size_t b = static_cast<std::size_t>(r) * na + a;
      ++tot[b];
      ssum[b] += (patch.at<int16_t>(i, j) >= kOccThresh) ? 1.0 : 0.0;
    }
  }
  for (int k = 0; k < nr * na; ++k) {
    const double v = tot[static_cast<std::size_t>(k)] > 0
      ? ssum[static_cast<std::size_t>(k)] / tot[static_cast<std::size_t>(k)] : 0.0;
    row.at<float>(0, 15 + k) = static_cast<float>(v);
  }
  return row;
}

cv::Mat MapGeometryModels::obstacleFeatures(const cv::Mat & patch) const
{
  // Mirrors map_features.obstacle_features (margin 0.20): interior occ/free/unk
  // ratios, central-square occupancy, occupied-centroid distance from interior
  // centre (blob_radius), bbox compactness, interior gradient.
  const int s = patch.rows;
  const auto [r0, r1] = band(s, kObstacleMargin, 1.0 - kObstacleMargin);
  const auto [c0, c1] = band(s, kObstacleMargin, 1.0 - kObstacleMargin);
  const int h = r1 - r0, w = c1 - c0;
  const long n = static_cast<long>(h) * w;

  long occ = 0, fr = 0, unk = 0, n_occ = 0;
  double sumx = 0.0, sumy = 0.0;
  int min_by = h, max_by = -1, min_bx = w, max_bx = -1;
  for (int i = r0; i < r1; ++i) {
    for (int j = c0; j < c1; ++j) {
      const int16_t v = patch.at<int16_t>(i, j);
      const bool is_occ = v >= kOccThresh;
      occ += is_occ;
      fr += (v >= 0 && v <= kFreeThresh);
      unk += (v < 0);
      if (is_occ) {
        const int by = i - r0, bx = j - c0;
        sumy += by;
        sumx += bx;
        min_by = std::min(min_by, by);
        max_by = std::max(max_by, by);
        min_bx = std::min(min_bx, bx);
        max_bx = std::max(max_bx, bx);
        ++n_occ;
      }
    }
  }
  const double interior_occ = n > 0 ? static_cast<double>(occ) / n : 0.0;
  const double interior_free = n > 0 ? static_cast<double>(fr) / n : 0.0;
  const double interior_unk = n > 0 ? static_cast<double>(unk) / n : 0.0;
  const double center_occ = occRatio(patch, band(s, 0.4, 0.6).first, band(s, 0.4, 0.6).second,
      band(s, 0.4, 0.6).first, band(s, 0.4, 0.6).second);

  double blob_radius = 0.0, compactness = 0.0;
  if (n_occ >= 1) {
    const double cy = (h - 1) / 2.0, cx = (w - 1) / 2.0;
    const double diag = std::hypot(cx, cy);
    blob_radius = std::hypot(sumx / n_occ - cx, sumy / n_occ - cy) / (diag != 0.0 ? diag : 1.0);
    const long bb = static_cast<long>(max_by - min_by + 1) * (max_bx - min_bx + 1);
    compactness = static_cast<double>(n_occ) / (bb != 0 ? bb : 1);
  }
  const double grad = gradMeanSub(patch, r0, r1, c0, c1);

  cv::Mat row(1, 7, CV_32F);
  const double f[7] = {interior_occ, interior_free, interior_unk, center_occ,
    blob_radius, compactness, grad};
  for (int i = 0; i < 7; ++i) {
    row.at<float>(0, i) = static_cast<float>(f[i]);
  }
  return row;
}

int MapGeometryModels::predictLabel(
  const cv::Ptr<cv::ml::RTrees> & model, const cv::Mat & feature_row) const
{
  const float r = model->predict(feature_row);
  return static_cast<int>(std::lround(r));
}

SubtileGeometryPrediction MapGeometryModels::predictSubtile(const cv::Mat & patch) const
{
  SubtileGeometryPrediction out;
  if (!loaded_ || patch.empty()) {
    return out;
  }
  out.explored = predictLabel(explored_, features(patch)) != 0;  // 31 patch_features
  if (!out.explored) {
    return out;  // gate: leave walls/curve at 0
  }
  for (int d = 0; d < 4; ++d) {
    out.walls[static_cast<std::size_t>(d)] =
      predictLabel(wall_, wallFeatures(rot90ccw(patch, d))) != 0;
  }
  out.curve_dir = predictLabel(curve_, curveFeatures(patch));
  return out;
}

bool MapGeometryModels::predictObstacle(const cv::Mat & tile_patch) const
{
  if (!loaded_ || tile_patch.empty()) {
    return false;
  }
  return predictLabel(obstacle_, obstacleFeatures(tile_patch)) != 0;
}

}  // namespace ros2_mapper
