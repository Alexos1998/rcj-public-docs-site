#pragma once

#include <array>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

namespace ros2_vision {

// Mask-first, ellipse-free target reading. The 5 concentric rings are sampled at
// fixed fractions of their own radius R(theta), so no perspective model is needed.
// Ring 0 is the innermost ring; the pattern reads center -> outer ("KRYGB").
// Ports notebooks/common/target_geometry.py + target_classification_radial.py.

struct TargetRadialConfig {
  int n_rays = 64;
  int samples_per_ring = 5;
  float min_ring_coverage = 0.15f;   // min fraction of in-frame samples per ring
  int black_value_max = 60;          // RGB max below which a pixel is black (K)
  bool refine_center = true;
  float refine_coarse_radius = 6.0f;
  float refine_coarse_step = 1.5f;
  float refine_fine_radius = 1.0f;
  float refine_fine_step = 0.34f;
};

struct RadialTargetResult {
  bool valid = false;                 // all 5 rings resolved to a color (no '?')
  cv::Point2f center{0.0f, 0.0f};
  std::array<std::string, 5> colors{{"?", "?", "?", "?", "?"}};
  std::string pattern = "?????";
  std::array<float, 5> ring_confidence{{0.0f, 0.0f, 0.0f, 0.0f, 0.0f}};
  float radial_coverage = 0.0f;
  cv::Rect visible_bbox;
  int mask_area_px = 0;
  int sum_value = 0;
  std::string class_name;             // F/P/C/O when the sum is valid, else ""
  bool sum_valid = false;
};

// Keep only the largest connected foreground component (input/255 mask, output 0/255).
cv::Mat cleanLargestComponent(const cv::Mat& mask);

// Robust ring center: circle fit on the non-border outer contour, then a small
// color-consistency refinement (uses bgr). Falls back to distance-transform /
// centroid for degenerate masks. Returns (x, y) in pixels.
cv::Point2f estimateTargetCenter(const cv::Mat& mask, const cv::Mat& bgr,
                                 const TargetRadialConfig& cfg = TargetRadialConfig());

// Cast n_rays rays from center to the target contour. rays[i] = distance (px);
// ray_valid[i] = the ray hit background before the image border and is long enough.
void extractRadialContour(const cv::Mat& mask, cv::Point2f center, int n_rays,
                          std::vector<float>& rays, std::vector<unsigned char>& ray_valid);

// Classify a single BGR pixel to "K"/"R"/"Y"/"G"/"B" (nearest prototype + black rule).
std::string classifyPixelColor(const cv::Vec3b& bgr_pixel, int black_value_max = 60);

// Read the 5 ring colors by proportional radial sampling of the RGB content.
RadialTargetResult classifyTargetRadial(const cv::Mat& bgr, const cv::Mat& mask,
                                        cv::Point2f center, const std::vector<float>& rays,
                                        const std::vector<unsigned char>& ray_valid,
                                        const TargetRadialConfig& cfg = TargetRadialConfig());

struct TargetSumDecode {
  bool valid = false;
  int sum_value = 0;
  std::string class_name;             // F/P/C/O
};

// K=-2, R=-1, Y=0, G=1, B=2; sum of all 5 rings -> 0:F 1:P 2:C 3:O (else invalid).
TargetSumDecode decodeTargetSum(const std::array<std::string, 5>& colors);

// Convenience: mask -> clean -> center -> rays -> radial colors -> sum/class.
RadialTargetResult decodeTargetFromMask(const cv::Mat& bgr, const cv::Mat& mask,
                                        const TargetRadialConfig& cfg = TargetRadialConfig());

}  // namespace ros2_vision
