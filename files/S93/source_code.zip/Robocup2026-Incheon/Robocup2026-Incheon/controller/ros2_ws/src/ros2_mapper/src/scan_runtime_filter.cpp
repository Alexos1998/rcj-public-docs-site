#include "ros2_mapper/scan_runtime_filter.hpp"

#include <chrono>
#include <sstream>

namespace ros2_mapper
{

using namespace std::chrono_literals;

ScanRuntimeFilter::ScanRuntimeFilter(const rclcpp::NodeOptions & options)
: Node("scan_runtime_filter", options)
{
  // QoS for subscribing to raw /scan from bridge.
  // Bridge publishes /scan as SensorDataQoS / best_effort / depth 1.
  // Subscriber must also be best_effort, otherwise ROS 2 reports:
  // "offering incompatible QoS ... RELIABILITY_QOS_POLICY".
  auto scan_sub_qos = rclcpp::SensorDataQoS();
  scan_sub_qos.keep_last(1);
  scan_sub_qos.best_effort();
  scan_sub_qos.durability_volatile();

  // QoS for publishing filtered scans for SLAM.
  // Keep this reliable for slam_toolbox compatibility, but depth 1 to avoid stale backlog.
  rclcpp::QoS scan_pub_qos(rclcpp::KeepLast(1));
  scan_pub_qos.reliable();
  scan_pub_qos.durability_volatile();

  // QoS for bridge ready notifications (transient_local + reliable)
  rclcpp::QoS ready_qos(rclcpp::KeepLast(1));
  ready_qos.reliable();
  ready_qos.transient_local();

  scan_pub_ = create_publisher<sensor_msgs::msg::LaserScan>("/scan_for_slam", scan_pub_qos);

  scan_sub_ = create_subscription<sensor_msgs::msg::LaserScan>(
    "/scan",
    scan_sub_qos,
    std::bind(&ScanRuntimeFilter::scanCallback, this, std::placeholders::_1));

  ready_sub_ = create_subscription<std_msgs::msg::String>(
    "/ros2_bridge/ready",
    ready_qos,
    std::bind(&ScanRuntimeFilter::readyCallback, this, std::placeholders::_1));

  RCLCPP_INFO(get_logger(), "scan_runtime_filter node started");
}

void ScanRuntimeFilter::logRobotEvent(
  const std::string & event,
  const std::vector<std::pair<std::string, std::string>> & fields) const
{
  std::ostringstream oss;
  oss << "ROBOT_EVENT node=scan_runtime_filter event=" << event;
  for (const auto & f : fields) {
    oss << ' ' << f.first << '=' << f.second;
  }
  RCLCPP_INFO(get_logger(), "%s", oss.str().c_str());
}

void ScanRuntimeFilter::readyCallback(const std_msgs::msg::String::SharedPtr msg)
{
  bool new_ready = false;
  uint64_t new_connection_id = 0;

  // Very small JSON parse to extract "ready": and "connection_id":
  const std::string & s = msg->data;
  auto found_ready = s.find("\"ready\":");
  if (found_ready != std::string::npos) {
    auto pos = found_ready + 8;
    while (pos < s.size() && isspace(static_cast<unsigned char>(s[pos]))) ++pos;
    if (s.compare(pos, 4, "true") == 0) {
      new_ready = true;
    }
  }
  auto found_conn = s.find("\"connection_id\":");
  if (found_conn != std::string::npos) {
    auto pos = found_conn + 16;
    while (pos < s.size() && (s[pos] == ' ' || s[pos] == '\t')) ++pos;
    // read integer
    uint64_t val = 0;
    bool have = false;
    while (pos < s.size() && isdigit(static_cast<unsigned char>(s[pos]))) {
      have = true;
      val = val * 10 + (s[pos] - '0');
      ++pos;
    }
    if (have) {
      new_connection_id = val;
    }
  }

  std::lock_guard<std::mutex> lock(mutex_);

  if (new_ready && (!ready_ || new_connection_id != connection_id_)) {
    // transition to ready
    ready_ = true;
    connection_id_ = new_connection_id;
    dropped_count_ = 0;
    first_scan_logged_ = false;
    logRobotEvent("scan_filter_ready", { {"ready", "true"}, {"connection_id", std::to_string(connection_id_)} });
  } else if (!new_ready && (ready_ || new_connection_id != connection_id_)) {
    // transition to not ready or connection change -> reset
    ready_ = false;
    connection_id_ = new_connection_id;
    dropped_count_ = 0;
    first_scan_logged_ = false;
    logRobotEvent("scan_filter_reset", { {"reason", "bridge_not_ready"} });
  }
}

void ScanRuntimeFilter::scanCallback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
{
  std::lock_guard<std::mutex> lock(mutex_);
  if (!ready_) {
    ++dropped_count_;
    // Throttled ROBOT_EVENT log every 5s
    static rclcpp::Clock steady_clock(RCL_STEADY_TIME);
    RCLCPP_INFO_THROTTLE(get_logger(), *get_clock(), 5000, "%s", (std::string("ROBOT_EVENT node=scan_runtime_filter event=scan_dropped_before_ready count=") + std::to_string(dropped_count_)).c_str());
    return;
  }

  // If ready, publish scan unchanged (preserve stamp, frame_id, ranges/intensities)
  scan_pub_->publish(*msg);

  if (!first_scan_logged_) {
    first_scan_logged_ = true;
    std::ostringstream ss;
    ss << msg->header.stamp.sec << "." << std::setw(9) << std::setfill('0') << msg->header.stamp.nanosec;
    logRobotEvent("first_scan_for_slam", { {"stamp", ss.str()} });
  }
}

}  // namespace ros2_mapper

// Register node for composition / launch
int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<ros2_mapper::ScanRuntimeFilter>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
