// Parity test: C++ map-geometry features + RTrees predictions vs the
// Python-exported reference (controller/models/map_parity_reference.yml).
//
//   test_map_geometry_models <models_dir>
//
// Validates that each MapGeometryModels feature set reproduces its Python
// counterpart (tol 1e-4) and that each exported .yml model predicts the same
// label C++-side as in Python:
//   explored -> features()        (patch_features, 31)
//   curve    -> curveFeatures()   (map_features.curve_features, 87)
//   wall     -> wallFeatures()    (map_features.wall_features, 8, rotated patch)
//   obstacle -> obstacleFeatures()(map_features.obstacle_features, 7)

#include <cstdio>
#include <string>

#include <opencv2/core.hpp>
#include <opencv2/ml.hpp>

#include "ros2_mapper/map_geometry_models.hpp"

namespace
{
using ros2_mapper::MapGeometryModels;

float maxAbsDiff(const cv::Mat & a, const cv::Mat & b)
{
  cv::Mat d;
  cv::absdiff(a.reshape(1, 1), b.reshape(1, 1), d);
  double mx = 0.0;
  cv::minMaxLoc(d, nullptr, &mx);
  return static_cast<float>(mx);
}

int predict(const cv::Ptr<cv::ml::RTrees> & m, const cv::Mat & feat)
{
  return static_cast<int>(std::lround(m->predict(feat)));
}
}  // namespace

int main(int argc, char ** argv)
{
  const std::string models_dir = argc > 1 ? argv[1] : "../../../models";
  const std::string ref_path = models_dir + "/map_parity_reference.yml";

  auto explored = cv::ml::RTrees::load(models_dir + "/map_explorado.yml");
  auto wall = cv::ml::RTrees::load(models_dir + "/map_parede.yml");
  auto curve = cv::ml::RTrees::load(models_dir + "/map_curva.yml");
  auto obstacle = cv::ml::RTrees::load(models_dir + "/map_obstaculo.yml");
  if (!explored || !wall || !curve || !obstacle) {
    std::fprintf(stderr, "FAIL: could not load map_*.yml from %s\n", models_dir.c_str());
    return 1;
  }

  cv::FileStorage fs(ref_path, cv::FileStorage::READ);
  if (!fs.isOpened()) {
    std::fprintf(stderr, "FAIL: could not open %s\n", ref_path.c_str());
    return 1;
  }

  MapGeometryModels mg;  // features()/rot90ccw() need no loaded models
  const int n_sub = static_cast<int>(fs["n_sub"]);
  const int n_tile = static_cast<int>(fs["n_tile"]);
  int failures = 0;
  float worst_feat = 0.0f;

  const auto checkFeat = [&](const char * tag, int i, const cv::Mat & got,
      const cv::Mat & ref) {
    const float diff = maxAbsDiff(got, ref);
    worst_feat = std::max(worst_feat, diff);
    if (diff > 1e-4f) {
      std::fprintf(stderr, "%s %d: feature diff %.6f > 1e-4\n", tag, i, diff);
      ++failures;
    }
  };

  for (int i = 0; i < n_sub; ++i) {
    const std::string p = "sub_" + std::to_string(i) + "_";
    cv::Mat patch, ref_efeat, ref_cfeat, ref_wfeat, ref_walls;
    fs[p + "patch"] >> patch;
    fs[p + "efeat"] >> ref_efeat;   // explored features (31)
    fs[p + "cfeat"] >> ref_cfeat;   // curve features (87)
    fs[p + "wfeat"] >> ref_wfeat;   // wall features per dir (4 x 8)
    fs[p + "walls"] >> ref_walls;
    const int ref_explored = static_cast<int>(fs[p + "explored"]);
    const int ref_curve = static_cast<int>(fs[p + "curve"]);
    patch.convertTo(patch, CV_16S);

    const cv::Mat efeat = mg.features(patch);
    checkFeat("sub explored", i, efeat, ref_efeat);
    if (predict(explored, efeat) != ref_explored) {
      std::fprintf(stderr, "sub %d: explored mismatch\n", i);
      ++failures;
    }

    const cv::Mat cfeat = mg.curveFeatures(patch);
    checkFeat("sub curve", i, cfeat, ref_cfeat);
    if (predict(curve, cfeat) != ref_curve) {
      std::fprintf(stderr, "sub %d: curve mismatch\n", i);
      ++failures;
    }

    for (int d = 0; d < 4; ++d) {
      const cv::Mat wfeat = mg.wallFeatures(MapGeometryModels::rot90ccw(patch, d));
      checkFeat("sub wall", i, wfeat, ref_wfeat.row(d));
      const int got = predict(wall, wfeat);
      if (got != ref_walls.at<int>(0, d)) {
        std::fprintf(stderr, "sub %d: wall[%d] mismatch (got %d want %d)\n",
          i, d, got, ref_walls.at<int>(0, d));
        ++failures;
      }
    }
  }

  for (int i = 0; i < n_tile; ++i) {
    const std::string p = "tile_" + std::to_string(i) + "_";
    cv::Mat patch, ref_ofeat;
    fs[p + "patch"] >> patch;
    fs[p + "ofeat"] >> ref_ofeat;   // obstacle features (7)
    const int ref_obstacle = static_cast<int>(fs[p + "obstacle"]);
    patch.convertTo(patch, CV_16S);

    const cv::Mat ofeat = mg.obstacleFeatures(patch);
    checkFeat("tile obstacle", i, ofeat, ref_ofeat);
    if (predict(obstacle, ofeat) != ref_obstacle) {
      std::fprintf(stderr, "tile %d: obstacle mismatch\n", i);
      ++failures;
    }
  }

  std::printf("map geometry parity: %d subtiles + %d tiles, worst feature diff %.2e, %d failures\n",
    n_sub, n_tile, worst_feat, failures);
  return failures == 0 ? 0 : 1;
}
