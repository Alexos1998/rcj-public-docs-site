#include "ros2_exploration/explorer_node.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <exception>
#include <functional>
#include <limits>
#include <optional>
#include <queue>
#include <sstream>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

#include "tf2/exceptions.h"
#include "tf2/time.h"

namespace ros2_exploration
{

using namespace std::chrono_literals;

namespace
{


bool worldToMapCell(
  const nav_msgs::msg::OccupancyGrid & grid,
  double wx,
  double wy,
  int & mx,
  int & my)
{
  const double resolution = grid.info.resolution;
  if (resolution <= 0.0 || grid.info.width == 0 || grid.info.height == 0) {
    return false;
  }

  const double origin_x = grid.info.origin.position.x;
  const double origin_y = grid.info.origin.position.y;
  mx = static_cast<int>(std::floor((wx - origin_x) / resolution));
  my = static_cast<int>(std::floor((wy - origin_y) / resolution));

  return mx >= 0 && my >= 0 &&
         mx < static_cast<int>(grid.info.width) &&
         my < static_cast<int>(grid.info.height);
}

std::optional<int8_t> gridValueAt(
  const nav_msgs::msg::OccupancyGrid & grid,
  int mx,
  int my)
{
  if (mx < 0 || my < 0 ||
    mx >= static_cast<int>(grid.info.width) ||
    my >= static_cast<int>(grid.info.height))
  {
    return std::nullopt;
  }

  const std::size_t index =
    static_cast<std::size_t>(my) * static_cast<std::size_t>(grid.info.width) +
    static_cast<std::size_t>(mx);
  if (index >= grid.data.size()) {
    return std::nullopt;
  }

  return grid.data[index];
}

bool gridValueBlocked(
  const nav_msgs::msg::OccupancyGrid & grid,
  double wx,
  double wy,
  int occ_threshold,
  bool unknown_is_blocked)
{
  int mx = 0;
  int my = 0;
  if (!worldToMapCell(grid, wx, wy, mx, my)) {
    return true;
  }

  const std::optional<int8_t> value = gridValueAt(grid, mx, my);
  if (!value.has_value()) {
    return true;
  }
  if (*value < 0) {
    return unknown_is_blocked;
  }

  return static_cast<int>(*value) >= occ_threshold;
}

std::string quoteDebugValue(std::string value)
{
  for (char & ch : value) {
    if (ch == ' ' || ch == '"' || ch == '\n' || ch == '\t') {
      ch = '_';
    }
  }
  return value;
}

struct TileGraphCell
{
  int x{0};
  int y{0};
};

bool operator==(const TileGraphCell & lhs, const TileGraphCell & rhs)
{
  return lhs.x == rhs.x && lhs.y == rhs.y;
}

bool operator!=(const TileGraphCell & lhs, const TileGraphCell & rhs)
{
  return !(lhs == rhs);
}

int graphIndex(int width, const TileGraphCell & cell)
{
  return cell.y * width + cell.x;
}

std::optional<TileGraphCell> worldToTileGraphCell(
  const nav_msgs::msg::OccupancyGrid & costmap,
  double step_m,
  const geometry_msgs::msg::Point & point)
{
  if (step_m <= 0.0 || costmap.info.resolution <= 0.0 ||
    costmap.info.width == 0 || costmap.info.height == 0)
  {
    return std::nullopt;
  }

  const double width_m = static_cast<double>(costmap.info.width) * costmap.info.resolution;
  const double height_m = static_cast<double>(costmap.info.height) * costmap.info.resolution;
  const int graph_width = std::max(1, static_cast<int>(std::ceil(width_m / step_m)));
  const int graph_height = std::max(1, static_cast<int>(std::ceil(height_m / step_m)));
  const double origin_x = costmap.info.origin.position.x;
  const double origin_y = costmap.info.origin.position.y;

  const int x = static_cast<int>(std::llround((point.x - origin_x) / step_m));
  const int y = static_cast<int>(std::llround((point.y - origin_y) / step_m));
  if (x < 0 || y < 0 || x >= graph_width || y >= graph_height) {
    return std::nullopt;
  }
  return TileGraphCell{x, y};
}

geometry_msgs::msg::Point tileGraphCellCenter(
  const nav_msgs::msg::OccupancyGrid & costmap,
  double step_m,
  const TileGraphCell & cell)
{
  geometry_msgs::msg::Point point;
  point.x = costmap.info.origin.position.x + static_cast<double>(cell.x) * step_m;
  point.y = costmap.info.origin.position.y + static_cast<double>(cell.y) * step_m;
  point.z = 0.0;
  return point;
}

bool graphPointFree(
  const nav_msgs::msg::OccupancyGrid & costmap,
  const geometry_msgs::msg::Point & point,
  int occ_threshold)
{
  return !gridValueBlocked(costmap, point.x, point.y, occ_threshold, true);
}

bool graphCellFree(
  const nav_msgs::msg::OccupancyGrid & costmap,
  double step_m,
  const TileGraphCell & cell,
  int occ_threshold)
{
  return graphPointFree(
    costmap,
    tileGraphCellCenter(costmap, step_m, cell),
    occ_threshold);
}

bool graphEdgeFree(
  const nav_msgs::msg::OccupancyGrid & costmap,
  double step_m,
  const TileGraphCell & from,
  const TileGraphCell & to,
  int occ_threshold)
{
  const geometry_msgs::msg::Point a = tileGraphCellCenter(costmap, step_m, from);
  const geometry_msgs::msg::Point b = tileGraphCellCenter(costmap, step_m, to);
  geometry_msgs::msg::Point mid;
  mid.x = 0.5 * (a.x + b.x);
  mid.y = 0.5 * (a.y + b.y);
  if (!graphPointFree(costmap, a, occ_threshold) ||
    !graphPointFree(costmap, mid, occ_threshold) ||
    !graphPointFree(costmap, b, occ_threshold))
  {
    return false;
  }

  const int dx = to.x - from.x;
  const int dy = to.y - from.y;
  if (std::abs(dx) == 1 && std::abs(dy) == 1) {
    const TileGraphCell side_a{from.x + dx, from.y};
    const TileGraphCell side_b{from.x, from.y + dy};
    return graphCellFree(costmap, step_m, side_a, occ_threshold) &&
           graphCellFree(costmap, step_m, side_b, occ_threshold);
  }
  return true;
}

std::vector<TileGraphCell> graphNeighbors(
  const nav_msgs::msg::OccupancyGrid & costmap,
  double step_m,
  const TileGraphCell & cell,
  bool allow_diagonal,
  int occ_threshold)
{
  const double width_m = static_cast<double>(costmap.info.width) * costmap.info.resolution;
  const double height_m = static_cast<double>(costmap.info.height) * costmap.info.resolution;
  const int graph_width = std::max(1, static_cast<int>(std::ceil(width_m / step_m)));
  const int graph_height = std::max(1, static_cast<int>(std::ceil(height_m / step_m)));

  const std::vector<TileGraphCell> offsets = allow_diagonal
    ? std::vector<TileGraphCell>{{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {-1, 1}, {1, -1}, {-1, -1}}
    : std::vector<TileGraphCell>{{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

  std::vector<TileGraphCell> out;
  for (const auto & offset : offsets) {
    const TileGraphCell next{cell.x + offset.x, cell.y + offset.y};
    if (next.x < 0 || next.y < 0 || next.x >= graph_width || next.y >= graph_height) {
      continue;
    }
    if (!graphCellFree(costmap, step_m, next, occ_threshold)) {
      continue;
    }
    if (!graphEdgeFree(costmap, step_m, cell, next, occ_threshold)) {
      continue;
    }
    out.push_back(next);
  }
  return out;
}

std::vector<geometry_msgs::msg::Point> graphPathToGoal(
  const nav_msgs::msg::OccupancyGrid & costmap,
  double step_m,
  bool allow_diagonal,
  int occ_threshold,
  const geometry_msgs::msg::Pose & current_pose,
  const geometry_msgs::msg::Point & goal_point)
{
  const auto start_cell = worldToTileGraphCell(costmap, step_m, current_pose.position);
  const auto goal_cell = worldToTileGraphCell(costmap, step_m, goal_point);
  if (!start_cell.has_value() || !goal_cell.has_value()) {
    return {};
  }
  if (!graphCellFree(costmap, step_m, *start_cell, occ_threshold) ||
    !graphCellFree(costmap, step_m, *goal_cell, occ_threshold))
  {
    return {};
  }

  const double width_m = static_cast<double>(costmap.info.width) * costmap.info.resolution;
  const double height_m = static_cast<double>(costmap.info.height) * costmap.info.resolution;
  const int graph_width = std::max(1, static_cast<int>(std::ceil(width_m / step_m)));
  const int graph_height = std::max(1, static_cast<int>(std::ceil(height_m / step_m)));
  const int total = graph_width * graph_height;

  std::vector<double> dist(static_cast<std::size_t>(total), std::numeric_limits<double>::infinity());
  std::vector<TileGraphCell> parent(static_cast<std::size_t>(total), TileGraphCell{-1, -1});

  using QueueNode = std::tuple<double, int, int>;
  std::priority_queue<QueueNode, std::vector<QueueNode>, std::greater<QueueNode>> queue;

  const int start_index = graphIndex(graph_width, *start_cell);
  dist[static_cast<std::size_t>(start_index)] = 0.0;
  queue.push({0.0, start_cell->x, start_cell->y});

  while (!queue.empty()) {
    const auto [d, x, y] = queue.top();
    queue.pop();
    const TileGraphCell cell{x, y};
    const int index = graphIndex(graph_width, cell);
    if (d > dist[static_cast<std::size_t>(index)]) {
      continue;
    }
    if (cell == *goal_cell) {
      break;
    }

    for (const auto & next : graphNeighbors(
        costmap, step_m, cell, allow_diagonal, occ_threshold))
    {
      const int next_index = graphIndex(graph_width, next);
      const double step = std::hypot(
        static_cast<double>(next.x - cell.x),
        static_cast<double>(next.y - cell.y));
      const double nd = d + step;
      if (nd < dist[static_cast<std::size_t>(next_index)]) {
        dist[static_cast<std::size_t>(next_index)] = nd;
        parent[static_cast<std::size_t>(next_index)] = cell;
        queue.push({nd, next.x, next.y});
      }
    }
  }

  const int goal_index = graphIndex(graph_width, *goal_cell);
  if (!std::isfinite(dist[static_cast<std::size_t>(goal_index)])) {
    return {};
  }

  std::vector<TileGraphCell> reversed;
  TileGraphCell cell = *goal_cell;
  int guard = total;
  while (cell != *start_cell && guard-- > 0) {
    reversed.push_back(cell);
    const TileGraphCell p = parent[static_cast<std::size_t>(graphIndex(graph_width, cell))];
    if (p.x < 0 || p.y < 0) {
      return {};
    }
    cell = p;
  }
  reversed.push_back(*start_cell);
  std::reverse(reversed.begin(), reversed.end());

  std::vector<geometry_msgs::msg::Point> path;
  path.reserve(reversed.size());
  for (const auto & c : reversed) {
    geometry_msgs::msg::Point point = tileGraphCellCenter(costmap, step_m, c);
    point.z = 0.12;
    path.push_back(point);
  }
  return path;
}

bool pointInsideCostmap(
  const nav_msgs::msg::OccupancyGrid & costmap,
  const geometry_msgs::msg::Point & point)
{
  int mx = 0;
  int my = 0;
  return worldToMapCell(costmap, point.x, point.y, mx, my);
}

geometry_msgs::msg::Point priorityTileCenterPoint(
  const nav_msgs::msg::OccupancyGrid & costmap,
  double priority_tile_size_m,
  int x,
  int y)
{
  geometry_msgs::msg::Point point;
  point.x = costmap.info.origin.position.x + static_cast<double>(x) * priority_tile_size_m;
  point.y = costmap.info.origin.position.y + static_cast<double>(y) * priority_tile_size_m;
  point.z = 0.0;
  return point;
}

std::optional<geometry_msgs::msg::Point> nearestReachablePriorityTileCenter(
  const nav_msgs::msg::OccupancyGrid & costmap,
  double graph_step_m,
  double priority_tile_size_m,
  bool allow_diagonal,
  int occ_threshold,
  const geometry_msgs::msg::Pose & current_pose,
  const geometry_msgs::msg::Point & desired_point)
{
  if (graph_step_m <= 0.0 || priority_tile_size_m <= 0.0) {
    return std::nullopt;
  }

  const double origin_x = costmap.info.origin.position.x;
  const double origin_y = costmap.info.origin.position.y;
  const int desired_x =
    static_cast<int>(std::llround((desired_point.x - origin_x) / priority_tile_size_m));
  const int desired_y =
    static_cast<int>(std::llround((desired_point.y - origin_y) / priority_tile_size_m));

  struct CandidateCenter
  {
    double score{0.0};
    geometry_msgs::msg::Point point;
  };

  std::vector<CandidateCenter> centers;
  constexpr int kSearchRadiusTiles = 4;
  centers.reserve((kSearchRadiusTiles * 2 + 1) * (kSearchRadiusTiles * 2 + 1));
  for (int dy = -kSearchRadiusTiles; dy <= kSearchRadiusTiles; ++dy) {
    for (int dx = -kSearchRadiusTiles; dx <= kSearchRadiusTiles; ++dx) {
      geometry_msgs::msg::Point point =
        priorityTileCenterPoint(costmap, priority_tile_size_m, desired_x + dx, desired_y + dy);
      if (!pointInsideCostmap(costmap, point)) {
        continue;
      }
      if (!graphPointFree(costmap, point, occ_threshold)) {
        continue;
      }
      const double desired_distance =
        std::hypot(point.x - desired_point.x, point.y - desired_point.y);
      const double robot_distance =
        std::hypot(point.x - current_pose.position.x, point.y - current_pose.position.y);
      centers.push_back(CandidateCenter{desired_distance + 0.05 * robot_distance, point});
    }
  }

  std::sort(
    centers.begin(),
    centers.end(),
    [](const CandidateCenter & lhs, const CandidateCenter & rhs) {
      return lhs.score < rhs.score;
    });

  constexpr std::size_t kMaxReachabilityChecks = 16;
  std::size_t checked = 0;
  for (const auto & center : centers) {
    if (checked++ >= kMaxReachabilityChecks) {
      break;
    }
    const auto path = graphPathToGoal(
      costmap,
      graph_step_m,
      allow_diagonal,
      occ_threshold,
      current_pose,
      center.point);
    if (!path.empty()) {
      return center.point;
    }
  }

  return std::nullopt;
}


double pointDistance2d(
  const geometry_msgs::msg::Point & lhs,
  const geometry_msgs::msg::Point & rhs)
{
  return std::hypot(lhs.x - rhs.x, lhs.y - rhs.y);
}

double poseDistance2d(
  const geometry_msgs::msg::Pose & lhs,
  const geometry_msgs::msg::Pose & rhs)
{
  return std::hypot(lhs.position.x - rhs.position.x, lhs.position.y - rhs.position.y);
}

double secondsSince(const rclcpp::Time & start, const rclcpp::Time & now)
{
  if (start.nanoseconds() == 0 || now <= start) {
    return 0.0;
  }
  return (now - start).seconds();
}

geometry_msgs::msg::Quaternion yawToQuaternion(double yaw)
{
  geometry_msgs::msg::Quaternion orientation;
  orientation.z = std::sin(yaw * 0.5);
  orientation.w = std::cos(yaw * 0.5);
  return orientation;
}

void setMarkerLifetime(visualization_msgs::msg::Marker & marker)
{
  marker.lifetime.sec = 1;
  marker.lifetime.nanosec = 0;
}

std::string resultCodeToString(rclcpp_action::ResultCode code)
{
  switch (code) {
    case rclcpp_action::ResultCode::SUCCEEDED:
      return "succeeded";
    case rclcpp_action::ResultCode::ABORTED:
      return "aborted";
    case rclcpp_action::ResultCode::CANCELED:
      return "canceled";
    case rclcpp_action::ResultCode::UNKNOWN:
    default:
      return "unknown";
  }
}

std::string resultFailureReason(rclcpp_action::ResultCode code)
{
  switch (code) {
    case rclcpp_action::ResultCode::ABORTED:
      return "nav2_aborted";
    case rclcpp_action::ResultCode::CANCELED:
      return "nav2_canceled";
    case rclcpp_action::ResultCode::UNKNOWN:
      return "nav2_aborted";
    case rclcpp_action::ResultCode::SUCCEEDED:
    default:
      return {};
  }
}

}  // namespace

ExplorerNode::ExplorerNode(const rclcpp::NodeOptions & options)
: rclcpp::Node("ros2_explorer", options),
  tf_buffer_(this->get_clock()),
  tf_listener_(tf_buffer_)
{
  declareParameters();
  readParameters();
  configureHelpers();

  semantic_layer_.setEnabled(params_.semantic_scoring_enabled);

  debug_pub_ = this->create_publisher<std_msgs::msg::String>(params_.debug_topic, 10);
  frontiers_pub_ =
    this->create_publisher<visualization_msgs::msg::MarkerArray>(params_.frontiers_topic, 10);
  graph_pub_ =
    this->create_publisher<visualization_msgs::msg::MarkerArray>(params_.graph_topic, 10);
  selected_goal_pub_ =
    this->create_publisher<geometry_msgs::msg::PoseStamped>(params_.selected_goal_topic, 10);

  map_sub_ = this->create_subscription<nav_msgs::msg::OccupancyGrid>(
    params_.map_topic,
    rclcpp::QoS(1).transient_local().reliable(),
    std::bind(&ExplorerNode::onMap, this, std::placeholders::_1));

  global_costmap_sub_ = this->create_subscription<nav_msgs::msg::OccupancyGrid>(
    params_.global_costmap_topic,
    rclcpp::QoS(1).reliable(),
    std::bind(&ExplorerNode::onGlobalCostmap, this, std::placeholders::_1));

  local_costmap_sub_ = this->create_subscription<nav_msgs::msg::OccupancyGrid>(
    params_.local_costmap_topic,
    rclcpp::QoS(1).reliable(),
    std::bind(&ExplorerNode::onLocalCostmap, this, std::placeholders::_1));

  odom_sub_ = this->create_subscription<nav_msgs::msg::Odometry>(
    params_.odom_topic,
    rclcpp::SensorDataQoS(),
    std::bind(&ExplorerNode::onOdom, this, std::placeholders::_1));

  nav2_goal_manager_ = std::make_unique<Nav2GoalManager>(this, params_.navigate_to_pose_action);

  const double safe_period_s = std::max(0.1, params_.replan_period_s);
  timer_ = this->create_wall_timer(
    std::chrono::duration_cast<std::chrono::milliseconds>(
      std::chrono::duration<double>(safe_period_s)),
    std::bind(&ExplorerNode::onTimer, this));

  logStartupParameters();
  RCLCPP_INFO(
    this->get_logger(),
    "ros2_explorer started; Nav2 NavigateToPose action client created for '%s'.",
    params_.navigate_to_pose_action.c_str());
}

void ExplorerNode::declareParameters()
{
  this->declare_parameter<std::string>("map_topic", params_.map_topic);
  this->declare_parameter<std::string>("global_costmap_topic", params_.global_costmap_topic);
  this->declare_parameter<std::string>("local_costmap_topic", params_.local_costmap_topic);
  this->declare_parameter<std::string>("odom_topic", params_.odom_topic);
  this->declare_parameter<std::string>("debug_topic", params_.debug_topic);
  this->declare_parameter<std::string>("frontiers_topic", params_.frontiers_topic);
  this->declare_parameter<std::string>("graph_topic", params_.graph_topic);
  this->declare_parameter<std::string>("selected_goal_topic", params_.selected_goal_topic);
  this->declare_parameter<std::string>("navigate_to_pose_action", params_.navigate_to_pose_action);
  this->declare_parameter<std::string>("global_frame", params_.global_frame);
  this->declare_parameter<std::string>("robot_frame", params_.robot_frame);
  this->declare_parameter<double>("transform_timeout_s", params_.transform_timeout_s);
  this->declare_parameter<bool>("autostart", params_.autostart);

  this->declare_parameter<double>("timing.replan_period_s", params_.replan_period_s);
  this->declare_parameter<double>("timing.goal_timeout_s", params_.goal_timeout_s);
  this->declare_parameter<double>("timing.stuck_timeout_s", params_.stuck_timeout_s);
  this->declare_parameter<double>("timing.post_goal_settle_s", params_.post_goal_settle_s);
  this->declare_parameter<double>("map.geometry_settle_s", params_.map_geometry_settle_s);

  this->declare_parameter<int>("frontier.occ_threshold", params_.frontier_occ_threshold);
  this->declare_parameter<int>("frontier.min_frontier_size_cells", params_.min_frontier_size_cells);
  this->declare_parameter<double>(
    "frontier.candidate_min_goal_distance_m",
    params_.candidate_min_goal_distance_m);
  this->declare_parameter<double>("frontier.min_goal_distance_m", params_.min_goal_distance_m);
  this->declare_parameter<double>("frontier.max_goal_distance_m", params_.max_goal_distance_m);
  this->declare_parameter<double>(
    "frontier.duplicate_goal_radius_m",
    params_.duplicate_goal_radius_m);

  this->declare_parameter<double>("scoring.information_gain", params_.information_gain_weight);
  this->declare_parameter<double>("scoring.distance_cost", params_.distance_cost_weight);
  this->declare_parameter<double>("scoring.size_gain", params_.size_gain_weight);
  this->declare_parameter<double>(
    "scoring.heading_change_cost",
    params_.heading_change_cost_weight);
  this->declare_parameter<double>("scoring.recent_goal_penalty", params_.recent_goal_penalty);
  this->declare_parameter<double>("scoring.blacklist_penalty", params_.blacklist_penalty);

  this->declare_parameter<double>("blacklist.radius_m", params_.blacklist_radius_m);
  this->declare_parameter<double>("blacklist.duration_s", params_.blacklist_duration_s);
  this->declare_parameter<int>("blacklist.max_entries", params_.blacklist_max_entries);

  this->declare_parameter<double>("stuck.min_progress_m", params_.stuck_min_progress_m);
  this->declare_parameter<double>("stuck.check_period_s", params_.stuck_check_period_s);

  this->declare_parameter<bool>("debug.publish_markers", params_.publish_markers);
  this->declare_parameter<bool>("debug.publish_graph_markers", params_.publish_graph_markers);
  this->declare_parameter<bool>("debug.log_selected_goal", params_.log_selected_goal);
  this->declare_parameter<int>("debug.graph_subdivision", params_.graph_subdivision);
  this->declare_parameter<double>("debug.graph_motion_step_m", params_.graph_motion_step_m);
  this->declare_parameter<double>(
    "debug.graph_priority_tile_size_m",
    params_.graph_priority_tile_size_m);
  this->declare_parameter<bool>("debug.graph_allow_diagonal", params_.graph_allow_diagonal);
  this->declare_parameter<std::string>(
    "debug.graph_visualization_mode", params_.graph_visualization_mode);
  this->declare_parameter<double>(
    "debug.graph_marker_min_period_s", params_.graph_marker_min_period_s);
  this->declare_parameter<bool>("semantic_scoring_enabled", params_.semantic_scoring_enabled);
}

void ExplorerNode::readParameters()
{
  params_.map_topic = this->get_parameter("map_topic").as_string();
  params_.global_costmap_topic = this->get_parameter("global_costmap_topic").as_string();
  params_.local_costmap_topic = this->get_parameter("local_costmap_topic").as_string();
  params_.odom_topic = this->get_parameter("odom_topic").as_string();
  params_.debug_topic = this->get_parameter("debug_topic").as_string();
  params_.frontiers_topic = this->get_parameter("frontiers_topic").as_string();
  params_.graph_topic = this->get_parameter("graph_topic").as_string();
  params_.selected_goal_topic = this->get_parameter("selected_goal_topic").as_string();
  params_.navigate_to_pose_action = this->get_parameter("navigate_to_pose_action").as_string();
  params_.global_frame = this->get_parameter("global_frame").as_string();
  params_.robot_frame = this->get_parameter("robot_frame").as_string();
  params_.transform_timeout_s = this->get_parameter("transform_timeout_s").as_double();
  params_.autostart = this->get_parameter("autostart").as_bool();

  params_.replan_period_s = this->get_parameter("timing.replan_period_s").as_double();
  params_.goal_timeout_s = this->get_parameter("timing.goal_timeout_s").as_double();
  params_.stuck_timeout_s = this->get_parameter("timing.stuck_timeout_s").as_double();
  params_.post_goal_settle_s = this->get_parameter("timing.post_goal_settle_s").as_double();
  params_.map_geometry_settle_s = this->get_parameter("map.geometry_settle_s").as_double();

  params_.frontier_occ_threshold = this->get_parameter("frontier.occ_threshold").as_int();
  params_.min_frontier_size_cells =
    this->get_parameter("frontier.min_frontier_size_cells").as_int();
  params_.candidate_min_goal_distance_m =
    this->get_parameter("frontier.candidate_min_goal_distance_m").as_double();
  params_.min_goal_distance_m = this->get_parameter("frontier.min_goal_distance_m").as_double();
  params_.max_goal_distance_m = this->get_parameter("frontier.max_goal_distance_m").as_double();
  params_.duplicate_goal_radius_m =
    this->get_parameter("frontier.duplicate_goal_radius_m").as_double();

  params_.information_gain_weight = this->get_parameter("scoring.information_gain").as_double();
  params_.distance_cost_weight = this->get_parameter("scoring.distance_cost").as_double();
  params_.size_gain_weight = this->get_parameter("scoring.size_gain").as_double();
  params_.heading_change_cost_weight =
    this->get_parameter("scoring.heading_change_cost").as_double();
  params_.recent_goal_penalty = this->get_parameter("scoring.recent_goal_penalty").as_double();
  params_.blacklist_penalty = this->get_parameter("scoring.blacklist_penalty").as_double();

  params_.blacklist_radius_m = this->get_parameter("blacklist.radius_m").as_double();
  params_.blacklist_duration_s = this->get_parameter("blacklist.duration_s").as_double();
  params_.blacklist_max_entries = this->get_parameter("blacklist.max_entries").as_int();

  params_.stuck_min_progress_m = this->get_parameter("stuck.min_progress_m").as_double();
  params_.stuck_check_period_s = this->get_parameter("stuck.check_period_s").as_double();

  params_.publish_markers = this->get_parameter("debug.publish_markers").as_bool();
  params_.publish_graph_markers = this->get_parameter("debug.publish_graph_markers").as_bool();
  params_.log_selected_goal = this->get_parameter("debug.log_selected_goal").as_bool();
  params_.graph_subdivision = static_cast<int>(
    this->get_parameter("debug.graph_subdivision").as_int());
  params_.graph_motion_step_m = this->get_parameter("debug.graph_motion_step_m").as_double();
  params_.graph_priority_tile_size_m =
    this->get_parameter("debug.graph_priority_tile_size_m").as_double();
  params_.graph_allow_diagonal = this->get_parameter("debug.graph_allow_diagonal").as_bool();
  params_.graph_visualization_mode = this->get_parameter("debug.graph_visualization_mode").as_string();
  if (params_.graph_visualization_mode != "active_path" &&
    params_.graph_visualization_mode != "full")
  {
    RCLCPP_WARN(
      this->get_logger(),
      "debug.graph_visualization_mode='%s' inválido; usando active_path",
      params_.graph_visualization_mode.c_str());
    params_.graph_visualization_mode = "active_path";
  }
  params_.graph_marker_min_period_s = std::max(
    0.0,
    this->get_parameter("debug.graph_marker_min_period_s").as_double());
  params_.semantic_scoring_enabled = this->get_parameter("semantic_scoring_enabled").as_bool();

  params_.frontier_occ_threshold = std::clamp(params_.frontier_occ_threshold, 0, 100);
  params_.min_frontier_size_cells = std::max(1, params_.min_frontier_size_cells);
  params_.candidate_min_goal_distance_m = std::max(0.0, params_.candidate_min_goal_distance_m);
  params_.min_goal_distance_m = std::max(0.0, params_.min_goal_distance_m);
  params_.max_goal_distance_m = std::max(0.0, params_.max_goal_distance_m);
  if (params_.max_goal_distance_m > 0.0 &&
    params_.max_goal_distance_m < params_.min_goal_distance_m)
  {
    params_.max_goal_distance_m = params_.min_goal_distance_m;
  }
  params_.duplicate_goal_radius_m = std::max(0.0, params_.duplicate_goal_radius_m);
  params_.goal_timeout_s = std::max(0.1, params_.goal_timeout_s);
  params_.stuck_timeout_s = std::max(0.1, params_.stuck_timeout_s);
  params_.post_goal_settle_s = std::max(0.0, params_.post_goal_settle_s);
  params_.map_geometry_settle_s = std::max(0.0, params_.map_geometry_settle_s);
  params_.transform_timeout_s = std::clamp(params_.transform_timeout_s, 0.01, 2.0);
  params_.blacklist_radius_m = std::max(0.0, params_.blacklist_radius_m);
  params_.blacklist_duration_s = std::max(0.1, params_.blacklist_duration_s);
  params_.blacklist_max_entries = std::max(1, params_.blacklist_max_entries);
  params_.stuck_min_progress_m = std::max(0.0, params_.stuck_min_progress_m);
  params_.stuck_check_period_s = std::max(0.1, params_.stuck_check_period_s);
  params_.graph_subdivision = std::clamp(params_.graph_subdivision, 1, 3);
  params_.graph_motion_step_m =
    params_.graph_priority_tile_size_m /
    static_cast<double>(1 << (params_.graph_subdivision - 1));
  params_.graph_motion_step_m = std::clamp(params_.graph_motion_step_m, 0.03, 0.50);
  params_.graph_priority_tile_size_m =
    std::clamp(params_.graph_priority_tile_size_m, params_.graph_motion_step_m, 0.50);
}

void ExplorerNode::configureHelpers()
{
  FrontierScoringWeights weights;
  weights.information_gain = params_.information_gain_weight;
  weights.distance_cost = params_.distance_cost_weight;
  weights.size_gain = params_.size_gain_weight;
  weights.heading_change_cost = params_.heading_change_cost_weight;
  weights.recent_goal_penalty = params_.recent_goal_penalty;
  weights.blacklist_penalty = params_.blacklist_penalty;
  frontier_scorer_.setWeights(weights);

  blacklist_.configure(
    params_.blacklist_radius_m,
    params_.blacklist_duration_s,
    static_cast<std::size_t>(params_.blacklist_max_entries));
}

void ExplorerNode::logStartupParameters() const
{
  RCLCPP_INFO(this->get_logger(), "Explorer parameters:");
  RCLCPP_INFO(this->get_logger(), "  map_topic: %s", params_.map_topic.c_str());
  RCLCPP_INFO(this->get_logger(), "  global_costmap_topic: %s", params_.global_costmap_topic.c_str());
  RCLCPP_INFO(this->get_logger(), "  local_costmap_topic: %s", params_.local_costmap_topic.c_str());
  RCLCPP_INFO(this->get_logger(), "  odom_topic: %s", params_.odom_topic.c_str());
  RCLCPP_INFO(this->get_logger(), "  debug_topic: %s", params_.debug_topic.c_str());
  RCLCPP_INFO(this->get_logger(), "  frontiers_topic: %s", params_.frontiers_topic.c_str());
  RCLCPP_INFO(this->get_logger(), "  graph_topic: %s", params_.graph_topic.c_str());
  RCLCPP_INFO(this->get_logger(), "  selected_goal_topic: %s", params_.selected_goal_topic.c_str());
  RCLCPP_INFO(
    this->get_logger(),
    "  navigate_to_pose_action: %s",
    params_.navigate_to_pose_action.c_str());
  RCLCPP_INFO(this->get_logger(), "  global_frame: %s", params_.global_frame.c_str());
  RCLCPP_INFO(this->get_logger(), "  robot_frame: %s", params_.robot_frame.c_str());
  RCLCPP_INFO(this->get_logger(), "  transform_timeout_s: %.3f", params_.transform_timeout_s);
  RCLCPP_INFO(this->get_logger(), "  autostart: %s", params_.autostart ? "true" : "false");
  RCLCPP_INFO(
    this->get_logger(),
    "  timing: replan=%.3f goal_timeout=%.3f stuck_timeout=%.3f post_goal_settle=%.3f map_geometry_settle=%.3f",
    params_.replan_period_s,
    params_.goal_timeout_s,
    params_.stuck_timeout_s,
    params_.post_goal_settle_s,
    params_.map_geometry_settle_s);
  RCLCPP_INFO(
    this->get_logger(),
    "  frontier: occ=%d min_size=%d candidate_min=%.3f min_goal=%.3f max_goal=%.3f duplicate_radius=%.3f",
    params_.frontier_occ_threshold,
    params_.min_frontier_size_cells,
    params_.candidate_min_goal_distance_m,
    params_.min_goal_distance_m,
    params_.max_goal_distance_m,
    params_.duplicate_goal_radius_m);
  RCLCPP_INFO(
    this->get_logger(),
    "  scoring: information_gain=%.3f distance_cost=%.3f size_gain=%.3f heading_change_cost=%.3f recent_penalty=%.3f blacklist_penalty=%.3f",
    params_.information_gain_weight,
    params_.distance_cost_weight,
    params_.size_gain_weight,
    params_.heading_change_cost_weight,
    params_.recent_goal_penalty,
    params_.blacklist_penalty);
  RCLCPP_INFO(
    this->get_logger(),
    "  blacklist: radius=%.3f duration=%.3f max_entries=%d",
    params_.blacklist_radius_m,
    params_.blacklist_duration_s,
    params_.blacklist_max_entries);
  RCLCPP_INFO(
    this->get_logger(),
    "  stuck: min_progress=%.3f check_period=%.3f",
    params_.stuck_min_progress_m,
    params_.stuck_check_period_s);
  RCLCPP_INFO(
    this->get_logger(),
    "  debug.publish_markers: %s debug.publish_graph_markers: %s debug.log_selected_goal: %s graph_subdivision=%d graph_motion_step_m=%.3f graph_priority_tile_size_m=%.3f graph_allow_diagonal=%s graph_visualization_mode=%s graph_marker_min_period_s=%.3f",
    params_.publish_markers ? "true" : "false",
    params_.publish_graph_markers ? "true" : "false",
    params_.log_selected_goal ? "true" : "false",
    params_.graph_subdivision,
    params_.graph_motion_step_m,
    params_.graph_priority_tile_size_m,
    params_.graph_allow_diagonal ? "true" : "false",
    params_.graph_visualization_mode.c_str(),
    params_.graph_marker_min_period_s);
}

void ExplorerNode::onMap(nav_msgs::msg::OccupancyGrid::SharedPtr msg)
{
  std::lock_guard<std::mutex> lock(messages_mutex_);

  const bool geometry_changed =
    !map_geometry_initialized_ ||
    msg->info.width != last_map_width_ ||
    msg->info.height != last_map_height_ ||
    std::abs(msg->info.resolution - last_map_resolution_) > 1e-9 ||
    std::abs(msg->info.origin.position.x - last_map_origin_x_) > 1e-6 ||
    std::abs(msg->info.origin.position.y - last_map_origin_y_) > 1e-6;

  if (geometry_changed) {
    map_geometry_initialized_ = true;
    last_map_width_ = msg->info.width;
    last_map_height_ = msg->info.height;
    last_map_resolution_ = msg->info.resolution;
    last_map_origin_x_ = msg->info.origin.position.x;
    last_map_origin_y_ = msg->info.origin.position.y;
    last_map_geometry_change_time_ = this->now();
  }

  latest_map_ = msg;
}

void ExplorerNode::onGlobalCostmap(nav_msgs::msg::OccupancyGrid::SharedPtr msg)
{
  std::lock_guard<std::mutex> lock(messages_mutex_);
  latest_global_costmap_ = msg;
}

void ExplorerNode::onLocalCostmap(nav_msgs::msg::OccupancyGrid::SharedPtr msg)
{
  std::lock_guard<std::mutex> lock(messages_mutex_);
  latest_local_costmap_ = msg;
}

void ExplorerNode::onOdom(nav_msgs::msg::Odometry::SharedPtr msg)
{
  std::lock_guard<std::mutex> lock(messages_mutex_);
  latest_odom_ = msg;
}

void ExplorerNode::onTimer()
{
  const rclcpp::Time now = this->now();
  blacklist_.pruneExpired(now);
  pruneRecentGoals(now);

  const bool nav2_ready = nav2_goal_manager_ && nav2_goal_manager_->actionServerReady(0ms);
  const ExplorerSnapshot snapshot = snapshotMessages();

  const auto publish_waiting_status =
    [&](const std::string & reason, const std::string & extra_debug) {
      std_msgs::msg::String debug_msg;
      debug_msg.data = makeWaitingDebugStatus(snapshot, nav2_ready, reason);
      if (!extra_debug.empty()) {
        debug_msg.data += " " + extra_debug;
      }
      debug_pub_->publish(debug_msg);
      if (params_.publish_markers && snapshot.map) {
        publishFrontierMarkers(snapshot.map->header, {}, std::nullopt);
      }
      if (params_.publish_graph_markers && snapshot.global_costmap) {
        geometry_msgs::msg::Pose graph_pose;
        if (snapshot.map) {
          std::string ignored_tf_error;
          const auto current_pose_for_viz = lookupRobotPoseInMapFrame(*snapshot.map, ignored_tf_error);
          if (current_pose_for_viz.has_value()) {
            graph_pose = *current_pose_for_viz;
          }
        }
        publishGraphMarkers(snapshot, graph_pose, std::nullopt);
      }
      RCLCPP_INFO(this->get_logger(), "%s", debug_msg.data.c_str());
    };

  if (!params_.autostart) {
    publish_waiting_status("autostart_false", "");
    return;
  }

  if (!snapshot.map || !snapshot.global_costmap || !snapshot.odom) {
    publish_waiting_status("waiting_required_topics", "");
    return;
  }

  std::string tf_error;
  const std::optional<geometry_msgs::msg::Pose> current_pose =
    lookupRobotPoseInMapFrame(*snapshot.map, tf_error);
  if (!current_pose.has_value()) {
    publish_waiting_status(
      "waiting_robot_tf",
      "pose_source=tf robot_frame=" + params_.robot_frame +
        " map_frame=" + (snapshot.map->header.frame_id.empty() ? params_.global_frame : snapshot.map->header.frame_id) +
        " tf_error=" + quoteDebugValue(tf_error));
    return;
  }

  int robot_map_x = 0;
  int robot_map_y = 0;
  const bool robot_inside_map = worldToMapCell(
    *snapshot.map,
    current_pose->position.x,
    current_pose->position.y,
    robot_map_x,
    robot_map_y);
  if (!robot_inside_map) {
    std::ostringstream extra;
    extra << "pose_source=tf"
          << " robot_frame=" << params_.robot_frame
          << " map_frame=" << (snapshot.map->header.frame_id.empty() ? params_.global_frame : snapshot.map->header.frame_id)
          << " robot_x=" << current_pose->position.x
          << " robot_y=" << current_pose->position.y
          << " robot_pose_inside_map=false";
    publish_waiting_status("robot_pose_out_of_map", extra.str());
    return;
  }

  if (goalActive()) {
    if (handleActiveGoalWatchdogs(*current_pose)) {
      publish_waiting_status("goal_recovery_cancel", "pose_source=tf robot_pose_inside_map=true");
      return;
    }
    if (params_.publish_graph_markers) {
      const GoalRuntimeStatus status = goalStatus();
      std::optional<geometry_msgs::msg::Point> active_goal;
      if (status.active) {
        active_goal = status.active_goal;
      }
      publishGraphMarkers(snapshot, *current_pose, active_goal);
    }
    publish_waiting_status("goal_active", "pose_source=tf robot_pose_inside_map=true");
    return;
  }

  if (!nav2_ready) {
    publish_waiting_status("waiting_nav2_action_server", "pose_source=tf robot_pose_inside_map=true");
    return;
  }

  if (withinPostGoalSettle()) {
    publish_waiting_status("post_goal_settle", "pose_source=tf robot_pose_inside_map=true");
    return;
  }

  if (!mapGeometryStable(snapshot, now)) {
    std::ostringstream extra;
    extra << "pose_source=tf"
          << " robot_pose_inside_map=true"
          << " map_geometry_stable=false"
          << " map_geometry_age_s=" << mapGeometryAgeSeconds(snapshot, now)
          << " map_geometry_settle_s=" << params_.map_geometry_settle_s;
    publish_waiting_status("map_geometry_settling", extra.str());
    return;
  }

  const FrontierDetector frontier_detector(
    params_.frontier_occ_threshold,
    static_cast<std::size_t>(params_.min_frontier_size_cells));
  const std::vector<Frontier> frontiers = frontier_detector.detect(*snapshot.map);

  CandidateBuildResult candidate_result =
    buildCandidateSet(frontiers, snapshot, *current_pose, now);
  const std::optional<ScoredFrontierCandidate> selected =
    selectBestCandidate(candidate_result.candidates);

  if (params_.publish_markers) {
    publishFrontierMarkers(snapshot.map->header, candidate_result.candidates, selected);
  }
  if (params_.publish_graph_markers) {
    std::optional<geometry_msgs::msg::Point> selected_goal;
    if (selected.has_value()) {
      selected_goal = selected->goal.pose.position;
    }
    publishGraphMarkers(snapshot, *current_pose, selected_goal);
  }

  if (selected.has_value()) {
    selected_goal_pub_->publish(selected->goal);
    sendSelectedGoal(*selected, *current_pose);
  }

  std_msgs::msg::String debug_msg;
  debug_msg.data = makeDebugStatus(
    snapshot,
    frontiers,
    candidate_result,
    selected,
    GridIndex{robot_map_x, robot_map_y},
    nav2_ready);
  debug_msg.data += " pose_source=tf robot_frame=" + params_.robot_frame +
                    " map_frame=" +
                    (snapshot.map->header.frame_id.empty() ? params_.global_frame : snapshot.map->header.frame_id) +
                    " robot_x=" + std::to_string(current_pose->position.x) +
                    " robot_y=" + std::to_string(current_pose->position.y) +
                    " robot_pose_inside_map=true" +
                    " map_geometry_stable=true" +
                    " map_geometry_age_s=" + std::to_string(mapGeometryAgeSeconds(snapshot, now));
  debug_pub_->publish(debug_msg);
  RCLCPP_INFO(this->get_logger(), "%s", debug_msg.data.c_str());
}

ExplorerSnapshot ExplorerNode::snapshotMessages() const
{
  std::lock_guard<std::mutex> lock(messages_mutex_);
  ExplorerSnapshot snapshot;
  snapshot.map = latest_map_;
  snapshot.global_costmap = latest_global_costmap_;
  snapshot.local_costmap = latest_local_costmap_;
  snapshot.odom = latest_odom_;
  snapshot.map_geometry_initialized = map_geometry_initialized_;
  snapshot.last_map_geometry_change_time = last_map_geometry_change_time_;
  return snapshot;
}


std::optional<geometry_msgs::msg::Pose> ExplorerNode::lookupRobotPoseInMapFrame(
  const nav_msgs::msg::OccupancyGrid & map,
  std::string & error_message)
{
  const std::string target_frame = !map.header.frame_id.empty() ? map.header.frame_id : params_.global_frame;
  if (target_frame.empty() || params_.robot_frame.empty()) {
    error_message = "empty_tf_frame";
    return std::nullopt;
  }

  try {
    const geometry_msgs::msg::TransformStamped transform =
      tf_buffer_.lookupTransform(
        target_frame,
        params_.robot_frame,
        tf2::TimePointZero,
        tf2::durationFromSec(params_.transform_timeout_s));

    geometry_msgs::msg::Pose pose;
    pose.position.x = transform.transform.translation.x;
    pose.position.y = transform.transform.translation.y;
    pose.position.z = transform.transform.translation.z;
    pose.orientation = transform.transform.rotation;
    return pose;
  } catch (const tf2::TransformException & error) {
    error_message = error.what();
    return std::nullopt;
  }
}

double ExplorerNode::mapGeometryAgeSeconds(
  const ExplorerSnapshot & snapshot,
  const rclcpp::Time & now) const
{
  if (!snapshot.map_geometry_initialized ||
    snapshot.last_map_geometry_change_time.nanoseconds() == 0 ||
    now <= snapshot.last_map_geometry_change_time)
  {
    return 0.0;
  }
  return (now - snapshot.last_map_geometry_change_time).seconds();
}

bool ExplorerNode::mapGeometryStable(
  const ExplorerSnapshot & snapshot,
  const rclcpp::Time & now) const
{
  if (!snapshot.map_geometry_initialized) {
    return false;
  }
  return mapGeometryAgeSeconds(snapshot, now) >= params_.map_geometry_settle_s;
}

std::optional<std::string> ExplorerNode::validateGoalPoint(
  const geometry_msgs::msg::Point & goal_point,
  const ExplorerSnapshot & snapshot,
  const geometry_msgs::msg::Pose & current_pose) const
{
  if (!std::isfinite(goal_point.x) || !std::isfinite(goal_point.y)) {
    return std::string("goal_not_finite");
  }
  if (!snapshot.map) {
    return std::string("missing_map");
  }

  int map_x = 0;
  int map_y = 0;
  if (!worldToMapCell(*snapshot.map, goal_point.x, goal_point.y, map_x, map_y)) {
    return std::string("goal_outside_map");
  }

  if (gridValueBlocked(
      *snapshot.map,
      goal_point.x,
      goal_point.y,
      params_.frontier_occ_threshold,
      true))
  {
    return std::string("goal_blocked_in_map");
  }

  if (snapshot.global_costmap) {
    int costmap_x = 0;
    int costmap_y = 0;
    if (!worldToMapCell(*snapshot.global_costmap, goal_point.x, goal_point.y, costmap_x, costmap_y)) {
      return std::string("goal_outside_global_costmap");
    }
    if (gridValueBlocked(
        *snapshot.global_costmap,
        goal_point.x,
        goal_point.y,
        params_.frontier_occ_threshold,
        true))
    {
      return std::string("goal_blocked_in_global_costmap");
    }
  }

  const double distance = std::hypot(
    goal_point.x - current_pose.position.x,
    goal_point.y - current_pose.position.y);
  if (distance < params_.min_goal_distance_m) {
    return std::string("goal_too_close");
  }
  if (params_.max_goal_distance_m > 0.0 && distance > params_.max_goal_distance_m) {
    return std::string("goal_too_far");
  }

  return std::nullopt;
}


CandidateBuildResult ExplorerNode::buildCandidateSet(
  const std::vector<Frontier> & frontiers,
  const ExplorerSnapshot & snapshot,
  const geometry_msgs::msg::Pose & current_pose,
  const rclcpp::Time & now)
{
  CandidateBuildResult built;
  built.candidates.reserve(frontiers.size());

  for (const auto & frontier : frontiers) {
    if (frontier.cells.empty() ||
      !std::isfinite(frontier.centroid.x) ||
      !std::isfinite(frontier.centroid.y))
    {
      ++built.stats.rejected_invalid;
      continue;
    }

    geometry_msgs::msg::Point goal_point = frontier.centroid;
    if (snapshot.global_costmap) {
      const auto snapped_goal = nearestReachablePriorityTileCenter(
        *snapshot.global_costmap,
        params_.graph_motion_step_m,
        params_.graph_priority_tile_size_m,
        params_.graph_allow_diagonal,
        params_.frontier_occ_threshold,
        current_pose,
        frontier.centroid);
      if (!snapped_goal.has_value()) {
        ++built.stats.rejected_invalid;
        continue;
      }
      goal_point = *snapped_goal;
    }

    const std::optional<std::string> goal_rejection =
      validateGoalPoint(goal_point, snapshot, current_pose);
    if (goal_rejection.has_value()) {
      if (*goal_rejection == "goal_too_close" || *goal_rejection == "goal_too_far") {
        ++built.stats.rejected_by_distance;
      } else {
        ++built.stats.rejected_invalid;
      }
      continue;
    }

    const FrontierScoreBreakdown base_score =
      frontier_scorer_.score(frontier, current_pose, goal_point, false, false);

    if (!std::isfinite(base_score.distance_m)) {
      ++built.stats.rejected_invalid;
      continue;
    }
    if (base_score.distance_m < params_.min_goal_distance_m) {
      ++built.stats.rejected_by_distance;
      continue;
    }
    if (params_.max_goal_distance_m > 0.0 && base_score.distance_m > params_.max_goal_distance_m) {
      ++built.stats.rejected_by_distance;
      continue;
    }

    if (blacklist_.contains(goal_point, now)) {
      ++built.stats.rejected_by_blacklist;
      continue;
    }

    const std::optional<RecentGoal> recent_match = findRecentGoalNear(goal_point, now);
    const bool near_recent_goal = recent_match.has_value();
    if (recent_match.has_value() &&
      base_score.score <= recent_match->score + params_.recent_goal_penalty)
    {
      ++built.stats.rejected_by_duplicate;
      blacklist_.add(goal_point, now, "duplicate");
      continue;
    }

    ScoredFrontierCandidate candidate;
    candidate.frontier = frontier;
    candidate.near_recent_goal = near_recent_goal;
    candidate.score =
      frontier_scorer_.score(frontier, current_pose, goal_point, near_recent_goal, false);
    candidate.goal.header = snapshot.map->header;
    candidate.goal.header.stamp = now;
    candidate.goal.header.frame_id =
      params_.global_frame.empty() ? snapshot.map->header.frame_id : params_.global_frame;
    candidate.goal.pose.position = goal_point;
    const double yaw = std::atan2(
      candidate.goal.pose.position.y - current_pose.position.y,
      candidate.goal.pose.position.x - current_pose.position.x);
    candidate.goal.pose.orientation = yawToQuaternion(yaw);

    built.candidates.push_back(candidate);
  }

  return built;
}

std::optional<ScoredFrontierCandidate> ExplorerNode::selectBestCandidate(
  const std::vector<ScoredFrontierCandidate> & candidates) const
{
  if (candidates.empty()) {
    return std::nullopt;
  }

  return *std::max_element(
    candidates.begin(),
    candidates.end(),
    [](const ScoredFrontierCandidate & lhs, const ScoredFrontierCandidate & rhs) {
      if (lhs.score.score != rhs.score.score) {
        return lhs.score.score < rhs.score.score;
      }
      if (lhs.frontier.cells.size() != rhs.frontier.cells.size()) {
        return lhs.frontier.cells.size() < rhs.frontier.cells.size();
      }
      return lhs.score.distance_m > rhs.score.distance_m;
    });
}

bool ExplorerNode::goalActive() const
{
  std::lock_guard<std::mutex> lock(goal_mutex_);
  return goal_active_;
}

bool ExplorerNode::withinPostGoalSettle() const
{
  std::lock_guard<std::mutex> lock(goal_mutex_);
  if (!has_last_goal_complete_time_) {
    return false;
  }
  return secondsSince(last_goal_complete_time_, this->now()) < params_.post_goal_settle_s;
}

GoalRuntimeStatus ExplorerNode::goalStatus() const
{
  std::lock_guard<std::mutex> lock(goal_mutex_);
  GoalRuntimeStatus status;
  status.active = goal_active_;
  status.last_failure_reason = last_failure_reason_;
  status.last_nav2_result = last_nav2_result_;
  status.stuck_low_progress_s = stuck_low_progress_s_;
  status.last_stuck_delta_m = last_stuck_delta_m_;
  if (goal_active_) {
    status.age_s = secondsSince(active_goal_sent_time_, this->now());
    status.active_goal = active_goal_.pose.position;
    status.active_goal_score = active_goal_score_;
  }
  return status;
}

bool ExplorerNode::handleActiveGoalWatchdogs(const geometry_msgs::msg::Pose & current_pose)
{
  const rclcpp::Time now = this->now();
  std::string recovery_reason;

  {
    std::lock_guard<std::mutex> lock(goal_mutex_);
    if (!goal_active_) {
      return false;
    }

    const double goal_age_s = secondsSince(active_goal_sent_time_, now);
    if (goal_age_s >= params_.goal_timeout_s) {
      recovery_reason = "goal_timeout";
    } else {
      const double check_age_s = secondsSince(last_stuck_check_time_, now);
      if (check_age_s >= params_.stuck_check_period_s) {
        last_stuck_delta_m_ = poseDistance2d(current_pose, last_stuck_check_pose_);
        if (last_stuck_delta_m_ < params_.stuck_min_progress_m) {
          stuck_low_progress_s_ += check_age_s;
        } else {
          stuck_low_progress_s_ = 0.0;
        }
        last_stuck_check_time_ = now;
        last_stuck_check_pose_ = current_pose;

        if (stuck_low_progress_s_ >= params_.stuck_timeout_s) {
          recovery_reason = "stuck";
        }
      }
    }
  }

  if (recovery_reason.empty()) {
    return false;
  }

  cancelActiveGoalForReason(recovery_reason);
  return true;
}

void ExplorerNode::cancelActiveGoalForReason(const std::string & reason)
{
  geometry_msgs::msg::PoseStamped goal_to_blacklist;
  bool had_goal = false;
  std::uint64_t sequence = 0;

  {
    std::lock_guard<std::mutex> lock(goal_mutex_);
    if (!goal_active_) {
      return;
    }

    had_goal = true;
    sequence = current_goal_sequence_;
    goal_to_blacklist = active_goal_;
    goal_active_ = false;
    recovery_cancel_sequence_ = sequence;
    recovery_cancel_reason_ = reason;
    last_failure_reason_ = reason;
    last_nav2_result_ = reason;
    for (auto & recent_goal : recent_goals_) {
      if (recent_goal.sequence == sequence) {
        recent_goal.result = reason;
      }
    }
  }

  if (!had_goal) {
    return;
  }

  blacklistGoal(goal_to_blacklist, reason);
  const bool cancel_sent = nav2_goal_manager_ && nav2_goal_manager_->cancelActiveGoal();
  {
    std::lock_guard<std::mutex> lock(goal_mutex_);
    last_nav2_result_ = cancel_sent ? reason + "_cancel_sent" : reason + "_cancel_unavailable";
  }
  publishGoalEventDebug(reason);
}

void ExplorerNode::sendSelectedGoal(
  const ScoredFrontierCandidate & selected,
  const geometry_msgs::msg::Pose & current_pose)
{
  const rclcpp::Time now = this->now();
  std::uint64_t goal_sequence = 0;

  {
    std::lock_guard<std::mutex> lock(goal_mutex_);
    if (goal_active_) {
      return;
    }
    goal_sequence = ++current_goal_sequence_;
    goal_active_ = true;
    active_goal_ = selected.goal;
    active_goal_sent_time_ = now;
    active_goal_score_ = selected.score.score;
    last_nav2_result_ = "sent";
    recovery_cancel_sequence_ = 0;
    recovery_cancel_reason_.clear();
    last_stuck_check_time_ = now;
    last_stuck_check_pose_ = current_pose;
    stuck_low_progress_s_ = 0.0;
    last_stuck_delta_m_ = 0.0;
  }

  rememberRecentGoal(
    selected.goal.pose.position,
    selected.score.score,
    goal_sequence,
    now);

  if (params_.log_selected_goal) {
    RCLCPP_INFO(
      this->get_logger(),
      "Sending NavigateToPose goal: x=%.3f y=%.3f score=%.3f distance=%.3f heading=%.3f size=%d",
      selected.goal.pose.position.x,
      selected.goal.pose.position.y,
      selected.score.score,
      selected.score.distance_m,
      selected.score.absolute_heading_change_rad,
      static_cast<int>(selected.frontier.cells.size()));
  }

  try {
    nav2_goal_manager_->sendGoal(
      selected.goal,
      [this, goal_sequence](Nav2GoalManager::GoalHandle::SharedPtr goal_handle) {
        handleGoalResponse(goal_sequence, goal_handle);
      },
      [this, goal_sequence](const Nav2GoalManager::GoalHandle::WrappedResult & result) {
        handleGoalResult(goal_sequence, result);
      });
  } catch (const std::exception & error) {
    {
      std::lock_guard<std::mutex> lock(goal_mutex_);
      goal_active_ = false;
      last_nav2_result_ = std::string("send_failed:") + error.what();
      last_failure_reason_ = "nav2_rejected";
    }
    updateRecentGoalResult(goal_sequence, "nav2_rejected");
    blacklistGoal(selected.goal, "nav2_rejected");
    publishGoalEventDebug("nav2_rejected");
    RCLCPP_WARN(this->get_logger(), "Failed to send NavigateToPose goal: %s", error.what());
  }
}

void ExplorerNode::handleGoalResponse(
  std::uint64_t goal_sequence,
  Nav2GoalManager::GoalHandle::SharedPtr goal_handle)
{
  if (goal_handle) {
    {
      std::lock_guard<std::mutex> lock(goal_mutex_);
      if (goal_sequence == current_goal_sequence_ && goal_active_) {
        last_nav2_result_ = "accepted";
      }
    }
    publishGoalEventDebug("nav2_accepted");
    return;
  }

  geometry_msgs::msg::PoseStamped rejected_goal;
  bool should_blacklist = false;
  {
    std::lock_guard<std::mutex> lock(goal_mutex_);
    if (goal_sequence != current_goal_sequence_) {
      return;
    }

    rejected_goal = active_goal_;
    goal_active_ = false;
    last_nav2_result_ = "rejected";
    last_failure_reason_ = "nav2_rejected";
    should_blacklist = true;
  }

  updateRecentGoalResult(goal_sequence, "nav2_rejected");
  if (should_blacklist) {
    blacklistGoal(rejected_goal, "nav2_rejected");
  }
  publishGoalEventDebug("nav2_rejected");
}

void ExplorerNode::handleGoalResult(
  std::uint64_t goal_sequence,
  const Nav2GoalManager::GoalHandle::WrappedResult & result)
{
  const rclcpp::Time now = this->now();
  const std::string result_text = resultCodeToString(result.code);
  geometry_msgs::msg::PoseStamped failed_goal;
  std::string failure_reason;
  bool should_blacklist = false;

  {
    std::lock_guard<std::mutex> lock(goal_mutex_);
    if (goal_sequence != current_goal_sequence_) {
      return;
    }

    const bool recovery_cancel = recovery_cancel_sequence_ == goal_sequence;
    last_nav2_result_ = result_text;
    goal_active_ = false;

    if (result.code == rclcpp_action::ResultCode::SUCCEEDED) {
      last_goal_complete_time_ = now;
      has_last_goal_complete_time_ = true;
      recovery_cancel_sequence_ = 0;
      recovery_cancel_reason_.clear();
      for (auto & recent_goal : recent_goals_) {
        if (recent_goal.sequence == goal_sequence) {
          recent_goal.result = "succeeded";
        }
      }
    } else if (result.code == rclcpp_action::ResultCode::CANCELED && recovery_cancel) {
      last_nav2_result_ = "canceled_after_" + recovery_cancel_reason_;
      for (auto & recent_goal : recent_goals_) {
        if (recent_goal.sequence == goal_sequence) {
          recent_goal.result = recovery_cancel_reason_;
        }
      }
      recovery_cancel_sequence_ = 0;
      recovery_cancel_reason_.clear();
    } else {
      failure_reason = resultFailureReason(result.code);
      if (failure_reason.empty()) {
        failure_reason = "nav2_aborted";
      }
      failed_goal = active_goal_;
      last_failure_reason_ = failure_reason;
      should_blacklist = true;
      for (auto & recent_goal : recent_goals_) {
        if (recent_goal.sequence == goal_sequence) {
          recent_goal.result = failure_reason;
        }
      }
    }
  }

  if (should_blacklist) {
    blacklistGoal(failed_goal, failure_reason);
  }
  publishGoalEventDebug(failure_reason.empty() ? result_text : failure_reason);
}

void ExplorerNode::blacklistGoal(
  const geometry_msgs::msg::PoseStamped & goal,
  const std::string & reason)
{
  blacklist_.add(goal.pose.position, this->now(), reason);
}

void ExplorerNode::rememberRecentGoal(
  const geometry_msgs::msg::Point & point,
  double score,
  std::uint64_t sequence,
  const rclcpp::Time & now)
{
  std::lock_guard<std::mutex> lock(goal_mutex_);
  RecentGoal goal;
  goal.point = point;
  goal.stamp = now;
  goal.score = score;
  goal.sequence = sequence;
  recent_goals_.push_back(goal);

  while (recent_goals_.size() > static_cast<std::size_t>(params_.blacklist_max_entries)) {
    recent_goals_.erase(recent_goals_.begin());
  }
}

void ExplorerNode::updateRecentGoalResult(std::uint64_t sequence, const std::string & result)
{
  std::lock_guard<std::mutex> lock(goal_mutex_);
  for (auto & recent_goal : recent_goals_) {
    if (recent_goal.sequence == sequence) {
      recent_goal.result = result;
    }
  }
}

void ExplorerNode::pruneRecentGoals(const rclcpp::Time & now)
{
  const double max_age_s = std::max(
    params_.blacklist_duration_s,
    params_.goal_timeout_s + params_.stuck_timeout_s + 5.0);

  std::lock_guard<std::mutex> lock(goal_mutex_);
  recent_goals_.erase(
    std::remove_if(
      recent_goals_.begin(),
      recent_goals_.end(),
      [&now, max_age_s](const RecentGoal & goal) {
        return secondsSince(goal.stamp, now) > max_age_s;
      }),
    recent_goals_.end());

  while (recent_goals_.size() > static_cast<std::size_t>(params_.blacklist_max_entries)) {
    recent_goals_.erase(recent_goals_.begin());
  }
}

std::optional<RecentGoal> ExplorerNode::findRecentGoalNear(
  const geometry_msgs::msg::Point & point,
  const rclcpp::Time & now) const
{
  const double max_age_s = std::max(
    params_.blacklist_duration_s,
    params_.goal_timeout_s + params_.stuck_timeout_s + 5.0);

  std::lock_guard<std::mutex> lock(goal_mutex_);
  std::optional<RecentGoal> best_match;
  double best_distance = std::numeric_limits<double>::infinity();
  for (const auto & goal : recent_goals_) {
    if (secondsSince(goal.stamp, now) > max_age_s) {
      continue;
    }
    const double distance = pointDistance2d(point, goal.point);
    if (distance <= params_.duplicate_goal_radius_m && distance < best_distance) {
      best_match = goal;
      best_distance = distance;
    }
  }

  return best_match;
}

std::string ExplorerNode::makeWaitingDebugStatus(
  const ExplorerSnapshot & snapshot,
  bool nav2_ready,
  const std::string & reason) const
{
  const GoalRuntimeStatus goal_status = goalStatus();
  std::ostringstream stream;
  stream << "ros2_exploration status:"
         << " reason=" << reason
         << " map_received=" << (snapshot.map ? "true" : "false")
         << " global_costmap_received=" << (snapshot.global_costmap ? "true" : "false")
         << " local_costmap_received=" << (snapshot.local_costmap ? "true" : "false")
         << " odom_received=" << (snapshot.odom ? "true" : "false")
         << " nav2_action_ready=" << (nav2_ready ? "true" : "false")
         << " action=" << params_.navigate_to_pose_action
         << " frontier_count=0"
         << " valid_candidate_count=0"
         << " rejected_by_blacklist=0"
         << " rejected_by_distance=0"
         << " rejected_by_duplicate=0"
         << " selected_score=none"
         << " selected_goal=none"
         << " goal_active=" << (goal_status.active ? "true" : "false")
         << " active_goal=";
  if (goal_status.active) {
    stream << "(" << goal_status.active_goal.x << "," << goal_status.active_goal.y << ")"
           << " active_goal_score=" << goal_status.active_goal_score;
  } else {
    stream << "none active_goal_score=none";
  }
  stream << " goal_age_s=" << goal_status.age_s
         << " stuck_low_progress_s=" << goal_status.stuck_low_progress_s
         << " stuck_last_delta_m=" << goal_status.last_stuck_delta_m
         << " blacklist_size=" << blacklist_.size()
         << " last_failure_reason=" << goal_status.last_failure_reason
         << " last_nav2_result=" << goal_status.last_nav2_result;

  if (snapshot.map) {
    stream << " map_size=" << snapshot.map->info.width << "x" << snapshot.map->info.height;
  }

  return stream.str();
}

std::string ExplorerNode::makeDebugStatus(
  const ExplorerSnapshot & snapshot,
  const std::vector<Frontier> & frontiers,
  const CandidateBuildResult & candidate_result,
  const std::optional<ScoredFrontierCandidate> & selected,
  const GridIndex & robot_map_cell,
  bool nav2_ready) const
{
  const GoalRuntimeStatus goal_status = goalStatus();
  std::ostringstream stream;
  stream << "ros2_exploration status:"
         << " map_size=" << snapshot.map->info.width << "x" << snapshot.map->info.height
         << " global_costmap_received=true"
         << " local_costmap_received=" << (snapshot.local_costmap ? "true" : "false")
         << " frontier_count=" << frontiers.size()
         << " valid_candidate_count=" << candidate_result.candidates.size()
         << " rejected_by_blacklist=" << candidate_result.stats.rejected_by_blacklist
         << " rejected_by_distance=" << candidate_result.stats.rejected_by_distance
         << " rejected_by_duplicate=" << candidate_result.stats.rejected_by_duplicate
         << " rejected_invalid=" << candidate_result.stats.rejected_invalid
         << " robot_map_cell=(" << robot_map_cell.x << ","
         << robot_map_cell.y << ")"
         << " nav2_action_ready=" << (nav2_ready ? "true" : "false")
         << " goal_active=" << (goal_status.active ? "true" : "false")
         << " active_goal=";
  if (goal_status.active) {
    stream << "(" << goal_status.active_goal.x << "," << goal_status.active_goal.y << ")"
           << " active_goal_score=" << goal_status.active_goal_score;
  } else {
    stream << "none active_goal_score=none";
  }
  stream << " goal_age_s=" << goal_status.age_s
         << " stuck_low_progress_s=" << goal_status.stuck_low_progress_s
         << " stuck_last_delta_m=" << goal_status.last_stuck_delta_m
         << " blacklist_size=" << blacklist_.size()
         << " last_failure_reason=" << goal_status.last_failure_reason
         << " last_nav2_result=" << goal_status.last_nav2_result;

  if (selected.has_value()) {
    stream << " selected_goal=(" << selected->goal.pose.position.x << ","
           << selected->goal.pose.position.y << ")"
           << " selected_score=" << selected->score.score
           << " selected_distance=" << selected->score.distance_m
           << " selected_heading_change=" << selected->score.absolute_heading_change_rad
           << " selected_information_gain=" << selected->score.information_gain
           << " selected_frontier_size=" << selected->score.frontier_size
           << " selected_recent_penalty=" << selected->score.recent_goal_penalty;
  } else {
    stream << " selected_goal=none selected_score=none";
  }

  return stream.str();
}

void ExplorerNode::publishGoalEventDebug(const std::string & event)
{
  if (!debug_pub_) {
    return;
  }

  const GoalRuntimeStatus goal_status = goalStatus();
  std_msgs::msg::String debug_msg;
  std::ostringstream stream;
  stream << "ros2_exploration event=" << event
         << " goal_active=" << (goal_status.active ? "true" : "false")
         << " active_goal=";
  if (goal_status.active) {
    stream << "(" << goal_status.active_goal.x << "," << goal_status.active_goal.y << ")"
           << " active_goal_score=" << goal_status.active_goal_score;
  } else {
    stream << "none active_goal_score=none";
  }
  stream << " goal_age_s=" << goal_status.age_s
         << " stuck_low_progress_s=" << goal_status.stuck_low_progress_s
         << " blacklist_size=" << blacklist_.size()
         << " last_failure_reason=" << goal_status.last_failure_reason
         << " last_nav2_result=" << goal_status.last_nav2_result;
  debug_msg.data = stream.str();
  debug_pub_->publish(debug_msg);
  RCLCPP_INFO(this->get_logger(), "%s", debug_msg.data.c_str());
}

void ExplorerNode::publishFrontierMarkers(
  const std_msgs::msg::Header & map_header,
  const std::vector<ScoredFrontierCandidate> & candidates,
  const std::optional<ScoredFrontierCandidate> & selected)
{
  const std::vector<BlacklistedGoal> blacklisted_goals = blacklist_.entries(this->now());
  if (candidates.empty() && !selected.has_value() && blacklisted_goals.empty()) {
    publishDeleteAllMarkers(map_header);
    return;
  }

  visualization_msgs::msg::MarkerArray markers;
  visualization_msgs::msg::Marker clear_marker;
  clear_marker.header = map_header;
  clear_marker.header.frame_id =
    params_.global_frame.empty() ? map_header.frame_id : params_.global_frame;
  clear_marker.ns = "ros2_exploration_frontiers";
  clear_marker.id = 0;
  clear_marker.action = visualization_msgs::msg::Marker::DELETEALL;
  markers.markers.push_back(clear_marker);

  int marker_id = 1;
  for (const auto & candidate : candidates) {
    visualization_msgs::msg::Marker goal_marker;
    goal_marker.header = clear_marker.header;
    goal_marker.ns = "ros2_exploration_frontier_goals";
    goal_marker.id = marker_id++;
    goal_marker.type = visualization_msgs::msg::Marker::SPHERE;
    goal_marker.action = visualization_msgs::msg::Marker::ADD;
    goal_marker.pose.position = candidate.goal.pose.position;
    goal_marker.pose.position.z = 0.05;
    goal_marker.pose.orientation.w = 1.0;
    goal_marker.scale.x = candidate.near_recent_goal ? 0.12 : 0.16;
    goal_marker.scale.y = goal_marker.scale.x;
    goal_marker.scale.z = goal_marker.scale.x;
    goal_marker.color.r = candidate.near_recent_goal ? 0.8F : 0.1F;
    goal_marker.color.g = 0.85F;
    goal_marker.color.b = candidate.near_recent_goal ? 0.1F : 0.25F;
    goal_marker.color.a = 0.85F;
    setMarkerLifetime(goal_marker);
    markers.markers.push_back(goal_marker);

    visualization_msgs::msg::Marker center_marker;
    center_marker.header = clear_marker.header;
    center_marker.ns = "ros2_exploration_frontier_centers";
    center_marker.id = marker_id++;
    center_marker.type = visualization_msgs::msg::Marker::CUBE;
    center_marker.action = visualization_msgs::msg::Marker::ADD;
    center_marker.pose.position = candidate.frontier.centroid;
    center_marker.pose.position.z = 0.03;
    center_marker.pose.orientation.w = 1.0;
    center_marker.scale.x = 0.10;
    center_marker.scale.y = 0.10;
    center_marker.scale.z = 0.10;
    center_marker.color.r = 0.1F;
    center_marker.color.g = 0.45F;
    center_marker.color.b = 1.0F;
    center_marker.color.a = 0.70F;
    setMarkerLifetime(center_marker);
    markers.markers.push_back(center_marker);
  }

  for (const auto & blacklisted_goal : blacklisted_goals) {
    visualization_msgs::msg::Marker blacklist_marker;
    blacklist_marker.header = clear_marker.header;
    blacklist_marker.ns = "ros2_exploration_blacklist";
    blacklist_marker.id = marker_id++;
    blacklist_marker.type = visualization_msgs::msg::Marker::CUBE;
    blacklist_marker.action = visualization_msgs::msg::Marker::ADD;
    blacklist_marker.pose.position = blacklisted_goal.point;
    blacklist_marker.pose.position.z = 0.08;
    blacklist_marker.pose.orientation.w = 1.0;
    blacklist_marker.scale.x = std::max(0.08, params_.blacklist_radius_m * 2.0);
    blacklist_marker.scale.y = blacklist_marker.scale.x;
    blacklist_marker.scale.z = 0.06;
    blacklist_marker.color.r = 1.0F;
    blacklist_marker.color.g = 0.1F;
    blacklist_marker.color.b = 0.1F;
    blacklist_marker.color.a = 0.85F;
    setMarkerLifetime(blacklist_marker);
    markers.markers.push_back(blacklist_marker);
  }

  if (selected.has_value()) {
    visualization_msgs::msg::Marker selected_marker;
    selected_marker.header = clear_marker.header;
    selected_marker.ns = "ros2_exploration_selected_goal";
    selected_marker.id = marker_id++;
    selected_marker.type = visualization_msgs::msg::Marker::SPHERE;
    selected_marker.action = visualization_msgs::msg::Marker::ADD;
    selected_marker.pose = selected->goal.pose;
    selected_marker.pose.position.z = 0.10;
    selected_marker.scale.x = 0.28;
    selected_marker.scale.y = 0.28;
    selected_marker.scale.z = 0.28;
    selected_marker.color.r = 1.0F;
    selected_marker.color.g = 0.65F;
    selected_marker.color.b = 0.05F;
    selected_marker.color.a = 1.0F;
    setMarkerLifetime(selected_marker);
    markers.markers.push_back(selected_marker);
  }

  frontiers_pub_->publish(markers);
}

void ExplorerNode::publishGraphMarkers(
  const ExplorerSnapshot & snapshot,
  const geometry_msgs::msg::Pose & current_pose,
  const std::optional<geometry_msgs::msg::Point> & goal_point)
{
  if (!graph_pub_ || !snapshot.global_costmap) {
    return;
  }

  const auto & costmap = *snapshot.global_costmap;
  if (costmap.info.resolution <= 0.0 || costmap.info.width == 0 || costmap.info.height == 0) {
    publishDeleteAllGraphMarkers(costmap.header);
    return;
  }

  if (params_.graph_marker_min_period_s > 0.0) {
    const rclcpp::Time now = this->now();
    if (last_graph_marker_publish_time_.nanoseconds() != 0 &&
      (now - last_graph_marker_publish_time_).seconds() < params_.graph_marker_min_period_s)
    {
      return;
    }
    last_graph_marker_publish_time_ = now;
  }

  const double graph_step = params_.graph_motion_step_m;
  const double priority_tile_size = params_.graph_priority_tile_size_m;
  const double width_m = static_cast<double>(costmap.info.width) * costmap.info.resolution;
  const double height_m = static_cast<double>(costmap.info.height) * costmap.info.resolution;
  const int graph_width = std::max(1, static_cast<int>(std::ceil(width_m / graph_step)));
  const int graph_height = std::max(1, static_cast<int>(std::ceil(height_m / graph_step)));

  std_msgs::msg::Header header = costmap.header;
  header.frame_id = params_.global_frame.empty() ? costmap.header.frame_id : params_.global_frame;

  visualization_msgs::msg::MarkerArray markers;
  visualization_msgs::msg::Marker clear_marker;
  clear_marker.header = header;
  clear_marker.ns = "ros2_exploration_tile_graph";
  clear_marker.id = 0;
  clear_marker.action = visualization_msgs::msg::Marker::DELETEALL;
  markers.markers.push_back(clear_marker);

  std::size_t nodes_count = 0;
  std::size_t edges_count = 0;
  std::size_t priority_center_count = 0;

  // Full lattice visualization is useful but expensive: it publishes every free
  // graph vertex/edge in the entire costmap.  Keep it available behind an
  // explicit parameter, but default to active_path to avoid RViz becoming the
  // simulation bottleneck.
  if (params_.graph_visualization_mode == "full") {
    visualization_msgs::msg::Marker nodes;
    nodes.header = header;
    nodes.ns = "ros2_exploration_tile_graph_nodes";
    nodes.id = 1;
    nodes.type = visualization_msgs::msg::Marker::CUBE_LIST;
    nodes.action = visualization_msgs::msg::Marker::ADD;
    nodes.pose.orientation.w = 1.0;
    nodes.scale.x = graph_step * 0.28;
    nodes.scale.y = graph_step * 0.28;
    nodes.scale.z = 0.018;
    nodes.color.r = 0.10F;
    nodes.color.g = 0.55F;
    nodes.color.b = 1.00F;
    nodes.color.a = 0.35F;
    setMarkerLifetime(nodes);

    visualization_msgs::msg::Marker edges;
    edges.header = header;
    edges.ns = "ros2_exploration_tile_graph_edges";
    edges.id = 2;
    edges.type = visualization_msgs::msg::Marker::LINE_LIST;
    edges.action = visualization_msgs::msg::Marker::ADD;
    edges.pose.orientation.w = 1.0;
    edges.scale.x = 0.004;
    edges.color.r = 0.55F;
    edges.color.g = 0.63F;
    edges.color.b = 0.70F;
    edges.color.a = 0.22F;
    setMarkerLifetime(edges);

    visualization_msgs::msg::Marker priority_centers;
    priority_centers.header = header;
    priority_centers.ns = "ros2_exploration_tile_graph_priority_centers";
    priority_centers.id = 5;
    priority_centers.type = visualization_msgs::msg::Marker::SPHERE_LIST;
    priority_centers.action = visualization_msgs::msg::Marker::ADD;
    priority_centers.pose.orientation.w = 1.0;
    priority_centers.scale.x = priority_tile_size * 0.20;
    priority_centers.scale.y = priority_centers.scale.x;
    priority_centers.scale.z = 0.018;
    priority_centers.color.r = 0.20F;
    priority_centers.color.g = 1.00F;
    priority_centers.color.b = 0.42F;
    priority_centers.color.a = 0.42F;
    setMarkerLifetime(priority_centers);

    const std::vector<TileGraphCell> edge_offsets = params_.graph_allow_diagonal
      ? std::vector<TileGraphCell>{{1, 0}, {0, 1}, {1, 1}, {1, -1}}
      : std::vector<TileGraphCell>{{1, 0}, {0, 1}};

    for (int y = 0; y < graph_height; ++y) {
      for (int x = 0; x < graph_width; ++x) {
        const TileGraphCell cell{x, y};
        if (!graphCellFree(costmap, graph_step, cell, params_.frontier_occ_threshold)) {
          continue;
        }

        geometry_msgs::msg::Point center =
          tileGraphCellCenter(costmap, graph_step, cell);
        center.z = 0.08;
        nodes.points.push_back(center);

        for (const auto & offset : edge_offsets) {
          const TileGraphCell next{x + offset.x, y + offset.y};
          if (next.x < 0 || next.y < 0 || next.x >= graph_width || next.y >= graph_height) {
            continue;
          }
          if (!graphCellFree(costmap, graph_step, next, params_.frontier_occ_threshold)) {
            continue;
          }
          if (!graphEdgeFree(costmap, graph_step, cell, next, params_.frontier_occ_threshold)) {
            continue;
          }
          geometry_msgs::msg::Point a = center;
          geometry_msgs::msg::Point b = tileGraphCellCenter(costmap, graph_step, next);
          b.z = 0.08;
          edges.points.push_back(a);
          edges.points.push_back(b);
        }
      }
    }

    const int priority_width =
      std::max(1, static_cast<int>(std::ceil(width_m / priority_tile_size)));
    const int priority_height =
      std::max(1, static_cast<int>(std::ceil(height_m / priority_tile_size)));
    for (int y = 0; y < priority_height; ++y) {
      for (int x = 0; x < priority_width; ++x) {
        geometry_msgs::msg::Point center =
          priorityTileCenterPoint(costmap, priority_tile_size, x, y);
        if (!pointInsideCostmap(costmap, center)) {
          continue;
        }
        if (!graphPointFree(costmap, center, params_.frontier_occ_threshold)) {
          continue;
        }
        center.z = 0.105;
        priority_centers.points.push_back(center);
      }
    }

    nodes_count = nodes.points.size();
    edges_count = edges.points.size() / 2;
    priority_center_count = priority_centers.points.size();
    markers.markers.push_back(nodes);
    markers.markers.push_back(edges);
    markers.markers.push_back(priority_centers);
  }

  std::vector<geometry_msgs::msg::Point> path;
  if (goal_point.has_value()) {
    path = graphPathToGoal(
      costmap,
      graph_step,
      params_.graph_allow_diagonal,
      params_.frontier_occ_threshold,
      current_pose,
      *goal_point);
  }

  if (!path.empty()) {
    visualization_msgs::msg::Marker path_marker;
    path_marker.header = header;
    path_marker.ns = "ros2_exploration_tile_graph_selected_path";
    path_marker.id = 3;
    path_marker.type = visualization_msgs::msg::Marker::LINE_STRIP;
    path_marker.action = visualization_msgs::msg::Marker::ADD;
    path_marker.pose.orientation.w = 1.0;
    path_marker.scale.x = 0.026;
    path_marker.color.r = 1.0F;
    path_marker.color.g = 0.62F;
    path_marker.color.b = 0.05F;
    path_marker.color.a = 1.0F;
    path_marker.points = path;
    setMarkerLifetime(path_marker);
    markers.markers.push_back(path_marker);

    visualization_msgs::msg::Marker path_centers;
    path_centers.header = header;
    path_centers.ns = "ros2_exploration_tile_graph_path_centers";
    path_centers.id = 6;
    path_centers.type = visualization_msgs::msg::Marker::SPHERE_LIST;
    path_centers.action = visualization_msgs::msg::Marker::ADD;
    path_centers.pose.orientation.w = 1.0;
    path_centers.scale.x = std::max(0.018, graph_step * 0.28);
    path_centers.scale.y = path_centers.scale.x;
    path_centers.scale.z = 0.016;
    path_centers.color.r = 0.18F;
    path_centers.color.g = 0.72F;
    path_centers.color.b = 1.0F;
    path_centers.color.a = 0.90F;
    path_centers.points = path;
    for (auto & point : path_centers.points) {
      point.z = 0.145;
    }
    setMarkerLifetime(path_centers);
    markers.markers.push_back(path_centers);
  }

  visualization_msgs::msg::Marker robot_marker;
  robot_marker.header = header;
  robot_marker.ns = "ros2_exploration_tile_graph_robot";
  robot_marker.id = 7;
  robot_marker.type = visualization_msgs::msg::Marker::SPHERE;
  robot_marker.action = visualization_msgs::msg::Marker::ADD;
  robot_marker.pose.position = current_pose.position;
  robot_marker.pose.position.z = 0.18;
  robot_marker.pose.orientation.w = 1.0;
  robot_marker.scale.x = priority_tile_size * 0.48;
  robot_marker.scale.y = robot_marker.scale.x;
  robot_marker.scale.z = 0.035;
  robot_marker.color.r = 0.10F;
  robot_marker.color.g = 0.70F;
  robot_marker.color.b = 1.0F;
  robot_marker.color.a = 0.95F;
  setMarkerLifetime(robot_marker);
  markers.markers.push_back(robot_marker);

  if (goal_point.has_value()) {
    visualization_msgs::msg::Marker goal_marker;
    goal_marker.header = header;
    goal_marker.ns = "ros2_exploration_tile_graph_path_goal";
    goal_marker.id = 4;
    goal_marker.type = visualization_msgs::msg::Marker::SPHERE;
    goal_marker.action = visualization_msgs::msg::Marker::ADD;
    goal_marker.pose.position = *goal_point;
    goal_marker.pose.position.z = 0.18;
    goal_marker.pose.orientation.w = 1.0;
    goal_marker.scale.x = priority_tile_size * 0.65;
    goal_marker.scale.y = goal_marker.scale.x;
    goal_marker.scale.z = 0.040;
    goal_marker.color.r = 1.0F;
    goal_marker.color.g = 0.80F;
    goal_marker.color.b = 0.05F;
    goal_marker.color.a = 0.95F;
    setMarkerLifetime(goal_marker);
    markers.markers.push_back(goal_marker);
  }

  graph_pub_->publish(markers);
  RCLCPP_INFO_THROTTLE(
    this->get_logger(),
    *this->get_clock(),
    2000,
    "Published tile graph: mode=%s movement_step=%.3f priority_tile=%.3f full_nodes=%zu full_edges=%zu full_priority_centers=%zu path_points=%zu goal=%s",
    params_.graph_visualization_mode.c_str(),
    graph_step,
    priority_tile_size,
    nodes_count,
    edges_count,
    priority_center_count,
    path.size(),
    goal_point.has_value() ? "true" : "false");
}

void ExplorerNode::publishDeleteAllMarkers(const std_msgs::msg::Header & map_header)
{
  visualization_msgs::msg::MarkerArray markers;
  visualization_msgs::msg::Marker marker;
  marker.header = map_header;
  marker.header.frame_id =
    params_.global_frame.empty() ? map_header.frame_id : params_.global_frame;
  marker.ns = "ros2_exploration_frontiers";
  marker.id = 0;
  marker.action = visualization_msgs::msg::Marker::DELETEALL;
  markers.markers.push_back(marker);
  frontiers_pub_->publish(markers);
}

void ExplorerNode::publishDeleteAllGraphMarkers(const std_msgs::msg::Header & header)
{
  if (!graph_pub_) {
    return;
  }

  visualization_msgs::msg::MarkerArray markers;
  visualization_msgs::msg::Marker marker;
  marker.header = header;
  marker.header.frame_id = params_.global_frame.empty() ? header.frame_id : params_.global_frame;
  marker.ns = "ros2_exploration_tile_graph";
  marker.id = 0;
  marker.action = visualization_msgs::msg::Marker::DELETEALL;
  markers.markers.push_back(marker);
  graph_pub_->publish(markers);
}

}  // namespace ros2_exploration
