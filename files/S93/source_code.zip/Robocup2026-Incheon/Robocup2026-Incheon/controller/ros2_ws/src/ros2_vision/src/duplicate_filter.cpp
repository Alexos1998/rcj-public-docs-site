#include "ros2_vision/duplicate_filter.hpp"

#include <sstream>

namespace ros2_vision {

DuplicateFilter::DuplicateFilter(std::string scope)
  : scope_(std::move(scope))
{
}

bool DuplicateFilter::tileAlreadyReported(int tile_x, int tile_y) const
{
  return reported_tiles_.count(tileKey(tile_x, tile_y)) > 0;
}

void DuplicateFilter::markTileReported(int tile_x, int tile_y)
{
  reported_tiles_.insert(tileKey(tile_x, tile_y));
}

std::string DuplicateFilter::tileKey(int tile_x, int tile_y) const
{
  std::ostringstream oss;
  oss << tile_x << '|' << tile_y;
  return oss.str();
}

bool DuplicateFilter::seen(int tile_x,
                           int tile_y,
                           int camera_id,
                           const std::string& kind,
                           const std::string& class_name) const
{
  return reported_.count(makeKey(tile_x, tile_y, camera_id, kind, class_name)) > 0;
}

void DuplicateFilter::mark(int tile_x,
                           int tile_y,
                           int camera_id,
                           const std::string& kind,
                           const std::string& class_name)
{
  reported_.insert(makeKey(tile_x, tile_y, camera_id, kind, class_name));
}

std::string DuplicateFilter::makeKey(int tile_x,
                                     int tile_y,
                                     int camera_id,
                                     const std::string& kind,
                                     const std::string& class_name) const
{
  std::ostringstream oss;
  if (scope_ == "tile") {
    oss << tile_x << '|' << tile_y << '|';
  } else {
    oss << "global|";
  }
  oss << camera_id << '|' << kind << '|' << class_name;
  return oss.str();
}

}  // namespace ros2_vision
