#pragma once

#include <memory>
#include <string>

#include "target_legacy/target_legacy.hpp"

#include "ros2_vision/target_mask_rf.hpp"
#include "ros2_vision/target_radial_classifier.hpp"
#include "ros2_vision/vision_protocol.hpp"

namespace ros2_vision {

struct TargetDetectorConfig {
  // "rf_radial" (default, primary) or "legacy".
  std::string mode = "rf_radial";
  bool allow_legacy_fallback = true;
  std::string rf_model_path;            // target_mask_rf.yml
  std::string rf_feature_config_path;   // target_mask_features.yml
  int min_mask_area_px = 60;
  TargetRadialConfig radial;
  target_legacy::TargetLegacyConfig legacy;
};

// Primary path: whole-target mask (Random Forest) -> center -> radial ring read
// -> sum -> F/P/C/O. The legacy ellipse detector is kept only as a configurable
// fallback (used when the RF model fails to load and allow_legacy_fallback).
class TargetDetector {
public:
  TargetDetector() = default;
  explicit TargetDetector(TargetDetectorConfig config);

  TargetResult detect(const cv::Mat& bgr) const;

  bool usingRandomForest() const { return mask_rf_ && mask_rf_->loaded() && config_.mode == "rf_radial"; }
  const std::string& lastLoadError() const { return load_error_; }

private:
  TargetResult detectRfRadial(const cv::Mat& bgr) const;
  TargetResult detectLegacy(const cv::Mat& bgr) const;

  TargetDetectorConfig config_;
  std::shared_ptr<TargetMaskRF> mask_rf_;
  std::string load_error_;
};

}  // namespace ros2_vision
