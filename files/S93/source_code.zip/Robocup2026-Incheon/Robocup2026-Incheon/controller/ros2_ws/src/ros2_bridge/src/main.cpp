#include "ros2_bridge/bridge_node.hpp"

#include <rclcpp/rclcpp.hpp>

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<ros2_bridge::BridgeNode>());
  rclcpp::shutdown();
  return 0;
}
