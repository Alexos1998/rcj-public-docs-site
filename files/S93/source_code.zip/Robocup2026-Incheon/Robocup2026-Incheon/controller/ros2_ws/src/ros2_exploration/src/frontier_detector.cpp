#include "ros2_exploration/frontier_detector.hpp"

#include <array>
#include <queue>

#include "ros2_exploration/grid_utils.hpp"

namespace ros2_exploration
{

namespace
{

constexpr std::array<GridIndex, 4> kCardinalNeighbors{
  GridIndex{1, 0},
  GridIndex{-1, 0},
  GridIndex{0, 1},
  GridIndex{0, -1},
};

}  // namespace

FrontierDetector::FrontierDetector(int occupied_threshold, std::size_t min_frontier_size)
: occupied_threshold_(occupied_threshold),
  min_frontier_size_(min_frontier_size)
{
}

std::vector<Frontier> FrontierDetector::detect(const nav_msgs::msg::OccupancyGrid & map) const
{
  std::vector<Frontier> frontiers;

  if (map.info.width == 0U || map.info.height == 0U || map.data.empty()) {
    return frontiers;
  }

  std::vector<bool> visited(map.data.size(), false);

  for (int y = 0; y < static_cast<int>(map.info.height); ++y) {
    for (int x = 0; x < static_cast<int>(map.info.width); ++x) {
      const auto linear_index = grid_utils::toLinearIndex(map, x, y);
      if (linear_index >= visited.size() || visited[linear_index]) {
        continue;
      }

      const GridIndex index{x, y};
      if (!isFrontierCell(map, index)) {
        continue;
      }

      Frontier frontier = buildFrontier(map, index, visited);
      if (frontier.cells.size() >= min_frontier_size_) {
        frontiers.push_back(frontier);
      }
    }
  }

  return frontiers;
}

void FrontierDetector::setOccupiedThreshold(int occupied_threshold)
{
  occupied_threshold_ = occupied_threshold;
}

void FrontierDetector::setMinFrontierSize(std::size_t min_frontier_size)
{
  min_frontier_size_ = min_frontier_size;
}

bool FrontierDetector::isFrontierCell(
  const nav_msgs::msg::OccupancyGrid & map,
  const GridIndex & index) const
{
  if (!grid_utils::isInBounds(map, index.x, index.y)) {
    return false;
  }

  const auto value = grid_utils::occupancyAt(map, index.x, index.y);
  if (!grid_utils::isFree(value, occupied_threshold_)) {
    return false;
  }

  for (const auto & offset : kCardinalNeighbors) {
    const int neighbor_x = index.x + offset.x;
    const int neighbor_y = index.y + offset.y;
    if (!grid_utils::isInBounds(map, neighbor_x, neighbor_y)) {
      continue;
    }

    if (grid_utils::isUnknown(grid_utils::occupancyAt(map, neighbor_x, neighbor_y))) {
      return true;
    }
  }

  return false;
}

Frontier FrontierDetector::buildFrontier(
  const nav_msgs::msg::OccupancyGrid & map,
  const GridIndex & seed,
  std::vector<bool> & visited) const
{
  Frontier frontier;
  std::queue<GridIndex> queue;
  queue.push(seed);

  double sum_x = 0.0;
  double sum_y = 0.0;
  double sum_z = 0.0;

  while (!queue.empty()) {
    const GridIndex current = queue.front();
    queue.pop();

    if (!grid_utils::isInBounds(map, current.x, current.y)) {
      continue;
    }

    const auto linear_index = grid_utils::toLinearIndex(map, current.x, current.y);
    if (linear_index >= visited.size() || visited[linear_index]) {
      continue;
    }

    visited[linear_index] = true;
    if (!isFrontierCell(map, current)) {
      continue;
    }

    FrontierCell cell;
    cell.index = current;
    cell.world = grid_utils::gridToWorld(map, current);
    frontier.cells.push_back(cell);

    sum_x += cell.world.x;
    sum_y += cell.world.y;
    sum_z += cell.world.z;

    for (const auto & offset : kCardinalNeighbors) {
      const GridIndex neighbor{current.x + offset.x, current.y + offset.y};
      if (!grid_utils::isInBounds(map, neighbor.x, neighbor.y)) {
        continue;
      }

      const auto neighbor_index = grid_utils::toLinearIndex(map, neighbor.x, neighbor.y);
      if (neighbor_index < visited.size() && !visited[neighbor_index]) {
        queue.push(neighbor);
      }
    }
  }

  if (!frontier.cells.empty()) {
    const double count = static_cast<double>(frontier.cells.size());
    frontier.centroid.x = sum_x / count;
    frontier.centroid.y = sum_y / count;
    frontier.centroid.z = sum_z / count;
  }

  return frontier;
}

}  // namespace ros2_exploration
