#include "ros2_exploration/grid_utils.hpp"

#include <cmath>
#include <cstddef>

#include "tf2_geometry_msgs/tf2_geometry_msgs.hpp"
#include "tf2/utils.h"

namespace ros2_exploration::grid_utils
{

bool isInBounds(const nav_msgs::msg::OccupancyGrid & map, int x, int y)
{
  return x >= 0 && y >= 0 &&
         x < static_cast<int>(map.info.width) &&
         y < static_cast<int>(map.info.height);
}

std::size_t toLinearIndex(const nav_msgs::msg::OccupancyGrid & map, int x, int y)
{
  return static_cast<std::size_t>(y) * static_cast<std::size_t>(map.info.width) +
         static_cast<std::size_t>(x);
}

int8_t occupancyAt(const nav_msgs::msg::OccupancyGrid & map, int x, int y)
{
  if (!isInBounds(map, x, y)) {
    return 100;
  }

  const auto index = toLinearIndex(map, x, y);
  if (index >= map.data.size()) {
    return 100;
  }

  return map.data[index];
}

bool isUnknown(int8_t value)
{
  return value < 0;
}

bool isOccupied(int8_t value, int occupied_threshold)
{
  return value >= occupied_threshold;
}

bool isFree(int8_t value, int occupied_threshold)
{
  return value >= 0 && !isOccupied(value, occupied_threshold);
}

geometry_msgs::msg::Point gridToWorld(
  const nav_msgs::msg::OccupancyGrid & map,
  const GridIndex & index)
{
  const double resolution = static_cast<double>(map.info.resolution);
  const double local_x = (static_cast<double>(index.x) + 0.5) * resolution;
  const double local_y = (static_cast<double>(index.y) + 0.5) * resolution;
  const double yaw = tf2::getYaw(map.info.origin.orientation);
  const double cos_yaw = std::cos(yaw);
  const double sin_yaw = std::sin(yaw);

  geometry_msgs::msg::Point point;
  point.x = map.info.origin.position.x + cos_yaw * local_x - sin_yaw * local_y;
  point.y = map.info.origin.position.y + sin_yaw * local_x + cos_yaw * local_y;
  point.z = map.info.origin.position.z;
  return point;
}

bool worldToGrid(
  const nav_msgs::msg::OccupancyGrid & map,
  const geometry_msgs::msg::Point & point,
  GridIndex & index)
{
  if (map.info.resolution <= 0.0F) {
    return false;
  }

  const double yaw = tf2::getYaw(map.info.origin.orientation);
  const double cos_yaw = std::cos(yaw);
  const double sin_yaw = std::sin(yaw);
  const double dx = point.x - map.info.origin.position.x;
  const double dy = point.y - map.info.origin.position.y;

  const double local_x = cos_yaw * dx + sin_yaw * dy;
  const double local_y = -sin_yaw * dx + cos_yaw * dy;

  index.x = static_cast<int>(std::floor(local_x / map.info.resolution));
  index.y = static_cast<int>(std::floor(local_y / map.info.resolution));
  return isInBounds(map, index.x, index.y);
}

}  // namespace ros2_exploration::grid_utils
