#pragma once

#include <atomic>
#include <cstddef>
#include <map>
#include <mutex>
#include <string>
#include <thread>

#include "ros2_vision/vision_protocol.hpp"

namespace ros2_vision {

class TcpFrameServer {
public:
  TcpFrameServer(std::string host, int port, std::size_t recv_buffer_bytes);
  ~TcpFrameServer();

  TcpFrameServer(const TcpFrameServer&) = delete;
  TcpFrameServer& operator=(const TcpFrameServer&) = delete;

  bool start();
  void stop();
  bool getLatestFrame(VisionFrame& out);
  std::uint64_t receivedFrames() const { return received_frames_.load(); }

private:
  void run();
  bool readOneFrame(int client_fd);
  bool readExact(int fd, void* data, std::size_t size);
  bool decodeFrame(const VisionFrameHeader& header,
                   const std::vector<float>& ranges,
                   const std::vector<std::uint8_t>& image,
                   VisionFrame& out);
  void closeListenSocket();

  std::string host_;
  int port_ = 5100;
  std::size_t recv_buffer_bytes_ = 1048576;
  int listen_fd_ = -1;
  std::atomic<bool> running_{false};
  std::thread thread_;

  // Per-camera latest-frame slot. A single shared slot let two cameras arriving
  // back-to-back overwrite one another before the worker polled, dropping the
  // left camera. Keyed per camera_id so each side keeps its own most-recent
  // frame; getLatestFrame round-robins across cameras so neither side starves.
  struct CameraSlot {
    VisionFrame frame;
    std::uint64_t generation = 0;
    std::uint64_t consumed = 0;
    bool has = false;
  };

  mutable std::mutex mutex_;
  std::map<int, CameraSlot> cameras_;
  int round_robin_cursor_ = -1;
  std::atomic<std::uint64_t> received_frames_{0};
};

}  // namespace ros2_vision
