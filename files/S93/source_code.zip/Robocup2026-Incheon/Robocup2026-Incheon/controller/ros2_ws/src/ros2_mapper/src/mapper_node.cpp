#include "ros2_mapper/mapper_node.hpp"
#include "ros2_mapper/submission_matrix_builder.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <functional>
#include <iomanip>
#include <limits>
#include <stdexcept>
#include <utility>
#include <chrono>
#include <cctype>
#include <cinttypes>
#include <deque>
#include <sstream>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include <tf2/time.h>

namespace ros2_mapper
{

namespace
{

std::string sanitizeRobotEventValue(const std::string & value)
{
  if (value.empty()) {
    return "none";
  }

  std::string out = value;
  for (auto & ch : out) {
    if (std::isspace(static_cast<unsigned char>(ch))) {
      ch = '_';
    }
  }
  return out;
}

std::string boolText(bool value)
{
  return value ? "true" : "false";
}

std::string numberText(double value, int precision = 3)
{
  if (!std::isfinite(value)) {
    return "none";
  }
  std::ostringstream oss;
  oss << std::fixed << std::setprecision(precision) << value;
  return oss.str();
}

const char * floorColorClassToLogString(FloorColorClass color_class)
{
  switch (color_class) {
    case FloorColorClass::Normal:
      return "NORMAL";
    case FloorColorClass::BlackHoleBorder:
      return "BLACK_HOLE_BORDER";
    case FloorColorClass::SilverCheckpoint:
      return "SILVER_CHECKPOINT";
    case FloorColorClass::BrownSwamp:
      return "BROWN_SWAMP";
    case FloorColorClass::BlueArea1To2:
      return "BLUE_AREA_1_2";
    case FloorColorClass::YellowArea1To3:
      return "YELLOW_AREA_1_3";
    case FloorColorClass::GreenArea1To4:
      return "GREEN_AREA_1_4";
    case FloorColorClass::PurpleArea2To3:
      return "PURPLE_AREA_2_3";
    case FloorColorClass::OrangeArea2To4:
      return "ORANGE_AREA_2_4";
    case FloorColorClass::RedArea3To4:
      return "RED_AREA_3_4";
    case FloorColorClass::Unknown:
    default:
      return "UNKNOWN";
  }
}

struct PhantomQuadrantKey
{
  TileCoord coord;
  TileQuadrant quadrant;

  bool operator==(const PhantomQuadrantKey & other) const noexcept
  {
    return coord == other.coord && quadrant == other.quadrant;
  }
};

struct PhantomQuadrantKeyHash
{
  std::size_t operator()(const PhantomQuadrantKey & key) const noexcept
  {
    const auto coord_hash = TileCoordHash{}(key.coord);
    const auto quadrant_hash = std::hash<int>{}(static_cast<int>(key.quadrant));
    return coord_hash ^ (
      quadrant_hash + 0x9e3779b9U + (coord_hash << 6U) + (coord_hash >> 2U));
  }
};

struct PhantomSupportBinKey
{
  TileCoord coord;
  int bin_index;

  bool operator==(const PhantomSupportBinKey & other) const noexcept
  {
    return coord == other.coord && bin_index == other.bin_index;
  }
};

struct PhantomSupportBinKeyHash
{
  std::size_t operator()(const PhantomSupportBinKey & key) const noexcept
  {
    const auto coord_hash = TileCoordHash{}(key.coord);
    const auto bin_hash = std::hash<int>{}(key.bin_index);
    return coord_hash ^ (bin_hash + 0x9e3779b9U + (coord_hash << 6U) + (coord_hash >> 2U));
  }
};

struct PhantomPrimitiveSubtileKey
{
  TileCoord coord;
  SubtileIndex subtile;

  bool operator==(const PhantomPrimitiveSubtileKey & other) const noexcept
  {
    return coord == other.coord && subtile == other.subtile;
  }
};

struct PhantomPrimitiveSubtileKeyHash
{
  std::size_t operator()(const PhantomPrimitiveSubtileKey & key) const noexcept
  {
    const auto coord_hash = TileCoordHash{}(key.coord);
    const auto subtile_hash = std::hash<int>{}(static_cast<int>(key.subtile));
    return coord_hash ^ (
      subtile_hash + 0x9e3779b9U + (coord_hash << 6U) + (coord_hash >> 2U));
  }
};

struct PhantomQuarterEdgeKey
{
  TileCoord coord;
  CanonicalSegmentKey segment;

  bool operator==(const PhantomQuarterEdgeKey & other) const noexcept
  {
    return coord == other.coord && segment == other.segment;
  }
};

struct PhantomQuarterEdgeKeyHash
{
  std::size_t operator()(const PhantomQuarterEdgeKey & key) const noexcept
  {
    const auto coord_hash = TileCoordHash{}(key.coord);
    std::size_t segment_hash =
      std::hash<int>{}(static_cast<int>(key.segment.orientation));
    segment_hash ^= std::hash<int>{}(key.segment.line) + 0x9e3779b9U +
      (segment_hash << 6U) + (segment_hash >> 2U);
    segment_hash ^= std::hash<int>{}(key.segment.offset) + 0x9e3779b9U +
      (segment_hash << 6U) + (segment_hash >> 2U);
    return coord_hash ^ (
      segment_hash + 0x9e3779b9U + (coord_hash << 6U) + (coord_hash >> 2U));
  }
};

struct PhantomPrimitiveMarkerKey
{
  TileCoord coord;
  SubtileIndex subtile;
  PrimitiveKind primitive;
};

struct PhantomPrimitiveMarkerKeyHash
{
  std::size_t operator()(const PhantomPrimitiveMarkerKey & key) const noexcept
  {
    std::size_t hash = TileCoordHash{}(key.coord);
    hash ^= std::hash<int>{}(static_cast<int>(key.subtile)) + 0x9e3779b9U +
      (hash << 6U) + (hash >> 2U);
    hash ^= std::hash<int>{}(static_cast<int>(key.primitive)) + 0x9e3779b9U +
      (hash << 6U) + (hash >> 2U);
    return hash;
  }
};

struct PhantomObstacleGridBinKey
{
  TileCoord coord;
  int bin_index;

  bool operator==(const PhantomObstacleGridBinKey & other) const noexcept
  {
    return coord == other.coord && bin_index == other.bin_index;
  }
};

struct PhantomObstacleGridBinKeyHash
{
  std::size_t operator()(const PhantomObstacleGridBinKey & key) const noexcept
  {
    const auto coord_hash = TileCoordHash{}(key.coord);
    const auto bin_hash = std::hash<int>{}(key.bin_index);
    return coord_hash ^ (bin_hash + 0x9e3779b9U + (coord_hash << 6U) + (coord_hash >> 2U));
  }
};

struct ObstacleClusterCandidate
{
  bool valid = false;
  double center_local_x = 0.0;
  double center_local_y = 0.0;
  double width_m = 0.0;
  double length_m = 0.0;
  double min_local_x = 0.0;
  double min_local_y = 0.0;
  double max_local_x = 0.0;
  double max_local_y = 0.0;
  double hit_score = 0.0;
  double free_score = 0.0;
  double confidence = 0.0;
  double free_ratio = 0.0;
  double surrounding_free_ratio = 0.0;
  double wall_overlap_penalty = 0.0;
  double edge_proximity_penalty = 0.0;
  int cluster_bins = 0;
  int total_hits = 0;
  int free_count = 0;
};

double lidarObservationWeight(double range, double scale)
{
  return 1.0 / (1.0 + range / scale);
}

double evidenceAlpha(double value, double alpha_min, double alpha_max)
{
  const double normalized = std::clamp(value / 10.0, 0.0, 1.0);
  return alpha_min + (alpha_max - alpha_min) * normalized;
}

double clamp01(double value)
{
  return std::clamp(value, 0.0, 1.0);
}

bool jsonFieldToken(const std::string & json, const std::string & field, std::string * token)
{
  if (token == nullptr) {
    return false;
  }

  const std::string key = "\"" + field + "\"";
  const auto key_pos = json.find(key);
  if (key_pos == std::string::npos) {
    return false;
  }

  const auto colon_pos = json.find(':', key_pos + key.size());
  if (colon_pos == std::string::npos) {
    return false;
  }

  auto value_pos = colon_pos + 1U;
  while (value_pos < json.size() && std::isspace(static_cast<unsigned char>(json[value_pos]))) {
    ++value_pos;
  }

  auto end_pos = value_pos;
  while (
    end_pos < json.size() &&
    json[end_pos] != ',' &&
    json[end_pos] != '}')
  {
    ++end_pos;
  }

  while (end_pos > value_pos && std::isspace(static_cast<unsigned char>(json[end_pos - 1U]))) {
    --end_pos;
  }

  *token = json.substr(value_pos, end_pos - value_pos);
  return true;
}

bool jsonBoolField(const std::string & json, const std::string & field, bool * value)
{
  std::string token;
  if (!jsonFieldToken(json, field, &token)) {
    return false;
  }

  if (token == "true") {
    *value = true;
    return true;
  }
  if (token == "false") {
    *value = false;
    return true;
  }

  return false;
}

bool jsonUInt64Field(const std::string & json, const std::string & field, std::uint64_t * value)
{
  std::string token;
  if (!jsonFieldToken(json, field, &token)) {
    return false;
  }

  try {
    std::size_t parsed_chars = 0;
    const auto parsed = std::stoull(token, &parsed_chars);
    if (parsed_chars != token.size()) {
      return false;
    }
    *value = static_cast<std::uint64_t>(parsed);
    return true;
  } catch (const std::exception &) {
    return false;
  }
}

const char * cardinalDirectionBetweenAdjacentTiles(
  const TileCoord & from,
  const TileCoord & to)
{
  const int dx = to.x - from.x;
  const int dy = to.y - from.y;
  if (dx == 1 && dy == 0) {
    return "E";
  }
  if (dx == -1 && dy == 0) {
    return "W";
  }
  if (dx == 0 && dy == 1) {
    return "N";
  }
  if (dx == 0 && dy == -1) {
    return "S";
  }
  return nullptr;
}

const char * cardinalDirectionForYaw(double yaw)
{
  const double c = std::cos(yaw);
  const double s = std::sin(yaw);
  if (std::fabs(c) >= std::fabs(s)) {
    return c >= 0.0 ? "E" : "W";
  }
  return s >= 0.0 ? "N" : "S";
}

std::vector<std::string> splitPipeFields(const std::string & text)
{
  std::vector<std::string> fields;
  std::stringstream ss(text);
  std::string field;
  while (std::getline(ss, field, '|')) {
    fields.push_back(field);
  }
  return fields;
}

WallDirection wallDirectionFromCardinal(const char * cardinal)
{
  if (cardinal != nullptr) {
    const std::string value(cardinal);
    if (value == "N") {
      return WallDirection::North;
    }
    if (value == "E") {
      return WallDirection::East;
    }
    if (value == "S") {
      return WallDirection::South;
    }
  }
  return WallDirection::West;
}

const char * wallDirectionCode(WallDirection direction)
{
  switch (direction) {
    case WallDirection::North:
      return "N";
    case WallDirection::East:
      return "E";
    case WallDirection::South:
      return "S";
    case WallDirection::West:
      return "W";
  }
  return "W";
}

SubmissionSubtile subtileForWallImagePosition(WallDirection wall, bool image_left_half)
{
  switch (wall) {
    case WallDirection::North:
      return image_left_half ? SubmissionSubtile::NW : SubmissionSubtile::NE;
    case WallDirection::East:
      return image_left_half ? SubmissionSubtile::NE : SubmissionSubtile::SE;
    case WallDirection::South:
      return image_left_half ? SubmissionSubtile::SE : SubmissionSubtile::SW;
    case WallDirection::West:
      return image_left_half ? SubmissionSubtile::SW : SubmissionSubtile::NW;
  }
  return SubmissionSubtile::NW;
}

const char * submissionSubtileCode(SubmissionSubtile subtile)
{
  switch (subtile) {
    case SubmissionSubtile::NW:
      return "NW";
    case SubmissionSubtile::NE:
      return "NE";
    case SubmissionSubtile::SW:
      return "SW";
    case SubmissionSubtile::SE:
      return "SE";
  }
  return "NW";
}

struct LegacyDirectionVector
{
  double x;
  double y;
};

std::optional<LegacyDirectionVector> legacyDirectionToWorldVector(const std::string & direction)
{
  constexpr double kInvSqrt2 = 0.7071067811865476;

  if (direction == "N") {
    return LegacyDirectionVector{1.0, 0.0};
  }
  if (direction == "E") {
    return LegacyDirectionVector{0.0, -1.0};
  }
  if (direction == "S") {
    return LegacyDirectionVector{-1.0, 0.0};
  }
  if (direction == "W") {
    return LegacyDirectionVector{0.0, 1.0};
  }
  if (direction == "NE") {
    return LegacyDirectionVector{kInvSqrt2, -kInvSqrt2};
  }
  if (direction == "SE") {
    return LegacyDirectionVector{-kInvSqrt2, -kInvSqrt2};
  }
  if (direction == "SW") {
    return LegacyDirectionVector{-kInvSqrt2, kInvSqrt2};
  }
  if (direction == "NW") {
    return LegacyDirectionVector{kInvSqrt2, kInvSqrt2};
  }

  return std::nullopt;
}

std::size_t slamDirectionIndex(SlamCardinalDirection direction)
{
  switch (direction) {
    case SlamCardinalDirection::North:
      return 0U;
    case SlamCardinalDirection::East:
      return 1U;
    case SlamCardinalDirection::South:
      return 2U;
    case SlamCardinalDirection::West:
      return 3U;
  }
  return 0U;
}

enum class SimpleEdgeState
{
  Unknown,
  Open,
  Wall,
  BlockedByHazard
};

const char * simpleEdgeStateToString(SimpleEdgeState state)
{
  switch (state) {
    case SimpleEdgeState::Open:
      return "open";
    case SimpleEdgeState::Wall:
      return "wall";
    case SimpleEdgeState::BlockedByHazard:
      return "blocked_by_hazard";
    case SimpleEdgeState::Unknown:
      return "unknown";
  }
  return "unknown";
}

WallState wallStateForDirection(const EdgeWalls & walls, SlamCardinalDirection direction)
{
  switch (direction) {
    case SlamCardinalDirection::North:
      return walls.north;
    case SlamCardinalDirection::East:
      return walls.east;
    case SlamCardinalDirection::South:
      return walls.south;
    case SlamCardinalDirection::West:
      return walls.west;
  }
  return WallState::Unknown;
}

const char * slamCardinalDirectionToString(SlamCardinalDirection direction)
{
  switch (direction) {
    case SlamCardinalDirection::North:
      return "N";
    case SlamCardinalDirection::East:
      return "E";
    case SlamCardinalDirection::South:
      return "S";
    case SlamCardinalDirection::West:
      return "W";
  }
  return "UNKNOWN";
}

std::optional<SlamCardinalDirection> cardinalDirectionBetween(
  const TileCoord & from,
  const TileCoord & to)
{
  const int dx = to.x - from.x;
  const int dy = to.y - from.y;

  if (dx == 0 && dy == 1) {
    return SlamCardinalDirection::North;
  }
  if (dx == 1 && dy == 0) {
    return SlamCardinalDirection::East;
  }
  if (dx == 0 && dy == -1) {
    return SlamCardinalDirection::South;
  }
  if (dx == -1 && dy == 0) {
    return SlamCardinalDirection::West;
  }

  return std::nullopt;
}

SlamCardinalDirection oppositeSlamCardinalDirection(SlamCardinalDirection direction)
{
  switch (direction) {
    case SlamCardinalDirection::North:
      return SlamCardinalDirection::South;
    case SlamCardinalDirection::East:
      return SlamCardinalDirection::West;
    case SlamCardinalDirection::South:
      return SlamCardinalDirection::North;
    case SlamCardinalDirection::West:
      return SlamCardinalDirection::East;
  }

  return SlamCardinalDirection::North;
}

TileCoord adjacentTileInDirection(
  const TileCoord & coord,
  SlamCardinalDirection direction)
{
  switch (direction) {
    case SlamCardinalDirection::North:
      return TileCoord{coord.x, coord.y + 1};
    case SlamCardinalDirection::East:
      return TileCoord{coord.x + 1, coord.y};
    case SlamCardinalDirection::South:
      return TileCoord{coord.x, coord.y - 1};
    case SlamCardinalDirection::West:
      return TileCoord{coord.x - 1, coord.y};
  }

  return coord;
}

bool isWallState(WallState state)
{
  return state == WallState::Wall || state == WallState::VirtualWall;
}

bool submissionModelHasWallOnSide(
  const SubmissionTileModel & model,
  SlamCardinalDirection direction)
{
  const auto & nw = model.subtiles[static_cast<int>(SubmissionSubtile::NW)];
  const auto & ne = model.subtiles[static_cast<int>(SubmissionSubtile::NE)];
  const auto & sw = model.subtiles[static_cast<int>(SubmissionSubtile::SW)];
  const auto & se = model.subtiles[static_cast<int>(SubmissionSubtile::SE)];

  switch (direction) {
    case SlamCardinalDirection::North:
      return nw.wall_north || ne.wall_north;
    case SlamCardinalDirection::East:
      return ne.wall_east || se.wall_east;
    case SlamCardinalDirection::South:
      return sw.wall_south || se.wall_south;
    case SlamCardinalDirection::West:
      return nw.wall_west || sw.wall_west;
  }

  return false;
}

bool isBlockingHazardTile(const TileRecord & record)
{
  return record.is_blocked ||
    record.is_hole ||
    (
      record.hazard_state == HazardState::Confirmed &&
      record.hazard_type == HazardType::BlackHole);
}

enum class SlamWallDiagnosticState
{
  Unknown,
  Open,
  Wall
};

const char * slamWallDiagnosticStateToString(SlamWallDiagnosticState state)
{
  switch (state) {
    case SlamWallDiagnosticState::Open:
      return "open";
    case SlamWallDiagnosticState::Wall:
      return "wall";
    case SlamWallDiagnosticState::Unknown:
      return "unknown";
  }
  return "unknown";
}

SlamWallDiagnosticState classifySlamWallDiagnostic(
  const SlamRegionStats & edge_strip,
  const SlamRegionStats & corridor,
  const SlamMapSamplerConfig & config)
{
  if (
    !edge_strip.map_real ||
    !corridor.map_real ||
    edge_strip.sample_count < config.min_region_samples ||
    corridor.sample_count < config.min_region_samples)
  {
    return SlamWallDiagnosticState::Unknown;
  }

  if (edge_strip.occupied_ratio >= config.likely_wall_occupied_ratio) {
    return SlamWallDiagnosticState::Wall;
  }

  if (
    edge_strip.occupied_ratio <= config.max_open_occupied_ratio &&
    corridor.free_ratio >= config.likely_open_free_ratio &&
    corridor.unknown_ratio <= config.max_confirmed_open_unknown_ratio)
  {
    return SlamWallDiagnosticState::Open;
  }

  return SlamWallDiagnosticState::Unknown;
}

double slamWallDiagnosticConfidence(
  SlamWallDiagnosticState state,
  const SlamRegionStats & edge_strip,
  const SlamRegionStats & corridor,
  const SlamMapSamplerConfig & config)
{
  if (state == SlamWallDiagnosticState::Wall) {
    return std::clamp(
      edge_strip.occupied_ratio / std::max(1.0e-6, config.confirmed_wall_occupied_ratio),
      0.0,
      1.0);
  }
  if (state == SlamWallDiagnosticState::Open) {
    const double free_confidence =
      corridor.free_ratio / std::max(1.0e-6, config.confirmed_open_free_ratio);
    const double known_confidence = 1.0 - corridor.unknown_ratio;
    const double clear_edge_confidence =
      1.0 - (
        edge_strip.occupied_ratio / std::max(1.0e-6, config.max_open_occupied_ratio));
    return std::clamp(
      std::min({free_confidence, known_confidence, clear_edge_confidence}),
      0.0,
      1.0);
  }
  return 0.0;
}

double tileEdgeDistanceLocal(double local_x, double local_y, double tile_size)
{
  const double half_tile = tile_size * 0.5;
  const double x_distance = half_tile - std::fabs(local_x);
  const double y_distance = half_tile - std::fabs(local_y);
  return std::min(x_distance, y_distance);
}

bool obstacleGridBinsValid(int bins_per_tile)
{
  return bins_per_tile >= 8 && bins_per_tile <= kObstacleGridMaxBinsPerTile;
}

int obstacleGridIndex(int col, int row, int bins_per_tile)
{
  return row * bins_per_tile + col;
}

int obstacleGridBinForLocal(
  double local_x,
  double local_y,
  double tile_size,
  int bins_per_tile)
{
  if (!obstacleGridBinsValid(bins_per_tile)) {
    return -1;
  }

  const double half_tile = tile_size * 0.5;
  if (
    local_x < -half_tile || local_x > half_tile ||
    local_y < -half_tile || local_y > half_tile)
  {
    return -1;
  }

  const double u = (local_x + half_tile) / tile_size;
  const double v = (half_tile - local_y) / tile_size;
  const int col = std::clamp(
    static_cast<int>(std::floor(u * static_cast<double>(bins_per_tile))),
    0,
    bins_per_tile - 1);
  const int row = std::clamp(
    static_cast<int>(std::floor(v * static_cast<double>(bins_per_tile))),
    0,
    bins_per_tile - 1);
  return obstacleGridIndex(col, row, bins_per_tile);
}

double obstacleGridBinCenterLocalX(int col, double tile_size, int bins_per_tile)
{
  const double half_tile = tile_size * 0.5;
  const double bin_size = tile_size / static_cast<double>(bins_per_tile);
  return -half_tile + (static_cast<double>(col) + 0.5) * bin_size;
}

double obstacleGridBinCenterLocalY(int row, double tile_size, int bins_per_tile)
{
  const double half_tile = tile_size * 0.5;
  const double bin_size = tile_size / static_cast<double>(bins_per_tile);
  return half_tile - (static_cast<double>(row) + 0.5) * bin_size;
}

int positiveMarkerId(std::size_t hash)
{
  return static_cast<int>(hash & 0x7fffffffU);
}

int phantomTileMarkerId(const TileCoord & coord)
{
  return positiveMarkerId(TileCoordHash{}(coord));
}

int phantomObstacleGridMarkerId(const TileCoord & coord, int bin_index)
{
  constexpr std::size_t obstacle_grid_marker_offset = 0x50000000U;
  std::size_t hash = TileCoordHash{}(coord) + obstacle_grid_marker_offset;
  hash ^= std::hash<int>{}(bin_index) + 0x9e3779b9U + (hash << 6U) + (hash >> 2U);
  return positiveMarkerId(hash);
}

std::size_t phantomQuadrantMarkerHash(const TileCoord & coord, TileQuadrant quadrant)
{
  return PhantomQuadrantKeyHash{}(PhantomQuadrantKey{coord, quadrant});
}

int phantomQuadrantFreeMarkerId(const TileCoord & coord, TileQuadrant quadrant)
{
  return positiveMarkerId(phantomQuadrantMarkerHash(coord, quadrant));
}

int phantomQuadrantHitMarkerId(const TileCoord & coord, TileQuadrant quadrant)
{
  constexpr std::size_t hit_marker_offset = 0x40000000U;
  return positiveMarkerId(phantomQuadrantMarkerHash(coord, quadrant) + hit_marker_offset);
}

std::size_t phantomQuarterEdgeMarkerHash(
  const TileCoord & coord,
  CanonicalSegmentKey segment)
{
  return PhantomQuarterEdgeKeyHash{}(PhantomQuarterEdgeKey{coord, segment});
}

int phantomQuarterEdgePositiveMarkerId(
  const TileCoord & coord,
  CanonicalSegmentKey segment)
{
  return positiveMarkerId(phantomQuarterEdgeMarkerHash(coord, segment));
}

int phantomQuarterEdgeConflictMarkerId(
  const TileCoord & coord,
  CanonicalSegmentKey segment)
{
  constexpr std::size_t conflict_marker_offset = 0x20000000U;
  return positiveMarkerId(phantomQuarterEdgeMarkerHash(coord, segment) + conflict_marker_offset);
}

int phantomMaskMarkerId(
  const TileCoord & coord,
  CanonicalSegmentKey segment)
{
  constexpr std::size_t mask_marker_offset = 0x60000000U;
  return positiveMarkerId(phantomQuarterEdgeMarkerHash(coord, segment) + mask_marker_offset);
}

int phantomPrimitiveMarkerId(
  const TileCoord & coord,
  SubtileIndex subtile,
  PrimitiveKind primitive)
{
  return positiveMarkerId(
    PhantomPrimitiveMarkerKeyHash{}(PhantomPrimitiveMarkerKey{coord, subtile, primitive}));
}

int phantomPrimitiveNegativeMarkerId(
  const TileCoord & coord,
  SubtileIndex subtile,
  PrimitiveKind primitive)
{
  constexpr std::size_t negative_marker_offset = 0x30000000U;
  return positiveMarkerId(
    PhantomPrimitiveMarkerKeyHash{}(
      PhantomPrimitiveMarkerKey{coord, subtile, primitive}) + negative_marker_offset);
}

double confidenceAlpha(double confidence, double alpha_min, double alpha_max)
{
  const double normalized = std::clamp(confidence, 0.0, 1.0);
  return alpha_min + (alpha_max - alpha_min) * normalized;
}

double quadrantOffsetX(TileQuadrant quadrant, double tile_size)
{
  switch (quadrant) {
    case TileQuadrant::NW:
    case TileQuadrant::SW:
      return -tile_size * 0.25;
    case TileQuadrant::NE:
    case TileQuadrant::SE:
      return tile_size * 0.25;
  }

  return 0.0;
}

double quadrantOffsetY(TileQuadrant quadrant, double tile_size)
{
  switch (quadrant) {
    case TileQuadrant::NW:
    case TileQuadrant::NE:
      return tile_size * 0.25;
    case TileQuadrant::SW:
    case TileQuadrant::SE:
      return -tile_size * 0.25;
  }

  return 0.0;
}

std::array<PrimitiveKind, 4> edgePrimitiveKinds()
{
  return {
    PrimitiveKind::EdgeNorth,
    PrimitiveKind::EdgeEast,
    PrimitiveKind::EdgeSouth,
    PrimitiveKind::EdgeWest,
  };
}

std::array<PrimitiveKind, 4> curvePrimitiveKinds()
{
  return {
    PrimitiveKind::Curve1,
    PrimitiveKind::Curve2,
    PrimitiveKind::Curve3,
    PrimitiveKind::Curve4,
  };
}

bool isEdgePrimitive(PrimitiveKind primitive)
{
  return primitive == PrimitiveKind::EdgeNorth ||
    primitive == PrimitiveKind::EdgeEast ||
    primitive == PrimitiveKind::EdgeSouth ||
    primitive == PrimitiveKind::EdgeWest;
}

bool isCurvePrimitive(PrimitiveKind primitive)
{
  return primitive == PrimitiveKind::Curve1 ||
    primitive == PrimitiveKind::Curve2 ||
    primitive == PrimitiveKind::Curve3 ||
    primitive == PrimitiveKind::Curve4;
}

// --- Submission-model conversion helpers ---
// SubtileIndex and SubmissionSubtile share the NW=0,NE=1,SW=2,SE=3 ordering, so
// a phantom subtile index maps directly to the submission subtile index.
PrimitiveKind curvePrimitiveKindFromDir(int curve_dir)
{
  switch (curve_dir) {
    case 1:
      return PrimitiveKind::Curve1;
    case 2:
      return PrimitiveKind::Curve2;
    case 3:
      return PrimitiveKind::Curve3;
    case 4:
      return PrimitiveKind::Curve4;
    default:
      return PrimitiveKind::Empty;
  }
}

int submissionGeometryVisualCurveDir(int curve_dir, const std::string & transform)
{
  if (transform == "identity" || transform == "none") {
    return curve_dir;
  }

  switch (curve_dir) {
    case 1:  // SW
      if (transform == "flip_x") {return 4;}
      if (transform == "flip_y") {return 2;}
      if (transform == "rotate_180") {return 3;}
      if (transform == "transpose_xy") {return 1;}
      if (transform == "anti_transpose_xy") {return 3;}
      if (transform == "rotate_90_cw") {return 2;}
      if (transform == "rotate_90_ccw") {return 4;}
      return curve_dir;
    case 2:  // NW
      if (transform == "flip_x") {return 3;}
      if (transform == "flip_y") {return 1;}
      if (transform == "rotate_180") {return 4;}
      if (transform == "transpose_xy") {return 4;}
      if (transform == "anti_transpose_xy") {return 2;}
      if (transform == "rotate_90_cw") {return 3;}
      if (transform == "rotate_90_ccw") {return 1;}
      return curve_dir;
    case 3:  // NE
      if (transform == "flip_x") {return 2;}
      if (transform == "flip_y") {return 4;}
      if (transform == "rotate_180") {return 1;}
      if (transform == "transpose_xy") {return 3;}
      if (transform == "anti_transpose_xy") {return 1;}
      if (transform == "rotate_90_cw") {return 4;}
      if (transform == "rotate_90_ccw") {return 2;}
      return curve_dir;
    case 4:  // SE
      if (transform == "flip_x") {return 1;}
      if (transform == "flip_y") {return 3;}
      if (transform == "rotate_180") {return 2;}
      if (transform == "transpose_xy") {return 2;}
      if (transform == "anti_transpose_xy") {return 4;}
      if (transform == "rotate_90_cw") {return 1;}
      if (transform == "rotate_90_ccw") {return 3;}
      return curve_dir;
    default:
      return curve_dir;
  }
}

double subtileCenterLocalX(SubtileIndex subtile, double tile_size)
{
  switch (subtile) {
    case SubtileIndex::NW:
    case SubtileIndex::SW:
      return -tile_size * 0.25;
    case SubtileIndex::NE:
    case SubtileIndex::SE:
      return tile_size * 0.25;
  }

  return 0.0;
}

double subtileCenterLocalY(SubtileIndex subtile, double tile_size)
{
  switch (subtile) {
    case SubtileIndex::NW:
    case SubtileIndex::NE:
      return tile_size * 0.25;
    case SubtileIndex::SW:
    case SubtileIndex::SE:
      return -tile_size * 0.25;
  }

  return 0.0;
}

bool primitiveIsHorizontal(PrimitiveKind primitive)
{
  return primitive == PrimitiveKind::EdgeNorth || primitive == PrimitiveKind::EdgeSouth;
}

double primitiveCenterLocalX(SubtileIndex subtile, PrimitiveKind primitive, double tile_size)
{
  const double center_x = subtileCenterLocalX(subtile, tile_size);
  const double half_subtile = tile_size * 0.25;

  if (primitive == PrimitiveKind::EdgeWest) {
    return center_x - half_subtile;
  }
  if (primitive == PrimitiveKind::EdgeEast) {
    return center_x + half_subtile;
  }

  return center_x;
}

double primitiveCenterLocalY(SubtileIndex subtile, PrimitiveKind primitive, double tile_size)
{
  const double center_y = subtileCenterLocalY(subtile, tile_size);
  const double half_subtile = tile_size * 0.25;

  if (primitive == PrimitiveKind::EdgeNorth) {
    return center_y + half_subtile;
  }
  if (primitive == PrimitiveKind::EdgeSouth) {
    return center_y - half_subtile;
  }

  return center_y;
}

struct PrimitiveAabb
{
  double min_x = 0.0;
  double min_y = 0.0;
  double max_x = 0.0;
  double max_y = 0.0;
};

struct CurveGeometry
{
  double center_x = 0.0;
  double center_y = 0.0;
  double inner_radius = 0.0;
  double outer_radius = 0.0;
  double angle_start = 0.0;
  double angle_end = 0.0;
  bool clockwise = false;
};

struct PrimitiveHitCandidate
{
  PrimitiveKind primitive;
  bool is_curve = false;
  double t_model = 0.0;
  double residual = 0.0;
  double hit_tolerance = 0.0;
  double incidence = 0.0;
  double center_weight = 0.0;
  double radial_center_weight = 1.0;
  double projection = 0.0;
  double range_weight = 0.0;
  double final_weight = 0.0;
  double hit_score = 0.0;
};

PrimitiveAabb primitiveAabbLocal(
  SubtileIndex subtile,
  PrimitiveKind primitive,
  double tile_size,
  double wall_thickness,
  double wall_margin)
{
  const double subtile_size = tile_size * 0.5;
  const double half_subtile = subtile_size * 0.5;
  const double half_thickness = (wall_thickness + 2.0 * wall_margin) * 0.5;
  const double center_x = primitiveCenterLocalX(subtile, primitive, tile_size);
  const double center_y = primitiveCenterLocalY(subtile, primitive, tile_size);

  if (primitiveIsHorizontal(primitive)) {
    return PrimitiveAabb{
      center_x - half_subtile,
      center_y - half_thickness,
      center_x + half_subtile,
      center_y + half_thickness};
  }

  return PrimitiveAabb{
    center_x - half_thickness,
    center_y - half_subtile,
    center_x + half_thickness,
    center_y + half_subtile};
}

double primitiveIncidence(PrimitiveKind primitive, double ray_dir_x, double ray_dir_y)
{
  const double normal_dot =
    primitiveIsHorizontal(primitive) ? std::fabs(ray_dir_y) : std::fabs(ray_dir_x);
  return std::clamp(normal_dot, 0.0, 1.0);
}

double primitiveIncidenceWeight(PrimitiveKind primitive, double ray_dir_x, double ray_dir_y)
{
  return std::clamp(primitiveIncidence(primitive, ray_dir_x, ray_dir_y), 0.15, 1.0);
}

double primitiveProjectionAlongEdge(
  SubtileIndex subtile,
  PrimitiveKind primitive,
  double local_x,
  double local_y,
  double tile_size)
{
  const double subtile_size = tile_size * 0.5;
  const double half_subtile = subtile_size * 0.5;
  const double subtile_center =
    primitiveIsHorizontal(primitive) ?
    subtileCenterLocalX(subtile, tile_size) :
    subtileCenterLocalY(subtile, tile_size);
  const double value = primitiveIsHorizontal(primitive) ? local_x : local_y;
  return std::clamp(
    (value - (subtile_center - half_subtile)) / subtile_size,
    0.0,
    1.0);
}

double centerMaskWeight(double projection, double mask_ratio)
{
  const double ratio = std::clamp(mask_ratio, 0.30, 1.0);
  const double margin = 0.5 * (1.0 - ratio);
  if (projection < margin || projection > 1.0 - margin) {
    return 0.0;
  }

  return 1.0;
}

double curveBellyWeight(double projection, double mask_ratio)
{
  const double ratio = std::clamp(mask_ratio, 0.30, 1.0);
  const double outer_margin = std::max(0.5 * (1.0 - ratio), 0.10);
  if (projection < outer_margin || projection > 1.0 - outer_margin) {
    return 0.0;
  }

  if (projection >= 0.35 && projection <= 0.65) {
    return 1.0;
  }

  if (projection >= 0.20 && projection <= 0.80) {
    return 0.65;
  }

  return 0.10;
}

double primitiveCenterWeight(
  SubtileIndex subtile,
  PrimitiveKind primitive,
  double local_x,
  double local_y,
  double tile_size,
  double mask_ratio)
{
  const double projection = primitiveProjectionAlongEdge(
    subtile,
    primitive,
    local_x,
    local_y,
    tile_size);
  return centerMaskWeight(projection, mask_ratio);
}

double curveProtoRotationRad(PrimitiveKind curve)
{
  switch (curve) {
    case PrimitiveKind::Curve1:
      return 1.57;
    case PrimitiveKind::Curve2:
      return 0.0;
    case PrimitiveKind::Curve3:
      return 4.71;
    case PrimitiveKind::Curve4:
      return 3.14;
    default:
      return 0.0;
  }
}

std::array<double, 2> curveProtoTranslationWebots(PrimitiveKind curve, double half_subtile)
{
  switch (curve) {
    case PrimitiveKind::Curve1:
      return {{-half_subtile, half_subtile}};
    case PrimitiveKind::Curve2:
      return {{-half_subtile, -half_subtile}};
    case PrimitiveKind::Curve3:
      return {{half_subtile, -half_subtile}};
    case PrimitiveKind::Curve4:
      return {{half_subtile, half_subtile}};
    default:
      return {{0.0, 0.0}};
  }
}

std::array<double, 2> webotsLocalXzToMapperXy(double webots_x, double webots_z)
{
  // Webots uses +z toward the tile bottom/south in these protos; mapper local +y is north.
  return {{webots_x, -webots_z}};
}

std::array<double, 2> rotateWebotsXzByProtoYaw(
  double webots_x,
  double webots_z,
  double yaw)
{
  const double cos_yaw = std::cos(yaw);
  const double sin_yaw = std::sin(yaw);
  return {{
    cos_yaw * webots_x + sin_yaw * webots_z,
    -sin_yaw * webots_x + cos_yaw * webots_z}};
}

double positiveAngularDelta(double from, double to)
{
  constexpr double kTwoPi = 2.0 * M_PI;
  double delta = to - from;
  while (delta < 0.0) {
    delta += kTwoPi;
  }
  while (delta >= kTwoPi) {
    delta -= kTwoPi;
  }
  return delta;
}

double curveAngularSpan(const CurveGeometry & geometry)
{
  if (geometry.clockwise) {
    return positiveAngularDelta(geometry.angle_end, geometry.angle_start);
  }

  return positiveAngularDelta(geometry.angle_start, geometry.angle_end);
}

double curveAngleAtProjection(const CurveGeometry & geometry, double projection)
{
  const double span = curveAngularSpan(geometry);
  return geometry.clockwise ?
    geometry.angle_start - span * projection :
    geometry.angle_start + span * projection;
}

CurveGeometry curveGeometryFromProtoTransform(
  SubtileIndex subtile,
  PrimitiveKind curve,
  double tile_size,
  double inner_radius_m,
  double outer_radius_m,
  double radius_offset_m,
  double wall_margin)
{
  const double subtile_size = tile_size * 0.5;
  const double half_subtile = subtile_size * 0.5;
  const double subtile_center_x = subtileCenterLocalX(subtile, tile_size);
  const double subtile_center_y = subtileCenterLocalY(subtile, tile_size);
  const auto proto_translation = curveProtoTranslationWebots(curve, half_subtile);
  const auto mapper_translation =
    webotsLocalXzToMapperXy(proto_translation[0], proto_translation[1]);
  const double proto_yaw = curveProtoRotationRad(curve);
  const auto proto_start = rotateWebotsXzByProtoYaw(1.0, 0.0, proto_yaw);
  const auto proto_end = rotateWebotsXzByProtoYaw(0.0, 1.0, proto_yaw);
  const auto mapper_start = webotsLocalXzToMapperXy(proto_start[0], proto_start[1]);
  const auto mapper_end = webotsLocalXzToMapperXy(proto_end[0], proto_end[1]);

  CurveGeometry geometry;
  geometry.center_x = subtile_center_x + mapper_translation[0];
  geometry.center_y = subtile_center_y + mapper_translation[1];
  const double effective_inner_radius = inner_radius_m + radius_offset_m;
  const double effective_outer_radius = outer_radius_m + radius_offset_m;
  geometry.inner_radius = std::max(0.0, effective_inner_radius - wall_margin);
  geometry.outer_radius = effective_outer_radius + wall_margin;
  geometry.angle_start = std::atan2(mapper_start[1], mapper_start[0]);
  geometry.angle_end = std::atan2(mapper_end[1], mapper_end[0]);
  geometry.clockwise =
    mapper_start[0] * mapper_end[1] - mapper_start[1] * mapper_end[0] < 0.0;

  return geometry;
}

bool curveGeometryIsValid(const CurveGeometry & geometry)
{
  return geometry.outer_radius > geometry.inner_radius;
}

double angleProjectionInSector(const CurveGeometry & geometry, double angle)
{
  constexpr double kAngleEpsilon = 1.0e-9;
  const double span = std::max(curveAngularSpan(geometry), kAngleEpsilon);
  const double delta = geometry.clockwise ?
    positiveAngularDelta(angle, geometry.angle_start) :
    positiveAngularDelta(geometry.angle_start, angle);
  return delta / span;
}

bool angleInSector(const CurveGeometry & geometry, double angle)
{
  constexpr double kProjectionEpsilon = 1.0e-9;
  const double projection = angleProjectionInSector(geometry, angle);
  return projection >= -kProjectionEpsilon && projection <= 1.0 + kProjectionEpsilon;
}

bool pointInsideSubtile(
  SubtileIndex subtile,
  double local_x,
  double local_y,
  double tile_size,
  double tolerance)
{
  const double subtile_size = tile_size * 0.5;
  const double half_subtile = subtile_size * 0.5;
  const double center_x = subtileCenterLocalX(subtile, tile_size);
  const double center_y = subtileCenterLocalY(subtile, tile_size);
  return
    local_x >= center_x - half_subtile - tolerance &&
    local_x <= center_x + half_subtile + tolerance &&
    local_y >= center_y - half_subtile - tolerance &&
    local_y <= center_y + half_subtile + tolerance;
}

bool curveGeometryMostlyInsideSubtile(
  SubtileIndex subtile,
  const CurveGeometry & geometry,
  double tile_size,
  double tolerance_m,
  double required_fraction)
{
  if (!curveGeometryIsValid(geometry)) {
    return false;
  }

  constexpr int kSamplesPerCurve = 9;
  const double radius_mid = 0.5 * (geometry.inner_radius + geometry.outer_radius);
  const double half_thickness = 0.5 * (geometry.outer_radius - geometry.inner_radius);
  const double effective_tolerance = tolerance_m + half_thickness;
  int inside_count = 0;
  int sample_count = 0;

  for (int i = 0; i < kSamplesPerCurve; ++i) {
    const double projection =
      static_cast<double>(i) / static_cast<double>(kSamplesPerCurve - 1);
    const double angle = curveAngleAtProjection(geometry, projection);
    const double x = geometry.center_x + radius_mid * std::cos(angle);
    const double y = geometry.center_y + radius_mid * std::sin(angle);
    if (pointInsideSubtile(subtile, x, y, tile_size, effective_tolerance)) {
      inside_count += 1;
    }
    sample_count += 1;
  }

  return sample_count > 0 &&
    static_cast<double>(inside_count) / static_cast<double>(sample_count) >= required_fraction;
}

bool rayIntersectsAabb2d(
  double ray_origin_x,
  double ray_origin_y,
  double ray_dir_x,
  double ray_dir_y,
  double min_x,
  double min_y,
  double max_x,
  double max_y,
  double * t_enter)
{
  double t_min = 0.0;
  double t_max = std::numeric_limits<double>::infinity();
  constexpr double direction_epsilon = 1.0e-9;

  const auto update_slab =
    [&](double origin, double direction, double slab_min, double slab_max) {
      if (std::fabs(direction) < direction_epsilon) {
        return origin >= slab_min && origin <= slab_max;
      }

      double t0 = (slab_min - origin) / direction;
      double t1 = (slab_max - origin) / direction;
      if (t0 > t1) {
        std::swap(t0, t1);
      }

      t_min = std::max(t_min, t0);
      t_max = std::min(t_max, t1);
      return t_min <= t_max;
    };

  if (!update_slab(ray_origin_x, ray_dir_x, min_x, max_x)) {
    return false;
  }
  if (!update_slab(ray_origin_y, ray_dir_y, min_y, max_y)) {
    return false;
  }

  if (t_min < 0.0) {
    return false;
  }

  if (t_enter != nullptr) {
    *t_enter = t_min;
  }
  return true;
}

bool aabbOverlaps2d(
  double lhs_min_x,
  double lhs_min_y,
  double lhs_max_x,
  double lhs_max_y,
  double rhs_min_x,
  double rhs_min_y,
  double rhs_max_x,
  double rhs_max_y)
{
  return
    lhs_min_x <= rhs_max_x &&
    lhs_max_x >= rhs_min_x &&
    lhs_min_y <= rhs_max_y &&
    lhs_max_y >= rhs_min_y;
}

bool curveGeometryOverlapsAabb(
  const CurveGeometry & geometry,
  double min_x,
  double min_y,
  double max_x,
  double max_y,
  int samples)
{
  if (!curveGeometryIsValid(geometry)) {
    return false;
  }

  const double radius = 0.5 * (geometry.inner_radius + geometry.outer_radius);
  const double half_thickness = 0.5 * (geometry.outer_radius - geometry.inner_radius);
  const double expanded_min_x = min_x - half_thickness;
  const double expanded_min_y = min_y - half_thickness;
  const double expanded_max_x = max_x + half_thickness;
  const double expanded_max_y = max_y + half_thickness;
  const int sample_count = std::max(3, samples);

  for (int i = 0; i < sample_count; ++i) {
    const double u = static_cast<double>(i) / static_cast<double>(sample_count - 1);
    const double angle = curveAngleAtProjection(geometry, u);
    const double x = geometry.center_x + radius * std::cos(angle);
    const double y = geometry.center_y + radius * std::sin(angle);
    if (
      x >= expanded_min_x && x <= expanded_max_x &&
      y >= expanded_min_y && y <= expanded_max_y)
    {
      return true;
    }
  }

  return false;
}

double obstacleWallOverlapPenalty(
  const PhantomTileEvidence & evidence,
  double min_x,
  double min_y,
  double max_x,
  double max_y,
  double tile_size,
  double primitive_wall_thickness,
  double primitive_wall_margin,
  double primitive_confidence_threshold,
  double curve_confidence_threshold,
  double curve_inner_radius,
  double curve_outer_radius,
  double curve_radius_offset,
  double curve_wall_margin,
  double penalty_weight)
{
  double max_overlap_confidence = 0.0;

  for (std::size_t subtile_i = 0; subtile_i < evidence.subtiles.size(); ++subtile_i) {
    const auto subtile = static_cast<SubtileIndex>(subtile_i);
    const auto & subtile_evidence = evidence.subtiles[subtile_i];

    for (const auto primitive : edgePrimitiveKinds()) {
      const int index = primitiveIndex(primitive);
      if (index < 0) {
        continue;
      }

      const auto & primitive_evidence =
        subtile_evidence.primitives[static_cast<std::size_t>(index)];
      if (
        primitive_evidence.log_odds <= 0.0 ||
        primitive_evidence.confidence < primitive_confidence_threshold)
      {
        continue;
      }

      const auto aabb = primitiveAabbLocal(
        subtile,
        primitive,
        tile_size,
        primitive_wall_thickness,
        primitive_wall_margin);
      if (aabbOverlaps2d(min_x, min_y, max_x, max_y, aabb.min_x, aabb.min_y, aabb.max_x, aabb.max_y))
      {
        max_overlap_confidence = std::max(max_overlap_confidence, primitive_evidence.confidence);
      }
    }

    for (const auto primitive : curvePrimitiveKinds()) {
      const int index = primitiveIndex(primitive);
      if (index < 0) {
        continue;
      }

      const auto & primitive_evidence =
        subtile_evidence.primitives[static_cast<std::size_t>(index)];
      if (
        primitive_evidence.log_odds <= 0.0 ||
        primitive_evidence.confidence < curve_confidence_threshold)
      {
        continue;
      }

      const auto geometry = curveGeometryFromProtoTransform(
        subtile,
        primitive,
        tile_size,
        curve_inner_radius,
        curve_outer_radius,
        curve_radius_offset,
        curve_wall_margin);
      if (curveGeometryOverlapsAabb(geometry, min_x, min_y, max_x, max_y, 9)) {
        max_overlap_confidence = std::max(max_overlap_confidence, primitive_evidence.confidence);
      }
    }
  }

  return std::clamp(penalty_weight * max_overlap_confidence, 0.0, 1.0);
}

ObstacleClusterCandidate detectObstacleClusterFromGrid(
  const PhantomTileEvidence & evidence,
  int bins_per_tile,
  double tile_size,
  double occupied_threshold,
  double free_margin,
  int min_cluster_bins,
  int min_total_hits,
  double min_confidence,
  double max_free_ratio,
  double min_distance_from_tile_edge,
  double min_box_size,
  double max_box_size,
  double box_padding,
  int surrounding_ring_bins,
  double min_surrounding_free_ratio,
  double wall_overlap_penalty_weight,
  double edge_proximity_penalty_weight,
  double primitive_wall_thickness,
  double primitive_wall_margin,
  double primitive_confidence_threshold,
  double curve_confidence_threshold,
  double curve_inner_radius,
  double curve_outer_radius,
  double curve_radius_offset,
  double curve_wall_margin)
{
  ObstacleClusterCandidate best;
  if (!obstacleGridBinsValid(bins_per_tile)) {
    return best;
  }

  const int cell_count = bins_per_tile * bins_per_tile;
  std::array<bool, kObstacleGridCellCount> occupied{};
  std::array<bool, kObstacleGridCellCount> visited{};

  for (int index = 0; index < cell_count; ++index) {
    const auto & bin = evidence.obstacle_grid[static_cast<std::size_t>(index)];
    occupied[static_cast<std::size_t>(index)] =
      bin.hit_count > 0 &&
      bin.hit_score >= occupied_threshold &&
      bin.hit_score >= bin.free_score + free_margin;
  }

  double best_score = std::numeric_limits<double>::lowest();
  std::vector<int> stack;
  stack.reserve(static_cast<std::size_t>(cell_count));

  for (int start_index = 0; start_index < cell_count; ++start_index) {
    if (
      !occupied[static_cast<std::size_t>(start_index)] ||
      visited[static_cast<std::size_t>(start_index)])
    {
      continue;
    }

    int min_col = bins_per_tile;
    int max_col = -1;
    int min_row = bins_per_tile;
    int max_row = -1;
    int cluster_bins = 0;
    int total_hits = 0;
    int free_count = 0;
    double hit_score = 0.0;
    double free_score = 0.0;

    stack.clear();
    stack.push_back(start_index);
    visited[static_cast<std::size_t>(start_index)] = true;

    while (!stack.empty()) {
      const int index = stack.back();
      stack.pop_back();
      const int row = index / bins_per_tile;
      const int col = index % bins_per_tile;
      const auto & bin = evidence.obstacle_grid[static_cast<std::size_t>(index)];

      min_col = std::min(min_col, col);
      max_col = std::max(max_col, col);
      min_row = std::min(min_row, row);
      max_row = std::max(max_row, row);
      cluster_bins += 1;
      total_hits += bin.hit_count;
      free_count += bin.free_count;
      hit_score += bin.hit_score;
      free_score += bin.free_score;

      for (int dy = -1; dy <= 1; ++dy) {
        for (int dx = -1; dx <= 1; ++dx) {
          if (dx == 0 && dy == 0) {
            continue;
          }

          const int next_col = col + dx;
          const int next_row = row + dy;
          if (
            next_col < 0 || next_col >= bins_per_tile ||
            next_row < 0 || next_row >= bins_per_tile)
          {
            continue;
          }

          const int next_index = obstacleGridIndex(next_col, next_row, bins_per_tile);
          if (
            occupied[static_cast<std::size_t>(next_index)] &&
            !visited[static_cast<std::size_t>(next_index)])
          {
            visited[static_cast<std::size_t>(next_index)] = true;
            stack.push_back(next_index);
          }
        }
      }
    }

    const double cluster_score = hit_score - free_score;
    if (cluster_score <= 0.0) {
      continue;
    }

    const double bin_size = tile_size / static_cast<double>(bins_per_tile);
    const double half_tile = tile_size * 0.5;
    const double min_x = -half_tile + static_cast<double>(min_col) * bin_size;
    const double max_x = -half_tile + static_cast<double>(max_col + 1) * bin_size;
    const double max_y = half_tile - static_cast<double>(min_row) * bin_size;
    const double min_y = half_tile - static_cast<double>(max_row + 1) * bin_size;
    const double edge_clearance = std::min(
      std::min(min_x + half_tile, half_tile - max_x),
      std::min(min_y + half_tile, half_tile - max_y));
    const double padded_width = (max_x - min_x) + 2.0 * box_padding;
    const double padded_length = (max_y - min_y) + 2.0 * box_padding;
    const double free_ratio =
      free_score > 0.0 ? free_score / std::max(hit_score + free_score, 1.0e-9) : 0.0;
    const int ring_min_col = std::max(0, min_col - surrounding_ring_bins);
    const int ring_max_col = std::min(bins_per_tile - 1, max_col + surrounding_ring_bins);
    const int ring_min_row = std::max(0, min_row - surrounding_ring_bins);
    const int ring_max_row = std::min(bins_per_tile - 1, max_row + surrounding_ring_bins);
    int ring_bins = 0;
    int ring_free_bins = 0;
    for (int row = ring_min_row; row <= ring_max_row; ++row) {
      for (int col = ring_min_col; col <= ring_max_col; ++col) {
        if (col >= min_col && col <= max_col && row >= min_row && row <= max_row) {
          continue;
        }

        const int ring_index = obstacleGridIndex(col, row, bins_per_tile);
        const auto & ring_bin = evidence.obstacle_grid[static_cast<std::size_t>(ring_index)];
        ring_bins += 1;
        if (
          ring_bin.free_score >= free_margin &&
          ring_bin.free_score >= ring_bin.hit_score)
        {
          ring_free_bins += 1;
        }
      }
    }
    const double surrounding_free_ratio =
      ring_bins > 0 ? static_cast<double>(ring_free_bins) / static_cast<double>(ring_bins) : 0.0;

    if (
      cluster_bins < min_cluster_bins ||
      total_hits < min_total_hits ||
      free_ratio > max_free_ratio ||
      edge_clearance < min_distance_from_tile_edge ||
      padded_width < min_box_size ||
      padded_length < min_box_size ||
      padded_width > max_box_size ||
      padded_length > max_box_size)
    {
      continue;
    }

    const double hit_score_target =
      occupied_threshold * static_cast<double>(std::max(1, min_cluster_bins));
    const double hit_confidence = clamp01(hit_score / std::max(hit_score_target, 1.0e-9));
    const double count_confidence =
      clamp01(static_cast<double>(total_hits) / static_cast<double>(std::max(1, min_total_hits)));
    const double free_confidence =
      max_free_ratio > 0.0 ? clamp01(1.0 - free_ratio / max_free_ratio) :
      (free_score <= 0.0 ? 1.0 : 0.0);
    const double surrounding_confidence =
      min_surrounding_free_ratio > 0.0 ?
      clamp01(surrounding_free_ratio / min_surrounding_free_ratio) :
      1.0;
    const double edge_window = std::max(
      min_distance_from_tile_edge,
      bin_size * static_cast<double>(std::max(1, surrounding_ring_bins)));
    const double edge_pressure =
      edge_window > 0.0 ?
      clamp01((min_distance_from_tile_edge + edge_window - edge_clearance) / edge_window) :
      0.0;
    const double edge_penalty =
      std::clamp(edge_proximity_penalty_weight * edge_pressure, 0.0, 1.0);
    const double wall_penalty = obstacleWallOverlapPenalty(
      evidence,
      min_x,
      min_y,
      max_x,
      max_y,
      tile_size,
      primitive_wall_thickness,
      primitive_wall_margin,
      primitive_confidence_threshold,
      curve_confidence_threshold,
      curve_inner_radius,
      curve_outer_radius,
      curve_radius_offset,
      curve_wall_margin,
      wall_overlap_penalty_weight);
    const double confidence =
      hit_confidence *
      count_confidence *
      free_confidence *
      surrounding_confidence *
      (1.0 - edge_penalty) *
      (1.0 - wall_penalty);

    const double final_score = cluster_score * confidence;
    if (confidence < min_confidence || final_score <= best_score) {
      continue;
    }

    best_score = final_score;
    best.valid = true;
    best.center_local_x = 0.5 * (min_x + max_x);
    best.center_local_y = 0.5 * (min_y + max_y);
    best.width_m = padded_width;
    best.length_m = padded_length;
    best.min_local_x = min_x;
    best.min_local_y = min_y;
    best.max_local_x = max_x;
    best.max_local_y = max_y;
    best.hit_score = hit_score;
    best.free_score = free_score;
    best.confidence = confidence;
    best.free_ratio = free_ratio;
    best.surrounding_free_ratio = surrounding_free_ratio;
    best.wall_overlap_penalty = wall_penalty;
    best.edge_proximity_penalty = edge_penalty;
    best.cluster_bins = cluster_bins;
    best.total_hits = total_hits;
    best.free_count = free_count;
  }

  return best;
}

bool rayIntersectsAnnularSector2d(
  double ray_origin_x,
  double ray_origin_y,
  double ray_dir_x,
  double ray_dir_y,
  const CurveGeometry & geometry,
  double * t_enter,
  double * angle_at_hit,
  double * radial_error)
{
  constexpr double kTMin = 0.0;
  constexpr double kDiscriminantEpsilon = 1.0e-12;
  constexpr double kRadiusEpsilon = 1.0e-9;
  double best_t = std::numeric_limits<double>::infinity();
  double best_angle = 0.0;
  double best_radial_error = 0.0;

  const auto consider_intersection =
    [&](double t) {
      if (t < kTMin || t >= best_t) {
        return;
      }

      const double hit_x = ray_origin_x + t * ray_dir_x;
      const double hit_y = ray_origin_y + t * ray_dir_y;
      const double dx = hit_x - geometry.center_x;
      const double dy = hit_y - geometry.center_y;
      const double radius = std::hypot(dx, dy);
      if (
        radius < geometry.inner_radius - kRadiusEpsilon ||
        radius > geometry.outer_radius + kRadiusEpsilon)
      {
        return;
      }

      const double angle = std::atan2(dy, dx);
      if (!angleInSector(geometry, angle)) {
        return;
      }

      best_t = t;
      best_angle = angle;
      best_radial_error =
        std::fabs(radius - 0.5 * (geometry.inner_radius + geometry.outer_radius));
    };

  const double origin_dx = ray_origin_x - geometry.center_x;
  const double origin_dy = ray_origin_y - geometry.center_y;
  const double origin_radius = std::hypot(origin_dx, origin_dy);
  if (
    origin_radius >= geometry.inner_radius &&
    origin_radius <= geometry.outer_radius &&
    angleInSector(geometry, std::atan2(origin_dy, origin_dx)))
  {
    consider_intersection(0.0);
  }

  const auto intersect_circle =
    [&](double radius) {
      if (radius <= 0.0) {
        return;
      }

      const double b = origin_dx * ray_dir_x + origin_dy * ray_dir_y;
      const double c = origin_dx * origin_dx + origin_dy * origin_dy - radius * radius;
      const double discriminant = b * b - c;
      if (discriminant < -kDiscriminantEpsilon) {
        return;
      }

      const double root = std::sqrt(std::max(0.0, discriminant));
      consider_intersection(-b - root);
      consider_intersection(-b + root);
    };

  intersect_circle(geometry.inner_radius);
  intersect_circle(geometry.outer_radius);

  if (!std::isfinite(best_t)) {
    return false;
  }

  if (t_enter != nullptr) {
    *t_enter = best_t;
  }
  if (angle_at_hit != nullptr) {
    *angle_at_hit = best_angle;
  }
  if (radial_error != nullptr) {
    *radial_error = best_radial_error;
  }
  return true;
}

double segmentDistance(
  double local_x,
  double local_y,
  CanonicalSegmentKey segment,
  double tile_size)
{
  const double half_tile = tile_size * 0.5;

  if (segment.orientation == CanonicalSegmentOrientation::Horizontal) {
    const double y = half_tile - static_cast<double>(segment.line) * half_tile;
    const double x_min = segment.offset == 0 ? -half_tile : 0.0;
    const double x_max = segment.offset == 0 ? 0.0 : half_tile;
    const double x = std::clamp(local_x, x_min, x_max);
    return std::hypot(local_x - x, local_y - y);
  }

  const double x = -half_tile + static_cast<double>(segment.line) * half_tile;
  const double y_min = segment.offset == 0 ? 0.0 : -half_tile;
  const double y_max = segment.offset == 0 ? half_tile : 0.0;
  const double y = std::clamp(local_y, y_min, y_max);
  return std::hypot(local_x - x, local_y - y);
}

double segmentCenterLocalX(CanonicalSegmentKey segment, double tile_size)
{
  const double half_tile = tile_size * 0.5;

  if (segment.orientation == CanonicalSegmentOrientation::Horizontal) {
    return segment.offset == 0 ? -tile_size * 0.25 : tile_size * 0.25;
  }

  return -half_tile + static_cast<double>(segment.line) * half_tile;
}

double segmentCenterLocalY(CanonicalSegmentKey segment, double tile_size)
{
  const double half_tile = tile_size * 0.5;

  if (segment.orientation == CanonicalSegmentOrientation::Horizontal) {
    return half_tile - static_cast<double>(segment.line) * half_tile;
  }

  return segment.offset == 0 ? tile_size * 0.25 : -tile_size * 0.25;
}

CanonicalSegmentKey canonicalSegmentFromIndex(std::size_t index)
{
  CanonicalSegmentKey segment;
  if (index < 6U) {
    segment.orientation = CanonicalSegmentOrientation::Horizontal;
    segment.line = static_cast<int>(index / 2U);
    segment.offset = static_cast<int>(index % 2U);
    return segment;
  }

  const std::size_t vertical_index = index - 6U;
  segment.orientation = CanonicalSegmentOrientation::Vertical;
  segment.line = static_cast<int>(vertical_index / 2U);
  segment.offset = static_cast<int>(vertical_index % 2U);
  return segment;
}

}  // namespace

bool isSpecialFloorColor(FloorColorClass color_class)
{
  switch (color_class) {
    case FloorColorClass::BlackHoleBorder:
    case FloorColorClass::SilverCheckpoint:
    case FloorColorClass::BrownSwamp:
    case FloorColorClass::BlueArea1To2:
    case FloorColorClass::YellowArea1To3:
    case FloorColorClass::GreenArea1To4:
    case FloorColorClass::PurpleArea2To3:
    case FloorColorClass::OrangeArea2To4:
    case FloorColorClass::RedArea3To4:
      return true;

    case FloorColorClass::Unknown:
    case FloorColorClass::Normal:
      return false;
  }

  return false;
}

bool isConfirmedBlackHoleHazard(const TileRecord & record)
{
  return
    record.hazard_state == HazardState::Confirmed &&
    record.hazard_type == HazardType::BlackHole;
}

std::optional<std::array<TileArea, 2>> transitionAreasForColor(FloorColorClass color_class)
{
  switch (color_class) {
    case FloorColorClass::BlueArea1To2:
      return std::array<TileArea, 2>{TileArea::Area1, TileArea::Area2};
    case FloorColorClass::YellowArea1To3:
      return std::array<TileArea, 2>{TileArea::Area1, TileArea::Area3};
    case FloorColorClass::GreenArea1To4:
      return std::array<TileArea, 2>{TileArea::Area1, TileArea::Area4};
    case FloorColorClass::PurpleArea2To3:
      return std::array<TileArea, 2>{TileArea::Area2, TileArea::Area3};
    case FloorColorClass::OrangeArea2To4:
      return std::array<TileArea, 2>{TileArea::Area2, TileArea::Area4};
    case FloorColorClass::RedArea3To4:
      return std::array<TileArea, 2>{TileArea::Area3, TileArea::Area4};

    case FloorColorClass::Unknown:
    case FloorColorClass::Normal:
    case FloorColorClass::BlackHoleBorder:
    case FloorColorClass::SilverCheckpoint:
    case FloorColorClass::BrownSwamp:
      return std::nullopt;
  }

  return std::nullopt;
}

void clearFloorColorSemantic(TileRecord & record, bool preserve_confirmed_black_hole = false)
{
  const bool preserve_hole =
    preserve_confirmed_black_hole &&
    isConfirmedBlackHoleHazard(record);

  record.is_checkpoint = false;
  record.is_swamp = false;
  record.is_transition = false;
  record.transition = TransitionInfo{};

  if (preserve_hole) {
    record.is_hole = true;
    record.has_black_hole_border = true;
    record.is_blocked = true;
    record.kind = TileKind::Hole;
    return;
  }

  record.is_hole = false;
  record.has_black_hole_border = false;
  record.is_blocked = false;

  if (!record.is_start && record.kind != TileKind::Area4Generic) {
    record.kind = TileKind::Unknown;
  }
}

void applyFloorColorClassToRecord(
  TileRecord & record,
  FloorColorClass color_class,
  bool black_hole_detected,
  bool preserve_confirmed_black_hole)
{
  clearFloorColorSemantic(record, preserve_confirmed_black_hole);

  record.floor_color = color_class;

  switch (color_class) {
    case FloorColorClass::Normal:
      if (!record.is_start && record.kind == TileKind::Unknown) {
        record.kind = TileKind::Normal;
      }
      break;

    case FloorColorClass::BlackHoleBorder:
      record.has_black_hole_border = true;
      if (black_hole_detected) {
        record.is_hole = true;
        record.is_blocked = true;
        record.kind = TileKind::Hole;
      }
      break;

    case FloorColorClass::SilverCheckpoint:
      record.is_checkpoint = true;
      record.kind = TileKind::Checkpoint;
      record.is_blocked = false;
      break;

    case FloorColorClass::BrownSwamp:
      record.is_swamp = true;
      record.kind = TileKind::Swamp;
      break;

    case FloorColorClass::BlueArea1To2:
    case FloorColorClass::YellowArea1To3:
    case FloorColorClass::GreenArea1To4:
    case FloorColorClass::PurpleArea2To3:
    case FloorColorClass::OrangeArea2To4:
    case FloorColorClass::RedArea3To4:
      record.is_transition = true;
      record.kind = TileKind::Transition;
      record.transition = transitionInfoFromColor(color_class);
      record.is_blocked = false;
      break;

    case FloorColorClass::Unknown:
      break;
  }
}

MapperNode::MapperNode()
: Node("ros2_mapper"),
  tile_size_(0.12),
  origin_x_(0.0),
  origin_y_(0.0),
  origin_initialized_(false),
  auto_start_(false),
  mapping_active_(false),
  origin_require_scan_before_init_(true),
  origin_require_scan_timeout_s_(5.0),
  race_wait_for_bridge_ready_(false),
  race_require_scan_after_ready_(true),
  race_require_odom_after_ready_(true),
  bridge_ready_(false),
  scan_seen_after_bridge_ready_(false),
  odom_seen_after_bridge_ready_(false),
  race_waiting_for_fresh_scan_after_activation_(false),
  has_bridge_connection_id_(false),
  bridge_connection_id_(0),
  marker_publish_rate_hz_(10.0),
  current_tile_marker_z_(0.002),
  current_tile_marker_height_(0.004),
  current_tile_alpha_(0.30),
  current_tile_color_r_(0.10),
  current_tile_color_g_(0.70),
  current_tile_color_b_(1.00),
  current_tile_center_z_(0.015),
  current_tile_center_radius_(0.015),
  publish_visited_tiles_(true),
  visited_tile_marker_z_(0.001),
  visited_tile_marker_height_(0.002),
  visited_tile_alpha_(0.18),
  visited_tile_color_r_(0.20),
  visited_tile_color_g_(0.85),
  visited_tile_color_b_(0.35),
  log_tile_changes_(true),
  mark_origin_tile_as_start_(true),
  publish_semantic_tile_colors_(true),
  semantic_tile_alpha_(0.35),
  status_publish_period_s_(0.5),
  map_validity_summary_log_period_s_(1.0),
  odom_recent_timeout_s_(1.0),
  scan_recent_timeout_s_(1.0),
  slam_map_recent_timeout_s_(3.0),
  publish_lidar_debug_points_(true),
  lidar_debug_point_stride_(1),
  lidar_debug_point_size_(0.01),
  lidar_debug_z_(0.02),
  lidar_debug_min_range_(0.01),
  lidar_debug_max_range_(1.0),
  enable_lidar_phantom_observations_(true),
  lidar_observation_max_range_(0.55),
  lidar_ray_step_m_(0.015),
  lidar_ray_grid_step_m_(0.005),
  lidar_range_weight_scale_m_(0.5),
  lidar_range_sigma_m_(0.003),
  lidar_evidence_decay_half_life_s_(8.0),
  lidar_positive_evidence_max_(12.0),
  lidar_negative_evidence_max_(12.0),
  lidar_conflict_weight_(2.0),
  lidar_skip_after_teleport_s_(0.50),
  odom_buffer_duration_s_(1.0),
  scan_odom_match_max_delta_s_(0.12),
  enable_delayed_scan_processing_(true),
  scan_processing_delay_s_(0.10),
  scan_pending_max_age_s_(0.50),
  require_odom_bracket_for_scan_(true),
  odom_interpolation_max_gap_s_(0.20),
  max_scan_odom_time_delta_s_(0.15),
  reject_non_monotonic_scan_stamps_(true),
  teleport_detection_enabled_(true),
  teleport_distance_threshold_m_(0.25),
  teleport_yaw_threshold_rad_(1.5708),
  publish_phantom_tiles_(true),
  phantom_visual_mode_("summary"),
  publish_phantom_tile_background_(false),
  publish_phantom_quadrant_debug_(false),
  publish_phantom_free_summary_(false),
  phantom_update_max_tile_radius_(4),
  phantom_mask_max_tile_radius_(3),
  phantom_tile_marker_z_(0.035),
  phantom_tile_marker_height_(0.003),
  phantom_tile_marker_alpha_(0.02),
  phantom_quadrant_marker_z_(0.038),
  phantom_quadrant_marker_height_(0.004),
  phantom_quadrant_marker_alpha_min_(0.01),
  phantom_quadrant_marker_alpha_max_(0.08),
  enable_quarter_edge_evidence_(true),
  quarter_edge_hit_tolerance_m_(0.012),
  quarter_edge_free_conflict_tolerance_m_(0.010),
  quarter_edge_min_visibility_rays_(3),
  quarter_edge_hit_weight_(1.0),
  quarter_edge_conflict_weight_(2.0),
  publish_quarter_edge_debug_(false),
  quarter_edge_marker_z_(0.052),
  quarter_edge_marker_thickness_(0.006),
  quarter_edge_marker_alpha_min_(0.04),
  quarter_edge_marker_alpha_max_(0.25),
  mask_supported_segment_min_score_(0.5),
  mask_conflict_segment_max_score_(-0.5),
  mask_complexity_penalty_(0.15),
  mask_unsupported_segment_penalty_(0.25),
  mask_min_confidence_(0.0),
  publish_phantom_mask_debug_(false),
  phantom_mask_marker_z_(0.060),
  phantom_mask_marker_thickness_(0.009),
  phantom_mask_marker_alpha_min_(0.08),
  phantom_mask_marker_alpha_max_(0.45),
  phantom_summary_min_confidence_(0.20),
  phantom_summary_marker_alpha_min_(0.08),
  phantom_summary_marker_alpha_max_(0.50),
  phantom_free_summary_alpha_max_(0.12),
  enable_ray_model_primitives_(true),
  primitive_wall_thickness_m_(0.010),
  primitive_wall_margin_m_(0.006),
  primitive_base_tolerance_m_(0.006),
  primitive_yaw_sigma_rad_(0.035),
  primitive_hit_tolerance_max_m_(0.008),
  primitive_allow_multi_positive_per_ray_(false),
  primitive_positive_min_incidence_(0.40),
  primitive_positive_min_hit_score_(0.20),
  primitive_endpoint_exclusion_ratio_(0.10),
  primitive_positive_log_odds_update_(0.25),
  primitive_negative_log_odds_update_(0.90),
  primitive_log_odds_min_(-4.0),
  primitive_log_odds_max_(4.0),
  primitive_min_visibility_rays_(8),
  publish_primitive_debug_(true),
  primitive_debug_min_confidence_(0.40),
  primitive_debug_marker_z_(0.070),
  primitive_debug_marker_alpha_min_(0.08),
  primitive_debug_marker_alpha_max_(0.65),
  primitive_debug_marker_thickness_(0.008),
  primitive_debug_color_r_(0.20),
  primitive_debug_color_g_(0.95),
  primitive_debug_color_b_(1.00),
  publish_primitive_negative_debug_(false),
  primitive_negative_debug_min_confidence_(0.30),
  primitive_negative_debug_color_r_(1.00),
  primitive_negative_debug_color_g_(0.15),
  primitive_negative_debug_color_b_(0.15),
  primitive_negative_debug_marker_alpha_min_(0.04),
  primitive_negative_debug_marker_alpha_max_(0.25),
  enable_obstacle_primitives_(false),
  obstacle_grid_bins_per_tile_(kObstacleGridBinsPerTile),
  obstacle_bin_hit_weight_(1.0),
  obstacle_bin_free_weight_(2.0),
  obstacle_bin_occupied_threshold_(3.0),
  obstacle_bin_free_margin_(1.0),
  obstacle_min_cluster_bins_(8),
  obstacle_min_total_hits_(10),
  obstacle_min_confidence_(0.70),
  obstacle_debug_min_confidence_(0.70),
  obstacle_max_free_ratio_(0.30),
  obstacle_min_distance_from_tile_edge_m_(0.015),
  obstacle_min_box_size_m_(0.015),
  obstacle_max_box_size_m_(0.085),
  obstacle_box_padding_m_(0.005),
  obstacle_surrounding_ring_bins_(2),
  obstacle_min_surrounding_free_ratio_(0.45),
  obstacle_wall_overlap_penalty_(2.0),
  obstacle_edge_proximity_penalty_(1.5),
  obstacle_temporal_decay_half_life_s_(6.0),
  publish_obstacle_grid_debug_(false),
  subtile_wall_center_mask_ratio_(0.65),
  subtile_curve_center_mask_ratio_(0.80),
  floor_color_center_mask_ratio_(0.70),
  transition_reassociation_boundary_margin_m_(0.006),
  transition_center_max_distance_m_(0.068),
  checkpoint_center_max_distance_m_(0.055),
  transition_same_color_cooldown_s_(6.0),
  black_hole_projection_boundary_margin_m_(0.012),
  semantic_observation_max_abs_world_m_(50.0),
  semantic_observation_max_tile_distance_(2),
  hole_duplicate_association_radius_tiles_(1),
  hole_duplicate_association_max_center_distance_m_(0.17),
  hole_confirmation_required_hits_(2),
  hole_confirmation_window_s_(2.0),
  hole_confirm_immediate_confidence_(0.95),
  hole_candidate_min_confidence_(0.75),
  controller_hole_weak_distance_travel_m_(0.005),
  controller_hole_normal_clear_center_distance_m_(0.025),
  controller_hole_normal_clear_hits_(2),
  enable_curve_primitives_(true),
  curve_proto_inner_radius_(0.055),
  curve_proto_outer_radius_(0.065),
  curve_proto_tile_size_(0.300),
  curve_wall_margin_m_(0.0015),
  curve_base_tolerance_m_(0.006),
  curve_hit_tolerance_max_m_(0.01875),
  curve_yaw_sigma_rad_(0.035),
  curve_subtile_containment_tolerance_m_(0.0015),
  curve_radius_offset_m_(-0.002),
  curve_radial_center_tolerance_m_(0.004),
  curve_radial_center_power_(2.0),
  curve_angular_center_power_(2.5),
  curve_positive_weight_scale_(1.00),
  curve_negative_weight_scale_(0.70),
  curve_subtile_containment_required_fraction_(0.98),
  curve_positive_min_incidence_(0.40),
  curve_positive_min_hit_score_(0.20),
  curve_endpoint_exclusion_ratio_(0.10),
  curve_min_visibility_rays_(8),
  curve_min_confidence_(0.20),
  curve_min_best_margin_(0.05),
  curve_edge_ambiguity_ratio_(0.70),
  curve_coverage_bins_(16),
  curve_min_coverage_score_(0.20),
  publish_curve_debug_(true),
  publish_curve_geometry_debug_(true),
  curve_debug_min_confidence_(0.05),
  curve_debug_log_scores_(false),
  curve_debug_log_period_s_(2.0),
  curve_debug_marker_z_(0.078),
  curve_debug_marker_alpha_min_(0.08),
  curve_debug_marker_alpha_max_(0.65),
  curve_debug_color_r_(0.20),
  curve_debug_color_g_(0.95),
  curve_debug_color_b_(1.00)
{
  loadParameters();
  validateParameters();
  parameter_callback_handle_ = add_on_set_parameters_callback(
    std::bind(&MapperNode::onDynamicParameters, this, std::placeholders::_1));
  phantom_tile_map_.configurePrimitiveLogOdds(
    primitive_positive_log_odds_update_,
    primitive_negative_log_odds_update_,
    primitive_log_odds_min_,
    primitive_log_odds_max_);
  phantom_tile_map_.configureTemporalEvidence(
    lidar_evidence_decay_half_life_s_,
    obstacle_temporal_decay_half_life_s_,
    lidar_positive_evidence_max_,
    lidar_negative_evidence_max_);
  tf_buffer_ = std::make_unique<tf2_ros::Buffer>(get_clock());
  tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);

  lidar_integration_blocked_until_ = get_clock()->now();
  last_integrated_scan_stamp_ = lidar_integration_blocked_until_;

  if (origin_mode_ == "manual") {
    origin_initialized_ = true;
  }

  odom_sub_ = create_subscription<nav_msgs::msg::Odometry>(
    odom_topic_,
    rclcpp::QoS(10),
    std::bind(&MapperNode::odomCallback, this, std::placeholders::_1));

  scan_sub_ = create_subscription<sensor_msgs::msg::LaserScan>(
    scan_topic_,
    rclcpp::SensorDataQoS(),
    std::bind(&MapperNode::scanCallback, this, std::placeholders::_1));

  auto slam_map_qos = rclcpp::QoS(rclcpp::KeepLast(1));
  slam_map_qos.reliable();
  slam_map_qos.transient_local();
  slam_map_sub_ = create_subscription<nav_msgs::msg::OccupancyGrid>(
    slam_geometry_config_.map_topic,
    slam_map_qos,
    std::bind(&MapperNode::slamMapCallback, this, std::placeholders::_1));

  auto bridge_ready_qos = rclcpp::QoS(rclcpp::KeepLast(1));
  bridge_ready_qos.reliable();
  bridge_ready_qos.transient_local();
  bridge_ready_sub_ = create_subscription<std_msgs::msg::String>(
    bridge_ready_topic_,
    bridge_ready_qos,
    std::bind(&MapperNode::bridgeReadyCallback, this, std::placeholders::_1));

  if (enable_floor_color_observations_) {
    floor_color_sub_ = create_subscription<std_msgs::msg::String>(
      floor_color_topic_,
      rclcpp::QoS(10),
      std::bind(&MapperNode::floorColorCallback, this, std::placeholders::_1));

    RCLCPP_INFO(
      get_logger(),
      "Floor color observations enabled on topic '%s'",
      floor_color_topic_.c_str());
  } else {
    RCLCPP_INFO(get_logger(), "Floor color observations disabled");
  }

  hole_detection_sub_ = create_subscription<std_msgs::msg::String>(
    hole_detection_topic_,
    rclcpp::QoS(10),
    std::bind(&MapperNode::holeDetectionCallback, this, std::placeholders::_1));

  RCLCPP_INFO(
    get_logger(),
    "Controller hole detections enabled on topic '%s'",
    hole_detection_topic_.c_str());

  vision_classification_sub_ = create_subscription<std_msgs::msg::String>(
    vision_classification_topic_,
    rclcpp::QoS(10),
    std::bind(&MapperNode::visionClassificationCallback, this, std::placeholders::_1));

  RCLCPP_INFO(
    get_logger(),
    "Vision classifications enabled on topic '%s'",
    vision_classification_topic_.c_str());

  tile_markers_pub_ = create_publisher<visualization_msgs::msg::MarkerArray>(
    tile_markers_topic_,
    rclcpp::QoS(10));

  phantom_tile_markers_pub_ = create_publisher<visualization_msgs::msg::MarkerArray>(
    phantom_tiles_topic_,
    rclcpp::QoS(10));

  submission_geometry_marker_pub_ = create_publisher<visualization_msgs::msg::MarkerArray>(
    submission_geometry_topic_,
    rclcpp::QoS(10));

  lidar_points_pub_ = create_publisher<visualization_msgs::msg::Marker>(
    lidar_points_topic_,
    rclcpp::QoS(rclcpp::KeepLast(1)));

  current_tile_pub_ = create_publisher<std_msgs::msg::String>(
    "/mapper/current_tile",
    rclcpp::QoS(10));

  tile_semantic_map_pub_ = create_publisher<std_msgs::msg::String>(
    "/mapper/tile_semantic_map",
    rclcpp::QoS(10));

  submission_matrix_pub_ = create_publisher<std_msgs::msg::String>(
    "/mapper/submission_matrix",
    rclcpp::QoS(10));

  mapper_events_pub_ = create_publisher<std_msgs::msg::String>(
    "/mapper/events",
    rclcpp::QoS(10));

  mapper_status_pub_ = create_publisher<std_msgs::msg::String>(
      "/mapper/status",
      rclcpp::QoS(10));

  const auto period = std::chrono::duration<double>(1.0 / marker_publish_rate_hz_);
  publish_timer_ = create_wall_timer(
    std::chrono::duration_cast<std::chrono::nanoseconds>(period),
    std::bind(&MapperNode::publishTimerCallback, this));

  RCLCPP_INFO(
    get_logger(),
    "ros2_mapper started: odom=%s scan=%s map=%s bridge_ready=%s marker_frame=%s origin_mode=%s tile_size=%.3f auto_start=%s race_wait_for_bridge_ready=%s",
    odom_topic_.c_str(),
    scan_topic_.c_str(),
    slam_geometry_config_.map_topic.c_str(),
    bridge_ready_topic_.c_str(),
    marker_frame_.c_str(),
    origin_mode_.c_str(),
    tile_size_,
    auto_start_ ? "true" : "false",
    race_wait_for_bridge_ready_ ? "true" : "false");
  logRobotEvent(
    "mapper_started",
    {
      {"odom_topic", odom_topic_},
      {"scan_topic", scan_topic_},
      {"map_topic", slam_geometry_config_.map_topic},
      {"bridge_ready_topic", bridge_ready_topic_},
      {"marker_frame", marker_frame_},
      {"origin_mode", origin_mode_},
      {"tile_size", numberText(tile_size_, 3)},
      {"auto_start", boolText(auto_start_)},
      {"race_wait_for_bridge_ready", boolText(race_wait_for_bridge_ready_)},
      {"floor_color_topic", floor_color_topic_},
      {"vision_classification_topic", vision_classification_topic_},
    });
  RCLCPP_INFO(
    get_logger(),
    "Mapper status publisher active on /mapper/status period=%.3f s",
    status_publish_period_s_);
}

void MapperNode::loadParameters()
{
  odom_topic_ = declare_parameter<std::string>("odom_topic", "/odometry/filtered");
  scan_topic_ = declare_parameter<std::string>("scan_topic", "/scan");
  bridge_ready_topic_ =
    declare_parameter<std::string>("bridge_ready_topic", "/ros2_bridge/ready");
  tile_markers_topic_ = declare_parameter<std::string>("tile_markers_topic", "/tile_markers");
  lidar_points_topic_ = declare_parameter<std::string>(
    "lidar_points_topic", "/mapper_debug/lidar_points");
  phantom_tiles_topic_ = declare_parameter<std::string>(
    "phantom_tiles_topic", "/mapper_debug/phantom_tiles");

  marker_frame_ = declare_parameter<std::string>("marker_frame", "odom");
  marker_use_latest_tf_stamp_ =
    declare_parameter<bool>("markers.use_latest_tf_stamp", true);

  auto_start_ = declare_parameter<bool>("auto_start", false);
  race_wait_for_bridge_ready_ =
    declare_parameter<bool>("race_wait_for_bridge_ready", false);
  race_require_scan_after_ready_ =
    declare_parameter<bool>("race_require_scan_after_ready", true);
  race_require_odom_after_ready_ =
    declare_parameter<bool>("race_require_odom_after_ready", true);
  mapping_active_ = auto_start_ && !race_wait_for_bridge_ready_;

  tile_size_ = declare_parameter<double>("tile_size", 0.12);
  origin_mode_ = declare_parameter<std::string>("origin_mode", "auto_first_pose");
  origin_x_ = declare_parameter<double>("origin_x", 0.0);
  origin_y_ = declare_parameter<double>("origin_y", 0.0);
  origin_require_scan_before_init_ =
    declare_parameter<bool>("origin_require_scan_before_init", true);
  origin_require_scan_timeout_s_ =
    declare_parameter<double>("origin_require_scan_timeout_s", 5.0);

  marker_publish_rate_hz_ = declare_parameter<double>("marker_publish_rate_hz", 10.0);

  current_tile_marker_z_ = declare_parameter<double>("current_tile_marker_z", 0.002);
  current_tile_marker_height_ = declare_parameter<double>("current_tile_marker_height", 0.004);
  current_tile_alpha_ = declare_parameter<double>("current_tile_alpha", 0.30);
  current_tile_color_r_ = declare_parameter<double>("current_tile_color_r", 0.10);
  current_tile_color_g_ = declare_parameter<double>("current_tile_color_g", 0.70);
  current_tile_color_b_ = declare_parameter<double>("current_tile_color_b", 1.00);

  current_tile_center_z_ = declare_parameter<double>("current_tile_center_z", 0.015);
  current_tile_center_radius_ = declare_parameter<double>("current_tile_center_radius", 0.015);

  publish_visited_tiles_ = declare_parameter<bool>("publish_visited_tiles", true);
  visited_tile_marker_z_ = declare_parameter<double>("visited_tile_marker_z", 0.001);
  visited_tile_marker_height_ = declare_parameter<double>("visited_tile_marker_height", 0.002);
  visited_tile_alpha_ = declare_parameter<double>("visited_tile_alpha", 0.18);
  visited_tile_color_r_ = declare_parameter<double>("visited_tile_color_r", 0.20);
  visited_tile_color_g_ = declare_parameter<double>("visited_tile_color_g", 0.85);
  visited_tile_color_b_ = declare_parameter<double>("visited_tile_color_b", 0.35);

  log_tile_changes_ = declare_parameter<bool>("log_tile_changes", true);

  mark_origin_tile_as_start_ =
    declare_parameter<bool>("mark_origin_tile_as_start", true);

  publish_semantic_tile_colors_ =
    declare_parameter<bool>("publish_semantic_tile_colors", true);

  semantic_tile_alpha_ =
    declare_parameter<double>("semantic_tile_alpha", 0.35);

  publish_semantic_map_json_ =
    declare_parameter<bool>("publish_semantic_map_json", true);

  semantic_map_publish_period_s_ =
    declare_parameter<double>("semantic_map_publish_period_s", 0.5);

  semantic_map_max_tiles_ =
    declare_parameter<int>("semantic_map_max_tiles", 500);

  status_publish_period_s_ =
    declare_parameter<double>("status_publish_period_s", 0.5);
  map_validity_summary_log_period_s_ =
    declare_parameter<double>("map_validity_summary_log_period_s", 1.0);
  odom_recent_timeout_s_ =
    declare_parameter<double>("odom_recent_timeout_s", 1.0);
  scan_recent_timeout_s_ =
    declare_parameter<double>("scan_recent_timeout_s", 1.0);
  slam_map_recent_timeout_s_ =
    declare_parameter<double>("slam_map_recent_timeout_s", 3.0);
  slam_geometry_config_.enabled =
    declare_parameter<bool>("slam_geometry.enabled", true);
  slam_geometry_config_.map_topic =
    declare_parameter<std::string>("slam_geometry.map_topic", "/map");
  slam_geometry_config_.expected_resolution_m =
    declare_parameter<double>("slam_geometry.expected_resolution_m", 0.005);
  slam_geometry_config_.resolution_tolerance_m =
    declare_parameter<double>("slam_geometry.resolution_tolerance_m", 0.002);
  slam_geometry_config_.max_map_age_sec =
    declare_parameter<double>("slam_geometry.max_map_age_sec", 1.0);
  slam_geometry_config_.min_known_cells =
    declare_parameter<int>("slam_geometry.min_known_cells", 200);
  slam_geometry_config_.min_occupied_cells =
    declare_parameter<int>("slam_geometry.min_occupied_cells", 20);
  slam_geometry_config_.min_known_ratio =
    declare_parameter<double>("slam_geometry.min_known_ratio", 0.001);
  slam_geometry_config_.reject_all_free_maps =
    declare_parameter<bool>("slam_geometry.reject_all_free_maps", true);
  slam_geometry_config_.reject_all_unknown_maps =
    declare_parameter<bool>("slam_geometry.reject_all_unknown_maps", true);
  slam_geometry_config_.free_threshold =
    declare_parameter<int>("slam_geometry.free_threshold", 20);
  slam_geometry_config_.occupied_threshold =
    declare_parameter<int>("slam_geometry.occupied_threshold", 65);
  slam_geometry_config_.debug_log_period_sec =
    declare_parameter<double>("slam_geometry.debug_log_period_sec", 2.0);
  slam_geometry_config_.confirmed_wall_occupied_ratio =
    declare_parameter<double>("slam_geometry.confirmed_wall_occupied_ratio", 0.45);
  slam_geometry_config_.likely_wall_occupied_ratio =
    declare_parameter<double>("slam_geometry.likely_wall_occupied_ratio", 0.25);
  slam_geometry_config_.likely_open_free_ratio =
    declare_parameter<double>("slam_geometry.likely_open_free_ratio", 0.60);
  slam_geometry_config_.confirmed_open_free_ratio =
    declare_parameter<double>("slam_geometry.confirmed_open_free_ratio", 0.80);
  slam_geometry_config_.max_open_occupied_ratio =
    declare_parameter<double>("slam_geometry.max_open_occupied_ratio", 0.10);
  slam_geometry_config_.max_confirmed_open_unknown_ratio =
    declare_parameter<double>("slam_geometry.max_confirmed_open_unknown_ratio", 0.25);
  slam_geometry_config_.min_region_samples =
    declare_parameter<int>("slam_geometry.min_region_samples", 8);
  slam_geometry_config_.tile_interior_ratio =
    declare_parameter<double>("slam_geometry.tile_interior_ratio", 0.60);
  slam_geometry_config_.edge_strip_length_ratio =
    declare_parameter<double>("slam_geometry.edge_strip_length_ratio", 0.70);
  slam_geometry_config_.edge_strip_min_width_m =
    declare_parameter<double>("slam_geometry.edge_strip_min_width_m", 0.025);
  slam_geometry_config_.corridor_width_m =
    declare_parameter<double>("slam_geometry.corridor_width_m", 0.10);
  slam_geometry_config_.phantom_support_free_ratio =
    declare_parameter<double>("slam_geometry.phantom_support_free_ratio", 0.60);
  slam_geometry_config_.phantom_conflict_occupied_ratio =
    declare_parameter<double>("slam_geometry.phantom_conflict_occupied_ratio", 0.25);
  slam_geometry_config_.phantom_confirmed_conflict_occupied_ratio =
    declare_parameter<double>("slam_geometry.phantom_confirmed_conflict_occupied_ratio", 0.45);
  slam_geometry_config_.phantom_max_supported_occupied_ratio =
    declare_parameter<double>("slam_geometry.phantom_max_supported_occupied_ratio", 0.10);
  slam_geometry_config_.phantom_min_region_samples =
    declare_parameter<int>("slam_geometry.phantom_min_region_samples", 8);
  slam_geometry_config_.phantom_tile_sample_scale =
    declare_parameter<double>("slam_geometry.phantom_tile_sample_scale", 0.60);
  slam_geometry_config_.phantom_corridor_width_m =
    declare_parameter<double>("slam_geometry.phantom_corridor_width_m", 0.09);
  slam_geometry_config_.clearance_enabled =
    declare_parameter<bool>("clearance.enabled", true);
  slam_geometry_config_.clearance_occupied_threshold =
    declare_parameter<int>("clearance.occupied_threshold", 65);
  slam_geometry_config_.clearance_unknown_as_obstacle =
    declare_parameter<bool>("clearance.unknown_as_obstacle", false);
  slam_geometry_config_.clearance_robot_radius_m =
    declare_parameter<double>("clearance.robot_radius_m", 0.035);
  slam_geometry_config_.clearance_safety_margin_m =
    declare_parameter<double>("clearance.safety_margin_m", 0.015);
  slam_geometry_config_.clearance_min_passage_clearance_m =
    declare_parameter<double>("clearance.min_passage_clearance_m", 0.050);
  slam_geometry_config_.clearance_stale_after_sec =
    declare_parameter<double>("clearance.stale_after_sec", 1.0);
  slam_map_sampler_.configure(slam_geometry_config_);

  // RandomForest map-geometry models (explored gate + wall/curve + obstacle).
  map_model_explorado_path_ = declare_parameter<std::string>(
    "models.map_explorado", "/workspace/controller/models/map_explorado.yml");
  map_model_parede_path_ = declare_parameter<std::string>(
    "models.map_parede", "/workspace/controller/models/map_parede.yml");
  map_model_curva_path_ = declare_parameter<std::string>(
    "models.map_curva", "/workspace/controller/models/map_curva.yml");
  map_model_obstaculo_path_ = declare_parameter<std::string>(
    "models.map_obstaculo", "/workspace/controller/models/map_obstaculo.yml");
  if (map_geometry_models_.load(
      map_model_explorado_path_, map_model_parede_path_,
      map_model_curva_path_, map_model_obstaculo_path_))
  {
    RCLCPP_INFO(get_logger(), "map geometry RF models loaded (explored/wall/curve/obstacle)");
  } else {
    RCLCPP_ERROR(
      get_logger(),
      "FAILED to load map geometry RF models (%s ...); submission geometry will be empty",
      map_model_explorado_path_.c_str());
  }

  edge_evidence_enabled_ =
    declare_parameter<bool>("edge_evidence.enabled", true);
  edge_evidence_wall_update_gain_ =
    declare_parameter<double>("edge_evidence.wall_update_gain", 0.85);
  edge_evidence_open_update_gain_ =
    declare_parameter<double>("edge_evidence.open_update_gain", 0.65);
  edge_evidence_conflict_decay_ =
    declare_parameter<double>("edge_evidence.conflict_decay", 0.35);
  edge_evidence_unknown_ema_alpha_ =
    declare_parameter<double>("edge_evidence.unknown_ema_alpha", 0.30);
  edge_evidence_min_log_odds_ =
    declare_parameter<double>("edge_evidence.min_log_odds", -4.0);
  edge_evidence_max_log_odds_ =
    declare_parameter<double>("edge_evidence.max_log_odds", 4.0);
  edge_evidence_confirmed_wall_log_odds_ =
    declare_parameter<double>("edge_evidence.confirmed_wall_log_odds", 2.2);
  edge_evidence_likely_wall_log_odds_ =
    declare_parameter<double>("edge_evidence.likely_wall_log_odds", 1.0);
  edge_evidence_confirmed_open_log_odds_ =
    declare_parameter<double>("edge_evidence.confirmed_open_log_odds", 2.0);
  edge_evidence_likely_open_log_odds_ =
    declare_parameter<double>("edge_evidence.likely_open_log_odds", 0.9);
  edge_evidence_conflict_log_odds_delta_ =
    declare_parameter<double>("edge_evidence.conflict_log_odds_delta", 0.75);
  edge_evidence_stale_after_sec_ =
    declare_parameter<double>("edge_evidence.stale_after_sec", 3.0);

  enable_floor_color_observations_ =
    declare_parameter<bool>("enable_floor_color_observations", true);

  floor_color_topic_ =
    declare_parameter<std::string>("floor_color_topic", "/floor_color/classification");

  color_sensor_forward_offset_ =
    declare_parameter<double>("color_sensor_forward_offset", 0.037);

  color_sensor_lateral_offset_ =
    declare_parameter<double>("color_sensor_lateral_offset", 0.0);

  floor_color_min_confidence_ =
    declare_parameter<double>("floor_color_min_confidence", 0.5);

  floor_color_update_margin_m_ =
    declare_parameter<double>("floor_color_update_margin_m", 0.005);

  floor_color_allow_normal_correction_ =
    declare_parameter<bool>("floor_color_allow_normal_correction", true);

  floor_color_center_mask_ratio_ =
    declare_parameter<double>("floor_color_center_mask_ratio", 0.70);

  transition_reassociation_boundary_margin_m_ =
    declare_parameter<double>("transition_reassociation_boundary_margin_m", 0.006);

  transition_center_max_distance_m_ =
    declare_parameter<double>("transition_center_max_distance_m", 0.068);

  checkpoint_center_max_distance_m_ =
    declare_parameter<double>("checkpoint_center_max_distance_m", 0.055);

  transition_same_color_cooldown_s_ =
    declare_parameter<double>("transition_same_color_cooldown_s", 6.0);

  black_hole_projection_boundary_margin_m_ =
    declare_parameter<double>("black_hole_projection_boundary_margin_m", 0.012);

  semantic_observation_max_abs_world_m_ =
    declare_parameter<double>("semantic_observation_max_abs_world_m", 50.0);

  semantic_observation_max_tile_distance_ =
    declare_parameter<int>("semantic_observation_max_tile_distance", 2);

  hole_duplicate_association_radius_tiles_ =
    declare_parameter<int>("hole_duplicate_association_radius_tiles", 1);

  hole_duplicate_association_max_center_distance_m_ =
    declare_parameter<double>("hole_duplicate_association_max_center_distance_m", 0.17);

  hole_confirmation_required_hits_ =
    declare_parameter<int>("hole_confirmation_required_hits", 2);

  hole_confirmation_window_s_ =
    declare_parameter<double>("hole_confirmation_window_s", 2.0);

  hole_confirm_immediate_confidence_ =
    declare_parameter<double>("hole_confirm_immediate_confidence", 0.95);

  hole_candidate_min_confidence_ =
    declare_parameter<double>("hole_candidate_min_confidence", 0.75);

  hole_detection_topic_ =
    declare_parameter<std::string>("hole_detection_topic", "/hazard/hole_detection");
  vision_classification_topic_ =
    declare_parameter<std::string>("vision_classification_topic", "/vision/classification");

  legacy_hole_projection_distance_m_ =
    declare_parameter<double>("legacy_hole_projection_distance_m", 0.06);

  controller_hole_weak_distance_travel_m_ =
    declare_parameter<double>("controller_hole_weak_distance_travel_m", 0.005);

  controller_hole_normal_clear_center_distance_m_ =
    declare_parameter<double>("controller_hole_normal_clear_center_distance_m", 0.025);

  controller_hole_normal_clear_hits_ =
    declare_parameter<int>("controller_hole_normal_clear_hits", 2);

  hazard_preserve_confirmed_black_hole_ =
    declare_parameter<bool>("hazard.preserve_confirmed_black_hole", true);

  use_area4_all_ = declare_parameter<bool>("use_area4_all", false);

  submission_model_explored_tiles_ =
    declare_parameter<bool>("submission_model_explored_tiles", true);
  submission_area4_flood_fill_ =
    declare_parameter<bool>("submission_area4_flood_fill", true);

  area_hint_max_lidar_distance_m_ =
    declare_parameter<double>("area_hint_max_lidar_distance_m", 0.25);

  area_assignment_requires_visit_ =
    declare_parameter<bool>("area_assignment_requires_visit", true);

  publish_lidar_debug_points_ = declare_parameter<bool>("publish_lidar_debug_points", true);
  lidar_debug_point_stride_ = declare_parameter<int>("lidar_debug_point_stride", 1);
  lidar_debug_point_size_ = declare_parameter<double>("lidar_debug_point_size", 0.01);
  lidar_debug_z_ = declare_parameter<double>("lidar_debug_z", 0.02);
  lidar_debug_min_range_ = declare_parameter<double>("lidar_debug_min_range", 0.01);
  lidar_debug_max_range_ = declare_parameter<double>("lidar_debug_max_range", 1.0);

  enable_lidar_phantom_observations_ =
    declare_parameter<bool>("enable_lidar_phantom_observations", true);
  lidar_observation_max_range_ =
    declare_parameter<double>("lidar_observation_max_range", 0.55);
  lidar_ray_step_m_ = declare_parameter<double>("lidar_ray_step_m", 0.015);
  lidar_ray_grid_step_m_ = declare_parameter<double>("lidar_ray_grid_step_m", 0.005);
  lidar_range_weight_scale_m_ =
    declare_parameter<double>("lidar_range_weight_scale_m", 0.5);
  lidar_range_sigma_m_ =
    declare_parameter<double>("lidar_range_sigma_m", 0.003);
  lidar_evidence_decay_half_life_s_ =
    declare_parameter<double>("lidar_evidence_decay_half_life_s", 8.0);
  lidar_positive_evidence_max_ =
    declare_parameter<double>("lidar_positive_evidence_max", 12.0);
  lidar_negative_evidence_max_ =
    declare_parameter<double>("lidar_negative_evidence_max", 12.0);
  lidar_conflict_weight_ =
    declare_parameter<double>("lidar_conflict_weight", 2.0);
  lidar_skip_after_teleport_s_ =
    declare_parameter<double>("lidar_skip_after_teleport_s", 0.50);
  max_scan_odom_time_delta_s_ =
    declare_parameter<double>("max_scan_odom_time_delta_s", 0.15);
  odom_buffer_duration_s_ =
    declare_parameter<double>("odom_buffer_duration_s", 1.0);
  scan_odom_match_max_delta_s_ =
    declare_parameter<double>("scan_odom_match_max_delta_s", 0.12);
  enable_delayed_scan_processing_ =
    declare_parameter<bool>("enable_delayed_scan_processing", true);
  scan_processing_delay_s_ =
    declare_parameter<double>("scan_processing_delay_s", 0.10);
  scan_pending_max_age_s_ =
    declare_parameter<double>("scan_pending_max_age_s", 0.50);
  require_odom_bracket_for_scan_ =
    declare_parameter<bool>("require_odom_bracket_for_scan", true);
  odom_interpolation_max_gap_s_ =
    declare_parameter<double>("odom_interpolation_max_gap_s", 0.20);
  reject_non_monotonic_scan_stamps_ =
    declare_parameter<bool>("reject_non_monotonic_scan_stamps", true);

  publish_phantom_tiles_ = declare_parameter<bool>("publish_phantom_tiles", true);
  publish_submission_geometry_ =
    declare_parameter<bool>("publish_submission_geometry", true);
  submission_geometry_topic_ = declare_parameter<std::string>(
    "submission_geometry_topic", "/mapper_debug/submission_geometry");
  submission_curve_visual_transform_ = declare_parameter<std::string>(
    "submission_curve_visual_transform", "rotate_180");
  submission_min_wall_confidence_ =
    declare_parameter<double>("submission_min_wall_confidence", 0.5);
  phantom_visual_mode_ =
    declare_parameter<std::string>("phantom_visual_mode", "summary");
  publish_phantom_tile_background_ =
    declare_parameter<bool>("publish_phantom_tile_background", false);
  publish_phantom_quadrant_debug_ =
    declare_parameter<bool>("publish_phantom_quadrant_debug", false);
  publish_phantom_free_summary_ =
    declare_parameter<bool>("publish_phantom_free_summary", false);
  phantom_update_max_tile_radius_ =
    declare_parameter<int>("phantom_update_max_tile_radius", 4);
  phantom_mask_max_tile_radius_ =
    declare_parameter<int>("phantom_mask_max_tile_radius", 3);
  phantom_tile_marker_z_ = declare_parameter<double>("phantom_tile_marker_z", 0.035);
  phantom_tile_marker_height_ = declare_parameter<double>("phantom_tile_marker_height", 0.003);
  phantom_tile_marker_alpha_ = declare_parameter<double>("phantom_tile_marker_alpha", 0.02);
  phantom_quadrant_marker_z_ = declare_parameter<double>("phantom_quadrant_marker_z", 0.038);
  phantom_quadrant_marker_height_ =
    declare_parameter<double>("phantom_quadrant_marker_height", 0.004);
  phantom_quadrant_marker_alpha_min_ =
    declare_parameter<double>("phantom_quadrant_marker_alpha_min", 0.01);
  phantom_quadrant_marker_alpha_max_ =
    declare_parameter<double>("phantom_quadrant_marker_alpha_max", 0.08);

  enable_quarter_edge_evidence_ =
    declare_parameter<bool>("enable_quarter_edge_evidence", true);
  quarter_edge_hit_tolerance_m_ =
    declare_parameter<double>("quarter_edge_hit_tolerance_m", 0.012);
  quarter_edge_free_conflict_tolerance_m_ =
    declare_parameter<double>("quarter_edge_free_conflict_tolerance_m", 0.010);
  quarter_edge_min_visibility_rays_ =
    declare_parameter<int>("quarter_edge_min_visibility_rays", 3);
  quarter_edge_hit_weight_ =
    declare_parameter<double>("quarter_edge_hit_weight", 1.0);
  quarter_edge_conflict_weight_ =
    declare_parameter<double>("quarter_edge_conflict_weight", 2.0);
  publish_quarter_edge_debug_ =
    declare_parameter<bool>("publish_quarter_edge_debug", false);
  quarter_edge_marker_z_ =
    declare_parameter<double>("quarter_edge_marker_z", 0.052);
  quarter_edge_marker_thickness_ =
    declare_parameter<double>("quarter_edge_marker_thickness", 0.006);
  quarter_edge_marker_alpha_min_ =
    declare_parameter<double>("quarter_edge_marker_alpha_min", 0.04);
  quarter_edge_marker_alpha_max_ =
    declare_parameter<double>("quarter_edge_marker_alpha_max", 0.25);
  mask_supported_segment_min_score_ =
    declare_parameter<double>("mask_supported_segment_min_score", 0.5);
  mask_conflict_segment_max_score_ =
    declare_parameter<double>("mask_conflict_segment_max_score", -0.5);
  mask_complexity_penalty_ =
    declare_parameter<double>("mask_complexity_penalty", 0.15);
  mask_unsupported_segment_penalty_ =
    declare_parameter<double>("mask_unsupported_segment_penalty", 0.25);
  mask_min_confidence_ =
    declare_parameter<double>("mask_min_confidence", 0.0);
  publish_phantom_mask_debug_ =
    declare_parameter<bool>("publish_phantom_mask_debug", false);
  phantom_mask_marker_z_ =
    declare_parameter<double>("phantom_mask_marker_z", 0.060);
  phantom_mask_marker_thickness_ =
    declare_parameter<double>("phantom_mask_marker_thickness", 0.009);
  phantom_mask_marker_alpha_min_ =
    declare_parameter<double>("phantom_mask_marker_alpha_min", 0.08);
  phantom_mask_marker_alpha_max_ =
    declare_parameter<double>("phantom_mask_marker_alpha_max", 0.45);
  phantom_summary_min_confidence_ =
    declare_parameter<double>("phantom_summary_min_confidence", 0.20);
  phantom_summary_marker_alpha_min_ =
    declare_parameter<double>("phantom_summary_marker_alpha_min", 0.08);
  phantom_summary_marker_alpha_max_ =
    declare_parameter<double>("phantom_summary_marker_alpha_max", 0.50);
  phantom_free_summary_alpha_max_ =
    declare_parameter<double>("phantom_free_summary_alpha_max", 0.12);

  enable_ray_model_primitives_ =
    declare_parameter<bool>("enable_ray_model_primitives", true);
  primitive_wall_thickness_m_ =
    declare_parameter<double>("primitive_wall_thickness_m", 0.010);
  primitive_wall_margin_m_ =
    declare_parameter<double>("primitive_wall_margin_m", 0.006);
  primitive_base_tolerance_m_ =
    declare_parameter<double>("primitive_base_tolerance_m", 0.006);
  primitive_yaw_sigma_rad_ =
    declare_parameter<double>("primitive_yaw_sigma_rad", 0.035);
  primitive_hit_tolerance_max_m_ =
    declare_parameter<double>("primitive_hit_tolerance_max_m", 0.008);
  primitive_allow_multi_positive_per_ray_ =
    declare_parameter<bool>("primitive_allow_multi_positive_per_ray", false);
  primitive_positive_min_incidence_ =
    declare_parameter<double>("primitive_positive_min_incidence", 0.40);
  primitive_positive_min_hit_score_ =
    declare_parameter<double>("primitive_positive_min_hit_score", 0.20);
  primitive_endpoint_exclusion_ratio_ =
    declare_parameter<double>("primitive_endpoint_exclusion_ratio", 0.10);
  primitive_positive_log_odds_update_ =
    declare_parameter<double>("primitive_positive_log_odds_update", 0.25);
  primitive_negative_log_odds_update_ =
    declare_parameter<double>("primitive_negative_log_odds_update", 0.90);
  primitive_log_odds_min_ =
    declare_parameter<double>("primitive_log_odds_min", -4.0);
  primitive_log_odds_max_ =
    declare_parameter<double>("primitive_log_odds_max", 4.0);
  primitive_min_visibility_rays_ =
    declare_parameter<int>("primitive_min_visibility_rays", 8);
  publish_primitive_debug_ =
    declare_parameter<bool>("publish_primitive_debug", true);
  primitive_debug_min_confidence_ =
    declare_parameter<double>("primitive_debug_min_confidence", 0.40);
  primitive_debug_marker_z_ =
    declare_parameter<double>("primitive_debug_marker_z", 0.070);
  primitive_debug_marker_alpha_min_ =
    declare_parameter<double>("primitive_debug_marker_alpha_min", 0.08);
  primitive_debug_marker_alpha_max_ =
    declare_parameter<double>("primitive_debug_marker_alpha_max", 0.65);
  primitive_debug_marker_thickness_ =
    declare_parameter<double>("primitive_debug_marker_thickness", 0.008);
  primitive_debug_color_r_ =
    declare_parameter<double>("primitive_debug_color_r", 0.20);
  primitive_debug_color_g_ =
    declare_parameter<double>("primitive_debug_color_g", 0.95);
  primitive_debug_color_b_ =
    declare_parameter<double>("primitive_debug_color_b", 1.00);
  publish_primitive_negative_debug_ =
    declare_parameter<bool>("publish_primitive_negative_debug", false);
  primitive_negative_debug_min_confidence_ =
    declare_parameter<double>("primitive_negative_debug_min_confidence", 0.30);
  primitive_negative_debug_color_r_ =
    declare_parameter<double>("primitive_negative_debug_color_r", 1.00);
  primitive_negative_debug_color_g_ =
    declare_parameter<double>("primitive_negative_debug_color_g", 0.15);
  primitive_negative_debug_color_b_ =
    declare_parameter<double>("primitive_negative_debug_color_b", 0.15);
  primitive_negative_debug_marker_alpha_min_ =
    declare_parameter<double>("primitive_negative_debug_marker_alpha_min", 0.04);
  primitive_negative_debug_marker_alpha_max_ =
    declare_parameter<double>("primitive_negative_debug_marker_alpha_max", 0.25);

  enable_obstacle_primitives_ =
    declare_parameter<bool>("enable_obstacle_primitives", false);
  obstacle_grid_bins_per_tile_ =
    declare_parameter<int>("obstacle_grid_bins_per_tile", kObstacleGridBinsPerTile);
  obstacle_bin_hit_weight_ =
    declare_parameter<double>("obstacle_bin_hit_weight", 1.0);
  obstacle_bin_free_weight_ =
    declare_parameter<double>("obstacle_bin_free_weight", 2.0);
  obstacle_bin_occupied_threshold_ =
    declare_parameter<double>("obstacle_bin_occupied_threshold", 3.0);
  obstacle_bin_free_margin_ =
    declare_parameter<double>("obstacle_bin_free_margin", 1.0);
  obstacle_min_cluster_bins_ =
    declare_parameter<int>("obstacle_min_cluster_bins", 8);
  obstacle_min_total_hits_ =
    declare_parameter<int>("obstacle_min_total_hits", 10);
  obstacle_min_confidence_ =
    declare_parameter<double>("obstacle_min_confidence", 0.70);
  obstacle_debug_min_confidence_ =
    declare_parameter<double>("obstacle_debug_min_confidence", 0.70);
  obstacle_max_free_ratio_ =
    declare_parameter<double>("obstacle_max_free_ratio", 0.30);
  obstacle_min_distance_from_tile_edge_m_ =
    declare_parameter<double>("obstacle_min_distance_from_tile_edge_m", 0.015);
  obstacle_min_box_size_m_ =
    declare_parameter<double>("obstacle_min_box_size_m", 0.015);
  obstacle_max_box_size_m_ =
    declare_parameter<double>("obstacle_max_box_size_m", 0.085);
  obstacle_box_padding_m_ =
    declare_parameter<double>("obstacle_box_padding_m", 0.005);
  obstacle_surrounding_ring_bins_ =
    declare_parameter<int>("obstacle_surrounding_ring_bins", 2);
  obstacle_min_surrounding_free_ratio_ =
    declare_parameter<double>("obstacle_min_surrounding_free_ratio", 0.45);
  obstacle_wall_overlap_penalty_ =
    declare_parameter<double>("obstacle_wall_overlap_penalty", 2.0);
  obstacle_edge_proximity_penalty_ =
    declare_parameter<double>("obstacle_edge_proximity_penalty", 1.5);
  obstacle_temporal_decay_half_life_s_ =
    declare_parameter<double>("obstacle_temporal_decay_half_life_s", 6.0);
  publish_obstacle_grid_debug_ =
    declare_parameter<bool>("publish_obstacle_grid_debug", false);

  subtile_wall_center_mask_ratio_ =
    declare_parameter<double>("subtile_wall_center_mask_ratio", 0.65);
  subtile_curve_center_mask_ratio_ =
    declare_parameter<double>("subtile_curve_center_mask_ratio", 0.80);

  enable_curve_primitives_ =
    declare_parameter<bool>("enable_curve_primitives", true);
  curve_proto_inner_radius_ =
    declare_parameter<double>("curve_proto_inner_radius", 0.055);
  curve_proto_outer_radius_ =
    declare_parameter<double>("curve_proto_outer_radius", 0.065);
  curve_proto_tile_size_ =
    declare_parameter<double>("curve_proto_tile_size", 0.300);
  curve_wall_margin_m_ =
    declare_parameter<double>("curve_wall_margin_m", 0.0015);
  curve_base_tolerance_m_ =
    declare_parameter<double>("curve_base_tolerance_m", 0.006);
  curve_hit_tolerance_max_m_ =
    declare_parameter<double>("curve_hit_tolerance_max_m", 0.01875);
  curve_yaw_sigma_rad_ =
    declare_parameter<double>("curve_yaw_sigma_rad", 0.035);
  curve_subtile_containment_tolerance_m_ =
    declare_parameter<double>("curve_subtile_containment_tolerance_m", 0.0015);
  curve_radius_offset_m_ =
    declare_parameter<double>("curve_radius_offset_m", -0.002);
  curve_radial_center_tolerance_m_ =
    declare_parameter<double>("curve_radial_center_tolerance_m", 0.004);
  curve_radial_center_power_ =
    declare_parameter<double>("curve_radial_center_power", 2.0);
  curve_angular_center_power_ =
    declare_parameter<double>("curve_angular_center_power", 2.5);
  curve_positive_weight_scale_ =
    declare_parameter<double>("curve_positive_weight_scale", 1.00);
  curve_negative_weight_scale_ =
    declare_parameter<double>("curve_negative_weight_scale", 0.70);
  curve_subtile_containment_required_fraction_ =
    declare_parameter<double>("curve_subtile_containment_required_fraction", 0.98);
  curve_positive_min_incidence_ =
    declare_parameter<double>("curve_positive_min_incidence", 0.40);
  curve_positive_min_hit_score_ =
    declare_parameter<double>("curve_positive_min_hit_score", 0.20);
  curve_endpoint_exclusion_ratio_ =
    declare_parameter<double>("curve_endpoint_exclusion_ratio", 0.10);
  curve_min_visibility_rays_ =
    declare_parameter<int>("curve_min_visibility_rays", 8);
  curve_min_confidence_ =
    declare_parameter<double>("curve_min_confidence", 0.20);
  curve_min_best_margin_ =
    declare_parameter<double>("curve_min_best_margin", 0.05);
  curve_edge_ambiguity_ratio_ =
    declare_parameter<double>("curve_edge_ambiguity_ratio", 0.70);
  curve_coverage_bins_ =
    declare_parameter<int>("curve_coverage_bins", 16);
  curve_min_coverage_score_ =
    declare_parameter<double>("curve_min_coverage_score", 0.20);
  publish_curve_debug_ =
    declare_parameter<bool>("publish_curve_debug", true);
  publish_curve_geometry_debug_ =
    declare_parameter<bool>("publish_curve_geometry_debug", true);
  curve_debug_min_confidence_ =
    declare_parameter<double>("curve_debug_min_confidence", 0.05);
  curve_debug_log_scores_ =
    declare_parameter<bool>("curve_debug_log_scores", false);
  curve_debug_log_period_s_ =
    declare_parameter<double>("curve_debug_log_period_s", 2.0);
  curve_debug_marker_z_ =
    declare_parameter<double>("curve_debug_marker_z", 0.078);
  curve_debug_marker_alpha_min_ =
    declare_parameter<double>("curve_debug_marker_alpha_min", 0.08);
  curve_debug_marker_alpha_max_ =
    declare_parameter<double>("curve_debug_marker_alpha_max", 0.65);
  curve_debug_color_r_ =
    declare_parameter<double>("curve_debug_color_r", 0.20);
  curve_debug_color_g_ =
    declare_parameter<double>("curve_debug_color_g", 0.95);
  curve_debug_color_b_ =
    declare_parameter<double>("curve_debug_color_b", 1.00);

  teleport_detection_enabled_ = declare_parameter<bool>("teleport_detection_enabled", true);
  teleport_distance_threshold_m_ = declare_parameter<double>(
    "teleport_distance_threshold_m", 0.25);
  teleport_yaw_threshold_rad_ = declare_parameter<double>(
    "teleport_yaw_threshold_rad", 1.5708);
}

void MapperNode::validateParameters() const
{
  if (odom_topic_.empty() || scan_topic_.empty() || bridge_ready_topic_.empty()) {
    RCLCPP_FATAL(get_logger(), "odom_topic, scan_topic, and bridge_ready_topic must not be empty");
    throw std::runtime_error("invalid mapper input topic");
  }

  if (tile_size_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "tile_size must be greater than zero");
    throw std::runtime_error("tile_size must be greater than zero");
  }

  if (origin_mode_ != "auto_first_pose" && origin_mode_ != "manual") {
    RCLCPP_FATAL(
      get_logger(),
      "Invalid origin_mode '%s'. Expected 'auto_first_pose' or 'manual'.",
      origin_mode_.c_str());
    throw std::runtime_error("invalid origin_mode");
  }

  if (origin_require_scan_timeout_s_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "origin_require_scan_timeout_s must be greater than zero");
    throw std::runtime_error("invalid origin_require_scan_timeout_s");
  }

  if (marker_publish_rate_hz_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "marker_publish_rate_hz must be greater than zero");
    throw std::runtime_error("marker_publish_rate_hz must be greater than zero");
  }

  if (current_tile_marker_height_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "current_tile_marker_height must be greater than zero");
    throw std::runtime_error("current_tile_marker_height must be greater than zero");
  }

  if (visited_tile_marker_height_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "visited_tile_marker_height must be greater than zero");
    throw std::runtime_error("visited_tile_marker_height must be greater than zero");
  }

  if (current_tile_center_radius_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "current_tile_center_radius must be greater than zero");
    throw std::runtime_error("current_tile_center_radius must be greater than zero");
  }

  if (lidar_debug_point_stride_ < 1) {
    RCLCPP_FATAL(get_logger(), "lidar_debug_point_stride must be at least one");
    throw std::runtime_error("lidar_debug_point_stride must be at least one");
  }

  if (lidar_debug_point_size_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "lidar_debug_point_size must be greater than zero");
    throw std::runtime_error("lidar_debug_point_size must be greater than zero");
  }

  if (lidar_debug_min_range_ < 0.0 || lidar_debug_max_range_ <= lidar_debug_min_range_) {
    RCLCPP_FATAL(
      get_logger(),
      "Invalid LiDAR debug range limits: min=%.3f max=%.3f",
      lidar_debug_min_range_,
      lidar_debug_max_range_);
    throw std::runtime_error("invalid lidar debug range limits");
  }

  if (lidar_observation_max_range_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "lidar_observation_max_range must be greater than zero");
    throw std::runtime_error("invalid lidar_observation_max_range");
  }

  if (lidar_ray_step_m_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "lidar_ray_step_m must be greater than zero");
    throw std::runtime_error("invalid lidar_ray_step_m");
  }

  if (lidar_ray_grid_step_m_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "lidar_ray_grid_step_m must be greater than zero");
    throw std::runtime_error("invalid lidar_ray_grid_step_m");
  }

  if (lidar_range_weight_scale_m_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "lidar_range_weight_scale_m must be greater than zero");
    throw std::runtime_error("invalid lidar_range_weight_scale_m");
  }

  if (lidar_range_sigma_m_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "lidar_range_sigma_m must be non-negative");
    throw std::runtime_error("invalid lidar_range_sigma_m");
  }

  if (lidar_evidence_decay_half_life_s_ < 1.0 || lidar_evidence_decay_half_life_s_ > 60.0) {
    RCLCPP_FATAL(
      get_logger(),
      "lidar_evidence_decay_half_life_s must be in range [1.0, 60.0]");
    throw std::runtime_error("invalid lidar evidence decay half life");
  }

  if (lidar_positive_evidence_max_ < 2.0 || lidar_positive_evidence_max_ > 50.0) {
    RCLCPP_FATAL(get_logger(), "lidar_positive_evidence_max must be in range [2.0, 50.0]");
    throw std::runtime_error("invalid lidar positive evidence max");
  }

  if (lidar_negative_evidence_max_ < 2.0 || lidar_negative_evidence_max_ > 50.0) {
    RCLCPP_FATAL(get_logger(), "lidar_negative_evidence_max must be in range [2.0, 50.0]");
    throw std::runtime_error("invalid lidar negative evidence max");
  }

  if (lidar_conflict_weight_ < 1.0 || lidar_conflict_weight_ > 6.0) {
    RCLCPP_FATAL(get_logger(), "lidar_conflict_weight must be in range [1.0, 6.0]");
    throw std::runtime_error("invalid lidar conflict weight");
  }

  if (lidar_skip_after_teleport_s_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "lidar_skip_after_teleport_s must be non-negative");
    throw std::runtime_error("invalid lidar_skip_after_teleport_s");
  }

  if (max_scan_odom_time_delta_s_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "max_scan_odom_time_delta_s must be non-negative");
    throw std::runtime_error("invalid max_scan_odom_time_delta_s");
  }

  if (odom_buffer_duration_s_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "odom_buffer_duration_s must be greater than zero");
    throw std::runtime_error("invalid odom_buffer_duration_s");
  }

  if (scan_odom_match_max_delta_s_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "scan_odom_match_max_delta_s must be non-negative");
    throw std::runtime_error("invalid scan_odom_match_max_delta_s");
  }

  if (scan_processing_delay_s_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "scan_processing_delay_s must be non-negative");
    throw std::runtime_error("invalid scan_processing_delay_s");
  }

  if (scan_pending_max_age_s_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "scan_pending_max_age_s must be greater than zero");
    throw std::runtime_error("invalid scan_pending_max_age_s");
  }

  if (odom_interpolation_max_gap_s_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "odom_interpolation_max_gap_s must be greater than zero");
    throw std::runtime_error("invalid odom_interpolation_max_gap_s");
  }

  if (teleport_distance_threshold_m_ < 0.0 || teleport_yaw_threshold_rad_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "Teleport thresholds must be non-negative");
    throw std::runtime_error("invalid teleport thresholds");
  }

  if (semantic_tile_alpha_ < 0.0 || semantic_tile_alpha_ > 1.0) {
    RCLCPP_FATAL(get_logger(), "semantic_tile_alpha must be in range [0.0, 1.0]");
    throw std::runtime_error("semantic_tile_alpha must be in range [0.0, 1.0]");
  }

  if (semantic_map_publish_period_s_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "semantic_map_publish_period_s must be greater than zero");
    throw std::runtime_error("invalid semantic_map_publish_period_s");
  }

  if (semantic_map_max_tiles_ < 0) {
    RCLCPP_FATAL(get_logger(), "semantic_map_max_tiles must be non-negative");
    throw std::runtime_error("invalid semantic_map_max_tiles");
  }

  if (status_publish_period_s_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "status_publish_period_s must be greater than zero");
    throw std::runtime_error("invalid status_publish_period_s");
  }

  if (map_validity_summary_log_period_s_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "map_validity_summary_log_period_s must be non-negative");
    throw std::runtime_error("invalid map_validity_summary_log_period_s");
  }

  if (odom_recent_timeout_s_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "odom_recent_timeout_s must be greater than zero");
    throw std::runtime_error("invalid odom_recent_timeout_s");
  }

  if (scan_recent_timeout_s_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "scan_recent_timeout_s must be greater than zero");
    throw std::runtime_error("invalid scan_recent_timeout_s");
  }

  if (slam_map_recent_timeout_s_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "slam_map_recent_timeout_s must be greater than zero");
    throw std::runtime_error("invalid slam_map_recent_timeout_s");
  }

  if (slam_geometry_config_.map_topic.empty()) {
    RCLCPP_FATAL(get_logger(), "slam_geometry.map_topic must not be empty");
    throw std::runtime_error("invalid slam_geometry.map_topic");
  }

  if (slam_geometry_config_.expected_resolution_m <= 0.0) {
    RCLCPP_FATAL(get_logger(), "slam_geometry.expected_resolution_m must be greater than zero");
    throw std::runtime_error("invalid slam_geometry.expected_resolution_m");
  }

  if (slam_geometry_config_.resolution_tolerance_m < 0.0) {
    RCLCPP_FATAL(get_logger(), "slam_geometry.resolution_tolerance_m must be non-negative");
    throw std::runtime_error("invalid slam_geometry.resolution_tolerance_m");
  }

  if (slam_geometry_config_.max_map_age_sec <= 0.0) {
    RCLCPP_FATAL(get_logger(), "slam_geometry.max_map_age_sec must be greater than zero");
    throw std::runtime_error("invalid slam_geometry.max_map_age_sec");
  }

  if (slam_geometry_config_.min_known_cells < 0 || slam_geometry_config_.min_occupied_cells < 0) {
    RCLCPP_FATAL(
      get_logger(),
      "slam_geometry min_known_cells and min_occupied_cells must be non-negative");
    throw std::runtime_error("invalid slam_geometry cell thresholds");
  }

  if (slam_geometry_config_.min_known_ratio < 0.0 || slam_geometry_config_.min_known_ratio > 1.0) {
    RCLCPP_FATAL(get_logger(), "slam_geometry.min_known_ratio must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid slam_geometry.min_known_ratio");
  }

  if (
    slam_geometry_config_.free_threshold < 0 ||
    slam_geometry_config_.free_threshold > 100 ||
    slam_geometry_config_.occupied_threshold < 0 ||
    slam_geometry_config_.occupied_threshold > 100 ||
    slam_geometry_config_.free_threshold >= slam_geometry_config_.occupied_threshold)
  {
    RCLCPP_FATAL(
      get_logger(),
      "slam_geometry free_threshold and occupied_threshold must be in range [0, 100] and ordered");
    throw std::runtime_error("invalid slam_geometry occupancy thresholds");
  }

  if (slam_geometry_config_.debug_log_period_sec <= 0.0) {
    RCLCPP_FATAL(get_logger(), "slam_geometry.debug_log_period_sec must be greater than zero");
    throw std::runtime_error("invalid slam_geometry.debug_log_period_sec");
  }

  const auto validate_ratio =
    [this](double value, const char * name) {
      if (value < 0.0 || value > 1.0) {
        RCLCPP_FATAL(get_logger(), "%s must be in range [0.0, 1.0]", name);
        throw std::runtime_error("invalid slam_geometry ratio");
      }
    };

  validate_ratio(
    slam_geometry_config_.confirmed_wall_occupied_ratio,
    "slam_geometry.confirmed_wall_occupied_ratio");
  validate_ratio(
    slam_geometry_config_.likely_wall_occupied_ratio,
    "slam_geometry.likely_wall_occupied_ratio");
  validate_ratio(
    slam_geometry_config_.likely_open_free_ratio,
    "slam_geometry.likely_open_free_ratio");
  validate_ratio(
    slam_geometry_config_.confirmed_open_free_ratio,
    "slam_geometry.confirmed_open_free_ratio");
  validate_ratio(
    slam_geometry_config_.max_open_occupied_ratio,
    "slam_geometry.max_open_occupied_ratio");
  validate_ratio(
    slam_geometry_config_.max_confirmed_open_unknown_ratio,
    "slam_geometry.max_confirmed_open_unknown_ratio");
  validate_ratio(
    slam_geometry_config_.phantom_support_free_ratio,
    "slam_geometry.phantom_support_free_ratio");
  validate_ratio(
    slam_geometry_config_.phantom_conflict_occupied_ratio,
    "slam_geometry.phantom_conflict_occupied_ratio");
  validate_ratio(
    slam_geometry_config_.phantom_confirmed_conflict_occupied_ratio,
    "slam_geometry.phantom_confirmed_conflict_occupied_ratio");
  validate_ratio(
    slam_geometry_config_.phantom_max_supported_occupied_ratio,
    "slam_geometry.phantom_max_supported_occupied_ratio");

  if (
    slam_geometry_config_.likely_wall_occupied_ratio >
    slam_geometry_config_.confirmed_wall_occupied_ratio)
  {
    RCLCPP_FATAL(
      get_logger(),
      "slam_geometry likely wall threshold must not exceed confirmed wall threshold");
    throw std::runtime_error("invalid slam_geometry wall thresholds");
  }

  if (
    slam_geometry_config_.likely_open_free_ratio >
    slam_geometry_config_.confirmed_open_free_ratio)
  {
    RCLCPP_FATAL(
      get_logger(),
      "slam_geometry likely open threshold must not exceed confirmed open threshold");
    throw std::runtime_error("invalid slam_geometry open thresholds");
  }

  if (
    slam_geometry_config_.phantom_conflict_occupied_ratio >
    slam_geometry_config_.phantom_confirmed_conflict_occupied_ratio)
  {
    RCLCPP_FATAL(
      get_logger(),
      "slam_geometry phantom conflict threshold must not exceed confirmed conflict threshold");
    throw std::runtime_error("invalid slam_geometry phantom conflict thresholds");
  }

  if (slam_geometry_config_.min_region_samples <= 0) {
    RCLCPP_FATAL(get_logger(), "slam_geometry.min_region_samples must be greater than zero");
    throw std::runtime_error("invalid slam_geometry.min_region_samples");
  }

  if (slam_geometry_config_.phantom_min_region_samples <= 0) {
    RCLCPP_FATAL(
      get_logger(),
      "slam_geometry.phantom_min_region_samples must be greater than zero");
    throw std::runtime_error("invalid slam_geometry.phantom_min_region_samples");
  }

  if (
    slam_geometry_config_.tile_interior_ratio <= 0.0 ||
    slam_geometry_config_.tile_interior_ratio > 1.0 ||
    slam_geometry_config_.edge_strip_length_ratio <= 0.0 ||
    slam_geometry_config_.edge_strip_length_ratio > 1.0)
  {
    RCLCPP_FATAL(
      get_logger(),
      "slam_geometry tile_interior_ratio and edge_strip_length_ratio must be in range (0.0, 1.0]");
    throw std::runtime_error("invalid slam_geometry region ratios");
  }

  if (
    slam_geometry_config_.phantom_tile_sample_scale <= 0.0 ||
    slam_geometry_config_.phantom_tile_sample_scale > 1.0)
  {
    RCLCPP_FATAL(
      get_logger(),
      "slam_geometry.phantom_tile_sample_scale must be in range (0.0, 1.0]");
    throw std::runtime_error("invalid slam_geometry phantom tile sample scale");
  }

  if (
    slam_geometry_config_.edge_strip_min_width_m <= 0.0 ||
    slam_geometry_config_.corridor_width_m <= 0.0)
  {
    RCLCPP_FATAL(
      get_logger(),
      "slam_geometry edge_strip_min_width_m and corridor_width_m must be greater than zero");
    throw std::runtime_error("invalid slam_geometry region widths");
  }

  if (slam_geometry_config_.phantom_corridor_width_m <= 0.0) {
    RCLCPP_FATAL(
      get_logger(),
      "slam_geometry.phantom_corridor_width_m must be greater than zero");
    throw std::runtime_error("invalid slam_geometry.phantom_corridor_width_m");
  }

  if (
    edge_evidence_wall_update_gain_ < 0.0 ||
    edge_evidence_open_update_gain_ < 0.0 ||
    edge_evidence_conflict_decay_ < 0.0)
  {
    RCLCPP_FATAL(get_logger(), "edge_evidence gains must be non-negative");
    throw std::runtime_error("invalid edge_evidence gains");
  }

  if (edge_evidence_unknown_ema_alpha_ < 0.0 || edge_evidence_unknown_ema_alpha_ > 1.0) {
    RCLCPP_FATAL(get_logger(), "edge_evidence.unknown_ema_alpha must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid edge_evidence unknown ema alpha");
  }

  if (edge_evidence_min_log_odds_ >= edge_evidence_max_log_odds_) {
    RCLCPP_FATAL(get_logger(), "edge_evidence min_log_odds must be less than max_log_odds");
    throw std::runtime_error("invalid edge_evidence log odds limits");
  }

  if (
    edge_evidence_likely_wall_log_odds_ > edge_evidence_confirmed_wall_log_odds_ ||
    edge_evidence_likely_open_log_odds_ > edge_evidence_confirmed_open_log_odds_)
  {
    RCLCPP_FATAL(get_logger(), "edge_evidence likely thresholds must not exceed confirmed thresholds");
    throw std::runtime_error("invalid edge_evidence thresholds");
  }

  if (edge_evidence_conflict_log_odds_delta_ < 0.0 || edge_evidence_stale_after_sec_ <= 0.0) {
    RCLCPP_FATAL(
      get_logger(),
      "edge_evidence conflict_log_odds_delta must be non-negative and stale_after_sec positive");
    throw std::runtime_error("invalid edge_evidence stale/conflict thresholds");
  }

  if (
    slam_geometry_config_.clearance_occupied_threshold < 0 ||
    slam_geometry_config_.clearance_occupied_threshold > 100)
  {
    RCLCPP_FATAL(get_logger(), "clearance.occupied_threshold must be in range [0, 100]");
    throw std::runtime_error("invalid clearance occupied threshold");
  }

  if (
    slam_geometry_config_.clearance_robot_radius_m < 0.0 ||
    slam_geometry_config_.clearance_safety_margin_m < 0.0 ||
    slam_geometry_config_.clearance_min_passage_clearance_m <= 0.0 ||
    slam_geometry_config_.clearance_stale_after_sec <= 0.0)
  {
    RCLCPP_FATAL(
      get_logger(),
      "clearance robot_radius/safety_margin must be non-negative and min_passage/stale positive");
    throw std::runtime_error("invalid clearance parameters");
  }

  if (floor_color_min_confidence_ < 0.0 || floor_color_min_confidence_ > 1.0) {
    RCLCPP_FATAL(get_logger(), "floor_color_min_confidence must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid floor_color_min_confidence");
  }

  if (floor_color_update_margin_m_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "floor_color_update_margin_m must be non-negative");
    throw std::runtime_error("invalid floor_color_update_margin_m");
  }

  if (
    transition_reassociation_boundary_margin_m_ < 0.0 ||
    transition_reassociation_boundary_margin_m_ > tile_size_ * 0.5)
  {
    RCLCPP_FATAL(
      get_logger(),
      "transition_reassociation_boundary_margin_m must be in range [0, tile_size / 2]");
    throw std::runtime_error("invalid transition reassociation boundary margin");
  }

  if (transition_same_color_cooldown_s_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "transition_same_color_cooldown_s must be non-negative");
    throw std::runtime_error("invalid transition same color cooldown");
  }

  if (
    transition_center_max_distance_m_ <= 0.0 ||
    transition_center_max_distance_m_ > std::sqrt(2.0) * tile_size_ * 0.5)
  {
    RCLCPP_FATAL(
      get_logger(),
      "transition_center_max_distance_m must be in range (0, half tile diagonal]");
    throw std::runtime_error("invalid transition center max distance");
  }

  if (
    checkpoint_center_max_distance_m_ <= 0.0 ||
    checkpoint_center_max_distance_m_ > std::sqrt(2.0) * tile_size_ * 0.5)
  {
    RCLCPP_FATAL(
      get_logger(),
      "checkpoint_center_max_distance_m must be in range (0, half tile diagonal]");
    throw std::runtime_error("invalid checkpoint center max distance");
  }

  if (
    black_hole_projection_boundary_margin_m_ < 0.0 ||
    black_hole_projection_boundary_margin_m_ > tile_size_ * 0.5)
  {
    RCLCPP_FATAL(
      get_logger(),
      "black_hole_projection_boundary_margin_m must be in range [0, tile_size / 2]");
    throw std::runtime_error("invalid black hole projection boundary margin");
  }

  if (legacy_hole_projection_distance_m_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "legacy_hole_projection_distance_m must be positive");
    throw std::runtime_error("invalid legacy hole projection distance");
  }

  if (semantic_observation_max_abs_world_m_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "semantic_observation_max_abs_world_m must be positive");
    throw std::runtime_error("invalid semantic observation max world value");
  }

  if (semantic_observation_max_tile_distance_ < 0) {
    RCLCPP_FATAL(get_logger(), "semantic_observation_max_tile_distance must be non-negative");
    throw std::runtime_error("invalid semantic observation max tile distance");
  }

  if (hole_duplicate_association_radius_tiles_ < 0) {
    RCLCPP_FATAL(get_logger(), "hole_duplicate_association_radius_tiles must be non-negative");
    throw std::runtime_error("invalid hole duplicate association radius");
  }

  if (hole_duplicate_association_max_center_distance_m_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "hole_duplicate_association_max_center_distance_m must be positive");
    throw std::runtime_error("invalid hole duplicate association distance");
  }

  if (hole_confirmation_required_hits_ < 1) {
    RCLCPP_FATAL(get_logger(), "hole_confirmation_required_hits must be at least 1");
    throw std::runtime_error("invalid hole confirmation required hits");
  }

  if (hole_confirmation_window_s_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "hole_confirmation_window_s must be non-negative");
    throw std::runtime_error("invalid hole confirmation window");
  }

  if (hole_confirm_immediate_confidence_ < 0.0 || hole_confirm_immediate_confidence_ > 1.0) {
    RCLCPP_FATAL(get_logger(), "hole_confirm_immediate_confidence must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid hole immediate confidence");
  }

  if (hole_candidate_min_confidence_ < 0.0 || hole_candidate_min_confidence_ > 1.0) {
    RCLCPP_FATAL(get_logger(), "hole_candidate_min_confidence must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid hole candidate min confidence");
  }

  if (controller_hole_weak_distance_travel_m_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "controller_hole_weak_distance_travel_m must be non-negative");
    throw std::runtime_error("invalid controller hole weak distance travel");
  }

  if (
    controller_hole_normal_clear_center_distance_m_ <= 0.0 ||
    controller_hole_normal_clear_center_distance_m_ > std::sqrt(2.0) * tile_size_ * 0.5)
  {
    RCLCPP_FATAL(
      get_logger(),
      "controller_hole_normal_clear_center_distance_m must be in range (0, half tile diagonal]");
    throw std::runtime_error("invalid controller hole normal clear center distance");
  }

  if (controller_hole_normal_clear_hits_ < 1) {
    RCLCPP_FATAL(get_logger(), "controller_hole_normal_clear_hits must be at least 1");
    throw std::runtime_error("invalid controller hole normal clear hits");
  }

  if (area_hint_max_lidar_distance_m_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "area_hint_max_lidar_distance_m must be non-negative");
    throw std::runtime_error("invalid area_hint_max_lidar_distance_m");
  }

  if (
    subtile_wall_center_mask_ratio_ < 0.30 ||
    subtile_wall_center_mask_ratio_ > 1.0 ||
    subtile_curve_center_mask_ratio_ < 0.30 ||
    subtile_curve_center_mask_ratio_ > 1.0 ||
    floor_color_center_mask_ratio_ < 0.30 ||
    floor_color_center_mask_ratio_ > 1.0)
  {
    RCLCPP_FATAL(get_logger(), "center mask ratios must be in range [0.30, 1.00]");
    throw std::runtime_error("invalid center mask ratios");
  }

  if (phantom_visual_mode_ != "summary" && phantom_visual_mode_ != "raw") {
    RCLCPP_FATAL(
      get_logger(),
      "Invalid phantom_visual_mode '%s'. Expected 'summary' or 'raw'.",
      phantom_visual_mode_.c_str());
    throw std::runtime_error("invalid phantom_visual_mode");
  }

  if (phantom_update_max_tile_radius_ < 0) {
    RCLCPP_FATAL(get_logger(), "phantom_update_max_tile_radius must be non-negative");
    throw std::runtime_error("invalid phantom_update_max_tile_radius");
  }

  if (phantom_mask_max_tile_radius_ < 0) {
    RCLCPP_FATAL(get_logger(), "phantom_mask_max_tile_radius must be non-negative");
    throw std::runtime_error("invalid phantom_mask_max_tile_radius");
  }

  if (phantom_mask_max_tile_radius_ > phantom_update_max_tile_radius_) {
    RCLCPP_WARN(
      get_logger(),
      "phantom_mask_max_tile_radius (%d) is greater than phantom_update_max_tile_radius (%d)",
      phantom_mask_max_tile_radius_,
      phantom_update_max_tile_radius_);
  }

  if (phantom_tile_marker_height_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "phantom_tile_marker_height must be greater than zero");
    throw std::runtime_error("invalid phantom_tile_marker_height");
  }

  if (phantom_tile_marker_alpha_ < 0.0 || phantom_tile_marker_alpha_ > 1.0) {
    RCLCPP_FATAL(get_logger(), "phantom_tile_marker_alpha must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid phantom_tile_marker_alpha");
  }

  if (phantom_quadrant_marker_height_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "phantom_quadrant_marker_height must be greater than zero");
    throw std::runtime_error("invalid phantom_quadrant_marker_height");
  }

  if (
    phantom_quadrant_marker_alpha_min_ < 0.0 ||
    phantom_quadrant_marker_alpha_min_ > 1.0 ||
    phantom_quadrant_marker_alpha_max_ < 0.0 ||
    phantom_quadrant_marker_alpha_max_ > 1.0 ||
    phantom_quadrant_marker_alpha_max_ < phantom_quadrant_marker_alpha_min_)
  {
    RCLCPP_FATAL(
      get_logger(),
      "phantom quadrant alpha range must be within [0.0, 1.0] and max >= min");
    throw std::runtime_error("invalid phantom quadrant alpha range");
  }

  if (quarter_edge_hit_tolerance_m_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "quarter_edge_hit_tolerance_m must be greater than zero");
    throw std::runtime_error("invalid quarter_edge_hit_tolerance_m");
  }

  if (quarter_edge_free_conflict_tolerance_m_ <= 0.0) {
    RCLCPP_FATAL(
      get_logger(),
      "quarter_edge_free_conflict_tolerance_m must be greater than zero");
    throw std::runtime_error("invalid quarter_edge_free_conflict_tolerance_m");
  }

  if (quarter_edge_min_visibility_rays_ <= 0) {
    RCLCPP_FATAL(get_logger(), "quarter_edge_min_visibility_rays must be greater than zero");
    throw std::runtime_error("invalid quarter_edge_min_visibility_rays");
  }

  if (quarter_edge_hit_weight_ < 0.0 || quarter_edge_conflict_weight_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "quarter edge weights must be non-negative");
    throw std::runtime_error("invalid quarter edge weights");
  }

  if (quarter_edge_marker_thickness_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "quarter_edge_marker_thickness must be greater than zero");
    throw std::runtime_error("invalid quarter_edge_marker_thickness");
  }

  if (
    quarter_edge_marker_alpha_min_ < 0.0 ||
    quarter_edge_marker_alpha_min_ > 1.0 ||
    quarter_edge_marker_alpha_max_ < 0.0 ||
    quarter_edge_marker_alpha_max_ > 1.0 ||
    quarter_edge_marker_alpha_max_ < quarter_edge_marker_alpha_min_)
  {
    RCLCPP_FATAL(
      get_logger(),
      "quarter edge marker alpha range must be within [0.0, 1.0] and max >= min");
    throw std::runtime_error("invalid quarter edge marker alpha range");
  }

  if (mask_supported_segment_min_score_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "mask_supported_segment_min_score must be non-negative");
    throw std::runtime_error("invalid mask_supported_segment_min_score");
  }

  if (mask_conflict_segment_max_score_ > 0.0) {
    RCLCPP_FATAL(get_logger(), "mask_conflict_segment_max_score must be zero or negative");
    throw std::runtime_error("invalid mask_conflict_segment_max_score");
  }

  if (mask_complexity_penalty_ < 0.0 || mask_unsupported_segment_penalty_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "mask penalties must be non-negative");
    throw std::runtime_error("invalid mask penalties");
  }

  if (mask_min_confidence_ < 0.0 || mask_min_confidence_ > 1.0) {
    RCLCPP_FATAL(get_logger(), "mask_min_confidence must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid mask_min_confidence");
  }

  if (phantom_mask_marker_thickness_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "phantom_mask_marker_thickness must be greater than zero");
    throw std::runtime_error("invalid phantom_mask_marker_thickness");
  }

  if (
    phantom_mask_marker_alpha_min_ < 0.0 ||
    phantom_mask_marker_alpha_min_ > 1.0 ||
    phantom_mask_marker_alpha_max_ < 0.0 ||
    phantom_mask_marker_alpha_max_ > 1.0 ||
    phantom_mask_marker_alpha_max_ < phantom_mask_marker_alpha_min_)
  {
    RCLCPP_FATAL(
      get_logger(),
      "phantom mask marker alpha range must be within [0.0, 1.0] and max >= min");
    throw std::runtime_error("invalid phantom mask marker alpha range");
  }

  if (phantom_summary_min_confidence_ < 0.0 || phantom_summary_min_confidence_ > 1.0) {
    RCLCPP_FATAL(get_logger(), "phantom_summary_min_confidence must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid phantom_summary_min_confidence");
  }

  if (
    phantom_summary_marker_alpha_min_ < 0.0 ||
    phantom_summary_marker_alpha_min_ > 1.0 ||
    phantom_summary_marker_alpha_max_ < 0.0 ||
    phantom_summary_marker_alpha_max_ > 1.0 ||
    phantom_summary_marker_alpha_max_ < phantom_summary_marker_alpha_min_)
  {
    RCLCPP_FATAL(
      get_logger(),
      "phantom summary marker alpha range must be within [0.0, 1.0] and max >= min");
    throw std::runtime_error("invalid phantom summary marker alpha range");
  }

  if (phantom_free_summary_alpha_max_ < 0.0 || phantom_free_summary_alpha_max_ > 1.0) {
    RCLCPP_FATAL(get_logger(), "phantom_free_summary_alpha_max must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid phantom_free_summary_alpha_max");
  }

  if (
    primitive_wall_thickness_m_ <= 0.0 ||
    primitive_wall_margin_m_ <= 0.0 ||
    primitive_base_tolerance_m_ <= 0.0)
  {
    RCLCPP_FATAL(
      get_logger(),
      "primitive wall thickness, margin, and base tolerance must be greater than zero");
    throw std::runtime_error("invalid primitive geometry parameters");
  }

  if (primitive_yaw_sigma_rad_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "primitive_yaw_sigma_rad must be non-negative");
    throw std::runtime_error("invalid primitive_yaw_sigma_rad");
  }

  if (primitive_hit_tolerance_max_m_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "primitive_hit_tolerance_max_m must be greater than zero");
    throw std::runtime_error("invalid primitive_hit_tolerance_max_m");
  }

  if (primitive_positive_min_incidence_ < 0.0 || primitive_positive_min_incidence_ > 1.0) {
    RCLCPP_FATAL(
      get_logger(),
      "primitive_positive_min_incidence must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid primitive_positive_min_incidence");
  }

  if (primitive_positive_min_hit_score_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "primitive_positive_min_hit_score must be non-negative");
    throw std::runtime_error("invalid primitive_positive_min_hit_score");
  }

  if (primitive_endpoint_exclusion_ratio_ < 0.0 || primitive_endpoint_exclusion_ratio_ > 0.49) {
    RCLCPP_FATAL(
      get_logger(),
      "primitive_endpoint_exclusion_ratio must be in range [0.0, 0.49]");
    throw std::runtime_error("invalid primitive_endpoint_exclusion_ratio");
  }

  if (primitive_positive_log_odds_update_ < 0.0 || primitive_negative_log_odds_update_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "primitive log-odds updates must be non-negative");
    throw std::runtime_error("invalid primitive log-odds updates");
  }

  if (primitive_log_odds_min_ >= primitive_log_odds_max_) {
    RCLCPP_FATAL(get_logger(), "primitive_log_odds_min must be less than primitive_log_odds_max");
    throw std::runtime_error("invalid primitive log-odds bounds");
  }

  if (primitive_min_visibility_rays_ <= 0) {
    RCLCPP_FATAL(get_logger(), "primitive_min_visibility_rays must be greater than zero");
    throw std::runtime_error("invalid primitive_min_visibility_rays");
  }

  if (primitive_debug_min_confidence_ < 0.0 || primitive_debug_min_confidence_ > 1.0) {
    RCLCPP_FATAL(get_logger(), "primitive_debug_min_confidence must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid primitive_debug_min_confidence");
  }

  if (
    primitive_debug_marker_alpha_min_ < 0.0 ||
    primitive_debug_marker_alpha_min_ > 1.0 ||
    primitive_debug_marker_alpha_max_ < 0.0 ||
    primitive_debug_marker_alpha_max_ > 1.0 ||
    primitive_debug_marker_alpha_max_ < primitive_debug_marker_alpha_min_)
  {
    RCLCPP_FATAL(
      get_logger(),
      "primitive debug marker alpha range must be within [0.0, 1.0] and max >= min");
    throw std::runtime_error("invalid primitive debug marker alpha range");
  }

  if (primitive_debug_marker_thickness_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "primitive_debug_marker_thickness must be greater than zero");
    throw std::runtime_error("invalid primitive_debug_marker_thickness");
  }

  if (
    primitive_debug_color_r_ < 0.0 ||
    primitive_debug_color_r_ > 1.0 ||
    primitive_debug_color_g_ < 0.0 ||
    primitive_debug_color_g_ > 1.0 ||
    primitive_debug_color_b_ < 0.0 ||
    primitive_debug_color_b_ > 1.0)
  {
    RCLCPP_FATAL(get_logger(), "primitive debug color channels must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid primitive debug color");
  }

  if (
    primitive_negative_debug_min_confidence_ < 0.0 ||
    primitive_negative_debug_min_confidence_ > 1.0)
  {
    RCLCPP_FATAL(
      get_logger(),
      "primitive_negative_debug_min_confidence must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid primitive_negative_debug_min_confidence");
  }

  if (
    primitive_negative_debug_color_r_ < 0.0 ||
    primitive_negative_debug_color_r_ > 1.0 ||
    primitive_negative_debug_color_g_ < 0.0 ||
    primitive_negative_debug_color_g_ > 1.0 ||
    primitive_negative_debug_color_b_ < 0.0 ||
    primitive_negative_debug_color_b_ > 1.0)
  {
    RCLCPP_FATAL(
      get_logger(),
      "primitive negative debug color channels must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid primitive negative debug color");
  }

  if (
    primitive_negative_debug_marker_alpha_min_ < 0.0 ||
    primitive_negative_debug_marker_alpha_min_ > 1.0 ||
    primitive_negative_debug_marker_alpha_max_ < 0.0 ||
    primitive_negative_debug_marker_alpha_max_ > 1.0 ||
    primitive_negative_debug_marker_alpha_max_ < primitive_negative_debug_marker_alpha_min_)
  {
    RCLCPP_FATAL(
      get_logger(),
      "primitive negative debug marker alpha range must be within [0.0, 1.0] and max >= min");
    throw std::runtime_error("invalid primitive negative debug marker alpha range");
  }

  if (enable_obstacle_primitives_) {
    if (!obstacleGridBinsValid(obstacle_grid_bins_per_tile_)) {
      RCLCPP_FATAL(
        get_logger(),
        "obstacle_grid_bins_per_tile must be in range [8, %d]",
        kObstacleGridMaxBinsPerTile);
      throw std::runtime_error("invalid obstacle grid bins");
    }

    if (
      obstacle_bin_hit_weight_ < 0.1 || obstacle_bin_hit_weight_ > 5.0 ||
      obstacle_bin_free_weight_ < 0.1 || obstacle_bin_free_weight_ > 8.0)
    {
      RCLCPP_FATAL(
        get_logger(),
        "obstacle bin weights must be in configured ranges");
      throw std::runtime_error("invalid obstacle bin weights");
    }

    if (
      obstacle_bin_occupied_threshold_ < 0.5 ||
      obstacle_bin_occupied_threshold_ > 20.0 ||
      obstacle_bin_free_margin_ < 0.0 ||
      obstacle_bin_free_margin_ > 10.0)
    {
      RCLCPP_FATAL(
        get_logger(),
        "obstacle bin thresholds must be in configured ranges");
      throw std::runtime_error("invalid obstacle bin thresholds");
    }

    const int obstacle_cell_count = obstacle_grid_bins_per_tile_ * obstacle_grid_bins_per_tile_;
    if (
      obstacle_min_cluster_bins_ <= 0 ||
      obstacle_min_cluster_bins_ > obstacle_cell_count ||
      obstacle_min_cluster_bins_ > 200 ||
      obstacle_min_total_hits_ <= 0 ||
      obstacle_min_total_hits_ > 500)
    {
      RCLCPP_FATAL(
        get_logger(),
        "obstacle cluster bins and total hits must be positive and fit in the grid");
      throw std::runtime_error("invalid obstacle cluster thresholds");
    }

    if (obstacle_min_confidence_ < 0.0 || obstacle_min_confidence_ > 1.0) {
      RCLCPP_FATAL(get_logger(), "obstacle_min_confidence must be in range [0.0, 1.0]");
      throw std::runtime_error("invalid obstacle_min_confidence");
    }

    if (obstacle_debug_min_confidence_ < 0.0 || obstacle_debug_min_confidence_ > 1.0) {
      RCLCPP_FATAL(get_logger(), "obstacle_debug_min_confidence must be in range [0.0, 1.0]");
      throw std::runtime_error("invalid obstacle_debug_min_confidence");
    }

    if (obstacle_max_free_ratio_ < 0.0 || obstacle_max_free_ratio_ > 1.0) {
      RCLCPP_FATAL(get_logger(), "obstacle_max_free_ratio must be in range [0.0, 1.0]");
      throw std::runtime_error("invalid obstacle_max_free_ratio");
    }

    if (
      obstacle_min_distance_from_tile_edge_m_ < 0.0 ||
      obstacle_min_distance_from_tile_edge_m_ > 0.05)
    {
      RCLCPP_FATAL(
        get_logger(),
        "obstacle_min_distance_from_tile_edge_m must be in range [0.0, 0.05]");
      throw std::runtime_error("invalid obstacle edge distance");
    }

    if (
      obstacle_min_box_size_m_ < 0.005 ||
      obstacle_min_box_size_m_ > 0.12 ||
      obstacle_max_box_size_m_ < obstacle_min_box_size_m_ ||
      obstacle_max_box_size_m_ < 0.01 ||
      obstacle_max_box_size_m_ > 0.12)
    {
      RCLCPP_FATAL(
        get_logger(),
        "obstacle box sizes must be positive, ordered, and no larger than tile_size");
      throw std::runtime_error("invalid obstacle box size");
    }

    if (obstacle_box_padding_m_ < 0.0 || obstacle_box_padding_m_ > 0.02) {
      RCLCPP_FATAL(
        get_logger(),
        "obstacle_box_padding_m must be in range [0.0, 0.02]");
      throw std::runtime_error("invalid obstacle box padding");
    }

    if (obstacle_surrounding_ring_bins_ < 1 || obstacle_surrounding_ring_bins_ > 6) {
      RCLCPP_FATAL(get_logger(), "obstacle_surrounding_ring_bins must be in range [1, 6]");
      throw std::runtime_error("invalid obstacle surrounding ring bins");
    }

    if (
      obstacle_min_surrounding_free_ratio_ < 0.0 ||
      obstacle_min_surrounding_free_ratio_ > 1.0)
    {
      RCLCPP_FATAL(
        get_logger(),
        "obstacle_min_surrounding_free_ratio must be in range [0.0, 1.0]");
      throw std::runtime_error("invalid obstacle surrounding free ratio");
    }

    if (obstacle_wall_overlap_penalty_ < 0.0 || obstacle_wall_overlap_penalty_ > 6.0) {
      RCLCPP_FATAL(get_logger(), "obstacle_wall_overlap_penalty must be in range [0.0, 6.0]");
      throw std::runtime_error("invalid obstacle wall overlap penalty");
    }

    if (obstacle_edge_proximity_penalty_ < 0.0 || obstacle_edge_proximity_penalty_ > 6.0) {
      RCLCPP_FATAL(get_logger(), "obstacle_edge_proximity_penalty must be in range [0.0, 6.0]");
      throw std::runtime_error("invalid obstacle edge proximity penalty");
    }

    if (
      obstacle_temporal_decay_half_life_s_ < 1.0 ||
      obstacle_temporal_decay_half_life_s_ > 60.0)
    {
      RCLCPP_FATAL(
        get_logger(),
        "obstacle_temporal_decay_half_life_s must be in range [1.0, 60.0]");
      throw std::runtime_error("invalid obstacle temporal decay half life");
    }
  }

  if (curve_proto_inner_radius_ <= 0.0 || curve_proto_outer_radius_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "curve proto radii must be greater than zero");
    throw std::runtime_error("invalid curve proto radii");
  }

  if (curve_proto_outer_radius_ <= curve_proto_inner_radius_) {
    RCLCPP_FATAL(get_logger(), "curve_proto_outer_radius must be greater than inner radius");
    throw std::runtime_error("invalid curve proto radius order");
  }

  if (curve_proto_tile_size_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "curve_proto_tile_size must be greater than zero");
    throw std::runtime_error("invalid curve_proto_tile_size");
  }

  if (
    curve_wall_margin_m_ <= 0.0 ||
    curve_base_tolerance_m_ <= 0.0 ||
    curve_hit_tolerance_max_m_ <= 0.0)
  {
    RCLCPP_FATAL(
      get_logger(),
      "curve wall margin and hit tolerances must be greater than zero");
    throw std::runtime_error("invalid curve tolerance parameters");
  }

  if (curve_yaw_sigma_rad_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "curve_yaw_sigma_rad must be non-negative");
    throw std::runtime_error("invalid curve_yaw_sigma_rad");
  }

  if (curve_subtile_containment_tolerance_m_ < 0.0) {
    RCLCPP_FATAL(
      get_logger(),
      "curve_subtile_containment_tolerance_m must be non-negative");
    throw std::runtime_error("invalid curve_subtile_containment_tolerance_m");
  }

  if (curve_radial_center_tolerance_m_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "curve_radial_center_tolerance_m must be greater than zero");
    throw std::runtime_error("invalid curve_radial_center_tolerance_m");
  }

  if (curve_radial_center_power_ < 1.0) {
    RCLCPP_FATAL(get_logger(), "curve_radial_center_power must be at least one");
    throw std::runtime_error("invalid curve_radial_center_power");
  }

  if (curve_angular_center_power_ < 1.0) {
    RCLCPP_FATAL(get_logger(), "curve_angular_center_power must be at least one");
    throw std::runtime_error("invalid curve_angular_center_power");
  }

  if (curve_positive_weight_scale_ < 0.0 || curve_negative_weight_scale_ < 0.0) {
    RCLCPP_FATAL(get_logger(), "curve positive/negative weight scales must be non-negative");
    throw std::runtime_error("invalid curve weight scales");
  }

  if (
    curve_subtile_containment_required_fraction_ < 0.5 ||
    curve_subtile_containment_required_fraction_ > 1.0)
  {
    RCLCPP_FATAL(
      get_logger(),
      "curve_subtile_containment_required_fraction must be in range [0.5, 1.0]");
    throw std::runtime_error("invalid curve_subtile_containment_required_fraction");
  }

  if (curve_positive_min_incidence_ < 0.0 || curve_positive_min_incidence_ > 1.0) {
    RCLCPP_FATAL(
      get_logger(),
      "curve_positive_min_incidence must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid curve_positive_min_incidence");
  }

  if (curve_positive_min_hit_score_ < 0.0 || curve_positive_min_hit_score_ > 1.0) {
    RCLCPP_FATAL(
      get_logger(),
      "curve_positive_min_hit_score must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid curve_positive_min_hit_score");
  }

  if (curve_endpoint_exclusion_ratio_ < 0.0 || curve_endpoint_exclusion_ratio_ > 0.49) {
    RCLCPP_FATAL(
      get_logger(),
      "curve_endpoint_exclusion_ratio must be in range [0.0, 0.49]");
    throw std::runtime_error("invalid curve_endpoint_exclusion_ratio");
  }

  if (curve_min_visibility_rays_ <= 0) {
    RCLCPP_FATAL(get_logger(), "curve_min_visibility_rays must be greater than zero");
    throw std::runtime_error("invalid curve_min_visibility_rays");
  }

  if (curve_min_confidence_ < 0.0 || curve_min_confidence_ > 1.0) {
    RCLCPP_FATAL(get_logger(), "curve_min_confidence must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid curve_min_confidence");
  }

  if (curve_min_best_margin_ < 0.0 || curve_min_best_margin_ > 1.0) {
    RCLCPP_FATAL(get_logger(), "curve_min_best_margin must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid curve_min_best_margin");
  }

  if (curve_edge_ambiguity_ratio_ < 0.0 || curve_edge_ambiguity_ratio_ > 1.0) {
    RCLCPP_FATAL(get_logger(), "curve_edge_ambiguity_ratio must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid curve_edge_ambiguity_ratio");
  }

  if (curve_coverage_bins_ < 2) {
    RCLCPP_FATAL(get_logger(), "curve_coverage_bins must be at least two");
    throw std::runtime_error("invalid curve_coverage_bins");
  }

  if (curve_min_coverage_score_ < 0.0 || curve_min_coverage_score_ > 1.0) {
    RCLCPP_FATAL(get_logger(), "curve_min_coverage_score must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid curve_min_coverage_score");
  }

  if (curve_debug_min_confidence_ < 0.0 || curve_debug_min_confidence_ > 1.0) {
    RCLCPP_FATAL(get_logger(), "curve_debug_min_confidence must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid curve_debug_min_confidence");
  }

  if (curve_debug_log_period_s_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "curve_debug_log_period_s must be greater than zero");
    throw std::runtime_error("invalid curve_debug_log_period_s");
  }

  if (
    curve_debug_marker_alpha_min_ < 0.0 ||
    curve_debug_marker_alpha_min_ > 1.0 ||
    curve_debug_marker_alpha_max_ < 0.0 ||
    curve_debug_marker_alpha_max_ > 1.0 ||
    curve_debug_marker_alpha_max_ < curve_debug_marker_alpha_min_)
  {
    RCLCPP_FATAL(
      get_logger(),
      "curve debug marker alpha range must be within [0.0, 1.0] and max >= min");
    throw std::runtime_error("invalid curve debug marker alpha range");
  }

  if (
    curve_debug_color_r_ < 0.0 ||
    curve_debug_color_r_ > 1.0 ||
    curve_debug_color_g_ < 0.0 ||
    curve_debug_color_g_ > 1.0 ||
    curve_debug_color_b_ < 0.0 ||
    curve_debug_color_b_ > 1.0)
  {
    RCLCPP_FATAL(get_logger(), "curve debug color channels must be in range [0.0, 1.0]");
    throw std::runtime_error("invalid curve debug color");
  }
}

rcl_interfaces::msg::SetParametersResult MapperNode::onDynamicParameters(
  const std::vector<rclcpp::Parameter> & parameters)
{
  rcl_interfaces::msg::SetParametersResult result;
  result.successful = true;

  double next_lidar_evidence_decay_half_life_s = lidar_evidence_decay_half_life_s_;
  double next_lidar_positive_evidence_max = lidar_positive_evidence_max_;
  double next_lidar_negative_evidence_max = lidar_negative_evidence_max_;
  double next_lidar_conflict_weight = lidar_conflict_weight_;
  bool next_enable_obstacle_primitives = enable_obstacle_primitives_;
  int next_obstacle_grid_bins_per_tile = obstacle_grid_bins_per_tile_;
  double next_obstacle_bin_hit_weight = obstacle_bin_hit_weight_;
  double next_obstacle_bin_free_weight = obstacle_bin_free_weight_;
  double next_obstacle_bin_occupied_threshold = obstacle_bin_occupied_threshold_;
  double next_obstacle_bin_free_margin = obstacle_bin_free_margin_;
  int next_obstacle_min_cluster_bins = obstacle_min_cluster_bins_;
  int next_obstacle_min_total_hits = obstacle_min_total_hits_;
  double next_obstacle_min_confidence = obstacle_min_confidence_;
  double next_obstacle_debug_min_confidence = obstacle_debug_min_confidence_;
  double next_obstacle_max_free_ratio = obstacle_max_free_ratio_;
  double next_obstacle_min_distance_from_tile_edge_m = obstacle_min_distance_from_tile_edge_m_;
  double next_obstacle_min_box_size_m = obstacle_min_box_size_m_;
  double next_obstacle_max_box_size_m = obstacle_max_box_size_m_;
  double next_obstacle_box_padding_m = obstacle_box_padding_m_;
  int next_obstacle_surrounding_ring_bins = obstacle_surrounding_ring_bins_;
  double next_obstacle_min_surrounding_free_ratio = obstacle_min_surrounding_free_ratio_;
  double next_obstacle_wall_overlap_penalty = obstacle_wall_overlap_penalty_;
  double next_obstacle_edge_proximity_penalty = obstacle_edge_proximity_penalty_;
  double next_obstacle_temporal_decay_half_life_s = obstacle_temporal_decay_half_life_s_;
  bool next_publish_obstacle_grid_debug = publish_obstacle_grid_debug_;
  double next_curve_debug_min_confidence = curve_debug_min_confidence_;
  bool next_curve_debug_log_scores = curve_debug_log_scores_;
  double next_curve_debug_log_period_s = curve_debug_log_period_s_;
  bool next_auto_start = auto_start_;

  const auto reject =
    [&result](const std::string & reason) {
      result.successful = false;
      result.reason = reason;
    };

  const auto read_bool =
    [&reject](const rclcpp::Parameter & parameter, bool * value) {
      if (parameter.get_type() != rclcpp::ParameterType::PARAMETER_BOOL) {
        reject(parameter.get_name() + " must be a bool");
        return false;
      }
      *value = parameter.as_bool();
      return true;
    };

  const auto read_double =
    [&reject](const rclcpp::Parameter & parameter, double * value) {
      if (parameter.get_type() == rclcpp::ParameterType::PARAMETER_DOUBLE) {
        *value = parameter.as_double();
      } else if (parameter.get_type() == rclcpp::ParameterType::PARAMETER_INTEGER) {
        *value = static_cast<double>(parameter.as_int());
      } else {
        reject(parameter.get_name() + " must be a number");
        return false;
      }

      if (!std::isfinite(*value)) {
        reject(parameter.get_name() + " must be finite");
        return false;
      }
      return true;
    };

  const auto read_int =
    [&reject](const rclcpp::Parameter & parameter, int * value) {
      if (parameter.get_type() != rclcpp::ParameterType::PARAMETER_INTEGER) {
        reject(parameter.get_name() + " must be an integer");
        return false;
      }
      const auto int_value = parameter.as_int();
      if (int_value < std::numeric_limits<int>::min() ||
        int_value > std::numeric_limits<int>::max())
      {
        reject(parameter.get_name() + " is outside int range");
        return false;
      }
      *value = static_cast<int>(int_value);
      return true;
    };

  if (parameters.size() == 1 && parameters.front().get_name() == "auto_start") {
    if (!read_bool(parameters.front(), &next_auto_start)) {
      return result;
    }

    auto_start_ = next_auto_start;
    reevaluateRaceMappingActivation(get_clock()->now());
    return result;
  }

  for (const auto & parameter : parameters) {
    const auto & name = parameter.get_name();
    if (name == "auto_start") {
      if (!read_bool(parameter, &next_auto_start)) {
        return result;
      }
    } else if (name == "lidar_evidence_decay_half_life_s") {
      if (!read_double(parameter, &next_lidar_evidence_decay_half_life_s)) {
        return result;
      }
    } else if (name == "lidar_positive_evidence_max") {
      if (!read_double(parameter, &next_lidar_positive_evidence_max)) {
        return result;
      }
    } else if (name == "lidar_negative_evidence_max") {
      if (!read_double(parameter, &next_lidar_negative_evidence_max)) {
        return result;
      }
    } else if (name == "lidar_conflict_weight") {
      if (!read_double(parameter, &next_lidar_conflict_weight)) {
        return result;
      }
    } else if (name == "enable_obstacle_primitives") {
      if (!read_bool(parameter, &next_enable_obstacle_primitives)) {
        return result;
      }
    } else if (name == "obstacle_grid_bins_per_tile") {
      if (!read_int(parameter, &next_obstacle_grid_bins_per_tile)) {
        return result;
      }
    } else if (name == "obstacle_bin_hit_weight") {
      if (!read_double(parameter, &next_obstacle_bin_hit_weight)) {
        return result;
      }
    } else if (name == "obstacle_bin_free_weight") {
      if (!read_double(parameter, &next_obstacle_bin_free_weight)) {
        return result;
      }
    } else if (name == "obstacle_bin_occupied_threshold") {
      if (!read_double(parameter, &next_obstacle_bin_occupied_threshold)) {
        return result;
      }
    } else if (name == "obstacle_bin_free_margin") {
      if (!read_double(parameter, &next_obstacle_bin_free_margin)) {
        return result;
      }
    } else if (name == "obstacle_min_cluster_bins") {
      if (!read_int(parameter, &next_obstacle_min_cluster_bins)) {
        return result;
      }
    } else if (name == "obstacle_min_total_hits") {
      if (!read_int(parameter, &next_obstacle_min_total_hits)) {
        return result;
      }
    } else if (name == "obstacle_min_confidence") {
      if (!read_double(parameter, &next_obstacle_min_confidence)) {
        return result;
      }
    } else if (name == "obstacle_debug_min_confidence") {
      if (!read_double(parameter, &next_obstacle_debug_min_confidence)) {
        return result;
      }
    } else if (name == "obstacle_max_free_ratio") {
      if (!read_double(parameter, &next_obstacle_max_free_ratio)) {
        return result;
      }
    } else if (name == "obstacle_min_distance_from_tile_edge_m") {
      if (!read_double(parameter, &next_obstacle_min_distance_from_tile_edge_m)) {
        return result;
      }
    } else if (name == "obstacle_min_box_size_m") {
      if (!read_double(parameter, &next_obstacle_min_box_size_m)) {
        return result;
      }
    } else if (name == "obstacle_max_box_size_m") {
      if (!read_double(parameter, &next_obstacle_max_box_size_m)) {
        return result;
      }
    } else if (name == "obstacle_box_padding_m") {
      if (!read_double(parameter, &next_obstacle_box_padding_m)) {
        return result;
      }
    } else if (name == "obstacle_surrounding_ring_bins") {
      if (!read_int(parameter, &next_obstacle_surrounding_ring_bins)) {
        return result;
      }
    } else if (name == "obstacle_min_surrounding_free_ratio") {
      if (!read_double(parameter, &next_obstacle_min_surrounding_free_ratio)) {
        return result;
      }
    } else if (name == "obstacle_wall_overlap_penalty") {
      if (!read_double(parameter, &next_obstacle_wall_overlap_penalty)) {
        return result;
      }
    } else if (name == "obstacle_edge_proximity_penalty") {
      if (!read_double(parameter, &next_obstacle_edge_proximity_penalty)) {
        return result;
      }
    } else if (name == "obstacle_temporal_decay_half_life_s") {
      if (!read_double(parameter, &next_obstacle_temporal_decay_half_life_s)) {
        return result;
      }
    } else if (name == "publish_obstacle_grid_debug") {
      if (!read_bool(parameter, &next_publish_obstacle_grid_debug)) {
        return result;
      }
    } else if (name == "curve_debug_min_confidence") {
      if (!read_double(parameter, &next_curve_debug_min_confidence)) {
        return result;
      }
    } else if (name == "curve_debug_log_scores") {
      if (!read_bool(parameter, &next_curve_debug_log_scores)) {
        return result;
      }
    } else if (name == "curve_debug_log_period_s") {
      if (!read_double(parameter, &next_curve_debug_log_period_s)) {
        return result;
      }
    }
  }

  if (
    next_lidar_evidence_decay_half_life_s < 1.0 ||
    next_lidar_evidence_decay_half_life_s > 60.0)
  {
    reject("lidar_evidence_decay_half_life_s must be in range [1.0, 60.0]");
    return result;
  }
  if (next_lidar_positive_evidence_max < 2.0 || next_lidar_positive_evidence_max > 50.0) {
    reject("lidar_positive_evidence_max must be in range [2.0, 50.0]");
    return result;
  }
  if (next_lidar_negative_evidence_max < 2.0 || next_lidar_negative_evidence_max > 50.0) {
    reject("lidar_negative_evidence_max must be in range [2.0, 50.0]");
    return result;
  }
  if (next_lidar_conflict_weight < 1.0 || next_lidar_conflict_weight > 6.0) {
    reject("lidar_conflict_weight must be in range [1.0, 6.0]");
    return result;
  }
  if (next_obstacle_grid_bins_per_tile != obstacle_grid_bins_per_tile_) {
    reject("obstacle_grid_bins_per_tile is startup-only in this slice");
    return result;
  }
  if (!obstacleGridBinsValid(next_obstacle_grid_bins_per_tile)) {
    reject("obstacle_grid_bins_per_tile must be in range [8, 48]");
    return result;
  }
  if (
    next_obstacle_bin_hit_weight < 0.1 ||
    next_obstacle_bin_hit_weight > 5.0 ||
    next_obstacle_bin_free_weight < 0.1 ||
    next_obstacle_bin_free_weight > 8.0)
  {
    reject("obstacle bin weights must be in configured ranges");
    return result;
  }
  if (
    next_obstacle_bin_occupied_threshold < 0.5 ||
    next_obstacle_bin_occupied_threshold > 20.0 ||
    next_obstacle_bin_free_margin < 0.0 ||
    next_obstacle_bin_free_margin > 10.0)
  {
    reject("obstacle bin thresholds must be in configured ranges");
    return result;
  }
  const int next_obstacle_cell_count =
    next_obstacle_grid_bins_per_tile * next_obstacle_grid_bins_per_tile;
  if (
    next_obstacle_min_cluster_bins <= 0 ||
    next_obstacle_min_cluster_bins > next_obstacle_cell_count ||
    next_obstacle_min_cluster_bins > 200 ||
    next_obstacle_min_total_hits <= 0 ||
    next_obstacle_min_total_hits > 500)
  {
    reject("obstacle cluster bins and total hits must be positive and fit in the grid");
    return result;
  }
  if (next_obstacle_min_confidence < 0.0 || next_obstacle_min_confidence > 1.0) {
    reject("obstacle_min_confidence must be in range [0.0, 1.0]");
    return result;
  }
  if (
    next_obstacle_debug_min_confidence < 0.0 ||
    next_obstacle_debug_min_confidence > 1.0)
  {
    reject("obstacle_debug_min_confidence must be in range [0.0, 1.0]");
    return result;
  }
  if (next_obstacle_max_free_ratio < 0.0 || next_obstacle_max_free_ratio > 1.0) {
    reject("obstacle_max_free_ratio must be in range [0.0, 1.0]");
    return result;
  }
  if (
    next_obstacle_min_distance_from_tile_edge_m < 0.0 ||
    next_obstacle_min_distance_from_tile_edge_m > 0.05)
  {
    reject("obstacle edge distance must be in range [0.0, 0.05]");
    return result;
  }
  if (
    next_obstacle_min_box_size_m < 0.005 ||
    next_obstacle_min_box_size_m > 0.12 ||
    next_obstacle_max_box_size_m < next_obstacle_min_box_size_m ||
    next_obstacle_max_box_size_m < 0.01 ||
    next_obstacle_max_box_size_m > 0.12)
  {
    reject("obstacle box sizes must be positive, ordered, and no larger than tile_size");
    return result;
  }
  if (next_obstacle_box_padding_m < 0.0 || next_obstacle_box_padding_m > 0.02) {
    reject("obstacle_box_padding_m must be in range [0.0, 0.02]");
    return result;
  }
  if (next_obstacle_surrounding_ring_bins < 1 || next_obstacle_surrounding_ring_bins > 6) {
    reject("obstacle_surrounding_ring_bins must be in range [1, 6]");
    return result;
  }
  if (
    next_obstacle_min_surrounding_free_ratio < 0.0 ||
    next_obstacle_min_surrounding_free_ratio > 1.0)
  {
    reject("obstacle_min_surrounding_free_ratio must be in range [0.0, 1.0]");
    return result;
  }
  if (next_obstacle_wall_overlap_penalty < 0.0 || next_obstacle_wall_overlap_penalty > 6.0) {
    reject("obstacle_wall_overlap_penalty must be in range [0.0, 6.0]");
    return result;
  }
  if (next_obstacle_edge_proximity_penalty < 0.0 || next_obstacle_edge_proximity_penalty > 6.0) {
    reject("obstacle_edge_proximity_penalty must be in range [0.0, 6.0]");
    return result;
  }
  if (
    next_obstacle_temporal_decay_half_life_s < 1.0 ||
    next_obstacle_temporal_decay_half_life_s > 60.0)
  {
    reject("obstacle_temporal_decay_half_life_s must be in range [1.0, 60.0]");
    return result;
  }
  if (next_curve_debug_min_confidence < 0.0 || next_curve_debug_min_confidence > 1.0) {
    reject("curve_debug_min_confidence must be in range [0.0, 1.0]");
    return result;
  }
  if (next_curve_debug_log_period_s <= 0.0) {
    reject("curve_debug_log_period_s must be greater than zero");
    return result;
  }

  lidar_evidence_decay_half_life_s_ = next_lidar_evidence_decay_half_life_s;
  lidar_positive_evidence_max_ = next_lidar_positive_evidence_max;
  lidar_negative_evidence_max_ = next_lidar_negative_evidence_max;
  lidar_conflict_weight_ = next_lidar_conflict_weight;
  enable_obstacle_primitives_ = next_enable_obstacle_primitives;
  obstacle_grid_bins_per_tile_ = next_obstacle_grid_bins_per_tile;
  obstacle_bin_hit_weight_ = next_obstacle_bin_hit_weight;
  obstacle_bin_free_weight_ = next_obstacle_bin_free_weight;
  obstacle_bin_occupied_threshold_ = next_obstacle_bin_occupied_threshold;
  obstacle_bin_free_margin_ = next_obstacle_bin_free_margin;
  obstacle_min_cluster_bins_ = next_obstacle_min_cluster_bins;
  obstacle_min_total_hits_ = next_obstacle_min_total_hits;
  obstacle_min_confidence_ = next_obstacle_min_confidence;
  obstacle_debug_min_confidence_ = next_obstacle_debug_min_confidence;
  obstacle_max_free_ratio_ = next_obstacle_max_free_ratio;
  obstacle_min_distance_from_tile_edge_m_ = next_obstacle_min_distance_from_tile_edge_m;
  obstacle_min_box_size_m_ = next_obstacle_min_box_size_m;
  obstacle_max_box_size_m_ = next_obstacle_max_box_size_m;
  obstacle_box_padding_m_ = next_obstacle_box_padding_m;
  obstacle_surrounding_ring_bins_ = next_obstacle_surrounding_ring_bins;
  obstacle_min_surrounding_free_ratio_ = next_obstacle_min_surrounding_free_ratio;
  obstacle_wall_overlap_penalty_ = next_obstacle_wall_overlap_penalty;
  obstacle_edge_proximity_penalty_ = next_obstacle_edge_proximity_penalty;
  obstacle_temporal_decay_half_life_s_ = next_obstacle_temporal_decay_half_life_s;
  publish_obstacle_grid_debug_ = next_publish_obstacle_grid_debug;
  curve_debug_min_confidence_ = next_curve_debug_min_confidence;
  curve_debug_log_scores_ = next_curve_debug_log_scores;
  curve_debug_log_period_s_ = next_curve_debug_log_period_s;
  auto_start_ = next_auto_start;
  phantom_tile_map_.configureTemporalEvidence(
    lidar_evidence_decay_half_life_s_,
    obstacle_temporal_decay_half_life_s_,
    lidar_positive_evidence_max_,
    lidar_negative_evidence_max_);

  reevaluateRaceMappingActivation(get_clock()->now());
  return result;
}

void MapperNode::clearPreReadyRuntimeBuffers()
{
  latest_odom_.reset();
  latest_scan_.reset();
  odom_buffer_.clear();
  pending_scans_.clear();
  latest_lidar_debug_odom_.reset();
  latest_lidar_debug_scan_.reset();
  has_last_odom_received_stamp_ = false;
  has_last_scan_received_stamp_ = false;
  has_slam_map_received_ = false;
  has_valid_slam_map_ = false;
  slam_map_sampler_.reset();
  has_last_slam_geometry_log_stamp_ = false;
  race_waiting_for_fresh_scan_after_activation_ = false;
}

void MapperNode::reevaluateRaceMappingActivation(const rclcpp::Time & stamp)
{
  const bool was_mapping_active = mapping_active_;
  bool should_be_active = auto_start_;

  if (race_wait_for_bridge_ready_) {
    should_be_active = should_be_active && bridge_ready_;
    if (race_require_scan_after_ready_) {
      should_be_active = should_be_active && scan_seen_after_bridge_ready_;
    }
    if (race_require_odom_after_ready_) {
      should_be_active = should_be_active && odom_seen_after_bridge_ready_;
    }
  }

  if (mapping_active_ == should_be_active) {
    publishMapperStatus(stamp);
    return;
  }

  mapping_active_ = should_be_active;

  if (!was_mapping_active && mapping_active_) {
    origin_initialization_after_activation_pending_ = !origin_initialized_;
    if (race_wait_for_bridge_ready_) {
      const auto cleared_pending_scan_count = pending_scans_.size();
      pending_scans_.clear();
      latest_scan_.reset();
      latest_lidar_debug_scan_.reset();
      latest_lidar_debug_odom_.reset();
      has_last_integrated_scan_stamp_ = false;
      race_waiting_for_fresh_scan_after_activation_ = true;
      RCLCPP_INFO(
        get_logger(),
        "race handoff activation: cleared pre-activation pending scans=%zu; "
        "waiting for fresh scan integration",
        cleared_pending_scan_count);
      logRobotEvent(
        "mapping_activated",
        {
          {"connection_id", std::to_string(bridge_connection_id_)},
          {"reason", "race_handoff"},
          {"cleared_pending_scans", std::to_string(cleared_pending_scan_count)},
          {"bridge_ready", boolText(bridge_ready_)},
          {"scan_after_ready", boolText(scan_seen_after_bridge_ready_)},
          {"odom_after_ready", boolText(odom_seen_after_bridge_ready_)},
        });
    }
    RCLCPP_INFO(
      get_logger(),
      "ros2_mapper mapping activated: auto_start=%s bridge_ready=%s "
      "scan_after_ready=%s odom_after_ready=%s connection_id=%" PRIu64,
      auto_start_ ? "true" : "false",
      bridge_ready_ ? "true" : "false",
      scan_seen_after_bridge_ready_ ? "true" : "false",
      odom_seen_after_bridge_ready_ ? "true" : "false",
      bridge_connection_id_);
    logRobotEvent(
      "mapping_activated",
      {
        {"connection_id", std::to_string(bridge_connection_id_)},
        {"reason", "readiness_satisfied"},
        {"auto_start", boolText(auto_start_)},
        {"bridge_ready", boolText(bridge_ready_)},
        {"scan_after_ready", boolText(scan_seen_after_bridge_ready_)},
        {"odom_after_ready", boolText(odom_seen_after_bridge_ready_)},
        {"origin_initialized", boolText(origin_initialized_)},
      });

    if (origin_mode_ == "auto_first_pose" && !origin_initialized_ && latest_odom_) {
      initializeOriginFromPose(
        latest_odom_->pose.pose.position.x,
        latest_odom_->pose.pose.position.y);
      updateCurrentTile(*latest_odom_);
    }
  } else if (was_mapping_active && !mapping_active_) {
    origin_initialization_after_activation_pending_ = false;
    pending_scans_.clear();
    race_waiting_for_fresh_scan_after_activation_ = false;
    RCLCPP_WARN(
      get_logger(),
      "ros2_mapper mapping deactivated: auto_start=%s bridge_ready=%s "
      "scan_after_ready=%s odom_after_ready=%s; semantic state is kept",
      auto_start_ ? "true" : "false",
      bridge_ready_ ? "true" : "false",
      scan_seen_after_bridge_ready_ ? "true" : "false",
      odom_seen_after_bridge_ready_ ? "true" : "false");
    logRobotEvent(
      EventLevel::Warn,
      "mapping_deactivated",
      {
        {"connection_id", std::to_string(bridge_connection_id_)},
        {"reason", "readiness_lost"},
        {"auto_start", boolText(auto_start_)},
        {"bridge_ready", boolText(bridge_ready_)},
        {"scan_after_ready", boolText(scan_seen_after_bridge_ready_)},
        {"odom_after_ready", boolText(odom_seen_after_bridge_ready_)},
      });
  }

  publishMapperStatus(stamp);
}

void MapperNode::bridgeReadyCallback(const std_msgs::msg::String::SharedPtr msg)
{
  if (!race_wait_for_bridge_ready_ || !msg) {
    return;
  }

  bool ready = false;
  if (!jsonBoolField(msg->data, "ready", &ready)) {
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      5000,
      "Ignoring malformed bridge ready JSON: '%s'",
      msg->data.c_str());
    return;
  }

  std::uint64_t connection_id = bridge_connection_id_;
  const bool has_connection_id = jsonUInt64Field(msg->data, "connection_id", &connection_id);
  const bool connection_changed =
    has_connection_id && (!has_bridge_connection_id_ || connection_id != bridge_connection_id_);
  const bool ready_changed = ready != bridge_ready_;

  if (connection_changed || ready_changed) {
    bridge_ready_ = ready;
    if (has_connection_id) {
      bridge_connection_id_ = connection_id;
      has_bridge_connection_id_ = true;
    }
    scan_seen_after_bridge_ready_ = false;
    odom_seen_after_bridge_ready_ = false;
    clearPreReadyRuntimeBuffers();

    RCLCPP_INFO(
      get_logger(),
      "bridge readiness changed: ready=%s connection_id=%" PRIu64 " changed=%s",
      bridge_ready_ ? "true" : "false",
      bridge_connection_id_,
      connection_changed ? "true" : "false");
    logRobotEvent(
      "bridge_readiness_changed",
      {
        {"connection_id", std::to_string(bridge_connection_id_)},
        {"ready", boolText(bridge_ready_)},
        {"changed", boolText(connection_changed)},
        {"source", bridge_ready_topic_},
      });
  }

  reevaluateRaceMappingActivation(get_clock()->now());
}

void MapperNode::odomCallback(nav_msgs::msg::Odometry::SharedPtr msg)
{
  const auto now = get_clock()->now();

  if (race_wait_for_bridge_ready_ && !bridge_ready_) {
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      5000,
      "Ignoring odometry before real bridge readiness");
    return;
  }

  if (race_wait_for_bridge_ready_ && bridge_ready_ && !odom_seen_after_bridge_ready_) {
    odom_seen_after_bridge_ready_ = true;
    RCLCPP_INFO(
      get_logger(),
      "First odometry after bridge ready for connection_id=%" PRIu64,
      bridge_connection_id_);
    logRobotEvent(
      "first_odom_after_ready",
      {
        {"connection_id", std::to_string(bridge_connection_id_)},
        {"topic", odom_topic_},
      });
  }

  last_odom_received_stamp_ = now;
  has_last_odom_received_stamp_ = true;
  latest_odom_ = msg;
  odom_buffer_.push_back(msg);
  reevaluateRaceMappingActivation(now);

  if (!mapping_active_) {
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      5000,
      "Ignoring odometry for tile origin/current tile because mapper auto_start is false");
    return;
  }

  const double x = msg->pose.pose.position.x;
  const double y = msg->pose.pose.position.y;

  if (origin_mode_ == "auto_first_pose" && !origin_initialized_) {
    if (origin_require_scan_before_init_ && !has_last_scan_received_stamp_) {
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        std::max(1, static_cast<int>(origin_require_scan_timeout_s_ * 1000.0)),
        "Waiting for first /scan before initializing tile origin from odometry");
    } else {
      initializeOriginFromPose(x, y);
    }
  }

  detectTeleportIfNeeded(*msg);
  updateCurrentTile(*msg);

  rclcpp::Time newest_valid_stamp;
  bool has_newest_valid_stamp = false;
  for (auto it = odom_buffer_.rbegin(); it != odom_buffer_.rend(); ++it) {
    if (!*it) {
      continue;
    }

    const rclcpp::Time odom_stamp((*it)->header.stamp);
    if (odom_stamp.nanoseconds() != 0) {
      newest_valid_stamp = odom_stamp;
      has_newest_valid_stamp = true;
      break;
    }
  }

  const rclcpp::Time prune_reference = has_newest_valid_stamp ? newest_valid_stamp : now;
  while (!odom_buffer_.empty()) {
    if (!odom_buffer_.front()) {
      odom_buffer_.pop_front();
      continue;
    }

    rclcpp::Time odom_stamp(odom_buffer_.front()->header.stamp);
    if (odom_stamp.nanoseconds() == 0) {
      odom_stamp = now;
    }

    if ((prune_reference - odom_stamp).seconds() <= odom_buffer_duration_s_) {
      break;
    }

    odom_buffer_.pop_front();
  }
}

nav_msgs::msg::Odometry::SharedPtr MapperNode::findClosestOdom(
  const rclcpp::Time & stamp,
  double * delta_s) const
{
  if (delta_s) {
    *delta_s = std::numeric_limits<double>::infinity();
  }

  if (odom_buffer_.empty()) {
    return nullptr;
  }

  const bool scan_stamp_valid = stamp.nanoseconds() != 0;
  nav_msgs::msg::Odometry::SharedPtr best_odom;
  double best_delta_s = std::numeric_limits<double>::infinity();

  for (const auto & odom : odom_buffer_) {
    if (!odom) {
      continue;
    }

    const rclcpp::Time odom_stamp(odom->header.stamp);
    if (odom_stamp.nanoseconds() == 0) {
      if (scan_stamp_valid) {
        continue;
      }

      if (!best_odom) {
        best_odom = odom;
        best_delta_s = 0.0;
      }
      continue;
    }

    const auto scan_ns = stamp.nanoseconds();
    const auto odom_ns = odom_stamp.nanoseconds();
    const auto delta_ns = scan_ns >= odom_ns ? scan_ns - odom_ns : odom_ns - scan_ns;
    const double candidate_delta_s = static_cast<double>(delta_ns) * 1.0e-9;

    if (candidate_delta_s < best_delta_s) {
      best_delta_s = candidate_delta_s;
      best_odom = odom;
    }
  }

  if (!best_odom && latest_odom_) {
    const rclcpp::Time latest_stamp(latest_odom_->header.stamp);
    if (scan_stamp_valid && latest_stamp.nanoseconds() != 0) {
      const auto scan_ns = stamp.nanoseconds();
      const auto odom_ns = latest_stamp.nanoseconds();
      const auto delta_ns = scan_ns >= odom_ns ? scan_ns - odom_ns : odom_ns - scan_ns;
      best_delta_s = static_cast<double>(delta_ns) * 1.0e-9;
    } else {
      best_delta_s = 0.0;
    }

    best_odom = latest_odom_;
  }

  if (delta_s) {
    *delta_s = best_delta_s;
  }

  return best_odom;
}

bool MapperNode::interpolateOdomForStamp(
  const rclcpp::Time & stamp,
  InterpolatedOdomResult * result) const
{
  if (!result || stamp.nanoseconds() == 0) {
    return false;
  }

  *result = InterpolatedOdomResult{};

  nav_msgs::msg::Odometry::SharedPtr odom_before;
  nav_msgs::msg::Odometry::SharedPtr odom_after;
  rclcpp::Time before_stamp;
  rclcpp::Time after_stamp;
  bool has_before = false;
  bool has_after = false;

  for (const auto & odom : odom_buffer_) {
    if (!odom) {
      continue;
    }

    const rclcpp::Time odom_stamp(odom->header.stamp);
    if (odom_stamp.nanoseconds() == 0) {
      continue;
    }

    if (odom_stamp <= stamp && (!has_before || odom_stamp > before_stamp)) {
      odom_before = odom;
      before_stamp = odom_stamp;
      has_before = true;
    }

    if (odom_stamp >= stamp && (!has_after || odom_stamp < after_stamp)) {
      odom_after = odom;
      after_stamp = odom_stamp;
      has_after = true;
    }
  }

  if (!has_before || !has_after) {
    if (require_odom_bracket_for_scan_) {
      return false;
    }

    double closest_delta_s = std::numeric_limits<double>::infinity();
    auto closest_odom = findClosestOdom(stamp, &closest_delta_s);
    if (!closest_odom || closest_delta_s > scan_odom_match_max_delta_s_) {
      return false;
    }

    result->odom = *closest_odom;
    result->odom.header.stamp = stamp;
    result->delta_before_s = closest_delta_s;
    result->delta_after_s = closest_delta_s;
    result->bracket_gap_s = 0.0;
    result->interpolated = false;
    return true;
  }

  const auto before_ns = before_stamp.nanoseconds();
  const auto after_ns = after_stamp.nanoseconds();
  if (after_ns < before_ns) {
    return false;
  }

  const double gap_s = static_cast<double>(after_ns - before_ns) * 1.0e-9;
  result->bracket_gap_s = gap_s;
  result->delta_before_s = static_cast<double>(stamp.nanoseconds() - before_ns) * 1.0e-9;
  result->delta_after_s = static_cast<double>(after_ns - stamp.nanoseconds()) * 1.0e-9;

  if (gap_s > odom_interpolation_max_gap_s_) {
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      5000,
      "Dropping scan because odometry bracket gap is %.3f s, above %.3f s",
      gap_s,
      odom_interpolation_max_gap_s_);
    logRobotEvent(
      EventLevel::Warn,
      "scan_dropped",
      {
        {"reason", "odom_bracket_gap"},
        {"scan_stamp", std::to_string(stamp.nanoseconds())},
        {"previous_odom_stamp", std::to_string(before_stamp.nanoseconds())},
        {"next_odom_stamp", std::to_string(after_stamp.nanoseconds())},
        {"bracket_gap", numberText(gap_s, 4)},
        {"threshold", numberText(odom_interpolation_max_gap_s_, 4)},
        {"dropped", "true"},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return false;
  }

  if (gap_s == 0.0 || odom_before == odom_after) {
    result->odom = *odom_before;
    result->odom.header.stamp = stamp;
    result->interpolated = false;
    return true;
  }

  const double alpha =
    std::clamp(
      static_cast<double>(stamp.nanoseconds() - before_ns) /
      static_cast<double>(after_ns - before_ns),
      0.0,
      1.0);

  const auto & before_pose = odom_before->pose.pose;
  const auto & after_pose = odom_after->pose.pose;
  const double yaw0 = yawFromQuaternion(before_pose.orientation);
  const double yaw1 = yawFromQuaternion(after_pose.orientation);
  const double yaw = yaw0 + alpha * normalizeAngle(yaw1 - yaw0);
  const double half_yaw = yaw * 0.5;

  result->odom = *odom_before;
  result->odom.header = odom_before->header;
  result->odom.header.stamp = stamp;
  result->odom.header.frame_id = odom_before->header.frame_id;
  result->odom.child_frame_id = odom_before->child_frame_id;
  result->odom.pose.pose.position.x =
    before_pose.position.x + alpha * (after_pose.position.x - before_pose.position.x);
  result->odom.pose.pose.position.y =
    before_pose.position.y + alpha * (after_pose.position.y - before_pose.position.y);
  result->odom.pose.pose.position.z =
    before_pose.position.z + alpha * (after_pose.position.z - before_pose.position.z);
  result->odom.pose.pose.orientation.x = 0.0;
  result->odom.pose.pose.orientation.y = 0.0;
  result->odom.pose.pose.orientation.z = std::sin(half_yaw);
  result->odom.pose.pose.orientation.w = std::cos(half_yaw);
  result->interpolated = true;
  return true;
}

bool MapperNode::processSingleScanWithOdom(
  const sensor_msgs::msg::LaserScan::SharedPtr & scan,
  const rclcpp::Time & scan_stamp,
  const nav_msgs::msg::Odometry & odom)
{
  if (!mapping_active_ || !scan || !enable_lidar_phantom_observations_ || !origin_initialized_) {
    return false;
  }

  if (get_clock()->now() < lidar_integration_blocked_until_) {
    return false;
  }

  if (
    reject_non_monotonic_scan_stamps_ &&
    has_last_integrated_scan_stamp_ &&
    scan_stamp <= last_integrated_scan_stamp_)
  {
    return false;
  }

  integrateLidarPhantomObservations(*scan, odom, scan_stamp);
  latest_lidar_debug_scan_ = scan;
  latest_lidar_debug_odom_ = std::make_shared<nav_msgs::msg::Odometry>(odom);
  last_integrated_scan_stamp_ = scan_stamp;
  has_last_integrated_scan_stamp_ = true;
  if (race_waiting_for_fresh_scan_after_activation_) {
    race_waiting_for_fresh_scan_after_activation_ = false;
    RCLCPP_INFO(
      get_logger(),
      "Processing first fresh scan after race activation");
    logRobotEvent(
      "first_fresh_scan_integrated",
      {
        {"connection_id", std::to_string(bridge_connection_id_)},
        {"scan_stamp", std::to_string(scan_stamp.nanoseconds())},
        {"origin_initialized", boolText(origin_initialized_)},
        {"mapping_active", boolText(mapping_active_)},
      });
  }
  return true;
}

void MapperNode::processPendingScans()
{
  if (!mapping_active_) {
    return;
  }

  const auto now = get_clock()->now();

  while (!pending_scans_.empty()) {
    const auto & pending = pending_scans_.front();
    const double age_s = (now - pending.received_at).seconds();

    if (age_s < scan_processing_delay_s_) {
      break;
    }

    if (age_s > scan_pending_max_age_s_) {
      InterpolatedOdomResult expired_interp;
      if (
        require_odom_bracket_for_scan_ &&
        !interpolateOdomForStamp(pending.stamp, &expired_interp))
      {
        RCLCPP_WARN_THROTTLE(
          get_logger(),
          *get_clock(),
          5000,
          "Dropping pending scan after %.3f s without a usable odometry bracket",
          age_s);
        logRobotEvent(
          EventLevel::Warn,
          "scan_dropped",
          {
            {"reason", "odom_bracket_missing"},
            {"scan_stamp", std::to_string(pending.stamp.nanoseconds())},
            {"bracket_gap", numberText(expired_interp.bracket_gap_s, 4)},
            {"threshold", numberText(odom_interpolation_max_gap_s_, 4)},
            {"dropped", "true"},
            {"connection_id", std::to_string(bridge_connection_id_)},
          });
      } else {
        RCLCPP_WARN_THROTTLE(
          get_logger(),
          *get_clock(),
          5000,
          "Dropping pending scan after %.3f s, above max age %.3f s",
          age_s,
          scan_pending_max_age_s_);
      }

      pending_scans_.pop_front();
      continue;
    }

    if (now < lidar_integration_blocked_until_) {
      break;
    }

    if (
      reject_non_monotonic_scan_stamps_ &&
      has_last_integrated_scan_stamp_ &&
      pending.stamp <= last_integrated_scan_stamp_)
    {
      pending_scans_.pop_front();
      continue;
    }

    InterpolatedOdomResult interp;
    if (!interpolateOdomForStamp(pending.stamp, &interp)) {
      if (require_odom_bracket_for_scan_) {
        break;
      }

      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        5000,
        "Dropping scan because odometry interpolation/fallback failed");
      logRobotEvent(
        EventLevel::Warn,
        "scan_dropped",
        {
          {"reason", "odom_interpolation_failed"},
          {"scan_stamp", std::to_string(pending.stamp.nanoseconds())},
          {"threshold", numberText(scan_odom_match_max_delta_s_, 4)},
          {"dropped", "true"},
          {"connection_id", std::to_string(bridge_connection_id_)},
        });
      pending_scans_.pop_front();
      continue;
    }

    processSingleScanWithOdom(pending.scan, pending.stamp, interp.odom);
    pending_scans_.pop_front();
  }
}

void MapperNode::scanCallback(sensor_msgs::msg::LaserScan::SharedPtr msg)
{
  if (!msg) {
    return;
  }

  const auto now = get_clock()->now();

  if (race_wait_for_bridge_ready_ && !bridge_ready_) {
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      5000,
      "Ignoring scan before real bridge readiness");
    return;
  }

  rclcpp::Time scan_stamp(msg->header.stamp);
  if (scan_stamp.nanoseconds() == 0) {
    scan_stamp = now;
  }

  if (race_wait_for_bridge_ready_ && bridge_ready_ && !scan_seen_after_bridge_ready_) {
    scan_seen_after_bridge_ready_ = true;
    RCLCPP_INFO(
      get_logger(),
      "First scan after bridge ready for connection_id=%" PRIu64,
      bridge_connection_id_);
    logRobotEvent(
      "first_scan_after_ready",
      {
        {"connection_id", std::to_string(bridge_connection_id_)},
        {"topic", scan_topic_},
      });
  }

  last_scan_received_stamp_ = now;
  has_last_scan_received_stamp_ = true;

  latest_scan_ = msg;
  const bool was_mapping_active = mapping_active_;
  reevaluateRaceMappingActivation(now);
  const bool race_activated_by_this_scan =
    race_wait_for_bridge_ready_ && !was_mapping_active && mapping_active_;
  if (race_activated_by_this_scan) {
    latest_scan_.reset();
    RCLCPP_INFO(
      get_logger(),
      "Skipping scan that completed race handoff activation; waiting for next fresh scan");
    return;
  }

  if (!mapping_active_) {
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      5000,
      race_wait_for_bridge_ready_ && bridge_ready_ ?
      "Ignoring post-ready scan until race mapping activation; scan will not be queued" :
      "Ignoring scan integration because mapper auto_start is false");
    return;
  }

  if (enable_delayed_scan_processing_) {
    pending_scans_.push_back(PendingScan{msg, scan_stamp, now});
    processPendingScans();
    return;
  }

  if (!enable_lidar_phantom_observations_ || !origin_initialized_) {
    return;
  }

  if (now < lidar_integration_blocked_until_) {
    return;
  }

  double odom_delta_s = std::numeric_limits<double>::infinity();
  auto matched_odom = findClosestOdom(scan_stamp, &odom_delta_s);
  if (!matched_odom) {
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      5000,
      "Dropping scan because no odometry sample is available for timestamp matching");
    return;
  }

  if (odom_delta_s > scan_odom_match_max_delta_s_) {
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      5000,
      "Dropping scan because closest odometry is %.3f s away, above %.3f s",
      odom_delta_s,
      scan_odom_match_max_delta_s_);
    return;
  }

  processSingleScanWithOdom(msg, scan_stamp, *matched_odom);
}

void MapperNode::slamMapCallback(nav_msgs::msg::OccupancyGrid::SharedPtr msg)
{
  const auto now = get_clock()->now();

  if (race_wait_for_bridge_ready_ && !bridge_ready_) {
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      5000,
      "Ignoring /map before real bridge readiness");
    return;
  }

  last_slam_map_received_stamp_ = now;
  has_slam_map_received_ = true;

  if (!msg) {
    return;
  }

  slam_map_sampler_.updateMap(*msg, now);
  maybeLogSlamGeometryStatus(now);

  const auto expected_size =
    static_cast<std::size_t>(msg->info.width) * static_cast<std::size_t>(msg->info.height);
  const bool valid =
    msg->info.width > 0U &&
    msg->info.height > 0U &&
    std::isfinite(static_cast<double>(msg->info.resolution)) &&
    msg->info.resolution > 0.0F &&
    msg->data.size() == expected_size;

  if (!valid) {
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      5000,
      "Received invalid /map: width=%u height=%u resolution=%.6f data=%zu expected=%zu",
      msg->info.width,
      msg->info.height,
      msg->info.resolution,
      msg->data.size(),
      expected_size);
    return;
  }

  const bool first_valid_map = !has_valid_slam_map_;
  last_valid_slam_map_ = *msg;
  last_valid_slam_map_stamp_ = now;
  has_valid_slam_map_ = true;

  if (first_valid_map) {
    RCLCPP_INFO(
      get_logger(),
      "Received first valid /map: width=%u height=%u resolution=%.6f frame_id=%s",
      msg->info.width,
      msg->info.height,
      msg->info.resolution,
      msg->header.frame_id.c_str());
  }
}

void MapperNode::integrateLidarPhantomObservations(
  const sensor_msgs::msg::LaserScan & scan,
  const nav_msgs::msg::Odometry & odom,
  const rclcpp::Time & stamp)
{
  const double scan_min_range = std::max(0.0, static_cast<double>(scan.range_min));
  const double scan_max_range =
    std::isfinite(static_cast<double>(scan.range_max)) ?
    static_cast<double>(scan.range_max) :
    lidar_observation_max_range_;
  const double max_usable_range = std::min(scan_max_range, lidar_observation_max_range_);

  if (max_usable_range <= scan_min_range) {
    return;
  }

  const auto & pose = odom.pose.pose;
  const double robot_x = pose.position.x;
  const double robot_y = pose.position.y;
  const double yaw = yawFromQuaternion(pose.orientation);
  std::unordered_set<PhantomQuarterEdgeKey, PhantomQuarterEdgeKeyHash> touched_edges;
  std::unordered_set<TileCoord, TileCoordHash> touched_tiles;
  std::unordered_set<TileCoord, TileCoordHash> obstacle_touched_tiles;

  for (std::size_t i = 0; i < scan.ranges.size(); ++i) {
    const double range = static_cast<double>(scan.ranges[i]);

    if (std::isnan(range) || range < scan_min_range) {
      continue;
    }

    const bool hit_valid =
      std::isfinite(range) &&
      range <= scan_max_range &&
      range <= lidar_observation_max_range_;

    const double endpoint_range =
      hit_valid ? std::min(range, lidar_observation_max_range_) : max_usable_range;

    if (endpoint_range <= 0.0) {
      continue;
    }

    const double theta = static_cast<double>(scan.angle_min) +
      static_cast<double>(i) * static_cast<double>(scan.angle_increment);
    const double world_theta = yaw + theta;
    const double cos_theta = std::cos(world_theta);
    const double sin_theta = std::sin(world_theta);

    std::unordered_set<PhantomQuadrantKey, PhantomQuadrantKeyHash> possible_seen;
    std::unordered_set<PhantomQuadrantKey, PhantomQuadrantKeyHash> free_seen;
    std::unordered_set<PhantomSupportBinKey, PhantomSupportBinKeyHash> support_possible_seen;
    std::unordered_set<PhantomSupportBinKey, PhantomSupportBinKeyHash> support_free_seen;
    std::unordered_set<PhantomQuarterEdgeKey, PhantomQuarterEdgeKeyHash> edge_possible_seen;
    std::unordered_set<PhantomQuarterEdgeKey, PhantomQuarterEdgeKeyHash> edge_free_conflict_seen;
    std::unordered_set<PhantomQuarterEdgeKey, PhantomQuarterEdgeKeyHash> edge_hit_support_seen;
    std::unordered_set<
      PhantomPrimitiveSubtileKey,
      PhantomPrimitiveSubtileKeyHash> primitive_subtiles_seen;
    std::optional<PhantomPrimitiveSubtileKey> positive_primitive_subtile;

    if (enable_obstacle_primitives_) {
      std::unordered_set<PhantomObstacleGridBinKey, PhantomObstacleGridBinKeyHash>
        obstacle_free_seen;
      const double obstacle_bin_size =
        tile_size_ / static_cast<double>(obstacle_grid_bins_per_tile_);
      const double obstacle_bin_step = std::min(lidar_ray_grid_step_m_, obstacle_bin_size);
      const double obstacle_free_limit =
        hit_valid ? std::max(0.0, endpoint_range - obstacle_bin_step) : endpoint_range;

      for (
        double distance = obstacle_bin_step;
        distance < obstacle_free_limit;
        distance += obstacle_bin_step)
      {
        const double sample_x = robot_x + distance * cos_theta;
        const double sample_y = robot_y + distance * sin_theta;
        const auto coord = computeTileCoord(sample_x, sample_y, origin_x_, origin_y_, tile_size_);
        if (!isTileWithinCurrentRadius(coord, phantom_update_max_tile_radius_)) {
          continue;
        }

        const double tile_center_x = static_cast<double>(coord.x) * tile_size_ + origin_x_;
        const double tile_center_y = static_cast<double>(coord.y) * tile_size_ + origin_y_;
        const double local_x = sample_x - tile_center_x;
        const double local_y = sample_y - tile_center_y;
        if (
          tileEdgeDistanceLocal(local_x, local_y, tile_size_) <
          obstacle_min_distance_from_tile_edge_m_)
        {
          continue;
        }

        const int obstacle_bin = obstacleGridBinForLocal(
          local_x,
          local_y,
          tile_size_,
          obstacle_grid_bins_per_tile_);
        if (obstacle_bin < 0) {
          continue;
        }

        const PhantomObstacleGridBinKey key{coord, obstacle_bin};
        if (!obstacle_free_seen.insert(key).second) {
          continue;
        }

        const double weight = lidarObservationWeight(distance, lidar_range_weight_scale_m_);
        phantom_tile_map_.recordObstacleGridFree(
          coord,
          obstacle_bin,
          obstacle_bin_free_weight_ * weight,
          stamp);
        obstacle_touched_tiles.insert(coord);
      }
    }

    for (
      double distance = lidar_ray_step_m_;
      distance < endpoint_range;
      distance += lidar_ray_step_m_)
    {
      const double sample_x = robot_x + distance * cos_theta;
      const double sample_y = robot_y + distance * sin_theta;
      const auto coord = computeTileCoord(sample_x, sample_y, origin_x_, origin_y_, tile_size_);
      if (!isTileWithinCurrentRadius(coord, phantom_update_max_tile_radius_)) {
        continue;
      }

      touched_tiles.insert(coord);
      const auto quadrant = tileQuadrantForPoint(sample_x, sample_y, coord);
      const PhantomQuadrantKey key{coord, quadrant};
      const double weight = lidarObservationWeight(distance, lidar_range_weight_scale_m_);

      if (possible_seen.insert(key).second) {
        phantom_tile_map_.recordPossibleRay(coord, quadrant, distance, weight, stamp);
      }
      if (free_seen.insert(key).second) {
        phantom_tile_map_.recordFreeRay(coord, quadrant, distance, weight, stamp);
      }

      const int support_bin = supportBinIndexForPoint(sample_x, sample_y, coord);
      const PhantomSupportBinKey support_key{coord, support_bin};
      if (support_possible_seen.insert(support_key).second) {
        phantom_tile_map_.recordSupportPossible(coord, support_bin, distance, weight, stamp);
      }
      if (support_free_seen.insert(support_key).second) {
        phantom_tile_map_.recordSupportFree(coord, support_bin, distance, weight, stamp);
      }

      if (enable_ray_model_primitives_) {
        primitive_subtiles_seen.insert(
          PhantomPrimitiveSubtileKey{coord, subtileForPoint(sample_x, sample_y, coord)});
      }

      if (enable_quarter_edge_evidence_) {
        const double possible_tolerance = std::max(
          quarter_edge_hit_tolerance_m_,
          quarter_edge_free_conflict_tolerance_m_);
        const bool allow_edge_free_conflict =
          !hit_valid ||
          distance + quarter_edge_free_conflict_tolerance_m_ < endpoint_range;

        for (
          const auto & segment :
          canonicalSegmentsNearPoint(sample_x, sample_y, coord, possible_tolerance))
        {
          const PhantomQuarterEdgeKey edge_key{coord, segment};
          if (edge_possible_seen.insert(edge_key).second) {
            phantom_tile_map_.recordQuarterEdgePossible(coord, segment, weight, stamp);
            touched_edges.insert(edge_key);
          }
        }

        if (allow_edge_free_conflict) {
          for (
            const auto & segment :
            canonicalSegmentsNearPoint(
              sample_x,
              sample_y,
              coord,
              quarter_edge_free_conflict_tolerance_m_))
          {
            const PhantomQuarterEdgeKey edge_key{coord, segment};
            if (edge_free_conflict_seen.insert(edge_key).second) {
              phantom_tile_map_.recordQuarterEdgeFreeConflict(coord, segment, weight, stamp);
              touched_edges.insert(edge_key);
            }
          }
        }
      }
    }

    if (hit_valid) {
      const double hit_x = robot_x + endpoint_range * cos_theta;
      const double hit_y = robot_y + endpoint_range * sin_theta;
      const auto coord = computeTileCoord(hit_x, hit_y, origin_x_, origin_y_, tile_size_);
      if (isTileWithinCurrentRadius(coord, phantom_update_max_tile_radius_)) {
        touched_tiles.insert(coord);
        const auto quadrant = tileQuadrantForPoint(hit_x, hit_y, coord);
        const PhantomQuadrantKey key{coord, quadrant};
        const double weight = lidarObservationWeight(endpoint_range, lidar_range_weight_scale_m_);

        if (possible_seen.insert(key).second) {
          phantom_tile_map_.recordPossibleRay(coord, quadrant, endpoint_range, weight, stamp);
        }
        phantom_tile_map_.recordHit(coord, quadrant, endpoint_range, weight, stamp);

        const int support_bin = supportBinIndexForPoint(hit_x, hit_y, coord);
        const PhantomSupportBinKey support_key{coord, support_bin};
        if (support_possible_seen.insert(support_key).second) {
          phantom_tile_map_.recordSupportPossible(coord, support_bin, endpoint_range, weight, stamp);
        }
        phantom_tile_map_.recordSupportHit(coord, support_bin, endpoint_range, weight, stamp);

        if (enable_obstacle_primitives_) {
          const double tile_center_x = static_cast<double>(coord.x) * tile_size_ + origin_x_;
          const double tile_center_y = static_cast<double>(coord.y) * tile_size_ + origin_y_;
          const double local_x = hit_x - tile_center_x;
          const double local_y = hit_y - tile_center_y;
          if (
            tileEdgeDistanceLocal(local_x, local_y, tile_size_) >=
            obstacle_min_distance_from_tile_edge_m_)
          {
            const int obstacle_bin = obstacleGridBinForLocal(
              local_x,
              local_y,
              tile_size_,
              obstacle_grid_bins_per_tile_);
            if (obstacle_bin >= 0) {
              phantom_tile_map_.recordObstacleGridHit(
                coord,
                obstacle_bin,
                obstacle_bin_hit_weight_ * weight,
                stamp);
              obstacle_touched_tiles.insert(coord);
            }
          }
        }

        if (enable_ray_model_primitives_) {
          const PhantomPrimitiveSubtileKey primitive_subtile{
            coord,
            subtileForPoint(hit_x, hit_y, coord)};
          primitive_subtiles_seen.insert(primitive_subtile);
          positive_primitive_subtile = primitive_subtile;
        }

        if (enable_quarter_edge_evidence_) {
          const double possible_tolerance = std::max(
            quarter_edge_hit_tolerance_m_,
            quarter_edge_free_conflict_tolerance_m_);

          for (
            const auto & segment :
            canonicalSegmentsNearPoint(hit_x, hit_y, coord, possible_tolerance))
          {
            const PhantomQuarterEdgeKey edge_key{coord, segment};
            if (edge_possible_seen.insert(edge_key).second) {
              phantom_tile_map_.recordQuarterEdgePossible(coord, segment, weight, stamp);
              touched_edges.insert(edge_key);
            }
          }

          for (
            const auto & segment :
            canonicalSegmentsNearPoint(hit_x, hit_y, coord, quarter_edge_hit_tolerance_m_))
          {
            const PhantomQuarterEdgeKey edge_key{coord, segment};
            if (edge_hit_support_seen.insert(edge_key).second) {
              phantom_tile_map_.recordQuarterEdgeHitSupport(coord, segment, weight, stamp);
              touched_edges.insert(edge_key);
            }
          }
        }
      }
    }

    if (enable_ray_model_primitives_) {
      for (const auto & primitive_subtile : primitive_subtiles_seen) {
        const bool allow_positive_hit =
          positive_primitive_subtile &&
          *positive_primitive_subtile == primitive_subtile;
        recordRayModelPrimitiveObservations(
          primitive_subtile.coord,
          primitive_subtile.subtile,
          robot_x,
          robot_y,
          cos_theta,
          sin_theta,
          endpoint_range,
          hit_valid,
          allow_positive_hit,
          stamp);
      }
    }

  }

  if (enable_obstacle_primitives_) {
    for (const auto & coord : obstacle_touched_tiles) {
      phantom_tile_map_.decayObstacleGridTile(coord, obstacle_grid_bins_per_tile_, stamp);
      auto & evidence = phantom_tile_map_.getOrCreate(coord, stamp);
      const auto candidate = detectObstacleClusterFromGrid(
        evidence,
        obstacle_grid_bins_per_tile_,
        tile_size_,
        obstacle_bin_occupied_threshold_,
        obstacle_bin_free_margin_,
        obstacle_min_cluster_bins_,
        obstacle_min_total_hits_,
        obstacle_min_confidence_,
        obstacle_max_free_ratio_,
        obstacle_min_distance_from_tile_edge_m_,
        obstacle_min_box_size_m_,
        obstacle_max_box_size_m_,
        obstacle_box_padding_m_,
        obstacle_surrounding_ring_bins_,
        obstacle_min_surrounding_free_ratio_,
        obstacle_wall_overlap_penalty_,
        obstacle_edge_proximity_penalty_,
        primitive_wall_thickness_m_,
        primitive_wall_margin_m_,
        primitive_debug_min_confidence_,
        curve_debug_min_confidence_,
        curve_proto_inner_radius_,
        curve_proto_outer_radius_,
        curve_radius_offset_m_,
        curve_wall_margin_m_);

      evidence.obstacle.has_candidate = candidate.valid;
      evidence.obstacle.center_local_x = candidate.center_local_x;
      evidence.obstacle.center_local_y = candidate.center_local_y;
      evidence.obstacle.width_m = candidate.width_m;
      evidence.obstacle.length_m = candidate.length_m;
      evidence.obstacle.hit_score = candidate.hit_score;
      evidence.obstacle.free_conflict_score = candidate.free_score;
      evidence.obstacle.confidence = candidate.confidence;
      evidence.obstacle.free_ratio = candidate.free_ratio;
      evidence.obstacle.surrounding_free_ratio = candidate.surrounding_free_ratio;
      evidence.obstacle.wall_overlap_penalty = candidate.wall_overlap_penalty;
      evidence.obstacle.edge_proximity_penalty = candidate.edge_proximity_penalty;
      evidence.obstacle.cluster_bins = candidate.cluster_bins;
      evidence.obstacle.hit_count = candidate.total_hits;
      evidence.obstacle.free_conflicts = candidate.free_count;
      evidence.obstacle.last_seen = stamp;
      evidence.last_seen = stamp;
      evidence.observation_count += 1;
    }
  }

  for (const auto & edge : touched_edges) {
    phantom_tile_map_.recomputeQuarterEdgeScores(
      edge.coord,
      quarter_edge_min_visibility_rays_,
      quarter_edge_hit_weight_,
      quarter_edge_conflict_weight_);
  }

  for (const auto & coord : touched_tiles) {
    if (!isTileWithinCurrentRadius(coord, phantom_mask_max_tile_radius_)) {
      continue;
    }

    phantom_tile_map_.recomputeMaskCandidates(
      coord,
      mask_supported_segment_min_score_,
      mask_conflict_segment_max_score_,
      mask_complexity_penalty_,
      mask_unsupported_segment_penalty_,
      mask_min_confidence_);
  }

}

TileQuadrant MapperNode::tileQuadrantForPoint(
  double x,
  double y,
  const TileCoord & coord) const
{
  const double cx = static_cast<double>(coord.x) * tile_size_ + origin_x_;
  const double cy = static_cast<double>(coord.y) * tile_size_ + origin_y_;
  const double u = (x - cx) / tile_size_;
  const double v = (y - cy) / tile_size_;

  if (u < 0.0) {
    return v >= 0.0 ? TileQuadrant::NW : TileQuadrant::SW;
  }

  return v >= 0.0 ? TileQuadrant::NE : TileQuadrant::SE;
}

int MapperNode::supportBinIndexForPoint(
  double x,
  double y,
  const TileCoord & coord) const
{
  const double cx = static_cast<double>(coord.x) * tile_size_ + origin_x_;
  const double cy = static_cast<double>(coord.y) * tile_size_ + origin_y_;
  const double u = (x - cx) / tile_size_;
  const double v = (y - cy) / tile_size_;
  const int col = std::clamp(
    static_cast<int>(std::floor((u + 0.5) * 4.0)),
    0,
    3);
  const int row = std::clamp(
    static_cast<int>(std::floor((0.5 - v) * 4.0)),
    0,
    3);
  return row * 4 + col;
}

SubtileIndex MapperNode::subtileForPoint(
  double x,
  double y,
  const TileCoord & coord) const
{
  const double cx = static_cast<double>(coord.x) * tile_size_ + origin_x_;
  const double cy = static_cast<double>(coord.y) * tile_size_ + origin_y_;
  const double u = x - cx;
  const double v = y - cy;

  if (u < 0.0) {
    return v >= 0.0 ? SubtileIndex::NW : SubtileIndex::SW;
  }

  return v >= 0.0 ? SubtileIndex::NE : SubtileIndex::SE;
}

void MapperNode::recordRayModelPrimitiveObservations(
  const TileCoord & coord,
  SubtileIndex subtile,
  double ray_origin_x,
  double ray_origin_y,
  double ray_dir_x,
  double ray_dir_y,
  double endpoint_range,
  bool hit_valid,
  bool allow_positive_hit,
  const rclcpp::Time & stamp)
{
  const double tile_center_x = static_cast<double>(coord.x) * tile_size_ + origin_x_;
  const double tile_center_y = static_cast<double>(coord.y) * tile_size_ + origin_y_;
  std::vector<PrimitiveHitCandidate> hit_candidates;
  hit_candidates.reserve(edgePrimitiveKinds().size() + curvePrimitiveKinds().size() + 1U);

  const auto recompute_primitive =
    [&](PrimitiveKind primitive) {
      if (isCurvePrimitive(primitive)) {
        phantom_tile_map_.recomputePrimitiveConfidence(
          coord,
          subtile,
          primitive,
          curve_min_visibility_rays_,
          curve_min_visibility_rays_);
        return;
      }

      phantom_tile_map_.recomputePrimitiveConfidence(
        coord,
        subtile,
        primitive,
        primitive_min_visibility_rays_);
    };

  for (const auto primitive : edgePrimitiveKinds()) {
    double t_model = 0.0;
    const auto aabb = primitiveAabbLocal(
      subtile,
      primitive,
      tile_size_,
      primitive_wall_thickness_m_,
      primitive_wall_margin_m_);

    if (!rayIntersectsAabb2d(
        ray_origin_x,
        ray_origin_y,
        ray_dir_x,
        ray_dir_y,
        tile_center_x + aabb.min_x,
        tile_center_y + aabb.min_y,
        tile_center_x + aabb.max_x,
        tile_center_y + aabb.max_y,
        &t_model))
    {
      continue;
    }

    const double hit_tolerance = std::min(
      primitive_base_tolerance_m_ + lidar_range_sigma_m_ + t_model * primitive_yaw_sigma_rad_,
      primitive_hit_tolerance_max_m_);

    const double intersection_x = ray_origin_x + t_model * ray_dir_x;
    const double intersection_y = ray_origin_y + t_model * ray_dir_y;
    const double local_x = intersection_x - tile_center_x;
    const double local_y = intersection_y - tile_center_y;
    const double range_weight = lidarObservationWeight(t_model, lidar_range_weight_scale_m_);
    const double incidence = primitiveIncidence(primitive, ray_dir_x, ray_dir_y);
    const double incidence_weight = primitiveIncidenceWeight(primitive, ray_dir_x, ray_dir_y);
    const double projection =
      primitiveProjectionAlongEdge(subtile, primitive, local_x, local_y, tile_size_);
    const double center_weight =
      primitiveCenterWeight(
        subtile,
        primitive,
        local_x,
        local_y,
        tile_size_,
        subtile_wall_center_mask_ratio_);
    const double negative_weight =
      range_weight * incidence_weight * center_weight * lidar_conflict_weight_;
    const double positive_weight = range_weight * incidence * center_weight;

    bool updated = false;
    if (hit_valid && endpoint_range < t_model - hit_tolerance) {
      phantom_tile_map_.recordPrimitiveOccluded(coord, subtile, primitive, stamp);
      updated = true;
    } else if (
      hit_valid &&
      allow_positive_hit &&
      std::fabs(endpoint_range - t_model) <= hit_tolerance)
    {
      PrimitiveHitCandidate candidate;
      candidate.primitive = primitive;
      candidate.t_model = t_model;
      candidate.residual = std::fabs(endpoint_range - t_model);
      candidate.hit_tolerance = hit_tolerance;
      candidate.incidence = incidence;
      candidate.center_weight = center_weight;
      candidate.projection = projection;
      candidate.range_weight = range_weight;
      candidate.final_weight = positive_weight;
      hit_candidates.push_back(candidate);
    } else if (negative_weight > 0.0 && t_model < endpoint_range - hit_tolerance) {
      phantom_tile_map_.recordPrimitivePossible(coord, subtile, primitive, negative_weight, stamp);
      phantom_tile_map_.recordPrimitiveNegative(coord, subtile, primitive, negative_weight, stamp);
      updated = true;
    } else if (negative_weight > 0.0 && !hit_valid && t_model <= endpoint_range) {
      phantom_tile_map_.recordPrimitivePossible(coord, subtile, primitive, negative_weight, stamp);
      phantom_tile_map_.recordPrimitiveNegative(coord, subtile, primitive, negative_weight, stamp);
      updated = true;
    }

    if (updated) {
      recompute_primitive(primitive);
    }
  }

  if (enable_curve_primitives_) {
    for (const auto primitive : curvePrimitiveKinds()) {
      auto geometry = curveGeometryFromProtoTransform(
        subtile,
        primitive,
        tile_size_,
        curve_proto_inner_radius_,
        curve_proto_outer_radius_,
        curve_radius_offset_m_,
        curve_wall_margin_m_);
      if (!curveGeometryIsValid(geometry)) {
        RCLCPP_WARN_THROTTLE(
          get_logger(),
          *get_clock(),
          5000,
          "Ignoring invalid curve radius: tile=(%d,%d) subtile=%d curve=%d",
          coord.x,
          coord.y,
          static_cast<int>(subtile),
          static_cast<int>(primitive));
        continue;
      }

      if (
        !curveGeometryMostlyInsideSubtile(
          subtile,
          geometry,
          tile_size_,
          curve_subtile_containment_tolerance_m_,
          curve_subtile_containment_required_fraction_))
      {
        RCLCPP_WARN_THROTTLE(
          get_logger(),
          *get_clock(),
          5000,
          "Ignoring curve geometry outside subtile: tile=(%d,%d) subtile=%d curve=%d",
          coord.x,
          coord.y,
          static_cast<int>(subtile),
          static_cast<int>(primitive));
        continue;
      }

      geometry.center_x += tile_center_x;
      geometry.center_y += tile_center_y;

      double t_model = 0.0;
      double angle_at_hit = 0.0;
      double radial_error = 0.0;
      if (!rayIntersectsAnnularSector2d(
          ray_origin_x,
          ray_origin_y,
          ray_dir_x,
          ray_dir_y,
          geometry,
          &t_model,
          &angle_at_hit,
          &radial_error))
      {
        continue;
      }

      const double hit_tolerance = std::min(
        curve_base_tolerance_m_ + lidar_range_sigma_m_ + t_model * curve_yaw_sigma_rad_,
        curve_hit_tolerance_max_m_);

      const double intersection_x = ray_origin_x + t_model * ray_dir_x;
      const double intersection_y = ray_origin_y + t_model * ray_dir_y;
      const double radial_x = intersection_x - geometry.center_x;
      const double radial_y = intersection_y - geometry.center_y;
      const double radius = std::hypot(radial_x, radial_y);
      if (radius <= 1.0e-9) {
        continue;
      }

      const double radial_normal_x = radial_x / radius;
      const double radial_normal_y = radial_y / radius;
      const double incidence =
        std::clamp(
          std::fabs(ray_dir_x * radial_normal_x + ray_dir_y * radial_normal_y),
          0.0,
          1.0);
      const double incidence_weight = std::clamp(incidence, 0.15, 1.0);
      const double projection =
        std::clamp(angleProjectionInSector(geometry, angle_at_hit), 0.0, 1.0);
      const double angular_center_weight =
        curveBellyWeight(projection, subtile_curve_center_mask_ratio_);
      const double raw_radial_center_weight = std::clamp(
        1.0 - radial_error / curve_radial_center_tolerance_m_,
        0.0,
        1.0);
      const double radial_center_weight =
        std::pow(raw_radial_center_weight, curve_radial_center_power_);
      const double range_weight = lidarObservationWeight(t_model, lidar_range_weight_scale_m_);
      const double negative_weight =
        range_weight *
        incidence_weight *
        angular_center_weight *
        lidar_conflict_weight_ *
        curve_negative_weight_scale_;
      const double positive_weight =
        range_weight *
        incidence *
        angular_center_weight *
        radial_center_weight *
        curve_positive_weight_scale_;

      bool updated = false;
      if (hit_valid && endpoint_range < t_model - hit_tolerance) {
        phantom_tile_map_.recordPrimitiveOccluded(coord, subtile, primitive, stamp);
        updated = true;
      } else if (
        hit_valid &&
        allow_positive_hit &&
        std::fabs(endpoint_range - t_model) <= hit_tolerance)
      {
        if (radial_center_weight <= 0.0) {
          continue;
        }

        PrimitiveHitCandidate candidate;
        candidate.primitive = primitive;
        candidate.is_curve = true;
        candidate.t_model = t_model;
        candidate.residual = std::fabs(endpoint_range - t_model);
        candidate.hit_tolerance = hit_tolerance;
        candidate.incidence = incidence;
        candidate.center_weight = angular_center_weight;
        candidate.radial_center_weight = radial_center_weight;
        candidate.projection = projection;
        candidate.range_weight = range_weight;
        candidate.final_weight = positive_weight;
        hit_candidates.push_back(candidate);
      } else if (negative_weight > 0.0 && t_model < endpoint_range - hit_tolerance) {
        phantom_tile_map_.recordPrimitivePossible(coord, subtile, primitive, negative_weight, stamp);
        phantom_tile_map_.recordPrimitiveNegative(coord, subtile, primitive, negative_weight, stamp);
        updated = true;
      } else if (negative_weight > 0.0 && !hit_valid && t_model <= endpoint_range) {
        phantom_tile_map_.recordPrimitivePossible(coord, subtile, primitive, negative_weight, stamp);
        phantom_tile_map_.recordPrimitiveNegative(coord, subtile, primitive, negative_weight, stamp);
        updated = true;
      }

      if (updated) {
        recompute_primitive(primitive);
      }
    }
  }

  if (hit_candidates.empty()) {
    return;
  }

  constexpr double kHitToleranceEpsilon = 1.0e-9;
  const PrimitiveHitCandidate * best_candidate = nullptr;
  const PrimitiveHitCandidate * best_edge_candidate = nullptr;
  const PrimitiveHitCandidate * best_curve_candidate = nullptr;

  for (auto & candidate : hit_candidates) {
    const double residual_score = std::clamp(
      1.0 - candidate.residual / std::max(candidate.hit_tolerance, kHitToleranceEpsilon),
      0.0,
      1.0);
    candidate.hit_score =
      residual_score *
      candidate.incidence *
      candidate.center_weight *
      (candidate.is_curve ? candidate.radial_center_weight : 1.0);
    const double min_incidence =
      candidate.is_curve ? curve_positive_min_incidence_ : primitive_positive_min_incidence_;
    const double endpoint_exclusion_ratio =
      candidate.is_curve ? curve_endpoint_exclusion_ratio_ : primitive_endpoint_exclusion_ratio_;
    const double min_hit_score =
      candidate.is_curve ? curve_positive_min_hit_score_ : primitive_positive_min_hit_score_;

    if (candidate.is_curve && candidate.radial_center_weight <= 0.0) {
      continue;
    }

    if (
      candidate.incidence < min_incidence ||
      candidate.projection < endpoint_exclusion_ratio ||
      candidate.projection > 1.0 - endpoint_exclusion_ratio ||
      candidate.hit_score < min_hit_score)
    {
      continue;
    }

    if (primitive_allow_multi_positive_per_ray_) {
      const int min_visibility_rays =
        candidate.is_curve ? curve_min_visibility_rays_ : primitive_min_visibility_rays_;
      phantom_tile_map_.recordPrimitivePossible(
        coord,
        subtile,
        candidate.primitive,
        candidate.final_weight,
        stamp);
      phantom_tile_map_.recordPrimitivePositive(
        coord,
        subtile,
        candidate.primitive,
        candidate.final_weight,
        stamp);
      phantom_tile_map_.recomputePrimitiveConfidence(
        coord,
        subtile,
        candidate.primitive,
        min_visibility_rays,
        candidate.is_curve ? curve_min_visibility_rays_ : 3);
      continue;
    }

    if (isEdgePrimitive(candidate.primitive)) {
      if (
        best_edge_candidate == nullptr ||
        candidate.hit_score > best_edge_candidate->hit_score ||
        (
          candidate.hit_score == best_edge_candidate->hit_score &&
          candidate.residual < best_edge_candidate->residual))
      {
        best_edge_candidate = &candidate;
      }
    } else if (candidate.is_curve) {
      if (
        best_curve_candidate == nullptr ||
        candidate.hit_score > best_curve_candidate->hit_score ||
        (
          candidate.hit_score == best_curve_candidate->hit_score &&
          candidate.residual < best_curve_candidate->residual))
      {
        best_curve_candidate = &candidate;
      }
    }

    if (best_candidate == nullptr) {
      best_candidate = &candidate;
      continue;
    }

    const bool equal_score_better_residual =
      candidate.hit_score == best_candidate->hit_score &&
      candidate.residual < best_candidate->residual;

    if (candidate.hit_score > best_candidate->hit_score || equal_score_better_residual) {
      best_candidate = &candidate;
    }
  }

  if (!primitive_allow_multi_positive_per_ray_ && best_candidate != nullptr) {
    const bool curve_blocks_wall =
      best_curve_candidate != nullptr &&
      best_edge_candidate != nullptr &&
      best_curve_candidate->projection >= 0.35 &&
      best_curve_candidate->projection <= 0.65 &&
      best_curve_candidate->t_model + best_curve_candidate->hit_tolerance <
      best_edge_candidate->t_model;

    if (curve_blocks_wall) {
      best_candidate = best_curve_candidate;
    }

    if (
      !curve_blocks_wall &&
      best_candidate->is_curve &&
      best_edge_candidate != nullptr &&
      best_edge_candidate->hit_score >= best_candidate->hit_score * curve_edge_ambiguity_ratio_)
    {
      best_candidate = best_edge_candidate;
    }

    phantom_tile_map_.recordPrimitivePossible(
      coord,
      subtile,
      best_candidate->primitive,
      best_candidate->final_weight,
      stamp);
    phantom_tile_map_.recordPrimitivePositive(
      coord,
      subtile,
      best_candidate->primitive,
      best_candidate->final_weight,
      stamp);
    const int min_visibility_rays =
      best_candidate->is_curve ? curve_min_visibility_rays_ : primitive_min_visibility_rays_;
    phantom_tile_map_.recomputePrimitiveConfidence(
      coord,
      subtile,
      best_candidate->primitive,
      min_visibility_rays,
      best_candidate->is_curve ? curve_min_visibility_rays_ : 3);
  }
}

std::vector<CanonicalSegmentKey> MapperNode::canonicalSegmentsNearPoint(
  double x,
  double y,
  const TileCoord & coord,
  double tolerance) const
{
  const double cx = static_cast<double>(coord.x) * tile_size_ + origin_x_;
  const double cy = static_cast<double>(coord.y) * tile_size_ + origin_y_;
  const double local_x = x - cx;
  const double local_y = y - cy;

  std::vector<CanonicalSegmentKey> segments;
  segments.reserve(4);

  for (int line = 0; line < 3; ++line) {
    for (int offset = 0; offset < 2; ++offset) {
      CanonicalSegmentKey horizontal;
      horizontal.orientation = CanonicalSegmentOrientation::Horizontal;
      horizontal.line = line;
      horizontal.offset = offset;
      if (segmentDistance(local_x, local_y, horizontal, tile_size_) <= tolerance) {
        segments.push_back(horizontal);
      }

      CanonicalSegmentKey vertical;
      vertical.orientation = CanonicalSegmentOrientation::Vertical;
      vertical.line = line;
      vertical.offset = offset;
      if (segmentDistance(local_x, local_y, vertical, tile_size_) <= tolerance) {
        segments.push_back(vertical);
      }
    }
  }

  return segments;
}

bool MapperNode::isTileWithinCurrentRadius(const TileCoord & coord, int radius) const
{
  std::optional<TileCoord> current = previous_current_tile_;
  if (!current) {
    if (!origin_initialized_ || !latest_odom_) {
      return false;
    }

    current = computeTileCoord(
      latest_odom_->pose.pose.position.x,
      latest_odom_->pose.pose.position.y,
      origin_x_,
      origin_y_,
      tile_size_);
  }

  const int dx = coord.x >= current->x ? coord.x - current->x : current->x - coord.x;
  const int dy = coord.y >= current->y ? coord.y - current->y : current->y - coord.y;
  return std::max(dx, dy) <= radius;
}

void MapperNode::publishTimerCallback()
{
  const auto stamp = get_clock()->now();

  processPendingScans();
  maybePublishMapperStatus(stamp);

  if (!mapping_active_) {
    return;
  }

  if (publish_phantom_tiles_ && phantom_tile_markers_pub_) {
    phantom_tile_markers_pub_->publish(buildPhantomTileMarkers(stamp));
  }

  if (!latest_odom_ || !origin_initialized_) {
    return;
  }

  tile_markers_pub_->publish(buildTileMarkers(*latest_odom_));

  if (previous_current_tile_) {
    const auto record_iter = tile_map_.records().find(*previous_current_tile_);
    if (record_iter != tile_map_.records().end()) {
      publishCurrentTile(record_iter->second, stamp);
    }
  }

  maybePublishSemanticMapJson(stamp);

  if (publish_lidar_debug_points_ && latest_lidar_debug_odom_ && latest_lidar_debug_scan_) {
    lidar_points_pub_->publish(
      buildLidarDebugMarker(*latest_lidar_debug_odom_, *latest_lidar_debug_scan_));
  }
}

void MapperNode::initializeOriginFromPose(double x, double y)
{
  origin_x_ = x;
  origin_y_ = y;
  origin_initialized_ = true;

  RCLCPP_INFO(
    get_logger(),
    "Initialized tile origin from first odometry pose: origin_x=%.4f origin_y=%.4f",
    origin_x_,
    origin_y_);
  logRobotEvent(
    "tile_origin_initialized",
    {
      {"origin_xy", "(" + numberText(origin_x_, 4) + "," + numberText(origin_y_, 4) + ")"},
      {"tile_size", numberText(tile_size_, 3)},
      {"connection_id", std::to_string(bridge_connection_id_)},
      {"source", "odometry"},
    });

  if (origin_initialization_after_activation_pending_) {
    origin_initialization_after_activation_pending_ = false;
    RCLCPP_INFO(
      get_logger(),
      "ros2_mapper tile origin initialized after activation: x=%.4f y=%.4f",
      origin_x_,
      origin_y_);
  }

  if (mark_origin_tile_as_start_) {
    const auto coord = computeTileCoord(x, y, origin_x_, origin_y_, tile_size_);
    const auto center = tileCenter(coord, origin_x_, origin_y_, tile_size_);

    const auto stamp = get_clock()->now();
    auto & record = tile_map_.markStart(coord, center, stamp);
    updateCurrentAreaFromRecord(record, stamp);

    RCLCPP_INFO(
      get_logger(),
      "Marked origin tile as start: coord=(%d,%d)",
      coord.x,
      coord.y);
  }
}

void MapperNode::detectTeleportIfNeeded(const nav_msgs::msg::Odometry & odom)
{
  if (!teleport_detection_enabled_ || !latest_odom_) {
    return;
  }

  const double dx = odom.pose.pose.position.x - latest_odom_->pose.pose.position.x;
  const double dy = odom.pose.pose.position.y - latest_odom_->pose.pose.position.y;
  const double distance_delta = std::hypot(dx, dy);

  const double yaw = yawFromQuaternion(odom.pose.pose.orientation);
  const double previous_yaw = yawFromQuaternion(latest_odom_->pose.pose.orientation);
  const double yaw_delta = std::fabs(normalizeAngle(yaw - previous_yaw));

  if (
    distance_delta > teleport_distance_threshold_m_ ||
    yaw_delta > teleport_yaw_threshold_rad_)
  {
    if (pending_transition_crossing_) {
      const auto transition_tile = pending_transition_crossing_->tile;
      const auto transition_color = pending_transition_crossing_->color;
      clearPendingTransitionCrossing();
      logRobotEvent(
        "area_transition_cancelled",
        {
          {"transition_color", floorColorClassToLogString(transition_color)},
          {"transition_tile", tileCoordToJson(transition_tile)},
          {"current_area", tileAreaToString(current_area_)},
          {"reason", "pose_discontinuity"},
          {"connection_id", std::to_string(bridge_connection_id_)},
        });
    }

    const auto now = get_clock()->now();
    lidar_integration_blocked_until_ =
      now + rclcpp::Duration::from_seconds(lidar_skip_after_teleport_s_);

    RCLCPP_WARN(
      get_logger(),
      "Pose discontinuity detected: distance_delta=%.3f m yaw_delta=%.3f rad. "
      "Keeping mapper origin and state. Blocking phantom LiDAR integration for %.2f s.",
      distance_delta,
      yaw_delta,
      lidar_skip_after_teleport_s_);

    if (origin_initialized_) {
      const auto coord = computeTileCoord(
        odom.pose.pose.position.x,
        odom.pose.pose.position.y,
        origin_x_,
        origin_y_,
        tile_size_);
      publishMapperEvent(teleportEventJson(distance_delta, yaw_delta, coord, now));
    }
  }
}

void MapperNode::updateCurrentTile(const nav_msgs::msg::Odometry & odom)
{
  if (!origin_initialized_) {
    return;
  }

  const auto coord = computeTileCoord(
    odom.pose.pose.position.x,
    odom.pose.pose.position.y,
    origin_x_,
    origin_y_,
    tile_size_);

  const auto center = tileCenter(coord, origin_x_, origin_y_, tile_size_);
  const rclcpp::Time stamp(odom.header.stamp);

  auto & record = tile_map_.markVisited(coord, center, stamp);

  const auto event_stamp = get_clock()->now();

  if (!previous_current_tile_) {
    if (record.area == TileArea::Unknown) {
      assignCurrentAreaToRecord(record, stamp);
    }

    previous_current_tile_ = coord;
    publishCurrentTile(record, event_stamp);

    logRobotEvent(
      "tile_changed",
      {
        {"previous_tile", "none"},
        {"new_tile", tileCoordToJson(coord)},
        {"robot_xy", "(" + numberText(odom.pose.pose.position.x, 4) + "," + numberText(odom.pose.pose.position.y, 4) + ")"},
        {"origin_xy", "(" + numberText(origin_x_, 4) + "," + numberText(origin_y_, 4) + ")"},
        {"tile_size", numberText(tile_size_, 3)},
        {"visited_count", std::to_string(tile_map_.visitedCount())},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });

    return;
  }

  if (!(*previous_current_tile_ == coord)) {
    const auto previous_coord = *previous_current_tile_;

    updatePendingTransitionCrossing(previous_coord, coord, stamp);

    if (record.area == TileArea::Unknown) {
      assignCurrentAreaToRecord(record, stamp);
    }

    if (log_tile_changes_) {
      RCLCPP_INFO(
        get_logger(),
        "Tile changed: previous=(%d,%d) new=(%d,%d) visited=%zu",
        previous_coord.x,
        previous_coord.y,
        coord.x,
        coord.y,
        tile_map_.visitedCount());
    }

    publishMapperEvent(tileChangedEventJson(previous_coord, record, event_stamp));

    logRobotEvent(
      "tile_changed",
      {
        {"previous_tile", tileCoordToJson(previous_coord)},
        {"new_tile", tileCoordToJson(coord)},
        {"robot_xy", "(" + numberText(odom.pose.pose.position.x, 4) + "," + numberText(odom.pose.pose.position.y, 4) + ")"},
        {"origin_xy", "(" + numberText(origin_x_, 4) + "," + numberText(origin_y_, 4) + ")"},
        {"tile_size", numberText(tile_size_, 3)},
        {"visited_count", std::to_string(tile_map_.visitedCount())},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });

    tile_before_current_tile_ = previous_coord;
    previous_current_tile_ = coord;
    publishCurrentTile(record, event_stamp);
  } else if (record.area == TileArea::Unknown) {
    assignCurrentAreaToRecord(record, stamp);
  }
}
visualization_msgs::msg::MarkerArray MapperNode::buildTileMarkers(
  const nav_msgs::msg::Odometry & odom) const
{
  const auto coord = computeTileCoord(
    odom.pose.pose.position.x,
    odom.pose.pose.position.y,
    origin_x_,
    origin_y_,
    tile_size_);

  auto center = tileCenter(coord, origin_x_, origin_y_, tile_size_);
  const rclcpp::Time stamp = get_clock()->now();

  visualization_msgs::msg::MarkerArray markers;

  if (publish_visited_tiles_) {
    for (const auto & entry : tile_map_.records()) {
      if (entry.second.visited || hasSemanticState(entry.second)) {
        markers.markers.push_back(buildVisitedTileMarker(entry.second, stamp));
      }
    }
  }

  markers.markers.push_back(buildCurrentTileMarker(center, stamp));
  markers.markers.push_back(buildCurrentTileCenterMarker(center, stamp));
  return markers;
}

visualization_msgs::msg::Marker MapperNode::buildVisitedTileMarker(
  const TileRecord & record,
  const rclcpp::Time & stamp) const
{
  visualization_msgs::msg::Marker marker;
  marker.header.frame_id = marker_frame_;
  marker.header.stamp = markerStamp(stamp);
  marker.ns = "visited_tiles";
  marker.id = record.marker_id;
  marker.type = visualization_msgs::msg::Marker::CUBE;
  marker.action = visualization_msgs::msg::Marker::ADD;
  marker.pose.position = record.center;
  marker.pose.position.z = visited_tile_marker_z_;
  marker.pose.orientation.w = 1.0;
  marker.scale.x = tile_size_;
  marker.scale.y = tile_size_;
  marker.scale.z = visited_tile_marker_height_;
  applyVisitedTileColor(record, marker);

  return marker;
}

void MapperNode::applyVisitedTileColor(
  const TileRecord & record,
  visualization_msgs::msg::Marker & marker) const
{
  // Cor padrão dos tiles visitados
  marker.color.r = static_cast<float>(visited_tile_color_r_);
  marker.color.g = static_cast<float>(visited_tile_color_g_);
  marker.color.b = static_cast<float>(visited_tile_color_b_);
  marker.color.a = static_cast<float>(visited_tile_alpha_);

  if (!publish_semantic_tile_colors_) {
    return;
  }

  // Buraco ou bloqueado
  if (record.is_hole || record.is_blocked) {
    marker.color.r = 0.05f;
    marker.color.g = 0.0f;
    marker.color.b = 0.0f;
    marker.color.a = static_cast<float>(semantic_tile_alpha_);
    return;
  }

  // Checkpoint
  if (record.is_checkpoint) {
    marker.color.r = 0.52f;
    marker.color.g = 0.52f;
    marker.color.b = 0.49f;
    marker.color.a = 0.90f;
    return;
  }

  // Início
  if (record.is_start) {
    marker.color.r = 0.0f;
    marker.color.g = 1.0f;
    marker.color.b = 0.2f;
    marker.color.a = static_cast<float>(semantic_tile_alpha_);
    return;
  }

  // Swamp
  if (record.is_swamp) {
    marker.color.r = 0.45f;
    marker.color.g = 0.25f;
    marker.color.b = 0.10f;
    marker.color.a = static_cast<float>(semantic_tile_alpha_);
    return;
  }

  // Tiles de transição continuam tendo prioridade visual
  if (record.is_transition) {
    switch (record.floor_color) {
      case FloorColorClass::BlueArea1To2:
        marker.color.r = 0.0f;
        marker.color.g = 0.25f;
        marker.color.b = 1.0f;
        break;

      case FloorColorClass::YellowArea1To3:
        marker.color.r = 1.0f;
        marker.color.g = 0.9f;
        marker.color.b = 0.0f;
        break;

      case FloorColorClass::GreenArea1To4:
        marker.color.r = 0.0f;
        marker.color.g = 0.8f;
        marker.color.b = 0.2f;
        break;

      case FloorColorClass::PurpleArea2To3:
        marker.color.r = 0.55f;
        marker.color.g = 0.1f;
        marker.color.b = 0.9f;
        break;

      case FloorColorClass::OrangeArea2To4:
        marker.color.r = 1.0f;
        marker.color.g = 0.45f;
        marker.color.b = 0.0f;
        break;

      case FloorColorClass::RedArea3To4:
        marker.color.r = 1.0f;
        marker.color.g = 0.0f;
        marker.color.b = 0.0f;
        break;

      default:
        marker.color.r = 0.7f;
        marker.color.g = 0.7f;
        marker.color.b = 0.7f;
        break;
    }

    marker.color.a = static_cast<float>(semantic_tile_alpha_);
    return;
  }

  // Area 2: azul/ciano forte
  if (record.area == TileArea::Area2) {
    marker.color.r = 0.0f;
    marker.color.g = 0.65f;
    marker.color.b = 1.0f;
    marker.color.a = static_cast<float>(semantic_tile_alpha_);
    return;
  }

  // Area 3: rosa/magenta
  if (record.area == TileArea::Area3) {
    marker.color.r = 1.0f;
    marker.color.g = 0.2f;
    marker.color.b = 0.85f;
    marker.color.a = static_cast<float>(semantic_tile_alpha_);
    return;
  }

  // Area 4: mantém a cor que você já tinha
  if (record.kind == TileKind::Area4Generic || record.area == TileArea::Area4) {
    marker.color.r = 0.65f;
    marker.color.g = 1.0f;
    marker.color.b = 0.0f;
    marker.color.a = static_cast<float>(semantic_tile_alpha_);
    return;
  }
}
visualization_msgs::msg::Marker MapperNode::buildCurrentTileMarker(
  const geometry_msgs::msg::Point & center,
  const rclcpp::Time & stamp) const
{
  visualization_msgs::msg::Marker marker;
  marker.header.frame_id = marker_frame_;
  marker.header.stamp = markerStamp(stamp);
  marker.ns = "current_tile";
  marker.id = 0;
  marker.type = visualization_msgs::msg::Marker::CUBE;
  marker.action = visualization_msgs::msg::Marker::ADD;
  marker.pose.position = center;
  marker.pose.position.z = current_tile_marker_z_;
  marker.pose.orientation.w = 1.0;
  marker.scale.x = tile_size_;
  marker.scale.y = tile_size_;
  marker.scale.z = current_tile_marker_height_;
  marker.color.r = static_cast<float>(current_tile_color_r_);
  marker.color.g = static_cast<float>(current_tile_color_g_);
  marker.color.b = static_cast<float>(current_tile_color_b_);
  marker.color.a = static_cast<float>(current_tile_alpha_);
  return marker;
}

visualization_msgs::msg::Marker MapperNode::buildCurrentTileCenterMarker(
  const geometry_msgs::msg::Point & center,
  const rclcpp::Time & stamp) const
{
  visualization_msgs::msg::Marker marker;
  marker.header.frame_id = marker_frame_;
  marker.header.stamp = markerStamp(stamp);
  marker.ns = "current_tile_center";
  marker.id = 1;
  marker.type = visualization_msgs::msg::Marker::SPHERE;
  marker.action = visualization_msgs::msg::Marker::ADD;
  marker.pose.position = center;
  marker.pose.position.z = current_tile_center_z_;
  marker.pose.orientation.w = 1.0;
  const double diameter = current_tile_center_radius_ * 2.0;
  marker.scale.x = diameter;
  marker.scale.y = diameter;
  marker.scale.z = diameter;
  marker.color.r = 1.0f;
  marker.color.g = 0.9f;
  marker.color.b = 0.1f;
  marker.color.a = 1.0f;
  return marker;
}

builtin_interfaces::msg::Time MapperNode::markerStamp(const rclcpp::Time & stamp) const
{
  if (marker_use_latest_tf_stamp_) {
    return builtin_interfaces::msg::Time{};
  }

  builtin_interfaces::msg::Time msg;
  const int64_t ns = stamp.nanoseconds();
  msg.sec = static_cast<int32_t>(ns / 1000000000LL);
  msg.nanosec = static_cast<uint32_t>(ns % 1000000000LL);
  return msg;
}

visualization_msgs::msg::Marker MapperNode::buildLidarDebugMarker(
  const nav_msgs::msg::Odometry & odom,
  const sensor_msgs::msg::LaserScan & scan) const
{
  visualization_msgs::msg::Marker marker;
  marker.header.frame_id = marker_frame_;
  marker.header.stamp = get_clock()->now();
  marker.ns = "mapper_lidar_debug";
  marker.id = 0;
  marker.type = visualization_msgs::msg::Marker::POINTS;
  marker.action = visualization_msgs::msg::Marker::ADD;
  marker.pose.orientation.w = 1.0;
  marker.scale.x = lidar_debug_point_size_;
  marker.scale.y = lidar_debug_point_size_;
  marker.color.r = 0.0f;
  marker.color.g = 1.0f;
  marker.color.b = 0.3f;
  marker.color.a = 1.0f;

  const double robot_x = odom.pose.pose.position.x;
  const double robot_y = odom.pose.pose.position.y;
  const double yaw = yawFromQuaternion(odom.pose.pose.orientation);
  const double cos_yaw = std::cos(yaw);
  const double sin_yaw = std::sin(yaw);

  marker.points.reserve(scan.ranges.size() / static_cast<std::size_t>(lidar_debug_point_stride_) + 1);

  for (std::size_t i = 0; i < scan.ranges.size(); i += static_cast<std::size_t>(lidar_debug_point_stride_)) {
    const double range = scan.ranges[i];
    if (!std::isfinite(range)) {
      continue;
    }
    if (range < lidar_debug_min_range_ || range > lidar_debug_max_range_) {
      continue;
    }

    const double angle = static_cast<double>(scan.angle_min) +
      static_cast<double>(i) * static_cast<double>(scan.angle_increment);
    const double lx = range * std::cos(angle);
    const double ly = range * std::sin(angle);

    geometry_msgs::msg::Point point;
    point.x = robot_x + cos_yaw * lx - sin_yaw * ly;
    point.y = robot_y + sin_yaw * lx + cos_yaw * ly;
    point.z = lidar_debug_z_;
    marker.points.push_back(point);
  }

  return marker;
}

visualization_msgs::msg::MarkerArray MapperNode::buildPhantomTileMarkers(
  const rclcpp::Time & stamp)
{
  visualization_msgs::msg::MarkerArray markers;
  const auto visual_stamp = markerStamp(stamp);
  if (phantom_tile_map_.empty()) {
    return markers;
  }

  const bool summary_mode = phantom_visual_mode_ == "summary";

  for (const auto & entry : phantom_tile_map_.records()) {
    phantom_tile_map_.decayPrimitiveEvidenceTile(entry.first, stamp);
    for (std::size_t subtile_i = 0; subtile_i < entry.second.subtiles.size(); ++subtile_i) {
      const auto subtile = static_cast<SubtileIndex>(subtile_i);
      for (const auto primitive : edgePrimitiveKinds()) {
        phantom_tile_map_.recomputePrimitiveConfidence(
          entry.first,
          subtile,
          primitive,
          primitive_min_visibility_rays_);
      }
      for (const auto primitive : curvePrimitiveKinds()) {
        phantom_tile_map_.recomputePrimitiveConfidence(
          entry.first,
          subtile,
          primitive,
          curve_min_visibility_rays_,
          curve_min_visibility_rays_);
      }
    }

    if (enable_obstacle_primitives_) {
      phantom_tile_map_.decayObstacleGridTile(entry.first, obstacle_grid_bins_per_tile_, stamp);
      auto & mutable_evidence = phantom_tile_map_.getOrCreate(entry.first, stamp);
      const auto candidate = detectObstacleClusterFromGrid(
        mutable_evidence,
        obstacle_grid_bins_per_tile_,
        tile_size_,
        obstacle_bin_occupied_threshold_,
        obstacle_bin_free_margin_,
        obstacle_min_cluster_bins_,
        obstacle_min_total_hits_,
        obstacle_min_confidence_,
        obstacle_max_free_ratio_,
        obstacle_min_distance_from_tile_edge_m_,
        obstacle_min_box_size_m_,
        obstacle_max_box_size_m_,
        obstacle_box_padding_m_,
        obstacle_surrounding_ring_bins_,
        obstacle_min_surrounding_free_ratio_,
        obstacle_wall_overlap_penalty_,
        obstacle_edge_proximity_penalty_,
        primitive_wall_thickness_m_,
        primitive_wall_margin_m_,
        primitive_debug_min_confidence_,
        curve_debug_min_confidence_,
        curve_proto_inner_radius_,
        curve_proto_outer_radius_,
        curve_radius_offset_m_,
        curve_wall_margin_m_);

      mutable_evidence.obstacle.has_candidate = candidate.valid;
      mutable_evidence.obstacle.center_local_x = candidate.center_local_x;
      mutable_evidence.obstacle.center_local_y = candidate.center_local_y;
      mutable_evidence.obstacle.width_m = candidate.width_m;
      mutable_evidence.obstacle.length_m = candidate.length_m;
      mutable_evidence.obstacle.hit_score = candidate.hit_score;
      mutable_evidence.obstacle.free_conflict_score = candidate.free_score;
      mutable_evidence.obstacle.confidence = candidate.confidence;
      mutable_evidence.obstacle.free_ratio = candidate.free_ratio;
      mutable_evidence.obstacle.surrounding_free_ratio = candidate.surrounding_free_ratio;
      mutable_evidence.obstacle.wall_overlap_penalty = candidate.wall_overlap_penalty;
      mutable_evidence.obstacle.edge_proximity_penalty = candidate.edge_proximity_penalty;
      mutable_evidence.obstacle.cluster_bins = candidate.cluster_bins;
      mutable_evidence.obstacle.hit_count = candidate.total_hits;
      mutable_evidence.obstacle.free_conflicts = candidate.free_count;
      mutable_evidence.obstacle.last_seen = stamp;
    }

    const auto & evidence = entry.second;
    const double tile_center_x = static_cast<double>(evidence.coord.x) * tile_size_ + origin_x_;
    const double tile_center_y = static_cast<double>(evidence.coord.y) * tile_size_ + origin_y_;

    if (publish_phantom_tile_background_) {
      visualization_msgs::msg::Marker marker;
      marker.header.frame_id = marker_frame_;
      marker.header.stamp = visual_stamp;
      marker.ns = "phantom_tiles";
      marker.id = phantomTileMarkerId(evidence.coord);
      marker.type = visualization_msgs::msg::Marker::CUBE;
      marker.action = visualization_msgs::msg::Marker::ADD;
      marker.pose.position.x = tile_center_x;
      marker.pose.position.y = tile_center_y;
      marker.pose.position.z = phantom_tile_marker_z_;
      marker.pose.orientation.w = 1.0;
      marker.scale.x = tile_size_;
      marker.scale.y = tile_size_;
      marker.scale.z = phantom_tile_marker_height_;
      marker.color.r = 1.0f;
      marker.color.g = 0.15f;
      marker.color.b = 0.75f;
      marker.color.a = static_cast<float>(phantom_tile_marker_alpha_);
      markers.markers.push_back(marker);
    }

    if (publish_phantom_quadrant_debug_) {
      for (std::size_t i = 0; i < evidence.quadrants.size(); ++i) {
        const auto quadrant = static_cast<TileQuadrant>(i);
        const auto & quadrant_evidence = evidence.quadrants[i];
        const bool has_possible_or_free =
          quadrant_evidence.possible_rays > 0 || quadrant_evidence.free_rays > 0;

        if (has_possible_or_free) {
          visualization_msgs::msg::Marker quadrant_marker;
          quadrant_marker.header.frame_id = marker_frame_;
          quadrant_marker.header.stamp = visual_stamp;
          quadrant_marker.ns = "phantom_quadrants_free";
          quadrant_marker.id = phantomQuadrantFreeMarkerId(evidence.coord, quadrant);
          quadrant_marker.type = visualization_msgs::msg::Marker::CUBE;
          quadrant_marker.action = visualization_msgs::msg::Marker::ADD;
          quadrant_marker.pose.position.x =
            tile_center_x + quadrantOffsetX(quadrant, tile_size_);
          quadrant_marker.pose.position.y =
            tile_center_y + quadrantOffsetY(quadrant, tile_size_);
          quadrant_marker.pose.position.z = phantom_quadrant_marker_z_;
          quadrant_marker.pose.orientation.w = 1.0;
          quadrant_marker.scale.x = tile_size_ * 0.5;
          quadrant_marker.scale.y = tile_size_ * 0.5;
          quadrant_marker.scale.z = phantom_quadrant_marker_height_;
          quadrant_marker.color.r = 0.10f;
          quadrant_marker.color.g = 0.75f;
          quadrant_marker.color.b = 1.00f;
          quadrant_marker.color.a = static_cast<float>(
            evidenceAlpha(
              quadrant_evidence.free_range_weight_sum > 0.0 ?
              quadrant_evidence.free_range_weight_sum :
              quadrant_evidence.range_weight_sum,
              phantom_quadrant_marker_alpha_min_,
              phantom_quadrant_marker_alpha_max_));
          markers.markers.push_back(quadrant_marker);
        }

        if (quadrant_evidence.hit_count > 0) {
          visualization_msgs::msg::Marker hit_marker;
          hit_marker.header.frame_id = marker_frame_;
          hit_marker.header.stamp = visual_stamp;
          hit_marker.ns = "phantom_quadrants_hit";
          hit_marker.id = phantomQuadrantHitMarkerId(evidence.coord, quadrant);
          hit_marker.type = visualization_msgs::msg::Marker::CUBE;
          hit_marker.action = visualization_msgs::msg::Marker::ADD;
          hit_marker.pose.position.x = tile_center_x + quadrantOffsetX(quadrant, tile_size_);
          hit_marker.pose.position.y = tile_center_y + quadrantOffsetY(quadrant, tile_size_);
          hit_marker.pose.position.z = phantom_quadrant_marker_z_;
          hit_marker.pose.orientation.w = 1.0;
          hit_marker.scale.x = tile_size_ * 0.5;
          hit_marker.scale.y = tile_size_ * 0.5;
          hit_marker.scale.z = phantom_quadrant_marker_height_;
          hit_marker.color.r = 1.00f;
          hit_marker.color.g = 0.25f;
          hit_marker.color.b = 0.05f;
          hit_marker.color.a = static_cast<float>(
            evidenceAlpha(
              quadrant_evidence.hit_range_weight_sum,
              phantom_quadrant_marker_alpha_min_,
              phantom_quadrant_marker_alpha_max_));
          markers.markers.push_back(hit_marker);
        }
      }
    }

    if (publish_quarter_edge_debug_) {
      for (std::size_t i = 0; i < evidence.quarter_edges.size(); ++i) {
        const auto segment = canonicalSegmentFromIndex(i);
        const auto & edge = evidence.quarter_edges[i];
        const bool horizontal =
          segment.orientation == CanonicalSegmentOrientation::Horizontal;
        const double center_x =
          tile_center_x + segmentCenterLocalX(segment, tile_size_);
        const double center_y =
          tile_center_y + segmentCenterLocalY(segment, tile_size_);

        if (edge.hit_support > 0 || edge.raw_score > 0.0) {
          visualization_msgs::msg::Marker positive_marker;
          positive_marker.header.frame_id = marker_frame_;
          positive_marker.header.stamp = visual_stamp;
          positive_marker.ns = "phantom_quarter_edges_positive";
          positive_marker.id = phantomQuarterEdgePositiveMarkerId(evidence.coord, segment);
          positive_marker.type = visualization_msgs::msg::Marker::CUBE;
          positive_marker.action = visualization_msgs::msg::Marker::ADD;
          positive_marker.pose.position.x = center_x;
          positive_marker.pose.position.y = center_y;
          positive_marker.pose.position.z = quarter_edge_marker_z_;
          positive_marker.pose.orientation.w = 1.0;
          positive_marker.scale.x = horizontal ? tile_size_ * 0.5 : quarter_edge_marker_thickness_;
          positive_marker.scale.y = horizontal ? quarter_edge_marker_thickness_ : tile_size_ * 0.5;
          positive_marker.scale.z = quarter_edge_marker_thickness_;
          positive_marker.color.r = 0.20f;
          positive_marker.color.g = 1.00f;
          positive_marker.color.b = 0.25f;
          positive_marker.color.a = static_cast<float>(
            evidenceAlpha(
              edge.hit_score > 0.0 ? edge.hit_score : edge.raw_score,
              quarter_edge_marker_alpha_min_,
              quarter_edge_marker_alpha_max_));
          markers.markers.push_back(positive_marker);
        }

        if (edge.free_conflicts > 0) {
          visualization_msgs::msg::Marker conflict_marker;
          conflict_marker.header.frame_id = marker_frame_;
          conflict_marker.header.stamp = visual_stamp;
          conflict_marker.ns = "phantom_quarter_edges_conflict";
          conflict_marker.id = phantomQuarterEdgeConflictMarkerId(evidence.coord, segment);
          conflict_marker.type = visualization_msgs::msg::Marker::CUBE;
          conflict_marker.action = visualization_msgs::msg::Marker::ADD;
          conflict_marker.pose.position.x = center_x;
          conflict_marker.pose.position.y = center_y;
          conflict_marker.pose.position.z = quarter_edge_marker_z_;
          conflict_marker.pose.orientation.w = 1.0;
          conflict_marker.scale.x = horizontal ? tile_size_ * 0.5 : quarter_edge_marker_thickness_;
          conflict_marker.scale.y = horizontal ? quarter_edge_marker_thickness_ : tile_size_ * 0.5;
          conflict_marker.scale.z = quarter_edge_marker_thickness_;
          conflict_marker.color.r = 1.00f;
          conflict_marker.color.g = 0.05f;
          conflict_marker.color.b = 0.10f;
          conflict_marker.color.a = static_cast<float>(
            evidenceAlpha(
              edge.free_conflict_score,
              quarter_edge_marker_alpha_min_,
              quarter_edge_marker_alpha_max_));
          markers.markers.push_back(conflict_marker);
        }
      }
    }

    if (publish_primitive_debug_) {
      for (std::size_t subtile_i = 0; subtile_i < evidence.subtiles.size(); ++subtile_i) {
        const auto subtile = static_cast<SubtileIndex>(subtile_i);
        const auto & subtile_evidence = evidence.subtiles[subtile_i];

        for (const auto primitive : edgePrimitiveKinds()) {
          const int index = primitiveIndex(primitive);
          if (index < 0) {
            continue;
          }

          const auto & primitive_evidence =
            subtile_evidence.primitives[static_cast<std::size_t>(index)];
          if (
            primitive_evidence.log_odds <= 0.0 ||
            primitive_evidence.confidence < primitive_debug_min_confidence_)
          {
            continue;
          }

          const bool horizontal = primitiveIsHorizontal(primitive);

          visualization_msgs::msg::Marker primitive_marker;
          primitive_marker.header.frame_id = marker_frame_;
          primitive_marker.header.stamp = visual_stamp;
          primitive_marker.ns = "phantom_primitive_edges";
          primitive_marker.id = phantomPrimitiveMarkerId(evidence.coord, subtile, primitive);
          primitive_marker.type = visualization_msgs::msg::Marker::CUBE;
          primitive_marker.action = visualization_msgs::msg::Marker::ADD;
          primitive_marker.pose.position.x =
            tile_center_x + primitiveCenterLocalX(subtile, primitive, tile_size_);
          primitive_marker.pose.position.y =
            tile_center_y + primitiveCenterLocalY(subtile, primitive, tile_size_);
          primitive_marker.pose.position.z = primitive_debug_marker_z_;
          primitive_marker.pose.orientation.w = 1.0;
          primitive_marker.scale.x =
            horizontal ? tile_size_ * 0.5 : primitive_debug_marker_thickness_;
          primitive_marker.scale.y =
            horizontal ? primitive_debug_marker_thickness_ : tile_size_ * 0.5;
          primitive_marker.scale.z = primitive_debug_marker_thickness_;
          primitive_marker.color.r = static_cast<float>(primitive_debug_color_r_);
          primitive_marker.color.g = static_cast<float>(primitive_debug_color_g_);
          primitive_marker.color.b = static_cast<float>(primitive_debug_color_b_);
          primitive_marker.color.a = static_cast<float>(
            confidenceAlpha(
              primitive_evidence.confidence,
              primitive_debug_marker_alpha_min_,
              primitive_debug_marker_alpha_max_));
          markers.markers.push_back(primitive_marker);
        }
      }
    }

    if (publish_primitive_debug_) {
      for (std::size_t subtile_i = 0; subtile_i < evidence.subtiles.size(); ++subtile_i) {
        visualization_msgs::msg::Marker delete_old_subtile_marker;
        delete_old_subtile_marker.header.frame_id = marker_frame_;
        delete_old_subtile_marker.header.stamp = visual_stamp;
        delete_old_subtile_marker.ns = "phantom_primitive_obstacles";
        delete_old_subtile_marker.id = phantomPrimitiveMarkerId(
          evidence.coord,
          static_cast<SubtileIndex>(subtile_i),
          PrimitiveKind::Obstacle);
        delete_old_subtile_marker.action = visualization_msgs::msg::Marker::DELETE;
        markers.markers.push_back(delete_old_subtile_marker);
      }

      const auto & obstacle = evidence.obstacle;
      if (
        enable_obstacle_primitives_ &&
        obstacle.has_candidate &&
        obstacle.confidence >= obstacle_debug_min_confidence_)
      {
        visualization_msgs::msg::Marker obstacle_marker;
        obstacle_marker.header.frame_id = marker_frame_;
        obstacle_marker.header.stamp = visual_stamp;
        obstacle_marker.ns = "phantom_primitive_obstacles";
        obstacle_marker.id = phantomTileMarkerId(evidence.coord);
        obstacle_marker.type = visualization_msgs::msg::Marker::CUBE;
        obstacle_marker.action = visualization_msgs::msg::Marker::ADD;
        obstacle_marker.pose.position.x = tile_center_x + obstacle.center_local_x;
        obstacle_marker.pose.position.y = tile_center_y + obstacle.center_local_y;
        obstacle_marker.pose.position.z =
          primitive_debug_marker_z_ + primitive_debug_marker_thickness_;
        obstacle_marker.pose.orientation.w = 1.0;
        obstacle_marker.scale.x = std::max(obstacle.width_m, 0.001);
        obstacle_marker.scale.y = std::max(obstacle.length_m, 0.001);
        obstacle_marker.scale.z = primitive_debug_marker_thickness_;
        obstacle_marker.color.r = 1.00f;
        obstacle_marker.color.g = 0.58f;
        obstacle_marker.color.b = 0.08f;
        obstacle_marker.color.a = static_cast<float>(
          confidenceAlpha(
            obstacle.confidence,
            primitive_debug_marker_alpha_min_,
            primitive_debug_marker_alpha_max_));
        markers.markers.push_back(obstacle_marker);
      } else {
        visualization_msgs::msg::Marker delete_obstacle_marker;
        delete_obstacle_marker.header.frame_id = marker_frame_;
        delete_obstacle_marker.header.stamp = visual_stamp;
        delete_obstacle_marker.ns = "phantom_primitive_obstacles";
        delete_obstacle_marker.id = phantomTileMarkerId(evidence.coord);
        delete_obstacle_marker.action = visualization_msgs::msg::Marker::DELETE;
        markers.markers.push_back(delete_obstacle_marker);
      }

      if (enable_obstacle_primitives_ && publish_obstacle_grid_debug_) {
        const int obstacle_cell_count =
          obstacle_grid_bins_per_tile_ * obstacle_grid_bins_per_tile_;
        const double obstacle_bin_size =
          tile_size_ / static_cast<double>(obstacle_grid_bins_per_tile_);
        for (int bin_index = 0; bin_index < obstacle_cell_count; ++bin_index) {
          const auto & bin = evidence.obstacle_grid[static_cast<std::size_t>(bin_index)];
          const bool occupied =
            bin.hit_count > 0 &&
            bin.hit_score >= obstacle_bin_occupied_threshold_ &&
            bin.hit_score >= bin.free_score + obstacle_bin_free_margin_;
          if (!occupied) {
            continue;
          }

          const int row = bin_index / obstacle_grid_bins_per_tile_;
          const int col = bin_index % obstacle_grid_bins_per_tile_;
          visualization_msgs::msg::Marker bin_marker;
          bin_marker.header.frame_id = marker_frame_;
          bin_marker.header.stamp = visual_stamp;
          bin_marker.ns = "phantom_obstacle_grid_bins";
          bin_marker.id = phantomObstacleGridMarkerId(evidence.coord, bin_index);
          bin_marker.type = visualization_msgs::msg::Marker::CUBE;
          bin_marker.action = visualization_msgs::msg::Marker::ADD;
          bin_marker.pose.position.x =
            tile_center_x +
            obstacleGridBinCenterLocalX(col, tile_size_, obstacle_grid_bins_per_tile_);
          bin_marker.pose.position.y =
            tile_center_y +
            obstacleGridBinCenterLocalY(row, tile_size_, obstacle_grid_bins_per_tile_);
          bin_marker.pose.position.z = primitive_debug_marker_z_;
          bin_marker.pose.orientation.w = 1.0;
          bin_marker.scale.x = obstacle_bin_size;
          bin_marker.scale.y = obstacle_bin_size;
          bin_marker.scale.z = primitive_debug_marker_thickness_ * 0.5;
          bin_marker.color.r = 1.00f;
          bin_marker.color.g = 0.82f;
          bin_marker.color.b = 0.12f;
          bin_marker.color.a = static_cast<float>(
            confidenceAlpha(
              clamp01(bin.hit_score / std::max(obstacle_bin_occupied_threshold_, 1.0e-9)),
              primitive_debug_marker_alpha_min_,
              primitive_debug_marker_alpha_max_));
          markers.markers.push_back(bin_marker);
        }
      }
    }

    if (publish_curve_geometry_debug_ && enable_curve_primitives_) {
      for (std::size_t subtile_i = 0; subtile_i < evidence.subtiles.size(); ++subtile_i) {
        const auto subtile = static_cast<SubtileIndex>(subtile_i);

        for (const auto primitive : curvePrimitiveKinds()) {
          const auto geometry = curveGeometryFromProtoTransform(
            subtile,
            primitive,
            tile_size_,
            curve_proto_inner_radius_,
            curve_proto_outer_radius_,
            curve_radius_offset_m_,
            curve_wall_margin_m_);

          if (!curveGeometryIsValid(geometry)) {
            RCLCPP_WARN_THROTTLE(
              get_logger(),
              *get_clock(),
              5000,
              "Skipping debug curve with invalid radius: tile=(%d,%d) subtile=%d curve=%d",
              evidence.coord.x,
              evidence.coord.y,
              static_cast<int>(subtile),
              static_cast<int>(primitive));
            continue;
          }

          if (
            !curveGeometryMostlyInsideSubtile(
              subtile,
              geometry,
              tile_size_,
              curve_subtile_containment_tolerance_m_,
              curve_subtile_containment_required_fraction_))
          {
            RCLCPP_WARN_THROTTLE(
              get_logger(),
              *get_clock(),
              5000,
              "Skipping debug curve geometry outside subtile: tile=(%d,%d) subtile=%d curve=%d",
              evidence.coord.x,
              evidence.coord.y,
              static_cast<int>(subtile),
              static_cast<int>(primitive));
            continue;
          }

          const double radius = 0.5 * (geometry.inner_radius + geometry.outer_radius);
          const int segment_count = std::max(8, curve_coverage_bins_ * 4);

          visualization_msgs::msg::Marker curve_marker;
          curve_marker.header.frame_id = marker_frame_;
          curve_marker.header.stamp = visual_stamp;
          curve_marker.ns = "phantom_curve_geometry_candidates";
          curve_marker.id = phantomPrimitiveMarkerId(evidence.coord, subtile, primitive);
          curve_marker.type = visualization_msgs::msg::Marker::LINE_STRIP;
          curve_marker.action = visualization_msgs::msg::Marker::ADD;
          curve_marker.pose.orientation.w = 1.0;
          curve_marker.scale.x = std::max(0.001, geometry.outer_radius - geometry.inner_radius);
          curve_marker.color.r = static_cast<float>(curve_debug_color_r_);
          curve_marker.color.g = static_cast<float>(curve_debug_color_g_);
          curve_marker.color.b = static_cast<float>(curve_debug_color_b_);
          curve_marker.color.a = 0.05f;
          curve_marker.points.reserve(static_cast<std::size_t>(segment_count + 1));

          for (int i = 0; i <= segment_count; ++i) {
            const double u = static_cast<double>(i) / static_cast<double>(segment_count);
            const double angle = curveAngleAtProjection(geometry, u);

            geometry_msgs::msg::Point point;
            point.x = tile_center_x + geometry.center_x + radius * std::cos(angle);
            point.y = tile_center_y + geometry.center_y + radius * std::sin(angle);
            point.z = curve_debug_marker_z_;
            curve_marker.points.push_back(point);
          }

          markers.markers.push_back(curve_marker);
        }
      }
    }

    if (publish_curve_debug_ && enable_curve_primitives_) {
      for (std::size_t subtile_i = 0; subtile_i < evidence.subtiles.size(); ++subtile_i) {
        const auto subtile = static_cast<SubtileIndex>(subtile_i);
        const auto & subtile_evidence = evidence.subtiles[subtile_i];
        const PrimitiveEvidence * best_curve_evidence = nullptr;
        PrimitiveKind best_curve = PrimitiveKind::Empty;
        double second_curve_confidence = 0.0;

        for (const auto primitive : curvePrimitiveKinds()) {
          const int index = primitiveIndex(primitive);
          if (index < 0) {
            continue;
          }

          const auto & primitive_evidence =
            subtile_evidence.primitives[static_cast<std::size_t>(index)];
          if (primitive_evidence.log_odds <= 0.0) {
            continue;
          }

          if (
            best_curve_evidence == nullptr ||
            primitive_evidence.confidence > best_curve_evidence->confidence)
          {
            if (best_curve_evidence != nullptr) {
              second_curve_confidence =
                std::max(second_curve_confidence, best_curve_evidence->confidence);
            }
            best_curve_evidence = &primitive_evidence;
            best_curve = primitive;
            continue;
          }

          second_curve_confidence =
            std::max(second_curve_confidence, primitive_evidence.confidence);
        }

        bool render_best_curve =
          best_curve_evidence != nullptr &&
          best_curve_evidence->log_odds > 0.0 &&
          best_curve_evidence->confidence >= curve_debug_min_confidence_;
        CurveGeometry geometry;

        if (render_best_curve) {
          geometry = curveGeometryFromProtoTransform(
            subtile,
            best_curve,
            tile_size_,
            curve_proto_inner_radius_,
            curve_proto_outer_radius_,
            curve_radius_offset_m_,
            curve_wall_margin_m_);

          if (!curveGeometryIsValid(geometry)) {
            RCLCPP_WARN_THROTTLE(
              get_logger(),
              *get_clock(),
              5000,
              "Skipping rendered curve with invalid radius: tile=(%d,%d) subtile=%d curve=%d",
              evidence.coord.x,
              evidence.coord.y,
              static_cast<int>(subtile),
              static_cast<int>(best_curve));
            render_best_curve = false;
          }

          if (
            render_best_curve &&
            !curveGeometryMostlyInsideSubtile(
              subtile,
              geometry,
              tile_size_,
              curve_subtile_containment_tolerance_m_,
              curve_subtile_containment_required_fraction_))
          {
            RCLCPP_WARN_THROTTLE(
              get_logger(),
              *get_clock(),
              5000,
              "Skipping rendered curve geometry outside subtile: tile=(%d,%d) subtile=%d curve=%d",
              evidence.coord.x,
              evidence.coord.y,
              static_cast<int>(subtile),
              static_cast<int>(best_curve));
            render_best_curve = false;
          }
        }

        if (curve_debug_log_scores_ && best_curve_evidence != nullptr) {
          RCLCPP_INFO_THROTTLE(
            get_logger(),
            *get_clock(),
            static_cast<int>(std::max(1.0, curve_debug_log_period_s_ * 1000.0)),
            "curve_debug tile=(%d,%d) subtile=%d best=%d log_odds=%.3f hit=%.3f conflict=%.3f possible=%.3f visibility=%.3f coverage=%.3f confidence=%.3f second=%.3f render=%s",
            evidence.coord.x,
            evidence.coord.y,
            static_cast<int>(subtile),
            static_cast<int>(best_curve),
            best_curve_evidence->log_odds,
            best_curve_evidence->positive_score,
            best_curve_evidence->negative_score,
            best_curve_evidence->possible_weight_sum,
            best_curve_evidence->visibility_score,
            best_curve_evidence->coverage_score,
            best_curve_evidence->confidence,
            second_curve_confidence,
            render_best_curve ? "true" : "false");
        }

        for (const auto primitive : curvePrimitiveKinds()) {
          if (render_best_curve && primitive == best_curve) {
            continue;
          }

          visualization_msgs::msg::Marker delete_marker;
          delete_marker.header.frame_id = marker_frame_;
          delete_marker.header.stamp = visual_stamp;
          delete_marker.ns = "phantom_primitive_curves";
          delete_marker.id = phantomPrimitiveMarkerId(evidence.coord, subtile, primitive);
          delete_marker.action = visualization_msgs::msg::Marker::DELETE;
          markers.markers.push_back(delete_marker);
        }

        if (!render_best_curve) {
          continue;
        }

        const double radius = 0.5 * (geometry.inner_radius + geometry.outer_radius);
        const int segment_count = std::max(8, curve_coverage_bins_ * 4);

        visualization_msgs::msg::Marker curve_marker;
        curve_marker.header.frame_id = marker_frame_;
        curve_marker.header.stamp = visual_stamp;
        curve_marker.ns = "phantom_primitive_curves";
        curve_marker.id = phantomPrimitiveMarkerId(evidence.coord, subtile, best_curve);
        curve_marker.type = visualization_msgs::msg::Marker::LINE_STRIP;
        curve_marker.action = visualization_msgs::msg::Marker::ADD;
        curve_marker.pose.orientation.w = 1.0;
        curve_marker.scale.x = std::max(0.001, geometry.outer_radius - geometry.inner_radius);
        curve_marker.color.r = static_cast<float>(curve_debug_color_r_);
        curve_marker.color.g = static_cast<float>(curve_debug_color_g_);
        curve_marker.color.b = static_cast<float>(curve_debug_color_b_);
        curve_marker.color.a = static_cast<float>(
          confidenceAlpha(
            best_curve_evidence->confidence,
            curve_debug_marker_alpha_min_,
            curve_debug_marker_alpha_max_));
        curve_marker.points.reserve(static_cast<std::size_t>(segment_count + 1));

        for (int i = 0; i <= segment_count; ++i) {
          const double u = static_cast<double>(i) / static_cast<double>(segment_count);
          const double angle = curveAngleAtProjection(geometry, u);

          geometry_msgs::msg::Point point;
          point.x = tile_center_x + geometry.center_x + radius * std::cos(angle);
          point.y = tile_center_y + geometry.center_y + radius * std::sin(angle);
          point.z = curve_debug_marker_z_;
          curve_marker.points.push_back(point);
        }

        markers.markers.push_back(curve_marker);
      }
    }

    if (publish_primitive_negative_debug_) {
      for (std::size_t subtile_i = 0; subtile_i < evidence.subtiles.size(); ++subtile_i) {
        const auto subtile = static_cast<SubtileIndex>(subtile_i);
        const auto & subtile_evidence = evidence.subtiles[subtile_i];

        for (const auto primitive : edgePrimitiveKinds()) {
          const int index = primitiveIndex(primitive);
          if (index < 0) {
            continue;
          }

          const auto & primitive_evidence =
            subtile_evidence.primitives[static_cast<std::size_t>(index)];
          if (
            primitive_evidence.log_odds >= 0.0 ||
            primitive_evidence.confidence < primitive_negative_debug_min_confidence_)
          {
            continue;
          }

          const bool horizontal = primitiveIsHorizontal(primitive);

          visualization_msgs::msg::Marker primitive_marker;
          primitive_marker.header.frame_id = marker_frame_;
          primitive_marker.header.stamp = visual_stamp;
          primitive_marker.ns = "phantom_primitive_edges_negative";
          primitive_marker.id =
            phantomPrimitiveNegativeMarkerId(evidence.coord, subtile, primitive);
          primitive_marker.type = visualization_msgs::msg::Marker::CUBE;
          primitive_marker.action = visualization_msgs::msg::Marker::ADD;
          primitive_marker.pose.position.x =
            tile_center_x + primitiveCenterLocalX(subtile, primitive, tile_size_);
          primitive_marker.pose.position.y =
            tile_center_y + primitiveCenterLocalY(subtile, primitive, tile_size_);
          primitive_marker.pose.position.z = primitive_debug_marker_z_;
          primitive_marker.pose.orientation.w = 1.0;
          primitive_marker.scale.x =
            horizontal ? tile_size_ * 0.5 : primitive_debug_marker_thickness_;
          primitive_marker.scale.y =
            horizontal ? primitive_debug_marker_thickness_ : tile_size_ * 0.5;
          primitive_marker.scale.z = primitive_debug_marker_thickness_;
          primitive_marker.color.r = static_cast<float>(primitive_negative_debug_color_r_);
          primitive_marker.color.g = static_cast<float>(primitive_negative_debug_color_g_);
          primitive_marker.color.b = static_cast<float>(primitive_negative_debug_color_b_);
          primitive_marker.color.a = static_cast<float>(
            confidenceAlpha(
              primitive_evidence.confidence,
              primitive_negative_debug_marker_alpha_min_,
              primitive_negative_debug_marker_alpha_max_));
          markers.markers.push_back(primitive_marker);
        }
      }
    }

    const auto & candidate = evidence.best_mask_candidate;
    const bool should_render_mask =
      publish_phantom_mask_debug_ &&
      candidate.kind != PhantomMaskKind::Empty &&
      (!summary_mode || candidate.confidence >= phantom_summary_min_confidence_);

    if (should_render_mask) {
      const double alpha_min =
        summary_mode ? phantom_summary_marker_alpha_min_ : phantom_mask_marker_alpha_min_;
      const double alpha_max =
        summary_mode ? phantom_summary_marker_alpha_max_ : phantom_mask_marker_alpha_max_;

      for (std::size_t i = 0; i < candidate.segment_mask.size(); ++i) {
        if (!candidate.segment_mask[i]) {
          continue;
        }

        const auto segment = canonicalSegmentFromIndex(i);
        const bool horizontal =
          segment.orientation == CanonicalSegmentOrientation::Horizontal;

        visualization_msgs::msg::Marker mask_marker;
        mask_marker.header.frame_id = marker_frame_;
        mask_marker.header.stamp = visual_stamp;
        mask_marker.ns = "phantom_mask_best";
        mask_marker.id = phantomMaskMarkerId(evidence.coord, segment);
        mask_marker.type = visualization_msgs::msg::Marker::CUBE;
        mask_marker.action = visualization_msgs::msg::Marker::ADD;
        mask_marker.pose.position.x =
          tile_center_x + segmentCenterLocalX(segment, tile_size_);
        mask_marker.pose.position.y =
          tile_center_y + segmentCenterLocalY(segment, tile_size_);
        mask_marker.pose.position.z = phantom_mask_marker_z_;
        mask_marker.pose.orientation.w = 1.0;
        mask_marker.scale.x =
          horizontal ? tile_size_ * 0.5 : phantom_mask_marker_thickness_;
        mask_marker.scale.y =
          horizontal ? phantom_mask_marker_thickness_ : tile_size_ * 0.5;
        mask_marker.scale.z = phantom_mask_marker_thickness_;
        mask_marker.color.r = 0.70f;
        mask_marker.color.g = 0.95f;
        mask_marker.color.b = 1.00f;
        mask_marker.color.a = static_cast<float>(
          confidenceAlpha(candidate.confidence, alpha_min, alpha_max));
        markers.markers.push_back(mask_marker);
      }
    } else if (
      summary_mode &&
      publish_phantom_free_summary_ &&
      candidate.kind == PhantomMaskKind::Empty &&
      candidate.confidence >= phantom_summary_min_confidence_)
    {
      visualization_msgs::msg::Marker free_marker;
      free_marker.header.frame_id = marker_frame_;
      free_marker.header.stamp = visual_stamp;
      free_marker.ns = "phantom_free_summary";
      free_marker.id = phantomTileMarkerId(evidence.coord);
      free_marker.type = visualization_msgs::msg::Marker::CUBE;
      free_marker.action = visualization_msgs::msg::Marker::ADD;
      free_marker.pose.position.x = tile_center_x;
      free_marker.pose.position.y = tile_center_y;
      free_marker.pose.position.z = phantom_tile_marker_z_;
      free_marker.pose.orientation.w = 1.0;
      free_marker.scale.x = tile_size_;
      free_marker.scale.y = tile_size_;
      free_marker.scale.z = phantom_tile_marker_height_;
      free_marker.color.r = 0.55f;
      free_marker.color.g = 0.85f;
      free_marker.color.b = 1.00f;
      free_marker.color.a = static_cast<float>(
        phantom_free_summary_alpha_max_ * std::clamp(candidate.confidence, 0.0, 1.0));
      markers.markers.push_back(free_marker);
    }
  }

  return markers;
}

double MapperNode::yawFromQuaternion(const geometry_msgs::msg::Quaternion & q)
{
  const double siny_cosp = 2.0 * (q.w * q.z + q.x * q.y);
  const double cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z);
  return std::atan2(siny_cosp, cosy_cosp);
}

double MapperNode::normalizeAngle(double angle)
{
  while (angle > M_PI) {
    angle -= 2.0 * M_PI;
  }
  while (angle < -M_PI) {
    angle += 2.0 * M_PI;
  }
  return angle;
}

FloorColorClass MapperNode::parseFloorColorClass(const std::string & value)
{
  std::string key;
  key.reserve(value.size());

  for (const char c : value) {
    if (c == '-' || c == ' ') {
      key.push_back('_');
    } else {
      key.push_back(static_cast<char>(std::toupper(static_cast<unsigned char>(c))));
    }
  }

  if (key == "NORMAL") {
    return FloorColorClass::Normal;
  }
  if (key == "BLACK_HOLE_BORDER" || key == "BLACK" || key == "HOLE") {
    return FloorColorClass::BlackHoleBorder;
  }
  if (key == "SILVER_CHECKPOINT" || key == "SILVER" || key == "CHECKPOINT") {
    return FloorColorClass::SilverCheckpoint;
  }
  if (key == "BROWN_SWAMP" || key == "BROWN" || key == "SWAMP") {
    return FloorColorClass::BrownSwamp;
  }
  if (key == "BLUE_AREA_1_2" || key == "BLUE" || key == "AREA_1_2") {
    return FloorColorClass::BlueArea1To2;
  }
  if (key == "YELLOW_AREA_1_3" || key == "YELLOW" || key == "AREA_1_3") {
    return FloorColorClass::YellowArea1To3;
  }
  if (key == "GREEN_AREA_1_4" || key == "GREEN" || key == "AREA_1_4") {
    return FloorColorClass::GreenArea1To4;
  }
  if (key == "PURPLE_AREA_2_3" || key == "PURPLE" || key == "AREA_2_3") {
    return FloorColorClass::PurpleArea2To3;
  }
  if (key == "ORANGE_AREA_2_4" || key == "ORANGE" || key == "AREA_2_4") {
    return FloorColorClass::OrangeArea2To4;
  }
  if (key == "RED_AREA_3_4" || key == "RED" || key == "AREA_3_4") {
    return FloorColorClass::RedArea3To4;
  }

  return FloorColorClass::Unknown;
}

const char * MapperNode::tileAreaToString(TileArea area)
{
  switch (area) {
    case TileArea::Area1:
      return "area1";
    case TileArea::Area2:
      return "area2";
    case TileArea::Area3:
      return "area3";
    case TileArea::Area4:
      return "area4";
    case TileArea::Unknown:
      return "unknown";
  }

  return "unknown";
}

const char * MapperNode::tileKindToString(TileKind kind)
{
  switch (kind) {
    case TileKind::Normal:
      return "normal";
    case TileKind::Start:
      return "start";
    case TileKind::Hole:
      return "hole";
    case TileKind::Swamp:
      return "swamp";
    case TileKind::Checkpoint:
      return "checkpoint";
    case TileKind::Area4Generic:
      return "area4_generic";
    case TileKind::Transition:
      return "transition";
    case TileKind::Unknown:
      return "unknown";
  }

  return "unknown";
}

const char * MapperNode::hazardStateToString(HazardState state)
{
  switch (state) {
    case HazardState::None:
      return "none";
    case HazardState::Suspected:
      return "suspected";
    case HazardState::Confirmed:
      return "confirmed";
    case HazardState::Rejected:
      return "rejected";
  }

  return "none";
}

const char * MapperNode::hazardTypeToString(HazardType type)
{
  switch (type) {
    case HazardType::BlackHole:
      return "black_hole";
    case HazardType::Swamp:
      return "swamp";
    case HazardType::Checkpoint:
      return "checkpoint";
    case HazardType::ColoredArea:
      return "colored_area";
    case HazardType::Unknown:
      return "unknown";
  }

  return "unknown";
}

const char * MapperNode::hazardSourceToString(HazardSource source)
{
  switch (source) {
    case HazardSource::FloorColor:
      return "floor_color";
    case HazardSource::ControllerEvent:
      return "controller_event";
    case HazardSource::MapperFusion:
      return "mapper_fusion";
    case HazardSource::Unknown:
      return "unknown";
  }

  return "unknown";
}

const char * MapperNode::hazardEdgeToString(HazardEdge edge)
{
  switch (edge) {
    case HazardEdge::North:
      return "N";
    case HazardEdge::South:
      return "S";
    case HazardEdge::East:
      return "E";
    case HazardEdge::West:
      return "W";
    case HazardEdge::Unknown:
      return "UNKNOWN";
  }

  return "UNKNOWN";
}

std::string MapperNode::stampToJson(const rclcpp::Time & stamp)
{
  std::ostringstream oss;
  oss << std::fixed << std::setprecision(3) << stamp.seconds();
  return oss.str();
}

std::string MapperNode::tileCoordToJson(const TileCoord & coord)
{
  std::ostringstream oss;
  oss << "{\"x\":" << coord.x << ",\"y\":" << coord.y << "}";
  return oss.str();
}

std::string MapperNode::hazardJson(const TileRecord & record, const rclcpp::Time & stamp) const
{
  std::ostringstream oss;
  oss << std::fixed << std::setprecision(3);
  oss
    << "{\"state\":\"" << hazardStateToString(record.hazard_state)
    << "\",\"type\":\"" << hazardTypeToString(record.hazard_type)
    << "\",\"confidence\":" << std::clamp(record.hazard_confidence, 0.0, 1.0)
    << ",\"source\":\"" << hazardSourceToString(record.hazard_source)
    << "\",\"edge\":\"" << hazardEdgeToString(record.hazard_edge)
    << "\",\"hit_count\":" << record.hazard_hit_count
    << ",\"age_sec\":";

  if (record.hazard_last_seen.nanoseconds() != 0) {
    oss << std::max(0.0, (stamp - record.hazard_last_seen).seconds());
  } else {
    oss << "null";
  }

  oss << ",\"ttl_sec\":" << record.hazard_ttl_sec << "}";
  return oss.str();
}

std::optional<geometry_msgs::msg::TransformStamped> MapperNode::lookupTransformToSlamMapFrame(
  const std::string & source_frame) const
{
  if (!tf_buffer_) {
    return std::nullopt;
  }

  const auto status = slam_map_sampler_.status(get_clock()->now());
  if (!status.map_real || status.frame_id.empty() || source_frame.empty()) {
    return std::nullopt;
  }

  if (status.frame_id == source_frame) {
    return std::nullopt;
  }

  try {
    return tf_buffer_->lookupTransform(status.frame_id, source_frame, tf2::TimePointZero);
  } catch (const std::exception & ex) {
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      5000,
      "SLAM geometry TF unavailable from %s to %s: %s",
      source_frame.c_str(),
      status.frame_id.c_str(),
      ex.what());
    return std::nullopt;
  }
}

std::string MapperNode::slamRegionStatsToJson(const SlamRegionStats & stats) const
{
  const auto state = slam_map_sampler_.classifyRegion(stats);
  std::ostringstream oss;
  oss << std::boolalpha << std::fixed << std::setprecision(3);
  oss
    << "{\"source\":\"" << (stats.map_real ? "slam_map" : "legacy_or_unavailable")
    << "\",\"state\":\"" << slamGeometryStateToString(state)
    << "\",\"free_ratio\":" << stats.free_ratio
    << ",\"occupied_ratio\":" << stats.occupied_ratio
    << ",\"unknown_ratio\":" << stats.unknown_ratio
    << ",\"sample_count\":" << stats.sample_count
    << ",\"confidence\":" << stats.confidence
    << ",\"clearance\":{"
    << "\"available\":" << stats.clearance_available
    << ",\"min_m\":" << stats.clearance_min_m
    << ",\"mean_m\":" << stats.clearance_mean_m
    << ",\"ratio_ok\":" << stats.clearance_ratio_ok
    << ",\"sample_count\":" << stats.clearance_sample_count
    << ",\"threshold_m\":" << stats.clearance_threshold_m
    << "}"
    << "}";
  return oss.str();
}

std::string MapperNode::slamRegionStatsToJson(
  const SlamRegionStats & stats,
  const EdgeEvidence * edge_evidence,
  const rclcpp::Time & stamp) const
{
  const auto state = slam_map_sampler_.classifyRegion(stats);
  std::ostringstream oss;
  oss << std::boolalpha << std::fixed << std::setprecision(3);
  oss
    << "{\"source\":\"" << (stats.map_real ? "slam_map" : "legacy_or_unavailable")
    << "\",\"state\":\"" << slamGeometryStateToString(state)
    << "\",\"free_ratio\":" << stats.free_ratio
    << ",\"occupied_ratio\":" << stats.occupied_ratio
    << ",\"unknown_ratio\":" << stats.unknown_ratio
    << ",\"sample_count\":" << stats.sample_count
    << ",\"confidence\":" << stats.confidence
    << ",\"clearance\":{"
    << "\"available\":" << stats.clearance_available
    << ",\"min_m\":" << stats.clearance_min_m
    << ",\"mean_m\":" << stats.clearance_mean_m
    << ",\"ratio_ok\":" << stats.clearance_ratio_ok
    << ",\"sample_count\":" << stats.clearance_sample_count
    << ",\"threshold_m\":" << stats.clearance_threshold_m
    << "}";
  if (edge_evidence != nullptr) {
    oss << ",\"edge_model\":" << edgeEvidenceJson(*edge_evidence, stamp);
  }
  oss << "}";
  return oss.str();
}

std::string MapperNode::edgeEvidenceJson(
  const EdgeEvidence & evidence,
  const rclcpp::Time & stamp) const
{
  bool stale = false;
  if (evidence.has_observation) {
    const double age_s = (stamp - evidence.last_update).seconds();
    stale = age_s < 0.0 || age_s > edge_evidence_stale_after_sec_;
  }

  const char * state = "unknown";
  if (stale) {
    state = "stale";
  } else {
    state = slamGeometryStateToString(evidence.state);
  }

  std::ostringstream oss;
  oss << std::boolalpha << std::fixed << std::setprecision(3);
  oss
    << "{\"state\":\"" << state
    << "\",\"wall_log_odds\":" << evidence.wall_log_odds
    << ",\"open_log_odds\":" << evidence.open_log_odds
    << ",\"unknown_ema\":" << evidence.unknown_ema
    << ",\"confidence\":" << evidence.confidence
    << ",\"last_occupied_ratio\":" << evidence.last_occupied_ratio
    << ",\"last_free_ratio\":" << evidence.last_free_ratio
    << ",\"last_unknown_ratio\":" << evidence.last_unknown_ratio
    << ",\"has_observation\":" << evidence.has_observation
    << ",\"stale\":" << stale;
  if (evidence.has_observation) {
    oss << ",\"age_sec\":" << std::max(0.0, (stamp - evidence.last_update).seconds());
  } else {
    oss << ",\"age_sec\":null";
  }
  oss << "}";
  return oss.str();
}

EdgeEvidence & MapperNode::tileEdgeEvidence(
  const TileCoord & coord,
  SlamCardinalDirection direction) const
{
  auto & edges = tile_edge_evidence_[coord];
  return edges[slamDirectionIndex(direction)];
}

EdgeEvidence & MapperNode::phantomEdgeEvidence(
  const TileCoord & coord,
  SlamCardinalDirection direction) const
{
  auto & edges = phantom_edge_evidence_[coord];
  return edges[slamDirectionIndex(direction)];
}

void MapperNode::updateEdgeEvidence(
  EdgeEvidence & evidence,
  const SlamRegionStats & stats,
  const rclcpp::Time & stamp) const
{
  if (!edge_evidence_enabled_) {
    return;
  }

  if (
    !stats.map_real ||
    !stats.map_recent ||
    stats.sample_count < slam_geometry_config_.min_region_samples)
  {
    return;
  }

  const double alpha = edge_evidence_unknown_ema_alpha_;
  evidence.unknown_ema =
    evidence.has_observation ?
    (1.0 - alpha) * evidence.unknown_ema + alpha * stats.unknown_ratio :
    stats.unknown_ratio;
  evidence.last_occupied_ratio = stats.occupied_ratio;
  evidence.last_free_ratio = stats.free_ratio;
  evidence.last_unknown_ratio = stats.unknown_ratio;
  evidence.last_update = stamp;
  evidence.has_observation = true;

  const bool wall_observed =
    stats.occupied_ratio >= slam_geometry_config_.likely_wall_occupied_ratio;
  const bool open_observed =
    stats.free_ratio >= slam_geometry_config_.likely_open_free_ratio &&
    stats.occupied_ratio <= slam_geometry_config_.max_open_occupied_ratio;

  if (wall_observed) {
    evidence.wall_log_odds += edge_evidence_wall_update_gain_ * stats.occupied_ratio;
    if (!open_observed) {
      evidence.open_log_odds -= edge_evidence_conflict_decay_ * stats.occupied_ratio;
    }
  }
  if (open_observed) {
    evidence.open_log_odds += edge_evidence_open_update_gain_ * stats.free_ratio;
    if (!wall_observed) {
      evidence.wall_log_odds -= edge_evidence_conflict_decay_ * stats.free_ratio;
    }
  }

  evidence.wall_log_odds = std::clamp(
    evidence.wall_log_odds,
    edge_evidence_min_log_odds_,
    edge_evidence_max_log_odds_);
  evidence.open_log_odds = std::clamp(
    evidence.open_log_odds,
    edge_evidence_min_log_odds_,
    edge_evidence_max_log_odds_);

  const bool wall_confirmed =
    evidence.wall_log_odds >= edge_evidence_confirmed_wall_log_odds_ &&
    evidence.wall_log_odds - evidence.open_log_odds >= edge_evidence_conflict_log_odds_delta_;
  const bool open_confirmed =
    evidence.open_log_odds >= edge_evidence_confirmed_open_log_odds_ &&
    evidence.open_log_odds - evidence.wall_log_odds >= edge_evidence_conflict_log_odds_delta_;
  const bool wall_likely = evidence.wall_log_odds >= edge_evidence_likely_wall_log_odds_;
  const bool open_likely = evidence.open_log_odds >= edge_evidence_likely_open_log_odds_;

  if (wall_confirmed) {
    evidence.state = SlamGeometryState::ConfirmedWall;
  } else if (open_confirmed) {
    evidence.state = SlamGeometryState::ConfirmedOpen;
  } else if (wall_likely && open_likely) {
    evidence.state = SlamGeometryState::Conflicted;
  } else if (wall_likely) {
    evidence.state = SlamGeometryState::LikelyWall;
  } else if (open_likely) {
    evidence.state = SlamGeometryState::LikelyOpen;
  } else {
    evidence.state = SlamGeometryState::Unknown;
  }

  const double strongest_log_odds =
    std::max(std::fabs(evidence.wall_log_odds), std::fabs(evidence.open_log_odds));
  const double log_odds_confidence =
    strongest_log_odds / std::max(1.0e-6, edge_evidence_max_log_odds_);
  evidence.confidence = std::clamp(
    log_odds_confidence * (1.0 - evidence.unknown_ema),
    0.0,
    1.0);
}

std::string MapperNode::tileRecordToJson(
  const TileRecord & record,
  const rclcpp::Time & stamp,
  const geometry_msgs::msg::TransformStamped * semantic_to_map) const
{
  std::ostringstream oss;
  oss << std::boolalpha;
  oss
    << "{\"x\":" << record.coord.x
    << ",\"y\":" << record.coord.y
    << ",\"area\":\"" << tileAreaToString(record.area)
    << "\",\"kind\":\"" << tileKindToString(record.kind)
    << "\",\"visited\":" << record.visited
    << ",\"blocked\":" << record.is_blocked
    << ",\"hole\":" << record.is_hole
    << ",\"black_hole_border\":" << record.has_black_hole_border
    << ",\"swamp\":" << record.is_swamp
    << ",\"checkpoint\":" << record.is_checkpoint
    << ",\"visit_count\":" << record.visit_count;

  if (record.hazard_state != HazardState::None) {
    oss << ",\"hazard\":" << hazardJson(record, stamp);
  }

  const auto slam_status = slam_map_sampler_.status(stamp);
  const bool same_frame = slam_status.frame_id == marker_frame_;
  const bool can_sample_slam = slam_status.map_real && (same_frame || semantic_to_map != nullptr);

  struct DirectionRegion
  {
    const char * label;
    SlamCardinalDirection direction;
    int dx;
    int dy;
  };

  const std::array<DirectionRegion, 4> directions = {{
    DirectionRegion{"N", SlamCardinalDirection::North, 0, 1},
    DirectionRegion{"E", SlamCardinalDirection::East, 1, 0},
    DirectionRegion{"S", SlamCardinalDirection::South, 0, -1},
    DirectionRegion{"W", SlamCardinalDirection::West, -1, 0},
  }};
  std::array<SlamRegionStats, 4> slam_wall_edge_stats;
  std::array<SlamRegionStats, 4> slam_wall_corridor_stats;

  if (can_sample_slam) {
    const double tile_interior_size =
      slam_geometry_config_.tile_interior_ratio * tile_size_;
    const double edge_strip_length =
      slam_geometry_config_.edge_strip_length_ratio * tile_size_;
    const double edge_strip_width =
      std::max(slam_geometry_config_.edge_strip_min_width_m, 4.0 * slam_status.resolution);

    const auto tile_stats = slam_map_sampler_.sampleAxisAlignedBox(
      record.center.x,
      record.center.y,
      tile_interior_size,
      tile_interior_size,
      stamp,
      semantic_to_map);
    oss << ",\"geometry\":" << slamRegionStatsToJson(tile_stats);

    oss << ",\"edges\":{";
    for (std::size_t i = 0; i < directions.size(); ++i) {
      if (i > 0U) {
        oss << ",";
      }
      const auto & direction = directions[i];
      const auto edge_stats = slam_map_sampler_.sampleEdgeStrip(
        record.center.x,
        record.center.y,
        tile_size_,
        direction.direction,
        edge_strip_length,
        edge_strip_width,
        stamp,
        semantic_to_map);
      slam_wall_edge_stats[i] = edge_stats;
      auto & edge_evidence = tileEdgeEvidence(record.coord, direction.direction);
      updateEdgeEvidence(edge_evidence, edge_stats, stamp);
      oss << "\"" << direction.label << "\":" <<
        slamRegionStatsToJson(edge_stats, &edge_evidence, stamp);
    }
    oss << "}";

    oss << ",\"corridors\":{";
    for (std::size_t i = 0; i < directions.size(); ++i) {
      if (i > 0U) {
        oss << ",";
      }
      const auto & direction = directions[i];
      const double neighbor_x =
        record.center.x + static_cast<double>(direction.dx) * tile_size_;
      const double neighbor_y =
        record.center.y + static_cast<double>(direction.dy) * tile_size_;
      const auto corridor_stats = slam_map_sampler_.sampleCorridor(
        record.center.x,
        record.center.y,
        neighbor_x,
        neighbor_y,
        slam_geometry_config_.corridor_width_m,
        stamp,
        semantic_to_map);
      slam_wall_corridor_stats[i] = corridor_stats;
      oss << "\"" << direction.label << "\":" << slamRegionStatsToJson(corridor_stats);
    }
    oss << "}";
  }

  oss << std::fixed << std::setprecision(3);
  oss
    << ",\"slam_wall_diagnostics\":{"
    << "\"map_valid\":" << can_sample_slam
    << ",\"map_real\":" << slam_status.map_real
    << ",\"source\":\"slam_wall_model_diagnostic\"";
  if (!can_sample_slam) {
    oss << ",\"rejection_reason\":\"" <<
      (slam_status.map_real ? "map_transform_unavailable" : slam_status.rejection_reason) << "\"";
  }
  for (std::size_t i = 0; i < directions.size(); ++i) {
    const auto & direction = directions[i];
    SlamWallDiagnosticState state = SlamWallDiagnosticState::Unknown;
    double confidence = 0.0;
    if (can_sample_slam) {
      state = classifySlamWallDiagnostic(
        slam_wall_edge_stats[i],
        slam_wall_corridor_stats[i],
        slam_geometry_config_);
      confidence = slamWallDiagnosticConfidence(
        state,
        slam_wall_edge_stats[i],
        slam_wall_corridor_stats[i],
        slam_geometry_config_);
    }
    oss
      << ",\"" << direction.label << "\":{"
      << "\"state\":\"" << slamWallDiagnosticStateToString(state)
      << "\",\"source\":\"slam_wall_model_diagnostic"
      << "\",\"confidence\":" << confidence;
    if (can_sample_slam) {
      const auto & edge_stats = slam_wall_edge_stats[i];
      const auto & corridor_stats = slam_wall_corridor_stats[i];
      oss
        << ",\"edge_strip\":{"
        << "\"known_ratio\":" << (1.0 - edge_stats.unknown_ratio)
        << ",\"occupied_ratio\":" << edge_stats.occupied_ratio
        << ",\"free_ratio\":" << edge_stats.free_ratio
        << ",\"unknown_ratio\":" << edge_stats.unknown_ratio
        << ",\"sample_count\":" << edge_stats.sample_count
        << "}"
        << ",\"corridor\":{"
        << "\"known_ratio\":" << (1.0 - corridor_stats.unknown_ratio)
        << ",\"occupied_ratio\":" << corridor_stats.occupied_ratio
        << ",\"free_ratio\":" << corridor_stats.free_ratio
        << ",\"unknown_ratio\":" << corridor_stats.unknown_ratio
        << ",\"sample_count\":" << corridor_stats.sample_count
        << "}";
    }
    oss << "}";
  }
  oss << "}";

  struct SimpleDirection
  {
    const char * label;
    SlamCardinalDirection direction;
    int dx;
    int dy;
  };

  const std::array<SimpleDirection, 4> simple_directions = {{
    SimpleDirection{"N", SlamCardinalDirection::North, 0, 1},
    SimpleDirection{"E", SlamCardinalDirection::East, 1, 0},
    SimpleDirection{"S", SlamCardinalDirection::South, 0, -1},
    SimpleDirection{"W", SlamCardinalDirection::West, -1, 0},
  }};

  const auto edge_evidence_it = tile_edge_evidence_.find(record.coord);
  const auto & tile_records = tile_map_.records();

  oss << std::fixed << std::setprecision(3);
  oss << ",\"simple_edges\":{";
  for (std::size_t i = 0; i < simple_directions.size(); ++i) {
    if (i > 0U) {
      oss << ",";
    }

    const auto & direction = simple_directions[i];
    SimpleEdgeState state = SimpleEdgeState::Unknown;
    const char * source = "none";
    double confidence = 0.0;

    const TileCoord neighbor{
      record.coord.x + direction.dx,
      record.coord.y + direction.dy};
    const auto neighbor_it = tile_records.find(neighbor);
    if (neighbor_it != tile_records.end() && isBlockingHazardTile(neighbor_it->second)) {
      const auto & neighbor_record = neighbor_it->second;
      state = SimpleEdgeState::BlockedByHazard;
      source =
        neighbor_record.hazard_source == HazardSource::FloorColor ?
        "floor_color" : "existing_mapper_state";
      confidence = neighbor_record.hazard_confidence > 0.0 ?
        std::clamp(neighbor_record.hazard_confidence, 0.0, 1.0) : 1.0;
    } else {
      const auto wall_state = wallStateForDirection(record.walls, direction.direction);
      if (wall_state == WallState::Wall || wall_state == WallState::VirtualWall) {
        state = SimpleEdgeState::Wall;
        source = "wall_state";
        confidence = 1.0;
      }

      const EdgeEvidence * evidence = nullptr;
      if (edge_evidence_it != tile_edge_evidence_.end()) {
        evidence = &edge_evidence_it->second[slamDirectionIndex(direction.direction)];
      }

      bool evidence_stale = false;
      if (evidence != nullptr && evidence->has_observation) {
        const double age_s = (stamp - evidence->last_update).seconds();
        evidence_stale = age_s < 0.0 || age_s > edge_evidence_stale_after_sec_;
      }

      if (
        state == SimpleEdgeState::Unknown &&
        evidence != nullptr &&
        evidence->has_observation &&
        !evidence_stale)
      {
        if (
          evidence->state == SlamGeometryState::ConfirmedWall ||
          evidence->state == SlamGeometryState::LikelyWall)
        {
          state = SimpleEdgeState::Wall;
          source = "existing_edge_evidence";
          confidence = std::clamp(evidence->confidence, 0.0, 1.0);
        }
      }

      if (state == SimpleEdgeState::Unknown && wall_state == WallState::Open) {
        state = SimpleEdgeState::Open;
        source = "wall_state";
        confidence = 1.0;
      }

      if (
        state == SimpleEdgeState::Unknown &&
        evidence != nullptr &&
        evidence->has_observation &&
        !evidence_stale &&
        (
          evidence->state == SlamGeometryState::ConfirmedOpen ||
          evidence->state == SlamGeometryState::LikelyOpen))
      {
        state = SimpleEdgeState::Open;
        source = "existing_edge_evidence";
        confidence = std::clamp(evidence->confidence, 0.0, 1.0);
      }
    }

    oss
      << "\"" << direction.label << "\":{"
      << "\"state\":\"" << simpleEdgeStateToString(state)
      << "\",\"source\":\"" << source
      << "\",\"confidence\":" << confidence
      << "}";
  }
  oss << "}";

  oss << "}";
  return oss.str();
}

std::string MapperNode::phantomRecordToJson(
  const PhantomTileEvidence & evidence,
  const rclcpp::Time & stamp,
  const geometry_msgs::msg::TransformStamped * semantic_to_map) const
{
  const bool has_observation =
    evidence.observation_count > 0 ||
    evidence.possible_rays_total > 0 ||
    evidence.hit_count_total > 0 ||
    evidence.free_rays_total > 0 ||
    evidence.confidence > 0.0;
  const char * base_state = has_observation ? "phantom_candidate" : "phantom_unknown";
  const char * state = base_state;
  const char * slam_state = "phantom_unknown";
  const char * source = "legacy_lidar";
  const double base_confidence = std::clamp(evidence.confidence, 0.0, 1.0);
  double derived_confidence = base_confidence;
  double slam_confidence = 0.0;
  double slam_support_score = 0.0;
  double slam_conflict_score = 0.0;

  const auto slam_status = slam_map_sampler_.status(stamp);
  const bool same_frame = slam_status.frame_id == marker_frame_;
  const bool can_sample_slam = slam_status.map_real && (same_frame || semantic_to_map != nullptr);

  SlamRegionStats tile_stats;
  SlamRegionStats corridor_stats;
  bool corridor_sampled = false;
  struct PhantomEdgeRegion
  {
    const char * label;
    SlamCardinalDirection direction;
  };
  const std::array<PhantomEdgeRegion, 4> phantom_edges = {{
    PhantomEdgeRegion{"N", SlamCardinalDirection::North},
    PhantomEdgeRegion{"E", SlamCardinalDirection::East},
    PhantomEdgeRegion{"S", SlamCardinalDirection::South},
    PhantomEdgeRegion{"W", SlamCardinalDirection::West},
  }};
  std::array<SlamRegionStats, 4> edge_stats{};

  if (can_sample_slam) {
    const double phantom_center_x =
      static_cast<double>(evidence.coord.x) * tile_size_ + origin_x_;
    const double phantom_center_y =
      static_cast<double>(evidence.coord.y) * tile_size_ + origin_y_;
    const double phantom_sample_size =
      slam_geometry_config_.phantom_tile_sample_scale * tile_size_;
    const double edge_strip_length =
      slam_geometry_config_.edge_strip_length_ratio * tile_size_;
    const double edge_strip_width =
      std::max(slam_geometry_config_.edge_strip_min_width_m, 4.0 * slam_status.resolution);

    tile_stats = slam_map_sampler_.sampleAxisAlignedBox(
      phantom_center_x,
      phantom_center_y,
      phantom_sample_size,
      phantom_sample_size,
      stamp,
      semantic_to_map);

    if (previous_current_tile_) {
      const int dx = evidence.coord.x - previous_current_tile_->x;
      const int dy = evidence.coord.y - previous_current_tile_->y;
      const bool cardinal_neighbor =
        (dx == 0 && (dy == 1 || dy == -1)) ||
        (dy == 0 && (dx == 1 || dx == -1));

      if (cardinal_neighbor) {
        const double current_center_x =
          static_cast<double>(previous_current_tile_->x) * tile_size_ + origin_x_;
        const double current_center_y =
          static_cast<double>(previous_current_tile_->y) * tile_size_ + origin_y_;
        corridor_stats = slam_map_sampler_.sampleCorridor(
          current_center_x,
          current_center_y,
          phantom_center_x,
          phantom_center_y,
          slam_geometry_config_.phantom_corridor_width_m,
          stamp,
          semantic_to_map);
        corridor_sampled = true;
      }
    }

    for (std::size_t i = 0; i < phantom_edges.size(); ++i) {
      const auto & edge = phantom_edges[i];
      edge_stats[i] = slam_map_sampler_.sampleEdgeStrip(
        phantom_center_x,
        phantom_center_y,
        tile_size_,
        edge.direction,
        edge_strip_length,
        edge_strip_width,
        stamp,
        semantic_to_map);
    }

    const auto region_valid =
      [this](const SlamRegionStats & stats) {
        return
          stats.map_real &&
          stats.map_recent &&
          stats.sample_count >= slam_geometry_config_.phantom_min_region_samples;
      };
    const auto supported_region =
      [this](const SlamRegionStats & stats) {
        return
          stats.free_ratio >= slam_geometry_config_.phantom_support_free_ratio &&
          stats.occupied_ratio <= slam_geometry_config_.phantom_max_supported_occupied_ratio;
      };
    const auto conflicted_region =
      [this](const SlamRegionStats & stats) {
        return stats.occupied_ratio >= slam_geometry_config_.phantom_conflict_occupied_ratio;
      };
    const auto normalized_support =
      [this](double free_ratio) {
        const double span =
          std::max(1.0e-6, 1.0 - slam_geometry_config_.phantom_support_free_ratio);
        return std::clamp(
          (free_ratio - slam_geometry_config_.phantom_support_free_ratio) / span,
          0.0,
          1.0);
      };
    const auto normalized_conflict =
      [this](double occupied_ratio) {
        const double span = std::max(
          1.0e-6,
          slam_geometry_config_.phantom_confirmed_conflict_occupied_ratio -
          slam_geometry_config_.phantom_conflict_occupied_ratio);
        return std::clamp(
          (occupied_ratio - slam_geometry_config_.phantom_conflict_occupied_ratio) / span,
          0.0,
          1.0);
      };

    const bool tile_valid = region_valid(tile_stats);
    const bool corridor_valid = corridor_sampled && region_valid(corridor_stats);
    const bool interior_supported = tile_valid && supported_region(tile_stats);
    const bool corridor_supported =
      !corridor_sampled ||
      (corridor_valid && supported_region(corridor_stats));
    const bool interior_conflicted = tile_valid && conflicted_region(tile_stats);
    const bool corridor_conflicted = corridor_valid && conflicted_region(corridor_stats);

    double confidence_sum = 0.0;
    int confidence_regions = 0;
    double support_sum = 0.0;
    int support_regions = 0;

    if (tile_valid) {
      confidence_sum += tile_stats.confidence;
      ++confidence_regions;
      support_sum += normalized_support(tile_stats.free_ratio);
      ++support_regions;
      slam_conflict_score = std::max(
        slam_conflict_score,
        normalized_conflict(tile_stats.occupied_ratio));
    }
    if (corridor_valid) {
      confidence_sum += corridor_stats.confidence;
      ++confidence_regions;
      support_sum += normalized_support(corridor_stats.free_ratio);
      ++support_regions;
      slam_conflict_score = std::max(
        slam_conflict_score,
        normalized_conflict(corridor_stats.occupied_ratio));
    }
    if (confidence_regions > 0) {
      slam_confidence = confidence_sum / static_cast<double>(confidence_regions);
    }
    if (support_regions > 0) {
      slam_support_score = support_sum / static_cast<double>(support_regions);
    }

    if (interior_conflicted || corridor_conflicted) {
      state = "phantom_conflicted_by_slam";
      slam_state = "phantom_conflicted_by_slam";
      source = "legacy_lidar+slam_map";
      derived_confidence =
        std::clamp(base_confidence - 0.5 * std::max(0.2, slam_conflict_score), 0.0, 1.0);
    } else if (interior_supported && corridor_supported) {
      state = "phantom_supported_by_slam";
      slam_state = "phantom_supported_by_slam";
      source = "legacy_lidar+slam_map";
      derived_confidence = std::clamp(base_confidence + 0.35 * slam_support_score, 0.0, 1.0);
    } else if (tile_valid || corridor_valid) {
      state = "phantom_unknown";
      slam_state = "phantom_unknown";
    }
  }

  std::ostringstream oss;
  oss << std::boolalpha << std::fixed << std::setprecision(3);
  oss
    << "{\"x\":" << evidence.coord.x
    << ",\"y\":" << evidence.coord.y
    << ",\"state\":\"" << state
    << "\",\"confidence\":" << derived_confidence
    << ",\"base_confidence\":" << base_confidence
    << ",\"source\":\"" << source
    << "\",\"visited\":false"
    << ",\"promoted\":false"
    << ",\"hit_score\":" << evidence.hit_score
    << ",\"free_score\":" << evidence.free_score
    << ",\"conflict_score\":" << evidence.conflict_score
    << ",\"visibility_score\":" << evidence.visibility_score
    << ",\"best_score\":" << evidence.best_score
    << ",\"second_score\":" << evidence.second_score
    << ",\"observation_count\":" << evidence.observation_count
    << ",\"possible_rays\":" << evidence.possible_rays_total
    << ",\"free_rays\":" << evidence.free_rays_total
    << ",\"hit_count\":" << evidence.hit_count_total
    << ",\"support_bins\":" << evidence.support_bins.size()
    << ",\"quadrants\":" << evidence.quadrants.size()
    << ",\"last_seen_age_sec\":";

  if (evidence.last_seen.nanoseconds() != 0) {
    oss << std::max(0.0, (stamp - evidence.last_seen).seconds());
  } else {
    oss << "null";
  }

  oss
    << ",\"slam\":{"
    << "\"available\":" << slam_status.map_available
    << ",\"map_real\":" << slam_status.map_real
    << ",\"map_recent\":" << slam_status.map_recent
    << ",\"sampleable\":" << can_sample_slam
    << ",\"state\":\"" << slam_state
    << "\",\"free_ratio\":" << tile_stats.free_ratio
    << ",\"occupied_ratio\":" << tile_stats.occupied_ratio
    << ",\"unknown_ratio\":" << tile_stats.unknown_ratio
    << ",\"confidence\":" << slam_confidence
    << ",\"support_score\":" << slam_support_score
    << ",\"conflict_score\":" << slam_conflict_score
    << ",\"sample_count\":" << tile_stats.sample_count
    << ",\"corridor_sampled\":" << corridor_sampled
    << ",\"corridor_free_ratio\":" << corridor_stats.free_ratio
    << ",\"corridor_occupied_ratio\":" << corridor_stats.occupied_ratio
    << ",\"corridor_unknown_ratio\":" << corridor_stats.unknown_ratio
    << ",\"corridor_sample_count\":" << corridor_stats.sample_count
    << "}";

  oss << ",\"edges\":{";
  for (std::size_t i = 0; i < phantom_edges.size(); ++i) {
    if (i > 0U) {
      oss << ",";
    }
    auto & edge_evidence = phantomEdgeEvidence(evidence.coord, phantom_edges[i].direction);
    updateEdgeEvidence(edge_evidence, edge_stats[i], stamp);
    oss << "\"" << phantom_edges[i].label << "\":" <<
      slamRegionStatsToJson(edge_stats[i], &edge_evidence, stamp);
  }
  oss << "}}";
  return oss.str();
}

std::string MapperNode::phantomMapJson(
  const rclcpp::Time & stamp,
  const geometry_msgs::msg::TransformStamped * semantic_to_map) const
{
  std::vector<const PhantomTileEvidence *> records;
  records.reserve(phantom_tile_map_.records().size());
  for (const auto & entry : phantom_tile_map_.records()) {
    records.push_back(&entry.second);
  }

  std::sort(
    records.begin(),
    records.end(),
    [](const PhantomTileEvidence * lhs, const PhantomTileEvidence * rhs) {
      if (lhs->coord.y != rhs->coord.y) {
        return lhs->coord.y < rhs->coord.y;
      }
      return lhs->coord.x < rhs->coord.x;
    });

  std::ostringstream oss;
  oss << "[";
  for (std::size_t i = 0; i < records.size(); ++i) {
    if (i > 0U) {
      oss << ",";
    }
    oss << phantomRecordToJson(*records[i], stamp, semantic_to_map);
  }
  oss << "]";
  return oss.str();
}

std::string MapperNode::slamGeometryStatusJson(const rclcpp::Time & stamp) const
{
  const auto status = slam_map_sampler_.status(stamp);
  std::ostringstream oss;
  oss << std::boolalpha << std::fixed << std::setprecision(6);
  oss
    << "{\"enabled\":" << status.enabled
    << ",\"map_available\":" << status.map_available
    << ",\"map_real\":" << status.map_real
    << ",\"map_recent\":" << status.map_recent
    << ",\"source\":\"" << (status.map_real ? "slam_map" : "legacy_or_unavailable")
    << "\",\"frame_id\":\"" << status.frame_id
    << "\",\"width\":" << status.width
    << ",\"height\":" << status.height
    << ",\"resolution\":" << status.resolution
    << ",\"age_sec\":" << status.age_sec
    << ",\"known_cells\":" << status.known_cells
    << ",\"free_cells\":" << status.free_cells
    << ",\"occupied_cells\":" << status.occupied_cells
    << ",\"unknown_cells\":" << status.unknown_cells
    << ",\"known_ratio\":" << status.known_ratio
    << ",\"free_ratio\":" << status.free_ratio
    << ",\"occupied_ratio\":" << status.occupied_ratio
    << ",\"unknown_ratio\":" << status.unknown_ratio
    << ",\"rejection_reason\":\"" << status.rejection_reason
    << "\"}";
  return oss.str();
}

std::string MapperNode::currentTileJson(
  const TileRecord & record,
  const rclcpp::Time & stamp) const
{
  std::ostringstream oss;
  oss << std::boolalpha;
  oss
    << "{\"stamp\":" << stampToJson(stamp)
    << ",\"tile\":" << tileCoordToJson(record.coord)
    << ",\"area\":\"" << tileAreaToString(record.area)
    << "\",\"kind\":\"" << tileKindToString(record.kind)
    << "\",\"visited\":" << record.visited
    << ",\"blocked\":" << record.is_blocked
    << ",\"hole\":" << record.is_hole
    << ",\"black_hole_border\":" << record.has_black_hole_border
    << ",\"swamp\":" << record.is_swamp
    << ",\"checkpoint\":" << record.is_checkpoint
    << ",\"visit_count\":" << record.visit_count;

  if (record.hazard_state != HazardState::None) {
    oss << ",\"hazard\":" << hazardJson(record, stamp);
  }

  oss << "}";
  return oss.str();
}

std::string MapperNode::semanticMapJson(const rclcpp::Time & stamp) const
{
  std::vector<const TileRecord *> records;
  records.reserve(tile_map_.records().size());
  for (const auto & entry : tile_map_.records()) {
    if (entry.second.visited || hasSemanticState(entry.second)) {
      records.push_back(&entry.second);
    }
  }

  std::sort(
    records.begin(),
    records.end(),
    [](const TileRecord * lhs, const TileRecord * rhs) {
      if (lhs->coord.y != rhs->coord.y) {
        return lhs->coord.y < rhs->coord.y;
      }
      return lhs->coord.x < rhs->coord.x;
    });

  const auto max_tiles = static_cast<std::size_t>(semantic_map_max_tiles_);
  if (records.size() > max_tiles) {
    records.resize(max_tiles);
  }

  const auto slam_status = slam_map_sampler_.status(stamp);
  const bool same_slam_frame = slam_status.frame_id == marker_frame_;
  const auto semantic_to_map =
    slam_status.map_real && !same_slam_frame ?
    lookupTransformToSlamMapFrame(marker_frame_) :
    std::optional<geometry_msgs::msg::TransformStamped>{};
  const auto * semantic_to_map_ptr = semantic_to_map ? &(*semantic_to_map) : nullptr;

  std::ostringstream oss;
  oss << std::fixed << std::setprecision(3);
  oss
    << "{\"stamp\":" << stampToJson(stamp)
    << ",\"frame_id\":\"" << marker_frame_
    << "\""
    << ",\"origin\":{\"x\":" << origin_x_
    << ",\"y\":" << origin_y_
    << "},\"tile_size\":" << tile_size_
    << ",\"slam_geometry\":" << slamGeometryStatusJson(stamp)
    << ",\"tiles\":[";

  for (std::size_t i = 0; i < records.size(); ++i) {
    if (i > 0U) {
      oss << ",";
    }
    oss << tileRecordToJson(*records[i], stamp, semantic_to_map_ptr);
  }

  oss << "],\"phantoms\":" << phantomMapJson(stamp, semantic_to_map_ptr) << "}";
  return oss.str();
}

std::string MapperNode::mapperStatusJson(const rclcpp::Time & stamp) const
{
  std::size_t semantic_tile_count = 0U;
  for (const auto & entry : tile_map_.records()) {
    if (entry.second.visited || hasSemanticState(entry.second)) {
      ++semantic_tile_count;
    }
  }

  const auto is_recent =
    [&stamp](bool has_stamp, const rclcpp::Time & last_stamp, double timeout_s) {
      if (!has_stamp) {
        return false;
      }

      const double age_s = (stamp - last_stamp).seconds();
      return age_s >= 0.0 && age_s <= timeout_s;
    };

  const bool teleport_recovering = stamp < lidar_integration_blocked_until_;
  const bool semantic_map_ready =
    mapping_active_ && origin_initialized_ && semantic_tile_count > 0U && !teleport_recovering;
  const bool origin_waiting_for_activation =
    !origin_initialized_ && !mapping_active_;
  const bool origin_waiting_for_scan =
    !origin_initialized_ &&
    mapping_active_ &&
    origin_mode_ == "auto_first_pose" &&
    origin_require_scan_before_init_ &&
    !has_last_scan_received_stamp_;
  const bool slam_map_recent = is_recent(
    has_valid_slam_map_,
    last_valid_slam_map_stamp_,
    slam_map_recent_timeout_s_);
  const auto slam_map_width = has_valid_slam_map_ ? last_valid_slam_map_.info.width : 0U;
  const auto slam_map_height = has_valid_slam_map_ ? last_valid_slam_map_.info.height : 0U;
  const double slam_map_resolution =
    has_valid_slam_map_ ? static_cast<double>(last_valid_slam_map_.info.resolution) : 0.0;
  const auto slam_status = slam_map_sampler_.status(stamp);
  const bool slam_map_structural_ready = slam_status.map_available;
  const bool slam_map_valid = slam_status.map_real;
  const std::string slam_map_rejection_reason =
    slam_map_valid ? std::string{} : slam_status.rejection_reason;
  const bool map_is_dummy =
    has_slam_map_received_ &&
    slam_map_structural_ready &&
    !slam_map_valid &&
    (
      slam_map_rejection_reason == "all_free_or_no_occupied_cells" ||
      slam_map_rejection_reason == "all_unknown" ||
      slam_map_rejection_reason == "too_few_known_cells" ||
      slam_map_rejection_reason == "insufficient_known_cells" ||
      slam_map_rejection_reason == "too_few_occupied_cells" ||
      slam_map_rejection_reason == "insufficient_occupied_cells" ||
      slam_map_rejection_reason == "known_ratio_too_low" ||
      slam_map_rejection_reason == "known_ratio_below_threshold" ||
      slam_map_rejection_reason == "stale" ||
      slam_map_rejection_reason == "stale_map");

  std::ostringstream oss;
  oss << std::boolalpha << std::fixed << std::setprecision(6);
  oss
    << "{\"stamp\":" << stampToJson(stamp)
    << ",\"frame_id\":\"" << marker_frame_
    << "\",\"auto_start\":" << auto_start_
    << ",\"mapping_active\":" << mapping_active_
    << ",\"race_wait_for_bridge_ready\":" << race_wait_for_bridge_ready_
    << ",\"bridge_ready\":" << bridge_ready_
    << ",\"bridge_connection_id\":";

  if (has_bridge_connection_id_) {
    oss << bridge_connection_id_;
  } else {
    oss << "null";
  }

  oss
    << ",\"scan_seen_after_bridge_ready\":" << scan_seen_after_bridge_ready_
    << ",\"odom_seen_after_bridge_ready\":" << odom_seen_after_bridge_ready_
    << ",\"origin_initialized\":" << origin_initialized_
    << ",\"origin_waiting_for_activation\":" << origin_waiting_for_activation
    << ",\"origin_waiting_for_scan\":" << origin_waiting_for_scan
    << ",\"semantic_map_ready\":" << semantic_map_ready
    << ",\"has_recent_odom\":" << is_recent(
      has_last_odom_received_stamp_, last_odom_received_stamp_, odom_recent_timeout_s_)
    << ",\"has_recent_scan\":" << is_recent(
      has_last_scan_received_stamp_, last_scan_received_stamp_, scan_recent_timeout_s_)
    << ",\"slam_map_received\":" << has_slam_map_received_
    << ",\"slam_map_structural_ready\":" << slam_map_structural_ready
    << ",\"slam_map_valid\":" << slam_map_valid
    << ",\"map_is_dummy\":" << map_is_dummy
    << ",\"slam_map_rejection_reason\":\"" << slam_map_rejection_reason
    << "\",\"slam_map_stats\":{"
    << "\"width\":" << slam_status.width
    << ",\"height\":" << slam_status.height
    << ",\"resolution\":" << slam_status.resolution
    << ",\"total_cells\":" << slam_status.total_cells
    << ",\"known_cells\":" << slam_status.known_cells
    << ",\"free_cells\":" << slam_status.free_cells
    << ",\"occupied_cells\":" << slam_status.occupied_cells
    << ",\"unknown_cells\":" << slam_status.unknown_cells
    << ",\"known_ratio\":" << slam_status.known_ratio
    << ",\"free_ratio\":" << slam_status.free_ratio
    << ",\"occupied_ratio\":" << slam_status.occupied_ratio
    << ",\"unknown_ratio\":" << slam_status.unknown_ratio
    << ",\"age_sec\":" << slam_status.age_sec
    << "}"
    << ",\"slam_map_ready\":" << has_valid_slam_map_
    << ",\"slam_map_recent\":" << slam_map_recent
    << ",\"slam_map_width\":" << slam_map_width
    << ",\"slam_map_height\":" << slam_map_height
    << ",\"slam_map_resolution\":" << slam_map_resolution
    << ",\"slam_geometry\":" << slamGeometryStatusJson(stamp)
    << ",\"teleport_recovering\":" << teleport_recovering
    << ",\"tile_count\":" << tile_map_.records().size()
    << ",\"visited_tile_count\":" << tile_map_.visitedCount()
    << ",\"semantic_tile_count\":" << semantic_tile_count
    << ",\"current_tile\":";

  if (previous_current_tile_) {
    oss << tileCoordToJson(*previous_current_tile_);
  } else {
    oss << "null";
  }

  oss << "}";
  return oss.str();
}

void MapperNode::maybeLogSlamGeometryStatus(const rclcpp::Time & stamp)
{
  if (has_last_slam_geometry_log_stamp_) {
    const double elapsed_s = (stamp - last_slam_geometry_log_stamp_).seconds();
    if (elapsed_s >= 0.0 && elapsed_s < slam_geometry_config_.debug_log_period_sec) {
      return;
    }
  }

  const auto status = slam_map_sampler_.status(stamp);
  RCLCPP_INFO(
    get_logger(),
    "SLAM map status: available=%s real=%s recent=%s reason=%s known=%d occupied=%d free=%d unknown=%d size=%ux%u resolution=%.6f frame_id=%s",
    status.map_available ? "true" : "false",
    status.map_real ? "true" : "false",
    status.map_recent ? "true" : "false",
    status.rejection_reason.c_str(),
    status.known_cells,
    status.occupied_cells,
    status.free_cells,
    status.unknown_cells,
    status.width,
    status.height,
    status.resolution,
    status.frame_id.c_str());

  last_slam_geometry_log_stamp_ = stamp;
  has_last_slam_geometry_log_stamp_ = true;
}

void MapperNode::publishCurrentTile(
  const TileRecord & record,
  const rclcpp::Time & stamp) const
{
  if (!current_tile_pub_) {
    return;
  }

  std_msgs::msg::String msg;
  msg.data = currentTileJson(record, stamp);
  current_tile_pub_->publish(msg);
}
SubmissionResolvedWalls MapperNode::buildSubmissionResolvedWalls(
  const rclcpp::Time & stamp) const
{
  SubmissionResolvedWalls resolved_walls;

  const auto & tile_records = tile_map_.records();

  struct DirectionInfo
  {
    SlamCardinalDirection direction;
    int dx;
    int dy;
  };

  const std::array<DirectionInfo, 4> directions = {{
    DirectionInfo{SlamCardinalDirection::North, 0, 1},
    DirectionInfo{SlamCardinalDirection::East, 1, 0},
    DirectionInfo{SlamCardinalDirection::South, 0, -1},
    DirectionInfo{SlamCardinalDirection::West, -1, 0},
  }};

  const auto set_resolved_wall = [](
    EdgeWalls & walls,
    SlamCardinalDirection direction,
    WallState state)
  {
    switch (direction) {
      case SlamCardinalDirection::North:
        walls.north = state;
        break;

      case SlamCardinalDirection::East:
        walls.east = state;
        break;

      case SlamCardinalDirection::South:
        walls.south = state;
        break;

      case SlamCardinalDirection::West:
        walls.west = state;
        break;
    }
  };

  for (const auto & entry : tile_records) {
    const TileRecord & record = entry.second;
    EdgeWalls walls;

    const auto edge_evidence_it = tile_edge_evidence_.find(record.coord);

    for (const auto & direction : directions) {
      SimpleEdgeState simple_state = SimpleEdgeState::Unknown;

      const TileCoord neighbor{
        record.coord.x + direction.dx,
        record.coord.y + direction.dy};

      const auto neighbor_it = tile_records.find(neighbor);

      if (neighbor_it != tile_records.end() && isBlockingHazardTile(neighbor_it->second)) {
        simple_state = SimpleEdgeState::BlockedByHazard;
      } else {
        const WallState wall_state = wallStateForDirection(record.walls, direction.direction);

        if (wall_state == WallState::Wall || wall_state == WallState::VirtualWall) {
          simple_state = SimpleEdgeState::Wall;
        }

        const EdgeEvidence * evidence = nullptr;

        if (edge_evidence_it != tile_edge_evidence_.end()) {
          evidence = &edge_evidence_it->second[slamDirectionIndex(direction.direction)];
        }

        bool evidence_stale = false;

        if (evidence != nullptr && evidence->has_observation) {
          const double age_s = (stamp - evidence->last_update).seconds();
          evidence_stale = age_s < 0.0 || age_s > edge_evidence_stale_after_sec_;
        }

        if (
          simple_state == SimpleEdgeState::Unknown &&
          evidence != nullptr &&
          evidence->has_observation &&
          !evidence_stale)
        {
          if (
            evidence->state == SlamGeometryState::ConfirmedWall ||
            evidence->state == SlamGeometryState::LikelyWall)
          {
            simple_state = SimpleEdgeState::Wall;
          }
        }

        if (simple_state == SimpleEdgeState::Unknown && wall_state == WallState::Open) {
          simple_state = SimpleEdgeState::Open;
        }

        if (
          simple_state == SimpleEdgeState::Unknown &&
          evidence != nullptr &&
          evidence->has_observation &&
          !evidence_stale &&
          (
            evidence->state == SlamGeometryState::ConfirmedOpen ||
            evidence->state == SlamGeometryState::LikelyOpen))
        {
          simple_state = SimpleEdgeState::Open;
        }
      }

      if (simple_state == SimpleEdgeState::Wall) {
        set_resolved_wall(walls, direction.direction, WallState::Wall);
      } else if (simple_state == SimpleEdgeState::Open) {
        set_resolved_wall(walls, direction.direction, WallState::Open);
      } else {
        set_resolved_wall(walls, direction.direction, WallState::Unknown);
      }
    }

    resolved_walls[record.coord] = walls;
  }

  return resolved_walls;
}

void MapperNode::publishSubmissionMatrix(const rclcpp::Time & stamp)
{
  if (!submission_matrix_pub_ || !mapping_active_ || !origin_initialized_) {
    return;
  }

  SubmissionMatrixBuilder builder;

  // Prefer the resolved subtile-model path (area 2 internal walls, area 3
  // curves, area 4 wildcard, transitions, victims). Fall back to the legacy
  // full-tile EdgeWalls path only when no models are available.
  const SubmissionResolvedTileModels resolved_models =
    buildSubmissionResolvedTileModels(stamp);

  SubmissionMatrixResult result;
  if (!resolved_models.empty()) {
    result = builder.build(tile_map_, resolved_models);
  } else {
    const SubmissionResolvedWalls resolved_walls = buildSubmissionResolvedWalls(stamp);
    result = builder.build(tile_map_, &resolved_walls);
  }

  if (result.cells.empty()) {
    return;
  }

  std::size_t star_cell_count = 0U;
  for (const auto & row : result.cells) {
    for (const auto & cell : row) {
      if (cell == "*") {
        ++star_cell_count;
      }
    }
  }

  std::size_t area4_model_count = 0U;
  std::size_t area4_unvisited_model_count = 0U;
  std::size_t area4_gateway_count = 0U;
  for (const auto & entry : resolved_models) {
    const SubmissionTileModel & model = entry.second;
    if (model.area4_wildcard) {
      ++area4_model_count;
      if (!model.committed) {
        ++area4_unvisited_model_count;
      }
    }
    if (model.area4_gateway) {
      ++area4_gateway_count;
    }
  }

  RCLCPP_INFO_THROTTLE(
    get_logger(), *get_clock(), 5000,
    "ROBOT_EVENT node=mapper event=submission_area4_debug "
    "model_tiles=%zu visited_tiles=%zu area4_models=%zu "
    "area4_unvisited_models=%zu would_be_visited_only_ignored=%zu "
    "area4_gateways=%zu star_cells=%zu "
    "matrix_rows=%zu matrix_cols=%zu connection_id=%" PRIu64,
    resolved_models.size(),
    tile_map_.visitedCount(),
    area4_model_count,
    area4_unvisited_model_count,
    area4_unvisited_model_count,
    area4_gateway_count,
    star_cell_count,
    result.cells.size(),
    result.cells.empty() ? 0U : result.cells.front().size(),
    bridge_connection_id_);

  std_msgs::msg::String msg;
  msg.data = SubmissionMatrixBuilder::toText(result);

  submission_matrix_pub_->publish(msg);

  if (publish_submission_geometry_) {
    publishSubmissionGeometryMarkers(resolved_models, stamp);
  }
}

SubmissionResolvedTileModels MapperNode::buildSubmissionResolvedTileModels(
  const rclcpp::Time & stamp)
{
  (void)stamp;  // geometry now comes from the RF models, not stamped evidence
  SubmissionResolvedTileModels models;

  const auto & tile_records = tile_map_.records();
  if (tile_records.empty()) {
    return models;
  }

  // Geometry comes from the RandomForest models read off the SLAM grid.
  // Quarter (subtile) world-center offsets, order NW, NE, SW, SE (matches
  // SubmissionSubtile and the Python QUARTER_ORDER).
  constexpr double kQuarterOffsetM = 0.03;
  constexpr double kSubtileHalfExtentM = 0.06;   // 0.12 m window per subtile
  constexpr double kTileHalfExtentM = 0.06;      // 0.12 m window per tile
  static const double kQdx[4] = {-kQuarterOffsetM, kQuarterOffsetM,
                                 -kQuarterOffsetM, kQuarterOffsetM};
  static const double kQdy[4] = {kQuarterOffsetM, kQuarterOffsetM,
                                 -kQuarterOffsetM, -kQuarterOffsetM};
  const bool geometry_available = map_geometry_models_.loaded() && has_valid_slam_map_;

  for (const auto & entry : tile_records) {
    const TileRecord & record = entry.second;

    SubmissionTileModel model;
    model.coord = record.coord;
    model.area = record.area;
    model.committed = record.visited;
    model.area_uncertain = record.area == TileArea::Unknown;

    // Quarter-center semantic value (official precedence, shared with builder).
    const std::string value = SubmissionMatrixBuilder::tileValue(record);
    for (auto & subtile : model.subtiles) {
      subtile.value = value;
    }

    const bool is_transition_tile =
      record.is_transition || record.kind == TileKind::Transition;

    // Area 4 gateways (entrance/exit): a transition whose pair involves Area 4,
    // by resolved areas or by the official floor color when areas are pending.
    if (is_transition_tile) {
      const bool by_area =
        record.transition.area_a == TileArea::Area4 ||
        record.transition.area_b == TileArea::Area4;
      const bool by_color =
        record.floor_color == FloorColorClass::RedArea3To4 ||
        record.floor_color == FloorColorClass::GreenArea1To4 ||
        record.floor_color == FloorColorClass::OrangeArea2To4;
      model.area4_gateway = by_area || by_color;
    }

    // Area 4 is wildcard: do not classify walls or curves.
    // Transition tiles touching Area 4 must keep their official center token
    // (g/r/o) instead of being swallowed by the Area 4 '*' overlay.
    if (useArea4GeometryForTile(record.area) && !is_transition_tile) {
      model.area = TileArea::Area4;
      model.area4_wildcard = true;
      models[record.coord] = std::move(model);
      continue;
    }

    // RandomForest geometry: explored gate -> wall/curve per subtile, obstacle
    // per tile. Without loaded models or a valid SLAM map the geometry stays
    // empty (no confidence fallback). Semantics/victims/area are unchanged.
    if (geometry_available) {
      const auto & grid = last_valid_slam_map_;
      const int8_t * data = reinterpret_cast<const int8_t *>(grid.data.data());
      const int gw = static_cast<int>(grid.info.width);
      const int gh = static_cast<int>(grid.info.height);
      const double gres = grid.info.resolution;
      const double gox = grid.info.origin.position.x;
      const double goy = grid.info.origin.position.y;

      const auto center = tileCenter(record.coord, origin_x_, origin_y_, tile_size_);

      for (int q = 0; q < kSubtileCount; ++q) {
        const cv::Mat patch = map_geometry_models_.extractPatch(
          data, gw, gh, gres, gox, goy,
          center.x + kQdx[q], center.y + kQdy[q], kSubtileHalfExtentM);
        const auto pred = map_geometry_models_.predictSubtile(patch);
        if (!pred.explored) {
          continue;  // explored gate: leave this subtile's geometry at 0
        }
        auto & sm = model.subtiles[q];
        sm.wall_north = pred.walls[MapGeometryModels::kNorth];
        sm.wall_east = pred.walls[MapGeometryModels::kEast];
        sm.wall_south = pred.walls[MapGeometryModels::kSouth];
        sm.wall_west = pred.walls[MapGeometryModels::kWest];
        sm.curve_dir = pred.curve_dir;
      }

      // Per-tile obstacle (full-tile crop). Wired into the model but NOT emitted
      // to the submission matrix yet (see SubmissionMatrixBuilder::build()).
      const cv::Mat tile_patch = map_geometry_models_.extractPatch(
        data, gw, gh, gres, gox, goy, center.x, center.y, kTileHalfExtentM);
      model.obstacle = map_geometry_models_.predictObstacle(tile_patch);
    }

    models[record.coord] = std::move(model);
  }

  // Tiles the explored model reads off the SLAM grid but that were never
  // physically visited (mapped through openings, seen from a distance). Runs
  // before the Area 4 fill so scan tiles inside the room exist as soft models
  // the fill can convert to '*' instead of leaving wall-geometry holes.
  if (submission_model_explored_tiles_ && geometry_available) {
    const int added = addModelExploredTiles(models);
    if (added > 0) {
      RCLCPP_INFO_THROTTLE(
        get_logger(), *get_clock(), 5000,
        "Submission: explored model added %d unvisited tiles", added);
    }
  }

  SubmissionArea4ExpansionStats area4_observed_stats;
  const int area4_observed_promoted =
    SubmissionMatrixBuilder::promoteConnectedArea4ObservedTiles(
      models,
      &area4_observed_stats);
  if (area4_observed_stats.candidate_edges > 0) {
    RCLCPP_INFO_THROTTLE(
      get_logger(), *get_clock(), 5000,
      "ROBOT_EVENT node=mapper event=submission_area4_observed_promoted "
      "promoted_tiles=%d candidate_edges=%d rejected_by_wall=%d "
      "rejected_missing_model=%d rejected_non_soft=%d "
      "reason=connected_observed_soft_models connection_id=%" PRIu64,
      area4_observed_promoted,
      area4_observed_stats.candidate_edges,
      area4_observed_stats.rejected_by_wall,
      area4_observed_stats.rejected_missing_model,
      area4_observed_stats.rejected_non_soft,
      bridge_connection_id_);
  }

  if (submission_area4_flood_fill_) {
    SubmissionArea4ExpansionStats area4_fill_stats;
    const int filled = SubmissionMatrixBuilder::applyArea4FloodFill(
      models,
      &area4_fill_stats);
    if (area4_fill_stats.candidate_edges > 0) {
      RCLCPP_INFO_THROTTLE(
        get_logger(), *get_clock(), 5000,
        "ROBOT_EVENT node=mapper event=submission_area4_flood_fill "
        "filled_tiles=%d candidate_edges=%d rejected_by_wall=%d "
        "rejected_missing_model=%d rejected_non_soft=%d connection_id=%" PRIu64,
        filled,
        area4_fill_stats.candidate_edges,
        area4_fill_stats.rejected_by_wall,
        area4_fill_stats.rejected_missing_model,
        area4_fill_stats.rejected_non_soft,
        bridge_connection_id_);
    }
  }

  for (const auto & observation : vision_victims_) {
    auto iter = models.find(observation.tile);
    if (iter == models.end()) {
      continue;
    }
    iter->second.victims.push_back(observation.mark);
  }

  return models;
}

int MapperNode::addModelExploredTiles(SubmissionResolvedTileModels & models)
{
  if (!map_geometry_models_.loaded() || !has_valid_slam_map_) {
    return 0;
  }

  const auto & grid = last_valid_slam_map_;
  const int8_t * data = reinterpret_cast<const int8_t *>(grid.data.data());
  const int gw = static_cast<int>(grid.info.width);
  const int gh = static_cast<int>(grid.info.height);
  const double gres = grid.info.resolution;
  const double gox = grid.info.origin.position.x;
  const double goy = grid.info.origin.position.y;
  if (gw <= 0 || gh <= 0 || gres <= 0.0) {
    return 0;
  }

  // Same quarter layout as buildSubmissionResolvedTileModels (NW, NE, SW, SE).
  constexpr double kQuarterOffsetM = 0.03;
  constexpr double kSubtileHalfExtentM = 0.06;
  static const double kQdx[4] = {-kQuarterOffsetM, kQuarterOffsetM,
                                 -kQuarterOffsetM, kQuarterOffsetM};
  static const double kQdy[4] = {kQuarterOffsetM, kQuarterOffsetM,
                                 -kQuarterOffsetM, -kQuarterOffsetM};

  // Tile range covering the SLAM grid extent.
  const TileCoord corner_a =
    computeTileCoord(gox, goy, origin_x_, origin_y_, tile_size_);
  const TileCoord corner_b = computeTileCoord(
    gox + gw * gres, goy + gh * gres, origin_x_, origin_y_, tile_size_);
  const int min_tx = std::min(corner_a.x, corner_b.x);
  const int max_tx = std::max(corner_a.x, corner_b.x);
  const int min_ty = std::min(corner_a.y, corner_b.y);
  const int max_ty = std::max(corner_a.y, corner_b.y);

  constexpr long kMaxScannedTiles = 40000;  // safety cap for degenerate grids
  const long span_x = static_cast<long>(max_tx) - min_tx + 1;
  const long span_y = static_cast<long>(max_ty) - min_ty + 1;
  if (span_x <= 0 || span_y <= 0 || span_x * span_y > kMaxScannedTiles) {
    return 0;
  }

  int added = 0;
  for (int tx = min_tx; tx <= max_tx; ++tx) {
    for (int ty = min_ty; ty <= max_ty; ++ty) {
      const TileCoord coord{tx, ty};
      if (models.find(coord) != models.end()) {
        continue;  // visited records, Area 4 fill, transitions: already covered
      }

      const auto center = tileCenter(coord, origin_x_, origin_y_, tile_size_);

      SubmissionTileModel model;
      model.coord = coord;
      model.area = TileArea::Unknown;
      model.area_uncertain = true;
      model.committed = false;

      bool any_explored = false;
      for (int q = 0; q < kSubtileCount; ++q) {
        const cv::Mat patch = map_geometry_models_.extractPatch(
          data, gw, gh, gres, gox, goy,
          center.x + kQdx[q], center.y + kQdy[q], kSubtileHalfExtentM);

        // Cheap occupancy prefilter: a quarter the SLAM map barely knows can
        // never pass the explored gate, and skipping the RF forest here keeps
        // the whole-extent scan from starving the sim every publish cycle.
        const int known_cells = cv::countNonZero(patch > -1);
        if (known_cells * 20 < static_cast<int>(patch.total())) {  // <5% known
          continue;
        }

        const auto pred = map_geometry_models_.predictSubtile(patch);
        if (!pred.explored) {
          continue;
        }
        any_explored = true;
        auto & sm = model.subtiles[q];
        sm.wall_north = pred.walls[MapGeometryModels::kNorth];
        sm.wall_east = pred.walls[MapGeometryModels::kEast];
        sm.wall_south = pred.walls[MapGeometryModels::kSouth];
        sm.wall_west = pred.walls[MapGeometryModels::kWest];
        sm.curve_dir = pred.curve_dir;
      }

      if (!any_explored) {
        continue;
      }

      models[coord] = std::move(model);
      ++added;
    }
  }

  return added;
}

void MapperNode::publishSubmissionGeometryMarkers(
  const SubmissionResolvedTileModels & resolved_models,
  const rclcpp::Time & stamp)
{
  if (!submission_geometry_marker_pub_) {
    return;
  }

  visualization_msgs::msg::MarkerArray markers;
  const auto visual_stamp = markerStamp(stamp);

  // Always clear stale geometry first.
  visualization_msgs::msg::Marker clear_marker;
  clear_marker.header.frame_id = marker_frame_;
  clear_marker.header.stamp = visual_stamp;
  clear_marker.action = visualization_msgs::msg::Marker::DELETEALL;
  markers.markers.push_back(clear_marker);

  if (resolved_models.empty()) {
    submission_geometry_marker_pub_->publish(markers);
    return;
  }

  constexpr double kCenterZ = 0.085;
  constexpr double kWallZ = 0.090;
  constexpr double kCurveZ = 0.092;
  constexpr double kArea4Z = 0.080;

  const double subtile_half = tile_size_ * 0.25;        // edge offset (~0.03)
  const double subtile_size = tile_size_ * 0.5;         // subtile side (~0.06)
  const double wall_thickness =
    std::max(0.004, primitive_wall_thickness_m_);        // ~0.01

  // (r,g,b,a) for a quarter-center semantic token.
  const auto center_color = [](const std::string & value) {
    std::array<float, 4> c{0.6f, 0.6f, 0.6f, 0.15f};  // normal/unknown
    if (value == "5") {c = {0.10f, 0.85f, 0.10f, 0.7f};}        // start green
    else if (value == "2") {c = {0.05f, 0.05f, 0.05f, 0.8f};}   // hole black
    else if (value == "3") {c = {0.80f, 0.45f, 0.10f, 0.7f};}   // swamp brown
    else if (value == "4") {c = {0.52f, 0.52f, 0.49f, 0.90f};}  // checkpoint dark silver
    else if (value == "b") {c = {0.10f, 0.30f, 0.95f, 0.7f};}
    else if (value == "p") {c = {0.55f, 0.15f, 0.75f, 0.7f};}
    else if (value == "r") {c = {0.90f, 0.10f, 0.10f, 0.7f};}
    else if (value == "g") {c = {0.10f, 0.75f, 0.30f, 0.7f};}
    else if (value == "o") {c = {0.95f, 0.55f, 0.10f, 0.7f};}
    else if (value == "y") {c = {0.95f, 0.90f, 0.10f, 0.7f};}
    else if (value == "*") {c = {0.85f, 0.10f, 0.85f, 0.5f};}   // area4 magenta
    return c;
  };

  int center_id = 0;
  int wall_id = 0;
  int curve_id = 0;
  int area4_id = 0;

  const SubmissionSubtile kSubmissionSubtiles[4] = {
    SubmissionSubtile::NW,
    SubmissionSubtile::NE,
    SubmissionSubtile::SW,
    SubmissionSubtile::SE};

  const auto matrix_cell_to_local = [this](const MatrixCell & cell) {
    return std::array<double, 2>{
      (static_cast<double>(cell.col) - 2.0) * tile_size_ * 0.25,
      (2.0 - static_cast<double>(cell.row)) * tile_size_ * 0.25};
  };

  const auto add_wall = [&](double cx, double cy, bool horizontal) {
    visualization_msgs::msg::Marker m;
    m.header.frame_id = marker_frame_;
    m.header.stamp = visual_stamp;
    m.ns = "submission_walls";
    m.id = wall_id++;
    m.type = visualization_msgs::msg::Marker::CUBE;
    m.action = visualization_msgs::msg::Marker::ADD;
    m.pose.position.x = cx;
    m.pose.position.y = cy;
    m.pose.position.z = kWallZ;
    m.pose.orientation.w = 1.0;
    m.scale.x = horizontal ? subtile_size : wall_thickness;
    m.scale.y = horizontal ? wall_thickness : subtile_size;
    m.scale.z = 0.05;
    m.color.r = 0.95f;
    m.color.g = 0.95f;
    m.color.b = 0.95f;
    m.color.a = 0.9f;
    markers.markers.push_back(m);
  };

  for (const auto & entry : resolved_models) {
    const SubmissionTileModel & model = entry.second;

    const double tile_cx =
      static_cast<double>(model.coord.x) * tile_size_ + origin_x_;
    const double tile_cy =
      static_cast<double>(model.coord.y) * tile_size_ + origin_y_;

    if (model.area4_wildcard) {
      visualization_msgs::msg::Marker m;
      m.header.frame_id = marker_frame_;
      m.header.stamp = visual_stamp;
      m.ns = "submission_area4";
      m.id = area4_id++;
      m.type = visualization_msgs::msg::Marker::CUBE;
      m.action = visualization_msgs::msg::Marker::ADD;
      m.pose.position.x = tile_cx;
      m.pose.position.y = tile_cy;
      m.pose.position.z = kArea4Z;
      m.pose.orientation.w = 1.0;
      m.scale.x = tile_size_;
      m.scale.y = tile_size_;
      m.scale.z = 0.02;
      m.color.r = 0.85f;
      m.color.g = 0.10f;
      m.color.b = 0.85f;
      m.color.a = 0.30f;
      markers.markers.push_back(m);
      continue;
    }

    for (int i = 0; i < kSubtileCount; ++i) {
      const auto subtile = static_cast<SubtileIndex>(i);
      const double sx = tile_cx + subtileCenterLocalX(subtile, tile_size_);
      const double sy = tile_cy + subtileCenterLocalY(subtile, tile_size_);
      const SubmissionSubtileModel & sm = model.subtiles[i];

      // Quarter center.
      {
        const auto color = center_color(sm.value);
        visualization_msgs::msg::Marker m;
        m.header.frame_id = marker_frame_;
        m.header.stamp = visual_stamp;
        m.ns = "submission_centers";
        m.id = center_id++;
        m.type = visualization_msgs::msg::Marker::CUBE;
        m.action = visualization_msgs::msg::Marker::ADD;
        m.pose.position.x = sx;
        m.pose.position.y = sy;
        m.pose.position.z = kCenterZ;
        m.pose.orientation.w = 1.0;
        m.scale.x = subtile_size * 0.5;
        m.scale.y = subtile_size * 0.5;
        m.scale.z = 0.004;
        m.color.r = color[0];
        m.color.g = color[1];
        m.color.b = color[2];
        m.color.a = color[3];
        markers.markers.push_back(m);
      }

      // Straight subtile walls. Keep this in lock-step with
      // SubmissionMatrixBuilder: curved subtiles ignore straight wall flags.
      if (sm.curve_dir == 0) {
        if (sm.wall_north) {add_wall(sx, sy + subtile_half, true);}
        if (sm.wall_south) {add_wall(sx, sy - subtile_half, true);}
        if (sm.wall_east) {add_wall(sx + subtile_half, sy, false);}
        if (sm.wall_west) {add_wall(sx - subtile_half, sy, false);}
      }

      // Curve drawn from the exact matrix helpers used for judge submission.
      if (sm.curve_dir != 0) {
        const int visual_curve_dir =
          submissionGeometryVisualCurveDir(sm.curve_dir, submission_curve_visual_transform_);
        const SubmissionSubtile submission_subtile = kSubmissionSubtiles[i];
        const auto edge_dirs =
          SubmissionMatrixBuilder::curveEdgeDirections(visual_curve_dir);
        const MatrixCell corner_cell =
          SubmissionMatrixBuilder::curveSuppressedVertex(
            submission_subtile, visual_curve_dir);
        const MatrixCell start_cell =
          SubmissionMatrixBuilder::edgeCell(submission_subtile, edge_dirs[0]);
        const MatrixCell end_cell =
          SubmissionMatrixBuilder::edgeCell(submission_subtile, edge_dirs[1]);

        const auto corner = matrix_cell_to_local(corner_cell);
        const auto start = matrix_cell_to_local(start_cell);
        const auto end = matrix_cell_to_local(end_cell);

        const double start_dx = start[0] - corner[0];
        const double start_dy = start[1] - corner[1];
        const double end_dx = end[0] - corner[0];
        const double end_dy = end[1] - corner[1];
        const double start_radius = std::hypot(start_dx, start_dy);
        const double end_radius = std::hypot(end_dx, end_dy);
        const double radius = 0.5 * (start_radius + end_radius);

        if (radius > 1.0e-9) {
          const double angle_start = std::atan2(start_dy, start_dx);
          const double angle_end = std::atan2(end_dy, end_dx);
          double angle_span = positiveAngularDelta(angle_start, angle_end);
          bool clockwise = false;
          if (angle_span > M_PI) {
            angle_span = positiveAngularDelta(angle_end, angle_start);
            clockwise = true;
          }
          const int segment_count = std::max(12, curve_coverage_bins_);

          visualization_msgs::msg::Marker m;
          m.header.frame_id = marker_frame_;
          m.header.stamp = visual_stamp;
          m.ns = "submission_curves";
          m.id = curve_id++;
          m.type = visualization_msgs::msg::Marker::LINE_STRIP;
          m.action = visualization_msgs::msg::Marker::ADD;
          m.pose.orientation.w = 1.0;
          m.scale.x = wall_thickness;
          m.color.r = 0.20f;
          m.color.g = 0.95f;
          m.color.b = 0.95f;
          m.color.a = 0.9f;
          m.points.reserve(static_cast<std::size_t>(segment_count + 1));

          for (int s = 0; s <= segment_count; ++s) {
            const double u =
              static_cast<double>(s) / static_cast<double>(segment_count);
            const double angle = clockwise ?
              angle_start - angle_span * u :
              angle_start + angle_span * u;
            geometry_msgs::msg::Point point;
            point.x = tile_cx + corner[0] + radius * std::cos(angle);
            point.y = tile_cy + corner[1] + radius * std::sin(angle);
            point.z = kCurveZ;
            m.points.push_back(point);
          }

          markers.markers.push_back(m);
        }
      }
    }
  }

  submission_geometry_marker_pub_->publish(markers);
}
void MapperNode::publishSemanticMapJson(const rclcpp::Time & stamp)
{
  if (!tile_semantic_map_pub_ || !mapping_active_ || !origin_initialized_) {
    return;
  }

  std_msgs::msg::String msg;
  msg.data = semanticMapJson(stamp);
  tile_semantic_map_pub_->publish(msg);
  publishSubmissionMatrix(stamp);
  std::size_t hazard_count = 0U;
  std::size_t wall_count = 0U;
  for (const auto & entry : tile_map_.records()) {
    const auto & record = entry.second;
    if (record.hazard_state != HazardState::None || record.is_hole || record.is_blocked) {
      ++hazard_count;
    }
    if (record.walls.north == WallState::Wall || record.walls.north == WallState::VirtualWall) {
      ++wall_count;
    }
    if (record.walls.east == WallState::Wall || record.walls.east == WallState::VirtualWall) {
      ++wall_count;
    }
    if (record.walls.south == WallState::Wall || record.walls.south == WallState::VirtualWall) {
      ++wall_count;
    }
    if (record.walls.west == WallState::Wall || record.walls.west == WallState::VirtualWall) {
      ++wall_count;
    }
  }
  logRobotEvent(
    "semantic_map_summary",
    {
      {"tile_count", std::to_string(tile_map_.records().size())},
      {"frame_id", marker_frame_},
      {"origin", "(" + numberText(origin_x_, 4) + "," + numberText(origin_y_, 4) + ")"},
      {"updated_tiles", std::to_string(tile_map_.records().size())},
      {"hazards_count", std::to_string(hazard_count)},
      {"walls_count", std::to_string(wall_count)},
      {"victims_count", std::to_string(vision_victims_.size())},
      {"connection_id", std::to_string(bridge_connection_id_)},
    });
  last_semantic_map_publish_stamp_ = stamp;
  has_last_semantic_map_publish_stamp_ = true;
}

void MapperNode::maybePublishSemanticMapJson(const rclcpp::Time & stamp)
{
  if (!publish_semantic_map_json_) {
    return;
  }

  if (!has_last_semantic_map_publish_stamp_) {
    publishSemanticMapJson(stamp);
    return;
  }

  const double elapsed_s = (stamp - last_semantic_map_publish_stamp_).seconds();
  if (elapsed_s < 0.0 || elapsed_s >= semantic_map_publish_period_s_) {
    publishSemanticMapJson(stamp);
  }
}

void MapperNode::publishMapperStatus(const rclcpp::Time & stamp)
{
  if (!mapper_status_pub_) {
    return;
  }

  std_msgs::msg::String msg;
  msg.data = mapperStatusJson(stamp);
  mapper_status_pub_->publish(msg);
  const auto slam_status = slam_map_sampler_.status(stamp);

  const auto validity_signature =
    boolText(slam_status.map_real) + "|" +
    boolText(slam_status.map_available && !slam_status.map_real) + "|" +
    slam_status.rejection_reason + "|" +
    slam_status.frame_id + "|" +
    std::to_string(slam_status.width) + "x" + std::to_string(slam_status.height);

  const auto log_stamp = get_clock()->now();
  double log_elapsed_s = 0.0;
  if (has_last_map_validity_summary_log_stamp_) {
    log_elapsed_s = (log_stamp - last_map_validity_summary_log_stamp_).seconds();
  }

  const bool validity_changed = validity_signature != last_map_validity_summary_signature_;
  const bool log_due =
    !has_last_map_validity_summary_log_stamp_ ||
    map_validity_summary_log_period_s_ == 0.0 ||
    log_elapsed_s < 0.0 ||
    log_elapsed_s >= map_validity_summary_log_period_s_;

  if (validity_changed || log_due) {
    logRobotEvent(
      "map_validity_summary",
      {
        {"slam_map_valid", boolText(slam_status.map_real)},
        {"map_is_dummy", boolText(slam_status.map_available && !slam_status.map_real)},
        {"rejection_reason", slam_status.rejection_reason},
        {"known", std::to_string(slam_status.known_cells)},
        {"free", std::to_string(slam_status.free_cells)},
        {"occupied", std::to_string(slam_status.occupied_cells)},
        {"unknown", std::to_string(slam_status.unknown_cells)},
        {"map_age", numberText(slam_status.age_sec, 3)},
        {"frame_id", slam_status.frame_id},
        {"map_size", std::to_string(slam_status.width) + "x" + std::to_string(slam_status.height)},
        {"connection_id", std::to_string(bridge_connection_id_)},
        {"throttled", boolText(!validity_changed && has_last_map_validity_summary_log_stamp_)},
      });
    last_map_validity_summary_log_stamp_ = log_stamp;
    has_last_map_validity_summary_log_stamp_ = true;
    last_map_validity_summary_signature_ = validity_signature;
  }

  last_status_publish_stamp_ = stamp;
  has_last_status_publish_stamp_ = true;
}

void MapperNode::maybePublishMapperStatus(const rclcpp::Time & stamp)
{
  if (!has_last_status_publish_stamp_) {
    publishMapperStatus(stamp);
    return;
  }

  const double elapsed_s = (stamp - last_status_publish_stamp_).seconds();
  if (elapsed_s < 0.0 || elapsed_s >= status_publish_period_s_) {
    publishMapperStatus(stamp);
  }
}

void MapperNode::publishMapperEvent(const std::string & json) const
{
  if (!mapper_events_pub_) {
    return;
  }

  std_msgs::msg::String msg;
  msg.data = json;
  mapper_events_pub_->publish(msg);
}

void MapperNode::logRobotEvent(
  EventLevel level,
  const std::string & event,
  const std::vector<std::pair<std::string, std::string>> & fields) const
{
  std::ostringstream oss;
  oss << "ROBOT_EVENT node=mapper event=" << event;
  for (const auto & field : fields) {
    oss << ' ' << field.first << '=' << sanitizeRobotEventValue(field.second);
  }

  const auto line = oss.str();
  switch (level) {
    case EventLevel::Warn:
      RCLCPP_WARN(get_logger(), "%s", line.c_str());
      break;
    case EventLevel::Error:
      RCLCPP_ERROR(get_logger(), "%s", line.c_str());
      break;
    case EventLevel::Debug:
      RCLCPP_DEBUG(get_logger(), "%s", line.c_str());
      break;
    case EventLevel::Info:
    default:
      RCLCPP_INFO(get_logger(), "%s", line.c_str());
      break;
  }
}

void MapperNode::logRobotEvent(
  const std::string & event,
  const std::vector<std::pair<std::string, std::string>> & fields) const
{
  logRobotEvent(EventLevel::Info, event, fields);
}

std::string MapperNode::tileChangedEventJson(
  const TileCoord & previous_coord,
  const TileRecord & record,
  const rclcpp::Time & stamp) const
{
  std::ostringstream oss;
  oss
    << "{\"stamp\":" << stampToJson(stamp)
    << ",\"event\":\"tile_changed\""
    << ",\"tile\":" << tileCoordToJson(record.coord)
    << ",\"previous_tile\":" << tileCoordToJson(previous_coord)
    << ",\"area\":\"" << tileAreaToString(record.area)
    << "\",\"kind\":\"" << tileKindToString(record.kind)
    << "\"}";
  return oss.str();
}

std::string MapperNode::semanticEventJson(
  const char * event,
  const TileRecord & record,
  const rclcpp::Time & stamp) const
{
  std::ostringstream oss;
  oss
    << "{\"stamp\":" << stampToJson(stamp)
    << ",\"event\":\"" << event
    << "\",\"tile\":" << tileCoordToJson(record.coord)
    << ",\"area\":\"" << tileAreaToString(record.area)
    << "\",\"kind\":\"" << tileKindToString(record.kind)
    << "\"}";
  return oss.str();
}

std::string MapperNode::hazardEventJson(
  const char * event,
  const TileRecord & record,
  const rclcpp::Time & stamp,
  const std::optional<TileCoord> & robot_tile,
  double heading_yaw,
  double robot_x,
  double robot_y,
  double sensor_x,
  double sensor_y) const
{
  const char * heading_direction = cardinalDirectionForYaw(heading_yaw);
  const char * edge_direction = robot_tile ?
    cardinalDirectionBetweenAdjacentTiles(*robot_tile, record.coord) :
    nullptr;
  bool robot_tile_is_safe = false;
  if (robot_tile) {
    if (!(*robot_tile == record.coord)) {
      robot_tile_is_safe = true;
      const auto robot_record = tile_map_.records().find(*robot_tile);
      if (
        robot_record != tile_map_.records().end() &&
        (
          isConfirmedBlackHoleHazard(robot_record->second) ||
          robot_record->second.is_hole ||
          robot_record->second.is_blocked
        ))
      {
        robot_tile_is_safe = false;
      }
    }
  }

  std::ostringstream oss;
  oss << std::boolalpha << std::fixed << std::setprecision(6);
  oss
    << "{\"stamp\":" << stampToJson(stamp)
    << ",\"event\":\"" << event
    << "\",\"tile\":" << tileCoordToJson(record.coord)
    << ",\"area\":\"" << tileAreaToString(record.area)
    << "\",\"kind\":\"" << tileKindToString(record.kind)
    << "\",\"hazard_type\":\"" << hazardTypeToString(record.hazard_type)
    << "\",\"hazard_tile\":" << tileCoordToJson(record.coord)
    << ",\"sensor_tile\":" << tileCoordToJson(record.coord)
    << ",\"observed_tile\":" << tileCoordToJson(record.coord)
    << ",\"current_tile\":";

  if (robot_tile) {
    oss << tileCoordToJson(*robot_tile);
  } else {
    oss << "null";
  }

  oss << ",\"robot_tile\":";
  if (robot_tile) {
    oss << tileCoordToJson(*robot_tile);
  } else {
    oss << "null";
  }

  oss << ",\"base_tile\":";
  if (robot_tile) {
    oss << tileCoordToJson(*robot_tile);
  } else {
    oss << "null";
  }

  oss
    << ",\"heading_yaw\":" << heading_yaw
    << ",\"heading_direction\":\"" << heading_direction << "\""
    << ",\"robot_tile_is_safe\":" << robot_tile_is_safe
    << ",\"color_sensor\":{"
    << "\"forward_offset_m\":" << color_sensor_forward_offset_
    << ",\"lateral_offset_m\":" << color_sensor_lateral_offset_
    << ",\"world_x\":" << sensor_x
    << ",\"world_y\":" << sensor_y
    << ",\"robot_x\":" << robot_x
    << ",\"robot_y\":" << robot_y
    << ",\"robot_yaw\":" << heading_yaw
    << "}"
    << ",\"hazard\":{"
    << "\"state\":\"" << hazardStateToString(record.hazard_state)
    << "\",\"type\":\"" << hazardTypeToString(record.hazard_type)
    << "\",\"confidence\":" << std::clamp(record.hazard_confidence, 0.0, 1.0)
    << ",\"source\":\"" << hazardSourceToString(record.hazard_source)
    << "\",\"edge\":\"" << (edge_direction != nullptr ? edge_direction : "UNKNOWN")
    << "\",\"observed_by\":\"color_sensor\""
    << ",\"robot_tile_is_safe\":" << robot_tile_is_safe
    << ",\"hit_count\":" << record.hazard_hit_count
    << ",\"age_sec\":";

  if (record.hazard_last_seen.nanoseconds() != 0) {
    oss << std::max(0.0, (stamp - record.hazard_last_seen).seconds());
  } else {
    oss << "null";
  }

  oss << ",\"ttl_sec\":" << record.hazard_ttl_sec << "}";

  if (robot_tile && edge_direction != nullptr) {
    oss
      << ",\"edge\":{"
      << "\"from\":" << tileCoordToJson(*robot_tile)
      << ",\"to\":" << tileCoordToJson(record.coord)
      << ",\"direction\":\"" << edge_direction << "\"}";
  }

  oss << "}";
  return oss.str();
}

std::string MapperNode::teleportEventJson(
  double distance_delta,
  double yaw_delta,
  const TileCoord & coord,
  const rclcpp::Time & stamp) const
{
  std::ostringstream oss;
  oss << std::fixed << std::setprecision(3);
  oss
    << "{\"stamp\":" << stampToJson(stamp)
    << ",\"event\":\"teleport_detected\""
    << ",\"distance_delta\":" << distance_delta
    << ",\"yaw_delta\":" << yaw_delta
    << ",\"tile\":" << tileCoordToJson(coord)
    << "}";
  return oss.str();
}

bool MapperNode::hasSemanticState(const TileRecord & record)
{
  return record.is_start ||
    record.is_checkpoint ||
    record.is_swamp ||
    record.is_hole ||
    record.has_black_hole_border ||
    record.is_blocked ||
    record.hazard_state != HazardState::None ||
    record.is_transition ||
    record.has_obstacle ||
    record.kind != TileKind::Unknown ||
    record.area != TileArea::Unknown ||
    record.floor_color != FloorColorClass::Unknown;
}

void MapperNode::updateCurrentAreaFromRecord(
  const TileRecord & record,
  const rclcpp::Time & stamp)
{
  if (record.area == TileArea::Unknown) {
    return;
  }

  current_area_ = record.area;
  current_area_known_ = true;
  last_area_update_stamp_ = stamp;
}

void MapperNode::updateCurrentAreaFromTransition(
  FloorColorClass color_class,
  const rclcpp::Time & stamp)
{
  const auto transition_areas = transitionAreasForColor(color_class);
  if (!transition_areas || !current_area_known_) {
    return;
  }

  const auto from = (*transition_areas)[0];
  const auto to = (*transition_areas)[1];
  if (current_area_ == from) {
    current_area_ = to;
  } else if (current_area_ == to) {
    current_area_ = from;
  } else {
    return;
  }

  last_area_update_stamp_ = stamp;
}

void MapperNode::beginPendingTransitionCrossing(
  TileCoord transition_tile,
  FloorColorClass color,
  TileCoord robot_tile)
{
  if (
    pending_transition_crossing_ &&
    pending_transition_crossing_->tile == transition_tile &&
    pending_transition_crossing_->color == color)
  {
    return;
  }

  PendingTransitionCrossing pending;
  pending.tile = transition_tile;
  pending.color = color;
  pending.robot_entered_transition = robot_tile == transition_tile;

  if (!(robot_tile == transition_tile)) {
    const int dx = std::abs(robot_tile.x - transition_tile.x);
    const int dy = std::abs(robot_tile.y - transition_tile.y);
    if (dx + dy == 1) {
      pending.entry_tile = robot_tile;
    }
  } else if (
    tile_before_current_tile_ &&
    std::abs(tile_before_current_tile_->x - transition_tile.x) +
    std::abs(tile_before_current_tile_->y - transition_tile.y) == 1)
  {
    pending.entry_tile = *tile_before_current_tile_;
  }

  pending_transition_crossing_ = pending;
  active_transition_tile_ = transition_tile;
  active_transition_color_ = color;

  logRobotEvent(
    "area_transition_pending",
    {
      {"transition_color", floorColorClassToLogString(color)},
      {"transition_tile", tileCoordToJson(transition_tile)},
      {"robot_tile", tileCoordToJson(robot_tile)},
      {"entry_tile", pending.entry_tile ? tileCoordToJson(*pending.entry_tile) : std::string("none")},
      {"robot_entered_transition", pending.robot_entered_transition ? "true" : "false"},
      {"current_area", tileAreaToString(current_area_)},
      {"reason", "awaiting_complete_tile_crossing"},
      {"connection_id", std::to_string(bridge_connection_id_)},
    });
}

void MapperNode::clearPendingTransitionCrossing()
{
  pending_transition_crossing_.reset();
  active_transition_tile_.reset();
  active_transition_color_ = FloorColorClass::Unknown;
}

void MapperNode::updatePendingTransitionCrossing(
  TileCoord previous_tile,
  TileCoord new_tile,
  const rclcpp::Time & stamp)
{
  if (!pending_transition_crossing_) {
    return;
  }

  auto & pending = *pending_transition_crossing_;

  if (!pending.robot_entered_transition) {
    if (new_tile == pending.tile) {
      pending.robot_entered_transition = true;
      if (!pending.entry_tile) {
        pending.entry_tile = previous_tile;
      }

      logRobotEvent(
        "area_transition_entered",
        {
          {"transition_color", floorColorClassToLogString(pending.color)},
          {"transition_tile", tileCoordToJson(pending.tile)},
          {"entry_tile", pending.entry_tile ? tileCoordToJson(*pending.entry_tile) : std::string("none")},
          {"current_area", tileAreaToString(current_area_)},
          {"connection_id", std::to_string(bridge_connection_id_)},
        });
      return;
    }

    if (pending.entry_tile && !(new_tile == *pending.entry_tile)) {
      const auto transition_tile = pending.tile;
      const auto transition_color = pending.color;
      clearPendingTransitionCrossing();
      logRobotEvent(
        "area_transition_cancelled",
        {
          {"transition_color", floorColorClassToLogString(transition_color)},
          {"transition_tile", tileCoordToJson(transition_tile)},
          {"exit_tile", tileCoordToJson(new_tile)},
          {"current_area", tileAreaToString(current_area_)},
          {"reason", "robot_moved_away_before_entering_transition"},
          {"connection_id", std::to_string(bridge_connection_id_)},
        });
    }
    return;
  }

  if (new_tile == pending.tile) {
    return;
  }

  const auto transition_tile = pending.tile;
  const auto transition_color = pending.color;
  const auto entry_tile = pending.entry_tile;

  if (
    entry_tile &&
    !(new_tile == *entry_tile))
  {
    struct TransitionGateDirection
    {
      SlamCardinalDirection direction;
    };

    const std::array<TransitionGateDirection, 4> directions = {{
      TransitionGateDirection{SlamCardinalDirection::North},
      TransitionGateDirection{SlamCardinalDirection::East},
      TransitionGateDirection{SlamCardinalDirection::South},
      TransitionGateDirection{SlamCardinalDirection::West},
    }};

    const auto entry_direction =
      cardinalDirectionBetween(transition_tile, *entry_tile);
    const auto exit_direction =
      cardinalDirectionBetween(transition_tile, new_tile);

    const SubmissionResolvedWalls resolved_walls =
      buildSubmissionResolvedWalls(stamp);
    const auto resolved_walls_it = resolved_walls.find(transition_tile);
    const auto transition_record_it = tile_map_.records().find(transition_tile);
    const EdgeWalls transition_walls =
      resolved_walls_it != resolved_walls.end() ?
      resolved_walls_it->second :
      (
        transition_record_it != tile_map_.records().end() ?
        transition_record_it->second.walls :
        EdgeWalls{});

    const SubmissionResolvedTileModels resolved_models =
      buildSubmissionResolvedTileModels(stamp);
    const auto resolved_model_it = resolved_models.find(transition_tile);
    const SubmissionTileModel * transition_model =
      resolved_model_it != resolved_models.end() ? &resolved_model_it->second : nullptr;

    const auto resolvedWallStateForTileSide =
      [&](const TileCoord & coord, SlamCardinalDirection direction)
    {
      const auto resolved_it = resolved_walls.find(coord);
      if (resolved_it != resolved_walls.end()) {
        return wallStateForDirection(resolved_it->second, direction);
      }

      const auto record_it = tile_map_.records().find(coord);
      if (record_it != tile_map_.records().end()) {
        return wallStateForDirection(record_it->second.walls, direction);
      }

      return WallState::Unknown;
    };

    const auto resolvedModelHasWallOnTileSide =
      [&](const TileCoord & coord, SlamCardinalDirection direction)
    {
      const auto model_it = resolved_models.find(coord);
      return
        model_it != resolved_models.end() &&
        submissionModelHasWallOnSide(model_it->second, direction);
    };

    int blocked_exit_side_count = 0;
    int open_exit_side_count = 0;
    int unknown_exit_side_count = 0;
    std::optional<SlamCardinalDirection> only_unblocked_direction;
    std::string gate_sides;

    if (entry_direction && exit_direction) {
      for (const auto & direction : directions) {
        if (direction.direction == *entry_direction) {
          continue;
        }

        const WallState wall_state =
          wallStateForDirection(transition_walls, direction.direction);
        const bool model_wall =
          transition_model != nullptr &&
          submissionModelHasWallOnSide(*transition_model, direction.direction);
        const TileCoord neighbor_tile =
          adjacentTileInDirection(transition_tile, direction.direction);
        const SlamCardinalDirection neighbor_direction =
          oppositeSlamCardinalDirection(direction.direction);
        const WallState neighbor_wall_state =
          resolvedWallStateForTileSide(neighbor_tile, neighbor_direction);
        const bool neighbor_model_wall =
          resolvedModelHasWallOnTileSide(neighbor_tile, neighbor_direction);
        const bool blocked =
          model_wall ||
          neighbor_model_wall ||
          isWallState(wall_state) ||
          isWallState(neighbor_wall_state);
        const bool explicitly_open =
          wall_state == WallState::Open ||
          neighbor_wall_state == WallState::Open;

        if (!gate_sides.empty()) {
          gate_sides += ",";
        }
        gate_sides += slamCardinalDirectionToString(direction.direction);
        gate_sides += "=";
        gate_sides += blocked ?
          "blocked" :
          (explicitly_open ? "open" : "unknown");
        if (model_wall && !isWallState(wall_state)) {
          gate_sides += "+subtile_wall";
        }
        if (isWallState(neighbor_wall_state)) {
          gate_sides += "+neighbor_wall";
        }
        if (neighbor_model_wall && !isWallState(neighbor_wall_state)) {
          gate_sides += "+neighbor_subtile_wall";
        }

        if (blocked) {
          blocked_exit_side_count++;
        } else {
          only_unblocked_direction = direction.direction;
          if (explicitly_open) {
            open_exit_side_count++;
          } else {
            unknown_exit_side_count++;
          }
        }
      }
    }

    const bool transition_wall_gate_resolved =
      entry_direction &&
      exit_direction &&
      blocked_exit_side_count >= 2 &&
      (open_exit_side_count + unknown_exit_side_count) == 1 &&
      only_unblocked_direction.has_value();

    const bool transition_wall_gate_allows_exit =
      transition_wall_gate_resolved &&
      *exit_direction == *only_unblocked_direction;

    if (!entry_direction || !exit_direction) {
      clearPendingTransitionCrossing();

      logRobotEvent(
        "area_transition_cancelled",
        {
          {"transition_color", floorColorClassToLogString(transition_color)},
          {"transition_tile", tileCoordToJson(transition_tile)},
          {"entry_tile", tileCoordToJson(*entry_tile)},
          {"exit_tile", tileCoordToJson(new_tile)},
          {"entry_direction", entry_direction ? slamCardinalDirectionToString(*entry_direction) : "UNKNOWN"},
          {"exit_direction", exit_direction ? slamCardinalDirectionToString(*exit_direction) : "UNKNOWN"},
          {"allowed_exit_direction", "UNKNOWN"},
          {"blocked_exit_side_count", std::to_string(blocked_exit_side_count)},
          {"open_exit_side_count", std::to_string(open_exit_side_count)},
          {"unknown_exit_side_count", std::to_string(unknown_exit_side_count)},
          {"gate_sides", gate_sides.empty() ? std::string("none") : gate_sides},
          {"current_area", tileAreaToString(current_area_)},
          {"accepted", "false"},
          {"reason", "non_cardinal_transition_crossing"},
          {"connection_id", std::to_string(bridge_connection_id_)},
        });
      return;
    }

    if (transition_wall_gate_resolved && !transition_wall_gate_allows_exit) {
      clearPendingTransitionCrossing();

      logRobotEvent(
        "area_transition_cancelled",
        {
          {"transition_color", floorColorClassToLogString(transition_color)},
          {"transition_tile", tileCoordToJson(transition_tile)},
          {"entry_tile", tileCoordToJson(*entry_tile)},
          {"exit_tile", tileCoordToJson(new_tile)},
          {"entry_direction", entry_direction ? slamCardinalDirectionToString(*entry_direction) : "UNKNOWN"},
          {"exit_direction", exit_direction ? slamCardinalDirectionToString(*exit_direction) : "UNKNOWN"},
          {"allowed_exit_direction", transition_wall_gate_resolved ? slamCardinalDirectionToString(*only_unblocked_direction) : "UNKNOWN"},
          {"blocked_exit_side_count", std::to_string(blocked_exit_side_count)},
          {"open_exit_side_count", std::to_string(open_exit_side_count)},
          {"unknown_exit_side_count", std::to_string(unknown_exit_side_count)},
          {"gate_sides", gate_sides.empty() ? std::string("none") : gate_sides},
          {"current_area", tileAreaToString(current_area_)},
          {"accepted", "false"},
          {"reason", "exit_side_blocked_by_transition_walls"},
          {"connection_id", std::to_string(bridge_connection_id_)},
        });
      return;
    }

    const TileArea previous_area = current_area_;
    updateCurrentAreaFromTransition(transition_color, stamp);
    const bool area_changed =
      current_area_known_ &&
      current_area_ != previous_area;

    if (area_changed) {
      last_applied_transition_tile_ = transition_tile;
      last_applied_transition_color_ = transition_color;
      last_applied_transition_stamp_ = stamp;
    }

    clearPendingTransitionCrossing();

    logRobotEvent(
      area_changed ? "area_transition_applied" : "area_transition_ignored",
      {
        {"transition_color", floorColorClassToLogString(transition_color)},
        {"transition_tile", tileCoordToJson(transition_tile)},
        {"entry_tile", tileCoordToJson(*entry_tile)},
        {"exit_tile", tileCoordToJson(new_tile)},
        {"entry_direction", slamCardinalDirectionToString(*entry_direction)},
        {"exit_direction", slamCardinalDirectionToString(*exit_direction)},
        {"allowed_exit_direction", transition_wall_gate_resolved ? slamCardinalDirectionToString(*only_unblocked_direction) : "UNKNOWN"},
        {"blocked_exit_side_count", std::to_string(blocked_exit_side_count)},
        {"open_exit_side_count", std::to_string(open_exit_side_count)},
        {"unknown_exit_side_count", std::to_string(unknown_exit_side_count)},
        {"gate_sides", gate_sides.empty() ? std::string("none") : gate_sides},
        {"previous_area", tileAreaToString(previous_area)},
        {"new_area", tileAreaToString(current_area_)},
        {"accepted", area_changed ? "true" : "false"},
        {"reason", area_changed ? (transition_wall_gate_resolved ? "completed_wall_gated_transition_corridor" : "completed_transition_corridor_wall_gate_ambiguous") : "current_area_not_connected_to_transition"},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  clearPendingTransitionCrossing();

  logRobotEvent(
    "area_transition_cancelled",
    {
      {"transition_color", floorColorClassToLogString(transition_color)},
      {"transition_tile", tileCoordToJson(transition_tile)},
      {"entry_tile", entry_tile ? tileCoordToJson(*entry_tile) : std::string("none")},
      {"exit_tile", tileCoordToJson(new_tile)},
      {"current_area", tileAreaToString(current_area_)},
      {"reason", "robot_returned_to_entry_side"},
      {"connection_id", std::to_string(bridge_connection_id_)},
    });
}

void MapperNode::assignCurrentAreaToRecord(TileRecord & record, const rclcpp::Time & stamp)
{
  if (!current_area_known_ || record.area != TileArea::Unknown) {
    return;
  }

  if (area_assignment_requires_visit_ && !record.visited) {
    return;
  }

  record.area = current_area_;
  updateCurrentAreaFromRecord(record, stamp);
}

bool MapperNode::updateHazardFromFloorColor(
  TileRecord & record,
  FloorColorClass color_class,
  double confidence,
  const rclcpp::Time & stamp) const
{
  const auto reset_hazard =
    [&record]() {
      record.hazard_state = HazardState::None;
      record.hazard_type = HazardType::Unknown;
      record.hazard_source = HazardSource::Unknown;
      record.hazard_edge = HazardEdge::Unknown;
      record.hazard_confidence = 0.0;
      record.hazard_hit_count = 0;
      record.hazard_normal_hit_count = 0;
      record.hazard_ttl_sec = 0.0;
      record.hazard_last_seen = rclcpp::Time{};
    };

  const bool confirmed_black_hole = isConfirmedBlackHoleHazard(record);

  if (color_class == FloorColorClass::BlackHoleBorder) {
    record.has_black_hole_border = true;
    record.is_hole = true;
    record.is_blocked = true;
    record.kind = TileKind::Hole;
    record.hazard_type = HazardType::BlackHole;
    record.hazard_source = HazardSource::FloorColor;
    record.hazard_edge = HazardEdge::Unknown;
    record.hazard_last_seen = stamp;
    record.hazard_ttl_sec = 0.0;
    record.hazard_normal_hit_count = 0;
    record.hazard_confidence = std::max(record.hazard_confidence, confidence);
    record.hazard_hit_count = std::max(1, record.hazard_hit_count + 1);
    record.hazard_state = HazardState::Confirmed;
    return true;
  }

  if (color_class == FloorColorClass::Normal) {
    if (confirmed_black_hole && hazard_preserve_confirmed_black_hole_) {
      return true;
    }

    if (record.hazard_state != HazardState::Rejected) {
      reset_hazard();
    }

    return false;
  }

  if (color_class == FloorColorClass::BrownSwamp) {
    record.hazard_state = HazardState::Confirmed;
    record.hazard_type = HazardType::Swamp;
  } else if (color_class == FloorColorClass::SilverCheckpoint) {
    record.hazard_state = HazardState::Confirmed;
    record.hazard_type = HazardType::Checkpoint;
  } else if (transitionAreasForColor(color_class).has_value()) {
    record.hazard_state = HazardState::Confirmed;
    record.hazard_type = HazardType::ColoredArea;
  } else {
    return confirmed_black_hole && hazard_preserve_confirmed_black_hole_;
  }

  record.hazard_source = HazardSource::FloorColor;
  record.hazard_edge = HazardEdge::Unknown;
  record.hazard_confidence = confidence;
  record.hazard_hit_count = std::max(1, record.hazard_hit_count + 1);
  record.hazard_normal_hit_count = 0;
  record.hazard_ttl_sec = 0.0;
  record.hazard_last_seen = stamp;
  return false;
}

bool MapperNode::useArea4GeometryForTile(TileArea area) const
{
  return use_area4_all_ || area == TileArea::Area4;
}

void MapperNode::visionClassificationCallback(const std_msgs::msg::String::SharedPtr msg)
{
  if (!msg) {
    return;
  }

  const std::vector<std::string> parts = splitPipeFields(msg->data);
  if (parts.size() != 11U) {
    logRobotEvent(
      EventLevel::Warn,
      "vision_classification_ignored",
      {
        {"reason", "invalid_payload"},
        {"raw_payload", msg->data},
      });
    return;
  }

  const std::string & kind = parts[0];
  const std::string & class_name = parts[1];
  if (kind != "victim" && kind != "target") {
    logRobotEvent(
      "vision_classification_ignored",
      {
        {"reason", "non_matrix_kind"},
        {"kind", kind},
        {"class", class_name},
      });
    return;
  }
  if (class_name.empty() || class_name == "none" || class_name == "fake") {
    return;
  }

  int tile_x = 0;
  int tile_y = 0;
  double yaw = 0.0;
  double center_x = 0.0;
  double image_width = 0.0;
  double confidence = 0.0;
  try {
    tile_x = std::stoi(parts[3]);
    tile_y = std::stoi(parts[4]);
    yaw = std::stod(parts[6]);
    center_x = std::stod(parts[7]);
    image_width = std::stod(parts[8]);
    confidence = std::stod(parts[10]);
  } catch (const std::exception &) {
    logRobotEvent(
      EventLevel::Warn,
      "vision_classification_ignored",
      {
        {"reason", "invalid_numeric_value"},
        {"raw_payload", msg->data},
      });
    return;
  }

  if (!std::isfinite(yaw) ||
      !std::isfinite(center_x) ||
      !std::isfinite(image_width) ||
      !std::isfinite(confidence) ||
      image_width <= 0.0)
  {
    logRobotEvent(
      EventLevel::Warn,
      "vision_classification_ignored",
      {
        {"reason", "non_finite_numeric_value"},
        {"raw_payload", msg->data},
      });
    return;
  }

  const std::string & camera = parts[5];
  const double camera_yaw = yaw + (camera == "right" ? -0.5 * M_PI : 0.5 * M_PI);
  const WallDirection wall = wallDirectionFromCardinal(cardinalDirectionForYaw(camera_yaw));
  const bool image_left_half = center_x < image_width * 0.5;
  const SubmissionSubtile subtile = subtileForWallImagePosition(wall, image_left_half);

  VisionVictimObservation observation;
  observation.tile = TileCoord{tile_x, tile_y};
  observation.mark.subtile = subtile;
  observation.mark.wall = wall;
  observation.mark.code = class_name.substr(0, 1);
  observation.camera = camera;
  observation.confidence = confidence;

  for (auto & existing : vision_victims_) {
    if (existing.tile == observation.tile &&
        existing.mark.subtile == observation.mark.subtile &&
        existing.mark.wall == observation.mark.wall &&
        existing.mark.code == observation.mark.code)
    {
      existing.confidence = std::max(existing.confidence, confidence);
      return;
    }
  }

  vision_victims_.push_back(observation);
  logRobotEvent(
    "vision_mark_added_to_submission",
    {
      {"tile", "(" + std::to_string(tile_x) + "," + std::to_string(tile_y) + ")"},
      {"kind", kind},
      {"class", observation.mark.code},
      {"camera", camera},
      {"wall", wallDirectionCode(wall)},
      {"subtile", submissionSubtileCode(subtile)},
      {"confidence", numberText(confidence, 3)},
    });
}

void MapperNode::holeDetectionCallback(const std_msgs::msg::String::SharedPtr msg)
{
  if (!msg) {
    return;
  }

  std::vector<std::string> parts;
  std::stringstream ss(msg->data);
  std::string part;

  while (std::getline(ss, part, '|')) {
    parts.push_back(part);
  }

  if (parts.size() != 5U && parts.size() != 12U) {
    RCLCPP_WARN(
      get_logger(),
      "Invalid controller hole detection payload: '%s'",
      msg->data.c_str());
    logRobotEvent(
      EventLevel::Warn,
      "controller_hole_ignored",
      {
        {"accepted", "false"},
        {"reason", "invalid_payload"},
        {"raw_payload", msg->data},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  double robot_x = 0.0;
  double robot_y = 0.0;
  double yaw = 0.0;
  double confidence = 0.0;
  std::string legacy_direction = "none";
  int legacy_current_x = 0;
  int legacy_current_y = 0;
  int legacy_target_x = 0;
  int legacy_target_y = 0;
  double requested_distance_m = -1.0;
  double traveled_before_stop_m = -1.0;

  try {
    robot_x = std::stod(parts[0]);
    robot_y = std::stod(parts[1]);
    yaw = std::stod(parts[2]);
    confidence = std::stod(parts[4]);
    if (parts.size() == 12U) {
      legacy_direction = parts[5];
      legacy_current_x = std::stoi(parts[6]);
      legacy_current_y = std::stoi(parts[7]);
      legacy_target_x = std::stoi(parts[8]);
      legacy_target_y = std::stoi(parts[9]);
      requested_distance_m = std::stod(parts[10]);
      traveled_before_stop_m = std::stod(parts[11]);
    }
  } catch (const std::exception &) {
    RCLCPP_WARN(
      get_logger(),
      "Invalid numeric value in controller hole detection payload: '%s'",
      msg->data.c_str());
    logRobotEvent(
      EventLevel::Warn,
      "controller_hole_ignored",
      {
        {"accepted", "false"},
        {"reason", "invalid_numeric_value"},
        {"raw_payload", msg->data},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  if (
    !std::isfinite(robot_x) ||
    !std::isfinite(robot_y) ||
    !std::isfinite(yaw) ||
    !std::isfinite(confidence) ||
    (parts.size() == 12U && (
      !std::isfinite(requested_distance_m) ||
      !std::isfinite(traveled_before_stop_m))))
  {
    logRobotEvent(
      EventLevel::Warn,
      "controller_hole_ignored",
      {
        {"accepted", "false"},
        {"reason", "non_finite_numeric_value"},
        {"raw_payload", msg->data},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  if (!mapping_active_ || !origin_initialized_) {
    logRobotEvent(
      EventLevel::Warn,
      "controller_hole_ignored",
      {
        {"accepted", "false"},
        {"reason", !mapping_active_ ? "mapping_inactive" : "origin_not_initialized"},
        {"source", parts[3]},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  confidence = std::clamp(confidence, 0.0, 1.0);
  const std::string source = parts[3];

  const auto stamp = get_clock()->now();

  const auto finite_plausible_world_point =
    [&](double x, double y) {
      return
        std::isfinite(x) &&
        std::isfinite(y) &&
        std::fabs(x) <= semantic_observation_max_abs_world_m_ &&
        std::fabs(y) <= semantic_observation_max_abs_world_m_;
    };

  if (!finite_plausible_world_point(robot_x, robot_y)) {
    logRobotEvent(
      EventLevel::Warn,
      "controller_hole_ignored",
      {
        {"accepted", "false"},
        {"reason", "invalid_robot_world_coordinate"},
        {"source", source},
        {"confidence", numberText(confidence, 3)},
        {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
        {"robot_yaw", numberText(yaw, 4)},
        {"max_abs_world_m", numberText(semantic_observation_max_abs_world_m_, 3)},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  const auto robot_coord = computeTileCoord(
    robot_x,
    robot_y,
    origin_x_,
    origin_y_,
    tile_size_);

  auto reject_hole = [&](const std::string & reason,
                         double probe_x_value,
                         double probe_y_value,
                         const std::optional<TileCoord> & candidate_tile,
                         const std::string & projection_method_value,
                         double projection_distance_value,
                         const std::vector<std::pair<std::string, std::string>> & extra = {}) {
    std::vector<std::pair<std::string, std::string>> fields = {
      {"accepted", "false"},
      {"reason", reason},
      {"source", source},
      {"confidence", numberText(confidence, 3)},
      {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
      {"robot_yaw", numberText(yaw, 4)},
      {"probe_world_xy", "(" + numberText(probe_x_value, 4) + "," + numberText(probe_y_value, 4) + ")"},
      {"robot_tile", tileCoordToJson(robot_coord)},
      {"candidate_hole_tile", candidate_tile ? tileCoordToJson(*candidate_tile) : std::string("none")},
      {"projection_method", projection_method_value},
      {"projection_distance_m", numberText(projection_distance_value, 4)},
      {"legacy_direction", legacy_direction},
      {"connection_id", std::to_string(bridge_connection_id_)},
    };
    fields.insert(fields.end(), extra.begin(), extra.end());
    logRobotEvent(EventLevel::Warn, "controller_hole_ignored", fields);
  };

  std::optional<LegacyDirectionVector> legacy_direction_vector;
  if (parts.size() == 12U) {
    legacy_direction_vector = legacyDirectionToWorldVector(legacy_direction);
  }

  const double c = std::cos(yaw);
  const double s = std::sin(yaw);
  double sensor_x =
    robot_x +
    c * color_sensor_forward_offset_ -
    s * color_sensor_lateral_offset_;
  double sensor_y =
    robot_y +
    s * color_sensor_forward_offset_ +
    c * color_sensor_lateral_offset_;

  double probe_dir_x = c;
  double probe_dir_y = s;
  std::string projection_method;
  double projection_distance = 0.0;
  double probe_x = sensor_x;
  double probe_y = sensor_y;

  if (source == "floor_color") {
    projection_method = "color_sensor_offset";
    projection_distance = std::hypot(sensor_x - robot_x, sensor_y - robot_y);
  } else {
    projection_method = "yaw_fixed_distance";
    projection_distance = legacy_hole_projection_distance_m_;
  }

  if (source != "floor_color" && legacy_direction_vector) {
    probe_dir_x = legacy_direction_vector->x;
    probe_dir_y = legacy_direction_vector->y;
    projection_method = "legacy_planned_direction";

    const double remaining_to_target_m = requested_distance_m - traveled_before_stop_m;
    if (requested_distance_m > 0.0 && traveled_before_stop_m >= 0.0 && remaining_to_target_m > 0.0) {
      projection_distance = std::clamp(
        remaining_to_target_m,
        tile_size_ * 0.35,
        tile_size_ * 1.50);
      projection_method = "legacy_planned_direction_remaining_distance";
    }
  }

  if (source != "floor_color") {
    probe_x = robot_x + probe_dir_x * projection_distance;
    probe_y = robot_y + probe_dir_y * projection_distance;
  }

  if (!finite_plausible_world_point(probe_x, probe_y)) {
    reject_hole(
      "invalid_probe_world_coordinate",
      probe_x,
      probe_y,
      std::nullopt,
      projection_method,
      projection_distance,
      {
        {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
        {"max_abs_world_m", numberText(semantic_observation_max_abs_world_m_, 3)},
      });
    return;
  }

  auto hole_coord = computeTileCoord(
    probe_x,
    probe_y,
    origin_x_,
    origin_y_,
    tile_size_);

  if (source != "floor_color" && legacy_direction_vector && hole_coord == robot_coord) {
    projection_distance = std::max(projection_distance, tile_size_ * 0.75);
    probe_x = robot_x + probe_dir_x * projection_distance;
    probe_y = robot_y + probe_dir_y * projection_distance;
    if (!finite_plausible_world_point(probe_x, probe_y)) {
      reject_hole(
        "invalid_forced_probe_world_coordinate",
        probe_x,
        probe_y,
        std::nullopt,
        projection_method,
        projection_distance,
        {{"max_abs_world_m", numberText(semantic_observation_max_abs_world_m_, 3)}});
      return;
    }
    hole_coord = computeTileCoord(
      probe_x,
      probe_y,
      origin_x_,
      origin_y_,
      tile_size_);
    projection_method += "_forced_out_of_robot_tile";
  }

  const auto hole_center = tileCenter(
    hole_coord,
    origin_x_,
    origin_y_,
    tile_size_);

  const int candidate_tile_delta =
    std::max(
      std::abs(hole_coord.x - robot_coord.x),
      std::abs(hole_coord.y - robot_coord.y));
  const double candidate_center_distance =
    std::hypot(probe_x - hole_center.x, probe_y - hole_center.y);
  const double half_tile_diagonal = std::sqrt(2.0) * tile_size_ * 0.5;
  const double hole_spatial_full_confidence_radius =
    std::min(
      half_tile_diagonal,
      tile_size_ * 0.5 + black_hole_projection_boundary_margin_m_);
  const double hole_spatial_falloff =
    std::max(half_tile_diagonal - hole_spatial_full_confidence_radius, 1.0e-9);
  const double spatial_confidence =
    std::clamp(
      1.0 -
      std::max(0.0, candidate_center_distance - hole_spatial_full_confidence_radius) /
      hole_spatial_falloff,
      0.0,
      1.0);
  const double fused_confidence = confidence * spatial_confidence;

  if (candidate_tile_delta > semantic_observation_max_tile_distance_) {
    reject_hole(
      "candidate_tile_too_far_from_robot",
      probe_x,
      probe_y,
      hole_coord,
      projection_method,
      projection_distance,
      {
        {"tile_delta", std::to_string(candidate_tile_delta)},
        {"max_tile_delta", std::to_string(semantic_observation_max_tile_distance_)},
        {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
      });
    return;
  }

  if (candidate_center_distance > half_tile_diagonal + 1.0e-6) {
    reject_hole(
      "probe_not_inside_candidate_tile",
      probe_x,
      probe_y,
      hole_coord,
      projection_method,
      projection_distance,
      {
        {"center_dist", numberText(candidate_center_distance, 4)},
        {"half_tile_diagonal", numberText(half_tile_diagonal, 4)},
      });
    return;
  }

  if (fused_confidence < hole_candidate_min_confidence_) {
    reject_hole(
      "spatial_confidence_below_threshold",
      probe_x,
      probe_y,
      hole_coord,
      projection_method,
      projection_distance,
      {
        {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
        {"center_dist", numberText(candidate_center_distance, 4)},
        {"spatial_conf", numberText(spatial_confidence, 3)},
        {"fused_conf", numberText(fused_confidence, 3)},
        {"threshold", numberText(hole_candidate_min_confidence_, 3)},
      });
    return;
  }

  const bool weak_distance_sensor_hole =
    source == "distance_sensor" &&
    parts.size() == 12U &&
    traveled_before_stop_m >= 0.0 &&
    traveled_before_stop_m <= controller_hole_weak_distance_travel_m_;

  auto append_source = [](std::string existing, const std::string & new_source) {
    if (existing.empty()) {
      return new_source;
    }
    if (existing.find(new_source) == std::string::npos) {
      existing += "," + new_source;
    }
    return existing;
  };

  auto find_confirmed_nearby_hole = [&]() -> std::optional<TileCoord> {
    std::optional<TileCoord> best_coord;
    double best_score = std::numeric_limits<double>::infinity();
    const int radius = hole_duplicate_association_radius_tiles_;
    for (int dy = -radius; dy <= radius; ++dy) {
      for (int dx = -radius; dx <= radius; ++dx) {
        const TileCoord candidate{hole_coord.x + dx, hole_coord.y + dy};
        const auto iter = tile_map_.records().find(candidate);
        if (
          iter == tile_map_.records().end() ||
          !iter->second.is_hole ||
          iter->second.hazard_type != HazardType::BlackHole ||
          iter->second.hazard_state != HazardState::Confirmed)
        {
          continue;
        }
        const double center_distance =
          std::hypot(hole_center.x - iter->second.center.x, hole_center.y - iter->second.center.y);
        if (center_distance <= hole_duplicate_association_max_center_distance_m_ &&
            center_distance < best_score)
        {
          best_coord = candidate;
          best_score = center_distance;
        }
      }
    }
    return best_coord;
  };

  if (const auto associated_hole_coord = find_confirmed_nearby_hole()) {
    auto & associated_record = tile_map_.getOrCreateTile(
      *associated_hole_coord,
      tileCenter(*associated_hole_coord, origin_x_, origin_y_, tile_size_),
      stamp);
    associated_record.hazard_confidence =
      std::max(associated_record.hazard_confidence, fused_confidence);
    associated_record.hazard_hit_count =
      std::max(1, associated_record.hazard_hit_count + 1);
    associated_record.hazard_last_seen = stamp;
    associated_record.last_seen = stamp;

    pending_hole_candidates_.erase(hole_coord);

    logRobotEvent(
      EventLevel::Warn,
      "controller_hole_associated",
      {
        {"accepted", "false"},
        {"reason", hole_coord == *associated_hole_coord
          ? "same_hole_tile_reinforced"
          : "candidate_near_confirmed_hole_fused"},
        {"source", source},
        {"confidence", numberText(confidence, 3)},
        {"spatial_conf", numberText(spatial_confidence, 3)},
        {"fused_conf", numberText(fused_confidence, 3)},
        {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
        {"robot_yaw", numberText(yaw, 4)},
        {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
        {"probe_world_xy", "(" + numberText(probe_x, 4) + "," + numberText(probe_y, 4) + ")"},
        {"robot_tile", tileCoordToJson(robot_coord)},
        {"candidate_hole_tile", tileCoordToJson(hole_coord)},
        {"associated_hole_tile", tileCoordToJson(*associated_hole_coord)},
        {"projection_method", projection_method},
        {"projection_distance_m", numberText(projection_distance, 4)},
        {"legacy_direction", legacy_direction},
        {"traveled_before_stop_m", parts.size() == 12U
          ? numberText(traveled_before_stop_m, 4)
          : "none"},
        {"associated_evidence_count", std::to_string(associated_record.hazard_hit_count)},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  std::optional<TileCoord> associated_pending_coord;
  double associated_pending_score = std::numeric_limits<double>::infinity();
  for (const auto & item : pending_hole_candidates_) {
    const auto & pending = item.second;
    const int dx = std::abs(pending.tile.x - hole_coord.x);
    const int dy = std::abs(pending.tile.y - hole_coord.y);
    if (std::max(dx, dy) > hole_duplicate_association_radius_tiles_) {
      continue;
    }
    const double age_s = (stamp - pending.last_seen).seconds();
    if (age_s < 0.0 || age_s > hole_confirmation_window_s_) {
      continue;
    }
    const double center_distance =
      std::hypot(
        hole_center.x - tileCenter(pending.tile, origin_x_, origin_y_, tile_size_).x,
        hole_center.y - tileCenter(pending.tile, origin_x_, origin_y_, tile_size_).y);
    if (center_distance <= hole_duplicate_association_max_center_distance_m_ &&
        center_distance < associated_pending_score)
    {
      associated_pending_coord = pending.tile;
      associated_pending_score = center_distance;
    }
  }

  TileCoord confirmation_coord = hole_coord;
  if (associated_pending_coord && !(*associated_pending_coord == hole_coord)) {
    confirmation_coord = *associated_pending_coord;
  }

  auto & pending = pending_hole_candidates_[confirmation_coord];
  if (pending.hits == 0) {
    pending.tile = confirmation_coord;
    pending.first_seen = stamp;
    pending.sources = source;
  } else {
    pending.sources = append_source(pending.sources, source);
  }
  pending.last_seen = stamp;
  pending.confidence = std::max(pending.confidence, fused_confidence);
  pending.hits = std::max(1, pending.hits + 1);

  const bool source_fusion_confirmed =
    pending.sources.find(',') != std::string::npos;
  const bool repeated_confirmed =
    pending.hits >= hole_confirmation_required_hits_;
  const bool immediate_confirmed =
    !weak_distance_sensor_hole &&
    fused_confidence >= hole_confirm_immediate_confidence_;
  const bool should_confirm =
    source_fusion_confirmed ||
    repeated_confirmed ||
    immediate_confirmed ||
    (source == "floor_color" && confidence >= hole_confirm_immediate_confidence_);

  if (!should_confirm) {
    logRobotEvent(
      EventLevel::Warn,
      "controller_hole_candidate",
      {
        {"accepted", "false"},
        {"reason", weak_distance_sensor_hole
          ? "weak_detection_waiting_for_confirmation"
          : "waiting_for_confirmation"},
        {"source", source},
        {"sources", pending.sources},
        {"confidence", numberText(confidence, 3)},
        {"spatial_conf", numberText(spatial_confidence, 3)},
        {"fused_conf", numberText(fused_confidence, 3)},
        {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
        {"robot_yaw", numberText(yaw, 4)},
        {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
        {"probe_world_xy", "(" + numberText(probe_x, 4) + "," + numberText(probe_y, 4) + ")"},
        {"robot_tile", tileCoordToJson(robot_coord)},
        {"candidate_hole_tile", tileCoordToJson(hole_coord)},
        {"pending_hole_tile", tileCoordToJson(confirmation_coord)},
        {"projection_method", projection_method},
        {"projection_distance_m", numberText(projection_distance, 4)},
        {"legacy_direction", legacy_direction},
        {"hits", std::to_string(pending.hits)},
        {"required_hits", std::to_string(hole_confirmation_required_hits_)},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  const auto final_hole_center = tileCenter(
    confirmation_coord,
    origin_x_,
    origin_y_,
    tile_size_);

  const std::string pending_sources = pending.sources;
  const int pending_hits = pending.hits;
  const double pending_confidence = pending.confidence;

  auto & record = tile_map_.getOrCreateTile(confirmation_coord, final_hole_center, stamp);
  const bool was_hole = record.is_hole;

  record.floor_color = FloorColorClass::BlackHoleBorder;
  record.has_black_hole_border = true;
  record.is_hole = true;
  record.is_blocked = true;
  record.kind = TileKind::Hole;
  record.hazard_state = HazardState::Confirmed;
  record.hazard_type = HazardType::BlackHole;
  record.hazard_source = HazardSource::ControllerEvent;
  record.hazard_edge = HazardEdge::Unknown;
  record.hazard_confidence = std::max(record.hazard_confidence, pending_confidence);
  record.hazard_hit_count = std::max(1, record.hazard_hit_count + pending_hits);
  record.hazard_normal_hit_count = 0;
  record.hazard_ttl_sec = 0.0;
  record.hazard_last_seen = stamp;
  record.last_seen = stamp;

  pending_hole_candidates_.erase(confirmation_coord);

  logRobotEvent(
    EventLevel::Warn,
    "controller_hole_applied",
    {
      {"accepted", "true"},
      {"action", was_hole ? "reinforced" : "created"},
      {"reason", source_fusion_confirmed
        ? "source_fusion_confirmed"
        : (repeated_confirmed
          ? "repeated_tile_confirmation"
          : "high_confidence_spatial_observation")},
      {"source", source},
      {"sources", pending_sources},
      {"confidence", numberText(confidence, 3)},
      {"spatial_conf", numberText(spatial_confidence, 3)},
      {"fused_conf", numberText(fused_confidence, 3)},
      {"record_confidence", numberText(record.hazard_confidence, 3)},
      {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
      {"robot_yaw", numberText(yaw, 4)},
      {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
      {"probe_world_xy", "(" + numberText(probe_x, 4) + "," + numberText(probe_y, 4) + ")"},
      {"robot_tile", tileCoordToJson(robot_coord)},
      {"candidate_hole_tile", tileCoordToJson(hole_coord)},
      {"hole_tile", tileCoordToJson(confirmation_coord)},
      {"projection_method", projection_method},
      {"projection_distance_m", numberText(projection_distance, 4)},
      {"legacy_direction", legacy_direction},
      {"legacy_current", parts.size() == 12U
        ? "(" + std::to_string(legacy_current_x) + "," + std::to_string(legacy_current_y) + ")"
        : "none"},
      {"legacy_target", parts.size() == 12U
        ? "(" + std::to_string(legacy_target_x) + "," + std::to_string(legacy_target_y) + ")"
        : "none"},
      {"requested_distance_m", parts.size() == 12U
        ? numberText(requested_distance_m, 4)
        : "none"},
      {"traveled_before_stop_m", parts.size() == 12U
        ? numberText(traveled_before_stop_m, 4)
        : "none"},
      {"evidence_count", std::to_string(record.hazard_hit_count)},
      {"pending_hits", std::to_string(pending_hits)},
      {"connection_id", std::to_string(bridge_connection_id_)},
    });

  if (!was_hole) {
    publishMapperEvent(
      hazardEventJson(
        "black_hole_detected",
        record,
        stamp,
        std::optional<TileCoord>{robot_coord},
        yaw,
        robot_x,
        robot_y,
        probe_x,
        probe_y));
  }
}

void MapperNode::floorColorCallback(const std_msgs::msg::String::SharedPtr msg)
{
  if (!msg) {
    return;
  }

  std::vector<std::string> parts;
  std::stringstream ss(msg->data);
  std::string part;

  while (std::getline(ss, part, '|')) {
    parts.push_back(part);
  }

  if (parts.empty()) {
    RCLCPP_WARN(get_logger(), "Received empty floor color observation");
    logRobotEvent(
      EventLevel::Warn,
      "floor_color_ignored",
      {
        {"accepted", "false"},
        {"reason", "empty_payload"},
        {"raw_payload", msg->data},
      });
    return;
  }

  const auto color_class = parseFloorColorClass(parts[0]);
  const std::string raw_rgb =
    parts.size() >= 4 ? "(" + parts[1] + "," + parts[2] + "," + parts[3] + ")" : "none";

  if (color_class == FloorColorClass::Unknown) {
    RCLCPP_WARN(
      get_logger(),
      "Unknown floor color class: '%s'",
      parts[0].c_str());
    logRobotEvent(
      EventLevel::Warn,
      "floor_color_ignored",
      {
        {"raw_class", parts[0]},
        {"class_label", parts[0]},
        {"raw_rgb", raw_rgb},
        {"accepted", "false"},
        {"reason", "unknown_class"},
        {"source", floor_color_topic_},
      });
    return;
  }

  double confidence = 1.0;

  if (parts.size() >= 5) {
    try {
      confidence = std::stod(parts[4]);
    } catch (const std::exception &) {
      RCLCPP_WARN(
        get_logger(),
        "Invalid floor color confidence in payload: '%s'",
        msg->data.c_str());
      logRobotEvent(
        EventLevel::Warn,
        "floor_color_ignored",
        {
          {"raw_class", parts[0]},
          {"class_label", parts[0]},
          {"raw_rgb", raw_rgb},
          {"accepted", "false"},
          {"reason", "invalid_confidence"},
          {"source", floor_color_topic_},
        });
      return;
    }
  }

  if (!std::isfinite(confidence)) {
    logRobotEvent(
      EventLevel::Warn,
      "floor_color_ignored",
      {
        {"raw_class", parts[0]},
        {"class_label", parts[0]},
        {"raw_rgb", raw_rgb},
        {"accepted", "false"},
        {"reason", "non_finite_confidence"},
        {"source", floor_color_topic_},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  logRobotEvent(
    "floor_color_observation",
    {
      {"raw_class", parts[0]},
      {"class_label", parts[0]},
      {"mapper_class_name", floorColorClassToLogString(color_class)},
      {"chosen_class", floorColorClassToLogString(color_class)},
      {"raw_rgb", raw_rgb},
      {"confidence", numberText(confidence, 3)},
      {"color_conf", numberText(confidence, 3)},
      {"source", floor_color_topic_},
      {"connection_id", std::to_string(bridge_connection_id_)},
    });

  if (confidence < floor_color_min_confidence_) {
    RCLCPP_DEBUG(
      get_logger(),
      "Ignoring low-confidence floor color observation: confidence=%.3f",
      confidence);
    logRobotEvent(
      "floor_color_ignored",
      {
        {"raw_class", parts[0]},
        {"class_label", parts[0]},
        {"raw_rgb", raw_rgb},
        {"confidence", numberText(confidence, 3)},
        {"color_conf", numberText(confidence, 3)},
        {"accepted", "false"},
        {"reason", "low_confidence"},
        {"threshold", numberText(floor_color_min_confidence_, 3)},
        {"source", floor_color_topic_},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  applyFloorColorObservation(color_class, confidence, get_clock()->now());
}

void MapperNode::applyFloorColorObservation(
  FloorColorClass color_class,
  double confidence,
  const rclcpp::Time & stamp)
{
  if (!mapping_active_) {
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      5000,
      "Ignoring floor color observation because mapper auto_start is false");
    logRobotEvent(
      EventLevel::Warn,
      "floor_color_ignored",
      {
        {"accepted", "false"},
        {"reason", "mapping_inactive"},
        {"mapping_active", boolText(mapping_active_)},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  if (!origin_initialized_) {
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      2000,
      "Ignoring floor color observation because tile origin is not initialized yet");
    logRobotEvent(
      EventLevel::Warn,
      "floor_color_ignored",
      {
        {"accepted", "false"},
        {"reason", "origin_not_initialized"},
        {"origin_initialized", boolText(origin_initialized_)},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  if (!latest_odom_) {
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      2000,
      "Ignoring floor color observation because no odometry has been received yet");
    logRobotEvent(
      EventLevel::Warn,
      "floor_color_ignored",
      {
        {"accepted", "false"},
        {"reason", "odom_missing"},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  const auto & pose = latest_odom_->pose.pose;

  const double robot_x = pose.position.x;
  const double robot_y = pose.position.y;
  const double yaw = yawFromQuaternion(pose.orientation);

  const auto finite_plausible_world_point =
    [&](double x, double y) {
      return
        std::isfinite(x) &&
        std::isfinite(y) &&
        std::fabs(x) <= semantic_observation_max_abs_world_m_ &&
        std::fabs(y) <= semantic_observation_max_abs_world_m_;
    };

  if (!finite_plausible_world_point(robot_x, robot_y) || !std::isfinite(yaw)) {
    logRobotEvent(
      EventLevel::Warn,
      "floor_color_ignored",
      {
        {"raw_class", floorColorClassToLogString(color_class)},
        {"class_label", floorColorClassToLogString(color_class)},
        {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
        {"robot_yaw", numberText(yaw, 4)},
        {"confidence", numberText(confidence, 3)},
        {"color_conf", numberText(confidence, 3)},
        {"accepted", "false"},
        {"reason", "invalid_robot_pose"},
        {"max_abs_world_m", numberText(semantic_observation_max_abs_world_m_, 3)},
        {"source", floor_color_topic_},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  const auto robot_coord = computeTileCoord(
    robot_x,
    robot_y,
    origin_x_,
    origin_y_,
    tile_size_);

  if (color_class == FloorColorClass::BlackHoleBorder) {
    logRobotEvent(
      "floor_color_ignored",
      {
        {"raw_class", floorColorClassToLogString(color_class)},
        {"class_label", floorColorClassToLogString(color_class)},
        {"robot_tile", tileCoordToJson(robot_coord)},
        {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
        {"confidence", numberText(confidence, 3)},
        {"color_conf", numberText(confidence, 3)},
        {"accepted", "false"},
        {"reason", "black_hole_requires_legacy_even_tile"},
        {"source", floor_color_topic_},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });

    logRobotEvent(
      EventLevel::Warn,
      "hazard_ignored",
      {
        {"hazard_type", "black_hole"},
        {"robot_tile", tileCoordToJson(robot_coord)},
        {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
        {"confidence", numberText(confidence, 3)},
        {"color_conf", numberText(confidence, 3)},
        {"accepted", "false"},
        {"reason", "black_hole_requires_legacy_even_tile"},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  const double c = std::cos(yaw);
  const double s = std::sin(yaw);

  const double sensor_x =
    robot_x +
    c * color_sensor_forward_offset_ -
    s * color_sensor_lateral_offset_;

  const double sensor_y =
    robot_y +
    s * color_sensor_forward_offset_ +
    c * color_sensor_lateral_offset_;

  if (!finite_plausible_world_point(sensor_x, sensor_y)) {
    logRobotEvent(
      EventLevel::Warn,
      "floor_color_ignored",
      {
        {"raw_class", floorColorClassToLogString(color_class)},
        {"class_label", floorColorClassToLogString(color_class)},
        {"robot_tile", tileCoordToJson(robot_coord)},
        {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
        {"robot_yaw", numberText(yaw, 4)},
        {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
        {"sensor_forward_offset_m", numberText(color_sensor_forward_offset_, 4)},
        {"sensor_lateral_offset_m", numberText(color_sensor_lateral_offset_, 4)},
        {"confidence", numberText(confidence, 3)},
        {"color_conf", numberText(confidence, 3)},
        {"accepted", "false"},
        {"reason", "invalid_sensor_world_coordinate"},
        {"max_abs_world_m", numberText(semantic_observation_max_abs_world_m_, 3)},
        {"source", floor_color_topic_},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  const auto raw_observed_coord = computeTileCoord(
    sensor_x,
    sensor_y,
    origin_x_,
    origin_y_,
    tile_size_);

  const bool is_transition_color =
    transitionAreasForColor(color_class).has_value();
  const bool is_checkpoint_color =
    color_class == FloorColorClass::SilverCheckpoint;

  auto observed_coord = raw_observed_coord;

  if (color_class == FloorColorClass::BlackHoleBorder) {
    const auto boundary_neighbors = adjacentTileCoordsNearBoundary(
      raw_observed_coord,
      sensor_x,
      sensor_y,
      origin_x_,
      origin_y_,
      tile_size_,
      black_hole_projection_boundary_margin_m_);

    if (!boundary_neighbors.empty()) {
      const double sensor_direction_x = sensor_x - robot_x;
      const double sensor_direction_y = sensor_y - robot_y;

      const auto best = std::max_element(
        boundary_neighbors.begin(),
        boundary_neighbors.end(),
        [&](const TileCoord & lhs, const TileCoord & rhs) {
          const double lhs_alignment =
            static_cast<double>(lhs.x - raw_observed_coord.x) * sensor_direction_x +
            static_cast<double>(lhs.y - raw_observed_coord.y) * sensor_direction_y;
          const double rhs_alignment =
            static_cast<double>(rhs.x - raw_observed_coord.x) * sensor_direction_x +
            static_cast<double>(rhs.y - raw_observed_coord.y) * sensor_direction_y;
          return lhs_alignment < rhs_alignment;
        });

      observed_coord = *best;

      logRobotEvent(
        "black_hole_tile_projected",
        {
          {"raw_observed_tile", tileCoordToJson(raw_observed_coord)},
          {"projected_hole_tile", tileCoordToJson(observed_coord)},
          {"robot_tile", tileCoordToJson(robot_coord)},
          {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
          {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
          {"boundary_margin_m", numberText(black_hole_projection_boundary_margin_m_, 4)},
          {"reason", "black_border_near_tile_boundary"},
          {"connection_id", std::to_string(bridge_connection_id_)},
        });
    }
  }

  if (is_transition_color) {
    const auto boundary_neighbors = adjacentTileCoordsNearBoundary(
      raw_observed_coord,
      sensor_x,
      sensor_y,
      origin_x_,
      origin_y_,
      tile_size_,
      transition_reassociation_boundary_margin_m_);

    std::optional<TileCoord> reassociated_coord;
    std::string reassociation_reason;

    if (
      active_transition_tile_ &&
      active_transition_color_ == color_class)
    {
      for (const auto & candidate : boundary_neighbors) {
        if (candidate == *active_transition_tile_) {
          reassociated_coord = candidate;
          reassociation_reason = "same_active_transition_across_boundary";
          break;
        }
      }
    }

    if (!reassociated_coord) {
      for (const auto & candidate : boundary_neighbors) {
        const auto iter = tile_map_.records().find(candidate);
        if (
          iter != tile_map_.records().end() &&
          iter->second.is_transition &&
          iter->second.floor_color == color_class)
        {
          reassociated_coord = candidate;
          reassociation_reason = "matching_confirmed_transition_across_boundary";
          break;
        }
      }
    }

    if (reassociated_coord) {
      observed_coord = *reassociated_coord;
      logRobotEvent(
        "transition_tile_reassociated",
        {
          {"color", floorColorClassToLogString(color_class)},
          {"raw_observed_tile", tileCoordToJson(raw_observed_coord)},
          {"resolved_tile", tileCoordToJson(observed_coord)},
          {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
          {"boundary_margin_m", numberText(transition_reassociation_boundary_margin_m_, 4)},
          {"reason", reassociation_reason},
          {"connection_id", std::to_string(bridge_connection_id_)},
        });
    }
  }

  const int observed_tile_delta =
    std::max(
      std::abs(observed_coord.x - robot_coord.x),
      std::abs(observed_coord.y - robot_coord.y));
  if (observed_tile_delta > semantic_observation_max_tile_distance_) {
    logRobotEvent(
      EventLevel::Warn,
      "floor_color_ignored",
      {
        {"raw_class", floorColorClassToLogString(color_class)},
        {"class_label", floorColorClassToLogString(color_class)},
        {"raw_sensor_tile", tileCoordToJson(raw_observed_coord)},
        {"sensor_tile", tileCoordToJson(observed_coord)},
        {"robot_tile", tileCoordToJson(robot_coord)},
        {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
        {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
        {"robot_yaw", numberText(yaw, 4)},
        {"sensor_forward_offset_m", numberText(color_sensor_forward_offset_, 4)},
        {"sensor_lateral_offset_m", numberText(color_sensor_lateral_offset_, 4)},
        {"tile_delta", std::to_string(observed_tile_delta)},
        {"max_tile_delta", std::to_string(semantic_observation_max_tile_distance_)},
        {"confidence", numberText(confidence, 3)},
        {"color_conf", numberText(confidence, 3)},
        {"accepted", "false"},
        {"reason", "candidate_tile_too_far_from_robot"},
        {"source", floor_color_topic_},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  const auto observed_center = tileCenter(
    observed_coord,
    origin_x_,
    origin_y_,
    tile_size_);

  const double center_distance =
    std::hypot(sensor_x - observed_center.x, sensor_y - observed_center.y);

  /*
   * Transições, checkpoints e pântanos não podem depender do filtro de centro
   * do tile. O sensor de cor fica deslocado em relação ao centro do robô e pode
   * detectar esses pisos antes de alcançar a máscara central. O log real mostrou
   * leituras válidas de SILVER_CHECKPOINT/BROWN_SWAMP sendo descartadas por esse
   * filtro geométrico apesar da confiança de cor alta.
   */
  const bool bypass_center_mask =
    floorColorBypassesCenterMask(color_class) || is_transition_color;

  const double half_tile_diagonal = std::sqrt(2.0) * tile_size_ * 0.5;

  const double tile_geometric_confidence = std::clamp(
    1.0 - center_distance / half_tile_diagonal,
    0.0,
    1.0);

  const double local_x = sensor_x - observed_center.x;
  const double local_y = sensor_y - observed_center.y;

  const double half_subtile = tile_size_ * 0.25;
  const double subtile_center_x = local_x < 0.0 ? -half_subtile : half_subtile;
  const double subtile_center_y = local_y < 0.0 ? -half_subtile : half_subtile;

  const double subtile_axis_distance =
    std::max(
      std::fabs(local_x - subtile_center_x),
      std::fabs(local_y - subtile_center_y));

  const double mask_half_extent = half_subtile * floor_color_center_mask_ratio_;
  const double mask_falloff = std::max(half_subtile - mask_half_extent, 1.0e-9);

  const double subtile_geometric_confidence = std::clamp(
    1.0 -
      std::max(0.0, subtile_axis_distance - mask_half_extent) /
        mask_falloff,
    0.0,
    1.0);

  const double geometric_confidence = bypass_center_mask ?
    1.0 :
    std::min(tile_geometric_confidence, subtile_geometric_confidence);

  const double effective_confidence = bypass_center_mask ?
    confidence :
    confidence * geometric_confidence;

  /*
   * A trava de transição é por tile observado. Enquanto o sensor ainda está
   * sobre o mesmo tile de passagem, leituras NORMAL ou outra cor não podem
   * apagar a passagem nem alternar a área de volta.
   */
  bool sensor_on_latched_transition_tile = false;
  if (active_transition_tile_) {
    sensor_on_latched_transition_tile = (*active_transition_tile_ == observed_coord);

    if (!sensor_on_latched_transition_tile) {
      const auto released_tile = *active_transition_tile_;
      const auto released_color = active_transition_color_;

      active_transition_tile_.reset();
      active_transition_color_ = FloorColorClass::Unknown;

      logRobotEvent(
        "transition_latch_released",
        {
          {"released_tile", tileCoordToJson(released_tile)},
          {"released_color", floorColorClassToLogString(released_color)},
          {"observed_tile", tileCoordToJson(observed_coord)},
          {"observed_color", floorColorClassToLogString(color_class)},
          {"current_area", tileAreaToString(current_area_)},
          {"reason", "sensor_left_transition_tile"},
          {"connection_id", std::to_string(bridge_connection_id_)},
        });
    }
  }

  if (is_transition_color && center_distance > transition_center_max_distance_m_) {
    logRobotEvent(
      "floor_color_ignored",
      {
        {"sensor_tile", tileCoordToJson(observed_coord)},
        {"robot_tile", tileCoordToJson(robot_coord)},
        {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
        {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
        {"center_dist", numberText(center_distance, 4)},
        {"max_center_dist", numberText(transition_center_max_distance_m_, 4)},
        {"confidence", numberText(confidence, 3)},
        {"color_conf", numberText(confidence, 3)},
        {"geom_conf", numberText(geometric_confidence, 3)},
        {"effective_conf", numberText(effective_confidence, 3)},
        {"accepted", "false"},
        {"reason", "transition_requires_centered_reading"},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  if (is_checkpoint_color && center_distance > checkpoint_center_max_distance_m_) {
    logRobotEvent(
      "floor_color_ignored",
      {
        {"sensor_tile", tileCoordToJson(observed_coord)},
        {"robot_tile", tileCoordToJson(robot_coord)},
        {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
        {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
        {"center_dist", numberText(center_distance, 4)},
        {"max_center_dist", numberText(checkpoint_center_max_distance_m_, 4)},
        {"confidence", numberText(confidence, 3)},
        {"color_conf", numberText(confidence, 3)},
        {"geom_conf", numberText(geometric_confidence, 3)},
        {"effective_conf", numberText(effective_confidence, 3)},
        {"accepted", "false"},
        {"reason", "checkpoint_requires_centered_reading"},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
    return;
  }

  if (!bypass_center_mask && effective_confidence < floor_color_min_confidence_) {
    RCLCPP_INFO_THROTTLE(
      get_logger(),
      *get_clock(),
      1000,
      "Ignoring floor color update near tile edge: coord=(%d,%d) geom_conf=%.3f color_conf=%.3f effective=%.3f",
      observed_coord.x,
      observed_coord.y,
      geometric_confidence,
      confidence,
      effective_confidence);

    logRobotEvent(
      "floor_color_ignored",
      {
        {"sensor_tile", tileCoordToJson(observed_coord)},
        {"robot_tile", tileCoordToJson(robot_coord)},
        {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
        {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
        {"center_dist", numberText(center_distance, 4)},
        {"confidence", numberText(confidence, 3)},
        {"color_conf", numberText(confidence, 3)},
        {"geom_conf", numberText(geometric_confidence, 3)},
        {"effective_conf", numberText(effective_confidence, 3)},
        {"accepted", "false"},
        {"reason", "effective_confidence_below_threshold"},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });

    if (color_class == FloorColorClass::BlackHoleBorder) {
      logRobotEvent(
        EventLevel::Warn,
        "hazard_ignored",
        {
          {"hazard_type", "black_hole"},
          {"hazard_tile", tileCoordToJson(observed_coord)},
          {"robot_tile", tileCoordToJson(robot_coord)},
          {"sensor_tile", tileCoordToJson(observed_coord)},
          {"confidence", numberText(confidence, 3)},
          {"color_conf", numberText(confidence, 3)},
          {"geom_conf", numberText(geometric_confidence, 3)},
          {"effective_conf", numberText(effective_confidence, 3)},
          {"reason", "effective_confidence_below_threshold"},
          {"accepted", "false"},
          {"connection_id", std::to_string(bridge_connection_id_)},
        });
    }

    return;
  }

  auto & record =
    tile_map_.getOrCreateTile(observed_coord, observed_center, stamp);

  const bool was_hole = record.is_hole;
  const bool was_checkpoint = record.is_checkpoint;
  const bool was_swamp = record.is_swamp;
  const bool was_transition = record.is_transition;

  const HazardState previous_hazard_state = record.hazard_state;
  const HazardType previous_hazard_type = record.hazard_type;
  const int previous_hazard_hit_count = record.hazard_hit_count;

  const bool normal_challenges_controller_hole =
    color_class == FloorColorClass::Normal &&
    record.is_hole &&
    record.hazard_state == HazardState::Confirmed &&
    record.hazard_type == HazardType::BlackHole &&
    record.hazard_source == HazardSource::ControllerEvent &&
    observed_coord == robot_coord &&
    center_distance <= controller_hole_normal_clear_center_distance_m_ &&
    confidence >= floor_color_min_confidence_;

  if (normal_challenges_controller_hole) {
    record.hazard_normal_hit_count =
      std::max(0, record.hazard_normal_hit_count) + 1;
    record.last_seen = stamp;

    if (record.hazard_normal_hit_count < controller_hole_normal_clear_hits_) {
      logRobotEvent(
        "controller_hole_normal_evidence",
        {
          {"accepted", "false"},
          {"reason", "waiting_for_repeated_centered_normal"},
          {"hole_tile", tileCoordToJson(record.coord)},
          {"robot_tile", tileCoordToJson(robot_coord)},
          {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
          {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
          {"center_dist", numberText(center_distance, 4)},
          {"max_center_dist", numberText(controller_hole_normal_clear_center_distance_m_, 4)},
          {"confidence", numberText(confidence, 3)},
          {"normal_evidence_count", std::to_string(record.hazard_normal_hit_count)},
          {"required_hits", std::to_string(controller_hole_normal_clear_hits_)},
          {"previous_hazard_hits", std::to_string(previous_hazard_hit_count)},
          {"connection_id", std::to_string(bridge_connection_id_)},
        });
      return;
    }

    clearFloorColorSemantic(record);
    record.floor_color = FloorColorClass::Normal;
    if (!record.is_start && record.kind == TileKind::Unknown) {
      record.kind = TileKind::Normal;
    }
    record.hazard_state = HazardState::None;
    record.hazard_type = HazardType::Unknown;
    record.hazard_source = HazardSource::MapperFusion;
    record.hazard_edge = HazardEdge::Unknown;
    record.hazard_confidence = 0.0;
    record.hazard_hit_count = 0;
    record.hazard_normal_hit_count = 0;
    record.hazard_ttl_sec = 0.0;
    record.floor_color_center_distance_m = center_distance;
    record.floor_color_geometric_confidence = geometric_confidence;
    record.last_seen = stamp;

    logRobotEvent(
      EventLevel::Warn,
      "controller_hole_reverted",
      {
        {"accepted", "true"},
        {"reason", "repeated_centered_normal_after_controller_hole"},
        {"tile", tileCoordToJson(record.coord)},
        {"robot_tile", tileCoordToJson(robot_coord)},
        {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
        {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
        {"center_dist", numberText(center_distance, 4)},
        {"max_center_dist", numberText(controller_hole_normal_clear_center_distance_m_, 4)},
        {"confidence", numberText(confidence, 3)},
        {"required_hits", std::to_string(controller_hole_normal_clear_hits_)},
        {"previous_hazard_hits", std::to_string(previous_hazard_hit_count)},
        {"previous_state", hazardStateToString(previous_hazard_state)},
        {"previous_hazard_type", hazardTypeToString(previous_hazard_type)},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });

    const auto event_stamp = get_clock()->now();
    if (previous_current_tile_ && *previous_current_tile_ == observed_coord) {
      publishCurrentTile(record, event_stamp);
    }
    return;
  }

  const bool has_previous_color =
    record.floor_color != FloorColorClass::Unknown;

  const bool same_color =
    record.floor_color == color_class;

  const bool same_active_transition =
    active_transition_tile_ &&
    (*active_transition_tile_ == observed_coord);

  const bool same_pending_transition =
    pending_transition_crossing_ &&
    pending_transition_crossing_->tile == observed_coord &&
    pending_transition_crossing_->color == color_class;

  const bool new_transition_observation =
    is_transition_color &&
    !same_active_transition &&
    !same_pending_transition;

  if (is_transition_color) {
    logRobotEvent(
      "transition_logic_probe",
      {
        {"color", floorColorClassToLogString(color_class)},
        {"observed_tile", tileCoordToJson(observed_coord)},
        {"robot_tile", tileCoordToJson(robot_coord)},
        {"record_area", tileAreaToString(record.area)},
        {"current_area", tileAreaToString(current_area_)},
        {"current_area_known", current_area_known_ ? "true" : "false"},
        {"has_previous_color", has_previous_color ? "true" : "false"},
        {"same_color_as_record", same_color ? "true" : "false"},
        {"active_transition_tile", active_transition_tile_ ? tileCoordToJson(*active_transition_tile_) : std::string("none")},
        {"active_transition_color", floorColorClassToLogString(active_transition_color_)},
        {"same_active_transition", same_active_transition ? "true" : "false"},
        {"same_pending_transition", same_pending_transition ? "true" : "false"},
        {"new_transition_observation", new_transition_observation ? "true" : "false"},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
  }

  bool transition_blocked_by_same_color_cooldown = false;
  if (
    new_transition_observation &&
    last_applied_transition_tile_ &&
    last_applied_transition_color_ == color_class)
  {
    const double elapsed =
      (stamp - last_applied_transition_stamp_).seconds();
    const int transition_tile_distance =
      std::abs(observed_coord.x - last_applied_transition_tile_->x) +
      std::abs(observed_coord.y - last_applied_transition_tile_->y);

    transition_blocked_by_same_color_cooldown =
      elapsed >= 0.0 &&
      elapsed < transition_same_color_cooldown_s_ &&
      transition_tile_distance <= 1;

    if (transition_blocked_by_same_color_cooldown) {
      logRobotEvent(
        "area_transition_ignored",
        {
          {"transition_color", floorColorClassToLogString(color_class)},
          {"transition_tile", tileCoordToJson(observed_coord)},
          {"last_transition_tile", tileCoordToJson(*last_applied_transition_tile_)},
          {"current_area", tileAreaToString(current_area_)},
          {"accepted", "false"},
          {"reason", "same_color_transition_cooldown"},
          {"elapsed_s", numberText(elapsed, 3)},
          {"cooldown_s", numberText(transition_same_color_cooldown_s_, 3)},
          {"tile_distance", std::to_string(transition_tile_distance)},
          {"connection_id", std::to_string(bridge_connection_id_)},
        });
    }
  }

  const bool new_reading_is_better =
    center_distance + floor_color_update_margin_m_ <
    record.floor_color_center_distance_m;

  const bool existing_is_special =
    isSpecialFloorColor(record.floor_color) ||
    record.is_checkpoint ||
    record.is_swamp ||
    record.is_hole ||
    record.has_black_hole_border ||
    record.is_blocked ||
    record.hazard_state != HazardState::None ||
    record.is_transition;

  const bool new_is_normal =
    color_class == FloorColorClass::Normal;

  if (!bypass_center_mask && has_previous_color && !same_color && !new_reading_is_better) {
    RCLCPP_INFO_THROTTLE(
      get_logger(),
      *get_clock(),
      1000,
      "Ignoring floor color update for tile (%d,%d): new distance %.4f m is not better than stored %.4f m",
      observed_coord.x,
      observed_coord.y,
      center_distance,
      record.floor_color_center_distance_m);

    logRobotEvent(
      "floor_color_ignored",
      {
        {"sensor_tile", tileCoordToJson(observed_coord)},
        {"robot_tile", tileCoordToJson(robot_coord)},
        {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
        {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
        {"center_dist", numberText(center_distance, 4)},
        {"stored_center_dist", numberText(record.floor_color_center_distance_m, 4)},
        {"confidence", numberText(confidence, 3)},
        {"color_conf", numberText(confidence, 3)},
        {"geom_conf", numberText(geometric_confidence, 3)},
        {"effective_conf", numberText(effective_confidence, 3)},
        {"accepted", "false"},
        {"reason", "not_better_than_stored_observation"},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });

    return;
  }

  if (
    existing_is_special &&
    new_is_normal &&
    !floor_color_allow_normal_correction_ &&
    !new_reading_is_better)
  {
    RCLCPP_INFO_THROTTLE(
      get_logger(),
      *get_clock(),
      1000,
      "Ignoring NORMAL correction for semantic tile (%d,%d)",
      observed_coord.x,
      observed_coord.y);

    logRobotEvent(
      "floor_color_ignored",
      {
        {"sensor_tile", tileCoordToJson(observed_coord)},
        {"robot_tile", tileCoordToJson(robot_coord)},
        {"confidence", numberText(confidence, 3)},
        {"color_conf", numberText(confidence, 3)},
        {"geom_conf", numberText(geometric_confidence, 3)},
        {"effective_conf", numberText(effective_confidence, 3)},
        {"accepted", "false"},
        {"reason", "normal_correction_disabled"},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });

    return;
  }

  record.center = observed_center;
  record.floor_color_center_distance_m = center_distance;
  record.floor_color_geometric_confidence = geometric_confidence;
  record.last_seen = stamp;

  if (new_transition_observation && !transition_blocked_by_same_color_cooldown) {
    const auto transition_areas = transitionAreasForColor(color_class);
    const bool current_area_connected =
      transition_areas &&
      current_area_known_ &&
      (
        current_area_ == (*transition_areas)[0] ||
        current_area_ == (*transition_areas)[1]);

    if (current_area_connected) {
      beginPendingTransitionCrossing(observed_coord, color_class, robot_coord);
    } else {
      logRobotEvent(
        "area_transition_ignored",
        {
          {"transition_color", floorColorClassToLogString(color_class)},
          {"transition_tile", tileCoordToJson(observed_coord)},
          {"current_area", tileAreaToString(current_area_)},
          {"accepted", "false"},
          {"reason", "current_area_not_connected_to_transition"},
          {"connection_id", std::to_string(bridge_connection_id_)},
        });
    }
  } else if (
    is_transition_color &&
    (same_active_transition || same_pending_transition))
  {
    logRobotEvent(
      "area_transition_ignored",
      {
        {"transition_color", floorColorClassToLogString(color_class)},
        {"transition_tile", tileCoordToJson(observed_coord)},
        {"current_area", tileAreaToString(current_area_)},
        {"accepted", "false"},
        {"reason", "same_transition_crossing_pending"},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
  }

  const bool black_hole_detected =
    updateHazardFromFloorColor(record, color_class, effective_confidence, stamp);

  const bool preserve_confirmed_black_hole =
    color_class == FloorColorClass::Normal &&
    black_hole_detected &&
    hazard_preserve_confirmed_black_hole_;

  applyFloorColorClassToRecord(
    record,
    color_class,
    black_hole_detected,
    preserve_confirmed_black_hole);

  assignCurrentAreaToRecord(record, stamp);

  logRobotEvent(
    "floor_color_applied",
    {
      {"chosen_class", floorColorClassToLogString(color_class)},
      {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
      {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
      {"robot_yaw", numberText(yaw, 4)},
      {"sensor_forward_offset_m", numberText(color_sensor_forward_offset_, 4)},
      {"sensor_lateral_offset_m", numberText(color_sensor_lateral_offset_, 4)},
      {"raw_sensor_tile", tileCoordToJson(raw_observed_coord)},
      {"sensor_tile", tileCoordToJson(observed_coord)},
      {"robot_tile", tileCoordToJson(robot_coord)},
      {"center_dist", numberText(center_distance, 4)},
      {"confidence", numberText(confidence, 3)},
      {"color_conf", numberText(confidence, 3)},
      {"geom_conf", numberText(geometric_confidence, 3)},
      {"effective_conf", numberText(effective_confidence, 3)},
      {"accepted", "true"},
      {"reason", black_hole_detected ? "hazard_detected" : "semantic_update"},
      {"previous_state", hazardStateToString(previous_hazard_state)},
      {"new_state", hazardStateToString(record.hazard_state)},
      {"hazard_type", hazardTypeToString(record.hazard_type)},
      {"evidence_count", std::to_string(record.hazard_hit_count)},
      {"connection_id", std::to_string(bridge_connection_id_)},
    });

  const auto event_stamp = get_clock()->now();

  const bool has_black_hole_hazard =
    record.hazard_type == HazardType::BlackHole &&
    record.hazard_state == HazardState::Confirmed;

  const bool black_hole_hazard_state_changed =
    previous_hazard_state != record.hazard_state ||
    previous_hazard_type != record.hazard_type;

  const bool black_hole_hit_changed =
    record.hazard_state == HazardState::Confirmed &&
    previous_hazard_hit_count != record.hazard_hit_count;

  if (
    color_class == FloorColorClass::BlackHoleBorder &&
    has_black_hole_hazard &&
    (
      black_hole_hazard_state_changed ||
      black_hole_hit_changed
    ))
  {
    logRobotEvent(
      EventLevel::Warn,
      "hazard_confirmed",
      {
        {"hazard_type", hazardTypeToString(record.hazard_type)},
        {"state", hazardStateToString(record.hazard_state)},
        {"hazard_tile", tileCoordToJson(record.coord)},
        {"robot_tile", tileCoordToJson(robot_coord)},
        {"sensor_tile", tileCoordToJson(observed_coord)},
        {"confidence", numberText(record.hazard_confidence, 3)},
        {"color_conf", numberText(confidence, 3)},
        {"geom_conf", numberText(geometric_confidence, 3)},
        {"effective_conf", numberText(effective_confidence, 3)},
        {"raw_class", "BLACK_HOLE_BORDER"},
        {"reason", "floor_color_black_hole_border"},
        {"evidence_count", std::to_string(record.hazard_hit_count)},
        {"previous_state", hazardStateToString(previous_hazard_state)},
        {"new_state", hazardStateToString(record.hazard_state)},
        {"sensor_world_xy", "(" + numberText(sensor_x, 4) + "," + numberText(sensor_y, 4) + ")"},
        {"robot_world_xy", "(" + numberText(robot_x, 4) + "," + numberText(robot_y, 4) + ")"},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });

    publishMapperEvent(
      hazardEventJson(
        "black_hole_detected",
        record,
        event_stamp,
        std::optional<TileCoord>{robot_coord},
        yaw,
        robot_x,
        robot_y,
        sensor_x,
        sensor_y));
  }

  if (record.hazard_state != HazardState::None && record.hazard_state != HazardState::Confirmed) {
    logRobotEvent(
      "hazard_candidate",
      {
        {"hazard_type", hazardTypeToString(record.hazard_type)},
        {"state", hazardStateToString(record.hazard_state)},
        {"hazard_tile", tileCoordToJson(record.coord)},
        {"robot_tile", tileCoordToJson(robot_coord)},
        {"sensor_tile", tileCoordToJson(observed_coord)},
        {"confidence", numberText(record.hazard_confidence, 3)},
        {"color_conf", numberText(confidence, 3)},
        {"geom_conf", numberText(geometric_confidence, 3)},
        {"effective_conf", numberText(effective_confidence, 3)},
        {"reason", "floor_color_observation"},
        {"evidence_count", std::to_string(record.hazard_hit_count)},
        {"previous_state", hazardStateToString(previous_hazard_state)},
        {"new_state", hazardStateToString(record.hazard_state)},
        {"connection_id", std::to_string(bridge_connection_id_)},
      });
  }

  if (!was_hole && record.is_hole && color_class != FloorColorClass::BlackHoleBorder) {
    publishMapperEvent(
      hazardEventJson(
        "hole_detected",
        record,
        event_stamp,
        std::optional<TileCoord>{robot_coord},
        yaw,
        robot_x,
        robot_y,
        sensor_x,
        sensor_y));
  }

  if (!was_checkpoint && record.is_checkpoint) {
    publishMapperEvent(semanticEventJson("checkpoint_detected", record, event_stamp));
  }

  if (!was_swamp && record.is_swamp) {
    publishMapperEvent(semanticEventJson("swamp_detected", record, event_stamp));
  }

  if (!was_transition && record.is_transition) {
    publishMapperEvent(semanticEventJson("area_transition_detected", record, event_stamp));
  }

  if (previous_current_tile_ && *previous_current_tile_ == observed_coord) {
    publishCurrentTile(record, event_stamp);
  }

  RCLCPP_INFO(
    get_logger(),
    "Applied floor color observation to tile (%d,%d): sensor=(%.3f, %.3f) center_dist=%.4f geom_conf=%.3f color_conf=%.3f effective_conf=%.3f",
    observed_coord.x,
    observed_coord.y,
    sensor_x,
    sensor_y,
    center_distance,
    geometric_confidence,
    confidence,
    effective_confidence);
  }
}
