#ifndef ROS2_MAPPER__MAP_GEOMETRY_MODELS_HPP_
#define ROS2_MAPPER__MAP_GEOMETRY_MODELS_HPP_

#include <array>
#include <cstdint>
#include <string>

#include <opencv2/core.hpp>
#include <opencv2/ml.hpp>

namespace ros2_mapper
{

// Per-subtile geometry predicted by the RandomForest (RTrees) specialists.
// Mirrors notebooks/common/map_dataset.py (MapPipeline.predict_subtiles).
struct SubtileGeometryPrediction
{
  bool explored = false;            // explored gate: false -> walls/curve left 0
  std::array<bool, 4> walls{};      // index 0..3 = North, East, South, West
  int curve_dir = 0;                // 0=none, 1=SW, 2=NW, 3=NE, 4=SE
};

// Loads the exported OpenCV RTrees map-geometry models and runs the gated
// pipeline (explored -> wall/curve per subtile; obstacle per tile).
//
// Each specialist uses its own feature set, byte-parity with the notebooks:
//   * explored : patch_features()      -> 31 generic occupancy features
//                (notebooks/common/map_dataset.py)
//   * wall     : wall_features()       -> 8  edge-profile features
//   * curve    : curve_features()      -> 15 centroid features + 72 polar = 87
//   * obstacle : obstacle_features()   -> 7  interior-blob features
//                (notebooks/common/map_features.py, the resolution-aware set)
// The C++ here must reproduce those exactly (see test_map_geometry_models.cpp).
class MapGeometryModels
{
public:
  // Edge order matches Python DIRS = (N, E, S, W); rotating the patch by this
  // index (rot90 CCW) brings the target edge to the north band.
  static constexpr int kNorth = 0;
  static constexpr int kEast = 1;
  static constexpr int kSouth = 2;
  static constexpr int kWest = 3;

  // Returns true only if all four .yml models loaded and are trained.
  bool load(
    const std::string & explored_path,
    const std::string & wall_path,
    const std::string & curve_path,
    const std::string & obstacle_path);

  bool loaded() const {return loaded_;}

  // North-up occupancy patch (CV_16S, row 0 = north, col 0 = west) of a
  // 2*half_extent window around world (wx, wy); out-of-bounds cells are -1.
  // Raw grid fields (no ROS dependency): data is row-major int8 from the
  // OccupancyGrid (origin/resolution from grid.info).
  cv::Mat extractPatch(
    const int8_t * data, int width, int height,
    double resolution, double origin_x, double origin_y,
    double wx, double wy, double half_extent_m) const;

  // 1x31 CV_32F feature row (patch_features / FEATURE_NAMES order) -> explored.
  cv::Mat features(const cv::Mat & patch) const;

  // 1x8 CV_32F wall features for a patch whose TARGET edge is rotated to north
  // (map_features.wall_features, margin 0.08). Order: peak_occ, peak_pos,
  // thickness, lateral_cover, inside_free, outside_free, edge_occ_fixed, edge_grad.
  cv::Mat wallFeatures(const cv::Mat & patch) const;

  // 1x87 CV_32F curve features (map_features.curve_features, margin 0.10):
  // 15 centroid/corner/edge + 72 polar (6 radius x 12 angle) occupancy bins.
  cv::Mat curveFeatures(const cv::Mat & patch) const;

  // 1x7 CV_32F obstacle features for a full-tile patch
  // (map_features.obstacle_features, margin 0.20): interior occ/free/unk,
  // center_occ, blob_radius, compactness, interior_grad.
  cv::Mat obstacleFeatures(const cv::Mat & patch) const;

  // rot90 CCW applied k times (k in {0..3}); k=0 returns a clone.
  static cv::Mat rot90ccw(const cv::Mat & patch, int k);

  // Full gated subtile inference from a subtile-centered patch.
  SubtileGeometryPrediction predictSubtile(const cv::Mat & patch) const;

  // Per-tile obstacle (full-tile crop). NOT emitted to the matrix yet.
  bool predictObstacle(const cv::Mat & tile_patch) const;

private:
  int predictLabel(const cv::Ptr<cv::ml::RTrees> & model, const cv::Mat & feature_row) const;

  cv::Ptr<cv::ml::RTrees> explored_;
  cv::Ptr<cv::ml::RTrees> wall_;
  cv::Ptr<cv::ml::RTrees> curve_;
  cv::Ptr<cv::ml::RTrees> obstacle_;
  bool loaded_ = false;
};

}  // namespace ros2_mapper

#endif  // ROS2_MAPPER__MAP_GEOMETRY_MODELS_HPP_
