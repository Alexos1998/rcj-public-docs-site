#include "ros2_mapper/submission_matrix_builder.hpp"

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <limits>
#include <optional>
#include <queue>
#include <set>
#include <sstream>
#include <utility>

namespace ros2_mapper
{

namespace
{

// Convenience: the four wall directions in a stable order.
constexpr std::array<WallDirection, 4> kAllDirections{
  WallDirection::North,
  WallDirection::East,
  WallDirection::South,
  WallDirection::West};

bool cellInBounds(const SubmissionMatrixResult & result, int r, int c)
{
  return r >= 0 && c >= 0 &&
    r < static_cast<int>(result.cells.size()) &&
    c < static_cast<int>(result.cells[r].size());
}

void setCell(
  SubmissionMatrixResult & result,
  int base_row,
  int base_col,
  const MatrixCell & cell,
  const std::string & token)
{
  const int r = base_row + cell.row;
  const int c = base_col + cell.col;

  if (cellInBounds(result, r, c)) {
    result.cells[r][c] = token;
  }
}

void fillZerosEnclosedByArea4(SubmissionMatrixResult & result)
{
  const int rows = static_cast<int>(result.cells.size());
  if (rows == 0) {
    return;
  }

  std::vector<std::vector<bool>> visited(
    result.cells.size(), std::vector<bool>());
  for (std::size_t r = 0; r < result.cells.size(); ++r) {
    visited[r].assign(result.cells[r].size(), false);
  }

  constexpr int kDr[4] = {-1, 1, 0, 0};
  constexpr int kDc[4] = {0, 0, -1, 1};

  for (int start_r = 0; start_r < rows; ++start_r) {
    const int cols = static_cast<int>(result.cells[start_r].size());
    for (int start_c = 0; start_c < cols; ++start_c) {
      if (visited[start_r][start_c] || result.cells[start_r][start_c] != "0") {
        continue;
      }

      bool enclosed_by_area4 = true;
      std::vector<std::pair<int, int>> component;
      std::queue<std::pair<int, int>> q;

      visited[start_r][start_c] = true;
      q.push({start_r, start_c});

      while (!q.empty()) {
        const auto current = q.front();
        q.pop();
        component.push_back(current);

        for (int i = 0; i < 4; ++i) {
          const int nr = current.first + kDr[i];
          const int nc = current.second + kDc[i];

          if (!cellInBounds(result, nr, nc)) {
            enclosed_by_area4 = false;
            continue;
          }

          const std::string & neighbor = result.cells[nr][nc];
          if (neighbor == "0") {
            if (!visited[nr][nc]) {
              visited[nr][nc] = true;
              q.push({nr, nc});
            }
          } else if (neighbor != "*") {
            enclosed_by_area4 = false;
          }
        }
      }

      if (enclosed_by_area4) {
        for (const auto & cell : component) {
          result.cells[cell.first][cell.second] = "*";
        }
      }
    }
  }
}

}  // namespace

MatrixCell SubmissionMatrixBuilder::quarterCenterCell(SubmissionSubtile subtile)
{
  switch (subtile) {
    case SubmissionSubtile::NW:
      return {1, 1};
    case SubmissionSubtile::NE:
      return {1, 3};
    case SubmissionSubtile::SW:
      return {3, 1};
    case SubmissionSubtile::SE:
      return {3, 3};
  }

  return {1, 1};
}

MatrixCell SubmissionMatrixBuilder::edgeCell(SubmissionSubtile subtile, WallDirection dir)
{
  const MatrixCell center = quarterCenterCell(subtile);

  switch (dir) {
    case WallDirection::North:
      return {center.row - 1, center.col};
    case WallDirection::South:
      return {center.row + 1, center.col};
    case WallDirection::West:
      return {center.row, center.col - 1};
    case WallDirection::East:
      return {center.row, center.col + 1};
  }

  return center;
}

std::array<MatrixCell, 2> SubmissionMatrixBuilder::edgeVertices(
  SubmissionSubtile subtile, WallDirection dir)
{
  const MatrixCell edge = edgeCell(subtile, dir);

  // North/South edges are horizontal -> endpoints left/right.
  // East/West edges are vertical    -> endpoints up/down.
  if (dir == WallDirection::North || dir == WallDirection::South) {
    return {{{edge.row, edge.col - 1}, {edge.row, edge.col + 1}}};
  }

  return {{{edge.row - 1, edge.col}, {edge.row + 1, edge.col}}};
}

std::array<WallDirection, 2> SubmissionMatrixBuilder::curveEdgeDirections(int curve_dir)
{
  // curve_dir matches PrimitiveKind::Curve1..Curve4. The rounded corner of the
  // subtile is given by curveProtoTranslationWebots():
  //   Curve1 -> SW corner, Curve2 -> NW, Curve3 -> NE, Curve4 -> SE.
  // The curve connects the two edges meeting at that corner.
  switch (curve_dir) {
    case 1:  // SW corner
      return {{WallDirection::South, WallDirection::West}};
    case 2:  // NW corner
      return {{WallDirection::North, WallDirection::West}};
    case 3:  // NE corner
      return {{WallDirection::North, WallDirection::East}};
    case 4:  // SE corner
      return {{WallDirection::South, WallDirection::East}};
    default:
      return {{WallDirection::North, WallDirection::East}};
  }
}

MatrixCell SubmissionMatrixBuilder::curveSuppressedVertex(
  SubmissionSubtile subtile, int curve_dir)
{
  const MatrixCell center = quarterCenterCell(subtile);

  switch (curve_dir) {
    case 1:  // SW corner
      return {center.row + 1, center.col - 1};
    case 2:  // NW corner
      return {center.row - 1, center.col - 1};
    case 3:  // NE corner
      return {center.row - 1, center.col + 1};
    case 4:  // SE corner
      return {center.row + 1, center.col + 1};
    default:
      return {center.row - 1, center.col + 1};
  }
}

SubmissionMatrixResult SubmissionMatrixBuilder::build(
  const TileMap & tile_map,
  const SubmissionResolvedWalls * resolved_walls) const
{
  SubmissionMatrixResult result;

  const auto & records = tile_map.records();

  if (records.empty()) {
    return result;
  }

  result.min_x = std::numeric_limits<int>::max();
  result.max_x = std::numeric_limits<int>::min();
  result.min_y = std::numeric_limits<int>::max();
  result.max_y = std::numeric_limits<int>::min();

  for (const auto & entry : records) {
    const TileRecord & record = entry.second;

    result.min_x = std::min(result.min_x, record.coord.x);
    result.max_x = std::max(result.max_x, record.coord.x);
    result.min_y = std::min(result.min_y, record.coord.y);
    result.max_y = std::max(result.max_y, record.coord.y);
  }

  result.tile_width = result.max_x - result.min_x + 1;
  result.tile_height = result.max_y - result.min_y + 1;

  const int matrix_rows = 4 * result.tile_height + 1;
  const int matrix_cols = 4 * result.tile_width + 1;

  result.cells.assign(
    matrix_rows, std::vector<std::string>(matrix_cols, "0"));

  // Straight-wall vertex support is resolved after all edges are marked so that
  // shared vertices behave consistently across neighbouring tiles.
  std::set<std::pair<int, int>> straight_vertices;

  auto mark_full_wall = [&](int base_row, int base_col, WallDirection dir) {
    // A full-tile wall spans the two quarter edges along that side.
    const std::array<SubmissionSubtile, 2> subtiles = [dir]() {
      switch (dir) {
        case WallDirection::North:
          return std::array<SubmissionSubtile, 2>{
            SubmissionSubtile::NW, SubmissionSubtile::NE};
        case WallDirection::South:
          return std::array<SubmissionSubtile, 2>{
            SubmissionSubtile::SW, SubmissionSubtile::SE};
        case WallDirection::West:
          return std::array<SubmissionSubtile, 2>{
            SubmissionSubtile::NW, SubmissionSubtile::SW};
        case WallDirection::East:
          return std::array<SubmissionSubtile, 2>{
            SubmissionSubtile::NE, SubmissionSubtile::SE};
      }
      return std::array<SubmissionSubtile, 2>{
        SubmissionSubtile::NW, SubmissionSubtile::NE};
    }();

    for (SubmissionSubtile sub : subtiles) {
      const MatrixCell edge = edgeCell(sub, dir);
      setCell(result, base_row, base_col, edge, "1");

      for (const MatrixCell & vtx : edgeVertices(sub, dir)) {
        straight_vertices.insert({base_row + vtx.row, base_col + vtx.col});
      }
    }
  };

  for (const auto & entry : records) {
    const TileRecord & record = entry.second;

    const int base_row = 4 * (result.max_y - record.coord.y);
    const int base_col = 4 * (record.coord.x - result.min_x);

    const std::string value = tileValue(record);
    for (SubmissionSubtile sub :
      {SubmissionSubtile::NW, SubmissionSubtile::NE,
        SubmissionSubtile::SW, SubmissionSubtile::SE})
    {
      setCell(result, base_row, base_col, quarterCenterCell(sub), value);
    }

    const EdgeWalls * resolved_tile_walls =
      resolvedWallsForTile(resolved_walls, record.coord);

    const EdgeWalls & walls =
      resolved_tile_walls != nullptr ? *resolved_tile_walls : record.walls;

    if (isWall(walls.north)) {
      mark_full_wall(base_row, base_col, WallDirection::North);
    }
    if (isWall(walls.south)) {
      mark_full_wall(base_row, base_col, WallDirection::South);
    }
    if (isWall(walls.west)) {
      mark_full_wall(base_row, base_col, WallDirection::West);
    }
    if (isWall(walls.east)) {
      mark_full_wall(base_row, base_col, WallDirection::East);
    }
  }

  for (const auto & vtx : straight_vertices) {
    if (cellInBounds(result, vtx.first, vtx.second)) {
      result.cells[vtx.first][vtx.second] = "1";
    }
  }

  fillZerosEnclosedByArea4(result);

  return result;
}

SubmissionMatrixResult SubmissionMatrixBuilder::build(
  const TileMap & tile_map,
  const SubmissionResolvedTileModels & resolved_models) const
{
  SubmissionMatrixResult result;

  const auto & records = tile_map.records();

  if (records.empty()) {
    return result;
  }

  result.min_x = std::numeric_limits<int>::max();
  result.max_x = std::numeric_limits<int>::min();
  result.min_y = std::numeric_limits<int>::max();
  result.max_y = std::numeric_limits<int>::min();

  // Resolved models may cover tiles beyond the visited records (model-explored
  // tiles, Area 4 flood fill), so the matrix bounds must span both sets.
  for (const auto & entry : records) {
    const TileRecord & record = entry.second;
    result.min_x = std::min(result.min_x, record.coord.x);
    result.max_x = std::max(result.max_x, record.coord.x);
    result.min_y = std::min(result.min_y, record.coord.y);
    result.max_y = std::max(result.max_y, record.coord.y);
  }
  for (const auto & entry : resolved_models) {
    const TileCoord & coord = entry.second.coord;
    result.min_x = std::min(result.min_x, coord.x);
    result.max_x = std::max(result.max_x, coord.x);
    result.min_y = std::min(result.min_y, coord.y);
    result.max_y = std::max(result.max_y, coord.y);
  }

  result.tile_width = result.max_x - result.min_x + 1;
  result.tile_height = result.max_y - result.min_y + 1;

  const int matrix_rows = 4 * result.tile_height + 1;
  const int matrix_cols = 4 * result.tile_width + 1;

  result.cells.assign(
    matrix_rows, std::vector<std::string>(matrix_cols, "0"));

  // Vertex resolution sets (see header / three-pass design).
  std::set<std::pair<int, int>> straight_vertices;
  std::set<std::pair<int, int>> curve_only_vertices;

  const SubmissionSubtile kSubtiles[4] = {
    SubmissionSubtile::NW, SubmissionSubtile::NE,
    SubmissionSubtile::SW, SubmissionSubtile::SE};

  // --- Pass 1: quarter centers, straight walls + straight vertices. ---
  for (const auto & entry : resolved_models) {
    const SubmissionTileModel & model = entry.second;

    const int base_row = 4 * (result.max_y - model.coord.y);
    const int base_col = 4 * (model.coord.x - result.min_x);

    if (model.area4_wildcard) {
      continue;
    }

    for (int i = 0; i < 4; ++i) {
      const SubmissionSubtileModel & sub = model.subtiles[i];
      setCell(result, base_row, base_col, quarterCenterCell(kSubtiles[i]), sub.value);

      if (sub.curve_dir != 0) {
        continue;  // straight walls of curved subtiles handled in pass 2
      }

      const bool wall_flags[4] = {
        sub.wall_north, sub.wall_east, sub.wall_south, sub.wall_west};

      for (int d = 0; d < 4; ++d) {
        if (!wall_flags[d]) {
          continue;
        }

        const WallDirection dir = kAllDirections[d];
        setCell(result, base_row, base_col, edgeCell(kSubtiles[i], dir), "1");

        for (const MatrixCell & vtx : edgeVertices(kSubtiles[i], dir)) {
          straight_vertices.insert({base_row + vtx.row, base_col + vtx.col});
        }
      }
    }

    // TODO(obstacle): the tile-level obstacle model is wired (model.obstacle),
    // but emitting 'x' is deferred. An obstacle is marked on the whole 0.12 m
    // tile with 'x' at its four corner cells. Uncomment when the convention is
    // finalized:
    // if (model.obstacle) {
    //   for (const MatrixCell corner : {MatrixCell{0, 0}, MatrixCell{0, 4},
    //                                   MatrixCell{4, 0}, MatrixCell{4, 4}}) {
    //     setCell(result, base_row, base_col, corner, "x");
    //   }
    // }
  }

  // --- Pass 2: curve edge cells + record curve-only vertices. ---
  for (const auto & entry : resolved_models) {
    const SubmissionTileModel & model = entry.second;

    if (model.area4_wildcard) {
      continue;
    }

    const int base_row = 4 * (result.max_y - model.coord.y);
    const int base_col = 4 * (model.coord.x - result.min_x);

    for (int i = 0; i < 4; ++i) {
      const SubmissionSubtileModel & sub = model.subtiles[i];
      if (sub.curve_dir == 0) {
        continue;
      }

      for (WallDirection dir : curveEdgeDirections(sub.curve_dir)) {
        setCell(result, base_row, base_col, edgeCell(kSubtiles[i], dir), "1");
      }

      const MatrixCell vtx = curveSuppressedVertex(kSubtiles[i], sub.curve_dir);
      curve_only_vertices.insert({base_row + vtx.row, base_col + vtx.col});
    }
  }

  // --- Pass 3: resolve vertices. Straight support wins; curve-only stays 0. ---
  for (const auto & vtx : straight_vertices) {
    if (cellInBounds(result, vtx.first, vtx.second)) {
      result.cells[vtx.first][vtx.second] = "1";
    }
  }
  // Curve-only vertices are deliberately left as "0" unless straight support
  // already promoted them above (the normal-right-angle exception).

  // Victims are deliberately NOT written into the submission matrix: the
  // current competition format does not accept victim codes in map cells.
  // Victim marks are still kept on the models (soft-tile protection).

  // --- Overlay area-4 wildcard blocks last. ---
  applyArea4StarsToSubmissionMatrix(result, buildArea4Mask(resolved_models));

  fillZerosEnclosedByArea4(result);

  return result;
}

namespace
{

// A model the Area 4 flood fill may safely overwrite with a wildcard: nothing
// committed it to another area and it carries no semantic evidence. Covers
// records created only by wall votes and tiles added by the explored scan.
bool isSoftModel(const SubmissionTileModel & model)
{
  if (model.area4_wildcard || model.area4_gateway || model.committed) {
    return false;
  }
  if (!model.area_uncertain || !model.victims.empty()) {
    return false;
  }
  for (const auto & subtile : model.subtiles) {
    if (subtile.value != "0") {
      return false;  // start/hole/swamp/checkpoint/transition token
    }
  }
  return true;
}

WallDirection oppositeWallDirection(WallDirection direction)
{
  switch (direction) {
    case WallDirection::North:
      return WallDirection::South;
    case WallDirection::East:
      return WallDirection::West;
    case WallDirection::South:
      return WallDirection::North;
    case WallDirection::West:
      return WallDirection::East;
  }

  return WallDirection::North;
}

bool submissionModelHasWallOnSide(
  const SubmissionTileModel & model,
  WallDirection direction)
{
  const auto & nw = model.subtiles[static_cast<int>(SubmissionSubtile::NW)];
  const auto & ne = model.subtiles[static_cast<int>(SubmissionSubtile::NE)];
  const auto & sw = model.subtiles[static_cast<int>(SubmissionSubtile::SW)];
  const auto & se = model.subtiles[static_cast<int>(SubmissionSubtile::SE)];

  switch (direction) {
    case WallDirection::North:
      return nw.wall_north || ne.wall_north;
    case WallDirection::East:
      return ne.wall_east || se.wall_east;
    case WallDirection::South:
      return sw.wall_south || se.wall_south;
    case WallDirection::West:
      return nw.wall_west || sw.wall_west;
  }

  return false;
}

std::optional<WallDirection> cardinalDirectionBetween(
  const TileCoord & from,
  const TileCoord & to)
{
  const int dx = to.x - from.x;
  const int dy = to.y - from.y;
  if (dx == 1 && dy == 0) {
    return WallDirection::East;
  }
  if (dx == -1 && dy == 0) {
    return WallDirection::West;
  }
  if (dx == 0 && dy == 1) {
    return WallDirection::North;
  }
  if (dx == 0 && dy == -1) {
    return WallDirection::South;
  }
  return std::nullopt;
}

bool cardinalConnectionBlockedByWall(
  const SubmissionResolvedTileModels & models,
  const TileCoord & from,
  const TileCoord & to)
{
  const auto direction = cardinalDirectionBetween(from, to);
  if (!direction) {
    return false;
  }

  const auto from_it = models.find(from);
  if (
    from_it != models.end() &&
    submissionModelHasWallOnSide(from_it->second, *direction))
  {
    return true;
  }

  const auto to_it = models.find(to);
  if (
    to_it != models.end() &&
    submissionModelHasWallOnSide(to_it->second, oppositeWallDirection(*direction)))
  {
    return true;
  }

  return false;
}

bool area4ConnectionAllowed(
  const SubmissionResolvedTileModels & models,
  const TileCoord & from,
  const TileCoord & to)
{
  const int dx = to.x - from.x;
  const int dy = to.y - from.y;

  if (std::abs(dx) + std::abs(dy) == 1) {
    return !cardinalConnectionBlockedByWall(models, from, to);
  }

  if (std::abs(dx) == 1 && std::abs(dy) == 1) {
    const TileCoord via_x{from.x + dx, from.y};
    const TileCoord via_y{from.x, from.y + dy};

    const bool path_x_open =
      models.count(via_x) != 0 &&
      !cardinalConnectionBlockedByWall(models, from, via_x) &&
      !cardinalConnectionBlockedByWall(models, via_x, to);
    const bool path_y_open =
      models.count(via_y) != 0 &&
      !cardinalConnectionBlockedByWall(models, from, via_y) &&
      !cardinalConnectionBlockedByWall(models, via_y, to);

    return path_x_open || path_y_open;
  }

  return false;
}

}  // namespace

SubmissionArea4Mask SubmissionMatrixBuilder::buildArea4Mask(
  const SubmissionResolvedTileModels & models)
{
  SubmissionArea4Mask mask;
  for (const auto & entry : models) {
    const SubmissionTileModel & model = entry.second;
    if (model.area4_wildcard) {
      mask.insert(model.coord);
    }
  }
  return mask;
}

bool SubmissionMatrixBuilder::isArea4SubmissionCell(
  const SubmissionResolvedTileModels & models,
  const TileCoord & coord)
{
  const auto iter = models.find(coord);
  return iter != models.end() && iter->second.area4_wildcard;
}

int SubmissionMatrixBuilder::promoteConnectedArea4ObservedTiles(
  SubmissionResolvedTileModels & models,
  SubmissionArea4ExpansionStats * stats)
{
  std::queue<TileCoord> queue;
  SubmissionArea4Mask enqueued;

  for (const auto & entry : models) {
    const SubmissionTileModel & model = entry.second;
    if (model.area4_wildcard) {
      enqueued.insert(model.coord);
      queue.push(model.coord);
    }
  }

  if (queue.empty()) {
    return 0;
  }

  // Area 4 is not constrained to cardinal tile motion; use 8-neighbour
  // connectivity, but only across existing observed soft models.
  constexpr int kDx[8] = {1, -1, 0, 0, 1, 1, -1, -1};
  constexpr int kDy[8] = {0, 0, 1, -1, 1, -1, 1, -1};

  int promoted = 0;
  while (!queue.empty()) {
    const TileCoord tile = queue.front();
    queue.pop();

    for (int i = 0; i < 8; ++i) {
      const TileCoord next{tile.x + kDx[i], tile.y + kDy[i]};
      if (enqueued.count(next) != 0) {
        continue;
      }
      enqueued.insert(next);
      if (stats != nullptr) {
        ++stats->candidate_edges;
      }

      if (!area4ConnectionAllowed(models, tile, next)) {
        if (stats != nullptr) {
          ++stats->rejected_by_wall;
        }
        continue;
      }

      auto existing = models.find(next);
      if (existing == models.end()) {
        if (stats != nullptr) {
          ++stats->rejected_missing_model;
        }
        continue;
      }

      SubmissionTileModel & model = existing->second;
      if (model.area4_wildcard) {
        queue.push(next);
        continue;
      }

      if (!isSoftModel(model)) {
        if (stats != nullptr) {
          ++stats->rejected_non_soft;
        }
        continue;
      }

      model.area = TileArea::Area4;
      model.area_uncertain = false;
      model.area4_wildcard = true;
      model.subtiles = {};
      ++promoted;
      if (stats != nullptr) {
        ++stats->promoted_tiles;
      }
      queue.push(next);
    }
  }

  return promoted;
}

int SubmissionMatrixBuilder::applyArea4StarsToSubmissionMatrix(
  SubmissionMatrixResult & result,
  const SubmissionArea4Mask & area4_mask)
{
  int changed = 0;
  for (const TileCoord & coord : area4_mask) {
    const int base_row = 4 * (result.max_y - coord.y);
    const int base_col = 4 * (coord.x - result.min_x);

    for (int dr = 0; dr <= 4; ++dr) {
      for (int dc = 0; dc <= 4; ++dc) {
        const int r = base_row + dr;
        const int c = base_col + dc;
        if (!cellInBounds(result, r, c)) {
          continue;
        }
        if (result.cells[r][c] != "*") {
          ++changed;
        }
        result.cells[r][c] = "*";
      }
    }
  }
  return changed;
}

int SubmissionMatrixBuilder::applyArea4FloodFill(
  SubmissionResolvedTileModels & models,
  SubmissionArea4ExpansionStats * stats)
{
  std::vector<TileCoord> seeds;
  int gateway_count = 0;
  int min_x = std::numeric_limits<int>::max();
  int max_x = std::numeric_limits<int>::min();
  int min_y = std::numeric_limits<int>::max();
  int max_y = std::numeric_limits<int>::min();

  for (const auto & entry : models) {
    const SubmissionTileModel & model = entry.second;
    if (!model.area4_wildcard && !model.area4_gateway) {
      continue;
    }
    seeds.push_back(model.coord);
    min_x = std::min(min_x, model.coord.x);
    max_x = std::max(max_x, model.coord.x);
    min_y = std::min(min_y, model.coord.y);
    max_y = std::max(max_y, model.coord.y);
    if (model.area4_gateway) {
      ++gateway_count;
    }
  }

  // Only fill once the entrance AND the exit of Area 4 are known; with a
  // single gateway the extent of the room is still unconstrained.
  if (gateway_count < 2 || seeds.empty()) {
    return 0;
  }

  constexpr int kDx[4] = {1, -1, 0, 0};
  constexpr int kDy[4] = {0, 0, 1, -1};

  std::unordered_map<TileCoord, bool, TileCoordHash> enqueued;
  std::queue<TileCoord> queue;
  for (const TileCoord & seed : seeds) {
    enqueued[seed] = true;
    queue.push(seed);
  }

  int filled = 0;
  while (!queue.empty()) {
    const TileCoord tile = queue.front();
    queue.pop();

    for (int i = 0; i < 4; ++i) {
      const TileCoord next{tile.x + kDx[i], tile.y + kDy[i]};
      if (next.x < min_x || next.x > max_x || next.y < min_y || next.y > max_y) {
        continue;  // never extrapolate beyond the known Area 4 bounding box
      }
      if (enqueued.count(next) != 0) {
        continue;
      }
      enqueued[next] = true;
      if (stats != nullptr) {
        ++stats->candidate_edges;
      }

      if (!area4ConnectionAllowed(models, tile, next)) {
        if (stats != nullptr) {
          ++stats->rejected_by_wall;
        }
        continue;
      }

      const auto existing = models.find(next);
      if (existing != models.end()) {
        if (existing->second.area4_wildcard) {
          // Known Area 4 tile: continue through.
          queue.push(next);
        } else if (isSoftModel(existing->second)) {
          // Uncommitted, semantics-free tile inside the room (wall-vote record
          // or explored-scan tile): overwrite with the wildcard instead of
          // leaving spurious wall geometry as a hole in the '*' block.
          SubmissionTileModel & soft = existing->second;
          soft.area = TileArea::Area4;
          soft.area_uncertain = false;
          soft.area4_wildcard = true;
          soft.subtiles = {};
          ++filled;
          if (stats != nullptr) {
            ++stats->promoted_tiles;
          }
          queue.push(next);
        }
        // Committed / semantic / other-area tiles block the fill.
        else if (stats != nullptr) {
          ++stats->rejected_non_soft;
        }
      } else if (stats != nullptr) {
        ++stats->rejected_missing_model;
      }
    }
  }

  return filled;
}

std::string SubmissionMatrixBuilder::toText(const SubmissionMatrixResult & result)
{
  std::ostringstream oss;

  for (std::size_t r = 0; r < result.cells.size(); ++r) {
    if (r > 0U) {
      oss << '\n';
    }

    for (const std::string & token : result.cells[r]) {
      // Single-character cells reproduce the legacy output exactly; multi-code
      // victim cells preserve the concatenated token. Adapt here if the
      // competition platform requires explicit delimiters.
      oss << token;
    }
  }

  return oss.str();
}

std::string SubmissionMatrixBuilder::tileValue(const TileRecord & record)
{
  if (record.area == TileArea::Area4 &&
    !(record.is_transition || record.kind == TileKind::Transition))
  {
    return "*";
  }

  if (record.is_start || record.kind == TileKind::Start) {
    return "5";
  }

  if (record.is_hole || record.kind == TileKind::Hole) {
    return "2";
  }

  if (record.is_swamp || record.kind == TileKind::Swamp) {
    return "3";
  }

  if (record.is_checkpoint || record.kind == TileKind::Checkpoint) {
    return "4";
  }

  if (record.is_transition || record.kind == TileKind::Transition) {
    const char from_transition = transitionValue(record.transition);

    if (from_transition != '0') {
      return std::string(1, from_transition);
    }

    return std::string(1, transitionValueFromFloorColor(record.floor_color));
  }

  return "0";
}

char SubmissionMatrixBuilder::transitionValue(const TransitionInfo & transition)
{
  const TileArea a = transition.area_a;
  const TileArea b = transition.area_b;

  auto pair_is = [&](TileArea x, TileArea y) {
    return (a == x && b == y) || (a == y && b == x);
  };

  // Official mapping (do NOT trust enum color names for the output char):
  //   Area1<->Area2 = b, Area2<->Area3 = p, Area3<->Area4 = r,
  //   Area1<->Area4 = g, Area1<->Area3 = y, Area2<->Area4 = o
  if (pair_is(TileArea::Area1, TileArea::Area2)) {
    return 'b';
  }
  if (pair_is(TileArea::Area2, TileArea::Area3)) {
    return 'p';
  }
  if (pair_is(TileArea::Area3, TileArea::Area4)) {
    return 'r';
  }
  if (pair_is(TileArea::Area1, TileArea::Area4)) {
    return 'g';
  }
  if (pair_is(TileArea::Area1, TileArea::Area3)) {
    return 'y';
  }
  if (pair_is(TileArea::Area2, TileArea::Area4)) {
    return 'o';
  }

  return '0';
}

char SubmissionMatrixBuilder::transitionValueFromFloorColor(FloorColorClass color)
{
  // Map by the area pair the color encodes, then apply the official mapping.
  // The enum names are historical and must not drive the output char.
  switch (color) {
    case FloorColorClass::BlueArea1To2:
      return 'b';  // Area1<->Area2

    case FloorColorClass::PurpleArea2To3:
      return 'p';  // Area2<->Area3

    case FloorColorClass::RedArea3To4:
      return 'r';  // Area3<->Area4

    case FloorColorClass::GreenArea1To4:
      return 'g';  // Area1<->Area4

    case FloorColorClass::YellowArea1To3:
      return 'y';  // Area1<->Area3

    case FloorColorClass::OrangeArea2To4:
      return 'o';  // Area2<->Area4

    default:
      return '0';
  }
}

bool SubmissionMatrixBuilder::isWall(WallState state)
{
  return state == WallState::Wall || state == WallState::VirtualWall;
}

const EdgeWalls * SubmissionMatrixBuilder::resolvedWallsForTile(
  const SubmissionResolvedWalls * resolved_walls,
  const TileCoord & coord)
{
  if (resolved_walls == nullptr) {
    return nullptr;
  }

  const auto it = resolved_walls->find(coord);

  if (it == resolved_walls->end()) {
    return nullptr;
  }

  return &it->second;
}

}  // namespace ros2_mapper
