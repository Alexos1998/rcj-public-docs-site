#pragma once

#include "ros2_bridge/protocol_parser.hpp"
#include "ros2_bridge/tcp_server.hpp"

#include "exploration_legacy/reachability.hpp"

#include <geometry_msgs/msg/transform_stamped.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <nav2_msgs/action/compute_path_to_pose.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <nav_msgs/msg/occupancy_grid.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include <rclcpp/rclcpp.hpp>
#include <rosgraph_msgs/msg/clock.hpp>
#include <sensor_msgs/msg/imu.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <std_msgs/msg/string.hpp>
#include <tf2_ros/static_transform_broadcaster.h>
#include <tf2_ros/transform_broadcaster.h>

#include <cstddef>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace ros2_bridge
{

class BridgeNode : public rclcpp::Node
{
public:
  BridgeNode();
  ~BridgeNode() override;

private:
  using ComputePathToPose = nav2_msgs::action::ComputePathToPose;

  enum class EventLevel
  {
    Info,
    Warn,
    Error,
    Debug
  };

  struct TcpConfig
  {
    std::string host = "0.0.0.0";
    int port = 5000;
    std::size_t max_line_bytes = 1048576;
    std::size_t recv_buffer_bytes = 8192;
  };

  struct ImuConfig
  {
    std::string frame = "imu_link";
    bool invert_yaw = false;
  };

  struct GpsConfig
  {
    std::string frame = "gps_link";
    std::string odom_frame = "odom";
    bool swap_xy = false;
    bool invert_x = false;
    bool invert_y = false;
    bool invert_z = false;
  };

  struct ScanConfig
  {
    std::string frame = "lidar_link";
    double angle_min = -3.141592653589793;
    double angle_max = 3.141592653589793;
    double range_min = 0.001;
    double range_max = 1.0;
    bool rotate_half_turn = false;
    bool invert = false;
    bool mirror_left_right = false;
  };

  void declareParameters();
  void loadParameters();
  void validateParameters() const;

  void createPublishers();
  void createSubscriptions();
  void createActionClients();
  void publishStaticTransforms();
  void startTcpServer();
  void startStatusTimer();

  void handleLine(const std::string & line);
  void cmdVelCallback(const geometry_msgs::msg::Twist::SharedPtr msg);
  void submissionMatrixCallback(const std_msgs::msg::String::SharedPtr msg);
  void globalCostmapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg);
  void localCostmapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg);

  void handleTime(const std::string & payload);
  void handleImu(const std::string & payload);
  void handleGps(const std::string & payload);
  void handleLocalization(const std::string & payload);
  void handleWheelOdom(const std::string & payload);
  void handleScan(const std::string & payload);
  void handleColor(const std::string & payload);
  void handleHole(const std::string & payload);
  void handleVision(const std::string & payload);
  void handleLegacyReachabilityRequest(const std::string & line);

  rclcpp::Time makeSensorStamp();
  static rclcpp::Time secondsToRosTime(double seconds);
  static std::vector<std::string> splitFields(const std::string & text, char delimiter);
  static bool parseDoubleStrict(const std::string & text, double & value);
  static bool parseUint64Strict(const std::string & text, std::uint64_t & value);
  static double quaternionYaw(const geometry_msgs::msg::Quaternion & q);
  static geometry_msgs::msg::PoseStamped makePoseStamped(
    const std::string & frame_id,
    const rclcpp::Time & stamp,
    double x,
    double y,
    double yaw);
  std::shared_ptr<const exploration_legacy::CostmapSnapshot> latestCostmapSnapshot() const;
  std::shared_ptr<const exploration_legacy::CostmapSnapshot> latestLocalCostmapSnapshot() const;
  exploration_legacy::ReachabilityResult validatePlannerSegment(
    const exploration_legacy::PathSegment & segment);
  void sendLegacyReachabilityResponse(
    std::uint64_t request_id,
    const exploration_legacy::ReachabilityResult & result);
  void logDebugSummary(const std::string & message_type);
  void handleTcpConnected(const std::string & remote_endpoint);
  void handleTcpDisconnected();
  void recordLineReceived();
  void recordParseError();
  void recordReceived(ProtocolMessageType type);
  void recordPublished(ProtocolMessageType type);
  void publishStatus();
  void resetCurrentConnectionReadinessLocked();
  void logRobotEvent(
    EventLevel level,
    const std::string & event,
    const std::vector<std::pair<std::string, std::string>> & fields = {}) const;
  void logRobotEvent(
    const std::string & event,
    const std::vector<std::pair<std::string, std::string>> & fields = {}) const;
  std::string statusJson(const rclcpp::Time & stamp) const;
  std::string readyJson(bool & ready) const;

  bool debug_mode_ = false;
  double status_publish_period_s_ = 0.1;

  TcpConfig tcp_;
  ImuConfig imu_;
  GpsConfig gps_;
  ScanConfig scan_;

  exploration_legacy::LegacyReachabilityChecker::Config reachability_config_;
  std::string global_costmap_topic_ = "/global_costmap/costmap";
  // Layer 2 of the layered edge clearing: the higher-resolution / more current
  // local costmap can free edges the (inflated/coarse) global costmap blocked.
  std::string local_costmap_topic_ = "/local_costmap/costmap";
  std::string planner_action_name_ = "/compute_path_to_pose";
  std::string planner_id_ = "GridBased";
  double reachability_request_timeout_s_ = 1.0;
  double reachability_costmap_snapshot_log_period_s_ = 1.0;
  bool reachability_log_candidate_events_ = false;

  // Time / sim-time handling.
  //   publish_clock_                 -> republish Webots TIME on /clock.
  //   use_webots_time_for_stamps_    -> stamp sensors with Webots time, not now().
  //   scan_time_s_                   -> LaserScan.scan_time advertised to consumers.
  bool publish_clock_ = false;
  bool use_webots_time_for_stamps_ = false;
  double scan_time_s_ = 0.016;
  double current_batch_sim_time_ = 0.0;
  bool has_current_batch_sim_time_ = false;

  std::unordered_map<std::string, std::size_t> debug_message_counts_;
  rclcpp::Time last_debug_summary_time_;

  ProtocolParser parser_;
  std::unique_ptr<TcpServer> tcp_server_;

  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr submission_matrix_sub_;
  rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr global_costmap_sub_;
  rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr local_costmap_sub_;
  rclcpp_action::Client<ComputePathToPose>::SharedPtr compute_path_client_;
  
  std::string floor_color_topic_ = "/floor_color/classification";
  std::string hole_detection_topic_ = "/hazard/hole_detection";
  std::string vision_classification_topic_ = "/vision/classification";

  rclcpp::Publisher<sensor_msgs::msg::Imu>::SharedPtr imu_pub_;
  rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr gps_odom_pub_;
  rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr localization_odom_pub_;
  rclcpp::Publisher<nav_msgs::msg::Odometry>::SharedPtr wheel_odom_pub_;
  rclcpp::Publisher<sensor_msgs::msg::LaserScan>::SharedPtr scan_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr floor_color_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr hole_detection_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr vision_classification_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr status_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr ready_pub_;
  rclcpp::Publisher<rosgraph_msgs::msg::Clock>::SharedPtr clock_pub_;
  std::unique_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;
  std::unique_ptr<tf2_ros::StaticTransformBroadcaster> static_tf_broadcaster_;
  rclcpp::TimerBase::SharedPtr status_timer_;

  mutable std::mutex costmap_mutex_;
  nav_msgs::msg::OccupancyGrid::SharedPtr latest_global_costmap_;
  std::shared_ptr<const exploration_legacy::CostmapSnapshot> latest_global_costmap_snapshot_;
  rclcpp::Time latest_global_costmap_receive_time_;
  bool logged_first_global_costmap_ = false;
  nav_msgs::msg::OccupancyGrid::SharedPtr latest_local_costmap_;
  std::shared_ptr<const exploration_legacy::CostmapSnapshot> latest_local_costmap_snapshot_;
  rclcpp::Time latest_local_costmap_receive_time_;
  bool logged_first_local_costmap_ = false;
  rclcpp::Time last_reachability_costmap_snapshot_log_stamp_;
  bool has_last_reachability_costmap_snapshot_log_stamp_ = false;
  std::string last_reachability_costmap_snapshot_signature_;

  mutable std::mutex status_mutex_;
  std::uint64_t current_connection_id_ = 0;
  std::uint64_t tcp_connect_count_ = 0;
  std::uint64_t tcp_disconnect_count_ = 0;
  std::uint64_t lines_received_ = 0;
  std::uint64_t parse_errors_ = 0;
  std::uint64_t time_count_ = 0;
  std::uint64_t loc_count_ = 0;
  std::uint64_t imu_count_ = 0;
  std::uint64_t gps_count_ = 0;
  std::uint64_t scan_count_ = 0;
  std::uint64_t color_count_ = 0;
  std::uint64_t vision_count_ = 0;
  std::uint64_t cam_count_ = 0;
  std::uint64_t imu_published_count_ = 0;
  std::uint64_t gps_published_count_ = 0;
  std::uint64_t localization_published_count_ = 0;
  std::uint64_t tf_published_count_ = 0;
  std::uint64_t scan_published_count_ = 0;
  std::uint64_t color_published_count_ = 0;
  std::uint64_t vision_published_count_ = 0;
  bool has_last_time_stamp_ = false;
  bool has_last_loc_stamp_ = false;
  bool has_last_imu_stamp_ = false;
  bool has_last_gps_stamp_ = false;
  bool has_last_scan_stamp_ = false;
  bool has_last_color_stamp_ = false;
  rclcpp::Time last_time_stamp_;
  rclcpp::Time last_loc_stamp_;
  rclcpp::Time last_imu_stamp_;
  rclcpp::Time last_gps_stamp_;
  rclcpp::Time last_scan_stamp_;
  rclcpp::Time last_color_stamp_;
  bool logged_first_time_received_ = false;
  bool logged_first_loc_received_ = false;
  bool logged_first_imu_received_ = false;
  bool logged_first_gps_received_ = false;
  bool logged_first_scan_received_ = false;
  bool logged_first_color_received_ = false;
  bool logged_first_hole_received_ = false;
  bool logged_first_vision_received_ = false;
  bool logged_first_cam_received_ = false;
  bool logged_first_imu_published_ = false;
  bool logged_first_gps_published_ = false;
  bool logged_first_localization_published_ = false;
  bool logged_first_tf_published_ = false;
  bool logged_first_scan_published_ = false;
  bool logged_first_color_published_ = false;
  bool logged_first_hole_published_ = false;
  bool logged_first_vision_published_ = false;
  bool logged_bridge_ready_ = false;
  bool loc_seen_this_connection_ = false;
  bool gps_seen_this_connection_ = false;
  bool imu_seen_this_connection_ = false;
  bool scan_seen_this_connection_ = false;
  double last_loc_z_debug_ = 0.0;
};

}  // namespace ros2_bridge
