#pragma once

#include <cstddef>

#include "geometry_msgs/msg/point.hpp"
#include "nav_msgs/msg/occupancy_grid.hpp"

#include "ros2_exploration/frontier_types.hpp"

namespace ros2_exploration::grid_utils
{

bool isInBounds(const nav_msgs::msg::OccupancyGrid & map, int x, int y);
std::size_t toLinearIndex(const nav_msgs::msg::OccupancyGrid & map, int x, int y);

int8_t occupancyAt(const nav_msgs::msg::OccupancyGrid & map, int x, int y);
bool isUnknown(int8_t value);
bool isOccupied(int8_t value, int occupied_threshold);
bool isFree(int8_t value, int occupied_threshold);

geometry_msgs::msg::Point gridToWorld(
  const nav_msgs::msg::OccupancyGrid & map,
  const GridIndex & index);

bool worldToGrid(
  const nav_msgs::msg::OccupancyGrid & map,
  const geometry_msgs::msg::Point & point,
  GridIndex & index);

}  // namespace ros2_exploration::grid_utils
