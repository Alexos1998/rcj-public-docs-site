#include "ros2_vision/onnx_runner.hpp"

#include <algorithm>
#include <cmath>
#include <numeric>
#include <stdexcept>
#include <cstdint>
#include <iostream>
#include <sstream>

#include <opencv2/imgproc.hpp>

namespace ros2_vision {
namespace {

Ort::Env& ortEnv()
{
  static Ort::Env env(ORT_LOGGING_LEVEL_WARNING, "ros2_vision");
  return env;
}

std::int64_t dimOrDefault(std::int64_t dim, std::int64_t fallback)
{
  return dim > 0 ? dim : fallback;
}

std::string shapeToString(const std::vector<std::int64_t>& shape)
{
  std::ostringstream oss;
  oss << "[";
  for (std::size_t i = 0; i < shape.size(); ++i) {
    if (i > 0) {
      oss << ",";
    }
    oss << shape[i];
  }
  oss << "]";
  return oss.str();
}

}  // namespace

OnnxRunner::OnnxRunner(const std::string& path)
{
  initialize(path);
}

OnnxRunner::OnnxRunner(const std::string& path, Options options)
  : options_(options)
{
  initialize(path);
}

void OnnxRunner::initialize(const std::string& path)
{
  session_options_.SetIntraOpNumThreads(1);
  session_options_.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_EXTENDED);

  // Config fallback shape (NCHW 1x3xHxW) -- valid even if model load fails so
  // run() has a coherent shape and the node never crashes on a bad model file.
  input_shape_ = {
    1,
    3,
    static_cast<std::int64_t>(options_.input_height),
    static_cast<std::int64_t>(options_.input_width)
  };

  std::cerr << "[VISION_INIT] loading ONNX: " << path << std::endl;

  // A missing or corrupt model file throws here. Catch it so a single bad model
  // degrades that one stage (run() returns {}) instead of taking down the node.
  try {
    session_ = std::make_unique<Ort::Session>(ortEnv(), path.c_str(), session_options_);
  } catch (const std::exception& e) {
    session_.reset();
    std::cerr << "[VISION_INIT] FAILED to load ONNX: " << path << " error=" << e.what()
              << " (stage will be treated as unavailable)" << std::endl;
    return;
  } catch (...) {
    session_.reset();
    std::cerr << "[VISION_INIT] FAILED to load ONNX: " << path
              << " error=unknown (stage will be treated as unavailable)" << std::endl;
    return;
  }

  std::cerr << "[VISION_INIT] session created: " << path << std::endl;

  Ort::AllocatorWithDefaultOptions allocator;
  const std::size_t input_count = session_->GetInputCount();
  const std::size_t output_count = session_->GetOutputCount();

  input_names_storage_.clear();
  output_names_storage_.clear();
  input_names_.clear();
  output_names_.clear();

  for (std::size_t i = 0; i < input_count; ++i) {
#if ORT_API_VERSION >= 12
    auto name = session_->GetInputNameAllocated(i, allocator);
    input_names_storage_.emplace_back(name.get());
#else
    char* name = session_->GetInputName(i, allocator);
    input_names_storage_.emplace_back(name);
    allocator.Free(name);
#endif
  }

  for (std::size_t i = 0; i < output_count; ++i) {
#if ORT_API_VERSION >= 12
    auto name = session_->GetOutputNameAllocated(i, allocator);
    output_names_storage_.emplace_back(name.get());
#else
    char* name = session_->GetOutputName(i, allocator);
    output_names_storage_.emplace_back(name);
    allocator.Free(name);
#endif
  }

  for (const auto& name : input_names_storage_) {
    input_names_.push_back(name.c_str());
  }
  for (const auto& name : output_names_storage_) {
    output_names_.push_back(name.c_str());
  }

  // Shape introspection is optional. Some exported ONNX files have incomplete
  // tensor shape metadata; some ORT/header mismatches can also throw here.
  // The runtime config is authoritative for this project: NCHW 1x3x64x64
  // (input_shape_ already holds that fallback). Only override C/H/W from valid
  // metadata; the batch dim is always forced to 1 since run() feeds one image.
  if (input_count > 0) {
    try {
      const auto info = session_->GetInputTypeInfo(0).GetTensorTypeAndShapeInfo();
      auto model_shape = info.GetShape();
      std::cerr << "[VISION_INIT] ONNX input shape metadata path=" << path
                << " shape=" << shapeToString(model_shape) << std::endl;

      if (model_shape.size() == 4) {
        const auto c = dimOrDefault(model_shape[1], 3);
        const auto h = dimOrDefault(model_shape[2], options_.input_height);
        const auto w = dimOrDefault(model_shape[3], options_.input_width);

        if (c > 0 && c <= 4 &&
            h > 0 && h <= 4096 &&
            w > 0 && w <= 4096) {
          input_shape_ = {1, c, h, w};
          options_.input_height = static_cast<int>(h);
          options_.input_width = static_cast<int>(w);
        }
      }
    } catch (const std::exception& e) {
      std::cerr << "[VISION_INIT] ONNX input shape introspection failed path=" << path
                << " error=" << e.what() << std::endl;
      // Keep config fallback: 1x3xHxW.
    } catch (...) {
      std::cerr << "[VISION_INIT] ONNX input shape introspection failed path=" << path
                << " error=unknown" << std::endl;
      // Keep config fallback: 1x3xHxW.
    }
  }

  std::cerr << "[VISION_INIT] ONNX runtime input path=" << path
            << " shape=" << shapeToString(input_shape_)
            << " resize=" << options_.input_width << "x" << options_.input_height
            << " inputs=" << input_count << " outputs=" << output_count << std::endl;
}

std::vector<float> OnnxRunner::preprocess(const cv::Mat& bgr) const
{
  if (bgr.empty()) {
    return {};
  }

  cv::Mat resized;
  cv::resize(bgr, resized, cv::Size(options_.input_width, options_.input_height), 0.0, 0.0, cv::INTER_LINEAR);
  if (options_.bgr_to_rgb) {
    cv::cvtColor(resized, resized, cv::COLOR_BGR2RGB);
  }
  resized.convertTo(resized, CV_32FC3, options_.normalize_01 ? 1.0 / 255.0 : 1.0);

  std::vector<cv::Mat> channels;
  cv::split(resized, channels);
  if (options_.normalize_mean_std && channels.size() == 3) {
    for (std::size_t i = 0; i < channels.size(); ++i) {
      const float stdev = std::abs(options_.stdev[i]) > 1e-6f ? options_.stdev[i] : 1.0f;
      channels[i] = (channels[i] - options_.mean[i]) / stdev;
    }
  }

  std::vector<float> tensor;
  tensor.reserve(static_cast<std::size_t>(options_.input_width) * options_.input_height * 3u);
  for (const auto& channel : channels) {
    tensor.insert(tensor.end(), reinterpret_cast<const float*>(channel.datastart),
                  reinterpret_cast<const float*>(channel.dataend));
  }
  return tensor;
}

std::vector<float> OnnxRunner::run(const cv::Mat& bgr)
{
  if (!session_) {
    return {};
  }

  if (input_names_.empty() || output_names_.empty() || input_shape_.empty()) {
    return {};
  }

  std::vector<float> input = preprocess(bgr);
  if (input.empty()) {
    return {};
  }

  // The tensor element count must match the declared NCHW shape exactly, or
  // ORT reads out of bounds. Guard against a preprocess/shape mismatch (e.g. a
  // grayscale model paired with a 3-channel preprocess).
  std::size_t expected = 1;
  for (const std::int64_t d : input_shape_) {
    if (d <= 0) {
      return {};
    }
    expected *= static_cast<std::size_t>(d);
  }
  if (input.size() != expected) {
    std::cerr << "[VISION_RUN] input size " << input.size() << " != expected " << expected
              << " for declared shape; skipping inference" << std::endl;
    return {};
  }

  try {
    Ort::MemoryInfo memory_info = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
    Ort::Value input_tensor = Ort::Value::CreateTensor<float>(
      memory_info,
      input.data(),
      input.size(),
      input_shape_.data(),
      input_shape_.size());

    auto outputs = session_->Run(Ort::RunOptions{nullptr},
                                 input_names_.data(),
                                 &input_tensor,
                                 1,
                                 output_names_.data(),
                                 output_names_.size());

    std::vector<float> result;
    for (auto& output : outputs) {
      if (!output.IsTensor()) {
        continue;
      }
      auto info = output.GetTensorTypeAndShapeInfo();
      const auto count = info.GetElementCount();
      const float* data = output.GetTensorData<float>();
      if (data == nullptr || count == 0) {
        continue;
      }
      result.insert(result.end(), data, data + count);
    }
    return result;
  } catch (const std::exception& e) {
    std::cerr << "[VISION_RUN] inference failed: " << e.what() << std::endl;
    return {};
  } catch (...) {
    std::cerr << "[VISION_RUN] inference failed: unknown error" << std::endl;
    return {};
  }
}

}  // namespace ros2_vision
