// Standalone parity test: C++ TargetMaskRF vs the Python-exported RTrees masks.
// Build (no ROS needed):
//   g++ -std=c++17 -I include test/test_target_mask_rf.cpp src/target_mask_rf.cpp \
//       $(pkg-config --cflags --libs opencv4) -o /tmp/test_target_mask_rf
//   /tmp/test_target_mask_rf <models_dir> <fixtures_dir>

#include <cstdio>
#include <fstream>
#include <string>
#include <vector>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include "ros2_vision/target_mask_rf.hpp"

namespace {

float maskIou(const cv::Mat& a, const cv::Mat& b)
{
  cv::Mat ab;
  cv::Mat aa;
  cv::Mat bb;
  cv::bitwise_and(a, b, ab);
  cv::bitwise_or(a, b, aa);
  const double inter = cv::countNonZero(ab);
  const double uni = cv::countNonZero(aa);
  (void)bb;
  return uni > 0 ? static_cast<float>(inter / uni) : 1.0f;
}

// Minimal extraction of "image" filenames from expected.json (no JSON dep).
std::vector<std::string> readImageNames(const std::string& json_path)
{
  std::vector<std::string> names;
  std::ifstream in(json_path);
  std::string content((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
  const std::string key = "\"image\":";
  std::size_t pos = 0;
  while ((pos = content.find(key, pos)) != std::string::npos) {
    const std::size_t q1 = content.find('"', pos + key.size());
    const std::size_t q2 = content.find('"', q1 + 1);
    if (q1 == std::string::npos || q2 == std::string::npos) {
      break;
    }
    names.push_back(content.substr(q1 + 1, q2 - q1 - 1));
    pos = q2 + 1;
  }
  return names;
}

}  // namespace

int main(int argc, char** argv)
{
  const std::string models_dir = argc > 1 ? argv[1] : "../../../models";
  const std::string fixtures_dir = argc > 2 ? argv[2] : "test/fixtures";

  ros2_vision::TargetMaskRF rf;
  if (!rf.load(models_dir + "/target_mask_rf.yml", models_dir + "/target_mask_features.yml")) {
    std::fprintf(stderr, "[FAIL] could not load target_mask_rf.yml from %s\n", models_dir.c_str());
    return 1;
  }
  std::printf("[PASS] loaded RTrees (input %dx%d)\n", rf.inputWidth(), rf.inputHeight());

  const auto names = readImageNames(fixtures_dir + "/expected.json");
  if (names.empty()) {
    std::fprintf(stderr, "[FAIL] no fixtures in %s/expected.json\n", fixtures_dir.c_str());
    return 1;
  }

  int passed = 0;
  int failed = 0;
  for (const auto& name : names) {
    const cv::Mat bgr = cv::imread(fixtures_dir + "/" + name, cv::IMREAD_COLOR);
    const std::string py_name = name.substr(0, name.size() - 4) + "_pymask.png";
    const cv::Mat py_mask = cv::imread(fixtures_dir + "/" + py_name, cv::IMREAD_GRAYSCALE);
    if (bgr.empty() || py_mask.empty()) {
      std::fprintf(stderr, "[FAIL] missing fixture %s\n", name.c_str());
      ++failed;
      continue;
    }
    float conf = 0.0f;
    const cv::Mat cpp_mask = rf.predictMask(bgr, conf);
    cv::Mat py_bin;
    cv::threshold(py_mask, py_bin, 127, 255, cv::THRESH_BINARY);
    const float iou = maskIou(cpp_mask, py_bin);
    const bool ok = iou >= 0.98f && cv::countNonZero(cpp_mask) > 0;
    std::printf("[%s] %-22s C++-vs-Py mask IoU=%.4f area=%d conf=%.3f\n",
                ok ? "PASS" : "FAIL", name.c_str(), iou, cv::countNonZero(cpp_mask), conf);
    ok ? ++passed : ++failed;
  }

  std::printf("\n%d/%d mask-parity checks passed\n", passed, passed + failed);
  return failed == 0 ? 0 : 1;
}
