#include "ros2_vision/victim_detector.hpp"

#include <algorithm>
#include <array>
#include <cmath>

namespace ros2_vision {
namespace {

const std::array<std::string, 5> kVictimClasses{{"H", "U", "S", "none", "fake"}};

float sigmoid(float x)
{
  return 1.0f / (1.0f + std::exp(-x));
}

std::vector<float> softmax(const std::vector<float>& values)
{
  if (values.empty()) {
    return {};
  }
  const float max_value = *std::max_element(values.begin(), values.end());
  std::vector<float> probabilities;
  probabilities.reserve(values.size());
  float sum = 0.0f;
  for (float value : values) {
    const float e = std::exp(value - max_value);
    probabilities.push_back(e);
    sum += e;
  }
  if (sum <= 0.0f || !std::isfinite(sum)) {
    return values;
  }
  for (float& value : probabilities) {
    value /= sum;
  }
  return probabilities;
}

}  // namespace

VictimDetector::VictimDetector(std::shared_ptr<OnnxRunner> bbox_runner,
                               std::shared_ptr<OnnxRunner> cls_runner,
                               Config config)
  : bbox_runner_(std::move(bbox_runner)),
    cls_runner_(std::move(cls_runner)),
    config_(config)
{
}

VictimResult VictimDetector::detect(const cv::Mat& bgr)
{
  VictimResult result;
  if (bgr.empty()) {
    result.reject_reason = "empty_frame";
    return result;
  }
  const bool bbox_ok = bbox_runner_ && bbox_runner_->valid();
  const bool cls_ok = cls_runner_ && cls_runner_->valid();
  if (!bbox_ok || !cls_ok) {
    result.reject_reason = "runner_unavailable";
    return result;
  }

  // 1) Localize: ONNX bbox regression in image space.
  const auto bbox_output = bbox_runner_->run(bgr);
  result.bbox = decodeBbox(bbox_output, bgr.size());
  if (result.bbox.area() <= 0) {
    result.reject_reason = "bbox_invalid";
    return result;
  }

  // 2) Clamp the predicted box to image bounds before cropping.
  const cv::Rect image_rect(0, 0, bgr.cols, bgr.rows);
  result.bbox &= image_rect;
  if (result.bbox.width <= 0 || result.bbox.height <= 0) {
    result.reject_reason = "crop_out_of_bounds";
    return result;
  }
  result.bbox_valid = true;

  // 3) Robust crop: clamped rect is guaranteed inside the image, but guard the
  // resulting Mat anyway before handing it to the classifier.
  const cv::Rect crop_rect = paddedCropRect(result.bbox, bgr.size());
  if (crop_rect.width <= 0 || crop_rect.height <= 0) {
    result.reject_reason = "crop_invalid";
    return result;
  }
  cv::Mat crop = bgr(crop_rect).clone();
  if (crop.empty() || crop.cols <= 0 || crop.rows <= 0) {
    result.reject_reason = "crop_invalid";
    return result;
  }
  result.crop_valid = true;

  // 4) Classify. victim_cls is trained on full frames; the tight bbox crop is
  // out-of-distribution and collapses the classifier, so classify the whole frame
  // by default and keep the bbox only for the center/localization.
  const cv::Mat& cls_input = config_.classify_full_frame ? bgr : crop;
  const auto cls_output = cls_runner_->run(cls_input);
  auto [class_name, confidence] = decodeClass(cls_output);
  result.class_name = class_name;
  result.confidence = confidence;

  if (class_name == "none") {
    result.reject_reason = "victim_class_none";
    return result;
  }
  if (class_name == "fake") {
    result.reject_reason =
      confidence >= config_.fake_min_confidence ? "victim_fake" : "victim_fake_low_confidence";
    if (config_.reject_fake || confidence < config_.fake_min_confidence) {
      return result;
    }
  }
  if (confidence < config_.min_confidence) {
    result.reject_reason = "victim_low_confidence";
    return result;
  }

  result.valid = true;
  result.reject_reason = "none";
  result.center_x = result.bbox.x + result.bbox.width * 0.5f;
  result.center_y = result.bbox.y + result.bbox.height * 0.5f;
  return result;
}

cv::Rect VictimDetector::decodeBbox(const std::vector<float>& output, const cv::Size& size) const
{
  if (output.size() < 4 || size.width <= 0 || size.height <= 0) {
    return {};
  }

  float x0 = output[0];
  float y0 = output[1];
  float x1 = output[2];
  float y1 = output[3];

  const bool normalized =
    std::fabs(x0) <= 1.5f && std::fabs(y0) <= 1.5f &&
    std::fabs(x1) <= 1.5f && std::fabs(y1) <= 1.5f;
  if (normalized) {
    x0 *= size.width;
    x1 *= size.width;
    y0 *= size.height;
    y1 *= size.height;
  }

  if (x1 < x0) {
    std::swap(x0, x1);
  }
  if (y1 < y0) {
    std::swap(y0, y1);
  }

  const int left = static_cast<int>(std::floor(x0));
  const int top = static_cast<int>(std::floor(y0));
  const int right = static_cast<int>(std::ceil(x1));
  const int bottom = static_cast<int>(std::ceil(y1));
  return cv::Rect(left, top, right - left, bottom - top);
}

cv::Rect VictimDetector::paddedCropRect(const cv::Rect& bbox, const cv::Size& size) const
{
  if (bbox.width <= 0 || bbox.height <= 0 || size.width <= 0 || size.height <= 0) {
    return {};
  }
  const float pad = std::max(0.0f, config_.crop_padding);
  const float px = bbox.width * pad;
  const float py = bbox.height * pad;
  const int left = static_cast<int>(std::floor(bbox.x - px));
  const int top = static_cast<int>(std::floor(bbox.y - py));
  const int right = static_cast<int>(std::ceil(bbox.x + bbox.width + px));
  const int bottom = static_cast<int>(std::ceil(bbox.y + bbox.height + py));
  return cv::Rect(left, top, right - left, bottom - top) & cv::Rect(0, 0, size.width, size.height);
}

std::pair<std::string, float> VictimDetector::decodeClass(const std::vector<float>& output) const
{
  if (output.empty()) {
    return {"none", 0.0f};
  }

  auto values = output;
  if (values.size() > 1) {
    values = softmax(values);
  }
  const auto max_it = std::max_element(values.begin(), values.end());
  const std::size_t idx = static_cast<std::size_t>(std::distance(values.begin(), max_it));
  float confidence = *max_it;
  if (confidence < 0.0f || confidence > 1.0f) {
    confidence = sigmoid(confidence);
  }

  const std::string class_name = idx < kVictimClasses.size() ? kVictimClasses[idx] : "none";
  return {class_name, confidence};
}

}  // namespace ros2_vision
