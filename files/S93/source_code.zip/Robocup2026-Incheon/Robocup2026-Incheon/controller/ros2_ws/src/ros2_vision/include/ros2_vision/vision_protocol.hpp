#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <vector>

#include <opencv2/core.hpp>

namespace ros2_vision {

constexpr std::uint32_t kVisionFrameMagic = 0x4d524656u;
constexpr std::uint16_t kVisionFrameVersion = 1;
constexpr std::uint32_t kMaxImageBytes = 16u * 1024u * 1024u;
constexpr std::uint32_t kMaxLidarCount = 4096u;

enum VisionImageEncoding : std::uint8_t {
  kEncodingBgr8 = 1,
  kEncodingBgra8 = 2,
  kEncodingJpeg = 3,
};

#pragma pack(push, 1)
struct VisionFrameHeader {
  std::uint32_t magic;
  std::uint16_t version;
  std::uint16_t header_size;

  std::uint64_t seq;
  double stamp_s;

  std::uint8_t camera_id;
  std::uint8_t encoding;
  std::uint16_t width;
  std::uint16_t height;

  float camera_hfov_rad;
  float camera_vfov_rad;
  float camera_yaw_offset_rad;

  float robot_x;
  float robot_y;
  float robot_yaw;

  std::int32_t tile_x;
  std::int32_t tile_y;

  std::uint16_t lidar_count;
  float lidar_angle_min;
  float lidar_angle_increment;
  float lidar_range_min;
  float lidar_range_max;

  std::uint32_t image_bytes;
};
#pragma pack(pop)

static_assert(sizeof(VisionFrameHeader) == 84, "VisionFrameHeader wire size changed");

struct VisionFrame {
  std::uint64_t seq = 0;
  double stamp_s = 0.0;

  int camera_id = 0;
  std::string camera_name;

  cv::Mat bgr;

  std::vector<float> scan;
  float lidar_angle_min = -3.14159265f;
  float lidar_angle_increment = 0.0f;
  float lidar_range_min = 0.01f;
  float lidar_range_max = 1.0f;

  float camera_hfov_rad = 1.0f;
  float camera_vfov_rad = 1.0f;
  float camera_yaw_offset_rad = 0.0f;

  float robot_x = 0.0f;
  float robot_y = 0.0f;
  float robot_yaw = 0.0f;

  int tile_x = 0;
  int tile_y = 0;
};

struct TargetResult {
  bool valid = false;
  float confidence = 0.0f;
  float center_x = 0.0f;
  float center_y = 0.0f;
  cv::Rect visible_bbox;

  // Mask-first / radial fields (primary path).
  std::array<std::string, 5> colors{{"none", "none", "none", "none", "none"}};
  std::string pattern = "none";        // five color letters, e.g. "KRYGB" (debug)
  std::string class_name = "none";     // F/P/C/O derived from the ring sum
  int sum_value = 0;
  bool sum_valid = false;              // true when sum_value maps to F/P/C/O
  std::array<float, 5> ring_confidence{{0.0f, 0.0f, 0.0f, 0.0f, 0.0f}};
  float radial_coverage = 0.0f;
  float mask_confidence = 0.0f;
  int mask_area_px = 0;
  float distance = 0.0f;               // optional/debug

  // Legacy ellipse-fit fields (only populated by the legacy fallback detector).
  float radius_px = 0.0f;
  float major_radius_px = 0.0f;
  float minor_radius_px = 0.0f;
  float angle_deg = 0.0f;
  float fit_error = 0.0f;
};

struct VictimResult {
  bool valid = false;
  std::string class_name = "none";
  float confidence = 0.0f;
  cv::Rect bbox;
  float center_x = 0.0f;
  float center_y = 0.0f;
  // Exact reason the candidate failed, for explainability logging. One of:
  // bbox_invalid, crop_out_of_bounds, crop_invalid, victim_class_none,
  // victim_fake, victim_low_confidence, runner_unavailable, empty_frame.
  std::string reject_reason = "none";
  bool bbox_valid = false;
  bool crop_valid = false;
};

struct VisionDetection {
  std::uint64_t seq = 0;
  int camera_id = 0;
  std::string camera_name;
  int tile_x = 0;
  int tile_y = 0;
  std::string kind;
  std::string class_name;
  float confidence = 0.0f;
  float distance = 0.0f;
  float center_x = 0.0f;
  float center_y = 0.0f;
  cv::Rect bbox;
  std::string target_pattern = "none";  // 5 colors, debug/explainability only
  int target_sum = 0;
  float radial_coverage = 0.0f;
  float mask_confidence = 0.0f;
  float target_radius_px = 0.0f;
  float target_major_radius_px = 0.0f;
  float target_minor_radius_px = 0.0f;
  float target_angle_deg = 0.0f;
  float target_fit_error = 0.0f;
};

struct VisionDebugImage {
  std::string status = "rejected";      // classified or rejected
  std::string kind = "unknown";         // presence/type/target/victim
  std::string class_name = "none";
  std::string reason = "none";
  float confidence = 0.0f;
  float distance = 0.0f;
  cv::Rect bbox;
  float center_x = 0.0f;
  float center_y = 0.0f;
  std::string target_pattern = "none";
  int target_sum = 0;
  float radial_coverage = 0.0f;
  float mask_confidence = 0.0f;
  float lidar_xmin = 0.0f;
  float lidar_xmax = 0.0f;
  int valid_lidar_rays = 0;
  double inference_ms = 0.0;
};

inline std::string cameraName(int camera_id)
{
  return camera_id == 0 ? "left" : "right";
}

}  // namespace ros2_vision
