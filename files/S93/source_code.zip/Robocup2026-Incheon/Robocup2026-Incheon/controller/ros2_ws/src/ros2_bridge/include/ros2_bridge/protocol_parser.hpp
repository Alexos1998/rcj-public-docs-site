#pragma once

#include <optional>
#include <string>

namespace ros2_bridge
{

enum class ProtocolMessageType
{
  Time,
  Loc,
  Odom,
  Imu,
  Scan,
  Gps,
  Color,
  Hole,
  Vision,
  Camera,
  LegacyReachabilityRequest,
  Unknown
};

struct ProtocolMessage
{
  ProtocolMessageType type = ProtocolMessageType::Unknown;
  std::string type_name;
};

class ProtocolParser
{
public:
  std::optional<ProtocolMessage> parsePrefix(const std::string & line) const;

private:
  static bool startsWith(const std::string & value, const char * prefix);
};

const char * toString(ProtocolMessageType type);

}  // namespace ros2_bridge
