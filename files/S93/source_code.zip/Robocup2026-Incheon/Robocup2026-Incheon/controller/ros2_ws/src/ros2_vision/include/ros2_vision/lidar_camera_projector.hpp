#pragma once

#include <limits>
#include <vector>

namespace ros2_vision {

// Estimates the distance to a pixel interval by projecting it through the camera
// model onto the LiDAR scan. Uses the scan header (angle_min / angle_increment /
// range_min / range_max) explicitly -- it does NOT assume a fixed 360 deg scan.
class LidarCameraProjector {
public:
  struct Config {
    float robust_percentile = 20.0f;
    int window_extra_rays = 1;
    bool use_min_range = false;
  };

  struct CloseRunResult {
    bool pass = false;
    float distance = std::numeric_limits<float>::quiet_NaN();
    int valid_rays = 0;
    int close_rays = 0;
    int max_consecutive = 0;
  };

  LidarCameraProjector();
  explicit LidarCameraProjector(Config config);

  // Convert a robot-frame angle to a scan index using the scan header. Returns -1
  // when the angle falls outside a non-wrapping scan.
  int angleToScanIndex(double theta_robot,
                       int n,
                       double angle_min,
                       double angle_increment) const;

  // pixel x -> robot-frame angle: theta = yaw_offset + atan((x - cx) / fx),
  // fx = width / (2 tan(hfov/2)), cx = (width - 1) / 2.
  double pixelToRobotAngle(double x,
                           int image_width,
                           double hfov_rad,
                           double camera_yaw_offset_rad) const;

  // Robust distance over [xmin, xmax]. Filters non-finite ranges and ranges
  // outside [range_min, range_max]; returns NaN when no valid ray is found.
  float estimateDistanceForPixelInterval(const std::vector<float>& ranges,
                                         int image_width,
                                         float hfov_rad,
                                         float camera_yaw_offset_rad,
                                         float lidar_angle_min,
                                         float lidar_angle_increment,
                                         float lidar_range_min,
                                         float lidar_range_max,
                                         float xmin,
                                         float xmax,
                                         int* valid_rays_out = nullptr) const;

  // Acceptance check over a pixel interval. The detection passes only if at
  // least min_consecutive_rays adjacent LiDAR rays in that interval are within
  // max_close_range_m. This is stricter than the robust distance estimate and
  // prevents a single nearby wall sliver from validating a distant detection.
  CloseRunResult closeRunForPixelInterval(const std::vector<float>& ranges,
                                          int image_width,
                                          float hfov_rad,
                                          float camera_yaw_offset_rad,
                                          float lidar_angle_min,
                                          float lidar_angle_increment,
                                          float lidar_range_min,
                                          float lidar_range_max,
                                          float xmin,
                                          float xmax,
                                          float max_close_range_m,
                                          int min_consecutive_rays) const;

private:
  Config config_;
};

}  // namespace ros2_vision
