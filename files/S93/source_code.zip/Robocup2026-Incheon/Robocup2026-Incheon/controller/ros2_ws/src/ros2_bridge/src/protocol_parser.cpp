#include "ros2_bridge/protocol_parser.hpp"

namespace ros2_bridge
{

std::optional<ProtocolMessage> ProtocolParser::parsePrefix(const std::string & line) const
{
  if (startsWith(line, "TIME|")) {
    return ProtocolMessage{ProtocolMessageType::Time, "TIME"};
  }
  if (startsWith(line, "LOC|")) {
    return ProtocolMessage{ProtocolMessageType::Loc, "LOC"};
  }
  if (startsWith(line, "ODOM|")) {
    return ProtocolMessage{ProtocolMessageType::Odom, "ODOM"};
  }
  if (startsWith(line, "IMU|")) {
    return ProtocolMessage{ProtocolMessageType::Imu, "IMU"};
  }
  if (startsWith(line, "SCAN|")) {
    return ProtocolMessage{ProtocolMessageType::Scan, "SCAN"};
  }
  if (startsWith(line, "GPS|")) {
    return ProtocolMessage{ProtocolMessageType::Gps, "GPS"};
  }
  if (startsWith(line, "COLOR|")) {
    return ProtocolMessage{ProtocolMessageType::Color, "COLOR"};
  }
  if (startsWith(line, "HOLE|")) {
    return ProtocolMessage{ProtocolMessageType::Hole, "HOLE"};
  }
  if (startsWith(line, "VISION|")) {
    return ProtocolMessage{ProtocolMessageType::Vision, "VISION"};
  }
  if (startsWith(line, "CAM|")) {
    return ProtocolMessage{ProtocolMessageType::Camera, "CAM"};
  }
  if (startsWith(line, "LEGACY_REACHABILITY_REQUEST|")) {
    return ProtocolMessage{ProtocolMessageType::LegacyReachabilityRequest, "LEGACY_REACHABILITY_REQUEST"};
  }

  return std::nullopt;
}

bool ProtocolParser::startsWith(const std::string & value, const char * prefix)
{
  return value.rfind(prefix, 0) == 0;
}

const char * toString(ProtocolMessageType type)
{
  switch (type) {
    case ProtocolMessageType::Time:
      return "TIME";
    case ProtocolMessageType::Loc:
      return "LOC";
    case ProtocolMessageType::Odom:
      return "ODOM";
    case ProtocolMessageType::Imu:
      return "IMU";
    case ProtocolMessageType::Scan:
      return "SCAN";
    case ProtocolMessageType::Gps:
      return "GPS";
    case ProtocolMessageType::Color:
      return "COLOR";
    case ProtocolMessageType::Hole:
      return "HOLE";
    case ProtocolMessageType::Vision:
      return "VISION";
    case ProtocolMessageType::Camera:
      return "CAM";
    case ProtocolMessageType::LegacyReachabilityRequest:
      return "LEGACY_REACHABILITY_REQUEST";
    case ProtocolMessageType::Unknown:
      return "UNKNOWN";
  }

  return "UNKNOWN";
}

}  // namespace ros2_bridge
