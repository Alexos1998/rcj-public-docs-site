#include <memory>

#include "rclcpp/rclcpp.hpp"
#include "ros2_exploration/explorer_node.hpp"

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<ros2_exploration::ExplorerNode>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
