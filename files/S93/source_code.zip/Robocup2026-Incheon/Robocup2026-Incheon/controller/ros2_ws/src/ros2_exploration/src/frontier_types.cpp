#include "ros2_exploration/frontier_types.hpp"

namespace ros2_exploration
{

bool operator==(const GridIndex & lhs, const GridIndex & rhs)
{
  return lhs.x == rhs.x && lhs.y == rhs.y;
}

bool operator!=(const GridIndex & lhs, const GridIndex & rhs)
{
  return !(lhs == rhs);
}

std::size_t frontierSize(const Frontier & frontier)
{
  return frontier.cells.size();
}

bool frontierEmpty(const Frontier & frontier)
{
  return frontier.cells.empty();
}

}  // namespace ros2_exploration
