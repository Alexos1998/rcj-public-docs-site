#include "ros2_vision/target_radial_classifier.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <map>

#include <opencv2/imgproc.hpp>

namespace ros2_vision {
namespace {

constexpr int kNumRings = 5;
constexpr std::array<const char*, 5> kColorCodes{{"K", "R", "Y", "G", "B"}};

// Pure prototype colors in RGB (matches target_classification_radial.py).
const std::array<cv::Vec3f, 5> kPrototypesRGB{{
  cv::Vec3f(0, 0, 0),        // K
  cv::Vec3f(207, 0, 0),      // R
  cv::Vec3f(207, 207, 0),    // Y
  cv::Vec3f(0, 207, 0),      // G
  cv::Vec3f(0, 0, 207),      // B
}};

// Inner radial band per ring (fraction of R), away from ring borders.
const std::array<std::pair<float, float>, 5> kRingBands{{
  {0.04f, 0.16f}, {0.24f, 0.36f}, {0.44f, 0.56f}, {0.64f, 0.76f}, {0.84f, 0.96f},
}};

// Color value for the final sum.
const std::map<std::string, int> kColorValues{
  {"K", -2}, {"R", -1}, {"Y", 0}, {"G", 1}, {"B", 2}};

std::string classifyRGB(float r, float g, float b, int black_value_max)
{
  if (std::max({r, g, b}) <= static_cast<float>(black_value_max)) {
    return "K";
  }
  int best = 0;
  float best_dist = std::numeric_limits<float>::max();
  for (int c = 0; c < kNumRings; ++c) {
    const float dr = r - kPrototypesRGB[c][0];
    const float dg = g - kPrototypesRGB[c][1];
    const float db = b - kPrototypesRGB[c][2];
    const float dist = dr * dr + dg * dg + db * db;
    if (dist < best_dist) {
      best_dist = dist;
      best = c;
    }
  }
  return kColorCodes[best];
}

cv::Vec3f bilinearBGR(const cv::Mat& bgr, float x, float y)
{
  const int w = bgr.cols;
  const int h = bgr.rows;
  x = std::min(std::max(x, 0.0f), static_cast<float>(w - 1));
  y = std::min(std::max(y, 0.0f), static_cast<float>(h - 1));
  const int x0 = static_cast<int>(std::floor(x));
  const int y0 = static_cast<int>(std::floor(y));
  const int x1 = std::min(x0 + 1, w - 1);
  const int y1 = std::min(y0 + 1, h - 1);
  const float fx = x - x0;
  const float fy = y - y0;
  const cv::Vec3b p00 = bgr.at<cv::Vec3b>(y0, x0);
  const cv::Vec3b p01 = bgr.at<cv::Vec3b>(y0, x1);
  const cv::Vec3b p10 = bgr.at<cv::Vec3b>(y1, x0);
  const cv::Vec3b p11 = bgr.at<cv::Vec3b>(y1, x1);
  cv::Vec3f out;
  for (int c = 0; c < 3; ++c) {
    out[c] = p00[c] * (1 - fx) * (1 - fy) + p01[c] * fx * (1 - fy) +
             p10[c] * (1 - fx) * fy + p11[c] * fx * fy;
  }
  return out;
}

// Sum of per-ring majority fractions for a candidate center (used by refinement).
float ringConsistency(const cv::Mat& bgr, const cv::Mat& mask, cv::Point2f center,
                      const TargetRadialConfig& cfg)
{
  std::vector<float> rays;
  std::vector<unsigned char> valid;
  extractRadialContour(mask, center, cfg.n_rays, rays, valid);
  int n_valid = 0;
  for (auto v : valid) {
    n_valid += v ? 1 : 0;
  }
  if (n_valid < 3) {
    return -1.0f;
  }
  const RadialTargetResult res = classifyTargetRadial(bgr, mask, center, rays, valid, cfg);
  float score = 0.0f;
  for (int j = 0; j < kNumRings; ++j) {
    score += res.ring_confidence[j];
  }
  return score;
}

cv::Point2f gridRefine(const cv::Mat& bgr, const cv::Mat& mask, cv::Point2f c0,
                       float radius, float step, const TargetRadialConfig& cfg)
{
  cv::Point2f best = c0;
  float best_score = -1.0f;
  for (float dy = -radius; dy <= radius + 1e-6f; dy += step) {
    for (float dx = -radius; dx <= radius + 1e-6f; dx += step) {
      const cv::Point2f cand(c0.x + dx, c0.y + dy);
      const float score = ringConsistency(bgr, mask, cand, cfg);
      if (score > best_score) {
        best_score = score;
        best = cand;
      }
    }
  }
  return best;
}

}  // namespace

cv::Mat cleanLargestComponent(const cv::Mat& mask)
{
  cv::Mat bin;
  if (mask.type() != CV_8U) {
    mask.convertTo(bin, CV_8U);
  } else {
    bin = mask;
  }
  cv::Mat binary = (bin > 0);
  cv::Mat labels;
  cv::Mat stats;
  cv::Mat centroids;
  const int count = cv::connectedComponentsWithStats(binary, labels, stats, centroids, 8);
  if (count <= 1) {
    return cv::Mat::zeros(mask.size(), CV_8U);
  }
  int largest = 1;
  int largest_area = stats.at<int>(1, cv::CC_STAT_AREA);
  for (int i = 2; i < count; ++i) {
    const int area = stats.at<int>(i, cv::CC_STAT_AREA);
    if (area > largest_area) {
      largest_area = area;
      largest = i;
    }
  }
  return (labels == largest);
}

cv::Point2f estimateTargetCenter(const cv::Mat& mask, const cv::Mat& bgr,
                                 const TargetRadialConfig& cfg)
{
  const int w = mask.cols;
  const int h = mask.rows;
  cv::Point2f fallback((w - 1) * 0.5f, (h - 1) * 0.5f);
  if (cv::countNonZero(mask) == 0) {
    return fallback;
  }

  // Outer contour, drop image-border points (the clip cut), then circle-fit.
  std::vector<std::vector<cv::Point>> contours;
  cv::findContours(mask.clone(), contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_NONE);
  std::vector<cv::Point2f> pts;
  if (!contours.empty()) {
    const auto& largest = *std::max_element(
      contours.begin(), contours.end(),
      [](const auto& a, const auto& b) { return cv::contourArea(a) < cv::contourArea(b); });
    std::vector<cv::Point2f> all;
    std::vector<cv::Point2f> interior;
    for (const auto& p : largest) {
      all.emplace_back(static_cast<float>(p.x), static_cast<float>(p.y));
      if (p.x > 0 && p.x < w - 1 && p.y > 0 && p.y < h - 1) {
        interior.emplace_back(static_cast<float>(p.x), static_cast<float>(p.y));
      }
    }
    pts = (all.size() >= 8 && interior.size() >= 5) ? interior : all;
  }

  cv::Point2f center = fallback;
  bool have_center = false;
  if (pts.size() >= 3) {
    cv::Mat a(static_cast<int>(pts.size()), 3, CV_64F);
    cv::Mat rhs(static_cast<int>(pts.size()), 1, CV_64F);
    for (int i = 0; i < static_cast<int>(pts.size()); ++i) {
      a.at<double>(i, 0) = 2.0 * pts[i].x;
      a.at<double>(i, 1) = 2.0 * pts[i].y;
      a.at<double>(i, 2) = 1.0;
      rhs.at<double>(i, 0) = static_cast<double>(pts[i].x) * pts[i].x +
                             static_cast<double>(pts[i].y) * pts[i].y;
    }
    cv::Mat sol;
    if (cv::solve(a, rhs, sol, cv::DECOMP_SVD)) {
      const double cx = sol.at<double>(0, 0);
      const double cy = sol.at<double>(1, 0);
      if (std::isfinite(cx) && std::isfinite(cy) && cx >= -w && cx <= 2 * w &&
          cy >= -h && cy <= 2 * h) {
        center = cv::Point2f(static_cast<float>(cx), static_cast<float>(cy));
        have_center = true;
      }
    }
  }

  if (!have_center) {
    cv::Mat dist;
    cv::distanceTransform(mask, dist, cv::DIST_L2, 5);
    double min_v = 0.0;
    double max_v = 0.0;
    cv::minMaxLoc(dist, &min_v, &max_v);
    if (max_v > 0.0) {
      cv::Mat plateau = dist >= max_v * 0.9;
      const cv::Moments m = cv::moments(plateau, true);
      if (m.m00 > 0) {
        center = cv::Point2f(static_cast<float>(m.m10 / m.m00), static_cast<float>(m.m01 / m.m00));
        have_center = true;
      }
    }
  }

  if (!have_center) {
    const cv::Moments m = cv::moments(mask, true);
    if (m.m00 > 0) {
      center = cv::Point2f(static_cast<float>(m.m10 / m.m00), static_cast<float>(m.m01 / m.m00));
    }
  }

  if (cfg.refine_center && !bgr.empty()) {
    center = gridRefine(bgr, mask, center, cfg.refine_coarse_radius, cfg.refine_coarse_step, cfg);
    center = gridRefine(bgr, mask, center, cfg.refine_fine_radius, cfg.refine_fine_step, cfg);
  }
  return center;
}

void extractRadialContour(const cv::Mat& mask, cv::Point2f center, int n_rays,
                          std::vector<float>& rays, std::vector<unsigned char>& ray_valid)
{
  const int w = mask.cols;
  const int h = mask.rows;
  const float cx = center.x;
  const float cy = center.y;
  const float step = 0.5f;
  const float min_radius = 2.0f;
  const float max_reach = std::sqrt(static_cast<float>(w * w + h * h));

  rays.assign(n_rays, 0.0f);
  ray_valid.assign(n_rays, 0);
  for (int i = 0; i < n_rays; ++i) {
    const float theta = static_cast<float>(i) * (2.0f * static_cast<float>(CV_PI) / n_rays);
    const float dx = std::cos(theta);
    const float dy = std::sin(theta);
    float last_inside = 0.0f;
    bool found_bg = false;
    for (float r = step; r <= max_reach; r += step) {
      const int xi = static_cast<int>(std::lround(cx + dx * r));
      const int yi = static_cast<int>(std::lround(cy + dy * r));
      if (xi < 0 || yi < 0 || xi >= w || yi >= h) {
        break;  // left the image before hitting background -> clipped
      }
      if (mask.at<unsigned char>(yi, xi) > 0) {
        last_inside = r;
      } else {
        found_bg = true;
        break;
      }
    }
    rays[i] = last_inside;
    ray_valid[i] = (found_bg && last_inside >= min_radius) ? 1 : 0;
  }
}

std::string classifyPixelColor(const cv::Vec3b& bgr_pixel, int black_value_max)
{
  return classifyRGB(static_cast<float>(bgr_pixel[2]), static_cast<float>(bgr_pixel[1]),
                     static_cast<float>(bgr_pixel[0]), black_value_max);
}

RadialTargetResult classifyTargetRadial(const cv::Mat& bgr, const cv::Mat& mask,
                                        cv::Point2f center, const std::vector<float>& rays,
                                        const std::vector<unsigned char>& ray_valid,
                                        const TargetRadialConfig& cfg)
{
  RadialTargetResult result;
  result.center = center;
  result.visible_bbox = cv::boundingRect(mask);
  result.mask_area_px = cv::countNonZero(mask);

  const int w = bgr.cols;
  const int h = bgr.rows;
  const int n_rays = static_cast<int>(rays.size());
  int valid_count = 0;
  for (auto v : ray_valid) {
    valid_count += v ? 1 : 0;
  }
  result.radial_coverage = n_rays > 0 ? static_cast<float>(valid_count) / n_rays : 0.0f;

  std::string pattern;
  for (int j = 0; j < kNumRings; ++j) {
    const auto band = kRingBands[j];
    int attempted = 0;
    std::map<std::string, int> votes;
    int total = 0;
    for (int i = 0; i < n_rays; ++i) {
      if (!ray_valid[i]) {
        continue;
      }
      const float theta = static_cast<float>(i) * (2.0f * static_cast<float>(CV_PI) / n_rays);
      const float ct = std::cos(theta);
      const float st = std::sin(theta);
      for (int s = 0; s < cfg.samples_per_ring; ++s) {
        const float rho = cfg.samples_per_ring > 1
                            ? band.first + (band.second - band.first) * s / (cfg.samples_per_ring - 1)
                            : 0.5f * (band.first + band.second);
        const float x = center.x + rho * rays[i] * ct;
        const float y = center.y + rho * rays[i] * st;
        ++attempted;
        if (x < 0 || x > w - 1 || y < 0 || y > h - 1) {
          continue;
        }
        const cv::Vec3f px = bilinearBGR(bgr, x, y);
        const std::string color = classifyRGB(px[2], px[1], px[0], cfg.black_value_max);
        votes[color]++;
        ++total;
      }
    }
    const float coverage = attempted > 0 ? static_cast<float>(total) / attempted : 0.0f;
    if (total == 0 || coverage < cfg.min_ring_coverage) {
      result.colors[j] = "?";
      result.ring_confidence[j] = 0.0f;
      pattern += "?";
      continue;
    }
    std::string best = "?";
    int best_count = 0;
    for (const auto& kv : votes) {
      if (kv.second > best_count) {
        best_count = kv.second;
        best = kv.first;
      }
    }
    result.colors[j] = best;
    result.ring_confidence[j] = static_cast<float>(best_count) / total;
    pattern += best;
  }

  result.pattern = pattern;
  result.valid = pattern.find('?') == std::string::npos;

  const TargetSumDecode sum = decodeTargetSum(result.colors);
  result.sum_valid = sum.valid;
  result.sum_value = sum.sum_value;
  result.class_name = sum.class_name;
  return result;
}

TargetSumDecode decodeTargetSum(const std::array<std::string, 5>& colors)
{
  TargetSumDecode out;
  int sum = 0;
  for (const auto& color : colors) {
    const auto it = kColorValues.find(color);
    if (it == kColorValues.end()) {
      return out;  // invalid (contains '?' or unknown)
    }
    sum += it->second;
  }
  out.sum_value = sum;
  switch (sum) {
    case 0: out.class_name = "F"; out.valid = true; break;
    case 1: out.class_name = "P"; out.valid = true; break;
    case 2: out.class_name = "C"; out.valid = true; break;
    case 3: out.class_name = "O"; out.valid = true; break;
    default: out.valid = false; break;
  }
  return out;
}

RadialTargetResult decodeTargetFromMask(const cv::Mat& bgr, const cv::Mat& mask,
                                        const TargetRadialConfig& cfg)
{
  const cv::Mat clean = cleanLargestComponent(mask);
  if (cv::countNonZero(clean) == 0) {
    return RadialTargetResult{};
  }
  const cv::Point2f center = estimateTargetCenter(clean, bgr, cfg);
  std::vector<float> rays;
  std::vector<unsigned char> valid;
  extractRadialContour(clean, center, cfg.n_rays, rays, valid);
  return classifyTargetRadial(bgr, clean, center, rays, valid, cfg);
}

}  // namespace ros2_vision
