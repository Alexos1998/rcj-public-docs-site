// Lightweight self-contained tests for SubmissionMatrixBuilder.
//
// Avoids a hard gtest dependency: a tiny CHECK macro accumulates failures and
// main() returns non-zero if any check fails (so ctest reports the failure).

#include "ros2_mapper/submission_matrix_builder.hpp"
#include "ros2_mapper/tile_map.hpp"

#include <rclcpp/time.hpp>

#include <cstdio>
#include <string>

namespace
{

int g_failures = 0;
int g_checks = 0;

#define CHECK(cond) \
  do { \
    ++g_checks; \
    if (!(cond)) { \
      ++g_failures; \
      std::printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); \
    } \
  } while (0)

#define CHECK_EQ(a, b) \
  do { \
    ++g_checks; \
    const std::string va_ = (a); \
    const std::string vb_ = (b); \
    if (va_ != vb_) { \
      ++g_failures; \
      std::printf("FAIL %s:%d: \"%s\" != \"%s\"\n", __FILE__, __LINE__, \
        va_.c_str(), vb_.c_str()); \
    } \
  } while (0)

using namespace ros2_mapper;

geometry_msgs::msg::Point pt(double x, double y)
{
  geometry_msgs::msg::Point p;
  p.x = x;
  p.y = y;
  p.z = 0.0;
  return p;
}

// Make a single-tile map at (0,0) so the matrix is a 5x5 block.
TileRecord & singleTile(TileMap & map)
{
  const rclcpp::Time t(0, 0, RCL_ROS_TIME);
  return map.getOrCreateTile(TileCoord{0, 0}, pt(0.0, 0.0), t);
}

const std::string & at(const SubmissionMatrixResult & r, int row, int col)
{
  static const std::string empty;
  if (row < 0 || col < 0 ||
    row >= static_cast<int>(r.cells.size()) ||
    col >= static_cast<int>(r.cells[row].size()))
  {
    return empty;
  }
  return r.cells[row][col];
}

void testEmptyTile()
{
  TileMap map;
  singleTile(map);

  SubmissionMatrixBuilder builder;
  const auto result = builder.build(map);

  CHECK(result.cells.size() == 5);
  for (int rr = 0; rr < 5; ++rr) {
    for (int cc = 0; cc < 5; ++cc) {
      CHECK_EQ(at(result, rr, cc), "0");
    }
  }
}

void testStartTile()
{
  TileMap map;
  auto & rec = singleTile(map);
  rec.is_start = true;

  SubmissionMatrixBuilder builder;
  const auto result = builder.build(map);

  CHECK_EQ(at(result, 1, 1), "5");
  CHECK_EQ(at(result, 1, 3), "5");
  CHECK_EQ(at(result, 3, 1), "5");
  CHECK_EQ(at(result, 3, 3), "5");
}

void testArea4CheckpointRemainsWildcard()
{
  TileMap map;
  auto & rec = singleTile(map);
  rec.area = TileArea::Area4;
  rec.floor_color = FloorColorClass::SilverCheckpoint;
  rec.is_checkpoint = true;
  rec.kind = TileKind::Checkpoint;

  SubmissionMatrixBuilder builder;
  const auto result = builder.build(map);

  CHECK_EQ(at(result, 1, 1), "*");
  CHECK(floorColorBypassesCenterMask(FloorColorClass::SilverCheckpoint));
  CHECK(floorColorBypassesCenterMask(FloorColorClass::BlackHoleBorder));
  CHECK(!floorColorBypassesCenterMask(FloorColorClass::Normal));
}

void testFullNorthWall()
{
  TileMap map;
  auto & rec = singleTile(map);
  rec.walls.north = WallState::Wall;

  SubmissionMatrixBuilder builder;
  const auto result = builder.build(map);

  for (int cc = 0; cc <= 4; ++cc) {
    CHECK_EQ(at(result, 0, cc), "1");
  }
  // Bottom row stays open.
  for (int cc = 0; cc <= 4; ++cc) {
    CHECK_EQ(at(result, 4, cc), "0");
  }
}

SubmissionResolvedTileModels modelsFor(TileMap & map, SubmissionTileModel model)
{
  const rclcpp::Time t(0, 0, RCL_ROS_TIME);
  map.getOrCreateTile(model.coord, pt(0.0, 0.0), t);
  SubmissionResolvedTileModels models;
  models[model.coord] = std::move(model);
  return models;
}

void addArea4Model(TileMap & map, SubmissionResolvedTileModels & models, int x, int y)
{
  const rclcpp::Time t(0, 0, RCL_ROS_TIME);
  map.getOrCreateTile(TileCoord{x, y}, pt(0.0, 0.0), t);

  SubmissionTileModel model;
  model.coord = TileCoord{x, y};
  model.area = TileArea::Area4;
  model.area4_wildcard = true;
  models[model.coord] = model;
}

void testInternalSubtileWall()
{
  TileMap map;
  SubmissionTileModel model;
  model.coord = TileCoord{0, 0};
  model.area = TileArea::Area2;
  model.subtiles[static_cast<int>(SubmissionSubtile::NW)].wall_east = true;
  const auto models = modelsFor(map, model);

  SubmissionMatrixBuilder builder;
  const auto result = builder.build(map, models);

  // NW east internal edge cell.
  CHECK_EQ(at(result, 1, 2), "1");
  // Its endpoint vertices.
  CHECK_EQ(at(result, 0, 2), "1");
  CHECK_EQ(at(result, 2, 2), "1");
  // Unrelated outer edges remain open.
  CHECK_EQ(at(result, 1, 0), "0");
  CHECK_EQ(at(result, 0, 1), "0");
}

void testArea3Curve()
{
  TileMap map;
  SubmissionTileModel model;
  model.coord = TileCoord{0, 0};
  model.area = TileArea::Area3;
  // NW subtile, curve_dir 3 -> NE corner -> connects North + East edges.
  model.subtiles[static_cast<int>(SubmissionSubtile::NW)].curve_dir = 3;
  const auto models = modelsFor(map, model);

  SubmissionMatrixBuilder builder;
  const auto result = builder.build(map, models);

  CHECK_EQ(at(result, 0, 1), "1");  // NW north edge
  CHECK_EQ(at(result, 1, 2), "1");  // NW east edge
  CHECK_EQ(at(result, 0, 2), "0");  // curve-only corner vertex stays 0
}

void testCurveRightAngleException()
{
  TileMap map;
  SubmissionTileModel model;
  model.coord = TileCoord{0, 0};
  model.area = TileArea::Area3;
  // NW curve rounds the NE corner -> would suppress vertex (0,2).
  model.subtiles[static_cast<int>(SubmissionSubtile::NW)].curve_dir = 3;
  // NE subtile has a straight west wall that also reaches vertex (0,2).
  model.subtiles[static_cast<int>(SubmissionSubtile::NE)].wall_west = true;
  const auto models = modelsFor(map, model);

  SubmissionMatrixBuilder builder;
  const auto result = builder.build(map, models);

  // Straight support wins: shared vertex becomes 1.
  CHECK_EQ(at(result, 0, 2), "1");
}

void testArea4Wildcard()
{
  TileMap map;
  SubmissionTileModel model;
  model.coord = TileCoord{0, 0};
  model.area = TileArea::Area4;
  model.area4_wildcard = true;
  const auto models = modelsFor(map, model);

  SubmissionMatrixBuilder builder;
  const auto result = builder.build(map, models);

  for (int rr = 0; rr < 5; ++rr) {
    for (int cc = 0; cc < 5; ++cc) {
      CHECK_EQ(at(result, rr, cc), "*");
    }
  }
}

void testZerosEnclosedByArea4BecomeWildcard()
{
  TileMap map;
  SubmissionResolvedTileModels models;

  for (int y = -1; y <= 1; ++y) {
    for (int x = -1; x <= 1; ++x) {
      if (x == 0 && y == 0) {
        continue;
      }
      addArea4Model(map, models, x, y);
    }
  }

  SubmissionMatrixBuilder builder;
  const auto result = builder.build(map, models);

  // The absent center tile would leave a 0 island at local center (5..7,5..7)
  // unless area-4 enclosure flood fill promotes it to wildcard.
  CHECK_EQ(at(result, 6, 6), "*");
}

SubmissionTileModel makeModel(int x, int y, bool wildcard, bool gateway)
{
  SubmissionTileModel model;
  model.coord = TileCoord{x, y};
  if (wildcard) {
    model.area = TileArea::Area4;
    model.area4_wildcard = true;
  }
  model.area4_gateway = gateway;
  return model;
}

void testArea4FloodFillFromGateways()
{
  SubmissionResolvedTileModels models;

  // Entrance at (0,0), exit at (4,0), one known Area 4 tile in between; the
  // observed soft gap tiles (2,0) and (3,0) must be converted, nothing outside
  // the bounding box of the evidence.
  models[TileCoord{0, 0}] = makeModel(0, 0, false, true);
  models[TileCoord{1, 0}] = makeModel(1, 0, true, false);
  models[TileCoord{2, 0}] = makeModel(2, 0, false, false);
  models[TileCoord{3, 0}] = makeModel(3, 0, false, false);
  models[TileCoord{4, 0}] = makeModel(4, 0, false, true);

  const int filled = SubmissionMatrixBuilder::applyArea4FloodFill(models);

  CHECK(filled == 2);
  CHECK(models.count(TileCoord{2, 0}) == 1);
  CHECK(models.count(TileCoord{3, 0}) == 1);
  CHECK((models[TileCoord{2, 0}].area4_wildcard));
  CHECK((models[TileCoord{3, 0}].area4_wildcard));
  CHECK(models.count(TileCoord{2, 1}) == 0);
  CHECK(models.count(TileCoord{5, 0}) == 0);
}

void testArea4FloodFillNeedsBothGateways()
{
  SubmissionResolvedTileModels models;
  models[TileCoord{0, 0}] = makeModel(0, 0, false, true);
  models[TileCoord{1, 0}] = makeModel(1, 0, true, false);

  CHECK(SubmissionMatrixBuilder::applyArea4FloodFill(models) == 0);
  CHECK(models.count(TileCoord{2, 0}) == 0);
}

void testArea4FloodFillBlockedByKnownTiles()
{
  SubmissionResolvedTileModels models;
  models[TileCoord{0, 0}] = makeModel(0, 0, false, true);
  models[TileCoord{1, 0}] = makeModel(1, 0, false, false);
  models[TileCoord{4, 0}] = makeModel(4, 0, false, true);
  models[TileCoord{3, 0}] = makeModel(3, 0, false, false);

  // A known non-Area4 tile in the middle blocks the fill from crossing it,
  // and is never overwritten.
  SubmissionTileModel known = makeModel(2, 0, false, false);
  known.area = TileArea::Area1;
  known.area_uncertain = false;
  models[TileCoord{2, 0}] = known;

  const int filled = SubmissionMatrixBuilder::applyArea4FloodFill(models);

  CHECK(filled == 2);  // (1,0) and (3,0)
  CHECK((models[TileCoord{2, 0}].area == TileArea::Area1));
  CHECK((!models[TileCoord{2, 0}].area4_wildcard));
}

void testArea4FloodFillDoesNotCreateBoundingBoxTiles()
{
  SubmissionResolvedTileModels models;
  models[TileCoord{0, 0}] = makeModel(0, 0, false, true);
  models[TileCoord{1, 0}] = makeModel(1, 0, true, false);
  models[TileCoord{4, 0}] = makeModel(4, 0, false, true);

  const int filled = SubmissionMatrixBuilder::applyArea4FloodFill(models);

  CHECK(filled == 0);
  CHECK(models.count(TileCoord{2, 0}) == 0);
  CHECK(models.count(TileCoord{3, 0}) == 0);
}

void testArea4FloodFillConvertsSoftTiles()
{
  SubmissionResolvedTileModels models;
  models[TileCoord{0, 0}] = makeModel(0, 0, false, true);
  models[TileCoord{4, 0}] = makeModel(4, 0, false, true);

  // Soft tile inside the room: unvisited, uncertain area, wall geometry only
  // (wall-vote record or explored-scan output). Must become '*', walls gone.
  SubmissionTileModel soft_entry = makeModel(1, 0, false, false);
  models[TileCoord{1, 0}] = soft_entry;

  SubmissionTileModel soft = makeModel(2, 0, false, false);
  soft.subtiles[0].wall_north = true;
  models[TileCoord{2, 0}] = soft;

  // Committed (visited) tile inside the room must survive untouched.
  SubmissionTileModel visited = makeModel(3, 0, false, false);
  visited.committed = true;
  models[TileCoord{3, 0}] = visited;

  const int filled = SubmissionMatrixBuilder::applyArea4FloodFill(models);

  CHECK(filled == 2);  // converted (1,0) + (2,0); (3,0) blocked
  CHECK((models[TileCoord{2, 0}].area4_wildcard));
  CHECK((!models[TileCoord{2, 0}].subtiles[0].wall_north));
  CHECK((!models[TileCoord{3, 0}].area4_wildcard));
}

void testArea4ObservedConnectedPromotion()
{
  SubmissionResolvedTileModels models;
  models[TileCoord{0, 0}] = makeModel(0, 0, true, false);

  // Observed by the geometry model, not visited, no semantic commitment. This
  // used to remain a regular unknown model and could leave a hole in Area 4.
  SubmissionTileModel observed = makeModel(1, 0, false, false);
  observed.subtiles[0].wall_north = true;
  models[TileCoord{1, 0}] = observed;

  // A real transition touching A4 keeps its passage token and is not swallowed.
  SubmissionTileModel gateway = makeModel(2, 0, false, true);
  gateway.subtiles[0].value = "r";
  models[TileCoord{2, 0}] = gateway;

  // A committed non-A4 tile is part of the visitation layer and blocks the
  // observed-mask expansion.
  SubmissionTileModel visited = makeModel(0, 1, false, false);
  visited.committed = true;
  models[TileCoord{0, 1}] = visited;

  const int promoted =
    SubmissionMatrixBuilder::promoteConnectedArea4ObservedTiles(models);
  const auto mask = SubmissionMatrixBuilder::buildArea4Mask(models);

  CHECK(promoted == 1);
  CHECK((SubmissionMatrixBuilder::isArea4SubmissionCell(models, TileCoord{1, 0})));
  CHECK((models[TileCoord{1, 0}].area == TileArea::Area4));
  CHECK((!models[TileCoord{1, 0}].subtiles[0].wall_north));
  CHECK(mask.count(TileCoord{0, 0}) == 1);
  CHECK(mask.count(TileCoord{1, 0}) == 1);
  CHECK(mask.count(TileCoord{2, 0}) == 0);
  CHECK((!SubmissionMatrixBuilder::isArea4SubmissionCell(models, TileCoord{0, 1})));
}

void testArea4ObservedPromotionBlockedByWall()
{
  SubmissionResolvedTileModels models;
  models[TileCoord{0, 0}] = makeModel(0, 0, true, false);

  SubmissionTileModel outside = makeModel(1, 0, false, false);
  outside.subtiles[static_cast<int>(SubmissionSubtile::NW)].wall_west = true;
  outside.subtiles[static_cast<int>(SubmissionSubtile::SW)].wall_west = true;
  models[TileCoord{1, 0}] = outside;

  const int promoted =
    SubmissionMatrixBuilder::promoteConnectedArea4ObservedTiles(models);

  CHECK(promoted == 0);
  CHECK((!SubmissionMatrixBuilder::isArea4SubmissionCell(models, TileCoord{1, 0})));
}

void testArea4ObservedDiagonalRequiresOpenCornerPath()
{
  SubmissionResolvedTileModels models;
  models[TileCoord{0, 0}] = makeModel(0, 0, true, false);
  models[TileCoord{1, 1}] = makeModel(1, 1, false, false);

  CHECK(SubmissionMatrixBuilder::promoteConnectedArea4ObservedTiles(models) == 0);
  CHECK((!SubmissionMatrixBuilder::isArea4SubmissionCell(models, TileCoord{1, 1})));

  models[TileCoord{1, 0}] = makeModel(1, 0, false, false);

  CHECK(SubmissionMatrixBuilder::promoteConnectedArea4ObservedTiles(models) == 2);
  CHECK((SubmissionMatrixBuilder::isArea4SubmissionCell(models, TileCoord{1, 0})));
  CHECK((SubmissionMatrixBuilder::isArea4SubmissionCell(models, TileCoord{1, 1})));
}

void testArea4MaskOverlayRunsAfterGeometry()
{
  TileMap map;
  SubmissionTileModel model;
  model.coord = TileCoord{0, 0};
  model.area = TileArea::Area4;
  model.area4_wildcard = true;
  model.subtiles[0].wall_north = true;
  const auto models = modelsFor(map, model);

  SubmissionMatrixBuilder builder;
  auto result = builder.build(map, models);

  for (int rr = 0; rr < 5; ++rr) {
    for (int cc = 0; cc < 5; ++cc) {
      CHECK_EQ(at(result, rr, cc), "*");
    }
  }
}

void testResolvedModelsExtendBounds()
{
  TileMap map;
  auto models = modelsFor(map, makeModel(0, 0, false, false));

  // Model tile with no backing record (explored scan / flood fill output)
  // must widen the matrix instead of being clipped away.
  models[TileCoord{1, 0}] = makeModel(1, 0, true, false);

  SubmissionMatrixBuilder builder;
  const auto result = builder.build(map, models);

  CHECK(result.tile_width == 2);
  CHECK(static_cast<int>(result.cells[0].size()) == 9);
  CHECK_EQ(at(result, 1, 5), "*");
}

void testTransitionCodes()
{
  struct Case
  {
    TileArea a;
    TileArea b;
    std::string code;
  };

  const Case cases[] = {
    {TileArea::Area1, TileArea::Area2, "b"},
    {TileArea::Area1, TileArea::Area3, "y"},
    {TileArea::Area1, TileArea::Area4, "g"},
    {TileArea::Area2, TileArea::Area3, "p"},
    {TileArea::Area2, TileArea::Area4, "o"},
    {TileArea::Area3, TileArea::Area4, "r"},
    {TileArea::Area1, TileArea::Area4, "g"},
    {TileArea::Area1, TileArea::Area3, "y"},
    {TileArea::Area2, TileArea::Area4, "o"},
  };

  for (const auto & c : cases) {
    TileMap map;
    auto & rec = singleTile(map);
    rec.is_transition = true;
    rec.transition = TransitionInfo{c.a, c.b};

    SubmissionMatrixBuilder builder;
    const auto result = builder.build(map);
    CHECK_EQ(at(result, 1, 1), c.code);
  }
}

void testTransitionCodesFromFloorColor()
{
  struct Case
  {
    FloorColorClass color;
    std::string code;
  };

  const Case cases[] = {
    {FloorColorClass::BlueArea1To2, "b"},
    {FloorColorClass::YellowArea1To3, "y"},
    {FloorColorClass::GreenArea1To4, "g"},
    {FloorColorClass::PurpleArea2To3, "p"},
    {FloorColorClass::OrangeArea2To4, "o"},
    {FloorColorClass::RedArea3To4, "r"},
  };

  for (const auto & c : cases) {
    TileMap map;
    auto & rec = singleTile(map);
    rec.is_transition = true;
    rec.floor_color = c.color;

    SubmissionMatrixBuilder builder;
    const auto result = builder.build(map);
    CHECK_EQ(at(result, 1, 1), c.code);
  }
}

void testVictimsNotWrittenToMatrix()
{
  TileMap map;
  SubmissionTileModel model;
  model.coord = TileCoord{0, 0};
  model.area = TileArea::Area1;
  // Victims on the NW-north wall, plus a wall there.
  model.subtiles[static_cast<int>(SubmissionSubtile::NW)].wall_north = true;
  const auto victim = [](const std::string & code) {
    SubmissionVictimMark mark;
    mark.subtile = SubmissionSubtile::NW;
    mark.wall = WallDirection::North;
    mark.code = code;
    return mark;
  };
  model.victims.push_back(victim("S"));
  model.victims.push_back(victim("H"));
  const auto models = modelsFor(map, model);

  SubmissionMatrixBuilder builder;
  const auto result = builder.build(map, models);

  // The submission format carries no victim codes: the wall cell keeps its
  // structural token.
  CHECK_EQ(at(result, 0, 1), "1");
}

}  // namespace

int main()
{
  testEmptyTile();
  testStartTile();
  testArea4CheckpointRemainsWildcard();
  testFullNorthWall();
  testInternalSubtileWall();
  testArea3Curve();
  testCurveRightAngleException();
  testArea4Wildcard();
  testZerosEnclosedByArea4BecomeWildcard();
  testArea4FloodFillFromGateways();
  testArea4FloodFillNeedsBothGateways();
  testArea4FloodFillBlockedByKnownTiles();
  testArea4FloodFillDoesNotCreateBoundingBoxTiles();
  testArea4FloodFillConvertsSoftTiles();
  testArea4ObservedConnectedPromotion();
  testArea4ObservedPromotionBlockedByWall();
  testArea4ObservedDiagonalRequiresOpenCornerPath();
  testArea4MaskOverlayRunsAfterGeometry();
  testResolvedModelsExtendBounds();
  testTransitionCodes();
  testTransitionCodesFromFloorColor();
  testVictimsNotWrittenToMatrix();

  std::printf("ran %d checks, %d failures\n", g_checks, g_failures);
  return g_failures == 0 ? 0 : 1;
}
