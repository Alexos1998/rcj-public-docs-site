#include "ros2_vision/target_detector.hpp"

#include <algorithm>
#include <utility>

namespace ros2_vision {

TargetDetector::TargetDetector(TargetDetectorConfig config)
  : config_(std::move(config))
{
  if (config_.mode == "rf_radial" && !config_.rf_model_path.empty()) {
    mask_rf_ = std::make_shared<TargetMaskRF>();
    if (!mask_rf_->load(config_.rf_model_path, config_.rf_feature_config_path)) {
      load_error_ = "failed to load target_mask_rf.yml: " + config_.rf_model_path;
      mask_rf_.reset();
    }
  }
}

TargetResult TargetDetector::detect(const cv::Mat& bgr) const
{
  if (config_.mode == "rf_radial" && mask_rf_ && mask_rf_->loaded()) {
    return detectRfRadial(bgr);
  }
  if (config_.mode == "rf_radial" && !config_.allow_legacy_fallback) {
    return TargetResult{};  // RF unavailable and fallback disabled -> no detection
  }
  return detectLegacy(bgr);
}

TargetResult TargetDetector::detectRfRadial(const cv::Mat& bgr) const
{
  TargetResult result;
  float mask_confidence = 0.0f;
  const cv::Mat mask = mask_rf_->predictMask(bgr, mask_confidence);
  if (mask.empty()) {
    return result;
  }

  const cv::Mat clean = cleanLargestComponent(mask);
  const int area = cv::countNonZero(clean);
  if (area < config_.min_mask_area_px) {
    result.mask_area_px = area;
    result.mask_confidence = mask_confidence;
    return result;
  }

  const RadialTargetResult radial = decodeTargetFromMask(bgr, clean, config_.radial);
  result.center_x = radial.center.x;
  result.center_y = radial.center.y;
  result.visible_bbox = radial.visible_bbox;
  result.colors = radial.colors;
  result.pattern = radial.pattern;
  result.class_name = radial.sum_valid ? radial.class_name : "none";
  result.sum_value = radial.sum_value;
  result.sum_valid = radial.sum_valid;
  result.ring_confidence = radial.ring_confidence;
  result.radial_coverage = radial.radial_coverage;
  result.mask_confidence = mask_confidence;
  result.mask_area_px = radial.mask_area_px;

  float min_ring_conf = 1.0f;
  for (float c : radial.ring_confidence) {
    min_ring_conf = std::min(min_ring_conf, c);
  }
  // "valid" here means the rings were all read AND map to a real class. The
  // pipeline still applies coverage / ring-confidence / distance gates with
  // explicit reject reasons.
  result.valid = radial.valid && radial.sum_valid;
  result.confidence = result.valid
                        ? std::min(mask_confidence, min_ring_conf)
                        : 0.0f;
  return result;
}

TargetResult TargetDetector::detectLegacy(const cv::Mat& bgr) const
{
  TargetResult result;
  const auto legacy_result = target_legacy::detectTargetLegacy(bgr, config_.legacy);
  result.valid = legacy_result.valid;
  result.confidence = legacy_result.confidence;
  result.center_x = legacy_result.center_x;
  result.center_y = legacy_result.center_y;
  result.radius_px = legacy_result.radius_px;
  result.major_radius_px = legacy_result.major_radius_px;
  result.minor_radius_px = legacy_result.minor_radius_px;
  result.angle_deg = legacy_result.angle_deg;
  result.fit_error = legacy_result.fit_error;
  result.colors = legacy_result.colors;
  result.pattern = legacy_result.pattern;
  result.visible_bbox = legacy_result.visible_bbox;

  // Derive F/P/C/O for the legacy path too, when the colors map to a valid sum.
  const TargetSumDecode sum = decodeTargetSum(legacy_result.colors);
  result.sum_valid = sum.valid;
  result.sum_value = sum.sum_value;
  result.class_name = sum.valid ? sum.class_name : "none";
  if (result.visible_bbox.area() > 0) {
    result.mask_area_px = result.visible_bbox.area();
  }
  return result;
}

}  // namespace ros2_vision
