#pragma once

#include <cstddef>
#include <cstdint>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <vector>

#include "geometry_msgs/msg/point.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "nav_msgs/msg/occupancy_grid.hpp"
#include "nav_msgs/msg/odometry.hpp"
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/header.hpp"
#include "std_msgs/msg/string.hpp"
#include "tf2_ros/buffer.h"
#include "tf2_ros/transform_listener.h"
#include "visualization_msgs/msg/marker_array.hpp"

#include "ros2_exploration/blacklist.hpp"
#include "ros2_exploration/frontier_detector.hpp"
#include "ros2_exploration/frontier_scorer.hpp"
#include "ros2_exploration/nav2_goal_manager.hpp"
#include "ros2_exploration/semantic_layer.hpp"

namespace ros2_exploration
{

struct ExplorerParams
{
  std::string map_topic{"/map"};
  std::string global_costmap_topic{"/global_costmap/costmap"};
  std::string local_costmap_topic{"/local_costmap/costmap"};
  std::string odom_topic{"/odometry/filtered"};
  std::string debug_topic{"/ros2_exploration/debug"};
  std::string frontiers_topic{"/ros2_exploration/frontiers"};
  std::string graph_topic{"/ros2_exploration/tile_graph"};
  std::string selected_goal_topic{"/ros2_exploration/selected_goal"};
  std::string navigate_to_pose_action{"/navigate_to_pose"};
  std::string global_frame{"map"};
  std::string robot_frame{"base_link"};
  double transform_timeout_s{0.20};
  bool autostart{true};

  double replan_period_s{0.75};
  double goal_timeout_s{8.0};
  double stuck_timeout_s{6.0};
  double post_goal_settle_s{0.50};
  double map_geometry_settle_s{1.0};

  int frontier_occ_threshold{65};
  int min_frontier_size_cells{3};
  double candidate_min_goal_distance_m{0.10};
  double min_goal_distance_m{0.10};
  double max_goal_distance_m{1.25};
  double duplicate_goal_radius_m{0.08};

  double information_gain_weight{3.0};
  double distance_cost_weight{1.0};
  double size_gain_weight{0.25};
  double heading_change_cost_weight{0.15};
  double recent_goal_penalty{4.0};
  double blacklist_penalty{100.0};

  double blacklist_radius_m{0.12};
  double blacklist_duration_s{20.0};
  int blacklist_max_entries{80};

  double stuck_min_progress_m{0.03};
  double stuck_check_period_s{1.0};

  bool publish_markers{true};
  bool publish_graph_markers{true};
  bool log_selected_goal{true};
  bool semantic_scoring_enabled{false};

  int graph_subdivision{2};
  double graph_motion_step_m{0.06};
  double graph_priority_tile_size_m{0.12};
  bool graph_allow_diagonal{true};
  // RViz graph visualization can become the bottleneck when every free node and
  // edge in the whole costmap is published.  The default below keeps RViz useful
  // for race/debug by showing only the current planned graph path, its centers,
  // the robot point, and the goal point.  Set debug.graph_visualization_mode to
  // "full" when the complete lattice is needed for offline debugging.
  std::string graph_visualization_mode{"active_path"};
  double graph_marker_min_period_s{0.20};
};

struct ExplorerSnapshot
{
  nav_msgs::msg::OccupancyGrid::SharedPtr map;
  nav_msgs::msg::OccupancyGrid::SharedPtr global_costmap;
  nav_msgs::msg::OccupancyGrid::SharedPtr local_costmap;
  nav_msgs::msg::Odometry::SharedPtr odom;
  bool map_geometry_initialized{false};
  rclcpp::Time last_map_geometry_change_time{0, 0, RCL_ROS_TIME};
};

struct ScoredFrontierCandidate
{
  Frontier frontier;
  geometry_msgs::msg::PoseStamped goal;
  FrontierScoreBreakdown score;
  bool near_recent_goal{false};
};

struct CandidateBuildStats
{
  std::size_t rejected_by_blacklist{0};
  std::size_t rejected_by_distance{0};
  std::size_t rejected_by_duplicate{0};
  std::size_t rejected_invalid{0};
};

struct CandidateBuildResult
{
  std::vector<ScoredFrontierCandidate> candidates;
  CandidateBuildStats stats;
};

struct GoalRuntimeStatus
{
  bool active{false};
  double age_s{0.0};
  geometry_msgs::msg::Point active_goal;
  double active_goal_score{0.0};
  double stuck_low_progress_s{0.0};
  double last_stuck_delta_m{0.0};
  std::string last_failure_reason{"none"};
  std::string last_nav2_result{"none"};
};

struct RecentGoal
{
  geometry_msgs::msg::Point point;
  rclcpp::Time stamp;
  double score{0.0};
  std::uint64_t sequence{0};
  std::string result{"sent"};
};

class ExplorerNode : public rclcpp::Node
{
public:
  explicit ExplorerNode(const rclcpp::NodeOptions & options = rclcpp::NodeOptions());

private:
  void declareParameters();
  void readParameters();
  void logStartupParameters() const;
  void configureHelpers();

  void onMap(nav_msgs::msg::OccupancyGrid::SharedPtr msg);
  void onGlobalCostmap(nav_msgs::msg::OccupancyGrid::SharedPtr msg);
  void onLocalCostmap(nav_msgs::msg::OccupancyGrid::SharedPtr msg);
  void onOdom(nav_msgs::msg::Odometry::SharedPtr msg);
  void onTimer();

  ExplorerSnapshot snapshotMessages() const;
  std::optional<geometry_msgs::msg::Pose> lookupRobotPoseInMapFrame(
    const nav_msgs::msg::OccupancyGrid & map,
    std::string & error_message);
  bool mapGeometryStable(const ExplorerSnapshot & snapshot, const rclcpp::Time & now) const;
  double mapGeometryAgeSeconds(const ExplorerSnapshot & snapshot, const rclcpp::Time & now) const;
  std::optional<std::string> validateGoalPoint(
    const geometry_msgs::msg::Point & goal_point,
    const ExplorerSnapshot & snapshot,
    const geometry_msgs::msg::Pose & current_pose) const;
  CandidateBuildResult buildCandidateSet(
    const std::vector<Frontier> & frontiers,
    const ExplorerSnapshot & snapshot,
    const geometry_msgs::msg::Pose & current_pose,
    const rclcpp::Time & now);
  std::optional<ScoredFrontierCandidate> selectBestCandidate(
    const std::vector<ScoredFrontierCandidate> & candidates) const;

  bool goalActive() const;
  bool withinPostGoalSettle() const;
  GoalRuntimeStatus goalStatus() const;
  bool handleActiveGoalWatchdogs(const geometry_msgs::msg::Pose & current_pose);
  void cancelActiveGoalForReason(const std::string & reason);

  void sendSelectedGoal(
    const ScoredFrontierCandidate & selected,
    const geometry_msgs::msg::Pose & current_pose);
  void handleGoalResponse(
    std::uint64_t goal_sequence,
    Nav2GoalManager::GoalHandle::SharedPtr goal_handle);
  void handleGoalResult(
    std::uint64_t goal_sequence,
    const Nav2GoalManager::GoalHandle::WrappedResult & result);
  void blacklistGoal(const geometry_msgs::msg::PoseStamped & goal, const std::string & reason);

  void rememberRecentGoal(
    const geometry_msgs::msg::Point & point,
    double score,
    std::uint64_t sequence,
    const rclcpp::Time & now);
  void updateRecentGoalResult(std::uint64_t sequence, const std::string & result);
  void pruneRecentGoals(const rclcpp::Time & now);
  std::optional<RecentGoal> findRecentGoalNear(
    const geometry_msgs::msg::Point & point,
    const rclcpp::Time & now) const;

  std::string makeWaitingDebugStatus(
    const ExplorerSnapshot & snapshot,
    bool nav2_ready,
    const std::string & reason) const;
  std::string makeDebugStatus(
    const ExplorerSnapshot & snapshot,
    const std::vector<Frontier> & frontiers,
    const CandidateBuildResult & candidate_result,
    const std::optional<ScoredFrontierCandidate> & selected,
    const GridIndex & robot_map_cell,
    bool nav2_ready) const;
  void publishGoalEventDebug(const std::string & event);
  void publishFrontierMarkers(
    const std_msgs::msg::Header & map_header,
    const std::vector<ScoredFrontierCandidate> & candidates,
    const std::optional<ScoredFrontierCandidate> & selected);
  void publishGraphMarkers(
    const ExplorerSnapshot & snapshot,
    const geometry_msgs::msg::Pose & current_pose,
    const std::optional<geometry_msgs::msg::Point> & goal_point);
  void publishDeleteAllMarkers(const std_msgs::msg::Header & map_header);
  void publishDeleteAllGraphMarkers(const std_msgs::msg::Header & header);

  ExplorerParams params_;

  rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr map_sub_;
  rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr global_costmap_sub_;
  rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr local_costmap_sub_;
  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr debug_pub_;
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr frontiers_pub_;
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr graph_pub_;
  rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr selected_goal_pub_;
  rclcpp::TimerBase::SharedPtr timer_;

  mutable std::mutex messages_mutex_;
  nav_msgs::msg::OccupancyGrid::SharedPtr latest_map_;
  nav_msgs::msg::OccupancyGrid::SharedPtr latest_global_costmap_;
  nav_msgs::msg::OccupancyGrid::SharedPtr latest_local_costmap_;
  nav_msgs::msg::Odometry::SharedPtr latest_odom_;

  bool map_geometry_initialized_{false};
  uint32_t last_map_width_{0};
  uint32_t last_map_height_{0};
  double last_map_resolution_{0.0};
  double last_map_origin_x_{0.0};
  double last_map_origin_y_{0.0};
  rclcpp::Time last_map_geometry_change_time_{0, 0, RCL_ROS_TIME};

  tf2_ros::Buffer tf_buffer_;
  tf2_ros::TransformListener tf_listener_;

  SemanticLayer semantic_layer_;
  FrontierScorer frontier_scorer_;
  Blacklist blacklist_;
  std::unique_ptr<Nav2GoalManager> nav2_goal_manager_;

  mutable std::mutex goal_mutex_;
  bool goal_active_{false};
  bool has_last_goal_complete_time_{false};
  rclcpp::Time last_goal_complete_time_{0, 0, RCL_ROS_TIME};
  std::string last_nav2_result_{"none"};
  std::string last_failure_reason_{"none"};

  std::uint64_t current_goal_sequence_{0};
  std::uint64_t recovery_cancel_sequence_{0};
  std::string recovery_cancel_reason_;
  geometry_msgs::msg::PoseStamped active_goal_;
  rclcpp::Time active_goal_sent_time_{0, 0, RCL_ROS_TIME};
  double active_goal_score_{0.0};
  rclcpp::Time last_stuck_check_time_{0, 0, RCL_ROS_TIME};
  geometry_msgs::msg::Pose last_stuck_check_pose_;
  double stuck_low_progress_s_{0.0};
  double last_stuck_delta_m_{0.0};

  std::vector<RecentGoal> recent_goals_;
  rclcpp::Time last_graph_marker_publish_time_{0, 0, RCL_ROS_TIME};
};

}  // namespace ros2_exploration
