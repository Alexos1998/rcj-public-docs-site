#include <rclcpp/rclcpp.hpp>

#include "ros2_vision/vision_node.hpp"

int main(int argc, char** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<ros2_vision::VisionNode>());
  rclcpp::shutdown();
  return 0;
}
