import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, LogInfo, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def _runtime_params_list(context):
    """Return [runtime_params_file] when it points at an existing file, else []."""
    path = LaunchConfiguration("runtime_params_file").perform(context)
    return [path] if path and os.path.exists(path) else []


def launch_setup(context, *args, **kwargs):
    del args, kwargs

    pkg_share = get_package_share_directory("ros2_navigation")
    params_file = os.path.join(pkg_share, "config", "nav2_params.yaml")
    behavior_tree_xml = os.path.join(
        pkg_share,
        "behavior_trees",
        "simple_compute_follow.xml",
    )

    nav_mode = LaunchConfiguration("nav_mode")
    use_sim_time = LaunchConfiguration("use_sim_time")
    autostart = LaunchConfiguration("autostart")

    # Runtime override file is appended LAST so it wins over the base YAML.
    runtime_params = _runtime_params_list(context)

    lifecycle_nodes = [
        "controller_server",
        "planner_server",
        "behavior_server",
        "bt_navigator",
        "waypoint_follower",
    ]

    return [
        LogInfo(
            msg=[
                "ROBOT_EVENT node=nav2 event=navigation_started ",
                "planner_plugin=GridBased controller_plugin=FollowPath ",
                "cmd_vel_topic=/cmd_vel global_costmap_topic=/global_costmap/costmap ",
                "local_costmap_topic=/local_costmap/costmap behavior_tree=",
                behavior_tree_xml,
                " use_sim_time=",
                use_sim_time,
                " autostart=",
                autostart,
            ]
        ),
        LogInfo(
            msg=[
                "nav_mode='",
                nav_mode,
                "' is deprecated and ignored; ros2_navigation uses the map/SLAM Nav2 bringup.",
            ]
        ),
        Node(
            package="nav2_controller",
            executable="controller_server",
            name="controller_server",
            output="screen",
            parameters=[params_file, {"use_sim_time": use_sim_time}, *runtime_params],
            remappings=[("cmd_vel", "/cmd_vel")],
        ),
        Node(
            package="nav2_planner",
            executable="planner_server",
            name="planner_server",
            output="screen",
            parameters=[params_file, {"use_sim_time": use_sim_time}, *runtime_params],
        ),
        Node(
            package="nav2_behaviors",
            executable="behavior_server",
            name="behavior_server",
            output="screen",
            parameters=[params_file, {"use_sim_time": use_sim_time}, *runtime_params],
        ),
        Node(
            package="nav2_bt_navigator",
            executable="bt_navigator",
            name="bt_navigator",
            output="screen",
            parameters=[
                params_file,
                {
                    "use_sim_time": use_sim_time,
                    "default_nav_to_pose_bt_xml": behavior_tree_xml,
                },
                *runtime_params,
            ],
        ),
        Node(
            package="nav2_waypoint_follower",
            executable="waypoint_follower",
            name="waypoint_follower",
            output="screen",
            parameters=[params_file, {"use_sim_time": use_sim_time}, *runtime_params],
        ),
        Node(
            package="nav2_lifecycle_manager",
            executable="lifecycle_manager",
            name="lifecycle_manager_navigation",
            output="screen",
            parameters=[
                params_file,
                {
                    "use_sim_time": use_sim_time,
                    "autostart": ParameterValue(autostart, value_type=bool),
                    "node_names": lifecycle_nodes,
                },
                *runtime_params,
            ],
        ),
    ]


def generate_launch_description():
    return LaunchDescription(
        [
            DeclareLaunchArgument(
                "nav_mode",
                default_value="slam",
                description="Deprecated compatibility argument; ignored by ros2_navigation.",
            ),
            DeclareLaunchArgument(
                "use_sim_time",
                default_value="false",
                description="Use simulation clock.",
            ),
            DeclareLaunchArgument(
                "autostart",
                default_value="true",
                description="Automatically configure and activate Nav2 lifecycle nodes.",
            ),
            DeclareLaunchArgument(
                "runtime_params_file",
                default_value="",
                description="Optional runtime YAML override loaded last (timing/use_sim_time).",
            ),
            OpaqueFunction(function=launch_setup),
        ]
    )
