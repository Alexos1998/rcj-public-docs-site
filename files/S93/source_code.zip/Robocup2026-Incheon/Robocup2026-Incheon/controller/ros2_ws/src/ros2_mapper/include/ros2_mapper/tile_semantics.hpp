#ifndef ROS2_MAPPER__TILE_SEMANTICS_HPP_
#define ROS2_MAPPER__TILE_SEMANTICS_HPP_

#include "ros2_mapper/slam_map_sampler.hpp"

#include <rclcpp/time.hpp>

namespace ros2_mapper
{

enum class TileArea
{
  Unknown,
  Area1,
  Area2,
  Area3,
  Area4
};

enum class TileKind
{
  Unknown,
  Normal,
  Start,
  Checkpoint,
  Swamp,
  Hole,
  Transition,
  Area4Generic
};

enum class FloorColorClass
{
  Unknown,
  Normal,
  BlackHoleBorder,
  SilverCheckpoint,
  BrownSwamp,
  BlueArea1To2,
  YellowArea1To3,
  GreenArea1To4,
  PurpleArea2To3,
  OrangeArea2To4,
  RedArea3To4
};

enum class HazardState
{
  None,
  Suspected,
  Confirmed,
  Rejected
};

enum class HazardType
{
  Unknown,
  BlackHole,
  Swamp,
  Checkpoint,
  ColoredArea
};

enum class HazardSource
{
  Unknown,
  FloorColor,
  ControllerEvent,
  MapperFusion
};

enum class HazardEdge
{
  Unknown,
  North,
  East,
  South,
  West
};

enum class WallState
{
  Unknown,
  Open,
  Wall,
  VirtualWall
};

enum class WallDirection
{
  North,
  East,
  South,
  West
};

enum class RobotSide
{
  Front,
  Right,
  Back,
  Left
};

struct TransitionInfo
{
  TileArea area_a = TileArea::Unknown;
  TileArea area_b = TileArea::Unknown;
};

struct EdgeWalls
{
  WallState north = WallState::Unknown;
  WallState east = WallState::Unknown;
  WallState south = WallState::Unknown;
  WallState west = WallState::Unknown;
};

struct WallObservationStats
{
  int wall_votes = 0;
  int open_votes = 0;
  rclcpp::Time last_observed;
};

struct EdgeWallStats
{
  WallObservationStats north;
  WallObservationStats east;
  WallObservationStats south;
  WallObservationStats west;
};

struct EdgeEvidence
{
  double wall_log_odds = 0.0;
  double open_log_odds = 0.0;
  double unknown_ema = 1.0;
  double last_occupied_ratio = 0.0;
  double last_free_ratio = 0.0;
  double last_unknown_ratio = 1.0;
  double confidence = 0.0;
  SlamGeometryState state = SlamGeometryState::Unknown;
  rclcpp::Time last_update;
  bool has_observation = false;
};

inline bool isTransitionColor(FloorColorClass color)
{
  return color == FloorColorClass::BlueArea1To2 ||
    color == FloorColorClass::YellowArea1To3 ||
    color == FloorColorClass::GreenArea1To4 ||
    color == FloorColorClass::PurpleArea2To3 ||
    color == FloorColorClass::OrangeArea2To4 ||
    color == FloorColorClass::RedArea3To4;
}

inline bool floorColorBypassesCenterMask(FloorColorClass color)
{
  return color == FloorColorClass::BlackHoleBorder ||
    color == FloorColorClass::SilverCheckpoint ||
    color == FloorColorClass::BrownSwamp;
}

inline TransitionInfo transitionInfoFromColor(FloorColorClass color)
{
  switch (color) {
    case FloorColorClass::BlueArea1To2:
      return TransitionInfo{TileArea::Area1, TileArea::Area2};
    case FloorColorClass::YellowArea1To3:
      return TransitionInfo{TileArea::Area1, TileArea::Area3};
    case FloorColorClass::GreenArea1To4:
      return TransitionInfo{TileArea::Area1, TileArea::Area4};
    case FloorColorClass::PurpleArea2To3:
      return TransitionInfo{TileArea::Area2, TileArea::Area3};
    case FloorColorClass::OrangeArea2To4:
      return TransitionInfo{TileArea::Area2, TileArea::Area4};
    case FloorColorClass::RedArea3To4:
      return TransitionInfo{TileArea::Area3, TileArea::Area4};
    default:
      return TransitionInfo{};
  }
}

}  // namespace ros2_mapper

#endif  // ROS2_MAPPER__TILE_SEMANTICS_HPP_
