#pragma once

#include <memory>
#include <optional>
#include <functional>
#include <set>
#include <string>

#include "ros2_vision/duplicate_filter.hpp"
#include "ros2_vision/lidar_camera_projector.hpp"
#include "ros2_vision/onnx_runner.hpp"
#include "ros2_vision/target_detector.hpp"
#include "ros2_vision/victim_detector.hpp"
#include "ros2_vision/vision_protocol.hpp"

namespace ros2_vision {

class LarcVisionPipeline {
public:
  struct Config {
    int process_every_n = 1;
    float min_presence_confidence = 0.55f;
    float min_type_confidence = 0.60f;
    bool type_fallback_enabled = false;
    // Single fused none/target/victim model. When true and object_presence_runner
    // is valid, one inference replaces the presence + object_type chain (measured
    // at parity accuracy on the imagens_larc test split, but half the model runs).
    bool use_fused_object_model = false;
    std::shared_ptr<OnnxRunner> object_presence_runner;  // logits [none, target, victim]
    float min_victim_cls_confidence = 0.5f;
    float victim_crop_padding = 0.05f;
    // Classify the whole frame (not the tight bbox crop) — victim_cls was trained
    // on full frames; see VictimDetector::Config.
    bool victim_classify_full_frame = true;
    // Single acceptance distance for both branches (legacy *_max_distance_m map here).
    float valid_detection_distance_m = 0.06f;
    float victim_min_distance_m = 0.0f;
    // Camera-only bbox proximity gate. The thresholds are the bbox size an object
    // has at valid_detection_distance_m (dataset boundary). A larger predicted box
    // means the object is closer, so this replaces the (distorted) LiDAR distance
    // measurement. The gate is on WIDTH (x) and HEIGHT (y); area is left
    // non-blocking (min_area = 0) because it over-rejects — see
    // scripts/evaluate_bbox_gate_xy.py.
    bool use_bbox_gate = false;
    float victim_bbox_gate_min_area_px = 30.0f;
    float victim_bbox_gate_min_width_px = 6.0f;
    float victim_bbox_gate_min_height_px = 5.0f;
    float target_bbox_gate_min_area_px = 0.0f;
    float target_bbox_gate_min_width_px = 12.0f;
    float target_bbox_gate_min_height_px = 8.0f;
    int victim_min_bbox_area_px = 16;
    int victim_min_bbox_axis_px = 3;
    // Target (rf_radial) acceptance gates.
    float min_radial_coverage = 0.25f;
    float min_ring_confidence = 0.34f;
    int min_mask_area_px = 60;
    float min_mask_confidence = 0.0f;
    // The production victim classifier has an explicit camera fake class. High
    // confidence fake detections are rejected before report generation.
    bool reject_fake_victims = true;
    float fake_min_confidence = 0.90f;
    // When true, at most one debug image is written per (tile, camera, outcome):
    // repeated identical classified/rejected frames are dropped so a stationary
    // robot cannot flood logs/images/{classified,rejected} with duplicates.
    bool dedup_debug_images = true;
    std::string duplicate_scope = "tile";
    // LiDAR distance is distorted/unreliable on wall-mounted objects, so by
    // default it is diagnostic only and does not gate camera detections.
    bool use_lidar_distance_gate = false;
    bool use_target_lidar_distance_gate = false;
    bool use_victim_lidar_distance_gate = false;
    bool lidar_gate_enabled = false;
    int lidar_gate_min_consecutive_rays = 5;
    float lidar_gate_max_range_m = 0.06f;
    int lidar_bbox_min_consecutive_rays = 5;
    float lidar_bbox_center_fraction = 0.50f;
    LidarCameraProjector::Config projector;
    TargetDetectorConfig target_detector;
    std::function<void(const std::string&)> event_logger;
    std::function<void(const VisionFrame&, const VisionDebugImage&)> debug_image_logger;
  };

  LarcVisionPipeline(std::shared_ptr<OnnxRunner> presence_runner,
                     std::shared_ptr<OnnxRunner> type_runner,
                     std::shared_ptr<OnnxRunner> victim_bbox_runner,
                     std::shared_ptr<OnnxRunner> target_bbox_runner,
                     std::shared_ptr<OnnxRunner> victim_cls_runner,
                     Config config);

  std::optional<VisionDetection> process(const VisionFrame& frame, std::string& reject_reason);

  // Introspection for startup logging.
  bool targetUsesRandomForest() const { return target_detector_.usingRandomForest(); }
  const std::string& targetLoadError() const { return target_detector_.lastLoadError(); }

private:
  // Branch handlers fill out_debug for every outcome (accepted or rejected) but do
  // NOT write the image themselves: process() logs exactly one debug image per
  // frame, so the losing side of a type-fallback never leaves a stray PNG behind.
  std::optional<VisionDetection> processTarget(const VisionFrame& frame, float presence,
                                               float type_confidence, std::string& reject_reason,
                                               VisionDebugImage& out_debug);
  std::optional<VisionDetection> processVictim(const VisionFrame& frame, float presence,
                                               float type_confidence, std::string& reject_reason,
                                               VisionDebugImage& out_debug);
  void logLidar(const std::string& branch, const VisionFrame& frame, float xmin, float xmax,
                float distance, int valid_rays) const;
  bool lidarGatePasses(const VisionFrame& frame, int* close_rays, int* max_run) const;
  // Presence + object-type decision. Uses the single fused none/target/victim
  // model when config_.use_fused_object_model is set (and the runner is valid),
  // otherwise the legacy two-stage presence + object_type models. On success
  // fills presence/kind/type_confidence and returns true; on rejection it logs
  // the reject image, sets reject_reason and returns false.
  bool decodeObjectStage(const VisionFrame& frame, const std::string& ctx, float& presence,
                         std::string& kind, float& type_confidence,
                         std::string& reject_reason) const;
  // Shared structured log prefix: camera/seq/tile/heading/image dims.
  std::string frameContext(const VisionFrame& frame) const;
  float decodeConfidence(const std::vector<float>& output) const;
  std::pair<std::string, float> decodeType(const std::vector<float>& output) const;
  void logEvent(const std::string& event) const;
  // Deduplicated debug-image sink: collapses repeated identical outcomes for the
  // same tile/camera so a stationary robot does not flood the log with thousands
  // of copies of the same classified/rejected frame. Returns immediately if the
  // (tile, camera, status, kind, class-or-reason) key was already written.
  void logDebugImage(const VisionFrame& frame, const VisionDebugImage& debug) const;
  std::string debugImageKey(const VisionFrame& frame, const VisionDebugImage& debug) const;

  std::shared_ptr<OnnxRunner> presence_runner_;
  std::shared_ptr<OnnxRunner> type_runner_;
  std::shared_ptr<OnnxRunner> target_bbox_runner_;
  TargetDetector target_detector_;
  VictimDetector victim_detector_;
  LidarCameraProjector projector_;
  DuplicateFilter duplicate_filter_;
  mutable std::set<std::string> logged_debug_keys_;
  Config config_;
};

}  // namespace ros2_vision
