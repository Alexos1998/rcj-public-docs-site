#pragma once

#include "geometry_msgs/msg/point.hpp"
#include "geometry_msgs/msg/pose.hpp"

#include "ros2_exploration/frontier_types.hpp"

namespace ros2_exploration
{

struct FrontierScoringWeights
{
  double information_gain{3.0};
  double distance_cost{1.0};
  double size_gain{0.25};
  double heading_change_cost{0.15};
  double recent_goal_penalty{4.0};
  double blacklist_penalty{100.0};
};

struct FrontierScoreBreakdown
{
  double information_gain{0.0};
  double frontier_size{0.0};
  double distance_m{0.0};
  double absolute_heading_change_rad{0.0};
  double recent_goal_penalty{0.0};
  double blacklist_penalty{0.0};
  double score{0.0};
};

class FrontierScorer
{
public:
  FrontierScorer() = default;
  explicit FrontierScorer(FrontierScoringWeights weights);
  FrontierScorer(double size_weight, double distance_weight);

  void setWeights(const FrontierScoringWeights & weights);
  const FrontierScoringWeights & weights() const;

  FrontierScoreBreakdown score(
    const Frontier & frontier,
    const geometry_msgs::msg::Pose & robot_pose,
    const geometry_msgs::msg::Point & goal_point,
    bool near_recent_goal,
    bool blacklisted) const;

private:
  static double estimateInformationGain(const Frontier & frontier);
  static double distance2d(
    const geometry_msgs::msg::Pose & pose,
    const geometry_msgs::msg::Point & point);
  static double yawFromPose(const geometry_msgs::msg::Pose & pose);
  static double normalizeAngle(double angle);
  static double absoluteHeadingChange(
    const geometry_msgs::msg::Pose & robot_pose,
    const geometry_msgs::msg::Point & goal_point);

  FrontierScoringWeights weights_;
};

}  // namespace ros2_exploration
