#include "ros2_vision/lidar_camera_projector.hpp"

#include <algorithm>
#include <cmath>
#include <limits>

namespace ros2_vision {
namespace {

constexpr double kTwoPi = 2.0 * M_PI;

bool isFullCircle(int n, double angle_increment)
{
  return n > 0 && angle_increment > 0.0 &&
         std::abs(static_cast<double>(n) * angle_increment - kTwoPi) < 0.05 * kTwoPi;
}

}  // namespace

LidarCameraProjector::LidarCameraProjector()
  : LidarCameraProjector(Config{})
{
}

LidarCameraProjector::LidarCameraProjector(Config config)
  : config_(config)
{
}

int LidarCameraProjector::angleToScanIndex(double theta_robot,
                                           int n,
                                           double angle_min,
                                           double angle_increment) const
{
  if (n <= 0 || !(angle_increment > 0.0) || !std::isfinite(theta_robot)) {
    return -1;
  }
  long idx = std::lround((theta_robot - angle_min) / angle_increment);
  if (idx >= 0 && idx < n) {
    return static_cast<int>(idx);
  }
  // Out of range: wrap only when the scan covers (approximately) the full circle.
  if (isFullCircle(n, angle_increment)) {
    idx %= n;
    if (idx < 0) {
      idx += n;
    }
    return static_cast<int>(idx);
  }
  return -1;
}

double LidarCameraProjector::pixelToRobotAngle(double x,
                                               int image_width,
                                               double hfov_rad,
                                               double camera_yaw_offset_rad) const
{
  const double fx = image_width / (2.0 * std::tan(hfov_rad / 2.0));
  const double cx = (image_width - 1) * 0.5;
  return camera_yaw_offset_rad + std::atan((x - cx) / fx);
}

float LidarCameraProjector::estimateDistanceForPixelInterval(const std::vector<float>& ranges,
                                                             int image_width,
                                                             float hfov_rad,
                                                             float camera_yaw_offset_rad,
                                                             float lidar_angle_min,
                                                             float lidar_angle_increment,
                                                             float lidar_range_min,
                                                             float lidar_range_max,
                                                             float xmin,
                                                             float xmax,
                                                             int* valid_rays_out) const
{
  if (valid_rays_out) {
    *valid_rays_out = 0;
  }
  const int n = static_cast<int>(ranges.size());
  if (n <= 0 || image_width <= 1 || hfov_rad <= 0.0f || !std::isfinite(hfov_rad) ||
      !(lidar_angle_increment > 0.0f)) {
    return std::numeric_limits<float>::quiet_NaN();
  }

  xmin = std::max(0.0f, std::min(xmin, static_cast<float>(image_width - 1)));
  xmax = std::max(0.0f, std::min(xmax, static_cast<float>(image_width - 1)));
  if (xmax < xmin) {
    std::swap(xmin, xmax);
  }

  const double theta_min = pixelToRobotAngle(xmin, image_width, hfov_rad, camera_yaw_offset_rad);
  const double theta_max = pixelToRobotAngle(xmax, image_width, hfov_rad, camera_yaw_offset_rad);
  const int i0 = angleToScanIndex(theta_min, n, lidar_angle_min, lidar_angle_increment);
  const int i1 = angleToScanIndex(theta_max, n, lidar_angle_min, lidar_angle_increment);

  const bool full_circle = isFullCircle(n, lidar_angle_increment);
  const int extra = std::max(0, config_.window_extra_rays);

  std::vector<float> samples;
  auto add_index = [&](int idx) {
    if (full_circle) {
      idx %= n;
      if (idx < 0) {
        idx += n;
      }
    } else if (idx < 0 || idx >= n) {
      return;
    }
    const float r = ranges[static_cast<std::size_t>(idx)];
    if (std::isfinite(r) && r >= lidar_range_min && r <= lidar_range_max) {
      samples.push_back(r);
    }
  };

  if (i0 < 0 && i1 < 0) {
    return std::numeric_limits<float>::quiet_NaN();
  }

  // Sweep the shorter arc between the two endpoints (plus a small margin).
  if (i0 >= 0 && i1 >= 0) {
    int lo = std::min(i0, i1);
    int hi = std::max(i0, i1);
    if (full_circle) {
      const int forward = (i1 - i0 + n) % n;
      const int backward = (i0 - i1 + n) % n;
      const int start = (forward <= backward) ? i0 : i1;
      const int span = std::min(forward, backward);
      for (int d = -extra; d <= span + extra; ++d) {
        add_index(start + d);
      }
    } else {
      for (int idx = lo - extra; idx <= hi + extra; ++idx) {
        add_index(idx);
      }
    }
  } else {
    const int center = i0 >= 0 ? i0 : i1;
    for (int d = -extra; d <= extra; ++d) {
      add_index(center + d);
    }
  }

  if (valid_rays_out) {
    *valid_rays_out = static_cast<int>(samples.size());
  }
  if (samples.empty()) {
    return std::numeric_limits<float>::quiet_NaN();
  }

  std::sort(samples.begin(), samples.end());
  if (config_.use_min_range) {
    return samples.front();
  }
  const float pct = std::max(0.0f, std::min(config_.robust_percentile, 100.0f));
  const float pos = (pct / 100.0f) * static_cast<float>(samples.size() - 1);
  const auto idx = static_cast<std::size_t>(std::lround(pos));
  return samples[std::min(idx, samples.size() - 1)];
}

LidarCameraProjector::CloseRunResult LidarCameraProjector::closeRunForPixelInterval(
  const std::vector<float>& ranges,
  int image_width,
  float hfov_rad,
  float camera_yaw_offset_rad,
  float lidar_angle_min,
  float lidar_angle_increment,
  float lidar_range_min,
  float lidar_range_max,
  float xmin,
  float xmax,
  float max_close_range_m,
  int min_consecutive_rays) const
{
  CloseRunResult result;
  result.distance = std::numeric_limits<float>::quiet_NaN();

  const int n = static_cast<int>(ranges.size());
  if (n <= 0 || image_width <= 1 || hfov_rad <= 0.0f || !std::isfinite(hfov_rad) ||
      !(lidar_angle_increment > 0.0f) || !(max_close_range_m > 0.0f)) {
    return result;
  }

  xmin = std::max(0.0f, std::min(xmin, static_cast<float>(image_width - 1)));
  xmax = std::max(0.0f, std::min(xmax, static_cast<float>(image_width - 1)));
  if (xmax < xmin) {
    std::swap(xmin, xmax);
  }

  const double theta_min = pixelToRobotAngle(xmin, image_width, hfov_rad, camera_yaw_offset_rad);
  const double theta_max = pixelToRobotAngle(xmax, image_width, hfov_rad, camera_yaw_offset_rad);
  const int i0 = angleToScanIndex(theta_min, n, lidar_angle_min, lidar_angle_increment);
  const int i1 = angleToScanIndex(theta_max, n, lidar_angle_min, lidar_angle_increment);
  if (i0 < 0 && i1 < 0) {
    return result;
  }

  const bool full_circle = isFullCircle(n, lidar_angle_increment);
  const int extra = std::max(0, config_.window_extra_rays);
  const int required = std::max(1, min_consecutive_rays);

  std::vector<int> indices;
  auto add_index = [&](int idx) {
    if (full_circle) {
      idx %= n;
      if (idx < 0) {
        idx += n;
      }
    } else if (idx < 0 || idx >= n) {
      return;
    }
    if (indices.empty() || indices.back() != idx) {
      indices.push_back(idx);
    }
  };

  if (i0 >= 0 && i1 >= 0) {
    if (full_circle) {
      const int forward = (i1 - i0 + n) % n;
      const int backward = (i0 - i1 + n) % n;
      const int start = (forward <= backward) ? i0 : i1;
      const int span = std::min(forward, backward);
      for (int d = -extra; d <= span + extra; ++d) {
        add_index(start + d);
      }
    } else {
      for (int idx = std::min(i0, i1) - extra; idx <= std::max(i0, i1) + extra; ++idx) {
        add_index(idx);
      }
    }
  } else {
    const int center = i0 >= 0 ? i0 : i1;
    for (int d = -extra; d <= extra; ++d) {
      add_index(center + d);
    }
  }

  int current_run = 0;
  std::vector<float> current_samples;
  std::vector<float> best_samples;
  std::vector<float> close_samples;

  for (int idx : indices) {
    const float r = ranges[static_cast<std::size_t>(idx)];
    const bool valid = std::isfinite(r) && r >= lidar_range_min && r <= lidar_range_max;
    if (valid) {
      ++result.valid_rays;
    }
    const bool close = valid && r <= max_close_range_m;
    if (close) {
      ++result.close_rays;
      ++current_run;
      current_samples.push_back(r);
      close_samples.push_back(r);
      if (current_run > result.max_consecutive) {
        result.max_consecutive = current_run;
        best_samples = current_samples;
      }
    } else {
      current_run = 0;
      current_samples.clear();
    }
  }

  result.pass = result.max_consecutive >= required;
  auto choose_distance = [](std::vector<float> samples) {
    if (samples.empty()) {
      return std::numeric_limits<float>::quiet_NaN();
    }
    std::sort(samples.begin(), samples.end());
    return samples[samples.size() / 2U];
  };
  result.distance = result.pass ? choose_distance(best_samples) : choose_distance(close_samples);
  return result;
}

}  // namespace ros2_vision
