#pragma once

#include <cstddef>
#include <mutex>
#include <optional>
#include <string>
#include <vector>

#include "geometry_msgs/msg/point.hpp"
#include "rclcpp/time.hpp"

namespace ros2_exploration
{

struct BlacklistedGoal
{
  geometry_msgs::msg::Point point;
  rclcpp::Time expires_at;
  std::string reason;
};

class Blacklist
{
public:
  void configure(double radius_m, double duration_s, std::size_t max_entries);

  void add(
    const geometry_msgs::msg::Point & point,
    const rclcpp::Time & now,
    const std::string & reason);
  bool contains(const geometry_msgs::msg::Point & point, const rclcpp::Time & now) const;
  std::optional<BlacklistedGoal> match(
    const geometry_msgs::msg::Point & point,
    const rclcpp::Time & now) const;

  void pruneExpired(const rclcpp::Time & now);
  void clear();
  std::size_t size() const;
  std::vector<BlacklistedGoal> entries(const rclcpp::Time & now) const;

  double radius() const;
  double duration() const;
  std::size_t maxEntries() const;

private:
  static double distance2d(
    const geometry_msgs::msg::Point & lhs,
    const geometry_msgs::msg::Point & rhs);

  void pruneExpiredLocked(const rclcpp::Time & now);
  void trimLocked();

  mutable std::mutex mutex_;
  std::vector<BlacklistedGoal> goals_;
  double radius_m_{0.12};
  double duration_s_{20.0};
  std::size_t max_entries_{80};
};

}  // namespace ros2_exploration
