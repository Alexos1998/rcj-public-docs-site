#pragma once

#include <set>
#include <string>

namespace ros2_vision {

class DuplicateFilter {
public:
  explicit DuplicateFilter(std::string scope = "tile");

  // Tile-level report gate: independent of class/camera/pattern. Checked BEFORE
  // any inference so a tile that already produced a valid detection is skipped.
  bool tileAlreadyReported(int tile_x, int tile_y) const;
  void markTileReported(int tile_x, int tile_y);

  bool seen(int tile_x,
            int tile_y,
            int camera_id,
            const std::string& kind,
            const std::string& class_name) const;

  void mark(int tile_x,
            int tile_y,
            int camera_id,
            const std::string& kind,
            const std::string& class_name);

private:
  std::string tileKey(int tile_x, int tile_y) const;

  std::string makeKey(int tile_x,
                      int tile_y,
                      int camera_id,
                      const std::string& kind,
                      const std::string& class_name) const;

  std::string scope_;
  std::set<std::string> reported_;
  std::set<std::string> reported_tiles_;
};

}  // namespace ros2_vision
