#include "ros2_vision/target_mask_rf.hpp"

#include <fstream>

#include <opencv2/imgproc.hpp>

namespace ros2_vision {

bool TargetMaskRF::load(const std::string& model_path, const std::string& feature_config_path)
{
  rtrees_.reset();
  try {
    std::ifstream probe(model_path);
    if (!probe.good()) {
      return false;
    }
    rtrees_ = cv::ml::RTrees::load(model_path);
  } catch (const cv::Exception&) {
    rtrees_.reset();
    return false;
  }
  if (!rtrees_ || !rtrees_->isTrained()) {
    rtrees_.reset();
    return false;
  }

  // Feature config is optional; when present it carries the input size used at
  // training so the runtime resizes identically.
  if (!feature_config_path.empty()) {
    try {
      cv::FileStorage fs(feature_config_path, cv::FileStorage::READ);
      if (fs.isOpened()) {
        const cv::FileNode schema = fs["feature_schema"];
        if (!schema.empty()) {
          if (!schema["input_width"].empty()) {
            input_width_ = static_cast<int>(schema["input_width"]);
          }
          if (!schema["input_height"].empty()) {
            input_height_ = static_cast<int>(schema["input_height"]);
          }
        }
      }
    } catch (const cv::Exception&) {
      // Keep defaults (64x64) if the schema cannot be parsed.
    }
  }
  return true;
}

cv::Mat TargetMaskRF::extractPixelFeatures(const cv::Mat& bgr, int width, int height)
{
  cv::Mat src = bgr;
  if (src.channels() == 4) {
    cv::cvtColor(src, src, cv::COLOR_BGRA2BGR);
  }
  cv::Mat resized;
  cv::resize(src, resized, cv::Size(width, height), 0.0, 0.0, cv::INTER_LINEAR);

  // All color features are computed on the RGB image to match the notebook.
  cv::Mat rgb;
  cv::cvtColor(resized, rgb, cv::COLOR_BGR2RGB);
  cv::Mat rgbf;
  rgb.convertTo(rgbf, CV_32FC3, 1.0 / 255.0);

  cv::Mat hsv;
  cv::cvtColor(rgb, hsv, cv::COLOR_RGB2HSV);
  cv::Mat lab;
  cv::cvtColor(rgb, lab, cv::COLOR_RGB2Lab);

  cv::Mat gray;
  cv::cvtColor(rgb, gray, cv::COLOR_RGB2GRAY);
  cv::Mat grayf;
  gray.convertTo(grayf, CV_32F, 1.0 / 255.0);

  cv::Mat local_mean;
  cv::blur(grayf, local_mean, cv::Size(3, 3));

  cv::Mat gx;
  cv::Mat gy;
  cv::Sobel(grayf, gx, CV_32F, 1, 0, 3);
  cv::Sobel(grayf, gy, CV_32F, 0, 1, 3);
  cv::Mat grad;
  cv::magnitude(gx, gy, grad);
  double min_val = 0.0;
  double max_val = 0.0;
  cv::minMaxLoc(grad, &min_val, &max_val);
  grad /= static_cast<float>(max_val + 1e-6);

  const int n = width * height;
  cv::Mat feats(n, kNumFeatures, CV_32F);
  const float inv_w = width > 1 ? 1.0f / static_cast<float>(width - 1) : 0.0f;
  const float inv_h = height > 1 ? 1.0f / static_cast<float>(height - 1) : 0.0f;
  for (int y = 0; y < height; ++y) {
    const cv::Vec3f* rgb_row = rgbf.ptr<cv::Vec3f>(y);
    const cv::Vec3b* hsv_row = hsv.ptr<cv::Vec3b>(y);
    const cv::Vec3b* lab_row = lab.ptr<cv::Vec3b>(y);
    const float* mean_row = local_mean.ptr<float>(y);
    const float* grad_row = grad.ptr<float>(y);
    for (int x = 0; x < width; ++x) {
      float* f = feats.ptr<float>(y * width + x);
      f[0] = rgb_row[x][0];
      f[1] = rgb_row[x][1];
      f[2] = rgb_row[x][2];
      f[3] = static_cast<float>(hsv_row[x][0]) / 179.0f;
      f[4] = static_cast<float>(hsv_row[x][1]) / 255.0f;
      f[5] = static_cast<float>(hsv_row[x][2]) / 255.0f;
      f[6] = static_cast<float>(lab_row[x][0]) / 255.0f;
      f[7] = static_cast<float>(lab_row[x][1]) / 255.0f;
      f[8] = static_cast<float>(lab_row[x][2]) / 255.0f;
      f[9] = static_cast<float>(x) * inv_w;
      f[10] = static_cast<float>(y) * inv_h;
      f[11] = mean_row[x];
      f[12] = grad_row[x];
    }
  }
  return feats;
}

cv::Mat TargetMaskRF::predictMask(const cv::Mat& bgr) const
{
  float ignored = 0.0f;
  return predictMask(bgr, ignored);
}

cv::Mat TargetMaskRF::predictMask(const cv::Mat& bgr, float& mask_confidence) const
{
  mask_confidence = 0.0f;
  if (!loaded() || bgr.empty()) {
    return {};
  }

  const int w = input_width_;
  const int h = input_height_;
  cv::Mat feats = extractPixelFeatures(bgr, w, h);

  cv::Mat results;
  rtrees_->predict(feats, results);  // (N,1) CV_32F class labels

  cv::Mat mask(h, w, CV_8U, cv::Scalar(0));
  long target_pixels = 0;
  for (int i = 0; i < results.rows; ++i) {
    if (results.at<float>(i, 0) >= 0.5f) {
      mask.data[i] = 255;
      ++target_pixels;
    }
  }

  // Vote agreement over predicted-target pixels -> mask confidence.
  if (target_pixels > 0) {
    cv::Mat votes;
    try {
      rtrees_->getVotes(feats, votes, 0);  // row 0 = class labels, rows 1.. = counts
    } catch (const cv::Exception&) {
      votes.release();
    }
    if (!votes.empty() && votes.rows == results.rows + 1 && votes.cols >= 2) {
      int target_col = 1;
      if (static_cast<int>(votes.at<int>(0, 0)) == 1) {
        target_col = 0;
      }
      double conf_sum = 0.0;
      for (int i = 0; i < results.rows; ++i) {
        if (mask.data[i]) {
          const int total = votes.at<int>(i + 1, 0) + votes.at<int>(i + 1, 1);
          if (total > 0) {
            conf_sum += static_cast<double>(votes.at<int>(i + 1, target_col)) / total;
          }
        }
      }
      mask_confidence = static_cast<float>(conf_sum / static_cast<double>(target_pixels));
    } else {
      mask_confidence = 1.0f;  // votes unavailable; treat hard prediction as confident
    }
  }

  if (morph_close_ && target_pixels > 0) {
    const cv::Mat kernel = cv::getStructuringElement(cv::MORPH_RECT, {3, 3});
    cv::morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel);
  }

  if (bgr.cols != w || bgr.rows != h) {
    cv::resize(mask, mask, bgr.size(), 0.0, 0.0, cv::INTER_NEAREST);
  }
  return mask;
}

}  // namespace ros2_vision
