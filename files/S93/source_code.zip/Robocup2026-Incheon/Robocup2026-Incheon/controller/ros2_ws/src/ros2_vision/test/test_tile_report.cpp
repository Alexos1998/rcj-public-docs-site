// Standalone test: tile-level report gate + sim-time report hold logic.
// Build (no ROS needed):
//   g++ -std=c++17 -I include test/test_tile_report.cpp src/duplicate_filter.cpp -o /tmp/test_tile
//   /tmp/test_tile

#include <cstdio>

#include "ros2_vision/duplicate_filter.hpp"

namespace {
int g_passed = 0;
int g_failed = 0;
void check(const char* name, bool ok)
{
  std::printf("[%s] %s\n", ok ? "PASS" : "FAIL", name);
  ok ? ++g_passed : ++g_failed;
}
}  // namespace

int main()
{
  // --- Tile report gate: first detection accepted, second on same tile skipped. ---
  ros2_vision::DuplicateFilter filter("tile");
  check("tile not reported initially", !filter.tileAlreadyReported(2, 3));
  filter.markTileReported(2, 3);
  check("tile reported after mark", filter.tileAlreadyReported(2, 3));
  check("different tile still open", !filter.tileAlreadyReported(2, 4));
  // Re-checking the same tile (the second frame) is rejected before any inference.
  check("second frame same tile skipped", filter.tileAlreadyReported(2, 3));

  // --- Sim-time report hold: zero velocity until >= 1.0s of sim time elapses. ---
  const double hold_duration = 1.0;
  const double dt = 0.032;  // sim step
  double sim_time = 0.0;
  const double hold_start = sim_time;
  bool reported = false;
  double left_vel = 5.0;
  double right_vel = 5.0;
  bool velocity_zero_throughout = true;
  int steps = 0;
  while (!reported && steps < 1000) {
    // HOLDING_FOR_REPORT: velocities forced to zero every cycle.
    left_vel = 0.0;
    right_vel = 0.0;
    if (left_vel != 0.0 || right_vel != 0.0) {
      velocity_zero_throughout = false;
    }
    if ((sim_time - hold_start) >= hold_duration) {
      reported = true;
      break;
    }
    sim_time += dt;
    ++steps;
  }
  check("velocity zero during hold", velocity_zero_throughout);
  check("report only after >= 1.0s sim time", reported && (sim_time - hold_start) >= hold_duration);
  check("did not report before 1.0s", (sim_time - hold_start) >= hold_duration);

  std::printf("\n%d/%d tile-report/hold checks passed\n", g_passed, g_passed + g_failed);
  return g_failed == 0 ? 0 : 1;
}
