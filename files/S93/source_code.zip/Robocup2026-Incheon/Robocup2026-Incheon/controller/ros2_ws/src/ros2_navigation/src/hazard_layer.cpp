#include "ros2_navigation/hazard_layer.hpp"

#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <iomanip>
#include <regex>
#include <sstream>
#include <utility>

#include <nav2_costmap_2d/cost_values.hpp>
#include <pluginlib/class_list_macros.hpp>
#include <std_msgs/msg/color_rgba.hpp>

namespace ros2_navigation
{
namespace
{

bool jsonBoolField(const nlohmann::json & payload, const char * field)
{
  if (!payload.is_object() || !payload.contains(field)) {
    return false;
  }
  const auto & value = payload.at(field);
  if (value.is_boolean()) {
    return value.get<bool>();
  }
  if (value.is_number_integer()) {
    return value.get<int>() != 0;
  }
  if (value.is_string()) {
    auto text = value.get<std::string>();
    std::transform(text.begin(), text.end(), text.begin(), [](unsigned char ch) {
      return static_cast<char>(std::tolower(ch));
    });
    return text == "true" || text == "yes" || text == "1";
  }
  return false;
}

}  // namespace

void HazardLayer::onInitialize()
{
  auto node = node_.lock();
  if (!node) {
    throw std::runtime_error("HazardLayer requires a valid lifecycle node");
  }

  declareParameter("enabled", rclcpp::ParameterValue(enabled_));
  declareParameter("hazard_events_topic", rclcpp::ParameterValue(hazard_events_topic_));
  declareParameter("semantic_map_topic", rclcpp::ParameterValue(semantic_map_topic_));
  declareParameter("marker_topic", rclcpp::ParameterValue(marker_topic_));
  declareParameter("marker_frame", rclcpp::ParameterValue(marker_frame_));
  declareParameter("subscribe_semantic_map", rclcpp::ParameterValue(subscribe_semantic_map_));
  declareParameter("hazard_block_confidence_threshold", rclcpp::ParameterValue(confidence_threshold_));
  declareParameter("hazard_block_suspected", rclcpp::ParameterValue(block_suspected_));
  declareParameter("tile_size_m", rclcpp::ParameterValue(tile_size_m_));
  declareParameter("tile_origin_x", rclcpp::ParameterValue(tile_origin_x_));
  declareParameter("tile_origin_y", rclcpp::ParameterValue(tile_origin_y_));
  declareParameter("tile_padding_m", rclcpp::ParameterValue(tile_padding_m_));
  declareParameter("hazard_cost", rclcpp::ParameterValue(static_cast<int>(hazard_cost_)));

  node->get_parameter(name_ + ".enabled", enabled_);
  node->get_parameter(name_ + ".hazard_events_topic", hazard_events_topic_);
  node->get_parameter(name_ + ".semantic_map_topic", semantic_map_topic_);
  node->get_parameter(name_ + ".marker_topic", marker_topic_);
  node->get_parameter(name_ + ".marker_frame", marker_frame_);
  node->get_parameter(name_ + ".subscribe_semantic_map", subscribe_semantic_map_);
  node->get_parameter(name_ + ".hazard_block_confidence_threshold", confidence_threshold_);
  node->get_parameter(name_ + ".hazard_block_suspected", block_suspected_);
  node->get_parameter(name_ + ".tile_size_m", tile_size_m_);
  node->get_parameter(name_ + ".tile_origin_x", tile_origin_x_);
  node->get_parameter(name_ + ".tile_origin_y", tile_origin_y_);
  node->get_parameter(name_ + ".tile_padding_m", tile_padding_m_);
  int hazard_cost = static_cast<int>(hazard_cost_);
  node->get_parameter(name_ + ".hazard_cost", hazard_cost);
  hazard_cost_ = static_cast<unsigned char>(std::clamp(hazard_cost, 1, 254));
  tile_size_m_ = std::max(0.001, tile_size_m_);
  tile_padding_m_ = std::max(0.0, tile_padding_m_);

  if (enabled_) {
    marker_pub_ = node->create_publisher<visualization_msgs::msg::MarkerArray>(
      marker_topic_,
      rclcpp::QoS(1).transient_local().reliable());

    hazard_events_sub_ = node->create_subscription<std_msgs::msg::String>(
      hazard_events_topic_,
      rclcpp::QoS(50).reliable(),
      std::bind(&HazardLayer::hazardEventCallback, this, std::placeholders::_1));

    if (subscribe_semantic_map_) {
      semantic_map_sub_ = node->create_subscription<std_msgs::msg::String>(
        semantic_map_topic_,
        rclcpp::QoS(10),
        std::bind(&HazardLayer::semanticMapCallback, this, std::placeholders::_1));
    }
  }

  current_ = true;
  RCLCPP_INFO(
    logger_,
    "ROBOT_EVENT node=hazard_layer event=initialized enabled=%s hazard_events_topic=%s "
    "semantic_map_topic=%s tile_size=%.3f origin=(%.4f,%.4f) hazard_cost=%u",
    enabled_ ? "true" : "false",
    hazard_events_topic_.c_str(),
    semantic_map_topic_.c_str(),
    tile_size_m_,
    tile_origin_x_,
    tile_origin_y_,
    static_cast<unsigned int>(hazard_cost_));
  publishMarkers();
}

void HazardLayer::updateBounds(
  double,
  double,
  double,
  double * min_x,
  double * min_y,
  double * max_x,
  double * max_y)
{
  if (!enabled_) {
    return;
  }

  std::lock_guard<std::mutex> lock(mutex_);
  for (const auto & entry : hazard_tiles_) {
    double tile_min_x = 0.0;
    double tile_min_y = 0.0;
    double tile_max_x = 0.0;
    double tile_max_y = 0.0;
    tileBounds(entry.first, &tile_min_x, &tile_min_y, &tile_max_x, &tile_max_y);
    *min_x = std::min(*min_x, tile_min_x);
    *min_y = std::min(*min_y, tile_min_y);
    *max_x = std::max(*max_x, tile_max_x);
    *max_y = std::max(*max_y, tile_max_y);
  }
}

void HazardLayer::updateCosts(
  nav2_costmap_2d::Costmap2D & master_grid,
  int min_i,
  int min_j,
  int max_i,
  int max_j)
{
  if (!enabled_) {
    return;
  }

  std::lock_guard<std::mutex> lock(mutex_);
  if (hazard_tiles_.empty()) {
    return;
  }

  const int bounded_min_i = std::max(0, min_i);
  const int bounded_min_j = std::max(0, min_j);
  const int bounded_max_i = std::min(static_cast<int>(master_grid.getSizeInCellsX()), max_i);
  const int bounded_max_j = std::min(static_cast<int>(master_grid.getSizeInCellsY()), max_j);

  for (int j = bounded_min_j; j < bounded_max_j; ++j) {
    for (int i = bounded_min_i; i < bounded_max_i; ++i) {
      double wx = 0.0;
      double wy = 0.0;
      master_grid.mapToWorld(static_cast<unsigned int>(i), static_cast<unsigned int>(j), wx, wy);
      const auto tile = worldToTile(wx, wy);
      if (hazard_tiles_.count(tile) == 0U) {
        continue;
      }

      const auto previous = master_grid.getCost(static_cast<unsigned int>(i), static_cast<unsigned int>(j));
      if (previous == nav2_costmap_2d::NO_INFORMATION || previous < hazard_cost_) {
        master_grid.setCost(
          static_cast<unsigned int>(i),
          static_cast<unsigned int>(j),
          hazard_cost_);
      }
    }
  }
}

void HazardLayer::reset()
{
  current_ = true;
}

void HazardLayer::hazardEventCallback(std_msgs::msg::String::SharedPtr msg)
{
  if (!enabled_) {
    return;
  }

  nlohmann::json payload;
  try {
    payload = nlohmann::json::parse(msg->data);
  } catch (const nlohmann::json::exception & ex) {
    RCLCPP_WARN_THROTTLE(
      logger_,
      *clock_,
      2000,
      "ROBOT_EVENT node=hazard_layer event=hazard_event_ignored reason=json_parse_error error=%s",
      ex.what());
    return;
  }

  std::string hazard_type;
  double confidence = 1.0;
  if (!isBlockingHazardEvent(payload, &hazard_type, &confidence)) {
    return;
  }

  const auto tile = resolveHazardTile(payload);
  if (!tile.has_value()) {
    RCLCPP_WARN_THROTTLE(
      logger_,
      *clock_,
      2000,
      "ROBOT_EVENT node=hazard_layer event=hazard_event_ignored reason=missing_tile_attribution");
    return;
  }

  blockTile(
    tile.value(),
    hazard_type,
    confidence,
    lowerAscii(jsonStringField(payload, "event")).empty() ? "mapper_hazard_event" :
    lowerAscii(jsonStringField(payload, "event")));
}

void HazardLayer::semanticMapCallback(std_msgs::msg::String::SharedPtr msg)
{
  if (!enabled_) {
    return;
  }

  nlohmann::json payload;
  try {
    payload = nlohmann::json::parse(msg->data);
  } catch (const nlohmann::json::exception &) {
    return;
  }

  {
    std::lock_guard<std::mutex> lock(mutex_);
    if (payload.contains("tile_size") && payload.at("tile_size").is_number()) {
      tile_size_m_ = std::max(0.001, payload.at("tile_size").get<double>());
    }
    if (payload.contains("origin") && payload.at("origin").is_object()) {
      const auto & origin = payload.at("origin");
      if (origin.contains("x") && origin.at("x").is_number()) {
        tile_origin_x_ = origin.at("x").get<double>();
      }
      if (origin.contains("y") && origin.at("y").is_number()) {
        tile_origin_y_ = origin.at("y").get<double>();
      }
    }
  }

  if (!payload.contains("tiles") || !payload.at("tiles").is_array()) {
    return;
  }

  for (const auto & tile_record : payload.at("tiles")) {
    if (!tile_record.is_object()) {
      continue;
    }

    const bool blocked = jsonBoolField(tile_record, "blocked");
    const bool hole = jsonBoolField(tile_record, "hole");
    const bool black_hole_border = jsonBoolField(tile_record, "black_hole_border");
    const std::string nested_type = lowerAscii(jsonNestedStringField(tile_record, "hazard", "type"));
    const std::string nested_state = lowerAscii(jsonNestedStringField(tile_record, "hazard", "state"));
    if (!blocked && !hole && !black_hole_border &&
        !(isHazardTypeName(nested_type) && nested_state == "confirmed"))
    {
      continue;
    }

    const auto tile = parseTileValue(tile_record);
    if (!tile.has_value()) {
      continue;
    }

    const double confidence =
      tile_record.contains("hazard") && tile_record.at("hazard").is_object() ?
      jsonNumberField(tile_record.at("hazard"), "confidence", 1.0) :
      1.0;
    blockTile(tile.value(), nested_type.empty() ? "black_hole" : nested_type, confidence, "semantic_map");
  }
}

bool HazardLayer::isBlockingHazardEvent(
  const nlohmann::json & payload,
  std::string * hazard_type,
  double * confidence) const
{
  const auto event = lowerAscii(jsonStringField(payload, "event"));
  auto type = lowerAscii(jsonStringField(payload, "hazard_type"));
  const auto nested_type = lowerAscii(jsonNestedStringField(payload, "hazard", "type"));
  if (type.empty()) {
    type = nested_type;
  }
  if (type.empty()) {
    type = "unknown";
  }

  const double detected_confidence = hazardConfidenceFromPayload(payload);
  const bool confirmed_event = isConfirmedEventName(event);
  const bool suspected_event = event == "black_hole_suspected" || event == "hazard_candidate";
  const bool type_match = isHazardTypeName(type) || isHazardTypeName(nested_type);

  bool should_block = confirmed_event || type_match;
  if (event == "hazard_candidate") {
    should_block = detected_confidence >= confidence_threshold_ || block_suspected_;
  } else if (suspected_event && !confirmed_event && !type_match) {
    should_block = block_suspected_ && detected_confidence >= confidence_threshold_;
  }

  if (!should_block) {
    return false;
  }

  if (hazard_type != nullptr) {
    *hazard_type = type == "unknown" && !nested_type.empty() ? nested_type : type;
  }
  if (confidence != nullptr) {
    *confidence = detected_confidence;
  }
  return true;
}

std::optional<TileCoord> HazardLayer::resolveHazardTile(const nlohmann::json & payload) const
{
  const std::array<const char *, 4> fields = {
    "hazard_tile", "sensor_tile", "observed_tile", "tile"};
  for (const auto * field : fields) {
    const auto tile = parseTileField(payload, field);
    if (tile.has_value()) {
      return tile;
    }
  }
  return std::nullopt;
}

std::optional<TileCoord> HazardLayer::parseTileValue(const nlohmann::json & value) const
{
  if (value.is_object() && value.contains("x") && value.contains("y")) {
    try {
      return TileCoord{value.at("x").get<int>(), value.at("y").get<int>()};
    } catch (const nlohmann::json::exception &) {
      return std::nullopt;
    }
  }

  if (value.is_array() && value.size() >= 2U) {
    try {
      return TileCoord{value.at(0).get<int>(), value.at(1).get<int>()};
    } catch (const nlohmann::json::exception &) {
      return std::nullopt;
    }
  }

  if (value.is_string()) {
    static const std::regex tile_regex(R"(^\s*\(?\s*(-?\d+)\s*,\s*(-?\d+)\s*\)?\s*$)");
    std::smatch match;
    const auto text = value.get<std::string>();
    if (std::regex_match(text, match, tile_regex)) {
      return TileCoord{std::stoi(match[1].str()), std::stoi(match[2].str())};
    }
  }

  return std::nullopt;
}

std::optional<TileCoord> HazardLayer::parseTileField(
  const nlohmann::json & payload,
  const char * field) const
{
  if (!payload.is_object() || !payload.contains(field) || payload.at(field).is_null()) {
    return std::nullopt;
  }
  return parseTileValue(payload.at(field));
}

void HazardLayer::blockTile(
  const TileCoord & tile,
  const std::string & hazard_type,
  double confidence,
  const std::string & reason)
{
  bool inserted = false;
  int hit_count = 0;
  {
    std::lock_guard<std::mutex> lock(mutex_);
    auto & record = hazard_tiles_[tile];
    inserted = record.hit_count == 0;
    record.hazard_type = hazard_type.empty() || hazard_type == "unknown" ? "black_hole" : hazard_type;
    record.confidence = std::max(record.confidence, confidence);
    record.last_seen = clock_->now();
    ++record.hit_count;
    hit_count = record.hit_count;
  }

  current_ = true;
  RCLCPP_INFO_THROTTLE(
    logger_,
    *clock_,
    inserted ? 1 : 1000,
    "ROBOT_EVENT node=hazard_layer event=hazard_tile_blocked tile=%s hazard_type=%s "
    "confidence=%.3f reason=%s hit_count=%d",
    tileToString(tile).c_str(),
    (hazard_type.empty() ? "black_hole" : hazard_type).c_str(),
    confidence,
    reason.c_str(),
    hit_count);
  publishMarkers();
}

void HazardLayer::publishMarkers()
{
  if (!marker_pub_) {
    return;
  }

  visualization_msgs::msg::MarkerArray array;

  visualization_msgs::msg::Marker clear;
  clear.header.frame_id = marker_frame_;
  clear.header.stamp = clock_->now();
  clear.ns = "nav2_hazard_layer";
  clear.id = 0;
  clear.action = visualization_msgs::msg::Marker::DELETEALL;
  array.markers.push_back(clear);

  visualization_msgs::msg::Marker tiles;
  tiles.header = clear.header;
  tiles.ns = "nav2_hazard_layer";
  tiles.id = 1;
  tiles.type = visualization_msgs::msg::Marker::CUBE_LIST;
  tiles.action = visualization_msgs::msg::Marker::ADD;
  tiles.pose.orientation.w = 1.0;
  tiles.scale.x = tile_size_m_;
  tiles.scale.y = tile_size_m_;
  tiles.scale.z = 0.006;
  tiles.color.r = 0.02F;
  tiles.color.g = 0.02F;
  tiles.color.b = 0.02F;
  tiles.color.a = 0.88F;

  visualization_msgs::msg::Marker inflation;
  inflation.header = clear.header;
  inflation.ns = "nav2_hazard_layer_inflation_radius";
  inflation.id = 2;
  inflation.type = visualization_msgs::msg::Marker::SPHERE_LIST;
  inflation.action = visualization_msgs::msg::Marker::ADD;
  inflation.pose.orientation.w = 1.0;
  inflation.scale.x = 0.037 * 2.0;
  inflation.scale.y = 0.037 * 2.0;
  inflation.scale.z = 0.003;
  inflation.color.r = 1.0F;
  inflation.color.g = 0.12F;
  inflation.color.b = 0.02F;
  inflation.color.a = 0.25F;

  {
    std::lock_guard<std::mutex> lock(mutex_);
    for (const auto & entry : hazard_tiles_) {
      const auto & tile = entry.first;
      geometry_msgs::msg::Point center;
      center.x = tile_origin_x_ + static_cast<double>(tile.x) * tile_size_m_;
      center.y = tile_origin_y_ + static_cast<double>(tile.y) * tile_size_m_;
      center.z = 0.012;
      tiles.points.push_back(center);
      inflation.points.push_back(center);
    }
  }

  array.markers.push_back(tiles);
  array.markers.push_back(inflation);
  marker_pub_->publish(array);
}

TileCoord HazardLayer::worldToTile(double wx, double wy) const
{
  return TileCoord{
    static_cast<int>(std::lround((wx - tile_origin_x_) / tile_size_m_)),
    static_cast<int>(std::lround((wy - tile_origin_y_) / tile_size_m_))};
}

void HazardLayer::tileBounds(
  const TileCoord & tile,
  double * min_x,
  double * min_y,
  double * max_x,
  double * max_y) const
{
  *min_x = tile_origin_x_ + (static_cast<double>(tile.x) - 0.5) * tile_size_m_ -
    tile_padding_m_;
  *min_y = tile_origin_y_ + (static_cast<double>(tile.y) - 0.5) * tile_size_m_ -
    tile_padding_m_;
  *max_x = tile_origin_x_ + (static_cast<double>(tile.x) + 0.5) * tile_size_m_ +
    tile_padding_m_;
  *max_y = tile_origin_y_ + (static_cast<double>(tile.y) + 0.5) * tile_size_m_ +
    tile_padding_m_;
}

std::string HazardLayer::tileToString(const TileCoord & tile) const
{
  std::ostringstream oss;
  oss << "(" << tile.x << "," << tile.y << ")";
  return oss.str();
}

std::string HazardLayer::lowerAscii(std::string text) const
{
  std::transform(text.begin(), text.end(), text.begin(), [](unsigned char ch) {
    return static_cast<char>(std::tolower(ch));
  });
  return text;
}

std::string HazardLayer::jsonStringField(const nlohmann::json & payload, const char * field) const
{
  if (!payload.is_object() || !payload.contains(field) || payload.at(field).is_null()) {
    return "";
  }
  const auto & value = payload.at(field);
  if (value.is_string()) {
    return value.get<std::string>();
  }
  if (value.is_boolean()) {
    return value.get<bool>() ? "true" : "false";
  }
  if (value.is_number_integer()) {
    return std::to_string(value.get<int>());
  }
  return "";
}

std::string HazardLayer::jsonNestedStringField(
  const nlohmann::json & payload,
  const char * object_field,
  const char * nested_field) const
{
  if (!payload.is_object() || !payload.contains(object_field) ||
      !payload.at(object_field).is_object())
  {
    return "";
  }
  return jsonStringField(payload.at(object_field), nested_field);
}

double HazardLayer::jsonNumberField(
  const nlohmann::json & payload,
  const char * field,
  double fallback) const
{
  if (!payload.is_object() || !payload.contains(field) || payload.at(field).is_null()) {
    return fallback;
  }
  const auto & value = payload.at(field);
  if (value.is_number()) {
    return value.get<double>();
  }
  if (value.is_string()) {
    try {
      return std::stod(value.get<std::string>());
    } catch (const std::exception &) {
      return fallback;
    }
  }
  return fallback;
}

double HazardLayer::hazardConfidenceFromPayload(const nlohmann::json & payload) const
{
  double confidence = jsonNumberField(payload, "confidence", -1.0);
  if (confidence < 0.0 && payload.is_object() && payload.contains("hazard") &&
      payload.at("hazard").is_object())
  {
    confidence = jsonNumberField(payload.at("hazard"), "confidence", -1.0);
  }
  if (confidence < 0.0) {
    confidence = 1.0;
  }
  return std::clamp(confidence, 0.0, 1.0);
}

bool HazardLayer::isConfirmedEventName(const std::string & event) const
{
  return event == "black_hole_detected" || event == "hole_detected" ||
         event == "black_hole_confirmed" || event == "black_hole_border_detected" ||
         event == "black_hole_border" || event == "hazard_confirmed";
}

bool HazardLayer::isHazardTypeName(const std::string & hazard_type) const
{
  return hazard_type == "black_hole" || hazard_type == "hole" ||
         hazard_type == "black_hole_border" || hazard_type == "black";
}

}  // namespace ros2_navigation

PLUGINLIB_EXPORT_CLASS(ros2_navigation::HazardLayer, nav2_costmap_2d::Layer)
