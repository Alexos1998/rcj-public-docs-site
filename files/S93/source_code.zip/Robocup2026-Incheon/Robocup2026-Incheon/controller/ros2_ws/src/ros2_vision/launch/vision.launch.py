import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, OpaqueFunction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def _runtime_params_list(context):
    """Return [runtime_params_file] when it points at an existing file, else []."""
    path = LaunchConfiguration("runtime_params_file").perform(context)
    return [path] if path and os.path.exists(path) else []


def launch_setup(context, *args, **kwargs):
    del args, kwargs

    params_file = LaunchConfiguration("params_file")
    use_sim_time = LaunchConfiguration("use_sim_time")

    # Runtime override file is appended LAST so it wins over the base YAML.
    parameters = [
        params_file,
        {"use_sim_time": ParameterValue(use_sim_time, value_type=bool)},
        *_runtime_params_list(context),
    ]

    return [
        Node(
            package="ros2_vision",
            executable="ros2_vision_node",
            name="ros2_vision",
            output="screen",
            parameters=parameters,
        ),
    ]


def generate_launch_description():
    pkg_share = get_package_share_directory("ros2_vision")
    params_file_default = os.path.join(pkg_share, "config", "vision.yaml")

    return LaunchDescription([
        DeclareLaunchArgument(
            "params_file",
            default_value=params_file_default,
            description="Path to ros2_vision parameter YAML.",
        ),
        DeclareLaunchArgument(
            "use_sim_time",
            default_value="false",
            description="Use simulation clock.",
        ),
        DeclareLaunchArgument(
            "runtime_params_file",
            default_value="",
            description="Optional runtime YAML override loaded last (timing/use_sim_time).",
        ),
        OpaqueFunction(function=launch_setup),
    ])
