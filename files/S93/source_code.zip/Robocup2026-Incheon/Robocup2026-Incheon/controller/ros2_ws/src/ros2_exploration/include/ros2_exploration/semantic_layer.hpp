#pragma once

#include "ros2_exploration/frontier_types.hpp"

namespace ros2_exploration
{

class SemanticLayer
{
public:
  void setEnabled(bool enabled);
  bool enabled() const;

  double scoreBias(const Frontier & frontier) const;

private:
  bool enabled_{false};
};

}  // namespace ros2_exploration
