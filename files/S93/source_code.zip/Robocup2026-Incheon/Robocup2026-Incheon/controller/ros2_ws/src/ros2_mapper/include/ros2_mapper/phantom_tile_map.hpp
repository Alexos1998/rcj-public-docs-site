#ifndef ROS2_MAPPER__PHANTOM_TILE_MAP_HPP_
#define ROS2_MAPPER__PHANTOM_TILE_MAP_HPP_

#include "ros2_mapper/tile_math.hpp"
#include "ros2_mapper/tile_semantics.hpp"

#include <rclcpp/time.hpp>

#include <array>
#include <cstddef>
#include <limits>
#include <unordered_map>

namespace ros2_mapper
{

enum class TileTemplateKind
{
  Unknown,
  Empty,
  WallNorth,
  WallEast,
  WallSouth,
  WallWest,
  CornerNE,
  CornerNW,
  CornerSE,
  CornerSW,
  HalfWall,
  Obstacle,
  UnknownOccupied,
  Curve1,
  Curve2,
  Curve3,
  Curve4,
  Area4GenericOccupied,
  Area4GenericFree
};

enum class TileQuadrant
{
  NW = 0,
  NE = 1,
  SW = 2,
  SE = 3
};

enum class SubtileIndex
{
  NW = 0,
  NE = 1,
  SW = 2,
  SE = 3
};

enum class PrimitiveKind
{
  Empty,
  EdgeNorth,
  EdgeEast,
  EdgeSouth,
  EdgeWest,
  Curve1,
  Curve2,
  Curve3,
  Curve4,
  Obstacle,
  UnknownOccupied
};

enum class CanonicalSegmentOrientation
{
  Horizontal,
  Vertical
};

struct CanonicalSegmentKey
{
  CanonicalSegmentOrientation orientation = CanonicalSegmentOrientation::Horizontal;
  int line = 0;
  int offset = 0;

  bool operator==(const CanonicalSegmentKey & other) const noexcept
  {
    return orientation == other.orientation &&
      line == other.line &&
      offset == other.offset;
  }
};

struct PhantomQuadrantEvidence
{
  int possible_rays = 0;
  int free_rays = 0;
  int hit_count = 0;
  double range_weight_sum = 0.0;
  double hit_range_weight_sum = 0.0;
  double free_range_weight_sum = 0.0;
  double min_observed_range = std::numeric_limits<double>::infinity();
  double max_observed_range = 0.0;
};

struct PhantomSupportBinEvidence
{
  int possible_count = 0;
  int free_count = 0;
  int hit_count = 0;
  double possible_weight_sum = 0.0;
  double free_weight_sum = 0.0;
  double hit_weight_sum = 0.0;
};

struct QuarterEdgeEvidence
{
  int possible_rays = 0;
  int hit_support = 0;
  int free_conflicts = 0;
  double possible_weight_sum = 0.0;
  double hit_score = 0.0;
  double free_conflict_score = 0.0;
  double visibility_score = 0.0;
  double raw_score = 0.0;
};

struct PrimitiveEvidence
{
  double log_odds = 0.0;
  double positive_score = 0.0;
  double negative_score = 0.0;
  double possible_weight_sum = 0.0;

  int possible_rays = 0;
  int hit_matches = 0;
  int pass_through_conflicts = 0;
  int occluded_rays = 0;

  double visibility_score = 0.0;
  double coverage_score = 0.0;
  double confidence = 0.0;

  rclcpp::Time last_seen;
};

constexpr int kSubtileCount = 4;
constexpr int kPrimitiveKindCount = 11;
constexpr int kObstacleGridBinsPerTile = 24;
constexpr int kObstacleGridMaxBinsPerTile = 48;
constexpr int kObstacleGridCellCount =
  kObstacleGridMaxBinsPerTile * kObstacleGridMaxBinsPerTile;

struct PhantomObstacleGridBinEvidence
{
  int hit_count = 0;
  int free_count = 0;
  double hit_score = 0.0;
  double free_score = 0.0;
  rclcpp::Time last_seen;
};

struct PhantomObstacleEvidence
{
  bool has_candidate = false;
  double center_local_x = 0.0;
  double center_local_y = 0.0;
  double width_m = 0.0;
  double length_m = 0.0;
  double hit_score = 0.0;
  double free_conflict_score = 0.0;
  double confidence = 0.0;
  double free_ratio = 0.0;
  double surrounding_free_ratio = 0.0;
  double wall_overlap_penalty = 0.0;
  double edge_proximity_penalty = 0.0;
  int cluster_bins = 0;
  int hit_count = 0;
  int free_conflicts = 0;
  rclcpp::Time last_seen;
};

struct SubtileEvidence
{
  std::array<PrimitiveEvidence, kPrimitiveKindCount> primitives;
};

enum class PhantomMaskKind
{
  Unknown,
  Empty,
  SingleSegment,
  TwoSegmentConnected,
  Area1North,
  Area1East,
  Area1South,
  Area1West,
  UnknownOccupied
};

struct PhantomMaskCandidate
{
  PhantomMaskKind kind = PhantomMaskKind::Unknown;
  std::array<bool, 12> segment_mask{};
  double raw_score = 0.0;
  double confidence = 0.0;
  double visibility = 0.0;
  double consistency = 0.0;
  int supported_segments = 0;
  int conflicting_segments = 0;
};

int quarterEdgeIndex(CanonicalSegmentKey key);
int primitiveIndex(PrimitiveKind kind);
int subtileIndex(SubtileIndex subtile);

struct PhantomTileEvidence
{
  TileCoord coord;
  TileArea area_hint = TileArea::Unknown;
  bool area_uncertain = true;
  TileTemplateKind best_template = TileTemplateKind::Unknown;
  double confidence = 0.0;
  double best_score = 0.0;
  double second_score = 0.0;
  double visibility_score = 0.0;
  double hit_score = 0.0;
  double free_score = 0.0;
  double conflict_score = 0.0;
  // Incremented per evidence update in B2; not a scan count.
  int observation_count = 0;
  rclcpp::Time first_seen;
  std::array<PhantomQuadrantEvidence, 4> quadrants;
  std::array<PhantomSupportBinEvidence, 16> support_bins;
  std::array<QuarterEdgeEvidence, 12> quarter_edges;
  std::array<SubtileEvidence, kSubtileCount> subtiles;
  std::array<PhantomObstacleGridBinEvidence, kObstacleGridCellCount> obstacle_grid;
  PhantomObstacleEvidence obstacle;
  PhantomMaskCandidate best_mask_candidate;
  PhantomMaskCandidate second_mask_candidate;
  int possible_rays_total = 0;
  int free_rays_total = 0;
  int hit_count_total = 0;
  double range_weight_sum_total = 0.0;
  rclcpp::Time last_seen;
};

class PhantomTileMap
{
public:
  PhantomTileEvidence & getOrCreate(
    const TileCoord & coord,
    const rclcpp::Time & stamp);

  const std::unordered_map<TileCoord, PhantomTileEvidence, TileCoordHash> & records() const;

  void configurePrimitiveLogOdds(
    double positive_update,
    double negative_update,
    double min_log_odds,
    double max_log_odds);

  void configureTemporalEvidence(
    double lidar_decay_half_life_s,
    double obstacle_decay_half_life_s,
    double positive_evidence_max,
    double negative_evidence_max);

  void recordPossibleRay(
    const TileCoord & coord,
    TileQuadrant quadrant,
    double range,
    double weight,
    const rclcpp::Time & stamp);

  void recordFreeRay(
    const TileCoord & coord,
    TileQuadrant quadrant,
    double range,
    double weight,
    const rclcpp::Time & stamp);

  void recordHit(
    const TileCoord & coord,
    TileQuadrant quadrant,
    double range,
    double weight,
    const rclcpp::Time & stamp);

  void recordSupportPossible(
    const TileCoord & coord,
    int bin_index,
    double range,
    double weight,
    const rclcpp::Time & stamp);

  void recordSupportFree(
    const TileCoord & coord,
    int bin_index,
    double range,
    double weight,
    const rclcpp::Time & stamp);

  void recordSupportHit(
    const TileCoord & coord,
    int bin_index,
    double range,
    double weight,
    const rclcpp::Time & stamp);

  void recordQuarterEdgePossible(
    const TileCoord & coord,
    CanonicalSegmentKey key,
    double weight,
    const rclcpp::Time & stamp);

  void recordQuarterEdgeHitSupport(
    const TileCoord & coord,
    CanonicalSegmentKey key,
    double score,
    const rclcpp::Time & stamp);

  void recordQuarterEdgeFreeConflict(
    const TileCoord & coord,
    CanonicalSegmentKey key,
    double score,
    const rclcpp::Time & stamp);

  void recordPrimitivePositive(
    const TileCoord & coord,
    SubtileIndex subtile,
    PrimitiveKind kind,
    double weight,
    const rclcpp::Time & stamp);

  void recordPrimitiveNegative(
    const TileCoord & coord,
    SubtileIndex subtile,
    PrimitiveKind kind,
    double weight,
    const rclcpp::Time & stamp);

  void recordPrimitivePossible(
    const TileCoord & coord,
    SubtileIndex subtile,
    PrimitiveKind kind,
    double weight,
    const rclcpp::Time & stamp);

  void recordPrimitiveOccluded(
    const TileCoord & coord,
    SubtileIndex subtile,
    PrimitiveKind kind,
    const rclcpp::Time & stamp);

  void recordObstacleGridHit(
    const TileCoord & coord,
    int bin_index,
    double score,
    const rclcpp::Time & stamp);

  void recordObstacleGridFree(
    const TileCoord & coord,
    int bin_index,
    double score,
    const rclcpp::Time & stamp);

  void decayObstacleGridTile(
    const TileCoord & coord,
    int bins_per_tile,
    const rclcpp::Time & stamp);

  void decayPrimitiveEvidenceTile(
    const TileCoord & coord,
    const rclcpp::Time & stamp);

  void recomputePrimitiveConfidence(
    const TileCoord & coord,
    SubtileIndex subtile,
    PrimitiveKind kind,
    int min_visibility_rays,
    int min_coverage_hits = 3);

  void recomputeQuarterEdgeScores(
    const TileCoord & coord,
    int min_visibility_rays,
    double hit_weight,
    double conflict_weight);

  void recomputeMaskCandidates(
    const TileCoord & coord,
    double supported_segment_min_score,
    double conflict_segment_max_score,
    double complexity_penalty,
    double unsupported_segment_penalty,
    double min_confidence);

  bool empty() const;
  std::size_t size() const;
  void clear();

private:
  void applyPrimitiveTemporalDecay(
    PrimitiveEvidence & primitive,
    const rclcpp::Time & stamp) const;

  void applyObstacleGridBinTemporalDecay(
    PhantomObstacleGridBinEvidence & bin,
    const rclcpp::Time & stamp) const;

  std::unordered_map<TileCoord, PhantomTileEvidence, TileCoordHash> records_;
  double primitive_positive_log_odds_update_ = 0.45;
  double primitive_negative_log_odds_update_ = 0.70;
  double primitive_log_odds_min_ = -4.0;
  double primitive_log_odds_max_ = 4.0;
  double lidar_evidence_decay_half_life_s_ = 8.0;
  double obstacle_temporal_decay_half_life_s_ = 6.0;
  double lidar_positive_evidence_max_ = 12.0;
  double lidar_negative_evidence_max_ = 12.0;
};

}  // namespace ros2_mapper

#endif  // ROS2_MAPPER__PHANTOM_TILE_MAP_HPP_
