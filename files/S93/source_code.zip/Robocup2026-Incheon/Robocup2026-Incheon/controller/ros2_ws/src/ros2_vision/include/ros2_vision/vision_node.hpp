#pragma once

#include <atomic>
#include <map>
#include <memory>
#include <thread>

#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include "ros2_vision/larc_vision_pipeline.hpp"
#include "ros2_vision/tcp_frame_server.hpp"

namespace ros2_vision {

class ResultLineServer;

class VisionNode : public rclcpp::Node {
public:
  VisionNode();
  ~VisionNode() override;

private:
  void workerLoop();
  void publishDebug(const std::string& text);
  void publishDetection(const VisionDetection& detection);
  void saveClassificationImage(const VisionFrame& frame, const VisionDetection& detection, double inference_ms) const;
  void saveVisionDebugImage(const VisionFrame& frame, const VisionDebugImage& debug) const;
  std::string detectionToJson(const VisionDetection& detection) const;
  std::string detectionToResultLine(const VisionDetection& detection) const;

  std::unique_ptr<TcpFrameServer> frame_server_;
  std::unique_ptr<ResultLineServer> result_server_;
  std::unique_ptr<LarcVisionPipeline> pipeline_;

  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr detections_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr debug_pub_;

  std::atomic<bool> running_{false};
  std::thread worker_;
  std::uint64_t worker_counter_ = 0;
  // Per-camera subsample counters. A single global counter combined with
  // strictly alternating cameras made process_every_n parity skip the same
  // camera every time; per-camera counters subsample each side independently.
  std::map<int, std::uint64_t> camera_frame_counter_;
  std::string classification_image_dir_;
  bool save_classification_images_ = true;
  bool save_rejected_images_ = true;
  int lidar_window_extra_rays_ = 1;
  int process_every_n_ = 2;
  double max_inference_ms_warn_ = 80.0;
};

}  // namespace ros2_vision
