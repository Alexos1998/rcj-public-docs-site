#include "ros2_exploration/blacklist.hpp"

#include <algorithm>
#include <cmath>

#include "rclcpp/duration.hpp"

namespace ros2_exploration
{

void Blacklist::configure(double radius_m, double duration_s, std::size_t max_entries)
{
  std::lock_guard<std::mutex> lock(mutex_);
  radius_m_ = std::max(0.0, radius_m);
  duration_s_ = std::max(0.0, duration_s);
  max_entries_ = std::max<std::size_t>(1, max_entries);
  trimLocked();
}

void Blacklist::add(
  const geometry_msgs::msg::Point & point,
  const rclcpp::Time & now,
  const std::string & reason)
{
  std::lock_guard<std::mutex> lock(mutex_);
  pruneExpiredLocked(now);

  BlacklistedGoal goal;
  goal.point = point;
  goal.expires_at = now + rclcpp::Duration::from_seconds(duration_s_);
  goal.reason = reason;
  goals_.push_back(goal);
  trimLocked();
}

bool Blacklist::contains(const geometry_msgs::msg::Point & point, const rclcpp::Time & now) const
{
  return match(point, now).has_value();
}

std::optional<BlacklistedGoal> Blacklist::match(
  const geometry_msgs::msg::Point & point,
  const rclcpp::Time & now) const
{
  std::lock_guard<std::mutex> lock(mutex_);
  for (const auto & goal : goals_) {
    if (goal.expires_at <= now) {
      continue;
    }
    if (distance2d(point, goal.point) <= radius_m_) {
      return goal;
    }
  }

  return std::nullopt;
}

void Blacklist::pruneExpired(const rclcpp::Time & now)
{
  std::lock_guard<std::mutex> lock(mutex_);
  pruneExpiredLocked(now);
}

void Blacklist::clear()
{
  std::lock_guard<std::mutex> lock(mutex_);
  goals_.clear();
}

std::size_t Blacklist::size() const
{
  std::lock_guard<std::mutex> lock(mutex_);
  return goals_.size();
}

std::vector<BlacklistedGoal> Blacklist::entries(const rclcpp::Time & now) const
{
  std::lock_guard<std::mutex> lock(mutex_);
  std::vector<BlacklistedGoal> active;
  active.reserve(goals_.size());

  for (const auto & goal : goals_) {
    if (goal.expires_at > now) {
      active.push_back(goal);
    }
  }

  return active;
}

double Blacklist::radius() const
{
  std::lock_guard<std::mutex> lock(mutex_);
  return radius_m_;
}

double Blacklist::duration() const
{
  std::lock_guard<std::mutex> lock(mutex_);
  return duration_s_;
}

std::size_t Blacklist::maxEntries() const
{
  std::lock_guard<std::mutex> lock(mutex_);
  return max_entries_;
}

double Blacklist::distance2d(
  const geometry_msgs::msg::Point & lhs,
  const geometry_msgs::msg::Point & rhs)
{
  return std::hypot(lhs.x - rhs.x, lhs.y - rhs.y);
}

void Blacklist::pruneExpiredLocked(const rclcpp::Time & now)
{
  goals_.erase(
    std::remove_if(
      goals_.begin(),
      goals_.end(),
      [&now](const BlacklistedGoal & goal) {
        return goal.expires_at <= now;
      }),
    goals_.end());
}

void Blacklist::trimLocked()
{
  while (goals_.size() > max_entries_) {
    goals_.erase(goals_.begin());
  }
}

}  // namespace ros2_exploration
