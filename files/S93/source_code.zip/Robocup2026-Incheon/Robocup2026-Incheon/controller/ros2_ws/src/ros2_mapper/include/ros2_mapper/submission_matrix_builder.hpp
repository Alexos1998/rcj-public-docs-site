#ifndef ROS2_MAPPER__SUBMISSION_MATRIX_BUILDER_HPP_
#define ROS2_MAPPER__SUBMISSION_MATRIX_BUILDER_HPP_

#include "ros2_mapper/tile_map.hpp"

#include <array>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace ros2_mapper
{

using SubmissionResolvedWalls =
  std::unordered_map<TileCoord, EdgeWalls, TileCoordHash>;

// Quarter tile inside a full tile.
//   NW NE
//   SW SE
enum class SubmissionSubtile
{
  NW = 0,
  NE = 1,
  SW = 2,
  SE = 3
};

// Local cell coordinate inside a tile's 5x5 block (row/col offsets 0..4).
struct MatrixCell
{
  int row = 0;
  int col = 0;
};

struct SubmissionSubtileModel
{
  bool wall_north = false;
  bool wall_east = false;
  bool wall_south = false;
  bool wall_west = false;

  // 0 = no curve; 1..4 correspond to the proto curveDir / PrimitiveKind::Curve1..Curve4.
  int curve_dir = 0;

  // Quarter tile semantic value: 0,2,3,4,5,b,p,r,g,o,y,* etc.
  std::string value = "0";
};

struct SubmissionVictimMark
{
  SubmissionSubtile subtile = SubmissionSubtile::NW;
  WallDirection wall = WallDirection::North;
  std::string code;  // H,S,U,F,P,C,O
};

struct SubmissionTileModel
{
  TileCoord coord;
  TileArea area = TileArea::Unknown;
  bool area_uncertain = true;
  bool area4_wildcard = false;
  // Transition tile whose transition involves Area 4 (an entrance/exit of the
  // wildcard room). Used to seed the Area 4 flood fill.
  bool area4_gateway = false;
  bool committed = false;

  std::array<SubmissionSubtileModel, 4> subtiles;
  std::vector<SubmissionVictimMark> victims;

  // Tile-level obstacle from the RF model (per 0.12 m tile). Wired but NOT yet
  // emitted to the matrix; see the commented 'x' block in build().
  bool obstacle = false;

  double score = 0.0;
  double confidence = 0.0;
};

using SubmissionResolvedTileModels =
  std::unordered_map<TileCoord, SubmissionTileModel, TileCoordHash>;

using SubmissionArea4Mask = std::unordered_set<TileCoord, TileCoordHash>;

struct SubmissionMatrixResult
{
  // Token matrix. Each cell is a string so victim cells may hold multiple codes.
  std::vector<std::vector<std::string>> cells;

  int min_x = 0;
  int max_x = 0;
  int min_y = 0;
  int max_y = 0;

  int tile_width = 0;
  int tile_height = 0;
};

struct SubmissionArea4ExpansionStats
{
  int candidate_edges = 0;
  int promoted_tiles = 0;
  int rejected_by_wall = 0;
  int rejected_missing_model = 0;
  int rejected_non_soft = 0;
};

class SubmissionMatrixBuilder
{
public:
  // Backward-compatible full-tile path (EdgeWalls only).
  SubmissionMatrixResult build(
    const TileMap & tile_map,
    const SubmissionResolvedWalls * resolved_walls = nullptr) const;

  // Resolved subtile-model path (walls, curves, victims, area 4, transitions).
  SubmissionMatrixResult build(
    const TileMap & tile_map,
    const SubmissionResolvedTileModels & resolved_models) const;

  static std::string toText(const SubmissionMatrixResult & result);

  // Builds the final Area 4 submission mask from resolved models. This mask is
  // independent from physical visitation: any model promoted to Area 4 wildcard
  // is emitted as '*', including its border cells.
  static SubmissionArea4Mask buildArea4Mask(
    const SubmissionResolvedTileModels & models);

  static bool isArea4SubmissionCell(
    const SubmissionResolvedTileModels & models,
    const TileCoord & coord);

  // Promotes already-observed, uncommitted, semantics-free models connected to
  // known Area 4 wildcard evidence. It does not create new tiles; it only
  // reclassifies information the mapper already observed.
  static int promoteConnectedArea4ObservedTiles(
    SubmissionResolvedTileModels & models,
    SubmissionArea4ExpansionStats * stats = nullptr);

  // Applies Area 4 '*' cells after geometry conversion and before final text
  // serialization. Returns the number of matrix cells changed to '*'.
  static int applyArea4StarsToSubmissionMatrix(
    SubmissionMatrixResult & result,
    const SubmissionArea4Mask & area4_mask);

  // Fills the unknown interior of Area 4 with wildcard tiles. Seeds are the
  // known Area 4 tiles plus the Area 4 gateways (entrance/exit transitions);
  // it only runs when at least two gateways are known (entrance AND exit) and
  // never extrapolates: the 4-connected fill is clamped to the bounding box of
  // the existing Area 4 evidence and only creates tiles for coordinates that
  // have no resolved model yet (known tiles of other areas block the fill).
  // Returns the number of wildcard tiles added.
  static int applyArea4FloodFill(
    SubmissionResolvedTileModels & models,
    SubmissionArea4ExpansionStats * stats = nullptr);

  // Official quarter-center semantic value for a tile (area4 '*', start '5',
  // hole '2', swamp '3', checkpoint '4', transition code, else '0'). Public so
  // the runtime model builder can reuse the exact same precedence rules.
  static std::string tileValue(const TileRecord & record);

  // --- Matrix-coordinate helpers (local 5x5 block offsets) ---
  static MatrixCell quarterCenterCell(SubmissionSubtile subtile);
  static MatrixCell edgeCell(SubmissionSubtile subtile, WallDirection dir);
  static std::array<MatrixCell, 2> edgeVertices(
    SubmissionSubtile subtile, WallDirection dir);

  // The two perpendicular edges a curve connects, and the rounded corner vertex.
  static std::array<WallDirection, 2> curveEdgeDirections(int curve_dir);
  static MatrixCell curveSuppressedVertex(SubmissionSubtile subtile, int curve_dir);

private:
  static char transitionValue(const TransitionInfo & transition);
  static char transitionValueFromFloorColor(FloorColorClass color);
  static bool isWall(WallState state);

  static const EdgeWalls * resolvedWallsForTile(
    const SubmissionResolvedWalls * resolved_walls,
    const TileCoord & coord);
};

}  // namespace ros2_mapper

#endif  // ROS2_MAPPER__SUBMISSION_MATRIX_BUILDER_HPP_
