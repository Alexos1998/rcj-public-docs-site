#pragma once

#include <string>

#include <opencv2/core.hpp>
#include <opencv2/ml.hpp>

namespace ros2_vision {

// Whole-target binary segmenter backed by an OpenCV cv::ml::RTrees model
// (exported from the notebooks by export_controller_runtime_assets.py). Runs in
// pure C++ -- no Python / sklearn / joblib at runtime. The 13 per-pixel features
// must match notebooks/common/target_mask_rf.py exactly.
class TargetMaskRF {
public:
  static constexpr int kNumFeatures = 13;

  TargetMaskRF() = default;

  // Load the RTrees YAML and (optionally) the feature schema YAML. Returns false
  // and leaves loaded()==false on any failure -- the caller logs and falls back.
  bool load(const std::string& model_path, const std::string& feature_config_path = "");

  bool loaded() const { return rtrees_ && rtrees_->isTrained(); }

  // Predict a binary mask (255 = target, 0 = background) at the model input size,
  // resized back to the input image size. Empty Mat if not loaded.
  cv::Mat predictMask(const cv::Mat& bgr) const;

  // Same, also returning the mean RTrees vote agreement over predicted pixels.
  cv::Mat predictMask(const cv::Mat& bgr, float& mask_confidence) const;

  int inputWidth() const { return input_width_; }
  int inputHeight() const { return input_height_; }

  // Exposed for the cross-language parity test. Returns an (W*H, 13) CV_32F matrix
  // in row-major (y*W + x) order, computed on the RGB image.
  static cv::Mat extractPixelFeatures(const cv::Mat& bgr, int width, int height);

private:
  cv::Ptr<cv::ml::RTrees> rtrees_;
  int input_width_ = 64;
  int input_height_ = 64;
  bool morph_close_ = true;
};

}  // namespace ros2_vision
