#include "ros2_exploration/frontier_scorer.hpp"

#include <algorithm>
#include <cmath>

namespace ros2_exploration
{

FrontierScorer::FrontierScorer(FrontierScoringWeights weights)
: weights_(weights)
{
}

FrontierScorer::FrontierScorer(double size_weight, double distance_weight)
{
  weights_.size_gain = size_weight;
  weights_.distance_cost = distance_weight;
}

void FrontierScorer::setWeights(const FrontierScoringWeights & weights)
{
  weights_ = weights;
}

const FrontierScoringWeights & FrontierScorer::weights() const
{
  return weights_;
}

FrontierScoreBreakdown FrontierScorer::score(
  const Frontier & frontier,
  const geometry_msgs::msg::Pose & robot_pose,
  const geometry_msgs::msg::Point & goal_point,
  bool near_recent_goal,
  bool blacklisted) const
{
  FrontierScoreBreakdown breakdown;
  breakdown.information_gain = estimateInformationGain(frontier);
  breakdown.frontier_size = static_cast<double>(frontier.cells.size());
  breakdown.distance_m = distance2d(robot_pose, goal_point);
  breakdown.absolute_heading_change_rad = absoluteHeadingChange(robot_pose, goal_point);
  breakdown.recent_goal_penalty = near_recent_goal ? weights_.recent_goal_penalty : 0.0;
  breakdown.blacklist_penalty = blacklisted ? weights_.blacklist_penalty : 0.0;
  breakdown.score =
    weights_.information_gain * breakdown.information_gain +
    weights_.size_gain * breakdown.frontier_size -
    weights_.distance_cost * breakdown.distance_m -
    weights_.heading_change_cost * breakdown.absolute_heading_change_rad -
    breakdown.recent_goal_penalty -
    breakdown.blacklist_penalty;
  return breakdown;
}

double FrontierScorer::estimateInformationGain(const Frontier & frontier)
{
  return static_cast<double>(frontier.cells.size());
}

double FrontierScorer::distance2d(
  const geometry_msgs::msg::Pose & pose,
  const geometry_msgs::msg::Point & point)
{
  return std::hypot(point.x - pose.position.x, point.y - pose.position.y);
}

double FrontierScorer::yawFromPose(const geometry_msgs::msg::Pose & pose)
{
  const auto & q = pose.orientation;
  const double siny_cosp = 2.0 * (q.w * q.z + q.x * q.y);
  const double cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z);
  return std::atan2(siny_cosp, cosy_cosp);
}

double FrontierScorer::normalizeAngle(double angle)
{
  constexpr double pi = 3.14159265358979323846;
  while (angle > pi) {
    angle -= 2.0 * pi;
  }
  while (angle < -pi) {
    angle += 2.0 * pi;
  }
  return angle;
}

double FrontierScorer::absoluteHeadingChange(
  const geometry_msgs::msg::Pose & robot_pose,
  const geometry_msgs::msg::Point & goal_point)
{
  const double robot_yaw = yawFromPose(robot_pose);
  const double goal_yaw = std::atan2(
    goal_point.y - robot_pose.position.y,
    goal_point.x - robot_pose.position.x);
  return std::abs(normalizeAngle(goal_yaw - robot_yaw));
}

}  // namespace ros2_exploration
