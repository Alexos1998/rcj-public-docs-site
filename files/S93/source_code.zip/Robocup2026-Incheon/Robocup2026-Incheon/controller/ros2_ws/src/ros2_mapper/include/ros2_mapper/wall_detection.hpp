#ifndef ROS2_MAPPER__WALL_DETECTION_HPP_
#define ROS2_MAPPER__WALL_DETECTION_HPP_

#include <rclcpp/time.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <visualization_msgs/msg/marker_array.hpp>

#include <cstddef>
#include <cstdint>
#include <limits>
#include <string>
#include <unordered_map>
#include <vector>

namespace ros2_mapper
{

enum class WallShape : uint8_t
{
  Straight = 0,
  Arc = 1
};

enum class WallAxis : uint8_t
{
  Horizontal = 0,
  Vertical = 1
};

struct Pose2D
{
  double x = 0.0;
  double y = 0.0;
  double yaw = 0.0;
};

struct SegmentEndpoints
{
  double ax = 0.0;
  double ay = 0.0;
  double bx = 0.0;
  double by = 0.0;
};

// Canonical straight wall segment key:
// - Horizontal: edge_j indexes a horizontal tile boundary line in y,
//   edge_i indexes the tile column in x, sub=0 west half, sub=1 east half.
// - Vertical: edge_i indexes a vertical tile boundary line in x,
//   edge_j indexes the tile row in y, sub=0 south half, sub=1 north half.
// Boundary line coordinate is origin + (edge_index - 0.5) * tile_size.
// This makes a shared wall boundary use the same key from either adjacent tile.
struct WallSegmentKey
{
  WallShape shape = WallShape::Straight;
  WallAxis axis = WallAxis::Horizontal;

  int edge_i = 0;
  int edge_j = 0;

  uint8_t sub = 0;
  uint8_t aux = 0;

  bool operator==(const WallSegmentKey & other) const noexcept;
};

struct WallSegmentKeyHash
{
  std::size_t operator()(const WallSegmentKey & key) const noexcept;
};

struct WallEvidence
{
  float log_odds = 0.0f;

  uint8_t hit_bin_mask = 0u;
  uint8_t free_bin_mask = 0u;

  uint16_t occ_supports = 0u;
  uint16_t free_supports = 0u;

  float best_p25_error_m = std::numeric_limits<float>::infinity();

  rclcpp::Time first_seen{};
  rclcpp::Time last_seen{};

  bool phantom_occ = false;
  bool phantom_free = false;
  bool confirmed_occ = false;
  bool confirmed_free = false;
};

using WallEvidenceMap =
  std::unordered_map<WallSegmentKey, WallEvidence, WallSegmentKeyHash>;

struct WallDetectionConfig
{
  double origin_x = 0.0;
  double origin_y = 0.0;

  double tile_size_m = 0.12;
  double segment_length_m = 0.06;
  double support_bin_size_m = 0.03;

  double phantom_marker_z = 0.045;
  double phantom_marker_thickness = 0.008;
  double phantom_marker_alpha = 0.40;

  double phantom_occ_threshold = 1.2;
  double phantom_free_threshold = -0.8;

  double snap_perp_tolerance_m = 0.012;
  double endpoint_guard_m = 0.006;

  int hit_min_points_per_scan = 2;
  double hit_error_percentile = 0.25;
  double hit_logodds_inc = 1.0;

  double min_pose_delta_m = 0.015;
  double min_pose_delta_yaw_rad = 0.12;

  double logodds_min = -4.0;
  double logodds_max = 4.0;

  int candidate_tile_radius = 1;
};

struct SegmentProjection
{
  WallSegmentKey key;
  double t = 0.0;
  double distance_m = 0.0;
  uint8_t bin_mask = 0u;
  bool accepted = false;
};

struct SegmentScanStats
{
  std::vector<double> hit_errors;
  uint8_t hit_bin_mask = 0u;
};

class WallDetection
{
public:
  explicit WallDetection(WallDetectionConfig config);

  void setConfig(WallDetectionConfig config);
  void reset();

  const WallEvidenceMap & evidence() const noexcept;

  void integrateScan(
    const sensor_msgs::msg::LaserScan & scan,
    const Pose2D & sensor_pose_odom,
    const rclcpp::Time & stamp);

  std::vector<WallSegmentKey> enumerateTileSegments(int tile_x, int tile_y) const;

  std::vector<WallSegmentKey> enumerateCandidateSegmentsAroundPoint(
    double x,
    double y,
    int tile_radius) const;

  SegmentEndpoints segmentEndpoints(const WallSegmentKey & key) const;

  visualization_msgs::msg::MarkerArray buildPhantomMarkers(
    const std::string & frame_id,
    const rclcpp::Time & stamp) const;

private:
  static double normalizeAngle(double angle);
  static double percentile(std::vector<double> values, double p);

  WallDetectionConfig config_;
  WallEvidenceMap evidence_;
  bool has_last_integrated_pose_ = false;
  Pose2D last_integrated_pose_;
};

}  // namespace ros2_mapper

#endif  // ROS2_MAPPER__WALL_DETECTION_HPP_
