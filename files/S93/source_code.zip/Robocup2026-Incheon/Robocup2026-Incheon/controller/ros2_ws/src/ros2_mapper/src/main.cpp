#include "ros2_mapper/mapper_node.hpp"

#include <rclcpp/rclcpp.hpp>

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<ros2_mapper::MapperNode>());
  rclcpp::shutdown();
  return 0;
}
