#include "ros2_mapper/tile_math.hpp"

#include <cmath>
#include <cstdio>

namespace
{

int g_failures = 0;

#define CHECK(cond) \
  do { \
    if (!(cond)) { \
      ++g_failures; \
      std::printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); \
    } \
  } while (0)

void testRedLogBoundaryReassociationCandidate()
{
  constexpr double origin_x = -0.0047;
  constexpr double origin_y = -0.0008;
  constexpr double tile_size = 0.12;
  constexpr double margin = 0.006;

  const auto raw = ros2_mapper::computeTileCoord(
    0.3629, 0.2984, origin_x, origin_y, tile_size);
  CHECK(raw == (ros2_mapper::TileCoord{3, 2}));

  const auto neighbors = ros2_mapper::adjacentTileCoordsNearBoundary(
    raw, 0.3629, 0.2984, origin_x, origin_y, tile_size, margin);

  CHECK(neighbors.size() == 1);
  CHECK(neighbors[0] == (ros2_mapper::TileCoord{3, 3}));
}

void testObservationAwayFromBoundaryHasNoCandidates()
{
  constexpr double origin_x = -0.0047;
  constexpr double origin_y = -0.0008;
  constexpr double tile_size = 0.12;
  constexpr double margin = 0.006;

  const auto raw = ros2_mapper::computeTileCoord(
    0.3445, 0.3350, origin_x, origin_y, tile_size);
  const auto neighbors = ros2_mapper::adjacentTileCoordsNearBoundary(
    raw, 0.3445, 0.3350, origin_x, origin_y, tile_size, margin);

  CHECK(raw == (ros2_mapper::TileCoord{3, 3}));
  CHECK(neighbors.empty());
}

void testCornerCanExposeTwoNeighbors()
{
  constexpr double origin = 0.0;
  constexpr double tile_size = 0.12;
  constexpr double margin = 0.006;

  const ros2_mapper::TileCoord raw{0, 0};
  const auto neighbors = ros2_mapper::adjacentTileCoordsNearBoundary(
    raw, 0.059, -0.059, origin, origin, tile_size, margin);

  CHECK(neighbors.size() == 2);
  CHECK(neighbors[0] == (ros2_mapper::TileCoord{1, 0}));
  CHECK(neighbors[1] == (ros2_mapper::TileCoord{0, -1}));
}

void testBlackHoleLogProjectsAcrossWestBoundary()
{
  constexpr double origin_x = -0.0049;
  constexpr double origin_y = -0.0006;
  constexpr double tile_size = 0.12;
  constexpr double margin = 0.012;

  const auto raw = ros2_mapper::computeTileCoord(
    0.8972, 0.3579, origin_x, origin_y, tile_size);
  const auto neighbors = ros2_mapper::adjacentTileCoordsNearBoundary(
    raw, 0.8972, 0.3579, origin_x, origin_y, tile_size, margin);

  CHECK(raw == (ros2_mapper::TileCoord{8, 3}));
  CHECK(neighbors.size() == 1);
  CHECK(neighbors[0] == (ros2_mapper::TileCoord{7, 3}));
}

void testLegacyHoleDetectionProjectsToTileAhead()
{
  constexpr double origin_x = 0.0;
  constexpr double origin_y = 0.0;
  constexpr double tile_size = 0.12;
  constexpr double projection_distance = 0.06;
  constexpr double robot_x = 0.055;
  constexpr double robot_y = 0.0;
  constexpr double yaw = 0.0;

  const auto robot = ros2_mapper::computeTileCoord(
    robot_x, robot_y, origin_x, origin_y, tile_size);
  const auto hole = ros2_mapper::computeTileCoord(
    robot_x + std::cos(yaw) * projection_distance,
    robot_y + std::sin(yaw) * projection_distance,
    origin_x,
    origin_y,
    tile_size);

  CHECK(robot == (ros2_mapper::TileCoord{0, 0}));
  CHECK(hole == (ros2_mapper::TileCoord{1, 0}));
}

void testOppositeTileCrossing()
{
  const ros2_mapper::TileCoord transition{2, 3};

  CHECK(ros2_mapper::areOppositeTileNeighbors(
      transition,
      ros2_mapper::TileCoord{2, 4},
      ros2_mapper::TileCoord{2, 2}));
  CHECK(!ros2_mapper::areOppositeTileNeighbors(
      transition,
      ros2_mapper::TileCoord{2, 4},
      ros2_mapper::TileCoord{2, 4}));
  CHECK(!ros2_mapper::areOppositeTileNeighbors(
      transition,
      ros2_mapper::TileCoord{2, 4},
      ros2_mapper::TileCoord{3, 3}));
}

}  // namespace

int main()
{
  testRedLogBoundaryReassociationCandidate();
  testObservationAwayFromBoundaryHasNoCandidates();
  testCornerCanExposeTwoNeighbors();
  testBlackHoleLogProjectsAcrossWestBoundary();
  testLegacyHoleDetectionProjectsToTileAhead();
  testOppositeTileCrossing();

  if (g_failures == 0) {
    std::printf("All tile math tests passed\n");
  }
  return g_failures == 0 ? 0 : 1;
}
