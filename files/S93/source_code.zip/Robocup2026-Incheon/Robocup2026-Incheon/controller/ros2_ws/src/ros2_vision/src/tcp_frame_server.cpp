#include "ros2_vision/tcp_frame_server.hpp"

#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cerrno>
#include <chrono>
#include <cstring>
#include <iostream>
#include <vector>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

namespace ros2_vision {

TcpFrameServer::TcpFrameServer(std::string host, int port, std::size_t recv_buffer_bytes)
  : host_(std::move(host)), port_(port), recv_buffer_bytes_(recv_buffer_bytes)
{
}

TcpFrameServer::~TcpFrameServer()
{
  stop();
}

bool TcpFrameServer::start()
{
  if (running_.exchange(true)) {
    return true;
  }

  listen_fd_ = socket(AF_INET, SOCK_STREAM, 0);
  if (listen_fd_ < 0) {
    running_ = false;
    return false;
  }

  int yes = 1;
  setsockopt(listen_fd_, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));

  sockaddr_in addr{};
  addr.sin_family = AF_INET;
  addr.sin_port = htons(static_cast<std::uint16_t>(port_));
  if (inet_pton(AF_INET, host_.c_str(), &addr.sin_addr) != 1) {
    addr.sin_addr.s_addr = INADDR_ANY;
  }

  if (bind(listen_fd_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) != 0) {
    closeListenSocket();
    running_ = false;
    return false;
  }

  if (listen(listen_fd_, 1) != 0) {
    closeListenSocket();
    running_ = false;
    return false;
  }

  thread_ = std::thread(&TcpFrameServer::run, this);
  return true;
}

void TcpFrameServer::stop()
{
  running_ = false;
  closeListenSocket();
  if (thread_.joinable()) {
    thread_.join();
  }
}

void TcpFrameServer::closeListenSocket()
{
  if (listen_fd_ >= 0) {
    shutdown(listen_fd_, SHUT_RDWR);
    close(listen_fd_);
    listen_fd_ = -1;
  }
}

bool TcpFrameServer::getLatestFrame(VisionFrame& out)
{
  std::lock_guard<std::mutex> lock(mutex_);

  // Collect cameras with an unconsumed frame. std::map iterates in ascending
  // camera_id order, so we can round-robin by picking the first id strictly
  // greater than the last-served cursor (wrapping to the smallest otherwise).
  int chosen = -1;
  for (const auto& entry : cameras_) {
    const CameraSlot& slot = entry.second;
    if (!slot.has || slot.generation == slot.consumed) {
      continue;
    }
    if (chosen < 0) {
      chosen = entry.first;  // smallest pending id (wrap-around fallback)
    }
    if (entry.first > round_robin_cursor_) {
      chosen = entry.first;
      break;
    }
  }

  if (chosen < 0) {
    return false;
  }

  CameraSlot& slot = cameras_[chosen];
  out = slot.frame;
  out.bgr = slot.frame.bgr.clone();
  slot.consumed = slot.generation;
  round_robin_cursor_ = chosen;
  return true;
}

void TcpFrameServer::run()
{
  while (running_) {
    sockaddr_in client_addr{};
    socklen_t len = sizeof(client_addr);
    const int client_fd = accept(listen_fd_, reinterpret_cast<sockaddr*>(&client_addr), &len);
    if (client_fd < 0) {
      if (running_) {
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
      }
      continue;
    }

    int flag = 1;
    setsockopt(client_fd, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag));
    if (recv_buffer_bytes_ > 0) {
      int bytes = static_cast<int>(recv_buffer_bytes_);
      setsockopt(client_fd, SOL_SOCKET, SO_RCVBUF, &bytes, sizeof(bytes));
    }

    while (running_) {
      if (!readOneFrame(client_fd)) {
        break;
      }
    }

    shutdown(client_fd, SHUT_RDWR);
    close(client_fd);
  }
}

bool TcpFrameServer::readExact(int fd, void* data, std::size_t size)
{
  auto* out = static_cast<std::uint8_t*>(data);
  std::size_t total = 0;
  while (total < size && running_) {
    const ssize_t n = recv(fd, out + total, size - total, 0);
    if (n > 0) {
      total += static_cast<std::size_t>(n);
      continue;
    }
    if (n == 0) {
      return false;
    }
    if (errno == EINTR) {
      continue;
    }
    return false;
  }
  return total == size;
}

bool TcpFrameServer::readOneFrame(int client_fd)
{
  VisionFrameHeader header{};
  if (!readExact(client_fd, &header, sizeof(header))) {
    return false;
  }

  if (header.magic != kVisionFrameMagic ||
      header.version != kVisionFrameVersion ||
      header.header_size < sizeof(VisionFrameHeader) ||
      header.width == 0 ||
      header.height == 0 ||
      header.lidar_count > kMaxLidarCount ||
      header.image_bytes == 0 ||
      header.image_bytes > kMaxImageBytes) {
    return false;
  }

  if (header.header_size > sizeof(VisionFrameHeader)) {
    std::vector<std::uint8_t> extra(header.header_size - sizeof(VisionFrameHeader));
    if (!readExact(client_fd, extra.data(), extra.size())) {
      return false;
    }
  }

  std::vector<float> ranges(header.lidar_count);
  if (!ranges.empty() &&
      !readExact(client_fd, ranges.data(), ranges.size() * sizeof(float))) {
    return false;
  }

  std::vector<std::uint8_t> image(header.image_bytes);
  if (!readExact(client_fd, image.data(), image.size())) {
    return false;
  }

  VisionFrame frame;
  if (!decodeFrame(header, ranges, image, frame)) {
    return true;
  }

  {
    const int camera_id = frame.camera_id;
    std::lock_guard<std::mutex> lock(mutex_);
    CameraSlot& slot = cameras_[camera_id];
    slot.frame = std::move(frame);
    ++slot.generation;
    slot.has = true;
  }
  ++received_frames_;
  return true;
}

bool TcpFrameServer::decodeFrame(const VisionFrameHeader& header,
                                 const std::vector<float>& ranges,
                                 const std::vector<std::uint8_t>& image,
                                 VisionFrame& out)
{
  const int width = static_cast<int>(header.width);
  const int height = static_cast<int>(header.height);

  if (header.encoding == kEncodingBgr8) {
    const std::size_t expected = static_cast<std::size_t>(width) * height * 3u;
    if (image.size() != expected) {
      return false;
    }
    out.bgr = cv::Mat(height, width, CV_8UC3, const_cast<std::uint8_t*>(image.data())).clone();
  } else if (header.encoding == kEncodingBgra8) {
    const std::size_t expected = static_cast<std::size_t>(width) * height * 4u;
    if (image.size() != expected) {
      return false;
    }
    cv::Mat bgra(height, width, CV_8UC4, const_cast<std::uint8_t*>(image.data()));
    cv::cvtColor(bgra, out.bgr, cv::COLOR_BGRA2BGR);
  } else if (header.encoding == kEncodingJpeg) {
    out.bgr = cv::imdecode(image, cv::IMREAD_COLOR);
    if (out.bgr.empty()) {
      return false;
    }
  } else {
    return false;
  }

  out.seq = header.seq;
  out.stamp_s = header.stamp_s;
  out.camera_id = static_cast<int>(header.camera_id);
  out.camera_name = cameraName(out.camera_id);
  out.scan = ranges;
  out.lidar_angle_min = header.lidar_angle_min;
  out.lidar_angle_increment = header.lidar_angle_increment;
  out.lidar_range_min = header.lidar_range_min;
  out.lidar_range_max = header.lidar_range_max;
  out.camera_hfov_rad = header.camera_hfov_rad;
  out.camera_vfov_rad = header.camera_vfov_rad;
  out.camera_yaw_offset_rad = header.camera_yaw_offset_rad;
  out.robot_x = header.robot_x;
  out.robot_y = header.robot_y;
  out.robot_yaw = header.robot_yaw;
  out.tile_x = header.tile_x;
  out.tile_y = header.tile_y;
  return true;
}

}  // namespace ros2_vision
