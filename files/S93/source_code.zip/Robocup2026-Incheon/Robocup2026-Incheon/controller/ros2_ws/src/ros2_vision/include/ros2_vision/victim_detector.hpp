#pragma once

#include <memory>

#include "ros2_vision/onnx_runner.hpp"
#include "ros2_vision/vision_protocol.hpp"

namespace ros2_vision {

class VictimDetector {
public:
  struct Config {
    float min_confidence = 0.65f;
    bool reject_fake = true;
    float fake_min_confidence = 0.90f;
    float crop_padding = 0.05f;
    // Classify the whole frame instead of the predicted bbox crop. victim_cls was
    // trained on full 64x64 victim frames, so the tight runtime crop is
    // out-of-distribution and collapses the classifier (measured: full-frame 0.94
    // vs bbox-crop 0.66 on the test split). The bbox is still used for the
    // center/localization; only the classifier input changes.
    bool classify_full_frame = true;
  };

  VictimDetector(std::shared_ptr<OnnxRunner> bbox_runner,
                 std::shared_ptr<OnnxRunner> cls_runner,
                 Config config);

  VictimResult detect(const cv::Mat& bgr);

private:
  cv::Rect decodeBbox(const std::vector<float>& output, const cv::Size& size) const;
  cv::Rect paddedCropRect(const cv::Rect& bbox, const cv::Size& size) const;
  std::pair<std::string, float> decodeClass(const std::vector<float>& output) const;

  std::shared_ptr<OnnxRunner> bbox_runner_;
  std::shared_ptr<OnnxRunner> cls_runner_;
  Config config_;
};

}  // namespace ros2_vision
