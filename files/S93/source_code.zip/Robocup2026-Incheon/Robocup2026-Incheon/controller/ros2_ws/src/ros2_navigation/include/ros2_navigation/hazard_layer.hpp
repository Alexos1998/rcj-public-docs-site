#pragma once

#include <mutex>
#include <optional>
#include <string>
#include <unordered_map>

#include <nav2_costmap_2d/layer.hpp>
#include <nav2_costmap_2d/layered_costmap.hpp>
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>
#include <visualization_msgs/msg/marker_array.hpp>

#include <nlohmann/json.hpp>

namespace ros2_navigation
{

struct TileCoord
{
  int x = 0;
  int y = 0;

  bool operator==(const TileCoord & other) const
  {
    return x == other.x && y == other.y;
  }
};

struct TileCoordHash
{
  std::size_t operator()(const TileCoord & coord) const noexcept
  {
    const auto hx = std::hash<int>{}(coord.x);
    const auto hy = std::hash<int>{}(coord.y);
    return hx ^ (hy + 0x9e3779b9U + (hx << 6U) + (hx >> 2U));
  }
};

class HazardLayer : public nav2_costmap_2d::Layer
{
public:
  HazardLayer() = default;

  void onInitialize() override;
  void updateBounds(
    double robot_x,
    double robot_y,
    double robot_yaw,
    double * min_x,
    double * min_y,
    double * max_x,
    double * max_y) override;
  void updateCosts(
    nav2_costmap_2d::Costmap2D & master_grid,
    int min_i,
    int min_j,
    int max_i,
    int max_j) override;
  void reset() override;
  bool isClearable() override { return false; }

private:
  struct HazardRecord
  {
    std::string hazard_type = "black_hole";
    double confidence = 1.0;
    rclcpp::Time last_seen;
    int hit_count = 0;
  };

  void hazardEventCallback(std_msgs::msg::String::SharedPtr msg);
  void semanticMapCallback(std_msgs::msg::String::SharedPtr msg);

  bool isBlockingHazardEvent(const nlohmann::json & payload, std::string * hazard_type, double * confidence) const;
  std::optional<TileCoord> resolveHazardTile(const nlohmann::json & payload) const;
  std::optional<TileCoord> parseTileValue(const nlohmann::json & value) const;
  std::optional<TileCoord> parseTileField(const nlohmann::json & payload, const char * field) const;
  void blockTile(const TileCoord & tile, const std::string & hazard_type, double confidence, const std::string & reason);
  void publishMarkers();
  TileCoord worldToTile(double wx, double wy) const;
  void tileBounds(const TileCoord & tile, double * min_x, double * min_y, double * max_x, double * max_y) const;
  std::string tileToString(const TileCoord & tile) const;
  std::string lowerAscii(std::string text) const;
  std::string jsonStringField(const nlohmann::json & payload, const char * field) const;
  std::string jsonNestedStringField(
    const nlohmann::json & payload,
    const char * object_field,
    const char * nested_field) const;
  double jsonNumberField(const nlohmann::json & payload, const char * field, double fallback) const;
  double hazardConfidenceFromPayload(const nlohmann::json & payload) const;
  bool isConfirmedEventName(const std::string & event) const;
  bool isHazardTypeName(const std::string & hazard_type) const;

  mutable std::mutex mutex_;
  std::unordered_map<TileCoord, HazardRecord, TileCoordHash> hazard_tiles_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr hazard_events_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr semantic_map_sub_;
  rclcpp::Publisher<visualization_msgs::msg::MarkerArray>::SharedPtr marker_pub_;

  bool enabled_ = true;
  bool subscribe_semantic_map_ = true;
  bool block_suspected_ = false;
  double confidence_threshold_ = 0.70;
  double tile_size_m_ = 0.12;
  double tile_origin_x_ = 0.0;
  double tile_origin_y_ = 0.0;
  double tile_padding_m_ = 0.0;
  unsigned char hazard_cost_ = 254U;
  std::string hazard_events_topic_ = "/mapper/events";
  std::string semantic_map_topic_ = "/mapper/tile_semantic_map";
  std::string marker_topic_ = "/nav2/hazard_layer/markers";
  std::string marker_frame_ = "map";
};

}  // namespace ros2_navigation
