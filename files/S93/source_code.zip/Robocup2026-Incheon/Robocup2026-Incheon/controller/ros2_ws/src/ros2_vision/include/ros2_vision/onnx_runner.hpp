#pragma once

#include <array>
#include <memory>
#include <string>
#include <vector>

#include <onnxruntime_cxx_api.h>
#include <opencv2/core.hpp>

namespace ros2_vision {

class OnnxRunner {
public:
  struct Options {
    int input_width = 64;
    int input_height = 64;
    bool normalize_01 = true;
    bool normalize_mean_std = true;
    bool bgr_to_rgb = true;
    std::array<float, 3> mean{{0.485f, 0.456f, 0.406f}};
    std::array<float, 3> stdev{{0.229f, 0.224f, 0.225f}};
  };

  explicit OnnxRunner(const std::string& path);
  OnnxRunner(const std::string& path, Options options);

  std::vector<float> run(const cv::Mat& bgr);
  bool valid() const { return session_ != nullptr; }

private:
  void initialize(const std::string& path);
  std::vector<float> preprocess(const cv::Mat& bgr) const;

  Options options_;
  Ort::SessionOptions session_options_;
  std::unique_ptr<Ort::Session> session_;
  std::vector<std::string> input_names_storage_;
  std::vector<std::string> output_names_storage_;
  std::vector<const char*> input_names_;
  std::vector<const char*> output_names_;
  std::vector<std::int64_t> input_shape_;
};

}  // namespace ros2_vision
