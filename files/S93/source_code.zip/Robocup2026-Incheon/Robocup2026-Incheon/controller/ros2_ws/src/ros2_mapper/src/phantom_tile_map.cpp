#include "ros2_mapper/phantom_tile_map.hpp"

#include <algorithm>
#include <cmath>
#include <vector>

namespace ros2_mapper
{

namespace
{

std::size_t quadrantIndex(TileQuadrant quadrant)
{
  return static_cast<std::size_t>(quadrant);
}

bool isValidSupportBinIndex(int bin_index)
{
  return bin_index >= 0 && bin_index < 16;
}

bool isValidQuarterEdgeIndex(int edge_index)
{
  return edge_index >= 0 && edge_index < 12;
}

bool isValidSubtileIndex(int index)
{
  return index >= 0 && index < kSubtileCount;
}

bool isValidPrimitiveIndex(int index)
{
  return index >= 0 && index < kPrimitiveKindCount;
}

void updateObservedRange(PhantomQuadrantEvidence & quadrant, double range)
{
  quadrant.min_observed_range = std::min(quadrant.min_observed_range, range);
  quadrant.max_observed_range = std::max(quadrant.max_observed_range, range);
}

void touchEvidence(PhantomTileEvidence & evidence, const rclcpp::Time & stamp)
{
  evidence.last_seen = stamp;
  evidence.observation_count += 1;
}

double clamp01(double value)
{
  return std::clamp(value, 0.0, 1.0);
}

double temporalDecayFactor(
  const rclcpp::Time & last_seen,
  const rclcpp::Time & stamp,
  double half_life_s)
{
  if (half_life_s <= 0.0 || last_seen.nanoseconds() == 0 || stamp.nanoseconds() == 0) {
    return 1.0;
  }

  const double dt_s = (stamp - last_seen).seconds();
  if (dt_s <= 0.0) {
    return 1.0;
  }

  return std::pow(0.5, dt_s / half_life_s);
}

std::array<int, 2> segmentEndpoints(std::size_t index)
{
  static constexpr std::array<std::array<int, 2>, 12> endpoints{{
    {{0, 1}},
    {{1, 2}},
    {{3, 4}},
    {{4, 5}},
    {{6, 7}},
    {{7, 8}},
    {{0, 3}},
    {{3, 6}},
    {{1, 4}},
    {{4, 7}},
    {{2, 5}},
    {{5, 8}},
  }};

  return endpoints[index];
}

bool segmentsConnected(std::size_t lhs, std::size_t rhs)
{
  const auto lhs_endpoints = segmentEndpoints(lhs);
  const auto rhs_endpoints = segmentEndpoints(rhs);
  return
    lhs_endpoints[0] == rhs_endpoints[0] ||
    lhs_endpoints[0] == rhs_endpoints[1] ||
    lhs_endpoints[1] == rhs_endpoints[0] ||
    lhs_endpoints[1] == rhs_endpoints[1];
}

std::array<bool, 12> singleSegmentMask(std::size_t index)
{
  std::array<bool, 12> mask{};
  mask[index] = true;
  return mask;
}

std::array<bool, 12> twoSegmentMask(std::size_t first, std::size_t second)
{
  std::array<bool, 12> mask{};
  mask[first] = true;
  mask[second] = true;
  return mask;
}

int maskSegmentCount(const std::array<bool, 12> & mask)
{
  int count = 0;
  for (const bool present : mask) {
    if (present) {
      count += 1;
    }
  }
  return count;
}

double totalFreeWeight(const PhantomTileEvidence & evidence)
{
  double total = 0.0;
  for (const auto & quadrant : evidence.quadrants) {
    total += quadrant.free_range_weight_sum;
  }
  return total;
}

double totalHitWeight(const PhantomTileEvidence & evidence)
{
  double total = 0.0;
  for (const auto & quadrant : evidence.quadrants) {
    total += quadrant.hit_range_weight_sum;
  }
  return total;
}

int supportBinHitCount(const PhantomTileEvidence & evidence)
{
  int total = 0;
  for (const auto & bin : evidence.support_bins) {
    total += bin.hit_count;
  }
  return total;
}

double supportBinHitWeight(const PhantomTileEvidence & evidence)
{
  double total = 0.0;
  for (const auto & bin : evidence.support_bins) {
    total += bin.hit_weight_sum;
  }
  return total;
}

double positiveSegmentScore(const PhantomTileEvidence & evidence)
{
  double total = 0.0;
  for (const auto & edge : evidence.quarter_edges) {
    total += std::max(0.0, edge.raw_score);
  }
  return total;
}

int supportedSegmentCount(
  const PhantomTileEvidence & evidence,
  double supported_segment_min_score)
{
  int total = 0;
  for (const auto & edge : evidence.quarter_edges) {
    if (edge.raw_score >= supported_segment_min_score) {
      total += 1;
    }
  }
  return total;
}

PhantomMaskCandidate evaluateSegmentMaskCandidate(
  PhantomMaskKind kind,
  const std::array<bool, 12> & mask,
  const PhantomTileEvidence & evidence,
  double supported_segment_min_score,
  double conflict_segment_max_score,
  double complexity_penalty,
  double unsupported_segment_penalty)
{
  PhantomMaskCandidate candidate;
  candidate.kind = kind;
  candidate.segment_mask = mask;

  const int segment_count = maskSegmentCount(mask);
  int unsupported_segments = 0;
  double visibility_sum = 0.0;

  for (std::size_t i = 0; i < mask.size(); ++i) {
    if (!mask[i]) {
      continue;
    }

    const auto & edge = evidence.quarter_edges[i];
    candidate.raw_score += edge.raw_score;
    visibility_sum += edge.visibility_score;

    if (edge.raw_score >= supported_segment_min_score) {
      candidate.supported_segments += 1;
    } else {
      unsupported_segments += 1;
    }

    if (edge.raw_score <= conflict_segment_max_score) {
      candidate.conflicting_segments += 1;
    }
  }

  candidate.raw_score -= complexity_penalty * static_cast<double>(segment_count);
  candidate.raw_score -= unsupported_segment_penalty * static_cast<double>(unsupported_segments);

  if (segment_count > 0) {
    candidate.visibility = clamp01(visibility_sum / static_cast<double>(segment_count));
  }

  const int consistency_denominator =
    std::max(1, candidate.supported_segments + candidate.conflicting_segments);
  candidate.consistency =
    static_cast<double>(candidate.supported_segments) /
    static_cast<double>(consistency_denominator);

  return candidate;
}

PhantomMaskCandidate makeEmptyCandidate(
  const PhantomTileEvidence & evidence,
  double supported_segment_min_score)
{
  PhantomMaskCandidate candidate;
  candidate.kind = PhantomMaskKind::Empty;

  const double free_weight = totalFreeWeight(evidence);
  const double hit_weight = totalHitWeight(evidence);
  const double positive_score = positiveSegmentScore(evidence);
  const int positive_segments = supportedSegmentCount(evidence, supported_segment_min_score);
  const double possible_weight = std::max(1.0, evidence.range_weight_sum_total);

  candidate.raw_score =
    clamp01(free_weight / possible_weight) +
    clamp01(static_cast<double>(evidence.free_rays_total) / 8.0) -
    hit_weight -
    positive_score;
  candidate.visibility = clamp01(static_cast<double>(evidence.possible_rays_total) / 8.0);
  candidate.conflicting_segments =
    positive_segments + (evidence.hit_count_total > 0 ? 1 : 0);

  const double consistency_denominator = free_weight + hit_weight + positive_score;
  if (consistency_denominator > 0.0) {
    candidate.consistency = clamp01(free_weight / consistency_denominator);
  }

  return candidate;
}

PhantomMaskCandidate makeUnknownOccupiedCandidate(
  const PhantomTileEvidence & evidence,
  double supported_segment_min_score,
  double complexity_penalty)
{
  PhantomMaskCandidate candidate;
  candidate.kind = PhantomMaskKind::UnknownOccupied;

  const int support_hits = supportBinHitCount(evidence);
  const double support_hit_weight = supportBinHitWeight(evidence);
  const double positive_score = positiveSegmentScore(evidence);
  const int positive_segments = supportedSegmentCount(evidence, supported_segment_min_score);
  const int total_hits = evidence.hit_count_total + support_hits;

  candidate.raw_score =
    clamp01(static_cast<double>(total_hits) / 8.0) +
    support_hit_weight -
    positive_score -
    complexity_penalty;
  candidate.visibility =
    clamp01(static_cast<double>(evidence.possible_rays_total + total_hits) / 8.0);
  candidate.conflicting_segments = positive_segments;

  if (total_hits > 0) {
    candidate.consistency = 1.0 / static_cast<double>(1 + positive_segments);
  }

  return candidate;
}

void finalizeCandidateConfidences(
  std::vector<PhantomMaskCandidate> & candidates,
  double min_confidence)
{
  std::sort(
    candidates.begin(),
    candidates.end(),
    [](const PhantomMaskCandidate & lhs, const PhantomMaskCandidate & rhs) {
      if (lhs.raw_score == rhs.raw_score) {
        return static_cast<int>(lhs.kind) < static_cast<int>(rhs.kind);
      }
      return lhs.raw_score > rhs.raw_score;
    });

  for (std::size_t i = 0; i < candidates.size(); ++i) {
    const double next_score =
      i + 1U < candidates.size() ? candidates[i + 1U].raw_score : candidates[i].raw_score - 1.0;
    double confidence =
      clamp01(candidates[i].raw_score - next_score) *
      candidates[i].visibility *
      candidates[i].consistency;

    if (confidence < min_confidence) {
      confidence = 0.0;
    }

    candidates[i].confidence = confidence;
  }
}

}  // namespace

int quarterEdgeIndex(CanonicalSegmentKey key)
{
  if (key.line < 0 || key.line > 2 || key.offset < 0 || key.offset > 1) {
    return -1;
  }

  if (key.orientation == CanonicalSegmentOrientation::Horizontal) {
    return key.line * 2 + key.offset;
  }

  return 6 + key.line * 2 + key.offset;
}

int primitiveIndex(PrimitiveKind kind)
{
  switch (kind) {
    case PrimitiveKind::Empty:
      return 0;
    case PrimitiveKind::EdgeNorth:
      return 1;
    case PrimitiveKind::EdgeEast:
      return 2;
    case PrimitiveKind::EdgeSouth:
      return 3;
    case PrimitiveKind::EdgeWest:
      return 4;
    case PrimitiveKind::Curve1:
      return 5;
    case PrimitiveKind::Curve2:
      return 6;
    case PrimitiveKind::Curve3:
      return 7;
    case PrimitiveKind::Curve4:
      return 8;
    case PrimitiveKind::Obstacle:
      return 9;
    case PrimitiveKind::UnknownOccupied:
      return 10;
  }

  return -1;
}

int subtileIndex(SubtileIndex subtile)
{
  switch (subtile) {
    case SubtileIndex::NW:
      return 0;
    case SubtileIndex::NE:
      return 1;
    case SubtileIndex::SW:
      return 2;
    case SubtileIndex::SE:
      return 3;
  }

  return -1;
}

PhantomTileEvidence & PhantomTileMap::getOrCreate(
  const TileCoord & coord,
  const rclcpp::Time & stamp)
{
  auto iter = records_.find(coord);
  if (iter != records_.end()) {
    iter->second.last_seen = stamp;
    return iter->second;
  }

  PhantomTileEvidence evidence;
  evidence.coord = coord;
  evidence.first_seen = stamp;
  evidence.last_seen = stamp;

  auto result = records_.emplace(coord, evidence);
  return result.first->second;
}

const std::unordered_map<TileCoord, PhantomTileEvidence, TileCoordHash> &
PhantomTileMap::records() const
{
  return records_;
}

void PhantomTileMap::configurePrimitiveLogOdds(
  double positive_update,
  double negative_update,
  double min_log_odds,
  double max_log_odds)
{
  primitive_positive_log_odds_update_ = positive_update;
  primitive_negative_log_odds_update_ = negative_update;
  primitive_log_odds_min_ = min_log_odds;
  primitive_log_odds_max_ = max_log_odds;
}

void PhantomTileMap::configureTemporalEvidence(
  double lidar_decay_half_life_s,
  double obstacle_decay_half_life_s,
  double positive_evidence_max,
  double negative_evidence_max)
{
  lidar_evidence_decay_half_life_s_ = lidar_decay_half_life_s;
  obstacle_temporal_decay_half_life_s_ = obstacle_decay_half_life_s;
  lidar_positive_evidence_max_ = positive_evidence_max;
  lidar_negative_evidence_max_ = negative_evidence_max;
}

void PhantomTileMap::applyPrimitiveTemporalDecay(
  PrimitiveEvidence & primitive,
  const rclcpp::Time & stamp) const
{
  const double decay = temporalDecayFactor(
    primitive.last_seen,
    stamp,
    lidar_evidence_decay_half_life_s_);
  if (decay >= 1.0) {
    return;
  }

  primitive.log_odds *= decay;
  primitive.positive_score = std::clamp(
    primitive.positive_score * decay,
    0.0,
    lidar_positive_evidence_max_);
  primitive.negative_score = std::clamp(
    primitive.negative_score * decay,
    0.0,
    lidar_negative_evidence_max_);
  primitive.last_seen = stamp;
}

void PhantomTileMap::applyObstacleGridBinTemporalDecay(
  PhantomObstacleGridBinEvidence & bin,
  const rclcpp::Time & stamp) const
{
  const double decay = temporalDecayFactor(
    bin.last_seen,
    stamp,
    obstacle_temporal_decay_half_life_s_);
  if (decay >= 1.0) {
    return;
  }

  bin.hit_score = std::clamp(
    bin.hit_score * decay,
    0.0,
    lidar_positive_evidence_max_);
  bin.free_score = std::clamp(
    bin.free_score * decay,
    0.0,
    lidar_negative_evidence_max_);
  bin.last_seen = stamp;
}

void PhantomTileMap::recordPossibleRay(
  const TileCoord & coord,
  TileQuadrant quadrant,
  double range,
  double weight,
  const rclcpp::Time & stamp)
{
  auto & evidence = getOrCreate(coord, stamp);
  auto & quadrant_evidence = evidence.quadrants[quadrantIndex(quadrant)];
  quadrant_evidence.possible_rays += 1;
  quadrant_evidence.range_weight_sum += weight;
  updateObservedRange(quadrant_evidence, range);
  evidence.possible_rays_total += 1;
  evidence.range_weight_sum_total += weight;
  touchEvidence(evidence, stamp);
}

void PhantomTileMap::recordFreeRay(
  const TileCoord & coord,
  TileQuadrant quadrant,
  double range,
  double weight,
  const rclcpp::Time & stamp)
{
  auto & evidence = getOrCreate(coord, stamp);
  auto & quadrant_evidence = evidence.quadrants[quadrantIndex(quadrant)];
  quadrant_evidence.free_rays += 1;
  quadrant_evidence.free_range_weight_sum += weight;
  updateObservedRange(quadrant_evidence, range);
  evidence.free_rays_total += 1;
  touchEvidence(evidence, stamp);
}

void PhantomTileMap::recordHit(
  const TileCoord & coord,
  TileQuadrant quadrant,
  double range,
  double weight,
  const rclcpp::Time & stamp)
{
  auto & evidence = getOrCreate(coord, stamp);
  auto & quadrant_evidence = evidence.quadrants[quadrantIndex(quadrant)];
  quadrant_evidence.hit_count += 1;
  quadrant_evidence.hit_range_weight_sum += weight;
  updateObservedRange(quadrant_evidence, range);
  evidence.hit_count_total += 1;
  touchEvidence(evidence, stamp);
}

void PhantomTileMap::recordSupportPossible(
  const TileCoord & coord,
  int bin_index,
  double /* range */,
  double weight,
  const rclcpp::Time & stamp)
{
  if (!isValidSupportBinIndex(bin_index)) {
    return;
  }

  auto & evidence = getOrCreate(coord, stamp);
  auto & bin = evidence.support_bins[static_cast<std::size_t>(bin_index)];
  bin.possible_count += 1;
  bin.possible_weight_sum += weight;
  touchEvidence(evidence, stamp);
}

void PhantomTileMap::recordSupportFree(
  const TileCoord & coord,
  int bin_index,
  double /* range */,
  double weight,
  const rclcpp::Time & stamp)
{
  if (!isValidSupportBinIndex(bin_index)) {
    return;
  }

  auto & evidence = getOrCreate(coord, stamp);
  auto & bin = evidence.support_bins[static_cast<std::size_t>(bin_index)];
  bin.free_count += 1;
  bin.free_weight_sum += weight;
  touchEvidence(evidence, stamp);
}

void PhantomTileMap::recordSupportHit(
  const TileCoord & coord,
  int bin_index,
  double /* range */,
  double weight,
  const rclcpp::Time & stamp)
{
  if (!isValidSupportBinIndex(bin_index)) {
    return;
  }

  auto & evidence = getOrCreate(coord, stamp);
  auto & bin = evidence.support_bins[static_cast<std::size_t>(bin_index)];
  bin.hit_count += 1;
  bin.hit_weight_sum += weight;
  touchEvidence(evidence, stamp);
}

void PhantomTileMap::recordQuarterEdgePossible(
  const TileCoord & coord,
  CanonicalSegmentKey key,
  double weight,
  const rclcpp::Time & stamp)
{
  const int index = quarterEdgeIndex(key);
  if (!isValidQuarterEdgeIndex(index)) {
    return;
  }

  auto & evidence = getOrCreate(coord, stamp);
  auto & edge = evidence.quarter_edges[static_cast<std::size_t>(index)];
  edge.possible_rays += 1;
  edge.possible_weight_sum += weight;
  touchEvidence(evidence, stamp);
}

void PhantomTileMap::recordQuarterEdgeHitSupport(
  const TileCoord & coord,
  CanonicalSegmentKey key,
  double score,
  const rclcpp::Time & stamp)
{
  const int index = quarterEdgeIndex(key);
  if (!isValidQuarterEdgeIndex(index)) {
    return;
  }

  auto & evidence = getOrCreate(coord, stamp);
  auto & edge = evidence.quarter_edges[static_cast<std::size_t>(index)];
  edge.hit_support += 1;
  edge.hit_score += score;
  touchEvidence(evidence, stamp);
}

void PhantomTileMap::recordQuarterEdgeFreeConflict(
  const TileCoord & coord,
  CanonicalSegmentKey key,
  double score,
  const rclcpp::Time & stamp)
{
  const int index = quarterEdgeIndex(key);
  if (!isValidQuarterEdgeIndex(index)) {
    return;
  }

  auto & evidence = getOrCreate(coord, stamp);
  auto & edge = evidence.quarter_edges[static_cast<std::size_t>(index)];
  edge.free_conflicts += 1;
  edge.free_conflict_score += score;
  touchEvidence(evidence, stamp);
}

void PhantomTileMap::recordPrimitivePositive(
  const TileCoord & coord,
  SubtileIndex subtile,
  PrimitiveKind kind,
  double weight,
  const rclcpp::Time & stamp)
{
  const int subtile_index = subtileIndex(subtile);
  const int primitive_index = primitiveIndex(kind);
  if (!isValidSubtileIndex(subtile_index) || !isValidPrimitiveIndex(primitive_index)) {
    return;
  }

  auto & evidence = getOrCreate(coord, stamp);
  auto & primitive =
    evidence.subtiles[static_cast<std::size_t>(subtile_index)]
    .primitives[static_cast<std::size_t>(primitive_index)];
  applyPrimitiveTemporalDecay(primitive, stamp);
  primitive.hit_matches += 1;
  primitive.positive_score = std::clamp(
    primitive.positive_score + weight,
    0.0,
    lidar_positive_evidence_max_);
  const double log_odds_min = std::max(primitive_log_odds_min_, -lidar_negative_evidence_max_);
  const double log_odds_max = std::min(primitive_log_odds_max_, lidar_positive_evidence_max_);
  primitive.log_odds = std::clamp(
    primitive.log_odds + primitive_positive_log_odds_update_ * weight,
    log_odds_min,
    log_odds_max);
  primitive.last_seen = stamp;
  touchEvidence(evidence, stamp);
}

void PhantomTileMap::recordPrimitiveNegative(
  const TileCoord & coord,
  SubtileIndex subtile,
  PrimitiveKind kind,
  double weight,
  const rclcpp::Time & stamp)
{
  const int subtile_index = subtileIndex(subtile);
  const int primitive_index = primitiveIndex(kind);
  if (!isValidSubtileIndex(subtile_index) || !isValidPrimitiveIndex(primitive_index)) {
    return;
  }

  auto & evidence = getOrCreate(coord, stamp);
  auto & primitive =
    evidence.subtiles[static_cast<std::size_t>(subtile_index)]
    .primitives[static_cast<std::size_t>(primitive_index)];
  applyPrimitiveTemporalDecay(primitive, stamp);
  primitive.pass_through_conflicts += 1;
  primitive.negative_score = std::clamp(
    primitive.negative_score + weight,
    0.0,
    lidar_negative_evidence_max_);
  const double log_odds_min = std::max(primitive_log_odds_min_, -lidar_negative_evidence_max_);
  const double log_odds_max = std::min(primitive_log_odds_max_, lidar_positive_evidence_max_);
  primitive.log_odds = std::clamp(
    primitive.log_odds - primitive_negative_log_odds_update_ * weight,
    log_odds_min,
    log_odds_max);
  primitive.last_seen = stamp;
  touchEvidence(evidence, stamp);
}

void PhantomTileMap::recordPrimitivePossible(
  const TileCoord & coord,
  SubtileIndex subtile,
  PrimitiveKind kind,
  double weight,
  const rclcpp::Time & stamp)
{
  const int subtile_index = subtileIndex(subtile);
  const int primitive_index = primitiveIndex(kind);
  if (!isValidSubtileIndex(subtile_index) || !isValidPrimitiveIndex(primitive_index)) {
    return;
  }

  auto & evidence = getOrCreate(coord, stamp);
  auto & primitive =
    evidence.subtiles[static_cast<std::size_t>(subtile_index)]
    .primitives[static_cast<std::size_t>(primitive_index)];
  applyPrimitiveTemporalDecay(primitive, stamp);
  primitive.possible_rays += 1;
  primitive.possible_weight_sum += weight;
  primitive.last_seen = stamp;
  touchEvidence(evidence, stamp);
}

void PhantomTileMap::recordPrimitiveOccluded(
  const TileCoord & coord,
  SubtileIndex subtile,
  PrimitiveKind kind,
  const rclcpp::Time & stamp)
{
  const int subtile_index = subtileIndex(subtile);
  const int primitive_index = primitiveIndex(kind);
  if (!isValidSubtileIndex(subtile_index) || !isValidPrimitiveIndex(primitive_index)) {
    return;
  }

  auto & evidence = getOrCreate(coord, stamp);
  auto & primitive =
    evidence.subtiles[static_cast<std::size_t>(subtile_index)]
    .primitives[static_cast<std::size_t>(primitive_index)];
  applyPrimitiveTemporalDecay(primitive, stamp);
  primitive.occluded_rays += 1;
  primitive.last_seen = stamp;
  touchEvidence(evidence, stamp);
}

void PhantomTileMap::recordObstacleGridHit(
  const TileCoord & coord,
  int bin_index,
  double score,
  const rclcpp::Time & stamp)
{
  if (bin_index < 0 || bin_index >= kObstacleGridCellCount) {
    return;
  }

  auto & evidence = getOrCreate(coord, stamp);
  auto & bin = evidence.obstacle_grid[static_cast<std::size_t>(bin_index)];
  applyObstacleGridBinTemporalDecay(bin, stamp);
  bin.hit_count += 1;
  bin.hit_score = std::clamp(
    bin.hit_score + score,
    0.0,
    lidar_positive_evidence_max_);
  bin.last_seen = stamp;
  evidence.obstacle.last_seen = stamp;
  touchEvidence(evidence, stamp);
}

void PhantomTileMap::recordObstacleGridFree(
  const TileCoord & coord,
  int bin_index,
  double score,
  const rclcpp::Time & stamp)
{
  if (bin_index < 0 || bin_index >= kObstacleGridCellCount) {
    return;
  }

  auto & evidence = getOrCreate(coord, stamp);
  auto & bin = evidence.obstacle_grid[static_cast<std::size_t>(bin_index)];
  applyObstacleGridBinTemporalDecay(bin, stamp);
  bin.free_count += 1;
  bin.free_score = std::clamp(
    bin.free_score + score,
    0.0,
    lidar_negative_evidence_max_);
  bin.last_seen = stamp;
  evidence.obstacle.last_seen = stamp;
  touchEvidence(evidence, stamp);
}

void PhantomTileMap::decayObstacleGridTile(
  const TileCoord & coord,
  int bins_per_tile,
  const rclcpp::Time & stamp)
{
  auto iter = records_.find(coord);
  if (iter == records_.end()) {
    return;
  }

  const int cell_count = std::clamp(
    bins_per_tile * bins_per_tile,
    0,
    kObstacleGridCellCount);
  for (int index = 0; index < cell_count; ++index) {
    applyObstacleGridBinTemporalDecay(
      iter->second.obstacle_grid[static_cast<std::size_t>(index)],
      stamp);
  }
}

void PhantomTileMap::decayPrimitiveEvidenceTile(
  const TileCoord & coord,
  const rclcpp::Time & stamp)
{
  auto iter = records_.find(coord);
  if (iter == records_.end()) {
    return;
  }

  for (auto & subtile : iter->second.subtiles) {
    for (auto & primitive : subtile.primitives) {
      applyPrimitiveTemporalDecay(primitive, stamp);
    }
  }
}

void PhantomTileMap::recomputePrimitiveConfidence(
  const TileCoord & coord,
  SubtileIndex subtile,
  PrimitiveKind kind,
  int min_visibility_rays,
  int min_coverage_hits)
{
  auto iter = records_.find(coord);
  if (iter == records_.end()) {
    return;
  }

  const int subtile_index = subtileIndex(subtile);
  const int primitive_index = primitiveIndex(kind);
  if (!isValidSubtileIndex(subtile_index) || !isValidPrimitiveIndex(primitive_index)) {
    return;
  }

  auto & primitive =
    iter->second.subtiles[static_cast<std::size_t>(subtile_index)]
    .primitives[static_cast<std::size_t>(primitive_index)];

  const double visibility_denominator = std::max(1, min_visibility_rays);
  primitive.visibility_score = clamp01(
    static_cast<double>(primitive.possible_rays) / visibility_denominator);
  // Coverage is intentionally coarse for C3/D2. D2b should replace this with angular bins
  // for Curve1..4 while keeping edge evidence compatible.
  const double coverage_denominator = std::max(1, min_coverage_hits);
  primitive.coverage_score =
    primitive.hit_matches > 0 ?
    clamp01(static_cast<double>(primitive.hit_matches) / coverage_denominator) :
    1.0;

  const double probability = 1.0 / (1.0 + std::exp(-primitive.log_odds));
  primitive.confidence =
    std::fabs(probability - 0.5) * 2.0 *
    primitive.visibility_score *
    primitive.coverage_score;
}

void PhantomTileMap::recomputeQuarterEdgeScores(
  const TileCoord & coord,
  int min_visibility_rays,
  double hit_weight,
  double conflict_weight)
{
  auto iter = records_.find(coord);
  if (iter == records_.end()) {
    return;
  }

  const double visibility_denominator =
    std::max(1, min_visibility_rays);

  for (auto & edge : iter->second.quarter_edges) {
    edge.visibility_score = std::clamp(
      static_cast<double>(edge.possible_rays) / visibility_denominator,
      0.0,
      1.0);
    edge.raw_score =
      hit_weight * edge.hit_score -
      conflict_weight * edge.free_conflict_score;
  }
}

void PhantomTileMap::recomputeMaskCandidates(
  const TileCoord & coord,
  double supported_segment_min_score,
  double conflict_segment_max_score,
  double complexity_penalty,
  double unsupported_segment_penalty,
  double min_confidence)
{
  auto iter = records_.find(coord);
  if (iter == records_.end()) {
    return;
  }

  auto & evidence = iter->second;
  std::vector<PhantomMaskCandidate> candidates;
  candidates.reserve(36);

  candidates.push_back(makeEmptyCandidate(evidence, supported_segment_min_score));

  for (std::size_t i = 0; i < evidence.quarter_edges.size(); ++i) {
    if (evidence.quarter_edges[i].raw_score <= 0.0) {
      continue;
    }

    candidates.push_back(
      evaluateSegmentMaskCandidate(
        PhantomMaskKind::SingleSegment,
        singleSegmentMask(i),
        evidence,
        supported_segment_min_score,
        conflict_segment_max_score,
        complexity_penalty,
        unsupported_segment_penalty));
  }

  for (std::size_t i = 0; i < evidence.quarter_edges.size(); ++i) {
    for (std::size_t j = i + 1U; j < evidence.quarter_edges.size(); ++j) {
      if (!segmentsConnected(i, j)) {
        continue;
      }

      if (evidence.quarter_edges[i].raw_score <= 0.0 &&
        evidence.quarter_edges[j].raw_score <= 0.0)
      {
        continue;
      }

      candidates.push_back(
        evaluateSegmentMaskCandidate(
          PhantomMaskKind::TwoSegmentConnected,
          twoSegmentMask(i, j),
          evidence,
          supported_segment_min_score,
          conflict_segment_max_score,
          complexity_penalty,
          unsupported_segment_penalty));
    }
  }

  candidates.push_back(
    evaluateSegmentMaskCandidate(
      PhantomMaskKind::Area1North,
      twoSegmentMask(0U, 1U),
      evidence,
      supported_segment_min_score,
      conflict_segment_max_score,
      complexity_penalty,
      unsupported_segment_penalty));
  candidates.push_back(
    evaluateSegmentMaskCandidate(
      PhantomMaskKind::Area1East,
      twoSegmentMask(10U, 11U),
      evidence,
      supported_segment_min_score,
      conflict_segment_max_score,
      complexity_penalty,
      unsupported_segment_penalty));
  candidates.push_back(
    evaluateSegmentMaskCandidate(
      PhantomMaskKind::Area1South,
      twoSegmentMask(4U, 5U),
      evidence,
      supported_segment_min_score,
      conflict_segment_max_score,
      complexity_penalty,
      unsupported_segment_penalty));
  candidates.push_back(
    evaluateSegmentMaskCandidate(
      PhantomMaskKind::Area1West,
      twoSegmentMask(6U, 7U),
      evidence,
      supported_segment_min_score,
      conflict_segment_max_score,
      complexity_penalty,
      unsupported_segment_penalty));

  candidates.push_back(
    makeUnknownOccupiedCandidate(evidence, supported_segment_min_score, complexity_penalty));

  finalizeCandidateConfidences(candidates, min_confidence);

  evidence.best_mask_candidate = candidates.empty() ? PhantomMaskCandidate{} : candidates[0];
  evidence.second_mask_candidate =
    candidates.size() > 1U ? candidates[1] : PhantomMaskCandidate{};
}

bool PhantomTileMap::empty() const
{
  return records_.empty();
}

std::size_t PhantomTileMap::size() const
{
  return records_.size();
}

void PhantomTileMap::clear()
{
  records_.clear();
}

}  // namespace ros2_mapper
