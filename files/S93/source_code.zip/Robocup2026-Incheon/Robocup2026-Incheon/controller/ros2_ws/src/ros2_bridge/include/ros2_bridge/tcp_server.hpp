#pragma once

#include <atomic>
#include <cstddef>
#include <functional>
#include <mutex>
#include <string>
#include <thread>

namespace ros2_bridge
{

class TcpServer
{
public:
  using LineCallback = std::function<void(const std::string &)>;
  using LogCallback = std::function<void(const std::string &)>;
  using ConnectionCallback = std::function<void(const std::string &)>;
  using DisconnectionCallback = std::function<void()>;

  TcpServer(
    std::string host,
    int port,
    std::size_t max_line_bytes,
    std::size_t recv_buffer_bytes,
    LineCallback on_line,
    LogCallback on_info,
    LogCallback on_warn,
    LogCallback on_error,
    ConnectionCallback on_connect,
    DisconnectionCallback on_disconnect);

  ~TcpServer();

  TcpServer(const TcpServer &) = delete;
  TcpServer & operator=(const TcpServer &) = delete;
  TcpServer(TcpServer &&) = delete;
  TcpServer & operator=(TcpServer &&) = delete;

  void start();
  void stop();

  // Thread-safe. Returns false if no client is connected or send fails.
  bool sendLine(const std::string & line);

  bool connected() const;
  const std::string & host() const;
  int port() const;

private:
  void acceptLoop();
  void readClient(int client_fd);
  void closeClient();
  void closeServer();

  std::string host_;
  int port_;
  std::size_t max_line_bytes_;
  std::size_t recv_buffer_bytes_;

  LineCallback on_line_;
  LogCallback on_info_;
  LogCallback on_warn_;
  LogCallback on_error_;
  ConnectionCallback on_connect_;
  DisconnectionCallback on_disconnect_;

  std::atomic<bool> running_{false};
  std::atomic<bool> connected_{false};

  int server_fd_ = -1;
  int client_fd_ = -1;

  mutable std::mutex socket_mutex_;
  std::thread io_thread_;
};

}  // namespace ros2_bridge
