#include "ros2_mapper/tile_map.hpp"

#include <algorithm>

namespace ros2_mapper
{

namespace
{

WallState & wallStateRef(TileRecord & record, WallDirection direction)
{
  switch (direction) {
    case WallDirection::North:
      return record.walls.north;
    case WallDirection::East:
      return record.walls.east;
    case WallDirection::South:
      return record.walls.south;
    case WallDirection::West:
      return record.walls.west;
  }

  return record.walls.north;
}

const WallState & wallStateRef(const TileRecord & record, WallDirection direction)
{
  switch (direction) {
    case WallDirection::North:
      return record.walls.north;
    case WallDirection::East:
      return record.walls.east;
    case WallDirection::South:
      return record.walls.south;
    case WallDirection::West:
      return record.walls.west;
  }

  return record.walls.north;
}

WallObservationStats & wallStatsRef(TileRecord & record, WallDirection direction)
{
  switch (direction) {
    case WallDirection::North:
      return record.wall_stats.north;
    case WallDirection::East:
      return record.wall_stats.east;
    case WallDirection::South:
      return record.wall_stats.south;
    case WallDirection::West:
      return record.wall_stats.west;
  }

  return record.wall_stats.north;
}

const WallObservationStats & wallStatsRef(const TileRecord & record, WallDirection direction)
{
  switch (direction) {
    case WallDirection::North:
      return record.wall_stats.north;
    case WallDirection::East:
      return record.wall_stats.east;
    case WallDirection::South:
      return record.wall_stats.south;
    case WallDirection::West:
      return record.wall_stats.west;
  }

  return record.wall_stats.north;
}

}  // namespace

TileRecord & TileMap::getOrCreateTile(
  TileCoord coord,
  geometry_msgs::msg::Point center,
  rclcpp::Time stamp)
{
  auto iter = records_.find(coord);
  if (iter != records_.end()) {
    iter->second.center = center;
    return iter->second;
  }

  TileRecord record{
    coord,
    center,
    false,
    0,
    stamp,
    stamp,
    next_marker_id_++,
  };

  auto result = records_.emplace(coord, record);
  return result.first->second;
}

TileRecord & TileMap::markVisited(
  TileCoord coord,
  geometry_msgs::msg::Point center,
  rclcpp::Time stamp)
{
  auto & record = getOrCreateTile(coord, center, stamp);
  record.center = center;
  record.visited = true;
  record.visit_count += 1;
  record.last_seen = stamp;
  return record;
}

TileRecord & TileMap::markStart(
  TileCoord coord,
  geometry_msgs::msg::Point center,
  rclcpp::Time stamp)
{
  auto & record = getOrCreateTile(coord, center, stamp);
  record.center = center;
  record.visited = true;
  record.is_start = true;
  record.kind = TileKind::Start;
  record.area = TileArea::Area1;
  record.is_blocked = false;
  record.last_seen = stamp;
  return record;
}

WallState TileMap::getWallState(TileCoord coord, WallDirection direction) const
{
  const auto iter = records_.find(coord);
  if (iter == records_.end()) {
    return WallState::Unknown;
  }

  return wallStateRef(iter->second, direction);
}

int TileMap::getWallVotes(TileCoord coord, WallDirection direction) const
{
  const auto iter = records_.find(coord);
  if (iter == records_.end()) {
    return 0;
  }

  return wallStatsRef(iter->second, direction).wall_votes;
}

void TileMap::addWallVote(
  TileCoord coord,
  geometry_msgs::msg::Point center,
  WallDirection direction,
  rclcpp::Time stamp,
  int max_votes)
{
  auto & record = getOrCreateTile(coord, center, stamp);
  record.center = center;
  record.last_seen = stamp;

  auto & stats = wallStatsRef(record, direction);
  stats.wall_votes = std::min(stats.wall_votes + 1, max_votes);
  stats.last_observed = stamp;
}

void TileMap::setWallState(
  TileCoord coord,
  geometry_msgs::msg::Point center,
  WallDirection direction,
  WallState state,
  rclcpp::Time stamp)
{
  if (state == WallState::Open) {
    return;
  }

  auto & record = getOrCreateTile(coord, center, stamp);
  record.center = center;
  record.last_seen = stamp;

  auto & current_state = wallStateRef(record, direction);
  if (current_state == WallState::VirtualWall && state != WallState::VirtualWall) {
    return;
  }

  current_state = state;
}

bool TileMap::hasTile(TileCoord coord) const
{
  return records_.find(coord) != records_.end();
}

std::size_t TileMap::visitedCount() const
{
  std::size_t count = 0;
  for (const auto & entry : records_) {
    if (entry.second.visited) {
      ++count;
    }
  }
  return count;
}

const std::unordered_map<TileCoord, TileRecord, TileCoordHash> & TileMap::records() const
{
  return records_;
}

}  // namespace ros2_mapper
