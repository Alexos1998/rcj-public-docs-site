#include "ros2_bridge/bridge_node.hpp"

#include <algorithm>
#include <chrono>
#include <cctype>
#include <cinttypes>
#include <cmath>
#include <functional>
#include <future>
#include <iomanip>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <thread>
#include <vector>

namespace ros2_bridge
{

namespace
{

std::string sanitizeRobotEventValue(const std::string & value)
{
  if (value.empty()) {
    return "none";
  }

  std::string out = value;
  for (auto & ch : out) {
    if (std::isspace(static_cast<unsigned char>(ch))) {
      ch = '_';
    }
  }
  return out;
}

std::string boolText(bool value)
{
  return value ? "true" : "false";
}

std::string numberText(double value, int precision = 3)
{
  if (!std::isfinite(value)) {
    return "none";
  }
  std::ostringstream oss;
  oss << std::fixed << std::setprecision(precision) << value;
  return oss.str();
}

}  // namespace

void mirrorScanLeftRight(std::vector<float> & ranges)
{
  if (ranges.size() < 2) {
    return;
  }

  std::vector<float> mirrored(ranges.size());

  mirrored[0] = ranges[0];

  for (std::size_t i = 1; i < ranges.size(); ++i) {
    mirrored[i] = ranges[ranges.size() - i];
  }

  ranges.swap(mirrored);
}

BridgeNode::BridgeNode()
: Node("ros2_bridge")
{
  declareParameters();
  loadParameters();
  validateParameters();

  if (debug_mode_) {
    RCLCPP_INFO(
      get_logger(),
      "ros2_bridge debug_mode=true, tcp_host=%s, tcp_port=%d, max_line_bytes=%zu, "
      "recv_buffer_bytes=%zu",
      tcp_.host.c_str(),
      tcp_.port,
      tcp_.max_line_bytes,
      tcp_.recv_buffer_bytes);
  }

  createPublishers();
  createSubscriptions();
  createActionClients();
  startTcpServer();
  startStatusTimer();

  last_debug_summary_time_ = now();

  RCLCPP_INFO(
    get_logger(),
    "[timing] use_sim_time=%s publish_clock=%s use_webots_time_for_stamps=%s scan_time_s=%.4f",
    boolText(get_parameter("use_sim_time").as_bool()).c_str(),
    boolText(publish_clock_).c_str(),
    boolText(use_webots_time_for_stamps_).c_str(),
    scan_time_s_);

  logRobotEvent(
    "bridge_started",
    {
      {"host", tcp_.host},
      {"port", std::to_string(tcp_.port)},
      {"status_topic", "/ros2_bridge/status"},
	      {"ready_topic", "/ros2_bridge/ready"},
	      {"scan_topic", "/scan"},
	      {"filtered_odom_topic", "/odometry/filtered"},
	      {"odom_topic", "/gps/odom"},
	      {"imu_topic", "/imu/data"},
      {"floor_color_topic", floor_color_topic_},
      {"cmd_vel_source", "/cmd_vel"},
      {"publish_clock", boolText(publish_clock_)},
      {"use_webots_time_for_stamps", boolText(use_webots_time_for_stamps_)},
      {"scan_time_s", numberText(scan_time_s_, 4)},
    });
}

BridgeNode::~BridgeNode()
{
  if (tcp_server_) {
    tcp_server_->stop();
  }
}

void BridgeNode::declareParameters()
{
  declare_parameter<bool>("debug_mode", false);
  declare_parameter<double>("batch_stamp_max_age_s", 0.25);
  declare_parameter<double>("status_publish_period_s", status_publish_period_s_);

  // Time / sim-time handling. Defaults preserve the fast wall-time startup:
  // no /clock, sensors stamped with now(), scan_time derived from ~20.8 Hz.
  declare_parameter<bool>("publish_clock", publish_clock_);
  declare_parameter<bool>("use_webots_time_for_stamps", use_webots_time_for_stamps_);
  declare_parameter<double>("scan_time_s", scan_time_s_);

  declare_parameter<std::string>("tcp_host", tcp_.host);
  declare_parameter<int>("tcp_port", tcp_.port);
  declare_parameter<int>("max_line_bytes", static_cast<int>(tcp_.max_line_bytes));
  declare_parameter<int>("recv_buffer_bytes", static_cast<int>(tcp_.recv_buffer_bytes));

  declare_parameter<std::string>("imu_frame", imu_.frame);
  declare_parameter<bool>("imu_invert_yaw", imu_.invert_yaw);

  declare_parameter<std::string>("gps_frame", gps_.frame);
  declare_parameter<std::string>("gps_odom_frame", gps_.odom_frame);
  declare_parameter<bool>("gps_swap_xy", gps_.swap_xy);
  declare_parameter<bool>("gps_invert_x", gps_.invert_x);
  declare_parameter<bool>("gps_invert_y", gps_.invert_y);
  declare_parameter<bool>("gps_invert_z", gps_.invert_z);

  declare_parameter<std::string>("scan_frame", scan_.frame);
  declare_parameter<double>("scan_angle_min", scan_.angle_min);
  declare_parameter<double>("scan_angle_max", scan_.angle_max);
  declare_parameter<double>("scan_range_min", scan_.range_min);
  declare_parameter<double>("scan_range_max", scan_.range_max);
  declare_parameter<bool>("scan_rotate_half_turn", scan_.rotate_half_turn);
  declare_parameter<bool>("scan_invert", scan_.invert);
  declare_parameter<bool>("scan_mirror_left_right", scan_.mirror_left_right);

  floor_color_topic_ =
    declare_parameter<std::string>("floor_color_topic", "/floor_color/classification");
  hole_detection_topic_ =
    declare_parameter<std::string>("hole_detection_topic", "/hazard/hole_detection");

  global_costmap_topic_ =
    declare_parameter<std::string>("legacy_reachability.global_costmap_topic", global_costmap_topic_);
  local_costmap_topic_ =
    declare_parameter<std::string>("legacy_reachability.local_costmap_topic", local_costmap_topic_);
  planner_action_name_ =
    declare_parameter<std::string>("legacy_reachability.planner_action_name", planner_action_name_);
  planner_id_ =
    declare_parameter<std::string>("legacy_reachability.planner_id", planner_id_);
  reachability_request_timeout_s_ =
    declare_parameter<double>("legacy_reachability.request_timeout_s", reachability_request_timeout_s_);
  reachability_costmap_snapshot_log_period_s_ =
    declare_parameter<double>(
      "legacy_reachability.costmap_snapshot_log_period_s",
      reachability_costmap_snapshot_log_period_s_);
  reachability_log_candidate_events_ =
    declare_parameter<bool>(
      "legacy_reachability.log_candidate_events",
      reachability_log_candidate_events_);
  reachability_config_.max_costmap_age_s =
    declare_parameter<double>("legacy_reachability.costmap_max_age_s", reachability_config_.max_costmap_age_s);
  reachability_config_.alignment_tolerance_m =
    declare_parameter<double>("legacy_reachability.alignment_tolerance_m", reachability_config_.alignment_tolerance_m);
  reachability_config_.max_sample_step_m =
    declare_parameter<double>("legacy_reachability.max_sample_step_m", reachability_config_.max_sample_step_m);
  reachability_config_.lethal_threshold =
    declare_parameter<int>("legacy_reachability.lethal_threshold", reachability_config_.lethal_threshold);
  reachability_config_.allow_unknown =
    declare_parameter<bool>("legacy_reachability.allow_unknown", reachability_config_.allow_unknown);
  reachability_config_.subgrid_occupancy_check =
    declare_parameter<bool>("legacy_reachability.subgrid_occupancy_check", reachability_config_.subgrid_occupancy_check);
  reachability_config_.subgrid_cell_m =
    declare_parameter<double>("legacy_reachability.subgrid_cell_m", reachability_config_.subgrid_cell_m);
}

void BridgeNode::loadParameters()
{
  debug_mode_ = get_parameter("debug_mode").as_bool();
  status_publish_period_s_ = get_parameter("status_publish_period_s").as_double();

  publish_clock_ = get_parameter("publish_clock").as_bool();
  use_webots_time_for_stamps_ = get_parameter("use_webots_time_for_stamps").as_bool();
  scan_time_s_ = get_parameter("scan_time_s").as_double();
  if (scan_time_s_ <= 0.0) {
    scan_time_s_ = 0.05;
  }

  tcp_.host = get_parameter("tcp_host").as_string();

  const auto tcp_port_param = get_parameter("tcp_port").as_int();
  const auto max_line_bytes_param = get_parameter("max_line_bytes").as_int();
  const auto recv_buffer_bytes_param = get_parameter("recv_buffer_bytes").as_int();

  tcp_.port = static_cast<int>(tcp_port_param);
  tcp_.max_line_bytes = static_cast<std::size_t>(max_line_bytes_param);
  tcp_.recv_buffer_bytes = static_cast<std::size_t>(recv_buffer_bytes_param);

  imu_.frame = get_parameter("imu_frame").as_string();
  imu_.invert_yaw = get_parameter("imu_invert_yaw").as_bool();

  gps_.frame = get_parameter("gps_frame").as_string();
  gps_.odom_frame = get_parameter("gps_odom_frame").as_string();
  gps_.swap_xy = get_parameter("gps_swap_xy").as_bool();
  gps_.invert_x = get_parameter("gps_invert_x").as_bool();
  gps_.invert_y = get_parameter("gps_invert_y").as_bool();
  gps_.invert_z = get_parameter("gps_invert_z").as_bool();

  scan_.frame = get_parameter("scan_frame").as_string();
  scan_.angle_min = get_parameter("scan_angle_min").as_double();
  scan_.angle_max = get_parameter("scan_angle_max").as_double();
  scan_.range_min = get_parameter("scan_range_min").as_double();
  scan_.range_max = get_parameter("scan_range_max").as_double();
  scan_.rotate_half_turn = get_parameter("scan_rotate_half_turn").as_bool();
  scan_.invert = get_parameter("scan_invert").as_bool();
  scan_.mirror_left_right = get_parameter("scan_mirror_left_right").as_bool();

  global_costmap_topic_ =
    get_parameter("legacy_reachability.global_costmap_topic").as_string();
  local_costmap_topic_ =
    get_parameter("legacy_reachability.local_costmap_topic").as_string();
  planner_action_name_ =
    get_parameter("legacy_reachability.planner_action_name").as_string();
  planner_id_ =
    get_parameter("legacy_reachability.planner_id").as_string();
  reachability_request_timeout_s_ =
    get_parameter("legacy_reachability.request_timeout_s").as_double();
  reachability_config_.max_costmap_age_s =
    get_parameter("legacy_reachability.costmap_max_age_s").as_double();
  reachability_config_.alignment_tolerance_m =
    get_parameter("legacy_reachability.alignment_tolerance_m").as_double();
  reachability_config_.max_sample_step_m =
    get_parameter("legacy_reachability.max_sample_step_m").as_double();
  reachability_config_.lethal_threshold =
    static_cast<int>(get_parameter("legacy_reachability.lethal_threshold").as_int());
  reachability_config_.allow_unknown =
    get_parameter("legacy_reachability.allow_unknown").as_bool();
  reachability_config_.subgrid_occupancy_check =
    get_parameter("legacy_reachability.subgrid_occupancy_check").as_bool();
  reachability_config_.subgrid_cell_m =
    get_parameter("legacy_reachability.subgrid_cell_m").as_double();
  reachability_config_.timeout = std::chrono::milliseconds(
    static_cast<int>(std::max(1.0, reachability_request_timeout_s_ * 1000.0)));
}

void BridgeNode::validateParameters() const
{
  if (tcp_.port <= 0 || tcp_.port > 65535) {
    RCLCPP_FATAL(
      get_logger(),
      "Invalid tcp_port parameter: %d. Expected value in range 1..65535.",
      tcp_.port);
    throw std::runtime_error("invalid tcp_port parameter");
  }

  if (tcp_.max_line_bytes == 0) {
    RCLCPP_FATAL(
      get_logger(),
      "Invalid max_line_bytes parameter: %zu. Expected value greater than 0.",
      tcp_.max_line_bytes);
    throw std::runtime_error("invalid max_line_bytes parameter");
  }

  if (tcp_.recv_buffer_bytes == 0) {
    RCLCPP_FATAL(
      get_logger(),
      "Invalid recv_buffer_bytes parameter: %zu. Expected value greater than 0.",
      tcp_.recv_buffer_bytes);
    throw std::runtime_error("invalid recv_buffer_bytes parameter");
  }

  if (status_publish_period_s_ <= 0.0) {
    RCLCPP_FATAL(
      get_logger(),
      "Invalid status_publish_period_s parameter: %f. Expected value greater than 0.",
      status_publish_period_s_);
    throw std::runtime_error("invalid status_publish_period_s parameter");
  }

  if (scan_.angle_max <= scan_.angle_min) {
    RCLCPP_FATAL(
      get_logger(),
      "Invalid scan angle range: angle_min=%f angle_max=%f. angle_max must be greater than angle_min.",
      scan_.angle_min,
      scan_.angle_max);
    throw std::runtime_error("invalid scan angle range");
  }

  if (scan_.range_min <= 0.0 || scan_.range_max <= scan_.range_min) {
    RCLCPP_FATAL(
      get_logger(),
      "Invalid scan range: range_min=%f range_max=%f.",
      scan_.range_min,
      scan_.range_max);
    throw std::runtime_error("invalid scan range");
  }

  if (reachability_request_timeout_s_ <= 0.0) {
    RCLCPP_FATAL(get_logger(), "legacy_reachability.request_timeout_s must be positive");
    throw std::runtime_error("invalid reachability timeout");
  }

  if (reachability_costmap_snapshot_log_period_s_ < 0.0) {
    RCLCPP_FATAL(
      get_logger(),
      "legacy_reachability.costmap_snapshot_log_period_s must be non-negative");
    throw std::runtime_error("invalid reachability costmap snapshot log period");
  }

  if (reachability_config_.lethal_threshold < 0 || reachability_config_.lethal_threshold > 255) {
    RCLCPP_FATAL(get_logger(), "legacy_reachability.lethal_threshold must be in range 0..255");
    throw std::runtime_error("invalid reachability lethal threshold");
  }
}

void BridgeNode::createPublishers()
{
  const auto sensor_qos = rclcpp::SensorDataQoS();

  // Raw bridge measurements remain available for diagnostics and auxiliary consumers.
  // The final localization estimate comes only from controller LOC packets.
  //
  // IMU/LiDAR use sensor QoS because fresh data matters more than old queued data.
  // A queued stale LaserScan can arrive after TF has moved on and be rejected by Nav2's
  // tf2 message filter ("timestamp earlier than all the data in the transform cache").
  // Keep only the newest scan and do not force reliable retransmission/backlog.
  imu_pub_ = create_publisher<sensor_msgs::msg::Imu>("/imu/data", sensor_qos);
  gps_odom_pub_ = create_publisher<nav_msgs::msg::Odometry>("/gps/odom", 10);
  localization_odom_pub_ = create_publisher<nav_msgs::msg::Odometry>("/odometry/filtered", 10);
  wheel_odom_pub_ = create_publisher<nav_msgs::msg::Odometry>("/wheel/odom", 10);
  tf_broadcaster_ = std::make_unique<tf2_ros::TransformBroadcaster>(*this);
  static_tf_broadcaster_ = std::make_unique<tf2_ros::StaticTransformBroadcaster>(*this);
  publishStaticTransforms();
  auto scan_qos = rclcpp::SensorDataQoS();
  scan_qos.keep_last(1);
  scan_qos.best_effort();
  scan_qos.durability_volatile();
  scan_pub_ = create_publisher<sensor_msgs::msg::LaserScan>("/scan", scan_qos);
  floor_color_pub_ = create_publisher<std_msgs::msg::String>(
    floor_color_topic_,
    rclcpp::QoS(10));
  hole_detection_pub_ = create_publisher<std_msgs::msg::String>(
    hole_detection_topic_,
    rclcpp::QoS(10));
  vision_classification_pub_ = create_publisher<std_msgs::msg::String>(
    vision_classification_topic_,
    rclcpp::QoS(10));
  auto status_qos = rclcpp::QoS(rclcpp::KeepLast(1));
  status_qos.reliable();
  status_qos.transient_local();
  status_pub_ = create_publisher<std_msgs::msg::String>(
    "/ros2_bridge/status",
    status_qos);
  ready_pub_ = create_publisher<std_msgs::msg::String>(
    "/ros2_bridge/ready",
    status_qos);

  // Only advertise /clock in sim-time mode so wall-time runs stay lean and
  // consumers never block waiting on a clock that will not be published.
  if (publish_clock_) {
    clock_pub_ = create_publisher<rosgraph_msgs::msg::Clock>("/clock", rclcpp::ClockQoS());
  }
}

void BridgeNode::publishStaticTransforms()
{
  if (!static_tf_broadcaster_) {
    return;
  }

  auto make_static_tf =
    [](const char * parent, const char * child, double z) {
      geometry_msgs::msg::TransformStamped msg;
      msg.header.stamp = rclcpp::Time(0, 0, RCL_ROS_TIME);
      msg.header.frame_id = parent;
      msg.child_frame_id = child;
      msg.transform.translation.x = 0.0;
      msg.transform.translation.y = 0.0;
      msg.transform.translation.z = z;
      msg.transform.rotation.x = 0.0;
      msg.transform.rotation.y = 0.0;
      msg.transform.rotation.z = 0.0;
      msg.transform.rotation.w = 1.0;
      return msg;
    };

  std::vector<geometry_msgs::msg::TransformStamped> transforms;
  transforms.reserve(3);
  transforms.push_back(make_static_tf("base_link", "gps_link", 0.0145));
  transforms.push_back(make_static_tf("base_link", "imu_link", 0.0265));
  transforms.push_back(make_static_tf("base_link", "lidar_link", 0.0515));
  static_tf_broadcaster_->sendTransform(transforms);

  logRobotEvent(
    "static_tf_published",
    {
      {"gps", "base_link->gps_link"},
      {"imu", "base_link->imu_link"},
      {"lidar", "base_link->lidar_link"},
    });
}

void BridgeNode::createSubscriptions()
{
  cmd_vel_sub_ = create_subscription<geometry_msgs::msg::Twist>(
    "/cmd_vel",
    10,
    std::bind(&BridgeNode::cmdVelCallback, this, std::placeholders::_1));

  submission_matrix_sub_ = create_subscription<std_msgs::msg::String>(
    "/mapper/submission_matrix",
    rclcpp::QoS(1).reliable(),
    std::bind(&BridgeNode::submissionMatrixCallback, this, std::placeholders::_1));

  global_costmap_sub_ = create_subscription<nav_msgs::msg::OccupancyGrid>(
    global_costmap_topic_,
    rclcpp::QoS(1).reliable().transient_local(),
    std::bind(&BridgeNode::globalCostmapCallback, this, std::placeholders::_1));

  local_costmap_sub_ = create_subscription<nav_msgs::msg::OccupancyGrid>(
    local_costmap_topic_,
    rclcpp::QoS(1).reliable().transient_local(),
    std::bind(&BridgeNode::localCostmapCallback, this, std::placeholders::_1));
}

void BridgeNode::createActionClients()
{
  compute_path_client_ = rclcpp_action::create_client<ComputePathToPose>(
    get_node_base_interface(),
    get_node_graph_interface(),
    get_node_logging_interface(),
    get_node_waitables_interface(),
    planner_action_name_);

  logRobotEvent(
    "legacy_reachability_infrastructure",
    {
      {"global_costmap_topic", global_costmap_topic_},
      {"planner_action", planner_action_name_},
      {"planner_id", planner_id_},
      {"allow_unknown", boolText(reachability_config_.allow_unknown)},
      {"lethal_threshold", std::to_string(reachability_config_.lethal_threshold)},
    });
}

void BridgeNode::startTcpServer()
{
  tcp_server_ = std::make_unique<TcpServer>(
    tcp_.host,
    tcp_.port,
    tcp_.max_line_bytes,
    tcp_.recv_buffer_bytes,
    std::bind(&BridgeNode::handleLine, this, std::placeholders::_1),
    [this](const std::string & msg) {
      if (debug_mode_) {
        RCLCPP_INFO(get_logger(), "%s", msg.c_str());
      }
    },
    [this](const std::string & msg) {
      if (debug_mode_) {
        RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 2000, "%s", msg.c_str());
      }
    },
    [this](const std::string & msg) {
      RCLCPP_ERROR(get_logger(), "%s", msg.c_str());
    },
    std::bind(&BridgeNode::handleTcpConnected, this, std::placeholders::_1),
    std::bind(&BridgeNode::handleTcpDisconnected, this));

  tcp_server_->start();
}

void BridgeNode::startStatusTimer()
{
  const auto period = std::chrono::duration<double>(status_publish_period_s_);
  status_timer_ = create_wall_timer(
    std::chrono::duration_cast<std::chrono::nanoseconds>(period),
    std::bind(&BridgeNode::publishStatus, this));

  RCLCPP_INFO(
    get_logger(),
    "ros2_bridge status publishers active on /ros2_bridge/status and /ros2_bridge/ready period=%.3f s",
    status_publish_period_s_);
	  logRobotEvent(
	    "warmup_start",
	    {
	      {"reason", "waiting_for_tcp_gps_imu_scan_localization"},
	      {"connection_id", std::to_string(current_connection_id_)},
	    });

  publishStatus();
}

void BridgeNode::logRobotEvent(
  EventLevel level,
  const std::string & event,
  const std::vector<std::pair<std::string, std::string>> & fields) const
{
  std::ostringstream oss;
  oss << "ROBOT_EVENT node=bridge event=" << event;
  for (const auto & field : fields) {
    oss << ' ' << field.first << '=' << sanitizeRobotEventValue(field.second);
  }

  const auto line = oss.str();
  switch (level) {
    case EventLevel::Warn:
      RCLCPP_WARN(get_logger(), "%s", line.c_str());
      break;
    case EventLevel::Error:
      RCLCPP_ERROR(get_logger(), "%s", line.c_str());
      break;
    case EventLevel::Debug:
      RCLCPP_DEBUG(get_logger(), "%s", line.c_str());
      break;
    case EventLevel::Info:
    default:
      RCLCPP_INFO(get_logger(), "%s", line.c_str());
      break;
  }
}

void BridgeNode::logRobotEvent(
  const std::string & event,
  const std::vector<std::pair<std::string, std::string>> & fields) const
{
  logRobotEvent(EventLevel::Info, event, fields);
}

void BridgeNode::handleTcpConnected(const std::string & remote_endpoint)
{
  std::uint64_t connect_count = 0;
  std::uint64_t connection_id = 0;
  {
    std::lock_guard<std::mutex> lock(status_mutex_);
    ++tcp_connect_count_;
    ++current_connection_id_;
    connect_count = tcp_connect_count_;
    connection_id = current_connection_id_;
    resetCurrentConnectionReadinessLocked();
  }

  RCLCPP_INFO(
    get_logger(),
    "Webots TCP client connected from %s (connection_id=%" PRIu64 ", connect_count=%" PRIu64 ")",
    remote_endpoint.c_str(),
    connection_id,
    connect_count);
  logRobotEvent(
    "connection_changed",
    {
      {"connection_id", std::to_string(connection_id)},
      {"state", "connected"},
      {"remote_endpoint", remote_endpoint},
      {"connect_count", std::to_string(connect_count)},
      {"reason", "tcp_client_connected"},
    });
  logRobotEvent(
    "warmup_start",
    {
      {"connection_id", std::to_string(connection_id)},
      {"reason", "new_connection"},
    });
  publishStatus();
}

void BridgeNode::handleTcpDisconnected()
{
  std::uint64_t disconnect_count = 0;
  std::uint64_t connection_id = 0;
  {
    std::lock_guard<std::mutex> lock(status_mutex_);
    ++tcp_disconnect_count_;
    disconnect_count = tcp_disconnect_count_;
    connection_id = current_connection_id_;
    resetCurrentConnectionReadinessLocked();
  }

  RCLCPP_WARN(
    get_logger(),
    "Webots TCP client disconnected (connection_id=%" PRIu64 ", disconnect_count=%" PRIu64 ")",
    connection_id,
    disconnect_count);
  logRobotEvent(
    EventLevel::Warn,
    "connection_changed",
    {
      {"connection_id", std::to_string(connection_id)},
      {"state", "disconnected"},
      {"disconnect_count", std::to_string(disconnect_count)},
      {"reason", "tcp_client_disconnected"},
    });
  publishStatus();
}

void BridgeNode::handleLine(const std::string & line)
{
  recordLineReceived();

  const auto parsed = parser_.parsePrefix(line);

  if (!parsed.has_value()) {
    recordParseError();
    if (debug_mode_) {
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "Received TCP line without known protocol prefix");
    }
    logRobotEvent(
      EventLevel::Warn,
      "packet_dropped",
      {
        {"topic", "tcp"},
        {"connection_id", std::to_string(current_connection_id_)},
        {"reason", "unknown_protocol_prefix"},
      });

    return;
  }

  recordReceived(parsed->type);

  if (parsed->type == ProtocolMessageType::Time) {
    handleTime(line.substr(5));    // remove "TIME|"
  } else if (parsed->type == ProtocolMessageType::Loc) {
    handleLocalization(line.substr(4));  // remove "LOC|"
  } else if (parsed->type == ProtocolMessageType::Imu) {
    handleImu(line.substr(4));     // remove "IMU|"
  } else if (parsed->type == ProtocolMessageType::Gps) {
    handleGps(line.substr(4));     // remove "GPS|"
  } else if (parsed->type == ProtocolMessageType::Scan) {
    handleScan(line.substr(5));    // remove "SCAN|"
  } else if (parsed->type == ProtocolMessageType::Color) {
    handleColor(line.substr(6));   // remove "COLOR|"
  } else if (parsed->type == ProtocolMessageType::Hole) {
    handleHole(line.substr(5));    // remove "HOLE|"
  } else if (parsed->type == ProtocolMessageType::Vision) {
    handleVision(line.substr(7));   // remove "VISION|"
  } else if (parsed->type == ProtocolMessageType::Camera) {
    // Count CAM packets for diagnostics; image transport is outside this slice.
  } else if (parsed->type == ProtocolMessageType::Odom) {
    handleWheelOdom(line.substr(5));  // remove "ODOM|"
  } else if (parsed->type == ProtocolMessageType::LegacyReachabilityRequest) {
    handleLegacyReachabilityRequest(line);
  }

  logDebugSummary(parsed->type_name);
}

void BridgeNode::recordLineReceived()
{
  std::lock_guard<std::mutex> lock(status_mutex_);
  ++lines_received_;
}

void BridgeNode::recordParseError()
{
  std::lock_guard<std::mutex> lock(status_mutex_);
  ++parse_errors_;
}

void BridgeNode::recordReceived(ProtocolMessageType type)
{
  const auto stamp = now();
  const char * first_label = nullptr;

  {
    std::lock_guard<std::mutex> lock(status_mutex_);

    switch (type) {
      case ProtocolMessageType::Time:
        ++time_count_;
        last_time_stamp_ = stamp;
        has_last_time_stamp_ = true;
        if (!logged_first_time_received_) {
          logged_first_time_received_ = true;
          first_label = "TIME";
        }
        break;
      case ProtocolMessageType::Loc:
        ++loc_count_;
        last_loc_stamp_ = stamp;
        has_last_loc_stamp_ = true;
        if (!logged_first_loc_received_) {
          logged_first_loc_received_ = true;
          first_label = "LOC";
        }
        break;
      case ProtocolMessageType::Imu:
        ++imu_count_;
        last_imu_stamp_ = stamp;
        has_last_imu_stamp_ = true;
        if (!logged_first_imu_received_) {
          logged_first_imu_received_ = true;
          first_label = "IMU";
        }
        break;
      case ProtocolMessageType::Gps:
        ++gps_count_;
        last_gps_stamp_ = stamp;
        has_last_gps_stamp_ = true;
        if (!logged_first_gps_received_) {
          logged_first_gps_received_ = true;
          first_label = "GPS";
        }
        break;
      case ProtocolMessageType::Scan:
        ++scan_count_;
        last_scan_stamp_ = stamp;
        has_last_scan_stamp_ = true;
        if (!logged_first_scan_received_) {
          logged_first_scan_received_ = true;
          first_label = "SCAN";
        }
        break;
      case ProtocolMessageType::Color:
        ++color_count_;
        last_color_stamp_ = stamp;
        has_last_color_stamp_ = true;
        if (!logged_first_color_received_) {
          logged_first_color_received_ = true;
          first_label = "COLOR";
        }
        break;
      case ProtocolMessageType::Hole:
        if (!logged_first_hole_received_) {
          logged_first_hole_received_ = true;
          first_label = "HOLE";
        }
        break;
      case ProtocolMessageType::Vision:
        ++vision_count_;
        if (!logged_first_vision_received_) {
          logged_first_vision_received_ = true;
          first_label = "VISION";
        }
        break;
      case ProtocolMessageType::Camera:
        ++cam_count_;
        if (!logged_first_cam_received_) {
          logged_first_cam_received_ = true;
          first_label = "CAM";
        }
        break;
      case ProtocolMessageType::Odom:
      case ProtocolMessageType::LegacyReachabilityRequest:
      case ProtocolMessageType::Unknown:
        break;
    }
  }

  if (first_label != nullptr) {
    RCLCPP_INFO(get_logger(), "first %s received from controller", first_label);
    logRobotEvent(
      "topic_first_real",
      {
        {"topic", first_label},
        {"connection_id", std::to_string(current_connection_id_)},
        {"source", "tcp_controller"},
        {"direction", "received"},
      });
  }
}

void BridgeNode::recordPublished(ProtocolMessageType type)
{
  const char * topic_name = nullptr;
  bool readiness_changed = false;

  {
    std::lock_guard<std::mutex> lock(status_mutex_);

    switch (type) {
      case ProtocolMessageType::Loc:
        ++localization_published_count_;
        if (!loc_seen_this_connection_) {
          loc_seen_this_connection_ = true;
          readiness_changed = true;
        }
        if (!logged_first_localization_published_) {
          logged_first_localization_published_ = true;
          topic_name = "/odometry/filtered";
        }
        break;
      case ProtocolMessageType::Imu:
        ++imu_published_count_;
        if (!imu_seen_this_connection_) {
          imu_seen_this_connection_ = true;
          readiness_changed = true;
        }
        if (!logged_first_imu_published_) {
          logged_first_imu_published_ = true;
          topic_name = "/imu/data";
        }
        break;
      case ProtocolMessageType::Gps:
        ++gps_published_count_;
        if (!gps_seen_this_connection_) {
          gps_seen_this_connection_ = true;
          readiness_changed = true;
        }
        if (!logged_first_gps_published_) {
          logged_first_gps_published_ = true;
          topic_name = "/gps/odom";
        }
        break;
      case ProtocolMessageType::Scan:
        ++scan_published_count_;
        if (!scan_seen_this_connection_) {
          scan_seen_this_connection_ = true;
          readiness_changed = true;
        }
        if (!logged_first_scan_published_) {
          logged_first_scan_published_ = true;
          topic_name = "/scan";
        }
        break;
      case ProtocolMessageType::Color:
        ++color_published_count_;
        if (!logged_first_color_published_) {
          logged_first_color_published_ = true;
          topic_name = floor_color_topic_.c_str();
        }
        break;
      case ProtocolMessageType::Hole:
        if (!logged_first_hole_published_) {
          logged_first_hole_published_ = true;
          topic_name = hole_detection_topic_.c_str();
        }
        break;
      case ProtocolMessageType::Vision:
        ++vision_published_count_;
        if (!logged_first_vision_published_) {
          logged_first_vision_published_ = true;
          topic_name = vision_classification_topic_.c_str();
        }
        break;
      case ProtocolMessageType::Time:
      case ProtocolMessageType::Odom:
      case ProtocolMessageType::Camera:
      case ProtocolMessageType::LegacyReachabilityRequest:
      case ProtocolMessageType::Unknown:
        break;
    }
  }

  if (topic_name != nullptr) {
    RCLCPP_INFO(get_logger(), "first %s published", topic_name);
    logRobotEvent(
      "topic_first_real",
      {
        {"topic", topic_name},
        {"connection_id", std::to_string(current_connection_id_)},
        {"source", "bridge"},
        {"direction", "published"},
      });
  }

  if (readiness_changed) {
    publishStatus();
  }
}

void BridgeNode::resetCurrentConnectionReadinessLocked()
{
  loc_seen_this_connection_ = false;
  gps_seen_this_connection_ = false;
  imu_seen_this_connection_ = false;
  scan_seen_this_connection_ = false;
  logged_bridge_ready_ = false;
}

std::string BridgeNode::statusJson(const rclcpp::Time & stamp) const
{
  const auto costmap_snapshot = latestCostmapSnapshot();
  const exploration_legacy::CostmapSnapshot empty_costmap;
  const auto & costmap = costmap_snapshot ? *costmap_snapshot : empty_costmap;
  bool costmap_received = false;
  double costmap_age_s = -1.0;
  {
    std::lock_guard<std::mutex> costmap_lock(costmap_mutex_);
    costmap_received = static_cast<bool>(latest_global_costmap_);
    if (costmap_received) {
      costmap_age_s = (stamp - latest_global_costmap_receive_time_).seconds();
      if (costmap_age_s < 0.0) {
        costmap_age_s = -1.0;
      }
    }
  }
  const bool planner_action_ready =
    compute_path_client_ && compute_path_client_->action_server_is_ready();

  const auto age_s =
    [&stamp](bool has_stamp, const rclcpp::Time & last_stamp) {
      if (!has_stamp) {
        return -1.0;
      }

      const double age = (stamp - last_stamp).seconds();
      return age >= 0.0 ? age : -1.0;
    };

  std::lock_guard<std::mutex> lock(status_mutex_);

  std::ostringstream oss;
  oss << std::boolalpha << std::fixed << std::setprecision(3);
  oss
    << "{\"tcp_client_connected\":" << (tcp_server_ && tcp_server_->connected())
    << ",\"connection_id\":" << current_connection_id_
    << ",\"tcp_connect_count\":" << tcp_connect_count_
    << ",\"tcp_disconnect_count\":" << tcp_disconnect_count_
    << ",\"lines_received\":" << lines_received_
	    << ",\"parse_errors\":" << parse_errors_
	    << ",\"time_count\":" << time_count_
	    << ",\"loc_count\":" << loc_count_
	    << ",\"imu_count\":" << imu_count_
    << ",\"gps_count\":" << gps_count_
    << ",\"scan_count\":" << scan_count_
    << ",\"color_count\":" << color_count_
    << ",\"vision_count\":" << vision_count_
    << ",\"cam_count\":" << cam_count_
	    << ",\"last_time_age_s\":" << age_s(has_last_time_stamp_, last_time_stamp_)
	    << ",\"last_loc_age_s\":" << age_s(has_last_loc_stamp_, last_loc_stamp_)
	    << ",\"last_imu_age_s\":" << age_s(has_last_imu_stamp_, last_imu_stamp_)
    << ",\"last_gps_age_s\":" << age_s(has_last_gps_stamp_, last_gps_stamp_)
    << ",\"last_scan_age_s\":" << age_s(has_last_scan_stamp_, last_scan_stamp_)
    << ",\"last_color_age_s\":" << age_s(has_last_color_stamp_, last_color_stamp_)
	    << ",\"gps_published_count\":" << gps_published_count_
	    << ",\"localization_published_count\":" << localization_published_count_
	    << ",\"tf_published_count\":" << tf_published_count_
	    << ",\"imu_published_count\":" << imu_published_count_
    << ",\"scan_published_count\":" << scan_published_count_
    << ",\"color_published_count\":" << color_published_count_
    << ",\"vision_published_count\":" << vision_published_count_
    << ",\"localization_seen_this_connection\":" << loc_seen_this_connection_
    << ",\"gps_seen_this_connection\":" << gps_seen_this_connection_
    << ",\"imu_seen_this_connection\":" << imu_seen_this_connection_
    << ",\"scan_seen_this_connection\":" << scan_seen_this_connection_
    << ",\"last_loc_z_debug\":" << last_loc_z_debug_
    << ",\"legacy_global_costmap_received\":" << costmap_received
    << ",\"legacy_global_costmap_valid\":" << costmap.valid
    << ",\"legacy_global_costmap_age_s\":"
    << (costmap_received ? costmap_age_s : -1.0)
    << ",\"legacy_global_costmap_width\":" << costmap.width
    << ",\"legacy_global_costmap_height\":" << costmap.height
    << ",\"legacy_global_costmap_resolution\":" << costmap.resolution_m
    << ",\"legacy_planner_action_ready\":" << planner_action_ready
    << "}";

  return oss.str();
}

std::string BridgeNode::readyJson(bool & ready) const
{
  std::lock_guard<std::mutex> lock(status_mutex_);

  const bool tcp_ready = tcp_server_ && tcp_server_->connected();
  const bool localization_ready = loc_seen_this_connection_;
  const bool gps_ready = gps_seen_this_connection_;
  const bool imu_ready = imu_seen_this_connection_;
  const bool scan_ready = scan_seen_this_connection_;
  ready = tcp_ready && localization_ready && gps_ready && imu_ready && scan_ready;

  std::ostringstream oss;
  oss << std::boolalpha
      << "{\"ready\":" << ready
      << ",\"connection_id\":" << current_connection_id_
      << ",\"tcp\":" << tcp_ready
      << ",\"localization\":" << localization_ready
      << ",\"gps\":" << gps_ready
      << ",\"imu\":" << imu_ready
      << ",\"scan\":" << scan_ready
      << "}";

  return oss.str();
}

void BridgeNode::publishStatus()
{
  bool ready_snapshot = false;
  if (status_pub_) {
    std_msgs::msg::String msg;
    msg.data = statusJson(now());
    status_pub_->publish(msg);
  }

  if (ready_pub_) {
    bool ready = false;
    std_msgs::msg::String msg;
    msg.data = readyJson(ready);
    ready_snapshot = ready;
    ready_pub_->publish(msg);

    bool should_log_ready = false;
    if (ready) {
      std::lock_guard<std::mutex> lock(status_mutex_);
      if (!logged_bridge_ready_) {
        logged_bridge_ready_ = true;
        should_log_ready = true;
      }
    }

	    if (should_log_ready) {
	      RCLCPP_INFO(get_logger(), "ros2_bridge ready: tcp/gps/imu/scan/localization confirmed");
	      logRobotEvent(
	        "runtime_released",
	        {
	          {"connection_id", std::to_string(current_connection_id_)},
	          {"reason", "tcp_gps_imu_scan_localization_confirmed"},
	          {"tcp", "true"},
	          {"localization", "true"},
	          {"gps", "true"},
	          {"imu", "true"},
          {"scan", "true"},
        });
      logRobotEvent(
        "warmup_end",
        {
          {"connection_id", std::to_string(current_connection_id_)},
          {"reason", "bridge_ready"},
        });
    }
  }

  logRobotEvent(
    "topic_rate_summary",
    {
      {"connection_id", std::to_string(current_connection_id_)},
	      {"lines_received", std::to_string(lines_received_)},
	      {"parse_errors", std::to_string(parse_errors_)},
	      {"time_count", std::to_string(time_count_)},
	      {"loc_count", std::to_string(loc_count_)},
	      {"imu_count", std::to_string(imu_count_)},
	      {"gps_count", std::to_string(gps_count_)},
	      {"scan_count", std::to_string(scan_count_)},
	      {"color_count", std::to_string(color_count_)},
	      {"localization_published_count", std::to_string(localization_published_count_)},
	      {"imu_published_count", std::to_string(imu_published_count_)},
      {"gps_published_count", std::to_string(gps_published_count_)},
      {"scan_published_count", std::to_string(scan_published_count_)},
      {"color_published_count", std::to_string(color_published_count_)},
      {"ready", boolText(ready_snapshot)},
    });
}

void BridgeNode::logDebugSummary(const std::string & message_type)
{
  if (!debug_mode_) {
    return;
  }

  debug_message_counts_[message_type]++;

  const auto current_time = now();

  if ((current_time - last_debug_summary_time_).seconds() < 2.0) {
    return;
  }

  std::ostringstream oss;
  oss << "TCP rx:";

  for (const auto & [name, count] : debug_message_counts_) {
    oss << " " << name << "=" << count;
  }

  RCLCPP_INFO(get_logger(), "%s", oss.str().c_str());

  debug_message_counts_.clear();
  last_debug_summary_time_ = current_time;
}

void BridgeNode::handleTime(const std::string & payload)
{
  try {
    std::size_t parsed_chars = 0;
    const double sim_time = std::stod(payload, &parsed_chars);
    if (parsed_chars != payload.size()) {
      throw std::invalid_argument("trailing characters in TIME payload");
    }

    current_batch_sim_time_ = sim_time;
    has_current_batch_sim_time_ = true;

    if (publish_clock_ && clock_pub_) {
      rosgraph_msgs::msg::Clock clock_msg;
      clock_msg.clock = secondsToRosTime(sim_time);
      clock_pub_->publish(clock_msg);
    }
  } catch (const std::exception &) {
    recordParseError();
    if (debug_mode_) {
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "Malformed TIME payload: '%s'",
        payload.c_str());
    }
    logRobotEvent(
      EventLevel::Warn,
      "packet_dropped",
      {
        {"topic", "TIME"},
        {"connection_id", std::to_string(current_connection_id_)},
        {"reason", "malformed_payload"},
      });
  }
}

rclcpp::Time BridgeNode::secondsToRosTime(double seconds)
{
  if (seconds < 0.0) {
    seconds = 0.0;
  }
  const std::int64_t total_ns =
    static_cast<std::int64_t>(std::llround(seconds * 1e9));
  return rclcpp::Time(total_ns, RCL_ROS_TIME);
}

rclcpp::Time BridgeNode::makeSensorStamp()
{
  // In sim-time mode, stamp sensors with the latest Webots TIME so timestamps
  // match /clock. Until the first TIME arrives, fall back to now() with a
  // throttled warning so consumers are not fed a zero/stale stamp.
  if (use_webots_time_for_stamps_) {
    if (has_current_batch_sim_time_) {
      return secondsToRosTime(current_batch_sim_time_);
    }
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      2000,
      "use_webots_time_for_stamps=true but no Webots TIME received yet; "
      "stamping with wall time as fallback.");
  }
  return now();
}

std::vector<std::string> BridgeNode::splitFields(const std::string & text, char delimiter)
{
  std::vector<std::string> fields;
  std::stringstream ss(text);
  std::string item;
  while (std::getline(ss, item, delimiter)) {
    fields.push_back(item);
  }
  if (!text.empty() && text.back() == delimiter) {
    fields.emplace_back();
  }
  return fields;
}

bool BridgeNode::parseDoubleStrict(const std::string & text, double & value)
{
  try {
    std::size_t parsed = 0;
    value = std::stod(text, &parsed);
    return parsed == text.size() && std::isfinite(value);
  } catch (const std::exception &) {
    return false;
  }
}

bool BridgeNode::parseUint64Strict(const std::string & text, std::uint64_t & value)
{
  try {
    std::size_t parsed = 0;
    value = std::stoull(text, &parsed);
    return parsed == text.size();
  } catch (const std::exception &) {
    return false;
  }
}

double BridgeNode::quaternionYaw(const geometry_msgs::msg::Quaternion & q)
{
  const double siny_cosp = 2.0 * (q.w * q.z + q.x * q.y);
  const double cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z);
  return std::atan2(siny_cosp, cosy_cosp);
}

geometry_msgs::msg::PoseStamped BridgeNode::makePoseStamped(
  const std::string & frame_id,
  const rclcpp::Time & stamp,
  double x,
  double y,
  double yaw)
{
  geometry_msgs::msg::PoseStamped pose;
  pose.header.frame_id = frame_id;
  pose.header.stamp = stamp;
  pose.pose.position.x = x;
  pose.pose.position.y = y;
  pose.pose.position.z = 0.0;
  pose.pose.orientation.x = 0.0;
  pose.pose.orientation.y = 0.0;
  pose.pose.orientation.z = std::sin(yaw * 0.5);
  pose.pose.orientation.w = std::cos(yaw * 0.5);
  return pose;
}

void BridgeNode::globalCostmapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg)
{
  const auto receive_time = now();

  auto snapshot = std::make_shared<exploration_legacy::CostmapSnapshot>();
  if (msg) {
    snapshot->frame_id = msg->header.frame_id;
    snapshot->resolution_m = static_cast<double>(msg->info.resolution);
    snapshot->width = msg->info.width;
    snapshot->height = msg->info.height;
    snapshot->origin_x_m = msg->info.origin.position.x;
    snapshot->origin_y_m = msg->info.origin.position.y;
    snapshot->origin_yaw_rad = quaternionYaw(msg->info.origin.orientation);
    snapshot->age_s = 0.0;
    snapshot->data.reserve(msg->data.size());
    for (const auto value : msg->data) {
      snapshot->data.push_back(static_cast<int>(value));
    }
    snapshot->valid =
      snapshot->frame_id == "map" &&
      snapshot->resolution_m > 0.0 &&
      snapshot->width > 0U &&
      snapshot->height > 0U &&
      snapshot->data.size() == static_cast<std::size_t>(snapshot->width) * snapshot->height;
  }

  bool should_log_first = false;
  {
    std::lock_guard<std::mutex> lock(costmap_mutex_);
    latest_global_costmap_ = msg;
    latest_global_costmap_snapshot_ = snapshot;
    latest_global_costmap_receive_time_ = receive_time;
    if (!logged_first_global_costmap_) {
      logged_first_global_costmap_ = true;
      should_log_first = true;
    }
  }

  if (should_log_first) {
    logRobotEvent(
      "legacy_reachability_costmap_received",
      {
        {"frame", msg ? msg->header.frame_id : "none"},
        {"resolution", msg ? numberText(msg->info.resolution, 4) : "0.0000"},
        {"size", msg ? std::to_string(msg->info.width) + "x" + std::to_string(msg->info.height) : "0x0"},
        {"data_size", msg ? std::to_string(msg->data.size()) : "0"},
        {"valid", boolText(snapshot->valid)},
        {"topic", global_costmap_topic_},
      });
  }
}

std::shared_ptr<const exploration_legacy::CostmapSnapshot> BridgeNode::latestCostmapSnapshot() const
{
  std::lock_guard<std::mutex> lock(costmap_mutex_);
  return latest_global_costmap_snapshot_;
}

void BridgeNode::localCostmapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg)
{
  const auto receive_time = now();

  auto snapshot = std::make_shared<exploration_legacy::CostmapSnapshot>();
  if (msg) {
    snapshot->frame_id = msg->header.frame_id;
    snapshot->resolution_m = static_cast<double>(msg->info.resolution);
    snapshot->width = msg->info.width;
    snapshot->height = msg->info.height;
    snapshot->origin_x_m = msg->info.origin.position.x;
    snapshot->origin_y_m = msg->info.origin.position.y;
    snapshot->origin_yaw_rad = quaternionYaw(msg->info.origin.orientation);
    snapshot->age_s = 0.0;
    snapshot->data.reserve(msg->data.size());
    for (const auto value : msg->data) {
      snapshot->data.push_back(static_cast<int>(value));
    }
    // The local costmap is a robot-centred rolling window, usually in the "odom"
    // frame (not "map"). Validity therefore checks geometry only, not the frame.
    // The legacy reachability candidates are immediate neighbours (<0.2 m), so
    // sampling them against the local origin is accurate while map~=odom holds.
    snapshot->valid =
      snapshot->resolution_m > 0.0 &&
      snapshot->width > 0U &&
      snapshot->height > 0U &&
      snapshot->data.size() == static_cast<std::size_t>(snapshot->width) * snapshot->height;
  }

  bool should_log_first = false;
  {
    std::lock_guard<std::mutex> lock(costmap_mutex_);
    latest_local_costmap_ = msg;
    latest_local_costmap_snapshot_ = snapshot;
    latest_local_costmap_receive_time_ = receive_time;
    if (!logged_first_local_costmap_) {
      logged_first_local_costmap_ = true;
      should_log_first = true;
    }
  }

  if (should_log_first) {
    logRobotEvent(
      "legacy_reachability_local_costmap_received",
      {
        {"frame", msg ? msg->header.frame_id : "none"},
        {"resolution", msg ? numberText(msg->info.resolution, 4) : "0.0000"},
        {"size", msg ? std::to_string(msg->info.width) + "x" + std::to_string(msg->info.height) : "0x0"},
        {"data_size", msg ? std::to_string(msg->data.size()) : "0"},
        {"valid", boolText(snapshot->valid)},
        {"topic", local_costmap_topic_},
      });
  }
}

std::shared_ptr<const exploration_legacy::CostmapSnapshot> BridgeNode::latestLocalCostmapSnapshot() const
{
  std::lock_guard<std::mutex> lock(costmap_mutex_);
  return latest_local_costmap_snapshot_;
}

exploration_legacy::ReachabilityResult BridgeNode::validatePlannerSegment(
  const exploration_legacy::PathSegment & segment)
{
  exploration_legacy::ReachabilityResult result;
  result.reachable = false;

  if (!compute_path_client_) {
    result.status = exploration_legacy::ReachabilityStatus::PlannerUnavailable;
    result.reason = "planner action client unavailable";
    return result;
  }

  const auto timeout = std::chrono::duration_cast<std::chrono::nanoseconds>(
    std::chrono::duration<double>(reachability_request_timeout_s_));
  if (!compute_path_client_->wait_for_action_server(std::chrono::milliseconds(100))) {
    result.status = exploration_legacy::ReachabilityStatus::PlannerUnavailable;
    result.reason = "planner action server unavailable";
    return result;
  }

  const double yaw = std::atan2(segment.end.y - segment.start.y, segment.end.x - segment.start.x);
  ComputePathToPose::Goal goal;
  goal.start = makePoseStamped("map", now(), segment.start.x, segment.start.y, yaw);
  goal.goal = makePoseStamped("map", now(), segment.end.x, segment.end.y, yaw);
  goal.planner_id = planner_id_;
  goal.use_start = true;

  auto goal_future = compute_path_client_->async_send_goal(goal);
  if (goal_future.wait_for(timeout) != std::future_status::ready) {
    result.status = exploration_legacy::ReachabilityStatus::Timeout;
    result.reason = "timeout sending ComputePathToPose goal";
    return result;
  }

  auto goal_handle = goal_future.get();
  if (!goal_handle) {
    result.status = exploration_legacy::ReachabilityStatus::PlannerRejected;
    result.reason = "ComputePathToPose goal rejected";
    return result;
  }

  auto result_future = compute_path_client_->async_get_result(goal_handle);
  if (result_future.wait_for(timeout) != std::future_status::ready) {
    result.status = exploration_legacy::ReachabilityStatus::Timeout;
    result.reason = "timeout waiting for ComputePathToPose result";
    return result;
  }

  const auto wrapped = result_future.get();
  if (wrapped.code != rclcpp_action::ResultCode::SUCCEEDED ||
      !wrapped.result ||
      wrapped.result->path.poses.empty())
  {
    result.status = exploration_legacy::ReachabilityStatus::PlannerRejected;
    result.reason = "ComputePathToPose did not return a usable path";
    return result;
  }

  result.reachable = true;
  result.status = exploration_legacy::ReachabilityStatus::Reachable;
  result.reason = "planner accepted segment";
  return result;
}

void BridgeNode::sendLegacyReachabilityResponse(
  std::uint64_t request_id,
  const exploration_legacy::ReachabilityResult & result)
{
  if (!tcp_server_) {
    return;
  }
  const auto line = exploration_legacy::serializeReachabilityResponse(request_id, result);
  if (!tcp_server_->sendLine(line)) {
    logRobotEvent(
      EventLevel::Warn,
      "legacy_reachability_response_failed",
      {
        {"request_id", std::to_string(request_id)},
        {"reason", "tcp_send_failed"},
      });
  }
}

void BridgeNode::handleLegacyReachabilityRequest(const std::string & line)
{
  const auto fields = splitFields(line, '|');
  std::uint64_t request_id = 0;
  if (fields.size() >= 3U) {
    parseUint64Strict(fields[2], request_id);
  }

  auto fail = [&](exploration_legacy::ReachabilityStatus status, const std::string & reason) {
    exploration_legacy::ReachabilityResult result;
    result.reachable = false;
    result.status = status;
    result.reason = reason;
    if (request_id != 0U) {
      sendLegacyReachabilityResponse(request_id, result);
    }
    logRobotEvent(
      EventLevel::Warn,
      "legacy_reachability_rejected",
      {
        {"request_id", std::to_string(request_id)},
        {"status", exploration_legacy::reachabilityStatusName(status)},
        {"reason", reason},
      });
  };

  if (fields.size() != 9U ||
      fields[0] != "LEGACY_REACHABILITY_REQUEST" ||
      fields[1] != "1" ||
      request_id == 0U)
  {
    recordParseError();
    fail(exploration_legacy::ReachabilityStatus::InvalidCoordinate, "malformed reachability request");
    return;
  }

  double start_x = 0.0;
  double start_y = 0.0;
  double start_yaw = 0.0;
  double goal_x = 0.0;
  double goal_y = 0.0;
  if (!parseDoubleStrict(fields[3], start_x) ||
      !parseDoubleStrict(fields[4], start_y) ||
      !parseDoubleStrict(fields[5], start_yaw) ||
      !parseDoubleStrict(fields[6], goal_x) ||
      !parseDoubleStrict(fields[7], goal_y))
  {
    recordParseError();
    fail(exploration_legacy::ReachabilityStatus::InvalidCoordinate, "invalid numeric fields");
    return;
  }

  std::vector<exploration_legacy::PathCandidate> candidates;
  if (!exploration_legacy::parseCandidatePayload(fields[8], candidates)) {
    recordParseError();
    fail(exploration_legacy::ReachabilityStatus::InvalidCoordinate, "invalid candidate payload");
    return;
  }

  std::ostringstream candidate_names;
  for (std::size_t i = 0; i < candidates.size(); ++i) {
    if (i > 0U) {
      candidate_names << ',';
    }
    candidate_names << candidates[i].name;
  }

  logRobotEvent(
    "legacy_reachability_request",
    {
      {"request_id", std::to_string(request_id)},
      {"goal", "(" + numberText(goal_x, 4) + "," + numberText(goal_y, 4) + ")"},
      {"start", "(" + numberText(start_x, 4) + "," + numberText(start_y, 4) + "," + numberText(start_yaw, 4) + ")"},
      {"candidates", std::to_string(candidates.size())},
      {"candidate_types", candidate_names.str()},
    });

  const auto snapshot_ptr = latestCostmapSnapshot();
  const exploration_legacy::CostmapSnapshot empty_snapshot;
  const auto & snapshot = snapshot_ptr ? *snapshot_ptr : empty_snapshot;
  bool costmap_received = false;
  double costmap_age_s = -1.0;
  {
    std::lock_guard<std::mutex> lock(costmap_mutex_);
    costmap_received = static_cast<bool>(latest_global_costmap_);
    if (costmap_received) {
      costmap_age_s = (now() - latest_global_costmap_receive_time_).seconds();
      if (costmap_age_s < 0.0) {
        costmap_age_s = -1.0;
      }
    }
  }
  // The heavy costmap data vector is cached when the costmap topic updates.  We
  // intentionally do not rebuild/copy it per reachability request; keep the
  // per-request age only for status/logging.  Functional staleness is still
  // bounded by the global_costmap topic update rate.
  const double snapshot_age_for_log = costmap_age_s >= 0.0 ? costmap_age_s : snapshot.age_s;

  if (costmap_received) {
    const auto signature =
      snapshot.frame_id + "|" +
      std::to_string(snapshot.width) + "x" + std::to_string(snapshot.height) + "|" +
      numberText(snapshot.resolution_m, 4) + "|" +
      boolText(snapshot.valid);
    const auto now_stamp = now();
    double elapsed_s = 0.0;
    if (has_last_reachability_costmap_snapshot_log_stamp_) {
      elapsed_s = (now_stamp - last_reachability_costmap_snapshot_log_stamp_).seconds();
    }
    const bool changed = signature != last_reachability_costmap_snapshot_signature_;
    const bool due =
      !has_last_reachability_costmap_snapshot_log_stamp_ ||
      reachability_costmap_snapshot_log_period_s_ == 0.0 ||
      elapsed_s < 0.0 ||
      elapsed_s >= reachability_costmap_snapshot_log_period_s_;

    if (changed || due) {
      logRobotEvent(
        "legacy_reachability_costmap_snapshot",
        {
          {"request_id", std::to_string(request_id)},
          {"frame", snapshot.frame_id},
          {"resolution", numberText(snapshot.resolution_m, 4)},
          {"size", std::to_string(snapshot.width) + "x" + std::to_string(snapshot.height)},
          {"age", numberText(snapshot_age_for_log, 3)},
          {"throttled", boolText(!changed && has_last_reachability_costmap_snapshot_log_stamp_)},
        });
      last_reachability_costmap_snapshot_log_stamp_ = now_stamp;
      has_last_reachability_costmap_snapshot_log_stamp_ = true;
      last_reachability_costmap_snapshot_signature_ = signature;
    }
  }

  if (!snapshot.valid) {
    logRobotEvent(
      EventLevel::Warn,
      "legacy_reachability_infrastructure_not_ready",
      {
        {"costmap_received", boolText(costmap_received)},
        {"costmap_frame", snapshot.frame_id},
        {"costmap_resolution", numberText(snapshot.resolution_m, 4)},
        {"costmap_size", std::to_string(snapshot.width) + "x" + std::to_string(snapshot.height)},
        {"costmap_data", std::to_string(snapshot.data.size())},
        {"costmap_age", numberText(snapshot_age_for_log, 3)},
        {"planner_action_ready", boolText(
            compute_path_client_ && compute_path_client_->action_server_is_ready())},
      });
  }

  if (snapshot.valid &&
      reachability_config_.max_costmap_age_s > 0.0 &&
      snapshot_age_for_log > reachability_config_.max_costmap_age_s)
  {
    exploration_legacy::ReachabilityResult stale_result;
    stale_result.reachable = false;
    stale_result.status = exploration_legacy::ReachabilityStatus::CostmapUnavailable;
    stale_result.selected_candidate = candidates.empty() ? "none" : candidates.front().name;
    stale_result.reason = "costmap is stale";

    logRobotEvent(
      EventLevel::Warn,
      "legacy_reachability_response",
      {
        {"request_id", std::to_string(request_id)},
        {"reachable", boolText(stale_result.reachable)},
        {"status", exploration_legacy::reachabilityStatusName(stale_result.status)},
        {"candidate", stale_result.selected_candidate.empty() ? "none" : stale_result.selected_candidate},
        {"reason", stale_result.reason},
      });

    sendLegacyReachabilityResponse(request_id, stale_result);
    return;
  }

  auto planner = [this](const exploration_legacy::PathSegment & segment) {
    return validatePlannerSegment(segment);
  };

  auto eval_config = reachability_config_;
  if (reachability_log_candidate_events_ || debug_mode_) {
    eval_config.log_callback = [this, request_id](const std::string & msg) {
      RCLCPP_INFO(
        get_logger(),
        "%s request_id=%" PRIu64,
        msg.c_str(),
        request_id);
    };
  } else {
    eval_config.log_callback = nullptr;
  }

  auto result = exploration_legacy::LegacyReachabilityChecker::evaluateCandidates(
    candidates,
    snapshot,
    eval_config,
    planner);

  // Layer 2 of the layered edge clearing: if the GLOBAL costmap did not clear
  // the edge, let the (higher-resolution / more current) LOCAL costmap free it.
  // An edge is reachable if global OR local says so; the controller's LIDAR
  // override is the final layer beyond this. Only consult the local costmap on a
  // costmap-based negative verdict (not on infrastructure errors), and only when
  // a valid local snapshot exists.
  if (!result.reachable &&
      (result.status == exploration_legacy::ReachabilityStatus::Blocked ||
       result.status == exploration_legacy::ReachabilityStatus::OutsideCostmap ||
       result.status == exploration_legacy::ReachabilityStatus::UnknownSpace ||
       result.status == exploration_legacy::ReachabilityStatus::CostmapUnavailable))
  {
    const auto local_ptr = latestLocalCostmapSnapshot();
    if (local_ptr && local_ptr->valid) {
      const auto local_result = exploration_legacy::LegacyReachabilityChecker::evaluateCandidates(
        candidates,
        *local_ptr,
        eval_config,
        planner);
      if (local_result.reachable) {
        result = local_result;
        result.reason = "freed_by_local_costmap:" + local_result.reason;
        logRobotEvent(
          "legacy_reachability_local_costmap_freed",
          {
            {"request_id", std::to_string(request_id)},
            {"candidate", result.selected_candidate.empty() ? "none" : result.selected_candidate},
          });
      }
    }
  }

  logRobotEvent(
    result.reachable ? EventLevel::Info : EventLevel::Warn,
    "legacy_reachability_response",
    {
      {"request_id", std::to_string(request_id)},
      {"reachable", boolText(result.reachable)},
      {"status", exploration_legacy::reachabilityStatusName(result.status)},
      {"candidate", result.selected_candidate.empty() ? "none" : result.selected_candidate},
      {"reason", result.reason},
    });

  sendLegacyReachabilityResponse(request_id, result);
}

void BridgeNode::handleImu(const std::string & payload)
{
  std::stringstream ss(payload);
  std::string roll_text;
  std::string pitch_text;
  std::string yaw_text;
  std::string extra_text;

  if (
    !std::getline(ss, roll_text, ',') ||
    !std::getline(ss, pitch_text, ',') ||
    !std::getline(ss, yaw_text, ',') ||
    std::getline(ss, extra_text, ','))
  {
    recordParseError();
    if (debug_mode_) {
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "Malformed raw IMU payload: '%s'",
        payload.c_str());
    }
    logRobotEvent(
      EventLevel::Warn,
      "packet_dropped",
      {
        {"topic", "/imu/data"},
        {"connection_id", std::to_string(current_connection_id_)},
        {"reason", "malformed_payload"},
      });
    return;
  }

  try {
    const double roll = std::stod(roll_text);
    const double pitch = std::stod(pitch_text);
    double yaw = std::stod(yaw_text);

    if (imu_.invert_yaw) {
      yaw = -yaw;
    }

    const double cr = std::cos(roll * 0.5);
    const double sr = std::sin(roll * 0.5);
    const double cp = std::cos(pitch * 0.5);
    const double sp = std::sin(pitch * 0.5);
    const double cy = std::cos(yaw * 0.5);
    const double sy = std::sin(yaw * 0.5);

    sensor_msgs::msg::Imu msg;
    msg.header.stamp = makeSensorStamp();
    msg.header.frame_id = imu_.frame;

    msg.orientation.x = sr * cp * cy - cr * sp * sy;
    msg.orientation.y = cr * sp * cy + sr * cp * sy;
    msg.orientation.z = cr * cp * sy - sr * sp * cy;
    msg.orientation.w = cr * cp * cy + sr * sp * sy;

    msg.orientation_covariance[0] = 999.0;
    msg.orientation_covariance[4] = 999.0;
    msg.orientation_covariance[8] = 0.0001;

    // Angular velocity and linear acceleration are intentionally not provided by this bridge.
    msg.angular_velocity_covariance[0] = -1.0;
    msg.linear_acceleration_covariance[0] = -1.0;

    imu_pub_->publish(msg);
    recordPublished(ProtocolMessageType::Imu);

    if (debug_mode_) {
      RCLCPP_INFO_THROTTLE(
        get_logger(),
        *get_clock(),
        1000,
        "Published raw /imu/data measurement: roll=%f pitch=%f yaw=%f",
        roll,
        pitch,
        yaw);
    }
  } catch (const std::exception &) {
    recordParseError();
    if (debug_mode_) {
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "Malformed raw IMU numeric values: '%s'",
        payload.c_str());
    }
    logRobotEvent(
      EventLevel::Warn,
      "packet_dropped",
      {
        {"topic", "/imu/data"},
        {"connection_id", std::to_string(current_connection_id_)},
        {"reason", "malformed_numeric_values"},
      });
  }
}

void BridgeNode::handleGps(const std::string & payload)
{
  std::stringstream ss(payload);
  std::string x_text;
  std::string y_text;
  std::string z_text;
  std::string extra_text;

  if (
    !std::getline(ss, x_text, ',') ||
    !std::getline(ss, y_text, ',') ||
    !std::getline(ss, z_text, ',') ||
    std::getline(ss, extra_text, ','))
  {
    recordParseError();
    if (debug_mode_) {
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "Malformed raw GPS payload: '%s'",
        payload.c_str());
    }
    logRobotEvent(
      EventLevel::Warn,
      "packet_dropped",
      {
        {"topic", "/gps/odom"},
        {"connection_id", std::to_string(current_connection_id_)},
        {"reason", "malformed_payload"},
      });
    return;
  }

  try {
    double x = std::stod(x_text);
    double y = std::stod(y_text);
    double z = std::stod(z_text);

    if (gps_.swap_xy) {
      std::swap(x, y);
    }
    if (gps_.invert_x) {
      x = -x;
    }
    if (gps_.invert_y) {
      y = -y;
    }
    if (gps_.invert_z) {
      z = -z;
    }

    nav_msgs::msg::Odometry msg;
    msg.header.stamp = makeSensorStamp();
    msg.header.frame_id = gps_.odom_frame;
    msg.child_frame_id = gps_.frame;

    msg.pose.pose.position.x = x;
    msg.pose.pose.position.y = y;
    msg.pose.pose.position.z = z;

    msg.pose.pose.orientation.x = 0.0;
    msg.pose.pose.orientation.y = 0.0;
    msg.pose.pose.orientation.z = 0.0;
    msg.pose.pose.orientation.w = 1.0;

	    // Raw GPS remains available for diagnostics. The final odometry is published
	    // separately from LOC packets on /odometry/filtered.
    msg.pose.covariance.fill(0.0);
    msg.pose.covariance[0] = 0.000025;   // x sigma ~= 0.005 m
    msg.pose.covariance[7] = 0.000025;   // y sigma ~= 0.005 m
    msg.pose.covariance[14] = 999.0;     // z unused
    msg.pose.covariance[21] = 999.0;     // roll unused
    msg.pose.covariance[28] = 999.0;     // pitch unused
    msg.pose.covariance[35] = 999.0;     // yaw unavailable from GPS
    gps_odom_pub_->publish(msg);
    recordPublished(ProtocolMessageType::Gps);

    if (debug_mode_) {
      RCLCPP_INFO_THROTTLE(
        get_logger(),
        *get_clock(),
        1000,
        "Published raw /gps/odom local Webots measurement: x=%f y=%f z=%f",
        x,
        y,
        z);
    }
  } catch (const std::exception &) {
    recordParseError();
    if (debug_mode_) {
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "Malformed raw GPS numeric values: '%s'",
        payload.c_str());
    }
    logRobotEvent(
      EventLevel::Warn,
      "packet_dropped",
      {
        {"topic", "/gps/odom"},
        {"connection_id", std::to_string(current_connection_id_)},
        {"reason", "malformed_numeric_values"},
      });
  }
}

void BridgeNode::handleLocalization(const std::string & payload)
{
  std::stringstream ss(payload);
  std::vector<std::string> fields;
  std::string item;

  while (std::getline(ss, item, ',')) {
    fields.push_back(item);
  }

  if (fields.size() != 14) {
    recordParseError();
    logRobotEvent(
      EventLevel::Warn,
      "packet_dropped",
      {
        {"topic", "/odometry/filtered"},
        {"connection_id", std::to_string(current_connection_id_)},
        {"reason", "malformed_loc_payload"},
      });
    return;
  }

  try {
    const double x = std::stod(fields[0]);
    const double y = std::stod(fields[1]);
    const double z_debug = std::stod(fields[2]);
    const double yaw = std::stod(fields[3]);
    const double vx = std::stod(fields[4]);
    const double wz = std::stod(fields[5]);
    const double cov_x = std::stod(fields[6]);
    const double cov_y = std::stod(fields[7]);
    const double cov_yaw = std::stod(fields[8]);
    const double cov_vx = std::stod(fields[9]);
    const double cov_wz = std::stod(fields[10]);
    const bool gps_used = std::stoi(fields[11]) != 0;
    const bool gps_rejected = std::stoi(fields[12]) != 0;
    const bool slip = std::stoi(fields[13]) != 0;

    const bool numeric_ok =
      std::isfinite(x) &&
      std::isfinite(y) &&
      std::isfinite(z_debug) &&
      std::isfinite(yaw) &&
      std::isfinite(vx) &&
      std::isfinite(wz) &&
      std::isfinite(cov_x) &&
      std::isfinite(cov_y) &&
      std::isfinite(cov_yaw) &&
      std::isfinite(cov_vx) &&
      std::isfinite(cov_wz);

    if (!numeric_ok) {
      throw std::invalid_argument("non-finite localization value");
    }

    const auto stamp = makeSensorStamp();
    const double half_yaw = yaw * 0.5;
    const double qz = std::sin(half_yaw);
    const double qw = std::cos(half_yaw);

    nav_msgs::msg::Odometry msg;
    msg.header.stamp = stamp;
    msg.header.frame_id = "odom";
    msg.child_frame_id = "base_link";

    msg.pose.pose.position.x = x;
    msg.pose.pose.position.y = y;
    msg.pose.pose.position.z = 0.0;
    msg.pose.pose.orientation.x = 0.0;
    msg.pose.pose.orientation.y = 0.0;
    msg.pose.pose.orientation.z = qz;
    msg.pose.pose.orientation.w = qw;

    msg.twist.twist.linear.x = vx;
    msg.twist.twist.linear.y = 0.0;
    msg.twist.twist.angular.z = wz;

    msg.pose.covariance.fill(0.0);
    msg.pose.covariance[0] = std::max(0.0, cov_x);
    msg.pose.covariance[7] = std::max(0.0, cov_y);
    msg.pose.covariance[14] = 999.0;
    msg.pose.covariance[21] = 999.0;
    msg.pose.covariance[28] = 999.0;
    msg.pose.covariance[35] = std::max(0.0, cov_yaw);

    msg.twist.covariance.fill(0.0);
    msg.twist.covariance[0] = std::max(0.0, cov_vx);
    msg.twist.covariance[7] = 999.0;
    msg.twist.covariance[14] = 999.0;
    msg.twist.covariance[21] = 999.0;
    msg.twist.covariance[28] = 999.0;
    msg.twist.covariance[35] = std::max(0.0, cov_wz);

    localization_odom_pub_->publish(msg);

    if (tf_broadcaster_) {
      geometry_msgs::msg::TransformStamped tf_msg;
      tf_msg.header.stamp = stamp;
      tf_msg.header.frame_id = "odom";
      tf_msg.child_frame_id = "base_link";
      tf_msg.transform.translation.x = x;
      tf_msg.transform.translation.y = y;
      tf_msg.transform.translation.z = 0.0;
      tf_msg.transform.rotation = msg.pose.pose.orientation;
      tf_broadcaster_->sendTransform(tf_msg);

      bool should_log_first_tf = false;
      {
        std::lock_guard<std::mutex> lock(status_mutex_);
        ++tf_published_count_;
        if (!logged_first_tf_published_) {
          logged_first_tf_published_ = true;
          should_log_first_tf = true;
        }
      }

      if (should_log_first_tf) {
        RCLCPP_INFO(get_logger(), "first dynamic TF published: odom -> base_link");
        logRobotEvent(
          "topic_first_real",
          {
            {"topic", "/tf"},
            {"frame", "odom->base_link"},
            {"connection_id", std::to_string(current_connection_id_)},
            {"source", "bridge"},
            {"direction", "published"},
          });
      }
    }

    {
      std::lock_guard<std::mutex> lock(status_mutex_);
      last_loc_z_debug_ = z_debug;
    }

    recordPublished(ProtocolMessageType::Loc);

    RCLCPP_INFO_THROTTLE(
      get_logger(),
      *get_clock(),
      1000,
      "Published /odometry/filtered from LOC: x=%.4f y=%.4f yaw=%.4f vx=%.4f wz=%.4f "
      "gps_used=%s gps_rejected=%s slip=%s z_debug=%.4f",
      x,
      y,
      yaw,
      vx,
      wz,
      gps_used ? "true" : "false",
      gps_rejected ? "true" : "false",
      slip ? "true" : "false",
      z_debug);

  } catch (const std::exception &) {
    recordParseError();
    logRobotEvent(
      EventLevel::Warn,
      "packet_dropped",
      {
        {"topic", "/odometry/filtered"},
        {"connection_id", std::to_string(current_connection_id_)},
        {"reason", "malformed_loc_numeric_values"},
      });
  }
}

void BridgeNode::handleWheelOdom(const std::string & payload)
{
  std::stringstream ss(payload);

  std::string x_text;
  std::string y_text;
  std::string yaw_text;
  std::string vx_text;
  std::string wz_text;
  std::string slip_text;
  std::string extra_text;

  if (
    !std::getline(ss, x_text, ',') ||
    !std::getline(ss, y_text, ',') ||
    !std::getline(ss, yaw_text, ',') ||
    !std::getline(ss, vx_text, ',') ||
    !std::getline(ss, wz_text, ',') ||
    !std::getline(ss, slip_text, ',') ||
    std::getline(ss, extra_text, ','))
  {
    recordParseError();
    logRobotEvent(
      EventLevel::Warn,
      "packet_dropped",
      {
        {"topic", "/wheel/odom"},
        {"connection_id", std::to_string(current_connection_id_)},
        {"reason", "malformed_payload"},
      });
    return;
  }

  try {
    const double x = std::stod(x_text);
    const double y = std::stod(y_text);
    const double yaw = std::stod(yaw_text);
    const double vx = std::stod(vx_text);
    const double wz = std::stod(wz_text);
    const bool slip = std::stoi(slip_text) != 0;

    nav_msgs::msg::Odometry msg;
    msg.header.stamp = makeSensorStamp();
    msg.header.frame_id = "odom";
    msg.child_frame_id = "base_link";

    msg.pose.pose.position.x = x;
    msg.pose.pose.position.y = y;
    msg.pose.pose.position.z = 0.0;

    const double half_yaw = yaw * 0.5;
    msg.pose.pose.orientation.x = 0.0;
    msg.pose.pose.orientation.y = 0.0;
    msg.pose.pose.orientation.z = std::sin(half_yaw);
    msg.pose.pose.orientation.w = std::cos(half_yaw);

    msg.twist.twist.linear.x = vx;
    msg.twist.twist.linear.y = 0.0;
    msg.twist.twist.angular.z = wz;

	    // Wheel odom is kept for diagnostics only. /odometry/filtered comes from LOC.
    msg.pose.covariance.fill(0.0);

    if (slip) {
      msg.pose.covariance[0] = 0.25;     // x: não confiar se slip
      msg.pose.covariance[7] = 0.25;     // y
	      msg.pose.covariance[35] = 999.0;   // yaw unavailable from wheel debug
    } else {
      msg.pose.covariance[0] = 0.000025;   // x sigma = 1 cm
      msg.pose.covariance[7] = 0.000025;   // y sigma = 1 cm
	      msg.pose.covariance[35] = 999.0;   // yaw unavailable from wheel debug
    }

    msg.pose.covariance[14] = 999.0;
    msg.pose.covariance[21] = 999.0;
    msg.pose.covariance[28] = 999.0;

    msg.twist.covariance.fill(0.0);

    if (slip) {
      msg.twist.covariance[0] = 1.0;      // vx não confiável
      msg.twist.covariance[35] = 0.05;
    } else {
      msg.twist.covariance[0] = 0.0001;   // vx sigma = 0.02 m/s
      msg.twist.covariance[35] = 0.0016;  // wz sigma = 0.05 rad/s
    }

    msg.twist.covariance[7] = 999.0;
    msg.twist.covariance[14] = 999.0;
    msg.twist.covariance[21] = 999.0;
    msg.twist.covariance[28] = 999.0;

    wheel_odom_pub_->publish(msg);
    recordPublished(ProtocolMessageType::Odom);

    RCLCPP_INFO_THROTTLE(
      get_logger(),
      *get_clock(),
      1000,
      "Published /wheel/odom: x=%.4f y=%.4f yaw=%.4f vx=%.4f wz=%.4f slip=%s",
      x,
      y,
      yaw,
      vx,
      wz,
      slip ? "true" : "false");

  } catch (const std::exception &) {
    recordParseError();
    logRobotEvent(
      EventLevel::Warn,
      "packet_dropped",
      {
        {"topic", "/wheel/odom"},
        {"connection_id", std::to_string(current_connection_id_)},
        {"reason", "malformed_numeric_values"},
      });
  }
}

void BridgeNode::handleScan(const std::string & payload)
{
  if (payload.empty()) {
    recordParseError();
    if (debug_mode_) {
      RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 2000, "Received empty raw SCAN payload");
    }
    logRobotEvent(
      EventLevel::Warn,
      "packet_dropped",
      {
        {"topic", "/scan"},
        {"connection_id", std::to_string(current_connection_id_)},
        {"reason", "empty_payload"},
      });
    return;
  }

  const auto stamp = makeSensorStamp();

  std::vector<float> ranges;
  std::stringstream ss(payload);
  std::string range_text;

  while (std::getline(ss, range_text, ',')) {
    try {
      ranges.push_back(std::stof(range_text));
    } catch (const std::exception &) {
      ranges.push_back(std::numeric_limits<float>::quiet_NaN());
    }
  }

  if (ranges.empty()) {
    recordParseError();
    if (debug_mode_) {
      RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 2000, "Received empty raw SCAN payload");
    }
    logRobotEvent(
      EventLevel::Warn,
      "packet_dropped",
      {
        {"topic", "/scan"},
        {"connection_id", std::to_string(current_connection_id_)},
        {"reason", "no_ranges"},
      });
    return;
  }

  // Webots raw LiDAR order starts at robot front and wraps back to front.
  // ROS LaserScan over [-pi, pi] should have angle 0 at the middle of the ranges array.
  // Half-turn rotation converts front-start ordering to ROS-centered front ordering.
  if (scan_.rotate_half_turn) {
  std::rotate(ranges.begin(), ranges.begin() + ranges.size() / 2, ranges.end());
  }

  if (scan_.mirror_left_right) {
    mirrorScanLeftRight(ranges);
  }

  if (scan_.invert) {
    std::reverse(ranges.begin(), ranges.end());
  }
  
  sensor_msgs::msg::LaserScan msg;
  msg.header.stamp = stamp;
  msg.header.frame_id = scan_.frame;

  msg.angle_min = scan_.angle_min;

  const double angle_span = scan_.angle_max - scan_.angle_min;

  if (ranges.size() > 1) {

    constexpr double kTwoPi = 6.28318530717958647692;

    if (std::abs(angle_span - kTwoPi) < 1e-6) {
      msg.angle_increment = angle_span / static_cast<double>(ranges.size());
      msg.angle_max = scan_.angle_min +
        msg.angle_increment * static_cast<double>(ranges.size() - 1);
    } else {
      msg.angle_increment = angle_span / static_cast<double>(ranges.size() - 1);
      msg.angle_max = scan_.angle_max;
    }
  } else {
    msg.angle_increment = 0.0;
    msg.angle_max = scan_.angle_min;
  }

  msg.time_increment = 0.0;
  // scan_time is derived from RACE_SCAN_HZ (scan_time_s = 1 / scan_hz) so it stays
  // consistent with the controller's actual publish rate instead of a fixed 0.05 s.
  msg.scan_time = static_cast<float>(scan_time_s_);
  msg.range_min = scan_.range_min;
  msg.range_max = scan_.range_max;
  msg.ranges = ranges;

  scan_pub_->publish(msg);
  recordPublished(ProtocolMessageType::Scan);

  if (debug_mode_) {
    const auto middle_index = ranges.size() / 2;
    RCLCPP_INFO_THROTTLE(
      get_logger(),
      *get_clock(),
      1000,
      "Published raw /scan measurement: size=%zu first=%f middle=%f last=%f",
      ranges.size(),
      ranges.front(),
      ranges[middle_index],
      ranges.back());
  }
}

void BridgeNode::handleColor(const std::string & payload)
{
  std_msgs::msg::String msg;
  msg.data = payload;

  floor_color_pub_->publish(msg);
  recordPublished(ProtocolMessageType::Color);

  if (debug_mode_) {
    RCLCPP_INFO_THROTTLE(
      get_logger(),
      *get_clock(),
      1000,
      "Published floor color classification: %s",
      payload.c_str());
  }
}

void BridgeNode::handleHole(const std::string & payload)
{
  std_msgs::msg::String msg;
  msg.data = payload;
  hole_detection_pub_->publish(msg);
  recordPublished(ProtocolMessageType::Hole);

  logRobotEvent(
    "hole_detection_published",
    {
      {"topic", hole_detection_topic_},
      {"payload", payload},
      {"connection_id", std::to_string(current_connection_id_)},
    });
}

void BridgeNode::handleVision(const std::string & payload)
{
  std_msgs::msg::String msg;
  msg.data = payload;
  vision_classification_pub_->publish(msg);
  recordPublished(ProtocolMessageType::Vision);

  logRobotEvent(
    "vision_classification_published",
    {
      {"topic", vision_classification_topic_},
      {"payload", payload},
      {"connection_id", std::to_string(current_connection_id_)},
    });
}

void BridgeNode::submissionMatrixCallback(const std_msgs::msg::String::SharedPtr msg)
{
  if (!tcp_server_) {
    return;
  }

  std::string encoded = msg->data;

  std::replace(encoded.begin(), encoded.end(), '\r', ' ');
  std::replace(encoded.begin(), encoded.end(), '\n', ';');

  while (!encoded.empty() &&
    (encoded.back() == ';' || std::isspace(static_cast<unsigned char>(encoded.back()))))
  {
    encoded.pop_back();
  }

  std::ostringstream oss;
  oss << "SUBMISSION_MATRIX|" << encoded << "\n";

  if (!tcp_server_->sendLine(oss.str()) && debug_mode_) {
    RCLCPP_WARN_THROTTLE(
      get_logger(),
      *get_clock(),
      2000,
      "Dropping /mapper/submission_matrix because no Webots TCP client is connected");
  }
}

void BridgeNode::cmdVelCallback(const geometry_msgs::msg::Twist::SharedPtr msg)
{
  std::ostringstream oss;
  oss << "CMD|" << msg->linear.x << "," << msg->angular.z << "\n";

  if (debug_mode_) {
    RCLCPP_INFO(
      get_logger(),
      "Forwarding /cmd_vel to Webots: linear_x=%f angular_z=%f",
      msg->linear.x,
      msg->angular.z);
  }

  if (!tcp_server_->sendLine(oss.str())) {
    if (debug_mode_) {
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "Dropping /cmd_vel because no Webots TCP client is connected");
    }
    logRobotEvent(
      EventLevel::Warn,
      "packet_dropped",
      {
        {"topic", "/cmd_vel"},
        {"connection_id", std::to_string(current_connection_id_)},
        {"reason", "tcp_client_not_connected"},
        {"raw_v", numberText(msg->linear.x, 4)},
        {"raw_w", numberText(msg->angular.z, 4)},
      });
  }
}

}  // namespace ros2_bridge
