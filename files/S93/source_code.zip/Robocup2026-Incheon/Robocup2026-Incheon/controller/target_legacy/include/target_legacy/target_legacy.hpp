#pragma once

#include <array>
#include <string>

#include <opencv2/core.hpp>

namespace target_legacy {

struct TargetLegacyConfig {
  int min_edge_points = 40;
  int min_target_axis_px = 25;
  int max_target_axis_px = 180;
  int min_component_area_px = 120;
  double min_fill_ratio = 0.08;
  int polar_width = 720;
  int polar_height = 360;
  double max_fit_error = 0.85;
  int band_count = 5;
};

struct TargetLegacyResult {
  bool valid = false;
  float confidence = 0.0f;

  float center_x = 0.0f;
  float center_y = 0.0f;
  float radius_px = 0.0f;

  float major_radius_px = 0.0f;
  float minor_radius_px = 0.0f;
  float angle_deg = 0.0f;
  float fit_error = 0.0f;

  std::array<std::string, 5> colors{{"none", "none", "none", "none", "none"}};
  std::string pattern = "none";

  cv::Rect visible_bbox;
};

TargetLegacyResult detectTargetLegacy(const cv::Mat& bgr,
                                      const TargetLegacyConfig& config = TargetLegacyConfig{});

}  // namespace target_legacy
