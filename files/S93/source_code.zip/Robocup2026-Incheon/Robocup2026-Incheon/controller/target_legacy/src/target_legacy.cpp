#include "target_legacy/target_legacy.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <numeric>
#include <sstream>
#include <vector>

#include <opencv2/imgproc.hpp>

namespace target_legacy {
namespace {

enum TargetColorId : unsigned char {
  kNotTarget = 0,
  kYellow = 1,
  kGreen = 2,
  kRed = 3,
  kBlue = 4,
  kBlack = 5,
};

struct ColorCounts {
  int yellow = 0;
  int green = 0;
  int red = 0;
  int blue = 0;
  int black = 0;
};

struct EllipseCandidate {
  bool valid = false;
  cv::Point2f center;
  float major_radius_px = 0.0f;
  float minor_radius_px = 0.0f;
  float angle_deg = 0.0f;
  float fit_error = std::numeric_limits<float>::infinity();
  cv::Rect visible_bbox;
  int area = 0;
  double fill_ratio = 0.0;
  cv::Mat component_mask;
};

double clampDouble(double value, double lo, double hi)
{
  return std::max(lo, std::min(value, hi));
}

int classify_color_bgr(const cv::Vec3b& bgr)
{
  cv::Mat3b pixel(1, 1);
  pixel(0, 0) = bgr;
  cv::Mat3b hsv_pixel;
  cv::cvtColor(pixel, hsv_pixel, cv::COLOR_BGR2HSV);
  const cv::Vec3b hsv = hsv_pixel(0, 0);

  const int h = hsv[0];
  const int s = hsv[1];
  const int v = hsv[2];

  if (v < 70) {
    return kBlack;
  }
  if (s < 55 || v < 75) {
    return kNotTarget;
  }
  if (h < 8 || h >= 170) {
    return kRed;
  }
  if (h >= 18 && h <= 38) {
    return kYellow;
  }
  if (h >= 40 && h <= 90) {
    return kGreen;
  }
  if (h >= 95 && h <= 135) {
    return kBlue;
  }
  return kNotTarget;
}

std::string colorName(int color_id)
{
  switch (color_id) {
    case kYellow:
      return "yellow";
    case kGreen:
      return "green";
    case kRed:
      return "red";
    case kBlue:
      return "blue";
    case kBlack:
      return "black";
    default:
      return "none";
  }
}

std::string most_common(const ColorCounts& counts)
{
  std::array<std::pair<int, int>, 5> ranked{{
    {kYellow, counts.yellow},
    {kGreen, counts.green},
    {kRed, counts.red},
    {kBlue, counts.blue},
    {kBlack, counts.black},
  }};
  const auto best = std::max_element(
    ranked.begin(),
    ranked.end(),
    [](const auto& a, const auto& b) { return a.second < b.second; });
  return best != ranked.end() && best->second > 0 ? colorName(best->first) : "none";
}

void addColor(ColorCounts& counts, int color_id)
{
  switch (color_id) {
    case kYellow:
      ++counts.yellow;
      break;
    case kGreen:
      ++counts.green;
      break;
    case kRed:
      ++counts.red;
      break;
    case kBlue:
      ++counts.blue;
      break;
    case kBlack:
      ++counts.black;
      break;
    default:
      break;
  }
}

cv::Mat build_target_color_id_map(const cv::Mat& bgr)
{
  cv::Mat color_ids(bgr.rows, bgr.cols, CV_8UC1, cv::Scalar(kNotTarget));
  cv::Mat nonblack_target(bgr.rows, bgr.cols, CV_8UC1, cv::Scalar(0));
  cv::Mat black_candidates(bgr.rows, bgr.cols, CV_8UC1, cv::Scalar(0));

  for (int y = 0; y < bgr.rows; ++y) {
    const auto* row = bgr.ptr<cv::Vec3b>(y);
    auto* id_row = color_ids.ptr<unsigned char>(y);
    auto* color_row = nonblack_target.ptr<unsigned char>(y);
    auto* black_row = black_candidates.ptr<unsigned char>(y);
    for (int x = 0; x < bgr.cols; ++x) {
      const int id = classify_color_bgr(row[x]);
      if (id == kBlack) {
        black_row[x] = 255;
      } else if (id != kNotTarget) {
        id_row[x] = static_cast<unsigned char>(id);
        color_row[x] = 255;
      }
    }
  }

  cv::Mat nearby_target;
  const cv::Mat near_kernel = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(7, 7));
  cv::dilate(nonblack_target, nearby_target, near_kernel);

  cv::Mat accepted_black = black_candidates & nearby_target;
  for (int y = 0; y < color_ids.rows; ++y) {
    auto* id_row = color_ids.ptr<unsigned char>(y);
    const auto* black_row = accepted_black.ptr<unsigned char>(y);
    for (int x = 0; x < color_ids.cols; ++x) {
      if (black_row[x] != 0) {
        id_row[x] = kBlack;
      }
    }
  }

  return color_ids;
}

cv::Mat cleanConnectedComponents(const cv::Mat& mask, int min_area)
{
  cv::Mat labels;
  cv::Mat stats;
  cv::Mat centroids;
  const int count = cv::connectedComponentsWithStats(mask, labels, stats, centroids, 8);
  cv::Mat clean = cv::Mat::zeros(mask.size(), CV_8UC1);
  for (int i = 1; i < count; ++i) {
    if (stats.at<int>(i, cv::CC_STAT_AREA) >= min_area) {
      clean.setTo(255, labels == i);
    }
  }
  return clean;
}

void extract_target_mask_and_edges(const cv::Mat& color_ids,
                                   const TargetLegacyConfig& config,
                                   cv::Mat& mask,
                                   cv::Mat& edges)
{
  mask = color_ids > 0;
  const cv::Mat kernel = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(3, 3));
  cv::morphologyEx(mask, mask, cv::MORPH_OPEN, kernel);
  cv::morphologyEx(mask, mask, cv::MORPH_CLOSE, kernel);

  const int cleanup_area = std::max(8, std::min(30, config.min_component_area_px / 4));
  mask = cleanConnectedComponents(mask, cleanup_area);
  cv::Canny(mask, edges, 50.0, 150.0);
}

cv::Point2f largest_component_centroid(const cv::Mat& color_ids,
                                       int color_id,
                                       const cv::Mat& visible_mask,
                                       bool& found)
{
  cv::Mat color_mask = (color_ids == color_id) & visible_mask;
  cv::Mat labels;
  cv::Mat stats;
  cv::Mat centroids;
  const int count = cv::connectedComponentsWithStats(color_mask, labels, stats, centroids, 8);

  int best_label = -1;
  int best_area = 0;
  for (int i = 1; i < count; ++i) {
    const int area = stats.at<int>(i, cv::CC_STAT_AREA);
    if (area > best_area) {
      best_label = i;
      best_area = area;
    }
  }

  found = best_label >= 0;
  if (!found) {
    return {};
  }
  return cv::Point2f(static_cast<float>(centroids.at<double>(best_label, 0)),
                     static_cast<float>(centroids.at<double>(best_label, 1)));
}

cv::RotatedRect normalize_ellipse(const cv::RotatedRect& ellipse)
{
  cv::RotatedRect out = ellipse;
  if (out.size.height > out.size.width) {
    std::swap(out.size.width, out.size.height);
    out.angle += 90.0f;
  }
  while (out.angle >= 180.0f) {
    out.angle -= 180.0f;
  }
  while (out.angle < 0.0f) {
    out.angle += 180.0f;
  }
  return out;
}

double ellipse_fit_error(const cv::RotatedRect& ellipse, const std::vector<cv::Point>& points)
{
  if (points.empty()) {
    return std::numeric_limits<double>::infinity();
  }

  const double a = std::max(1.0, static_cast<double>(ellipse.size.width) * 0.5);
  const double b = std::max(1.0, static_cast<double>(ellipse.size.height) * 0.5);
  const double angle = -ellipse.angle * CV_PI / 180.0;
  const double ca = std::cos(angle);
  const double sa = std::sin(angle);

  double total = 0.0;
  for (const auto& p : points) {
    const double dx = static_cast<double>(p.x) - ellipse.center.x;
    const double dy = static_cast<double>(p.y) - ellipse.center.y;
    const double x = dx * ca - dy * sa;
    const double y = dx * sa + dy * ca;
    const double normalized = std::sqrt((x * x) / (a * a) + (y * y) / (b * b));
    total += std::fabs(normalized - 1.0);
  }
  return total / static_cast<double>(points.size());
}

EllipseCandidate detect_raw_visible_target_ellipse(const cv::Mat& mask,
                                                   const cv::Mat& edges,
                                                   const TargetLegacyConfig& config)
{
  EllipseCandidate candidate;

  cv::Mat labels;
  cv::Mat stats;
  cv::Mat centroids;
  const int count = cv::connectedComponentsWithStats(mask, labels, stats, centroids, 8);

  int best_label = -1;
  int best_area = 0;
  for (int i = 1; i < count; ++i) {
    const int area = stats.at<int>(i, cv::CC_STAT_AREA);
    if (area > best_area) {
      best_label = i;
      best_area = area;
    }
  }

  if (best_label < 0 || best_area < config.min_component_area_px) {
    return candidate;
  }

  candidate.visible_bbox = cv::Rect(stats.at<int>(best_label, cv::CC_STAT_LEFT),
                                    stats.at<int>(best_label, cv::CC_STAT_TOP),
                                    stats.at<int>(best_label, cv::CC_STAT_WIDTH),
                                    stats.at<int>(best_label, cv::CC_STAT_HEIGHT));
  candidate.area = best_area;
  const double bbox_area = std::max(1, candidate.visible_bbox.area());
  candidate.fill_ratio = static_cast<double>(best_area) / bbox_area;
  if (candidate.fill_ratio < config.min_fill_ratio) {
    return candidate;
  }

  candidate.component_mask = labels == best_label;

  cv::Mat edge_points_mask = edges & candidate.component_mask;
  std::vector<cv::Point> points;
  cv::findNonZero(edge_points_mask, points);
  if (static_cast<int>(points.size()) < config.min_edge_points) {
    cv::findNonZero(candidate.component_mask, points);
  }
  if (static_cast<int>(points.size()) < config.min_edge_points || points.size() < 5) {
    return candidate;
  }

  cv::RotatedRect ellipse = normalize_ellipse(cv::fitEllipse(points));
  const float major_axis = std::max(ellipse.size.width, ellipse.size.height);
  const float minor_axis = std::min(ellipse.size.width, ellipse.size.height);
  if (major_axis < config.min_target_axis_px ||
      minor_axis < config.min_target_axis_px * 0.35f ||
      major_axis > config.max_target_axis_px) {
    return candidate;
  }

  const double fit_error = ellipse_fit_error(ellipse, points);
  if (!std::isfinite(fit_error) || fit_error > config.max_fit_error) {
    return candidate;
  }

  candidate.valid = true;
  candidate.center = ellipse.center;
  candidate.major_radius_px = major_axis * 0.5f;
  candidate.minor_radius_px = minor_axis * 0.5f;
  candidate.angle_deg = ellipse.angle;
  candidate.fit_error = static_cast<float>(fit_error);
  return candidate;
}

cv::Point2f estimate_projected_target_center(const cv::Mat& color_ids,
                                             const EllipseCandidate& ellipse)
{
  bool found = false;
  cv::Point2f center = largest_component_centroid(color_ids, kYellow, ellipse.component_mask, found);
  if (found) {
    return center;
  }

  cv::Mat warm_mask = ((color_ids == kRed) | (color_ids == kGreen)) & ellipse.component_mask;
  cv::Moments warm_moments = cv::moments(warm_mask, true);
  if (warm_moments.m00 > 1.0) {
    return cv::Point2f(static_cast<float>(warm_moments.m10 / warm_moments.m00),
                       static_cast<float>(warm_moments.m01 / warm_moments.m00));
  }

  return ellipse.center;
}

int classify_hsv_color(const cv::Vec3b& hsv)
{
  const int h = hsv[0];
  const int s = hsv[1];
  const int v = hsv[2];
  if (v < 70) {
    return kBlack;
  }
  if (s < 55 || v < 75) {
    return kNotTarget;
  }
  if (h < 8 || h >= 170) {
    return kRed;
  }
  if (h >= 18 && h <= 38) {
    return kYellow;
  }
  if (h >= 40 && h <= 90) {
    return kGreen;
  }
  if (h >= 95 && h <= 135) {
    return kBlue;
  }
  return kNotTarget;
}

std::array<std::string, 5> classifyPolarBands(const cv::Mat& bgr,
                                              const cv::Point2f& center,
                                              float radius,
                                              const TargetLegacyConfig& config)
{
  std::array<std::string, 5> colors{{"none", "none", "none", "none", "none"}};
  const int polar_width = std::max(32, config.polar_width);
  const int polar_height = std::max(40, config.polar_height);

  cv::Mat hsv;
  cv::cvtColor(bgr, hsv, cv::COLOR_BGR2HSV);

  cv::Mat polar;
  cv::warpPolar(hsv,
                polar,
                cv::Size(polar_width, polar_height),
                center,
                std::max(2.0f, radius),
                cv::WARP_POLAR_LINEAR | cv::INTER_LINEAR);

  const int bands = std::max(1, std::min(5, config.band_count));
  for (int band = 0; band < bands; ++band) {
    const int x0 = band * polar.cols / bands;
    const int x1 = (band + 1) * polar.cols / bands;
    ColorCounts counts;
    for (int y = 0; y < polar.rows; ++y) {
      const auto* row = polar.ptr<cv::Vec3b>(y);
      for (int x = x0; x < x1; ++x) {
        addColor(counts, classify_hsv_color(row[x]));
      }
    }
    colors[static_cast<std::size_t>(band)] = most_common(counts);
  }

  return colors;
}

std::string makePattern(const std::array<std::string, 5>& colors)
{
  std::ostringstream oss;
  for (std::size_t i = 0; i < colors.size(); ++i) {
    if (i != 0) {
      oss << '-';
    }
    oss << (colors[i].empty() ? "none" : colors[i]);
  }
  return oss.str();
}

int validColorCount(const std::array<std::string, 5>& colors)
{
  int count = 0;
  for (const auto& color : colors) {
    if (color == "yellow" || color == "green" || color == "red" ||
        color == "blue" || color == "black") {
      ++count;
    }
  }
  return count;
}

}  // namespace

TargetLegacyResult detectTargetLegacy(const cv::Mat& bgr, const TargetLegacyConfig& config)
{
  TargetLegacyResult result;
  if (bgr.empty()) {
    return result;
  }

  const cv::Mat color_ids = build_target_color_id_map(bgr);
  cv::Mat mask;
  cv::Mat edges;
  extract_target_mask_and_edges(color_ids, config, mask, edges);

  const EllipseCandidate ellipse = detect_raw_visible_target_ellipse(mask, edges, config);
  if (!ellipse.valid) {
    return result;
  }

  const cv::Point2f center = estimate_projected_target_center(color_ids, ellipse);
  const float radius = std::max(ellipse.major_radius_px, ellipse.minor_radius_px);
  const auto colors = classifyPolarBands(bgr, center, radius, config);
  if (validColorCount(colors) < 3) {
    return result;
  }

  result.valid = true;
  result.center_x = center.x;
  result.center_y = center.y;
  result.radius_px = radius;
  result.major_radius_px = ellipse.major_radius_px;
  result.minor_radius_px = ellipse.minor_radius_px;
  result.angle_deg = ellipse.angle_deg;
  result.fit_error = ellipse.fit_error;
  result.colors = colors;
  result.pattern = makePattern(colors);
  result.visible_bbox = ellipse.visible_bbox;

  const double fit_score = 1.0 - clampDouble(ellipse.fit_error / std::max(0.001, config.max_fit_error), 0.0, 1.0);
  const double fill_score = clampDouble(ellipse.fill_ratio / std::max(0.001, config.min_fill_ratio * 4.0), 0.0, 1.0);
  const double area_score = clampDouble(static_cast<double>(ellipse.area) /
                                          std::max(1, bgr.rows * bgr.cols / 3),
                                        0.0,
                                        1.0);
  result.confidence = static_cast<float>(clampDouble(0.45 * fit_score +
                                                       0.35 * fill_score +
                                                       0.20 * area_score,
                                                     0.0,
                                                     1.0));
  return result;
}

}  // namespace target_legacy
