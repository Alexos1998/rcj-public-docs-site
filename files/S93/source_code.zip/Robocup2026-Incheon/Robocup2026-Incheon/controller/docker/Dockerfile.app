ARG BASE_IMAGE_TAG=controller-base:24.04
FROM ${BASE_IMAGE_TAG}

ENV PATH="/usr/lib/ccache:${PATH}"

ENV CMAKE_CXX_COMPILER_LAUNCHER=ccache
ENV CMAKE_C_COMPILER_LAUNCHER=ccache

ARG BUILD_TYPE=Release

SHELL ["/bin/bash", "-o", "pipefail", "-lc"]

# =========================================================
# ROS2 WORKSPACE
# =========================================================

WORKDIR /workspace/controller/ros2_ws

COPY ros2_ws/src ./src
COPY exploration_legacy /workspace/controller/exploration_legacy
COPY target_legacy /workspace/controller/target_legacy

RUN find ./src -path "*/scripts/*" -type f -exec chmod +x {} \;

RUN --mount=type=cache,target=/root/.cache/ccache \
    source /opt/ros/jazzy/setup.bash && \
    colcon build \
    --executor parallel \
    --parallel-workers $(nproc) \
    --event-handlers console_direct+ \
    --cmake-args \
    -DCMAKE_BUILD_TYPE=${BUILD_TYPE}

# =========================================================
# WEBOTS CONTROLLER
# =========================================================

WORKDIR /workspace/controller

COPY include ./include
COPY src ./src
COPY scripts ./scripts
COPY exploration_legacy ./exploration_legacy
COPY target_legacy ./target_legacy
COPY models ./models

COPY main.cpp .
COPY Makefile .
COPY Makefile.include .

RUN find ./scripts -type f -name "*.sh" -exec sed -i 's/\r$//' {} \; && \
    find ./scripts -type f -name "*.sh" -exec chmod +x {} \;

RUN --mount=type=cache,target=/root/.cache/ccache \
    make -j$(nproc)

# =========================================================
# STARTUP
# =========================================================

COPY Ros.sh /workspace/controller/Ros.sh

RUN chmod +x /workspace/controller/Ros.sh && \
    sed -i 's/\r$//' /workspace/controller/Ros.sh

ENTRYPOINT ["/workspace/controller/Ros.sh"]
