#!/usr/bin/env bash
set -Eeo pipefail

# =========================================================
# FLAGS
# =========================================================

START_MAPPER_WAS_SET=0
START_NAV2_WAS_SET=0
START_RVIZ_WAS_SET=0
PRINT_LOG_TERMINALS_WAS_SET=0
[[ -n "${START_MAPPER+x}" ]] && START_MAPPER_WAS_SET=1
[[ -n "${START_NAV2+x}" ]] && START_NAV2_WAS_SET=1
[[ -n "${START_RVIZ+x}" ]] && START_RVIZ_WAS_SET=1
[[ -n "${PRINT_LOG_TERMINALS+x}" ]] && PRINT_LOG_TERMINALS_WAS_SET=1

export DEBUG_TOPICS="${DEBUG_TOPICS:-0}"
export DEBUG_TOPICS_INTERVAL="${DEBUG_TOPICS_INTERVAL:-3}"
export RACE_MODE="${RACE_MODE:-1}"
export RACE_BOOTSTRAP_YAW="${RACE_BOOTSTRAP_YAW:-1.5708}"
export LEGACY_REACHABILITY_FALLBACK_ENABLED="${LEGACY_REACHABILITY_FALLBACK_ENABLED:-true}"

export START_BRIDGE="${START_BRIDGE:-1}"
export START_VISION="${START_VISION:-1}"
export START_ROS2_VISION="${START_ROS2_VISION:-0}"
export VISION_TCP_HOST="${VISION_TCP_HOST:-127.0.0.1}"
export VISION_FRAME_PORT="${VISION_FRAME_PORT:-5100}"
export VISION_RESULT_PORT="${VISION_RESULT_PORT:-5101}"
export VISION_SEND_EVERY_N="${VISION_SEND_EVERY_N:-2}"
export VISION_IMAGE_ENCODING="${VISION_IMAGE_ENCODING:-BGR8}"
export VISION_CLASSIFY_HOLD_S="${VISION_CLASSIFY_HOLD_S:-1.2}"
export VISION_HOLD_AFTER_TILE_ADVANCE="${VISION_HOLD_AFTER_TILE_ADVANCE:-0}"
export VISION_REPORT_DUPLICATE_SCOPE="${VISION_REPORT_DUPLICATE_SCOPE:-tile_kind_class}"
export VISION_LIDAR_GATE_ENABLED="${VISION_LIDAR_GATE_ENABLED:-0}"
export VISION_LIDAR_GATE_MIN_CONSECUTIVE_RAYS="${VISION_LIDAR_GATE_MIN_CONSECUTIVE_RAYS:-5}"
export VISION_LIDAR_GATE_MAX_RANGE_M="${VISION_LIDAR_GATE_MAX_RANGE_M:-0.06}"
export VISION_VALID_DETECTION_DISTANCE_M="${VISION_VALID_DETECTION_DISTANCE_M:-0.06}"
export VISION_TARGET_LIDAR_GATE_ENABLED="${VISION_TARGET_LIDAR_GATE_ENABLED:-0}"
export VISION_VICTIM_LIDAR_GATE_ENABLED="${VISION_VICTIM_LIDAR_GATE_ENABLED:-0}"
export VISION_PIPELINE_LIDAR_GATE_MAX_RANGE_M="${VISION_PIPELINE_LIDAR_GATE_MAX_RANGE_M:-0.06}"
# Minimum confidence to REPORT a detection. Was 0.0 (no floor) -> a conf=0.029
# 9x9px target got reported (Misidentification of Target -5). Good reports were
# all >= 0.81, so 0.5 blocks the garbage without dropping valid detections.
export VISION_MIN_RESULT_CONFIDENCE="${VISION_MIN_RESULT_CONFIDENCE:-0.5}"
export VISION_ALIGN_AJUST="${VISION_ALIGN_AJUST:-1}"
export VISION_ALIGN_MAX_TIME_S="${VISION_ALIGN_MAX_TIME_S:-0.8}"
export VISION_ALIGN_THRESHOLD_PX="${VISION_ALIGN_THRESHOLD_PX:-8}"
export VISION_ALIGN_RESTORE_HEADING="${VISION_ALIGN_RESTORE_HEADING:-0}"
export VISION_ALIGN_RESTORE_MAX_TIME_S="${VISION_ALIGN_RESTORE_MAX_TIME_S:-1.6}"
export VISION_ALIGN_RESTORE_THRESHOLD_RAD="${VISION_ALIGN_RESTORE_THRESHOLD_RAD:-0.035}"
export VISION_TARGET_GATE_SEARCH_ENABLED="${VISION_TARGET_GATE_SEARCH_ENABLED:-1}"
export VISION_TARGET_GATE_SEARCH_TIME_S="${VISION_TARGET_GATE_SEARCH_TIME_S:-1.0}"
export VISION_TARGET_GATE_SEARCH_ANGULAR_RAD_S="${VISION_TARGET_GATE_SEARCH_ANGULAR_RAD_S:-0.45}"
export START_BOOTSTRAP="${START_BOOTSTRAP:-0}"
export START_CONTROLLER="${START_CONTROLLER:-1}"
export START_LOCALIZATION="${START_LOCALIZATION:-1}"
export START_MAPPER="${START_MAPPER:-1}"
export START_NAV2="${START_NAV2:-1}"
export START_EXPLORER="${START_EXPLORER:-1}"
export START_EXPLORER_GRAPH_VIZ="${START_EXPLORER_GRAPH_VIZ:-1}"
export RVIZ_SOFTWARE_RENDERING="${RVIZ_SOFTWARE_RENDERING:-0}"
export START_RVIZ="${START_RVIZ:-0}"
export START_MAP_DATASET="${START_MAP_DATASET:-1}"
export MAP_DATASET_NO_COPY="${MAP_DATASET_NO_COPY:-1}"
export MAP_DATASET_LATEST="${MAP_DATASET_LATEST:-0}"
export MAP_DATASET_INCLUDE_LATEST="${MAP_DATASET_INCLUDE_LATEST:-0}"
export MAP_DATASET_DAY="${MAP_DATASET_DAY:-}"
export MAP_DATASET_RUN="${MAP_DATASET_RUN:-}"
export MAP_DATASET_WORLD="${MAP_DATASET_WORLD:-}"
export MAP_DATASET_RUN_WORLD_MAP="${MAP_DATASET_RUN_WORLD_MAP:-}"
export MAP_DATASET_LIMIT="${MAP_DATASET_LIMIT:-}"
export EXPLORER_AUTO_START="${EXPLORER_AUTO_START:-true}"

export RACE_USE_SIM_TIME_BOOL="${RACE_USE_SIM_TIME_BOOL:-true}"

export EXPLORER_BACKEND="${EXPLORER_BACKEND:-legacy}"

export EXPLORATION_PARAMS_FILE="${EXPLORATION_PARAMS_FILE:-/workspace/controller/ros2_ws/src/ros2_exploration/config/explorer.yaml}"
export EXPLORER_LOG_LEVEL="${EXPLORER_LOG_LEVEL:-info}"

case "$EXPLORER_BACKEND" in
    legacy|continuous|tile)
        ;;
    *)
        echo "[ERRO] EXPLORER_BACKEND inválido: '$EXPLORER_BACKEND'"
        echo "[ERRO] Valores válidos: legacy, continuous, tile"
        exit 2
        ;;
esac

if [[ "$EXPLORER_BACKEND" == "legacy" ]]; then
    export START_BOOTSTRAP=0
    export START_EXPLORER=0
    export START_EXPLORATION=0
    export DEBUG_TOPICS="${DEBUG_TOPICS:-0}"

    case "${LEGACY_REACHABILITY_FALLBACK_ENABLED,,}" in
        1|true|yes|on)
            if [[ "$START_NAV2" != "1" ]]; then
                echo "[WARN] legacy reachability está habilitado; sobrescrevendo START_NAV2=$START_NAV2 para START_NAV2=1"
            fi
            if [[ "$START_MAPPER" != "1" ]]; then
                echo "[WARN] legacy reachability está habilitado; sobrescrevendo START_MAPPER=$START_MAPPER para START_MAPPER=1"
            fi
            export START_NAV2=1
            export START_MAPPER=1
            ;;
        *)
            if [[ "$START_NAV2_WAS_SET" != "1" ]]; then
                export START_NAV2=1
            fi
            if [[ "$START_MAPPER_WAS_SET" != "1" ]]; then
                export START_MAPPER=1
            fi
            ;;
    esac

    if [[ "$START_RVIZ_WAS_SET" != "1" ]]; then
        export START_RVIZ=1
    fi

    if [[ "$PRINT_LOG_TERMINALS_WAS_SET" != "1" ]]; then
        export PRINT_LOG_TERMINALS=1
    fi

    if [[ -z "${RVIZ_CONFIG:-}" ]]; then
        export RVIZ_CONFIG=/workspace/controller/ros2_ws/src/ros2_bridge/config/rviz_legacy_light.rviz
    fi

    echo "[INFO] EXPLORER_BACKEND=legacy -> direct Webots legacy exploration"
    echo "[INFO] legacy backend keeps Nav2 active for reachability only"
    echo "[INFO] legacy backend disables ros2_exploration backends"
    echo "[INFO] legacy Nav2 reachability: enabled=$LEGACY_REACHABILITY_FALLBACK_ENABLED START_NAV2=$START_NAV2 START_EXPLORER=$START_EXPLORER START_EXPLORER_GRAPH_VIZ=$START_EXPLORER_GRAPH_VIZ"
    echo "[INFO] legacy mapper for Nav2 costmap: START_MAPPER=$START_MAPPER"
    echo "[INFO] Webots controller will run exploration_legacy internally"
fi

export PRINT_LOG_TERMINALS="${PRINT_LOG_TERMINALS:-1}"
export PRINT_CONTROLLER_EVENTS="${PRINT_CONTROLLER_EVENTS:-0}"

export MAPPER_MODE="${MAPPER_MODE:-slam_toolbox}"

case "$MAPPER_MODE" in
    semantic|slam_toolbox)
        ;;
    mixed)
        echo "[ERRO] MAPPER_MODE=mixed reservado, ainda não implementado neste slice."
        exit 2
        ;;
    *)
        echo "[ERRO] MAPPER_MODE inválido: '$MAPPER_MODE'"
        echo "[ERRO] Valores válidos: semantic, slam_toolbox, mixed"
        exit 2
        ;;
esac

export NAV2_MODE="${NAV2_MODE:-slam}"

case "$NAV2_MODE" in
    slam|odom)
        ;;
    *)
        echo "[ERRO] NAV2_MODE inválido: '$NAV2_MODE'"
        echo "[ERRO] Valores válidos: slam, odom"
        exit 2
        ;;
esac

if [[ "$START_NAV2" == "1" && "$NAV2_MODE" == "slam" && "$MAPPER_MODE" != "slam_toolbox" ]]; then
    echo "[WARN] NAV2_MODE=slam espera /map e TF map -> odom. MAPPER_MODE atual não é slam_toolbox; esses dados precisam existir externamente."
fi

if [[ "$START_NAV2" == "1" && "$NAV2_MODE" == "odom" ]]; then
    echo "[INFO] NAV2_MODE=odom -> Nav2 usa frame odom e não espera /map."
fi

LOCAL_SENSOR_PIPELINE=1
if [[ "$START_BRIDGE" != "1" || "$START_CONTROLLER" != "1" ]]; then
    LOCAL_SENSOR_PIPELINE=0
    echo "[WARN] START_BRIDGE=$START_BRIDGE START_CONTROLLER=$START_CONTROLLER -> pipeline local de sensores incompleto."
    echo "[WARN] A infraestrutura ROS ainda será iniciada; os nós consumidores aguardarão dados internamente."
fi

export ROS2_BRIDGE_DEBUG="${ROS2_BRIDGE_DEBUG:-false}"

export AMENT_TRACE_SETUP_FILES="${AMENT_TRACE_SETUP_FILES:-}"
export ROS_AUTOMATIC_DISCOVERY_RANGE="${ROS_AUTOMATIC_DISCOVERY_RANGE:-SUBNET}"
export LANG="${LANG:-C.UTF-8}"
export LC_ALL="${LC_ALL:-C.UTF-8}"

export RCUTILS_LOGGING_BUFFERED_STREAM=1
export FASTDDS_BUILTIN_TRANSPORTS=UDPv4

# =========================================================
# TIMING / FREQUÊNCIAS / TEMPO DE SIMULAÇÃO
# =========================================================
#
# Fonte única de verdade para frequências, períodos e modo de tempo.
# Tudo abaixo é exportado para que:
#   - o controller Webots (main.cpp) leia RACE_*_HZ / RACE_USE_SIM_TIME;
#   - o YAML runtime gerado mais adiante aplique os mesmos valores ao ROS 2.
#
# Precedência:
#   1) variável específica setada no ambiente sempre vence (ex.: RACE_SCAN_HZ);
#   2) caso contrário, usa o valor do perfil (RACE_TIMING_PROFILE) escalado por
#      RACE_RATE_SCALE e limitado por clamps mínimos/máximos razoáveis.
#
# RACE_USE_SIM_TIME:
#   0 (default) -> wall-time, inicialização rápida, ROS não espera /clock.
#   1           -> sim-time real, bridge publica /clock e carimba sensores
#                  com o tempo do Webots.

# Toda a lógica de resolução (perfis, escala, clamps, overrides) e a geração do
# YAML de runtime vivem em scripts/race_timing_lib.sh, para serem testáveis
# isoladamente (scripts/smoke_timing_config.sh) sem subir a stack inteira.
RACE_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=scripts/race_timing_lib.sh
source "$RACE_SCRIPT_DIR/scripts/race_timing_lib.sh"

if ! race_timing_resolve; then
    exit 2
fi
race_timing_log

# =========================================================
# SOURCE
# =========================================================

source /opt/ros/jazzy/setup.bash

if [[ "${DEV_MODE:-0}" == "1" && "${ROS2_DEV_AUTOBUILD:-1}" == "1" ]]; then
    echo "[INFO] DEV_MODE=1 -> colcon build incremental"

    cd /workspace/controller/ros2_ws

    ROS2_PACKAGES_TO_BUILD="${ROS2_DEV_PACKAGES:-ros2_bridge ros2_vision ros2_bootstrap ros2_mapper ros2_navigation ros2_exploration}"

    colcon build \
        --symlink-install \
        --packages-select $ROS2_PACKAGES_TO_BUILD \
        --executor sequential \
        --parallel-workers 1 \
        --event-handlers console_direct+

    cd /workspace/controller
fi

if [[ -f /workspace/controller/ros2_ws/install/setup.bash ]]; then
    source /workspace/controller/ros2_ws/install/setup.bash
else
    echo "[WARN] ros2_ws install/setup.bash não encontrado."
    echo "[WARN] Se estiver em DEV_MODE, rode colcon build dentro do container."
fi

# =========================================================
# QT / WSL
# =========================================================

export QT_X11_NO_MITSHM=1
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/tmp/runtime-root}"
mkdir -p "$XDG_RUNTIME_DIR"
chmod 700 "$XDG_RUNTIME_DIR" || true
echo "[INFO] XDG_RUNTIME_DIR=$XDG_RUNTIME_DIR"
export XAUTHORITY="${XAUTHORITY:-/tmp/.docker.xauth}"
echo "[INFO] XAUTHORITY=$XAUTHORITY"

# Prefer hardware OpenGL for RViz. Software rendering was the main slowdown on
# WSL/Mesa in large graph views. Set RVIZ_SOFTWARE_RENDERING=1 only when your
# host GPU/driver cannot start RViz.
if [[ "$RVIZ_SOFTWARE_RENDERING" == "1" ]]; then
    export LIBGL_ALWAYS_SOFTWARE=1
    export MESA_GL_VERSION_OVERRIDE=3.3
    export QT_OPENGL=software
    export OGRE_RTT_MODE=Copy
else
    unset LIBGL_ALWAYS_SOFTWARE
    unset MESA_GL_VERSION_OVERRIDE
    unset QT_OPENGL
    unset OGRE_RTT_MODE
fi

# =========================================================
# LOGS
# =========================================================

LOG_ROOT="${LOG_ROOT:-/workspace/controller/logs}"
LOG_LATEST_DIR="$LOG_ROOT/latest"

sanitize_log_component() {
    local value="${1:-unknown_map}"
    value="${value##*/}"
    value="${value%.*}"
    value="${value// /_}"
    value="$(printf '%s' "$value" | tr -cd '[:alnum:]_.-')"
    if [[ -z "$value" ]]; then
        value="unknown_map"
    fi
    printf '%s' "$value"
}

resolve_run_map_name() {
    local candidate="${RUN_MAP_NAME:-${MAP_NAME:-${WORLD_NAME:-}}}"
    if [[ -z "$candidate" ]]; then
        candidate="${WORLD_PATH:-${WEBOTS_WORLD:-${EREBUS_WORLD:-}}}"
    fi
    if [[ -z "$candidate" && -d "$RACE_SCRIPT_DIR/mapsdataset/runs" ]]; then
        local latest_map_path
        latest_map_path="$(
            find "$RACE_SCRIPT_DIR/mapsdataset/runs" -mindepth 2 -maxdepth 2 -name map_path.txt -printf '%T@ %p\n' 2>/dev/null |
            sort -nr |
            awk 'NR==1 {print $2}'
        )"
        if [[ -n "$latest_map_path" && -f "$latest_map_path" ]]; then
            candidate="$(head -n 1 "$latest_map_path" 2>/dev/null || true)"
        fi
    fi
    sanitize_log_component "$candidate"
}

RUN_LOG_TIMESTAMP="${RUN_LOG_TIMESTAMP:-$(date +%Y-%m-%d_%H-%M-%S)}"
RUN_MAP_NAME_SAFE="${RUN_MAP_NAME_SAFE:-$(resolve_run_map_name)}"
RUN_LOG_DIR="${RUN_LOG_DIR:-$LOG_ROOT/${RUN_LOG_TIMESTAMP}_${RUN_MAP_NAME_SAFE}}"
LOG_DIR="$LOG_LATEST_DIR"

mkdir -p "$LOG_ROOT"

# latest agora é diretório real, não symlink.
# Se existir symlink antigo, remove uma vez.
if [[ -L "$LOG_LATEST_DIR" ]]; then
    rm -f "$LOG_LATEST_DIR"
fi

mkdir -p "$LOG_LATEST_DIR" "$RUN_LOG_DIR"

# latest é sobrescrito pela execução mais recente, mas segue sendo diretório real.
find "$LOG_DIR" -mindepth 1 -maxdepth 1 -exec rm -rf {} +
mkdir -p "$LOG_DIR/ros2" "$RUN_LOG_DIR/ros2"

export ROS_LOG_DIR="$LOG_DIR/ros2"
export RCUTILS_LOGGING_BUFFERED_STREAM=0
export RCUTILS_LOGGING_USE_STDOUT=1
export RCUTILS_LOGGING_MIN_SEVERITY=40
export PYTHONUNBUFFERED=1

BRIDGE_LOG="$LOG_DIR/bridge.log"
VISION_LOG="$LOG_DIR/vision.log"
BOOTSTRAP_LOG="$LOG_DIR/bootstrap.log"
CONTROLLER_LOG="$LOG_DIR/controller.log"
LOCALIZATION_LOG="$LOG_DIR/localization.log"
MAPPER_LOG="$LOG_DIR/mapper.log"
NAV2_LOG="$LOG_DIR/nav2.log"
EXPLORER_LOG="$LOG_DIR/explorer.log"
RVIZ_LOG="$LOG_DIR/rviz.log"
MAP_DATASET_LOG="$LOG_DIR/map_dataset.log"
DEBUG_LOG="$LOG_DIR/debug_topics.log"
UNIQUE_LOG="$LOG_DIR/unique.log"
CLASSIFICATION_IMAGE_DIR="$LOG_DIR/images"
RUN_CLASSIFICATION_IMAGE_DIR="$RUN_LOG_DIR/images"

: > "$BRIDGE_LOG"
: > "$VISION_LOG"
: > "$BOOTSTRAP_LOG"
: > "$CONTROLLER_LOG"
: > "$LOCALIZATION_LOG"
: > "$MAPPER_LOG"
: > "$NAV2_LOG"
: > "$EXPLORER_LOG"
: > "$RVIZ_LOG"
: > "$MAP_DATASET_LOG"
: > "$DEBUG_LOG"
: > "$UNIQUE_LOG"
rm -rf "$CLASSIFICATION_IMAGE_DIR"
rm -rf "$RUN_CLASSIFICATION_IMAGE_DIR"
mkdir -p "$CLASSIFICATION_IMAGE_DIR" "$RUN_CLASSIFICATION_IMAGE_DIR"

link_log_file_to_run_dir() {
    local latest_file="$1"
    local run_file="$RUN_LOG_DIR/$(basename "$latest_file")"
    rm -f "$run_file"
    ln "$latest_file" "$run_file" 2>/dev/null || cp -f "$latest_file" "$run_file"
}

for log_file in \
    "$BRIDGE_LOG" \
    "$VISION_LOG" \
    "$BOOTSTRAP_LOG" \
    "$CONTROLLER_LOG" \
    "$LOCALIZATION_LOG" \
    "$MAPPER_LOG" \
    "$NAV2_LOG" \
    "$EXPLORER_LOG" \
    "$RVIZ_LOG" \
    "$MAP_DATASET_LOG" \
    "$DEBUG_LOG" \
    "$UNIQUE_LOG"
do
    link_log_file_to_run_dir "$log_file"
done

cat > "$LOG_DIR/run_metadata.txt" <<EOF
timestamp=$RUN_LOG_TIMESTAMP
map=$RUN_MAP_NAME_SAFE
latest_dir=$LOG_DIR
run_dir=$RUN_LOG_DIR
explorer_backend=$EXPLORER_BACKEND
EOF
rm -f "$RUN_LOG_DIR/run_metadata.txt"
ln "$LOG_DIR/run_metadata.txt" "$RUN_LOG_DIR/run_metadata.txt" 2>/dev/null || cp -f "$LOG_DIR/run_metadata.txt" "$RUN_LOG_DIR/run_metadata.txt"

# Caminho do log dedicado do UniqueLogger (utils/UniqueLogger.*). O controller
# lê esta env para escrever direto no unique.log, separado do controller.log.
export UNIQUE_LOG_PATH="$UNIQUE_LOG"
export VISION_CLASSIFICATION_IMAGE_DIR="$CLASSIFICATION_IMAGE_DIR"
export RUN_LOG_DIR
echo "[INFO] UNIQUE_LOG=$UNIQUE_LOG"
echo "[INFO] CLASSIFICATION_IMAGE_DIR=$CLASSIFICATION_IMAGE_DIR"
echo "[INFO] LOG_LATEST_DIR=$LOG_DIR"
echo "[INFO] RUN_LOG_DIR=$RUN_LOG_DIR"

# =========================================================
# RUNTIME TIMING PARAMS (YAML de override)
# =========================================================
#
# Gera um arquivo YAML único, carregado por último em cada launch, sobrescrevendo
# os YAMLs base sem precisar editá-los. Centraliza use_sim_time e as frequências
# resolvidas acima para Nav2, costmaps, SLAM e a bridge.
#
# Os launches recebem este caminho via runtime_params_file:=$RACE_RUNTIME_PARAMS_FILE.

export RACE_RUNTIME_PARAMS_FILE="${RACE_RUNTIME_PARAMS_FILE:-$LOG_DIR/runtime_timing.yaml}"

# race_timing_write_yaml vem de scripts/race_timing_lib.sh (já sourced acima).
race_timing_write_yaml "$RACE_RUNTIME_PARAMS_FILE"
rm -f "$RUN_LOG_DIR/$(basename "$RACE_RUNTIME_PARAMS_FILE")"
ln "$RACE_RUNTIME_PARAMS_FILE" "$RUN_LOG_DIR/$(basename "$RACE_RUNTIME_PARAMS_FILE")" 2>/dev/null ||
    cp -f "$RACE_RUNTIME_PARAMS_FILE" "$RUN_LOG_DIR/$(basename "$RACE_RUNTIME_PARAMS_FILE")"

echo "[timing] runtime params -> $RACE_RUNTIME_PARAMS_FILE"

# =========================================================
# PIDS
# =========================================================

BRIDGE_PID=""
VISION_PID=""
BOOTSTRAP_PID=""
CONTROLLER_PID=""
LOCALIZATION_PID=""
MAPPER_PID=""
NAV2_PID=""
EXPLORER_PID=""
RVIZ_PID=""
DEBUG_PID=""
TAIL_BRIDGE_PID=""
TAIL_VISION_PID=""
TAIL_BOOTSTRAP_PID=""
TAIL_CONTROLLER_PID=""
TAIL_LOCALIZATION_PID=""
TAIL_MAPPER_PID=""
TAIL_NAV2_PID=""
TAIL_EXPLORER_PID=""
TAIL_RVIZ_PID=""
TAIL_DEBUG_PID=""
OPERATOR_CONSOLE_PID=""

CLEANUP_DONE=0

cleanup() {
    if [[ "$CLEANUP_DONE" == "1" ]]; then
        return
    fi
    CLEANUP_DONE=1

    echo "[INFO] Encerrando..."

    for pid in \
        "$OPERATOR_CONSOLE_PID" \
        "$TAIL_DEBUG_PID" \
        "$TAIL_RVIZ_PID" \
        "$TAIL_EXPLORER_PID" \
        "$TAIL_NAV2_PID" \
        "$TAIL_MAPPER_PID" \
        "$TAIL_LOCALIZATION_PID" \
        "$TAIL_CONTROLLER_PID" \
        "$TAIL_BOOTSTRAP_PID" \
        "$TAIL_VISION_PID" \
        "$TAIL_BRIDGE_PID" \
        "$DEBUG_PID" \
        "$RVIZ_PID" \
        "$EXPLORER_PID" \
        "$NAV2_PID" \
        "$MAPPER_PID" \
        "$LOCALIZATION_PID" \
        "$CONTROLLER_PID" \
        "$BOOTSTRAP_PID" \
        "$VISION_PID" \
        "$MAP_DATASET_PID" \
        "$BRIDGE_PID"
    do
        [[ -n "${pid:-}" ]] && kill "$pid" 2>/dev/null || true
    done

    if [[ -n "${RUN_LOG_DIR:-}" && -d "${LOG_DIR:-}" && "$RUN_LOG_DIR" != "$LOG_DIR" ]]; then
        rm -rf "$RUN_LOG_DIR/ros2" "$RUN_LOG_DIR/images" 2>/dev/null || true
        cp -a "$LOG_DIR/ros2" "$RUN_LOG_DIR/ros2" 2>/dev/null || true
        cp -a "$LOG_DIR/images" "$RUN_LOG_DIR/images" 2>/dev/null || true
    fi

    if [[ "${START_MAP_DATASET:-0}" == "1" && -f "$RACE_SCRIPT_DIR/mapsdataset/create.py" ]]; then
        local dataset_cmd=(python3 "$RACE_SCRIPT_DIR/mapsdataset/create.py" --logs-root "$LOG_ROOT")
        if [[ "${MAP_DATASET_NO_COPY:-1}" == "1" ]]; then
            dataset_cmd+=(--no-copy)
        fi
        if [[ "${MAP_DATASET_LATEST:-0}" == "1" ]]; then
            dataset_cmd+=(--latest)
        fi
        if [[ "${MAP_DATASET_INCLUDE_LATEST:-0}" == "1" ]]; then
            dataset_cmd+=(--include-latest)
        fi
        if [[ -n "${MAP_DATASET_DAY:-}" ]]; then
            dataset_cmd+=(--day "$MAP_DATASET_DAY")
        fi
        if [[ -n "${MAP_DATASET_RUN:-}" ]]; then
            dataset_cmd+=(--run "$MAP_DATASET_RUN")
        fi
        if [[ -n "${MAP_DATASET_WORLD:-}" ]]; then
            dataset_cmd+=(--world "$MAP_DATASET_WORLD")
        fi
        if [[ -n "${MAP_DATASET_RUN_WORLD_MAP:-}" ]]; then
            dataset_cmd+=(--run-world-map "$MAP_DATASET_RUN_WORLD_MAP")
        fi
        if [[ -n "${MAP_DATASET_LIMIT:-}" ]]; then
            dataset_cmd+=(--limit "$MAP_DATASET_LIMIT")
        fi

        echo "[INFO] Building complete mapsdataset from logs: ${dataset_cmd[*]}"
        "${dataset_cmd[@]}" \
            > "$MAP_DATASET_LOG" 2>&1 || {
            echo "[AVISO] mapsdataset create.py falhou"
            cat "$MAP_DATASET_LOG" 2>/dev/null || true
        }
    fi

    # Container roda como root: liberar os outputs bind-montados (logs + dataset)
    # para que o usuário do host edite/mova/apague sem sudo.
    chmod -R a+rwX "$LOG_ROOT" "$RACE_SCRIPT_DIR/mapsdataset" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

# =========================================================
# HELPERS
# =========================================================

operator_field() {
    local line="$1"
    local key="$2"
    local rest=""

    rest="${line#*${key}=}"

    if [[ "$rest" == "$line" ]]; then
        echo ""
        return
    fi

    echo "${rest%% *}"
}

operator_say() {
    echo "$1"
}

print_operator_console() {
    if [[ "$PRINT_CONTROLLER_EVENTS" != "1" ]]; then
        return
    fi

    if [[ -z "${CONTROLLER_LOG:-}" ]]; then
        return
    fi

    echo
    echo "========== OPERATOR CONSOLE =========="
    echo "[BOOT] Logs completos: $LOG_DIR"
    echo "[BOOT] Controller log: $CONTROLLER_LOG"
    echo "[BOOT] Terminal mostrando apenas inicialização, máquina de estado e decisões-chave."
    echo

    local last_current=""

    tail -n +1 -F "$CONTROLLER_LOG" 2>/dev/null | while IFS= read -r line; do
        [[ "$line" != *"ROBOT_EVENT"* ]] && continue

        local event=""
        local node=""

        event="$(operator_field "$line" "event")"
        node="$(operator_field "$line" "node")"

        [[ -z "$event" ]] && continue

        case "$event" in
            controller_started)
                operator_say "[BOOT] Controller iniciado: backend=$(operator_field "$line" "explorer_backend"), visão=$(operator_field "$line" "vision_transport"), sensores principais habilitados."
                ;;

            vision_client_started)
                operator_say "[BOOT] Visão iniciada: TCP $(operator_field "$line" "host"):$(operator_field "$line" "frame_port"), hold=$(operator_field "$line" "classify_hold_s")s."
                ;;

            started)
                if [[ "$node" == "legacy_explorer" ]]; then
                    operator_say "[BOOT] Explorador legacy iniciado: movimento=$(operator_field "$line" "movement"), segurança=$(operator_field "$line" "hole_safety")."
                fi
                ;;

            config)
                if [[ "$node" == "legacy_explorer" ]]; then
                    operator_say "[BOOT] Configuração legacy: passo=$(operator_field "$line" "legacy_step_m")m, threshold_parede=$(operator_field "$line" "wall_threshold_m"), diagonais habilitadas."
                fi
                ;;

            start_tile_set)
                operator_say "[STATE] Ladrilho inicial definido: $(operator_field "$line" "tile")."
                ;;

            step_begin)
                local current=""
                local heading=""

                current="$(operator_field "$line" "current")"
                heading="$(operator_field "$line" "heading")"

                if [[ "$current" != "$last_current" ]]; then
                    echo
                    operator_say "[STATE] Ladrilho atual: $current, olhando $heading."
                    last_current="$current"
                fi
                ;;

            walls_sensed)
                local current=""
                local front=""
                local right=""
                local left=""
                local front_txt=""
                local right_txt=""
                local left_txt=""

                current="$(operator_field "$line" "current")"
                front="$(operator_field "$line" "front_open")"
                right="$(operator_field "$line" "right_open")"
                left="$(operator_field "$line" "left_open")"

                [[ "$front" == "1" ]] && front_txt="livre" || front_txt="bloqueada"
                [[ "$right" == "1" ]] && right_txt="livre" || right_txt="bloqueada"
                [[ "$left" == "1" ]] && left_txt="livre" || left_txt="bloqueada"

                operator_say "[SENSE] Paredes em $current: frente=$front_txt, direita=$right_txt, esquerda=$left_txt."
                ;;

            planner_decision)
                local current=""
                local target=""
                local dir=""
                local backtracking=""

                current="$(operator_field "$line" "current")"
                target="$(operator_field "$line" "target")"
                dir="$(operator_field "$line" "dir")"
                backtracking="$(operator_field "$line" "backtracking")"

                if [[ "$backtracking" == "1" ]]; then
                    operator_say "[DECISION] Backtracking: de $current para $target pela direção $dir."
                else
                    operator_say "[DECISION] Próximo alvo: $target pela direção $dir. Exploração normal."
                fi
                ;;

            turn_start)
                operator_say "[MOTION] Girando para alinhar com o próximo alvo..."
                ;;

            turn_skipped_already_aligned)
                operator_say "[MOTION] Giro pulado: já estou alinhado."
                ;;

            turn_timeout_but_continuing)
                operator_say "[WARN] Giro atingiu timeout, mas vou continuar. erro=$(operator_field "$line" "error")."
                ;;

            turn_done)
                operator_say "[MOTION] Giro concluído em $(operator_field "$line" "duration")s, erro=$(operator_field "$line" "error")."
                ;;

            drive_start)
                operator_say "[MOTION] Avançando $(operator_field "$line" "requested")m até o próximo ladrilho..."
                ;;

            drive_done)
                operator_say "[MOTION] Deslocamento concluído: medido=$(operator_field "$line" "measured")m, erro=$(operator_field "$line" "error")."
                ;;

            tile_advanced)
                operator_say "[ARRIVED] Cheguei no ladrilho $(operator_field "$line" "to") vindo de $(operator_field "$line" "from"), heading=$(operator_field "$line" "heading"). Visitados=$(operator_field "$line" "visited_count"), bloqueados=$(operator_field "$line" "blocked_count"), buracos=$(operator_field "$line" "hole_count")."
                ;;

            hole_blocked)
                operator_say "[SAFETY] Buraco detectado/bloqueado em $(operator_field "$line" "tile"). Não vou entrar nesse ladrilho."
                ;;

            vision_hold_started)
                operator_say "[VISION] Parando no ladrilho $(operator_field "$line" "tile") para classificar vítimas/targets por $(operator_field "$line" "duration")s."
                ;;

            vision_victim_reported)
                operator_say "[VICTIM] Vítima reportada: classe=$(operator_field "$line" "class"), tile=$(operator_field "$line" "tile"), câmera=$(operator_field "$line" "camera"), confiança=$(operator_field "$line" "confidence")."
                ;;

            vision_target_accepted)
                operator_say "[TARGET] Target aceito: padrão=$(operator_field "$line" "pattern"), tile=$(operator_field "$line" "tile"), confiança=$(operator_field "$line" "confidence")."
                ;;

            report_resume_navigation)
                operator_say "[VISION] Classificação finalizada em $(operator_field "$line" "tile"). Resultado=$(operator_field "$line" "result"). Retomando navegação."
                ;;

            exploration_complete_returning_to_start)
                operator_say "[RETURN] Exploração completa. Iniciando retorno ao início."
                ;;

            return_path_built)
                operator_say "[RETURN] Caminho de retorno calculado. Passos restantes=$(operator_field "$line" "remaining")."
                ;;

            return_step)
                operator_say "[RETURN] Voltando: $(operator_field "$line" "from") -> $(operator_field "$line" "to")."
                ;;

            finished_at_start)
                operator_say "[DONE] Robô retornou ao início. Exploração encerrada."
                ;;
        esac
    done
}

wait_tcp_port() {
    local host="$1"
    local port="$2"
    local timeout_s="$3"

    local deadline=$((SECONDS + timeout_s))

    while (( SECONDS < deadline )); do
        if python3 - "$host" "$port" <<'PY' >/dev/null 2>&1
import socket
import sys

host = sys.argv[1]
port = int(sys.argv[2])

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.settimeout(0.2)
try:
    sock.connect((host, port))
finally:
    sock.close()
PY
        then
            return 0
        fi

        sleep 0.1
    done

    return 1
}

wait_ros_topic() {
    local topic="$1"
    local timeout_s="$2"

    local deadline=$((SECONDS + timeout_s))

    while (( SECONDS < deadline )); do
        if ros2 topic list 2>/dev/null | grep -qx "$topic"; then
            return 0
        fi

        sleep 0.2
    done

    return 1
}

wait_ros_topic_optional() {
    local topic="$1"
    local timeout_s="$2"
    local note="${3:-consumer node will wait internally}"

    if wait_ros_topic "$topic" "$timeout_s"; then
        echo "[INFO] Topic disponível: $topic"
        return 0
    fi

    echo "[WARN] Topic $topic não apareceu em ${timeout_s}s; continuando ($note)."
    return 0
}

wait_ros_topic_required() {
    local topic="$1"
    local timeout_s="$2"
    local note="${3:-required for activation}"

    echo "[INFO] Waiting required topic $topic (${timeout_s}s)"
    if wait_ros_topic "$topic" "$timeout_s"; then
        echo "[INFO] Required topic ready: $topic"
        return 0
    fi

    echo "[ERRO] Timeout esperando $topic ($note)"
    return 1
}

print_relevant_readiness_logs() {
    echo "========== BRIDGE LOG (tail) =========="
    if [[ -f "${BRIDGE_LOG:-}" ]]; then
        tail -n 80 "$BRIDGE_LOG" || true
    else
        echo "[WARN] BRIDGE_LOG indisponível"
    fi

    echo "========== CONTROLLER LOG (tail) =========="
    if [[ -f "${CONTROLLER_LOG:-}" ]]; then
        tail -n 80 "$CONTROLLER_LOG" || true
    else
        echo "[WARN] CONTROLLER_LOG indisponível"
    fi

    echo "========== LOCALIZATION LOG (tail) =========="
    if [[ -f "${LOCALIZATION_LOG:-}" ]]; then
        tail -n 80 "$LOCALIZATION_LOG" || true
    else
        echo "[WARN] LOCALIZATION_LOG indisponível"
    fi
}

print_message_wait_failure_context() {
    local topic="$1"

    echo "========== TOPIC INFO: $topic =========="
    timeout 5 ros2 topic info -v "$topic" || true
    print_relevant_readiness_logs
}

print_odometry_wait_failure_context() {
    echo "========== BRIDGE READY =========="
    timeout 8 ros2 topic echo /ros2_bridge/ready --once \
        --qos-reliability reliable \
        --qos-durability transient_local || true

    echo "========== BRIDGE STATUS =========="
    timeout 8 ros2 topic echo /ros2_bridge/status --once \
        --qos-reliability reliable \
        --qos-durability transient_local || true

    echo "========== TOPIC INFO: /gps/odom =========="
    timeout 5 ros2 topic info -v /gps/odom || true

    echo "========== TOPIC INFO: /imu/data =========="
    timeout 5 ros2 topic info -v /imu/data || true

    echo "========== LOCALIZATION LOG (tail) =========="
    if [[ -f "${LOCALIZATION_LOG:-}" ]]; then
        tail -n 120 "$LOCALIZATION_LOG" || true
    else
        echo "[WARN] LOCALIZATION_LOG indisponível"
    fi

    echo "========== BRIDGE LOG (tail) =========="
    if [[ -f "${BRIDGE_LOG:-}" ]]; then
        tail -n 120 "$BRIDGE_LOG" || true
    else
        echo "[WARN] BRIDGE_LOG indisponível"
    fi
}

wait_ros_message_required() {
    local topic="$1"
    local timeout_s="$2"
    local note="${3:-required for activation}"
    local qos_profile="${4:-}"
    local deadline=$((SECONDS + timeout_s))
    local echo_log="/tmp/ros_message_wait_${topic//\//_}.log"

    echo "[INFO] Waiting real ROS message on $topic (${timeout_s}s, $note)"

    while (( SECONDS < deadline )); do
        : > "$echo_log"

        if [[ -n "$qos_profile" ]]; then
            if timeout 3 ros2 topic echo "$topic" --once --qos-profile "$qos_profile" >"$echo_log" 2>&1; then
                echo "[INFO] Real ROS message received on $topic"
                return 0
            fi

            : > "$echo_log"
        fi

        # Map and costmap publishers commonly use reliable + transient_local.
        # Try that QoS explicitly before falling back to ros2 topic echo defaults.
        if timeout 3 ros2 topic echo "$topic" --once \
            --qos-reliability reliable \
            --qos-durability transient_local >"$echo_log" 2>&1; then
            echo "[INFO] Real ROS message received on $topic (reliable/transient_local)"
            return 0
        fi

        : > "$echo_log"
        if timeout 3 ros2 topic echo "$topic" --once >"$echo_log" 2>&1; then
            echo "[INFO] Real ROS message received on $topic"
            return 0
        fi

        sleep 0.5
    done

    echo "[ERRO] Timeout esperando mensagem real em $topic ($note)"
    cat "$echo_log" 2>/dev/null || true
    if [[ "$topic" == "/odometry/filtered" ]]; then
        print_odometry_wait_failure_context
    else
        print_message_wait_failure_context "$topic"
    fi
    return 1
}

wait_bridge_costmap_received() {
    local timeout_s="$1"
    local deadline=$((SECONDS + timeout_s))
    local status_output=""

    echo "[INFO] Waiting ros2_bridge to receive /global_costmap/costmap (${timeout_s}s)"

    while (( SECONDS < deadline )); do
        if [[ -f "${BRIDGE_LOG:-}" ]] &&
            grep -q "event=legacy_reachability_costmap_received" "$BRIDGE_LOG"
        then
            echo "[INFO] ros2_bridge confirmed receipt of the global costmap"
            return 0
        fi

        status_output="$(
            timeout 3 ros2 topic echo /ros2_bridge/status --once \
                --qos-reliability reliable \
                --qos-durability transient_local 2>/dev/null || true
        )"
        if echo "$status_output" | grep -Eq '\"legacy_global_costmap_received\"[[:space:]]*:[[:space:]]*true'; then
            echo "[INFO] /ros2_bridge/status confirmed receipt of the global costmap"
            return 0
        fi

        sleep 0.5
    done

    echo "[ERRO] ros2_bridge did not receive /global_costmap/costmap"
    echo "========== /ros2_bridge/status =========="
    echo "$status_output"
    echo "========== BRIDGE LOG (tail) =========="
    tail -n 120 "$BRIDGE_LOG" 2>/dev/null || true
    return 1
}

wait_nav2_activation_inputs() {
    local timeout_s="${1:-45}"

    echo "[INFO] Waiting inputs required to activate Nav2 costmaps"

    if ! wait_ros_message_required /map "$timeout_s" \
        "global costmap static layer requires a real map"; then
        return 1
    fi

    if ! wait_tf_transform map base_link "$timeout_s"; then
        return 1
    fi

    echo "[INFO] Nav2 activation inputs ready: /map and TF map -> base_link"
    return 0
}

verify_nav2_reachability_runtime() {
    local timeout_s="${1:-30}"

    echo "[INFO] Verifying Nav2 reachability infrastructure"

    if ! wait_lifecycle_active /planner_server "$timeout_s"; then
        echo "[ERRO] planner_server is not active"
        print_nav2_snapshot || true
        return 1
    fi

    if ! wait_compute_path_action_server "$timeout_s"; then
        print_nav2_snapshot || true
        return 1
    fi

    if ! wait_ros_message_required /global_costmap/costmap "$timeout_s" \
        "legacy reachability requires a published global costmap"; then
        print_nav2_snapshot || true
        return 1
    fi

    if ! wait_bridge_costmap_received "$timeout_s"; then
        print_nav2_snapshot || true
        return 1
    fi

    echo "[INFO] NAV2 REACHABILITY READY: planner_server=active compute_path_to_pose=ready global_costmap=publishing bridge_subscription=receiving"
    timeout 5 ros2 topic info -v /global_costmap/costmap || true
    return 0
}

wait_bridge_sensor_status_required() {
    local timeout_s="$1"
    local deadline=$((SECONDS + timeout_s))
    local ready_output=""
    local ready_log="/tmp/bridge_ready_wait.log"

    echo "[INFO] Waiting ros2_bridge sensor/localization readiness on /ros2_bridge/ready (${timeout_s}s)"

    while (( SECONDS < deadline )); do
        ready_output="$(
            timeout 8 ros2 topic echo /ros2_bridge/ready --once \
                --qos-reliability reliable \
                --qos-durability transient_local \
                2>"$ready_log" || true
        )"

	        if echo "$ready_output" | grep -Eq '"ready"[[:space:]]*:[[:space:]]*true' &&
	            echo "$ready_output" | grep -Eq '"tcp"[[:space:]]*:[[:space:]]*true' &&
	            echo "$ready_output" | grep -Eq '"localization"[[:space:]]*:[[:space:]]*true' &&
	            echo "$ready_output" | grep -Eq '"gps"[[:space:]]*:[[:space:]]*true' &&
	            echo "$ready_output" | grep -Eq '"imu"[[:space:]]*:[[:space:]]*true' &&
	            echo "$ready_output" | grep -Eq '"scan"[[:space:]]*:[[:space:]]*true'
	        then
	            echo "[INFO] Bridge sensor/localization readiness confirmed: loc/gps/imu/scan received and published"
	            return 0
	        fi

	        if [[ -f "${BRIDGE_LOG:-}" ]] &&
	            grep -q "ros2_bridge ready: tcp/gps/imu/scan/localization confirmed" "$BRIDGE_LOG"
	        then
	            echo "[WARN] /ros2_bridge/ready echo returned no parseable sample; using bridge log readiness confirmation"
	            echo "[INFO] Bridge sensor/localization readiness confirmed: loc/gps/imu/scan received and published"
	            return 0
	        fi

        sleep 0.5
    done

	    echo "[ERRO] Bridge sensor/localization readiness timeout: last ready=${ready_output}"
    cat "$ready_log" 2>/dev/null || true
    echo "========== LAST /ros2_bridge/ready =========="
    timeout 8 ros2 topic echo /ros2_bridge/ready --once \
        --qos-reliability reliable \
        --qos-durability transient_local || true
    echo "========== LAST /ros2_bridge/status =========="
    timeout 8 ros2 topic echo /ros2_bridge/status --once \
        --qos-reliability reliable \
        --qos-durability transient_local || true
    echo "========== TOPIC INFO: /ros2_bridge/ready =========="
    timeout 5 ros2 topic info -v /ros2_bridge/ready || true
    echo "========== BRIDGE LOG (tail) =========="
    if [[ -f "${BRIDGE_LOG:-}" ]]; then
        tail -n 120 "$BRIDGE_LOG" || true
    else
        echo "[WARN] BRIDGE_LOG indisponível"
    fi
    echo "========== CONTROLLER LOG (tail) =========="
    if [[ -f "${CONTROLLER_LOG:-}" ]]; then
        tail -n 120 "$CONTROLLER_LOG" || true
    else
        echo "[WARN] CONTROLLER_LOG indisponível"
    fi
    return 1
}

wait_ros_settle() {
    local label="$1"
    local timeout_s="${2:-5}"

    echo "[INFO] Waiting ROS settle: $label (${timeout_s}s)"

    local deadline=$((SECONDS + timeout_s))

    while (( SECONDS < deadline )); do
        ros2 topic list >/dev/null 2>&1 || true
        ros2 node list >/dev/null 2>&1 || true
        ros2 topic list 2>/dev/null | grep -q '^/tf$' || true
        ros2 topic list 2>/dev/null | grep -q '^/tf_static$' || true
        sleep 0.5
    done

    return 0
}

lifecycle_state_name() {
    local output="$1"
    printf '%s\n' "$output" | awk 'NF { print tolower($1); exit }'
}

lifecycle_state_is() {
    local output="$1"
    local expected="$2"
    [[ "$(lifecycle_state_name "$output")" == "$expected" ]]
}

wait_lifecycle_active() {
    local node="$1"
    local timeout_s="$2"
    local state=""

    local deadline=$((SECONDS + timeout_s))

    while (( SECONDS < deadline )); do
        state="$(timeout 5 ros2 lifecycle get "$node" 2>/dev/null || true)"
        if lifecycle_state_is "$state" active; then
            return 0
        fi

        sleep 0.5
    done

    return 1
}

wait_ros_service() {
    local service="$1"
    local timeout_s="$2"

    local deadline=$((SECONDS + timeout_s))

    while (( SECONDS < deadline )); do
        if ros2 service list 2>/dev/null | grep -qx "$service"; then
            return 0
        fi

        sleep 0.5
    done

    return 1
}

print_tf_wait_failure_context() {
    echo "========== /odometry/filtered SAMPLE =========="
    timeout 3 ros2 topic echo /odometry/filtered --once --qos-profile sensor_data || true

    echo "========== TOPIC INFO: /odometry/filtered =========="
    timeout 5 ros2 topic info -v /odometry/filtered || true

    echo "========== /tf SAMPLE =========="
    timeout 3 ros2 topic echo /tf --once || true

    echo "========== LOCALIZATION LOG (tail) =========="
    if [[ -f "${LOCALIZATION_LOG:-}" ]]; then
        tail -n 120 "$LOCALIZATION_LOG" || true
    else
        echo "[WARN] LOCALIZATION_LOG indisponível"
    fi

    echo "========== BRIDGE LOG (tail) =========="
    if [[ -f "${BRIDGE_LOG:-}" ]]; then
        tail -n 120 "$BRIDGE_LOG" || true
    else
        echo "[WARN] BRIDGE_LOG indisponível"
    fi
}

wait_tf_transform() {
    local parent_frame="$1"
    local child_frame="$2"
    local timeout_s="$3"

    local deadline=$((SECONDS + timeout_s))

    echo "[INFO] Waiting TF ${parent_frame} -> ${child_frame} (${timeout_s}s)"

    while (( SECONDS < deadline )); do
        : > /tmp/tf_wait.log
        timeout 5 ros2 run tf2_ros tf2_echo "$parent_frame" "$child_frame" >/tmp/tf_wait.log 2>&1 || true

        if grep -q "At time\\|Translation:" /tmp/tf_wait.log; then
            echo "[INFO] TF ready: ${parent_frame} -> ${child_frame}"
            return 0
        fi

        sleep 0.5
    done

    echo "[ERRO] Timeout esperando TF ${parent_frame} -> ${child_frame}"
    cat /tmp/tf_wait.log 2>/dev/null || true
    print_tf_wait_failure_context
    return 1
}

wait_nav2_action_server() {
    local timeout_s="$1"

    local deadline=$((SECONDS + timeout_s))

    echo "[INFO] Waiting Nav2 action server /navigate_to_pose (${timeout_s}s)"

    while (( SECONDS < deadline )); do
        if ros2 action list 2>/dev/null | grep -qx "/navigate_to_pose"; then
            echo "[INFO] Nav2 action server ready: /navigate_to_pose"
            return 0
        fi

        sleep 0.5
    done

    echo "[ERRO] Timeout esperando action /navigate_to_pose"
    return 1
}

wait_compute_path_action_server() {
    local timeout_s="$1"

    local deadline=$((SECONDS + timeout_s))

    echo "[INFO] Waiting Nav2 action server /compute_path_to_pose (${timeout_s}s)"

    while (( SECONDS < deadline )); do
        if ros2 action list 2>/dev/null | grep -qx "/compute_path_to_pose"; then
            echo "[INFO] Nav2 action server ready: /compute_path_to_pose"
            return 0
        fi

        sleep 0.5
    done

    echo "[ERRO] Timeout esperando action /compute_path_to_pose"
    return 1
}

wait_mapper_active_origin() {
    local timeout_s="$1"
    local deadline=$((SECONDS + timeout_s))
    local status_output=""

    echo "[INFO] Waiting /mapper/status mapping_active=true and origin_initialized=true (${timeout_s}s)"

    while (( SECONDS < deadline )); do
        status_output="$(timeout 3 ros2 topic echo /mapper/status --once 2>/tmp/mapper_status_wait.log || true)"

        if echo "$status_output" | grep -Eq '"mapping_active"[[:space:]]*:[[:space:]]*true' &&
            echo "$status_output" | grep -Eq '"origin_initialized"[[:space:]]*:[[:space:]]*true'
        then
            echo "[INFO] ros2_mapper active with initialized tile origin"
            return 0
        fi

        if [[ -f "${MAPPER_LOG:-}" ]] &&
            grep -q "ros2_mapper mapping activated by auto_start=true" "$MAPPER_LOG" &&
            grep -q "Initialized tile origin from first odometry pose" "$MAPPER_LOG"
        then
            echo "[WARN] /mapper/status echo returned no parseable sample; using mapper log activation/origin confirmation"
            echo "[INFO] ros2_mapper active with initialized tile origin"
            return 0
        fi

        sleep 0.5
    done

    echo "[ERRO] Timeout esperando /mapper/status mapping_active=true origin_initialized=true"
    cat /tmp/mapper_status_wait.log 2>/dev/null || true
    if [[ -n "$status_output" ]]; then
        echo "$status_output"
    fi
    return 1
}

activate_mapper_runtime() {
    echo "[INFO] Activating ros2_mapper auto_start after real sensor/TF readiness"

    echo "========== MAPPER NODE DISCOVERY =========="
    ros2 node list 2>/tmp/mapper_node_list.log | grep mapper || true
    cat /tmp/mapper_node_list.log 2>/dev/null || true

    echo "========== MAPPER PARAMS BEFORE ACTIVATION =========="
    timeout 5 ros2 param list /ros2_mapper || true
    timeout 5 ros2 param get /ros2_mapper auto_start || true
    timeout 3 ros2 topic echo /mapper/status --once || true

    if ! wait_ros_service /ros2_mapper/set_parameters 20; then
        echo "[ERRO] /ros2_mapper/set_parameters não ficou disponível"
        cat "$MAPPER_LOG" || true
        return 1
    fi

    if ! timeout 10 ros2 param set /ros2_mapper auto_start true >/tmp/mapper_auto_start.log 2>&1; then
        echo "[ERRO] Falha ao ativar ros2_mapper auto_start"
        cat /tmp/mapper_auto_start.log || true
        echo "========== MAPPER PARAMS AFTER FAILED ACTIVATION =========="
        timeout 5 ros2 param get /ros2_mapper auto_start || true
        timeout 3 ros2 topic echo /mapper/status --once || true
        cat "$MAPPER_LOG" || true
        return 1
    fi

    echo "========== MAPPER PARAMS AFTER ACTIVATION =========="
    cat /tmp/mapper_auto_start.log || true
    timeout 5 ros2 param get /ros2_mapper auto_start || true
    timeout 3 ros2 topic echo /mapper/status --once || true

    wait_mapper_active_origin 30
}

activate_slam_toolbox_lifecycle() {
    echo "[INFO] Activating SLAM Toolbox lifecycle after mapper origin is initialized"

    if ! wait_ros_service /slam_toolbox/change_state 30; then
        echo "[ERRO] /slam_toolbox/change_state não ficou disponível"
        cat "$MAPPER_LOG" || true
        return 1
    fi

    local state=""
    state="$(ros2 lifecycle get /slam_toolbox 2>/dev/null || true)"
    echo "[INFO] slam_toolbox lifecycle before activation: ${state:-unknown}"

    if lifecycle_state_is "$state" active; then
        echo "[INFO] slam_toolbox already active"
        return 0
    fi

    if ! lifecycle_state_is "$state" inactive; then
        echo "[INFO] Configuring slam_toolbox"
        if ! timeout 60 ros2 lifecycle set /slam_toolbox configure >/tmp/slam_lifecycle_configure.log 2>&1; then
            echo "[ERRO] Failed to configure slam_toolbox"
            cat /tmp/slam_lifecycle_configure.log || true
            cat "$MAPPER_LOG" || true
            return 1
        fi
        cat /tmp/slam_lifecycle_configure.log || true
    fi

    echo "[INFO] Activating slam_toolbox"
    if ! timeout 60 ros2 lifecycle set /slam_toolbox activate >/tmp/slam_lifecycle_activate.log 2>&1; then
        echo "[ERRO] Failed to activate slam_toolbox"
        cat /tmp/slam_lifecycle_activate.log || true
        cat "$MAPPER_LOG" || true
        return 1
    fi
    cat /tmp/slam_lifecycle_activate.log || true

    if ! wait_lifecycle_active /slam_toolbox 30; then
        echo "[ERRO] slam_toolbox não ficou active"
        cat "$MAPPER_LOG" || true
        return 1
    fi

    echo "[INFO] SLAM Toolbox lifecycle active"
    return 0
}

activate_nav2_lifecycle_node() {
    local node="$1"
    local transition="$2"
    local timeout_s="${3:-45}"
    local state=""
    local state_name=""

    state="$(timeout 5 ros2 lifecycle get "$node" 2>/dev/null || true)"
    state_name="$(lifecycle_state_name "$state")"
    echo "[INFO] Nav2 lifecycle before ${transition}: ${node} state=${state:-unknown}"

    if [[ "$transition" == "configure" &&
          ( "$state_name" == "inactive" || "$state_name" == "active" ) ]]; then
        echo "[INFO] Nav2 lifecycle configure skipped for ${node}: already configured"
        return 0
    fi

    if [[ "$transition" == "activate" && "$state_name" == "active" ]]; then
        echo "[INFO] Nav2 lifecycle activate skipped for ${node}: already active"
        return 0
    fi

    if [[ "$transition" == "activate" && "$state_name" == "unconfigured" ]]; then
        if ! activate_nav2_lifecycle_node "$node" configure "$timeout_s"; then
            return 1
        fi
    fi

    echo "[INFO] Nav2 lifecycle: ${transition} ${node}"

    if ! timeout "$timeout_s" ros2 lifecycle set "$node" "$transition" >/tmp/nav2_lifecycle_node.log 2>&1; then
        echo "[ERRO] Falha ao executar lifecycle ${transition} em ${node}"
        cat /tmp/nav2_lifecycle_node.log || true
        cat "$NAV2_LOG" || true
        return 1
    fi

    cat /tmp/nav2_lifecycle_node.log || true
    state="$(timeout 5 ros2 lifecycle get "$node" 2>/dev/null || true)"
    state_name="$(lifecycle_state_name "$state")"
    echo "[INFO] Nav2 lifecycle after ${transition}: ${node} state=${state:-unknown}"

    if [[ "$transition" == "activate" && "$state_name" != "active" ]]; then
        echo "[ERRO] ${node} não entrou em active após activate (state=${state_name:-unknown})"
        return 1
    fi
    if [[ "$transition" == "configure" &&
          "$state_name" != "inactive" && "$state_name" != "active" ]]; then
        echo "[ERRO] ${node} não ficou configurado após configure (state=${state_name:-unknown})"
        return 1
    fi

    return 0
}

activate_nav2_lifecycle() {
    echo "[INFO] Activating Nav2 lifecycle through lifecycle_manager_navigation"

    local manager_output=""
    if wait_ros_service /lifecycle_manager_navigation/manage_nodes 15; then
        manager_output="$(
            timeout 120 ros2 service call \
                /lifecycle_manager_navigation/manage_nodes \
                nav2_msgs/srv/ManageLifecycleNodes \
                "{command: 0}" 2>&1 || true
        )"
        echo "$manager_output"

        if echo "$manager_output" | grep -Eqi 'success[=:][[:space:]]*(true|True)|success=True'; then
            if wait_lifecycle_active /controller_server 30 &&
               wait_lifecycle_active /planner_server 30 &&
               wait_lifecycle_active /bt_navigator 30; then
                echo "[INFO] Nav2 lifecycle active via lifecycle manager"
                return 0
            fi
        fi

        echo "[WARN] lifecycle manager startup não confirmou todos os nós ativos; usando fallback manual"
    else
        echo "[WARN] /lifecycle_manager_navigation/manage_nodes indisponível; usando fallback manual"
    fi

    local nodes=(
        /controller_server
        /planner_server
        /behavior_server
        /bt_navigator
        /waypoint_follower
    )

    local node=""

    for node in "${nodes[@]}"; do
        if ! activate_nav2_lifecycle_node "$node" configure 60; then
            return 1
        fi
    done

    for node in "${nodes[@]}"; do
        if ! activate_nav2_lifecycle_node "$node" activate 60; then
            return 1
        fi
    done

    if ! wait_lifecycle_active /controller_server 30; then
        echo "[ERRO] controller_server não ficou active"
        cat "$NAV2_LOG" || true
        return 1
    fi

    if ! wait_lifecycle_active /planner_server 30; then
        echo "[ERRO] planner_server não ficou active"
        cat "$NAV2_LOG" || true
        return 1
    fi

    if ! wait_lifecycle_active /bt_navigator 30; then
        echo "[ERRO] bt_navigator não ficou active"
        cat "$NAV2_LOG" || true
        return 1
    fi

    echo "[INFO] Nav2 lifecycle active via manual fallback"
    return 0
}

print_topics_snapshot() {
    {
        echo "========================================"
        echo "[DEBUG] $(date -Is)"
        echo "[DEBUG] ros2 topic list"
        ros2 topic list || true

        echo
        echo "[DEBUG] ros2 topic info /scan"
        ros2 topic info /scan || true

        echo
        echo "[DEBUG] ros2 topic info /imu/data"
        ros2 topic info /imu/data || true

        echo
        echo "[DEBUG] ros2 topic info /gps/odom"
        ros2 topic info /gps/odom || true

        echo
	        echo "[DEBUG] ros2 topic info /odometry/filtered"
	        ros2 topic info /odometry/filtered || true

	        echo
	        echo "[DEBUG] ros2 topic info /scan_for_slam"
	        ros2 topic info /scan_for_slam || true

	        echo
	        echo "[DEBUG] ros2 topic info /tf"
	        ros2 topic info /tf || true

	        echo
	        echo "[DEBUG] ros2 topic info /tf_static"
	        ros2 topic info /tf_static || true

	        echo
	        echo "[DEBUG] ros2 topic info /map"
	        ros2 topic info /map || true

	        echo
	        echo "[DEBUG] ros2_bridge status"
	        timeout 3 ros2 topic echo /ros2_bridge/status --once \
	            --qos-reliability reliable \
	            --qos-durability transient_local || true

	        echo
	        echo "[DEBUG] mapper status"
	        timeout 3 ros2 topic echo /mapper/status --once || true

	        echo
	        echo "[DEBUG] slam_toolbox lifecycle"
	        timeout 3 ros2 lifecycle get /slam_toolbox || true

	        echo "========================================"
        echo
    } >> "$DEBUG_LOG" 2>&1
}

print_nav2_snapshot() {
    {
        echo "========================================"
        echo "[NAV2 DEBUG] $(date -Is)"
        echo "[NAV2 DEBUG] topics relevantes"
        timeout 5 ros2 topic list 2>&1 | grep -E 'map|costmap|plan|cmd_vel|goal|navigate|scan|odom' || true

        echo
        echo "[NAV2 DEBUG] navigate actions"
        timeout 5 ros2 action list 2>&1 | grep -E 'navigate|compute_path' || true

        echo
        echo "[NAV2 DEBUG] lifecycle"
        timeout 5 ros2 lifecycle get /controller_server || true
        timeout 5 ros2 lifecycle get /planner_server || true
        timeout 5 ros2 lifecycle get /bt_navigator || true
        timeout 5 ros2 lifecycle get /global_costmap/global_costmap || true
        timeout 5 ros2 lifecycle get /local_costmap/local_costmap || true

        echo
        echo "[NAV2 DEBUG] topic info"
        timeout 5 ros2 topic info -v /map || true
        timeout 5 ros2 topic info -v /scan || true
        timeout 5 ros2 topic info -v /global_costmap/costmap || true
        timeout 5 ros2 topic info -v /local_costmap/costmap || true
        timeout 5 ros2 topic info -v /plan || true
        timeout 5 ros2 topic info -v /cmd_vel || true

        echo "========================================"
        echo
    } 2>&1 | tee -a "$DEBUG_LOG"
}

start_debug_loop() {
    if [[ "$DEBUG_TOPICS" != "1" ]]; then
        return
    fi

    echo "[INFO] DEBUG_TOPICS=1 -> habilitando introspecção periódica"

    (
        while true; do
            print_topics_snapshot
            sleep "$DEBUG_TOPICS_INTERVAL"
        done
    ) &
    DEBUG_PID=$!
}

start_nav2_tile_explorer() {
    local auto_start="$1"
    local phase="$2"
    local race_wait_for_bridge_ready=false

    if [[ "$RACE_MODE" == "1" ]]; then
        race_wait_for_bridge_ready=true
    fi

    echo "[INFO] Starting ros2_exploration ${phase} (auto_start=${auto_start})"

    RCUTILS_LOGGING_BUFFERED_STREAM=0 \
    RCUTILS_LOGGING_USE_STDOUT=1 \
    PYTHONUNBUFFERED=1 \
    stdbuf -oL -eL \
    ros2 launch ros2_exploration nav2_tile_explorer.launch.py \
        auto_start:="$auto_start" \
        race_wait_for_bridge_ready:="$race_wait_for_bridge_ready" \
        behavior_tree:=/workspace/controller/ros2_ws/install/share/ros2_navigation/behavior_trees/simple_compute_follow.xml \
        use_sim_time:="$RACE_USE_SIM_TIME_BOOL" \
        runtime_params_file:="$RACE_RUNTIME_PARAMS_FILE" \
        > "$EXPLORER_LOG" 2>&1 &

    EXPLORER_PID=$!

    sleep 2

    if ! kill -0 "$EXPLORER_PID" 2>/dev/null; then
        echo "[ERRO] nav2_tile_explorer morreu"
        cat "$EXPLORER_LOG"
        return 1
    fi

    echo "[INFO] nav2_tile_explorer started (${phase}, auto_start=${auto_start})."
    return 0
}

echo "[INFO] Starting ROS infrastructure before Webots controller"

start_continuous_explorer() {
    local auto_start="${1:-true}"
    local phase="${2:-runtime}"

    if [[ ! -f "$EXPLORATION_PARAMS_FILE" ]]; then
        echo "[ERRO] EXPLORATION_PARAMS_FILE não encontrado: $EXPLORATION_PARAMS_FILE"
        return 1
    fi

    echo "[INFO] Starting ros2_exploration continuous explorer ${phase} (autostart=${auto_start})"
    echo "[INFO] EXPLORATION_PARAMS_FILE=$EXPLORATION_PARAMS_FILE"

    RCUTILS_LOGGING_BUFFERED_STREAM=0 \
    RCUTILS_LOGGING_USE_STDOUT=1 \
    PYTHONUNBUFFERED=1 \
    stdbuf -oL -eL \
    ros2 launch ros2_exploration explorer.launch.py \
        params_file:="$EXPLORATION_PARAMS_FILE" \
        use_sim_time:="$RACE_USE_SIM_TIME_BOOL" \
        autostart:="$auto_start" \
        runtime_params_file:="$RACE_RUNTIME_PARAMS_FILE" \
        log_level:="$EXPLORER_LOG_LEVEL" \
        > "$EXPLORER_LOG" 2>&1 &

    EXPLORER_PID=$!

    sleep 2

    if ! kill -0 "$EXPLORER_PID" 2>/dev/null; then
        echo "[ERRO] ros2_explorer morreu"
        cat "$EXPLORER_LOG"
        return 1
    fi

    echo "[INFO] ros2_explorer started (${phase}, autostart=${auto_start})."
    return 0
}

# =========================================================
# START ROS2 BRIDGE
# =========================================================

if [[ "$START_BRIDGE" == "1" ]]; then
    echo "[INFO] START_BRIDGE=1 -> Starting ros2_bridge..."

    stdbuf -oL -eL \
    ros2 launch ros2_bridge bridge.launch.py debug_mode:="$ROS2_BRIDGE_DEBUG" \
        use_sim_time:="$RACE_USE_SIM_TIME_BOOL" \
        runtime_params_file:="$RACE_RUNTIME_PARAMS_FILE" \
        > "$BRIDGE_LOG" 2>&1 &

    BRIDGE_PID=$!

    echo "[INFO] Waiting ros2_bridge TCP port..."

    if ! wait_tcp_port 127.0.0.1 5000 20; then
        echo "[ERRO] ros2_bridge TCP port 5000 não abriu"

        echo "========== BRIDGE =========="
        cat "$BRIDGE_LOG"

        exit 1
    fi

    if ! kill -0 "$BRIDGE_PID" 2>/dev/null; then
        echo "[ERRO] ros2_bridge morreu"
        cat "$BRIDGE_LOG"
        exit 1
    fi

    echo "[INFO] ros2_bridge TCP port is ready."
else
    echo "[INFO] START_BRIDGE=0 -> ros2_bridge não será iniciado."
fi

# =========================================================
# START ROS2 VISION NODE
# =========================================================

if [[ "$START_VISION" == "1" ]]; then
    echo "[INFO] START_VISION=1 -> in-process VisionRuntime será habilitado pelo controller."
else
    echo "[INFO] START_VISION=0 -> in-process VisionRuntime desabilitado no controller."
fi

if [[ "$START_ROS2_VISION" == "1" ]]; then
    echo "[INFO] START_ROS2_VISION=1 -> Starting ros2_vision node..."

    stdbuf -oL -eL \
    ros2 launch ros2_vision vision.launch.py \
        use_sim_time:="$RACE_USE_SIM_TIME_BOOL" \
        runtime_params_file:="$RACE_RUNTIME_PARAMS_FILE" \
        > "$VISION_LOG" 2>&1 &

    VISION_PID=$!

    echo "[INFO] Waiting ros2_vision TCP ports..."

    if ! wait_tcp_port 127.0.0.1 "${VISION_FRAME_PORT:-5100}" 20; then
        echo "[WARN] ros2_vision frame TCP port ${VISION_FRAME_PORT:-5100} não abriu; controller seguirá sem visão"
        echo "========== VISION =========="
        tail -n 80 "$VISION_LOG" || true
    elif ! wait_tcp_port 127.0.0.1 "${VISION_RESULT_PORT:-5101}" 20; then
        echo "[WARN] ros2_vision result TCP port ${VISION_RESULT_PORT:-5101} não abriu; controller seguirá sem retorno de visão"
        echo "========== VISION =========="
        tail -n 80 "$VISION_LOG" || true
    elif ! kill -0 "$VISION_PID" 2>/dev/null; then
        echo "[WARN] ros2_vision morreu; controller seguirá sem visão"
        tail -n 80 "$VISION_LOG" || true
    else
        echo "[INFO] ros2_vision TCP ports are ready."
    fi
else
    echo "[INFO] START_ROS2_VISION=0 -> ros2_vision node não será iniciado."
fi

# =========================================================
# START RACE BOOTSTRAP
# =========================================================

if [[ "$START_BOOTSTRAP" == "1" ]]; then
    echo "[INFO] START_BOOTSTRAP=1 -> Starting ros2_bootstrap (RACE_BOOTSTRAP_YAW=$RACE_BOOTSTRAP_YAW)"

    RCUTILS_LOGGING_BUFFERED_STREAM=0 \
    RCUTILS_LOGGING_USE_STDOUT=1 \
    PYTHONUNBUFFERED=1 \
    stdbuf -oL -eL \
    ros2 launch ros2_bootstrap bootstrap.launch.py \
        bootstrap_yaw:="$RACE_BOOTSTRAP_YAW" \
        use_sim_time:="$RACE_USE_SIM_TIME_BOOL" \
        runtime_params_file:="$RACE_RUNTIME_PARAMS_FILE" \
        > "$BOOTSTRAP_LOG" 2>&1 &

    BOOTSTRAP_PID=$!

    sleep 2

    if ! kill -0 "$BOOTSTRAP_PID" 2>/dev/null; then
        echo "[ERRO] ros2_bootstrap morreu"
        cat "$BOOTSTRAP_LOG"
        exit 1
    fi

    echo "[INFO] ros2_bootstrap started."
    wait_ros_topic_optional /bootstrap/status 2 "bootstrap publicará status internamente"
    wait_ros_topic_optional /gps/odom 2 "bootstrap aquece sensores auxiliares antes do controller"
    wait_ros_topic_optional /imu/data 2 "bootstrap aquece sensores auxiliares antes do controller"
    wait_ros_topic_optional /scan 2 "bootstrap aquece Nav2 antes do controller"
    wait_ros_topic_optional /map 2 "bootstrap aquece static layer antes do controller"
else
    echo "[INFO] START_BOOTSTRAP=$START_BOOTSTRAP -> ros2_bootstrap desabilitado"
fi

# =========================================================
# START LOCALIZATION
# =========================================================

if [[ "$START_LOCALIZATION" == "1" ]]; then
    echo "[INFO] START_LOCALIZATION ignorado: localização agora roda dentro do controller e é publicada pela ros2_bridge"
    echo "[INFO] START_LOCALIZATION ignorado: localização agora roda dentro do controller e é publicada pela ros2_bridge" > "$LOCALIZATION_LOG"
else
    echo "[INFO] START_LOCALIZATION=0 -> localization ROS2 antigo desabilitado; localização final vem de LOC| na ros2_bridge"
    echo "[INFO] START_LOCALIZATION=0 -> localization ROS2 antigo desabilitado; localização final vem de LOC| na ros2_bridge" > "$LOCALIZATION_LOG"
fi

# =========================================================
# START MAPPER
# =========================================================

if [[ "$START_MAPPER" == "1" ]]; then
    if [[ "$MAPPER_MODE" == "slam_toolbox" ]]; then
        wait_ros_settle "before slam_toolbox" 5
    fi

    MAPPER_AUTO_START=false
    MAPPER_RACE_WAIT_FOR_BRIDGE=false
    if [[ "$RACE_MODE" == "1" ]]; then
        MAPPER_AUTO_START=true
        MAPPER_RACE_WAIT_FOR_BRIDGE=true
    fi

    echo "[INFO] Starting ros2_mapper early (mapper_mode=$MAPPER_MODE auto_start=$MAPPER_AUTO_START race_wait_for_bridge_ready=$MAPPER_RACE_WAIT_FOR_BRIDGE)"

    RCUTILS_LOGGING_BUFFERED_STREAM=0 \
    RCUTILS_LOGGING_USE_STDOUT=1 \
    PYTHONUNBUFFERED=1 \
    stdbuf -oL -eL \
    ros2 launch ros2_mapper mapper.launch.py \
        mapper_mode:="$MAPPER_MODE" \
        auto_start:="$MAPPER_AUTO_START" \
        race_wait_for_bridge_ready:="$MAPPER_RACE_WAIT_FOR_BRIDGE" \
        slam_autostart:=false \
        use_sim_time:="$RACE_USE_SIM_TIME_BOOL" \
        runtime_params_file:="$RACE_RUNTIME_PARAMS_FILE" \
        > "$MAPPER_LOG" 2>&1 &

    MAPPER_PID=$!

    sleep 2

    if ! kill -0 "$MAPPER_PID" 2>/dev/null; then
        echo "[ERRO] ros2_mapper morreu"
        cat "$MAPPER_LOG"
        exit 1
    fi

    echo "[INFO] ros2_mapper started."
    wait_ros_topic_optional /odometry/filtered 2 "ros2_mapper aguardará odometria internamente"
    wait_ros_topic_optional /scan 2 "ros2_mapper aguardará scan internamente"
    wait_ros_topic_optional /mapper/status 2 "ros2_mapper publicará status quando estiver rodando"
else
    echo "[INFO] START_MAPPER=0 -> mapper desabilitado"
fi

# =========================================================
# MAP DATASET BUILDER
# =========================================================
# O mapsdataset atual e offline/completo: ele e construido no cleanup()
# a partir de controller/logs, sem guardar nome de mundo.
if [[ "$START_MAP_DATASET" == "1" ]]; then
    echo "[INFO] mapsdataset builder enabled; will run create.py on shutdown"
    echo "[INFO] mapsdataset params: no_copy=$MAP_DATASET_NO_COPY latest=$MAP_DATASET_LATEST include_latest=$MAP_DATASET_INCLUDE_LATEST day='${MAP_DATASET_DAY}' run='${MAP_DATASET_RUN}' world='${MAP_DATASET_WORLD}' run_world_map='${MAP_DATASET_RUN_WORLD_MAP}' limit='${MAP_DATASET_LIMIT}'"
else
    echo "[INFO] START_MAP_DATASET=0 -> mapsdataset builder desabilitado"
fi

# =========================================================
# START NAV2
# =========================================================

if [[ "$START_NAV2" == "1" ]]; then
    wait_ros_settle "before Nav2" 3

    # Nav2 must be preloaded/active before the Webots controller starts.
    # The legacy controller only queries Nav2 reachability; it does not let Nav2
    # drive /cmd_vel. Therefore legacy can safely autostart Nav2 here, matching
    # the old behavior, while the rest of the stack keeps its own timing.
    NAV2_AUTOSTART=false
    NAV2_USE_SIM_TIME_BOOL="$RACE_USE_SIM_TIME_BOOL"
    NAV2_RUNTIME_PARAMS_FILE="$RACE_RUNTIME_PARAMS_FILE"
    if [[ "$RACE_MODE" == "1" ]]; then
        NAV2_AUTOSTART=true
    fi

    # Local Nav2-only override: in legacy race preload, Nav2 must not wait for
    # a /clock that only exists after the Webots controller connects. This writes
    # a Nav2-specific runtime YAML; mapper/bridge/controller/RViz still receive
    # the original RACE_RUNTIME_PARAMS_FILE unchanged.
    if [[ "$RACE_MODE" == "1" && "$EXPLORER_BACKEND" == "legacy" ]]; then
        NAV2_USE_SIM_TIME_BOOL=false
        NAV2_RUNTIME_PARAMS_FILE="$LOG_DIR/nav2_runtime_timing.yaml"
        (
            RACE_USE_SIM_TIME_BOOL=false
            race_timing_write_yaml "$NAV2_RUNTIME_PARAMS_FILE"
        )
        rm -f "$RUN_LOG_DIR/$(basename "$NAV2_RUNTIME_PARAMS_FILE")"
        ln "$NAV2_RUNTIME_PARAMS_FILE" "$RUN_LOG_DIR/$(basename "$NAV2_RUNTIME_PARAMS_FILE")" 2>/dev/null ||
            cp -f "$NAV2_RUNTIME_PARAMS_FILE" "$RUN_LOG_DIR/$(basename "$NAV2_RUNTIME_PARAMS_FILE")"
    fi

    echo "[INFO] Starting ros2_navigation with autostart=$NAV2_AUTOSTART use_sim_time=$NAV2_USE_SIM_TIME_BOOL runtime_params=$NAV2_RUNTIME_PARAMS_FILE (nav_mode=$NAV2_MODE deprecated/ignored)..."

    RCUTILS_LOGGING_BUFFERED_STREAM=0 \
    RCUTILS_LOGGING_USE_STDOUT=1 \
    PYTHONUNBUFFERED=1 \
    stdbuf -oL -eL \
    ros2 launch ros2_navigation nav2_bringup.launch.py \
        nav_mode:="$NAV2_MODE" \
        autostart:="$NAV2_AUTOSTART" \
        use_sim_time:="$NAV2_USE_SIM_TIME_BOOL" \
        runtime_params_file:="$NAV2_RUNTIME_PARAMS_FILE" \
        > "$NAV2_LOG" 2>&1 &

    NAV2_PID=$!

    sleep 4

    if ! kill -0 "$NAV2_PID" 2>/dev/null; then
        echo "[ERRO] Nav2 morreu"
        cat "$NAV2_LOG"
        exit 1
    fi

    echo "[INFO] Nav2 started."
    wait_ros_topic_optional /odometry/filtered 2 "Nav2 aguardará odometria conforme seus nós internos"
    wait_ros_topic_optional /scan 2 "Nav2 aguardará scan conforme seus nós internos"
    wait_ros_topic_optional /map 2 "SLAM/Nav2 publicarão ou consumirão /map quando disponível"
else
    echo "[INFO] START_NAV2=0 -> Nav2 desabilitado"
fi

# =========================================================
# START EXPLORER BEFORE CONTROLLER
# =========================================================

if [[ "$START_EXPLORER" == "1" ]]; then
    if [[ "$START_NAV2" != "1" ]]; then
        echo "[ERRO] START_EXPLORER=1 exige START_NAV2=1"
        exit 1
    fi

    if [[ "$EXPLORER_BACKEND" == "tile" ]]; then
        EXPLORER_START_AUTO=false
        if [[ "$RACE_MODE" == "1" ]]; then
            EXPLORER_START_AUTO="$EXPLORER_AUTO_START"
        fi

        if ! start_nav2_tile_explorer "$EXPLORER_START_AUTO" "before Webots controller"; then
            exit 1
        fi

        wait_ros_topic_optional /mapper/status 2 "nav2_tile_explorer aguardará mapper readiness internamente"
        wait_ros_topic_optional /mapper/tile_semantic_map 2 "nav2_tile_explorer aguardará semantic map internamente"
    else
        echo "[INFO] EXPLORER_BACKEND=continuous -> continuous_explorer será iniciado após runtime topics"
    fi
else
    if [[ "$EXPLORER_BACKEND" == "legacy" ]]; then
        echo "[INFO] START_EXPLORER=0 -> ROS exploration disabled; Webots legacy explorer active"
        if [[ "$START_EXPLORER_GRAPH_VIZ" == "1" && "$START_NAV2" == "1" ]]; then
            echo "[INFO] Starting passive ros2_explorer for RViz tile graph only"
            if ! start_continuous_explorer false "legacy graph visualization"; then
                exit 1
            fi
        elif [[ "$START_EXPLORER_GRAPH_VIZ" == "1" ]]; then
            echo "[WARN] START_EXPLORER_GRAPH_VIZ=1 ignorado porque START_NAV2=0 não publica global costmap"
        fi
    else
        echo "[INFO] START_EXPLORER=0 -> exploration desabilitada"
    fi
fi

# =========================================================
# DEBUG LOOP
# =========================================================

start_debug_loop

# =========================================================
# RVIZ
# =========================================================

if [[ "$START_RVIZ" == "1" ]]; then
    if [[ -z "${RVIZ_CONFIG:-}" ]]; then
        RVIZ_CONFIG=/workspace/controller/ros2_ws/src/ros2_bridge/config/rviz.rviz
    fi

    RVIZ_ARGS=""
    [[ -f "$RVIZ_CONFIG" ]] && RVIZ_ARGS="-d $RVIZ_CONFIG"

    echo "[INFO] Starting RViz2..."
    echo "[INFO] RVIZ_CONFIG=$RVIZ_CONFIG"
    echo "[INFO] DISPLAY=${DISPLAY:-}"
    echo "[INFO] XAUTHORITY=${XAUTHORITY:-}"

    export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/tmp/runtime-root}"
    mkdir -p "$XDG_RUNTIME_DIR"
    chmod 700 "$XDG_RUNTIME_DIR" || true

    if [[ "$RVIZ_SOFTWARE_RENDERING" == "1" ]]; then
        export LIBGL_ALWAYS_SOFTWARE=1
        export MESA_GL_VERSION_OVERRIDE=3.3
        export QT_OPENGL=software
        export OGRE_RTT_MODE=Copy
        echo "[INFO] RViz software rendering enabled"
    else
        unset LIBGL_ALWAYS_SOFTWARE
        unset MESA_GL_VERSION_OVERRIDE
        unset QT_OPENGL
        unset OGRE_RTT_MODE
        echo "[INFO] RViz hardware rendering preferred (RVIZ_SOFTWARE_RENDERING=0)"
    fi

    RCUTILS_LOGGING_BUFFERED_STREAM=0 \
    RCUTILS_LOGGING_USE_STDOUT=1 \
	    PYTHONUNBUFFERED=1 \
	    stdbuf -oL -eL \
	    rviz2 $RVIZ_ARGS \
	        --ros-args --disable-external-lib-logs --disable-rosout-logs --log-level warn -p use_sim_time:="$RACE_USE_SIM_TIME_BOOL" \
	        > "$RVIZ_LOG" 2>&1 &

    RVIZ_PID=$!

    sleep 3

    if ! kill -0 "$RVIZ_PID" 2>/dev/null; then
        echo "[WARN] RViz falhou"
        cat "$RVIZ_LOG"
        RVIZ_PID=""
    fi
else
    echo "[INFO] START_RVIZ=0 -> RViz desabilitado"
fi

# =========================================================
# START WEBOTS CONTROLLER
# =========================================================

if [[ "$START_CONTROLLER" == "1" ]]; then
    echo "[INFO] Starting Webots controller as final main process"

    stdbuf -oL -eL \
    webots-controller \
        --protocol=tcp \
        --ip-address="${EREBUS_SERVER:?EREBUS_SERVER não definido}" \
        --port=1234 \
        --robot-name=Erebus_Bot \
        /workspace/controller/main \
        > "$CONTROLLER_LOG" 2>&1 &

    CONTROLLER_PID=$!
else
    echo "[INFO] START_CONTROLLER=0 -> Webots controller não será iniciado."
fi

# =========================================================
# WAIT BRIDGE CONNECTION
# =========================================================

if [[ "$START_BRIDGE" == "1" && "$START_CONTROLLER" == "1" ]]; then
    echo "[INFO] Waiting bridge connection after final controller start..."

    deadline=$((SECONDS + 40))

    while (( SECONDS < deadline )); do
        if ! kill -0 "$CONTROLLER_PID" 2>/dev/null; then
            echo "[ERRO] Controller morreu:"
            cat "$CONTROLLER_LOG"
            exit 1
        fi

        if ! kill -0 "$BRIDGE_PID" 2>/dev/null; then
            echo "[ERRO] ros2_bridge morreu:"
            cat "$BRIDGE_LOG"
            exit 1
        fi

        if grep -q "Conectado na bridge" "$CONTROLLER_LOG"; then
            echo "[INFO] Controller conectado ao Webots e ao bridge."
            break
        fi

        sleep 0.2
    done

    if (( SECONDS >= deadline )); then
        echo "[ERRO] Timeout bridge"

        echo "========== BRIDGE =========="
        cat "$BRIDGE_LOG"

        echo "========== CONTROLLER =========="
        cat "$CONTROLLER_LOG"

        exit 1
    fi
else
    echo "[INFO] Bridge connection wait pulado (START_BRIDGE=$START_BRIDGE, START_CONTROLLER=$START_CONTROLLER)."
fi

# =========================================================
# START EXPLORER AFTER RUNTIME READY
# =========================================================

if [[ "$RACE_MODE" == "1" &&
      "$START_EXPLORER" == "1" &&
      "$EXPLORER_BACKEND" == "continuous" ]]; then

    echo "[INFO] EXPLORER_BACKEND=continuous -> waiting runtime topics before starting continuous_explorer"

    if ! wait_nav2_action_server 45; then
        cat "$NAV2_LOG" || true
        print_nav2_snapshot || true
        exit 1
    fi

    if ! wait_ros_topic_required /map 45 "continuous_explorer precisa de /map"; then
        cat "$MAPPER_LOG" || true
        exit 1
    fi

    if ! wait_ros_topic_required /global_costmap/costmap 45 "continuous_explorer precisa do global costmap"; then
        cat "$NAV2_LOG" || true
        print_nav2_snapshot || true
        exit 1
    fi

    if ! wait_ros_topic_required /local_costmap/costmap 45 "continuous_explorer precisa do local costmap"; then
        cat "$NAV2_LOG" || true
        print_nav2_snapshot || true
        exit 1
    fi

    if ! wait_tf_transform map base_link 45; then
        print_nav2_snapshot || true
        exit 1
    fi

    if ! start_continuous_explorer "$EXPLORER_AUTO_START" "after runtime ready"; then
        exit 1
    fi
fi

# =========================================================
# POST-CONTROLLER READINESS AND ACTIVATION
# =========================================================

if [[ "$RACE_MODE" == "1" && "$EXPLORER_BACKEND" != "legacy" ]]; then
    echo "[INFO] RACE_MODE=1 -> post-controller CLI orchestration skipped; bridge/bootstrap/mapper/explorer release by topic events"
elif [[ "$START_CONTROLLER" == "1" && ( "$START_MAPPER" == "1" || "$START_NAV2" == "1" ) ]]; then
	    echo "[INFO] Controller connected; waiting bridge sensor/localization readiness and localization TF"

    if ! wait_bridge_sensor_status_required 30; then
        exit 1
    fi

    if ! wait_tf_transform odom base_link 30; then
        exit 1
    fi
elif [[ "$START_CONTROLLER" == "1" ]]; then
    echo "[INFO] START_MAPPER=0 START_NAV2=0 -> post-controller sensor/TF readiness skipped."
else
    echo "[WARN] START_CONTROLLER=0 -> post-controller readiness and automatic activation skipped."
fi

if [[ "$RACE_MODE" != "1" && "$START_CONTROLLER" == "1" && "$START_MAPPER" == "1" ]]; then
    if ! activate_mapper_runtime; then
        exit 1
    fi

    if [[ "$MAPPER_MODE" == "slam_toolbox" ]]; then
        if ! activate_slam_toolbox_lifecycle; then
            exit 1
        fi

        wait_ros_topic_optional /map 5 "SLAM Toolbox deve publicar /map após ativação"
    fi
fi

if [[ "$START_CONTROLLER" == "1" && "$START_NAV2" == "1" &&
      ( "$RACE_MODE" != "1" || "$EXPLORER_BACKEND" == "legacy" ) ]]; then
    if [[ "$EXPLORER_BACKEND" == "legacy" ]]; then
        nav2_reachability_ready=1

        # In legacy race mode Nav2 is intentionally autostarted before Webots.
        # Do not repeat the old delayed lifecycle activation after the robot has
        # already connected; just verify the infrastructure and fall back safely
        # if it is not ready yet.
        if [[ "${NAV2_AUTOSTART:-false}" == "true" ]]; then
            echo "[INFO] Legacy Nav2 preload enabled; skipping delayed post-controller lifecycle activation"
        else
            if ! wait_nav2_activation_inputs 45; then
                nav2_reachability_ready=0
                echo "[WARN] Nav2 reachability sem inputs de ativação; mantendo controller em modo LIDAR-only"
            fi

            if [[ "$nav2_reachability_ready" == "1" ]] && ! activate_nav2_lifecycle; then
                nav2_reachability_ready=0
                echo "[WARN] Nav2 não ativou; mantendo controller em modo LIDAR-only"
            fi
        fi

        if [[ "$nav2_reachability_ready" == "1" ]] &&
           ! verify_nav2_reachability_runtime 30; then
            nav2_reachability_ready=0
            echo "[WARN] Infraestrutura de reachability incompleta; mantendo controller em modo LIDAR-only"
        fi

        if [[ "$nav2_reachability_ready" == "1" ]]; then
            # The local costmap is not consumed by reachability, but seeing a real
            # message confirms that controller_server was also activated correctly.
            wait_ros_message_required /local_costmap/costmap 15 \
                "controller_server local costmap diagnostic" || true
            echo "[INFO] Legacy controller seguirá com LIDAR + Nav2 second check"
        else
            # Do not exit here. exit 1 triggers cleanup(), kills the Webots
            # controller, and an external supervisor may restart the whole stack
            # forever. The reachability checker already fails closed and the
            # legacy planner can continue safely with LIDAR only.
            cat "$NAV2_LOG" || true
            print_nav2_snapshot || true
            echo "[WARN] Controller preservado; Nav2 second check tentará novamente após o cooldown interno"
        fi
    else
        if ! activate_nav2_lifecycle; then
            exit 1
        fi

        if ! wait_nav2_action_server 30; then
            cat "$NAV2_LOG" || true
            print_nav2_snapshot || true
            exit 1
        fi

        if ! wait_compute_path_action_server 30; then
            cat "$NAV2_LOG" || true
            print_nav2_snapshot || true
            exit 1
        fi

        wait_ros_topic_optional /map 2 "não é gate fatal neste slice"

        if ! wait_tf_transform map base_link 30; then
            print_nav2_snapshot || true
            exit 1
        fi

        print_nav2_snapshot
    fi
fi

if [[ "$RACE_MODE" != "1" && "$START_CONTROLLER" == "1" && "$START_EXPLORER" == "1" ]]; then
    echo "[INFO] Activating exploration after Nav2 active"

    if [[ -n "${EXPLORER_PID:-}" ]] && kill -0 "$EXPLORER_PID" 2>/dev/null; then
        echo "[INFO] Relaunching nav2_tile_explorer because auto_start is not runtime-dynamic"
        kill "$EXPLORER_PID" 2>/dev/null || true
        wait "$EXPLORER_PID" 2>/dev/null || true
        EXPLORER_PID=""
    fi

    if [[ "$EXPLORER_BACKEND" == "tile" ]]; then
        if ! start_nav2_tile_explorer "$EXPLORER_AUTO_START" "after Nav2 active"; then
            exit 1
        fi
    else
        if ! start_continuous_explorer "$EXPLORER_AUTO_START" "after Nav2 active"; then
            exit 1
        fi
    fi
fi

# =========================================================
# STATUS
# =========================================================

if [[ "$RACE_MODE" != "1" ]]; then
    echo "[INFO] Topics disponíveis"
    ros2 topic list || true
else
    echo "[INFO] RACE_MODE=1 -> ros2 topic list final pulado"
fi

if [[ "$RACE_MODE" != "1" && -n "${NAV2_PID:-}" ]]; then
    print_nav2_snapshot
fi

echo "[INFO] Logs:"
echo "  BRIDGE_LOG=$BRIDGE_LOG"
echo "  VISION_LOG=$VISION_LOG"
echo "  BOOTSTRAP_LOG=$BOOTSTRAP_LOG"
echo "  CONTROLLER_LOG=$CONTROLLER_LOG"
echo "  LOCALIZATION_LOG=$LOCALIZATION_LOG"
echo "  MAPPER_LOG=$MAPPER_LOG"
echo "  NAV2_LOG=$NAV2_LOG"
echo "  EXPLORER_LOG=$EXPLORER_LOG"
echo "  RVIZ_LOG=$RVIZ_LOG"
echo "  DEBUG_LOG=$DEBUG_LOG"

if [[ "$PRINT_LOG_TERMINALS" == "1" ]]; then
    if [[ -n "${BRIDGE_PID:-}" ]]; then
        echo "========== BRIDGE =========="
        tail -n +1 -F "$BRIDGE_LOG" &
        TAIL_BRIDGE_PID=$!
    fi

    if [[ -n "${VISION_PID:-}" ]]; then
        echo "========== VISION =========="
        tail -n +1 -F "$VISION_LOG" &
        TAIL_VISION_PID=$!
    fi

    if [[ -n "${BOOTSTRAP_PID:-}" ]]; then
        echo "========== BOOTSTRAP =========="
        tail -n +1 -F "$BOOTSTRAP_LOG" &
        TAIL_BOOTSTRAP_PID=$!
    fi

    if [[ -n "${CONTROLLER_PID:-}" ]]; then
        echo "========== CONTROLLER =========="
        tail -n +1 -F "$CONTROLLER_LOG" &
        TAIL_CONTROLLER_PID=$!
    fi

    if [[ -n "${LOCALIZATION_PID:-}" ]]; then
        echo "========== LOCALIZATION =========="
        tail -n +1 -F "$LOCALIZATION_LOG" &
        TAIL_LOCALIZATION_PID=$!
    fi

    if [[ -n "${MAPPER_PID:-}" ]]; then
        echo "========== MAPPER =========="
        tail -n +1 -F "$MAPPER_LOG" &
        TAIL_MAPPER_PID=$!
    fi

    if [[ -n "${NAV2_PID:-}" ]]; then
        echo "========== NAV2 =========="
        tail -n +1 -F "$NAV2_LOG" &
        TAIL_NAV2_PID=$!
    fi

    if [[ -n "${RVIZ_PID:-}" ]]; then
        echo "========== RVIZ =========="
        tail -n +1 -F "$RVIZ_LOG" &
        TAIL_RVIZ_PID=$!
    fi

    if [[ -n "${EXPLORER_PID:-}" ]]; then
        echo "========== EXPLORER =========="
        tail -n +1 -F "$EXPLORER_LOG" &
        TAIL_EXPLORER_PID=$!
    fi

    if [[ "$DEBUG_TOPICS" == "1" ]]; then
        echo "========== DEBUG TOPICS =========="
        tail -n +1 -F "$DEBUG_LOG" &
        TAIL_DEBUG_PID=$!
    fi
fi

if [[ "$PRINT_CONTROLLER_EVENTS" == "1" && -n "${CONTROLLER_PID:-}" ]]; then
    print_operator_console &
    OPERATOR_CONSOLE_PID=$!
fi

echo "[INFO] Sistema rodando"

if [[ -n "${CONTROLLER_PID:-}" ]]; then
    set +e
    wait "$CONTROLLER_PID"
    CONTROLLER_RC=$?
    set -e

    if [[ "$CONTROLLER_RC" == "130" || "$CONTROLLER_RC" == "143" ]]; then
        echo "[INFO] Encerramento solicitado pelo usuário/container."
        exit 0
    fi

    if [[ "$CONTROLLER_RC" == "0" ]]; then
        echo "[INFO] Controller finalizou normalmente."
    else
        echo "[ERRO] Controller finalizou com código $CONTROLLER_RC"
        echo "========== CONTROLLER LOG TAIL =========="
        tail -n 160 "$CONTROLLER_LOG" || true
        echo "========== BRIDGE LOG TAIL =========="
        tail -n 120 "$BRIDGE_LOG" || true
        echo "========== LOCALIZATION LOG TAIL =========="
        tail -n 120 "$LOCALIZATION_LOG" || true
    fi

    exit "$CONTROLLER_RC"
fi

wait
