// File:          Diagonal
// Date:          12/07/2025
// Description:   ...
// Author:        Águabots
// Modifications: Many

#include <webots/Robot.hpp>
#include <webots/Motor.hpp>
#include <webots/PositionSensor.hpp>
#include <webots/DistanceSensor.hpp>
#include <webots/Camera.hpp>
#include <webots/GPS.hpp>
#include <webots/Lidar.hpp>
#include <webots/InertialUnit.hpp>
#include <webots/Emitter.hpp>
#include <webots/Receiver.hpp>

#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
#include <queue>
#include <vector>
#include <array>
#include <bitset>
#include <cstdint>
#include <memory>
#include <cstdlib>
#include <sstream>

#include <onnxruntime_cxx_api.h>
#include <opencv2/opencv.hpp>

#include <include/vision/LarcVision.hpp>
#include <include/utils/PID.hpp>

using namespace std;
using namespace webots;

#define HOLE_TARGET 29
#define HOLE_TARGET2 40
#define PISO_NORMAL 227
#define RGB_TOLERANCE 5
#define node tuple<double, int, int> // (custo, x, y)

typedef pair<int, int> pii;
typedef pair<double, double> pdd;

Robot *robot = new Robot();

int timeStep = (int)robot->getBasicTimeStep();
double dt = timeStep / 1000.0;            // Transformando de ms para segundos
const double pi = 3.14159265358979323846; // Valor de pi
const double max_speed = 6.27;               // Velocidade máxima do robô
double dist_voltar = 0;
const double raioRoda = 0.02;
const string obj_path = "models/model_obj.onnx";
const string type_path = "models/model_type.onnx";
const string bbox_path = "models/model_bbox.onnx";
const string cls_path = "models/modelo_cls.onnx";

// Inicializando os atuadores e sensores do robô

Motor *wheel_left = robot->getMotor("wheel1 motor"); // Inicialização dos atuadores
Motor *wheel_right = robot->getMotor("wheel2 motor");

PositionSensor *leftEncoders = wheel_left->getPositionSensor();
PositionSensor *rightEncoders = wheel_right->getPositionSensor();

Camera *colorSensor = robot->getCamera("colour_sensor");
Camera *came = robot->getCamera("camera1");
Camera *camd = robot->getCamera("camera2");


double fov = came->getFov();
int cam_width = came->getWidth();
int cam_height = came->getHeight();
const double L = 0.3;

GPS *gps = robot->getGPS("gps");

Lidar *lidar = robot->getLidar("lidar");
DistanceSensor *dsensor = robot->getDistanceSensor("distance sensor1");

InertialUnit *Iunit = robot->getInertialUnit("inertial_unit");

Emitter *emitter = robot->getEmitter("emitter");
Receiver *receiver = robot->getReceiver("receiver");

const double INF = 1e8;

bool returning = 0;
const int sizeMaze = 180;
int SalvaSala = 1, Aux = 0;
pii SalvaExtremos[2];
pii SalvaAsteriscos[2];
string Mapeamento[600][600];
int MapDfs[600][600];
int wallgrid[sizeMaze][sizeMaze]; // Matriz para armazenar as paredes do labirinto
int maze[sizeMaze][sizeMaze];
int swampmaze[sizeMaze][sizeMaze];
bool visited[sizeMaze][sizeMaze];          // Matriz para armazenar se o ladrilho foi visitado
pair<int, int> parent[sizeMaze][sizeMaze]; // Matriz para armazenar o último ladrilho visitado
bool foundvictim[sizeMaze][sizeMaze] = {0}; // Matriz para armazenar se a vítima foi encontrada
const int pc = lidar->getHorizontalResolution();
int idcompass = 0;
int dx[8] = {-1, 0, 1, 0, -1, 1, 1, -1}; // Direções: Norte, Leste, Sul, Oeste, Nordeste, Sudeste, Sudoeste, Noroeste
int dy[8] = {0, 1, 0, -1, 1, 1, -1, -1}; // Direções: Norte, Leste, Sul, Oeste, Nordeste, Sudeste, Sudoeste, Noroeste
int north = 2 * pc;
int east = (2 * pc) + (pc / 4);
int south = (2 * pc) + (pc / 2);
int west = (2 * pc) + (3 * pc / 4);
bool MudeiDeSala = false;
bool IgnoraOsTermos=false;
bool Com = true;

pii CordCor = {-1, -1};
int CSala=10;
vector<pii>Area4;
struct Cid{
   int x, y, id;
};
vector<Cid>EntradasA4;

bool naoda = 0;
bool finished = 0;

// Ponto inicial fixo
const int startX = sizeMaze / 2;
const int startY = sizeMaze / 2;

// Posição corrente do robô (inicializada ao ponto central)
int posx = startX;
int posy = startY;

// Posição do próximo ladrilho a ser visitado
int newx = startX; // Coordenadas do próximo ladrilho a ser visitado
int newy = startY; // Coordenadas do próximo ladrilho a ser visitado

// Ladrilho inicial é o primeiro checkpoint
int checkpointX = startX;
int checkpointY = startY;

// Coordenadas do último ladrilho visitado
int lastX = startX;
int lastY = startY;

double gpsX0 = 0.0, gpsY0 = 0.0; // Coordenadas GPS do ponto inicial (tile startX, startY)

int blocked[sizeMaze][sizeMaze]; // Matriz para armazenar buracos encontrados

const int width = 1;
const int height = 2;

double errori = 0;
double errorj = 0;


pii gpsToTile(double gpsX, double gpsY,
               double tileSize = 0.12)
{
    double dx = gpsX - gpsX0;
    double dy = gpsY - gpsY0;

    int tileX = startX + round(dx / tileSize);
    int tileY = startY + round(dy / tileSize);
    
    //cout << "TILE: " << tileX << " " << tileY << endl;

    return {tileX, tileY};
}

cv::Mat cameraToMat(Camera *cam) {
    const unsigned char *image = cam->getImage();

    cv::Mat imgBGRA(cam->getHeight(), cam->getWidth(), CV_8UC4, (void*)image);
    cv::Mat imgBGR;
    cv::cvtColor(imgBGRA, imgBGR, cv::COLOR_BGRA2BGR);

    return imgBGR;
}

// Inicializa o PID
PID pid_giro(92.9, 0.0, 0.0);
PID pid_velocidade(5.0, 0.0, 0.0);

unique_ptr<LarcVision> pDetector;

void delay(int milliseconds)
{
   double endTime = robot->getTime() + milliseconds / 1000.0;
   while (robot->getTime() < endTime)
   {
      robot->step(timeStep);
   }
}

// Envia uma string pelo emitter
void enviarVictima(char victima)
{
   wheel_left->setVelocity(0);
   wheel_right->setVelocity(0);
   delay(500);
   delay(1000);
   cout << "ENVIANDO" << endl;
   char mensagem[9]; // sizeof((int)posx + (int)posy + (char)victimaClass) = 9
   const double *position = gps->getValues(); 
   int x = (int) (position[0] * 100);
   int y = (int) (position[2] * 100);
   cout << "Vitima em: " << "X: " << x << " Y: " << y << endl;
   int victim_pos[2] = {x, y};
   memcpy(mensagem, victim_pos, sizeof(victim_pos));
   mensagem[8] = victima;
   emitter->send(mensagem, sizeof(mensagem));
   robot->step(timeStep);
}

int checkwall();

void detectar_e_imprimir()
{
   pii TILEgps = gpsToTile(gps->getValues()[0], gps->getValues()[2]);
   
   //cout << "[detectar_e_imprimir] Funcao chamada." << endl;
   if(foundvictim[TILEgps.first][TILEgps.second] == 1){
      //cout << "[detectar_e_imprimir] Ja vi essa vitima, ignorando." << endl;
      return;
   }
   //cout << "[detectar_e_imprimir] Imagens obtidas. Chamando Detector.detectar() para camera esquerda." << endl;
   cv::Mat img_e = cameraToMat(came);
   DetectionResult resultadoe = pDetector->detectar(img_e);
   //cout << resultadoe.class_name << endl;
   //cout << "[detectar_e_imprimir] Deteccao esquerda finalizada. Chamando para direita." << endl;
   cv::Mat img_d = cameraToMat(camd);
   DetectionResult resultadod = pDetector->detectar(img_d);
   //cout << resultadod.class_name << endl;

   // vamos marcar vitima apenas se uma das cameras detectar e houver parede para aquele lado
   // tambem ignorados as posicoes impares
   // if (posx % 2 != 0 or posy % 2 != 0)
   // {
   //    cout << "[detectar_e_imprimir] Posicao impar, ignorando vitimas." << endl;
   //    return;
   // }
   //cout << "Bounding Box Direita:" << " width=" << resultadod.bounding_box.width << ", height=" << resultadod.bounding_box.height << endl;
   //cout << "Bounding Box Esquerda:" << " width=" << resultadoe.bounding_box.width << ", height=" << resultadoe.bounding_box.height << endl;

   

   if (resultadoe.class_name != "none" || resultadod.class_name != "none")
   {

      if (resultadoe.class_name != "none" and foundvictim[TILEgps.first][TILEgps.second] == 0 and lidar->getRangeImage()[east] < 0.06)
      {
         //imprimindo a boundingbox
         cout << "[detectar_e_imprimir] Enviando vitima esquerda." << endl;
         foundvictim[TILEgps.first][TILEgps.second] = 1;
         enviarVictima(resultadoe.class_name[0]);
         
      }
      else if (resultadod.class_name != "none" and foundvictim[TILEgps.first][TILEgps.second] == 0 and lidar->getRangeImage()[west] < 0.06)
      {
         
         cout << "[detectar_e_imprimir] Enviando vitima direita." << endl;
         foundvictim[TILEgps.first][TILEgps.second] = 1;
         enviarVictima(resultadod.class_name[0]);
      }
      else
      {
         //cout << "[detectar_e_imprimir] Vitima detectada, mas sem parede naquele lado, ou ja vi aquela vitima. Ignorando." << endl;
      }
   }
   else
   {
      //cout << "[detectar_e_imprimir] Nenhuma vitima detectada." << endl;
   }

   //cout << "[detectar_e_imprimir] Funcao finalizada." << endl;
}

int tempo(){
   char message[1] = { 'G' }; // message = 'G' for game information
   emitter->send(message, sizeof(message)); // Send out the message array. Note that the 2nd parameter must be the size of the message
   int valor;
   if(receiver->getQueueLength() > 0) { // If receiver queue is not empty
      char *receivedData = (char *)receiver->getData(); // Grab data as a string
      float score = 0.0;
      int time = 0;
      if (receivedData[0] == 'G') {
         memcpy(&score, receivedData + 4, 4); // Score stored in bytes 4 to 7
         memcpy(&time, receivedData + 8, 4);  // Remaining time stored in bytes 8 to 11
         cout << "Game Score: " << score << " Remaining time: " << time << endl;
         receiver->nextPacket(); // Discard the current data packet
         valor = time;
      }
   }
   robot->step(timeStep);
   return valor;

}

void enviarMapa()
{
   string flattened = "";
   int width = 2*(SalvaExtremos[1].second-SalvaExtremos[0].second)+5;
   int height = 2*(SalvaExtremos[1].first-SalvaExtremos[0].first)+5;

   for(int i = 2*SalvaExtremos[0].second-2; i <= 2*SalvaExtremos[1].second+2; i++)
   {
      for(int j = 2*SalvaExtremos[0].first-2; j <= 2*SalvaExtremos[1].first+2; j++)
      {
         cout << Mapeamento[i][j] << " ";
         flattened += Mapeamento[i][j];
         if (!(i == height - 1 && j == width - 1))
               flattened += ",";
      }
      cout << endl;
   }

   flattened.pop_back(); // remove última vírgula

   cout << "flattened preview: " << flattened.substr(0, 150) << endl;
   cout << "width=" << width << " height=" << height << endl;

   vector<char> message(8 + flattened.size());
   memcpy(message.data(), &width, sizeof(width));       // bytes 0–3
   memcpy(message.data() + 4, &height, sizeof(height)); // bytes 4–7
   memcpy(message.data() + 8, flattened.c_str(), flattened.size());

   robot->step(timeStep);
   while (robot->step(timeStep) != -1) {
      emitter->send(message.data(), message.size()); // mapa
      char msg = 'M';
      emitter->send(&msg, sizeof(msg));              // avaliar
      msg = 'E';
      emitter->send(&msg, sizeof(msg));              // encerrar
      break;
   }
   robot->step(timeStep);
   robot->step(timeStep);

}

void FimDeJogo()
{
   char message[1] = {'E'};
   emitter->send(message, sizeof(message));
}

void emitirFalhaProgresso()
{
   char message[1] = {'L'};
   emitter->send(message, sizeof(message));
}

void lerFalhaProgresso()
{
   while (receiver->getQueueLength() > 0)
   {
      const char *message = (const char *)receiver->getData();
      if (message[0] == 'L')
      {
         cout << "Falha de Progresso!" << endl;
      }
      receiver->nextPacket();
   }
}

// Inicializa o labirinto com -1
void initMaze()
{
   for (int i = 0; i < sizeMaze; i++)
   {
      for (int j = 0; j < sizeMaze; j++)
      {
         maze[i][j] = -1;         // -1 indica que a célula ainda não foi visitada
         blocked[i][j] = 0;       // 0 indica ausência de buracos
         parent[i][j] = {-1, -1}; // Inicializa o pai como inválido
         visited[i][j] = false;   // Marca todas as células como não visitadas
      }
   }
   for (int i = 0; i <= 590; i++)
   {
      for (int j = 0; j <= 590; j++)
      {
         Mapeamento[i][j] = '0';
         MapDfs[i][j] = 0;
      }
   }
}

// Retorna um array<int,4> onde:
//   [0] = 1 se há buraco à frente (norte local),   0 caso contrário
//   [1] = 1 se há buraco à direita (leste local),  0 caso contrário
//   [2] = 1 se há buraco atrás  (sul local),       0 caso contrário
//   [3] = 1 se há buraco à esquerda (oeste local), 0 caso contrário
array<bool, 4> checarBuracos()
{
   array<bool, 4> dir_buraco = {0, 0, 0, 0};

   for (int i = 0; i < 4; i++)
   {
      // “i” indica direção local: 0=Norte, 1=Leste, 2=Sul, 3=Oeste (relativo ao robô)
      // Para mapear para coordenadas globais:
      int globalDir = (idcompass + i) % 4;
      int nx = posx + dx[globalDir];
      int ny = posy + dy[globalDir];

      if (nx < 0 || nx >= sizeMaze || ny < 0 || ny >= sizeMaze)
      {
         // Fora do labirinto → sem buraco válido naquela célula
         dir_buraco[i] = 0;
      }
      else
      {
         // Se já marcamos buraco na célula (nx,ny), então 1, senão 0
         dir_buraco[i] = (blocked[nx][ny] == 1 ? 1 : 0);
      }
   }

   return dir_buraco;
}

double calculadesviopadrao(const array<double, 16> &distancias)
{
   
   double sum = 0.0;
   double mean = 0.0;
   int count = 0;

   for (double d : distancias)
   {
      if (d < 1.0) // Considera apenas distâncias válidas (menores que 1 metro)
      {
         sum += d;
         count++;
      }
   }

   if (count == 0)
      return INF; // Evita divisão por zero, retorna infinito se não houver distâncias válidas

   mean = sum / count;

   double variance_sum = 0.0;
   for (double d : distancias)
   {
      if (d < 1.0)
      {
         variance_sum += (d - mean) * (d - mean);
      }
   }

   return sqrt(variance_sum / count);
}

array<double, 8> checarParede(int delta)
{

   robot->step(timeStep);
   int H = lidar->getHorizontalResolution();
   const LidarPoint *cloud = lidar->getPointCloud();

   double robotradius = 0.037;
   double robotradius2 = robotradius * robotradius;
   

   array<double, 8> temParede = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};

   for (int i = 0; i < 8; ++i)
   {

      
      int deltadiagonal = delta-10; // para as diagonais, o angulo é maior, então precisamos de um delta menor para evitar pegar pontos muito distantes

      int centerRay = (i * (H / 4) + (H / 8)) % H;
      int start, end;
      if (i == 0)
      {
         centerRay = 0;
         start = max(0, centerRay - delta);
         end = min(H - 1, centerRay + delta);
      }
      else if (i == 1)
      {
         centerRay = H / 4;
         start = max(0, centerRay - delta);
         end = min(H - 1, centerRay + delta);
      }
      else if (i == 2)
      {
         centerRay = H / 2;
         start = max(0, centerRay - delta);
         end = min(H - 1, centerRay + delta);
      }
      else if(i == 3)
      {
         centerRay = 3 * H / 4;
         start = max(0, centerRay - delta);
         end = min(H - 1, centerRay + delta);
      } 
      else if(i == 4)
      {
         centerRay = H / 8;
         start = max(0, centerRay - deltadiagonal);
         end = min(H - 1, centerRay + deltadiagonal);
         
      } 
      else if(i == 5)
      {
         
         centerRay = 3 * H / 8;
         start = max(0, centerRay - deltadiagonal);
         end = min(H - 1, centerRay + deltadiagonal);
      } 
      else if(i == 6)
      {
         
         centerRay = 5 * H / 8; 
         start = max(0, centerRay - deltadiagonal);
         end = min(H - 1, centerRay + deltadiagonal);
      } 
      else
      {
         
         centerRay = 7 * H / 8;
         start = max(0, centerRay - deltadiagonal);
         end = min(H - 1, centerRay + deltadiagonal);
      }

      // cout << centerRay << endl;
      

      int baseIndex = 2 * H;

      double minRange = 10.0;
      double r = 1.0;
      double lateral = 0.0;
      double diff = 0.0;
      if (i == 0)
      {
         for (int k = start; k <= end; ++k)
         {
               r = fabs(cloud[baseIndex + k].x);
               lateral = fabs(cloud[baseIndex + k].y);
               if (lateral > robotradius)
               {
                  r = 1.0;
                  diff = 0.0;
               }
               else diff = sqrt(robotradius2 - lateral * lateral);
               minRange = min(minRange, r - diff);
         }
         for (int k = H - 1 - delta; k <= H - 1; ++k)
         {
               r = fabs(cloud[baseIndex + k].x);
               lateral = fabs(cloud[baseIndex + k].y);
               if (lateral > robotradius)
               {
                  r = 1.0;
                  diff = 0.0;
               }
               else diff = sqrt(robotradius2 - lateral * lateral);
               
               minRange = min(minRange, r - diff);
         }
      }
      else
      {
         for (int k = start; k <= end; ++k)
         {
               if (i == 1)
               { // direita
                  r = fabs(cloud[baseIndex + k].y);
                  lateral = fabs(cloud[baseIndex + k].x);
                  if (lateral > robotradius)
                  {
                     r = 1.0;
                     diff = 0.0;
                  }
                  else diff = sqrt(robotradius2 - lateral * lateral);
               }
               else if (i == 2)
               { // trás
                  r = fabs(cloud[baseIndex + k].x);
                  lateral = fabs(cloud[baseIndex + k].y);
                  if (lateral > robotradius)
                  {
                     r = 1.0;
                     diff = 0.0;
                  }
                  else diff = sqrt(robotradius2 - lateral * lateral);
               }
               else if (i == 3)
               { // esquerda
                  r = fabs(cloud[baseIndex + k].y);
                  lateral = fabs(cloud[baseIndex + k].x);
                  if (lateral > robotradius)
                  {
                     r = 1.0;
                     diff = 0.0;
                  }
                  else diff = sqrt(robotradius2 - lateral * lateral);
               }
               else if (i == 4) // para 4, 5, 6 e 7 precisa de revisao, a lateral nao esta funcionando corretamente, uma vez que queremos medir se o ponto esta dentro do raio do robo ROTACIONADO 45 GRAUS
               {
                  //45 graus
                  r = sqrt(cloud[baseIndex + k].x * cloud[baseIndex + k].x + cloud[baseIndex + k].y * cloud[baseIndex + k].y);
                  lateral = fabs(cloud[baseIndex + k].x * cos(pi/4) + cloud[baseIndex + k].y * sin(pi/4));
                  //cout << "PARA O ANGULO DE 45: " << "r: " << r << " lateral: " << lateral << endl; 
                  if (lateral > robotradius)
                  {
                     r = 1.0;
                     diff = 0.0;
                  }
                  else diff = sqrt(robotradius2 - lateral * lateral);
               }
               else if (i == 5)
               {
                  //135 graus
                  r = sqrt(cloud[baseIndex + k].x * cloud[baseIndex + k].x + cloud[baseIndex + k].y * cloud[baseIndex + k].y);
                  lateral = fabs(cloud[baseIndex + k].x * cos(3*pi/4) + cloud[baseIndex + k].y * sin(3*pi/4));
                  if (lateral > robotradius)
                  {
                     r = 1.0;
                     diff = 0.0;
                  }
                  else diff = sqrt(robotradius2 - lateral * lateral);
               }
               else if (i == 6)
               {
                  //225 graus
                  r = sqrt(cloud[baseIndex + k].x * cloud[baseIndex + k].x + cloud[baseIndex + k].y * cloud[baseIndex + k].y);
                  lateral = fabs(cloud[baseIndex + k].x * cos(5*pi/4) + cloud[baseIndex + k].y * sin(5*pi/4));
                  if (lateral > robotradius)
                  {
                     r = 1.0; 
                     diff = 0.0;
                  }
                  else diff = sqrt(robotradius2 - lateral * lateral);
               }
               else
               {
                  //315 graus
                  
                  r = sqrt(cloud[baseIndex + k].x * cloud[baseIndex + k].x + cloud[baseIndex + k].y * cloud[baseIndex + k].y);
                  lateral = fabs(cloud[baseIndex + k].x * cos(7*pi/4) + cloud[baseIndex + k].y * sin(7*pi/4));
                  //cout << "PARA O ANGULO DE 315: " << "r: " << r << " lateral: " << lateral << endl; 
                  if (lateral > robotradius)
                  {
                     r = 1.0;
                     diff = 0.0;
                  }
                  else diff = sqrt(robotradius2 - lateral * lateral);
               }
               minRange = min(minRange, r - diff);
         }
      }

      temParede[i] = minRange;
      // cout << temParede[i] << endl;
   }

   return temParede;
}

//Mapeamento
void UnsNaBorda()
{
   int Sec1 = 2*SalvaExtremos[0].first-3, Sec2 = 2*SalvaExtremos[1].first+3;
   for(int i = 2*SalvaExtremos[0].second-2; i <= 2*SalvaExtremos[1].second+2; i++)
   {
      MapDfs[i][Sec1] = 1;
      MapDfs[i][Sec2] = 1;
      Mapeamento[i][Sec1]= '1';
      Mapeamento[i][Sec2]= '1';
   }
   Sec1 = 2*SalvaExtremos[0].second-3, Sec2 = 2*SalvaExtremos[1].second+3;
   for(int j = 2*SalvaExtremos[0].first-2; j <= 2*SalvaExtremos[1].first+2; j++)
   {
      MapDfs[j][Sec1] = 1;
      MapDfs[j][Sec2] = 1;
      Mapeamento[Sec1][j] = '1';
      Mapeamento[Sec2][j] = '1';
   }
}

void ColocarAstA4()
{
   UnsNaBorda();
   for(Cid i : EntradasA4)
   {
      cout << i.x << " " << i.y << " " << i.id << endl;
      if(i.id == 0)
      {
         Mapeamento[(2*i.x)-1][(2*i.y)-2] = '1';
         Mapeamento[(2*i.x)-1][(2*i.y)+2] = '1';
         Mapeamento[(2*i.x)][(2*i.y)-2] = '1';
         Mapeamento[(2*i.x)][(2*i.y)+2] = '1';

         Mapeamento[(2*i.x)-2][(2*i.y)] = '*';
         Mapeamento[(2*i.x)-2][(2*i.y)+1] = '*';
         Mapeamento[(2*i.x)-2][(2*i.y)-1] = '*';
         Mapeamento[(2*i.x)-2][(2*i.y)+2] = '*';
         Mapeamento[(2*i.x)-2][(2*i.y)-2] = '*';

      }
      if(i.id == 1)
      {
         Mapeamento[(2*i.x)+2][(2*i.y)-1] = '1';
         Mapeamento[(2*i.x)-2][(2*i.y)-1] = '1';
         Mapeamento[(2*i.x)+2][(2*i.y)] = '1';
         Mapeamento[(2*i.x)-2][(2*i.y)] = '1';

         Mapeamento[(2*i.x)+1][(2*i.y)-2] = '*';
         Mapeamento[(2*i.x)-1][(2*i.y)-2] = '*';
         Mapeamento[(2*i.x)+2][(2*i.y)-2] = '*';
         Mapeamento[(2*i.x)-2][(2*i.y)-2] = '*';
         Mapeamento[(2*i.x)][(2*i.y)-2] = '*';
      }

      if(i.id == 2)
      {
         Mapeamento[(2*i.x)+1][(2*i.y)-2] = '1';
         Mapeamento[(2*i.x)+1][(2*i.y)+2] = '1';
         Mapeamento[(2*i.x)][(2*i.y)-2] = '1';
         Mapeamento[(2*i.x)][(2*i.y)+2] = '1';

         Mapeamento[(2*i.x)-2][(2*i.y)] = '*';
         Mapeamento[(2*i.x)-2][(2*i.y)+1] = '*';
         Mapeamento[(2*i.x)-2][(2*i.y)-1] = '*';
         Mapeamento[(2*i.x)-2][(2*i.y)+2] = '*';
         Mapeamento[(2*i.x)-2][(2*i.y)-2] = '*';

      }

      if(i.id == 3)
      {
         Mapeamento[(2*i.x)+2][(2*i.y)+1] = '1';
         Mapeamento[(2*i.x)-2][(2*i.y)+1] = '1';
         Mapeamento[(2*i.x)+2][(2*i.y)] = '1';
         Mapeamento[(2*i.x)-2][(2*i.y)] = '1';

         Mapeamento[(2*i.x)+1][(2*i.y)-2] = '*';
         Mapeamento[(2*i.x)-1][(2*i.y)-2] = '*';
         Mapeamento[(2*i.x)+2][(2*i.y)-2] = '*';
         Mapeamento[(2*i.x)-2][(2*i.y)-2] = '*';
         Mapeamento[(2*i.x)][(2*i.y)-2] = '*';
      }

   }
   for(pii i : Area4)
   {
      Mapeamento[(2*i.second)+1][(2*i.first)+1] = '*';
      Mapeamento[(2*i.second)-1][(2*i.first)+1] = '*';
      Mapeamento[(2*i.second)+1][(2*i.first)-1] = '*';
      Mapeamento[(2*i.second)-1][(2*i.first)-1] = '*';
      Mapeamento[(2*i.second)][(2*i.first)] = '*';
      Mapeamento[(2*i.second)-1][(2*i.first)] = '*';
      Mapeamento[(2*i.second)+1][(2*i.first)] = '*';
      Mapeamento[(2*i.second)][(2*i.first)+1] = '*';
      Mapeamento[(2*i.second)][(2*i.first)-1] = '*';
      if(SalvaAsteriscos[0].first > (2*i.first)-1)
      {
         SalvaAsteriscos[0].first = (2*i.first)-1;
      }
      if(SalvaAsteriscos[0].second > (2*i.second)-1)
      {
         SalvaAsteriscos[0].second = (2*i.second)-1;
      }
      if(SalvaAsteriscos[1].second < (2*i.second)+1)
      {
         SalvaAsteriscos[1].second = (2*i.second)+1;
      }
      if(SalvaAsteriscos[1].first < (2*i.first)+1)
      {
         SalvaAsteriscos[1].first = (2*i.first)+1;
      }
   }
   for(int i = SalvaAsteriscos[0].second; i <= SalvaAsteriscos[1].second; i++)
   {
      for(int j = SalvaAsteriscos[0].first; j <= SalvaAsteriscos[1].first; j++)
      {
         if(Mapeamento[i][j] == "0" && MapDfs[i][j] == 0)
         {
            Com=true;
            queue<pii>Caminho;
            queue<pii> Q;
            Q.push({i, j});
            Caminho.push({i, j});
            while(!Q.empty())
            {
               pii atual = Q.front();
               Q.pop();
               if(MapDfs[atual.first][atual.second] == 2)
               {
                  continue;
               }
               MapDfs[atual.first][atual.second] = 2;

               if(Mapeamento[atual.first+1][atual.second] == "1" || Mapeamento[atual.first-1][atual.second] == "1" || Mapeamento[atual.first][atual.second-1] == "1" || Mapeamento[atual.first][atual.second+1] == "1" or Mapeamento[atual.first][atual.second+1] == "o" or Mapeamento[atual.first][atual.second+1] == "r" or Mapeamento[atual.first][atual.second+1] == "g")
               {
                  Com = false;
                  break;
               }
               if(MapDfs[atual.first+1][atual.second] == 1 or MapDfs[atual.first-1][atual.second] == 1 or MapDfs[atual.first][atual.second+1] == 1 or MapDfs[atual.first][atual.second-1] == 1)
               {
                  Com = false;
                  break;
               }
               if(Mapeamento[atual.first+1][atual.second] == "0")
               {
                  Q.push({atual.first+1, atual.second});
                  Caminho.push({atual.first+1, atual.second});
               }
               if(Mapeamento[atual.first-1][atual.second] == "0")
               {
                  Q.push({atual.first-1, atual.second});
                  Caminho.push({atual.first-1, atual.second});
               }
               if(Mapeamento[atual.first][atual.second+1] == "0")
               {
                  Q.push({atual.first, atual.second+1});
                  Caminho.push({atual.first, atual.second+1});
               }
               if(Mapeamento[atual.first][atual.second-1] == "0")
               {
                  Q.push({atual.first, atual.second-1});
                  Caminho.push({atual.first, atual.second-1});
               }
            }
            if(Com)
            {
               while(!Caminho.empty())
               {
                  cout << "COLOQUEI UM * EM " << Caminho.front().first << " " << Caminho.front().second << endl;
                  pii atual = Caminho.front();
                  Caminho.pop();
                  Mapeamento[atual.first][atual.second] = '*';
               }
            }
         }
      }
   }

}

void Coloca1(int CordX, int CordY)
{
   if(SalvaSala == 4 && MudeiDeSala)
   {
      if(SalvaAsteriscos[0].first > CordY)
      {
         SalvaAsteriscos[0].first = CordY;
      }
      if(SalvaAsteriscos[0].second > CordX)
      {
         SalvaAsteriscos[0].second = CordX;
      }
      if(SalvaAsteriscos[1].second < CordX)
      {
         SalvaAsteriscos[1].second = CordX;
      }
      if(SalvaAsteriscos[1].first < CordY)
      {
         SalvaAsteriscos[1].first = CordY;
      }

      Mapeamento[CordX][CordY] = "*";
   }
   if(Mapeamento[CordX][CordY] != "*")
   {
      Mapeamento[CordX][CordY] = '1';
      MapDfs[CordX][CordY] = 1;
   }

}

pdd RetornarP(int Conta)
{
      int Rays = 2;
      float P1=INF, P2 = INF;
      const LidarPoint *cloud = lidar->getPointCloud();
      if(Conta == 0){
         for(int i = north-(pc/9)-Rays; i <= north-(pc/9)+Rays; i++)
         {
            P1 = min(P1, cloud[i].x);
         }
         for(int i = north+(pc/9)-Rays; i <= north+(pc/9)+Rays; i++)
         {
            P2 = min(P2, cloud[i].x);
         }
      }
      if(Conta == 1){
         for(int i = east-(pc/9)-Rays; i <= east-(pc/9)+Rays; i++)
         {
            P1 = min(P1, cloud[i].y);
         }
         for(int i = east+(pc/9)-Rays; i <= east+(pc/9)+Rays; i++)
         {
            P2 = min(P2, cloud[i].y);
         }
      }
      if(Conta == 2){
         for(int i = south-(pc/9)-Rays; i <= south-(pc/9)+Rays; i++)
         {
            P1 = min(P1, cloud[i].x);
         }
         for(int i = south+(pc/9)-Rays; i <= south+(pc/9)+Rays; i++)
         {
            P2 = min(P2, cloud[i].x);
         }
      }
      if(Conta == 3){
      for(int i = west-(pc/9)-Rays; i <= west-(pc/9)+Rays; i++)
      {
         P1 = min(P1, cloud[i].y);
      }
      for(int i = west+(pc/9)-Rays; i <= west+(pc/9)+Rays; i++)
      {
         P2 = min(P2, cloud[i].y);
      }
   }
   return {fabs(P1), fabs(P2)};
}

float SeeFront(int Conta)
{
      int Rays = 1;
      float P1=INF;
      const LidarPoint *cloud = lidar->getPointCloud();
      if(Conta == 0){
         for(int i = 3*pc-Rays; i <= 3*pc; i++)
         {
            P1 = min(P1, cloud[i].x);
         }
         for(int i = north; i <= north+Rays; i++)
         {
            P1 = min(P1, cloud[i].x);
         }
      }
      if(Conta == 1){
         for(int i = east-Rays; i <= east+Rays; i++)
         {
            P1 = min(P1, cloud[i].y);
         }
      }
      if(Conta == 2){
         for(int i = south-Rays; i <= south+Rays; i++)
         {
            P1 = min(P1, cloud[i].x);
         }
      }
      if(Conta == 3){
         for(int i = west-Rays; i <= west+Rays; i++)
         {
            P1 = min(P1, cloud[i].y);
         }
   }
   return fabs(P1);
}

void SalaAtual()
{
   const unsigned char *image = colorSensor->getImage();
   int r = colorSensor->imageGetRed(image, width, 0, 0);
   int g = colorSensor->imageGetGreen(image, width, 0, 0);
   int b = colorSensor->imageGetBlue(image, width, 0, 0);
   int Const = 10;
   CSala++;
   if (posx % 2 != 0 || posy % 2 != 0)
   {
      if (r >= 32 - Const && r <= 32 + Const && g >= 247 - Const && g <= 247 + Const && b >= 32 - Const && b <= 32 + Const)
      {
         MudeiDeSala = false;
      }
      if (r >= 251 - Const && r <= 251 + Const && g >= 61 - Const && g <= 61 + Const && b >= 61 - Const && b <= 61 + Const)
      {
         MudeiDeSala = false;
      }      
      else if (r >= 251 - Const && r <= 251 + Const && g >= 251 - Const && g <= 251 + Const && b >= 61 - Const && b <= 61 + Const)
      {
         MudeiDeSala = false;
      }
   }
   // blue
   int TrueX = posy;
   int TrueY = posx;
   if (r >= 61 - Const && r <= 61 + Const && g >= 61 - Const && g <= 61 + Const && b >= 250 - Const && b <= 250 + Const)
   {
      if(posx % 2 == 0 && posy % 2 == 0)
      {      
         Mapeamento[(2 * TrueY) - 1][(2 * TrueX) + 1] = 'b';
         Mapeamento[(2 * TrueY) + 1][(2 * TrueX) - 1] = 'b';
         Mapeamento[(2 * TrueY) + 1][(2 * TrueX) + 1] = 'b';
         Mapeamento[(2 * TrueY) - 1][(2 * TrueX) - 1] = 'b';
         MapDfs[(2 * TrueY) - 1][(2 * TrueX) + 1] = 1;
         MapDfs[(2 * TrueY) + 1][(2 * TrueX) - 1] = 1;
         MapDfs[(2 * TrueY) + 1][(2 * TrueX) + 1] = 1;
         MapDfs[(2 * TrueY) - 1][(2 * TrueX) - 1] = 1;
      }
      if(CSala >= 3)
      {   
         CSala=0;
         if (SalvaSala == 1)
         {
            SalvaSala = 2;
            cout << "Sala 2" << endl;
         }
         else if (SalvaSala == 2)
         {
            SalvaSala = 1;
            cout << "Sala 1" << endl;
         }
      } 
  }
   // purple
   else if (r >= 139 - Const && r <= 139 + Const && g >= 61 - Const && g <= 61 + Const && b >= 221 - Const && b <= 221 + Const)
   {
      if(posx % 2 == 0 && posy % 2 == 0)
      {
         Mapeamento[(2 * TrueY) - 1][(2 * TrueX) + 1] = 'p';
         Mapeamento[(2 * TrueY) + 1][(2 * TrueX) - 1] = 'p';
         Mapeamento[(2 * TrueY) + 1][(2 * TrueX) + 1] = 'p';
         Mapeamento[(2 * TrueY) - 1][(2 * TrueX) - 1] = 'p';
         MapDfs[(2 * TrueY) - 1][(2 * TrueX) + 1] = 1;
         MapDfs[(2 * TrueY) + 1][(2 * TrueX) - 1] = 1;
         MapDfs[(2 * TrueY) + 1][(2 * TrueX) + 1] = 1;
         MapDfs[(2 * TrueY) - 1][(2 * TrueX) - 1] = 1;
      }
      if(CSala >= 3)
      {
         CSala=0;
         if (SalvaSala == 3)
         {
            SalvaSala = 2;
            cout << "Sala 2" << endl;
         }
         else if (SalvaSala == 2)
         {
            SalvaSala = 3;
            cout << "Sala 3" << endl;
         }
      }
   }
   // Green
   else if (r >= 32 - Const && r <= 32 + Const && g >= 247 - Const && g <= 247 + Const && b >= 32 - Const && b <= 32 + Const)
   {
      if(TrueX%2 != 0 || TrueY%2 != 0)
      {
         EntradasA4.push_back({TrueY+dx[idcompass], TrueX+dy[idcompass], idcompass});
      }
      else
      {
         EntradasA4.push_back({TrueY, TrueX, idcompass});
      }
      MudeiDeSala = false;
      if(posx % 2 == 0 && posy % 2 == 0)
      {
         Mapeamento[(2 * TrueY) - 1][(2 * TrueX) + 1] = 'g';
         Mapeamento[(2 * TrueY) + 1][(2 * TrueX) - 1] = 'g';
         Mapeamento[(2 * TrueY) + 1][(2 * TrueX) + 1] = 'g';
         Mapeamento[(2 * TrueY) - 1][(2 * TrueX) - 1] = 'g';
         MapDfs[(2 * TrueY) - 1][(2 * TrueX) + 1] = 1;
         MapDfs[(2 * TrueY) + 1][(2 * TrueX) - 1] = 1;
         MapDfs[(2 * TrueY) + 1][(2 * TrueX) + 1] = 1;
         MapDfs[(2 * TrueY) - 1][(2 * TrueX) - 1] = 1;
      }
      if(CSala >= 3)
      {
         CSala=0;
         if (SalvaSala == 1)
         {
            
            SalvaSala = 4;
            cout << "Sala 4 " << "id " << idcompass << endl;
         }
         else if (SalvaSala == 4)
         {
            SalvaSala = 1;
            cout << "Sala 1" << endl;
         }
      }
   }
   // Red
   else if (r >= 251 - Const && r <= 251 + Const && g >= 61 - Const && g <= 61 + Const && b >= 61 - Const && b <= 61 + Const)
   {
      if(TrueX%2 != 0 || TrueY%2 != 0)
      {
         EntradasA4.push_back({TrueY+dx[idcompass], TrueX+dy[idcompass], idcompass});
      }
      else
      {
         EntradasA4.push_back({TrueY, TrueX, idcompass});
      }
      MudeiDeSala = false;
      if(posx % 2 == 0 && posy % 2 == 0)
      {
         Mapeamento[(2 * TrueY) - 1][(2 * TrueX) + 1] = 'r';
         Mapeamento[(2 * TrueY) + 1][(2 * TrueX) - 1] = 'r';
         Mapeamento[(2 * TrueY) + 1][(2 * TrueX) + 1] = 'r';
         Mapeamento[(2 * TrueY) - 1][(2 * TrueX) - 1] = 'r';
         MapDfs[(2 * TrueY) - 1][(2 * TrueX) + 1] = 1;
         MapDfs[(2 * TrueY) + 1][(2 * TrueX) - 1] = 1;
         MapDfs[(2 * TrueY) + 1][(2 * TrueX) + 1] = 1;
         MapDfs[(2 * TrueY) - 1][(2 * TrueX) - 1] = 1;
      }
      if(CSala >= 3)
      {
         CSala=0;
      
         if (SalvaSala == 3)
         {
            
            SalvaSala = 4;
            cout << "Sala 4 " << "id " << idcompass << endl;
         }
         else if (SalvaSala == 4)
         {
            SalvaSala = 3;
            cout << "Sala 3" << endl;
         }
      }
   }
   // Yellow
   else if (r >= 251 - Const && r <= 251 + Const && g >= 251 - Const && g <= 251 + Const && b >= 61 - Const && b <= 61 + Const)
   {
      if(posx % 2 == 0 && posy % 2 == 0)
      {     
         Mapeamento[(2 * TrueY) - 1][(2 * TrueX) + 1] = 'y';
         Mapeamento[(2 * TrueY) + 1][(2 * TrueX) - 1] = 'y';
         Mapeamento[(2 * TrueY) + 1][(2 * TrueX) + 1] = 'y';
         Mapeamento[(2 * TrueY) - 1][(2 * TrueX) - 1] = 'y';
         MapDfs[(2 * TrueY) - 1][(2 * TrueX) + 1] = 1;
         MapDfs[(2 * TrueY) + 1][(2 * TrueX) - 1] = 1;
         MapDfs[(2 * TrueY) + 1][(2 * TrueX) + 1] = 1;
         MapDfs[(2 * TrueY) - 1][(2 * TrueX) - 1] = 1;
      }      
   if(CSala >= 3)
      {
         CSala=0;
      
         if (SalvaSala == 3)
         {
            SalvaSala = 1;
            cout << "Sala 1" << endl;
         }
         else if (SalvaSala == 1)
         {
            SalvaSala = 3;
            cout << "Sala 3" << endl;
         }
  
      }
   }
      // Orange
   else if (r >= 251 - Const && r <= 251 + Const && g >= 221 - Const && g <= 221 + Const && b >= 61 - Const && b <= 61 + Const)
   {
      if(TrueX%2 != 0 || TrueY%2 != 0)
      {
         EntradasA4.push_back({TrueY+dx[idcompass], TrueX+dy[idcompass], idcompass});
      }
      else
      {
         EntradasA4.push_back({TrueY, TrueX, idcompass});
      }

      MudeiDeSala = false;
      if(posx % 2 == 0 && posy % 2 == 0)
      {
         Mapeamento[(2 * TrueY) - 1][(2 * TrueX) + 1] = 'o';
         Mapeamento[(2 * TrueY) + 1][(2 * TrueX) - 1] = 'o';
         Mapeamento[(2 * TrueY) + 1][(2 * TrueX) + 1] = 'o';
         Mapeamento[(2 * TrueY) - 1][(2 * TrueX) - 1] = 'o';
         MapDfs[(2 * TrueY) - 1][(2 * TrueX) + 1] = 1;
         MapDfs[(2 * TrueY) + 1][(2 * TrueX) - 1] = 1;
         MapDfs[(2 * TrueY) + 1][(2 * TrueX) + 1] = 1;
         MapDfs[(2 * TrueY) - 1][(2 * TrueX) - 1] = 1;

      }
      if(CSala >= 3)
      {
         CSala=0;
      if (SalvaSala == 2)
      {
         SalvaSala = 4;
         cout << "Sala 4 " << "id " << idcompass << endl;
      }
      else if (SalvaSala == 4)
      {
         SalvaSala = 2;
         cout << "Sala 2" << endl;
      }
   }
   }
}

float CheckDiago(int Cont)
{
   int Ray = 2;
   //   N
   //W-----E
   //   S
   //LEMBRA SEMPRE NORTH/SOUTH X  West/East Y
   float Menor = INF;
   // N/W 1
   if(Cont == 1)
   {
      for(int i = (west+pc/8)-Ray; i < (west+pc/8)+Ray; i++)//Checa X
      {
         // cout << lidar->getRangeImage()[i] << endl;
         Menor = min(lidar->getRangeImage()[i], Menor);
      }
   }
   //N/E 2
   if(Cont == 2)
   {
      for(int i = (north+pc/8)-Ray; i < (north+pc/8)+Ray; i++)//Checa X
      {
         // cout << lidar->getRangeImage()[i] << endl;
         Menor = min(lidar->getRangeImage()[i], Menor);
      }
   }
   //E/S 3
   if(Cont == 3)
   {
      for(int i = (east+pc/8)-Ray; i < (east+pc/8)+Ray; i++)//Checa X
      {
         // cout << lidar->getRangeImage()[i] << endl;
         Menor = min(lidar->getRangeImage()[i], Menor);
      }

   }
   //S/W 4
   if(Cont == 4)
   {
      for(int i = (south+pc/8)-Ray; i < (south+pc/8)+Ray; i++)//Checa X
      {
         // cout << lidar->getRangeImage()[i] << endl;
         Menor = min(lidar->getRangeImage()[i], Menor);
      }

   }
   if(Menor < 0.062)
   {
      return 1;
   }
   return Menor;
}

void ColocarParedesNoMapa(int Cord)
{
   double ConstParede = 0.066, ContDiag = 0.085;  //calibrar qndo pegar o pc do vini
   int TrueX = posy;
   int TrueY = posx;
   //NOrth
   if(idcompass == 3 && Cord == 0)//AC
   {
      if(CheckDiago(1) < ContDiag)
      {
         Coloca1(2*TrueY+2, (2*TrueX)-2);
      }
      if(CheckDiago(2) < ContDiag)
      {
         Coloca1(2*TrueY-2, (2*TrueX)-2);
      }

      if(SeeFront(0) < ConstParede || IgnoraOsTermos)
      {
         Coloca1(2*TrueY, (2*TrueX)-2);
      }
      pdd Par = RetornarP(0);
      double P1 = Par.first, P2 = Par.second;
      if((P1 < ConstParede || IgnoraOsTermos))
      {
         cout << "ENTREI";
         delay(100);
         Coloca1(2*TrueY+1, (2*TrueX)-2);
      }
      if((P2 < ConstParede || IgnoraOsTermos))
      {
         delay(100);
         Coloca1(2*TrueY-1, (2*TrueX)-2);
      }
   }
   else if(idcompass == 0 && Cord == 0)//AC
   {
      if(CheckDiago(1) < ContDiag)
      {
         Coloca1(2*TrueY-2, 2*TrueX-2);
      }
      if(CheckDiago(2) < ContDiag)
      {
         Coloca1(2*TrueY-2, 2*TrueX+2);
      }

      if(SeeFront(0) < ConstParede || IgnoraOsTermos)
      {
         Coloca1(2*TrueY-2, 2*TrueX);
      }
      pdd Par = RetornarP(0);
      double P1 = Par.first, P2 = Par.second;
      if((P1 < ConstParede || IgnoraOsTermos))
      {
         Coloca1(2*TrueY-2, 2*TrueX-1);
      }
      if((P2 < ConstParede || IgnoraOsTermos))
      {
         Coloca1(2*TrueY-2, 2*TrueX+1);
      }
   }
   else if(idcompass == 1  && Cord == 0)//AC
   {
      if(CheckDiago(1) < ContDiag)
      {
         Coloca1(2*TrueY-2, 2*TrueX+2);
      }
      if(CheckDiago(2) < ContDiag)
      {
         Coloca1(2*TrueY+2, 2*TrueX+2);
      }

      if(SeeFront(0) < ConstParede || IgnoraOsTermos)
      {
         Coloca1(2*TrueY, 2*TrueX+2);
      }
      pdd Par = RetornarP(0);
      double P1 = Par.first, P2 = Par.second;
      if((P1 < ConstParede || IgnoraOsTermos))
      {
         // cout << "P1 " << P1 << endl; 
         Coloca1(2*TrueY-1, 2*TrueX+2);
      }
      if((P2 < ConstParede || IgnoraOsTermos))
      {
         // cout << "P2 " << P2 << endl; 
         Coloca1(2*TrueY+1, 2*TrueX+2);
      }
   }    
   else if(idcompass == 2 && Cord == 0)//AC
   {
      if(CheckDiago(1) < ContDiag)
      {
         Coloca1(2*TrueY+2, 2*TrueX+2);
      }
      if(CheckDiago(2) < ContDiag)
      {
         Coloca1(2*TrueY+2, 2*TrueX-2);
      }

      if(SeeFront(0) < ConstParede || IgnoraOsTermos)
      {
         cout << "SEEF" << SeeFront(0) << endl;
         Coloca1(2*TrueY+2, 2*TrueX);
      }
      pdd Par = RetornarP(0);
      double P1 = Par.first, P2 = Par.second;
      if((P1 < ConstParede || IgnoraOsTermos))
      {
         Coloca1(2*TrueY+2, 2*TrueX+1);
      }
      if((P2 < ConstParede || IgnoraOsTermos))
      {
         Coloca1(2*TrueY+2, 2*TrueX-1);
      }
   }

   // //EAST
   if(idcompass == 3 && Cord == 1)//AC
   {
      cout << "C8" << endl;
      if(CheckDiago(2) < ContDiag)
      {
         Coloca1(2*TrueY-2, (2*TrueX)-2);
      }
      if(CheckDiago(3) < ContDiag)
      {
         Coloca1(2*TrueY-2, 2*TrueX+2);
      }


      if(SeeFront(1) < ConstParede)
      {
         Coloca1(2*TrueY-2, 2*TrueX);
      }
      pdd Par = RetornarP(1);
      double P1 = Par.first, P2 = Par.second;
      // cout << "PS " << P1 << " " << P2 << endl;
      if(P1 < ConstParede)
      {
         Coloca1(2*TrueY-2, 2*TrueX-1);
      }
      if(P2 < ConstParede)
      {
         Coloca1(2*TrueY-2, 2*TrueX+1);
      }
   }
   else if(idcompass == 0 && Cord == 1)//AC
   {
      cout << "C9" << endl;
      if(CheckDiago(2) < ContDiag)
      {
         Coloca1(2*TrueY-2, 2*TrueX+2);
      }
      if(CheckDiago(3) < ContDiag)
      {
         Coloca1(2*TrueY+2, 2*TrueX+2);
      }

      if(SeeFront(1) < ConstParede)
      {
         Coloca1(2*TrueY, 2*TrueX+2);
      }
      pdd Par = RetornarP(1);
      double P1 = Par.first, P2 = Par.second;
      if(P1 < ConstParede)
      {
         Coloca1(2*TrueY-1, 2*TrueX+2);
      }
      if(P2 < ConstParede)
      {
         Coloca1(2*TrueY+1, 2*TrueX+2);
      }
   }
   else if(idcompass == 1 && Cord == 1)//AC
   {
      cout << "C10 " << endl;
      if(CheckDiago(2) < ContDiag)
      {
         Coloca1(2*TrueY+2, 2*TrueX+2);
      }
      if(CheckDiago(3) < ContDiag)
      {
         Coloca1(2*TrueY+2, 2*TrueX-2);
      }

      if(SeeFront(1) < ConstParede){
         Coloca1(2*TrueY+2, 2*TrueX);
      }
      pdd Par = RetornarP(1);
      double P1 = Par.first, P2 = Par.second;
      if(P1 < ConstParede)
      {
         Coloca1(2*TrueY+2, 2*TrueX+1);
      }
      if(P2 < ConstParede)
      {
         Coloca1(2*TrueY+2, 2*TrueX-1);
      }
   }
   else if(idcompass == 2 && Cord == 1)//AC
   {
      if(CheckDiago(3) < ContDiag)
      {
         Coloca1(2*TrueY-2, 2*TrueX-2);
      }
      if(CheckDiago(2) < ContDiag)
      {
         Coloca1(2*TrueY+2, 2*TrueX-2);
      }
      if(SeeFront(1) < ConstParede){
         Coloca1(2*TrueY, 2*TrueX-2);
      }
      pdd Par = RetornarP(1);
      double P1 = Par.first, P2 = Par.second;
      if(P1 < ConstParede)
      {
         Coloca1(2*TrueY+1, 2*TrueX-2);
      }
      if(P2 < ConstParede )
      {
         Coloca1(2*TrueY-1, 2*TrueX-2);
      }
   }

   
   // //SULL
   if(idcompass == 3 && Cord == 2)//AC
   {
      if(CheckDiago(3) < ContDiag)
      {
         Coloca1(2*TrueY-2, 2*TrueX+2);
      }
      if(CheckDiago(4) < ContDiag)
      {
         Coloca1(2*TrueY+2, 2*TrueX+2);
      }
      if(SeeFront(2) < ConstParede){
      Coloca1(2*TrueY, 2*TrueX+2);
      }
      pdd Par = RetornarP(2);
      double P1 = Par.first, P2 = Par.second;

      if(P1 < ConstParede)
      {
         Coloca1(2*TrueY-1, 2*TrueX+2);
      }
      if(P2 < ConstParede)
      {
         Coloca1(2*TrueY+1, 2*TrueX+2);
      }
   }
   else if(idcompass == 0 && Cord == 2)//AC
   {
      if(CheckDiago(3) < ContDiag)
      {
         Coloca1(2*TrueY+2, 2*TrueX+2);
      }
      if(CheckDiago(4) < ContDiag)
      {
         Coloca1(2*TrueY+2, 2*TrueX-2);
      }
      if(SeeFront(2) < ConstParede){
         Coloca1(2*TrueY+2, 2*TrueX);
      }
      pdd Par = RetornarP(2);
      double P1 = Par.first, P2 = Par.second;
      if(P1 < ConstParede)
      {
         Coloca1(2*TrueY+2, 2*TrueX+1);
      }
      if(P2 < ConstParede)
      {
         Coloca1(2*TrueY+2, 2*TrueX-1);
      }
   }
   else if(idcompass == 1  && Cord == 2)//AC
   {
      if(CheckDiago(3) < ContDiag)
      {
         Coloca1(2*TrueY+2, 2*TrueX-2);
      }
      if(CheckDiago(4) < ContDiag)
      {
         Coloca1(2*TrueY-2, 2*TrueX-2);
      }
      if(SeeFront(2) < ConstParede)
      {
         Coloca1(2*TrueY, 2*TrueX-2);
      }
      pdd Par = RetornarP(2);
      double P1 = Par.first, P2 = Par.second;
      if(P1 < ConstParede)
      {
         Coloca1(2*TrueY+1, 2*TrueX-2);
      }
      if(P2 < ConstParede )
      {
         Coloca1(2*TrueY-1, 2*TrueX-2);
      }
   }
   else if(idcompass == 2 && Cord == 2)//AC
   {      
      if(CheckDiago(3) < ContDiag)
      {
         Coloca1(2*TrueY-2, 2*TrueX-2);
      }
      if(CheckDiago(4) < ContDiag)
      {
         Coloca1(2*TrueY-2, 2*TrueX+2);
      }
      if(SeeFront(2) < ConstParede)
      {
         Coloca1(2*TrueY-2, 2*TrueX);
      }
      pdd Par = RetornarP(2);
      double P1 = Par.first, P2 = Par.second;
      if(P1 < ConstParede)
      {
         Coloca1(2*TrueY-2, 2*TrueX-1);
      }
      if(P2 < ConstParede)
      {
         Coloca1(2*TrueY-2, 2*TrueX+1);
      }
   }

   //WEST
   if(idcompass == 3 && Cord == 3)//AC
   {
      cout << "Coloquei2" << endl;
      if(CheckDiago(1) < ContDiag)
      {
         Coloca1(2*TrueY+2, (2*TrueX)-2);
      }
      if(CheckDiago(4) < ContDiag)
      {
         Coloca1(2*TrueY+2, 2*TrueX+2);
      }

      if(SeeFront(3) < ConstParede){
         Coloca1(2*TrueY+2, 2*TrueX);
      }
      pdd Par = RetornarP(3);
      double P1 = Par.first, P2 = Par.second;
      if(P1 < ConstParede)
      {
         Coloca1(2*TrueY+2, 2*TrueX+1);
      }
      if(P2 < ConstParede)
      {
         Coloca1(2*TrueY+2, 2*TrueX-1);
      }
   }
   else if(idcompass == 0 && Cord == 3)//AC
   {
      if(CheckDiago(4) < ContDiag)
      {
         Coloca1(2*TrueY+2, 2*TrueX-2);
      }
      if(CheckDiago(1) < ContDiag)
      {
         Coloca1(2*TrueY-2, 2*TrueX-2);
      }

      if(SeeFront(3) < ConstParede){
      Coloca1(2*TrueY, 2*TrueX-2);
      }
      pdd Par = RetornarP(3);
      double P1 = Par.first, P2 = Par.second;
      if(P1 < ConstParede)
      {
         Coloca1(2*TrueY+1, 2*TrueX-2);
      }
      if(P2 < ConstParede)
      {
         Coloca1(2*TrueY-1, 2*TrueX-2);
      }
   }
   else if(idcompass == 1  && Cord == 3)//AC
   {
      if(CheckDiago(1) < ContDiag)
      {
         Coloca1(2*TrueY-2, 2*TrueX+2);
      }
      if(CheckDiago(4) < ContDiag)
      {
         Coloca1(2*TrueY-2, 2*TrueX-2);
      }
      if(SeeFront(3) < ConstParede){
         Coloca1(2*TrueY-2, 2*TrueX);
      }
      pdd Par = RetornarP(3);
      double P1 = Par.first, P2 = Par.second;
      if(P1 < ConstParede)
      {
         Coloca1(2*TrueY-2, 2*TrueX-1);

      }
      if(P2 < ConstParede)
      {
         Coloca1(2*TrueY-2, 2*TrueX+1);
      }
   }
   else if(idcompass == 2 && Cord == 3)//AC
   {
      cout << "Coloquei5" << endl;
      if(CheckDiago(1) < ContDiag)
      {
         Coloca1(2*TrueY+2, 2*TrueX+2);
      }
      if(CheckDiago(4) < ContDiag)
      {
         Coloca1(2*TrueY-2, 2*TrueX+2);
      }

      if(SeeFront(3) < ConstParede){
         Coloca1(2*TrueY, 2*TrueX+2);
      }
      pdd Par = RetornarP(3);
      double P1 = Par.first, P2 = Par.second;

      if(P1 < ConstParede)
      {
         Coloca1(2*TrueY-1, 2*TrueX+2);
      }
      if(P2 < ConstParede)
      {
         Coloca1(2*TrueY+1, 2*TrueX+2);
      }
   }

}




int checkwall()
{
   // Verifica as distâncias do lidar em cada direção
   int ans = 0;
   int n, e, s, w, ne, se, sw, nw;
   n = 0;
   e = 0;
   s = 0;
   w = 0;
   ne = 0;
   se = 0;
   sw = 0;
   nw = 0;

   double wall_limiar = 0.061;
   double wall_limiar_diagonal = wall_limiar*sqrt(2);
   cout << "LIMIAR DA DIAGONAL: " << wall_limiar_diagonal << endl;
   array<double, 8> temParede;
   
   temParede = checarParede(64);
   
   array<bool, 4> no_buraco = checarBuracos();
   cout << "Tem Parede: " << temParede[0] << " " << temParede[1] << " " << temParede[2] << " " << temParede[3] 
   << " " << temParede[4] << " " << temParede[5] << " " << temParede[6] << " " << temParede[7] <<  endl;
   
   if (temParede[0] >= wall_limiar && !no_buraco[0])
   {
      n = 1;
   }
   else if (temParede[0] <= wall_limiar) // Colocar o != no buraco dps
   {
      cout << "Coloquei6" << endl;
      ColocarParedesNoMapa(0);
   }

   if (temParede[1] >= wall_limiar && !no_buraco[1])
   {
      e = 1;
   }
   else if (temParede[1] <= wall_limiar)
   {
      cout << "Coloquei7" << endl;
      ColocarParedesNoMapa(1);
   }

   if (temParede[2] >= wall_limiar && !no_buraco[2])
   {
      s = 1;
   }
   else if (temParede[2] <= wall_limiar)
   {
      cout << "Coloquei8" << endl;
      ColocarParedesNoMapa(2);
   }
   if (temParede[3] >= wall_limiar && !no_buraco[3])
   {
      w = 1;
   }
   else if (temParede[3] <= wall_limiar)
   {
      cout << "Coloquei1" << endl;
      ColocarParedesNoMapa(3);
   }
   
   //codando agora os casos da diagonal
   if(temParede[4] >= wall_limiar_diagonal && temParede[4] < 1){
      ne = 1;
   }
   if(temParede[5] >= wall_limiar_diagonal && temParede[5] < 1){
      se = 1;
   }
   if(temParede[6] >= wall_limiar_diagonal && temParede[6] < 1){
      sw = 1;
   }
   if(temParede[7] >= wall_limiar_diagonal && temParede[7] < 1){
      nw = 1;
   }

   if (idcompass == 0)
   {
      n = n * 1;
      e = e * 2;
      s = s * 4;
      w = w * 8;
      ne = ne*16;
      se = se*32;
      sw = sw*64;
      nw = nw*128;
   }
   else if (idcompass == 1)
   {
      n = n * 2;
      e = e * 4;
      s = s * 8;
      w = w * 1;
      ne = ne*32;
      se = se*64;
      sw = sw*128;
      nw = nw*16;
   }
   else if (idcompass == 2)
   {
      n = n * 4;
      e = e * 8;
      s = s * 1;
      w = w * 2;
      ne = ne*64;
      se = se*128;
      sw = sw*16;
      nw = nw*32;
   }
   else if (idcompass == 3)
   {
      n = n * 8;
      e = e * 1;
      s = s * 2;
      w = w * 4;
      ne = ne*128;
      se = se*16;
      sw = sw*32;
      nw = nw*64;
   }

   ans = n + e + s + w + ne + se + sw + nw;

   // cout << "Norte: " << lidar->getRangeImage()[north] << endl;
   // cout << "Leste: " << lidar->getRangeImage()[east] << endl;
   // cout << "Sul: " << lidar->getRangeImage()[south] << endl;
   // cout << "Oeste: " << lidar->getRangeImage()[west] << endl;
   
   cout << ans << endl;
   return ans;
}

// Função auxiliar para limitar o valor dentro de um intervalo
void clamp(double &value, double min_val, double max_val)
{
   if (value > max_val)
      value = max_val;
   else if (value < min_val)
      value = min_val;
}

// Função para normalizar ângulos para o intervalo [-pi, pi], o IMU funciona nesse intervalo
double pi_interval(double angle)
{
   while (angle > pi)
      angle -= 2 * pi;
   while (angle < -pi)
      angle += 2 * pi;
   return angle;
}

void girarRelativo(double targetYaw)
{
   detectar_e_imprimir();
   // Normaliza targetYaw
   targetYaw = pi_interval(targetYaw);
   double initialYaw = Iunit->getRollPitchYaw()[2];
   targetYaw = pi_interval(targetYaw + initialYaw); // Ajusta o alvo com o ângulo inicial
   int victimcounter = 0;
   while (robot->step(timeStep) != -1)
   {
      double currentYaw = Iunit->getRollPitchYaw()[2]; // Obtém o ângulo atual do IMU
      double error = pi_interval(targetYaw - currentYaw);
      if (fabs(error) < 0.001)
         break; // tolerância ~0.57°
      double control = pid_giro.calcular(0, -error, dt);
      // Converte controle angular em velocidade das rodas (rotate in place)
      clamp(control, -max_speed, max_speed); // Limita a velocidade de controle
      wheel_left->setVelocity(control);
      wheel_right->setVelocity(-control);

      if (victimcounter % 2 == 0) {
         detectar_e_imprimir();
         wheel_left->setVelocity(control);
         wheel_right->setVelocity(-control);
         victimcounter = 0;
      }

      victimcounter++;
   }
   // Para o movimento
   wheel_left->setVelocity(0);
   wheel_right->setVelocity(0);
   // Reseta o PID após a rotação
   pid_giro.reset();
   robot->step(timeStep);
}

void girarAbsoluto(double targetYaw)
{
   // Normaliza targetYaw
   targetYaw = pi_interval(targetYaw);
   while (robot->step(timeStep) != -1)
   {
      double currentYaw = Iunit->getRollPitchYaw()[2]; // Obtém o ângulo atual do IMU
      double error = pi_interval(targetYaw - currentYaw);
      if (fabs(error) < 0.001)
         break; // tolerância ~0.57°
      double control = pid_giro.calcular(0, -error, dt);
      // Converte controle angular em velocidade das rodas (rotate in place)
      clamp(control, -max_speed, max_speed); // Limita a velocidade de controle
      wheel_left->setVelocity(control);
      wheel_right->setVelocity(-control);
   }
   // Para o movimento
   wheel_left->setVelocity(0);
   wheel_right->setVelocity(0);
   // Reseta o PID após a rotação
   pid_giro.reset();
   robot->step(timeStep);
}

// Alinha o robô com a frente do robô, usando o IMU
void Alinhar()
{
   double currentYaw = Iunit->getRollPitchYaw()[2]; // Obtém o ângulo atual do IMU
   if (currentYaw < pi / 4 && currentYaw > -pi / 4)
   {
      girarAbsoluto(0); // Alinha com o Norte
   }
   else if (currentYaw >= pi / 4 && currentYaw < 3 * pi / 4)
   {
      girarAbsoluto(pi / 2); // Alinha com o Leste
   }
   else if (currentYaw >= 3 * pi / 4 || currentYaw < -3 * pi / 4)
   {
      girarAbsoluto(pi); // Alinha com o Sul
   }
   else if (currentYaw <= -pi / 4 && currentYaw > -3 * pi / 4)
   {
      girarAbsoluto(-pi / 2); // Alinha com o Oeste
   }
   else
   {
      cout << "Oxe." << endl;
   }
}

void direcaoinicial()
{
   double currentYaw = Iunit->getRollPitchYaw()[2]; // Obtém o ângulo atual do IMU
   cout << "Yaw: " << currentYaw << endl;

   if (currentYaw < pi / 4 && currentYaw > -pi / 4)
   {
      idcompass = 0;
   }
   else if (currentYaw >= pi / 4 && currentYaw < 3 * pi / 4)
   {
      idcompass = 3;
   }
   else if (currentYaw >= 3 * pi / 4 || currentYaw < -3 * pi / 4)
   {
      idcompass = 2;
   }
   else if (currentYaw <= -pi / 4 && currentYaw > -3 * pi / 4)
   {
      idcompass = 1;
   }
   else
   {
      cout << "Oxe." << endl;
   }
}


// Vê se há buraco, óbvio
bool TemBuraco()
{
   const unsigned char *image = colorSensor->getImage();
   int width = colorSensor->getWidth();
   int r = colorSensor->imageGetRed(image, width, 0, 0);
   int g = colorSensor->imageGetGreen(image, width, 0, 0);
   int b = colorSensor->imageGetBlue(image, width, 0, 0);
   double distance = dsensor->getValue();
   double anglep = Iunit->getRollPitchYaw()[0];
   //cout << "R: " << r << "G: " << g << "B: " << b << endl;
   //cout << "dsensor: " << dsensor->getValue() << endl;
   //cout << "anglep: " << anglep << endl;
   
   return ((abs(r - HOLE_TARGET) < RGB_TOLERANCE &&
            abs(g - HOLE_TARGET) < RGB_TOLERANCE &&
            abs(b - HOLE_TARGET) < RGB_TOLERANCE) or 
         (abs(r - HOLE_TARGET2) < RGB_TOLERANCE &&
            abs(g - HOLE_TARGET2) < RGB_TOLERANCE &&
            abs(b - HOLE_TARGET2) < RGB_TOLERANCE) or 
            (distance > 0.25 && distance < 0.258 && anglep > -0.01));
}
// Vê se tem pantano
bool Pantano()
{
   const unsigned char *image = colorSensor->getImage();
   int r = colorSensor->imageGetRed(image, width, 0, 0);
   int g = colorSensor->imageGetGreen(image, width, 0, 0);
   int b = colorSensor->imageGetBlue(image, width, 0, 0);
   int Const = 5;
   if (r >= 204 - Const && r <= 204 + Const && g >= 170 - Const && g <= 170 + Const && b >= 97 - Const && b <= 97 + Const)
   {
      return true;
   }
   return false;
}
// Vê se tem checkpoint
bool Checkpoint()
{
   const unsigned char *image = colorSensor->getImage();
   int r = colorSensor->imageGetRed(image, width, 0, 0);
   int g = colorSensor->imageGetGreen(image, width, 0, 0);
   int b = colorSensor->imageGetBlue(image, width, 0, 0);
   int Const = 5;
   if (r >= 247 - Const && r <= 247 + Const && g >= 247 - Const && g <= 247 + Const && b >= 247 - Const && b <= 247 + Const)
   {
      return true;
   }
   return false;
}
// Percorre o ladrilho e evita buraco
void percorrerLadrilho(double targetDistance, bool doAlign = true, int diagdirectional = -1)
{
   double time = tempo();
   cout << "Tempo decorrido: " << time << endl;
   if(time <= 6){
      enviarMapa();
   }
   cout << "Sala: " << SalvaSala << endl; 
   detectar_e_imprimir();   
   // 1) se for chamada para voltar (targetDistance < 0), apenas executa o retorno:
   if (targetDistance < 0.0)
   {
      int dir = -1;
      double limiarTheta = fabs(targetDistance / raioRoda);
      double thetaIniE = leftEncoders->getValue();
      double thetaIniD = rightEncoders->getValue();
      wheel_left->setVelocity(dir * max_speed);
      wheel_right->setVelocity(dir * max_speed);
      while (robot->step(timeStep) != -1)
      {
         double deltaE = fabs(leftEncoders->getValue() - thetaIniE);
         double deltaD = fabs(rightEncoders->getValue() - thetaIniD);
         if ((deltaE + deltaD) / 2.0 >= limiarTheta) break;
      }
      wheel_left->setVelocity(0);
      wheel_right->setVelocity(0);
      if (doAlign) Alinhar();
      return;
   }

   int victimcounter = 0;

   // 2) leitura inicial dos encoders
   double thetaIniE = leftEncoders->getValue();
   double thetaIniD = rightEncoders->getValue();
   double limiarTheta = fabs(targetDistance / raioRoda);

   //adaptar esse codigo aqui pro encoder
   
   // 3) anda pra frente até completar o tile ou encontrar buraco
   wheel_left->setVelocity(max_speed);
   wheel_right->setVelocity(max_speed);

   if(posx%2 == 0 && posy%2 == 0)
   {
      MudeiDeSala = true;
   }
   SalaAtual();
   if(SalvaSala == 4 && MudeiDeSala)
   {
      Area4.push_back({posy, posx});
   }
   int TrueX = posy;
   int TrueY = posx;
   if(SalvaExtremos[0].first > TrueX)
   {
      SalvaExtremos[0].first = TrueX;
   }
   if(SalvaExtremos[0].second > TrueY)
   {
      SalvaExtremos[0].second = TrueY;
   }
   if(SalvaExtremos[1].first < TrueX)
   {
      SalvaExtremos[1].first = TrueX;
   }
   if(SalvaExtremos[1].second < TrueY)
   {
      SalvaExtremos[1].second = TrueY;
   }   
   if(Checkpoint())
   {
      cout << "Checkpointt" << endl;
      if(posx%2 == 0 && posy%2 == 0)
      {
         // cout << "Printa isso: " << posx << " " << posy << endl;
         int TrueX = posy;
         int TrueY = posx;

         Mapeamento[(2*TrueY)-1][(2*TrueX)+1] = "4";
         Mapeamento[(2*TrueY)+1][(2*TrueX)-1] = "4";
         Mapeamento[(2*TrueY)+1][(2*TrueX)+1] = "4";
         Mapeamento[(2*TrueY)-1][(2*TrueX)-1] = "4";
      }
   }
   if(Pantano())
   {
      cout << "To no pantano" << endl;
      if(posx%2 == 0 && posy%2 == 0)
      {
         swampmaze[posx][posy] = 1;
         swampmaze[posx-1][posy] = 1;
         swampmaze[posx+1][posy] = 1;
         swampmaze[posx][posy-1] = 1;
         swampmaze[posx][posy+1] = 1;
         // cout << "Printa isso: " << posx << " " << posy << endl;
         int TrueX = posy;
         int TrueY = posx;
         Mapeamento[(2*TrueY)-1][(2*TrueX)+1] = "3";
         Mapeamento[(2*TrueY)+1][(2*TrueX)-1] = "3";
         Mapeamento[(2*TrueY)+1][(2*TrueX)+1] = "3";
         Mapeamento[(2*TrueY)-1][(2*TrueX)-1] = "3";
      }
   }
   while (robot->step(timeStep) != -1)
   {
      // cout << "TESTEEE" << endl;
      double deltaE = fabs(leftEncoders->getValue() - thetaIniE);
      double deltaD = fabs(rightEncoders->getValue() - thetaIniD);
      double deltaM = (deltaE + deltaD) / 2.0;
      // 3.1) encontrou buraco
      if ((TemBuraco()) and !returning)
      {
         wheel_left->setVelocity(0);
         wheel_right->setVelocity(0);
         if(posx%2 == 0 && posy%2 == 0)
         {
         //    cout << "East lidar: " << lidar->getRangeImage()[east] << endl;
         //    cout << "West lidar: " << lidar->getRangeImage()[west] << endl;
            if(lidar->getRangeImage()[north] < 0.166)
            {
               posx+=2*dx[idcompass];
               posy+=2*dy[idcompass];
               IgnoraOsTermos = true;
               ColocarParedesNoMapa(0);
               IgnoraOsTermos = false;
               posx-=2*dx[idcompass];
               posy-=2*dy[idcompass];

            }
         //    if(lidar->getRangeImage()[east] < 0.061)
         //    {
         //       cout << "Colocando parede leste: " << endl;
         //       ColocarParedesNoMapa(1);
         //    }
         //    if(lidar->getRangeImage()[west] < 0.061)
         //    {
         //       cout << "Colocando parede oeste" << endl;
         //       ColocarParedesNoMapa(3);
         //    }
            posx+=2*dx[idcompass];
            posy+=2*dy[idcompass];
            int TrueX = posy;
            int TrueY = posx;
            posx-=2*dx[idcompass];
            posy-=2*dy[idcompass];
            if(SalvaSala == 4)
            {
               Area4.push_back({TrueX, TrueY});
               TrueX  -= dy[idcompass];
               TrueY  -= dx[idcompass];
               Area4.push_back({TrueX, TrueY});
            }
            Mapeamento[(2*TrueY)-1][(2*TrueX)+1] = "2";
            Mapeamento[(2*TrueY)+1][(2*TrueX)-1] = "2";
            Mapeamento[(2*TrueY)+1][(2*TrueX)+1] = "2";
            Mapeamento[(2*TrueY)-1][(2*TrueX)-1] = "2";
         }
         // calcula dist_voltar
         dist_voltar = deltaM * raioRoda;
         cout << "[BURACO] dist_voltar = " << dist_voltar << " " << endl;
         cout << "[BURACO] Voltando para o ladrilho (" << posx << ", " << posy << ")" << endl;
         // marca o ladrilho como bloqueado
         int fx = posx + dx[idcompass];
         int fy = posy + dy[idcompass];
         if(doAlign) blocked[fx][fy] = 1;
         if ((fy%2 == 0 or fx%2 == 0) and doAlign)
         {
            cout << "meu idcompass: " << idcompass << endl;
            if(idcompass == 0){
               for(int i = -2; i <= 0; i++){
                  for(int j = -1; j <= 1; j++){
                     blocked[fx+i][fy+j] = 1;
                     maze[fx+i][fy+j] = -1;
                  }
               }
            } else if(idcompass == 3){
               for(int i = -1; i <= 1; i++){
                  for(int j = -2; j <= 0; j++){
                     blocked[fx+i][fy+j] = 1;
                     maze[fx+i][fy+j] = -1;
                  }
               }
            } else if(idcompass == 2){
               for(int i = 0; i <= 2; i++){
                  for(int j = -1; j <= 1; j++){
                     blocked[fx+i][fy+j] = 1;
                     maze[fx+i][fy+j] = -1;
                  }
               }
            } else if(idcompass == 1){
               for(int i = -1; i <= 1; i++){
                  for(int j = 0; j <= 2; j++){
                     blocked[fx+i][fy+j] = 1;
                     maze[fx+i][fy+j] = -1;
                  }
               }
            }
         }
         // já chama o retorno, sem alinhamento interno
         percorrerLadrilho(-dist_voltar, true);
         dist_voltar = 0; // Reseta dist_voltar após o retorno
         newx = posx;     // Reseta as coordenadas do próximo ladrilho
         newy = posy;     // Reseta as coordenadas do próximo ladrilho
         return;
      }
      //diferença entre inicial e final
      
      
      // 3.2) Vitima

      if (victimcounter % 6 == 0) {
         detectar_e_imprimir();
         wheel_left->setVelocity(max_speed);
         wheel_right->setVelocity(max_speed);
         victimcounter = 0;
      }

      victimcounter++;

      //coisa do isaac
      if((limiarTheta-deltaM)/limiarTheta < 0.2)
      {
         wheel_left->setVelocity(0.5*max_speed);
         wheel_right->setVelocity(0.5*max_speed);
      }

      //Se A cor tiver diferente checa:
      if (deltaM >= limiarTheta)
      {
         wheel_left->setVelocity(0);
         wheel_right->setVelocity(0);
         break;
      }
      
   }

   robot->step(timeStep);
   double encodere = fabs(leftEncoders->getValue() - thetaIniE);
   double encoderd = fabs(rightEncoders->getValue() - thetaIniD);
   double mediaencoders = (encodere + encoderd) / 2.0;
   
   cout << "diferenca E: " << encodere*raioRoda << " diferenca D: " << encoderd*raioRoda << " media: " << mediaencoders*raioRoda << endl;
   if(diagdirectional == -1){
      if(idcompass == 1){
         errorj += fabs(0.06 - mediaencoders*raioRoda);
      } else if(idcompass == 3){
         errorj -= fabs(targetDistance - mediaencoders*raioRoda);
      } else if(idcompass == 0){
         errori += fabs(targetDistance - mediaencoders*raioRoda);
      } else if(idcompass == 2){
         errori -= fabs(targetDistance - mediaencoders*raioRoda);
      }
   } else{
      if(diagdirectional == 0){
         errori += fabs(targetDistance - mediaencoders*raioRoda)*sqrt(2)/2;
         errorj += fabs(targetDistance - mediaencoders*raioRoda)*sqrt(2)/2;
      } else if(diagdirectional == 1){
         errori -= fabs(targetDistance - mediaencoders*raioRoda)*sqrt(2)/2;
         errorj += fabs(targetDistance - mediaencoders*raioRoda)*sqrt(2)/2;
      } else if(diagdirectional == 2){
         errori -= fabs(targetDistance - mediaencoders*raioRoda)*sqrt(2)/2;
         errorj -= fabs(targetDistance - mediaencoders*raioRoda)*sqrt(2)/2;
      } else if(diagdirectional == 3){
         errori += fabs(targetDistance - mediaencoders*raioRoda)*sqrt(2)/2;
         errorj -= fabs(targetDistance - mediaencoders*raioRoda)*sqrt(2)/2;
      }
   }
   
   cout << "Erro i: " << errori << " Erro j: " << errorj << endl;

   // 4) só alinha no avanço bem‑sucedido
   if (doAlign) Alinhar();
   delay(100);
}

void moveCompass(int windrose)
{
   if (windrose == idcompass)
   {
      return;
   }

   int8_t rig = idcompass, left = idcompass, stepsR = 0, stepsL = 0;

   while (rig != windrose)
   {
      if (rig == 3)
      {
         rig = 0;
      }
      else
      {
         rig++;
      }
      stepsR++;
   }

   while (left != windrose)
   {
      if (left == 0)
      {
         left = 3;
      }
      else
      {
         left--;
      }
      stepsL++;
   }

   // reminder = 1500
   if (stepsL == 1)
   {
      cout << "Girar 90 graus" << endl;
      girarRelativo(pi / 2);
   }
   else if (stepsR == 1)
   {
      cout << "Girar -90 graus" << endl;
      girarRelativo(-pi / 2);
   }
   else if (stepsR == 2 || stepsL == 2)
   {
      cout << "Girar 180 graus" << endl;
      girarRelativo(pi/2);
      delay(100);
      girarRelativo(pi/2);
   }
   idcompass = windrose; // Atualiza a direção do compasso
}

void moveWallGrid(int8_t xi, int8_t yi, int8_t xf, int8_t yf)
{
   //0.05846 é a distância de um ladrilho
   double dis = 0.06; // Distância de um ladrilho
   if (xi - 1 == xf && yi == yf)
   {
      cout << "Moving coordinates to NORTH" << endl;
      moveCompass(0);
      percorrerLadrilho(dis);
      wallgrid[xf][yf] |= 4; // Se eu vim do sul, então não há parede no sul.
   }

   if (xi + 1 == xf && yi == yf)
   {
      cout << "Moving coordinates to SOUTH" << endl;
      moveCompass(2);
      percorrerLadrilho(dis);
      wallgrid[xf][yf] |= 1; // Se eu vim do norte, então não há parede no norte.
   }

   if (xi == xf && yi + 1 == yf)
   {
      cout << "Moving coordinates to EAST" << endl;
      moveCompass(1);
      percorrerLadrilho(dis);
      wallgrid[xf][yf] |= 8; // Se eu vim do oeste, então não há parede no oeste.
   }

   if (xi == xf && yi - 1 == yf)
   {
      cout << "Moving coordinates to WEST" << endl;
      moveCompass(3);
      percorrerLadrilho(dis);
      wallgrid[xf][yf] |= 2; // Se eu vim do leste, então não há parede no leste.
   }

   //fix this -errori-errorj thingy(it sucks)
   if(xi-1 == xf && yi + 1 == yf){
      cout << "VAMOS AO NORDESTE" << endl;
      girarAbsoluto(7*pi/4);
      percorrerLadrilho((dis)*sqrt(2),false,0);
      wallgrid[xf][yf] |= 64;
      girarAbsoluto(0);
      Alinhar();
      idcompass = 0;
   }

   if(xi + 1 == xf && yi + 1 == yf){
      cout << "VAMOS AO SUDESTE" << endl;
      girarAbsoluto(5*pi/4);
      percorrerLadrilho(dis*sqrt(2),false,1);
      wallgrid[xf][yf] |= 128;
      girarAbsoluto(3*pi/2);
      Alinhar();
      idcompass = 1;
   }

   if(xi + 1 == xf && yi - 1 == yf){
      cout << "VAMOS AO SUDOESTE" << endl;
      girarAbsoluto(3*pi/4);
      percorrerLadrilho((dis)*sqrt(2),false,2);
      wallgrid[xf][yf] |= 16;
      girarAbsoluto(pi);
      Alinhar();
      idcompass = 2;
   }

   if(xi - 1 == xf && yi - 1 == yf){
      cout << "VAMOS AO NOROESTE" << endl;
      girarAbsoluto(pi/4);
      percorrerLadrilho((dis)*sqrt(2),false,3);
      wallgrid[xf][yf] |= 32;
      girarAbsoluto(pi/2);
      Alinhar();
      idcompass = 3;
   }
}

void bfs(int startx, int starty);

void dfs(int x, int y)
{
   
   double currentYaw = Iunit->getRollPitchYaw()[2]; // Obtém o ângulo atual do IMU
   cout << "Yaw DFS: " << currentYaw << endl;
   if(!naoda)
   {
      direcaoinicial();
      naoda = true;
   }
   if (finished)
   {
      return;
   }
   int caseMaze = checkwall();

   if (maze[x][y] < 0)
   {
      wallgrid[x][y] |= caseMaze; // Atualiza a matriz de paredes
      maze[x][y] = caseMaze;
   }

   cout << "DFS: " << x << " " << y << " " << caseMaze << endl;

   for (int i = 0; i < 8; i++)
   {
      int newx = x + dx[i];
      int newy = y + dy[i];
      int power = (1 << i);
      int inverse = 0;
      if (i == 0)
      {
         inverse = (1 << 2);
      }
      else if (i == 1)
      {
         inverse = (1 << 3);
      }
      else if (i == 2)
      {
         inverse = (1 << 0);
      }
      else if (i == 3)
      {
         inverse = (1 << 1);
      }
      else if (i == 4)
      {
         inverse = (1 << 6);
      } 
      else if (i == 5)
      {
         inverse = (1 << 7);
      }
      else if (i == 6)
      {
         inverse = (1 << 4);
      }
      else if (i == 7)
      {
         inverse = (1 << 5);
      }


      // Verificação de limite antes de acessar maze[newx][newy]
      if (newx < 0 || newx >= sizeMaze || newy < 0 || newy >= sizeMaze)
         continue;

      if ((maze[newx][newy] >= 0 && (maze[x][y] & power)) or (blocked[newx][newy] && (maze[x][y] & power)))
      {
         maze[x][y] -= power;
      }
      if (maze[newx][newy] >= 0 && (maze[newx][newy] & inverse))
      {
         maze[newx][newy] -= inverse;
      }
   }

   cout << "Maze atual: " << maze[x][y] << endl;

   for (int i = 0; i < 8; i++)
   {
      newx = x + dx[i];
      newy = y + dy[i];
      int power = (1 << i);

      // Verificação de limite antes de usar maze[newx][newy]
      if (newx < 0 || newx >= sizeMaze || newy < 0 || newy >= sizeMaze) continue;

      cout << "Tentando ir para: " << newx << " " << newy << endl;
      cout << "Condicoes: " << (maze[x][y] & power) << " " << (maze[newx][newy] < 0) << " " << (blocked[newx][newy] == 0) << endl;
      if ((maze[x][y] & power) && maze[newx][newy] < 0 && blocked[newx][newy] == 0)
      {
         cout << "Now Moving to: " << newx << " " << newy << endl;
         moveWallGrid(x, y, newx, newy); // Move o robô para a nova célula
         lastX = posx;                   // Atualiza o último ladrilho visitado
         lastY = posy;                   // Atualiza o último ladrilho visitado
         posx = newx;
         posy = newy;
         maze[x][y] -= power;
         dfs(newx, newy);
         return;
      }
   }

   if (maze[x][y] != 0)
   {
      cout << "Fudeu!" << endl;
   }
   bfs(x, y);
}

void returnToLastNode(int x, int y)
{
   returning = true;
   cout << "Retornando para o ponto " << x << " " << y << endl;
   cout << "Maze para o ponto: " << maze[x][y] << endl;
   deque<pii> dq;
   dq.push_front({x, y});
   while (parent[x][y] != make_pair(-1, -1))
   {
      cout << "Inserindo pais do ponto " << x << " " << y << " Na deque" << endl;
      // if(x == 89 and y == 87){
      //    cout << "Amigo estou aqui" << endl;
      //    cout << "Meu pai é " << parent[x][y].first << " " << parent[x][y].second << endl;
      // }
      dq.push_front(parent[x][y]);
      int oldx = x;
      int oldy = y;
      x = parent[oldx][oldy].first;
      y = parent[oldx][oldy].second;
   }

   dq.pop_front(); // Remove o ponto inicial (startX, startY)

   while (!dq.empty())
   {
      pii current = dq.front();
      dq.pop_front();
      int nx = current.first;
      int ny = current.second;
      cout << "Movendo para o ponto" << nx << " " << ny << endl;
      cout << "Walgrid para o novo ponto: " << wallgrid[nx][ny] << endl;
      // Move o robô para a célula atual
      moveWallGrid(posx, posy, nx, ny);
      posx = nx;
      posy = ny;
   }

   for (int i = 0; i < sizeMaze; i++)
   {
      for (int j = 0; j < sizeMaze; j++)
      {
         visited[i][j] = 0;
         parent[i][j] = {-1, -1}; // Reseta o pai para -1
      }
   }

   returning = false;
   dfs(posx, posy);
}

double cost(int i){
   if(i < 4){
      return 1.0;
   } else {
      return 5.0; // sqrt(2) para diagonais
   }
}

void bfs(int startx, int starty) // void dijkstra
{
   // node = tuple<double, int, int> (distancia, x, y)   
   cout << "Iniciando BFS" << endl; // Inicializa Dijkstra

   for(int i=0; i < sizeMaze; i++){
      for(int j=0; j < sizeMaze; j++){
         parent[i][j] = {-1, -1}; // Reseta o pai para -1
      }
   }

   vector<vector<double>> dist(sizeMaze, vector<double>(sizeMaze, INF));

   dist[startx][starty] = 0;

   priority_queue<node, vector<node>, greater<node>> pq;
   pq.push({0,startx, starty});

   while (!pq.empty())
   {
      cout << "tamanho da fila: " << pq.size() << endl;
      auto current = pq.top();
      pq.pop();
      double d = std::get<0>(current);
      int x = std::get<1>(current);
      int y = std::get<2>(current);

      if(d > dist[x][y]) continue;

      if (maze[x][y] > 0 && blocked[x][y] == 0)
      {
         returnToLastNode(x, y);
         return;
      }

      cout << "Wallgrid do ponto atual: " << wallgrid[x][y] << endl;
      // Explora os vizinhos
      for (int i = 0; i < 8; i++)
      {
         int nx = x + dx[i];
         int ny = y + dy[i];

         // Verifica limites
         if (nx < 0 || nx >= sizeMaze || ny < 0 || ny >= sizeMaze) continue;
         
         cout << "condicoes para inserir bfs: " << !blocked[nx][ny] << " " << (wallgrid[x][y] & (1 << i)) << endl;
         // Verifica se já foi visitado ou se há buraco
         if (!blocked[nx][ny] && (wallgrid[x][y] & (1 << i)))
         {
            double custo = cost(i); // Calcula o custo de movimento para essa direção
            double newDist = d + custo;

            if(newDist < dist[nx][ny]){
               dist[nx][ny] = newDist;
               cout << "Inserindo: " << nx << " " << ny << endl;
               cout << "Para isso, eu parti de " << x << " " << y << endl;
               parent[nx][ny] = {x, y}; // Armazena o último ladrilho visitado
               pq.push({newDist, nx, ny});
            }
         }
      }
   }
   cout << "Retornando ao inicio" << endl;
   finished = true;
   returnToLastNode(90, 90);
   ColocarAstA4();
   enviarMapa();
   //FimDeJogo(); // Se não encontrar, volta ao início
}

void rotina()
{
   if (!finished) dfs(posx, posy);
}

int main(int argc, char **argv)
{
   srand(time(NULL));
   cout << "[main global] Iniciando o Detector LarcVision..." << endl;
   pDetector = make_unique<LarcVision>(obj_path, type_path);
   cout << "[main global] Deu certo ;)." << endl;

   // Configura os motores para não pararem
   wheel_left->setPosition(INFINITY);
   wheel_right->setPosition(INFINITY);

   colorSensor->enable(timeStep);
   came->enable(timeStep);
   camd->enable(timeStep);

   lidar->enable(timeStep);
   lidar->enablePointCloud();

   Iunit->enable(timeStep);
   gps->enable(timeStep);

   dsensor->enable(timeStep);

   robot->step(timeStep);

   // AGORA, capture a posição inicial do GPS
   gpsX0 = gps->getValues()[0];
   gpsY0 = gps->getValues()[2];

   cout << "Ponto inicial do GPS capturado: X0 =" << gpsX0 << ", Y0 =" << gpsY0 << endl;

   leftEncoders->enable(timeStep);
   rightEncoders->enable(timeStep);

   receiver->enable(timeStep);

   initMaze(); // Inicializa o labirinto

   Mapeamento[(2 * posx) - 1][(2 * posy) + 1] = '5';
   Mapeamento[(2 * posx) + 1][(2 * posy) - 1] = '5';
   Mapeamento[(2 * posx) + 1][(2 * posy) + 1] = '5';
   Mapeamento[(2 * posx) - 1][(2 * posy) - 1] = '5';
   SalvaExtremos[0] = {90,90};
   SalvaExtremos[1] = {90,90};
   SalvaAsteriscos[0] = {INF,INF};
   SalvaAsteriscos[1] = {-1,-1};

   //direcaoinicial();
   tempo();
   cout << "informacao util para debugar: " << pc << endl;
   while (robot->step(timeStep) != -1 and !finished)
   {
      rotina();
   }

   //  Para o robô
   wheel_left->setVelocity(0.0);
   wheel_right->setVelocity(0.0);

   delete robot;
   return 0;
}