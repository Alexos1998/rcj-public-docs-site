# -*- coding: utf-8 -*-
import sys
sys.stdout.reconfigure(encoding='utf-8')

from controller import Robot, Keyboard
import numpy as np
import cv2
# Inicializaçã

robot = Robot()
timestep = int(robot.getBasicTimeStep())

kb = robot.getKeyboard()
kb.enable(timestep)

leftMotor = robot.getDevice('wheel1 motor')
rightMotor = robot.getDevice('wheel2 motor')

leftMotor.setPosition(float('inf'))
rightMotor.setPosition(float('inf'))

leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)

MAX_SPEED = 6.27

camera = robot.getDevice('camera1')
camera.enable(timestep)

orig_width = camera.getWidth()
orig_height = camera.getHeight()

# Redimensiona a imagem de 64x64 pra (64*x)*(54*x)
SCALE = 4

BG_COLOR = np.array([50, 120, 130])  # BGR, cor da parede, filtrar
THRESH = 30  # tolerância

# Limita o processamento pro pc não explodir
step_counter = 0
PROCESS_EVERY = 10

# Salva as imagens de exibição quando não detecta disco
last_img_bgr = None
last_polar = None
last_graph = None

last_height = 1
last_polar_w = 360
# Janela de control

def nothing(x):
    pass

cv2.namedWindow("Controle", cv2.WINDOW_NORMAL)
cv2.resizeWindow("Controle", 420, 260)

cv2.createTrackbar("dp x10", "Controle", 15, 40, nothing)
cv2.createTrackbar("minDist", "Controle", 60, 300, nothing)
cv2.createTrackbar("param1", "Controle", 85, 300, nothing)
cv2.createTrackbar("param2", "Controle", 40, 200, nothing)
cv2.createTrackbar("minRadius", "Controle", 40, 300, nothing)
cv2.createTrackbar("maxRadius", "Controle", 145, 500, nothing)
# Classificação de cor (HSV) / Classificaçã

def classify_color(bgr):
    pixel = np.uint8([[bgr]])
    hsv = cv2.cvtColor(pixel, cv2.COLOR_BGR2HSV)[0][0]
    h, s, v = hsv

    # Preto
    if v < 50:
        return "preto"

    # Vermelho
    if h < 10 or h > 170:
        return "vermelho"

    # Amarelo
    if 20 < h < 35:
        return "amarelo"

    # Verde
    if 40 < h < 80:
        return "verde"

    # Azul
    if 90 < h < 130:
        return "azul"

    return "desconhecido"


def most_common(values):
    if not values:
        return "desconhecido"
    uniq, counts = np.unique(np.array(values, dtype=object), return_counts=True)
    return uniq[np.argmax(counts)]


print("Controle:")
print("Setas = mover robô")
print("Trackbars = ajustar detecção de círculos")
# Loop principa
while robot.step(timestep) != -1:

    # CONTROLE DO ROBÔ
    step_counter += 1
    leftSpeed = 0
    rightSpeed = 0

    key = kb.getKey()
    while key != -1:
        if key == Keyboard.UP:
            leftSpeed = MAX_SPEED
            rightSpeed = MAX_SPEED

        elif key == Keyboard.DOWN:
            leftSpeed = -MAX_SPEED
            rightSpeed = -MAX_SPEED

        elif key == Keyboard.LEFT:
            leftSpeed = MAX_SPEED / 2
            rightSpeed = -MAX_SPEED / 2

        elif key == Keyboard.RIGHT:
            leftSpeed = -MAX_SPEED / 2
            rightSpeed = MAX_SPEED / 2

        key = kb.getKey()

    leftMotor.setVelocity(leftSpeed)
    rightMotor.setVelocity(rightSpeed)

    if step_counter % PROCESS_EVERY == 0:
        # LER TRACKBARS
        dp = max(cv2.getTrackbarPos("dp x10", "Controle"), 1) / 10.0
        minDist = max(cv2.getTrackbarPos("minDist", "Controle"), 1)
        param1 = max(cv2.getTrackbarPos("param1", "Controle"), 1)
        param2 = max(cv2.getTrackbarPos("param2", "Controle"), 1)
        minRadius = max(cv2.getTrackbarPos("minRadius", "Controle"), 0)
        maxRadius = max(cv2.getTrackbarPos("maxRadius", "Controle"), minRadius + 1)


        # PROCESSAMENTO DA CÂMERA
        image = camera.getImage()
        img = np.frombuffer(image, np.uint8).reshape((orig_height, orig_width, 4))
        img_bgr = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)

        # Upscale para melhorar amostragem
        img_bgr = cv2.resize(
            img_bgr,
            (orig_width * SCALE, orig_height * SCALE),
            interpolation=cv2.INTER_NEAREST
        )

        height, width = img_bgr.shape[:2]

        gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (9, 9), 2)


        # DETECÇÃO DE CÍRCULOS
        # Modificação lembrae: 3 pontos não colineares definem uma circunferência, 
        # no futuro utilizar algum filtro usando a parede para pegar o contorno do disco e completar ele mesmo que ele esteja incompleto
        # ou usar IA
        circles = cv2.HoughCircles(
            gray,
            cv2.HOUGH_GRADIENT,
            dp=dp,
            minDist=minDist,
            param1=param1,
            param2=param2,
            minRadius=minRadius,
            maxRadius=maxRadius
        )


        # CANVAS
        cart_size = 300
        cart_img = np.zeros((cart_size, cart_size, 3), dtype=np.uint8)
        graph = np.zeros((300, 200, 3), dtype=np.uint8)

        # centro cartesiano
        cx_cart = cart_size // 2
        cy_cart = cart_size // 2

        # eixos
        cv2.line(cart_img, (0, cy_cart), (cart_size, cy_cart), (100, 100, 100), 1)
        cv2.line(cart_img, (cx_cart, 0), (cx_cart, cart_size), (100, 100, 100), 1)

        # saída polar padrão caso não encontre círculo
        polar_w = 360
        polar_h = 1
        polar_img = np.zeros((polar_h, polar_w, 3), dtype=np.uint8)
        polar_overlay = polar_img.copy()

        faixas = [[] for _ in range(5)]


        # SE EXISTIR CÍRCULO

        if circles is not None:
            circles = np.around(circles[0]).astype(np.int32)

            # escolher o maior raio para evitar pegar círculo interno (não tá funcionando tão bem assim lembrar)
            cx, cy, r = max(circles, key=lambda c: c[2])

            cx = int(float(cx))
            cy = int(float(cy))
            r  = int(float(r))

            # desenhar na câmera contorno e centro
            img_clean = img_bgr.copy()
            cv2.circle(img_bgr, (cx, cy), r, (0, 255, 0), 2)
            cv2.circle(img_bgr, (cx, cy), 3, (0, 0, 255), -1)

            # texto de debug na imagem
            y0 = 20
            debug_lines = [
                f"cx={cx} cy={cy} r={r}",
                f"dp={dp:.1f} minDist={minDist}",
                f"p1={param1} p2={param2}",
                f"minR={minRadius} maxR={maxRadius}",
                f"num_circulos={len(circles)}"
            ]
            for i, txt in enumerate(debug_lines):
                cv2.putText(
                    img_bgr,
                    txt,
                    (10, y0 + i * 20),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 255, 255),
                    1,
                    cv2.LINE_AA
                )

    
            # UNWRAP POLAR (DISCO -> RETÂNGULO)
            polar_w = 360
            polar_h = int(r)
            if polar_h < 1:
                polar_h = 1

    
            # CRIAR MÁSCARA CIRCULAR (NO ESPAÇO ORIGINAL)
            mask_cart = np.zeros((height, width), dtype=np.uint8)
            cv2.circle(mask_cart, (cx, cy), r, 255, -1)

    
            # WARP POLAR DA IMAGEM
            polar_img = cv2.warpPolar(
                img_clean,
                (polar_w, polar_h),
                (cx, cy),
                r,
                cv2.WARP_POLAR_LINEAR
            )

    
            # WARP POLAR DA MÁSCARA
            polar_mask = cv2.warpPolar(
                mask_cart,
                (polar_w, polar_h),
                (cx, cy),
                r,
                cv2.WARP_POLAR_LINEAR
            )

            # converter pra booleano
            polar_mask = polar_mask > 0

    
            # LIMPAR PIXELS INVÁLIDOS
            polar_img[~polar_mask] = 0

            # suavização leve
            polar_img = cv2.GaussianBlur(polar_img, (3, 3), 0)

            polar_overlay = polar_img.copy()

            invalid = ~polar_mask
            overlay_color = np.array([0, 0, 255], dtype=np.uint8)
            alpha = 0.5

            polar_overlay[invalid] = (
                alpha * overlay_color + (1 - alpha) * polar_overlay[invalid]
            ).astype(np.uint8)

            h, w = polar_img.shape[:2]

            num_faixas = 5
            faixa_w = w // num_faixas

            for i in range(1, num_faixas):
                x = i * faixa_w
                cv2.line(polar_overlay, (x, 0), (x, h), (255, 255, 255), 1)

    
            # CLASSIFICAÇÃO DAS FAIXAS
            faixa_largura = polar_w // 5

            for i in range(5):
                inicio = i * faixa_largura
                fim = (i + 1) * faixa_largura if i < 4 else polar_w

                faixa_pixels = polar_img[:, inicio:fim]
                faixa_mask = polar_mask[:, inicio:fim]

                pixels = faixa_pixels[faixa_mask]

                cores = [classify_color(p) for p in pixels]
                cores = [c for c in cores if c != "desconhecido"]

                if cores:
                    cor_pred = most_common(cores)
                    faixas[i] = [cor_pred]


        # GERAR GRÁFICO

        cores_map = {
            "vermelho": (0, 0, 255),
            "verde": (0, 255, 0),
            "azul": (255, 0, 0),
            "amarelo": (0, 255, 255),
            "preto": (50, 50, 50),
            "desconhecido": (255, 255, 255)
        }

        for i, faixa in enumerate(faixas):
            y1 = i * 60
            y2 = (i + 1) * 60
            if faixa:
                cor_pred = faixa[0]
                cor = cores_map.get(cor_pred, (255, 255, 255))

                cv2.rectangle(graph, (0, y1), (200, y2), cor, -1)
                cv2.putText(
                    graph,
                    f"{i}: {cor_pred}",
                    (10, y1 + 40),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 0, 0),
                    1
                )
            else:
                cv2.rectangle(graph, (0, y1), (200, y2), (30, 30, 30), -1)
                cv2.putText(
                    graph,
                    f"{i}: vazio",
                    (10, y1 + 40),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (255, 255, 255),
                    1
                )


        # DESENHAR MAPA CARTESIANO DO CÍRCULO
        if circles is not None:
            scale_cart = cart_size / (2 * r)

            for theta in range(0, 360, 2):
                rad = np.deg2rad(theta)
                x_cart = int(cx_cart + r * np.cos(rad) * scale_cart)
                y_cart = int(cy_cart - r * np.sin(rad) * scale_cart)

                if 0 <= x_cart < cart_size and 0 <= y_cart < cart_size:
                    cv2.circle(cart_img, (x_cart, y_cart), 1, (255, 0, 255), -1)


        # COMBINAR VIZUALIZAÇOES
        polar_vis = cv2.resize(polar_overlay, (360, height), interpolation=cv2.INTER_NEAREST)
        graph_resized = cv2.resize(graph, (200, height), interpolation=cv2.INTER_NEAREST)

        combined = np.hstack((img_bgr, polar_vis, graph_resized))

        last_img_bgr = img_bgr.copy()
        last_polar = polar_overlay.copy()
        last_graph = graph.copy()

        last_height = height
        last_polar_w = polar_w

    if last_img_bgr is not None:
        polar_vis = cv2.resize(last_polar, (last_polar_w, last_height))
        graph_resized = cv2.resize(last_graph, (200, last_height), interpolation=cv2.INTER_NEAREST)
        combined = np.hstack((last_img_bgr, polar_vis, graph_resized))
        cv2.imshow("Visao Completa", combined)

    cv2.imshow("Controle", np.zeros((260, 420, 3), dtype=np.uint8))
    cv2.waitKey(1)