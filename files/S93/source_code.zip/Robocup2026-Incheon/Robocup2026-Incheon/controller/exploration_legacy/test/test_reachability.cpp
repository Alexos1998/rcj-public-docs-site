#include "exploration_legacy/reachability.hpp"

#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

namespace {

int g_failures = 0;

#define CHECK(cond) \
  do { \
    if (!(cond)) { \
      ++g_failures; \
      std::printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); \
    } \
  } while (0)

using exploration_legacy::CostmapSnapshot;
using exploration_legacy::LegacyReachabilityChecker;
using exploration_legacy::MapPoint;
using exploration_legacy::PathCandidate;
using exploration_legacy::PathSegment;
using exploration_legacy::ReachabilityResult;
using exploration_legacy::ReachabilityStatus;

LegacyReachabilityChecker::Config config()
{
  LegacyReachabilityChecker::Config cfg;
  cfg.alignment_tolerance_m = 1.0e-6;
  cfg.min_segment_length_m = 1.0e-6;
  cfg.allow_unknown = false;
  cfg.lethal_threshold = 90;
  cfg.max_costmap_age_s = 10.0;
  return cfg;
}

CostmapSnapshot makeCostmap(int width, int height, double resolution = 1.0)
{
  CostmapSnapshot map;
  map.valid = true;
  map.frame_id = "map";
  map.width = static_cast<std::uint32_t>(width);
  map.height = static_cast<std::uint32_t>(height);
  map.resolution_m = resolution;
  map.origin_x_m = 0.0;
  map.origin_y_m = 0.0;
  map.origin_yaw_rad = 0.0;
  map.age_s = 0.1;
  map.data.assign(static_cast<std::size_t>(width * height), 0);
  return map;
}

std::size_t idx(const CostmapSnapshot& map, int x, int y)
{
  return static_cast<std::size_t>(y) * map.width + static_cast<std::size_t>(x);
}

ReachabilityResult plannerOk(const PathSegment&)
{
  return {true, ReachabilityStatus::Reachable, "", "ok"};
}

ReachabilityResult plannerUnavailable(const PathSegment&)
{
  return {false, ReachabilityStatus::PlannerUnavailable, "", "planner down"};
}

ReachabilityResult plannerTimeout(const PathSegment&)
{
  return {false, ReachabilityStatus::Timeout, "", "planner timeout"};
}

bool hasCandidate(const std::vector<PathCandidate>& candidates, const std::string& name)
{
  for (const auto& candidate : candidates) {
    if (candidate.name == name) {
      return true;
    }
  }
  return false;
}

void testHorizontal()
{
  const auto candidates =
    LegacyReachabilityChecker::generateCandidates({1.0, 1.0}, {4.0, 1.0}, config());
  CHECK(hasCandidate(candidates, "direct"));
}

void testVertical()
{
  const auto candidates =
    LegacyReachabilityChecker::generateCandidates({1.0, 1.0}, {1.0, 4.0}, config());
  CHECK(hasCandidate(candidates, "direct"));
}

void testPerfectDiagonal()
{
  const auto candidates =
    LegacyReachabilityChecker::generateCandidates({1.0, 1.0}, {4.0, 4.0}, config());
  CHECK(hasCandidate(candidates, "direct"));
}

void testXThenY()
{
  const auto candidates =
    LegacyReachabilityChecker::generateCandidates({1.0, 1.0}, {4.0, 3.0}, config());
  CHECK(hasCandidate(candidates, "x_then_y"));
}

void testYThenX()
{
  const auto candidates =
    LegacyReachabilityChecker::generateCandidates({1.0, 1.0}, {4.0, 3.0}, config());
  CHECK(hasCandidate(candidates, "y_then_x"));
}

void testDiagonalResidual()
{
  const auto candidates =
    LegacyReachabilityChecker::generateCandidates({1.0, 1.0}, {5.0, 3.0}, config());
  CHECK(hasCandidate(candidates, "diagonal_then_axis"));
  CHECK(hasCandidate(candidates, "axis_then_diagonal"));
}

void testDuplicateRemoval()
{
  const auto candidates =
    LegacyReachabilityChecker::generateCandidates({1.0, 1.0}, {4.0, 4.0}, config());
  int direct_like = 0;
  for (const auto& candidate : candidates) {
    if (candidate.waypoints.size() == 2U) {
      ++direct_like;
    }
  }
  CHECK(direct_like == 1);
}

void testZeroLength()
{
  const auto candidates =
    LegacyReachabilityChecker::generateCandidates({1.0, 1.0}, {1.0, 1.0}, config());
  CHECK(candidates.empty());
}

void testInvalidCoordinate()
{
  const auto candidates = LegacyReachabilityChecker::generateCandidates(
    {std::nan(""), 1.0}, {1.0, 1.0}, config());
  CHECK(candidates.empty());
}

void testObstacleMiddle()
{
  auto map = makeCostmap(6, 3);
  map.data[idx(map, 3, 1)] = 100;
  auto cfg = config();
  cfg.max_sample_step_m = 0.5;
  const PathCandidate candidate{"direct", {{{0.5, 1.5}, {5.5, 1.5}}}};
  const auto result = LegacyReachabilityChecker::validateCandidateCostmap(candidate, map, cfg);
  CHECK(!result.reachable);
  CHECK(result.status == ReachabilityStatus::Blocked);
}

void testObstacleEndpoint()
{
  auto map = makeCostmap(6, 3);
  map.data[idx(map, 5, 1)] = 100;
  const PathCandidate candidate{"direct", {{{0.5, 1.5}, {5.5, 1.5}}}};
  const auto result = LegacyReachabilityChecker::validateCandidateCostmap(candidate, map, config());
  CHECK(!result.reachable);
  CHECK(result.status == ReachabilityStatus::Blocked);
}

void testUnknownRejected()
{
  auto map = makeCostmap(6, 3);
  map.data[idx(map, 3, 1)] = -1;
  auto cfg = config();
  cfg.allow_unknown = false;
  const PathCandidate candidate{"direct", {{{0.5, 1.5}, {5.5, 1.5}}}};
  const auto result = LegacyReachabilityChecker::validateCandidateCostmap(candidate, map, cfg);
  CHECK(!result.reachable);
  CHECK(result.status == ReachabilityStatus::UnknownSpace);
}

void testUnknownAllowed()
{
  auto map = makeCostmap(6, 3);
  map.data[idx(map, 3, 1)] = -1;
  auto cfg = config();
  cfg.allow_unknown = true;
  const PathCandidate candidate{"direct", {{{0.5, 1.5}, {5.5, 1.5}}}};
  const auto result = LegacyReachabilityChecker::validateCandidateCostmap(candidate, map, cfg);
  CHECK(result.reachable);
}

void testOutsideCostmap()
{
  auto map = makeCostmap(4, 4);
  const PathCandidate candidate{"direct", {{{0.5, 0.5}, {5.5, 0.5}}}};
  const auto result = LegacyReachabilityChecker::validateCandidateCostmap(candidate, map, config());
  CHECK(!result.reachable);
  CHECK(result.status == ReachabilityStatus::OutsideCostmap);
}

void testDiagonalFree()
{
  auto map = makeCostmap(6, 6);
  map.data[idx(map, 2, 3)] = 100;
  const PathCandidate candidate{"direct", {{{0.5, 0.5}, {5.5, 5.5}}}};
  const auto result = LegacyReachabilityChecker::validateCandidateCostmap(candidate, map, config());
  CHECK(result.reachable);
}

void testDiagonalBlocked()
{
  auto map = makeCostmap(6, 6);
  map.data[idx(map, 3, 3)] = 100;
  const PathCandidate candidate{"direct", {{{0.5, 0.5}, {5.5, 5.5}}}};
  const auto result = LegacyReachabilityChecker::validateCandidateCostmap(candidate, map, config());
  CHECK(!result.reachable);
}

void testPlannerUnavailable()
{
  auto map = makeCostmap(6, 6);
  const std::vector<PathCandidate> candidates{{"direct", {{{0.5, 0.5}, {5.5, 0.5}}}}};
  const auto result =
    LegacyReachabilityChecker::evaluateCandidates(candidates, map, config(), plannerUnavailable);
  CHECK(!result.reachable);
  CHECK(result.status == ReachabilityStatus::PlannerUnavailable);
}

void testTimeout()
{
  auto map = makeCostmap(6, 6);
  const std::vector<PathCandidate> candidates{{"direct", {{{0.5, 0.5}, {5.5, 0.5}}}}};
  const auto result =
    LegacyReachabilityChecker::evaluateCandidates(candidates, map, config(), plannerTimeout);
  CHECK(!result.reachable);
  CHECK(result.status == ReachabilityStatus::Timeout);
}

void testOneValidAmongBlocked()
{
  auto map = makeCostmap(6, 6);
  map.data[idx(map, 3, 1)] = 100;
  const std::vector<PathCandidate> candidates{
    {"blocked", {{{0.5, 1.5}, {5.5, 1.5}}}},
    {"valid", {{{0.5, 2.5}, {5.5, 2.5}}}},
  };
  const auto result =
    LegacyReachabilityChecker::evaluateCandidates(candidates, map, config(), plannerOk);
  CHECK(result.reachable);
  CHECK(result.selected_candidate == "valid");
}

void testAllBlocked()
{
  auto map = makeCostmap(6, 6);
  map.data[idx(map, 3, 1)] = 100;
  map.data[idx(map, 3, 2)] = 100;
  const std::vector<PathCandidate> candidates{
    {"blocked_a", {{{0.5, 1.5}, {5.5, 1.5}}}},
    {"blocked_b", {{{0.5, 2.5}, {5.5, 2.5}}}},
  };
  const auto result =
    LegacyReachabilityChecker::evaluateCandidates(candidates, map, config(), plannerOk);
  CHECK(!result.reachable);
  CHECK(result.status == ReachabilityStatus::Blocked);
}

void testProtocolRoundTrip()
{
  const std::vector<PathCandidate> candidates{
    {"direct", {{{0.5, 1.5}, {5.5, 1.5}}}},
    {"x_then_y", {{{0.5, 1.5}, {5.5, 1.5}, {5.5, 3.5}}}},
  };
  const auto payload = exploration_legacy::serializeCandidatePayload(candidates);
  std::vector<PathCandidate> parsed;
  CHECK(exploration_legacy::parseCandidatePayload(payload, parsed));
  CHECK(parsed.size() == candidates.size());
  CHECK(parsed[1].name == "x_then_y");

  ReachabilityResult result;
  result.reachable = true;
  result.status = ReachabilityStatus::Reachable;
  result.selected_candidate = "direct";
  result.reason = "ok with spaces";
  const auto response = exploration_legacy::serializeReachabilityResponse(42, result);
  std::uint64_t request_id = 0;
  ReachabilityResult parsed_result;
  std::string line = response;
  if (!line.empty() && line.back() == '\n') {
    line.pop_back();
  }
  CHECK(exploration_legacy::parseReachabilityResponse(line, request_id, parsed_result));
  CHECK(request_id == 42U);
  CHECK(parsed_result.reachable);
  CHECK(parsed_result.reason == "ok with spaces");
}

}  // namespace

int main()
{
  testHorizontal();
  testVertical();
  testPerfectDiagonal();
  testXThenY();
  testYThenX();
  testDiagonalResidual();
  testDuplicateRemoval();
  testZeroLength();
  testInvalidCoordinate();
  testObstacleMiddle();
  testObstacleEndpoint();
  testUnknownRejected();
  testUnknownAllowed();
  testOutsideCostmap();
  testDiagonalFree();
  testDiagonalBlocked();
  testPlannerUnavailable();
  testTimeout();
  testOneValidAmongBlocked();
  testAllBlocked();
  testProtocolRoundTrip();

  if (g_failures == 0) {
    std::printf("All legacy reachability tests passed\n");
  }
  return g_failures == 0 ? 0 : 1;
}
