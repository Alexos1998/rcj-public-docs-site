#include "exploration_legacy/grid_map.hpp"
#include "exploration_legacy/legacy_explorer.hpp"
#include "exploration_legacy/math.hpp"
#include "exploration_legacy/motion_executor.hpp"
#include "exploration_legacy/planner.hpp"
#include "exploration_legacy/reachability.hpp"
#include "exploration_legacy/wall_detector.hpp"

#include <chrono>
#include <cmath>
#include <cstdio>
#include <optional>
#include <string>
#include <vector>

namespace {

int g_failures = 0;

#define CHECK(cond) \
  do { \
    if (!(cond)) { \
      ++g_failures; \
      std::printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); \
    } \
  } while (0)

using namespace exploration_legacy;

class SimMotionIO final : public MotionExecutor::IO {
public:
  double timeSeconds() const override { return time_s_; }

  bool step() override
  {
    time_s_ += 0.01;
    snapshot_.yaw = pose_.yaw;
    snapshot_.pose = pose_;
    snapshot_.loc_pose = pose_;
    return true;
  }

  double yawRadians() const override { return pose_.yaw; }
  Pose2D pose() const override { return pose_; }

  bool localizedPose(Pose2D& out) const override
  {
    out = pose_;
    return true;
  }

  SensorSnapshot sensorSnapshot() const override { return snapshot_; }
  double leftWheelPositionRad() const override { return left_rad_; }
  double rightWheelPositionRad() const override { return right_rad_; }

  void setWheelTargetPosition(double left_rad, double right_rad) override
  {
    left_rad_ = left_rad;
    right_rad_ = right_rad;
  }

  void setWheelVelocityLimit(double, double) override {}

  void setWheelVelocity(double left_rad_s, double right_rad_s) override
  {
    left_velocity_ = left_rad_s;
    right_velocity_ = right_rad_s;
    // The regression only needs deterministic cardinal turns. Snap the fake
    // heading to the commanded quarter-turn so MotionExecutor can proceed to
    // the drive portion without modelling wheel dynamics.
    if (left_rad_s < right_rad_s) {
      pose_.yaw = -1.5707963267948966;
    } else if (left_rad_s > right_rad_s) {
      pose_.yaw = 1.5707963267948966;
    }
    snapshot_.yaw = pose_.yaw;
    snapshot_.pose = pose_;
    snapshot_.loc_pose = pose_;
  }

  void stop() override
  {
    left_velocity_ = 0.0;
    right_velocity_ = 0.0;
  }

  Pose2D pose_{1.0, 2.0, 0.0};
  SensorSnapshot snapshot_;

private:
  double time_s_ = 0.0;
  double left_rad_ = 0.0;
  double right_rad_ = 0.0;
  double left_velocity_ = 0.0;
  double right_velocity_ = 0.0;
};

SensorSnapshot cardinalSnapshot(double north, double east, double south, double west)
{
  SensorSnapshot snapshot;
  snapshot.pose = {1.0, 2.0, 0.0};
  snapshot.loc_pose = snapshot.pose;
  snapshot.loc_pose_valid = true;
  snapshot.yaw = 0.0;
  snapshot.lidar_horizontal_resolution = 8;
  snapshot.lidar_ranges.assign(8, 0.01F);
  snapshot.lidar_ranges[0] = static_cast<float>(north);
  snapshot.lidar_ranges[2] = static_cast<float>(east);
  snapshot.lidar_ranges[4] = static_cast<float>(south);
  snapshot.lidar_ranges[6] = static_cast<float>(west);
  snapshot.floor_r = 255;
  snapshot.floor_g = 255;
  snapshot.floor_b = 255;
  return snapshot;
}

void testPlannerBacktracksOnPermanentTraversedGraph()
{
  LegacyGridMap map(20);
  LegacyPlanner planner;

  const TileCoord current{9, 10};
  const TileCoord junction{10, 10};
  map.setCurrentTile(current);
  map.markVisited(current);
  map.markVisited(junction);
  map.setMazeValue(current, 0);
  map.setMazeValue(junction, directionBit(Direction8::East));
  map.markTraversedEdge(current, junction, Direction8::South);

  // Simulate a later bad sensor/costmap observation clearing the mutable wall
  // layer. The permanent graph must still provide the backtracking connection.
  map.clearWallBits(current, 0xFF);
  map.clearWallBits(junction, 0xFF);

  const LegacyPlanner::Decision decision =
    planner.nextDecision(map, current, Direction4::North);

  CHECK(decision.has_target);
  CHECK(decision.backtracking);
  CHECK(decision.target == junction);
  CHECK(decision.direction == Direction8::South);
}

void testPlannerBacktracksViaMutualVisitedShortcut()
{
  LegacyGridMap map(20);
  LegacyPlanner planner;

  // Traversed DFS chain around three sides of a square:
  // A(5,5) -> B(6,5) -> C(7,5) -> D(7,6) -> E(7,7) -> F(6,7) -> G(5,7).
  const TileCoord a{5, 5};
  const TileCoord b{6, 5};
  const TileCoord c{7, 5};
  const TileCoord d{7, 6};
  const TileCoord e{7, 7};
  const TileCoord f{6, 7};
  const TileCoord g{5, 7};
  const TileCoord m{5, 6};

  for (const TileCoord tile : {a, b, c, d, e, f, g, m}) {
    map.markVisited(tile);
    map.setMazeValue(tile, 0);
  }

  map.markTraversedEdge(a, b, Direction8::South);
  map.markTraversedEdge(b, c, Direction8::South);
  map.markTraversedEdge(c, d, Direction8::East);
  map.markTraversedEdge(d, e, Direction8::East);
  map.markTraversedEdge(e, f, Direction8::North);
  map.markTraversedEdge(f, g, Direction8::North);

  // A still has an unvisited open neighbor to its West: the backtracking goal.
  map.setMazeValue(a, directionBit(Direction8::West));

  // Mutually confirmed (but never traversed) openings across the fourth side:
  // G <-> M <-> A. Both endpoints of each edge are visited and observed the
  // passage open from their own side.
  map.orWallBits(g, directionBit(Direction8::West));
  map.orWallBits(m, directionBit(Direction8::East) | directionBit(Direction8::West));
  map.orWallBits(a, directionBit(Direction8::East));

  map.setCurrentTile(g);
  const LegacyPlanner::Decision first =
    planner.nextDecision(map, g, Direction4::North);

  // Shortcut path G -> M -> A (2 steps) must win over retracing the traversed
  // chain G -> F -> E -> D -> C -> B -> A (6 steps).
  CHECK(first.has_target);
  CHECK(first.backtracking);
  CHECK(first.target == m);
  CHECK(first.direction == Direction8::West);

  map.setCurrentTile(m);
  const LegacyPlanner::Decision second =
    planner.nextDecision(map, m, Direction4::West);
  CHECK(second.has_target);
  CHECK(second.backtracking);
  CHECK(second.target == a);
  CHECK(second.direction == Direction8::West);
}

void testVetoStopsNav2ReopeningRejectedUntraversedEdge()
{
  SimMotionIO io;
  io.snapshot_ = cardinalSnapshot(0.01, 0.20, 0.01, 0.01);

  MotionExecutor::Config motion_config;
  motion_config.tile_size_m = 0.06;
  motion_config.distance_validation_warn_m = 1.0;
  motion_config.stall_recovery_enabled = false;
  motion_config.debug_logs = false;
  MotionExecutor motion(io, motion_config);

  LegacyGridMap map;
  WallDetector::Config wall_config;
  wall_config.ray_delta = 0;
  wall_config.validate_rays_with_loc_pose = false;
  WallDetector walls(wall_config);
  LegacyPlanner planner;
  std::vector<std::string> logs;

  LegacyExplorer::Config explorer_config;
  explorer_config.tile_size_m = 0.06;
  explorer_config.allow_diagonal = false;
  explorer_config.graph_subdivision = 1;
  explorer_config.nav2_reachability_fallback = true;
  explorer_config.nav2_reachability_apply_to_map = true;
  explorer_config.debug_logs = true;
  explorer_config.log_callback = [&logs](const std::string& line) {
    logs.push_back(line);
  };

  LegacyExplorer explorer(motion, map, walls, planner, explorer_config);

  int north_broad_queries = 0;
  int north_exact_queries = 0;
  int other_queries = 0;
  LegacyReachabilityChecker::Config reachability_config;
  reachability_config.timeout = std::chrono::milliseconds(50);
  LegacyReachabilityChecker checker(
    reachability_config,
    [&io]() -> std::optional<Pose2D> { return io.pose_; },
    [&](const Pose2D&,
        double goal_x,
        double goal_y,
        const std::vector<PathCandidate>& candidates,
        std::chrono::milliseconds) {
      const bool north_goal = goal_x > 1.03 && std::abs(goal_y - 2.0) < 0.02;
      const bool exact = !candidates.empty() &&
        candidates.front().name.find("local_graph_L") == 0;

      ReachabilityResult result;
      if (north_goal && !exact) {
        ++north_broad_queries;
        result.reachable = true;
        result.status = ReachabilityStatus::Reachable;
        result.selected_candidate = "broad_coordinate_candidate";
        result.reason = "broad fallback accepts north";
      } else if (north_goal && exact) {
        ++north_exact_queries;
        result.reachable = false;
        result.status = ReachabilityStatus::Blocked;
        result.selected_candidate = candidates.front().name;
        result.reason = "exact edge intersects blocked costmap cell";
      } else {
        ++other_queries;
        result.reachable = false;
        result.status = ReachabilityStatus::Blocked;
        result.selected_candidate = candidates.empty() ? "none" : candidates.front().name;
        result.reason = "other direction blocked";
      }
      return result;
    });
  explorer.setReachabilityChecker(&checker);

  const TileCoord start{90, 90};
  const TileCoord east{90, 91};

  const bool first_step = explorer.stepExploration(io.snapshot_);
  CHECK(first_step);
  CHECK(explorer.currentTile() == start);
  CHECK(north_broad_queries == 1);
  CHECK(north_exact_queries == 1);
  CHECK((map.mazeValue(start) & directionBit(Direction8::North)) == 0);

  const bool second_step = explorer.stepExploration(io.snapshot_);
  CHECK(second_step);
  CHECK(explorer.currentTile() == east);
  CHECK(north_broad_queries == 1);
  CHECK(north_exact_queries == 1);
  CHECK(other_queries >= 2);

  bool saw_authoritative_veto_skip = false;
  bool saw_east_decision = false;
  for (const std::string& log : logs) {
    if (log.find("event=reachability_fallback_skipped") != std::string::npos &&
        log.find("reason=authoritative_untraversed_edge_veto") != std::string::npos) {
      saw_authoritative_veto_skip = true;
    }
    if (log.find("event=planner_decision") != std::string::npos &&
        log.find("target=(90,91)") != std::string::npos) {
      saw_east_decision = true;
    }
  }
  CHECK(saw_authoritative_veto_skip);
  CHECK(saw_east_decision);
}

}  // namespace

int main()
{
  testPlannerBacktracksOnPermanentTraversedGraph();
  testPlannerBacktracksViaMutualVisitedShortcut();
  testVetoStopsNav2ReopeningRejectedUntraversedEdge();

  if (g_failures == 0) {
    std::printf("All static edge authority regression tests passed\n");
  }
  return g_failures == 0 ? 0 : 1;
}
