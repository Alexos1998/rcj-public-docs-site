#include "exploration_legacy/grid_map.hpp"
#include "exploration_legacy/legacy_explorer.hpp"
#include "exploration_legacy/motion_executor.hpp"
#include "exploration_legacy/planner.hpp"
#include "exploration_legacy/reachability.hpp"
#include "exploration_legacy/wall_detector.hpp"

#include <chrono>
#include <cmath>
#include <cstdio>
#include <functional>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace {

int g_failures = 0;

#define CHECK(cond) \
  do { \
    if (!(cond)) { \
      ++g_failures; \
      std::printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); \
    } \
  } while (0)

using exploration_legacy::LegacyExplorer;
using exploration_legacy::LegacyGridMap;
using exploration_legacy::LegacyPlanner;
using exploration_legacy::LegacyReachabilityChecker;
using exploration_legacy::MotionExecutor;
using exploration_legacy::PathCandidate;
using exploration_legacy::Pose2D;
using exploration_legacy::ReachabilityResult;
using exploration_legacy::ReachabilityStatus;
using exploration_legacy::SensorSnapshot;
using exploration_legacy::TileCoord;
using exploration_legacy::WallDetector;

class FakeMotionIO final : public MotionExecutor::IO {
public:
  double timeSeconds() const override { return time_s_; }

  bool step() override
  {
    time_s_ += 0.01;
    return true;
  }

  double yawRadians() const override { return pose_.yaw; }
  Pose2D pose() const override { return pose_; }

  bool localizedPose(Pose2D& out) const override
  {
    out = pose_;
    return true;
  }

  SensorSnapshot sensorSnapshot() const override { return snapshot_; }

  double leftWheelPositionRad() const override { return left_rad_; }
  double rightWheelPositionRad() const override { return right_rad_; }

  void setWheelTargetPosition(double left_rad, double right_rad) override
  {
    left_rad_ = left_rad;
    right_rad_ = right_rad;
  }

  void setWheelVelocityLimit(double, double) override {}
  void setWheelVelocity(double, double) override {}
  void stop() override {}

  Pose2D pose_{1.0, 2.0, 0.0};
  SensorSnapshot snapshot_;

private:
  double time_s_ = 0.0;
  double left_rad_ = 0.0;
  double right_rad_ = 0.0;
};

SensorSnapshot makeCardinalSnapshot(
  double north_m,
  double east_m,
  double south_m,
  double west_m)
{
  SensorSnapshot snapshot;
  snapshot.pose = {0.0, 0.0, 0.0};
  snapshot.loc_pose = {1.0, 2.0, 0.0};
  snapshot.loc_pose_valid = true;
  snapshot.yaw = 0.0;
  snapshot.lidar_horizontal_resolution = 8;
  snapshot.lidar_ranges.assign(8, 0.01F);
  snapshot.lidar_ranges[0] = static_cast<float>(north_m);
  snapshot.lidar_ranges[2] = static_cast<float>(east_m);
  snapshot.lidar_ranges[4] = static_cast<float>(south_m);
  snapshot.lidar_ranges[6] = static_cast<float>(west_m);
  snapshot.floor_r = 255;
  snapshot.floor_g = 255;
  snapshot.floor_b = 255;
  return snapshot;
}

SensorSnapshot makeSnapshot(double range_m)
{
  return makeCardinalSnapshot(range_m, range_m, range_m, range_m);
}

LegacyExplorer::Config makeExplorerConfig(
  bool second_check_enabled,
  bool allow_diagonal,
  int graph_subdivision,
  std::vector<std::string>* logs)
{
  LegacyExplorer::Config cfg;
  cfg.tile_size_m = 0.06;
  cfg.allow_diagonal = allow_diagonal;
  cfg.nav2_reachability_fallback = second_check_enabled;
  cfg.nav2_reachability_apply_to_map = second_check_enabled;
  cfg.graph_subdivision = graph_subdivision;
  cfg.debug_logs = logs != nullptr;
  if (logs) {
    cfg.log_callback = [logs](const std::string& message) {
      logs->push_back(message);
    };
  }
  return cfg;
}

struct Fixture {
  FakeMotionIO io;
  MotionExecutor motion;
  LegacyGridMap map;
  WallDetector walls;
  LegacyPlanner planner;
  std::vector<std::string> logs;
  LegacyExplorer explorer;

  explicit Fixture(
    bool second_check_enabled = true,
    bool allow_diagonal = false,
    int graph_subdivision = 1,
    bool capture_logs = false)
    : motion(io, [] {
        MotionExecutor::Config cfg;
        cfg.tile_size_m = 0.06;
        cfg.distance_validation_warn_m = 1.0;
        cfg.debug_logs = false;
        return cfg;
      }()),
      map(),
      walls([] {
        WallDetector::Config cfg;
        cfg.ray_delta = 0;
        cfg.validate_rays_with_loc_pose = false;
        return cfg;
      }()),
      planner(),
      logs(),
      explorer(motion,
               map,
               walls,
               planner,
               makeExplorerConfig(second_check_enabled,
                                  allow_diagonal,
                                  graph_subdivision,
                                  capture_logs ? &logs : nullptr))
  {
  }
};

using ResultForGoal = std::function<ReachabilityResult(double, double)>;

LegacyReachabilityChecker makeChecker(
  int& query_count,
  std::vector<std::pair<double, double>>& goals,
  ResultForGoal result_for_goal)
{
  LegacyReachabilityChecker::Config cfg;
  cfg.timeout = std::chrono::milliseconds(50);

  return LegacyReachabilityChecker(
    cfg,
    []() -> std::optional<Pose2D> { return Pose2D{1.0, 2.0, 0.0}; },
    [&query_count, &goals, result_for_goal](
      const Pose2D& start,
      double query_goal_x,
      double query_goal_y,
      const std::vector<PathCandidate>& candidates,
      std::chrono::milliseconds) {
      ++query_count;
      goals.emplace_back(query_goal_x, query_goal_y);
      CHECK(std::abs(start.x - 1.0) < 1.0e-9);
      CHECK(std::abs(start.y - 2.0) < 1.0e-9);
      CHECK(!candidates.empty());
      return result_for_goal(query_goal_x, query_goal_y);
    });
}

ResultForGoal constantResult(ReachabilityResult result)
{
  return [result](double, double) { return result; };
}

void testEveryBlockedDirectionGetsASecondCheck()
{
  Fixture fixture;
  fixture.io.snapshot_ = makeSnapshot(0.01);

  int query_count = 0;
  std::vector<std::pair<double, double>> goals;
  ReachabilityResult accepted;
  accepted.reachable = true;
  accepted.status = ReachabilityStatus::Reachable;
  accepted.selected_candidate = "direct";
  accepted.reason = "ok";
  auto checker = makeChecker(query_count, goals, constantResult(accepted));
  fixture.explorer.setReachabilityChecker(&checker);

  const bool stepped = fixture.explorer.stepExploration(fixture.io.snapshot_);

  CHECK(stepped);
  CHECK(query_count == 4);
  CHECK(goals.size() == 4);
  CHECK(std::abs(goals[0].first - 1.06) < 1.0e-9);
  CHECK(std::abs(goals[0].second - 2.0) < 1.0e-9);
  CHECK(std::abs(goals[1].first - 1.0) < 1.0e-9);
  CHECK(std::abs(goals[1].second - 1.94) < 1.0e-9);
  CHECK(std::abs(goals[2].first - 0.94) < 1.0e-9);
  CHECK(std::abs(goals[2].second - 2.0) < 1.0e-9);
  CHECK(std::abs(goals[3].first - 1.0) < 1.0e-9);
  CHECK(std::abs(goals[3].second - 2.06) < 1.0e-9);
  CHECK(fixture.map.wallBits({90, 90}) == 0x0F);
  CHECK(fixture.map.mazeValue({90, 90}) == 0x0E);
  const TileCoord expected{89, 90};
  CHECK(fixture.explorer.currentTile() == expected);
}

void testBlockedDirectionsAreCheckedEvenWithLidarOpenNeighbor()
{
  Fixture fixture;
  fixture.io.snapshot_ = makeCardinalSnapshot(0.20, 0.01, 0.01, 0.01);

  int query_count = 0;
  std::vector<std::pair<double, double>> goals;
  auto checker = makeChecker(
    query_count,
    goals,
    [](double goal_x, double goal_y) {
      ReachabilityResult result;
      const bool is_east = std::abs(goal_x - 1.0) < 1.0e-9 && goal_y < 2.0;
      result.reachable = is_east;
      result.status = is_east
        ? ReachabilityStatus::Reachable
        : ReachabilityStatus::Blocked;
      result.selected_candidate = "direct";
      result.reason = is_east ? "east accepted" : "blocked";
      return result;
    });
  fixture.explorer.setReachabilityChecker(&checker);

  const bool stepped = fixture.explorer.stepExploration(fixture.io.snapshot_);

  CHECK(stepped);
  CHECK(query_count == 3);
  CHECK(goals.size() == 3);
  // North came from LIDAR (bit 0x01); East came from the Nav2 second check
  // (bit 0x02). South and West remained closed.
  CHECK(fixture.map.wallBits({90, 90}) == 0x03);
  CHECK(fixture.map.mazeValue({90, 90}) == 0x02);
  const TileCoord expected{89, 90};
  CHECK(fixture.explorer.currentTile() == expected);
}

void testDiagonalDirectionsAreAlsoCheckedWhenEnabled()
{
  Fixture fixture(true, true);
  fixture.io.snapshot_ = makeSnapshot(0.01);

  int query_count = 0;
  std::vector<std::pair<double, double>> goals;
  ReachabilityResult accepted;
  accepted.reachable = true;
  accepted.status = ReachabilityStatus::Reachable;
  accepted.selected_candidate = "direct";
  auto checker = makeChecker(query_count, goals, constantResult(accepted));
  fixture.explorer.setReachabilityChecker(&checker);

  const bool stepped = fixture.explorer.stepExploration(fixture.io.snapshot_);

  CHECK(stepped);
  CHECK(query_count == 8);
  CHECK(goals.size() == 8);
  CHECK(fixture.map.wallBits({90, 90}) == 0xFF);
  CHECK(fixture.map.mazeValue({90, 90}) == 0xFE);
}

void testInfrastructureFailureAbortsSecondCheckSweep()
{
  Fixture fixture;
  fixture.io.snapshot_ = makeSnapshot(0.01);

  int query_count = 0;
  std::vector<std::pair<double, double>> goals;
  ReachabilityResult unavailable;
  unavailable.reachable = false;
  unavailable.status = ReachabilityStatus::PlannerUnavailable;
  unavailable.reason = "planner down";
  auto checker = makeChecker(query_count, goals, constantResult(unavailable));
  fixture.explorer.setReachabilityChecker(&checker);

  fixture.explorer.stepExploration(fixture.io.snapshot_);

  CHECK(query_count == 1);
  CHECK(goals.size() == 1);
  const TileCoord expected{90, 90};
  CHECK(fixture.explorer.currentTile() == expected);
}


void testInfrastructureFailureStartsCooldown()
{
  Fixture fixture;
  fixture.io.snapshot_ = makeCardinalSnapshot(0.20, 0.01, 0.01, 0.01);

  int query_count = 0;
  std::vector<std::pair<double, double>> goals;
  ReachabilityResult unavailable;
  unavailable.reachable = false;
  unavailable.status = ReachabilityStatus::PlannerUnavailable;
  unavailable.reason = "planner down";
  auto checker = makeChecker(query_count, goals, constantResult(unavailable));
  fixture.explorer.setReachabilityChecker(&checker);

  const bool first_step = fixture.explorer.stepExploration(fixture.io.snapshot_);
  const bool second_step = fixture.explorer.stepExploration(fixture.io.snapshot_);

  CHECK(first_step);
  CHECK(second_step);
  // First step performs one query and opens the circuit on infrastructure
  // failure. The immediate next tile must not hammer Nav2 again.
  CHECK(query_count == 1);
  CHECK(goals.size() == 1);
}

void testDisabledSecondCheckDoesNotQueryNav2()
{
  Fixture fixture(false);
  fixture.io.snapshot_ = makeSnapshot(0.01);

  int query_count = 0;
  std::vector<std::pair<double, double>> goals;
  ReachabilityResult accepted;
  accepted.reachable = true;
  accepted.status = ReachabilityStatus::Reachable;
  auto checker = makeChecker(query_count, goals, constantResult(accepted));
  fixture.explorer.setReachabilityChecker(&checker);

  fixture.explorer.stepExploration(fixture.io.snapshot_);

  CHECK(query_count == 0);
  const TileCoord expected{90, 90};
  CHECK(fixture.explorer.currentTile() == expected);
}

void testMovementGraphInfrastructureFailureUsesSubdividedFallback()
{
  Fixture fixture(false, false, 2, true);
  fixture.io.snapshot_ = makeCardinalSnapshot(0.20, 0.01, 0.01, 0.01);

  int query_count = 0;
  std::vector<std::pair<double, double>> goals;
  ReachabilityResult unavailable;
  unavailable.reachable = false;
  unavailable.status = ReachabilityStatus::CostmapUnavailable;
  unavailable.reason = "costmap unavailable";
  auto checker = makeChecker(query_count, goals, constantResult(unavailable));
  fixture.explorer.setReachabilityChecker(&checker);

  const bool stepped = fixture.explorer.stepExploration(fixture.io.snapshot_);

  int subgoal_count = 0;
  bool saw_subdivided_fallback = false;
  bool saw_direct_fallback = false;
  bool saw_subdivided_target = false;
  for (const std::string& log : fixture.logs) {
    if (log.find("event=motion_subgoal_pose") != std::string::npos) {
      ++subgoal_count;
    }
    if (log.find("event=movement_graph_fallback_subdivision") != std::string::npos) {
      saw_subdivided_fallback = true;
    }
    if (log.find("event=movement_graph_fallback_direct") != std::string::npos) {
      saw_direct_fallback = true;
    }
    if (log.find("event=motion_target_pose") != std::string::npos &&
        log.find("subdivision_level=2") != std::string::npos &&
        log.find("subgoals=2") != std::string::npos) {
      saw_subdivided_target = true;
    }
  }

  CHECK(stepped);
  CHECK(query_count == 1);
  CHECK(goals.size() == 1);
  CHECK(subgoal_count == 2);
  CHECK(saw_subdivided_fallback);
  CHECK(!saw_direct_fallback);
  CHECK(saw_subdivided_target);
  const TileCoord expected{89, 90};
  CHECK(fixture.explorer.currentTile() == expected);
}

void testMovementGraphBlockedResultDoesNotBecomePhysicalBlock()
{
  Fixture fixture(false, false, 2, true);
  fixture.io.snapshot_ = makeCardinalSnapshot(0.20, 0.01, 0.01, 0.01);

  int query_count = 0;
  std::vector<std::pair<double, double>> goals;
  ReachabilityResult blocked;
  blocked.reachable = false;
  blocked.status = ReachabilityStatus::Blocked;
  blocked.reason = "sample in blocked costmap cell";
  auto checker = makeChecker(query_count, goals, constantResult(blocked));
  fixture.explorer.setReachabilityChecker(&checker);

  const bool stepped = fixture.explorer.stepExploration(fixture.io.snapshot_);

  int subgoal_count = 0;
  bool saw_override = false;
  bool saw_motion_blocked = false;
  for (const std::string& log : fixture.logs) {
    if (log.find("event=motion_subgoal_pose") != std::string::npos) {
      ++subgoal_count;
    }
    if (log.find("event=movement_graph_override_subdivision") != std::string::npos) {
      saw_override = true;
    }
    if (log.find("event=motion_blocked") != std::string::npos) {
      saw_motion_blocked = true;
    }
  }

  CHECK(stepped);
  CHECK(query_count == 2);
  CHECK(goals.size() == 2);
  CHECK(subgoal_count == 2);
  CHECK(saw_override);
  CHECK(!saw_motion_blocked);
  CHECK(fixture.map.blockedCount() == 0);
  const TileCoord expected{89, 90};
  CHECK(fixture.explorer.currentTile() == expected);
}

void testPreviouslyTraversedEdgeBypassesNav2OnReturn()
{
  Fixture fixture(false, false, 2, true);

  int query_count = 0;
  std::vector<std::pair<double, double>> goals;
  ReachabilityResult blocked;
  blocked.reachable = false;
  blocked.status = ReachabilityStatus::Blocked;
  blocked.reason = "narrow passage rejected by costmap";
  auto checker = makeChecker(query_count, goals, constantResult(blocked));
  fixture.explorer.setReachabilityChecker(&checker);

  fixture.io.snapshot_ = makeCardinalSnapshot(0.20, 0.01, 0.01, 0.01);
  const bool entered = fixture.explorer.stepExploration(fixture.io.snapshot_);

  const TileCoord north_of_start{89, 90};
  CHECK(entered);
  CHECK(fixture.explorer.currentTile() == north_of_start);
  CHECK(query_count == 0);

  fixture.io.snapshot_ = makeSnapshot(0.01);
  const bool returned = fixture.explorer.stepExploration(fixture.io.snapshot_);

  bool saw_traversed_skip = false;
  for (const std::string& log : fixture.logs) {
    if (log.find("event=movement_graph_skipped") != std::string::npos &&
        log.find("reason=previously_traversed_edge") != std::string::npos) {
      saw_traversed_skip = true;
    }
  }

  CHECK(!returned);
  CHECK(fixture.explorer.finished());
  const TileCoord start_tile{90, 90};
  CHECK(fixture.explorer.currentTile() == start_tile);
  CHECK(query_count == 0);
  CHECK(goals.empty());
  CHECK(saw_traversed_skip);
}

}  // namespace

int main()
{
  testEveryBlockedDirectionGetsASecondCheck();
  testBlockedDirectionsAreCheckedEvenWithLidarOpenNeighbor();
  testDiagonalDirectionsAreAlsoCheckedWhenEnabled();
  testInfrastructureFailureAbortsSecondCheckSweep();
  testInfrastructureFailureStartsCooldown();
  testDisabledSecondCheckDoesNotQueryNav2();
  testMovementGraphInfrastructureFailureUsesSubdividedFallback();
  testMovementGraphBlockedResultDoesNotBecomePhysicalBlock();
  testPreviouslyTraversedEdgeBypassesNav2OnReturn();

  if (g_failures == 0) {
    std::printf("All legacy explorer reachability second-check tests passed\n");
  }
  return g_failures == 0 ? 0 : 1;
}
