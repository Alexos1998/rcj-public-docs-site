#include "exploration_legacy/grid_map.hpp"

#include <algorithm>
#include <stdexcept>

#include "exploration_legacy/math.hpp"

namespace exploration_legacy {

LegacyGridMap::LegacyGridMap(int size)
  : size_(size),
    start_tile_{size / 2, size / 2},
    current_tile_(start_tile_),
    checkpoint_tile_(start_tile_)
{
  if (size_ <= 0) {
    throw std::invalid_argument("LegacyGridMap size must be positive");
  }
  reset();
}

void LegacyGridMap::reset()
{
  const int count = size_ * size_;
  maze_.assign(count, -1);
  wallgrid_.assign(count, 0);
  traversed_edges_.assign(count, 0);
  swampmaze_.assign(count, 0);
  semantic_.assign(count, static_cast<int>(TileSemantic::Unknown));
  blocked_.assign(count, 0);
  visited_.assign(count, 0);
  parent_.assign(count, {-1, -1});
  found_victim_.assign(count, 0);

  current_tile_ = start_tile_;
  checkpoint_tile_ = start_tile_;
  room_state_ = {};
  room_state_.min_tile = start_tile_;
  room_state_.max_tile = start_tile_;
}

int LegacyGridMap::size() const
{
  return size_;
}

TileCoord LegacyGridMap::startTile() const
{
  return start_tile_;
}

TileCoord LegacyGridMap::currentTile() const
{
  return current_tile_;
}

void LegacyGridMap::setCurrentTile(TileCoord tile)
{
  if (inBounds(tile)) {
    current_tile_ = tile;
  }
}

TileCoord LegacyGridMap::checkpointTile() const
{
  return checkpoint_tile_;
}

void LegacyGridMap::setCheckpointTile(TileCoord tile)
{
  if (inBounds(tile)) {
    checkpoint_tile_ = tile;
  }
}

bool LegacyGridMap::inBounds(TileCoord tile) const
{
  return tile.x >= 0 && tile.x < size_ && tile.y >= 0 && tile.y < size_;
}

bool LegacyGridMap::visited(TileCoord tile) const
{
  if (!inBounds(tile)) {
    return false;
  }
  return visited_[index(tile)] != 0;
}

void LegacyGridMap::markVisited(TileCoord tile)
{
  if (inBounds(tile)) {
    visited_[index(tile)] = 1;
  }
}

void LegacyGridMap::markBlocked(TileCoord tile)
{
  if (inBounds(tile)) {
    blocked_[index(tile)] = 1;
  }
}

void LegacyGridMap::clearBlocked(TileCoord tile)
{
  if (inBounds(tile)) {
    blocked_[index(tile)] = 0;
  }
}

bool LegacyGridMap::blocked(TileCoord tile) const
{
  if (!inBounds(tile)) {
    return true;
  }
  return blocked_[index(tile)] != 0;
}

int LegacyGridMap::mazeValue(TileCoord tile) const
{
  return valueOrDefault(maze_, tile, -1);
}

void LegacyGridMap::setMazeValue(TileCoord tile, int value)
{
  if (inBounds(tile)) {
    maze_[index(tile)] = value;
  }
}

void LegacyGridMap::orMazeBits(TileCoord tile, int bits)
{
  if (inBounds(tile)) {
    maze_[index(tile)] |= bits;
  }
}

void LegacyGridMap::clearMazeBits(TileCoord tile, int bits)
{
  if (inBounds(tile)) {
    maze_[index(tile)] &= ~bits;
  }
}

int LegacyGridMap::wallBits(TileCoord tile) const
{
  return valueOrDefault(wallgrid_, tile, 0);
}

void LegacyGridMap::orWallBits(TileCoord tile, int bits)
{
  if (inBounds(tile)) {
    wallgrid_[index(tile)] |= bits;
  }
}

void LegacyGridMap::clearWallBits(TileCoord tile, int bits)
{
  if (inBounds(tile)) {
    wallgrid_[index(tile)] &= ~bits;
  }
}

int LegacyGridMap::traversedEdgeBits(TileCoord tile) const
{
  return valueOrDefault(traversed_edges_, tile, 0);
}

bool LegacyGridMap::traversedEdge(TileCoord tile, Direction8 direction) const
{
  return (traversedEdgeBits(tile) & directionBit(direction)) != 0;
}

void LegacyGridMap::markTraversedEdge(
  TileCoord from,
  TileCoord to,
  Direction8 direction)
{
  const int forward_bit = directionBit(direction);
  const int reverse_bit = oppositeDirectionBit(direction);

  if (inBounds(from)) {
    traversed_edges_[index(from)] |= forward_bit;
    // Keep the mutable connectivity view consistent for diagnostics and any
    // legacy callers. The permanent traversed graph remains the authority.
    wallgrid_[index(from)] |= forward_bit;
  }
  if (inBounds(to)) {
    traversed_edges_[index(to)] |= reverse_bit;
    wallgrid_[index(to)] |= reverse_bit;
  }
}

bool LegacyGridMap::backtrackEdge(TileCoord from, Direction8 direction) const
{
  if (traversedEdge(from, direction)) {
    return true;
  }

  const TileCoord to = add(from, tileDelta(direction));
  if (!inBounds(from) || !inBounds(to) || blocked(to) || hole(to)) {
    return false;
  }
  if (!visited(from) || !visited(to)) {
    return false;
  }

  return (wallBits(from) & directionBit(direction)) != 0 &&
         (wallBits(to) & oppositeDirectionBit(direction)) != 0;
}

bool LegacyGridMap::swamp(TileCoord tile) const
{
  return valueOrDefault(swampmaze_, tile, 0) != 0;
}

void LegacyGridMap::markSwamp(TileCoord tile)
{
  if (inBounds(tile)) {
    swampmaze_[index(tile)] = 1;
    semantic_[index(tile)] = static_cast<int>(TileSemantic::Swamp);
  }
}

bool LegacyGridMap::hole(TileCoord tile) const
{
  return semantic(tile) == TileSemantic::Hole;
}

void LegacyGridMap::markHole(TileCoord tile)
{
  if (inBounds(tile)) {
    semantic_[index(tile)] = static_cast<int>(TileSemantic::Hole);
  }
}

TileSemantic LegacyGridMap::semantic(TileCoord tile) const
{
  return static_cast<TileSemantic>(
    valueOrDefault(semantic_, tile, static_cast<int>(TileSemantic::Unknown)));
}

void LegacyGridMap::setSemantic(TileCoord tile, TileSemantic semantic)
{
  if (inBounds(tile)) {
    semantic_[index(tile)] = static_cast<int>(semantic);
  }
}

bool LegacyGridMap::victimFound(TileCoord tile) const
{
  if (!inBounds(tile)) {
    return false;
  }
  return found_victim_[index(tile)] != 0;
}

void LegacyGridMap::markVictimFound(TileCoord tile)
{
  if (inBounds(tile)) {
    found_victim_[index(tile)] = 1;
  }
}

int LegacyGridMap::visitedCount() const
{
  return static_cast<int>(std::count(visited_.begin(), visited_.end(), 1));
}

int LegacyGridMap::blockedCount() const
{
  return static_cast<int>(std::count(blocked_.begin(), blocked_.end(), 1));
}

int LegacyGridMap::holeCount() const
{
  return static_cast<int>(std::count(
    semantic_.begin(),
    semantic_.end(),
    static_cast<int>(TileSemantic::Hole)));
}

int LegacyGridMap::knownCount() const
{
  return static_cast<int>(std::count_if(
    maze_.begin(),
    maze_.end(),
    [](int value) { return value >= 0; }));
}

TileCoord LegacyGridMap::parent(TileCoord tile) const
{
  if (!inBounds(tile)) {
    return {-1, -1};
  }
  return parent_[index(tile)];
}

void LegacyGridMap::setParent(TileCoord tile, TileCoord parent)
{
  if (inBounds(tile)) {
    parent_[index(tile)] = parent;
  }
}

void LegacyGridMap::clearParents()
{
  std::fill(parent_.begin(), parent_.end(), TileCoord{-1, -1});
}

LegacyGridMap::RoomState& LegacyGridMap::roomState()
{
  return room_state_;
}

const LegacyGridMap::RoomState& LegacyGridMap::roomState() const
{
  return room_state_;
}

int LegacyGridMap::index(TileCoord tile) const
{
  return tile.x * size_ + tile.y;
}

int LegacyGridMap::valueOrDefault(const std::vector<int>& values, TileCoord tile, int fallback) const
{
  if (!inBounds(tile)) {
    return fallback;
  }
  return values[index(tile)];
}

}  // namespace exploration_legacy
