#include "exploration_legacy/hazard_detector.hpp"

#include <cmath>

namespace exploration_legacy {

HazardDetector::HazardDetector(Config config)
  : config_(config)
{
}

bool HazardDetector::isHole(const SensorSnapshot& snapshot) const
{
  const bool hole_color_1 = rgbNear(snapshot,
                                    config_.hole_target_rgb_1,
                                    config_.hole_target_rgb_1,
                                    config_.hole_target_rgb_1,
                                    config_.rgb_tolerance);
  const bool hole_color_2 = rgbNear(snapshot,
                                    config_.hole_target_rgb_2,
                                    config_.hole_target_rgb_2,
                                    config_.hole_target_rgb_2,
                                    config_.rgb_tolerance);
  const bool distance_sensor_hole =
    snapshot.distance_sensor_valid &&
    snapshot.distance_sensor_value > config_.distance_sensor_hole_min &&
    snapshot.distance_sensor_value < config_.distance_sensor_hole_max &&
    snapshot.roll_rad > config_.roll_hole_min_rad;

  return hole_color_1 || hole_color_2 || distance_sensor_hole;
}

bool HazardDetector::isSwamp(const SensorSnapshot& snapshot) const
{
  return rgbNear(snapshot,
                 config_.swamp_r,
                 config_.swamp_g,
                 config_.swamp_b,
                 config_.floor_color_tolerance);
}

bool HazardDetector::isCheckpoint(const SensorSnapshot& snapshot) const
{
  return rgbNear(snapshot,
                 config_.checkpoint_r,
                 config_.checkpoint_g,
                 config_.checkpoint_b,
                 config_.floor_color_tolerance);
}

bool HazardDetector::rgbNear(const SensorSnapshot& snapshot,
                             int r,
                             int g,
                             int b,
                             int tolerance) const
{
  return std::abs(snapshot.floor_r - r) < tolerance &&
         std::abs(snapshot.floor_g - g) < tolerance &&
         std::abs(snapshot.floor_b - b) < tolerance;
}

}  // namespace exploration_legacy
