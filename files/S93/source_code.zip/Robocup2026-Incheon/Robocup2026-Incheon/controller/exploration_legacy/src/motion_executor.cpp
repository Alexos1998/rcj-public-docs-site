#include "exploration_legacy/motion_executor.hpp"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <sstream>

#include "exploration_legacy/math.hpp"

namespace exploration_legacy {

namespace {

double clamp(double value, double min_value, double max_value)
{
  return std::max(min_value, std::min(max_value, value));
}

}  // namespace

bool MotionExecutor::IO::localizedPose(Pose2D& out) const
{
  (void)out;
  return false;
}

MotionExecutor::MotionExecutor(IO& io, Config config)
  : MotionExecutor(io, config, HazardDetector{})
{
}

MotionExecutor::MotionExecutor(IO& io, Config config, HazardDetector hazard_detector)
  : io_(io),
    config_(config),
    hazard_detector_(hazard_detector)
{
}

bool MotionExecutor::turnToYaw(double target_yaw_rad)
{
  return turnToYawInternal(target_yaw_rad, "turn_timeout_but_continuing");
}

bool MotionExecutor::turnToYawInternal(double target_yaw_rad, const char* timeout_event)
{
  target_yaw_rad = normalizeAngle(target_yaw_rad);
  const double initial_yaw = io_.yawRadians();
  const double initial_error = angleDelta(target_yaw_rad, initial_yaw);
  if (std::abs(initial_error) < 0.004) {
    io_.stop();
    std::ostringstream fields;
    fields << "target_yaw=" << std::fixed << std::setprecision(4) << target_yaw_rad
           << " current_yaw=" << initial_yaw
           << " error=" << initial_error;
    logEvent("turn_skipped_already_aligned", fields.str());
    return true;
  }

  const double start_time = io_.timeSeconds();
  {
    std::ostringstream fields;
    fields << "target_yaw=" << std::fixed << std::setprecision(4) << target_yaw_rad
           << " current_yaw=" << initial_yaw;
    logEvent("turn_start", fields.str());
  }

  while (true) {
    const double current_yaw = io_.yawRadians();
    const double error = angleDelta(target_yaw_rad, current_yaw);
    if (std::abs(error) <= config_.turn_tolerance_rad) {
      io_.stop();
      std::ostringstream fields;
      fields << "success=1"
             << " final_yaw=" << std::fixed << std::setprecision(4) << current_yaw
             << " error=" << error
             << " duration=" << (io_.timeSeconds() - start_time);
      logEvent("turn_done", fields.str());
      return true;
    }

    double command = std::abs(error) * config_.turn_gain;
    command = clamp(command, config_.min_turn_speed_rad_s, config_.max_wheel_speed_rad_s);
    if (error < 0.0) {
      command = -command;
    }

    io_.setWheelVelocity(command, -command);

    if (!io_.step()) {
      io_.stop();
      logEvent("turn_done", "success=0 reason=step_failed");
      return false;
    }

    if (config_.abort_requested && config_.abort_requested()) {
      // Stop the turn and report success so driveToPose proceeds to its
      // post-turn abort check, which returns a DriveResult with aborted=true.
      io_.stop();
      logEvent("turn_aborted", "reason=external_abort");
      return true;
    }

    if (io_.timeSeconds() - start_time > config_.max_turn_duration_s) {
      io_.stop();
      const double final_yaw = io_.yawRadians();
      const double final_error = angleDelta(target_yaw_rad, final_yaw);
      std::ostringstream fields;
      fields << "target_yaw=" << std::fixed << std::setprecision(4) << target_yaw_rad
             << " final_yaw=" << final_yaw
             << " error=" << final_error
             << " duration=" << (io_.timeSeconds() - start_time);
      logEvent(timeout_event, fields.str());

      const bool acceptable =
        std::abs(final_error) <= config_.turn_tolerance_rad * 4.0;

      std::ostringstream done_fields;
      done_fields << "success=" << (acceptable ? 1 : 0)
                  << " reason=timeout"
                  << " final_yaw=" << std::fixed << std::setprecision(4) << final_yaw
                  << " error=" << final_error
                  << " duration=" << (io_.timeSeconds() - start_time);
      logEvent("turn_done", done_fields.str());
      return acceptable;
    }
  }
}

bool MotionExecutor::alignCardinal()
{
  const Direction4 nearest = nearestCardinalDirection(io_.yawRadians());
  return turnToYawInternal(directionToYaw(nearest), "align_timeout_but_continuing");
}

void MotionExecutor::stop()
{
  io_.stop();
}

MotionExecutor::DriveResult MotionExecutor::driveDistance(double distance_m)
{
  return driveDistanceAtSpeed(distance_m, config_.linear_speed_mps);
}

MotionExecutor::DriveResult MotionExecutor::driveTile()
{
  return driveDistance(config_.tile_size_m);
}

MotionExecutor::DriveResult MotionExecutor::driveDiagonalTile()
{
  return driveDistanceAtSpeed(config_.tile_size_m * std::sqrt(2.0), config_.diagonal_linear_speed_mps);
}

MotionExecutor::DriveResult MotionExecutor::driveToPose(Pose2D target_pose)
{
  Pose2D current_pose = measuredPose();

  if (!std::isfinite(current_pose.x) ||
      !std::isfinite(current_pose.y) ||
      !std::isfinite(current_pose.yaw) ||
      !std::isfinite(target_pose.x) ||
      !std::isfinite(target_pose.y)) {
    io_.stop();
    logEvent("drive_to_pose_failed", "reason=invalid_pose");
    return makeDriveResult(false, false, false, 0.0, 0.0, 0.0);
  }

  double dx = target_pose.x - current_pose.x;
  double dy = target_pose.y - current_pose.y;
  double distance_m = std::hypot(dx, dy);

  if (distance_m <= config_.distance_tolerance_m) {
    io_.stop();
    logEvent("drive_to_pose_skipped", "reason=already_at_target");
    return makeDriveResult(true, false, false, 0.0, 0.0, 0.0);
  }

  const double target_yaw = normalizeAngle(std::atan2(dy, dx));

  {
    std::ostringstream fields;
    fields << "current_x=" << std::fixed << std::setprecision(4) << current_pose.x
           << " current_y=" << current_pose.y
           << " target_x=" << target_pose.x
           << " target_y=" << target_pose.y
           << " dx=" << dx
           << " dy=" << dy
           << " distance=" << distance_m
           << " target_yaw=" << target_yaw
           << " current_yaw=" << io_.yawRadians()
           << " yaw_error=" << angleDelta(target_yaw, io_.yawRadians());
    logEvent("drive_to_pose_start", fields.str());
  }

  bool turned = turnToYaw(target_yaw);

  // Turn stall recovery: a timed-out turn with the yaw barely moving means the
  // chassis is wedged against a wall (wheels spin, robot cannot rotate).
  // Without this the explorer retries the same decision forever and the robot
  // never leaves the corner. Nudge straight backwards, then forwards, retrying
  // the turn after each nudge to break the wall contact.
  if (!turned && config_.stall_recovery_enabled && !recovering_from_stall_ &&
      config_.stall_recovery_reverse_m > 0.0)
  {
    for (int attempt = 0; attempt < 2 && !turned; ++attempt) {
      if (config_.abort_requested && config_.abort_requested()) {
        break;
      }
      const double nudge_m =
        (attempt == 0 ? -1.0 : 1.0) * config_.stall_recovery_reverse_m;
      const bool was_recovering = recovering_from_stall_;
      recovering_from_stall_ = true;
      driveDistanceAtSpeed(nudge_m, config_.linear_speed_mps);
      recovering_from_stall_ = was_recovering;

      std::ostringstream fields;
      fields << "attempt=" << (attempt + 1)
             << " nudge=" << std::fixed << std::setprecision(4) << nudge_m
             << " target_yaw=" << target_yaw
             << " current_yaw=" << io_.yawRadians();
      logEvent("turn_stall_recovery", fields.str());

      turned = turnToYaw(target_yaw);
    }
  }

  if (!turned) {
    io_.stop();

    current_pose = measuredPose();
    const double measured_after_failed_turn = distance2D(current_pose, target_pose);

    std::ostringstream fields;
    fields << "reason=turn_failed"
           << " target_yaw=" << std::fixed << std::setprecision(4) << target_yaw
           << " current_yaw=" << io_.yawRadians()
           << " remaining_distance=" << measured_after_failed_turn;
    logEvent("drive_to_pose_failed", fields.str());

    return makeDriveResult(false,
                           false,
                           false,
                           distance_m,
                           0.0,
                           distance2D(measuredPose(), current_pose));
  }

  // The turn may have been interrupted by an external abort request (vision saw
  // a reportable detection). Surface it as an aborted DriveResult before driving.
  if (config_.abort_requested && config_.abort_requested()) {
    io_.stop();
    DriveResult result = makeDriveResult(false, false, false, distance_m, 0.0, 0.0);
    result.aborted = true;
    logEvent("drive_to_pose_aborted", "reason=external_abort_during_turn");
    return result;
  }

  // Recalcula depois do giro, porque o robô pode escorregar ou mudar um pouco de posição.
  current_pose = measuredPose();
  dx = target_pose.x - current_pose.x;
  dy = target_pose.y - current_pose.y;
  distance_m = std::hypot(dx, dy);

  if (distance_m <= config_.distance_tolerance_m) {
    io_.stop();
    logEvent("drive_to_pose_done", "success=1 reason=target_reached_after_turn");
    return makeDriveResult(true, false, false, 0.0, 0.0, 0.0);
  }

  const double speed =
    distance_m > config_.tile_size_m * 1.20
      ? config_.diagonal_linear_speed_mps
      : config_.linear_speed_mps;

  DriveResult result = driveDistanceAtSpeed(distance_m, speed);

  const Pose2D final_pose = measuredPose();
  const double final_target_error = distance2D(final_pose, target_pose);
  if (final_target_error > config_.distance_validation_warn_m) {
    result.validation_warning = true;

    std::ostringstream fields;
    fields << "target_error=" << std::fixed << std::setprecision(4) << final_target_error
           << " warn_limit=" << config_.distance_validation_warn_m
           << " target_x=" << target_pose.x
           << " target_y=" << target_pose.y
           << " final_x=" << final_pose.x
           << " final_y=" << final_pose.y;
    logEvent("drive_to_pose_validation_warning", fields.str());
  }

  {
    std::ostringstream fields;
    fields << "success=" << (result.success ? 1 : 0)
           << " requested_distance=" << std::fixed << std::setprecision(4)
           << result.requested_distance_m
           << " measured_distance=" << result.measured_distance_m
           << " target_error=" << final_target_error
           << " validation_warning=" << (result.validation_warning ? 1 : 0);
    logEvent("drive_to_pose_done", fields.str());
  }

  return result;
}

MotionExecutor::DriveResult MotionExecutor::driveDistanceAtSpeed(double distance_m, double speed_mps)
{
  const Pose2D start_pose = measuredPose();
  const double start_left = io_.leftWheelPositionRad();
  const double start_right = io_.rightWheelPositionRad();
  const double target_distance = std::abs(distance_m);
  if (target_distance <= 0.0) {
    io_.stop();
    return makeDriveResult(true, false, false, distance_m, 0.0, 0.0);
  }

  const double wheel_radius = std::max(config_.wheel_radius_m, 1.0e-9);
  const double wheel_delta_rad = distance_m / wheel_radius;
  const double left_target = start_left + wheel_delta_rad;
  const double right_target = start_right + wheel_delta_rad;
  const double velocity_limit = clamp(
    std::abs(speed_mps) / wheel_radius,
    0.0,
    config_.max_wheel_speed_rad_s);
  const double start_time = io_.timeSeconds();

  io_.setWheelVelocityLimit(velocity_limit, velocity_limit);
  io_.setWheelTargetPosition(left_target, right_target);

  Pose2D stall_reference_pose;
  bool stall_reference_valid = io_.localizedPose(stall_reference_pose);
  double stall_reference_left = start_left;
  double stall_reference_right = start_right;
  double stall_reference_time = start_time;

  {
    std::ostringstream fields;
    fields << "requested=" << std::fixed << std::setprecision(4) << distance_m
           << " wheel_radius=" << wheel_radius
           << " wheel_delta_rad=" << wheel_delta_rad
           << " left_start=" << start_left
           << " right_start=" << start_right
           << " left_target=" << left_target
           << " right_target=" << right_target
           << " speed_limit=" << velocity_limit;
    logEvent("drive_start", fields.str());
  }

  while (true) {
    if (!io_.step()) {
      io_.stop();
      DriveResult result = makeDriveResult(false,
                                           false,
                                           false,
                                           distance_m,
                                           encoderTravelDistance(start_left, start_right),
                                           distance2D(start_pose, measuredPose()));
      std::ostringstream fields;
      fields << "success=0 reason=step_failed"
             << " requested=" << std::fixed << std::setprecision(4) << distance_m
             << " encoder_traveled=" << result.traveled_before_stop_m
             << " measured=" << result.measured_distance_m
             << " error=" << result.distance_error_m
             << " duration=" << (io_.timeSeconds() - start_time);
      logEvent("drive_done", fields.str());
      return result;
    }

    if (config_.abort_requested && config_.abort_requested()) {
      cancelWheelTargetAtCurrentPosition();
      DriveResult result = makeDriveResult(false,
                                           false,
                                           false,
                                           distance_m,
                                           encoderTravelDistance(start_left, start_right),
                                           distance2D(start_pose, measuredPose()));
      result.aborted = true;
      std::ostringstream fields;
      fields << "reason=external_abort"
             << " requested=" << std::fixed << std::setprecision(4) << distance_m
             << " encoder_traveled=" << result.traveled_before_stop_m
             << " duration=" << (io_.timeSeconds() - start_time);
      logEvent("drive_aborted", fields.str());
      return result;
    }

    if (!returning_from_hole_ &&
        distance_m > 0.0 &&
        hazard_detector_.isHole(io_.sensorSnapshot())) {
      return handleHoleDuringDrive(distance_m, speed_mps, start_pose, start_left, start_right);
    }

    if (!returning_from_hole_ &&
        !recovering_from_stall_ &&
        distance_m > 0.0 &&
        config_.stall_recovery_enabled)
    {
      Pose2D current_loc_pose;
      const bool current_loc_valid = io_.localizedPose(current_loc_pose);
      if (!current_loc_valid) {
        stall_reference_valid = false;
      } else if (!stall_reference_valid) {
        stall_reference_pose = current_loc_pose;
        stall_reference_left = io_.leftWheelPositionRad();
        stall_reference_right = io_.rightWheelPositionRad();
        stall_reference_time = io_.timeSeconds();
        stall_reference_valid = true;
      } else {
        const double encoder_window =
          encoderTravelDistance(stall_reference_left, stall_reference_right);
        const double loc_translation = distance2D(stall_reference_pose, current_loc_pose);
        const double window_duration = io_.timeSeconds() - stall_reference_time;
        if (encoder_window >= config_.stall_encoder_window_m) {
          if (loc_translation <= config_.stall_loc_translation_epsilon_m &&
              window_duration >= config_.stall_min_duration_s)
          {
            return handleStallDuringDrive(distance_m,
                                          speed_mps,
                                          start_pose,
                                          start_left,
                                          start_right,
                                          start_time);
          }

          stall_reference_pose = current_loc_pose;
          stall_reference_left = io_.leftWheelPositionRad();
          stall_reference_right = io_.rightWheelPositionRad();
          stall_reference_time = io_.timeSeconds();
        }
      }
    }

    const double left_error = std::abs(left_target - io_.leftWheelPositionRad());
    const double right_error = std::abs(right_target - io_.rightWheelPositionRad());
    if (left_error <= config_.wheel_position_tolerance_rad &&
        right_error <= config_.wheel_position_tolerance_rad) {
      io_.stop();
      DriveResult result = makeDriveResult(true,
                                           false,
                                           false,
                                           distance_m,
                                           encoderTravelDistance(start_left, start_right),
                                           distance2D(start_pose, measuredPose()));
      std::ostringstream fields;
      fields << "success=1"
             << " requested=" << std::fixed << std::setprecision(4) << distance_m
             << " encoder_traveled=" << result.traveled_before_stop_m
             << " measured=" << result.measured_distance_m
             << " error=" << result.distance_error_m
             << " validation_warning=" << (result.validation_warning ? 1 : 0)
             << " duration=" << (io_.timeSeconds() - start_time);
      logEvent("drive_done", fields.str());
      return result;
    }

    if (io_.timeSeconds() - start_time > config_.max_drive_duration_s) {
      io_.stop();
      DriveResult result = makeDriveResult(false,
                                           false,
                                           false,
                                           distance_m,
                                           encoderTravelDistance(start_left, start_right),
                                           distance2D(start_pose, measuredPose()));
      std::ostringstream timeout_fields;
      timeout_fields << "requested=" << std::fixed << std::setprecision(4) << distance_m
                     << " encoder_traveled=" << result.traveled_before_stop_m
                     << " left_error=" << left_error
                     << " right_error=" << right_error;
      logEvent("drive_timeout", timeout_fields.str());

      std::ostringstream fields;
      fields << "success=0 reason=timeout"
             << " requested=" << std::fixed << std::setprecision(4) << distance_m
             << " encoder_traveled=" << result.traveled_before_stop_m
             << " measured=" << result.measured_distance_m
             << " error=" << result.distance_error_m
             << " duration=" << (io_.timeSeconds() - start_time);
      logEvent("drive_done", fields.str());
      return result;
    }
  }
}

MotionExecutor::DriveResult MotionExecutor::handleHoleDuringDrive(double requested_distance_m,
                                                                  double speed_mps,
                                                                  Pose2D start_pose,
                                                                  double start_left_rad,
                                                                  double start_right_rad)
{
  const Pose2D hole_pose = measuredPose();
  const double traveled = encoderTravelDistance(start_left_rad, start_right_rad);
  const SensorSnapshot snapshot = io_.sensorSnapshot();

  {
    std::ostringstream fields;
    fields << "requested=" << std::fixed << std::setprecision(4) << requested_distance_m
           << " traveled_before_stop=" << traveled
           << " floor_rgb=(" << snapshot.floor_r << "," << snapshot.floor_g << "," << snapshot.floor_b << ")"
           << " roll=" << snapshot.roll_rad
           << " distance_sensor=" << snapshot.distance_sensor_value
           << " distance_sensor_valid=" << (snapshot.distance_sensor_valid ? 1 : 0);
    logEvent("drive_hole_detected", fields.str());
  }

  cancelWheelTargetAtCurrentPosition();

  if (traveled > 0.0) {
    const bool was_returning = returning_from_hole_;
    returning_from_hole_ = true;
    driveDistanceAtSpeed(-traveled, speed_mps);
    returning_from_hole_ = was_returning;
    std::ostringstream fields;
    fields << "returned=" << std::fixed << std::setprecision(4) << traveled;
    logEvent("drive_hole_return_done", fields.str());
  }

  alignCardinal();

  return makeDriveResult(false,
                         true,
                         false,
                         requested_distance_m,
                         traveled,
                         distance2D(start_pose, hole_pose));
}

MotionExecutor::DriveResult MotionExecutor::handleStallDuringDrive(double requested_distance_m,
                                                                   double speed_mps,
                                                                   Pose2D start_pose,
                                                                   double start_left_rad,
                                                                   double start_right_rad,
                                                                   double start_time_s)
{
  const double traveled = encoderTravelDistance(start_left_rad, start_right_rad);
  cancelWheelTargetAtCurrentPosition();

  DriveResult result = makeDriveResult(false,
                                       false,
                                       true,
                                       requested_distance_m,
                                       traveled,
                                       distance2D(start_pose, measuredPose()));

  std::ostringstream fields;
  fields << "requested=" << std::fixed << std::setprecision(4) << requested_distance_m
         << " encoder_traveled=" << traveled
         << " measured=" << result.measured_distance_m
         << " stall_encoder_window=" << config_.stall_encoder_window_m
         << " stall_loc_epsilon=" << config_.stall_loc_translation_epsilon_m
         << " duration=" << (io_.timeSeconds() - start_time_s);
  logEvent("drive_stall_detected", fields.str());

  if (config_.stall_recovery_reverse_m > 0.0) {
    const bool was_recovering = recovering_from_stall_;
    recovering_from_stall_ = true;
    driveDistanceAtSpeed(-config_.stall_recovery_reverse_m, speed_mps);
    recovering_from_stall_ = was_recovering;
    result.recovery_performed = true;
    alignCardinal();
    std::ostringstream recovery_fields;
    recovery_fields << "reverse=" << std::fixed << std::setprecision(4)
                    << config_.stall_recovery_reverse_m;
    logEvent("drive_stall_recovery_done", recovery_fields.str());
  }

  std::ostringstream done_fields;
  done_fields << "success=0 reason=loc_stall"
              << " requested=" << std::fixed << std::setprecision(4) << requested_distance_m
              << " encoder_traveled=" << result.traveled_before_stop_m
              << " measured=" << result.measured_distance_m
              << " error=" << result.distance_error_m
              << " recovery=" << (result.recovery_performed ? 1 : 0)
              << " duration=" << (io_.timeSeconds() - start_time_s);
  logEvent("drive_done", done_fields.str());

  return result;
}

MotionExecutor::DriveResult MotionExecutor::makeDriveResult(bool success,
                                                            bool hole_detected,
                                                            bool blocked_detected,
                                                            double requested_distance_m,
                                                            double traveled_before_stop_m,
                                                            double measured_distance_m) const
{
  DriveResult result;
  result.success = success;
  result.hole_detected = hole_detected;
  result.blocked_detected = blocked_detected;
  result.requested_distance_m = requested_distance_m;
  result.traveled_before_stop_m = traveled_before_stop_m;
  result.measured_distance_m = measured_distance_m;
  result.distance_error_m = result.measured_distance_m - std::abs(requested_distance_m);
  result.validation_warning =
    std::abs(result.distance_error_m) > config_.distance_validation_warn_m;
  if (result.validation_warning) {
    std::ostringstream fields;
    fields << "requested=" << std::fixed << std::setprecision(4) << result.requested_distance_m
           << " measured=" << result.measured_distance_m
           << " encoder=" << result.traveled_before_stop_m
           << " error=" << result.distance_error_m;
    logEvent("distance_validation_warning", fields.str());
  }
  return result;
}

Pose2D MotionExecutor::measuredPose() const
{
  Pose2D pose;
  if (io_.localizedPose(pose)) {
    return pose;
  }
  return io_.pose();
}

double MotionExecutor::encoderTravelDistance(double start_left_rad, double start_right_rad) const
{
  const double left_delta = std::abs(io_.leftWheelPositionRad() - start_left_rad);
  const double right_delta = std::abs(io_.rightWheelPositionRad() - start_right_rad);
  return 0.5 * (left_delta + right_delta) * config_.wheel_radius_m;
}

void MotionExecutor::cancelWheelTargetAtCurrentPosition()
{
  const double left_position = io_.leftWheelPositionRad();
  const double right_position = io_.rightWheelPositionRad();
  io_.stop();
  io_.setWheelTargetPosition(left_position, right_position);
}

void MotionExecutor::logEvent(const std::string& event, const std::string& fields) const
{
  if (!config_.debug_logs || !config_.log_callback) {
    return;
  }

  std::string message = "ROBOT_EVENT node=legacy_motion event=" + event;
  if (!fields.empty()) {
    message += " " + fields;
  }
  config_.log_callback(message);
}

}  // namespace exploration_legacy
