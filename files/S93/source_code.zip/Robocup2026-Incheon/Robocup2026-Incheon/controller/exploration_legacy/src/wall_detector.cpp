#include "exploration_legacy/wall_detector.hpp"

#include <algorithm>
#include <cmath>
#include <limits>

#include "exploration_legacy/math.hpp"

namespace exploration_legacy {

namespace {

constexpr double kFallbackClearance = 10.0;

int selectedLayerBase(int size, int horizontal_resolution)
{
  if (horizontal_resolution <= 0) {
    return 0;
  }

  return size >= 3 * horizontal_resolution ? 2 * horizontal_resolution : 0;
}

int wrappedIndex(int index, int size)
{
  while (index < 0) {
    index += size;
  }
  return index % size;
}

bool validRange(double value)
{
  return std::isfinite(value) && value > 0.0;
}

double clampMin(double value)
{
  return std::max(0.0, value);
}

double poseFilteredClearance(const WallDetector::Config&, int)
{
  // If pose validation rejected every ray in this sector, the local LIDAR
  // observation is unknown, not open.  Returning the fallback sentinel keeps the
  // direction out of the open mask.  The old diagonal path returned
  // threshold+epsilon, which made an untrusted/filtered diagonal look open.
  return kFallbackClearance;
}

bool clearanceKnown(double value)
{
  return std::isfinite(value) && value < kFallbackClearance;
}

bool finitePose(const Pose2D& pose)
{
  return std::isfinite(pose.x) && std::isfinite(pose.y) && std::isfinite(pose.yaw);
}

Pose2D transformLocalPoint(const Pose2D& pose, double local_x, double local_y)
{
  Pose2D out;
  const double c = std::cos(pose.yaw);
  const double s = std::sin(pose.yaw);
  out.x = pose.x + local_x * c - local_y * s;
  out.y = pose.y + local_x * s + local_y * c;
  out.yaw = pose.yaw;
  return out;
}

}  // namespace

WallDetector::WallDetector()
  : WallDetector(Config{})
{
}

WallDetector::WallDetector(Config config)
  : config_(config)
{
}

const WallDetector::Config& WallDetector::config() const
{
  return config_;
}

int WallDetector::computeWallMask4(const SensorSnapshot& snapshot, Direction4 heading) const
{
  return computeWallMask8(snapshot, heading, 0.0, 0.0) & 0x0F;
}

int WallDetector::computeWallMask4(const SensorSnapshot& snapshot, Direction4 heading,
                                   double center_offset_x, double center_offset_y) const
{
  return computeWallMask8(snapshot, heading, center_offset_x, center_offset_y) & 0x0F;
}

int WallDetector::computeWallMask8(const SensorSnapshot& snapshot, Direction4 heading) const
{
  return computeWallMask8(snapshot, heading, 0.0, 0.0);
}

std::array<double, 8> WallDetector::correctedClearances(const SensorSnapshot& snapshot,
                                                       double center_offset_x,
                                                       double center_offset_y) const
{
  std::array<double, 8> clearances = measureLocalClearances(snapshot);

  if (!config_.correct_for_tile_center_offset) {
    return clearances;
  }

  // Clamp the offset so a bad localization spike can't massively open/close edges.
  const double max_off = std::max(0.0, config_.max_center_offset_m);
  double off_gx = std::isfinite(center_offset_x) ? center_offset_x : 0.0;
  double off_gy = std::isfinite(center_offset_y) ? center_offset_y : 0.0;
  const double off_mag = std::hypot(off_gx, off_gy);
  if (off_mag <= 1.0e-9) {
    return clearances;
  }
  if (max_off > 0.0 && off_mag > max_off) {
    const double scale = max_off / off_mag;
    off_gx *= scale;
    off_gy *= scale;
  }

  // Rotate the global (tile-frame) offset into the robot body frame: clearances
  // are measured along body-frame ray angles (ray 0 = +x body = robot forward).
  const double yaw = std::isfinite(snapshot.yaw) ? snapshot.yaw : 0.0;
  const double c = std::cos(yaw);
  const double s = std::sin(yaw);
  const double off_bx = c * off_gx + s * off_gy;
  const double off_by = -s * off_gx + c * off_gy;

  for (int local = 0; local < 8; ++local) {
    // A fallback / no-hit clearance is not a real measurement: do not shift it.
    if (clearances[local] >= kFallbackClearance) {
      continue;
    }
    const double angle = local < 4
      ? static_cast<double>(local) * (kPi / 2.0)
      : static_cast<double>(2 * (local - 4) + 1) * (kPi / 4.0);
    // Component of the robot offset along this direction. If the robot moved
    // toward the wall (+), the wall reads closer, so add it back to recover the
    // clearance as seen from the tile centre.
    const double along = off_bx * std::cos(angle) + off_by * std::sin(angle);
    clearances[local] = std::max(0.0, clearances[local] + along);
  }

  return clearances;
}

int WallDetector::computeWallMask8(const SensorSnapshot& snapshot, Direction4 heading,
                                   double center_offset_x, double center_offset_y) const
{
  const std::array<double, 8> clearances =
    correctedClearances(snapshot, center_offset_x, center_offset_y);
  const int heading_turns = static_cast<int>(heading);
  int mask = 0;

  for (int local = 0; local < 4; ++local) {
    if (clearanceKnown(clearances[local]) &&
        clearances[local] >= config_.wall_threshold_m) {
      const Direction8 global = rotateDirection(directionFromIndex(local), heading_turns);
      mask |= directionBit(global);
    }
  }

  for (int local = 4; local < 8; ++local) {
    if (clearanceKnown(clearances[local]) &&
        clearances[local] >= config_.diagonal_wall_threshold_m &&
        clearances[local] < 1.0) {
      const Direction8 global = rotateDirection(directionFromIndex(local), heading_turns);
      mask |= directionBit(global);
    }
  }

  return mask;
}

std::array<double, 8> WallDetector::measureLocalClearances(const SensorSnapshot& snapshot) const
{
  std::array<double, 8> clearances{};

  for (int i = 0; i < 8; ++i) {
    if (!snapshot.lidar_cloud_x.empty() && !snapshot.lidar_cloud_y.empty()) {
      clearances[i] = measureFromCloud(snapshot, i);
    } else {
      clearances[i] = measureFromRanges(snapshot, i);
    }
  }

  return clearances;
}

double WallDetector::measureFromCloud(const SensorSnapshot& snapshot, int local_direction) const
{
  const int h = snapshot.lidar_horizontal_resolution;
  const int cloud_size = std::min(snapshot.lidar_cloud_x.size(), snapshot.lidar_cloud_y.size());
  if (h <= 0 || cloud_size <= 0) {
    return kFallbackClearance;
  }

  const int base = selectedLayerBase(cloud_size, h);
  const int available = cloud_size - base;
  if (available <= 0) {
    return kFallbackClearance;
  }

  const int delta = std::max(0, config_.ray_delta);
  const int diagonal_delta = std::max(0, delta - 10);
  const int center = local_direction < 4
    ? (local_direction * h / 4)
    : ((2 * (local_direction - 4) + 1) * h / 8);
  const int spread = local_direction < 4 ? delta : diagonal_delta;

  double min_clearance = kFallbackClearance;
  bool pose_filtered_any_ray = false;
  const double radius2 = config_.robot_radius_m * config_.robot_radius_m;

  for (int offset = -spread; offset <= spread; ++offset) {
    const int ray = wrappedIndex(center + offset, h);
    if (ray >= available) {
      continue;
    }

    const int index = base + ray;
    const double x = snapshot.lidar_cloud_x[index];
    const double y = snapshot.lidar_cloud_y[index];
    if (!std::isfinite(x) || !std::isfinite(y)) {
      continue;
    }
    if (!rayPoseUseful(snapshot, x, y)) {
      pose_filtered_any_ray = true;
      continue;
    }

    double r = 1.0;
    double lateral = 0.0;

    if (local_direction == 0 || local_direction == 2) {
      r = std::abs(x);
      lateral = std::abs(y);
    } else if (local_direction == 1 || local_direction == 3) {
      r = std::abs(y);
      lateral = std::abs(x);
    } else {
      const double angle = (static_cast<double>(2 * (local_direction - 4) + 1) * kPi) / 4.0;
      r = std::sqrt(x * x + y * y);
      lateral = std::abs(x * std::cos(angle) + y * std::sin(angle));
    }

    double radius_adjustment = 0.0;
    if (lateral <= config_.robot_radius_m) {
      radius_adjustment = std::sqrt(std::max(0.0, radius2 - lateral * lateral));
    } else {
      r = 1.0;
    }

    min_clearance = std::min(min_clearance, clampMin(r - radius_adjustment));
  }

  if (min_clearance == kFallbackClearance && pose_filtered_any_ray) {
    return poseFilteredClearance(config_, local_direction);
  }

  return min_clearance;
}

double WallDetector::measureFromRanges(const SensorSnapshot& snapshot, int local_direction) const
{
  const int h = snapshot.lidar_horizontal_resolution;
  const int range_count = static_cast<int>(snapshot.lidar_ranges.size());
  if (h <= 0 || range_count <= 0) {
    return kFallbackClearance;
  }

  const int base = selectedLayerBase(range_count, h);
  const int available = range_count - base;
  if (available <= 0) {
    return kFallbackClearance;
  }

  const int delta = std::max(0, config_.ray_delta);
  const int diagonal_delta = std::max(0, delta - 10);
  const int center = local_direction < 4
    ? (local_direction * h / 4)
    : ((2 * (local_direction - 4) + 1) * h / 8);
  const int spread = local_direction < 4 ? delta : diagonal_delta;

  double min_range = kFallbackClearance;
  bool pose_filtered_any_ray = false;
  for (int offset = -spread; offset <= spread; ++offset) {
    const int ray = wrappedIndex(center + offset, h);
    if (ray >= available) {
      continue;
    }

    const float range = snapshot.lidar_ranges[base + ray];
    if (validRange(range)) {
      const double angle = kTwoPi * static_cast<double>(ray) / static_cast<double>(h);
      const double x = static_cast<double>(range) * std::cos(angle);
      const double y = static_cast<double>(range) * std::sin(angle);
      if (!rayPoseUseful(snapshot, x, y)) {
        pose_filtered_any_ray = true;
        continue;
      }
      min_range = std::min(min_range, static_cast<double>(range));
    }
  }

  if (min_range == kFallbackClearance && pose_filtered_any_ray) {
    return poseFilteredClearance(config_, local_direction);
  }

  return min_range;
}

bool WallDetector::rayPoseUseful(const SensorSnapshot& snapshot, double local_x, double local_y) const
{
  if (!config_.validate_rays_with_loc_pose ||
      !snapshot.loc_pose_valid ||
      config_.ray_pose_endpoint_tolerance_m <= 0.0 ||
      !finitePose(snapshot.pose) ||
      !finitePose(snapshot.loc_pose))
  {
    return true;
  }

  const Pose2D believed_endpoint = transformLocalPoint(snapshot.pose, local_x, local_y);
  const Pose2D loc_endpoint = transformLocalPoint(snapshot.loc_pose, local_x, local_y);
  const double endpoint_error = distance2D(believed_endpoint, loc_endpoint);
  return endpoint_error <= config_.ray_pose_endpoint_tolerance_m;
}

}  // namespace exploration_legacy
