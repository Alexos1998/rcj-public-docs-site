#include "exploration_legacy/planner.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <functional>
#include <limits>
#include <numeric>
#include <queue>
#include <tuple>
#include <vector>

#include "exploration_legacy/math.hpp"

namespace exploration_legacy {

namespace {

constexpr int kInfCost = std::numeric_limits<int>::max() / 4;
constexpr int kCardinalCost = 100;

int flatIndex(const LegacyGridMap& map, TileCoord tile)
{
  return tile.x * map.size() + tile.y;
}

TileCoord tileFromFlatIndex(int index, int size)
{
  return {index / size, index % size};
}

std::array<int, kDirectionCount8> headingOrder(Direction4 heading)
{
  const double heading_yaw = directionToYaw(heading);
  std::array<int, kDirectionCount8> order;
  std::iota(order.begin(), order.end(), 0);
  std::sort(order.begin(), order.end(), [heading_yaw](int a, int b) {
    const Direction8 da = directionFromIndex(a);
    const Direction8 db = directionFromIndex(b);
    const double ya = std::abs(angleDelta(directionToYaw(da), heading_yaw));
    const double yb = std::abs(angleDelta(directionToYaw(db), heading_yaw));
    if (ya != yb) {
      return ya < yb;
    }
    return a < b;
  });
  return order;
}

std::array<int, kDirectionCount8> directOrder(LegacyPlanner::DirectMode mode, Direction4 heading)
{
  std::array<int, kDirectionCount8> order = headingOrder(heading);
  if (mode == LegacyPlanner::DirectMode::Heading) {
    return order;
  }

  if (mode == LegacyPlanner::DirectMode::CardinalFirst) {
    std::array<int, kDirectionCount8> out{};
    int n = 0;
    for (const int index : order) {
      if (isCardinal(directionFromIndex(index))) {
        out[n++] = index;
      }
    }
    for (const int index : order) {
      if (!isCardinal(directionFromIndex(index))) {
        out[n++] = index;
      }
    }
    return out;
  }

  const int h = static_cast<int>(heading);
  const std::array<int, kDirectionCount4> turns =
    mode == LegacyPlanner::DirectMode::LeftHand
      ? std::array<int, kDirectionCount4>{-1, 0, 1, 2}
      : std::array<int, kDirectionCount4>{1, 0, -1, 2};

  std::array<int, kDirectionCount8> out{};
  int n = 0;
  for (const int turn : turns) {
    int index = (h + turn) % kDirectionCount4;
    if (index < 0) {
      index += kDirectionCount4;
    }
    out[n++] = index;
  }
  for (const int index : order) {
    if (index >= kDirectionCount4) {
      out[n++] = index;
    }
  }
  return out;
}

}  // namespace

LegacyPlanner::LegacyPlanner()
  : LegacyPlanner(Config{})
{
}

LegacyPlanner::LegacyPlanner(Config config)
  : config_(config)
{
}

const LegacyPlanner::Config& LegacyPlanner::config() const
{
  return config_;
}

LegacyPlanner::Decision LegacyPlanner::nextDecision(const LegacyGridMap& map, TileCoord current, Direction4 heading)
{
  Decision direct = directDfsDecision(map, current, heading);
  if (direct.has_target) {
    clearBacktrackingCache();
    return direct;
  }

  return backtrackingDecision(map, current);
}

bool LegacyPlanner::hasUnvisitedOpenNeighbor(const LegacyGridMap& map, TileCoord tile) const
{
  const int mask = map.mazeValue(tile);
  if (mask < 0) {
    return false;
  }

  for (int i = 0; i < kDirectionCount8; ++i) {
    const Direction8 direction = directionFromIndex(i);
    if ((mask & directionBit(direction)) == 0) {
      continue;
    }

    const TileCoord next = add(tile, tileDelta(direction));
    if (map.inBounds(next) && !map.blocked(next) && map.mazeValue(next) < 0) {
      return true;
    }
  }

  return false;
}

LegacyPlanner::Decision LegacyPlanner::directDfsDecision(const LegacyGridMap& map, TileCoord current, Direction4 heading) const
{
  Decision decision;
  if (!map.inBounds(current) || map.blocked(current)) {
    return decision;
  }

  const int mask = map.mazeValue(current) >= 0 ? map.mazeValue(current) : map.wallBits(current);
  const std::array<int, kDirectionCount8> order = directOrder(config_.direct_mode, heading);

  for (const int i : order) {
    const Direction8 direction = directionFromIndex(i);
    if ((mask & directionBit(direction)) == 0) {
      continue;
    }

    const TileCoord next = add(current, tileDelta(direction));
    if (!map.inBounds(next) || map.blocked(next)) {
      continue;
    }

    if (map.mazeValue(next) < 0) {
      decision.has_target = true;
      decision.target = next;
      decision.direction = direction;
      decision.backtracking = false;
      return decision;
    }
  }

  return decision;
}

LegacyPlanner::Decision LegacyPlanner::backtrackingDecision(const LegacyGridMap& map, TileCoord current) const
{
  Decision decision;
  if (!map.inBounds(current) || map.blocked(current)) {
    clearBacktrackingCache();
    return decision;
  }

  if (cachedBacktrackingDecision(map, current, decision)) {
    return decision;
  }

  const int size = map.size();
  const int total = size * size;
  ensureSearchStorage(total);

  ++dijkstra_stamp_;
  if (dijkstra_stamp_ <= 0) {
    std::fill(dijkstra_seen_stamp_.begin(), dijkstra_seen_stamp_.end(), 0);
    std::fill(dijkstra_closed_stamp_.begin(), dijkstra_closed_stamp_.end(), 0);
    dijkstra_stamp_ = 1;
  }

  auto touch = [&](int index) {
    if (dijkstra_seen_stamp_[index] != dijkstra_stamp_) {
      dijkstra_seen_stamp_[index] = dijkstra_stamp_;
      dijkstra_closed_stamp_[index] = 0;
      dijkstra_dist_[index] = kInfCost;
      dijkstra_parent_[index] = -1;
    }
  };

  using Node = std::tuple<int, int>;
  std::priority_queue<Node, std::vector<Node>, std::greater<Node>> queue;

  const int start_index = flatIndex(map, current);
  touch(start_index);
  dijkstra_dist_[start_index] = 0;
  queue.push({0, start_index});

  int target_index = -1;
  const int diagonal_cost = std::max(
    kCardinalCost,
    static_cast<int>(std::lround(config_.diagonal_backtracking_cost * kCardinalCost)));

  while (!queue.empty()) {
    const Node node = queue.top();
    queue.pop();

    const int d = std::get<0>(node);
    const int tile_index = std::get<1>(node);
    touch(tile_index);
    if (d != dijkstra_dist_[tile_index]) {
      continue;
    }
    if (dijkstra_closed_stamp_[tile_index] == dijkstra_stamp_) {
      continue;
    }
    dijkstra_closed_stamp_[tile_index] = dijkstra_stamp_;

    const TileCoord tile = tileFromFlatIndex(tile_index, size);
    if (tile != current && hasUnvisitedOpenNeighbor(map, tile)) {
      target_index = tile_index;
      break;
    }

    // Backtracking follows physically traversed edges plus mutually confirmed
    // shortcuts between two visited tiles (see LegacyGridMap::backtrackEdge).
    // Raw wallBits() toward unvisited tiles stays excluded: it is
    // observation-driven and may be cleared/reopened by LIDAR or Nav2, so it is
    // not a safe connectivity graph for a static arena.  Without the shortcuts
    // the traversed graph is mostly the DFS tree, and backtracking retraces the
    // exploration path instead of cutting across the visited region.
    for (int i = 0; i < kDirectionCount8; ++i) {
      const Direction8 direction = directionFromIndex(i);
      if (!map.backtrackEdge(tile, direction)) {
        continue;
      }

      const TileCoord next = add(tile, tileDelta(direction));
      if (!map.inBounds(next) || map.blocked(next)) {
        continue;
      }

      const int next_index = flatIndex(map, next);
      touch(next_index);
      if (dijkstra_closed_stamp_[next_index] == dijkstra_stamp_) {
        continue;
      }

      const int movement_cost = isCardinal(direction) ? kCardinalCost : diagonal_cost;
      const int new_dist = d + movement_cost;
      if (new_dist < dijkstra_dist_[next_index]) {
        dijkstra_dist_[next_index] = new_dist;
        dijkstra_parent_[next_index] = tile_index;
        queue.push({new_dist, next_index});
      }
    }
  }

  if (target_index < 0) {
    clearBacktrackingCache();
    return decision;
  }

  std::vector<TileCoord> reversed;
  int node = target_index;
  while (node >= 0 && node != start_index) {
    reversed.push_back(tileFromFlatIndex(node, size));
    node = dijkstra_parent_[node];
  }
  if (node != start_index || reversed.empty()) {
    clearBacktrackingCache();
    return decision;
  }

  cached_backtrack_path_.clear();
  cached_backtrack_path_.reserve(reversed.size() + 1U);
  cached_backtrack_path_.push_back(current);
  for (auto it = reversed.rbegin(); it != reversed.rend(); ++it) {
    cached_backtrack_path_.push_back(*it);
  }
  cached_backtrack_pos_ = 0U;

  if (cachedBacktrackingDecision(map, current, decision)) {
    return decision;
  }

  clearBacktrackingCache();
  return decision;
}

bool LegacyPlanner::cachedBacktrackingDecision(
  const LegacyGridMap& map,
  TileCoord current,
  Decision& decision) const
{
  if (cached_backtrack_path_.size() < 2U) {
    return false;
  }

  if (cached_backtrack_pos_ >= cached_backtrack_path_.size() ||
      cached_backtrack_path_[cached_backtrack_pos_] != current)
  {
    auto it = std::find(cached_backtrack_path_.begin(), cached_backtrack_path_.end(), current);
    if (it == cached_backtrack_path_.end()) {
      clearBacktrackingCache();
      return false;
    }
    cached_backtrack_pos_ = static_cast<std::size_t>(std::distance(cached_backtrack_path_.begin(), it));
  }

  if (cached_backtrack_pos_ + 1U >= cached_backtrack_path_.size()) {
    clearBacktrackingCache();
    return false;
  }

  const TileCoord final_target = cached_backtrack_path_.back();
  if (!map.inBounds(final_target) || map.blocked(final_target) ||
      !hasUnvisitedOpenNeighbor(map, final_target))
  {
    clearBacktrackingCache();
    return false;
  }

  const TileCoord next = cached_backtrack_path_[cached_backtrack_pos_ + 1U];
  if (!map.inBounds(next) || map.blocked(next)) {
    clearBacktrackingCache();
    return false;
  }

  const Direction8 direction = directionBetween(current, next);
  const TileCoord delta = tileDelta(direction);
  if (add(current, delta) != next) {
    clearBacktrackingCache();
    return false;
  }

  if (!map.backtrackEdge(current, direction)) {
    clearBacktrackingCache();
    return false;
  }

  decision.has_target = true;
  decision.target = next;
  decision.direction = direction;
  decision.backtracking = true;
  return true;
}

void LegacyPlanner::clearBacktrackingCache() const
{
  cached_backtrack_path_.clear();
  cached_backtrack_pos_ = 0U;
}

void LegacyPlanner::ensureSearchStorage(int total) const
{
  if (total <= 0) {
    return;
  }
  const std::size_t count = static_cast<std::size_t>(total);
  if (dijkstra_dist_.size() == count &&
      dijkstra_parent_.size() == count &&
      dijkstra_seen_stamp_.size() == count &&
      dijkstra_closed_stamp_.size() == count)
  {
    return;
  }

  dijkstra_dist_.assign(count, kInfCost);
  dijkstra_parent_.assign(count, -1);
  dijkstra_seen_stamp_.assign(count, 0);
  dijkstra_closed_stamp_.assign(count, 0);
  dijkstra_stamp_ = 0;
  clearBacktrackingCache();
}

}  // namespace exploration_legacy
