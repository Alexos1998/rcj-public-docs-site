#include "exploration_legacy/legacy_explorer.hpp"

#include <array>
#include <chrono>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <queue>
#include <limits>
#include <sstream>
#include <tuple>
#include <string>
#include <vector>

#include "exploration_legacy/math.hpp"

namespace exploration_legacy {

namespace {

using Clock = std::chrono::steady_clock;

std::string tileText(TileCoord tile)
{
  std::ostringstream out;
  out << "(" << tile.x << "," << tile.y << ")";
  return out.str();
}

std::string directionText(Direction8 direction)
{
  switch (direction) {
    case Direction8::North:
      return "N";
    case Direction8::East:
      return "E";
    case Direction8::South:
      return "S";
    case Direction8::West:
      return "W";
    case Direction8::NorthEast:
      return "NE";
    case Direction8::SouthEast:
      return "SE";
    case Direction8::SouthWest:
      return "SW";
    case Direction8::NorthWest:
      return "NW";
  }
  return "?";
}

std::string directionText(Direction4 direction)
{
  return directionText(toDirection8(direction));
}

bool maskOpen(int mask, Direction8 direction)
{
  return (mask & directionBit(direction)) != 0;
}

bool textContains(const std::string& text, const char* needle)
{
  return text.find(needle) != std::string::npos;
}

bool lowConfidenceReachabilityRejection(const ReachabilityResult& result)
{
  if (result.reachable) {
    return false;
  }

  // These are exactly the cases where two grids/costmaps can disagree by a few
  // millimetres or one pixel: boundary samples, unknown frontiers, or a sample
  // just outside the current rolling window.  Local LIDAR may rescue these.
  if (result.status == ReachabilityStatus::OutsideCostmap ||
      result.status == ReachabilityStatus::UnknownSpace) {
    return true;
  }

  if (result.status != ReachabilityStatus::Blocked) {
    return false;
  }

  return textContains(result.reason, "sample in blocked costmap cell") ||
         textContains(result.reason, "sample_in_blocked_costmap_cell") ||
         textContains(result.reason, "costmap boundary") ||
         textContains(result.reason, "pixel boundary");
}

double elapsedMs(Clock::time_point start)
{
  return std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}

int flatIndex(int size, TileCoord tile)
{
  return tile.x * size + tile.y;
}

int latticeIndex(int ix, int iy, int min_ix, int min_iy, int width)
{
  return (iy - min_iy) * width + (ix - min_ix);
}

std::string latticeNodeText(int ix, int iy)
{
  std::ostringstream out;
  out << "(" << ix << "," << iy << ")";
  return out.str();
}

std::string latticeToken(int value)
{
  std::ostringstream out;
  if (value < 0) {
    out << 'm' << -value;
  } else {
    out << 'p' << value;
  }
  return out.str();
}

double yawBetween(Pose2D from, Pose2D to)
{
  return normalizeAngle(std::atan2(to.y - from.y, to.x - from.x));
}

bool validParent(TileCoord tile)
{
  return tile.x >= 0 && tile.y >= 0;
}

bool shouldBlockOnlyTraversalEdge(
  const MotionExecutor::DriveResult& result,
  bool target_was_already_visited)
{
  // executeMove() returns blocked_detected before any wheel command when the
  // local movement graph/costmap vetoes this traversal. That is an edge
  // failure, not proof that the target tile center is globally blocked.
  if (result.blocked_detected &&
      result.validation_warning &&
      result.traveled_before_stop_m <= 1.0e-6 &&
      result.measured_distance_m <= 1.0e-6) {
    return true;
  }

  // If the robot is trying to return to a tile it already visited, a new
  // shortfall only proves this particular passage is bad/stale now. Do not
  // erase the tile from the DFS world model.
  if (target_was_already_visited) {
    return true;
  }

  // On the 0.06 m auxiliary graph, localization can lag while encoders report
  // that the wheel target was reached. Treat that as an edge-level failure.
  // A real hole still takes the separate tile_hole path.
  if (result.validation_warning && result.requested_distance_m > 1.0e-6) {
    const double encoder_fraction =
      result.traveled_before_stop_m / std::max(result.requested_distance_m, 1.0e-6);
    if (encoder_fraction >= 0.70 && result.measured_distance_m > 0.010) {
      return true;
    }
  }

  return false;
}

void blockTraversalEdge(
  LegacyGridMap& map,
  TileCoord from,
  TileCoord to,
  Direction8 direction)
{
  // A successfully traversed edge is permanent in the static arena.  A later
  // blocked/costmap reading is therefore a bad observation, not a topology
  // change. Never erase known backtracking connectivity.
  if (map.traversedEdge(from, direction) ||
      map.traversedEdge(to, oppositeDirection(direction)))
  {
    const int bit = directionBit(direction);
    map.orWallBits(from, bit);
    if (map.inBounds(to)) {
      map.orWallBits(to, oppositeDirectionBit(direction));
    }
    return;
  }

  const int bit = directionBit(direction);
  map.clearMazeBits(from, bit);
  map.clearWallBits(from, bit);

  if (map.inBounds(to)) {
    const int opposite_bit = oppositeDirectionBit(direction);
    map.clearMazeBits(to, opposite_bit);
    map.clearWallBits(to, opposite_bit);
  }
}

bool reachabilityInfrastructureFailure(ReachabilityStatus status)
{
  return status == ReachabilityStatus::CostmapUnavailable ||
         status == ReachabilityStatus::PlannerUnavailable ||
         status == ReachabilityStatus::Timeout ||
         status == ReachabilityStatus::InvalidCoordinate;
}

bool shouldPrintLegacyEventToTerminal(const std::string& event, const std::string& fields)
{
  if (event == "start_tile_set") {
    return true;
  }

  if (event == "tile_advanced") {
    return true;
  }

  if (event == "hole_blocked") {
    return true;
  }

  if (event == "reachability_fallback_accepted") {
    return true;
  }

  if (event == "exploration_complete_returning_to_start") {
    return true;
  }

  if (event == "return_path_built") {
    return true;
  }

  if (event == "return_step") {
    return true;
  }

  if (event == "finished_at_start") {
    return true;
  }

  if (event == "planner_decision" &&
      fields.find("backtracking=1") != std::string::npos)
  {
    return true;
  }

  return false;
}

}  // namespace

struct LegacyExplorer::MovementGraphPlan {
  bool selected = false;
  bool infrastructure_failure = false;
  int edges_checked = 0;
  int edges_accepted = 0;
  int edges_rejected = 0;
  int nodes_expanded = 0;
  std::vector<Pose2D> waypoints;
  ReachabilityResult result;
};

LegacyExplorer::LegacyExplorer(MotionExecutor& motion,
                               LegacyGridMap& map,
                               WallDetector& walls,
                               LegacyPlanner& planner,
                               Config config)
  : motion_(motion),
    map_(map),
    walls_(walls),
    planner_(planner),
    config_(config)
{
  resetEdgeVetoCache();
}

void LegacyExplorer::setReachabilityChecker(LegacyReachabilityChecker* checker)
{
  reachability_checker_ = checker;
}

void LegacyExplorer::reset()
{
  map_.reset();
  phase_ = Phase::Exploring;
  initialized_ = false;
  heading_ = Direction4::North;
  start_tile_ = {};
  start_tile_set_ = false;
  start_pose_ = {};
  start_pose_set_ = false;
  return_path_.clear();
  nav2_retry_not_before_ = {};
  resetEdgeVetoCache();
  last_event_ = "reset";
}

void LegacyExplorer::resetEdgeVetoCache()
{
  live_lidar_tile_ = {-1, -1};
  live_lidar_open_mask_ = 0;
  live_lidar_valid_ = false;

  const int total = map_.size() * map_.size();
  if (total <= 0) {
    edge_veto_bits_.clear();
    return;
  }
  edge_veto_bits_.assign(static_cast<std::size_t>(total), 0);
}

int LegacyExplorer::edgeVetoBits(TileCoord tile) const
{
  if (!map_.inBounds(tile)) {
    return 0;
  }
  const int total = map_.size() * map_.size();
  if (total <= 0 || edge_veto_bits_.size() != static_cast<std::size_t>(total)) {
    return 0;
  }
  return edge_veto_bits_[static_cast<std::size_t>(flatIndex(map_.size(), tile))];
}

bool LegacyExplorer::edgeVetoed(TileCoord tile, Direction8 direction) const
{
  return (edgeVetoBits(tile) & directionBit(direction)) != 0;
}

void LegacyExplorer::markEdgeVeto(TileCoord from, TileCoord to, Direction8 direction)
{
  // Traversed edges are permanent on the static map and may never become vetoed.
  if (map_.traversedEdge(from, direction) ||
      map_.traversedEdge(to, oppositeDirection(direction)))
  {
    return;
  }

  const int total = map_.size() * map_.size();
  if (total <= 0) {
    return;
  }
  if (edge_veto_bits_.size() != static_cast<std::size_t>(total)) {
    edge_veto_bits_.assign(static_cast<std::size_t>(total), 0);
  }
  if (map_.inBounds(from)) {
    edge_veto_bits_[static_cast<std::size_t>(flatIndex(map_.size(), from))] |= directionBit(direction);
  }
  if (map_.inBounds(to)) {
    edge_veto_bits_[static_cast<std::size_t>(flatIndex(map_.size(), to))] |= oppositeDirectionBit(direction);
  }
}

int LegacyExplorer::traversedEdgeBits(TileCoord tile) const
{
  return map_.traversedEdgeBits(tile);
}

void LegacyExplorer::markTraversedEdge(TileCoord from, TileCoord to, Direction8 direction)
{
  const int total = map_.size() * map_.size();
  if (total <= 0) {
    return;
  }
  if (edge_veto_bits_.size() != static_cast<std::size_t>(total)) {
    edge_veto_bits_.assign(static_cast<std::size_t>(total), 0);
  }

  const int forward_bit = directionBit(direction);
  const int reverse_bit = oppositeDirectionBit(direction);

  if (map_.inBounds(from)) {
    const std::size_t index = static_cast<std::size_t>(flatIndex(map_.size(), from));
    edge_veto_bits_[index] &= ~forward_bit;
  }
  if (map_.inBounds(to)) {
    const std::size_t index = static_cast<std::size_t>(flatIndex(map_.size(), to));
    edge_veto_bits_[index] &= ~reverse_bit;
  }

  map_.markTraversedEdge(from, to, direction);
}

bool LegacyExplorer::stepExploration(const SensorSnapshot& snapshot)
{
  if (phase_ == Phase::FinishedAtStart) {
    logEvent("step_skipped", "reason=already_finished");
    return false;
  }

  initializeHeading(snapshot);

  if (phase_ == Phase::ReturningToStart) {
    return stepReturnToStart();
  }

  const TileCoord current = map_.currentTile();
  {
    std::ostringstream fields;
    fields << "current=" << tileText(current)
           << " heading=" << directionText(heading_)
           << " yaw=" << std::fixed << std::setprecision(4) << snapshot.yaw
           << " initialized=" << (initialized_ ? 1 : 0);
    logEvent("step_begin", fields.str());
  }

  if (!map_.inBounds(current) || map_.blocked(current)) {
    phase_ = Phase::FinishedAtStart;
    std::ostringstream fields;
    fields << "reason=current_invalid_or_blocked"
           << " current=" << tileText(current)
           << " in_bounds=" << (map_.inBounds(current) ? 1 : 0)
           << " blocked=" << (map_.blocked(current) ? 1 : 0);
    logEvent("finished", fields.str());
    return false;
  }

  map_.markVisited(current);

  const auto walls_t0 = Clock::now();
  const std::array<double, 8> clearances = walls_.measureLocalClearances(snapshot);
  const WallDetector::Config& wall_config = walls_.config();

  // Offset of the robot from the current tile centre, in the legacy metric frame.
  // The LIDAR wall thresholds assume the robot is on the centre vertex; feeding
  // this offset lets the wall detector reconstruct the clearance as if measured
  // from the centre, so a slightly off-centre robot does not over-block (falsely
  // mark) open directions. Only meaningful with a valid localized pose.
  double wall_offset_x = 0.0;
  double wall_offset_y = 0.0;
  if (start_pose_set_ && snapshot.loc_pose_valid &&
      std::isfinite(snapshot.loc_pose.x) && std::isfinite(snapshot.loc_pose.y))
  {
    const Pose2D tile_center = targetPoseForTile(current, Direction8::North);
    wall_offset_x = snapshot.loc_pose.x - tile_center.x;
    wall_offset_y = snapshot.loc_pose.y - tile_center.y;
  }

  const int sensed_mask = config_.allow_diagonal
    ? walls_.computeWallMask8(snapshot, heading_, wall_offset_x, wall_offset_y)
    : walls_.computeWallMask4(snapshot, heading_, wall_offset_x, wall_offset_y);

  // Static-map precedence:
  //   * successfully traversed edges are permanently open;
  //   * vetoed, never-traversed edges stay closed;
  //   * all other edges use the current LIDAR/Nav2 union.
  const int traversed_mask = map_.traversedEdgeBits(current);
  const int authoritative_veto_mask = edgeVetoBits(current) & ~traversed_mask;
  const int effective_open_mask =
    (sensed_mask & ~authoritative_veto_mask) | traversed_mask;

  live_lidar_tile_ = current;
  live_lidar_open_mask_ = effective_open_mask;
  live_lidar_valid_ = true;

  map_.orWallBits(current, effective_open_mask);
  if (map_.mazeValue(current) < 0) {
    map_.setMazeValue(current, effective_open_mask);
  }
  if (config_.macro_tile_marking) {
    markMacroCompanions(current, effective_open_mask);
  }
  {
    std::ostringstream fields;
    fields << "phase=walls_sensed duration_ms=" << std::fixed << std::setprecision(3)
           << elapsedMs(walls_t0);
    logEvent("step_timing", fields.str());
  }

  {
    std::ostringstream fields;
    fields << "current=" << tileText(current)
           << " mask=0x" << std::hex << sensed_mask << std::dec
           << " effective_mask=0x" << std::hex << effective_open_mask << std::dec
           << " traversed_mask=0x" << std::hex << traversed_mask << std::dec
           << " veto_mask=0x" << std::hex << authoritative_veto_mask << std::dec
           << " allow_diagonal=" << (config_.allow_diagonal ? 1 : 0)
           << " front_open=" << (maskOpen(sensed_mask, toDirection8(heading_)) ? 1 : 0)
           << " right_open=" << (maskOpen(sensed_mask, rotateDirection(toDirection8(heading_), 1)) ? 1 : 0)
           << " left_open=" << (maskOpen(sensed_mask, rotateDirection(toDirection8(heading_), -1)) ? 1 : 0)
           << std::fixed << std::setprecision(4)
           << " front_clearance=" << clearances[0]
           << " right_clearance=" << clearances[1]
           << " back_clearance=" << clearances[2]
           << " left_clearance=" << clearances[3]
           << " ne_clearance=" << clearances[4]
           << " se_clearance=" << clearances[5]
           << " sw_clearance=" << clearances[6]
           << " nw_clearance=" << clearances[7]
           << " wall_threshold=" << wall_config.wall_threshold_m
           << " diagonal_threshold=" << wall_config.diagonal_wall_threshold_m
           << " robot_radius=" << wall_config.robot_radius_m
           << " ray_delta=" << wall_config.ray_delta
           << " center_offset_x=" << wall_offset_x
           << " center_offset_y=" << wall_offset_y
           << " center_offset_correction="
           << (wall_config.correct_for_tile_center_offset ? 1 : 0);
    logEvent("walls_sensed", fields.str());
  }

  // Nav2 is a second check for each direction rejected by the current LIDAR
  // observation. This must run even when another direction is already open.
  // Use the effective current observation rather than the accumulated maze.
  // It already includes permanent traversed edges and removes authoritative
  // vetoes, so neither LIDAR nor Nav2 can accidentally reverse those decisions.
  applyNav2ReachabilitySecondCheck(snapshot, current, effective_open_mask);

  const auto planner_t0 = Clock::now();
  LegacyPlanner::Decision decision = planner_.nextDecision(map_, current, heading_);
  {
    std::ostringstream fields;
    fields << "phase=planner_decision duration_ms=" << std::fixed << std::setprecision(3)
           << elapsedMs(planner_t0);
    logEvent("step_timing", fields.str());
  }
  if (!decision.has_target) {
    // If the live lidar sees openings but the accumulated legacy maze has had
    // its bits cleared by previous uncertain graph checks, do not prematurely
    // switch to return-to-start.  Reconcile the current tile once with the live
    // observation, but never reopen neighbors that are already known blocked or
    // holes.
    const int previous_mask = map_.mazeValue(current);
    int reopen_mask = 0;
    for (int i = 0; i < kDirectionCount8; ++i) {
      const Direction8 direction = directionFromIndex(i);
      const int bit = directionBit(direction);
      if ((live_lidar_open_mask_ & bit) == 0) {
        continue;
      }
      const TileCoord neighbor = add(current, tileDelta(direction));
      if (!map_.inBounds(neighbor) || map_.blocked(neighbor) || map_.hole(neighbor)) {
        continue;
      }
      reopen_mask |= bit;
    }

    const int refreshed_mask = (previous_mask < 0 ? 0 : previous_mask) | reopen_mask;
    bool retried_after_lidar_refresh = false;
    if (reopen_mask != 0 && refreshed_mask != previous_mask) {
      map_.setMazeValue(current, refreshed_mask);
      map_.orWallBits(current, reopen_mask);
      decision = planner_.nextDecision(map_, current, heading_);
      retried_after_lidar_refresh = true;

      std::ostringstream fields;
      fields << "current=" << tileText(current)
             << " previous_mask=0x" << std::hex << previous_mask
             << " sensed_mask=0x" << sensed_mask
             << " reopen_mask=0x" << reopen_mask
             << " veto_mask=0x" << edgeVetoBits(current)
             << " refreshed_mask=0x" << refreshed_mask << std::dec
             << " rescued=" << (decision.has_target ? 1 : 0);
      logEvent("planner_lidar_refresh", fields.str());
    }

    if (!decision.has_target) {
      if (current == start_tile_) {
        logEvent("exploration_complete_already_at_start", "current=" + tileText(current));
        finishAtStart("already_at_start");
        return false;
      }

      phase_ = Phase::ReturningToStart;
      {
        std::ostringstream fields;
        fields << "current=" << tileText(current)
               << " start=" << tileText(start_tile_)
               << " visited_count=" << map_.visitedCount()
               << " blocked_count=" << map_.blockedCount()
               << " hole_count=" << map_.holeCount()
               << " retried_after_lidar_refresh=" << (retried_after_lidar_refresh ? 1 : 0);
        logEvent("exploration_complete_returning_to_start", fields.str());
      }

      if (!buildReturnPathToStart()) {
        std::ostringstream fields;
        fields << "reason=missing_parent_or_no_bfs_path"
               << " current=" << tileText(current)
               << " start=" << tileText(start_tile_);
        logEvent("return_path_failed", fields.str());
        finishAtStart("return_path_unavailable");
        return false;
      }

      return stepReturnToStart();
    }
  }

  {
    std::ostringstream fields;
    fields << "current=" << tileText(current)
           << " target=" << tileText(decision.target)
           << " dir=" << directionText(decision.direction)
           << " backtracking=" << (decision.backtracking ? 1 : 0)
           << " target_visited=" << (map_.visited(decision.target) ? 1 : 0)
           << " target_blocked=" << (map_.blocked(decision.target) ? 1 : 0);
    logEvent("planner_decision", fields.str());
  }

  MotionExecutor::DriveResult move_result = executeMove(decision);
  {
    std::ostringstream fields;
    fields << "success=" << (move_result.success ? 1 : 0)
           << " hole=" << (move_result.hole_detected ? 1 : 0)
           << " current=" << tileText(current)
           << " target=" << tileText(decision.target)
           << " requested=" << std::fixed << std::setprecision(4) << move_result.requested_distance_m
           << " traveled_before_stop=" << move_result.traveled_before_stop_m
           << " measured=" << move_result.measured_distance_m
           << " error=" << move_result.distance_error_m
           << " validation_warning=" << (move_result.validation_warning ? 1 : 0);
    logEvent("move_result", fields.str());
  }

  // External abort (vision saw a reportable detection mid-edge): the robot
  // simply stopped. Do not touch the map/edges/visited state -- the controller
  // runs its classify-hold and we re-plan the same move on the next step.
  if (move_result.aborted) {
    setLastEvent("move_aborted_external");
    logEvent("move_aborted_external",
             "current=" + tileText(current) + " target=" + tileText(decision.target));
    return true;
  }

  const bool permanent_traversed_edge = previouslyTraversedForDecision(decision);

  if (move_result.hole_detected) {
    if (permanent_traversed_edge) {
      std::ostringstream fields;
      fields << "current=" << tileText(current)
             << " target=" << tileText(decision.target)
             << " dir=" << directionText(decision.direction)
             << " reading=hole"
             << " action=preserve_static_traversed_edge";
      logEvent("traversed_edge_rejection_ignored", fields.str());
      return true;
    }
    map_.markBlocked(decision.target);
    map_.markHole(decision.target);
    blockTraversalEdge(map_, current, decision.target, decision.direction);
    std::ostringstream fields;
    fields << "current=" << tileText(current)
           << " blocked_target=" << tileText(decision.target)
           << " dir=" << directionText(decision.direction)
           << " block_scope=tile_hole"
           << " traveled_before_stop=" << std::fixed << std::setprecision(4)
           << move_result.traveled_before_stop_m;
    logEvent("hole_blocked", fields.str());
    return true;
  }

  if (move_result.blocked_detected) {
    if (permanent_traversed_edge) {
      std::ostringstream fields;
      fields << "current=" << tileText(current)
             << " target=" << tileText(decision.target)
             << " dir=" << directionText(decision.direction)
             << " reading=blocked"
             << " action=preserve_static_traversed_edge";
      logEvent("traversed_edge_rejection_ignored", fields.str());
      return true;
    }
    const bool edge_only = shouldBlockOnlyTraversalEdge(move_result, map_.visited(decision.target));
    if (!edge_only) {
      map_.markBlocked(decision.target);
    } else {
      markEdgeVeto(current, decision.target, decision.direction);
    }
    blockTraversalEdge(map_, current, decision.target, decision.direction);
    std::ostringstream fields;
    fields << "current=" << tileText(current)
           << " blocked_target=" << tileText(decision.target)
           << " dir=" << directionText(decision.direction)
           << " block_scope=" << (edge_only ? "edge" : "tile")
           << " target_marked_blocked=" << (edge_only ? 0 : 1)
           << " traveled_before_stop=" << std::fixed << std::setprecision(4)
           << move_result.traveled_before_stop_m
           << " recovery=" << (move_result.recovery_performed ? 1 : 0);
    logEvent(edge_only ? "edge_blocked" : "motion_blocked", fields.str());
    if (edge_only) {
      // Keep the legacy terminal event name for existing grep/debug scripts, but
      // make it explicit that only the traversal edge was removed.
      logEvent("motion_blocked", fields.str());
    }
    return true;
  }

  if (!move_result.success) {
    logEvent("move_failed", "current=" + tileText(current) + " target=" + tileText(decision.target));
    return false;
  }

  if (!decision.backtracking) {
    map_.clearMazeBits(current, directionBit(decision.direction));
  }
  markTraversedEdge(current, decision.target, decision.direction);
  recordParentIfNeeded(decision.target, current);
  map_.setCurrentTile(decision.target);
  map_.markVisited(decision.target);

  {
    std::ostringstream fields;
    fields << "from=" << tileText(current)
           << " to=" << tileText(decision.target)
           << " heading=" << directionText(heading_)
           << " visited_count=" << map_.visitedCount()
           << " blocked_count=" << map_.blockedCount()
           << " hole_count=" << map_.holeCount();
    logEvent("tile_advanced", fields.str());
  }

  return true;
}

bool LegacyExplorer::finished() const
{
  return phase_ == Phase::FinishedAtStart;
}

bool LegacyExplorer::returningToStart() const
{
  return phase_ == Phase::ReturningToStart;
}

LegacyExplorer::Phase LegacyExplorer::phase() const
{
  return phase_;
}

const char* LegacyExplorer::phaseName() const
{
  switch (phase_) {
    case Phase::Exploring:
      return "exploring";
    case Phase::ReturningToStart:
      return "returning_to_start";
    case Phase::FinishedAtStart:
      return "finished_at_start";
  }
  return "unknown";
}

TileCoord LegacyExplorer::currentTile() const
{
  return map_.currentTile();
}

TileCoord LegacyExplorer::startTile() const
{
  return start_tile_;
}

int LegacyExplorer::returnRemaining() const
{
  return static_cast<int>(return_path_.size());
}

int LegacyExplorer::visitedCount() const
{
  return map_.visitedCount();
}

int LegacyExplorer::blockedCount() const
{
  return map_.blockedCount();
}

int LegacyExplorer::holeCount() const
{
  return map_.holeCount();
}

std::string LegacyExplorer::lastEvent() const
{
  return last_event_;
}

void LegacyExplorer::initializeHeading(const SensorSnapshot& snapshot)
{
  if (initialized_) {
    return;
  }

  heading_ = nearestCardinalDirection(snapshot.yaw);
  start_tile_ = map_.currentTile();
  start_tile_set_ = true;

  start_pose_ = snapshot.loc_pose_valid ? snapshot.loc_pose : snapshot.pose;
  start_pose_.yaw = snapshot.yaw;
  start_pose_set_ = true;

  {
    std::ostringstream fields;
    fields << "tile=" << tileText(start_tile_)
           << " pose_source=" << (snapshot.loc_pose_valid ? "localized" : "raw")
           << std::fixed << std::setprecision(4)
           << " start_x=" << start_pose_.x
           << " start_y=" << start_pose_.y
           << " start_yaw=" << start_pose_.yaw;
    logEvent("start_tile_set", fields.str());
  }

  initialized_ = true;
}

bool LegacyExplorer::stepReturnToStart()
{
  const TileCoord current = map_.currentTile();
  if (current == start_tile_) {
    finishAtStart("reached_start");
    return false;
  }

  if (return_path_.empty() && !buildReturnPathToStart()) {
    std::ostringstream fields;
    fields << "reason=missing_parent_or_no_bfs_path"
           << " current=" << tileText(current)
           << " start=" << tileText(start_tile_);
    logEvent("return_path_failed", fields.str());
    return false;
  }

  const TileCoord next = return_path_.front();
  return_path_.erase(return_path_.begin());
  LegacyPlanner::Decision decision;
  decision.has_target = true;
  decision.target = next;
  decision.direction = directionBetween(current, next);
  decision.backtracking = true;

  const MotionExecutor::DriveResult result = executeMove(decision);
  {
    std::ostringstream fields;
    fields << "success=" << (result.success ? 1 : 0)
           << " hole=" << (result.hole_detected ? 1 : 0)
           << " current=" << tileText(current)
           << " target=" << tileText(next)
           << " requested=" << std::fixed << std::setprecision(4) << result.requested_distance_m
           << " traveled_before_stop=" << result.traveled_before_stop_m
           << " measured=" << result.measured_distance_m
           << " error=" << result.distance_error_m
           << " validation_warning=" << (result.validation_warning ? 1 : 0);
    logEvent("move_result", fields.str());
  }

  // External abort during return-to-start: keep the return path intact (restore
  // the step we just popped) so we resume toward start after the classify-hold.
  if (result.aborted) {
    setLastEvent("return_aborted_external");
    logEvent("return_aborted_external",
             "from=" + tileText(current) + " to=" + tileText(next));
    return_path_.insert(return_path_.begin(), next);
    return true;
  }

  const bool permanent_traversed_edge = previouslyTraversedForDecision(decision);

  if (result.hole_detected) {
    if (permanent_traversed_edge) {
      std::ostringstream fields;
      fields << "current=" << tileText(current)
             << " target=" << tileText(next)
             << " dir=" << directionText(decision.direction)
             << " reading=hole"
             << " action=preserve_static_traversed_edge";
      logEvent("traversed_edge_rejection_ignored", fields.str());
      return_path_.insert(return_path_.begin(), next);
      return true;
    }
    map_.markBlocked(next);
    map_.markHole(next);
    blockTraversalEdge(map_, current, next, decision.direction);
    std::ostringstream fields;
    fields << "current=" << tileText(current)
           << " blocked_target=" << tileText(next)
           << " dir=" << directionText(decision.direction)
           << " block_scope=tile_hole"
           << " traveled_before_stop=" << std::fixed << std::setprecision(4)
           << result.traveled_before_stop_m;
    logEvent("hole_blocked", fields.str());
    return_path_.clear();
    return true;
  }

  if (result.blocked_detected) {
    if (permanent_traversed_edge) {
      std::ostringstream fields;
      fields << "current=" << tileText(current)
             << " target=" << tileText(next)
             << " dir=" << directionText(decision.direction)
             << " reading=blocked"
             << " action=preserve_static_traversed_edge";
      logEvent("traversed_edge_rejection_ignored", fields.str());
      return_path_.insert(return_path_.begin(), next);
      return true;
    }
    const bool edge_only = shouldBlockOnlyTraversalEdge(result, map_.visited(next));
    if (!edge_only) {
      map_.markBlocked(next);
    } else {
      markEdgeVeto(current, next, decision.direction);
    }
    blockTraversalEdge(map_, current, next, decision.direction);
    std::ostringstream fields;
    fields << "current=" << tileText(current)
           << " blocked_target=" << tileText(next)
           << " dir=" << directionText(decision.direction)
           << " block_scope=" << (edge_only ? "edge" : "tile")
           << " target_marked_blocked=" << (edge_only ? 0 : 1)
           << " traveled_before_stop=" << std::fixed << std::setprecision(4)
           << result.traveled_before_stop_m
           << " recovery=" << (result.recovery_performed ? 1 : 0);
    logEvent(edge_only ? "edge_blocked" : "motion_blocked", fields.str());
    if (edge_only) {
      logEvent("motion_blocked", fields.str());
    }
    return_path_.clear();
    return true;
  }

  if (!result.success) {
    return_path_.clear();
    logEvent("return_step_failed", "from=" + tileText(current) + " to=" + tileText(next));
    return true;
  }

  markTraversedEdge(current, next, decision.direction);
  map_.setCurrentTile(next);
  std::ostringstream fields;
  fields << "from=" << tileText(current)
         << " to=" << tileText(next)
         << " dir=" << directionText(decision.direction)
         << " remaining=" << return_path_.size();
  logEvent("return_step", fields.str());

  if (next == start_tile_) {
    finishAtStart("reached_start");
    return false;
  }

  return true;
}

bool LegacyExplorer::buildReturnPathToStart()
{
  const TileCoord current = map_.currentTile();
  return_path_.clear();
  if (current == start_tile_) {
    return true;
  }

  // Prefer the shortest path over the known connectivity graph.  The parent
  // chain is the raw DFS discovery path and can be dramatically longer, so it
  // is only a fallback when BFS cannot connect current to start.
  if (!buildReturnPathByBfs(current) && !buildReturnPathFromParents(current)) {
    return false;
  }

  std::ostringstream fields;
  fields << "length=" << return_path_.size()
         << " current=" << tileText(current)
         << " start=" << tileText(start_tile_);
  logEvent("return_path_built", fields.str());
  return true;
}

bool LegacyExplorer::buildReturnPathFromParents(TileCoord current)
{
  std::vector<TileCoord> path;
  TileCoord tile = current;
  int guard = map_.size() * map_.size();

  while (tile != start_tile_ && guard-- > 0) {
    const TileCoord parent = map_.parent(tile);
    if (!validParent(parent) || !map_.inBounds(parent) || map_.blocked(parent)) {
      return_path_.clear();
      return false;
    }
    const Direction8 direction = directionBetween(tile, parent);
    if (add(tile, tileDelta(direction)) != parent ||
        !map_.traversedEdge(tile, direction))
    {
      return_path_.clear();
      return false;
    }
    path.push_back(parent);
    tile = parent;
  }

  if (tile != start_tile_) {
    return false;
  }

  return_path_ = path;
  return true;
}

bool LegacyExplorer::buildReturnPathByBfs(TileCoord current)
{
  const int size = map_.size();
  const int total = size * size;
  std::vector<int> seen(total, 0);
  std::vector<TileCoord> parent(total, {-1, -1});
  std::queue<TileCoord> queue;

  seen[flatIndex(size, current)] = 1;
  queue.push(current);

  while (!queue.empty()) {
    const TileCoord tile = queue.front();
    queue.pop();
    if (tile == start_tile_) {
      break;
    }

    const int direction_count = config_.allow_diagonal ? kDirectionCount8 : kDirectionCount4;
    for (int i = 0; i < direction_count; ++i) {
      const Direction8 direction = directionFromIndex(i);
      if (!map_.backtrackEdge(tile, direction)) {
        continue;
      }
      const TileCoord next = add(tile, tileDelta(direction));
      if (!map_.inBounds(next) || !map_.visited(next) || map_.blocked(next) || map_.hole(next)) {
        continue;
      }

      const int next_index = flatIndex(size, next);
      if (seen[next_index]) {
        continue;
      }

      seen[next_index] = 1;
      parent[next_index] = tile;
      queue.push(next);
    }
  }

  if (!seen[flatIndex(size, start_tile_)]) {
    return false;
  }

  std::vector<TileCoord> reversed;
  TileCoord tile = start_tile_;
  while (tile != current) {
    reversed.push_back(tile);
    tile = parent[flatIndex(size, tile)];
    if (!validParent(tile)) {
      return false;
    }
  }

  std::reverse(reversed.begin(), reversed.end());
  return_path_ = reversed;
  return true;
}

bool LegacyExplorer::applyNav2ReachabilitySecondCheck(
  const SensorSnapshot& snapshot,
  TileCoord current,
  int lidar_mask)
{
  if (!config_.nav2_reachability_fallback || reachability_checker_ == nullptr) {
    return false;
  }

  const auto now = Clock::now();
  if (now < nav2_retry_not_before_) {
    const auto remaining_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
      nav2_retry_not_before_ - now).count();
    std::ostringstream fields;
    fields << "mode=per_direction reason=infrastructure_cooldown"
           << " current=" << tileText(current)
           << " remaining_ms=" << remaining_ms;
    logEvent("reachability_fallback_skipped", fields.str());
    if (config_.debug_logs) {
      std::cerr << "[REACH DEBUG] NAV2 SKIPPED current=" << tileText(current)
                << " reason=infrastructure_cooldown"
                << " remaining_ms=" << remaining_ms
                << std::endl;
    }
    return false;
  }

  if (!snapshot.loc_pose_valid ||
      !std::isfinite(snapshot.loc_pose.x) ||
      !std::isfinite(snapshot.loc_pose.y))
  {
    logEvent(
      "reachability_fallback_skipped",
      "mode=per_direction reason=localized_pose_unavailable current=" + tileText(current));
    return false;
  }

  bool any_applied = false;
  int checked_count = 0;
  int accepted_count = 0;
  int applied_count = 0;
  const int direction_count = config_.allow_diagonal ? kDirectionCount8 : kDirectionCount4;

  if (config_.debug_logs) {
    std::cerr << "[REACH DEBUG] SECOND CHECK current=" << tileText(current)
              << " lidar_mask=0x" << std::hex << lidar_mask << std::dec
              << " directions=" << direction_count
              << std::endl;
  }

  for (int i = 0; i < direction_count; ++i) {
    const Direction8 direction = directionFromIndex(i);

    // The LIDAR already accepted this direction, so no second check is needed.
    if (maskOpen(lidar_mask, direction)) {
      continue;
    }

    const TileCoord target = add(current, tileDelta(direction));

    // Reachability is only useful here for unexplored neighboring tiles. Known,
    // blocked, or out-of-bounds tiles are handled by the legacy map/planner.
    if (!map_.inBounds(target) ||
        map_.blocked(target) ||
        map_.mazeValue(target) >= 0)
    {
      continue;
    }

    // A veto is authoritative only for an edge that has never been traversed.
    // This prevents the broad coordinate fallback from reopening the same edge
    // that the exact movement graph rejected on the previous cycle.
    if (edgeVetoed(current, direction) &&
        !map_.traversedEdge(current, direction))
    {
      std::ostringstream fields;
      fields << "mode=per_direction"
             << " current=" << tileText(current)
             << " target=" << tileText(target)
             << " dir=" << directionText(direction)
             << " reason=authoritative_untraversed_edge_veto";
      logEvent("reachability_fallback_skipped", fields.str());
      continue;
    }

    ++checked_count;

    const Pose2D target_pose = targetPoseForTile(target, direction);
    const double goal_x_m = target_pose.x;
    const double goal_y_m = target_pose.y;

    if (config_.debug_logs) {
      std::cerr << "[REACH DEBUG] NAV2 CHECK"
                << " current=" << tileText(current)
                << " target=" << tileText(target)
                << " direction=" << directionText(direction)
                << " start_map=(" << snapshot.loc_pose.x << "," << snapshot.loc_pose.y << ")"
                << " goal_map=(" << goal_x_m << "," << goal_y_m << ")"
                << std::endl;
    }

    const auto query_t0 = Clock::now();
    const ReachabilityResult result =
      reachability_checker_->canReachMapCoordinate(goal_x_m, goal_y_m);

    if (config_.debug_logs) {
      std::cerr << "[REACH DEBUG] NAV2 RESULT"
                << " target=" << tileText(target)
                << " direction=" << directionText(direction)
                << " reachable=" << (result.reachable ? 1 : 0)
                << " status=" << reachabilityStatusName(result.status)
                << " candidate="
                << (result.selected_candidate.empty() ? "none" : result.selected_candidate)
                << " reason=" << (result.reason.empty() ? "none" : result.reason)
                << std::endl;
    }

    {
      std::ostringstream fields;
      fields << "mode=per_direction"
             << " current=" << tileText(current)
             << " target=" << tileText(target)
             << " dir=" << directionText(direction)
             << " lidar_open=0"
             << " goal=(" << std::fixed << std::setprecision(4)
             << goal_x_m << "," << goal_y_m << ")"
             << " reachable=" << (result.reachable ? 1 : 0)
             << " status=" << reachabilityStatusName(result.status)
             << " candidate="
             << (result.selected_candidate.empty() ? "none" : result.selected_candidate)
             << " duration_ms=" << std::setprecision(3) << elapsedMs(query_t0)
             << " reason="
             << (result.reason.empty() ? "none" : percentEncode(result.reason));
      logEvent("reachability_fallback_check", fields.str());
    }

    if (result.reachable) {
      ++accepted_count;

      std::ostringstream fields;
      fields << "mode=per_direction"
             << " current=" << tileText(current)
             << " target=" << tileText(target)
             << " dir=" << directionText(direction)
             << " source=nav2"
             << " action="
             << (config_.nav2_reachability_apply_to_map ? "apply_to_map" : "compare_only");

      if (config_.nav2_reachability_apply_to_map) {
        if (edgeVetoed(current, direction) &&
            !map_.traversedEdge(current, direction))
        {
          fields << " suppressed_by=edge_veto";
          logEvent("reachability_fallback_suppressed", fields.str());
          continue;
        }
        const int bit = directionBit(direction);
        map_.orMazeBits(current, bit);
        map_.orWallBits(current, bit);
        any_applied = true;
        ++applied_count;
        logEvent("reachability_fallback_accepted", fields.str());

        if (config_.debug_logs) {
          std::cerr << "[REACH DEBUG] NAV2 ACCEPTED"
                    << " current=" << tileText(current)
                    << " target=" << tileText(target)
                    << " direction=" << directionText(direction)
                    << " bit=0x" << std::hex << bit
                    << " maze_mask=0x" << map_.mazeValue(current)
                    << " wall_mask=0x" << map_.wallBits(current)
                    << std::dec << std::endl;
        }
      } else {
        logEvent("reachability_fallback_compare_only", fields.str());

        if (config_.debug_logs) {
          std::cerr << "[REACH DEBUG] NAV2 COMPARE_ONLY"
                    << " current=" << tileText(current)
                    << " target=" << tileText(target)
                    << " direction=" << directionText(direction)
                    << " lidar_open=0"
                    << " reachable=1"
                    << std::endl;
        }
      }

      // Do not stop at the first accepted direction. Every other direction that
      // the LIDAR rejected still needs its own independent Nav2 second check.
      continue;
    }

    if (reachabilityInfrastructureFailure(result.status)) {
      nav2_retry_not_before_ = Clock::now() +
        config_.nav2_infrastructure_retry_cooldown;
      std::ostringstream fields;
      fields << "mode=per_direction"
             << " current=" << tileText(current)
             << " status=" << reachabilityStatusName(result.status)
             << " checked=" << checked_count
             << " accepted=" << accepted_count
             << " applied=" << applied_count
             << " reason="
             << (result.reason.empty() ? "none" : percentEncode(result.reason));
      logEvent("reachability_fallback_aborted", fields.str());
      if (config_.debug_logs) {
        std::cerr << "[REACH DEBUG] NAV2 ABORTED"
                  << " current=" << tileText(current)
                  << " status=" << reachabilityStatusName(result.status)
                  << " cooldown_ms="
                  << config_.nav2_infrastructure_retry_cooldown.count()
                  << " reason=" << (result.reason.empty() ? "none" : result.reason)
                  << std::endl;
      }
      return any_applied;
    }
  }

  if (checked_count > 0) {
    std::ostringstream fields;
    fields << "mode=per_direction"
           << " current=" << tileText(current)
           << " checked=" << checked_count
           << " accepted=" << accepted_count
           << " applied=" << applied_count;
    logEvent("reachability_fallback_summary", fields.str());
    if (config_.debug_logs) {
      std::cerr << "[REACH DEBUG] SECOND CHECK SUMMARY"
                << " current=" << tileText(current)
                << " checked=" << checked_count
                << " accepted=" << accepted_count
                << " applied=" << applied_count
                << std::endl;
    }
  }

  return any_applied;
}

MotionExecutor::DriveResult LegacyExplorer::executeMove(const LegacyPlanner::Decision& decision)
{
  MotionExecutor::DriveResult result;

  if (!start_pose_set_) {
    result.success = false;
    result.validation_warning = true;
    logEvent("move_failed", "reason=start_pose_not_set");
    return result;
  }

  const Pose2D target_pose = targetPoseForTile(decision.target, decision.direction);
  Pose2D current_pose = targetPoseForTile(map_.currentTile(), decision.direction);
  current_pose.yaw = directionToYaw(decision.direction);
  const int max_subdivision_level = std::max(1, config_.graph_subdivision);
  int selected_subdivision_level = 1;
  std::vector<Pose2D> selected_waypoints = movementWaypoints(current_pose, target_pose, 1);

  const bool previously_traversed = previouslyTraversedForDecision(decision);
  const bool live_lidar_open = liveLidarOpenForDecision(decision);
  if (previously_traversed) {
    selected_subdivision_level = max_subdivision_level;
    selected_waypoints = movementWaypoints(current_pose, target_pose, selected_subdivision_level);

    std::ostringstream fields;
    fields << "target_tile=" << tileText(decision.target)
           << " dir=" << directionText(decision.direction)
           << " reason=previously_traversed_edge"
           << " subdivision_level=" << selected_subdivision_level
           << " subgoals=" << selected_waypoints.size()
           << " traversed_mask=0x" << std::hex
           << traversedEdgeBits(map_.currentTile()) << std::dec
           << " costmap_graph=skipped";
    logEvent("movement_graph_skipped", fields.str());
  } else if (live_lidar_open) {
    selected_subdivision_level = max_subdivision_level;
    selected_waypoints = movementWaypoints(current_pose, target_pose, selected_subdivision_level);

    std::ostringstream fields;
    fields << "target_tile=" << tileText(decision.target)
           << " dir=" << directionText(decision.direction)
           << " reason=live_lidar_open_union"
           << " subdivision_level=" << selected_subdivision_level
           << " subgoals=" << selected_waypoints.size()
           << " live_mask=0x" << std::hex << live_lidar_open_mask_ << std::dec
           << " costmap_graph=skipped";
    logEvent("movement_graph_skipped", fields.str());
  } else if (reachability_checker_) {
    bool selected = false;
    bool infrastructure_failure = false;
    MovementGraphPlan last_plan;

    for (int level = 1; level <= max_subdivision_level; ++level) {
      const MovementGraphPlan plan = planMovementGraph(current_pose, target_pose, level);
      last_plan = plan;

      {
        std::ostringstream fields;
        fields << "target_tile=" << tileText(decision.target)
               << " dir=" << directionText(decision.direction)
               << " subdivision_level=" << level
               << " graph_nodes_expanded=" << plan.nodes_expanded
               << " graph_edges_checked=" << plan.edges_checked
               << " graph_edges_accepted=" << plan.edges_accepted
               << " graph_edges_rejected=" << plan.edges_rejected
               << " subgoals=" << plan.waypoints.size()
               << " step_m=" << std::fixed << std::setprecision(4)
               << (config_.tile_size_m / static_cast<double>(1 << (level - 1)))
               << " reachable=" << (plan.result.reachable ? 1 : 0)
               << " status=" << reachabilityStatusName(plan.result.status)
               << " candidate="
               << (plan.result.selected_candidate.empty() ? "none" : plan.result.selected_candidate)
               << " reason="
               << (plan.result.reason.empty() ? "none" : percentEncode(plan.result.reason));
        logEvent("movement_graph_check", fields.str());
      }

      if (plan.selected) {
        selected_subdivision_level = level;
        selected_waypoints = plan.waypoints;
        selected = true;
        break;
      }

      if (plan.infrastructure_failure) {
        infrastructure_failure = true;
        break;
      }
    }

    const bool costmap_low_confidence = lowConfidenceReachabilityRejection(last_plan.result);
    const bool lidar_tie_breaker_allowed = config_.lidar_overrides_costmap_block;
    const bool nav2_low_confidence_trial_allowed =
      config_.nav2_low_confidence_trial && costmap_low_confidence;
    const bool hard_reachability_rejection =
      last_plan.result.status == ReachabilityStatus::PlannerRejected ||
      last_plan.result.status == ReachabilityStatus::Timeout ||
      last_plan.result.status == ReachabilityStatus::InvalidCoordinate ||
      (last_plan.result.status == ReachabilityStatus::Blocked &&
       !lidar_tie_breaker_allowed &&
       !nav2_low_confidence_trial_allowed);

    if (!selected && nav2_low_confidence_trial_allowed && max_subdivision_level > 1) {
      selected_subdivision_level = max_subdivision_level;
      selected_waypoints = movementWaypoints(current_pose, target_pose, selected_subdivision_level);
      selected = true;

      std::ostringstream fields;
      fields << "target_tile=" << tileText(decision.target)
             << " dir=" << directionText(decision.direction)
             << " reason=nav2_low_confidence_trial"
             << " low_confidence=" << (costmap_low_confidence ? 1 : 0)
             << " infrastructure_failure=" << (infrastructure_failure ? 1 : 0)
             << " selected_subdivision_level=" << selected_subdivision_level
             << " subgoals=" << selected_waypoints.size()
             << " last_status=" << reachabilityStatusName(last_plan.result.status)
             << " last_reason="
             << (last_plan.result.reason.empty() ? "none" : percentEncode(last_plan.result.reason));
      logEvent("movement_graph_nav2_low_confidence_trial", fields.str());
    }

    if (!selected && lidar_tie_breaker_allowed && max_subdivision_level > 1) {
      selected_subdivision_level = max_subdivision_level;
      selected_waypoints = movementWaypoints(current_pose, target_pose, selected_subdivision_level);
      selected = true;

      std::ostringstream fields;
      fields << "target_tile=" << tileText(decision.target)
             << " dir=" << directionText(decision.direction)
             << " reason=lidar_overrides_costmap"
             << " low_confidence=" << (costmap_low_confidence ? 1 : 0)
             << " infrastructure_failure=" << (infrastructure_failure ? 1 : 0)
             << " selected_subdivision_level=" << selected_subdivision_level
             << " subgoals=" << selected_waypoints.size()
             << " last_status=" << reachabilityStatusName(last_plan.result.status)
             << " last_reason="
             << (last_plan.result.reason.empty() ? "none" : percentEncode(last_plan.result.reason));
      logEvent("movement_graph_lidar_override", fields.str());
    }

    if (!selected && !hard_reachability_rejection && max_subdivision_level > 1) {
      selected_subdivision_level = max_subdivision_level;
      selected_waypoints = movementWaypoints(current_pose, target_pose, selected_subdivision_level);
      selected = true;

      std::ostringstream fields;
      fields << "reason="
             << (infrastructure_failure
                   ? "reachability_infrastructure_unavailable"
                   : "movement_graph_not_confirmed_by_nav2")
             << " selected_subdivision_level=" << selected_subdivision_level
             << " subgoals=" << selected_waypoints.size()
             << " last_status=" << reachabilityStatusName(last_plan.result.status)
             << " last_reason="
             << (last_plan.result.reason.empty() ? "none" : percentEncode(last_plan.result.reason));
      logEvent("movement_graph_fallback_subdivision", fields.str());
    }

    if (!selected) {
      result.success = false;
      result.blocked_detected = true;
      result.requested_distance_m = distance2D(current_pose, target_pose);
      result.traveled_before_stop_m = 0.0;
      result.measured_distance_m = 0.0;
      result.distance_error_m = -result.requested_distance_m;
      result.validation_warning = true;

      std::ostringstream fields;
      fields << "target_tile=" << tileText(decision.target)
             << " dir=" << directionText(decision.direction)
             << " reason=movement_graph_hard_rejection_vetoed"
             << " max_subdivision_level=" << max_subdivision_level
             << " last_status=" << reachabilityStatusName(last_plan.result.status)
             << " last_reason="
             << (last_plan.result.reason.empty() ? "none" : percentEncode(last_plan.result.reason));
      logEvent("movement_graph_vetoed", fields.str());
      logEvent("move_failed", fields.str());
      return result;
    }
  }

  {
    std::ostringstream fields;
    fields << "target_tile=" << tileText(decision.target)
           << " dir=" << directionText(decision.direction)
           << " subdivision_level=" << selected_subdivision_level
           << " subgoals=" << selected_waypoints.size()
           << std::fixed << std::setprecision(4)
           << " target_x=" << target_pose.x
           << " target_y=" << target_pose.y
           << " target_yaw=" << target_pose.yaw;
    logEvent("motion_target_pose", fields.str());
  }

  const auto drive_t0 = Clock::now();
  for (std::size_t i = 0; i < selected_waypoints.size(); ++i) {
    {
      std::ostringstream fields;
      fields << "target_tile=" << tileText(decision.target)
             << " index=" << i
             << " count=" << selected_waypoints.size()
             << " subdivision_level=" << selected_subdivision_level
             << std::fixed << std::setprecision(4)
             << " target_x=" << selected_waypoints[i].x
             << " target_y=" << selected_waypoints[i].y
             << " target_yaw=" << selected_waypoints[i].yaw;
      logEvent("motion_subgoal_pose", fields.str());
    }

    result = motion_.driveToPose(selected_waypoints[i]);

    // Encoders may report that the wheel target was reached even when the
    // localized pose barely moved, which happens when the robot is physically
    // pushing into a wall or a too-narrow passage.  In that case the old code
    // only emitted validation_warning=1, but still advanced the tile.  Treat a
    // large negative distance error as a real blocked movement so the graph edge
    // is killed and the logical tile does not jump through the wall.
    const double critical_shortfall_m = std::max(0.025, config_.tile_size_m * 0.20);
    if (result.validation_warning && result.distance_error_m < -critical_shortfall_m) {
      result.success = false;
      result.blocked_detected = true;

      std::ostringstream fields;
      fields << "target_tile=" << tileText(decision.target)
             << " index=" << i
             << " count=" << selected_waypoints.size()
             << " subdivision_level=" << selected_subdivision_level
             << " reason=localized_motion_shortfall"
             << std::fixed << std::setprecision(4)
             << " requested=" << result.requested_distance_m
             << " measured=" << result.measured_distance_m
             << " error=" << result.distance_error_m
             << " critical_shortfall=" << critical_shortfall_m;
      logEvent("motion_validation_blocked", fields.str());
    }

    if (result.hole_detected || result.blocked_detected || !result.success) {
      break;
    }
  }
  {
    std::ostringstream fields;
    fields << "phase=drive_to_pose duration_ms=" << std::fixed << std::setprecision(3)
           << elapsedMs(drive_t0);
    logEvent("step_timing", fields.str());
  }

  if (result.hole_detected || result.blocked_detected || !result.success) {
    return result;
  }

  if (isDiagonal(decision.direction)) {
    heading_ = cardinalAfterDiagonal(decision.direction);

    const auto diagonal_align_t0 = Clock::now();
    if (!motion_.turnToYaw(directionToYaw(heading_))) {
      result.success = false;
      result.validation_warning = true;
      logEvent("move_failed", "reason=diagonal_cardinal_alignment_failed");
      return result;
    }

    {
      std::ostringstream fields;
      fields << "phase=turn duration_ms=" << std::fixed << std::setprecision(3)
             << elapsedMs(diagonal_align_t0)
             << " purpose=diagonal_cardinal_alignment";
      logEvent("step_timing", fields.str());
    }

    result.success = true;
    return result;
  }

  heading_ = static_cast<Direction4>(directionIndex(decision.direction));
  result.success = true;
  return result;
}

Pose2D LegacyExplorer::targetPoseForTile(TileCoord tile, Direction8 direction) const
{
  Pose2D target = start_pose_;

  const double delta_north_m =
    static_cast<double>(start_tile_.x - tile.x) * config_.tile_size_m;

  const double delta_east_m =
    static_cast<double>(tile.y - start_tile_.y) * config_.tile_size_m;

  target.x = start_pose_.x + delta_north_m;
  target.y = start_pose_.y - delta_east_m;
  target.yaw = directionToYaw(direction);

  return target;
}

std::vector<Pose2D> LegacyExplorer::movementWaypoints(
  Pose2D current_pose,
  Pose2D target_pose,
  int subdivision_level) const
{
  std::vector<Pose2D> waypoints;
  const int clamped_level = std::max(1, subdivision_level);
  const int segments = 1 << (clamped_level - 1);
  waypoints.reserve(static_cast<std::size_t>(segments));

  for (int i = 1; i <= segments; ++i) {
    const double u = static_cast<double>(i) / static_cast<double>(segments);
    Pose2D waypoint;
    waypoint.x = current_pose.x + (target_pose.x - current_pose.x) * u;
    waypoint.y = current_pose.y + (target_pose.y - current_pose.y) * u;
    waypoint.yaw = target_pose.yaw;
    waypoints.push_back(waypoint);
  }

  return waypoints;
}

LegacyExplorer::MovementGraphPlan LegacyExplorer::planMovementGraph(
  Pose2D current_pose,
  Pose2D target_pose,
  int subdivision_level) const
{
  MovementGraphPlan plan;
  plan.result.reachable = false;
  plan.result.status = ReachabilityStatus::Blocked;
  plan.result.selected_candidate = "local_graph";
  plan.result.reason = "local graph has no valid path";

  if (!reachability_checker_) {
    plan.selected = true;
    plan.result.reachable = true;
    plan.result.status = ReachabilityStatus::Reachable;
    plan.result.selected_candidate = "unchecked_local_graph";
    plan.result.reason = "reachability checker unavailable";
    plan.waypoints = movementWaypoints(current_pose, target_pose, subdivision_level);
    return plan;
  }

  const int level = std::max(1, subdivision_level);
  const int segments = 1 << (level - 1);
  const double step_m = config_.tile_size_m / static_cast<double>(segments);
  if (!(step_m > 0.0) ||
      !std::isfinite(step_m) ||
      !std::isfinite(current_pose.x) ||
      !std::isfinite(current_pose.y) ||
      !std::isfinite(target_pose.x) ||
      !std::isfinite(target_pose.y))
  {
    plan.result.status = ReachabilityStatus::InvalidCoordinate;
    plan.result.reason = "non-finite local graph geometry";
    return plan;
  }

  const int target_ix = static_cast<int>(std::llround((target_pose.x - current_pose.x) / step_m));
  const int target_iy = static_cast<int>(std::llround((target_pose.y - current_pose.y) / step_m));
  if (target_ix == 0 && target_iy == 0) {
    plan.result.status = ReachabilityStatus::InvalidCoordinate;
    plan.result.reason = "local graph target equals start";
    return plan;
  }

  // Level 1 is the historical direct edge.  Finer levels create a real local
  // lattice and allow a detour of one subcell around the center-line segment.
  const int margin_cells = level <= 1 ? 0 : 1;
  const int min_ix = std::min(0, target_ix) - margin_cells;
  const int max_ix = std::max(0, target_ix) + margin_cells;
  const int min_iy = std::min(0, target_iy) - margin_cells;
  const int max_iy = std::max(0, target_iy) + margin_cells;
  const int width = max_ix - min_ix + 1;
  const int height = max_iy - min_iy + 1;
  const int total = width * height;
  if (width <= 0 || height <= 0 || total <= 0 || total > 256) {
    plan.result.status = ReachabilityStatus::InvalidCoordinate;
    plan.result.reason = "invalid local graph dimensions";
    return plan;
  }

  auto inGraph = [&](int ix, int iy) {
    return ix >= min_ix && ix <= max_ix && iy >= min_iy && iy <= max_iy;
  };

  auto poseFor = [&](int ix, int iy) {
    Pose2D pose;
    pose.x = current_pose.x + static_cast<double>(ix) * step_m;
    pose.y = current_pose.y + static_cast<double>(iy) * step_m;
    pose.yaw = target_pose.yaw;
    if (ix == 0 && iy == 0) {
      pose.x = current_pose.x;
      pose.y = current_pose.y;
      pose.yaw = current_pose.yaw;
    } else if (ix == target_ix && iy == target_iy) {
      pose.x = target_pose.x;
      pose.y = target_pose.y;
      pose.yaw = target_pose.yaw;
    }
    return pose;
  };

  const int start_index = latticeIndex(0, 0, min_ix, min_iy, width);
  const int goal_index = latticeIndex(target_ix, target_iy, min_ix, min_iy, width);

  constexpr double kInf = 1.0e18;
  std::vector<double> dist(static_cast<std::size_t>(total), kInf);
  std::vector<int> parent(static_cast<std::size_t>(total), -1);
  std::vector<int> closed(static_cast<std::size_t>(total), 0);

  using QueueNode = std::tuple<double, int, int>;
  std::priority_queue<QueueNode, std::vector<QueueNode>, std::greater<QueueNode>> queue;
  dist[static_cast<std::size_t>(start_index)] = 0.0;
  queue.push({0.0, 0, 0});

  ReachabilityResult first_rejection = plan.result;

  const std::array<std::pair<int, int>, 8> deltas = {{{1, 0}, {-1, 0}, {0, 1}, {0, -1},
                                                       {1, 1}, {1, -1}, {-1, 1}, {-1, -1}}};

  while (!queue.empty()) {
    const auto [d, ix, iy] = queue.top();
    queue.pop();

    const int current_index = latticeIndex(ix, iy, min_ix, min_iy, width);
    if (d > dist[static_cast<std::size_t>(current_index)]) {
      continue;
    }
    if (closed[static_cast<std::size_t>(current_index)]) {
      continue;
    }
    closed[static_cast<std::size_t>(current_index)] = 1;
    ++plan.nodes_expanded;

    if (current_index == goal_index) {
      break;
    }

    for (const auto [dx, dy] : deltas) {
      const int nix = ix + dx;
      const int niy = iy + dy;
      if (!inGraph(nix, niy)) {
        continue;
      }

      const int next_index = latticeIndex(nix, niy, min_ix, min_iy, width);
      if (closed[static_cast<std::size_t>(next_index)]) {
        continue;
      }

      const Pose2D from_pose = poseFor(ix, iy);
      Pose2D to_pose = poseFor(nix, niy);
      to_pose.yaw = yawBetween(from_pose, to_pose);
      if (nix == target_ix && niy == target_iy) {
        to_pose.yaw = target_pose.yaw;
      }

      PathCandidate edge;
      std::ostringstream edge_name;
      edge_name << "local_graph_L" << level
                << "_" << latticeToken(ix) << "_" << latticeToken(iy)
                << "_to_" << latticeToken(nix) << "_" << latticeToken(niy);
      edge.name = edge_name.str();
      edge.waypoints = {{from_pose.x, from_pose.y}, {to_pose.x, to_pose.y}};

      ++plan.edges_checked;
      const ReachabilityResult edge_result = reachability_checker_->canReachPathCandidate(std::move(edge));
      if (!edge_result.reachable) {
        ++plan.edges_rejected;
        if (first_rejection.reason == "local graph has no valid path" ||
            edge_result.status == ReachabilityStatus::Blocked ||
            edge_result.status == ReachabilityStatus::PlannerRejected ||
            reachabilityInfrastructureFailure(edge_result.status))
        {
          first_rejection = edge_result;
        }
        if (reachabilityInfrastructureFailure(edge_result.status)) {
          plan.infrastructure_failure = true;
          plan.result = edge_result;
          return plan;
        }
        continue;
      }

      ++plan.edges_accepted;
      const double edge_cost = (dx != 0 && dy != 0) ? std::sqrt(2.0) * step_m : step_m;
      const double new_dist = d + edge_cost;
      if (new_dist < dist[static_cast<std::size_t>(next_index)]) {
        dist[static_cast<std::size_t>(next_index)] = new_dist;
        parent[static_cast<std::size_t>(next_index)] = current_index;
        queue.push({new_dist, nix, niy});
      }
    }
  }

  if (parent[static_cast<std::size_t>(goal_index)] < 0 && goal_index != start_index) {
    plan.result = first_rejection;
    if (plan.result.reason.empty() || plan.result.reason == "local graph has no valid path") {
      std::ostringstream reason;
      reason << "local graph has no path from " << latticeNodeText(0, 0)
             << " to " << latticeNodeText(target_ix, target_iy)
             << " at subdivision level " << level;
      plan.result.reason = reason.str();
    }
    return plan;
  }

  std::vector<int> reversed;
  int node = goal_index;
  while (node != start_index && node >= 0) {
    reversed.push_back(node);
    node = parent[static_cast<std::size_t>(node)];
  }
  if (node != start_index) {
    plan.result = first_rejection;
    plan.result.reason = "local graph parent chain is broken";
    return plan;
  }
  std::reverse(reversed.begin(), reversed.end());

  plan.waypoints.reserve(reversed.size());
  Pose2D previous = current_pose;
  for (const int index : reversed) {
    const int rel = index;
    const int iy = min_iy + rel / width;
    const int ix = min_ix + rel % width;
    Pose2D waypoint = poseFor(ix, iy);
    waypoint.yaw = yawBetween(previous, waypoint);
    if (index == goal_index) {
      waypoint.x = target_pose.x;
      waypoint.y = target_pose.y;
      waypoint.yaw = target_pose.yaw;
    }
    plan.waypoints.push_back(waypoint);
    previous = waypoint;
  }

  plan.selected = true;
  plan.result.reachable = true;
  plan.result.status = ReachabilityStatus::Reachable;
  plan.result.selected_candidate = "local_graph_L" + std::to_string(level);
  std::ostringstream reason;
  reason << "local graph path accepted edges=" << plan.edges_accepted
         << " checked=" << plan.edges_checked
         << " subgoals=" << plan.waypoints.size();
  plan.result.reason = reason.str();
  return plan;
}

ReachabilityResult LegacyExplorer::checkMovementWaypoints(
  Pose2D target_pose,
  const std::vector<Pose2D>& waypoints,
  int subdivision_level) const
{
  if (!reachability_checker_) {
    ReachabilityResult result;
    result.reachable = true;
    result.status = ReachabilityStatus::Reachable;
    result.selected_candidate = "unchecked";
    result.reason = "reachability checker unavailable";
    return result;
  }

  std::vector<MapPoint> intermediate;
  if (waypoints.size() > 1U) {
    intermediate.reserve(waypoints.size() - 1U);
    for (std::size_t i = 0; i + 1U < waypoints.size(); ++i) {
      intermediate.push_back({waypoints[i].x, waypoints[i].y});
    }
  }

  std::ostringstream name;
  name << "tile_subdivision_" << std::max(1, subdivision_level);
  return reachability_checker_->canReachMapWaypoints(
    target_pose.x,
    target_pose.y,
    intermediate,
    name.str());
}

bool LegacyExplorer::liveLidarOpenForDecision(const LegacyPlanner::Decision& decision) const
{
  if (!live_lidar_valid_ || live_lidar_tile_ != map_.currentTile()) {
    return false;
  }
  if ((live_lidar_open_mask_ & directionBit(decision.direction)) == 0) {
    return false;
  }
  if (isCardinal(decision.direction)) {
    return config_.trust_live_lidar_cardinal_edges;
  }
  return config_.trust_live_lidar_diagonal_edges;
}

bool LegacyExplorer::previouslyTraversedForDecision(const LegacyPlanner::Decision& decision) const
{
  const TileCoord current = map_.currentTile();
  if (!map_.inBounds(current) || !map_.inBounds(decision.target)) {
    return false;
  }
  if (add(current, tileDelta(decision.direction)) != decision.target) {
    return false;
  }

  const int forward_bit = directionBit(decision.direction);
  const int reverse_bit = oppositeDirectionBit(decision.direction);
  return (traversedEdgeBits(current) & forward_bit) != 0 ||
         (traversedEdgeBits(decision.target) & reverse_bit) != 0;
}

void LegacyExplorer::finishAtStart(const char* reason)
{
  phase_ = Phase::FinishedAtStart;
  motion_.stop();

  std::ostringstream fields;
  fields << "current=" << tileText(map_.currentTile())
         << " start=" << tileText(start_tile_)
         << " reason=" << reason
         << " visited_count=" << map_.visitedCount()
         << " blocked_count=" << map_.blockedCount()
         << " hole_count=" << map_.holeCount();
  logEvent("finished_at_start", fields.str());
}

void LegacyExplorer::markMacroCompanions(TileCoord t, int open_mask)
{
  const int ox = (t.x / 2) * 2;
  const int oy = (t.y / 2) * 2;
  const int dx = t.x - ox;
  const int dy = t.y - oy;

  struct Companion {
    TileCoord tile;
    Direction8 dir;
  };

  const Direction8 diag_dir =
    dx == 0
      ? (dy == 0 ? Direction8::SouthEast : Direction8::SouthWest)
      : (dy == 0 ? Direction8::NorthEast : Direction8::NorthWest);

  const Companion companions[3] = {
    {{ox + (1 - dx), oy + dy},       dx == 0 ? Direction8::South : Direction8::North},
    {{ox + dx,       oy + (1 - dy)}, dy == 0 ? Direction8::East  : Direction8::West},
    {{ox + (1 - dx), oy + (1 - dy)}, diag_dir},
  };

  for (const auto& c : companions) {
    if (!map_.inBounds(c.tile))             continue;
    if (map_.visited(c.tile))               continue;
    if (map_.blocked(c.tile))               continue;
    if (!(open_mask & directionBit(c.dir))) continue;
    map_.markVisited(c.tile);
    recordParentIfNeeded(c.tile, t);
    logEvent("macro_companion_marked",
             "from=" + tileText(t) + " companion=" + tileText(c.tile)
             + " dir=" + directionText(c.dir));
  }
}

void LegacyExplorer::recordParentIfNeeded(TileCoord child, TileCoord parent)
{
  if (!map_.inBounds(child) || !map_.inBounds(parent) || child == start_tile_) {
    return;
  }

  const TileCoord existing = map_.parent(child);
  if (!validParent(existing)) {
    map_.setParent(child, parent);
  }
}

void LegacyExplorer::logEvent(const std::string& event, const std::string& fields) const
{
  setLastEvent(event);
  if (!config_.debug_logs || !config_.log_callback) {
    return;
  }

  std::string message = "ROBOT_EVENT node=legacy_explorer event=" + event;

  if (shouldPrintLegacyEventToTerminal(event, fields)) {
    message += " terminal=1";
  }

  if (!fields.empty()) {
    message += " " + fields;
  }

  config_.log_callback(message);
}
void LegacyExplorer::setLastEvent(const std::string& event) const
{
  last_event_ = event;
}

}  // namespace exploration_legacy
