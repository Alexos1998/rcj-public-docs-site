#include "exploration_legacy/reachability.hpp"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <iomanip>
#include <limits>
#include <sstream>
#include <unordered_set>
#include <utility>

namespace exploration_legacy {

namespace {

constexpr const char* kResponsePrefix = "LEGACY_REACHABILITY_RESPONSE";
constexpr const char* kProtocolVersion = "1";

bool finitePoint(MapPoint p)
{
  return std::isfinite(p.x) && std::isfinite(p.y);
}

double segmentLength(PathSegment segment)
{
  const double dx = segment.end.x - segment.start.x;
  const double dy = segment.end.y - segment.start.y;
  return std::sqrt(dx * dx + dy * dy);
}

bool nearZero(double value, double tolerance)
{
  return std::abs(value) <= tolerance;
}

bool aligned45(MapPoint a, MapPoint b, double tolerance)
{
  const double dx = b.x - a.x;
  const double dy = b.y - a.y;
  return nearZero(dx, tolerance) ||
         nearZero(dy, tolerance) ||
         nearZero(std::abs(dx) - std::abs(dy), tolerance);
}

double signOf(double value)
{
  if (value > 0.0) {
    return 1.0;
  }
  if (value < 0.0) {
    return -1.0;
  }
  return 0.0;
}

std::string pointKey(MapPoint p, double tolerance)
{
  const double scale = tolerance > 0.0 ? 1.0 / tolerance : 1000000.0;
  std::ostringstream oss;
  oss << std::llround(p.x * scale) << ',' << std::llround(p.y * scale);
  return oss.str();
}

std::string candidateKey(const PathCandidate& candidate, double tolerance)
{
  std::ostringstream oss;
  oss << candidate.waypoints.size() << ':';
  for (const auto& point : candidate.waypoints) {
    oss << pointKey(point, tolerance) << ';';
  }
  return oss.str();
}

void appendCandidate(
  std::vector<PathCandidate>& out,
  std::unordered_set<std::string>& seen,
  PathCandidate candidate,
  const LegacyReachabilityChecker::Config& config)
{
  std::vector<MapPoint> clean;
  clean.reserve(candidate.waypoints.size());

  for (const auto& point : candidate.waypoints) {
    if (!finitePoint(point)) {
      return;
    }
    if (!clean.empty()) {
      const PathSegment segment{clean.back(), point};
      if (segmentLength(segment) <= config.min_segment_length_m) {
        continue;
      }
      if (!aligned45(segment.start, segment.end, config.alignment_tolerance_m)) {
        return;
      }
    }
    clean.push_back(point);
  }

  if (clean.size() < 2U) {
    return;
  }

  candidate.waypoints = std::move(clean);
  const auto key = candidateKey(candidate, std::max(config.alignment_tolerance_m, 1.0e-9));
  if (seen.insert(key).second) {
    out.push_back(std::move(candidate));
  }
}

std::vector<std::string> split(const std::string& text, char delimiter)
{
  std::vector<std::string> parts;
  std::stringstream ss(text);
  std::string item;
  while (std::getline(ss, item, delimiter)) {
    parts.push_back(item);
  }
  if (!text.empty() && text.back() == delimiter) {
    parts.emplace_back();
  }
  return parts;
}

bool parseDoubleStrict(const std::string& text, double& value)
{
  try {
    std::size_t parsed = 0;
    value = std::stod(text, &parsed);
    return parsed == text.size() && std::isfinite(value);
  } catch (...) {
    return false;
  }
}

bool worldToMapCell(const CostmapSnapshot& costmap, MapPoint point, int& mx, int& my)
{
  if (!costmap.valid || costmap.resolution_m <= 0.0 || !finitePoint(point)) {
    return false;
  }

  const double dx = point.x - costmap.origin_x_m;
  const double dy = point.y - costmap.origin_y_m;
  const double c = std::cos(costmap.origin_yaw_rad);
  const double s = std::sin(costmap.origin_yaw_rad);
  const double local_x = c * dx + s * dy;
  const double local_y = -s * dx + c * dy;

  mx = static_cast<int>(std::floor(local_x / costmap.resolution_m));
  my = static_cast<int>(std::floor(local_y / costmap.resolution_m));

  return mx >= 0 &&
         my >= 0 &&
         mx < static_cast<int>(costmap.width) &&
         my < static_cast<int>(costmap.height);
}

ReachabilityResult reject(ReachabilityStatus status, std::string candidate, std::string reason)
{
  ReachabilityResult result;
  result.reachable = false;
  result.status = status;
  result.selected_candidate = std::move(candidate);
  result.reason = std::move(reason);
  return result;
}

bool statusIsInfrastructure(ReachabilityStatus status)
{
  return status == ReachabilityStatus::CostmapUnavailable ||
         status == ReachabilityStatus::PlannerUnavailable ||
         status == ReachabilityStatus::Timeout ||
         status == ReachabilityStatus::InvalidCoordinate;
}

}  // namespace

LegacyReachabilityChecker::LegacyReachabilityChecker(
  Config config,
  PoseProvider pose_provider,
  QueryCallback query_callback)
: config_(std::move(config)),
  pose_provider_(std::move(pose_provider)),
  query_callback_(std::move(query_callback))
{
}

ReachabilityResult LegacyReachabilityChecker::canReachMapCoordinate(
  double goal_x_m,
  double goal_y_m) const
{
  if (!std::isfinite(goal_x_m) || !std::isfinite(goal_y_m)) {
    return reject(ReachabilityStatus::InvalidCoordinate, "", "goal coordinate is not finite");
  }
  if (!pose_provider_) {
    return reject(ReachabilityStatus::InvalidCoordinate, "", "no start pose provider configured");
  }

  const auto pose = pose_provider_();
  if (!pose.has_value() ||
      !std::isfinite(pose->x) ||
      !std::isfinite(pose->y) ||
      !std::isfinite(pose->yaw))
  {
    return reject(ReachabilityStatus::InvalidCoordinate, "", "localized start pose unavailable");
  }

  const MapPoint start{pose->x, pose->y};
  const MapPoint goal{goal_x_m, goal_y_m};
  const auto candidates = generateCandidates(start, goal, config_);
  if (candidates.empty()) {
    return reject(ReachabilityStatus::InvalidCoordinate, "", "no legacy-compatible candidate path");
  }
  if (!query_callback_) {
    return reject(ReachabilityStatus::PlannerUnavailable, "", "no external reachability query configured");
  }

  if (config_.log_callback) {
    std::ostringstream oss;
    oss << "ROBOT_EVENT node=legacy_reachability event=request_prepared"
        << " goal=(" << goal_x_m << "," << goal_y_m << ")"
        << " candidates=" << candidates.size();
    config_.log_callback(oss.str());
  }

  return query_callback_(pose.value(), goal_x_m, goal_y_m, candidates, config_.timeout);
}

ReachabilityResult LegacyReachabilityChecker::canReachMapWaypoints(
  double goal_x_m,
  double goal_y_m,
  const std::vector<MapPoint>& intermediate_waypoints,
  const std::string& candidate_name) const
{
  if (!std::isfinite(goal_x_m) || !std::isfinite(goal_y_m)) {
    return reject(ReachabilityStatus::InvalidCoordinate, candidate_name, "goal coordinate is not finite");
  }
  if (!pose_provider_) {
    return reject(ReachabilityStatus::InvalidCoordinate, candidate_name, "no start pose provider configured");
  }

  const auto pose = pose_provider_();
  if (!pose.has_value() ||
      !std::isfinite(pose->x) ||
      !std::isfinite(pose->y) ||
      !std::isfinite(pose->yaw))
  {
    return reject(ReachabilityStatus::InvalidCoordinate, candidate_name, "localized start pose unavailable");
  }
  if (!query_callback_) {
    return reject(ReachabilityStatus::PlannerUnavailable, candidate_name, "no external reachability query configured");
  }

  PathCandidate candidate;
  candidate.name = candidate_name.empty() ? "waypoints" : candidate_name;
  candidate.waypoints.reserve((intermediate_waypoints.size() + 2U) * 2U);
  candidate.waypoints.push_back({pose->x, pose->y});

  auto appendAlignedLeg = [&](MapPoint target) {
    const MapPoint current = candidate.waypoints.back();
    if (aligned45(current, target, config_.alignment_tolerance_m)) {
      candidate.waypoints.push_back(target);
      return;
    }

    const MapPoint x_then_y{target.x, current.y};
    candidate.waypoints.push_back(x_then_y);
    candidate.waypoints.push_back(target);
  };

  for (const auto& waypoint : intermediate_waypoints) {
    appendAlignedLeg(waypoint);
  }
  appendAlignedLeg({goal_x_m, goal_y_m});

  std::vector<PathCandidate> candidates;
  std::unordered_set<std::string> seen;
  appendCandidate(candidates, seen, std::move(candidate), config_);
  if (candidates.empty()) {
    return reject(ReachabilityStatus::InvalidCoordinate, candidate_name, "no legacy-compatible waypoint path");
  }

  if (config_.log_callback) {
    std::ostringstream oss;
    oss << "ROBOT_EVENT node=legacy_reachability event=request_prepared"
        << " goal=(" << goal_x_m << "," << goal_y_m << ")"
        << " candidates=" << candidates.size()
        << " mode=explicit_waypoints";
    config_.log_callback(oss.str());
  }

  return query_callback_(pose.value(), goal_x_m, goal_y_m, candidates, config_.timeout);
}

ReachabilityResult LegacyReachabilityChecker::canReachPathCandidate(PathCandidate candidate) const
{
  if (candidate.name.empty()) {
    candidate.name = "explicit_path";
  }
  if (candidate.waypoints.size() < 2U) {
    return reject(ReachabilityStatus::InvalidCoordinate, candidate.name, "candidate path has fewer than two points");
  }
  for (const auto& point : candidate.waypoints) {
    if (!finitePoint(point)) {
      return reject(ReachabilityStatus::InvalidCoordinate, candidate.name, "candidate path contains non-finite point");
    }
  }
  if (!pose_provider_) {
    return reject(ReachabilityStatus::InvalidCoordinate, candidate.name, "no start pose provider configured");
  }

  const auto pose = pose_provider_();
  if (!pose.has_value() ||
      !std::isfinite(pose->x) ||
      !std::isfinite(pose->y) ||
      !std::isfinite(pose->yaw))
  {
    return reject(ReachabilityStatus::InvalidCoordinate, candidate.name, "localized start pose unavailable");
  }
  if (!query_callback_) {
    return reject(ReachabilityStatus::PlannerUnavailable, candidate.name, "no external reachability query configured");
  }

  const MapPoint goal = candidate.waypoints.back();
  std::vector<PathCandidate> candidates;
  std::unordered_set<std::string> seen;
  appendCandidate(candidates, seen, std::move(candidate), config_);
  if (candidates.empty()) {
    return reject(ReachabilityStatus::InvalidCoordinate, "explicit_path", "candidate path is not legacy-compatible");
  }

  if (config_.log_callback) {
    std::ostringstream oss;
    oss << "ROBOT_EVENT node=legacy_reachability event=request_prepared"
        << " goal=(" << goal.x << "," << goal.y << ")"
        << " candidates=" << candidates.size()
        << " mode=explicit_path";
    config_.log_callback(oss.str());
  }

  return query_callback_(pose.value(), goal.x, goal.y, candidates, config_.timeout);
}

std::vector<PathCandidate> LegacyReachabilityChecker::generateCandidates(
  MapPoint start,
  MapPoint goal,
  const Config& config)
{
  std::vector<PathCandidate> candidates;
  std::unordered_set<std::string> seen;

  if (!finitePoint(start) || !finitePoint(goal)) {
    return candidates;
  }

  const double dx = goal.x - start.x;
  const double dy = goal.y - start.y;
  const double abs_dx = std::abs(dx);
  const double abs_dy = std::abs(dy);
  const double sx = signOf(dx);
  const double sy = signOf(dy);

  if (std::sqrt(dx * dx + dy * dy) <= config.min_segment_length_m) {
    return candidates;
  }

  if (aligned45(start, goal, config.alignment_tolerance_m)) {
    appendCandidate(candidates, seen, {"direct", {start, goal}}, config);
  }

  appendCandidate(candidates, seen, {"x_then_y", {start, {goal.x, start.y}, goal}}, config);
  appendCandidate(candidates, seen, {"y_then_x", {start, {start.x, goal.y}, goal}}, config);

  const double diagonal_distance = std::min(abs_dx, abs_dy);
  if (diagonal_distance > config.min_segment_length_m) {
    const MapPoint diagonal_mid{
      start.x + sx * diagonal_distance,
      start.y + sy * diagonal_distance};
    appendCandidate(
      candidates,
      seen,
      {"diagonal_then_axis", {start, diagonal_mid, goal}},
      config);
  }

  if (abs_dx >= abs_dy) {
    const double axis_distance = abs_dx - abs_dy;
    const MapPoint axis_mid{start.x + sx * axis_distance, start.y};
    appendCandidate(
      candidates,
      seen,
      {"axis_then_diagonal", {start, axis_mid, goal}},
      config);
  } else {
    const double axis_distance = abs_dy - abs_dx;
    const MapPoint axis_mid{start.x, start.y + sy * axis_distance};
    appendCandidate(
      candidates,
      seen,
      {"axis_then_diagonal", {start, axis_mid, goal}},
      config);
  }

  return candidates;
}

ReachabilityResult LegacyReachabilityChecker::evaluateCandidates(
  const std::vector<PathCandidate>& candidates,
  const CostmapSnapshot& costmap,
  const Config& config,
  const SegmentPlanner& planner)
{
  if (candidates.empty()) {
    return reject(ReachabilityStatus::InvalidCoordinate, "", "no candidates supplied");
  }
  if (config.use_planner_validation && !planner) {
    return reject(ReachabilityStatus::PlannerUnavailable, "", "planner callback unavailable");
  }

  ReachabilityResult first_rejection =
    reject(ReachabilityStatus::Blocked, candidates.front().name, "all candidates blocked");

  for (const auto& candidate : candidates) {
    const auto costmap_result = validateCandidateCostmap(candidate, costmap, config);
    if (!costmap_result.reachable) {
      if (config.log_callback) {
        std::ostringstream oss;
        oss << "ROBOT_EVENT node=legacy_reachability event=candidate_rejected"
            << " candidate=" << candidate.name
            << " stage=costmap_geometry"
            << " status=" << reachabilityStatusName(costmap_result.status)
            << " reason=" << percentEncode(costmap_result.reason);
        config.log_callback(oss.str());
      }
      if (first_rejection.reason == "all candidates blocked" ||
          statusIsInfrastructure(costmap_result.status))
      {
        first_rejection = costmap_result;
      }
      if (statusIsInfrastructure(costmap_result.status)) {
        return costmap_result;
      }
      continue;
    }

    if (!config.use_planner_validation) {
      ReachabilityResult result;
      result.reachable = true;
      result.status = ReachabilityStatus::Reachable;
      result.selected_candidate = candidate.name;
      result.reason = "candidate accepted by costmap geometry";
      if (config.log_callback) {
        std::ostringstream oss;
        oss << "ROBOT_EVENT node=legacy_reachability event=candidate_selected"
            << " candidate=" << candidate.name
            << " stage=costmap_geometry";
        config.log_callback(oss.str());
      }
      return result;
    }

    bool planner_ok = true;
    ReachabilityResult planner_rejection;
    for (const auto& segment : candidateSegments(candidate, config.min_segment_length_m)) {
      const auto planner_result = planner(segment);
      if (!planner_result.reachable) {
        planner_ok = false;
        planner_rejection = planner_result;
        planner_rejection.selected_candidate = candidate.name;
        if (planner_rejection.reason.empty()) {
          planner_rejection.reason = "planner rejected segment";
        }
        if (config.log_callback) {
          std::ostringstream oss;
          oss << "ROBOT_EVENT node=legacy_reachability event=candidate_rejected"
              << " candidate=" << candidate.name
              << " stage=planner"
              << " status=" << reachabilityStatusName(planner_rejection.status)
              << " reason=" << percentEncode(planner_rejection.reason);
          config.log_callback(oss.str());
        }
        break;
      }
    }

    if (planner_ok) {
      ReachabilityResult result;
      result.reachable = true;
      result.status = ReachabilityStatus::Reachable;
      result.selected_candidate = candidate.name;
      result.reason = "candidate accepted by costmap and planner";
      if (config.log_callback) {
        std::ostringstream oss;
        oss << "ROBOT_EVENT node=legacy_reachability event=candidate_selected"
            << " candidate=" << candidate.name
            << " stage=planner";
        config.log_callback(oss.str());
      }
      return result;
    }

    if (statusIsInfrastructure(planner_rejection.status)) {
      return planner_rejection;
    }
    first_rejection = planner_rejection;
  }

  return first_rejection;
}

ReachabilityResult LegacyReachabilityChecker::validateCandidateCostmap(
  const PathCandidate& candidate,
  const CostmapSnapshot& costmap,
  const Config& config)
{
  if (!costmap.valid ||
      costmap.resolution_m <= 0.0 ||
      costmap.width == 0U ||
      costmap.height == 0U ||
      costmap.data.size() != static_cast<std::size_t>(costmap.width) * costmap.height)
  {
    return reject(ReachabilityStatus::CostmapUnavailable, candidate.name, "costmap unavailable or malformed");
  }
  if (config.max_costmap_age_s > 0.0 && costmap.age_s > config.max_costmap_age_s) {
    return reject(ReachabilityStatus::CostmapUnavailable, candidate.name, "costmap is stale");
  }

  const auto segments = candidateSegments(candidate, config.min_segment_length_m);
  if (segments.empty()) {
    return reject(ReachabilityStatus::InvalidCoordinate, candidate.name, "candidate has no non-zero segments");
  }

  const double step =
    config.max_sample_step_m > 0.0 ?
    std::min(config.max_sample_step_m, costmap.resolution_m * 0.5) :
    costmap.resolution_m * 0.5;
  const double sample_step = std::max(step, costmap.resolution_m * 0.1);

  for (const auto& segment : segments) {
    if (!aligned45(segment.start, segment.end, config.alignment_tolerance_m)) {
      return reject(ReachabilityStatus::InvalidCoordinate, candidate.name, "segment is not 8-direction aligned");
    }

    const double length = segmentLength(segment);
    const int samples = std::max(1, static_cast<int>(std::ceil(length / sample_step)));
    for (int i = 0; i <= samples; ++i) {
      const double u = static_cast<double>(i) / static_cast<double>(samples);
      const MapPoint point{
        segment.start.x + (segment.end.x - segment.start.x) * u,
        segment.start.y + (segment.end.y - segment.start.y) * u};

      int mx = 0;
      int my = 0;
      if (!worldToMapCell(costmap, point, mx, my)) {
        return reject(ReachabilityStatus::OutsideCostmap, candidate.name, "sample outside costmap");
      }

      const auto index =
        static_cast<std::size_t>(my) * static_cast<std::size_t>(costmap.width) +
        static_cast<std::size_t>(mx);
      const int value = costmap.data[index];

      if (config.subgrid_occupancy_check) {
        // Footprint / sub-grid occupancy: scan a subgrid_cell_m patch of cells
        // around this sample instead of trusting the single centre cell. This
        // resolves an UNKNOWN centre using its 0.06 m neighbourhood and makes a
        // real wall anywhere in the footprint block (safer than a point sample).
        const double half = 0.5 * std::max(config.subgrid_cell_m, costmap.resolution_m);
        const int span = std::max(1, static_cast<int>(std::round(half / costmap.resolution_m)));
        bool any_lethal = false;
        bool any_free = false;
        for (int dy = -span; dy <= span && !any_lethal; ++dy) {
          for (int dx = -span; dx <= span; ++dx) {
            const int cx = mx + dx;
            const int cy = my + dy;
            if (cx < 0 || cy < 0 ||
                cx >= static_cast<int>(costmap.width) ||
                cy >= static_cast<int>(costmap.height)) {
              continue;
            }
            const int v = costmap.data[
              static_cast<std::size_t>(cy) * static_cast<std::size_t>(costmap.width) +
              static_cast<std::size_t>(cx)];
            if (v == config.unknown_value) {
              continue;
            }
            if (v >= config.lethal_threshold) {
              any_lethal = true;
              break;
            }
            any_free = true;
          }
        }
        if (any_lethal) {
          return reject(ReachabilityStatus::Blocked, candidate.name, "subgrid patch has a lethal cell");
        }
        // Centre known-free, or unknown centre resolved free by the patch.
        if (value != config.unknown_value || any_free) {
          continue;
        }
        // Whole patch unknown: fall through to the unknown-space policy.
        if (!config.allow_unknown) {
          return reject(ReachabilityStatus::UnknownSpace, candidate.name, "subgrid patch fully unknown");
        }
        continue;
      }

      if (value == config.unknown_value) {
        if (!config.allow_unknown) {
          return reject(ReachabilityStatus::UnknownSpace, candidate.name, "sample in unknown space");
        }
        continue;
      }
      if (value >= config.lethal_threshold) {
        return reject(ReachabilityStatus::Blocked, candidate.name, "sample in blocked costmap cell");
      }
    }
  }

  ReachabilityResult result;
  result.reachable = true;
  result.status = ReachabilityStatus::Reachable;
  result.selected_candidate = candidate.name;
  result.reason = "candidate clear in costmap";
  return result;
}

const char* reachabilityStatusName(ReachabilityStatus status)
{
  switch (status) {
    case ReachabilityStatus::Reachable:
      return "Reachable";
    case ReachabilityStatus::Blocked:
      return "Blocked";
    case ReachabilityStatus::OutsideCostmap:
      return "OutsideCostmap";
    case ReachabilityStatus::UnknownSpace:
      return "UnknownSpace";
    case ReachabilityStatus::CostmapUnavailable:
      return "CostmapUnavailable";
    case ReachabilityStatus::PlannerUnavailable:
      return "PlannerUnavailable";
    case ReachabilityStatus::PlannerRejected:
      return "PlannerRejected";
    case ReachabilityStatus::Timeout:
      return "Timeout";
    case ReachabilityStatus::InvalidCoordinate:
      return "InvalidCoordinate";
  }
  return "Blocked";
}

std::optional<ReachabilityStatus> reachabilityStatusFromName(const std::string& name)
{
  const ReachabilityStatus statuses[] = {
    ReachabilityStatus::Reachable,
    ReachabilityStatus::Blocked,
    ReachabilityStatus::OutsideCostmap,
    ReachabilityStatus::UnknownSpace,
    ReachabilityStatus::CostmapUnavailable,
    ReachabilityStatus::PlannerUnavailable,
    ReachabilityStatus::PlannerRejected,
    ReachabilityStatus::Timeout,
    ReachabilityStatus::InvalidCoordinate,
  };

  for (const auto status : statuses) {
    if (name == reachabilityStatusName(status)) {
      return status;
    }
  }
  return std::nullopt;
}

std::vector<PathSegment> candidateSegments(
  const PathCandidate& candidate,
  double min_segment_length_m)
{
  std::vector<PathSegment> segments;
  if (candidate.waypoints.size() < 2U) {
    return segments;
  }
  for (std::size_t i = 1; i < candidate.waypoints.size(); ++i) {
    PathSegment segment{candidate.waypoints[i - 1U], candidate.waypoints[i]};
    if (segmentLength(segment) > min_segment_length_m) {
      segments.push_back(segment);
    }
  }
  return segments;
}

std::string serializeCandidatePayload(const std::vector<PathCandidate>& candidates)
{
  std::ostringstream oss;
  oss << std::fixed << std::setprecision(6);
  for (std::size_t ci = 0; ci < candidates.size(); ++ci) {
    if (ci > 0U) {
      oss << '#';
    }
    oss << candidates[ci].name << ':';
    for (std::size_t pi = 0; pi < candidates[ci].waypoints.size(); ++pi) {
      if (pi > 0U) {
        oss << ';';
      }
      oss << candidates[ci].waypoints[pi].x << ',' << candidates[ci].waypoints[pi].y;
    }
  }
  return oss.str();
}

bool parseCandidatePayload(const std::string& payload, std::vector<PathCandidate>& candidates)
{
  candidates.clear();
  if (payload.empty() || payload.size() > 262144U) {
    return false;
  }

  for (const auto& candidate_text : split(payload, '#')) {
    const auto colon = candidate_text.find(':');
    if (colon == std::string::npos || colon == 0U || colon + 1U >= candidate_text.size()) {
      return false;
    }

    PathCandidate candidate;
    candidate.name = candidate_text.substr(0, colon);
    for (const auto ch : candidate.name) {
      if (!(std::isalnum(static_cast<unsigned char>(ch)) || ch == '_' || ch == '-')) {
        return false;
      }
    }

    const auto points_text = candidate_text.substr(colon + 1U);
    for (const auto& point_text : split(points_text, ';')) {
      const auto comma = point_text.find(',');
      if (comma == std::string::npos || comma == 0U || comma + 1U >= point_text.size()) {
        return false;
      }
      double x = 0.0;
      double y = 0.0;
      if (!parseDoubleStrict(point_text.substr(0, comma), x) ||
          !parseDoubleStrict(point_text.substr(comma + 1U), y))
      {
        return false;
      }
      candidate.waypoints.push_back({x, y});
    }

    if (candidate.waypoints.size() < 2U) {
      return false;
    }
    candidates.push_back(std::move(candidate));
  }

  return !candidates.empty();
}

std::string percentEncode(const std::string& text)
{
  std::ostringstream oss;
  oss << std::uppercase << std::hex << std::setfill('0');
  for (const unsigned char ch : text) {
    if (std::isalnum(ch) || ch == '_' || ch == '-' || ch == '.' || ch == '~') {
      oss << static_cast<char>(ch);
    } else {
      oss << '%' << std::setw(2) << static_cast<int>(ch);
    }
  }
  return oss.str();
}

std::string percentDecode(const std::string& text)
{
  std::string out;
  out.reserve(text.size());
  for (std::size_t i = 0; i < text.size(); ++i) {
    if (text[i] == '%' && i + 2U < text.size()) {
      const auto hex = text.substr(i + 1U, 2U);
      try {
        const auto value = static_cast<char>(std::stoi(hex, nullptr, 16));
        out.push_back(value);
        i += 2U;
        continue;
      } catch (...) {
      }
    }
    out.push_back(text[i]);
  }
  return out;
}

std::string serializeReachabilityResponse(
  std::uint64_t request_id,
  const ReachabilityResult& result)
{
  std::ostringstream oss;
  oss << kResponsePrefix << '|'
      << kProtocolVersion << '|'
      << request_id << '|'
      << (result.reachable ? 1 : 0) << '|'
      << reachabilityStatusName(result.status) << '|'
      << percentEncode(result.selected_candidate) << '|'
      << percentEncode(result.reason)
      << '\n';
  return oss.str();
}

bool parseReachabilityResponse(
  const std::string& line,
  std::uint64_t& request_id,
  ReachabilityResult& result)
{
  const auto fields = split(line, '|');
  if (fields.size() != 7U ||
      fields[0] != kResponsePrefix ||
      fields[1] != kProtocolVersion)
  {
    return false;
  }

  try {
    std::size_t parsed = 0;
    request_id = std::stoull(fields[2], &parsed);
    if (parsed != fields[2].size()) {
      return false;
    }
  } catch (...) {
    return false;
  }

  if (fields[3] != "0" && fields[3] != "1") {
    return false;
  }
  const auto status = reachabilityStatusFromName(fields[4]);
  if (!status.has_value()) {
    return false;
  }

  result.reachable = fields[3] == "1";
  result.status = status.value();
  result.selected_candidate = percentDecode(fields[5]);
  result.reason = percentDecode(fields[6]);
  return true;
}

}  // namespace exploration_legacy
