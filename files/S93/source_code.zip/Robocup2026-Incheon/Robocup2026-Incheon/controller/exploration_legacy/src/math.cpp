#include "exploration_legacy/math.hpp"

#include <cmath>
#include <limits>

namespace exploration_legacy {

namespace {

constexpr std::array<TileCoord, kDirectionCount8> kDeltas = {{
  {-1, 0},
  {0, 1},
  {1, 0},
  {0, -1},
  {-1, 1},
  {1, 1},
  {1, -1},
  {-1, -1},
}};

int positiveModulo(int value, int modulus)
{
  int result = value % modulus;
  return result < 0 ? result + modulus : result;
}

}  // namespace

double normalizeAngle(double angle_rad)
{
  while (angle_rad > kPi) {
    angle_rad -= kTwoPi;
  }
  while (angle_rad < -kPi) {
    angle_rad += kTwoPi;
  }
  return angle_rad;
}

double angleDelta(double target_rad, double current_rad)
{
  return normalizeAngle(target_rad - current_rad);
}

Direction4 nearestCardinalDirection(double yaw_rad)
{
  yaw_rad = normalizeAngle(yaw_rad);

  const double north_error = std::abs(angleDelta(directionToYaw(Direction4::North), yaw_rad));
  const double east_error = std::abs(angleDelta(directionToYaw(Direction4::East), yaw_rad));
  const double south_error = std::abs(angleDelta(directionToYaw(Direction4::South), yaw_rad));
  const double west_error = std::abs(angleDelta(directionToYaw(Direction4::West), yaw_rad));

  Direction4 best = Direction4::North;
  double best_error = north_error;

  if (east_error < best_error) {
    best = Direction4::East;
    best_error = east_error;
  }
  if (south_error < best_error) {
    best = Direction4::South;
    best_error = south_error;
  }
  if (west_error < best_error) {
    best = Direction4::West;
  }

  return best;
}

double directionToYaw(Direction4 direction)
{
  switch (direction) {
    case Direction4::North:
      return 0.0;
    case Direction4::East:
      return -kPi / 2.0;
    case Direction4::South:
      return kPi;
    case Direction4::West:
      return kPi / 2.0;
  }

  return 0.0;
}

double directionToYaw(Direction8 direction)
{
  switch (direction) {
    case Direction8::North:
      return directionToYaw(Direction4::North);
    case Direction8::East:
      return directionToYaw(Direction4::East);
    case Direction8::South:
      return directionToYaw(Direction4::South);
    case Direction8::West:
      return directionToYaw(Direction4::West);
    case Direction8::NorthEast:
      return -kPi / 4.0;
    case Direction8::SouthEast:
      return -3.0 * kPi / 4.0;
    case Direction8::SouthWest:
      return 3.0 * kPi / 4.0;
    case Direction8::NorthWest:
      return kPi / 4.0;
  }

  return 0.0;
}

Direction4 rotateDirection(Direction4 direction, int quarter_turns)
{
  const int index = positiveModulo(static_cast<int>(direction) + quarter_turns, kDirectionCount4);
  return static_cast<Direction4>(index);
}

Direction8 rotateDirection(Direction8 direction, int quarter_turns)
{
  const int index = static_cast<int>(direction);
  if (index < kDirectionCount4) {
    return toDirection8(rotateDirection(static_cast<Direction4>(index), quarter_turns));
  }

  const int diagonal_index = positiveModulo(index - kDirectionCount4 + quarter_turns, kDirectionCount4);
  return static_cast<Direction8>(kDirectionCount4 + diagonal_index);
}

Direction8 toDirection8(Direction4 direction)
{
  return static_cast<Direction8>(static_cast<int>(direction));
}

Direction4 cardinalAfterDiagonal(Direction8 direction)
{
  switch (direction) {
    case Direction8::NorthEast:
      return Direction4::North;
    case Direction8::SouthEast:
      return Direction4::East;
    case Direction8::SouthWest:
      return Direction4::South;
    case Direction8::NorthWest:
      return Direction4::West;
    case Direction8::North:
      return Direction4::North;
    case Direction8::East:
      return Direction4::East;
    case Direction8::South:
      return Direction4::South;
    case Direction8::West:
      return Direction4::West;
  }

  return Direction4::North;
}

bool isCardinal(Direction8 direction)
{
  return static_cast<int>(direction) < kDirectionCount4;
}

bool isDiagonal(Direction8 direction)
{
  return !isCardinal(direction);
}

TileCoord tileDelta(Direction4 direction)
{
  return kDeltas[static_cast<int>(direction)];
}

TileCoord tileDelta(Direction8 direction)
{
  return kDeltas[static_cast<int>(direction)];
}

const std::array<TileCoord, kDirectionCount8>& tileDeltas8()
{
  return kDeltas;
}

Direction8 directionBetween(TileCoord from, TileCoord to)
{
  const int dx = to.x - from.x;
  const int dy = to.y - from.y;

  for (int i = 0; i < kDirectionCount8; ++i) {
    if (kDeltas[i].x == dx && kDeltas[i].y == dy) {
      return static_cast<Direction8>(i);
    }
  }

  return Direction8::North;
}

Direction8 directionFromIndex(int index)
{
  if (index < 0 || index >= kDirectionCount8) {
    return Direction8::North;
  }
  return static_cast<Direction8>(index);
}

int directionIndex(Direction8 direction)
{
  return static_cast<int>(direction);
}

int directionBit(Direction8 direction)
{
  return 1 << directionIndex(direction);
}

int oppositeDirectionBit(Direction8 direction)
{
  return directionBit(oppositeDirection(direction));
}

Direction8 oppositeDirection(Direction8 direction)
{
  switch (direction) {
    case Direction8::North:
      return Direction8::South;
    case Direction8::East:
      return Direction8::West;
    case Direction8::South:
      return Direction8::North;
    case Direction8::West:
      return Direction8::East;
    case Direction8::NorthEast:
      return Direction8::SouthWest;
    case Direction8::SouthEast:
      return Direction8::NorthWest;
    case Direction8::SouthWest:
      return Direction8::NorthEast;
    case Direction8::NorthWest:
      return Direction8::SouthEast;
  }

  return Direction8::North;
}

double distance(TileCoord a, TileCoord b)
{
  const double dx = static_cast<double>(a.x - b.x);
  const double dy = static_cast<double>(a.y - b.y);
  return std::sqrt(dx * dx + dy * dy);
}

double distance2D(Pose2D a, Pose2D b)
{
  const double dx = a.x - b.x;
  const double dy = a.y - b.y;
  return std::sqrt(dx * dx + dy * dy);
}

TileCoord add(TileCoord tile, TileCoord delta)
{
  return {tile.x + delta.x, tile.y + delta.y};
}

}  // namespace exploration_legacy

