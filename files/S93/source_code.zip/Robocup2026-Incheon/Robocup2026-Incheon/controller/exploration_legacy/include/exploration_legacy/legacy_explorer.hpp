#pragma once

#include "exploration_legacy/grid_map.hpp"
#include "exploration_legacy/motion_executor.hpp"
#include "exploration_legacy/planner.hpp"
#include "exploration_legacy/reachability.hpp"
#include "exploration_legacy/types.hpp"
#include "exploration_legacy/wall_detector.hpp"

#include <chrono>
#include <vector>

namespace exploration_legacy {

class LegacyExplorer {
public:
  enum class Phase {
    Exploring,
    ReturningToStart,
    FinishedAtStart
  };

  struct Config {
    // Logical navigation graph spacing.  The current production mode uses a
    // single 0.06 m graph: cardinal edges are 0.06 m and diagonal edges are
    // 0.06*sqrt(2).  This avoids maintaining both a 0.12 tile graph and a
    // separate half-tile graph.
    double tile_size_m = 0.06;
    int graph_subdivision = 1;
    bool allow_diagonal = true;
    // Historical field name kept for environment/config compatibility. When enabled,
    // Nav2 is used as a per-direction second check for every LIDAR-blocked
    // unexplored neighbor, not only as a whole-tile fallback. By default this is
    // compare-only: LIDAR remains the source of truth for legacy entrances.
    bool nav2_reachability_fallback = true;
    // Layered edge clearing (freeing direction): when the LIDAR says a neighbor
    // edge is blocked but the costmap says it is reachable, OPEN the edge unless
    // that never-traversed edge already has an authoritative execution veto. This
    // is the "global costmap says free -> free" layer and recovers tiles the
    // robot never entered (event=reachability_fallback_compare_only in old logs,
    // where the costmap confirmed reachability but it was never applied). The
    // costmap query is served by the bridge (global costmap today; a local
    // costmap layer can OR-in there). Disable to restore compare-only behavior.
    // DISABLED BY DEFAULT after a crash run: opening a LIDAR-blocked edge purely
    // because the (possibly stale/misframed) costmap calls it free drove the
    // robot into real walls. Re-enable via LEGACY_REACHABILITY_APPLY_TO_MAP only
    // once the subgrid occupancy check below makes "free" trustworthy.
    bool nav2_reachability_apply_to_map = true;
    // Avoid hammering the bridge/Nav2 while lifecycle nodes or costmaps are
    // temporarily unavailable. LIDAR-only exploration continues during this
    // cooldown.
    std::chrono::milliseconds nav2_infrastructure_retry_cooldown{5000};
    // Do not auto-mark neighboring half-tile companions as visited.  The 0.06 m
    // graph already represents centers and midpoints directly, so companion
    // marking creates hidden state and can make the DFS skip reachable corners.
    bool macro_tile_marking = false;
    // Layered edge clearing (global costmap -> local costmap -> LIDAR). The
    // planner only proposes edges the LIDAR wall detector sees as open, and the
    // LIDAR is the final authority: a negative costmap verdict (blocked / stale /
    // unavailable) must NOT veto a LIDAR-open edge, it may only refine subgoals.
    // This recovers 0.06 m graph shortcuts that the inflated/stale global costmap
    // used to hard-reject (event=movement_graph_vetoed). Disable to restore the
    // old costmap-authoritative behavior.
    // DISABLED BY DEFAULT after a crash run: restore the original costmap veto in
    // executeMove. Re-enable via LEGACY_LIDAR_OVERRIDES_COSTMAP once the wall/
    // subgrid checks are trustworthy. (Original behavior: costmap Blocked vetoes.)
    // Full override keeps the old experimental behaviour and should normally stay off.
    bool lidar_overrides_costmap_block = false;
    // Keep full LIDAR override off by default: LIDAR should not overrule a
    // confident Nav2/costmap rejection.
    bool local_lidar_low_confidence_override = false;
    // Preferred mode: when Nav2/costmap rejects for a low-confidence reason
    // (single blocked pixel, boundary, unknown/frontier, rolling-window edge),
    // try the physical motion once. Failure removes only the traversal edge;
    // holes remain the only reason to mark the target tile itself blocked.
    bool nav2_low_confidence_trial = true;
    // Union rule for edges that have not yet received a definitive result:
    //   LIDAR open => the robot may try the edge; costmap cannot veto it.
    //   costmap/Nav2 open => the edge is opened even if this single LIDAR scan
    //   did not see it.
    // Static-map precedence is stronger than this union: a successfully
    // traversed edge remains permanently open for backtracking, while a failed
    // never-traversed edge remains vetoed and cannot be reopened by a later
    // LIDAR/Nav2 sample.
    bool trust_live_lidar_cardinal_edges = true;
    bool trust_live_lidar_diagonal_edges = true;
    bool debug_logs = true;
    LogCallback log_callback;
  };

  LegacyExplorer(MotionExecutor& motion,
                 LegacyGridMap& map,
                 WallDetector& walls,
                 LegacyPlanner& planner,
                 Config config);

  void setReachabilityChecker(LegacyReachabilityChecker* checker);
  void reset();
  bool stepExploration(const SensorSnapshot& snapshot);
  bool finished() const;
  bool returningToStart() const;
  Phase phase() const;
  const char* phaseName() const;
  TileCoord currentTile() const;
  TileCoord startTile() const;
  int returnRemaining() const;
  int visitedCount() const;
  int blockedCount() const;
  int holeCount() const;
  std::string lastEvent() const;

private:
  void initializeHeading(const SensorSnapshot& snapshot);
  bool stepReturnToStart();
  bool buildReturnPathToStart();
  bool buildReturnPathFromParents(TileCoord current);
  bool buildReturnPathByBfs(TileCoord current);
  bool applyNav2ReachabilitySecondCheck(const SensorSnapshot& snapshot,
                                         TileCoord current,
                                         int lidar_mask);
  MotionExecutor::DriveResult executeMove(const LegacyPlanner::Decision& decision);
  Pose2D targetPoseForTile(TileCoord tile, Direction8 direction) const;
  std::vector<Pose2D> movementWaypoints(
    Pose2D current_pose,
    Pose2D target_pose,
    int subdivision_level) const;
  struct MovementGraphPlan;
  MovementGraphPlan planMovementGraph(
    Pose2D current_pose,
    Pose2D target_pose,
    int subdivision_level) const;
  ReachabilityResult checkMovementWaypoints(
    Pose2D target_pose,
    const std::vector<Pose2D>& waypoints,
    int subdivision_level) const;
  bool liveLidarOpenForDecision(const LegacyPlanner::Decision& decision) const;
  bool previouslyTraversedForDecision(const LegacyPlanner::Decision& decision) const;
  void resetEdgeVetoCache();
  int edgeVetoBits(TileCoord tile) const;
  bool edgeVetoed(TileCoord tile, Direction8 direction) const;
  void markEdgeVeto(TileCoord from, TileCoord to, Direction8 direction);
  int traversedEdgeBits(TileCoord tile) const;
  void markTraversedEdge(TileCoord from, TileCoord to, Direction8 direction);
  void finishAtStart(const char* reason);
  void markMacroCompanions(TileCoord current, int open_mask);
  void recordParentIfNeeded(TileCoord child, TileCoord parent);
  void logEvent(const std::string& event, const std::string& fields = "") const;
  void setLastEvent(const std::string& event) const;

  MotionExecutor& motion_;
  LegacyGridMap& map_;
  WallDetector& walls_;
  LegacyPlanner& planner_;
  LegacyReachabilityChecker* reachability_checker_ = nullptr;
  Config config_;
  Phase phase_ = Phase::Exploring;
  bool initialized_ = false;
  Direction4 heading_ = Direction4::North;
  TileCoord start_tile_;
  bool start_tile_set_ = false;
  Pose2D start_pose_;
  bool start_pose_set_ = false;
  std::vector<TileCoord> return_path_;
  std::vector<int> edge_veto_bits_;
  TileCoord live_lidar_tile_{-1, -1};
  int live_lidar_open_mask_ = 0;
  bool live_lidar_valid_ = false;
  mutable std::string last_event_ = "created";
  std::chrono::steady_clock::time_point nav2_retry_not_before_{};
};

}  // namespace exploration_legacy
