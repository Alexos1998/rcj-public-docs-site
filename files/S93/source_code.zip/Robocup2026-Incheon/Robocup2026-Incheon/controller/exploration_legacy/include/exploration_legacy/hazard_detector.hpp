#pragma once

#include "exploration_legacy/types.hpp"

namespace exploration_legacy {

class HazardDetector {
public:
  struct Config {
    constexpr Config(int hole_target_rgb_1_value = 29,
                     int hole_target_rgb_2_value = 40,
                     int rgb_tolerance_value = 5,
                     double distance_sensor_hole_min_value = 0.25,
                     double distance_sensor_hole_max_value = 0.258,
                     double roll_hole_min_rad_value = -0.01,
                     int swamp_r_value = 204,
                     int swamp_g_value = 170,
                     int swamp_b_value = 97,
                     int checkpoint_r_value = 247,
                     int checkpoint_g_value = 247,
                     int checkpoint_b_value = 247,
                     int floor_color_tolerance_value = 5)
      : hole_target_rgb_1(hole_target_rgb_1_value),
        hole_target_rgb_2(hole_target_rgb_2_value),
        rgb_tolerance(rgb_tolerance_value),
        distance_sensor_hole_min(distance_sensor_hole_min_value),
        distance_sensor_hole_max(distance_sensor_hole_max_value),
        roll_hole_min_rad(roll_hole_min_rad_value),
        swamp_r(swamp_r_value),
        swamp_g(swamp_g_value),
        swamp_b(swamp_b_value),
        checkpoint_r(checkpoint_r_value),
        checkpoint_g(checkpoint_g_value),
        checkpoint_b(checkpoint_b_value),
        floor_color_tolerance(floor_color_tolerance_value)
    {
    }

    int hole_target_rgb_1;
    int hole_target_rgb_2;
    int rgb_tolerance;

    double distance_sensor_hole_min;
    double distance_sensor_hole_max;
    double roll_hole_min_rad;

    int swamp_r;
    int swamp_g;
    int swamp_b;
    int checkpoint_r;
    int checkpoint_g;
    int checkpoint_b;
    int floor_color_tolerance;
  };

  explicit HazardDetector(Config config = {});

  bool isHole(const SensorSnapshot& snapshot) const;
  bool isSwamp(const SensorSnapshot& snapshot) const;
  bool isCheckpoint(const SensorSnapshot& snapshot) const;

private:
  bool rgbNear(const SensorSnapshot& snapshot, int r, int g, int b, int tolerance) const;

  Config config_;
};

}  // namespace exploration_legacy
