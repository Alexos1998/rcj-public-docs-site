#pragma once

#include <vector>

#include "exploration_legacy/types.hpp"

namespace exploration_legacy {

enum class TileSemantic {
  Unknown = 0,
  Hole = 2,
  Swamp = 3,
  Checkpoint = 4
};

class LegacyGridMap {
public:
  struct RoomEntry {
    TileCoord tile;
    Direction4 heading = Direction4::North;
  };

  struct RoomState {
    int current_room = 1;
    int color_counter = 0;
    bool changed_room = false;
    TileCoord min_tile;
    TileCoord max_tile;
    std::vector<TileCoord> area4_tiles;
    std::vector<RoomEntry> area4_entries;
  };

  explicit LegacyGridMap(int size = 180);

  void reset();

  int size() const;
  TileCoord startTile() const;
  TileCoord currentTile() const;
  void setCurrentTile(TileCoord tile);

  TileCoord checkpointTile() const;
  void setCheckpointTile(TileCoord tile);

  bool inBounds(TileCoord tile) const;
  bool visited(TileCoord tile) const;
  void markVisited(TileCoord tile);

  void markBlocked(TileCoord tile);
  void clearBlocked(TileCoord tile);
  bool blocked(TileCoord tile) const;

  int mazeValue(TileCoord tile) const;
  void setMazeValue(TileCoord tile, int value);
  void orMazeBits(TileCoord tile, int bits);
  void clearMazeBits(TileCoord tile, int bits);

  int wallBits(TileCoord tile) const;
  void orWallBits(TileCoord tile, int bits);
  void clearWallBits(TileCoord tile, int bits);

  // Permanent topological connectivity learned from successful motion.  The
  // arena is static, so once an edge has been traversed successfully it remains
  // valid for backtracking even if a later LIDAR/costmap sample says otherwise.
  int traversedEdgeBits(TileCoord tile) const;
  bool traversedEdge(TileCoord tile, Direction8 direction) const;
  void markTraversedEdge(TileCoord from, TileCoord to, Direction8 direction);

  // Edge usable for backtracking between known tiles.  True for permanently
  // traversed edges, and also for shortcut edges where both endpoints were
  // physically visited and each side independently observed the passage open
  // (mutual wall bits).  Raw wallBits toward unvisited tiles stay excluded, so
  // this remains safe against speculative LIDAR/Nav2 openings while letting
  // backtracking cut across the visited region instead of retracing the DFS
  // tree.
  bool backtrackEdge(TileCoord from, Direction8 direction) const;

  bool swamp(TileCoord tile) const;
  void markSwamp(TileCoord tile);
  bool hole(TileCoord tile) const;
  void markHole(TileCoord tile);
  TileSemantic semantic(TileCoord tile) const;
  void setSemantic(TileCoord tile, TileSemantic semantic);

  bool victimFound(TileCoord tile) const;
  void markVictimFound(TileCoord tile);

  int visitedCount() const;
  int blockedCount() const;
  int holeCount() const;
  int knownCount() const;

  TileCoord parent(TileCoord tile) const;
  void setParent(TileCoord tile, TileCoord parent);
  void clearParents();

  RoomState& roomState();
  const RoomState& roomState() const;

private:
  int index(TileCoord tile) const;
  int valueOrDefault(const std::vector<int>& values, TileCoord tile, int fallback) const;

  int size_;
  TileCoord start_tile_;
  TileCoord current_tile_;
  TileCoord checkpoint_tile_;

  std::vector<int> maze_;
  std::vector<int> wallgrid_;
  std::vector<int> traversed_edges_;
  std::vector<int> swampmaze_;
  std::vector<int> semantic_;
  std::vector<int> blocked_;
  std::vector<unsigned char> visited_;
  std::vector<TileCoord> parent_;
  std::vector<unsigned char> found_victim_;
  RoomState room_state_;
};

}  // namespace exploration_legacy
