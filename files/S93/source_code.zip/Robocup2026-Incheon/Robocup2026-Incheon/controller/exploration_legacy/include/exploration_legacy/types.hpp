#pragma once

#include <functional>
#include <string>
#include <vector>

namespace exploration_legacy {

using LogCallback = std::function<void(const std::string&)>;

struct LegacyLogConfig {
  bool enabled = true;
  bool verbose = true;
};

struct Pose2D {
  double x = 0.0;
  double y = 0.0;
  double yaw = 0.0;
};

struct TileCoord {
  int x = 0;
  int y = 0;
};

inline bool operator==(TileCoord lhs, TileCoord rhs)
{
  return lhs.x == rhs.x && lhs.y == rhs.y;
}

inline bool operator!=(TileCoord lhs, TileCoord rhs)
{
  return !(lhs == rhs);
}

enum class Direction4 {
  North = 0,
  East = 1,
  South = 2,
  West = 3
};

enum class Direction8 {
  North = 0,
  East = 1,
  South = 2,
  West = 3,
  NorthEast = 4,
  SouthEast = 5,
  SouthWest = 6,
  NorthWest = 7
};

// Legacy masks preserve the old DFS semantics: a set bit means that direction
// is traversable/no wall, despite the historical wallgrid name.
struct WallMask {
  int bits = 0;
};

struct SensorSnapshot {
  Pose2D pose;
  Pose2D loc_pose;
  double yaw = 0.0;
  double roll_rad = 0.0;
  double pitch_rad = 0.0;
  bool loc_pose_valid = false;
  std::vector<float> lidar_ranges;
  std::vector<float> lidar_cloud_x;
  std::vector<float> lidar_cloud_y;
  int lidar_horizontal_resolution = 0;
  int floor_r = 0;
  int floor_g = 0;
  int floor_b = 0;
  double distance_sensor_value = 0.0;
  bool distance_sensor_valid = false;
};

}  // namespace exploration_legacy
