#pragma once

#include <array>

#include "exploration_legacy/types.hpp"

namespace exploration_legacy {

class WallDetector {
public:
  struct Config {
    double robot_radius_m = 0.037;
    double wall_threshold_m = 0.061;
    double diagonal_wall_threshold_m = 0.061 * 1.4142135623730951;
    double ray_pose_endpoint_tolerance_m = 0.018;
    int ray_delta = 64;
    bool validate_rays_with_loc_pose = false;
    // The wall threshold (~one tile) assumes the robot sits exactly on the tile
    // centre vertex. When the robot stops off-centre, a truly open direction can
    // read just under the threshold and be falsely marked a wall (it "blocks
    // more than necessary"). When enabled, computeWallMask*() reconstructs the
    // clearance as if measured from the tile centre by adding back the robot's
    // offset along each direction, so the LIDAR layer only frees what is really
    // open. The offset magnitude is clamped to max_center_offset_m for safety.
    // DISABLED BY DEFAULT after a run where the robot crashed into walls: the
    // body-frame offset projection is unvalidated on the real robot and a wrong
    // sign/frame opens real walls. Re-enable only behind LEGACY_WALL_CENTER_OFFSET_CORRECTION
    // once verified in sim.
    bool correct_for_tile_center_offset = true;
    // Clamp on the centre-offset correction. Kept below ~half the threshold
    // margin so a mislocalized offset can never push a real adjacent wall
    // (~0.03 m) past wall_threshold_m (0.03 + 0.03 = 0.06 < 0.061): the
    // correction only ever recovers genuinely-open directions, never opens walls.
    double max_center_offset_m = 0.018;
  };

  WallDetector();
  explicit WallDetector(Config config);

  int computeWallMask4(const SensorSnapshot& snapshot, Direction4 heading) const;
  int computeWallMask8(const SensorSnapshot& snapshot, Direction4 heading) const;
  // Overloads that correct the clearance thresholds for the robot not being at
  // the tile centre. center_offset_{x,y} is (localized robot pose - tile centre)
  // in the legacy metric frame; pass {0,0} (or use the 2-arg form) to disable.
  int computeWallMask4(const SensorSnapshot& snapshot, Direction4 heading,
                       double center_offset_x, double center_offset_y) const;
  int computeWallMask8(const SensorSnapshot& snapshot, Direction4 heading,
                       double center_offset_x, double center_offset_y) const;
  std::array<double, 8> measureLocalClearances(const SensorSnapshot& snapshot) const;
  const Config& config() const;

private:
  std::array<double, 8> correctedClearances(const SensorSnapshot& snapshot,
                                            double center_offset_x,
                                            double center_offset_y) const;
  double measureFromCloud(const SensorSnapshot& snapshot, int local_direction) const;
  double measureFromRanges(const SensorSnapshot& snapshot, int local_direction) const;
  bool rayPoseUseful(const SensorSnapshot& snapshot, double local_x, double local_y) const;

  Config config_;
};

}  // namespace exploration_legacy
