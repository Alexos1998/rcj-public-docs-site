#pragma once

#include "exploration_legacy/grid_map.hpp"
#include "exploration_legacy/types.hpp"

#include <cstddef>
#include <vector>

namespace exploration_legacy {

class LegacyPlanner {
public:
  enum class DirectMode {
    Heading,
    CardinalFirst,
    LeftHand,
    RightHand
  };

  struct Config {
    DirectMode direct_mode = DirectMode::Heading;
    double diagonal_backtracking_cost = 2.4142135623730951;
  };

  struct Decision {
    bool has_target = false;
    TileCoord target;
    Direction8 direction = Direction8::North;
    bool backtracking = false;
  };

  LegacyPlanner();
  explicit LegacyPlanner(Config config);

  Decision nextDecision(const LegacyGridMap& map, TileCoord current, Direction4 heading);
  const Config& config() const;

private:
  bool hasUnvisitedOpenNeighbor(const LegacyGridMap& map, TileCoord tile) const;
  Decision directDfsDecision(const LegacyGridMap& map, TileCoord current, Direction4 heading) const;
  Decision backtrackingDecision(const LegacyGridMap& map, TileCoord current) const;
  bool cachedBacktrackingDecision(const LegacyGridMap& map, TileCoord current, Decision& decision) const;
  void clearBacktrackingCache() const;
  void ensureSearchStorage(int total) const;

  Config config_;

  // Hot-path backtracking cache.  The legacy map is small, but repeated
  // backtracking used to allocate and run Dijkstra from scratch every step.
  // These mutable buffers keep the public planner API unchanged while allowing
  // nextDecision() to be O(1) while following a still-valid cached path.
  mutable std::vector<int> dijkstra_dist_;
  mutable std::vector<int> dijkstra_parent_;
  mutable std::vector<int> dijkstra_seen_stamp_;
  mutable std::vector<int> dijkstra_closed_stamp_;
  mutable int dijkstra_stamp_ = 0;
  mutable std::vector<TileCoord> cached_backtrack_path_;
  mutable std::size_t cached_backtrack_pos_ = 0U;
};

}  // namespace exploration_legacy
