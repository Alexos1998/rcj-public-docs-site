#pragma once

#include <functional>

#include "exploration_legacy/hazard_detector.hpp"
#include "exploration_legacy/types.hpp"

namespace exploration_legacy {

class MotionExecutor {
public:
  struct DriveResult {
    bool success = false;
    // Movement was interrupted by an external request (e.g. the vision runtime
    // saw a reportable victim/target mid-edge and wants the robot to stop). This
    // is NOT a wall/hole: the explorer must keep the map untouched and re-plan.
    bool aborted = false;
    bool hole_detected = false;
    bool blocked_detected = false;
    bool recovery_performed = false;
    double requested_distance_m = 0.0;
    double traveled_before_stop_m = 0.0;
    double measured_distance_m = 0.0;
    double distance_error_m = 0.0;
    bool validation_warning = false;

    explicit operator bool() const { return success; }
  };

  struct Config {
    double tile_size_m = 0.06;
    double linear_speed_mps = 0.125;
    double diagonal_linear_speed_mps = 0.11;
    double turn_tolerance_rad = 0.006;
    double distance_tolerance_m = 0.003;
    double wheel_radius_m = 0.02;
    double axle_length_m = 0.052;
    double max_wheel_speed_rad_s = 6.27;
    double min_turn_speed_rad_s = 1.0;
    double turn_gain = 90.0;
    double max_turn_duration_s = 1.2;
    double max_drive_duration_s = 12.0;
    double wheel_position_tolerance_rad = 0.06;
    double distance_validation_warn_m = 0.015;
    double stall_encoder_window_m = 0.010;
    double stall_loc_translation_epsilon_m = 0.003;
    double stall_min_duration_s = 0.18;
    double stall_recovery_reverse_m = 0.025;
    bool stall_recovery_enabled = true;
    bool debug_logs = true;
    LogCallback log_callback;
    // When set and it returns true, the current drive/turn is aborted at the
    // next internal step (wheels stopped, DriveResult.aborted=true). Used by the
    // controller to stop mid-edge when vision sees a reportable detection.
    std::function<bool()> abort_requested;
  };

  class IO {
  public:
    virtual ~IO() = default;
    virtual double timeSeconds() const = 0;
    virtual bool step() = 0;
    // yawRadians() must use the library navigation convention documented in
    // math.hpp: North=0, East=-pi/2, South=pi, West=+pi/2. A Webots adapter is
    // responsible for converting Webots IMU yaw before returning it here.
    virtual double yawRadians() const = 0;
    virtual Pose2D pose() const = 0;
    virtual bool localizedPose(Pose2D& out) const;
    virtual SensorSnapshot sensorSnapshot() const = 0;
    virtual double leftWheelPositionRad() const = 0;
    virtual double rightWheelPositionRad() const = 0;
    virtual void setWheelTargetPosition(double left_rad, double right_rad) = 0;
    virtual void setWheelVelocityLimit(double left_rad_s, double right_rad_s) = 0;
    virtual void setWheelVelocity(double left_rad_s, double right_rad_s) = 0;
    virtual void stop() = 0;
  };

  MotionExecutor(IO& io, Config config);
  MotionExecutor(IO& io, Config config, HazardDetector hazard_detector);

  bool turnToYaw(double target_yaw_rad);
  bool alignCardinal();
  void stop();
  DriveResult driveDistance(double distance_m);
  DriveResult driveTile();
  DriveResult driveDiagonalTile();

  // Novo: move até uma pose alvo usando a localização atual.
  DriveResult driveToPose(Pose2D target_pose);

private:
  bool turnToYawInternal(double target_yaw_rad, const char* timeout_event);
  DriveResult driveDistanceAtSpeed(double distance_m, double speed_mps);
  DriveResult handleHoleDuringDrive(double requested_distance_m,
                                    double speed_mps,
                                    Pose2D start_pose,
                                    double start_left_rad,
                                    double start_right_rad);
  DriveResult handleStallDuringDrive(double requested_distance_m,
                                     double speed_mps,
                                     Pose2D start_pose,
                                     double start_left_rad,
                                     double start_right_rad,
                                     double start_time_s);
  DriveResult makeDriveResult(bool success,
                              bool hole_detected,
                              bool blocked_detected,
                              double requested_distance_m,
                              double traveled_before_stop_m,
                              double measured_distance_m) const;
  Pose2D measuredPose() const;
  double encoderTravelDistance(double start_left_rad, double start_right_rad) const;
  void cancelWheelTargetAtCurrentPosition();
  void logEvent(const std::string& event, const std::string& fields = "") const;

  IO& io_;
  Config config_;
  HazardDetector hazard_detector_;
  bool returning_from_hole_ = false;
  bool recovering_from_stall_ = false;
};

}  // namespace exploration_legacy
