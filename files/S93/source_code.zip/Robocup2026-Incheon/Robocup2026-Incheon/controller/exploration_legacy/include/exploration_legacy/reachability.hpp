#pragma once

#include "exploration_legacy/types.hpp"

#include <chrono>
#include <cstdint>
#include <functional>
#include <optional>
#include <string>
#include <vector>

namespace exploration_legacy {

enum class ReachabilityStatus {
  Reachable,
  Blocked,
  OutsideCostmap,
  UnknownSpace,
  CostmapUnavailable,
  PlannerUnavailable,
  PlannerRejected,
  Timeout,
  InvalidCoordinate
};

struct ReachabilityResult {
  bool reachable = false;
  ReachabilityStatus status = ReachabilityStatus::Blocked;
  std::string selected_candidate;
  std::string reason;
};

struct MapPoint {
  double x = 0.0;
  double y = 0.0;
};

struct PathSegment {
  MapPoint start;
  MapPoint end;
};

struct PathCandidate {
  std::string name;
  std::vector<MapPoint> waypoints;
};

struct CostmapSnapshot {
  std::string frame_id = "map";
  double resolution_m = 0.0;
  std::uint32_t width = 0;
  std::uint32_t height = 0;
  double origin_x_m = 0.0;
  double origin_y_m = 0.0;
  double origin_yaw_rad = 0.0;
  std::vector<int> data;
  double age_s = 0.0;
  bool valid = false;
};

class LegacyReachabilityChecker {
public:
  using PoseProvider = std::function<std::optional<Pose2D>()>;
  using QueryCallback = std::function<ReachabilityResult(
    const Pose2D& start,
    double goal_x_m,
    double goal_y_m,
    const std::vector<PathCandidate>& candidates,
    std::chrono::milliseconds timeout)>;
  using SegmentPlanner = std::function<ReachabilityResult(const PathSegment&)>;

  struct Config {
    double alignment_tolerance_m = 1.0e-4;
    double min_segment_length_m = 1.0e-6;
    double max_sample_step_m = 0.0;
    int unknown_value = -1;
    int lethal_threshold = 90;
    bool allow_unknown = false;
    // The legacy explorer builds and executes its own graph.  For each local
    // graph edge we only need a deterministic geometric collision check
    // against the inflated costmap.  Calling Nav2 ComputePathToPose for every
    // 0.06 m edge is much slower and may timeout under load.  Keep the old
    // planner callback available for explicit experiments, but default to
    // costmap-only validation.
    bool use_planner_validation = false;
    // Sub-grid (footprint) occupancy check. The single tile-centre sample can be
    // UNKNOWN even when the surrounding 0.06 m area is clearly free or clearly
    // occupied. When enabled, each path sample is evaluated over a subgrid_cell_m
    // patch of costmap cells: ANY lethal cell in the patch blocks (stricter and
    // safer than a centre point), and an unknown centre is resolved as free only
    // when the patch holds known-free cells and no lethal cell. Off by default.
    bool subgrid_occupancy_check = false;
    double subgrid_cell_m = 0.06;
    double max_costmap_age_s = 2.0;
    std::chrono::milliseconds timeout{1000};
    LogCallback log_callback;
  };

  LegacyReachabilityChecker(Config config, PoseProvider pose_provider, QueryCallback query_callback);

  ReachabilityResult canReachMapCoordinate(double goal_x_m, double goal_y_m) const;
  ReachabilityResult canReachMapWaypoints(
    double goal_x_m,
    double goal_y_m,
    const std::vector<MapPoint>& intermediate_waypoints,
    const std::string& candidate_name) const;
  ReachabilityResult canReachPathCandidate(PathCandidate candidate) const;

  static std::vector<PathCandidate> generateCandidates(
    MapPoint start,
    MapPoint goal,
    const Config& config);

  static ReachabilityResult evaluateCandidates(
    const std::vector<PathCandidate>& candidates,
    const CostmapSnapshot& costmap,
    const Config& config,
    const SegmentPlanner& planner);

  static ReachabilityResult validateCandidateCostmap(
    const PathCandidate& candidate,
    const CostmapSnapshot& costmap,
    const Config& config);

private:
  Config config_;
  PoseProvider pose_provider_;
  QueryCallback query_callback_;
};

const char* reachabilityStatusName(ReachabilityStatus status);
std::optional<ReachabilityStatus> reachabilityStatusFromName(const std::string& name);

std::vector<PathSegment> candidateSegments(
  const PathCandidate& candidate,
  double min_segment_length_m);

std::string serializeCandidatePayload(const std::vector<PathCandidate>& candidates);
bool parseCandidatePayload(const std::string& payload, std::vector<PathCandidate>& candidates);

std::string percentEncode(const std::string& text);
std::string percentDecode(const std::string& text);

std::string serializeReachabilityResponse(
  std::uint64_t request_id,
  const ReachabilityResult& result);
bool parseReachabilityResponse(
  const std::string& line,
  std::uint64_t& request_id,
  ReachabilityResult& result);

}  // namespace exploration_legacy
