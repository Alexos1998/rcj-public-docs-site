#pragma once

#include <array>

#include "exploration_legacy/types.hpp"

namespace exploration_legacy {

inline constexpr double kPi = 3.141592653589793238462643383279502884;
inline constexpr double kTwoPi = 2.0 * kPi;
inline constexpr int kDirectionCount4 = 4;
inline constexpr int kDirectionCount8 = 8;

double normalizeAngle(double angle_rad);
double angleDelta(double target_rad, double current_rad);

// Library navigation yaw convention:
//   North = 0
//   East  = -pi/2
//   South = pi
//   West  = +pi/2
// Adapters must convert simulator/sensor yaw into this convention before
// passing values to MotionExecutor::IO::yawRadians() or SensorSnapshot::yaw.
Direction4 nearestCardinalDirection(double yaw_rad);
double directionToYaw(Direction4 direction);
double directionToYaw(Direction8 direction);

Direction4 rotateDirection(Direction4 direction, int quarter_turns);
Direction8 rotateDirection(Direction8 direction, int quarter_turns);
Direction8 toDirection8(Direction4 direction);
Direction4 cardinalAfterDiagonal(Direction8 direction);

bool isCardinal(Direction8 direction);
bool isDiagonal(Direction8 direction);

TileCoord tileDelta(Direction4 direction);
TileCoord tileDelta(Direction8 direction);
const std::array<TileCoord, kDirectionCount8>& tileDeltas8();

Direction8 directionBetween(TileCoord from, TileCoord to);
Direction8 directionFromIndex(int index);
int directionIndex(Direction8 direction);
int directionBit(Direction8 direction);
int oppositeDirectionBit(Direction8 direction);
Direction8 oppositeDirection(Direction8 direction);

double distance(TileCoord a, TileCoord b);
double distance2D(Pose2D a, Pose2D b);
TileCoord add(TileCoord tile, TileCoord delta);

}  // namespace exploration_legacy
