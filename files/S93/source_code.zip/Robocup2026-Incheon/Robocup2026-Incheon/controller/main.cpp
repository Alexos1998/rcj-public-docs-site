// Author:        Águabots

#include <webots/Robot.hpp>
#include <webots/Motor.hpp>
#include <webots/PositionSensor.hpp>
#include <webots/Lidar.hpp>
#include <webots/GPS.hpp>
#include <webots/Camera.hpp>
#include <webots/InertialUnit.hpp>
#include <webots/DistanceSensor.hpp>
#include <webots/Emitter.hpp>
#include <webots/Receiver.hpp>

#include <webots/Keyboard.hpp>

#include <iostream>
#include <string>
#include <cmath>
#include <algorithm>
#include <vector>
#include <memory>
#include <chrono>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <limits>
#include <array>
#include <cstdlib>
#include <utility>
#include <cctype>
#include <cstdint>
#include <cstring>
#include <optional>
#include <set>
#include <functional>

#include "utils/BridgeClient.hpp"
#include "vision/VisionRuntime.hpp"
#include "utils/Diag.hpp"
#include "utils/PID.hpp"
#include "utils/MathUtils.hpp"
#include "utils/RobotEventLogger.hpp"
#include "utils/UniqueLogger.hpp"
#include "sensors/LidarUtils.hpp"
#include "sensors/FloorColorClassifier.hpp"
#include "control/DifferentialDrive.hpp"
#include "safety/BlackHoleSafety.hpp"
#include "diagnostics/StartupSensorInfo.hpp"
#include "localization/Localizer2D.hpp"
#include "mapping/WheelOdometry.hpp"
#include "exploration_legacy/legacy_explorer.hpp"
#include "exploration_legacy/reachability.hpp"

using namespace std;
using namespace webots;
using namespace utils;
using namespace sensors;
using utils::logRobotEvent;
using utils::logRobotTerminalEvent;
using utils::RobotEventFields;
using safety::BlackHoleSafetyState;
using safety::blackHoleSafetyStateName;

Robot *robot = new Robot();

int timeStep = (int)robot->getBasicTimeStep();
double dt = timeStep / 1000.0;

constexpr double max_speed = 6.27;
constexpr double raioRoda = 0.02;
constexpr double L = 0.052;

constexpr double kNav2CmdTimeout = 0.75;
constexpr double kMaxLinearVel = raioRoda * max_speed;
constexpr double kMaxAngularVel = (raioRoda * max_speed) / (L / 2.0);

// Built-in defaults (balanced profile). Used only when the matching RACE_*_HZ
// env var is absent; when Ros.sh exports those vars the values come pre-resolved
// (profile x RACE_RATE_SCALE), so we do NOT re-apply the scale to them here.
constexpr double kDefaultStateHz = 62.5;
constexpr double kDefaultScanHz = 62.5;
constexpr double kDefaultColorHz = 20.833333;
constexpr double kDefaultCameraHz = 31.25;

constexpr double kDefaultRaceTimeLimitS = 480.0;
constexpr double kDefaultSubmissionDeadlineMarginS = 2.0;
constexpr double kGameInformationRequestPeriodS = 0.25;

constexpr double kDefaultBlackHoleBrakeHoldMs = 250.0;
constexpr double kDefaultBlackHoleReverseMs = 450.0;
constexpr double kDefaultBlackHoleReverseSpeed = -0.035;
constexpr double kDefaultBlackHoleBrakeMinConfidence = 0.90;
Motor *wheel_left = robot->getMotor("wheel1 motor");
Motor *wheel_right = robot->getMotor("wheel2 motor");

PositionSensor *leftEncoders = wheel_left->getPositionSensor();
PositionSensor *rightEncoders = wheel_right->getPositionSensor();

Keyboard *keyboard = robot->getKeyboard();

Lidar *lidar = robot->getLidar("lidar");
GPS *gps = robot->getGPS("gps");
InertialUnit *Iunit = robot->getInertialUnit("inertial_unit");
DistanceSensor *dsensor = robot->getDistanceSensor("distance sensor1");
Emitter *emitter = robot->getEmitter("emitter");
Receiver *receiver = robot->getReceiver("receiver");

Camera *colorSensor = robot->getCamera("colour_sensor");
Camera *came = robot->getCamera("camera1");
Camera *camd = robot->getCamera("camera2");

double gpsX0 = 0.0, gpsY0 = 0.0;
int lidarH = 0;

unique_ptr<BridgeClient> bridge_client;
unique_ptr<vision_runtime::VisionRuntime> vision_runtime_ptr;

enum class VisionRuntimePhase {
   Idle,
   ClassifyHold,
   AlignAdjust,
   Reporting
};

struct VisionDetectionResult {
   bool valid = false;
   std::uint64_t seq = 0;
   std::string camera;
   int tile_x = 0;
   int tile_y = 0;
   std::string kind;
   std::string class_name;
   double confidence = 0.0;
   double distance_m = 0.0;
   double center_x = 0.0;
   double center_y = 0.0;
   double image_width = 0.0;
   int bbox_x = 0;
   int bbox_y = 0;
   int bbox_w = 0;
   int bbox_h = 0;
   std::string target_pattern;
   int target_sum = 0;
   double radial_coverage = 0.0;
};

struct VisionRejectionHint {
   bool valid = false;
   std::uint64_t seq = 0;
   std::string camera;
   int tile_x = 0;
   int tile_y = 0;
   std::string reason;
};

static bool isTargetBboxGateHint(const VisionRejectionHint& hint)
{
   return hint.valid && hint.reason == "target_bbox_gate";
}

static double g_vision_victim_report_min_confidence = 0.70;
static double g_vision_victim_small_bbox_min_confidence = 0.80;
static int g_vision_victim_small_bbox_area_px = 80;
static int g_vision_victim_small_bbox_width_px = 8;
static int g_vision_victim_small_bbox_height_px = 8;
// Distance proxy: victims close enough to score (<= half tile) sit low in the
// 64px frame (bbox center_y >= ~45); distant look-alikes cluster at the
// horizon (center_y <= ~43). Log-validated on 1796 detections: threshold 44
// kept all 7 true reports and removed all 18 misidentifications.
static double g_vision_victim_report_min_center_y_px = 44.0;
static double g_vision_target_report_min_confidence = 0.0;
static int g_vision_target_report_min_area_px = 340;
static int g_vision_target_report_min_width_px = 0;
static int g_vision_target_report_min_height_px = 0;

// Converts a pipeline detection into the controller-side result struct the
// vision phase logic consumes. Replaces the old TCP line serialize/parse path
// (detectionToResultLine -> parseVisionResultLine), preserving field semantics.
static VisionDetectionResult visionDetectionToResult(const ros2_vision::VisionDetection& det)
{
   VisionDetectionResult out;
   out.valid = !det.kind.empty() && !det.class_name.empty();
   out.seq = det.seq;
   out.camera = det.camera_name;
   out.tile_x = det.tile_x;
   out.tile_y = det.tile_y;
   out.kind = det.kind;
   out.class_name = det.class_name;
   out.confidence = det.confidence;
   out.distance_m = det.distance;
   out.center_x = det.center_x;
   out.center_y = det.center_y;
   out.bbox_x = det.bbox.x;
   out.bbox_y = det.bbox.y;
   out.bbox_w = det.bbox.width;
   out.bbox_h = det.bbox.height;
   out.target_pattern = det.target_pattern;
   out.target_sum = det.target_sum;
   out.radial_coverage = det.radial_coverage;
   return out;
}

static std::string envString(const char* name, const std::string& default_value)
{
   const char* raw = std::getenv(name);
   return raw == nullptr ? default_value : std::string(raw);
}

// Simulation-time gate: fires when at least period_s of simulation time elapsed.
// Driven by robot->getTime() so cadence tracks Webots speed, not wall time.
class PeriodicGate {
public:
   explicit PeriodicGate(double period_s) : period_s_(period_s), last_t_(-1.0) {}

   void setPeriod(double period_s) { period_s_ = period_s; }

   bool due(double t) {
      if (last_t_ < 0.0 || (t - last_t_) >= period_s_) {
         last_t_ = t;
         return true;
      }
      return false;
   }

private:
   double period_s_;
   double last_t_;
};

// Resolved runtime timing for the controller. Hz values come from RACE_*_HZ env
// vars (already profile/scale-resolved by Ros.sh). Periods are derived and the
// rates are clamped to what the Webots timestep can physically deliver.
struct RuntimeTimingConfig {
   bool use_sim_time = false;
   double rate_scale = 1.0;

   double state_hz = kDefaultStateHz;
   double scan_hz = kDefaultScanHz;
   double color_hz = kDefaultColorHz;
   double camera_hz = kDefaultCameraHz;
   double vision_hz = kDefaultCameraHz;

   double state_period_s = 1.0 / kDefaultStateHz;
   double scan_period_s = 1.0 / kDefaultScanHz;
   double color_period_s = 1.0 / kDefaultColorHz;
   double camera_period_s = 1.0 / kDefaultCameraHz;
   double vision_period_s = 1.0 / kDefaultCameraHz;
};

static double hzToPeriod(double hz)
{
   return (hz > 0.0) ? (1.0 / hz) : 0.0;
}

// Reads one RACE_*_HZ env var. If unset, falls back to default_hz * rate_scale.
// Always clamps to [0.1, max_hz] and warns when a request exceeds max_hz (i.e.
// faster than one publish per Webots step).
static double resolveTimingHz(const char* name,
                              double default_hz,
                              double rate_scale,
                              double max_hz)
{
   const char* raw = std::getenv(name);
   double requested;
   if (raw == nullptr) {
      requested = default_hz * rate_scale;
   } else {
      try {
         requested = std::stod(raw);
      } catch (const std::exception&) {
         diag::log(diag::Level::Warn,
                   "[timing] Valor inválido para ", name, "='", raw,
                   "', usando default ", numberText(default_hz, 4));
         requested = default_hz * rate_scale;
      }
   }

   double resolved = utils::clampd(requested, 0.1, max_hz);
   if (requested > max_hz) {
      diag::log(diag::Level::Warn,
                "[timing] ", name, "=", numberText(requested, 4),
                " Hz excede o limite do timestep (", numberText(max_hz, 4),
                " Hz); limitando.");
   }
   return resolved;
}

static RuntimeTimingConfig loadRuntimeTimingConfig(int time_step_ms)
{
   RuntimeTimingConfig cfg;
   cfg.use_sim_time = utils::envFlagEnabled("RACE_USE_SIM_TIME", false);
   cfg.rate_scale = std::max(0.01, utils::envDouble("RACE_RATE_SCALE", 1.0));

   // One publish per Webots step is the physical ceiling for sensor cadence.
   const double max_hz = (time_step_ms > 0) ? (1000.0 / time_step_ms) : 1000.0;

   cfg.state_hz = resolveTimingHz("RACE_STATE_HZ", kDefaultStateHz, cfg.rate_scale, max_hz);
   cfg.scan_hz = resolveTimingHz("RACE_SCAN_HZ", kDefaultScanHz, cfg.rate_scale, max_hz);
   cfg.color_hz = resolveTimingHz("RACE_COLOR_HZ", kDefaultColorHz, cfg.rate_scale, max_hz);
   cfg.camera_hz = resolveTimingHz("RACE_CAMERA_HZ", kDefaultCameraHz, cfg.rate_scale, max_hz);
   // Vision frame cadence defaults to the camera cadence unless overridden.
   cfg.vision_hz = resolveTimingHz("RACE_VISION_HZ", cfg.camera_hz, 1.0, max_hz);

   cfg.state_period_s = hzToPeriod(cfg.state_hz);
   cfg.scan_period_s = hzToPeriod(cfg.scan_hz);
   cfg.color_period_s = hzToPeriod(cfg.color_hz);
   cfg.camera_period_s = hzToPeriod(cfg.camera_hz);
   cfg.vision_period_s = hzToPeriod(cfg.vision_hz);

   diag::log(diag::Level::Info,
             "[timing] use_sim_time=", boolText(cfg.use_sim_time),
             " rate_scale=", numberText(cfg.rate_scale, 3),
             " timestep_ms=", std::to_string(time_step_ms),
             " max_hz=", numberText(max_hz, 4));
   diag::log(diag::Level::Info,
             "[timing] state_hz=", numberText(cfg.state_hz, 4),
             " period=", numberText(cfg.state_period_s, 4),
             " | scan_hz=", numberText(cfg.scan_hz, 4),
             " period=", numberText(cfg.scan_period_s, 4));
   diag::log(diag::Level::Info,
             "[timing] color_hz=", numberText(cfg.color_hz, 4),
             " period=", numberText(cfg.color_period_s, 4),
             " | camera_hz=", numberText(cfg.camera_hz, 4),
             " period=", numberText(cfg.camera_period_s, 4),
             " | vision_hz=", numberText(cfg.vision_hz, 4),
             " period=", numberText(cfg.vision_period_s, 4));

   return cfg;
}

static bool parseInt(const std::string& text, int& out)
{
   try {
      std::size_t pos = 0;
      const int value = std::stoi(text, &pos);
      if (pos != text.size()) return false;
      out = value;
      return true;
   } catch (...) {
      return false;
   }
}

static bool parseDoubleValue(const std::string& text, double& out)
{
   try {
      std::size_t pos = 0;
      const double value = std::stod(text, &pos);
      if (pos != text.size()) return false;
      out = value;
      return std::isfinite(value);
   } catch (...) {
      return false;
   }
}

static void logVisionClassificationUnique(const std::string& stage,
                                           const VisionDetectionResult& result,
                                           double sim_t,
                                           const GpsLocal& fixpos,
                                           double yaw_ros)
{
   // Linha curta e grepável no logs/latest/unique.log.
   // stage=RESULT_RX: o ros2_vision classificou e mandou o resultado.
   // stage=REPORT_SENT: o controller escolheu esse resultado e reportou.
   const std::string chosen = result.kind == "target"
      ? result.class_name + "/" + result.target_pattern
      : result.class_name;

   utils::uniqueLogger()
      << diag::timestampLocal()
      << " sim_t=" << numberText(sim_t, 3)
      << " event=VISION_CLASSIFICATION"
      << " stage=" << stage
      << " kind=" << result.kind
      << " chosen=" << chosen
      << " class=" << result.class_name
      << " pattern=" << result.target_pattern
      << " confidence=" << numberText(result.confidence, 3)
      << " lidar_distance_m=" << numberText(result.distance_m, 3)
      << " camera=" << result.camera
      << " seq=" << result.seq
      << " tile=(" << result.tile_x << "," << result.tile_y << ")"
      << " gps_m=(" << numberText(fixpos.x, 3) << "," << numberText(fixpos.z, 3) << ")"
      << " yaw_rad=" << numberText(yaw_ros, 3)
      << " center_px=(" << numberText(result.center_x, 1) << "," << numberText(result.center_y, 1) << ")"
      << " bbox_px=(" << result.bbox_x << "," << result.bbox_y << ","
      << result.bbox_w << "," << result.bbox_h << ")"
      << std::endl;
}

// Single duplicate rule: never report the same classification twice on the
// same tile. Different classes (or a different tile) are always reportable.
static std::string makeVisionKey(const VisionDetectionResult& result)
{
   return std::to_string(result.tile_x) + "," +
      std::to_string(result.tile_y) + "|" +
      result.kind + "|" +
      result.class_name + "|" +
      result.target_pattern;
}

static bool reportableVisionResult(const VisionDetectionResult& result)
{
   if (!result.valid) return false;
   if (result.kind == "victim") {
      if (result.class_name == "none" || result.class_name == "fake" || result.class_name.empty()) {
         return false;
      }
      if (result.confidence < g_vision_victim_report_min_confidence) {
         return false;
      }
      const int bbox_area = std::max(0, result.bbox_w) * std::max(0, result.bbox_h);
      const bool small_bbox =
         bbox_area < g_vision_victim_small_bbox_area_px ||
         result.bbox_w < g_vision_victim_small_bbox_width_px ||
         result.bbox_h < g_vision_victim_small_bbox_height_px;
      if (small_bbox && result.confidence < g_vision_victim_small_bbox_min_confidence) {
         return false;
      }
      if (!std::isfinite(result.center_y) ||
          result.center_y < g_vision_victim_report_min_center_y_px) {
         return false;
      }
      return true;
   }
   if (result.kind == "target") {
      if (result.target_pattern.empty() || result.target_pattern == "none") {
         return false;
      }
      if (result.confidence < g_vision_target_report_min_confidence) {
         return false;
      }
      const int bbox_area = std::max(0, result.bbox_w) * std::max(0, result.bbox_h);
      return bbox_area >= g_vision_target_report_min_area_px &&
         result.bbox_w >= g_vision_target_report_min_width_px &&
         result.bbox_h >= g_vision_target_report_min_height_px;
   }
   return false;
}

static std::string victimReportGateRejectReason(const VisionDetectionResult& result)
{
   if (result.kind != "victim" ||
       result.class_name == "none" ||
       result.class_name == "fake" ||
       result.class_name.empty())
   {
      return "not_reportable_victim_class";
   }
   if (result.confidence < g_vision_victim_report_min_confidence) {
      return "victim_report_confidence";
   }
   const int bbox_area = std::max(0, result.bbox_w) * std::max(0, result.bbox_h);
   const bool small_bbox =
      bbox_area < g_vision_victim_small_bbox_area_px ||
      result.bbox_w < g_vision_victim_small_bbox_width_px ||
      result.bbox_h < g_vision_victim_small_bbox_height_px;
   if (small_bbox && result.confidence < g_vision_victim_small_bbox_min_confidence) {
      return "victim_report_small_bbox";
   }
   if (!std::isfinite(result.center_y) ||
       result.center_y < g_vision_victim_report_min_center_y_px) {
      return "victim_report_center_y";
   }
   return "none";
}

static std::string targetReportGateRejectReason(const VisionDetectionResult& result)
{
   if (result.kind != "target" ||
       result.target_pattern.empty() ||
       result.target_pattern == "none")
   {
      return "not_reportable_target_pattern";
   }
   if (result.confidence < g_vision_target_report_min_confidence) {
      return "target_report_confidence";
   }
   const int bbox_area = std::max(0, result.bbox_w) * std::max(0, result.bbox_h);
   if (bbox_area < g_vision_target_report_min_area_px ||
       result.bbox_w < g_vision_target_report_min_width_px ||
       result.bbox_h < g_vision_target_report_min_height_px)
   {
      return "target_report_bbox";
   }
   return "none";
}

static double visionResultAbsCenterErrorPx(const VisionDetectionResult& result)
{
   if (!(result.image_width > 1.0) || !std::isfinite(result.center_x)) {
      return std::numeric_limits<double>::quiet_NaN();
   }
   const double cx = (result.image_width - 1.0) * 0.5;
   return std::abs(result.center_x - cx);
}

static std::optional<VisionDetectionResult> chooseBestVisionResult(
   const std::vector<VisionDetectionResult>& results,
   const std::set<std::string>& reported_vision_keys)
{
   std::optional<VisionDetectionResult> best;

   auto better = [](const VisionDetectionResult& candidate, const VisionDetectionResult& current) {
      if (candidate.confidence != current.confidence) {
         return candidate.confidence > current.confidence;
      }
      if (candidate.kind != current.kind) {
         return candidate.kind == "target";
      }
      const double candidate_center_error = visionResultAbsCenterErrorPx(candidate);
      const double current_center_error = visionResultAbsCenterErrorPx(current);
      const bool candidate_has_center_error = std::isfinite(candidate_center_error);
      const bool current_has_center_error = std::isfinite(current_center_error);
      if (candidate_has_center_error != current_has_center_error) {
         return candidate_has_center_error;
      }
      if (candidate_has_center_error &&
          std::abs(candidate_center_error - current_center_error) > 0.5)
      {
         return candidate_center_error < current_center_error;
      }

      const bool candidate_has_distance = std::isfinite(candidate.distance_m);
      const bool current_has_distance = std::isfinite(current.distance_m);
      if (candidate_has_distance != current_has_distance) {
         return candidate_has_distance;
      }
      if (candidate_has_distance &&
          std::abs(candidate.distance_m - current.distance_m) > 0.001)
      {
         return candidate.distance_m < current.distance_m;
      }

      if (candidate.camera == current.camera) {
         return candidate.seq > current.seq;
      }
      return false;
   };

   for (const auto& result : results) {
      if (!reportableVisionResult(result) ||
          reported_vision_keys.count(makeVisionKey(result)) > 0) {
         continue;
      }
      if (!best || better(result, *best)) {
         best = result;
      }
   }

   return best;
}

static void stopAndHoldWheelsAtCurrentPosition()
{
   wheel_left->setVelocity(0.0);
   wheel_right->setVelocity(0.0);

   if (leftEncoders && rightEncoders) {
      wheel_left->setPosition(leftEncoders->getValue());
      wheel_right->setPosition(rightEncoders->getValue());
   }
}

static void legacyDelayMs(int milliseconds)
{
   const double end_time = robot->getTime() + static_cast<double>(milliseconds) / 1000.0;
   while (robot->getTime() < end_time) {
      robot->step(timeStep);
   }
}

static void enviarVictimaLegacy(char victima)
{
   if (!emitter || !gps) {
      logRobotTerminalEvent(
         diag::Level::Warn,
         "vision_victim_report_failed",
         {
            {"reason", !emitter ? "missing_emitter" : "missing_gps"},
            {"class", std::string(1, victima)},
         });
      return;
   }

   stopAndHoldWheelsAtCurrentPosition();
   legacyDelayMs(500);
   legacyDelayMs(1000);

   char mensagem[9];
   const double* position = gps->getValues();
   const int x = static_cast<int>(position[0] * 100.0);
   const int y = static_cast<int>(position[2] * 100.0);
   int victim_pos[2] = {x, y};
   std::memcpy(mensagem, victim_pos, sizeof(victim_pos));
   mensagem[8] = victima;

   emitter->send(mensagem, sizeof(mensagem));
   robot->step(timeStep);
}

static void enviarTargetLegacy(const VisionDetectionResult& result)
{
   if (!result.class_name.empty()) {
      enviarVictimaLegacy(result.class_name[0]);
   }
   logRobotEvent(
      "vision_target_reported_emitter",
      {
         {"class", result.class_name},
         {"pattern", result.target_pattern},
         {"tile", "(" + std::to_string(result.tile_x) + "," + std::to_string(result.tile_y) + ")"},
         {"camera", result.camera},
         {"distance", numberText(result.distance_m, 3)},
      });
}

vector<float> getLidar() {
   const float *rays = lidar->getRangeImage();

   const int n = lidarH;
   vector<float> raw;
   raw.resize(n);

   // Webots range image layout:
   //   selected layer = 2
   //   raw index 0 starts at robot front and wraps around back to front.
   //
   // Observed behavior after basic half-turn rotation:
   //   north/south correct
   //   east/west mirrored
   //
   // Therefore the raw angular order is opposite to ROS LaserScan convention.
   //
   // Project ROS lidar convention:
   //   ROS LaserScan angle_min = -pi
   //   index 0       ~= back
   //   index n/4     ~= right
   //   index n/2     ~= front
   //   index 3n/4    ~= left
   //
   // Mapping from ROS scan index j to Webots raw index:
   //   raw_idx = n/2 - j  (wrapped)
   //
   // This keeps front/back fixed and swaps left/right correctly.
   for (int i = 0; i < n; ++i) {
      float value = rays[2 * n + i];

      if (!isfinite(value) || value <= 0.0f) {
         value = 1.0f;
      }

      raw[i] = value;
   }

   vector<float> ros_scan;
   ros_scan.resize(n);

   for (int j = 0; j < n; ++j) {
      int raw_idx = (n / 2) - j;

      while (raw_idx < 0) {
         raw_idx += n;
      }

      raw_idx %= n;

      ros_scan[j] = raw[raw_idx];
   }

   return ros_scan;
}

static bool visionLidarGatePasses(const std::vector<float>& scan,
                                  double camera_hfov_rad,
                                  double camera_yaw_offset_rad,
                                  int min_consecutive_rays,
                                  double max_range_m,
                                  int* close_rays = nullptr,
                                  int* max_run = nullptr)
{
   if (close_rays) *close_rays = 0;
   if (max_run) *max_run = 0;
   if (scan.empty() || camera_hfov_rad <= 0.0) {
      return false;
   }

   const double angle_min = -M_PI;
   const double angle_increment = (2.0 * M_PI) / static_cast<double>(scan.size());
   const double half_fov = camera_hfov_rad * 0.5;
   int close_count = 0;
   int run = 0;
   int best_run = 0;

   for (std::size_t i = 0; i < scan.size(); ++i) {
      const double angle = angle_min + static_cast<double>(i) * angle_increment;
      const bool in_camera_fov = std::abs(pi_interval(angle - camera_yaw_offset_rad)) <= half_fov;
      const float range = scan[i];
      const bool close =
         in_camera_fov &&
         std::isfinite(range) &&
         range >= 0.01f &&
         static_cast<double>(range) <= max_range_m;
      if (close) {
         ++close_count;
         ++run;
         best_run = std::max(best_run, run);
      } else if (in_camera_fov) {
         run = 0;
      }
   }

   if (close_rays) *close_rays = close_count;
   if (max_run) *max_run = best_run;
   return best_run >= std::max(1, min_consecutive_rays);
}

static void setVisionGuardedWheelVelocity(double left_rad_s, double right_rad_s)
{
   wheel_left->setPosition(INFINITY);
   wheel_right->setPosition(INFINITY);

   const double raw_left = clampd(left_rad_s, -max_speed, max_speed);
   const double raw_right = clampd(right_rad_s, -max_speed, max_speed);
   const double raw_v = 0.5 * raioRoda * (raw_left + raw_right);
   const double raw_w = raioRoda * (raw_right - raw_left) / L;

   sensors::LidarVelocityGuardConfig lidar_guard_cfg;
   const auto guard = sensors::applyLidarVelocityGuard(raw_v, raw_w, getLidar(), lidar_guard_cfg);
   double safe_left = raw_left;
   double safe_right = raw_right;
   if (guard.active) {
      safe_left = (guard.v - guard.w * (L / 2.0)) / raioRoda;
      safe_right = (guard.v + guard.w * (L / 2.0)) / raioRoda;
      logRobotEvent(
         "vision_align_lidar_guard",
         {
            {"reason", guard.reason},
            {"raw_v", numberText(raw_v, 4)},
            {"raw_w", numberText(raw_w, 4)},
            {"safe_v", numberText(guard.v, 4)},
            {"safe_w", numberText(guard.w, 4)},
            {"sector_min_range", numberText(guard.sector_min_range_m, 4)},
         });
   }

   wheel_left->setVelocity(clampd(safe_left, -max_speed, max_speed));
   wheel_right->setVelocity(clampd(safe_right, -max_speed, max_speed));
}

GpsLocal getGps() {
   const double* pos = gps->getValues();
   GpsLocal fix;
   fix.x = pos[0];
   fix.y = -pos[2];
   fix.z = pos[1];

   return fix;
}

class WebotsLegacyMotionIO final : public exploration_legacy::MotionExecutor::IO {
public:
   // Callback executado a cada robot->step() interno dos laços bloqueantes do
   // MotionExecutor (driveDistance/turnToYaw). Sem isso, scan/TF/odom só são
   // publicados entre movimentos, fazendo o LiDAR/SLAM/TF "congelarem" enquanto
   // o robô anda um ladrilho. Ver pump de publicação registrado em main().
   void setStepCallback(std::function<void()> on_step)
   {
      on_step_ = std::move(on_step);
   }

   void setLocalizationPoseProvider(std::function<std::optional<exploration_legacy::Pose2D>()> pose_provider)
   {
      loc_pose_provider_ = std::move(pose_provider);
   }

   double timeSeconds() const override
   {
      return robot->getTime();
   }

   bool step() override
   {
      const bool ok = robot->step(timeStep) != -1;
      if (ok) {
         applyPositionModeLidarGuard();
      }
      if (ok && on_step_) {
         on_step_();
      }
      return ok;
   }

   double yawRadians() const override
   {
      const double* rpy = Iunit ? Iunit->getRollPitchYaw() : nullptr;
      return rpy ? webotsYawToRos(rpy[2]) : 0.0;
   }

   exploration_legacy::Pose2D pose() const override
   {
      exploration_legacy::Pose2D out;
      const double* position = gps ? gps->getValues() : nullptr;
      if (position) {
         // Legacy exploration uses the startup GPS sample as its local metric origin.
         out.x = position[0] - gpsX0;
         out.y = -(position[2] - gpsY0);
      }
      out.yaw = yawRadians();
      return out;
   }

   bool localizedPose(exploration_legacy::Pose2D& out) const override
   {
      if (!loc_pose_provider_) {
         return false;
      }

      const std::optional<exploration_legacy::Pose2D> provided = loc_pose_provider_();
      if (!provided.has_value()) {
         return false;
      }

      out = *provided;
      return true;
   }

   exploration_legacy::SensorSnapshot sensorSnapshot() const override
   {
      exploration_legacy::SensorSnapshot snapshot;
      snapshot.pose = pose();
      snapshot.yaw = snapshot.pose.yaw;
      snapshot.loc_pose_valid = localizedPose(snapshot.loc_pose);

      const double* rpy = Iunit ? Iunit->getRollPitchYaw() : nullptr;
      if (rpy) {
         snapshot.roll_rad = rpy[0];
         snapshot.pitch_rad = rpy[1];
         snapshot.yaw = webotsYawToRos(rpy[2]);
         snapshot.pose.yaw = snapshot.yaw;
      }

      if (lidar) {
         const int h = lidar->getHorizontalResolution();
         const int layers = std::max(1, lidar->getNumberOfLayers());
         const int selected_layer = layers >= 3 ? 2 : 0;
         const int base = selected_layer * h;
         snapshot.lidar_horizontal_resolution = h;

         const float* ranges = lidar->getRangeImage();
         if (ranges && h > 0) {
            snapshot.lidar_ranges.resize(h);
            for (int i = 0; i < h; ++i) {
               float value = ranges[base + i];
               if (!std::isfinite(value) || value <= 0.0f) {
                  value = 1.0f;
               }
               snapshot.lidar_ranges[i] = value;
            }
         }

         const LidarPoint* cloud = lidar->getPointCloud();
         if (cloud && h > 0) {
            snapshot.lidar_cloud_x.resize(h);
            snapshot.lidar_cloud_y.resize(h);
            for (int i = 0; i < h; ++i) {
               snapshot.lidar_cloud_x[i] = static_cast<float>(cloud[base + i].x);
               snapshot.lidar_cloud_y[i] = static_cast<float>(cloud[base + i].y);
            }
         }
      }

      if (colorSensor) {
         const auto floor_sample = readColourSensorClassification(colorSensor);
         snapshot.floor_r = floor_sample.r;
         snapshot.floor_g = floor_sample.g;
         snapshot.floor_b = floor_sample.b;
      }

      if (dsensor) {
         snapshot.distance_sensor_value = dsensor->getValue();
         snapshot.distance_sensor_valid = std::isfinite(snapshot.distance_sensor_value);
      }

      return snapshot;
   }

   double leftWheelPositionRad() const override
   {
      return leftEncoders ? leftEncoders->getValue() : 0.0;
   }

   double rightWheelPositionRad() const override
   {
      return rightEncoders ? rightEncoders->getValue() : 0.0;
   }

   void setWheelTargetPosition(double left_rad, double right_rad) override
   {
      target_left_rad_ = left_rad;
      target_right_rad_ = right_rad;
      position_target_active_ = std::isfinite(left_rad) && std::isfinite(right_rad);
      wheel_left->setPosition(left_rad);
      wheel_right->setPosition(right_rad);
      applyPositionModeLidarGuard();
   }

   void setWheelVelocityLimit(double left_rad_s, double right_rad_s) override
   {
      requested_left_limit_rad_s_ = clampd(std::fabs(left_rad_s), 0.0, max_speed);
      requested_right_limit_rad_s_ = clampd(std::fabs(right_rad_s), 0.0, max_speed);
      wheel_left->setVelocity(requested_left_limit_rad_s_);
      wheel_right->setVelocity(requested_right_limit_rad_s_);
      applyPositionModeLidarGuard();
   }

   void setWheelVelocity(double left_rad_s, double right_rad_s) override
   {
      position_target_active_ = false;
      wheel_left->setPosition(INFINITY);
      wheel_right->setPosition(INFINITY);

      const double raw_left = clampd(left_rad_s, -max_speed, max_speed);
      const double raw_right = clampd(right_rad_s, -max_speed, max_speed);
      const auto guarded = applyVelocityGuardToWheelCommand(raw_left, raw_right);

      wheel_left->setVelocity(guarded.first);
      wheel_right->setVelocity(guarded.second);
   }

   void stop() override
   {
      const double left = leftWheelPositionRad();
      const double right = rightWheelPositionRad();

      wheel_left->setPosition(left);
      wheel_right->setPosition(right);
      wheel_left->setVelocity(0.0);
      wheel_right->setVelocity(0.0);
      position_target_active_ = false;
   }

private:
   static double directionSign(double value)
   {
      if (value > 1.0e-6) {
         return 1.0;
      }
      if (value < -1.0e-6) {
         return -1.0;
      }
      return 0.0;
   }

   std::pair<double, double> applyVelocityGuardToWheelCommand(
      double raw_left_rad_s,
      double raw_right_rad_s)
   {
      const double raw_v =
         0.5 * raioRoda * (raw_left_rad_s + raw_right_rad_s);
      const double raw_w =
         raioRoda * (raw_right_rad_s - raw_left_rad_s) / L;

      sensors::LidarVelocityGuardConfig lidar_guard_cfg;
      const auto lidar_guard = sensors::applyLidarVelocityGuard(
         raw_v,
         raw_w,
         getLidar(),
         lidar_guard_cfg
      );

      if (!lidar_guard.active) {
         return {
            clampd(raw_left_rad_s, -max_speed, max_speed),
            clampd(raw_right_rad_s, -max_speed, max_speed)
         };
      }

      logRobotEvent(
         "lidar_velocity_guard",
         {
            {"source", "legacy_motion_io"},
            {"reason", lidar_guard.reason},
            {"raw_v", numberText(raw_v, 4)},
            {"raw_w", numberText(raw_w, 4)},
            {"safe_v", numberText(lidar_guard.v, 4)},
            {"safe_w", numberText(lidar_guard.w, 4)},
            {"sector_index", std::to_string(lidar_guard.sector_index)},
            {"sector_angle", numberText(lidar_guard.sector_angle_rad, 3)},
            {"sector_min_range", numberText(lidar_guard.sector_min_range_m, 4)},
            {"closing_speed", numberText(lidar_guard.closing_speed_mps, 4)},
            {"sectors", std::to_string(lidar_guard_cfg.sectors)}
         });

      const double safe_left =
         (lidar_guard.v - lidar_guard.w * (L / 2.0)) / raioRoda;
      const double safe_right =
         (lidar_guard.v + lidar_guard.w * (L / 2.0)) / raioRoda;

      return {
         clampd(safe_left, -max_speed, max_speed),
         clampd(safe_right, -max_speed, max_speed)
      };
   }

   void applyPositionModeLidarGuard()
   {
      if (!position_target_active_) {
         return;
      }

      const double left_remaining = target_left_rad_ - leftWheelPositionRad();
      const double right_remaining = target_right_rad_ - rightWheelPositionRad();
      const double raw_left =
         directionSign(left_remaining) * requested_left_limit_rad_s_;
      const double raw_right =
         directionSign(right_remaining) * requested_right_limit_rad_s_;

      const auto guarded = applyVelocityGuardToWheelCommand(raw_left, raw_right);
      wheel_left->setVelocity(std::fabs(guarded.first));
      wheel_right->setVelocity(std::fabs(guarded.second));
   }

   std::function<void()> on_step_;
   std::function<std::optional<exploration_legacy::Pose2D>()> loc_pose_provider_;
   bool position_target_active_ = false;
   double target_left_rad_ = 0.0;
   double target_right_rad_ = 0.0;
   double requested_left_limit_rad_s_ = 0.0;
   double requested_right_limit_rad_s_ = 0.0;
};

static void sendCameraFrameIfReady(const std::string& name, Camera* camera, double t)
{
    if (!bridge_client || camera == nullptr) return;

    const unsigned char* image = camera->getImage();
    if (image == nullptr) return;

    const int w = camera->getWidth();
    const int h = camera->getHeight();
    const double fov = camera->getFov();

    bridge_client->sendCameraFrame(
        name, t, w, h, fov, image, static_cast<std::size_t>(w) * static_cast<std::size_t>(h) * 4
    );
}

// Runs the in-process vision pipeline synchronously on one camera frame.
// Replaces the old TCP enqueue (enqueueVisionFrameIfReady): builds the frame
// metadata, applies the optional lidar gate, runs the pipeline and returns the
// detection (if accepted) as a controller-side result. std::nullopt means no
// frame processed or no detection.
static std::optional<VisionDetectionResult> runVisionOnCamera(
    int camera_id,
    Camera* camera,
    double t,
    const std::vector<float>& scan,
    const GpsLocal& estimated_pose,
    double estimated_yaw_ros,
    int tile_x,
    int tile_y,
    float yaw_offset_rad,
    bool lidar_gate_enabled,
    int lidar_gate_min_consecutive_rays,
    double lidar_gate_max_range_m,
    bool log_rejection = true,
    VisionRejectionHint* rejection_hint = nullptr)
{
    if (!vision_runtime_ptr || camera == nullptr) return std::nullopt;

    const unsigned char* image = camera->getImage();
    if (image == nullptr) return std::nullopt;

    if (lidar_gate_enabled) {
       int close_rays = 0;
       int max_run = 0;
       if (!visionLidarGatePasses(scan,
                                  camera->getFov(),
                                  yaw_offset_rad,
                                  lidar_gate_min_consecutive_rays,
                                  lidar_gate_max_range_m,
                                  &close_rays,
                                  &max_run))
       {
          logRobotEvent(
             "vision_frame_lidar_gated",
             {
                {"camera", camera_id == 0 ? "left" : "right"},
                {"tile", "(" + std::to_string(tile_x) + "," + std::to_string(tile_y) + ")"},
                {"close_rays", std::to_string(close_rays)},
                {"max_consecutive", std::to_string(max_run)},
                {"required_consecutive", std::to_string(lidar_gate_min_consecutive_rays)},
                {"max_range", numberText(lidar_gate_max_range_m, 3)},
             });
          return std::nullopt;
       }
    }

    vision_runtime::VisionFrameMeta meta;
    static std::uint64_t vision_seq = 0;
    meta.seq = ++vision_seq;
    meta.stamp_s = t;
    meta.camera_id = camera_id;
    meta.camera_hfov_rad = static_cast<float>(camera->getFov());
    meta.camera_vfov_rad = static_cast<float>(camera->getFov());
    meta.camera_yaw_offset_rad = yaw_offset_rad;
    meta.robot_x = static_cast<float>(estimated_pose.x);
    meta.robot_y = static_cast<float>(estimated_pose.y);
    meta.robot_yaw = static_cast<float>(estimated_yaw_ros);
    meta.tile_x = tile_x;
    meta.tile_y = tile_y;
    meta.lidar_angle_min = -3.14159265f;
    meta.lidar_angle_increment = scan.empty()
        ? 0.0f
        : static_cast<float>((2.0 * M_PI) / static_cast<double>(scan.size()));
    meta.lidar_range_min = 0.01f;
    meta.lidar_range_max = 1.0f;

    std::string reject_reason;
    auto detection = vision_runtime_ptr->process(
        camera->getWidth(),
        camera->getHeight(),
        image,
        scan,
        meta,
        reject_reason);

    if (!detection) {
       if (rejection_hint != nullptr) {
          rejection_hint->valid = !reject_reason.empty();
          rejection_hint->seq = meta.seq;
          rejection_hint->camera = camera_id == 0 ? "left" : "right";
          rejection_hint->tile_x = tile_x;
          rejection_hint->tile_y = tile_y;
          rejection_hint->reason = reject_reason;
       }
       if (log_rejection) {
          logRobotEvent(
             "vision_detection_rejected",
             {
                {"camera", camera_id == 0 ? "left" : "right"},
                {"tile", "(" + std::to_string(tile_x) + "," + std::to_string(tile_y) + ")"},
                {"reason", reject_reason.empty() ? "none" : reject_reason},
                {"seq", std::to_string(meta.seq)},
             });
       }
       return std::nullopt;
    }

    auto result = visionDetectionToResult(*detection);
    result.image_width = static_cast<double>(camera->getWidth());
    return result;
}

PID pid_giro(92.9, 0.0, 0.0);

void girarAbsoluto(double targetYaw)
{
   // Normaliza targetYaw
   targetYaw = pi_interval(targetYaw);
   while (robot->step(timeStep) != -1)
   {
      double currentYaw = Iunit->getRollPitchYaw()[2]; // Obtém o ângulo atual do IMU
      double error = pi_interval(targetYaw - currentYaw);
      if (fabs(error) < 0.001)
         break; // tolerância ~0.57°
      double control = pid_giro.calcular(0, -error, dt);
      // Converte controle angular em velocidade das rodas (rotate in place)
      control = clampd(control, -max_speed, max_speed); // Limita a velocidade de controle
      wheel_left->setVelocity(control);
      wheel_right->setVelocity(-control);
   }
   // Para o movimento
   wheel_left->setVelocity(0);
   wheel_right->setVelocity(0);
   // Reseta o PID após a rotação
   pid_giro.reset();
   robot->step(timeStep);
}

static std::vector<std::string> splitSubmissionMatrixRows(const std::string& matrix_text)
{
   std::vector<std::string> rows;
   std::stringstream ss(matrix_text);
   std::string row;

   while (std::getline(ss, row)) {
      if (!row.empty() && row.back() == '\r') {
         row.pop_back();
      }

      if (!row.empty()) {
         rows.push_back(row);
      }
   }

   return rows;
}

static bool enviarSubmissionMatrix(const std::string& matrix_text)
{
   if (!robot || !emitter) {
      diag::log(
         diag::Level::Error,
         "ROBOT_EVENT node=main event=submission_matrix_send_failed reason=robot_or_emitter_null"
      );
      return false;
   }

   const std::vector<std::string> rows = splitSubmissionMatrixRows(matrix_text);

   if (rows.empty() || rows.front().empty()) {
      diag::log(
         diag::Level::Error,
         "ROBOT_EVENT node=main event=submission_matrix_send_failed reason=empty_matrix"
      );
      return false;
   }

   const int height = static_cast<int>(rows.size());
   const int width = static_cast<int>(rows.front().size());

   for (const std::string& row : rows) {
      if (static_cast<int>(row.size()) != width) {
         diag::log(
            diag::Level::Error,
            "ROBOT_EVENT node=main event=submission_matrix_send_failed reason=irregular_matrix"
         );
         return false;
      }
   }

   std::string flattened;
   flattened.reserve(static_cast<std::size_t>(width * height * 2));

   for (int r = 0; r < height; ++r) {
      for (int c = 0; c < width; ++c) {
         flattened.push_back(rows[r][c]);
         flattened.push_back(',');
      }
   }

   if (!flattened.empty()) {
      flattened.pop_back();
   }

   std::vector<char> message(8 + flattened.size());

   // Erebus reshapes the row-major payload with np.array(...).reshape(shape)
   // where shape = struct.unpack('2i', first 8 bytes) (see Robot.set_message).
   // The data is flattened row-major over (height rows, width cols), so the
   // shape header MUST be (height, width) = (rows, cols). Sending (width,
   // height) scrambles any non-square map (reshape mismatch -> ~0 score).
   std::memcpy(message.data(), &height, sizeof(height));
   std::memcpy(message.data() + 4, &width, sizeof(width));
   std::memcpy(message.data() + 8, flattened.data(), flattened.size());

   robot->step(timeStep);

   emitter->send(message.data(), message.size());

   char msg = 'M';
   emitter->send(&msg, sizeof(msg));

   msg = 'E';
   emitter->send(&msg, sizeof(msg));

   robot->step(timeStep);
   robot->step(timeStep);

   diag::log(
      diag::Level::Info,
      "ROBOT_EVENT node=main event=submission_matrix_sent"
   );

   std::cout << "[SUBMISSION] Matriz enviada. width="
             << width
             << " height="
             << height
             << " payload_size="
             << flattened.size()
             << std::endl;

   return true;
}

struct GameInformation {
   bool valid = false;
   double score = 0.0;
   double remaining_time_s = 0.0;
};

static void requestGameInformation()
{
   if (!emitter) {
      return;
   }

   char msg = 'G';
   emitter->send(&msg, sizeof(msg));
}

static std::optional<GameInformation> receiveLatestGameInformation()
{
   if (!receiver) {
      return std::nullopt;
   }

   std::optional<GameInformation> latest;

   while (receiver->getQueueLength() > 0) {
      const int size = receiver->getDataSize();
      const unsigned char* data = static_cast<const unsigned char*>(receiver->getData());

      if (data != nullptr && size >= 1 && data[0] == static_cast<unsigned char>('G')) {
         GameInformation info;
         info.valid = true;

         // Erebus sends the game-info packet as native Python/C layout for
         // "c f i": byte 0 is 'G', then padding, float score, int time left.
         if (size >= 12) {
            float score = 0.0f;
            int remaining_time = 0;
            std::memcpy(&score, data + 4, sizeof(score));
            std::memcpy(&remaining_time, data + 8, sizeof(remaining_time));
            info.score = static_cast<double>(score);
            info.remaining_time_s = static_cast<double>(remaining_time);
            latest = info;
         } else if (size >= 9) {
            float score = 0.0f;
            int remaining_time = 0;
            std::memcpy(&score, data + 1, sizeof(score));
            std::memcpy(&remaining_time, data + 5, sizeof(remaining_time));
            info.score = static_cast<double>(score);
            info.remaining_time_s = static_cast<double>(remaining_time);
            latest = info;
         }
      }

      receiver->nextPacket();
   }

   return latest;
}
// main

int main(int argc, char **argv) {
   diag::log(diag::Level::Info, "[MAIN] Iniciando...");

   const RuntimeTimingConfig timing = loadRuntimeTimingConfig(timeStep);

   const bool race_mode = envFlagEnabled("RACE_MODE", false);
   const std::string explorer_backend = envString("EXPLORER_BACKEND", "continuous");
   const bool legacy_explorer_enabled = explorer_backend == "legacy";
   const bool vision_enabled = envFlagEnabled("START_VISION", false);
   const bool legacy_cam_hex_debug = envFlagEnabled("LEGACY_CAM_HEX_DEBUG", false);
   const double vision_hold_duration_s = clampd(
      envDouble("VISION_CLASSIFY_HOLD_S", 1.2),
      1.0,
      1.5
   );
   const bool vision_hold_after_tile_advance = envFlagEnabled("VISION_HOLD_AFTER_TILE_ADVANCE", false);
   const double vision_min_result_confidence =
      clampd(envDouble("VISION_MIN_RESULT_CONFIDENCE", 0.0), 0.0, 1.0);
   g_vision_victim_report_min_confidence =
      clampd(envDouble("VISION_VICTIM_REPORT_MIN_CONFIDENCE", 0.72), 0.0, 1.0);
   g_vision_victim_small_bbox_min_confidence =
      clampd(envDouble("VISION_VICTIM_SMALL_BBOX_MIN_CONFIDENCE", 0.86), 0.0, 1.0);
   g_vision_victim_small_bbox_area_px =
      std::max(0, static_cast<int>(std::lround(envDouble("VISION_VICTIM_SMALL_BBOX_AREA_PX", 144.0))));
   g_vision_victim_small_bbox_width_px =
      std::max(0, static_cast<int>(std::lround(envDouble("VISION_VICTIM_SMALL_BBOX_WIDTH_PX", 8.0))));
   g_vision_victim_report_min_center_y_px =
      envDouble("VISION_VICTIM_REPORT_MIN_CENTER_Y_PX", 44.0);
   g_vision_victim_small_bbox_height_px =
      std::max(0, static_cast<int>(std::lround(envDouble("VISION_VICTIM_SMALL_BBOX_HEIGHT_PX", 8.0))));
   g_vision_target_report_min_confidence =
      clampd(envDouble("VISION_TARGET_REPORT_MIN_CONFIDENCE", 0.0), 0.0, 1.0);
   g_vision_target_report_min_area_px =
      std::max(0, static_cast<int>(std::lround(envDouble("VISION_TARGET_REPORT_MIN_AREA_PX", 340.0))));
   g_vision_target_report_min_width_px =
      std::max(0, static_cast<int>(std::lround(envDouble("VISION_TARGET_REPORT_MIN_WIDTH_PX", 0.0))));
   g_vision_target_report_min_height_px =
      std::max(0, static_cast<int>(std::lround(envDouble("VISION_TARGET_REPORT_MIN_HEIGHT_PX", 0.0))));
   const bool vision_lidar_gate_enabled =
      envFlagEnabled("VISION_LIDAR_GATE_ENABLED", false);
   const int vision_lidar_gate_min_consecutive_rays = std::max(
      1,
      static_cast<int>(envDouble("VISION_LIDAR_GATE_MIN_CONSECUTIVE_RAYS", 5.0))
   );
   const double vision_lidar_gate_max_range_m = std::max(
      0.0,
      envDouble("VISION_LIDAR_GATE_MAX_RANGE_M", 0.06)
   );
   const bool vision_align_adjust = envFlagEnabled("VISION_ALIGN_AJUST", true);
   const double vision_align_max_time_s = clampd(
      envDouble("VISION_ALIGN_MAX_TIME_S", 0.8),
      0.0,
      2.0
   );
   const double vision_align_threshold_px = std::max(
      0.0,
      envDouble("VISION_ALIGN_THRESHOLD_PX", 8.0)
   );
   const double vision_align_max_angular_rad_s = clampd(
      envDouble("VISION_ALIGN_MAX_ANGULAR_RAD_S", 0.75),
      0.05,
      kMaxAngularVel
   );
   const double vision_align_kp = std::max(
      0.0,
      envDouble("VISION_ALIGN_KP", 2.0)
   );
   const bool vision_align_restore_heading =
      envFlagEnabled("VISION_ALIGN_RESTORE_HEADING", false);
   const double vision_align_restore_max_time_s = clampd(
      envDouble("VISION_ALIGN_RESTORE_MAX_TIME_S", 1.6),
      0.0,
      3.0
   );
   const double vision_align_restore_threshold_rad = std::max(
      0.0,
      envDouble("VISION_ALIGN_RESTORE_THRESHOLD_RAD", 0.035)
   );
   const double vision_align_restore_kp = std::max(
      0.0,
      envDouble("VISION_ALIGN_RESTORE_KP", 2.0)
   );
   const bool vision_target_gate_search_enabled =
      envFlagEnabled("VISION_TARGET_GATE_SEARCH_ENABLED", true);
   const double vision_target_gate_search_time_s = clampd(
      envDouble("VISION_TARGET_GATE_SEARCH_TIME_S", 1.0),
      0.0,
      2.0
   );
   const double vision_target_gate_search_angular_rad_s = clampd(
      envDouble("VISION_TARGET_GATE_SEARCH_ANGULAR_RAD_S", 0.45),
      0.05,
      kMaxAngularVel
   );
   const double race_sim_time_limit_s = std::max(
      0.0,
      envDouble("RACE_SIM_TIME_LIMIT_S", kDefaultRaceTimeLimitS)
   );
   const double submission_deadline_margin_s = std::max(
      0.0,
      envDouble("RACE_SUBMISSION_DEADLINE_MARGIN_S", kDefaultSubmissionDeadlineMarginS)
   );
   const bool game_information_enabled = receiver != nullptr;
   const bool submission_deadline_enabled =
      game_information_enabled || race_sim_time_limit_s > 0.0;
   const float vision_left_yaw_offset = static_cast<float>(
      envDouble("VISION_LEFT_YAW_OFFSET_RAD", 1.57079632679)
   );
   const float vision_right_yaw_offset = static_cast<float>(
      envDouble("VISION_RIGHT_YAW_OFFSET_RAD", -1.57079632679)
   );
   const double race_bootstrap_yaw = pi_interval(envDouble("RACE_BOOTSTRAP_YAW", 0.0));
   const double black_hole_brake_hold_ms = std::max(
      0.0,
      envDouble("RACE_BLACK_HOLE_BRAKE_MS", kDefaultBlackHoleBrakeHoldMs)
   );
   const double black_hole_brake_hold_s = black_hole_brake_hold_ms / 1000.0;
   const double black_hole_reverse_ms = std::max(
      0.0,
      envDouble("RACE_BLACK_HOLE_REVERSE_MS", kDefaultBlackHoleReverseMs)
   );
   const double black_hole_reverse_s = black_hole_reverse_ms / 1000.0;
   const double black_hole_reverse_speed = -std::fabs(
      envDouble("RACE_BLACK_HOLE_REVERSE_SPEED", kDefaultBlackHoleReverseSpeed)
   );
   const double black_hole_brake_min_confidence = clampd(
      envDouble("RACE_BLACK_HOLE_BRAKE_CONFIDENCE", kDefaultBlackHoleBrakeMinConfidence),
      0.0,
      1.0
   );
   diag::log(
      diag::Level::Info,
      "[submission] deadline_enabled=", boolText(submission_deadline_enabled),
      " game_information_enabled=", boolText(game_information_enabled),
      " time_limit_s=", numberText(race_sim_time_limit_s, 3),
      " margin_s=", numberText(submission_deadline_margin_s, 3)
   );
   localization::LocalizerConfig localization_config;
   localization_config.wheel_radius_m = raioRoda;
   localization_config.wheel_base_m = L;
   localization_config.gps_alpha = clampd(
      envDouble("LOCALIZATION_GPS_ALPHA", localization_config.gps_alpha),
      0.0,
      1.0
   );
   localization_config.gps_gate_m = std::max(
      0.0,
      envDouble("LOCALIZATION_GPS_GATE_M", localization_config.gps_gate_m)
   );
   localization_config.gps_hard_reject_m = std::max(
      localization_config.gps_gate_m,
      envDouble("LOCALIZATION_GPS_HARD_REJECT_M", localization_config.gps_hard_reject_m)
   );
   localization_config.gps_sigma_m = std::max(
      0.001,
      envDouble("LOCALIZATION_GPS_SIGMA_M", localization_config.gps_sigma_m)
   );
   localization_config.freeze_translation_on_slip =
      envFlagEnabled("LOCALIZATION_FREEZE_ON_SLIP", localization_config.freeze_translation_on_slip);
   const bool localization_debug = envFlagEnabled("LOCALIZATION_DEBUG", false);
   localization::Localizer2D localizer(localization_config);

   wheel_left->setPosition(INFINITY);
   wheel_right->setPosition(INFINITY);

   lidar->enable(timeStep);
   lidar->enablePointCloud();
   lidarH = lidar->getHorizontalResolution();

   gps->enable(timeStep);
   Iunit->enable(timeStep);
   if (dsensor) {
      dsensor->enable(timeStep);
   }
   if (receiver) {
      receiver->enable(timeStep);
   }

   bool use_nav2 = !legacy_explorer_enabled;
   bool use_cam  = legacy_cam_hex_debug;
   const bool camera_runtime_enabled = use_cam || vision_enabled;

   Pose2D local_pose{};
   localization::LocalizerState localization_state{};
   WheelOdometry wheel_odom(raioRoda, L);

   colorSensor->enable(timeStep);
   if (camera_runtime_enabled) {
      came->enable(timeStep);
      camd->enable(timeStep);
      came->setFov(1.5);
      camd->setFov(1.5);
   }

   leftEncoders->enable(timeStep);
   rightEncoders->enable(timeStep);

   keyboard->enable(timeStep);

   robot->step(timeStep);

   const double *gps_init = gps->getValues();
   gpsX0 = gps_init ? gps_init[0] : 0.0;
   gpsY0 = gps_init ? gps_init[2] : 0.0;

   const double turn_angle = rosYawToWebots(race_bootstrap_yaw);
   girarAbsoluto(turn_angle);

   wheel_left->setVelocity(0.0);
   wheel_right->setVelocity(0.0);

   const GpsLocal race_gps0 = getGps();

   std::unique_ptr<WebotsLegacyMotionIO> legacy_io;
   std::unique_ptr<exploration_legacy::MotionExecutor> legacy_motion;
   std::unique_ptr<exploration_legacy::LegacyGridMap> legacy_map;
   std::unique_ptr<exploration_legacy::WallDetector> legacy_walls;
   std::unique_ptr<exploration_legacy::LegacyPlanner> legacy_planner;
   std::unique_ptr<exploration_legacy::LegacyExplorer> legacy_explorer;
   std::unique_ptr<exploration_legacy::LegacyReachabilityChecker> legacy_reachability;
   bool legacy_reachability_fallback_enabled = true;
   bool legacy_finished_logged = false;

   bool submission_sent = false;
   double legacy_finished_detected_t = -1.0;

   std::string latest_submission_matrix;
   bool has_latest_submission_matrix = false;
   double latest_submission_matrix_t = -1.0;
   bool submission_deadline_reached_logged = false;
   bool submission_deadline_no_matrix_logged = false;
   bool has_game_information = false;
   double latest_game_information_t = -1.0;
   double latest_game_score = 0.0;
   double latest_game_remaining_time_s = -1.0;
   double last_game_information_request_t = -1.0;

   VisionRuntimePhase vision_phase = VisionRuntimePhase::Idle;
   double vision_hold_start_t = -1.0;
   double vision_align_start_t = -1.0;
   exploration_legacy::TileCoord vision_hold_tile{};
   exploration_legacy::TileCoord vision_align_tile{};
   std::set<std::pair<int, int>> vision_checked_tiles;
   std::set<std::string> reported_vision_keys;
   std::vector<VisionDetectionResult> pending_vision_results;
   std::optional<VisionDetectionResult> vision_align_last_result;
   bool vision_align_attempted_for_hold = false;
   bool vision_align_restore_needed = false;
   double vision_align_restore_yaw_ros = std::numeric_limits<double>::quiet_NaN();
   bool vision_target_gate_search_active = false;
   double vision_target_gate_search_direction = 1.0;
   bool vision_initial_hold_considered = false;

   // Mid-movement vision interrupt: the per-step motion pump runs vision while
   // the robot drives between tiles. When it sees a reportable victim/target on
   // a tile that has NOT yet been reported, it raises this flag; the MotionExecutor
   // aborts the current drive, and the main loop then runs the normal classify
   // hold + align + report for that tile. Per-tile dedup keeps already-reported
   // tiles from triggering again.
   bool vision_interrupt_active = false;
   exploration_legacy::TileCoord vision_interrupt_tile{};
   VisionDetectionResult vision_interrupt_result;
   double last_vision_scan_t = -1.0;
   bool vision_next_interrupt_left_first = true;
   bool vision_next_hold_left_first = true;
   // Throttle for the mid-movement pump scan (SIM seconds). The pump runs on
   // every internal motion step; without a coarse gate the full 2-camera pipeline
   // ran thousands of times and tripled the per-tile loop time (425->1128 ms).
   // The robot crosses a tile in ~0.5 s at 0.125 m/s, so ~0.25 s still gives a
   // couple of scans per tile while keeping navigation responsive.
   const double vision_pump_scan_interval_s =
      std::max(0.05, envDouble("VISION_PUMP_SCAN_INTERVAL_S", 0.25));

   struct PendingLegacyHoleTarget {
      bool valid = false;
      exploration_legacy::TileCoord current{};
      exploration_legacy::TileCoord target{};
      std::string direction;
   };
   PendingLegacyHoleTarget pending_hole_target;

   auto pollLatestSubmissionMatrix = [&](double now) {
      std::string incoming_submission_matrix;
      if (bridge_client && bridge_client->receiveSubmissionMatrix(incoming_submission_matrix)) {
         latest_submission_matrix = incoming_submission_matrix;
         has_latest_submission_matrix = true;
         latest_submission_matrix_t = now;

         diag::log(
            diag::Level::Info,
            "ROBOT_EVENT node=main event=submission_matrix_received"
         );
      }
   };

   auto pollGameInformation = [&](double now) {
      if (!game_information_enabled) {
         return;
      }

      if (last_game_information_request_t < 0.0 ||
          (now - last_game_information_request_t) >= kGameInformationRequestPeriodS)
      {
         requestGameInformation();
         last_game_information_request_t = now;
      }

      const auto info = receiveLatestGameInformation();
      if (!info || !info->valid) {
         return;
      }

      has_game_information = true;
      latest_game_information_t = now;
      latest_game_score = info->score;
      latest_game_remaining_time_s = info->remaining_time_s;
   };

   auto trySubmitOnSimulationDeadline = [&](double now) {
      if (submission_sent || !submission_deadline_enabled) {
         return;
      }

      double remaining_s = 0.0;
      std::string deadline_source;

      if (has_game_information) {
         remaining_s = latest_game_remaining_time_s -
            std::max(0.0, now - latest_game_information_t);
         deadline_source = "game_information";
      } else if (race_sim_time_limit_s > 0.0) {
         remaining_s = race_sim_time_limit_s - now;
         deadline_source = "sim_time_fallback";
      } else {
         return;
      }

      if (remaining_s > submission_deadline_margin_s) {
         return;
      }

      if (!submission_deadline_reached_logged) {
         submission_deadline_reached_logged = true;
         logRobotEvent(
            "submission_deadline_reached",
            {
               {"sim_time", numberText(now, 3)},
               {"time_limit_s", numberText(race_sim_time_limit_s, 3)},
               {"remaining_s", numberText(remaining_s, 3)},
               {"margin_s", numberText(submission_deadline_margin_s, 3)},
               {"source", deadline_source},
               {"game_score", numberText(latest_game_score, 3)},
               {"has_matrix", boolText(has_latest_submission_matrix)},
            });
      }

      if (!has_latest_submission_matrix) {
         if (!submission_deadline_no_matrix_logged) {
            submission_deadline_no_matrix_logged = true;
            diag::log(
               diag::Level::Warn,
               "ROBOT_EVENT node=main event=submission_matrix_waiting reason=deadline_reached_no_mapper_submission_matrix"
            );
         }
         return;
      }

      submission_sent = enviarSubmissionMatrix(latest_submission_matrix);
      if (!submission_sent) {
         diag::log(
            diag::Level::Error,
            "ROBOT_EVENT node=main event=submission_matrix_send_failed reason=deadline_enviarSubmissionMatrix_returned_false"
         );
      }
   };

   if (legacy_explorer_enabled) {
      legacy_io = std::make_unique<WebotsLegacyMotionIO>();
      legacy_io->setLocalizationPoseProvider([&localization_state]() -> std::optional<exploration_legacy::Pose2D> {
         if (!localization_state.initialized ||
             !std::isfinite(localization_state.x_m) ||
             !std::isfinite(localization_state.y_m) ||
             !std::isfinite(localization_state.yaw_rad))
         {
            return std::nullopt;
         }

         exploration_legacy::Pose2D pose;
         pose.x = localization_state.x_m;
         pose.y = localization_state.y_m;
         pose.yaw = localization_state.yaw_rad;
         return pose;
      });
      auto legacy_log = [
         &legacy_io,
         &bridge_client,
         &legacy_explorer,
         &pending_hole_target
      ](const std::string& msg) {
         diag::log(diag::Level::Info, msg);

         auto extractStringField = [](const std::string& text, const std::string& key)
            -> std::optional<std::string>
         {
            const auto key_pos = text.find(key);
            if (key_pos == std::string::npos) {
               return std::nullopt;
            }

            const auto value_begin = key_pos + key.size();
            const auto value_end = text.find(' ', value_begin);
            return text.substr(value_begin, value_end - value_begin);
         };

         auto extractDoubleField = [](const std::string& text, const std::string& key)
            -> std::optional<double>
         {
            const auto key_pos = text.find(key);
            if (key_pos == std::string::npos) {
               return std::nullopt;
            }

            const auto value_begin = key_pos + key.size();
            const auto value_end = text.find(' ', value_begin);
            const auto value = text.substr(value_begin, value_end - value_begin);

            try {
               return std::stod(value);
            } catch (const std::exception&) {
               return std::nullopt;
            }
         };

         auto extractTileField = [](const std::string& text, const std::string& key)
            -> std::optional<exploration_legacy::TileCoord>
         {
            const auto key_pos = text.find(key);
            if (key_pos == std::string::npos) {
               return std::nullopt;
            }

            const auto tuple_begin = text.find('(', key_pos + key.size());
            if (tuple_begin == std::string::npos) {
               return std::nullopt;
            }
            const auto comma = text.find(',', tuple_begin + 1);
            const auto tuple_end = text.find(')', tuple_begin + 1);
            if (
               comma == std::string::npos ||
               tuple_end == std::string::npos ||
               comma > tuple_end)
            {
               return std::nullopt;
            }

            try {
               exploration_legacy::TileCoord coord;
               coord.x = std::stoi(text.substr(tuple_begin + 1, comma - tuple_begin - 1));
               coord.y = std::stoi(text.substr(comma + 1, tuple_end - comma - 1));
               return coord;
            } catch (const std::exception&) {
               return std::nullopt;
            }
         };

         if (
            msg.find("node=legacy_explorer event=planner_decision") !=
            std::string::npos)
         {
            const auto current = extractTileField(msg, "current=");
            const auto target = extractTileField(msg, "target=");
            const auto direction = extractStringField(msg, "dir=");

            if (current && target && direction && !direction->empty()) {
               pending_hole_target.valid = true;
               pending_hole_target.current = *current;
               pending_hole_target.target = *target;
               pending_hole_target.direction = *direction;
            }
            return;
         }

         if (
            msg.find("node=legacy_motion event=drive_hole_detected") ==
            std::string::npos)
         {
            return;
         }

         if (!legacy_io || !bridge_client) {
            return;
         }

         const auto snapshot = legacy_io->sensorSnapshot();
         const bool detected_by_color =
            std::max({snapshot.floor_r, snapshot.floor_g, snapshot.floor_b}) <= 100;
         const std::string source =
            detected_by_color ? "floor_color" : "distance_sensor";
         const double confidence = detected_by_color ? 1.0 : 0.95;

         const auto requested_distance =
            extractDoubleField(msg, "requested=");
         const auto traveled_before_stop =
            extractDoubleField(msg, "traveled_before_stop=");

         const auto legacy_tile = legacy_explorer
            ? legacy_explorer->currentTile()
            : exploration_legacy::TileCoord{-1, -1};
         const bool legacy_tile_is_center =
            legacy_explorer &&
            legacy_tile.x % 2 == 0 &&
            legacy_tile.y % 2 == 0;

         const exploration_legacy::TileCoord planned_current =
            pending_hole_target.valid
               ? pending_hole_target.current
               : legacy_tile;
         const exploration_legacy::TileCoord planned_target =
            pending_hole_target.valid
               ? pending_hole_target.target
               : exploration_legacy::TileCoord{-1, -1};
         const std::string planned_direction =
            pending_hole_target.valid ? pending_hole_target.direction : "UNKNOWN";

         bridge_client->sendHoleDetection(
            snapshot.pose.x,
            snapshot.pose.y,
            snapshot.pose.yaw,
            source,
            confidence,
            planned_direction,
            planned_current.x,
            planned_current.y,
            planned_target.x,
            planned_target.y,
            requested_distance.value_or(-1.0),
            traveled_before_stop.value_or(-1.0));

         logRobotEvent(
            diag::Level::Warn,
            "legacy_hole_detection_sent",
            {
               {"robot_world_x", numberText(snapshot.pose.x, 4)},
               {"robot_world_y", numberText(snapshot.pose.y, 4)},
               {"robot_yaw", numberText(snapshot.pose.yaw, 4)},
               {"source", source},
               {"confidence", numberText(confidence, 3)},
               {"legacy_tile", "(" + std::to_string(legacy_tile.x) + "," + std::to_string(legacy_tile.y) + ")"},
               {"legacy_tile_center", legacy_tile_is_center ? "true" : "false"},
               {"planned_current", "(" + std::to_string(planned_current.x) + "," + std::to_string(planned_current.y) + ")"},
               {"planned_target", "(" + std::to_string(planned_target.x) + "," + std::to_string(planned_target.y) + ")"},
               {"planned_direction", planned_direction},
               {"requested_distance", requested_distance.has_value()
                  ? numberText(*requested_distance, 4)
                  : "unknown"},
               {"traveled_before_stop", traveled_before_stop.has_value()
                  ? numberText(*traveled_before_stop, 4)
                  : "unknown"},
               {"floor_rgb", "(" + std::to_string(snapshot.floor_r) + "," + std::to_string(snapshot.floor_g) + "," + std::to_string(snapshot.floor_b) + ")"},
               {"distance_sensor", numberText(snapshot.distance_sensor_value, 4)},
            });
      };

      const double legacy_graph_step_m = std::max(0.01, envDouble("LEGACY_GRAPH_STEP_M", 0.06));

      exploration_legacy::MotionExecutor::Config motion_cfg;
      motion_cfg.tile_size_m = legacy_graph_step_m;
      motion_cfg.wheel_radius_m = raioRoda;
      motion_cfg.axle_length_m = L;
      motion_cfg.max_wheel_speed_rad_s = max_speed;
      motion_cfg.linear_speed_mps = 0.122;
      motion_cfg.diagonal_linear_speed_mps = 0.11;
      motion_cfg.wheel_position_tolerance_rad = 0.06;
      motion_cfg.distance_validation_warn_m = 0.015;
      motion_cfg.stall_encoder_window_m = std::max(
         0.001,
         envDouble("LEGACY_STALL_ENCODER_WINDOW_M", motion_cfg.stall_encoder_window_m));
      motion_cfg.stall_loc_translation_epsilon_m = std::max(
         0.0,
         envDouble("LEGACY_STALL_LOC_EPSILON_M", motion_cfg.stall_loc_translation_epsilon_m));
      motion_cfg.stall_min_duration_s = std::max(
         0.0,
         envDouble("LEGACY_STALL_MIN_DURATION_S", motion_cfg.stall_min_duration_s));
      motion_cfg.stall_recovery_reverse_m = std::max(
         0.0,
         envDouble("LEGACY_STALL_RECOVERY_REVERSE_M", motion_cfg.stall_recovery_reverse_m));
      motion_cfg.stall_recovery_enabled =
         envFlagEnabled("LEGACY_STALL_RECOVERY_ENABLED", motion_cfg.stall_recovery_enabled);
      motion_cfg.debug_logs = true;
      motion_cfg.log_callback = legacy_log;
      // Abort the current drive/turn when the motion pump flags a reportable
      // mid-edge vision detection (handled below as a classify-hold).
      motion_cfg.abort_requested = [&vision_interrupt_active]() {
         return vision_interrupt_active;
      };

      exploration_legacy::WallDetector::Config wall_cfg;
      wall_cfg.robot_radius_m = 0.037;
      wall_cfg.wall_threshold_m = 0.061;
      wall_cfg.diagonal_wall_threshold_m = 0.061 * std::sqrt(2.0);
      wall_cfg.ray_delta = 64;
      wall_cfg.ray_pose_endpoint_tolerance_m = std::max(
         0.0,
         envDouble("LEGACY_RAY_POSE_ENDPOINT_TOLERANCE_M", wall_cfg.ray_pose_endpoint_tolerance_m));
      wall_cfg.validate_rays_with_loc_pose =
         envFlagEnabled("LEGACY_VALIDATE_RAYS_WITH_LOC", false);
      // Pose-corrected wall check (LIDAR freeing layer): reconstruct clearances
      // from the tile centre using the robot's localized offset, so an off-centre
      // robot stops over-blocking open directions. On by default.
      wall_cfg.correct_for_tile_center_offset =
         envFlagEnabled("LEGACY_WALL_CENTER_OFFSET_CORRECTION", wall_cfg.correct_for_tile_center_offset);
      wall_cfg.max_center_offset_m = std::max(
         0.0,
         envDouble("LEGACY_WALL_MAX_CENTER_OFFSET_M", wall_cfg.max_center_offset_m));

      exploration_legacy::LegacyExplorer::Config explorer_cfg;
      explorer_cfg.tile_size_m = legacy_graph_step_m;
      explorer_cfg.graph_subdivision = std::clamp(
         static_cast<int>(envDouble("LEGACY_GRAPH_SUBDIVISION", 1.0)),
         1,
         3);
      explorer_cfg.allow_diagonal = true;
      const bool legacy_reachability_env_value = envFlagEnabled(
         "LEGACY_REACHABILITY_FALLBACK_ENABLED",
         explorer_cfg.nav2_reachability_fallback);
      explorer_cfg.nav2_reachability_fallback = envFlagEnabled(
         "LEGACY_REACHABILITY_SECOND_CHECK_ENABLED",
         legacy_reachability_env_value);
      explorer_cfg.nav2_reachability_apply_to_map = envFlagEnabled(
         "LEGACY_REACHABILITY_APPLY_TO_MAP",
         true);
      explorer_cfg.local_lidar_low_confidence_override = envFlagEnabled(
         "LEGACY_LOCAL_LIDAR_LOW_CONFIDENCE_OVERRIDE",
         false);
      explorer_cfg.nav2_low_confidence_trial = envFlagEnabled(
         "LEGACY_NAV2_LOW_CONFIDENCE_TRIAL",
         explorer_cfg.nav2_low_confidence_trial);
      explorer_cfg.lidar_overrides_costmap_block = envFlagEnabled(
         "LEGACY_LIDAR_OVERRIDES_COSTMAP",
         explorer_cfg.lidar_overrides_costmap_block);
      explorer_cfg.nav2_infrastructure_retry_cooldown = std::chrono::milliseconds(
         static_cast<int>(std::max(0.0, envDouble(
            "LEGACY_REACHABILITY_INFRA_RETRY_MS",
            static_cast<double>(
               explorer_cfg.nav2_infrastructure_retry_cooldown.count())))));
      legacy_reachability_fallback_enabled = explorer_cfg.nav2_reachability_fallback;
      explorer_cfg.macro_tile_marking = envFlagEnabled("LEGACY_MACRO_TILE_MARKING", false);
      explorer_cfg.lidar_overrides_costmap_block =
         envFlagEnabled("LEGACY_LIDAR_OVERRIDES_COSTMAP", explorer_cfg.lidar_overrides_costmap_block);
      explorer_cfg.trust_live_lidar_cardinal_edges =
         envFlagEnabled("LEGACY_TRUST_LIVE_LIDAR_CARDINAL_EDGES", explorer_cfg.trust_live_lidar_cardinal_edges);
      explorer_cfg.trust_live_lidar_diagonal_edges =
         envFlagEnabled("LEGACY_TRUST_LIVE_LIDAR_DIAGONAL_EDGES", explorer_cfg.trust_live_lidar_diagonal_edges);
      explorer_cfg.debug_logs = true;
      explorer_cfg.log_callback = legacy_log;

      exploration_legacy::LegacyPlanner::Config planner_cfg;
      planner_cfg.direct_mode = exploration_legacy::LegacyPlanner::DirectMode::LeftHand;
      planner_cfg.diagonal_backtracking_cost = std::max(
         1.0,
         envDouble("LEGACY_DIAGONAL_BACKTRACKING_COST", planner_cfg.diagonal_backtracking_cost));

      legacy_motion = std::make_unique<exploration_legacy::MotionExecutor>(*legacy_io, motion_cfg);
      legacy_map = std::make_unique<exploration_legacy::LegacyGridMap>();
      legacy_walls = std::make_unique<exploration_legacy::WallDetector>(wall_cfg);
      legacy_planner = std::make_unique<exploration_legacy::LegacyPlanner>(planner_cfg);
      legacy_explorer = std::make_unique<exploration_legacy::LegacyExplorer>(
         *legacy_motion,
         *legacy_map,
         *legacy_walls,
         *legacy_planner,
         explorer_cfg
      );

      diag::log(
         diag::Level::Info,
         "ROBOT_EVENT node=legacy_explorer event=started backend=legacy "
         "algorithm=tile_dfs_left_hand movement=wheel_position_distance "
         "hole_safety=legacy_tile_blocking cmd_vel=disabled"
      );
      std::ostringstream config_log;
      const double graph_min_step_m =
         explorer_cfg.tile_size_m /
         static_cast<double>(1 << (std::max(1, explorer_cfg.graph_subdivision) - 1));
      config_log << std::fixed << std::setprecision(4)
         << "ROBOT_EVENT node=legacy_explorer event=config"
         << " algorithm=tile_dfs_left_hand"
         << " legacy_step_m=" << motion_cfg.tile_size_m
         << " graph_subdivision=" << explorer_cfg.graph_subdivision
         << " graph_min_step_m=" << graph_min_step_m
         << " macro_tile_marking=" << (explorer_cfg.macro_tile_marking ? 1 : 0)
         << " union_open_lidar_cardinal=" << (explorer_cfg.trust_live_lidar_cardinal_edges ? 1 : 0)
         << " union_open_lidar_diagonal=" << (explorer_cfg.trust_live_lidar_diagonal_edges ? 1 : 0)
         << " lidar_overrides_costmap=" << (explorer_cfg.lidar_overrides_costmap_block ? 1 : 0)
         << " planner_direct_mode=left_hand"
         << " planner_diagonal_backtracking_cost=" << planner_cfg.diagonal_backtracking_cost
         << " wall_threshold_m=" << wall_cfg.wall_threshold_m
         << " diagonal_wall_threshold_m=" << wall_cfg.diagonal_wall_threshold_m
         << " robot_radius_m=" << wall_cfg.robot_radius_m
         << " ray_delta=" << wall_cfg.ray_delta
         << " ray_loc_validation=" << (wall_cfg.validate_rays_with_loc_pose ? 1 : 0)
         << " ray_pose_endpoint_tolerance_m=" << wall_cfg.ray_pose_endpoint_tolerance_m
         << " wall_center_offset_correction=" << (wall_cfg.correct_for_tile_center_offset ? 1 : 0)
         << " wall_max_center_offset_m=" << wall_cfg.max_center_offset_m
         << " nav2_reachability_second_check=" << (explorer_cfg.nav2_reachability_fallback ? 1 : 0)
         << " nav2_reachability_apply_to_map=" << (explorer_cfg.nav2_reachability_apply_to_map ? 1 : 0)
         << " local_lidar_low_confidence_override="
         << (explorer_cfg.local_lidar_low_confidence_override ? 1 : 0)
         << " nav2_low_confidence_trial="
         << (explorer_cfg.nav2_low_confidence_trial ? 1 : 0)
         << " lidar_overrides_costmap=" << (explorer_cfg.lidar_overrides_costmap_block ? 1 : 0)
         << " nav2_reachability_infra_retry_ms="
         << explorer_cfg.nav2_infrastructure_retry_cooldown.count()
         << " stall_encoder_window_m=" << motion_cfg.stall_encoder_window_m
         << " stall_loc_epsilon_m=" << motion_cfg.stall_loc_translation_epsilon_m
         << " stall_min_duration_s=" << motion_cfg.stall_min_duration_s
         << " stall_recovery_reverse_m=" << motion_cfg.stall_recovery_reverse_m
         << " lidar_velocity_guard=legacy_motion_io"
         << " movement=wheel_position_distance";
      diag::log(diag::Level::Info, config_log.str());
   }

   bridge_client = make_unique<BridgeClient>();
   if (!bridge_client->connect()) {
      diag::log(diag::Level::Warn, "[MAIN] Bridge ROS indisponível. O robô vai ficar girando até conectar.");
   }

   if (legacy_explorer_enabled) {
      exploration_legacy::LegacyReachabilityChecker::Config reachability_cfg;
      reachability_cfg.allow_unknown =
         envFlagEnabled("LEGACY_REACHABILITY_ALLOW_UNKNOWN", reachability_cfg.allow_unknown);
      reachability_cfg.lethal_threshold = static_cast<int>(
         clampd(envDouble("LEGACY_REACHABILITY_LETHAL_THRESHOLD", reachability_cfg.lethal_threshold), 0.0, 255.0));
      reachability_cfg.alignment_tolerance_m = std::max(
         0.0,
         envDouble("LEGACY_REACHABILITY_ALIGNMENT_TOLERANCE_M", reachability_cfg.alignment_tolerance_m));
      reachability_cfg.max_sample_step_m = std::max(
         0.0,
         envDouble("LEGACY_REACHABILITY_MAX_SAMPLE_STEP_M", reachability_cfg.max_sample_step_m));
      reachability_cfg.max_costmap_age_s = std::max(
         0.0,
         envDouble("LEGACY_REACHABILITY_COSTMAP_MAX_AGE_S", reachability_cfg.max_costmap_age_s));
      reachability_cfg.timeout = std::chrono::milliseconds(static_cast<int>(std::max(
         1.0,
         envDouble("LEGACY_REACHABILITY_TIMEOUT_MS", static_cast<double>(reachability_cfg.timeout.count())))));
      reachability_cfg.log_callback = [](const std::string& msg) {
         diag::log(diag::Level::Info, msg);
      };

      legacy_reachability = std::make_unique<exploration_legacy::LegacyReachabilityChecker>(
         reachability_cfg,
         [&localization_state]() -> std::optional<exploration_legacy::Pose2D> {
            if (!localization_state.initialized ||
                !std::isfinite(localization_state.x_m) ||
                !std::isfinite(localization_state.y_m) ||
                !std::isfinite(localization_state.yaw_rad))
            {
               return std::nullopt;
            }

            exploration_legacy::Pose2D pose;
            pose.x = localization_state.x_m;
            pose.y = localization_state.y_m;
            pose.yaw = localization_state.yaw_rad;
            return pose;
         },
         [&bridge_client](
            const exploration_legacy::Pose2D& start,
            double goal_x_m,
            double goal_y_m,
            const std::vector<exploration_legacy::PathCandidate>& candidates,
            std::chrono::milliseconds timeout) {
            if (!bridge_client) {
               exploration_legacy::ReachabilityResult result;
               result.status = exploration_legacy::ReachabilityStatus::Timeout;
               result.reason = "bridge client unavailable";
               return result;
            }

            return bridge_client->requestLegacyReachability(
               start,
               goal_x_m,
               goal_y_m,
               candidates,
               timeout);
         });

      if (legacy_explorer) {
         legacy_explorer->setReachabilityChecker(legacy_reachability.get());
      }

      logRobotEvent(
         "legacy_reachability_ready",
         {
            {"api", "canReachMapCoordinate"},
            {"backend", "union_lidar_nav2_costmap"},
            {"called_by_exploration", "true"},
            {"fallback_enabled", boolText(legacy_reachability_fallback_enabled)},
            {"allow_unknown", boolText(reachability_cfg.allow_unknown)},
            {"lethal_threshold", std::to_string(reachability_cfg.lethal_threshold)},
            {"timeout_ms", std::to_string(reachability_cfg.timeout.count())},
         });
   }

   if (vision_enabled) {
      // In-process vision: the pipeline runs synchronously inside the controller
      // (no TCP, no ROS node, no frequency throttle), like localization::Localizer2D.
      const std::string vision_model_dir = envString("VISION_MODEL_DIR", "models");
      auto modelPath = [&](const char* file) {
         return vision_model_dir.empty() ? std::string(file)
                                         : vision_model_dir + "/" + file;
      };

      vision_runtime::VisionRuntimeConfig vision_cfg;
      vision_cfg.presence_model = envString("VISION_PRESENCE_MODEL", modelPath("presence.onnx"));
      vision_cfg.type_model = envString("VISION_TYPE_MODEL", modelPath("object_type.onnx"));
      vision_cfg.victim_bbox_model = envString("VISION_VICTIM_BBOX_MODEL", modelPath("victim_bbox.onnx"));
      vision_cfg.target_bbox_model = envString("VISION_TARGET_BBOX_MODEL", modelPath("target_bbox.onnx"));
      vision_cfg.victim_cls_model = envString("VISION_VICTIM_CLS_MODEL", modelPath("victim_cls.onnx"));
      vision_cfg.target_mask_rf_model = envString("VISION_TARGET_MASK_RF_MODEL", modelPath("target_mask_rf.yml"));
      vision_cfg.target_mask_feature_config =
         envString("VISION_TARGET_MASK_FEATURES", modelPath("target_mask_features.yml"));
      vision_cfg.object_presence_model =
         envString("VISION_OBJECT_PRESENCE_MODEL", modelPath("object_presence.onnx"));

      // Pipeline acceptance config. Defaults mirror config/vision.yaml (the
      // values that differ from the struct defaults are set explicitly).
      vision_cfg.pipeline.min_presence_confidence =
         static_cast<float>(clampd(envDouble("VISION_MIN_PRESENCE_CONFIDENCE", 0.85), 0.0, 1.0));
      vision_cfg.pipeline.min_type_confidence =
         static_cast<float>(clampd(envDouble("VISION_MIN_TYPE_CONFIDENCE", 0.85), 0.0, 1.0));
      vision_cfg.pipeline.type_fallback_enabled = envFlagEnabled("VISION_TYPE_FALLBACK_ENABLED", true);
      // Single fused none/target/victim camera model in place of the old
      // presence+object_type chain. It is the production default; set
      // VISION_USE_FUSED_OBJECT_MODEL=0 only to debug the legacy chain.
      vision_cfg.pipeline.use_fused_object_model =
         envFlagEnabled("VISION_USE_FUSED_OBJECT_MODEL", true);
      // victim_cls was trained on full frames; classify the whole frame (not the
      // tight bbox crop) to avoid the train/serve mismatch that collapsed it to U.
      vision_cfg.pipeline.victim_classify_full_frame =
         envFlagEnabled("VISION_VICTIM_CLASSIFY_FULL_FRAME", true);
      vision_cfg.pipeline.valid_detection_distance_m =
         static_cast<float>(std::max(0.0, envDouble("VISION_VALID_DETECTION_DISTANCE_M", 0.06)));
      vision_cfg.pipeline.use_bbox_gate =
         envFlagEnabled("VISION_USE_BBOX_GATE", true);
      vision_cfg.pipeline.victim_bbox_gate_min_area_px =
         static_cast<float>(envDouble("VISION_VICTIM_BBOX_GATE_MIN_AREA_PX", 30.0));
      vision_cfg.pipeline.victim_bbox_gate_min_width_px =
         static_cast<float>(envDouble("VISION_VICTIM_BBOX_GATE_MIN_WIDTH_PX", 6.0));
      vision_cfg.pipeline.victim_bbox_gate_min_height_px =
         static_cast<float>(envDouble("VISION_VICTIM_BBOX_GATE_MIN_HEIGHT_PX", 5.0));
      vision_cfg.pipeline.target_bbox_gate_min_area_px =
         static_cast<float>(envDouble("VISION_TARGET_BBOX_GATE_MIN_AREA_PX", 0.0));
      vision_cfg.pipeline.target_bbox_gate_min_width_px =
         static_cast<float>(envDouble("VISION_TARGET_BBOX_GATE_MIN_WIDTH_PX", 12.0));
      vision_cfg.pipeline.target_bbox_gate_min_height_px =
         static_cast<float>(envDouble("VISION_TARGET_BBOX_GATE_MIN_HEIGHT_PX", 8.0));
      vision_cfg.pipeline.reject_fake_victims =
         envFlagEnabled("VISION_REJECT_FAKE_VICTIMS", true);
      vision_cfg.pipeline.fake_min_confidence =
         static_cast<float>(clampd(envDouble("VISION_FAKE_MIN_CONFIDENCE", 0.90), 0.0, 1.0));
      vision_cfg.pipeline.duplicate_scope = "tile";
      // Keep LiDAR distance gates off by default: range is noisy on these
      // wall-mounted objects and was hiding real camera detections.
      vision_cfg.pipeline.lidar_gate_enabled =
         envFlagEnabled("VISION_PIPELINE_LIDAR_GATE_ENABLED", false);
      vision_cfg.pipeline.lidar_gate_min_consecutive_rays = std::max(
         1,
         static_cast<int>(envDouble("VISION_PIPELINE_LIDAR_GATE_MIN_CONSECUTIVE_RAYS", 5.0))
      );
      vision_cfg.pipeline.lidar_gate_max_range_m =
         static_cast<float>(std::max(0.0, envDouble("VISION_PIPELINE_LIDAR_GATE_MAX_RANGE_M", 0.06)));
      vision_cfg.pipeline.use_lidar_distance_gate =
         envFlagEnabled("VISION_USE_LIDAR_DISTANCE_GATE", false);
      vision_cfg.pipeline.use_target_lidar_distance_gate =
         envFlagEnabled("VISION_TARGET_LIDAR_GATE_ENABLED", false);
      vision_cfg.pipeline.use_victim_lidar_distance_gate =
         envFlagEnabled("VISION_VICTIM_LIDAR_GATE_ENABLED", false);
      vision_cfg.event_logger = [](const std::string& event) {
         logRobotEvent("vision_pipeline", {{"detail", event}});
      };

      vision_runtime_ptr = std::make_unique<vision_runtime::VisionRuntime>(vision_cfg);
      logRobotEvent(
         vision_runtime_ptr->ready() ? "vision_runtime_started" : "vision_runtime_degraded",
         {
            {"model_dir", vision_model_dir},
            {"target_rf_ready", boolText(vision_runtime_ptr->ready())},
            {"target_load_error", vision_runtime_ptr->targetLoadError().empty()
                                      ? "none" : vision_runtime_ptr->targetLoadError()},
            {"classify_hold_s", numberText(vision_hold_duration_s, 3)},
            {"hold_after_tile_advance", boolText(vision_hold_after_tile_advance)},
            {"duplicate_scope", "tile_kind_class"},
            {"use_bbox_gate", boolText(vision_cfg.pipeline.use_bbox_gate)},
            {"victim_bbox_gate_min_area_px", numberText(vision_cfg.pipeline.victim_bbox_gate_min_area_px, 1)},
            {"victim_bbox_gate_min_width_px", numberText(vision_cfg.pipeline.victim_bbox_gate_min_width_px, 1)},
            {"victim_bbox_gate_min_height_px", numberText(vision_cfg.pipeline.victim_bbox_gate_min_height_px, 1)},
            {"target_bbox_gate_min_area_px", numberText(vision_cfg.pipeline.target_bbox_gate_min_area_px, 1)},
            {"target_bbox_gate_min_width_px", numberText(vision_cfg.pipeline.target_bbox_gate_min_width_px, 1)},
            {"target_bbox_gate_min_height_px", numberText(vision_cfg.pipeline.target_bbox_gate_min_height_px, 1)},
            {"victim_report_min_confidence", numberText(g_vision_victim_report_min_confidence, 3)},
            {"victim_small_bbox_min_confidence", numberText(g_vision_victim_small_bbox_min_confidence, 3)},
            {"victim_small_bbox_area_px", std::to_string(g_vision_victim_small_bbox_area_px)},
            {"victim_small_bbox_width_px", std::to_string(g_vision_victim_small_bbox_width_px)},
            {"victim_small_bbox_height_px", std::to_string(g_vision_victim_small_bbox_height_px)},
            {"victim_report_min_center_y_px", numberText(g_vision_victim_report_min_center_y_px, 1)},
            {"target_report_min_confidence", numberText(g_vision_target_report_min_confidence, 3)},
            {"target_report_min_area_px", std::to_string(g_vision_target_report_min_area_px)},
            {"target_report_min_width_px", std::to_string(g_vision_target_report_min_width_px)},
            {"target_report_min_height_px", std::to_string(g_vision_target_report_min_height_px)},
            {"lidar_gate", boolText(vision_lidar_gate_enabled)},
            {"pipeline_lidar_gate", boolText(vision_cfg.pipeline.lidar_gate_enabled)},
            {"target_lidar_gate", boolText(vision_cfg.pipeline.use_target_lidar_distance_gate)},
            {"victim_lidar_gate", boolText(vision_cfg.pipeline.use_victim_lidar_distance_gate)},
            {"valid_detection_distance_m", numberText(vision_cfg.pipeline.valid_detection_distance_m, 3)},
            {"lidar_gate_min_consecutive", std::to_string(vision_lidar_gate_min_consecutive_rays)},
            {"lidar_gate_max_range", numberText(vision_lidar_gate_max_range_m, 3)},
            {"align_ajust", boolText(vision_align_adjust)},
            {"align_max_time", numberText(vision_align_max_time_s, 3)},
            {"align_threshold_px", numberText(vision_align_threshold_px, 1)},
            {"align_restore_heading", boolText(vision_align_restore_heading)},
            {"align_restore_max_time", numberText(vision_align_restore_max_time_s, 3)},
            {"align_restore_threshold_rad", numberText(vision_align_restore_threshold_rad, 3)},
            {"target_gate_search", boolText(vision_target_gate_search_enabled)},
            {"target_gate_search_time", numberText(vision_target_gate_search_time_s, 3)},
            {"target_gate_search_angular", numberText(vision_target_gate_search_angular_rad_s, 3)},
            {"transport", "in_process"},
         });
   }

   robot->step(timeStep);

   const double *rpy_init = Iunit->getRollPitchYaw();
   [[maybe_unused]] double initial_yaw = rpy_init ? webotsYawToRos(rpy_init[2]) : 0.0;

   printStartupSensorInfo(
      timeStep,
      dt,
      raioRoda,
      L,
      max_speed,
      kMaxLinearVel,
      kMaxAngularVel,
      wheel_left,
      wheel_right,
      leftEncoders,
      rightEncoders,
      lidar,
      lidarH,
      gps,
      Iunit,
      came,
      camd,
      colorSensor,
      timing.state_period_s,
      timing.scan_period_s,
      timing.color_period_s,
      timing.camera_period_s
   );
   logRobotTerminalEvent(
      "controller_started",
      {
         {"wheel_radius", numberText(raioRoda, 5)},
         {"axle_length", numberText(L, 5)},
         {"max_motor_speed", numberText(max_speed, 3)},
         {"max_linear_vel", numberText(kMaxLinearVel, 4)},
         {"max_angular_vel", numberText(kMaxAngularVel, 4)},
         {"timestep_ms", std::to_string(timeStep)},
         {"left_motor", wheel_left ? "wheel1_motor" : "missing"},
         {"right_motor", wheel_right ? "wheel2_motor" : "missing"},
         {"left_encoder", leftEncoders ? "enabled" : "missing"},
         {"right_encoder", rightEncoders ? "enabled" : "missing"},
         {"lidar", lidar ? "enabled" : "missing"},
         {"gps", gps ? "enabled" : "missing"},
         {"imu", Iunit ? "enabled" : "missing"},
         {"color_sensor", colorSensor ? "enabled" : "missing"},
         {"distance_sensor", dsensor ? "enabled" : "missing"},
         {"explorer_backend", explorer_backend},
         {"publish_topics", legacy_cam_hex_debug ? "TIME,IMU,GPS,LOC,ODOM,SCAN,COLOR,CAM(debug)" : "TIME,IMU,GPS,LOC,ODOM,SCAN,COLOR"},
         {"vision_transport", vision_enabled ? "binary_tcp" : "disabled"},
         {"subscribe_topics", legacy_explorer_enabled ? "none" : "/cmd_vel"},
         {"source", "webots"},
      });
   logRobotEvent(
      "localization_config",
      {
         {"wheel_radius_m", numberText(localization_config.wheel_radius_m, 5)},
         {"wheel_base_m", numberText(localization_config.wheel_base_m, 5)},
         {"gps_alpha", numberText(localization_config.gps_alpha, 3)},
         {"gps_gate_m", numberText(localization_config.gps_gate_m, 4)},
         {"gps_hard_reject_m", numberText(localization_config.gps_hard_reject_m, 4)},
         {"gps_sigma_m", numberText(localization_config.gps_sigma_m, 4)},
         {"freeze_translation_on_slip", boolText(localization_config.freeze_translation_on_slip)},
         {"debug", boolText(localization_debug)},
         {"source", "controller_localizer2d"},
      });

   CmdVel last_cmd{};
   int counter = 0;
   std::uint64_t cmd_seq = 0;

   [[maybe_unused]] double roll = 0.0;
   [[maybe_unused]] double pitch = 0.0;
   double yaw_webots = 0.0;
   double yaw_ros = 0.0;

   double last_diag_t = -1.0;
   double last_cmd_rx_t = -1.0;
   double last_wheel_log_t = -1.0;
   double last_pose_log_t = -1.0;
   double last_localization_log_t = -1.0;
   double last_floor_raw_log_t = -1.0;

   double last_state_send_t = -1.0;
   double last_scan_send_t = -1.0;
   double last_color_send_t = -1.0;
   double last_camera_send_t = -1.0;
   // Vision runs in-process and synchronously during the per-tile classify-hold
   // phase, so there is no cadence gate anymore (no TCP, no frequency throttle).
   bool black_hole_brake_sample_latched = false;
   BlackHoleSafetyState black_hole_safety_state = BlackHoleSafetyState::Idle;
   double black_hole_safety_until_t = -1.0;
   double black_hole_still_detected_log_t = -1.0;

   bool idle_wiggle_active = false;
   [[maybe_unused]] double wiggle_start_t = 0.0;

   // Pump de publicação executado a cada robot->step(), inclusive nos laços
   // bloqueantes do MotionExecutor (driveTile/turnToYaw). Lê os sensores,
   // atualiza a localização e publica TIME/IMU/GPS/LOC/ODOM/SCAN no bridge.
   // Compartilha os gates (last_state_send_t / last_scan_send_t) com o corpo do
   // loop principal, então a cadência continua global: o LiDAR/TF/SLAM passam a
   // atualizar continuamente enquanto o robô anda, em vez de só quando ele para.
   auto pumpBridgePublish = [&]() {
      const double tp = robot->getTime();
      pollGameInformation(tp);
      pollLatestSubmissionMatrix(tp);
      trySubmitOnSimulationDeadline(tp);

      if (!bridge_client) {
         return;
      }

      const double* rpy_p = Iunit ? Iunit->getRollPitchYaw() : nullptr;
      const double yaw_ros_p = rpy_p ? webotsYawToRos(rpy_p[2]) : 0.0;

      auto layer_p = getLidar();

      GpsLocal fixpos_p = getGps();
      if (race_mode) {
         fixpos_p.x -= race_gps0.x;
         fixpos_p.y -= race_gps0.y;
         fixpos_p.z -= race_gps0.z;
      }

      const double front_clearance_p = lidarSectorMinRange(layer_p, 0.0, 0.35);
      const double gps_speed_p = gps ? gps->getSpeed() : 0.0;
      const double left_enc_p = leftEncoders ? leftEncoders->getValue() : 0.0;
      const double right_enc_p = rightEncoders ? rightEncoders->getValue() : 0.0;

      localization::LocalizerInput pump_input;
      pump_input.stamp_s = tp;
      pump_input.left_encoder_rad = left_enc_p;
      pump_input.right_encoder_rad = right_enc_p;
      pump_input.imu_yaw_ros_rad = yaw_ros_p;
      pump_input.has_gps =
         gps != nullptr &&
         std::isfinite(fixpos_p.x) &&
         std::isfinite(fixpos_p.y) &&
         std::isfinite(fixpos_p.z);
      pump_input.gps_x_m = fixpos_p.x;
      pump_input.gps_y_m = fixpos_p.y;
      pump_input.gps_z_m = fixpos_p.z;
      pump_input.gps_speed_mps = gps_speed_p;
      pump_input.cmd_v_mps = 0.0;
      pump_input.cmd_w_radps = 0.0;
      pump_input.has_front_clearance = std::isfinite(front_clearance_p);
      pump_input.front_clearance_m = front_clearance_p;

      localization_state = localizer.update(pump_input);

      const auto wheel_odom_update = wheel_odom.update(
         left_enc_p,
         right_enc_p,
         yaw_ros_p,
         fixpos_p.x,
         fixpos_p.y,
         gps_speed_p,
         0.0,
         0.0,
         front_clearance_p,
         dt);

      const bool should_send_state =
         periodicDue(tp, last_state_send_t, timing.state_period_s);
      const bool should_send_scan =
         periodicDue(tp, last_scan_send_t, timing.scan_period_s);

      bool state_sent_this_step = false;
      if (should_send_state) {
         bridge_client->sendTime(tp);
         bridge_client->sendImu(0.0, 0.0, yaw_ros_p);
         bridge_client->sendGps(fixpos_p);
         bridge_client->sendLocalization(localization_state);
         state_sent_this_step = true;
         if (wheel_odom_update.valid) {
            bridge_client->sendWheelOdom(
               wheel_odom_update.pose.x,
               wheel_odom_update.pose.y,
               wheel_odom_update.pose.yaw,
               wheel_odom_update.vx,
               wheel_odom_update.wz,
               wheel_odom_update.slip_suspected);
         }
         last_state_send_t = tp;
      }

      if (should_send_scan) {
         if (!state_sent_this_step) {
            bridge_client->sendTime(tp);
            bridge_client->sendImu(0.0, 0.0, yaw_ros_p);
            bridge_client->sendGps(fixpos_p);
            bridge_client->sendLocalization(localization_state);
         }
         bridge_client->sendScan(layer_p);
         last_scan_send_t = tp;
      }

      // Mid-movement vision: scan continuously while driving so victims/targets
      // seen between tiles are not missed. On a reportable detection for a tile
      // not yet reported, raise the interrupt -> MotionExecutor aborts the drive
      // -> main loop runs the classify-hold + report for that tile. Throttled to
      // the camera cadence (no point running faster than the camera refreshes).
      if (vision_runtime_ptr && legacy_explorer && vision_phase == VisionRuntimePhase::Idle &&
          !vision_interrupt_active && !legacy_explorer->finished() &&
          periodicDue(tp, last_vision_scan_t,
                      std::max(timing.camera_period_s, vision_pump_scan_interval_s)))
      {
         last_vision_scan_t = tp;
         const auto scan_tile = legacy_explorer->currentTile();
         // Always scan, even on tiles that already ran a classify-hold
         // (backtracking re-traverses them): the duplicate keys alone decide
         // whether a detection is reportable, so a victim/target of a class not
         // yet reported on this tile still raises the interrupt.
         {
            GpsLocal scan_pose;
            scan_pose.x = localization_state.x_m;
            scan_pose.y = localization_state.y_m;
            scan_pose.z = localization_state.z_m;

            std::vector<VisionDetectionResult> interrupt_candidates;
            std::optional<VisionRejectionHint> target_gate_hint;
            auto scanCamera = [&](int camera_id, Camera* camera, float yaw_offset) {
               VisionRejectionHint hint;
               auto result = runVisionOnCamera(
                  camera_id, camera, tp, layer_p, scan_pose, localization_state.yaw_rad,
                  scan_tile.x, scan_tile.y, yaw_offset,
                  vision_lidar_gate_enabled, vision_lidar_gate_min_consecutive_rays,
                  vision_lidar_gate_max_range_m, /*log_rejection=*/false, &hint);
               if (!result || !reportableVisionResult(*result)) {
                  if (!target_gate_hint && isTargetBboxGateHint(hint)) {
                     target_gate_hint = hint;
                  }
                  return;
               }
               if (result->confidence < vision_min_result_confidence) {
                  return;
               }
               interrupt_candidates.push_back(std::move(*result));
            };

            const bool left_first = vision_next_interrupt_left_first;
            vision_next_interrupt_left_first = !vision_next_interrupt_left_first;
            if (left_first) {
               scanCamera(0, came, vision_left_yaw_offset);
               scanCamera(1, camd, vision_right_yaw_offset);
            } else {
               scanCamera(1, camd, vision_right_yaw_offset);
               scanCamera(0, came, vision_left_yaw_offset);
            }

            auto interrupt_result = chooseBestVisionResult(
               interrupt_candidates,
               reported_vision_keys);
            if (interrupt_result) {
               vision_interrupt_active = true;
               vision_interrupt_tile = scan_tile;
               vision_interrupt_result = *interrupt_result;
               logRobotEvent(
                  "vision_interrupt_requested",
                  {
                     {"camera", interrupt_result->camera},
                     {"tile", "(" + std::to_string(scan_tile.x) + "," + std::to_string(scan_tile.y) + ")"},
                     {"kind", interrupt_result->kind},
                     {"class", interrupt_result->class_name},
                     {"confidence", numberText(interrupt_result->confidence, 3)},
                     {"candidates", std::to_string(interrupt_candidates.size())},
                  });
            } else if (target_gate_hint && vision_target_gate_search_enabled &&
                       vision_checked_tiles.count({scan_tile.x, scan_tile.y}) == 0) {
               // The gate-search near-miss interrupt stays limited to tiles that
               // never ran a hold, otherwise the same borderline target would
               // stop the robot on every pass over this tile.
               vision_interrupt_active = true;
               vision_interrupt_tile = scan_tile;
               vision_interrupt_result = {};
               vision_interrupt_result.camera = target_gate_hint->camera;
               vision_interrupt_result.tile_x = scan_tile.x;
               vision_interrupt_result.tile_y = scan_tile.y;
               vision_interrupt_result.kind = "target";
               vision_interrupt_result.class_name = "gate";
               logRobotEvent(
                  "vision_interrupt_requested",
                  {
                     {"tile", "(" + std::to_string(scan_tile.x) + "," + std::to_string(scan_tile.y) + ")"},
                     {"reason", "target_bbox_gate"},
                     {"camera", target_gate_hint->camera},
                  });
            }
         }
      }
   };

   if (legacy_io) {
      legacy_io->setStepCallback(pumpBridgePublish);
   }

   while (robot->step(timeStep) != -1) {
      auto wall_loop_t0 = std::chrono::steady_clock::now();
      double t = robot->getTime();

      pollLatestSubmissionMatrix(t);
      pollGameInformation(t);
      trySubmitOnSimulationDeadline(t);

      // 1) Ler orientação atual
      const double *rpy = Iunit->getRollPitchYaw();
      if (rpy) {
         roll = rpy[0];
         pitch = rpy[1];
         yaw_webots = rpy[2];
         yaw_ros = webotsYawToRos(yaw_webots);
      }

      // 3) Ler lidar e GPS
      auto t0 = std::chrono::steady_clock::now();
      auto layer = getLidar();
      auto t1 = std::chrono::steady_clock::now();
      const double lidar_ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

      GpsLocal fixpos = getGps();
      if (race_mode) {
         fixpos.x -= race_gps0.x;
         fixpos.y -= race_gps0.y;
         fixpos.z -= race_gps0.z;
      }

      const double front_clearance_m = lidarSectorMinRange(layer, 0.0, 0.35);
      const double gps_speed_mps = gps ? gps->getSpeed() : 0.0;
      const double left_enc_rad = leftEncoders ? leftEncoders->getValue() : 0.0;
      const double right_enc_rad = rightEncoders ? rightEncoders->getValue() : 0.0;

      CmdVel incoming{};
      if (bridge_client && bridge_client->receiveCmdVel(incoming)) {
         last_cmd = incoming;
         last_cmd_rx_t = t;
         ++cmd_seq;
         logRobotEvent(
            "cmd_vel_received",
            {
               {"cmd_seq", std::to_string(cmd_seq)},
               {"raw_v", numberText(incoming.v, 4)},
               {"raw_w", numberText(incoming.w, 4)},
               {"age", "0.0000"},
               {"source", "/cmd_vel"},
            });
      }

      const bool localization_cmd_alive =
         !legacy_explorer_enabled &&
         (last_cmd_rx_t >= 0.0) &&
         ((t - last_cmd_rx_t) <= kNav2CmdTimeout);

      localization::LocalizerInput localization_input;
      localization_input.stamp_s = t;
      localization_input.left_encoder_rad = left_enc_rad;
      localization_input.right_encoder_rad = right_enc_rad;
      localization_input.imu_yaw_ros_rad = yaw_ros;
      localization_input.has_gps =
         gps != nullptr &&
         std::isfinite(fixpos.x) &&
         std::isfinite(fixpos.y) &&
         std::isfinite(fixpos.z);
      localization_input.gps_x_m = fixpos.x;
      localization_input.gps_y_m = fixpos.y;
      localization_input.gps_z_m = fixpos.z;
      localization_input.gps_speed_mps = gps_speed_mps;
      localization_input.cmd_v_mps = localization_cmd_alive
         ? clampd(last_cmd.v, -kMaxLinearVel, kMaxLinearVel)
         : 0.0;
      localization_input.cmd_w_radps = localization_cmd_alive
         ? clampd(last_cmd.w, -kMaxAngularVel, kMaxAngularVel)
         : 0.0;
      localization_input.has_front_clearance = std::isfinite(front_clearance_m);
      localization_input.front_clearance_m = front_clearance_m;

      localization_state = localizer.update(localization_input);
      local_pose.x = localization_state.x_m;
      local_pose.y = localization_state.y_m;
      local_pose.th = localization_state.yaw_rad;
      const GpsLocal estimated_pose{
         localization_state.x_m,
         localization_state.y_m,
         localization_state.z_m
      };

      if (localization_debug ||
          last_localization_log_t < 0.0 ||
          (t - last_localization_log_t) >= 1.0)
      {
         last_localization_log_t = t;
         logRobotEvent(
            "localization_state",
            {
               {"x", numberText(localization_state.x_m, 4)},
               {"y", numberText(localization_state.y_m, 4)},
               {"z_debug", numberText(localization_state.z_m, 4)},
               {"yaw", numberText(localization_state.yaw_rad, 4)},
               {"vx", numberText(localization_state.vx_mps, 4)},
               {"wz", numberText(localization_state.wz_radps, 4)},
               {"dt", numberText(localization_state.dt_s, 4)},
               {"gps_used", boolText(localization_state.gps_used)},
               {"gps_rejected", boolText(localization_state.gps_rejected)},
               {"gps_innovation", numberText(localization_state.gps_innovation_m, 4)},
               {"slip", boolText(localization_state.slip_suspected)},
               {"encoder_jump_rejected", boolText(localization_state.encoder_jump_rejected)},
               {"dt_rejected", boolText(localization_state.dt_rejected)},
               {"cov_x", numberText(localization_state.cov_x, 6)},
               {"cov_y", numberText(localization_state.cov_y, 6)},
            });
      }

      const auto floor_color_sample = readColourSensorClassification(colorSensor);
      const double normalized_r = static_cast<double>(floor_color_sample.r) / 255.0;
      const double normalized_g = static_cast<double>(floor_color_sample.g) / 255.0;
      const double normalized_b = static_cast<double>(floor_color_sample.b) / 255.0;
      const bool strong_black_hole_sample = isStrongBlackHoleBrakeSample(
         floor_color_sample,
         black_hole_brake_min_confidence
      );

      const bool should_log_floor_raw =
         last_floor_raw_log_t < 0.0 ||
         (t - last_floor_raw_log_t) >= 1.0 ||
         strong_black_hole_sample;
      if (should_log_floor_raw) {
         last_floor_raw_log_t = t;
         logRobotEvent(
            "floor_color_raw",
            {
               {"raw_rgb", "(" + std::to_string(floor_color_sample.r) + "," + std::to_string(floor_color_sample.g) + "," + std::to_string(floor_color_sample.b) + ")"},
               {"normalized_rgb", "(" + numberText(normalized_r, 3) + "," + numberText(normalized_g, 3) + "," + numberText(normalized_b, 3) + ")"},
               {"class_label", floor_color_sample.color_class},
               {"chosen_class", floor_color_sample.color_class},
               {"confidence", numberText(floor_color_sample.confidence, 3)},
               {"color_conf", numberText(floor_color_sample.confidence, 3)},
               {"robot_world_x", numberText(localization_state.x_m, 4)},
               {"robot_world_y", numberText(localization_state.y_m, 4)},
               {"sensor_offset", "(0,0)"},
               {"source", "colour_sensor"},
            });
      }

      if (legacy_explorer_enabled) {
         const auto wheel_odom_update = wheel_odom.update(
            left_enc_rad,
            right_enc_rad,
            yaw_ros,
            fixpos.x,
            fixpos.y,
            gps_speed_mps,
            0.0,
            0.0,
            front_clearance_m,
            dt);

         double bridge_ms = 0.0;
         if (bridge_client) {
            auto tb0 = std::chrono::steady_clock::now();

            const bool should_send_state =
               periodicDue(t, last_state_send_t, timing.state_period_s);

            const bool should_send_scan =
               periodicDue(t, last_scan_send_t, timing.scan_period_s);

            const bool should_send_color =
               strong_black_hole_sample ||
               periodicDue(t, last_color_send_t, timing.color_period_s);

            const bool should_send_camera =
               periodicDue(t, last_camera_send_t, timing.camera_period_s);

            bool state_sent_this_step = false;

            if (should_send_state) {
               bridge_client->sendTime(t);
               bridge_client->sendImu(0.0, 0.0, yaw_ros);
               bridge_client->sendGps(fixpos);
               bridge_client->sendLocalization(localization_state);
               state_sent_this_step = true;

               if (wheel_odom_update.valid) {
                  bridge_client->sendWheelOdom(
                     wheel_odom_update.pose.x,
                     wheel_odom_update.pose.y,
                     wheel_odom_update.pose.yaw,
                     wheel_odom_update.vx,
                     wheel_odom_update.wz,
                     wheel_odom_update.slip_suspected
                  );
               }

               last_state_send_t = t;
            }

            if (should_send_scan) {
               if (!state_sent_this_step) {
                  bridge_client->sendTime(t);
                  bridge_client->sendImu(0.0, 0.0, yaw_ros);
                  bridge_client->sendGps(fixpos);
                  bridge_client->sendLocalization(localization_state);
               }

               bridge_client->sendScan(layer);
               last_scan_send_t = t;
            }

            if (should_send_color) {
               bridge_client->sendColorClassification(
                  floor_color_sample.color_class,
                  floor_color_sample.r,
                  floor_color_sample.g,
                  floor_color_sample.b,
                  floor_color_sample.confidence
               );
               last_color_send_t = t;
            }

            if (should_send_camera) {
               if (use_cam) {
                  sendCameraFrameIfReady("came", came, t);
                  sendCameraFrameIfReady("camd", camd, t);
               }
               last_camera_send_t = t;
            }

            auto tb1 = std::chrono::steady_clock::now();
            bridge_ms = std::chrono::duration<double, std::milli>(tb1 - tb0).count();
         }

         auto startVisionHold = [&](exploration_legacy::TileCoord tile, double now) {
            vision_phase = VisionRuntimePhase::ClassifyHold;
            vision_hold_start_t = now;
            vision_hold_tile = tile;
            pending_vision_results.clear();
            vision_align_start_t = -1.0;
            vision_align_tile = tile;
            vision_align_last_result.reset();
            vision_align_attempted_for_hold = false;
            vision_target_gate_search_active = false;
            vision_target_gate_search_direction = 1.0;
            stopAndHoldWheelsAtCurrentPosition();
            // HOLDING_FOR_REPORT: stop the robot, then hold >= duration of sim time
            // before reporting. Uses robot->getTime() (simulation clock), not wall time.
            logRobotTerminalEvent(
               "vision_hold_started",
               {
                  {"tile", "(" + std::to_string(tile.x) + "," + std::to_string(tile.y) + ")"},
                  {"duration", numberText(vision_hold_duration_s, 3)},
               });
         };

         // Holds the detections produced this step by runVisionOnCamera, drained
         // by pollVisionResultsForHold. Replaces the old TCP result queue.
         std::vector<VisionDetectionResult> fresh_vision_results;
         std::vector<VisionRejectionHint> fresh_vision_rejections;
         auto enqueueVisionFramesForTile = [&](exploration_legacy::TileCoord tile) {
            if (!vision_runtime_ptr) {
               return;
            }
            fresh_vision_results.clear();
            fresh_vision_rejections.clear();

            auto runCamera = [&](int camera_id, Camera* camera, float yaw_offset,
                                 const char* camera_name) {
               VisionRejectionHint hint;
               auto result = runVisionOnCamera(
                  camera_id,
                  camera,
                  t,
                  layer,
                  estimated_pose,
                  localization_state.yaw_rad,
                  tile.x,
                  tile.y,
                  yaw_offset,
                  vision_lidar_gate_enabled,
                  vision_lidar_gate_min_consecutive_rays,
                  vision_lidar_gate_max_range_m,
                  true,
                  &hint);
               if (result) {
                  logRobotEvent(
                     "vision_detection_accepted",
                     {
                        {"tile", "(" + std::to_string(tile.x) + "," + std::to_string(tile.y) + ")"},
                        {"camera", camera_name},
                        {"kind", result->kind},
                        {"class", result->class_name},
                        {"confidence", numberText(result->confidence, 3)},
                  });
                  fresh_vision_results.push_back(std::move(*result));
               } else if (isTargetBboxGateHint(hint)) {
                  fresh_vision_rejections.push_back(std::move(hint));
               }
            };

            const bool left_first = vision_next_hold_left_first;
            vision_next_hold_left_first = !vision_next_hold_left_first;
            if (left_first) {
               runCamera(0, came, vision_left_yaw_offset, "left");
               runCamera(1, camd, vision_right_yaw_offset, "right");
            } else {
               runCamera(1, camd, vision_right_yaw_offset, "right");
               runCamera(0, came, vision_left_yaw_offset, "left");
            }
         };

         auto cameraForVisionResult = [&](const VisionDetectionResult& result) -> Camera* {
            return result.camera == "right" ? camd : came;
         };

         auto visionCenterErrorPx = [&](const VisionDetectionResult& result) {
            Camera* camera = cameraForVisionResult(result);
            const double width = camera ? static_cast<double>(camera->getWidth()) : 64.0;
            const double cx = (width - 1.0) * 0.5;
            return result.center_x - cx;
         };

         auto commandVisionAlignment = [&](const VisionDetectionResult& result) {
            Camera* camera = cameraForVisionResult(result);
            const double width = camera ? static_cast<double>(camera->getWidth()) : 64.0;
            const double fov = camera ? static_cast<double>(camera->getFov()) : 1.0;
            const double fx = width / (2.0 * std::tan(fov * 0.5));
            const double angle_error = std::atan(visionCenterErrorPx(result) / std::max(1.0, fx));
            const double angular = clampd(
               vision_align_kp * angle_error,
               -vision_align_max_angular_rad_s,
               vision_align_max_angular_rad_s
            );
            const double left = -angular * (L / 2.0) / raioRoda;
            const double right = angular * (L / 2.0) / raioRoda;
            setVisionGuardedWheelVelocity(left, right);
            return angular;
         };

         auto restoreVisionAlignmentHeading = [&]() {
            if (!vision_align_restore_needed ||
                !vision_align_restore_heading ||
                !std::isfinite(vision_align_restore_yaw_ros) ||
                vision_align_restore_max_time_s <= 0.0)
            {
               vision_align_restore_needed = false;
               vision_align_restore_yaw_ros = std::numeric_limits<double>::quiet_NaN();
               return;
            }

            const double start_t = robot->getTime();
            double final_error = std::numeric_limits<double>::quiet_NaN();
            double final_yaw = std::numeric_limits<double>::quiet_NaN();
            std::string reason = "timeout";
            bool step_ended = false;
            logRobotTerminalEvent(
               "vision_align_heading_restore_started",
               {
                  {"target_yaw", numberText(vision_align_restore_yaw_ros, 4)},
                  {"max_time", numberText(vision_align_restore_max_time_s, 3)},
               });
            while (true) {
               if (robot->step(timeStep) == -1) {
                  step_ended = true;
                  reason = "webots_step_ended";
                  break;
               }
               const double elapsed = robot->getTime() - start_t;
               const double* rpy_restore = Iunit ? Iunit->getRollPitchYaw() : nullptr;
               if (!rpy_restore) {
                  reason = "missing_imu";
                  break;
               }

               const double yaw_ros_now = webotsYawToRos(rpy_restore[2]);
               final_yaw = yaw_ros_now;
               final_error = pi_interval(vision_align_restore_yaw_ros - yaw_ros_now);
               if (std::abs(final_error) <= vision_align_restore_threshold_rad) {
                  reason = "restored";
                  break;
               }
               if (elapsed >= vision_align_restore_max_time_s) {
                  break;
               }

               const double angular = clampd(
                  -vision_align_restore_kp * final_error,
                  -vision_align_max_angular_rad_s,
                  vision_align_max_angular_rad_s
               );
               const double left = -angular * (L / 2.0) / raioRoda;
               const double right = angular * (L / 2.0) / raioRoda;
               setVisionGuardedWheelVelocity(left, right);
            }

            if (step_ended) {
               vision_align_restore_needed = false;
               vision_align_restore_yaw_ros = std::numeric_limits<double>::quiet_NaN();
               diag::log(
                  diag::Level::Warn,
                  "ROBOT_EVENT node=controller event=vision_align_heading_restore_aborted reason=webots_step_ended"
               );
               return;
            }

            stopAndHoldWheelsAtCurrentPosition();
            logRobotTerminalEvent(
               "vision_align_heading_restore_finished",
               {
                  {"reason", reason},
                  {"elapsed", numberText(robot->getTime() - start_t, 3)},
                  {"target_yaw", numberText(vision_align_restore_yaw_ros, 4)},
                  {"final_yaw", numberText(final_yaw, 4)},
                  {"final_error", numberText(final_error, 4)},
               });
            vision_align_restore_needed = false;
            vision_align_restore_yaw_ros = std::numeric_limits<double>::quiet_NaN();
         };

         auto beginVisionAlignment = [&](const VisionDetectionResult& result) {
            vision_phase = VisionRuntimePhase::AlignAdjust;
            vision_align_start_t = t;
            vision_align_tile = vision_hold_tile;
            vision_align_last_result = result;
            vision_align_attempted_for_hold = true;
            vision_align_restore_needed = true;
            vision_align_restore_yaw_ros = std::isfinite(localization_state.yaw_rad)
               ? localization_state.yaw_rad
               : (Iunit ? webotsYawToRos(Iunit->getRollPitchYaw()[2]) : 0.0);
            pending_vision_results.clear();
            const double error_px = visionCenterErrorPx(result);
            const double angular = commandVisionAlignment(result);
            logRobotTerminalEvent(
               "vision_align_started",
               {
                  {"tile", "(" + std::to_string(vision_align_tile.x) + "," + std::to_string(vision_align_tile.y) + ")"},
                  {"camera", result.camera},
                  {"center_error_px", numberText(error_px, 2)},
                  {"threshold_px", numberText(vision_align_threshold_px, 2)},
                  {"angular", numberText(angular, 4)},
                  {"restore_yaw", numberText(vision_align_restore_yaw_ros, 4)},
               });
         };

         auto commandTargetGateSearch = [&]() {
            const double angular =
               vision_target_gate_search_direction * vision_target_gate_search_angular_rad_s;
            const double left = -angular * (L / 2.0) / raioRoda;
            const double right = angular * (L / 2.0) / raioRoda;
            setVisionGuardedWheelVelocity(left, right);
            return angular;
         };

         auto beginTargetGateSearch = [&](const VisionRejectionHint& hint) {
            if (!vision_target_gate_search_enabled || vision_target_gate_search_time_s <= 0.0) {
               return;
            }
            vision_phase = VisionRuntimePhase::AlignAdjust;
            vision_align_start_t = t;
            vision_align_tile = vision_hold_tile;
            vision_align_last_result.reset();
            vision_align_attempted_for_hold = true;
            vision_target_gate_search_active = true;
            vision_target_gate_search_direction = hint.camera == "right" ? -1.0 : 1.0;
            vision_align_restore_needed = true;
            vision_align_restore_yaw_ros = std::isfinite(localization_state.yaw_rad)
               ? localization_state.yaw_rad
               : (Iunit ? webotsYawToRos(Iunit->getRollPitchYaw()[2]) : 0.0);
            pending_vision_results.clear();
            const double angular = commandTargetGateSearch();
            logRobotTerminalEvent(
               "vision_target_gate_search_started",
               {
                  {"tile", "(" + std::to_string(vision_align_tile.x) + "," + std::to_string(vision_align_tile.y) + ")"},
                  {"camera", hint.camera},
                  {"reason", hint.reason},
                  {"duration", numberText(vision_target_gate_search_time_s, 3)},
                  {"angular", numberText(angular, 4)},
                  {"restore_yaw", numberText(vision_align_restore_yaw_ros, 4)},
               });
         };

         auto pollVisionResultsForHold = [&]() {
            for (const auto& parsed : fresh_vision_results) {
               logRobotEvent(
                  "vision_result_received",
                  {
                     {"camera", parsed.camera},
                     {"kind", parsed.kind},
                     {"class", parsed.class_name},
                     {"phase",
                      vision_phase == VisionRuntimePhase::ClassifyHold ? "classify_hold" :
                      (vision_phase == VisionRuntimePhase::AlignAdjust ? "align_adjust" : "idle")},
                  });

               if (!parsed.valid) {
                  continue;
               }

               logVisionClassificationUnique("RESULT_RX", parsed, t, fixpos, yaw_ros);

               if (parsed.confidence < vision_min_result_confidence) {
                  logRobotEvent(
                     "vision_result_rejected",
                     {
                        {"reason", "low_confidence"},
                        {"confidence", numberText(parsed.confidence, 3)},
                        {"threshold", numberText(vision_min_result_confidence, 3)},
                     });
                  continue;
               }

               const bool in_classify_hold = vision_phase == VisionRuntimePhase::ClassifyHold;
               const bool in_align_adjust = vision_phase == VisionRuntimePhase::AlignAdjust;
               const auto active_tile = in_align_adjust ? vision_align_tile : vision_hold_tile;

               if ((!in_classify_hold && !in_align_adjust) ||
                   parsed.tile_x != active_tile.x ||
                   parsed.tile_y != active_tile.y)
               {
                  logRobotEvent(
                     "vision_result_ignored",
                     {
                        {"reason", "not_current_hold_tile"},
                        {"result_tile", "(" + std::to_string(parsed.tile_x) + "," + std::to_string(parsed.tile_y) + ")"},
                        {"hold_tile", "(" + std::to_string(active_tile.x) + "," + std::to_string(active_tile.y) + ")"},
                     });
                  continue;
               }

               if (!reportableVisionResult(parsed)) {
                  std::string reason = "not_reportable";
                  if (parsed.kind == "victim") {
                     reason = victimReportGateRejectReason(parsed);
                  } else if (parsed.kind == "target") {
                     reason = targetReportGateRejectReason(parsed);
                  }
                  logRobotEvent(
                     "vision_result_rejected",
                     {
                        {"reason", reason},
                        {"kind", parsed.kind},
                        {"class", parsed.class_name},
                        {"confidence", numberText(parsed.confidence, 3)},
                        {"bbox", "(" + std::to_string(parsed.bbox_w) + "x" + std::to_string(parsed.bbox_h) + ")"},
                        {"tile", "(" + std::to_string(parsed.tile_x) + "," + std::to_string(parsed.tile_y) + ")"},
                     });
                  continue;
               }

               if (in_align_adjust) {
                  vision_align_last_result = parsed;
                  if (std::abs(visionCenterErrorPx(parsed)) <= vision_align_threshold_px) {
                     pending_vision_results.push_back(parsed);
                  }
                  continue;
               }

               if (vision_align_adjust &&
                   !vision_align_attempted_for_hold &&
                   reportableVisionResult(parsed) &&
                   std::abs(visionCenterErrorPx(parsed)) > vision_align_threshold_px &&
                   vision_align_max_time_s > 0.0)
               {
                  beginVisionAlignment(parsed);
                  continue;
               }

               pending_vision_results.push_back(parsed);
            }
            if (vision_phase == VisionRuntimePhase::ClassifyHold &&
                vision_target_gate_search_enabled &&
                !vision_align_attempted_for_hold &&
                pending_vision_results.empty())
            {
               for (const auto& hint : fresh_vision_rejections) {
                  if (isTargetBboxGateHint(hint) &&
                      hint.tile_x == vision_hold_tile.x &&
                      hint.tile_y == vision_hold_tile.y)
                  {
                     beginTargetGateSearch(hint);
                     break;
                  }
               }
            }
            fresh_vision_results.clear();
            fresh_vision_rejections.clear();
         };

         auto processBestVisionResultForTile = [&]() {
            auto best = chooseBestVisionResult(
               pending_vision_results,
               reported_vision_keys);

            if (!best) {
               return std::string("none");
            }

            const std::string key = makeVisionKey(*best);
            if (reported_vision_keys.count(key) > 0) {
               logRobotEvent(
                  "vision_duplicate_ignored",
                  {
                     {"key", key},
                     {"tile", "(" + std::to_string(best->tile_x) + "," + std::to_string(best->tile_y) + ")"},
                  });
               return std::string("duplicate");
            }

            vision_phase = VisionRuntimePhase::Reporting;
            stopAndHoldWheelsAtCurrentPosition();
            auto sendVisionDetectionToMapper = [&](const VisionDetectionResult& result) {
               if (!bridge_client) {
                  return;
               }
               Camera* result_camera = cameraForVisionResult(result);
               const double image_width = result_camera
                  ? static_cast<double>(result_camera->getWidth())
                  : 64.0;
               bridge_client->sendVisionDetection(
                  result.kind,
                  result.class_name,
                  result.target_pattern,
                  result.tile_x,
                  result.tile_y,
                  result.camera,
                  yaw_ros,
                  result.center_x,
                  image_width,
                  result.distance_m,
                  result.confidence);
               logRobotEvent(
                  "vision_detection_sent_to_mapper",
                  {
                     {"kind", result.kind},
                     {"class", result.class_name},
                     {"tile", "(" + std::to_string(result.tile_x) + "," + std::to_string(result.tile_y) + ")"},
                     {"camera", result.camera},
                  });
            };

            if (best->kind == "victim" &&
                best->class_name != "none" &&
                best->class_name != "fake" &&
                !best->class_name.empty())
            {
               sendVisionDetectionToMapper(*best);
               enviarVictimaLegacy(best->class_name[0]);
               reported_vision_keys.insert(makeVisionKey(*best));
               logVisionClassificationUnique("REPORT_SENT", *best, t, fixpos, yaw_ros);
               logRobotEvent(
                  "report_sent",
                  {
                     {"kind", "victim"},
                     {"class", best->class_name},
                     {"tile", "(" + std::to_string(best->tile_x) + "," + std::to_string(best->tile_y) + ")"},
                     {"distance", numberText(best->distance_m, 3)},
                  });
               logRobotTerminalEvent(
                  "vision_victim_reported",
                  {
                     {"tile", "(" + std::to_string(best->tile_x) + "," + std::to_string(best->tile_y) + ")"},
                     {"class", best->class_name},
                     {"camera", best->camera},
                     {"distance", numberText(best->distance_m, 3)},
                     {"confidence", numberText(best->confidence, 3)},
                  });
               return std::string("reported");
            }

            if (best->kind == "target") {
               sendVisionDetectionToMapper(*best);
               enviarTargetLegacy(*best);
               reported_vision_keys.insert(makeVisionKey(*best));
               logVisionClassificationUnique("REPORT_SENT", *best, t, fixpos, yaw_ros);
               logRobotEvent(
                  "report_sent",
                  {
                     {"kind", "target"},
                     {"class", best->class_name},
                     {"pattern", best->target_pattern},
                     {"tile", "(" + std::to_string(best->tile_x) + "," + std::to_string(best->tile_y) + ")"},
                     {"distance", numberText(best->distance_m, 3)},
                  });
               logRobotTerminalEvent(
                  "vision_target_accepted",
                  {
                     {"tile", "(" + std::to_string(best->tile_x) + "," + std::to_string(best->tile_y) + ")"},
                     {"pattern", best->target_pattern},
                     {"class", best->class_name},
                     {"camera", best->camera},
                     {"distance", numberText(best->distance_m, 3)},
                     {"confidence", numberText(best->confidence, 3)},
                  });
               return std::string("target_accepted");
            }

            logRobotEvent(
               "vision_result_rejected",
               {
                  {"reason", "unsupported_kind_or_class"},
                  {"kind", best->kind},
                  {"class", best->class_name},
               });
            return std::string("rejected");
         };

         if (vision_phase == VisionRuntimePhase::AlignAdjust) {
            enqueueVisionFramesForTile(vision_align_tile);
            pollVisionResultsForHold();

            const double elapsed = t - vision_align_start_t;
            const double align_timeout_s = vision_target_gate_search_active
               ? vision_target_gate_search_time_s
               : vision_align_max_time_s;
            bool done = false;
            std::string reason = "waiting_result";
            double error_px = std::numeric_limits<double>::quiet_NaN();
            if (vision_align_last_result) {
               vision_target_gate_search_active = false;
               error_px = visionCenterErrorPx(*vision_align_last_result);
               if (std::abs(error_px) <= vision_align_threshold_px) {
                  done = true;
                  reason = "centered";
               } else if (elapsed >= align_timeout_s) {
                  done = true;
                  reason = "timeout";
               } else {
                  commandVisionAlignment(*vision_align_last_result);
               }
            } else if (vision_target_gate_search_active && elapsed < align_timeout_s) {
               commandTargetGateSearch();
               reason = "target_gate_search";
            } else if (elapsed >= align_timeout_s) {
               done = true;
               reason = vision_target_gate_search_active
                  ? "target_gate_search_timeout"
                  : "timeout_no_result";
            }

            if (done) {
               stopAndHoldWheelsAtCurrentPosition();
               vision_target_gate_search_active = false;
               vision_phase = VisionRuntimePhase::ClassifyHold;
               vision_hold_tile = vision_align_tile;
               vision_hold_start_t = t;
               pending_vision_results.clear();
               if (vision_align_last_result &&
                   reportableVisionResult(*vision_align_last_result))
               {
                  pending_vision_results.push_back(*vision_align_last_result);
               }
               logRobotTerminalEvent(
                  "vision_align_finished",
                  {
                     {"tile", "(" + std::to_string(vision_hold_tile.x) + "," + std::to_string(vision_hold_tile.y) + ")"},
                     {"reason", reason},
                     {"elapsed", numberText(elapsed, 3)},
                     {"center_error_px", numberText(error_px, 2)},
                     {"preserved_results", std::to_string(pending_vision_results.size())},
                  });
            }

            counter++;
            continue;
         }

         if (vision_phase == VisionRuntimePhase::ClassifyHold) {
            // HOLDING_FOR_REPORT: keep velocities at zero every cycle (sim-time hold).
            stopAndHoldWheelsAtCurrentPosition();
            enqueueVisionFramesForTile(vision_hold_tile);
            pollVisionResultsForHold();
            if (vision_phase == VisionRuntimePhase::AlignAdjust) {
               counter++;
               continue;
            }

            const double elapsed = t - vision_hold_start_t;
            if (elapsed >= vision_hold_duration_s) {
               logRobotEvent(
                  "report_hold_elapsed",
                  {
                     {"tile", "(" + std::to_string(vision_hold_tile.x) + "," + std::to_string(vision_hold_tile.y) + ")"},
                     {"elapsed", numberText(elapsed, 3)},
                     {"required", numberText(vision_hold_duration_s, 3)},
                  });
               const std::string result = processBestVisionResultForTile();
               vision_checked_tiles.insert({vision_hold_tile.x, vision_hold_tile.y});
               logRobotEvent(
                  "vision_hold_finished",
                  {
                     {"tile", "(" + std::to_string(vision_hold_tile.x) + "," + std::to_string(vision_hold_tile.y) + ")"},
                     {"result", result},
                     {"pending_results", std::to_string(pending_vision_results.size())},
                  });
               restoreVisionAlignmentHeading();
               vision_phase = VisionRuntimePhase::Idle;  // RESUMING -> NAVIGATING
               vision_hold_start_t = -1.0;
               pending_vision_results.clear();
               logRobotTerminalEvent(
                  "report_resume_navigation",
                  {
                     {"tile", "(" + std::to_string(vision_hold_tile.x) + "," + std::to_string(vision_hold_tile.y) + ")"},
                     {"result", result},
                  });
            }

            counter++;
            continue;
         }

         if (legacy_explorer && !legacy_explorer->finished()) {
            const auto before_tile = legacy_explorer->currentTile();
            const auto snapshot = legacy_io->sensorSnapshot();
            legacy_explorer->stepExploration(snapshot);
            const auto after_tile = legacy_explorer->currentTile();

            // The motion pump aborted this drive because it saw a reportable
            // detection mid-edge. Run the classify-hold for that tile now (the
            // hold will align + classify + report + mark the tile reported).
            const bool vision_interrupted = vision_interrupt_active;
            if (vision_interrupted) {
               startVisionHold(vision_interrupt_tile, robot->getTime());
               if (reportableVisionResult(vision_interrupt_result)) {
                  pending_vision_results.push_back(vision_interrupt_result);
               }
               logRobotEvent(
                  "vision_interrupt_hold_started",
                  {
                     {"tile", "(" + std::to_string(vision_interrupt_tile.x) + "," + std::to_string(vision_interrupt_tile.y) + ")"},
                     {"kind", vision_interrupt_result.kind},
                     {"class", vision_interrupt_result.class_name},
                  });
               vision_interrupt_active = false;
            }

            const bool can_hold_for_vision =
               !vision_interrupted &&
               vision_runtime_ptr &&
               vision_hold_after_tile_advance;

            const bool tile_unchecked =
               vision_checked_tiles.count({after_tile.x, after_tile.y}) == 0;

            const bool initial_tile_check =
               !vision_initial_hold_considered &&
               before_tile == after_tile;

            const bool advanced_tile = after_tile != before_tile;

            vision_initial_hold_considered = true;

            if (can_hold_for_vision && tile_unchecked && (advanced_tile || initial_tile_check)) {
               startVisionHold(after_tile, robot->getTime());
            } else if (!vision_interrupted && vision_runtime_ptr && (advanced_tile || initial_tile_check) && tile_unchecked) {
               logRobotEvent(
                  "vision_hold_not_started",
                  {
                     {"tile", "(" + std::to_string(after_tile.x) + "," + std::to_string(after_tile.y) + ")"},
                     {"hold_after_tile_advance", boolText(vision_hold_after_tile_advance)},
                     {"returning_to_start", boolText(legacy_explorer->returningToStart())},
                  });
            }
         }

         if (legacy_explorer && legacy_explorer->finished()) {
            wheel_left->setVelocity(0.0);
            wheel_right->setVelocity(0.0);
            wheel_left->setPosition(leftEncoders ? leftEncoders->getValue() : 0.0);
            wheel_right->setPosition(rightEncoders ? rightEncoders->getValue() : 0.0);
            if (!legacy_finished_logged) {
               legacy_finished_logged = true;
               diag::log(
                  diag::Level::Info,
                  "ROBOT_EVENT node=legacy_explorer event=finished backend=legacy"
               );
            }
            if (legacy_finished_detected_t < 0.0) {
               legacy_finished_detected_t = t;
            }

            const bool matrix_after_finish =
               has_latest_submission_matrix &&
               latest_submission_matrix_t >= legacy_finished_detected_t;

            const bool fallback_wait_expired =
               has_latest_submission_matrix &&
               legacy_finished_detected_t >= 0.0 &&
               (t - legacy_finished_detected_t) >= 1.0;

            if (!submission_sent && (matrix_after_finish || fallback_wait_expired)) {
               submission_sent = enviarSubmissionMatrix(latest_submission_matrix);

               if (!submission_sent) {
                  diag::log(
                     diag::Level::Error,
                     "ROBOT_EVENT node=main event=submission_matrix_send_failed reason=enviarSubmissionMatrix_returned_false"
                  );
               }
            }

            if (!submission_sent && !has_latest_submission_matrix) {
               diag::log(
                  diag::Level::Warn,
                  "ROBOT_EVENT node=main event=submission_matrix_waiting reason=no_mapper_submission_matrix_received"
               );
            }
         }

         double loop_ms = std::chrono::duration<double, std::milli>(
            std::chrono::steady_clock::now() - wall_loop_t0
         ).count();

         if (last_diag_t < 0.0 || (t - last_diag_t) >= 1.0) {
            last_diag_t = t;

            std::ostringstream oss;
            const exploration_legacy::TileCoord legacy_tile = legacy_explorer
               ? legacy_explorer->currentTile()
               : exploration_legacy::TileCoord{};
            const exploration_legacy::TileCoord legacy_start_tile = legacy_explorer
               ? legacy_explorer->startTile()
               : exploration_legacy::TileCoord{};
            oss << std::fixed << std::setprecision(4);
            oss << "seq=" << counter
               << " t=" << t
               << " backend=legacy"
               << " yaw_webots=" << yaw_webots
               << " yaw_ros=" << yaw_ros
               << " encL=" << left_enc_rad
	               << " encR=" << right_enc_rad
	               << " gps=(" << fixpos.x << "," << fixpos.y << "," << fixpos.z << ")"
	               << " lidar_ms=" << lidar_ms
	               << " loc=("
	               << localization_state.x_m << ","
	               << localization_state.y_m << ","
	               << localization_state.yaw_rad << ")"
	               << " loc_vx=" << localization_state.vx_mps
	               << " loc_wz=" << localization_state.wz_radps
	               << " loc_gps_used=" << (localization_state.gps_used ? 1 : 0)
	               << " loc_gps_rejected=" << (localization_state.gps_rejected ? 1 : 0)
	               << " wheel_odom=("
	               << wheel_odom_update.pose.x << ","
               << wheel_odom_update.pose.y << ","
               << wheel_odom_update.pose.yaw << ")"
               << " wheel_vx=" << wheel_odom_update.vx
               << " wheel_wz=" << wheel_odom_update.wz
               << " front_clearance=" << front_clearance_m
               << " slip=" << (wheel_odom_update.slip_suspected ? 1 : 0)
               << " bridge_ms=" << bridge_ms
               << " loop_ms=" << loop_ms
               << " legacy_phase=" << (legacy_explorer ? legacy_explorer->phaseName() : "none")
               << " legacy_start_tile=(" << legacy_start_tile.x << "," << legacy_start_tile.y << ")"
               << " legacy_current_tile=(" << legacy_tile.x << "," << legacy_tile.y << ")"
               << " legacy_return_remaining=" << (legacy_explorer ? legacy_explorer->returnRemaining() : 0)
               << " legacy_finished=" << ((legacy_explorer && legacy_explorer->finished()) ? 1 : 0)
               << " legacy_visited_count=" << (legacy_explorer ? legacy_explorer->visitedCount() : 0)
               << " legacy_blocked_count=" << (legacy_explorer ? legacy_explorer->blockedCount() : 0)
               << " legacy_hole_count=" << (legacy_explorer ? legacy_explorer->holeCount() : 0)
               << " legacy_last_event=" << (legacy_explorer ? legacy_explorer->lastEvent() : "none");

            diag::log(diag::Level::Info, oss.str());
         }

         if (last_pose_log_t < 0.0 || (t - last_pose_log_t) >= 1.0) {
            last_pose_log_t = t;
            logRobotEvent(
               "pose_summary",
               {
                  {"x", numberText(localization_state.x_m, 4)},
                  {"y", numberText(localization_state.y_m, 4)},
                  {"z", numberText(localization_state.z_m, 4)},
                  {"yaw", numberText(localization_state.yaw_rad, 4)},
                  {"vx", numberText(localization_state.vx_mps, 4)},
                  {"wz", numberText(localization_state.wz_radps, 4)},
                  {"frame", "odom"},
                  {"cov_x", numberText(localization_state.cov_x, 6)},
                  {"cov_y", numberText(localization_state.cov_y, 6)},
                  {"source", "localizer2d"},
               });
         }

         counter++;
         continue;
      }

      if (!strong_black_hole_sample) {
         black_hole_brake_sample_latched = false;
      }

      if (
         black_hole_safety_state == BlackHoleSafetyState::BrakeHold &&
         t >= black_hole_safety_until_t)
      {
         if (black_hole_reverse_s > 0.0) {
            black_hole_safety_state = BlackHoleSafetyState::ReverseEscape;
            black_hole_safety_until_t = t + black_hole_reverse_s;
            diag::log(
               diag::Level::Warn,
               "[SAFETY] Emergency black-hole reverse escape activated for ",
               black_hole_reverse_ms,
               " ms speed=",
               black_hole_reverse_speed
            );
         } else {
            black_hole_safety_state = BlackHoleSafetyState::Idle;
            black_hole_safety_until_t = -1.0;
            diag::log(diag::Level::Warn, "[SAFETY] Emergency black-hole safety released");
         }
      }

      if (
         black_hole_safety_state == BlackHoleSafetyState::ReverseEscape &&
         t >= black_hole_safety_until_t)
      {
         black_hole_safety_state = BlackHoleSafetyState::Idle;
         black_hole_safety_until_t = -1.0;
         diag::log(diag::Level::Warn, "[SAFETY] Emergency black-hole safety released");
         if (strong_black_hole_sample && t - black_hole_still_detected_log_t >= 1.0) {
            black_hole_still_detected_log_t = t;
            diag::log(
               diag::Level::Warn,
               "[SAFETY] Black-hole color still strong after reverse escape; "
               "waiting for color latch reset before retrigger"
            );
         }
      }

      if (
         black_hole_safety_state == BlackHoleSafetyState::Idle &&
         black_hole_brake_hold_s > 0.0 &&
         strong_black_hole_sample &&
         !black_hole_brake_sample_latched)
      {
         black_hole_safety_state = BlackHoleSafetyState::BrakeHold;
         black_hole_brake_sample_latched = true;
         black_hole_safety_until_t = t + black_hole_brake_hold_s;
         logRobotEvent(
            diag::Level::Warn,
            "floor_color_classified",
            {
               {"raw_rgb", "(" + std::to_string(floor_color_sample.r) + "," + std::to_string(floor_color_sample.g) + "," + std::to_string(floor_color_sample.b) + ")"},
               {"chosen_class", floor_color_sample.color_class},
               {"confidence", numberText(floor_color_sample.confidence, 3)},
               {"color_conf", numberText(floor_color_sample.confidence, 3)},
               {"accepted", "true"},
               {"reason", "emergency_black_hole_brake"},
               {"state", blackHoleSafetyStateName(black_hole_safety_state)},
               {"robot_world_x", numberText(localization_state.x_m, 4)},
               {"robot_world_y", numberText(localization_state.y_m, 4)},
            });
         diag::log(
            diag::Level::Warn,
            "[SAFETY] Emergency black-hole brake activated for ",
            black_hole_brake_hold_ms,
            " ms class=",
            floor_color_sample.color_class,
            " confidence=",
            floor_color_sample.confidence
         );
      } else if (
         black_hole_safety_state == BlackHoleSafetyState::Idle &&
         black_hole_reverse_s > 0.0 &&
         strong_black_hole_sample &&
         !black_hole_brake_sample_latched)
      {
         black_hole_safety_state = BlackHoleSafetyState::ReverseEscape;
         black_hole_brake_sample_latched = true;
         black_hole_safety_until_t = t + black_hole_reverse_s;
         logRobotEvent(
            diag::Level::Warn,
            "floor_color_classified",
            {
               {"raw_rgb", "(" + std::to_string(floor_color_sample.r) + "," + std::to_string(floor_color_sample.g) + "," + std::to_string(floor_color_sample.b) + ")"},
               {"chosen_class", floor_color_sample.color_class},
               {"confidence", numberText(floor_color_sample.confidence, 3)},
               {"color_conf", numberText(floor_color_sample.confidence, 3)},
               {"accepted", "true"},
               {"reason", "emergency_black_hole_reverse"},
               {"state", blackHoleSafetyStateName(black_hole_safety_state)},
               {"robot_world_x", numberText(localization_state.x_m, 4)},
               {"robot_world_y", numberText(localization_state.y_m, 4)},
            });
         diag::log(
            diag::Level::Warn,
            "[SAFETY] Emergency black-hole reverse escape activated for ",
            black_hole_reverse_ms,
            " ms class=",
            floor_color_sample.color_class,
            " confidence=",
            floor_color_sample.confidence,
            " speed=",
            black_hole_reverse_speed
         );
      }

	      const bool nav2_cmd_alive =
	         (last_cmd_rx_t >= 0.0) && ((t - last_cmd_rx_t) <= kNav2CmdTimeout);

      // 6) Calcular controle
      double v = 0.0;
      double w = 0.0;

      if (nav2_cmd_alive && use_nav2) {
         idle_wiggle_active = false;

         v = clampd(last_cmd.v, -kMaxLinearVel, kMaxLinearVel);
         w = clampd(last_cmd.w, -kMaxAngularVel, kMaxAngularVel);
      } else {
         v = 0.0;
         w = 0.0;
      }

      if (!use_nav2) {
         int key = keyboard->getKey();

         switch (key) {
            case Keyboard::UP:
               v = 0.85 * kMaxLinearVel;
               w = 0.0;
               break;
            case Keyboard::DOWN:
               v = -0.85 * kMaxLinearVel;
               w = 0.0;
               break;
            case Keyboard::LEFT:
               v = 0.0;
               w = 0.85 * kMaxAngularVel;
               break;
            case Keyboard::RIGHT:
               v = 0.0;
               w = -0.85 * kMaxAngularVel;
               break;
            default:
               v = 0.0;
               w = 0.0;
            break;
         }
      }

      if (black_hole_safety_state == BlackHoleSafetyState::BrakeHold) {
         v = 0.0;
         w = 0.0;
      } else if (black_hole_safety_state == BlackHoleSafetyState::ReverseEscape) {
         v = black_hole_reverse_speed;
         w = 0.0;
      }

      const auto wheel_odom_update = wheel_odom.update(
         left_enc_rad,
         right_enc_rad,
         yaw_ros,
         fixpos.x,
         fixpos.y,
         gps_speed_mps,
         v,
         w,
         front_clearance_m,
         dt);

      sensors::LidarVelocityGuardConfig lidar_guard_cfg;
      const auto lidar_guard = sensors::applyLidarVelocityGuard(
         v,
         w,
         layer,
         lidar_guard_cfg
      );

      if (lidar_guard.active) {
         logRobotEvent(
            "lidar_velocity_guard",
            {
               {"reason", lidar_guard.reason},
               {"raw_v", numberText(v, 4)},
               {"raw_w", numberText(w, 4)},
               {"safe_v", numberText(lidar_guard.v, 4)},
               {"safe_w", numberText(lidar_guard.w, 4)},
               {"sector_index", std::to_string(lidar_guard.sector_index)},
               {"sector_angle", numberText(lidar_guard.sector_angle_rad, 3)},
               {"sector_min_range", numberText(lidar_guard.sector_min_range_m, 4)},
               {"closing_speed", numberText(lidar_guard.closing_speed_mps, 4)},
               {"sectors", std::to_string(lidar_guard_cfg.sectors)}
            });
      }

      v = lidar_guard.v;
      w = lidar_guard.w;

      const auto wheel_diag = control::computeWheelCommandDiagnostics(
         v,
         w,
         raioRoda,
         L,
         max_speed,
         kMaxLinearVel,
         kMaxAngularVel
      );

      // 7) Aplicar comando nas rodas
      control::applyBaseVelocity(
         wheel_left,
         wheel_right,
         v,
         w,
         raioRoda,
         L,
         max_speed
      );
      if (last_wheel_log_t < 0.0 || (t - last_wheel_log_t) >= 0.5) {
         last_wheel_log_t = t;
         logRobotEvent(
            "wheel_command_applied",
            {
               {"raw_v", numberText(wheel_diag.raw_v, 4)},
               {"raw_w", numberText(wheel_diag.raw_w, 4)},
               {"clamped_v", numberText(wheel_diag.clamped_v, 4)},
               {"clamped_w", numberText(wheel_diag.clamped_w, 4)},
               {"angular_sign_applied", numberText(wheel_diag.angular_sign_applied, 1)},
               {"wl_raw", numberText(wheel_diag.wl_raw, 4)},
               {"wr_raw", numberText(wheel_diag.wr_raw, 4)},
               {"wheel_scale", numberText(wheel_diag.wheel_scale, 4)},
               {"wl_final", numberText(wheel_diag.wl_final, 4)},
               {"wr_final", numberText(wheel_diag.wr_final, 4)},
               {"motor_max", numberText(max_speed, 3)},
               {"saturated", boolText(wheel_diag.saturated)},
               {"last_cmd_age", numberText((last_cmd_rx_t >= 0.0) ? (t - last_cmd_rx_t) : -1.0, 4)},
               {"nav2_cmd_alive", boolText(nav2_cmd_alive)},
               {"state", blackHoleSafetyStateName(black_hole_safety_state)},
               {"wheel_odom_x", numberText(wheel_odom_update.pose.x, 4)},
               {"wheel_odom_y", numberText(wheel_odom_update.pose.y, 4)},
               {"wheel_odom_yaw", numberText(wheel_odom_update.pose.yaw, 4)},
               {"wheel_odom_vx", numberText(wheel_odom_update.vx, 4)},
               {"wheel_odom_wz", numberText(wheel_odom_update.wz, 4)},
               {"wheel_odom_valid", boolText(wheel_odom_update.valid)},
               {"wheel_slip_suspected", boolText(wheel_odom_update.slip_suspected)},
               {"front_clearance", numberText(front_clearance_m, 4)},
            });
      }

      // 8) Publicar telemetria/estado após decidir e aplicar controle
      double bridge_ms = 0.0;
      if (bridge_client) {
         auto tb0 = std::chrono::steady_clock::now();

         const bool should_send_state =
            periodicDue(t, last_state_send_t, timing.state_period_s);

         const bool should_send_scan =
            periodicDue(t, last_scan_send_t, timing.scan_period_s);

         const bool should_send_color =
            strong_black_hole_sample ||
            periodicDue(t, last_color_send_t, timing.color_period_s);

         const bool should_send_camera =
            periodicDue(t, last_camera_send_t, timing.camera_period_s);

         bool state_sent_this_step = false;

         if (should_send_state) {
            bridge_client->sendTime(t);
            bridge_client->sendImu(0.0, 0.0, yaw_ros);
            bridge_client->sendGps(fixpos);
            bridge_client->sendLocalization(localization_state);
            state_sent_this_step = true;

            if (wheel_odom_update.valid) {
               bridge_client->sendWheelOdom(
                  wheel_odom_update.pose.x,
                  wheel_odom_update.pose.y,
                  wheel_odom_update.pose.yaw,
                  wheel_odom_update.vx,
                  wheel_odom_update.wz,
                  wheel_odom_update.slip_suspected
               );
            }

            last_state_send_t = t;
         }

         if (should_send_scan) {
            if (!state_sent_this_step) {
               bridge_client->sendTime(t);
               bridge_client->sendImu(0.0, 0.0, yaw_ros);
               bridge_client->sendGps(fixpos);
               bridge_client->sendLocalization(localization_state);
            }

            bridge_client->sendScan(layer);

            static std::uint64_t scan_send_count = 0;
            ++scan_send_count;

            if ((scan_send_count % 60) == 1) {
               logRobotEvent(
                  "scan_sent",
                  {
                     {"count", std::to_string(scan_send_count)},
                     {"ranges", std::to_string(layer.size())},
                     {"period_s", numberText(timing.scan_period_s, 4)},
                  });
            }

            last_scan_send_t = t;
         }

         if (should_send_color) {
            bridge_client->sendColorClassification(
               floor_color_sample.color_class,
               floor_color_sample.r,
               floor_color_sample.g,
               floor_color_sample.b,
               floor_color_sample.confidence
            );

            diag::log(
               diag::Level::Debug,
               "[COLOR] class=", floor_color_sample.color_class,
               " rgb=(", floor_color_sample.r, ",", floor_color_sample.g, ",", floor_color_sample.b, ")",
               " confidence=", floor_color_sample.confidence
            );

            last_color_send_t = t;
         }

         if (should_send_camera) {
            if (use_cam) {
               sendCameraFrameIfReady("came", came, t);
               sendCameraFrameIfReady("camd", camd, t);
            }
            last_camera_send_t = t;
         }

         auto tb1 = std::chrono::steady_clock::now();
         bridge_ms = std::chrono::duration<double, std::milli>(tb1 - tb0).count();
      }

      // Vision now runs in-process and synchronously, only during the per-tile
      // classify-hold / align phases (see enqueueVisionFramesForTile). There is
      // no always-on streaming pass anymore -- it previously only drained the TCP
      // result queue without acting on it.

      // 9) Log diagnóstico a cada ~1 s
      double loop_ms = std::chrono::duration<double, std::milli>(
         std::chrono::steady_clock::now() - wall_loop_t0
      ).count();

      if (last_diag_t < 0.0 || (t - last_diag_t) >= 1.0) {
         last_diag_t = t;

         const double encL = leftEncoders->getValue();
         const double encR = rightEncoders->getValue();

         std::ostringstream oss;
         oss << std::fixed << std::setprecision(4);
         oss << "seq=" << counter
            << " t=" << t
            << " yaw_webots=" << yaw_webots
            << " yaw_ros=" << yaw_ros
            << " encL=" << encL
            << " encR=" << encR
	            << " pose=(" << local_pose.x << "," << local_pose.y << "," << local_pose.th << ")"
	            << " gps=(" << fixpos.x << "," << fixpos.y << "," << fixpos.z << ")"
	            << " lidar_ms=" << lidar_ms
	            << " loc=("
	            << localization_state.x_m << ","
	            << localization_state.y_m << ","
	            << localization_state.yaw_rad << ")"
	            << " loc_vx=" << localization_state.vx_mps
	            << " loc_wz=" << localization_state.wz_radps
	            << " loc_gps_used=" << (localization_state.gps_used ? 1 : 0)
	            << " loc_gps_rejected=" << (localization_state.gps_rejected ? 1 : 0)
	            << " wheel_odom=("
	            << wheel_odom_update.pose.x << ","
            << wheel_odom_update.pose.y << ","
            << wheel_odom_update.pose.yaw << ")"
            << " wheel_vx=" << wheel_odom_update.vx
            << " wheel_wz=" << wheel_odom_update.wz
            << " front_clearance=" << front_clearance_m
            << " slip=" << (wheel_odom_update.slip_suspected ? 1 : 0)
            << " bridge_ms=" << bridge_ms
            << " loop_ms=" << loop_ms
            << " nav2_cmd_alive=" << (nav2_cmd_alive ? 1 : 0)
            << " black_hole_safety=" << blackHoleSafetyStateName(black_hole_safety_state)
            << " since_cmd=" << ((last_cmd_rx_t >= 0.0) ? (t - last_cmd_rx_t) : -1.0);

         diag::log(diag::Level::Info, oss.str());
      }

      if (last_pose_log_t < 0.0 || (t - last_pose_log_t) >= 1.0) {
         last_pose_log_t = t;
         logRobotEvent(
            "pose_summary",
            {
               {"x", numberText(localization_state.x_m, 4)},
               {"y", numberText(localization_state.y_m, 4)},
               {"z", numberText(localization_state.z_m, 4)},
               {"yaw", numberText(localization_state.yaw_rad, 4)},
               {"vx", numberText(localization_state.vx_mps, 4)},
               {"wz", numberText(localization_state.wz_radps, 4)},
               {"frame", "odom"},
               {"cov_x", numberText(localization_state.cov_x, 6)},
               {"cov_y", numberText(localization_state.cov_y, 6)},
               {"source", "localizer2d"},
            });
      }

      counter++;
   }

   wheel_left->setVelocity(0.0);
   wheel_right->setVelocity(0.0);

   vision_runtime_ptr.reset();

   delete robot;
   return 0;
}
