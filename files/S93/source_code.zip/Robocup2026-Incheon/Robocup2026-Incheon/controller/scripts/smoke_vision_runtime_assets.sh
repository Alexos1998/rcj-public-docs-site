#!/usr/bin/env bash
# Verify all runtime perception assets exist in controller/models and the
# manifest references them. Does NOT require ROS.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODELS_DIR="$(cd "${SCRIPT_DIR}/../models" && pwd)"

required=(
  presence.onnx
  object_presence.onnx
  object_type.onnx
  victim_bbox.onnx
  victim_cls.onnx
  target_mask_rf.yml
  target_mask_features.yml
  model_manifest.json
)

pass=0
fail=0
for f in "${required[@]}"; do
  if [[ -s "${MODELS_DIR}/${f}" ]]; then
    echo "[PASS] ${f} present ($(stat -c%s "${MODELS_DIR}/${f}") bytes)"
    pass=$((pass + 1))
  else
    echo "[FAIL] ${f} missing or empty"
    fail=$((fail + 1))
  fi
done

# Manifest must mention the RF model and the ONNX models.
manifest="${MODELS_DIR}/model_manifest.json"
if [[ -s "${manifest}" ]]; then
  for key in target_mask_rf presence object_presence object_type victim_bbox victim_cls; do
    if grep -q "\"${key}\"" "${manifest}"; then
      echo "[PASS] manifest references ${key}"
      pass=$((pass + 1))
    else
      echo "[FAIL] manifest missing ${key}"
      fail=$((fail + 1))
    fi
  done
fi

python3 - <<'PY' "${MODELS_DIR}/victim_cls.metadata.json" "${MODELS_DIR}/object_presence.metadata.json"
import json
import sys
from pathlib import Path

victim_meta = Path(sys.argv[1])
object_meta = Path(sys.argv[2])
checks = [
    (victim_meta, ["harmed", "unharmed", "stable", "none", "fake"]),
    (object_meta, ["none", "target", "victim"]),
]
for path, expected in checks:
    labels = json.loads(path.read_text()).get("labels")
    if labels != expected:
        print(f"[FAIL] {path.name} labels {labels!r} != {expected!r}")
        raise SystemExit(1)
    print(f"[PASS] {path.name} labels {labels}")
PY
if [[ $? -eq 0 ]]; then
  pass=$((pass + 2))
else
  fail=$((fail + 1))
fi

echo ""
echo "$((pass))/$((pass + fail)) asset checks passed"
[[ ${fail} -eq 0 ]]
