#!/usr/bin/env bash
# Compile + run the tile-report gate and sim-time report-hold logic test.
# Verifies: a tile that already reported is skipped before inference, velocities
# stay zero during the hold, and the report only fires after >= 1.0s of sim time.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_DIR="$(cd "${SCRIPT_DIR}/../ros2_ws/src/ros2_vision" && pwd)"
OUT="$(mktemp -d)"

echo "=== building tile-report / report-hold test ==="
g++ -std=c++17 -O2 -I "${PKG_DIR}/include" \
  "${PKG_DIR}/test/test_tile_report.cpp" \
  "${PKG_DIR}/src/duplicate_filter.cpp" \
  -o "${OUT}/test_tile" || exit 1

"${OUT}/test_tile" || exit 1
