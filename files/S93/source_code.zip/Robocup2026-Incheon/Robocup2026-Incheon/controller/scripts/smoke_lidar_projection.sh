#!/usr/bin/env bash
# Compile + run the standalone LidarCameraProjector test (pixel->angle->scan index,
# robust distance, range filtering). No ROS / OpenCV linkage needed.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_DIR="$(cd "${SCRIPT_DIR}/../ros2_ws/src/ros2_vision" && pwd)"
OUT="$(mktemp -d)"

echo "=== building lidar projection test ==="
g++ -std=c++17 -O2 -I "${PKG_DIR}/include" \
  "${PKG_DIR}/test/test_lidar_projection.cpp" \
  "${PKG_DIR}/src/lidar_camera_projector.cpp" \
  -o "${OUT}/test_lidar" || exit 1

"${OUT}/test_lidar" || exit 1
