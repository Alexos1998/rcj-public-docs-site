#!/usr/bin/env bash
# =========================================================
# race_timing_lib.sh — single source of truth for timing
# =========================================================
#
# Sourced by Ros.sh (and the smoke test). Provides:
#   race_timing_resolve         -> resolve RACE_*_HZ from profile/scale/overrides
#   race_timing_log             -> print the resolved configuration
#   race_timing_write_yaml FILE -> emit the ROS 2 runtime override YAML
#
# Precedence:
#   1) an explicitly-set RACE_*_HZ env var always wins;
#   2) otherwise: profile value (RACE_TIMING_PROFILE) x RACE_RATE_SCALE, clamped.
#
# Main knobs:
#   RACE_USE_SIM_TIME=0|1   0 (default) wall-time fast start; 1 sim-time + /clock
#   RACE_TIMING_PROFILE     low | balanced (default) | high
#   RACE_RATE_SCALE         scales the profile values (default 1.0)
#
# Fine overrides (win over profile/scale): RACE_STATE_HZ RACE_SCAN_HZ
#   RACE_COLOR_HZ RACE_CAMERA_HZ RACE_NAV_CONTROLLER_HZ
#   RACE_NAV_PLANNER_HZ RACE_BEHAVIOR_HZ RACE_LOCAL_COSTMAP_{UPDATE,PUBLISH}_HZ
#   RACE_GLOBAL_COSTMAP_{UPDATE,PUBLISH}_HZ RACE_SLAM_MAX_HZ.
#   (RACE_VISION_HZ is read directly by the controller; default = RACE_CAMERA_HZ.)
#
# How to run (from controller/):
#   RACE_USE_SIM_TIME=0 RACE_TIMING_PROFILE=balanced ./Ros.sh   # default fast start
#   RACE_USE_SIM_TIME=0 RACE_TIMING_PROFILE=low      ./Ros.sh   # weak PCs
#   RACE_USE_SIM_TIME=0 RACE_TIMING_PROFILE=high     ./Ros.sh   # strong PCs
#   RACE_USE_SIM_TIME=1 RACE_TIMING_PROFILE=balanced ./Ros.sh   # sim-time + /clock
#
# Validate without ROS:  ./scripts/smoke_timing_config.sh
# Validate with ROS:
#   ros2 param get /ros2_bridge use_sim_time
#   ros2 param get /ros2_bridge publish_clock
#   ros2 param get /controller_server controller_frequency
#   ros2 topic hz /scan ; ros2 topic hz /imu/data ; ros2 topic hz /odometry/filtered
#   ros2 topic echo /clock --once          # sim-time only
#
# Full reference: controller/TIMING.md (note: *.md is gitignored in this repo).

# clamp(base * RACE_RATE_SCALE, min, max)
_race_calc() {
    awk -v b="$1" -v lo="$2" -v hi="$3" -v s="$RACE_RATE_SCALE" 'BEGIN{
        if (s <= 0) s = 1.0;
        v = b * s;
        if (v < lo) v = lo;
        if (v > hi) v = hi;
        printf("%.6g", v);
    }'
}

# _race_float NUM: echo NUM guaranteed to carry a decimal point (or exponent) so
# the emitted YAML scalar is parsed as a double, not an integer.
# Nav2 (controller_frequency, etc.) declares these params as double; overriding
# a double param with an integer makes the
# node abort with InvalidParameterTypeException. "%.6g" drops the decimal for
# whole numbers (e.g. 25.0 -> "25"), so normalize before writing the YAML.
_race_float() {
    awk -v v="$1" 'BEGIN{
        if (v ~ /[.eE]/) printf("%s", v);
        else printf("%s.0", v);
    }'
}

# race_timing_resolve: exports the final timing variables.
race_timing_resolve() {
    export RACE_USE_SIM_TIME="${RACE_USE_SIM_TIME:-0}"
    export RACE_TIMING_PROFILE="${RACE_TIMING_PROFILE:-balanced}"
    export RACE_RATE_SCALE="${RACE_RATE_SCALE:-1.0}"

    case "$RACE_TIMING_PROFILE" in
        low|balanced|high) ;;
        *)
            echo "[ERRO] RACE_TIMING_PROFILE inválido: '$RACE_TIMING_PROFILE'" >&2
            echo "[ERRO] Valores válidos: low, balanced, high" >&2
            return 2
            ;;
    esac

    # Detect explicitly-set fine-grained overrides BEFORE applying the profile.
    declare -A _RACE_HZ_SET=()
    local _v
    for _v in RACE_STATE_HZ RACE_SCAN_HZ RACE_COLOR_HZ RACE_CAMERA_HZ \
              RACE_NAV_CONTROLLER_HZ RACE_NAV_PLANNER_HZ RACE_BEHAVIOR_HZ \
              RACE_LOCAL_COSTMAP_UPDATE_HZ RACE_LOCAL_COSTMAP_PUBLISH_HZ \
              RACE_GLOBAL_COSTMAP_UPDATE_HZ RACE_GLOBAL_COSTMAP_PUBLISH_HZ \
              RACE_SLAM_MAX_HZ; do
        [[ -n "${!_v+x}" ]] && _RACE_HZ_SET["$_v"]=1
    done

    local _P_STATE_HZ _P_SCAN_HZ _P_COLOR_HZ _P_CAMERA_HZ
    local _P_NAV_CTRL_HZ _P_NAV_PLAN_HZ _P_BEHAVIOR_HZ
    local _P_LCM_UPD_HZ _P_LCM_PUB_HZ _P_GCM_UPD_HZ _P_GCM_PUB_HZ _P_SLAM_HZ

    case "$RACE_TIMING_PROFILE" in
        low)
            _P_STATE_HZ=30.0;  _P_SCAN_HZ=30.0;      _P_COLOR_HZ=10.0;      _P_CAMERA_HZ=8.0
            _P_NAV_CTRL_HZ=5.0;   _P_NAV_PLAN_HZ=2.5;    _P_BEHAVIOR_HZ=5.0
            _P_LCM_UPD_HZ=5.0; _P_LCM_PUB_HZ=2.0;    _P_GCM_UPD_HZ=2.0;     _P_GCM_PUB_HZ=1.0
            _P_SLAM_HZ=15.0
            ;;
        balanced)
            _P_STATE_HZ=62.5;  _P_SCAN_HZ=62.5;      _P_COLOR_HZ=20.833333; _P_CAMERA_HZ=12.5
            _P_NAV_CTRL_HZ=10.0;  _P_NAV_PLAN_HZ=5.0;    _P_BEHAVIOR_HZ=10.0
            _P_LCM_UPD_HZ=10.0;_P_LCM_PUB_HZ=5.0;    _P_GCM_UPD_HZ=5.0;     _P_GCM_PUB_HZ=2.0
            _P_SLAM_HZ=30.0
            ;;
        high)
            _P_STATE_HZ=62.5;  _P_SCAN_HZ=62.5;      _P_COLOR_HZ=25.0;      _P_CAMERA_HZ=25.0
            _P_NAV_CTRL_HZ=20.0;  _P_NAV_PLAN_HZ=10.0;   _P_BEHAVIOR_HZ=20.0
            _P_LCM_UPD_HZ=15.0;_P_LCM_PUB_HZ=10.0;   _P_GCM_UPD_HZ=10.0;    _P_GCM_PUB_HZ=5.0
            _P_SLAM_HZ=50.0
            ;;
    esac

    # _race_resolve VAR base min max
    _race_resolve() {
        local name="$1" base="$2" lo="$3" hi="$4"
        if [[ -n "${_RACE_HZ_SET[$name]:-}" ]]; then
            export "$name=${!name}"
        else
            export "$name=$(_race_calc "$base" "$lo" "$hi")"
        fi
    }

    _race_resolve RACE_STATE_HZ               "$_P_STATE_HZ"    0.1 125.0
    _race_resolve RACE_SCAN_HZ                "$_P_SCAN_HZ"    0.1 125.0
    _race_resolve RACE_COLOR_HZ               "$_P_COLOR_HZ"   0.1 125.0
    _race_resolve RACE_CAMERA_HZ             "$_P_CAMERA_HZ"  0.1  60.0
    _race_resolve RACE_NAV_CONTROLLER_HZ     "$_P_NAV_CTRL_HZ" 1.0  40.0
    _race_resolve RACE_NAV_PLANNER_HZ        "$_P_NAV_PLAN_HZ" 0.5  20.0
    _race_resolve RACE_BEHAVIOR_HZ           "$_P_BEHAVIOR_HZ" 1.0  40.0
    _race_resolve RACE_LOCAL_COSTMAP_UPDATE_HZ  "$_P_LCM_UPD_HZ" 0.5 40.0
    _race_resolve RACE_LOCAL_COSTMAP_PUBLISH_HZ "$_P_LCM_PUB_HZ" 0.5 40.0
    _race_resolve RACE_GLOBAL_COSTMAP_UPDATE_HZ "$_P_GCM_UPD_HZ" 0.5 40.0
    _race_resolve RACE_GLOBAL_COSTMAP_PUBLISH_HZ "$_P_GCM_PUB_HZ" 0.5 40.0
    _race_resolve RACE_SLAM_MAX_HZ           "$_P_SLAM_HZ"    0.5  62.5

    case "$RACE_USE_SIM_TIME" in
        1|true|TRUE|yes|YES|on|ON) RACE_USE_SIM_TIME_BOOL="true" ;;
        *) RACE_USE_SIM_TIME_BOOL="false" ;;
    esac
    export RACE_USE_SIM_TIME_BOOL
}

# race_timing_log: prints the resolved configuration.
race_timing_log() {
    echo "[timing] RACE_USE_SIM_TIME=$RACE_USE_SIM_TIME (use_sim_time=$RACE_USE_SIM_TIME_BOOL)"
    echo "[timing] RACE_TIMING_PROFILE=$RACE_TIMING_PROFILE"
    echo "[timing] RACE_RATE_SCALE=$RACE_RATE_SCALE"
    echo "[timing] controller: state=$RACE_STATE_HZ Hz scan=$RACE_SCAN_HZ Hz color=$RACE_COLOR_HZ Hz camera=$RACE_CAMERA_HZ Hz"
    echo "[timing] nav_controller=$RACE_NAV_CONTROLLER_HZ Hz nav_planner=$RACE_NAV_PLANNER_HZ Hz behavior=$RACE_BEHAVIOR_HZ Hz"
    echo "[timing] local_costmap=${RACE_LOCAL_COSTMAP_UPDATE_HZ}/${RACE_LOCAL_COSTMAP_PUBLISH_HZ} Hz global_costmap=${RACE_GLOBAL_COSTMAP_UPDATE_HZ}/${RACE_GLOBAL_COSTMAP_PUBLISH_HZ} Hz slam_max=$RACE_SLAM_MAX_HZ Hz"
}

# race_timing_write_yaml FILE: emit the ROS 2 runtime override YAML.
race_timing_write_yaml() {
    local out="$1"
    if [[ -z "$out" ]]; then
        echo "[ERRO] race_timing_write_yaml requer um caminho de saída" >&2
        return 2
    fi

    # All numeric scalars below map to double-typed ROS 2 params; emit them as
    # floats so an integer-looking value (e.g. 25) never overrides a double and
    # aborts the node. See _race_float.
    local slam_interval scan_time
    slam_interval="$(_race_float "$(awk -v hz="$RACE_SLAM_MAX_HZ" 'BEGIN{printf("%.6g", (hz>0)?1.0/hz:0.1)}')")"
    scan_time="$(_race_float "$(awk -v hz="$RACE_SCAN_HZ" 'BEGIN{printf("%.6g", (hz>0)?1.0/hz:0.048)}')")"

    local nav_ctrl_hz nav_plan_hz behavior_hz
    local lcm_upd_hz lcm_pub_hz gcm_upd_hz gcm_pub_hz
    nav_ctrl_hz="$(_race_float "$RACE_NAV_CONTROLLER_HZ")"
    nav_plan_hz="$(_race_float "$RACE_NAV_PLANNER_HZ")"
    behavior_hz="$(_race_float "$RACE_BEHAVIOR_HZ")"
    lcm_upd_hz="$(_race_float "$RACE_LOCAL_COSTMAP_UPDATE_HZ")"
    lcm_pub_hz="$(_race_float "$RACE_LOCAL_COSTMAP_PUBLISH_HZ")"
    gcm_upd_hz="$(_race_float "$RACE_GLOBAL_COSTMAP_UPDATE_HZ")"
    gcm_pub_hz="$(_race_float "$RACE_GLOBAL_COSTMAP_PUBLISH_HZ")"

    cat > "$out" <<EOF
# AUTO-GERADO por race_timing_lib.sh — NÃO EDITAR À MÃO.
# profile=$RACE_TIMING_PROFILE scale=$RACE_RATE_SCALE use_sim_time=$RACE_USE_SIM_TIME_BOOL
/**:
  ros__parameters:
    use_sim_time: $RACE_USE_SIM_TIME_BOOL

ros2_bridge:
  ros__parameters:
    use_sim_time: $RACE_USE_SIM_TIME_BOOL
    publish_clock: $RACE_USE_SIM_TIME_BOOL
    use_webots_time_for_stamps: $RACE_USE_SIM_TIME_BOOL
    scan_time_s: $scan_time

controller_server:
  ros__parameters:
    use_sim_time: $RACE_USE_SIM_TIME_BOOL
    controller_frequency: $nav_ctrl_hz

planner_server:
  ros__parameters:
    use_sim_time: $RACE_USE_SIM_TIME_BOOL
    expected_planner_frequency: $nav_plan_hz

behavior_server:
  ros__parameters:
    use_sim_time: $RACE_USE_SIM_TIME_BOOL
    cycle_frequency: $behavior_hz

local_costmap:
  local_costmap:
    ros__parameters:
      use_sim_time: $RACE_USE_SIM_TIME_BOOL
      update_frequency: $lcm_upd_hz
      publish_frequency: $lcm_pub_hz

global_costmap:
  global_costmap:
    ros__parameters:
      use_sim_time: $RACE_USE_SIM_TIME_BOOL
      update_frequency: $gcm_upd_hz
      publish_frequency: $gcm_pub_hz

slam_toolbox:
  ros__parameters:
    use_sim_time: $RACE_USE_SIM_TIME_BOOL
    minimum_time_interval: $slam_interval
EOF
}
