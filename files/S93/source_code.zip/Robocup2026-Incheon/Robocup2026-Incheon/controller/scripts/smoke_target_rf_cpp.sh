#!/usr/bin/env bash
# Compile + run the standalone C++ tests that verify the runtime target path
# (Random Forest mask + radial ring classifier) WITHOUT Python/ROS, and confirm
# parity with the exported Python predictions on fixed images.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_DIR="$(cd "${SCRIPT_DIR}/../ros2_ws/src/ros2_vision" && pwd)"
MODELS_DIR="$(cd "${SCRIPT_DIR}/../models" && pwd)"
FIX_DIR="${PKG_DIR}/test/fixtures"
OUT="$(mktemp -d)"

CXXFLAGS="-std=c++17 -O2 -I ${PKG_DIR}/include $(pkg-config --cflags opencv4)"
LIBS="$(pkg-config --libs opencv4)"

echo "=== building C++ target RF + radial tests ==="
# shellcheck disable=SC2086
g++ ${CXXFLAGS} "${PKG_DIR}/test/test_target_mask_rf.cpp" "${PKG_DIR}/src/target_mask_rf.cpp" ${LIBS} -o "${OUT}/test_rf" || exit 1
# shellcheck disable=SC2086
g++ ${CXXFLAGS} "${PKG_DIR}/test/test_target_radial.cpp" "${PKG_DIR}/src/target_mask_rf.cpp" "${PKG_DIR}/src/target_radial_classifier.cpp" ${LIBS} -o "${OUT}/test_radial" || exit 1

echo "=== mask parity (C++ vs Python RTrees) ==="
"${OUT}/test_rf" "${MODELS_DIR}" "${FIX_DIR}" || exit 1
echo ""
echo "=== full radial decode (pattern + F/P/C/O) ==="
"${OUT}/test_radial" "${MODELS_DIR}" "${FIX_DIR}" || exit 1
