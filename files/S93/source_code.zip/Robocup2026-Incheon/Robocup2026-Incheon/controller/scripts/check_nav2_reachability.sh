#!/usr/bin/env bash
set -uo pipefail

if ! command -v ros2 >/dev/null 2>&1; then
    if [[ -f /opt/ros/${ROS_DISTRO:-humble}/setup.bash ]]; then
        # shellcheck disable=SC1090
        source /opt/ros/${ROS_DISTRO:-humble}/setup.bash
    fi
    if [[ -f /workspace/controller/ros2_ws/install/setup.bash ]]; then
        # shellcheck disable=SC1091
        source /workspace/controller/ros2_ws/install/setup.bash
    fi
fi

if ! command -v ros2 >/dev/null 2>&1; then
    echo "[FAIL] ros2 CLI is not available in this shell"
    exit 2
fi

failures=0
pass() { echo "[PASS] $*"; }
fail() { echo "[FAIL] $*"; failures=$((failures + 1)); }
section() { echo; echo "========== $* =========="; }
lifecycle_state_name() {
    printf '%s\n' "$1" | awk 'NF { print tolower($1); exit }'
}

section "Nav2 processes and lifecycle"
nodes="$(timeout 5 ros2 node list 2>/dev/null || true)"
echo "$nodes" | grep -E '/(planner_server|controller_server|bt_navigator|lifecycle_manager_navigation)$' || true
for node in /planner_server /controller_server /bt_navigator; do
    state="$(timeout 5 ros2 lifecycle get "$node" 2>/dev/null || true)"
    if [[ "$(lifecycle_state_name "$state")" == "active" ]]; then
        pass "$node is active"
    else
        fail "$node is not active (state=${state:-unavailable})"
    fi
done

section "Planner action"
actions="$(timeout 5 ros2 action list 2>/dev/null || true)"
if echo "$actions" | grep -qx /compute_path_to_pose; then
    pass "/compute_path_to_pose is available"
else
    fail "/compute_path_to_pose is missing"
fi

section "Global costmap publisher"
topic_type="$(timeout 5 ros2 topic type /global_costmap/costmap 2>/dev/null || true)"
if [[ "$topic_type" == "nav_msgs/msg/OccupancyGrid" ]]; then
    pass "/global_costmap/costmap type is nav_msgs/msg/OccupancyGrid"
else
    fail "/global_costmap/costmap has unexpected or missing type: ${topic_type:-none}"
fi

timeout 5 ros2 topic info -v /global_costmap/costmap || true
costmap_sample=/tmp/nav2_global_costmap_sample.txt
: > "$costmap_sample"
if timeout 8 ros2 topic echo /global_costmap/costmap --once \
    --qos-reliability reliable \
    --qos-durability transient_local >"$costmap_sample" 2>&1; then
    if grep -Eq 'width: [1-9][0-9]*' "$costmap_sample" &&
       grep -Eq 'height: [1-9][0-9]*' "$costmap_sample"; then
        pass "a non-empty global costmap message was received"
    else
        fail "a global costmap message arrived, but its dimensions look empty"
        sed -n '1,80p' "$costmap_sample"
    fi
else
    fail "no global costmap message was received"
    cat "$costmap_sample"
fi

section "Bridge reachability consumer"
bridge_status="$(
    timeout 5 ros2 topic echo /ros2_bridge/status --once \
        --qos-reliability reliable \
        --qos-durability transient_local 2>/dev/null || true
)"
echo "$bridge_status"
if echo "$bridge_status" | grep -Eq '\"legacy_global_costmap_received\"[[:space:]]*:[[:space:]]*true'; then
    pass "ros2_bridge received the global costmap"
else
    fail "ros2_bridge has not confirmed global costmap reception"
fi
if echo "$bridge_status" | grep -Eq '\"legacy_global_costmap_valid\"[[:space:]]*:[[:space:]]*true'; then
    pass "ros2_bridge considers the global costmap valid"
else
    fail "ros2_bridge considers the global costmap unavailable or malformed"
fi
if echo "$bridge_status" | grep -Eq '\"legacy_planner_action_ready\"[[:space:]]*:[[:space:]]*true'; then
    pass "ros2_bridge sees the planner action server"
else
    fail "ros2_bridge does not see the planner action server"
fi

section "Result"
if (( failures == 0 )); then
    echo "NAV2 REACHABILITY HEALTHY"
    exit 0
fi

echo "NAV2 REACHABILITY UNHEALTHY: ${failures} check(s) failed"
exit 1
