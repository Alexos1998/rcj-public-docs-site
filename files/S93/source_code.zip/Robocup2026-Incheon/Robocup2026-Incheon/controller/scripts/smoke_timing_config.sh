#!/usr/bin/env bash
# Validate the timing single-source-of-truth (scripts/race_timing_lib.sh):
#   - profile resolution (low/balanced/high)
#   - RACE_RATE_SCALE scaling + clamps
#   - explicit RACE_*_HZ overrides win over profile/scale
#   - runtime YAML is well-formed and carries use_sim_time + frequencies
# Does NOT require ROS. Each case runs in a subshell so env does not leak.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIB="${SCRIPT_DIR}/race_timing_lib.sh"

pass=0
fail=0

check() {
    # check "label" "actual" "expected"
    if [[ "$2" == "$3" ]]; then
        echo "[PASS] $1 ($2)"
        pass=$((pass + 1))
    else
        echo "[FAIL] $1: got '$2' expected '$3'"
        fail=$((fail + 1))
    fi
}

# resolve_var PROFILE SCALE VAR [EXTRA_ENV_ASSIGNMENTS...] -> echoes resolved VAR
resolve_var() {
    local profile="$1" scale="$2" var="$3"; shift 3
    (
        set -e
        for kv in "$@"; do export "$kv"; done
        export RACE_TIMING_PROFILE="$profile"
        export RACE_RATE_SCALE="$scale"
        source "$LIB"
        race_timing_resolve >/dev/null
        printf '%s' "${!var}"
    )
}

echo "== profile defaults (balanced) =="
check "balanced scan" "$(resolve_var balanced 1.0 RACE_SCAN_HZ)" "62.5"
check "balanced state" "$(resolve_var balanced 1.0 RACE_STATE_HZ)" "62.5"
check "balanced slam" "$(resolve_var balanced 1.0 RACE_SLAM_MAX_HZ)" "30"
check "balanced nav_ctrl" "$(resolve_var balanced 1.0 RACE_NAV_CONTROLLER_HZ)" "10"

echo "== profile low =="
check "low scan" "$(resolve_var low 1.0 RACE_SCAN_HZ)" "30"
check "low slam" "$(resolve_var low 1.0 RACE_SLAM_MAX_HZ)" "15"

echo "== profile high =="
check "high scan" "$(resolve_var high 1.0 RACE_SCAN_HZ)" "62.5"
check "high slam" "$(resolve_var high 1.0 RACE_SLAM_MAX_HZ)" "50"

echo "== rate scale + clamps =="
check "balanced scan x2" "$(resolve_var balanced 2.0 RACE_SCAN_HZ)" "125"

echo "== explicit override wins =="
check "explicit scan beats profile/scale" \
    "$(resolve_var balanced 2.0 RACE_SCAN_HZ RACE_SCAN_HZ=7)" "7"
check "explicit camera beats profile" \
    "$(resolve_var low 1.0 RACE_CAMERA_HZ RACE_CAMERA_HZ=30)" "30"

echo "== use_sim_time bool mapping =="
check "sim_time 0 -> false" \
    "$(resolve_var balanced 1.0 RACE_USE_SIM_TIME_BOOL RACE_USE_SIM_TIME=0)" "false"
check "sim_time 1 -> true" \
    "$(resolve_var balanced 1.0 RACE_USE_SIM_TIME_BOOL RACE_USE_SIM_TIME=1)" "true"

echo "== runtime YAML generation (wall-time) =="
yaml_wall="$(mktemp)"
(
    set -e
    export RACE_TIMING_PROFILE=balanced RACE_RATE_SCALE=1.0 RACE_USE_SIM_TIME=0
    source "$LIB"
    race_timing_resolve >/dev/null
    race_timing_write_yaml "$yaml_wall"
)
if python3 - "$yaml_wall" <<'PY'
import sys, yaml
d = yaml.safe_load(open(sys.argv[1]))
assert d["/**"]["ros__parameters"]["use_sim_time"] is False, "wall use_sim_time"
b = d["ros2_bridge"]["ros__parameters"]
assert b["publish_clock"] is False, "wall publish_clock"
assert b["use_webots_time_for_stamps"] is False, "wall stamps"
assert abs(b["scan_time_s"] - 0.016) < 1e-3, "scan_time_s ~ 1/62.5"
assert all("filter_node" not in str(k) for k in d.keys()), "no legacy filter runtime section"
assert d["controller_server"]["ros__parameters"]["controller_frequency"] == 10.0, "ctrl freq"
assert d["local_costmap"]["local_costmap"]["ros__parameters"]["update_frequency"] == 10.0, "lcm upd"
assert abs(d["slam_toolbox"]["ros__parameters"]["minimum_time_interval"] - (1.0 / 30.0)) < 1e-3, "slam interval ~ 1/30"
print("ok")
PY
then
    echo "[PASS] wall-time YAML well-formed"; pass=$((pass + 1))
else
    echo "[FAIL] wall-time YAML invalid"; fail=$((fail + 1))
fi
rm -f "$yaml_wall"

echo "== runtime YAML generation (sim-time) =="
yaml_sim="$(mktemp)"
(
    set -e
    export RACE_TIMING_PROFILE=balanced RACE_RATE_SCALE=1.0 RACE_USE_SIM_TIME=1
    source "$LIB"
    race_timing_resolve >/dev/null
    race_timing_write_yaml "$yaml_sim"
)
if python3 - "$yaml_sim" <<'PY'
import sys, yaml
d = yaml.safe_load(open(sys.argv[1]))
assert d["/**"]["ros__parameters"]["use_sim_time"] is True, "sim use_sim_time"
b = d["ros2_bridge"]["ros__parameters"]
assert b["publish_clock"] is True, "sim publish_clock"
assert b["use_webots_time_for_stamps"] is True, "sim stamps"
print("ok")
PY
then
    echo "[PASS] sim-time YAML well-formed"; pass=$((pass + 1))
else
    echo "[FAIL] sim-time YAML invalid"; fail=$((fail + 1))
fi
rm -f "$yaml_sim"

echo
echo "timing smoke: ${pass} passed, ${fail} failed"
[[ "$fail" -eq 0 ]]
