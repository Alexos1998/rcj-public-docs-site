#include "sensors/LidarUtils.hpp"

#include <algorithm>
#include <cmath>
#include <limits>

namespace sensors {

std::vector<LidarSectorInfo> computeLidarSectors(
   const std::vector<float>& scan,
   int sector_count)
{
   std::vector<LidarSectorInfo> sectors;
   if (scan.empty() || sector_count <= 0) {
      return sectors;
   }

   sectors.resize(static_cast<std::size_t>(sector_count));
   for (int s = 0; s < sector_count; ++s) {
      sectors[static_cast<std::size_t>(s)].index = s;
      sectors[static_cast<std::size_t>(s)].center_angle_rad =
         -M_PI + (2.0 * M_PI) *
         (static_cast<double>(s) + 0.5) /
         static_cast<double>(sector_count);
   }

   const int n = static_cast<int>(scan.size());
   for (int i = 0; i < n; ++i) {
      const double angle =
         -M_PI + (2.0 * M_PI * static_cast<double>(i) / static_cast<double>(n));

      int sector_index = static_cast<int>(
         std::floor(
            (angle + M_PI) /
            (2.0 * M_PI) *
            static_cast<double>(sector_count)
         )
      );

      if (sector_index < 0) {
         sector_index = 0;
      }
      if (sector_index >= sector_count) {
         sector_index = sector_count - 1;
      }

      const double r = static_cast<double>(scan[static_cast<std::size_t>(i)]);
      if (std::isfinite(r) && r > 0.0) {
         auto& sector = sectors[static_cast<std::size_t>(sector_index)];
         sector.min_range_m = std::min(sector.min_range_m, r);
      }
   }

   return sectors;
}

LidarVelocityGuardResult applyLidarVelocityGuard(
   double raw_v,
   double raw_w,
   const std::vector<float>& scan,
   const LidarVelocityGuardConfig& cfg)
{
   LidarVelocityGuardResult result;
   result.v = raw_v;
   result.w = raw_w;

   if (!cfg.enabled || scan.empty()) {
      return result;
   }

   const auto sectors = computeLidarSectors(scan, cfg.sectors);
   double worst_closing = 0.0;
   LidarSectorInfo worst_sector;

   for (const auto& sector : sectors) {
      if (!std::isfinite(sector.min_range_m)) {
         continue;
      }

      const double closing_speed = raw_v * std::cos(sector.center_angle_rad);
      if (closing_speed <= cfg.min_closing_speed_mps) {
         continue;
      }

      if (sector.min_range_m < cfg.hard_stop_m) {
         result.v = 0.0;
         result.active = true;
         result.linear_clamped = true;
         result.reason = "linear_hard_stop";
         result.sector_index = sector.index;
         result.sector_angle_rad = sector.center_angle_rad;
         result.sector_min_range_m = sector.min_range_m;
         result.closing_speed_mps = closing_speed;
         return result;
      }

      if (sector.min_range_m < cfg.slow_down_m) {
         if (closing_speed > worst_closing) {
            worst_closing = closing_speed;
            worst_sector = sector;
         }
      }
   }

   if (worst_closing > cfg.min_closing_speed_mps) {
      if (result.v > 0.0) {
         result.v = std::min(result.v, cfg.slow_linear_mps);
      } else if (result.v < 0.0) {
         result.v = std::max(result.v, -cfg.slow_linear_mps);
      }

      result.active = true;
      result.linear_clamped = true;
      result.reason = "linear_slow_down";
      result.sector_index = worst_sector.index;
      result.sector_angle_rad = worst_sector.center_angle_rad;
      result.sector_min_range_m = worst_sector.min_range_m;
      result.closing_speed_mps = worst_closing;
   }

   if (cfg.guard_rotation && std::fabs(raw_w) > 0.05) {
      double closest_for_rotation = std::numeric_limits<double>::infinity();
      int closest_sector_index = -1;
      double closest_sector_angle = 0.0;

      for (const auto& sector : sectors) {
         if (!std::isfinite(sector.min_range_m)) {
            continue;
         }

         if (sector.min_range_m < closest_for_rotation) {
            closest_for_rotation = sector.min_range_m;
            closest_sector_index = sector.index;
            closest_sector_angle = sector.center_angle_rad;
         }
      }

      if (closest_for_rotation < cfg.rotation_hard_stop_m) {
         result.w = 0.0;
         result.active = true;
         result.angular_clamped = true;
         result.reason = result.reason == "none"
            ? "angular_hard_stop"
            : result.reason + "+angular_hard_stop";
         result.sector_index = closest_sector_index;
         result.sector_angle_rad = closest_sector_angle;
         result.sector_min_range_m = closest_for_rotation;
      } else if (closest_for_rotation < cfg.rotation_slow_down_m) {
         if (result.w > 0.0) {
            result.w = std::min(result.w, cfg.slow_angular_rad_s);
         } else {
            result.w = std::max(result.w, -cfg.slow_angular_rad_s);
         }

         result.active = true;
         result.angular_clamped = true;
         result.reason = result.reason == "none"
            ? "angular_slow_down"
            : result.reason + "+angular_slow_down";
         result.sector_index = closest_sector_index;
         result.sector_angle_rad = closest_sector_angle;
         result.sector_min_range_m = closest_for_rotation;
      }
   }

   if (cfg.guard_side_clearance) {
      const double left_min =
         lidarSectorMinRange(scan, M_PI / 2.0, M_PI / 6.0);
      const double right_min =
         lidarSectorMinRange(scan, -M_PI / 2.0, M_PI / 6.0);
      const double front_left_min =
         lidarSectorMinRange(scan, M_PI / 4.0, M_PI / 8.0);
      const double front_right_min =
         lidarSectorMinRange(scan, -M_PI / 4.0, M_PI / 8.0);

      const double left_clearance = std::min(left_min, front_left_min);
      const double right_clearance = std::min(right_min, front_right_min);

      const bool left_hard =
         std::isfinite(left_clearance) &&
         left_clearance < cfg.side_hard_stop_m;

      const bool right_hard =
         std::isfinite(right_clearance) &&
         right_clearance < cfg.side_hard_stop_m;

      const bool left_slow =
         std::isfinite(left_clearance) &&
         left_clearance < cfg.side_slow_down_m;

      const bool right_slow =
         std::isfinite(right_clearance) &&
         right_clearance < cfg.side_slow_down_m;

      if (left_hard || right_hard) {
         if (result.v > 0.0) {
            result.v = std::min(result.v, cfg.side_slow_linear_mps);
         } else if (result.v < 0.0) {
            result.v = std::max(result.v, -cfg.side_slow_linear_mps);
         }

         if (left_hard && result.w > 0.0) {
            result.w = 0.0;
         }

         if (right_hard && result.w < 0.0) {
            result.w = 0.0;
         }

         result.active = true;
         result.linear_clamped = true;
         result.angular_clamped = true;
         result.reason = result.reason == "none"
            ? "side_hard_stop"
            : result.reason + "+side_hard_stop";

         if (left_hard && left_clearance <= right_clearance) {
            result.sector_angle_rad = M_PI / 2.0;
            result.sector_min_range_m = left_clearance;
         } else {
            result.sector_angle_rad = -M_PI / 2.0;
            result.sector_min_range_m = right_clearance;
         }

      } else if (left_slow || right_slow) {
         if (result.v > 0.0) {
            result.v = std::min(result.v, cfg.side_slow_linear_mps);
         } else if (result.v < 0.0) {
            result.v = std::max(result.v, -cfg.side_slow_linear_mps);
         }

         if (left_slow && result.w > 0.0) {
            result.w = std::min(result.w, cfg.side_slow_angular_rad_s);
         }

         if (right_slow && result.w < 0.0) {
            result.w = std::max(result.w, -cfg.side_slow_angular_rad_s);
         }

         result.active = true;
         result.linear_clamped = true;
         result.angular_clamped = true;
         result.reason = result.reason == "none"
            ? "side_slow_down"
            : result.reason + "+side_slow_down";

         if (left_slow && left_clearance <= right_clearance) {
            result.sector_angle_rad = M_PI / 2.0;
            result.sector_min_range_m = left_clearance;
         } else {
            result.sector_angle_rad = -M_PI / 2.0;
            result.sector_min_range_m = right_clearance;
         }
      }
   }

   return result;
}

double lidarSectorMinRange(
   const std::vector<float>& scan,
   double center_angle_rad,
   double half_width_rad)
{
   if (scan.empty()) {
      return std::numeric_limits<double>::infinity();
   }

   const int n = static_cast<int>(scan.size());
   double best = std::numeric_limits<double>::infinity();

   for (int i = 0; i < n; ++i) {
      const double angle =
         -M_PI + (2.0 * M_PI * static_cast<double>(i) / static_cast<double>(n));
      const double delta = std::remainder(angle - center_angle_rad, 2.0 * M_PI);
      if (std::fabs(delta) > half_width_rad) {
         continue;
      }

      const double r = static_cast<double>(scan[i]);
      if (std::isfinite(r) && r > 0.0) {
         best = std::min(best, r);
      }
   }

   return best;
}

} // namespace sensors
