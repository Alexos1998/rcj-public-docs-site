#include "sensors/FloorColorClassifier.hpp"
#include "utils/MathUtils.hpp"
#include <algorithm>
#include <cmath>
#include <array>
#include <limits>

namespace {
constexpr char kBlackHoleBrakeColorClass[] = "BLACK_HOLE_BORDER";

struct ColorPrototype {
   const char* color_class;
   int r;
   int g;
   int b;
};

static double rgbDistance(int r1, int g1, int b1, int r2, int g2, int b2) {
   const double dr = static_cast<double>(r1 - r2);
   const double dg = static_cast<double>(g1 - g2);
   const double db = static_cast<double>(b1 - b2);
   return std::sqrt(dr * dr + dg * dg + db * db);
}

} // namespace

FloorColorSample classifyFloorColorRgb(int r, int g, int b) {
   static constexpr std::array<ColorPrototype, 11> kPrototypes{{
      {"BLACK_HOLE_BORDER",   29,   29,   29},
      {"BLACK_HOLE_BORDER",  40,  40,  40},
      {"SILVER_CHECKPOINT", 247, 247, 247},
      {"BROWN_SWAMP",       204, 170,  97},
      {"BLUE_AREA_1_2",      61,  61, 250},
      {"YELLOW_AREA_1_3",   251, 251,  61},
      {"GREEN_AREA_1_4",      32, 247,  32},
      {"PURPLE_AREA_2_3",   139,  61, 221},
      {"ORANGE_AREA_2_4",   251, 221,  61},
      {"RED_AREA_3_4",      251,  61,  61},
      {"NORMAL",            227, 227, 227}
   }};

   double best_dist = std::numeric_limits<double>::infinity();
   double second_dist = std::numeric_limits<double>::infinity();
   const ColorPrototype* best = nullptr;

   for (const auto& proto : kPrototypes) {
      const double d = rgbDistance(r, g, b, proto.r, proto.g, proto.b);
      if (d < best_dist) {
         second_dist = best_dist;
         best_dist = d;
         best = &proto;
      } else if (d < second_dist) {
         second_dist = d;
      }
   }

   FloorColorSample out;
   out.r = r;
   out.g = g;
   out.b = b;

   const int darkest_channel = std::min({r, g, b});
   const int brightest_channel = std::max({r, g, b});
   const bool dark_neutral_surface =
      brightest_channel <= 100 &&
      brightest_channel - darkest_channel <= 24;

   if (dark_neutral_surface) {
      out.color_class = kBlackHoleBrakeColorClass;
      out.confidence = utils::clampd(
         0.90 + (100.0 - static_cast<double>(brightest_channel)) / 600.0,
         0.90,
         1.0
      );
      return out;
   }

   if (best == nullptr) {
      return out;
   }

   constexpr double kMaxRgbDistance = 441.67295593;
   const double distance_conf =
      utils::clampd(1.0 - (best_dist / kMaxRgbDistance), 0.0, 1.0);

   double margin_conf = 1.0;
   if (std::isfinite(second_dist) && second_dist > 1e-6) {
      margin_conf = utils::clampd((second_dist - best_dist) / second_dist, 0.0, 1.0);
   }

   out.confidence = utils::clampd(
      0.70 * distance_conf + 0.30 * margin_conf,
      0.0,
      1.0
   );

   if (out.confidence < 0.35) {
      out.color_class = "UNKNOWN";
   } else {
      const std::string best_class = best->color_class;
      if (
         best_class == kBlackHoleBrakeColorClass &&
         out.confidence < 0.90
      ) {
         out.color_class = "UNKNOWN";
      } else {
         out.color_class = best_class;
      }
   }

   return out;
}

FloorColorSample readColourSensorClassification(webots::Camera* camera) {
   FloorColorSample out;
   if (camera == nullptr) {
      return out;
   }

   const unsigned char* image = camera->getImage();
   if (image == nullptr) {
      return out;
   }

   const int width = camera->getWidth();
   if (width <= 0) {
      return out;
   }

   const int r = camera->imageGetRed(image, width, 0, 0);
   const int g = camera->imageGetGreen(image, width, 0, 0);
   const int b = camera->imageGetBlue(image, width, 0, 0);
   out = classifyFloorColorRgb(r, g, b);
   return out;
}

bool isStrongBlackHoleBrakeSample(const FloorColorSample& sample, double min_confidence) {
   return sample.color_class == kBlackHoleBrakeColorClass &&
      sample.confidence >= min_confidence;
}
