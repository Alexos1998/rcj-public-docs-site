#include "safety/BlackHoleSafety.hpp"

namespace safety {

const char* blackHoleSafetyStateName(BlackHoleSafetyState state) {
   switch (state) {
      case BlackHoleSafetyState::Idle:
         return "idle";
      case BlackHoleSafetyState::BrakeHold:
         return "brake_hold";
      case BlackHoleSafetyState::ReverseEscape:
         return "reverse_escape";
   }
   return "unknown";
}

} // namespace safety
