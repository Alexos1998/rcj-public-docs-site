#include "diagnostics/StartupSensorInfo.hpp"
#include "utils/Diag.hpp"
#include "utils/MathUtils.hpp"
#include <cmath>
#include <sstream>

namespace {

double rad2deg(double rad) {
   return rad * 180.0 / M_PI;
}

double hzFromSamplingPeriodMs(int period_ms) {
   return period_ms > 0 ? 1000.0 / static_cast<double>(period_ms) : 0.0;
}

const char* enabledText(int period_ms) {
   return period_ms > 0 ? "enabled" : "disabled";
}

std::string finiteOrText(double value) {
   if (std::isnan(value)) return "nan";
   if (std::isinf(value)) return value > 0.0 ? "inf" : "-inf";

   std::ostringstream ss;
   ss << std::fixed << std::setprecision(6) << value;
   return ss.str();
}

} // namespace

void printStartupSensorInfo(
   int timeStep,
   double dt,
   double wheel_radius,
   double axle_length,
   double max_motor_speed,
   double max_linear_vel,
   double max_angular_vel,
   webots::Motor* wheel_left,
   webots::Motor* wheel_right,
   webots::PositionSensor* left_encoder,
   webots::PositionSensor* right_encoder,
   webots::Lidar* lidar,
   int lidar_h,
   webots::GPS* gps,
   webots::InertialUnit* inertial_unit,
   webots::Camera* came,
   webots::Camera* camd,
   webots::Camera* color_sensor,
   double state_period_s,
   double scan_period_s,
   double color_period_s,
   double camera_period_s
) {
   std::ostringstream oss;
   oss << std::fixed << std::setprecision(6);

   oss << "\n========== WEBOTS STARTUP SENSOR INFO ==========" << "\n";
   oss << "[Robot]" << "\n";
   oss << "  basicTimeStep_ms=" << timeStep << "\n";
   oss << "  dt_s=" << dt << "\n";
   oss << "  controller_update_hz=" << hzFromSamplingPeriodMs(timeStep) << "\n";

   oss << "\n[Differential Drive]" << "\n";
   oss << "  wheel_radius_m=" << wheel_radius << "\n";
   oss << "  axle_length_m=" << axle_length << "\n";
   oss << "  max_motor_speed_rad_s_controller_const=" << max_motor_speed << "\n";
   oss << "  max_linear_vel_m_s_controller_const=" << max_linear_vel << "\n";
   oss << "  max_angular_vel_rad_s_controller_const=" << max_angular_vel << "\n";

   auto logMotor = [&](const std::string& label,
                       const std::string& webots_device_name,
                       webots::Motor* motor) {
      oss << "\n[Motor: " << label << "]" << "\n";
      oss << "  webots_device_name=" << webots_device_name << "\n";
      oss << "  ptr=" << motor << "\n";
      if (!motor) {
         oss << "  status=missing" << "\n";
         return;
      }
      oss << "  status=ok" << "\n";
      oss << "  target_position_rad=" << finiteOrText(motor->getTargetPosition()) << "\n";
      oss << "  commanded_velocity_rad_s=" << motor->getVelocity() << "\n";
      oss << "  max_velocity_rad_s_api=" << motor->getMaxVelocity() << "\n";
      oss << "  max_linear_velocity_m_s_from_api=" << motor->getMaxVelocity() * wheel_radius << "\n";
      oss << "  max_linear_velocity_m_s_controller_const=" << max_linear_vel << "\n";
   };

   logMotor("left", "wheel1 motor", wheel_left);
   logMotor("right", "wheel2 motor", wheel_right);

   auto logEncoder = [&](const std::string& label,
                         webots::PositionSensor* encoder) {
      oss << "\n[PositionSensor: " << label << "]" << "\n";
      oss << "  ptr=" << encoder << "\n";
      if (!encoder) {
         oss << "  status=missing" << "\n";
         return;
      }
      const int sp = encoder->getSamplingPeriod();
      oss << "  status=" << enabledText(sp) << "\n";
      oss << "  sampling_period_ms=" << sp << "\n";
      oss << "  sampling_rate_hz=" << hzFromSamplingPeriodMs(sp) << "\n";
      oss << "  value_rad=" << encoder->getValue() << "\n";
      oss << "  resolution_rad_from_proto=0.006280" << "\n";
      oss << "  note=wheel_encoder_rotational_position" << "\n";
   };

   logEncoder("left / wheel1 sensor", left_encoder);
   logEncoder("right / wheel2 sensor", right_encoder);

   oss << "\n[Lidar]" << "\n";
   oss << "  webots_device_name=lidar" << "\n";
   oss << "  ptr=" << lidar << "\n";
   if (lidar) {
      const int sp = lidar->getSamplingPeriod();
      const int hres = lidar->getHorizontalResolution();
      const int layers = lidar->getNumberOfLayers();
      const double fov = lidar->getFov();
      oss << "  status=" << enabledText(sp) << "\n";
      oss << "  sampling_period_ms=" << sp << "\n";
      oss << "  scan_update_hz=" << hzFromSamplingPeriodMs(sp) << "\n";
      oss << "  horizontal_resolution=" << hres << "\n";
      oss << "  number_of_layers=" << layers << "\n";
      oss << "  total_range_values=" << hres * layers << "\n";
      oss << "  range_image_bytes=" << static_cast<std::size_t>(hres) * static_cast<std::size_t>(layers) * sizeof(float) << "\n";
      oss << "  fov_rad=" << fov << "\n";
      oss << "  fov_deg=" << rad2deg(fov) << "\n";
      if (hres > 0) {
         oss << "  angle_increment_rad_bin_convention=" << fov / static_cast<double>(hres) << "\n";
         oss << "  angle_increment_deg_bin_convention=" << rad2deg(fov / static_cast<double>(hres)) << "\n";
      }
      if (hres > 1) {
         oss << "  angle_increment_rad_endpoint_convention=" << fov / static_cast<double>(hres - 1) << "\n";
         oss << "  angle_increment_deg_endpoint_convention=" << rad2deg(fov / static_cast<double>(hres - 1)) << "\n";
      }
      oss << "  ros_scan_angle_min_rad=-3.141593" << "\n";
      oss << "  ros_scan_angle_max_rad=3.141593" << "\n";
      oss << "  ros_scan_index_0_direction=back" << "\n";
      oss << "  ros_scan_index_n_over_4_direction=right" << "\n";
      oss << "  ros_scan_index_n_over_2_direction=front" << "\n";
      oss << "  ros_scan_index_3n_over_4_direction=left" << "\n";
      oss << "  min_range_m=" << lidar->getMinRange() << "\n";
      oss << "  max_range_m=" << lidar->getMaxRange() << "\n";
      oss << "  rotating_frequency_hz=" << lidar->getFrequency() << "\n";
      oss << "  note_rotating_frequency=not_the_same_as_scan_update_hz_for_fixed_lidar" << "\n";
      oss << "  selected_layer_index_for_bridge=2" << "\n";
      oss << "  selected_layer_valid=" << ((2 >= 0 && 2 < layers) ? "true" : "false") << "\n";
      oss << "  bridge_layer_size=" << lidar_h << "\n";
      if (layers % 2 == 0) {
         oss << "  note_layers=even_layer_count_no_single_center_layer; middle_layers_are_" << ((layers / 2) - 1) << "_and_" << (layers / 2) << "\n";
      }
   } else {
      oss << "  status=missing" << "\n";
   }

   oss << "\n[GPS]" << "\n";
   oss << "  webots_device_name=gps" << "\n";
   oss << "  ptr=" << gps << "\n";
   if (gps) {
      const int sp = gps->getSamplingPeriod();
      oss << "  status=" << enabledText(sp) << "\n";
      oss << "  sampling_period_ms=" << sp << "\n";
      oss << "  sampling_rate_hz=" << hzFromSamplingPeriodMs(sp) << "\n";
      oss << "  accuracy_m_from_proto=0.002500" << "\n";
      const double* gps_values = gps->getValues();
      if (gps_values) {
         const double xw = gps_values[0];
         const double yw = gps_values[1];
         const double zw = gps_values[2];
         oss << "  raw_webots_xyz=(" << xw << ", " << yw << ", " << zw << ")" << "\n";
         oss << "  converted_ros_local_xyz=(" << xw << ", " << -zw << ", " << yw << ")" << "\n";
      }
      oss << "  speed_m_s=" << gps->getSpeed() << "\n";
      const double* speed_vector = gps->getSpeedVector();
      if (speed_vector) {
         const double vxw = speed_vector[0];
         const double vyw = speed_vector[1];
         const double vzw = speed_vector[2];
         oss << "  speed_vector_webots_xyz=(" << vxw << ", " << vyw << ", " << vzw << ")" << "\n";
         oss << "  speed_vector_ros_local_xyz=(" << vxw << ", " << -vzw << ", " << vyw << ")" << "\n";
      }
   } else {
      oss << "  status=missing" << "\n";
   }

   oss << "\n[IMU / InertialUnit]" << "\n";
   oss << "  webots_device_name=inertial_unit" << "\n";
   oss << "  ptr=" << inertial_unit << "\n";
   if (inertial_unit) {
      const int sp = inertial_unit->getSamplingPeriod();
      oss << "  status=" << enabledText(sp) << "\n";
      oss << "  sampling_period_ms=" << sp << "\n";
      oss << "  sampling_rate_hz=" << hzFromSamplingPeriodMs(sp) << "\n";
      const double* rpy = inertial_unit->getRollPitchYaw();
      if (rpy) {
         const double yaw_ros = utils::webotsYawToRos(rpy[2]);
         oss << "  roll_rad=" << rpy[0] << "\n";
         oss << "  pitch_rad=" << rpy[1] << "\n";
         oss << "  yaw_webots_rad=" << rpy[2] << "\n";
         oss << "  yaw_ros_rad=" << yaw_ros << "\n";
         oss << "  roll_deg=" << rad2deg(rpy[0]) << "\n";
         oss << "  pitch_deg=" << rad2deg(rpy[1]) << "\n";
         oss << "  yaw_webots_deg=" << rad2deg(rpy[2]) << "\n";
         oss << "  yaw_ros_deg=" << rad2deg(yaw_ros) << "\n";
      }
   } else {
      oss << "  status=missing" << "\n";
   }

   auto logCamera = [&](const std::string& label,
                        const std::string& webots_device_name,
                        const std::string& cpp_variable_name,
                        webots::Camera* camera) {
      oss << "\n[Camera: " << label << "]" << "\n";
      oss << "  webots_device_name=" << webots_device_name << "\n";
      oss << "  cpp_variable_name=" << cpp_variable_name << "\n";
      oss << "  ptr=" << camera << "\n";
      if (!camera) {
         oss << "  status=missing" << "\n";
         return;
      }
      const int sp = camera->getSamplingPeriod();
      const int width = camera->getWidth();
      const int height = camera->getHeight();
      const double hfov = camera->getFov();
      double vfov = 0.0;
      if (width > 0 && height > 0) {
         vfov = 2.0 * std::atan(
            std::tan(hfov * 0.5) *
            (static_cast<double>(height) / static_cast<double>(width))
         );
      }
      oss << "  status=" << enabledText(sp) << "\n";
      oss << "  sampling_period_ms=" << sp << "\n";
      oss << "  frame_rate_hz=" << hzFromSamplingPeriodMs(sp) << "\n";
      oss << "  width_px=" << width << "\n";
      oss << "  height_px=" << height << "\n";
      if (height > 0) {
         oss << "  aspect_ratio_w_over_h=" << static_cast<double>(width) / static_cast<double>(height) << "\n";
      } else {
         oss << "  aspect_ratio_w_over_h=undefined" << "\n";
      }
      oss << "  pixels=" << width * height << "\n";
      oss << "  encoding=BGRA8" << "\n";
      oss << "  bytes_per_pixel=4" << "\n";
      oss << "  frame_bytes=" << static_cast<std::size_t>(width) * static_cast<std::size_t>(height) * static_cast<std::size_t>(4) << "\n";
      oss << "  horizontal_fov_rad=" << hfov << "\n";
      oss << "  horizontal_fov_deg=" << rad2deg(hfov) << "\n";
      oss << "  vertical_fov_rad_approx=" << vfov << "\n";
      oss << "  vertical_fov_deg_approx=" << rad2deg(vfov) << "\n";
      oss << "  center_pixel_index_floor=(" << (width / 2) << ", " << (height / 2) << ")" << "\n";
      if (width > 0 && height > 0) {
         oss << "  principal_point_approx_px=(" << (static_cast<double>(width) - 1.0) * 0.5 << ", " << (static_cast<double>(height) - 1.0) * 0.5 << ")" << "\n";
      }
   };

   logCamera("left", "camera1", "came", came);
   logCamera("right", "camera2", "camd", camd);
   logCamera("color_sensor", "colour_sensor", "colorSensor", color_sensor);

   oss << "\n[Controller Publish Periods]" << "\n";
   oss << "  state_period_s=" << state_period_s << "\n";
   oss << "  state_rate_hz=" << (state_period_s > 0.0 ? 1.0 / state_period_s : 0.0) << "\n";
   oss << "  scan_period_s=" << scan_period_s << "\n";
   oss << "  scan_rate_hz=" << (scan_period_s > 0.0 ? 1.0 / scan_period_s : 0.0) << "\n";
   oss << "  color_period_s=" << color_period_s << "\n";
   oss << "  color_rate_hz=" << (color_period_s > 0.0 ? 1.0 / color_period_s : 0.0) << "\n";
   oss << "  camera_period_s=" << camera_period_s << "\n";
   oss << "  camera_rate_hz=" << (camera_period_s > 0.0 ? 1.0 / camera_period_s : 0.0) << "\n";

   oss << "\n[Bridge Protocol]" << "\n";
   oss << "  outgoing TIME|t" << "\n";
	   oss << "  outgoing IMU|roll,pitch,yaw_ros" << "\n";
	   oss << "  outgoing SCAN|ranges..." << "\n";
	   oss << "  outgoing GPS|x_ros,y_ros,z_ros" << "\n";
	   oss << "  outgoing LOC|x,y,z,yaw,vx,wz,cov_x,cov_y,cov_yaw,cov_vx,cov_wz,gps_used,gps_rejected,slip" << "\n";
	   oss << "  outgoing ODOM|x,y,yaw,vx,wz,slip (debug wheel odom)" << "\n";
	   oss << "  outgoing COLOR|class,r,g,b,confidence" << "\n";
   oss << "  outgoing CAM|name|t|width|height|fov|bgra8|hex" << "\n";
   oss << "  incoming CMD|linear_x,angular_z" << "\n";
   oss << "================================================" << "\n";

   diag::log(diag::Level::Info, oss.str());
}
