#include "vision/VisionRuntime.hpp"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <limits>
#include <set>
#include <sstream>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

namespace vision_runtime {

namespace {

constexpr double kTwoPi = 6.28318530717958647692;

struct LidarDebugRay {
    int index = -1;
    float range = std::numeric_limits<float>::quiet_NaN();
    double angle = 0.0;
    double pixel_x = 0.0;
    bool valid = false;
};

std::shared_ptr<ros2_vision::OnnxRunner> makeRunner(const std::string& path,
                                                    int width,
                                                    int height)
{
    ros2_vision::OnnxRunner::Options options;
    options.input_width = width;
    options.input_height = height;
    return std::make_shared<ros2_vision::OnnxRunner>(path, options);
}

std::string sanitizeFileToken(const std::string& input)
{
    std::string out;
    out.reserve(input.size());
    for (char c : input) {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
            (c >= '0' && c <= '9') || c == '_' || c == '-') {
            out.push_back(c);
        } else {
            out.push_back('_');
        }
    }
    return out.empty() ? std::string("none") : out;
}

std::string defaultClassificationImageDir()
{
    if (const char* raw = std::getenv("VISION_CLASSIFICATION_IMAGE_DIR")) {
        if (*raw != '\0') {
            return std::string(raw);
        }
    }
    if (const char* unique_log = std::getenv("UNIQUE_LOG_PATH")) {
        if (*unique_log != '\0') {
            return (std::filesystem::path(unique_log).parent_path() / "images").string();
        }
    }
    return "/tmp/controller-logs/latest/images";
}

bool lidarFullCircle(int n, double angle_increment)
{
    return n > 0 && angle_increment > 0.0 &&
           std::abs(static_cast<double>(n) * angle_increment - kTwoPi) < 0.05 * kTwoPi;
}

double pixelToRobotAngle(double x, int image_width, double hfov_rad, double yaw_offset)
{
    const double fx = image_width / (2.0 * std::tan(hfov_rad / 2.0));
    const double cx = (image_width - 1) * 0.5;
    return yaw_offset + std::atan((x - cx) / fx);
}

int angleToScanIndex(double theta, int n, double angle_min, double angle_increment)
{
    if (n <= 0 || !(angle_increment > 0.0) || !std::isfinite(theta)) {
        return -1;
    }
    long idx = std::lround((theta - angle_min) / angle_increment);
    if (idx >= 0 && idx < n) {
        return static_cast<int>(idx);
    }
    if (lidarFullCircle(n, angle_increment)) {
        idx %= n;
        if (idx < 0) {
            idx += n;
        }
        return static_cast<int>(idx);
    }
    return -1;
}

double scanIndexToPixel(int index, const ros2_vision::VisionFrame& frame)
{
    if (frame.bgr.cols <= 1 || !(frame.camera_hfov_rad > 0.0f)) {
        return std::numeric_limits<double>::quiet_NaN();
    }
    const double theta = frame.lidar_angle_min +
        static_cast<double>(index) * frame.lidar_angle_increment;
    const double rel = theta - frame.camera_yaw_offset_rad;
    const double fx = frame.bgr.cols / (2.0 * std::tan(frame.camera_hfov_rad / 2.0));
    const double cx = (frame.bgr.cols - 1) * 0.5;
    return cx + fx * std::tan(rel);
}

std::vector<LidarDebugRay> selectedLidarRays(const ros2_vision::VisionFrame& frame,
                                             float xmin,
                                             float xmax,
                                             int extra)
{
    std::vector<LidarDebugRay> out;
    const int n = static_cast<int>(frame.scan.size());
    if (n <= 0 || frame.bgr.cols <= 1 || !(frame.lidar_angle_increment > 0.0f) ||
        !(frame.camera_hfov_rad > 0.0f)) {
        return out;
    }

    xmin = std::max(0.0f, std::min(xmin, static_cast<float>(frame.bgr.cols - 1)));
    xmax = std::max(0.0f, std::min(xmax, static_cast<float>(frame.bgr.cols - 1)));
    if (xmax < xmin) {
        std::swap(xmin, xmax);
    }

    const int i0 = angleToScanIndex(
        pixelToRobotAngle(xmin, frame.bgr.cols, frame.camera_hfov_rad, frame.camera_yaw_offset_rad),
        n, frame.lidar_angle_min, frame.lidar_angle_increment);
    const int i1 = angleToScanIndex(
        pixelToRobotAngle(xmax, frame.bgr.cols, frame.camera_hfov_rad, frame.camera_yaw_offset_rad),
        n, frame.lidar_angle_min, frame.lidar_angle_increment);
    if (i0 < 0 && i1 < 0) {
        return out;
    }

    const bool full_circle = lidarFullCircle(n, frame.lidar_angle_increment);
    extra = std::max(0, extra);
    std::set<int> indices;
    auto add_index = [&](int idx) {
        if (full_circle) {
            idx %= n;
            if (idx < 0) {
                idx += n;
            }
        } else if (idx < 0 || idx >= n) {
            return;
        }
        indices.insert(idx);
    };

    if (i0 >= 0 && i1 >= 0) {
        if (full_circle) {
            const int forward = (i1 - i0 + n) % n;
            const int backward = (i0 - i1 + n) % n;
            const int start = (forward <= backward) ? i0 : i1;
            const int span = std::min(forward, backward);
            for (int d = -extra; d <= span + extra; ++d) {
                add_index(start + d);
            }
        } else {
            for (int idx = std::min(i0, i1) - extra; idx <= std::max(i0, i1) + extra; ++idx) {
                add_index(idx);
            }
        }
    } else {
        const int center = i0 >= 0 ? i0 : i1;
        for (int d = -extra; d <= extra; ++d) {
            add_index(center + d);
        }
    }

    out.reserve(indices.size());
    for (int idx : indices) {
        const float r = frame.scan[static_cast<std::size_t>(idx)];
        LidarDebugRay ray;
        ray.index = idx;
        ray.range = r;
        ray.angle = frame.lidar_angle_min + static_cast<double>(idx) * frame.lidar_angle_increment;
        ray.pixel_x = scanIndexToPixel(idx, frame);
        ray.valid = std::isfinite(r) && r >= frame.lidar_range_min && r <= frame.lidar_range_max;
        out.push_back(ray);
    }
    return out;
}

}  // namespace

VisionRuntime::VisionRuntime(VisionRuntimeConfig config)
    : config_(std::move(config))
{
    // The target detector loads its RF model from the pipeline config. Wire the
    // runtime-level paths into it so callers only set them in one place.
    config_.pipeline.target_detector.rf_model_path = config_.target_mask_rf_model;
    config_.pipeline.target_detector.rf_feature_config_path =
        config_.target_mask_feature_config;
    config_.pipeline.min_mask_area_px = config_.pipeline.target_detector.min_mask_area_px;

    if (config_.event_logger) {
        config_.pipeline.event_logger = config_.event_logger;
        std::ostringstream oss;
        oss << "ROBOT_EVENT node=vision_runtime event=config"
            << " fused_object_model=" << (config_.pipeline.use_fused_object_model ? "true" : "false")
            << " use_bbox_gate=" << (config_.pipeline.use_bbox_gate ? "true" : "false")
            << " target_bbox_gate=(" << config_.pipeline.target_bbox_gate_min_area_px
            << "," << config_.pipeline.target_bbox_gate_min_width_px
            << "," << config_.pipeline.target_bbox_gate_min_height_px << ")"
            << " victim_bbox_gate=(" << config_.pipeline.victim_bbox_gate_min_area_px
            << "," << config_.pipeline.victim_bbox_gate_min_width_px
            << "," << config_.pipeline.victim_bbox_gate_min_height_px << ")"
            << " target_lidar_gate="
            << (config_.pipeline.use_target_lidar_distance_gate ? "true" : "false")
            << " victim_lidar_gate="
            << (config_.pipeline.use_victim_lidar_distance_gate ? "true" : "false")
            << " valid_detection_distance_m=" << config_.pipeline.valid_detection_distance_m
            << " reject_fake_victims=" << (config_.pipeline.reject_fake_victims ? "true" : "false")
            << " fake_min_confidence=" << config_.pipeline.fake_min_confidence
            << " object_presence_model=" << config_.object_presence_model
            << " target_bbox_model=" << config_.target_bbox_model
            << " victim_cls_model=" << config_.victim_cls_model;
        config_.event_logger(oss.str());
    }
    if (config_.debug_image_dir.empty()) {
        config_.debug_image_dir = defaultClassificationImageDir();
    }
    if (config_.save_classification_images || config_.save_rejected_images) {
        std::error_code ec;
        std::filesystem::create_directories(config_.debug_image_dir, ec);
        if (config_.event_logger) {
            std::ostringstream oss;
            oss << "ROBOT_EVENT node=vision_runtime event=classification_image_dir_"
                << (ec ? "failed" : "ready")
                << " path=" << config_.debug_image_dir;
            if (ec) {
                oss << " error=" << ec.message();
            }
            config_.event_logger(oss.str());
        }
        config_.pipeline.debug_image_logger = [this](const ros2_vision::VisionFrame& frame,
                                                     const ros2_vision::VisionDebugImage& debug) {
            this->saveVisionDebugImage(frame, debug);
        };
    }

    auto presence_runner =
        makeRunner(config_.presence_model, config_.presence_input_width, config_.presence_input_height);
    auto type_runner =
        makeRunner(config_.type_model, config_.type_input_width, config_.type_input_height);
    auto victim_bbox_runner = makeRunner(
        config_.victim_bbox_model, config_.victim_bbox_input_width, config_.victim_bbox_input_height);
    auto target_bbox_runner = makeRunner(
        config_.target_bbox_model, config_.target_bbox_input_width, config_.target_bbox_input_height);
    auto victim_cls_runner = makeRunner(
        config_.victim_cls_model, config_.victim_cls_input_width, config_.victim_cls_input_height);

    // Fused none/target/victim model: loaded only when enabled, replacing the
    // presence + object_type chain with a single inference.
    if (config_.pipeline.use_fused_object_model) {
        config_.pipeline.object_presence_runner = makeRunner(
            config_.object_presence_model,
            config_.object_presence_input_width,
            config_.object_presence_input_height);
    }

    pipeline_ = std::make_unique<ros2_vision::LarcVisionPipeline>(
        presence_runner, type_runner, victim_bbox_runner, target_bbox_runner, victim_cls_runner,
        config_.pipeline);
}

bool VisionRuntime::ready() const
{
    return pipeline_ && pipeline_->targetUsesRandomForest();
}

const std::string& VisionRuntime::targetLoadError() const
{
    static const std::string kNone;
    return pipeline_ ? pipeline_->targetLoadError() : kNone;
}

std::optional<ros2_vision::VisionDetection> VisionRuntime::process(
    int width,
    int height,
    const unsigned char* bgra,
    const std::vector<float>& scan,
    const VisionFrameMeta& meta,
    std::string& reject_reason)
{
    if (!pipeline_ || bgra == nullptr || width <= 0 || height <= 0) {
        reject_reason = "empty_frame";
        return std::nullopt;
    }

    ros2_vision::VisionFrame frame;
    frame.seq = meta.seq;
    frame.stamp_s = meta.stamp_s;
    frame.camera_id = meta.camera_id;
    frame.camera_name = ros2_vision::cameraName(meta.camera_id);

    // Webots delivers BGRA8; convert to BGR8 exactly like the old TCP path
    // (tcp_frame_server.cpp COLOR_BGRA2BGR). clone() so we own the buffer.
    cv::Mat bgra_view(height, width, CV_8UC4, const_cast<unsigned char*>(bgra));
    cv::cvtColor(bgra_view, frame.bgr, cv::COLOR_BGRA2BGR);

    frame.scan = scan;
    frame.lidar_angle_min = meta.lidar_angle_min;
    frame.lidar_angle_increment = meta.lidar_angle_increment;
    frame.lidar_range_min = meta.lidar_range_min;
    frame.lidar_range_max = meta.lidar_range_max;

    frame.camera_hfov_rad = meta.camera_hfov_rad;
    frame.camera_vfov_rad = meta.camera_vfov_rad;
    frame.camera_yaw_offset_rad = meta.camera_yaw_offset_rad;

    frame.robot_x = meta.robot_x;
    frame.robot_y = meta.robot_y;
    frame.robot_yaw = meta.robot_yaw;

    frame.tile_x = meta.tile_x;
    frame.tile_y = meta.tile_y;

    return pipeline_->process(frame, reject_reason);
}

void VisionRuntime::saveVisionDebugImage(const ros2_vision::VisionFrame& frame,
                                         const ros2_vision::VisionDebugImage& debug) const
{
    const bool classified = debug.status == "classified";
    if ((classified && !config_.save_classification_images) ||
        (!classified && !config_.save_rejected_images) ||
        frame.bgr.empty() ||
        config_.debug_image_dir.empty()) {
        return;
    }

    cv::Mat bgr;
    if (frame.bgr.channels() == 1) {
        cv::cvtColor(frame.bgr, bgr, cv::COLOR_GRAY2BGR);
    } else if (frame.bgr.channels() == 4) {
        cv::cvtColor(frame.bgr, bgr, cv::COLOR_BGRA2BGR);
    } else {
        bgr = frame.bgr.clone();
    }

    constexpr int scale = 4;
    cv::Mat view;
    cv::resize(bgr, view, cv::Size(bgr.cols * scale, bgr.rows * scale), 0, 0, cv::INTER_NEAREST);

    const cv::Scalar draw_color = classified ? cv::Scalar(0, 220, 0) : cv::Scalar(0, 0, 255);
    const cv::Rect image_rect(0, 0, bgr.cols, bgr.rows);
    const cv::Rect clipped = debug.bbox & image_rect;
    if (clipped.width > 0 && clipped.height > 0) {
        cv::rectangle(
            view,
            cv::Rect(clipped.x * scale, clipped.y * scale, clipped.width * scale, clipped.height * scale),
            draw_color,
            2);
    }
    if (std::isfinite(debug.center_x) && std::isfinite(debug.center_y)) {
        cv::circle(
            view,
            cv::Point(static_cast<int>(std::round(debug.center_x * scale)),
                      static_cast<int>(std::round(debug.center_y * scale))),
            4,
            draw_color,
            cv::FILLED);
    }
    if (debug.kind == "target" && clipped.width > 0 && clipped.height > 0) {
        const int radius = std::max(
            2, static_cast<int>(std::round(std::max(clipped.width, clipped.height) * 0.5 * scale)));
        cv::circle(
            view,
            cv::Point(static_cast<int>(std::round(debug.center_x * scale)),
                      static_cast<int>(std::round(debug.center_y * scale))),
            radius,
            cv::Scalar(0, 180, 255),
            1);
    }

    std::vector<LidarDebugRay> rays;
    if (debug.lidar_xmax > debug.lidar_xmin && !frame.scan.empty()) {
        const int x0 = static_cast<int>(std::round(debug.lidar_xmin * scale));
        const int x1 = static_cast<int>(std::round(debug.lidar_xmax * scale));
        cv::line(view, cv::Point(x0, 0), cv::Point(x0, view.rows - 1), cv::Scalar(255, 255, 0), 1);
        cv::line(view, cv::Point(x1, 0), cv::Point(x1, view.rows - 1), cv::Scalar(255, 255, 0), 1);
        rays = selectedLidarRays(frame, debug.lidar_xmin, debug.lidar_xmax, config_.lidar_window_extra_rays);
        for (const auto& ray : rays) {
            if (!std::isfinite(ray.pixel_x) || ray.pixel_x < 0.0 || ray.pixel_x > frame.bgr.cols - 1) {
                continue;
            }
            const int x = static_cast<int>(std::round(ray.pixel_x * scale));
            cv::line(view, cv::Point(x, 0), cv::Point(x, view.rows - 1),
                     ray.valid ? cv::Scalar(255, 0, 255) : cv::Scalar(80, 80, 80), 1);
        }
    }

    cv::Mat panel(std::max(view.rows, 360), 500, CV_8UC3, cv::Scalar(20, 20, 20));
    auto put = [&](int row, const std::string& text, double font_scale = 0.45) {
        cv::putText(panel, text, cv::Point(12, row), cv::FONT_HERSHEY_SIMPLEX, font_scale,
                    cv::Scalar(230, 230, 230), 1, cv::LINE_AA);
    };

    const std::string reason = debug.reason.empty() ? "none" : debug.reason;
    const std::string chosen = debug.kind == "target"
        ? debug.class_name + "/" + debug.target_pattern
        : debug.class_name;
    put(24, "VISION " + debug.status + ": " + debug.kind);
    put(48, "reason: " + reason);
    put(72, "chosen: " + chosen);
    put(96, "camera: " + frame.camera_name + "  seq: " + std::to_string(frame.seq));
    put(120, "tile: (" + std::to_string(frame.tile_x) + "," + std::to_string(frame.tile_y) + ")");
    {
        std::ostringstream oss;
        oss << std::fixed << std::setprecision(3)
            << "confidence=" << debug.confidence << " distance_m=" << debug.distance;
        put(144, oss.str());
    }
    {
        std::ostringstream oss;
        oss << "bbox_px=(" << debug.bbox.x << "," << debug.bbox.y << ","
            << debug.bbox.width << "," << debug.bbox.height << ")";
        put(168, oss.str());
    }
    {
        std::ostringstream oss;
        oss << std::fixed << std::setprecision(3)
            << "lidar_px=[" << debug.lidar_xmin << "," << debug.lidar_xmax << "]"
            << " valid=" << debug.valid_lidar_rays << "/" << rays.size();
        put(192, oss.str());
    }
    {
        std::ostringstream oss;
        oss << "scan_count=" << frame.scan.size()
            << " range=[" << frame.lidar_range_min << "," << frame.lidar_range_max << "]";
        put(216, oss.str());
    }
    {
        std::ostringstream oss;
        oss << std::fixed << std::setprecision(3)
            << "robot_m=(" << frame.robot_x << "," << frame.robot_y << ") yaw=" << frame.robot_yaw;
        put(240, oss.str());
    }
    if (debug.kind == "target") {
        std::ostringstream oss;
        oss << std::fixed << std::setprecision(3)
            << "pattern=" << debug.target_pattern << " sum=" << debug.target_sum
            << " radial=" << debug.radial_coverage << " mask=" << debug.mask_confidence;
        put(264, oss.str());
    }

    int row = debug.kind == "target" ? 288 : 264;
    put(row, "selected lidar rays:", 0.43);
    row += 22;
    std::ostringstream ray_line;
    int count_on_line = 0;
    int shown = 0;
    for (const auto& ray : rays) {
        if (shown >= 24) {
            break;
        }
        if (count_on_line > 0) {
            ray_line << "  ";
        }
        ray_line << ray.index << ":";
        if (std::isfinite(ray.range)) {
            ray_line << std::fixed << std::setprecision(3) << ray.range;
        } else {
            ray_line << "nan";
        }
        if (!ray.valid) {
            ray_line << "!";
        }
        ++shown;
        ++count_on_line;
        if (count_on_line == 4) {
            put(row, ray_line.str(), 0.40);
            row += 20;
            ray_line.str("");
            ray_line.clear();
            count_on_line = 0;
        }
    }
    if (count_on_line > 0) {
        put(row, ray_line.str(), 0.40);
    }

    if (panel.rows != view.rows) {
        cv::Mat adjusted(panel.rows, view.cols, CV_8UC3, cv::Scalar(0, 0, 0));
        view.copyTo(adjusted(cv::Rect(0, 0, view.cols, view.rows)));
        view = adjusted;
    }
    cv::Mat canvas;
    cv::hconcat(view, panel, canvas);

    std::filesystem::path dir = std::filesystem::path(config_.debug_image_dir);
    if (classified) {
        dir /= "classified";
        dir /= sanitizeFileToken(debug.kind);
    } else {
        dir /= "rejected";
        dir /= sanitizeFileToken(reason);
    }

    std::error_code ec;
    std::filesystem::create_directories(dir, ec);
    if (ec) {
        if (config_.event_logger) {
            config_.event_logger("ROBOT_EVENT node=vision_runtime event=vision_debug_image_dir_failed path=" +
                                 dir.string() + " error=" + ec.message());
        }
        return;
    }

    std::ostringstream stem;
    stem << debug.status << "_seq" << std::setw(8) << std::setfill('0') << frame.seq
         << "_tile" << frame.tile_x << "_" << frame.tile_y
         << "_" << sanitizeFileToken(frame.camera_name)
         << "_" << sanitizeFileToken(debug.kind)
         << "_" << sanitizeFileToken(chosen)
         << "_" << sanitizeFileToken(reason);
    const std::filesystem::path png_path = dir / (stem.str() + ".png");
    if (!cv::imwrite(png_path.string(), canvas)) {
        if (config_.event_logger) {
            config_.event_logger("ROBOT_EVENT node=vision_runtime event=vision_debug_image_write_failed path=" +
                                 png_path.string());
        }
        return;
    }

    const std::filesystem::path lidar_path = dir / (stem.str() + ".lidar.txt");
    std::ofstream lidar(lidar_path);
    if (lidar.good()) {
        lidar << std::fixed << std::setprecision(6)
              << "seq=" << frame.seq << "\n"
              << "status=" << debug.status << "\n"
              << "kind=" << debug.kind << "\n"
              << "class=" << debug.class_name << "\n"
              << "reason=" << reason << "\n"
              << "camera=" << frame.camera_name << "\n"
              << "tile_x=" << frame.tile_x << "\n"
              << "tile_y=" << frame.tile_y << "\n"
              << "lidar_xmin=" << debug.lidar_xmin << "\n"
              << "lidar_xmax=" << debug.lidar_xmax << "\n"
              << "selected_count=" << rays.size() << "\n"
              << "index angle_rad range_m selected valid pixel_x\n";
        std::set<int> selected;
        for (const auto& ray : rays) {
            selected.insert(ray.index);
        }
        for (std::size_t i = 0; i < frame.scan.size(); ++i) {
            const int idx = static_cast<int>(i);
            const float range = frame.scan[i];
            const bool valid = std::isfinite(range) &&
                range >= frame.lidar_range_min &&
                range <= frame.lidar_range_max;
            lidar << idx << " "
                  << frame.lidar_angle_min + static_cast<double>(idx) * frame.lidar_angle_increment << " "
                  << range << " "
                  << (selected.count(idx) ? 1 : 0) << " "
                  << (valid ? 1 : 0) << " "
                  << scanIndexToPixel(idx, frame) << "\n";
        }
    }

    if (config_.event_logger) {
        std::ostringstream oss;
        oss << "ROBOT_EVENT node=vision_runtime event=vision_debug_image_saved"
            << " status=" << debug.status
            << " reason=" << reason
            << " path=" << png_path.string()
            << " lidar_path=" << lidar_path.string()
            << " seq=" << frame.seq
            << " kind=" << debug.kind
            << " class=" << debug.class_name;
        config_.event_logger(oss.str());
    }
}

}  // namespace vision_runtime
