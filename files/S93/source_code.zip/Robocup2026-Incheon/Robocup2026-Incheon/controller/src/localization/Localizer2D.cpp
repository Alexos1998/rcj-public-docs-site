#include "localization/Localizer2D.hpp"

#include <algorithm>
#include <cmath>

namespace localization {

namespace {

constexpr double kPi = 3.14159265358979323846;
constexpr double kTwoPi = 2.0 * kPi;

}  // namespace

Localizer2D::Localizer2D(LocalizerConfig config)
: config_(config)
{
    refreshNoiseCovariances();
}

void Localizer2D::reset(double stamp_s,
                        double x_m,
                        double y_m,
                        double z_m,
                        double yaw_rad,
                        double left_encoder_rad,
                        double right_encoder_rad)
{
    state_ = LocalizerState{};
    state_.initialized = true;
    state_.stamp_s = stamp_s;
    state_.x_m = x_m;
    state_.y_m = y_m;
    state_.z_m = z_m;
    state_.yaw_rad = wrapPi(yaw_rad);
    refreshNoiseCovariances();

    updateEncoderBaseline(left_encoder_rad, right_encoder_rad);
    last_yaw_wrapped_rad_ = state_.yaw_rad;
    yaw_unwrapped_rad_ = state_.yaw_rad;
}

LocalizerState Localizer2D::update(const LocalizerInput& input)
{
    state_.gps_used = false;
    state_.gps_rejected = false;
    state_.gps_innovation_m = 0.0;
    state_.slip_suspected = false;
    state_.encoder_jump_rejected = false;
    state_.dt_rejected = false;
    state_.d_left_m = 0.0;
    state_.d_right_m = 0.0;
    state_.ds_m = 0.0;
    state_.d_yaw_rad = 0.0;
    state_.dt_s = 0.0;

    if (!finite(input.stamp_s) ||
        !finite(input.left_encoder_rad) ||
        !finite(input.right_encoder_rad) ||
        !finite(input.imu_yaw_ros_rad))
    {
        return state_;
    }

    const bool gps_valid =
        input.has_gps &&
        finite(input.gps_x_m) &&
        finite(input.gps_y_m) &&
        finite(input.gps_z_m);

    const double yaw_wrapped = wrapPi(input.imu_yaw_ros_rad);

    if (!state_.initialized) {
        const double x = gps_valid ? input.gps_x_m : 0.0;
        const double y = gps_valid ? input.gps_y_m : 0.0;
        const double z = gps_valid ? input.gps_z_m : 0.0;
        reset(
            input.stamp_s,
            x,
            y,
            z,
            yaw_wrapped,
            input.left_encoder_rad,
            input.right_encoder_rad);
        state_.gps_used = gps_valid;
        state_.gps_innovation_m = 0.0;
        return state_;
    }

    const double dt_s = input.stamp_s - state_.stamp_s;
    state_.dt_s = dt_s;

    const double d_yaw = wrapPi(yaw_wrapped - last_yaw_wrapped_rad_);
    const double next_yaw_unwrapped = yaw_unwrapped_rad_ + d_yaw;

    if (!finite(dt_s) || dt_s < config_.min_dt_s || dt_s > config_.max_dt_s) {
        state_.dt_rejected = true;
        state_.stamp_s = input.stamp_s;
        state_.yaw_rad = yaw_wrapped;
        state_.vx_mps = 0.0;
        state_.wz_radps = 0.0;
        updateEncoderBaseline(input.left_encoder_rad, input.right_encoder_rad);
        last_yaw_wrapped_rad_ = yaw_wrapped;
        yaw_unwrapped_rad_ = next_yaw_unwrapped;
        applyGpsCorrection(input, 0.0);
        return state_;
    }

    const double d_left_m =
        (input.left_encoder_rad - last_left_encoder_rad_) * config_.wheel_radius_m;
    const double d_right_m =
        (input.right_encoder_rad - last_right_encoder_rad_) * config_.wheel_radius_m;
    const double ds_m = 0.5 * (d_left_m + d_right_m);
    const double encoder_step_limit_m =
        config_.max_abs_vx_mps * dt_s * config_.encoder_jump_multiplier +
        config_.encoder_jump_extra_m;

    state_.d_left_m = d_left_m;
    state_.d_right_m = d_right_m;
    state_.ds_m = ds_m;
    state_.d_yaw_rad = d_yaw;

    updateEncoderBaseline(input.left_encoder_rad, input.right_encoder_rad);
    last_yaw_wrapped_rad_ = yaw_wrapped;
    yaw_unwrapped_rad_ = next_yaw_unwrapped;

    if (std::abs(d_left_m) > encoder_step_limit_m ||
        std::abs(d_right_m) > encoder_step_limit_m)
    {
        state_.encoder_jump_rejected = true;
        state_.stamp_s = input.stamp_s;
        state_.yaw_rad = wrapPi(next_yaw_unwrapped);
        state_.vx_mps = 0.0;
        state_.wz_radps = clamp(d_yaw / dt_s, -config_.max_abs_wz_radps, config_.max_abs_wz_radps);
        applyGpsCorrection(input, 0.0);
        return state_;
    }

    double vx = clamp(ds_m / dt_s, -config_.max_abs_vx_mps, config_.max_abs_vx_mps);
    const double wz = clamp(d_yaw / dt_s, -config_.max_abs_wz_radps, config_.max_abs_wz_radps);

    const bool front_blocked =
        input.has_front_clearance &&
        finite(input.front_clearance_m) &&
        input.front_clearance_m < 0.040;
    const bool gps_speed_stopped =
        finite(input.gps_speed_mps) &&
        input.gps_speed_mps < 0.006;

    if (input.cmd_v_mps > 0.02 &&
        vx > 0.015 &&
        gps_speed_stopped &&
        front_blocked)
    {
        state_.slip_suspected = true;
    }

    double integration_ds = ds_m;
    if (state_.slip_suspected && config_.freeze_translation_on_slip) {
        integration_ds = 0.0;
        vx = 0.0;
    }

    const double yaw_mid = yaw_unwrapped_rad_ - d_yaw + 0.5 * d_yaw;
    state_.x_m += integration_ds * std::cos(yaw_mid);
    state_.y_m += integration_ds * std::sin(yaw_mid);
    state_.yaw_rad = wrapPi(yaw_unwrapped_rad_);
    state_.vx_mps = vx;
    state_.wz_radps = wz;
    state_.stamp_s = input.stamp_s;

    applyGpsCorrection(input, std::abs(integration_ds));
    return state_;
}

const LocalizerState& Localizer2D::state() const
{
    return state_;
}

double Localizer2D::wrapPi(double angle)
{
    while (angle > kPi) {
        angle -= kTwoPi;
    }
    while (angle < -kPi) {
        angle += kTwoPi;
    }
    return angle;
}

double Localizer2D::clamp(double value, double min_value, double max_value)
{
    return std::max(min_value, std::min(value, max_value));
}

bool Localizer2D::finite(double value)
{
    return std::isfinite(value);
}

void Localizer2D::refreshNoiseCovariances()
{
    const double gps_var = config_.gps_sigma_m * config_.gps_sigma_m;
    state_.cov_x = std::max(state_.cov_x, gps_var);
    state_.cov_y = std::max(state_.cov_y, gps_var);
    state_.cov_yaw = config_.yaw_sigma_rad * config_.yaw_sigma_rad;
    state_.cov_vx = config_.wheel_vx_sigma_mps * config_.wheel_vx_sigma_mps;
    state_.cov_wz = config_.wheel_wz_sigma_radps * config_.wheel_wz_sigma_radps;
}

void Localizer2D::updateEncoderBaseline(double left_encoder_rad, double right_encoder_rad)
{
    last_left_encoder_rad_ = left_encoder_rad;
    last_right_encoder_rad_ = right_encoder_rad;
}

void Localizer2D::applyGpsCorrection(const LocalizerInput& input, double travelled_m)
{
    refreshNoiseCovariances();

    if (!config_.use_gps_correction || !input.has_gps) {
        return;
    }

    if (!finite(input.gps_x_m) || !finite(input.gps_y_m) || !finite(input.gps_z_m)) {
        state_.gps_rejected = true;
        return;
    }

    state_.z_m = input.gps_z_m;

    const double innovation_x = input.gps_x_m - state_.x_m;
    const double innovation_y = input.gps_y_m - state_.y_m;
    const double innovation = std::hypot(innovation_x, innovation_y);
    state_.gps_innovation_m = innovation;

    if (innovation <= config_.gps_gate_m) {
        state_.x_m += config_.gps_alpha * innovation_x;
        state_.y_m += config_.gps_alpha * innovation_y;
        state_.gps_used = true;
        const double gps_var = config_.gps_sigma_m * config_.gps_sigma_m;
        state_.cov_x += config_.gps_alpha * (gps_var - state_.cov_x);
        state_.cov_y += config_.gps_alpha * (gps_var - state_.cov_y);
        state_.cov_x = clamp(state_.cov_x, gps_var, config_.max_position_cov);
        state_.cov_y = clamp(state_.cov_y, gps_var, config_.max_position_cov);
        return;
    }

    state_.gps_rejected = true;

    if (innovation > config_.gps_hard_reject_m || travelled_m > 1e-5) {
        const double growth = std::max(0.0, travelled_m) * 0.0025;
        state_.cov_x = std::min(config_.max_position_cov, state_.cov_x + growth);
        state_.cov_y = std::min(config_.max_position_cov, state_.cov_y + growth);
    }
}

}  // namespace localization
