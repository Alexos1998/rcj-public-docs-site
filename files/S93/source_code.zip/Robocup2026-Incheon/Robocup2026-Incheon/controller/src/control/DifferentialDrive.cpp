#include "control/DifferentialDrive.hpp"
#include <cmath>
#include <algorithm>
#include "utils/MathUtils.hpp"

namespace control {

void applyBaseVelocity(
   webots::Motor* wheel_left,
   webots::Motor* wheel_right,
   double v,
   double w,
   double wheel_radius,
   double axle_length,
   double max_speed
) {
   const double signed_w = -w;
   double wl = (2.0 * v - signed_w * axle_length) / (2.0 * wheel_radius);
   double wr = (2.0 * v + signed_w * axle_length) / (2.0 * wheel_radius);

   double max_wheel = std::max(std::fabs(wl), std::fabs(wr));
   if (max_wheel > max_speed) {
      const double scale = max_speed / max_wheel;
      wl *= scale;
      wr *= scale;
   }

   if (wheel_left) {
      wheel_left->setVelocity(wl);
   }
   if (wheel_right) {
      wheel_right->setVelocity(wr);
   }
}

WheelCommandDiagnostics computeWheelCommandDiagnostics(
   double raw_v,
   double raw_w,
   double wheel_radius,
   double axle_length,
   double max_speed,
   double max_linear_vel,
   double max_angular_vel
) {
   WheelCommandDiagnostics diag;
   diag.raw_v = raw_v;
   diag.raw_w = raw_w;
   diag.clamped_v = utils::clampd(raw_v, -max_linear_vel, max_linear_vel);
   diag.clamped_w = utils::clampd(raw_w, -max_angular_vel, max_angular_vel);

   const double signed_w = -diag.clamped_w;
   diag.wl_raw = (2.0 * diag.clamped_v - signed_w * axle_length) / (2.0 * wheel_radius);
   diag.wr_raw = (2.0 * diag.clamped_v + signed_w * axle_length) / (2.0 * wheel_radius);

   const double max_wheel = std::max(std::fabs(diag.wl_raw), std::fabs(diag.wr_raw));
   diag.wl_final = diag.wl_raw;
   diag.wr_final = diag.wr_raw;
   if (max_wheel > max_speed) {
      diag.wheel_scale = max_speed / max_wheel;
      diag.wl_final *= diag.wheel_scale;
      diag.wr_final *= diag.wheel_scale;
      diag.saturated = true;
   }

   return diag;
}

} // namespace control
