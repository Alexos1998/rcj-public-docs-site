#include "utils/UniqueLogger.hpp"

#include <cstdlib>

namespace utils {

UniqueLogger::UniqueLogger(const std::string& path) : path_(path) {
   if (!path_.empty()) {
      stream_.open(path_, std::ios::out | std::ios::app);
   }
}

static std::string resolveUniqueLogPath() {
   const char* raw = std::getenv("UNIQUE_LOG_PATH");
   if (raw != nullptr && raw[0] != '\0') {
      return std::string(raw);
   }
   return std::string(UniqueLogger::kDefaultPath);
}

UniqueLogger& uniqueLogger() {
   static UniqueLogger instance(resolveUniqueLogPath());
   return instance;
}

} // namespace utils
