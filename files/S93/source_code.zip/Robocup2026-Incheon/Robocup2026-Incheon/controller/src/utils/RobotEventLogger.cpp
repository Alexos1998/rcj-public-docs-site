#include "utils/RobotEventLogger.hpp"
#include "utils/MathUtils.hpp"
#include <sstream>

namespace utils {

static void logRobotEventImpl(
   diag::Level level,
   const std::string& event,
   const RobotEventFields& fields,
   bool terminal
) {
   std::ostringstream oss;
   oss << "ROBOT_EVENT node=controller event=" << event;

   if (terminal) {
      oss << " terminal=1";
   }

   for (const auto& field : fields) {
      oss << ' ' << field.first << '=' << sanitizedValue(field.second);
   }

   diag::log(level, oss.str());
}

void logRobotEvent(
   diag::Level level,
   const std::string& event,
   const RobotEventFields& fields
) {
   logRobotEventImpl(level, event, fields, false);
}

void logRobotEvent(
   const std::string& event,
   const RobotEventFields& fields
) {
   logRobotEvent(diag::Level::Info, event, fields);
}

void logRobotTerminalEvent(
   diag::Level level,
   const std::string& event,
   const RobotEventFields& fields
) {
   logRobotEventImpl(level, event, fields, true);
}

void logRobotTerminalEvent(
   const std::string& event,
   const RobotEventFields& fields
) {
   logRobotTerminalEvent(diag::Level::Info, event, fields);
}

} // namespace utils