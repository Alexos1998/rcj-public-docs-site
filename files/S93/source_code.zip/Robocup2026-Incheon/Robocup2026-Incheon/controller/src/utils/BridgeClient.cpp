#include "utils/BridgeClient.hpp"

#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstring>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <thread>

namespace {
constexpr auto kReconnectRetryInterval = std::chrono::milliseconds(500);
constexpr auto kSocketSendTimeout = std::chrono::milliseconds(1000);
}

void BridgeClient::closeSocket() {
    if (sock_ >= 0) {
        close(sock_);
        sock_ = -1;
    }
}

bool BridgeClient::connectOnce(bool log_success, bool log_failure) {
    closeSocket();

    sock_ = socket(AF_INET, SOCK_STREAM, 0);

    if (sock_ < 0) {
        if (log_failure) {
            std::cout << "[MAIN] Erro ao criar socket\n";
        }
        return false;
    }

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(5000);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (::connect(sock_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) == 0) {
        int flag = 1;
        if (setsockopt(sock_, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag)) < 0) {
            std::cout << "[MAIN] Aviso: falha ao setar TCP_NODELAY: "
                      << std::strerror(errno) << "\n";
        }
        has_reconnect_attempt_ = false;
        if (log_success) {
            std::cout << "[MAIN] Conectado na bridge!\n";
        }
        return true;
    }

    const int connect_errno = errno;
    if (log_failure) {
        std::cout << "[MAIN] Falha ao conectar na bridge: "
                  << std::strerror(connect_errno) << "\n";
    }
    closeSocket();
    return false;
}

bool BridgeClient::shouldAttemptReconnect() {
    const auto now = std::chrono::steady_clock::now();

    if (!has_reconnect_attempt_ || (now - last_reconnect_attempt_) >= kReconnectRetryInterval) {
        last_reconnect_attempt_ = now;
        has_reconnect_attempt_ = true;
        return true;
    }

    return false;
}

bool BridgeClient::connect() {
    std::cout << "[MAIN] Conectando na bridge...\n";

    for (int i = 0; i < 20; ++i) {
        if (connectOnce(true, i == 0)) {
            return true;
        }
        usleep(200000);
    }

    std::cout << "[MAIN] Falha ao conectar na bridge\n";
    closeSocket();
    return false;
}

std::string BridgeClient::hexEncode(const unsigned char* data, std::size_t size)
{
    static constexpr char kHex[] = "0123456789ABCDEF";

    std::string out;
    out.reserve(size * 2);

    for (std::size_t i = 0; i < size; ++i) {
        const unsigned char b = data[i];
        out.push_back(kHex[(b >> 4) & 0x0F]);
        out.push_back(kHex[b & 0x0F]);
    }

    return out;
}

void BridgeClient::sendAll(const std::string& msg) {
    if (sock_ < 0) {
        if (!shouldAttemptReconnect() || !connectOnce(true, false)) {
            return;
        }
    }

    const auto deadline = std::chrono::steady_clock::now() + kSocketSendTimeout;
    size_t total = 0;
    while (total < msg.size()) {
        const ssize_t n = send(
            sock_,
            msg.c_str() + total,
            msg.size() - total,
            MSG_DONTWAIT | MSG_NOSIGNAL);

        if (n > 0) {
            total += static_cast<size_t>(n);
            continue;
        }

        if (n < 0 && errno == EINTR) {
            continue;
        }

        if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
            const auto now = std::chrono::steady_clock::now();
            if (now >= deadline) {
                std::cerr << "[MAIN] Timeout aguardando bridge aceitar dados; "
                          << "fechando conexão após " << total << "/" << msg.size()
                          << " bytes\n";
                closeSocket();
                return;
            }

            const auto remaining_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                deadline - now).count();
            pollfd descriptor{};
            descriptor.fd = sock_;
            descriptor.events = POLLOUT;
            const int wait_ms = static_cast<int>(std::min<long long>(50, remaining_ms));
            int poll_result = 0;
            do {
                poll_result = poll(&descriptor, 1, std::max(1, wait_ms));
            } while (poll_result < 0 && errno == EINTR);

            if (poll_result > 0 && (descriptor.revents & POLLOUT) != 0) {
                continue;
            }
            if (poll_result > 0 &&
                (descriptor.revents & (POLLERR | POLLHUP | POLLNVAL)) != 0)
            {
                std::cerr << "[MAIN] Bridge socket ficou inválido durante send(); revents="
                          << descriptor.revents << "\n";
                closeSocket();
                return;
            }
            continue;
        }

        std::cerr << "[MAIN] Erro no send(): "
                  << (n < 0 ? std::strerror(errno) : "conexão fechada")
                  << "\n";
        closeSocket();
        return;
    }
}

void BridgeClient::sendScan(const std::vector<float>& scan) {
    std::ostringstream oss;
    oss << "SCAN|";
    for (size_t i = 0; i < scan.size(); ++i) {
        oss << scan[i];
        if (i + 1 < scan.size()) oss << ",";
    }
    oss << "\n";
    sendAll(oss.str());
}

void BridgeClient::sendImu(double roll, double pitch, double yaw) {
    std::ostringstream oss;
    oss << "IMU|" << roll << "," << pitch << "," << yaw << "\n";
    sendAll(oss.str());
}

void BridgeClient::sendTime(double t) {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(6) << "TIME|" << t << "\n";
    sendAll(oss.str());
}

void BridgeClient::sendGps(const GpsLocal& pos) {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(6)
        << "GPS|" << pos.x
        << "," << pos.y
        << "," << pos.z
        << "\n";
    sendAll(oss.str());
}

void BridgeClient::sendWheelOdom(
    double x,
    double y,
    double yaw,
    double vx,
    double wz,
    bool slip_suspected)
{
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(6)
        << "ODOM|"
        << x << ","
        << y << ","
        << yaw << ","
        << vx << ","
        << wz << ","
        << (slip_suspected ? 1 : 0)
        << "\n";

    sendAll(oss.str());
}

void BridgeClient::sendLocalization(const localization::LocalizerState& state)
{
    if (!state.initialized) {
        return;
    }

    std::ostringstream oss;
    oss << std::fixed << std::setprecision(6)
        << "LOC|"
        << state.x_m << ","
        << state.y_m << ","
        << state.z_m << ","
        << state.yaw_rad << ","
        << state.vx_mps << ","
        << state.wz_radps << ","
        << state.cov_x << ","
        << state.cov_y << ","
        << state.cov_yaw << ","
        << state.cov_vx << ","
        << state.cov_wz << ","
        << (state.gps_used ? 1 : 0) << ","
        << (state.gps_rejected ? 1 : 0) << ","
        << (state.slip_suspected ? 1 : 0)
        << "\n";

    sendAll(oss.str());
}

void BridgeClient::sendColorClassification(const std::string& color_class,
                                           int r,
                                           int g,
                                           int b,
                                           double confidence)
{
    std::ostringstream oss;
    oss << "COLOR|"
        << color_class << "|"
        << r << "|"
        << g << "|"
        << b << "|"
        << std::fixed << std::setprecision(3)
        << confidence
        << "\n";

    sendAll(oss.str());
}

void BridgeClient::sendHoleDetection(
    double x,
    double y,
    double yaw,
    const std::string& source,
    double confidence,
    const std::string& legacy_direction,
    int legacy_current_x,
    int legacy_current_y,
    int legacy_target_x,
    int legacy_target_y,
    double requested_distance_m,
    double traveled_before_stop_m)
{
    std::ostringstream oss;
    oss << "HOLE|"
        << std::fixed << std::setprecision(6)
        << x << "|"
        << y << "|"
        << yaw << "|"
        << source << "|"
        << std::setprecision(3)
        << confidence << "|"
        << legacy_direction << "|"
        << legacy_current_x << "|"
        << legacy_current_y << "|"
        << legacy_target_x << "|"
        << legacy_target_y << "|"
        << std::setprecision(6)
        << requested_distance_m << "|"
        << traveled_before_stop_m
        << "\n";

    sendAll(oss.str());
}

void BridgeClient::sendVisionDetection(
    const std::string& kind,
    const std::string& class_name,
    const std::string& target_pattern,
    int tile_x,
    int tile_y,
    const std::string& camera,
    double yaw,
    double center_x,
    double image_width,
    double distance_m,
    double confidence)
{
    std::ostringstream oss;
    oss << "VISION|"
        << kind << "|"
        << class_name << "|"
        << target_pattern << "|"
        << tile_x << "|"
        << tile_y << "|"
        << camera << "|"
        << std::fixed << std::setprecision(6)
        << yaw << "|"
        << center_x << "|"
        << image_width << "|"
        << distance_m << "|"
        << std::setprecision(3)
        << confidence
        << "\n";

    sendAll(oss.str());
}

void BridgeClient::sendCameraFrame(const std::string& name,
                                   double t,
                                   int width,
                                   int height,
                                   double fov,
                                   const unsigned char* bgra,
                                   std::size_t size)
{
    if (sock_ < 0 || bgra == nullptr || size == 0) return;

    std::ostringstream oss;
    oss << "CAM|"
        << name << "|"
        << std::fixed << std::setprecision(6) << t << "|"
        << width << "|"
        << height << "|"
        << std::setprecision(9) << fov << "|"
        << "bgra8|"
        << hexEncode(bgra, size)
        << "\n";

    sendAll(oss.str());
}

exploration_legacy::ReachabilityResult BridgeClient::requestLegacyReachability(
    const exploration_legacy::Pose2D& start,
    double goal_x_m,
    double goal_y_m,
    const std::vector<exploration_legacy::PathCandidate>& candidates,
    std::chrono::milliseconds timeout)
{
    exploration_legacy::ReachabilityResult failure;

    if (!std::isfinite(start.x) ||
        !std::isfinite(start.y) ||
        !std::isfinite(start.yaw) ||
        !std::isfinite(goal_x_m) ||
        !std::isfinite(goal_y_m))
    {
        failure.status = exploration_legacy::ReachabilityStatus::InvalidCoordinate;
        failure.reason = "request contains non-finite coordinate";
        return failure;
    }

    if (candidates.empty()) {
        failure.status = exploration_legacy::ReachabilityStatus::InvalidCoordinate;
        failure.reason = "request contains no candidates";
        return failure;
    }

    if (sock_ < 0 && (!shouldAttemptReconnect() || !connectOnce(true, false))) {
        failure.status = exploration_legacy::ReachabilityStatus::Timeout;
        failure.reason = "bridge socket disconnected";
        return failure;
    }

    const std::uint64_t request_id = next_reachability_request_id_++;
    pending_reachability_responses_.erase(request_id);

    std::ostringstream oss;
    oss << std::fixed << std::setprecision(6)
        << "LEGACY_REACHABILITY_REQUEST|1|"
        << request_id << "|"
        << start.x << "|"
        << start.y << "|"
        << start.yaw << "|"
        << goal_x_m << "|"
        << goal_y_m << "|"
        << exploration_legacy::serializeCandidatePayload(candidates)
        << "\n";

    sendAll(oss.str());

    const auto deadline = std::chrono::steady_clock::now() + timeout;
    while (std::chrono::steady_clock::now() < deadline) {
        pollIncoming();
        const auto it = pending_reachability_responses_.find(request_id);
        if (it != pending_reachability_responses_.end()) {
            auto result = it->second;
            pending_reachability_responses_.erase(it);
            return result;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }

    failure.status = exploration_legacy::ReachabilityStatus::Timeout;
    failure.reason = "timed out waiting for reachability response";
    return failure;
}

void BridgeClient::pollIncoming() {
    if (sock_ < 0) return;

    char buffer[4096];

    while (true) {
        ssize_t n = recv(sock_, buffer, sizeof(buffer), MSG_DONTWAIT);

        if (n > 0) {
            incoming_buffer_.append(buffer, static_cast<std::size_t>(n));
            continue;
        }

        if (n == 0) {
            closeSocket();
            return;
        }

        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            break;
        }

        closeSocket();
        return;
    }

    size_t pos;

    while ((pos = incoming_buffer_.find('\n')) != std::string::npos) {
        std::string line = incoming_buffer_.substr(0, pos);
        incoming_buffer_.erase(0, pos + 1);

        if (!line.empty() && line.back() == '\r') {
            line.pop_back();
        }

        if (line.rfind("CMD|", 0) == 0) {
            std::string rest = line.substr(4);
            std::stringstream ss(rest);
            std::string a, b;

            if (std::getline(ss, a, ',') &&
                std::getline(ss, b, ',')) {
                try {
                    pending_cmd_.v = std::stod(a);
                    pending_cmd_.w = std::stod(b);
                    has_pending_cmd_ = true;
                } catch (...) {
                }
            }

            continue;
        }

        if (line.rfind("LEGACY_REACHABILITY_RESPONSE|", 0) == 0) {
            std::uint64_t request_id = 0;
            exploration_legacy::ReachabilityResult result;
            if (exploration_legacy::parseReachabilityResponse(line, request_id, result)) {
                pending_reachability_responses_[request_id] = result;
            }
            continue;
        }

        if (line.rfind("POSE|", 0) == 0) {
            std::string rest = line.substr(5);
            std::stringstream ss(rest);
            std::string a, b, c;

            if (std::getline(ss, a, ',') &&
                std::getline(ss, b, ',') &&
                std::getline(ss, c, ',')) {
                try {
                    pending_pose_.x = std::stod(a);
                    pending_pose_.y = std::stod(b);
                    pending_pose_.th = std::stod(c);
                    has_pending_pose_ = true;
                } catch (...) {
                }
            }

            continue;
        }

        static const std::string matrix_prefix = "SUBMISSION_MATRIX|";

        if (line.rfind(matrix_prefix, 0) == 0) {
            latest_submission_matrix_ = line.substr(matrix_prefix.size());

            std::replace(
                latest_submission_matrix_.begin(),
                latest_submission_matrix_.end(),
                ';',
                '\n');

            has_submission_matrix_ = true;
            continue;
        }
    }
}

bool BridgeClient::receiveCmdVel(CmdVel& cmd) {
    pollIncoming();

    if (!has_pending_cmd_) {
        return false;
    }

    cmd = pending_cmd_;
    has_pending_cmd_ = false;
    return true;
}

bool BridgeClient::receivePose(Pose2D& pose) {
    pollIncoming();

    if (!has_pending_pose_) {
        return false;
    }

    pose = pending_pose_;
    has_pending_pose_ = false;
    return true;
}

bool BridgeClient::receiveSubmissionMatrix(std::string& matrix_text) {
    pollIncoming();

    if (!has_submission_matrix_) {
        return false;
    }

    matrix_text = latest_submission_matrix_;
    has_submission_matrix_ = false;
    return true;
}
