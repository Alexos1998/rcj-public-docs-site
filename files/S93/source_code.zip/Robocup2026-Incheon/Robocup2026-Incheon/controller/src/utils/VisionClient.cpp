#include "utils/VisionClient.hpp"

#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <unistd.h>

#include <algorithm>
#include <cerrno>
#include <cstring>
#include <utility>

namespace {

constexpr std::uint32_t kVisionFrameMagic = 0x4d524656u;
constexpr std::uint16_t kVisionFrameVersion = 1;
constexpr std::uint8_t kEncodingBgr8 = 1;
constexpr std::uint8_t kEncodingBgra8 = 2;
constexpr auto kReconnectInterval = std::chrono::milliseconds(500);

#pragma pack(push, 1)
struct VisionFrameHeader {
    std::uint32_t magic;
    std::uint16_t version;
    std::uint16_t header_size;
    std::uint64_t seq;
    double stamp_s;
    std::uint8_t camera_id;
    std::uint8_t encoding;
    std::uint16_t width;
    std::uint16_t height;
    float camera_hfov_rad;
    float camera_vfov_rad;
    float camera_yaw_offset_rad;
    float robot_x;
    float robot_y;
    float robot_yaw;
    std::int32_t tile_x;
    std::int32_t tile_y;
    std::uint16_t lidar_count;
    float lidar_angle_min;
    float lidar_angle_increment;
    float lidar_range_min;
    float lidar_range_max;
    std::uint32_t image_bytes;
};
#pragma pack(pop)

static_assert(sizeof(VisionFrameHeader) == 84, "VisionFrameHeader wire size changed");

void appendBytes(std::vector<std::uint8_t>& out, const void* data, std::size_t size)
{
    const auto* first = static_cast<const std::uint8_t*>(data);
    out.insert(out.end(), first, first + size);
}

bool setNonblocking(int fd)
{
    const int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0) return false;
    return fcntl(fd, F_SETFL, flags | O_NONBLOCK) == 0;
}

}  // namespace

VisionClient::VisionClient(VisionClientConfig config)
    : config_(std::move(config)),
      send_every_n_(std::max(1, config_.send_every_n))
{
}

VisionClient::~VisionClient()
{
    stop();
}

void VisionClient::start()
{
    if (running_.exchange(true)) {
        return;
    }
    sender_ = std::thread(&VisionClient::senderLoop, this);
}

void VisionClient::stop()
{
    running_ = false;
    cv_.notify_all();
    if (sender_.joinable()) {
        sender_.join();
    }
    closeFrameSocket();
    closeResultSocket();
}

void VisionClient::enqueueBgraFrame(const VisionFrameMetadata& metadata,
                                    int width,
                                    int height,
                                    const unsigned char* bgra,
                                    const std::vector<float>& scan)
{
    if (!running_ || bgra == nullptr || width <= 0 || height <= 0) {
        return;
    }

    const bool send_bgra = config_.image_encoding == "BGRA8";
    const std::size_t pixels = static_cast<std::size_t>(width) * static_cast<std::size_t>(height);
    std::vector<std::uint8_t> image;
    image.reserve(pixels * (send_bgra ? 4u : 3u));
    if (send_bgra) {
        image.insert(image.end(), bgra, bgra + pixels * 4u);
    } else {
        for (std::size_t i = 0; i < pixels; ++i) {
            image.push_back(bgra[i * 4u + 0u]);
            image.push_back(bgra[i * 4u + 1u]);
            image.push_back(bgra[i * 4u + 2u]);
        }
    }

    VisionFrameHeader header{};
    header.magic = kVisionFrameMagic;
    header.version = kVisionFrameVersion;
    header.header_size = sizeof(VisionFrameHeader);
    header.seq = metadata.seq;
    header.stamp_s = metadata.stamp_s;
    header.camera_id = static_cast<std::uint8_t>(metadata.camera_id);
    header.encoding = send_bgra ? kEncodingBgra8 : kEncodingBgr8;
    header.width = static_cast<std::uint16_t>(width);
    header.height = static_cast<std::uint16_t>(height);
    header.camera_hfov_rad = metadata.camera_hfov_rad;
    header.camera_vfov_rad = metadata.camera_vfov_rad;
    header.camera_yaw_offset_rad = metadata.camera_yaw_offset_rad;
    header.robot_x = metadata.robot_x;
    header.robot_y = metadata.robot_y;
    header.robot_yaw = metadata.robot_yaw;
    header.tile_x = metadata.tile_x;
    header.tile_y = metadata.tile_y;
    header.lidar_count = static_cast<std::uint16_t>(std::min<std::size_t>(scan.size(), 4096u));
    header.lidar_angle_min = metadata.lidar_angle_min;
    header.lidar_angle_increment = metadata.lidar_angle_increment;
    header.lidar_range_min = metadata.lidar_range_min;
    header.lidar_range_max = metadata.lidar_range_max;
    header.image_bytes = static_cast<std::uint32_t>(image.size());

    PendingFrame pending;
    pending.bytes.reserve(sizeof(header) + header.lidar_count * sizeof(float) + image.size());
    appendBytes(pending.bytes, &header, sizeof(header));
    if (header.lidar_count > 0) {
        appendBytes(pending.bytes, scan.data(), static_cast<std::size_t>(header.lidar_count) * sizeof(float));
    }
    appendBytes(pending.bytes, image.data(), image.size());

    {
        std::lock_guard<std::mutex> lock(mutex_);
        latest_by_camera_[metadata.camera_id] = std::move(pending);
    }
    cv_.notify_one();
}

std::vector<std::string> VisionClient::pollResults()
{
    std::vector<std::string> lines;
    if (result_sock_ < 0) {
        connectResultSocket();
        return lines;
    }

    char buffer[1024];
    while (true) {
        const ssize_t n = recv(result_sock_, buffer, sizeof(buffer), MSG_DONTWAIT);
        if (n > 0) {
            result_buffer_.append(buffer, static_cast<std::size_t>(n));
            continue;
        }
        if (n == 0) {
            closeResultSocket();
        } else if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR) {
            closeResultSocket();
        }
        break;
    }

    std::size_t pos = 0;
    while ((pos = result_buffer_.find('\n')) != std::string::npos) {
        std::string line = result_buffer_.substr(0, pos);
        result_buffer_.erase(0, pos + 1);
        if (!line.empty()) {
            lines.push_back(std::move(line));
        }
    }
    return lines;
}

void VisionClient::senderLoop()
{
    while (running_) {
        std::vector<PendingFrame> batch;
        {
            std::unique_lock<std::mutex> lock(mutex_);
            cv_.wait_for(lock, std::chrono::milliseconds(100), [&] {
                return !running_ || !latest_by_camera_.empty();
            });
            if (!running_) {
                break;
            }
            if (latest_by_camera_.empty()) {
                continue;
            }
            // Drain the latest frame of every camera (ascending camera_id) so the
            // left camera is transmitted alongside the right instead of being
            // overwritten by it.
            batch.reserve(latest_by_camera_.size());
            for (auto& entry : latest_by_camera_) {
                batch.push_back(std::move(entry.second));
            }
            latest_by_camera_.clear();
        }

        if (frame_sock_ < 0 && !connectFrameSocket()) {
            continue;
        }
        for (const auto& frame : batch) {
            if (!sendPending(frame)) {
                closeFrameSocket();
                break;
            }
        }
    }
}

bool VisionClient::connectFrameSocket()
{
    if (!shouldReconnect(last_frame_reconnect_)) {
        return false;
    }

    frame_sock_ = socket(AF_INET, SOCK_STREAM, 0);
    if (frame_sock_ < 0) {
        return false;
    }
    int flag = 1;
    setsockopt(frame_sock_, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag));

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(static_cast<std::uint16_t>(config_.frame_port));
    inet_pton(AF_INET, config_.host.c_str(), &addr.sin_addr);
    if (connect(frame_sock_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) != 0) {
        closeFrameSocket();
        return false;
    }
    setNonblocking(frame_sock_);
    frame_connected_ = true;
    return true;
}

bool VisionClient::connectResultSocket()
{
    if (result_sock_ >= 0 || !shouldReconnect(last_result_reconnect_)) {
        return result_sock_ >= 0;
    }

    result_sock_ = socket(AF_INET, SOCK_STREAM, 0);
    if (result_sock_ < 0) {
        return false;
    }
    setNonblocking(result_sock_);
    int flag = 1;
    setsockopt(result_sock_, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag));

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(static_cast<std::uint16_t>(config_.result_port));
    inet_pton(AF_INET, config_.host.c_str(), &addr.sin_addr);
    if (connect(result_sock_, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) != 0 &&
        errno != EINPROGRESS) {
        closeResultSocket();
        return false;
    }
    result_connected_ = true;
    return true;
}

bool VisionClient::sendPending(const PendingFrame& frame)
{
    std::size_t total = 0;
    while (total < frame.bytes.size()) {
        const ssize_t n = send(frame_sock_,
                               frame.bytes.data() + total,
                               frame.bytes.size() - total,
                               MSG_DONTWAIT | MSG_NOSIGNAL);
        if (n > 0) {
            total += static_cast<std::size_t>(n);
            continue;
        }
        if (n < 0 && errno == EINTR) {
            continue;
        }
        return false;
    }
    return true;
}

void VisionClient::closeFrameSocket()
{
    if (frame_sock_ >= 0) {
        close(frame_sock_);
        frame_sock_ = -1;
    }
    frame_connected_ = false;
}

void VisionClient::closeResultSocket()
{
    if (result_sock_ >= 0) {
        close(result_sock_);
        result_sock_ = -1;
    }
    result_connected_ = false;
}

bool VisionClient::shouldReconnect(std::chrono::steady_clock::time_point& last_attempt)
{
    const auto now = std::chrono::steady_clock::now();
    if (last_attempt.time_since_epoch().count() != 0 &&
        now - last_attempt < kReconnectInterval) {
        return false;
    }
    last_attempt = now;
    return true;
}
