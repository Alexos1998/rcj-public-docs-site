#include "utils/PID.hpp"

// ===================== MÉTODOS PRIVADOS =====================

void PID::setDefaults()
{
   kff = 0.0;
   beta = 1.0;
   derivative_filtered = 0.0;
   alpha = 0.1;
   integral_min = -1000.0;
   integral_max = 1000.0;
   prev_output = 0.0;
   max_slew_rate = 1000.0;
}

// ===================== CONSTRUTOR =====================

PID::PID(double kp, double ki, double kd)
   : kp(kp), ki(ki), kd(kd), prev_error(0.0), integral(0.0)
{
   setDefaults();
}

// ===================== SETTERS =====================

void PID::setFeedforward(double kff_)
{
   kff = kff_;
}

void PID::setBeta(double beta_)
{
   beta = beta_;
}

void PID::setAlpha(double alpha_)
{
   alpha = alpha_;
}

void PID::setIntegralLimits(double min, double max)
{
   integral_min = min;
   integral_max = max;
}

void PID::setMaxSlewRate(double max_rate)
{
   max_slew_rate = max_rate;
}

// ===================== MÉTODO PRINCIPAL =====================

double PID::calcular(double alvo, double valor_medido, double dt)
{
   if (dt <= 0.0)
      return 0.0;

   double error = alvo - valor_medido;

   // Integral com anti-windup
   integral += error * dt;
   if (integral > integral_max)
      integral = integral_max;
   else if (integral < integral_min)
      integral = integral_min;

   // Derivada filtrada
   double derivada = (error - prev_error) / dt;
   derivative_filtered = alpha * derivada + (1.0 - alpha) * derivative_filtered;

   // Feedforward
   double feedforward = kff * alvo;

   double output = kp * (beta * alvo - valor_medido) +
                   ki * integral +
                   kd * derivative_filtered +
                   feedforward;

   // Slew rate limiter
   double delta_output = output - prev_output;
   double max_delta = max_slew_rate * dt;

   if (delta_output > max_delta)
      output = prev_output + max_delta;
   else if (delta_output < -max_delta)
      output = prev_output - max_delta;

   prev_error = error;
   prev_output = output;

   return output;
}

// ===================== RESET =====================

void PID::reset()
{
   integral = 0.0;
   prev_error = 0.0;
   derivative_filtered = 0.0;
   prev_output = 0.0;
}