#include "utils/Diag.hpp"
#include "utils/MathUtils.hpp"

namespace utils {

double clampd(double value, double min_val, double max_val) {
   if (value > max_val) return max_val;
   if (value < min_val) return min_val;
   return value;
}

double pi_interval(double angle) {
   while (angle > M_PI) angle -= 2.0 * M_PI;
   while (angle < -M_PI) angle += 2.0 * M_PI;
   return angle;
}

bool periodicDue(double t, double last_t, double period_s) {
   return last_t < 0.0 || (t - last_t) >= period_s;
}

double webotsYawToRos(double yaw_webots) {
   return pi_interval(yaw_webots + M_PI_2);
}

double rosYawToWebots(double yaw_ros) {
   return pi_interval(yaw_ros - M_PI_2);
}

bool envFlagEnabled(const char* name, bool default_value) {
   const char* raw = std::getenv(name);
   if (raw == nullptr) {
      return default_value;
   }

   const std::string value(raw);
   return value == "1" || value == "true" || value == "TRUE" ||
      value == "yes" || value == "YES" || value == "on" || value == "ON";
}

double envDouble(const char* name, double default_value) {
   const char* raw = std::getenv(name);
   if (raw == nullptr) {
      return default_value;
   }

   try {
      return std::stod(raw);
   } catch (const std::exception&) {
      diag::log(
         diag::Level::Warn,
         "[MAIN] Ignorando valor inválido para ",
         name,
         "='",
         raw,
         "'"
      );
      return default_value;
   }
}

std::string numberText(double value, int precision) {
   if (!std::isfinite(value)) {
      return "none";
   }

   std::ostringstream oss;
   oss << std::fixed << std::setprecision(precision) << value;
   return oss.str();
}

std::string boolText(bool value) {
   return value ? "true" : "false";
}

std::string sanitizedValue(const std::string& value) {
   if (value.empty()) {
      return "none";
   }

   std::string out = value;
   for (char& ch : out) {
      if (std::isspace(static_cast<unsigned char>(ch))) {
         ch = '_';
      }
   }
   return out;
}

} // namespace utils
