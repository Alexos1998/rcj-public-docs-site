#include "mapping/WheelOdometry.hpp"

#include <algorithm>
#include <limits>

WheelOdometry::WheelOdometry(double wheel_radius_m, double wheel_base_m)
: wheel_radius_m_(wheel_radius_m),
  wheel_base_m_(wheel_base_m)
{
}

void WheelOdometry::reset(double x, double y, double yaw_ros)
{
    pose_.x = x;
    pose_.y = y;
    pose_.yaw = wrapPi(yaw_ros);

    last_left_encoder_rad_ = 0.0;
    last_right_encoder_rad_ = 0.0;
    last_yaw_ros_ = pose_.yaw;
    last_gps_x_ = x;
    last_gps_y_ = y;

    initialized_ = false;
}

WheelOdomPose WheelOdometry::pose() const
{
    return pose_;
}

WheelOdomUpdate WheelOdometry::update(
    double left_encoder_rad,
    double right_encoder_rad,
    double yaw_ros,
    double gps_x,
    double gps_y,
    double gps_speed_mps,
    double cmd_v,
    double cmd_w,
    double front_clearance_m,
    double dt_s)
{
    WheelOdomUpdate out;
    out.pose = pose_;
    out.dt_s = dt_s;

    if (dt_s <= 0.0 || !std::isfinite(dt_s)) {
        return out;
    }

    yaw_ros = wrapPi(yaw_ros);

    if (!initialized_) {
        last_left_encoder_rad_ = left_encoder_rad;
        last_right_encoder_rad_ = right_encoder_rad;
        last_yaw_ros_ = yaw_ros;
        last_gps_x_ = gps_x;
        last_gps_y_ = gps_y;

        pose_.x = gps_x;
        pose_.y = gps_y;
        pose_.yaw = yaw_ros;

        out.pose = pose_;
        initialized_ = true;
        return out;
    }

    const double d_left_m =
        (left_encoder_rad - last_left_encoder_rad_) * wheel_radius_m_;
    const double d_right_m =
        (right_encoder_rad - last_right_encoder_rad_) * wheel_radius_m_;

    last_left_encoder_rad_ = left_encoder_rad;
    last_right_encoder_rad_ = right_encoder_rad;

    const double ds_m = 0.5 * (d_left_m + d_right_m);

    const double d_yaw_rad = wrapPi(yaw_ros - last_yaw_ros_);
    last_yaw_ros_ = yaw_ros;

    double vx = ds_m / dt_s;
    double wz = d_yaw_rad / dt_s;

    // Limites físicos aproximados para filtrar saltos absurdos.
    vx = clamp(vx, -0.14, 0.14);
    wz = clamp(wz, -6.0, 6.0);

    bool slip_suspected = false;

    // Detecção simples: encoders/cmd indicam avanço, GPS quase parado,
    // e LiDAR indica parede próxima à frente.
    const bool front_blocked =
        std::isfinite(front_clearance_m) && front_clearance_m < 0.040;

    if (
        cmd_v > 0.02 &&
        vx > 0.015 &&
        gps_speed_mps < 0.006 &&
        front_blocked)
    {
        slip_suspected = true;
    }

    // Por enquanto, NÃO corrigimos a pose. Só reportamos slip.
    // Depois podemos decidir se zera ds_m quando slip_suspected=true.
    const double integration_ds = ds_m;

    pose_.yaw = yaw_ros;
    pose_.x += integration_ds * std::cos(pose_.yaw);
    pose_.y += integration_ds * std::sin(pose_.yaw);

    last_gps_x_ = gps_x;
    last_gps_y_ = gps_y;

    out.pose = pose_;
    out.vx = vx;
    out.wz = wz;
    out.d_left_m = d_left_m;
    out.d_right_m = d_right_m;
    out.ds_m = ds_m;
    out.d_yaw_rad = d_yaw_rad;
    out.valid = true;
    out.slip_suspected = slip_suspected;

    return out;
}

double WheelOdometry::wrapPi(double angle)
{
    while (angle > M_PI) {
        angle -= 2.0 * M_PI;
    }
    while (angle < -M_PI) {
        angle += 2.0 * M_PI;
    }
    return angle;
}

double WheelOdometry::clamp(double value, double min_value, double max_value)
{
    return std::max(min_value, std::min(value, max_value));
}