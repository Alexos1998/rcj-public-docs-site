#pragma once

#include <webots/Camera.hpp>
#include <webots/GPS.hpp>
#include <webots/InertialUnit.hpp>
#include <webots/Lidar.hpp>
#include <webots/Motor.hpp>
#include <webots/PositionSensor.hpp>
#include <string>

void printStartupSensorInfo(
   int timeStep,
   double dt,
   double wheel_radius,
   double axle_length,
   double max_motor_speed,
   double max_linear_vel,
   double max_angular_vel,
   webots::Motor* wheel_left,
   webots::Motor* wheel_right,
   webots::PositionSensor* left_encoder,
   webots::PositionSensor* right_encoder,
   webots::Lidar* lidar,
   int lidar_h,
   webots::GPS* gps,
   webots::InertialUnit* inertial_unit,
   webots::Camera* came,
   webots::Camera* camd,
   webots::Camera* color_sensor,
   double state_period_s,
   double scan_period_s,
   double color_period_s,
   double camera_period_s
);
