#pragma once

#include <chrono>
#include <cstddef>
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

#include "exploration_legacy/reachability.hpp"
#include "localization/Localizer2D.hpp"

struct Pose2D {
    double x = 0.0;
    double y = 0.0;
    double th = 0.0;
};

struct CmdVel {
    double v = 0.0;
    double w = 0.0;
};

struct GpsLocal {
    double x;
    double y;
    double z;
};

class BridgeClient {
public:
    bool connect();
    void sendScan(const std::vector<float>& scan);
    void sendImu(double roll, double pitch, double yaw);
    void sendGps(const GpsLocal& fix);
    void sendTime(double t);

    void sendWheelOdom(
        double x,
        double y,
        double yaw,
        double vx,
        double wz,
        bool slip_suspected);

    void sendLocalization(const localization::LocalizerState& state);

    void sendColorClassification(const std::string& color_class,
                                int r,
                                int g,
                                int b,
                                double confidence);

    void sendHoleDetection(
        double x,
        double y,
        double yaw,
        const std::string& source,
        double confidence,
        const std::string& legacy_direction,
        int legacy_current_x,
        int legacy_current_y,
        int legacy_target_x,
        int legacy_target_y,
        double requested_distance_m,
        double traveled_before_stop_m);

    void sendVisionDetection(
        const std::string& kind,
        const std::string& class_name,
        const std::string& target_pattern,
        int tile_x,
        int tile_y,
        const std::string& camera,
        double yaw,
        double center_x,
        double image_width,
        double distance_m,
        double confidence);

    void sendCameraFrame(const std::string& name,
                         double t,
                         int width,
                         int height,
                         double fov,
                         const unsigned char* bgra,
                         std::size_t size);

    bool receiveCmdVel(CmdVel& cmd);
    bool receivePose(Pose2D& pose);
    bool receiveSubmissionMatrix(std::string& matrix_text);

    exploration_legacy::ReachabilityResult requestLegacyReachability(
        const exploration_legacy::Pose2D& start,
        double goal_x_m,
        double goal_y_m,
        const std::vector<exploration_legacy::PathCandidate>& candidates,
        std::chrono::milliseconds timeout);
private:
    int sock_ = -1;

    std::string incoming_buffer_;
    std::string cmd_buffer_;
    std::string pose_buffer_;
    CmdVel pending_cmd_;
    bool has_pending_cmd_ = false;

    Pose2D pending_pose_;
    bool has_pending_pose_ = false;

    std::string latest_submission_matrix_;
    bool has_submission_matrix_ = false;

    std::uint64_t next_reachability_request_id_ = 1;
    std::unordered_map<std::uint64_t, exploration_legacy::ReachabilityResult>
        pending_reachability_responses_;

    std::chrono::steady_clock::time_point last_reconnect_attempt_{};
    bool has_reconnect_attempt_ = false;   
    static std::string hexEncode(const unsigned char* data, std::size_t size);
    bool connectOnce(bool log_success, bool log_failure);
    bool shouldAttemptReconnect();
    void closeSocket();
    void sendAll(const std::string& msg);
    void pollIncoming();
};
