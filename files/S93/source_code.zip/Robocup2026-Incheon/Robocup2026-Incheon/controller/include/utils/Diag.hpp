#pragma once

#include <chrono>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

namespace diag {

enum class Level { Error = 0, Warn = 1, Info = 2, Debug = 3, Trace = 4 };

// Troque para Info quando quiser menos ruído.
// Depois vamos transformar isso em variável de ambiente.
inline constexpr Level kLevel = Level::Info;

inline const char* name(Level lvl) {
    switch (lvl) {
        case Level::Error: return "ERROR";
        case Level::Warn:  return "WARN";
        case Level::Info:  return "INFO";
        case Level::Debug: return "DEBUG";
        case Level::Trace: return "TRACE";
    }
    return "LOG";
}

inline std::string timestampLocal() {
    using namespace std::chrono;

    const auto now = system_clock::now();
    const auto sec = time_point_cast<seconds>(now);
    const auto ms = duration_cast<milliseconds>(now - sec).count();

    const std::time_t tt = system_clock::to_time_t(now);

    std::tm tm{};
    localtime_r(&tt, &tm);

    std::ostringstream oss;
    oss << std::put_time(&tm, "%Y-%m-%dT%H:%M:%S")
        << "."
        << std::setw(3)
        << std::setfill('0')
        << ms;

    return oss.str();
}

template <typename... Args>
inline void log(Level lvl, Args&&... args) {
    if (static_cast<int>(lvl) > static_cast<int>(kLevel)) {
        return;
    }

    std::ostringstream msg;
    (msg << ... << args);

    std::cout
        << timestampLocal()
        << " level=" << name(lvl)
        << " "
        << msg.str()
        << std::endl;
}

inline double now_ms() {
    using clock = std::chrono::steady_clock;
    return std::chrono::duration<double, std::milli>(
        clock::now().time_since_epoch()
    ).count();
}

}  // namespace diag