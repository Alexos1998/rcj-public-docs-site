#pragma once

#include <cmath>
#include <cstdlib>
#include <iomanip>
#include <limits>
#include <sstream>
#include <string>

namespace utils {

double clampd(double value, double min_val, double max_val);
double pi_interval(double angle);
bool periodicDue(double t, double last_t, double period_s);
double webotsYawToRos(double yaw_webots);
double rosYawToWebots(double yaw_ros);
bool envFlagEnabled(const char* name, bool default_value = false);
double envDouble(const char* name, double default_value);
std::string numberText(double value, int precision = 4);
std::string boolText(bool value);
std::string sanitizedValue(const std::string& value);

} // namespace utils
