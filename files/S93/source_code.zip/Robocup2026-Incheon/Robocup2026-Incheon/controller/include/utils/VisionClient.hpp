#pragma once

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

struct VisionClientConfig {
    std::string host = "127.0.0.1";
    int frame_port = 5100;
    int result_port = 5101;
    int send_every_n = 2;
    std::string image_encoding = "BGR8";
    float left_yaw_offset_rad = 1.57079632679f;
    float right_yaw_offset_rad = -1.57079632679f;
};

struct VisionFrameMetadata {
    std::uint64_t seq = 0;
    double stamp_s = 0.0;
    int camera_id = 0;
    float camera_hfov_rad = 1.0f;
    float camera_vfov_rad = 1.0f;
    float camera_yaw_offset_rad = 0.0f;
    float robot_x = 0.0f;
    float robot_y = 0.0f;
    float robot_yaw = 0.0f;
    int tile_x = 0;
    int tile_y = 0;
    float lidar_angle_min = -3.14159265f;
    float lidar_angle_increment = 0.0f;
    float lidar_range_min = 0.01f;
    float lidar_range_max = 1.0f;
};

class VisionClient {
public:
    explicit VisionClient(VisionClientConfig config);
    ~VisionClient();

    VisionClient(const VisionClient&) = delete;
    VisionClient& operator=(const VisionClient&) = delete;

    void start();
    void stop();

    void enqueueBgraFrame(const VisionFrameMetadata& metadata,
                          int width,
                          int height,
                          const unsigned char* bgra,
                          const std::vector<float>& scan);

    std::vector<std::string> pollResults();
    int sendEveryN() const { return send_every_n_; }
    bool frameConnected() const { return frame_connected_.load(); }
    bool resultConnected() const { return result_connected_.load(); }

private:
    struct PendingFrame {
        std::vector<std::uint8_t> bytes;
    };

    void senderLoop();
    bool connectFrameSocket();
    bool connectResultSocket();
    bool sendPending(const PendingFrame& frame);
    void closeFrameSocket();
    void closeResultSocket();
    bool shouldReconnect(std::chrono::steady_clock::time_point& last_attempt);

    VisionClientConfig config_;
    int send_every_n_ = 2;
    int frame_sock_ = -1;
    int result_sock_ = -1;
    std::atomic<bool> frame_connected_{false};
    std::atomic<bool> result_connected_{false};
    std::atomic<bool> running_{false};
    std::thread sender_;
    std::mutex mutex_;
    std::condition_variable cv_;
    // One latest-frame slot per camera_id. A single shared slot lets the second
    // camera enqueued in a control step clobber the first before the sender
    // thread wakes -- which silently dropped the left camera. Keyed per camera so
    // both survive while still keeping only the most recent frame per camera.
    std::map<int, PendingFrame> latest_by_camera_;
    std::chrono::steady_clock::time_point last_frame_reconnect_{};
    std::chrono::steady_clock::time_point last_result_reconnect_{};
    std::string result_buffer_;
};
