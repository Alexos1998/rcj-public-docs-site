#ifndef PID_HPP
#define PID_HPP

class PID
{
private:
   double kp, ki, kd;
   double prev_error, integral;

   // Parâmetros opcionais
   double kff;
   double beta;
   double derivative_filtered;
   double alpha;
   double integral_min;
   double integral_max;
   double prev_output;
   double max_slew_rate;

   void setDefaults();

public:
   PID(double kp, double ki, double kd);

   void setFeedforward(double kff_);
   void setBeta(double beta_);
   void setAlpha(double alpha_);
   void setIntegralLimits(double min, double max);
   void setMaxSlewRate(double max_rate);

   double calcular(double alvo, double valor_medido, double dt);

   void reset();
};

#endif