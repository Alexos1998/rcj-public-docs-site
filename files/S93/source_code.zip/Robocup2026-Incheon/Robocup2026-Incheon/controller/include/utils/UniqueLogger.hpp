#pragma once

#include <fstream>
#include <mutex>
#include <ostream>
#include <string>

namespace utils {

// Logger dedicado que escreve em um arquivo próprio (unique.log), separado do
// stdout do controller (que o Ros.sh redireciona para controller.log).
//
// Uso, no estilo std::cout:
//
//    utils::uniqueLogger() << "ola mundo com o uniquelogger" << std::endl;
//
// O caminho do arquivo vem da env UNIQUE_LOG_PATH (exportada por start.sh/Ros.sh);
// se ausente, cai no default kDefaultPath. O arquivo é aberto em modo append,
// pois os scripts já truncam o unique.log no início de cada execução.
class UniqueLogger {
public:
   static constexpr const char* kDefaultPath =
      "/tmp/controller-logs/latest/unique.log";

   explicit UniqueLogger(const std::string& path);

   // Streaming genérico (strings, números, etc.).
   template <typename T>
   UniqueLogger& operator<<(const T& value) {
      std::lock_guard<std::mutex> lock(mutex_);
      if (stream_.is_open()) {
         stream_ << value;
      }
      return *this;
   }

   // Suporte a manipuladores como std::endl e std::flush.
   UniqueLogger& operator<<(std::ostream& (*manip)(std::ostream&)) {
      std::lock_guard<std::mutex> lock(mutex_);
      if (stream_.is_open()) {
         manip(stream_);
      }
      return *this;
   }

   bool isOpen() const { return stream_.is_open(); }
   const std::string& path() const { return path_; }

private:
   std::string path_;
   std::ofstream stream_;
   std::mutex mutex_;
};

// Instância global compartilhada, inicializada a partir de UNIQUE_LOG_PATH.
UniqueLogger& uniqueLogger();

} // namespace utils
