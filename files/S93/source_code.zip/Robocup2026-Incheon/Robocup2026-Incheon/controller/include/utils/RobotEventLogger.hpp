#pragma once

#include <string>
#include <utility>
#include <vector>
#include "utils/Diag.hpp"

namespace utils {

using RobotEventFields = std::vector<std::pair<std::string, std::string>>;

void logRobotEvent(
   diag::Level level,
   const std::string& event,
   const RobotEventFields& fields = {}
);

void logRobotEvent(
   const std::string& event,
   const RobotEventFields& fields = {}
);

void logRobotTerminalEvent(
   diag::Level level,
   const std::string& event,
   const RobotEventFields& fields = {}
);

void logRobotTerminalEvent(
   const std::string& event,
   const RobotEventFields& fields = {}
);

} // namespace utils