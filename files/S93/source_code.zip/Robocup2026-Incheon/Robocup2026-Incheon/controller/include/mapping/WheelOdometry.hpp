#pragma once

#include <cmath>

struct WheelOdomPose {
    double x = 0.0;
    double y = 0.0;
    double yaw = 0.0;
};

struct WheelOdomUpdate {
    WheelOdomPose pose;

    double vx = 0.0;
    double wz = 0.0;

    double d_left_m = 0.0;
    double d_right_m = 0.0;
    double ds_m = 0.0;
    double d_yaw_rad = 0.0;
    double dt_s = 0.0;

    bool valid = false;
    bool slip_suspected = false;
};

class WheelOdometry {
public:
    WheelOdometry(double wheel_radius_m, double wheel_base_m);

    void reset(double x, double y, double yaw_ros);

    WheelOdomUpdate update(
        double left_encoder_rad,
        double right_encoder_rad,
        double yaw_ros,
        double gps_x,
        double gps_y,
        double gps_speed_mps,
        double cmd_v,
        double cmd_w,
        double front_clearance_m,
        double dt_s);

    WheelOdomPose pose() const;

private:
    static double wrapPi(double angle);
    static double clamp(double value, double min_value, double max_value);

    double wheel_radius_m_;
    double wheel_base_m_;

    WheelOdomPose pose_{};

    double last_left_encoder_rad_ = 0.0;
    double last_right_encoder_rad_ = 0.0;
    double last_yaw_ros_ = 0.0;
    double last_gps_x_ = 0.0;
    double last_gps_y_ = 0.0;

    bool initialized_ = false;
};