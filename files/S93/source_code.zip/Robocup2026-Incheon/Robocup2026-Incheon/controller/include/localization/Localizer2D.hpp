#pragma once

namespace localization {

struct LocalizerConfig {
    double wheel_radius_m = 0.02;
    double wheel_base_m = 0.052;

    double gps_alpha = 0.10;
    double gps_gate_m = 0.040;
    double gps_hard_reject_m = 0.120;

    double min_dt_s = 1e-5;
    double max_dt_s = 0.200;

    double max_abs_vx_mps = 0.20;
    double max_abs_wz_radps = 8.0;

    double gps_sigma_m = 0.005;
    double yaw_sigma_rad = 0.01;
    double wheel_vx_sigma_mps = 0.02;
    double wheel_wz_sigma_radps = 0.05;

    double max_position_cov = 0.010;
    double encoder_jump_multiplier = 3.0;
    double encoder_jump_extra_m = 0.005;

    bool use_gps_correction = true;
    bool freeze_translation_on_slip = false;
};

struct LocalizerInput {
    double stamp_s = 0.0;

    double left_encoder_rad = 0.0;
    double right_encoder_rad = 0.0;

    double imu_yaw_ros_rad = 0.0;

    bool has_gps = false;
    double gps_x_m = 0.0;
    double gps_y_m = 0.0;
    double gps_z_m = 0.0;
    double gps_speed_mps = 0.0;

    double cmd_v_mps = 0.0;
    double cmd_w_radps = 0.0;

    bool has_front_clearance = false;
    double front_clearance_m = 0.0;
};

struct LocalizerState {
    bool initialized = false;
    double stamp_s = 0.0;

    double x_m = 0.0;
    double y_m = 0.0;
    double z_m = 0.0;
    double yaw_rad = 0.0;

    double vx_mps = 0.0;
    double wz_radps = 0.0;

    double d_left_m = 0.0;
    double d_right_m = 0.0;
    double ds_m = 0.0;
    double d_yaw_rad = 0.0;
    double dt_s = 0.0;

    bool gps_used = false;
    bool gps_rejected = false;
    double gps_innovation_m = 0.0;

    bool slip_suspected = false;
    bool encoder_jump_rejected = false;
    bool dt_rejected = false;

    double cov_x = 0.000064;
    double cov_y = 0.000064;
    double cov_yaw = 0.0001;
    double cov_vx = 0.0004;
    double cov_wz = 0.0025;
};

class Localizer2D {
public:
    explicit Localizer2D(LocalizerConfig config);

    void reset(double stamp_s,
               double x_m,
               double y_m,
               double z_m,
               double yaw_rad,
               double left_encoder_rad,
               double right_encoder_rad);

    LocalizerState update(const LocalizerInput& input);

    const LocalizerState& state() const;

private:
    static double wrapPi(double angle);
    static double clamp(double value, double min_value, double max_value);
    static bool finite(double value);

    void refreshNoiseCovariances();
    void updateEncoderBaseline(double left_encoder_rad, double right_encoder_rad);
    void applyGpsCorrection(const LocalizerInput& input, double travelled_m);

    LocalizerConfig config_;
    LocalizerState state_;

    double last_left_encoder_rad_ = 0.0;
    double last_right_encoder_rad_ = 0.0;
    double last_yaw_wrapped_rad_ = 0.0;
    double yaw_unwrapped_rad_ = 0.0;
};

}  // namespace localization
