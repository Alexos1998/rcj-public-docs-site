#pragma once

#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <vector>

#include "ros2_vision/larc_vision_pipeline.hpp"
#include "ros2_vision/onnx_runner.hpp"
#include "ros2_vision/vision_protocol.hpp"

namespace vision_runtime {

// In-process configuration for the vision pipeline. Mirrors the parameters the
// (now removed) ros2_vision node read from vision.yaml / ROS params, but is
// populated directly by the Webots controller. Defaults match the previous node.
struct VisionRuntimeConfig {
    // Model files. Resolved by the caller (absolute or relative to CWD).
    std::string presence_model = "models/presence.onnx";
    std::string type_model = "models/object_type.onnx";
    // Fused none/target/victim model; used only when pipeline.use_fused_object_model.
    std::string object_presence_model = "models/object_presence.onnx";
    std::string victim_bbox_model = "models/victim_bbox.onnx";
    std::string target_bbox_model = "models/target_bbox.onnx";
    std::string victim_cls_model = "models/victim_cls.onnx";
    std::string target_mask_rf_model = "models/target_mask_rf.yml";
    std::string target_mask_feature_config = "models/target_mask_features.yml";

    // ONNX model input sizes (independent of the 64x64 camera frame).
    int presence_input_width = 48;
    int presence_input_height = 48;
    int type_input_width = 32;
    int type_input_height = 32;
    int object_presence_input_width = 48;
    int object_presence_input_height = 48;
    int victim_bbox_input_width = 96;
    int victim_bbox_input_height = 96;
    int target_bbox_input_width = 96;
    int target_bbox_input_height = 96;
    int victim_cls_input_width = 96;
    int victim_cls_input_height = 96;

    // Full pipeline configuration (acceptance gates, lidar, target/victim).
    // Field defaults already match the historical node defaults; callers
    // override only what they expose through env vars.
    ros2_vision::LarcVisionPipeline::Config pipeline;

    // Optional structured-event sink (e.g. RobotEventLogger). May be empty.
    std::function<void(const std::string&)> event_logger;

    // Debug image saving for the in-process runtime.
    std::string debug_image_dir;
    bool save_classification_images = true;
    bool save_rejected_images = true;
    int lidar_window_extra_rays = 2;
};

// Per-frame metadata that accompanies the raw BGRA buffer + lidar scan.
struct VisionFrameMeta {
    std::uint64_t seq = 0;
    double stamp_s = 0.0;
    int camera_id = 0;
    float camera_hfov_rad = 1.0f;
    float camera_vfov_rad = 1.0f;
    float camera_yaw_offset_rad = 0.0f;
    float robot_x = 0.0f;
    float robot_y = 0.0f;
    float robot_yaw = 0.0f;
    int tile_x = 0;
    int tile_y = 0;
    float lidar_angle_min = -3.14159265f;
    float lidar_angle_increment = 0.0f;
    float lidar_range_min = 0.01f;
    float lidar_range_max = 1.0f;
};

// Synchronous, in-process vision runtime. Same shape as localization::Localizer2D:
// a plain class the controller owns and calls per step -- no ROS, no threads, no
// TCP, no frequency throttling. The heavy lifting is delegated to the unchanged
// ros2_vision::LarcVisionPipeline.
class VisionRuntime {
public:
    explicit VisionRuntime(VisionRuntimeConfig config);

    VisionRuntime(const VisionRuntime&) = delete;
    VisionRuntime& operator=(const VisionRuntime&) = delete;

    // True when the target mask RF model loaded (mask-first path active).
    bool ready() const;
    const std::string& targetLoadError() const;

    // Run the full pipeline on one camera frame. `bgra` is the Webots camera
    // buffer (width*height*4, BGRA8). Returns a detection when accepted, or
    // std::nullopt with `reject_reason` set otherwise.
    std::optional<ros2_vision::VisionDetection> process(
        int width,
        int height,
        const unsigned char* bgra,
        const std::vector<float>& scan,
        const VisionFrameMeta& meta,
        std::string& reject_reason);

private:
    void saveVisionDebugImage(const ros2_vision::VisionFrame& frame,
                              const ros2_vision::VisionDebugImage& debug) const;

    VisionRuntimeConfig config_;
    std::unique_ptr<ros2_vision::LarcVisionPipeline> pipeline_;
};

}  // namespace vision_runtime
