#pragma once

#include <cmath>
#include <limits>
#include <string>
#include <vector>

namespace sensors {

struct LidarSectorInfo {
   int index = -1;
   double center_angle_rad = 0.0;
   double min_range_m = std::numeric_limits<double>::infinity();
};

struct LidarVelocityGuardConfig {
   bool enabled = true;
   int sectors = 16;

   // Linear guard:
   // Último fusível físico antes de bater/raspar. A exploração já decide
   // paredes/entradas antes disso; este guard só atua muito perto do contato.
   double hard_stop_m = 0.003;
   double slow_down_m = 0.005;
   double slow_linear_mps = 0.035;

   // Rotation/lateral guard:
   // Mantém proteção lateral contra raspagem/snap, mas menos agressiva.
   bool guard_rotation = true;
   double rotation_hard_stop_m = 0.003;
   double rotation_slow_down_m = 0.005;
   double slow_angular_rad_s = 1.4;

   // Evita que aproximação lateral muito fraca trave avanço normal.
   double min_closing_speed_mps = 0.010;

   bool guard_side_clearance = true;
   double side_hard_stop_m = 0.003;
   double side_slow_down_m = 0.005;
   double side_slow_linear_mps = 0.020;
   double side_slow_angular_rad_s = 1.2;
};

struct LidarVelocityGuardResult {
   double v = 0.0;
   double w = 0.0;
   bool active = false;
   bool linear_clamped = false;
   bool angular_clamped = false;
   std::string reason = "none";
   int sector_index = -1;
   double sector_angle_rad = 0.0;
   double sector_min_range_m = std::numeric_limits<double>::infinity();
   double closing_speed_mps = 0.0;
};

std::vector<LidarSectorInfo> computeLidarSectors(
   const std::vector<float>& scan,
   int sector_count
);

LidarVelocityGuardResult applyLidarVelocityGuard(
   double raw_v,
   double raw_w,
   const std::vector<float>& scan,
   const LidarVelocityGuardConfig& cfg
);

double lidarSectorMinRange(
   const std::vector<float>& scan,
   double center_angle_rad,
   double half_width_rad
);

} // namespace sensors
