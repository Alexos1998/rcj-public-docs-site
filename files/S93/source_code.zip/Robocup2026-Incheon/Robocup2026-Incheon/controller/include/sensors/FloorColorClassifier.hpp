#pragma once

#include <string>
#include <array>
#include <webots/Camera.hpp>

struct FloorColorSample {
   std::string color_class = "UNKNOWN";
   int r = 0;
   int g = 0;
   int b = 0;
   double confidence = 0.0;
};

FloorColorSample classifyFloorColorRgb(int r, int g, int b);
FloorColorSample readColourSensorClassification(webots::Camera* camera);
bool isStrongBlackHoleBrakeSample(const FloorColorSample& sample, double min_confidence);
