#pragma once

#include <webots/Motor.hpp>

namespace control {

struct WheelCommandDiagnostics {
   double raw_v = 0.0;
   double raw_w = 0.0;
   double clamped_v = 0.0;
   double clamped_w = 0.0;
   double angular_sign_applied = -1.0;
   double wl_raw = 0.0;
   double wr_raw = 0.0;
   double wheel_scale = 1.0;
   double wl_final = 0.0;
   double wr_final = 0.0;
   bool saturated = false;
};

void applyBaseVelocity(
   webots::Motor* wheel_left,
   webots::Motor* wheel_right,
   double v,
   double w,
   double wheel_radius,
   double axle_length,
   double max_speed
);

WheelCommandDiagnostics computeWheelCommandDiagnostics(
   double raw_v,
   double raw_w,
   double wheel_radius,
   double axle_length,
   double max_speed,
   double max_linear_vel,
   double max_angular_vel
);

} // namespace control
