#pragma once

namespace safety {

enum class BlackHoleSafetyState {
   Idle,
   BrakeHold,
   ReverseEscape
};

const char* blackHoleSafetyStateName(BlackHoleSafetyState state);

} // namespace safety
