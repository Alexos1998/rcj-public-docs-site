#Robocup Junior Rescue Simulation 2026 - Aguabots

## sobre a competicao

## sobre a equipe

## sobre o robo e seus modulos

### localizacao

### navegacao

### exploracao

### mapeamento

### Visao