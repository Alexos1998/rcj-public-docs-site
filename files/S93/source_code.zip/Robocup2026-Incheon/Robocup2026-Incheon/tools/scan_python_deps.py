import ast,json,os,sys
from pathlib import Path
ignore={".git",".venv","venv","__pycache__",".ipynb_checkpoints","build","dist"}
mapn={"cv2":"opencv-python","sklearn":"scikit-learn","PIL":"pillow","yaml":"pyyaml","bs4":"beautifulsoup4","serial":"pyserial","skimage":"scikit-image","dotenv":"python-dotenv"}
stdlib=set(sys.stdlib_module_names)|{"__future__"}
root=Path(sys.argv[1] if len(sys.argv)>1 else ".").resolve()
local={p.stem for p in root.glob("*.py")}|{p.name for p in root.iterdir() if p.is_dir() and (p/"__init__.py").exists()}
mods=set()
for dp,dn,fs in os.walk(root):
    dn[:]=[d for d in dn if d not in ignore]
    for f in fs:
        path=Path(dp)/f
        if path.suffix not in [".py",".ipynb"]: continue
        try:
            if path.suffix==".ipynb":
                nb=json.loads(path.read_text(encoding="utf-8"))
                code="\n".join("".join(c.get("source","")) for c in nb.get("cells",[]) if c.get("cell_type")=="code")
            else:
                code=path.read_text(encoding="utf-8",errors="ignore")
            tree=ast.parse(code)
        except Exception:
            continue
        for n in ast.walk(tree):
            if isinstance(n,ast.Import):
                for a in n.names: mods.add(a.name.split(".")[0])
            elif isinstance(n,ast.ImportFrom) and n.module and n.level==0:
                mods.add(n.module.split(".")[0])
pkgs=sorted({mapn.get(m,m) for m in mods if m not in stdlib and m not in local and not m.startswith("_")})
Path("requirements_detected.txt").write_text("\n".join(pkgs)+"\n")
print("\n".join(pkgs))
