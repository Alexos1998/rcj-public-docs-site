from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, UltrasonicSensor, ColorDistanceSensor
from pybricks.parameters import Port
from pybricks.tools import wait

Motor_B_Rechts = Motor(Port.B)
Motor_D_Links = Motor(Port.D)
Ultrasonic_C_Voor = UltrasonicSensor(Port.C)
Ultrasonic_A_Rechts = ColorDistanceSensor(Port.A)
Ultrasonic_E_Links = ColorDistanceSensor(Port.E)

while True: # Hoofdlus!
    Afstand_C_Voor = Ultrasonic_C_Voor.distance()
    Afstand_A_Rechts = Ultrasonic_A_Rechts.distance()
    Afstand_E_Links = Ultrasonic_E_Links.distance()
    print(Afstand_C_Voor, Afstand_A_Rechts, Afstand_E_Links)

    # Rechtdoor!
    if Afstand_A_Rechts < 95 and Afstand_E_Links < 95 and Afstand_C_Voor > 100:
        Motor_B_Rechts.run(250)
        Motor_D_Links.run(-250)
        wait(3500)
        Motor_B_Rechts.stop()
        Motor_D_Links.stop()
        wait(5000)

    # Rechts!
    if Afstand_C_Voor < 100 and Afstand_E_Links < 100 and Afstand_A_Rechts > 95:
        Motor_B_Rechts.run(-250)
        Motor_D_Links.run(-250)
        wait(2000)
        Motor_B_Rechts.stop()
        Motor_D_Links.stop()
        wait(5000)

    # Links!
    if Afstand_C_Voor < 100 and Afstand_A_Rechts < 100 and Afstand_E_Links > 95:
        Motor_B_Rechts.run(250)
        Motor_D_Links.run(250)
        wait(2000)
        Motor_B_Rechts.stop()
        Motor_D_Links.stop()
        wait(5000)

    # Doodlopend eind!
    if Afstand_C_Voor < 100 and Afstand_A_Rechts < 100 and Afstand_E_Links < 100:
        Motor_B_Rechts.run(-250)
        Motor_D_Links.run(-250)
        wait(2000)
        Motor_B_Rechts.stop()
        Motor_D_Links.stop()
        wait(5000)
        Motor_B_Rechts.run(-250)
        Motor_D_Links.run(-250)
        wait(2000)
        Motor_B_Rechts.stop()
        Motor_D_Links.stop()
        wait(5000)

    # T-splitsing! --> Rechts!
    if Afstand_C_Voor < 100 and Afstand_A_Rechts > 95 and Afstand_E_Links > 95:
        Motor_B_Rechts.run(-250)
        Motor_D_Links.run(-250)
        wait(2000)
        Motor_B_Rechts.stop()
        Motor_D_Links.stop()
        wait(5000)

    # Open plek! --> Links!
    if Afstand_C_Voor > 100 and Afstand_A_Rechts > 95 and Afstand_E_Links > 95:
        Motor_B_Rechts.run(250)
        Motor_D_Links.run(250)
        wait(2000)
        Motor_B_Rechts.stop()
        Motor_D_Links.stop()
        wait(5000)
        Motor_B_Rechts.run(250)
        Motor_D_Links.run(-250)
        wait(3500)
        Motor_B_Rechts.stop()
        Motor_D_Links.stop()
        wait(5000)

    # Rechtdoor 1!
    if Afstand_C_Voor > 100 and Afstand_A_Rechts < 100 and Afstand_E_Links > 95:
        Motor_B_Rechts.run(250)
        Motor_D_Links.run(-250)
        wait(3500)
        Motor_B_Rechts.stop()
        Motor_D_Links.stop()
        wait(5000)

    # Rechtdoor 2!
    if Afstand_C_Voor > 100 and Afstand_A_Rechts > 95 and Afstand_E_Links < 100:
        Motor_B_Rechts.run(250)
        Motor_D_Links.run(-250)
        wait(3500)
        Motor_B_Rechts.stop()
        Motor_D_Links.stop()
        wait(5000)

    
        




