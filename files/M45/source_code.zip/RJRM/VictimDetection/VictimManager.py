import LetterDetection as LDtect
import CircleDetection as CDtect