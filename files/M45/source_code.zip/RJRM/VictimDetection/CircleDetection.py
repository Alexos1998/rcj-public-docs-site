import cv2
import numpy as np

camera = cv2.VideoCapture(0)

while True:
    ret, frame = camera.read()
    if not ret:
        print("Fahhh")
        continue
        
    grayFrame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # 1. FIX THE TEXTURE NOISE: Aggressive Blurring
    # Increased to a 9x9 Gaussian blur to completely melt away fine details like knuckles and skin folds
    blurredFrame = cv2.GaussianBlur(grayFrame, (9, 9), 2)
    
    # 2. STRENGTHEN THE FILTER CRITERIA
    houghFrame = cv2.HoughCircles(
        blurredFrame, 
        cv2.HOUGH_GRADIENT, 
        dp=1.2,          # Sightly increased to scale down the accumulator resolution (fewer false centers)
        minDist=100,     # Increased to 100 pixels. A finger can no longer hold multiple circle centers.
        param1=100,      # Increased from 80. Strictly filters out weaker edges.
        param2=45,       # Increased from 30. The higher this is, the more "perfect" the circle must be to register.
        minRadius=25,    # CRITICAL: Added a minimum radius so tiny background/finger artifacts are ignored.
        maxRadius=400
    )
    
    if houghFrame is not None:
        circles = houghFrame[0, :]
        
        # Sort by radius (descending) to process largest outermost rings first
        circles = circles[np.argsort(circles[:, 2])[::-1]]
        
        filtered_circles = []
        
        for current in circles:
            cx, cy, cr = current[0], current[1], current[2]
            is_inner_ring = False
            
            for accepted in filtered_circles:
                ax, ay, ar = accepted[0], accepted[1], accepted[2]
                center_distance = np.sqrt((cx - ax)**2 + (cy - ay)**2)
                
                # If centers are within 50 pixels of each other, suppress the smaller one
                if center_distance < 50:  
                    is_inner_ring = True
                    break
            
            if not is_inner_ring:
                filtered_circles.append(current)

        # Draw the clean, surviving circles
        for circle in filtered_circles:
            x, y, r = int(circle[0]), int(circle[1]), int(circle[2])
            cv2.circle(frame, (x, y), r, (0, 255, 0), 2)
            cv2.circle(frame, (x, y), 2, (0, 0, 255), 3)

    cv2.imshow("CircleDetect", frame)
    
    val = cv2.waitKey(1)
    if (val & 0xFF) == ord('q') or (val & 0xFF) == ord('Q'):
        break

camera.release()
cv2.destroyAllWindows()