import cv2
import numpy as np
import sys

# ──────────────────────────────────────────────
# CONFIGURATION
# ──────────────────────────────────────────────
MIN_CONTOUR_AREA = 1200    # Minimum pixel size (filters small dust/noise)
MAX_CONTOUR_AREA = 80000   # Maximum pixel size (filters huge wall segments)

def preprocess_image(frame):
    """Isolates dark wall markers into solid white silhouettes."""
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) if frame.ndim == 3 else frame
    
    # Adaptive thresholding strip away lighting gradients and shadows
    thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                   cv2.THRESH_BINARY_INV, 31, 15)
    
    kernel = np.ones((3,3), np.uint8)
    return cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=1)

def classify_shape(roi):
    """
    Validates if the shape matches a known Greek letter structure.
    Returns (label, color) or (None, None) if it's junk/noise.
    """
    h, w = roi.shape
    
    # 1. VALIDATION STEP: Density Check (Fill Ratio)
    # A true letter vector occupies a very specific amount of space inside its box.
    # If the box is solid black/white or mostly empty, skip it.
    total_pixels = h * w
    white_pixels = cv2.countNonZero(roi)
    fill_ratio = white_pixels / total_pixels
    
    # Phi, Psi, and Omega usually occupy between 20% and 45% of their bounding box.
    if fill_ratio < 0.18 or fill_ratio > 0.50:
        return None, None

    # Normalize to a fixed grid for structural zone validation
    norm = cv2.resize(roi, (30, 30))
    
    # 2. FEATURE EXTRACTION
    # Center Column (The "Stem" check)
    center_strip = norm[:, 12:18] 
    center_fill = np.mean(center_strip) / 255.0
    
    # Bottom Corners (The "Legs" check)
    bottom_left  = norm[22:30, 0:8]
    bottom_right = norm[22:30, 22:30]
    bottom_fill = (np.mean(bottom_left) + np.mean(bottom_right)) / 2.0 / 255.0
    
    # Top Center (To differentiate open top shapes like Psi/Omega from closed Phi)
    top_center = norm[0:8, 10:20]
    top_center_fill = np.mean(top_center) / 255.0

    middle_left = norm[8:22, 0:8]
    middle_right = norm[8:22, 22:30]

    mid_left_fill = np.mean(middle_left) / 255.0
    mid_right_fill = np.mean(middle_right) / 255.0
    # 3. STRICT DECISION TREE
    # Phi validation: Has stem, filled top center, filled bottom corners
    if center_fill > 0.50 and top_center_fill > 0.40 and bottom_fill > 0.10:
        return "Phi", (0, 255, 255) # Yellow
        
    # Psi validation: Has stem, open/low-fill top center, completely empty bottom corners
    elif center_fill > 0.50 and top_center_fill < 0.35 and bottom_fill < 0.06:
        return "Psi", (0, 165, 255) # Orange
        
    # Omega validation: No central stem, open top center, weighted bottom feet
    elif (center_fill < 0.30 and
    top_center_fill < 0.20 and
    bottom_fill > 0.10 and
    mid_left_fill > 0.15 and
    mid_right_fill > 0.15):
        return "Omega", (255, 0, 0)
        
    # If it fails to tightly fit one of these structural descriptions, ignore it.
    return None, None

def process_frame(frame):
    clean = preprocess_image(frame)
    contours, _ = cv2.findContours(clean, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    detected_victim = False
    
    for cnt in contours:
        area = cv2.contourArea(cnt)
        if not (MIN_CONTOUR_AREA < area < MAX_CONTOUR_AREA):
            continue
            
        x, y, w, h = cv2.boundingRect(cnt)
        
        # Aspect Ratio Validation (Victims are uniformly square-ish, wall lines are stretched)
        aspect_ratio = float(w) / h
        if aspect_ratio < 0.6 or aspect_ratio > 1.4:
            continue 
            
        # Run classification on the valid candidate region
        roi = clean[y:y+h, x:x+w]
        label, color = classify_shape(roi)
        
        if label:
            detected_victim = True
            cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
            cv2.putText(frame, label, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, color, 2)

    # Global status overlay
    status_text = "VICTIM DETECTED" if detected_victim else "Searching..."
    status_color = (0, 255, 0) if detected_victim else (0, 0, 255)
    cv2.putText(frame, status_text, (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.0, status_color, 2)

    return frame

# ──────────────────────────────────────────────
# LIVE FEED LOOP
# ──────────────────────────────────────────────
if __name__ == "__main__":
    cap = cv2.VideoCapture(0)
    
    while True:
        ret, frame = cap.read()
        if not ret: 
            break
        
        output_frame = process_frame(frame)
        cv2.imshow("RoboCup Junior Rescue Maze 2026 Vision", output_frame)
        
        val=(cv2.waitKey(1))
        if  (val & 0xFF) == ord('q') or (val & 0xFF) == ord('Q'):
            break
            
    cap.release()
    cv2.destroyAllWindows()
