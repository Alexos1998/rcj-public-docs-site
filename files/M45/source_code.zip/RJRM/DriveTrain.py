import periphery as perpy
import time

class DriveTrain:
    def __init__(self):
        # 4 unique hardware PWM channels for your dual BTS7960 drivers
        self.left_fwd  = perpy.PWM(3, 0)   
        self.left_rev  = perpy.PWM(4, 0)
        self.right_fwd = perpy.PWM(5, 0)
        self.right_rev = perpy.PWM(6, 0)
               
        # Set 20 kHz frequency (0.00005s period) for silent operation
        PERIOD_20KHZ = 1.0 / 20000
        
        for pwm_channel in [self.left_fwd, self.left_rev, self.right_fwd, self.right_rev]:
            pwm_channel.period = PERIOD_20KHZ        # type: ignore
            pwm_channel.duty_cycle = 0.0             # type: ignore
            pwm_channel.enable()
            
        # Physical speed limits for your ~30 cm/s target
        self.MIN_DUTY = 0.15
        self.MAX_DUTY = 1

    def _calculate_duty(self, speed_input):
        """Helper to map a 0.0 to 1.0 speed value into physical limits"""
        if abs(speed_input) < 0.05:  # Deadzone cleanup
            return 0.0
        return self.MIN_DUTY + (abs(speed_input) * (self.MAX_DUTY - self.MIN_DUTY))

    def set_speeds(self, left_speed, right_speed):
        """
        Accepts values from -1.0 (Full Reverse) to 1.0 (Full Forward).
        """
        # --- LEFT WHEEL CONTROL ---
        if left_speed >= 0:
            self.left_fwd.duty_cycle = self._calculate_duty(left_speed)
            self.left_rev.duty_cycle = 0.0  # Keep reverse channel completely off
        else:
            self.left_fwd.duty_cycle = 0.0  # Keep forward channel completely off
            self.left_rev.duty_cycle = self._calculate_duty(left_speed)
        # --- RIGHT WHEEL CONTROL ---
        if right_speed >= 0:
            self.right_fwd.duty_cycle = self._calculate_duty(right_speed)
            self.right_rev.duty_cycle = 0.0  # Keep reverse channel completely off
        else:
            self.right_fwd.duty_cycle = 0.0  # Keep forward channel completely off
            self.right_rev.duty_cycle = self._calculate_duty(right_speed)
    def stop(self):
        self.set_speeds(0.0, 0.0)
driver=DriveTrain()
while True:
	time.sleep(6)
	driver.set_speeds(0, 0)
	time.sleep(5)
	driver.set_speeds(-0.9, -0.9)
