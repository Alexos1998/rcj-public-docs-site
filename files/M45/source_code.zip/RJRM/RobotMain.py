from Robot import robot

while True:
    robot.drive_train.set_speeds(1, 1)
    if not robot.tof_right.wall_exist():
        robot.turn_right()
        init_val=robot.tof_front.read()
        while(robot.tof_front.read()+300)>init_val:
            robot.drive_train.set_speeds(0.5, 0.5)
        
        #Move 30 cm minimum to avoid loops

    elif not robot.tof_front.wall_exist():
        continue
    elif not robot.tof_left.wall_exist():
        robot.turn_left()
    else:
        robot.turn_left()
        robot.turn_left()
