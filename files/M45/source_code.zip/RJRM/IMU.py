import time
import os

# Force Blinka to recognize the board as the Orange Pi 5 Plus
os.environ["BLINKA_FORCEBOARD"] = "ORANGE_PI_5_PLUS"

import math
import board
import busio

# Now import board and busio safely
print(f"Blinka successfully forced to: {os.environ['BLINKA_FORCEBOARD']}")
print(f"Board detected as: {board.board_id}")


from adafruit_bno08x.i2c import BNO08X_I2C
from adafruit_bno08x import BNO_REPORT_ROTATION_VECTOR


class IMU:

    def __init__(self, delay=0.01):

        self.delay = delay

        self.i2c = busio.I2C(scl=board.I2C8_SCL, sda=board.I2C8_SDA)
        
        # IMU direkt bağlı
        self.sensor = BNO08X_I2C(self.i2c)

        self.sensor.enable_feature(BNO_REPORT_ROTATION_VECTOR)

        time.sleep(0.2)  # IMU stabilize

    def read(self):

        time.sleep(self.delay)

        qi, qj, qk, qr = self.sensor.quaternion

        # Yaw
        yaw = math.atan2(
            2.0 * (qr * qk + qi * qj),
            1.0 - 2.0 * (qj * qj + qk * qk)
        )

        # Pitch
        sinp = 2.0 * (qr * qj - qk * qi)

        if abs(sinp) >= 1:
            pitch = math.copysign(math.pi / 2, sinp)
        else:
            pitch = math.asin(sinp)

        yaw = math.degrees(yaw)
        pitch = math.degrees(pitch)

        if yaw < 0:
            yaw += 360

        return yaw, pitch

"""
data_reader=IMU()

print("Reading IMU data... Press Ctrl+C to stop.")

try:
    while True:
        yaw, pitch = data_reader.read()
        
        # Using \r carriage return keeps the print on a single updating line
        print(f"Yaw: {yaw:6.2f}° | Pitch: {pitch:6.2f}°", end="\r")
        
except KeyboardInterrupt:
    print("\nMeasurement stopped by user.")
"""