# File: Maze.py
import matplotlib.pyplot as plt
import random
from Tile import Tile

class Maze:
    def __init__(self, width: int, height: int):
        self.width = width
        self.height = height
        
        # 1. Create a 2D grid of actual Tile objects
        self.grid = [[Tile(x, y) for x in range(width)] for y in range(height)]
        
        # Keep edges list for backwards compatibility / specific graph algorithms
        self.edges = []
        self.start_tile = (0, 0)
        
    def generate_braid_maze(self, min_erase_pct: float = 0.10, max_erase_pct: float = 0.50):
        # 1. Standard graph initialization
        graph = {}
        for x in range(self.width):
            for y in range(self.height):
                neighbors = []
                if x > 0: neighbors.append((x - 1, y))
                if x < self.width - 1: neighbors.append((x + 1, y))
                if y > 0: neighbors.append((x, y - 1))
                if y < self.height - 1: neighbors.append((x, y + 1))
                graph[(x, y)] = neighbors

        visited = set()
        perfect_edges = set()

        def backtrack(current_node):
            visited.add(current_node)
            neighbors = graph[current_node]
            random.shuffle(neighbors)
            for neighbor in neighbors:
                if neighbor not in visited:
                    perfect_edges.add((current_node, neighbor))
                    perfect_edges.add((neighbor, current_node))
                    backtrack(neighbor)

        backtrack((0, 0))
        
        # 2. Wall inventory and demolition
        all_possible_walls = []
        for x in range(self.width):
            for y in range(self.height):
                if x < self.width - 1: all_possible_walls.append(((x, y), (x + 1, y)))
                if y < self.height - 1: all_possible_walls.append(((x, y), (x, y + 1)))

        maze_walls = [wall for wall in all_possible_walls if wall not in perfect_edges]
        random.shuffle(maze_walls)

        erase_count = int(len(maze_walls) * random.uniform(min_erase_pct, max_erase_pct))
        erased_walls = maze_walls[:erase_count]

        # 3. Populate final edges array
        compiled_edges = list(perfect_edges)
        for u, v in erased_walls:
            compiled_edges.append((u, v))
            compiled_edges.append((v, u))
        random.shuffle(compiled_edges)
        self.edges = compiled_edges

        # 4. UPDATE TILE WALL OBJECTS DIRECTLY BASED ON COMPILED EDGES
        # By default, all walls are True. We knock them down if an edge exists.
        for edge in self.edges:
            (x1, y1), (x2, y2) = edge
            tile1 = self.grid[y1][x1]
            tile2 = self.grid[y2][x2]
            
            # Moving Right
            if x2 > x1: 
                tile1.has_wall_east = False
                tile2.has_wall_west = False
            # Moving Left
            elif x2 < x1:
                tile1.has_wall_west = False
                tile2.has_wall_east = False
            # Moving Up
            elif y2 > y1:
                tile1.has_wall_north = False
                tile2.has_wall_south = False
            # Moving Down
            elif y2 < y1:
                tile1.has_wall_south = False
                tile2.has_wall_north = False

    def populate_features(self, blue_count: int, checkpoint_count: int, black_count: int, victim_count: int):
        all_coordinates = [(r, c) for r in range(self.height) for c in range(self.width)]
        random.shuffle(all_coordinates)
        
        # Reset tile visual states safely
        for r in range(self.height):
            for c in range(self.width):
                self.grid[r][c].color = "white"
                self.grid[r][c].has_victim = False
        
        checkpoints = []
        for _ in range(checkpoint_count):
            if all_coordinates:
                r, c = all_coordinates.pop()
                self.grid[r][c].color = "silver"
                checkpoints.append((c, r))
                
        for _ in range(blue_count):
            if all_coordinates:
                r, c = all_coordinates.pop()
                self.grid[r][c].color = "blue"
                
        for _ in range(black_count):
            if all_coordinates:
                r, c = all_coordinates.pop()
                self.grid[r][c].color = "black"

        for _ in range(victim_count):
            if all_coordinates:
                r, c = all_coordinates.pop()
                self.grid[r][c].has_victim = True

        self.start_tile = random.choice(checkpoints) if checkpoints else (0, 0)

    def display_gui(self):
        fig, ax = plt.subplots(figsize=(10, 7))
        
        for y in range(self.height):
            for x in range(self.width):
                tile = self.grid[y][x]
                # Inside your drawing loop
                if tile.explored_state == "unknown":
                    face_color = "#2d2d2d"  # Dark gray for unmapped "Fog of War" cells
                else:
                    # If it IS explored, reveal its true physical color property!
                    face_color = tile.color
                # Draw background color
                if tile.color != "white":
                    rect = plt.Rectangle((x, y), 1, 1, facecolor=tile.color, edgecolor='none', zorder=1)
                    ax.add_patch(rect)
                    
                # Draw victim markers
                if tile.has_victim:
                    ax.text(x + 0.5, y + 0.5, '❌', color='red', weight='bold', 
                            ha='center', va='center', fontsize=12, zorder=2)

                # Draw walls dynamically by querying individual tile object states
                if tile.has_wall_north:
                    ax.plot([x, x + 1], [y + 1, y + 1], 'k-', linewidth=2, zorder=3)
                if tile.has_wall_south:
                    ax.plot([x, x + 1], [y, y], 'k-', linewidth=2, zorder=3)
                if tile.has_wall_east:
                    ax.plot([x + 1, x + 1], [y, y + 1], 'k-', linewidth=2, zorder=3)
                if tile.has_wall_west:
                    ax.plot([x, x], [y, y + 1], 'k-', linewidth=2, zorder=3)

        # Plot starting checkpoint flag
        start_x, start_y = self.start_tile
        ax.text(start_x + 0.5, start_y + 0.5, 'START\n(CP)', 
                color='darkgreen', weight='bold', ha='center', va='center', fontsize=9, zorder=4)

        ax.set_xlim(-0.5, self.width + 0.5)
        ax.set_ylim(-0.5, self.height + 0.5)
        ax.set_aspect('equal')
        ax.axis('off')
        plt.title(f"Object-Oriented Tile Grid Maze Matrix ({self.width}x{self.height})", fontsize=14, weight='bold')
        plt.show()