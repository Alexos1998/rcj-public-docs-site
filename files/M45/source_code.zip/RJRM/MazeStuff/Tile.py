# Updated Tile.py for Active Exploration
class Tile:
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = y
        
        # In a real maze, start with "True" or "Unknown" state
        # Classical approach: Assume walls exist everywhere until sensors prove otherwise
        self.has_wall_north = True
        self.has_wall_south = True
        self.has_wall_east  = True
        self.has_wall_west  = True
        
        # Exploration tracking fields
        self.explored_state = "unknown" # "unknown", "frontier", "visited"
        self.color = "white"            # Updated when the camera sees blue/black/silver
        self.has_victim = False