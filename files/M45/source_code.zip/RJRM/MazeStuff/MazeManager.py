import random
from Maze import Maze

if __name__ == "__main__":
    # 1. Structural Configuration Constants
    WIDTH, HEIGHT = 15, 10
    
    # 2. Instantiate our abstract maze object instance
    my_maze = Maze(width=WIDTH, height=HEIGHT)
    
    # 3. Call generation routine to construct graph edges
    my_maze.generate_braid_maze(min_erase_pct=0.10, max_erase_pct=0.50)
    
    # 4. Generate random quantities for internal features
    blue_count = random.randint(0, 15)
    checkpoint_count = random.randint(2, 10)
    black_count = random.randint(3, 8)
    victim_count = random.randint(4, 12)
    
    # 5. Distribute structural elements over grid field coordinates
    my_maze.populate_features(blue_count, checkpoint_count, black_count, victim_count)
    
    # --- Example of reading attributes cleanly externally ---
    print(f"Successfully generated a {my_maze.width}x{my_maze.height} maze matrix.")
    print(f"Active starting waypoint node is locked at: {my_maze.start_tile}")
    
    # 6. Execute GUI runtime presentation
    my_maze.display_gui()