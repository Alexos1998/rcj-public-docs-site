from DriveTrain import DriveTrain
from ToF import ToF
from Servo import Servo
from IMU import IMU
import time

"""drive_train = DriveTrain()
tof_front = ToF()
tof_left = ToF()
tof_right = ToF()"""

class Robot:
    TURN_SPEED = 0.5
    MAX_TURN_TIME = 3.0       # Safety cap — don't spin forever
    FRONT_CLEARANCE = 100     # mm
    TOLERANCE = 30            # mm — how close front≈right needs to be
    
    def __init__(self):
        self.drive_train = DriveTrain()

        self.tof_front = ToF()
        self.tof_left = ToF()
        self.tof_right = ToF()
        self.servo180 = Servo(0, 0)
	
	def dispense_kit()
	
    def turn_left(self):
        """
        Turn left until the wall that was in front is now on the right.
        Uses tof_front (pre-turn) as the target for tof_right (post-turn).
        """
        target_right_distance = self.tof_front.read()
        
        # Safety: abort if obstacle too close ahead
        if target_right_distance < self.FRONT_CLEARANCE:
            print("Turn aborted: obstacle too close")
            self.drive_train.stop()
            return False
        
        start_time = time.time()
        
        # Start turning left
        self.drive_train.set_speeds(-self.TURN_SPEED, self.TURN_SPEED)
        
        # Spin until right ToF matches what front ToF saw, or timeout
        while True:
            current_right = self.tof_right.read()
            elapsed = time.time() - start_time
            
            # Success condition: right wall distance ≈ previous front wall distance
            if abs(current_right - target_right_distance) < self.TOLERANCE:
                break
            
            # Safety timeout
            if elapsed > self.MAX_TURN_TIME:
                print("Turn timeout — wall not found")
                break
            
            # Tiny sleep to prevent CPU hogging and give ToF time to sample
            time.sleep(0.01)
        
        self.drive_train.stop()
        return True
    
    def turn_right(self):
        """
        Turn right until the wall that was on the right is now in front.
        Uses tof_right (pre-turn) as the target for tof_front (post-turn).
        """
        target_front_distance = self.tof_right.read()
        #sağ boşsa sağ dön hep?
        # Safety: abort if no right wall to follow (would be flying blind)
        if target_front_distance > 400:  # adjust threshold to your max useful range
            print("Turn aborted: no right wall detected")
            self.drive_train.stop()
            return False
        
        start_time = time.time()
        
        # Start turning right (left motors forward, right motors reverse)
        self.drive_train.set_speeds(self.TURN_SPEED, -self.TURN_SPEED)
        
        # Spin until front ToF matches what right ToF saw, or timeout
        while True:
            current_front = self.tof_front.read()
            elapsed = time.time() - start_time
            
            # Success condition: front wall distance ≈ previous right wall distance
            if abs(current_front - target_front_distance) < self.TOLERANCE:
                break
            
            # Safety timeout
            if elapsed > self.MAX_TURN_TIME:
                print("Turn timeout — wall not found")
                break
            
            time.sleep(0.01)
        
        self.drive_train.stop()
        return True
    
robot=Robot()
