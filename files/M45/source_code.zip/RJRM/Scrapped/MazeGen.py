import matplotlib.pyplot as plt
import random

def generate_maze_graph(width, height):
    # 1. Initialize a grid graph where every node connects to its 4 neighbors
    graph = {}
    for x in range(width):
        for y in range(height):
            neighbors = []
            if x > 0: neighbors.append((x - 1, y))
            if x < width - 1: neighbors.append((x + 1, y))
            if y > 0: neighbors.append((x, y - 1))
            if y < height - 1: neighbors.append((x, y + 1))
            graph[(x, y)] = neighbors

    visited = set()
    maze_edges = set()  # Using a set for O(1) fast lookup later

    def backtrack(current_node):
        visited.add(current_node)
        neighbors = graph[current_node]
        random.shuffle(neighbors)
        
        for neighbor in neighbors:
            if neighbor not in visited:
                # Carve path (Tunnel direction)
                maze_edges.add((current_node, neighbor))
                maze_edges.add((neighbor, current_node)) # Bidirectional for easy checking
                backtrack(neighbor)

    # Start carving from bottom-left corner
    backtrack((0, 0))
    
    shuffled_edges = list(maze_edges)
    random.shuffle(shuffled_edges)
    return shuffled_edges


def assign_tile_attributes(width, height, blue_count, checkpoint_count, black_count, victim_count):
    # 1. Create a flat list of all 150 coordinates in a 10x15 grid (height x width)
    all_coordinates = [(r, c) for r in range(height) for c in range(width)]
    random.shuffle(all_coordinates)
    
    # 2. Initialize matrix with default empty value 'white'
    grid = [["white" for _ in range(width)] for _ in range(height)]
    
    # 3. Distribute primary colored attributes sequentially
    checkpoints = []
    for _ in range(checkpoint_count):
        r, c = all_coordinates.pop()
        grid[r][c] = "silver"
        checkpoints.append((c, r))  # Save as (x, y) for drawing
        
    for _ in range(blue_count):
        r, c = all_coordinates.pop()
        grid[r][c] = "blue"
        
    for _ in range(black_count):
        r, c = all_coordinates.pop()
        grid[r][c] = "black"

    # 4. Colored tiles cannot have victims. The remaining elements in
    # all_coordinates are guaranteed to be uncolored ("white") tiles.
    for _ in range(victim_count):
        if all_coordinates:  # Safety check
            r, c = all_coordinates.pop()
            grid[r][c] = "victim"

    # 5. Pick a random checkpoint to serve as the start tile
    start_tile = random.choice(checkpoints)
    
    return grid, start_tile

def draw_maze(width, height, maze_edges, maze_grid, start_tile):
    fig, ax = plt.subplots(figsize=(10, 7))
    
    # Draw colored tile backgrounds before walls
    for y in range(height):
        for x in range(width):
            tile_type = maze_grid[y][x]
            
            # FIXED: Blue tiles are now rendered as "blue" instead of "black"
            if tile_type == "silver":
                face_color = "silver"
            elif tile_type == "black":
                face_color = "black"
            elif tile_type == "blue":
                face_color = "blue"
            else:
                face_color = "white"
                
            # Fill the tile cell background area graphically
            if face_color != "white":
                rect = plt.Rectangle((x, y), 1, 1, facecolor=face_color, edgecolor='none', zorder=1)
                ax.add_patch(rect)
                
            # If the tile is a victim tile, draw a clear red cross symbol in the middle
            if tile_type == "victim":
                ax.text(x + 0.5, y + 0.5, '❌', color='red', weight='bold', 
                        ha='center', va='center', fontsize=12, zorder=2)

    # Draw the thick outer perimeter walls
    ax.plot([0, width], [height, height], 'k-', linewidth=4, zorder=3)  # Top border
    ax.plot([0, width], [0, 0], 'k-', linewidth=4, zorder=3)              # Bottom border
    ax.plot([0, 0], [0, height], 'k-', linewidth=4, zorder=3)              # Left border
    ax.plot([width, width], [0, height], 'k-', linewidth=4, zorder=3)      # Right border

    # Iterate through every cell and construct internal walls
    for x in range(width):
        for y in range(height):
            
            # Check the cell to the RIGHT (Perpendicular vertical wall)
            if x < width - 1:
                if ((x, y), (x + 1, y)) not in maze_edges:
                    ax.plot([x + 1, x + 1], [y, y + 1], 'k-', linewidth=2, zorder=3)
                    
            # Check the cell ABOVE (Perpendicular horizontal wall)
            if y < height - 1:
                if ((x, y), (x, y + 1)) not in maze_edges:
                    ax.plot([x, x + 1], [y + 1, y + 1], 'k-', linewidth=2, zorder=3)

    # Label the starting checkpoint (Center of cell x + 0.5, y + 0.5)
    start_x, start_y = start_tile
    ax.text(start_x + 0.5, start_y + 0.5, 'START\n(CP)', 
            color='darkgreen', weight='bold', ha='center', va='center', fontsize=9, zorder=4)

    # Clean up layout axes
    ax.set_xlim(-0.5, width + 0.5)
    ax.set_ylim(-0.5, height + 0.5)
    ax.set_aspect('equal')
    ax.axis('off')
    plt.title(f"Graph Maze Matrix ({width}x{height}) with Unique Color Tiles & Victims", fontsize=14, weight='bold')
    plt.show()

# Run configuration
WIDTH, HEIGHT = 15, 10

# 1. Generate the initial perfect maze graph edges (as a bidirectional set)
perfect_edges_set = generate_maze_graph(WIDTH, HEIGHT)

# 2. Find all possible internal grid walls that COULD exist in a 15x10 graph
all_possible_walls = []
for x in range(WIDTH):
    for y in range(HEIGHT):
        # Look Right
        if x < WIDTH - 1:
            all_possible_walls.append(((x, y), (x + 1, y)))
        # Look Up
        if y < HEIGHT - 1:
            all_possible_walls.append(((x, y), (x, y + 1)))

# 3. Identify the subset of edges that actually became solid walls (the inverse of perfect_edges)
# We check only one direction since all_possible_walls contains unique pairs
maze_walls = [wall for wall in all_possible_walls if wall not in perfect_edges_set]

# 4. Shuffle our wall inventory
random.shuffle(maze_walls)

# 5. Determine a random percentage between 10% and 50% of walls to erase
total_walls_count = len(maze_walls)  # For a 15x10 grid, this will always be 126
erase_percentage = random.randint(10, 50) / 100.0
erase_count = int(total_walls_count * erase_percentage)

# 6. Split the shuffled walls into erased walls and remaining walls
erased_walls = maze_walls[:erase_count]
remaining_walls = maze_walls[erase_count:]  # Your separate variable representing active walls

# 7. Convert your perfect edge set into a list and append the newly erased walls
# We add them bidirectionally so the draw_maze function identifies them as open tunnels
edges = list(perfect_edges_set)
for u, v in erased_walls:
    edges.append((u, v))
    edges.append((v, u))

# 8. Re-shuffle the final compiled edges list
random.shuffle(edges)

# --- The rest of your code remains unchanged ---
# Dynamic allocation ranges for tiles
BlueTileCount = random.randint(0, 15)
CheckpointCount = random.randint(2, 10)
BlackTileCount = random.randint(3, 8)
VictimCount = random.randint(4, 12)

# Populate our 10x15 structural matrix and identify starting node
maze_grid, start_node = assign_tile_attributes(WIDTH, HEIGHT, BlueTileCount, CheckpointCount, BlackTileCount, VictimCount)

# Render everything visually (draw_maze will now show a looping braid maze!)
draw_maze(WIDTH, HEIGHT, edges, maze_grid, start_node)
