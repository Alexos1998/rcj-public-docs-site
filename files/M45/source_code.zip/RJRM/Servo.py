from periphery import PWM
import time

class Servo:
    def __init__(
        self,
        chip: int,
        channel: int,
        frequency: float = 50,
        min_pulse_ms: float = 1.0,
        max_pulse_ms: float = 2.0,
        max_angle: float = 180.0,
    ):
        self.frequency = frequency
        self.min_pulse_ms = min_pulse_ms
        self.max_pulse_ms = max_pulse_ms
        self.max_angle = max_angle

        self.pwm = PWM(chip, channel)
        self.pwm.frequency = frequency
        self.pwm.polarity = "normal"
        self.pwm.duty_cycle = 0.0
        self.pwm.enable()

    def set_angle(self, angle: float):
        """Set servo angle between 0 and max_angle degrees."""

        angle = max(0.0, min(angle, self.max_angle))

        pulse_ms = (
            self.min_pulse_ms
            + (angle / self.max_angle)
            * (self.max_pulse_ms - self.min_pulse_ms)
        )

        period_ms = 1000.0 / self.frequency
        self.pwm.duty_cycle = pulse_ms / period_ms

    def stop(self):
        self.pwm.duty_cycle = 0.0

    def close(self):
        self.stop()
        self.pwm.disable()
        self.pwm.close()
"""
servo=Servo(0, 0)
while True:
	servo.set_angle(20)
	time.sleep(2)
	servo.set_angle(160)
	time.sleep(2)
"""