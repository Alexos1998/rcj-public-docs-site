import os
# Force Blinka to recognize the Orange Pi 5 Plus pinout
os.environ["BLINKA_FORCEBOARD"] = "ORANGE_PI_5_PLUS"

import time
import board
import busio
import adafruit_vl53l0x
import adafruit_tca9548a


class VL53L0XArray:
    def __init__(self, channels, timing_budget=50000):
        self.channels = channels
        self.sensors = {}

        print("Initializing I2C bus...")
        # Verify your pins match the board's actual physical I2C2 pins
        self.i2c = busio.I2C(board.I2C2_SCL, board.I2C2_SDA)

        print("Scanning main I2C bus for the Multiplexer...")
        # Check if the Orange Pi can see the TCA9548A at all
        while not self.i2c.try_lock():
            pass
        addresses = [hex(x) for x in self.i2c.scan()]
        self.i2c.unlock()
        print(f"Found I2C devices on main bus: {addresses}")

        if not addresses:
            raise RuntimeError("No I2C devices found! Check your wiring to the Orange Pi.")

        print("Initializing TCA9548A Multiplexer...")
        # If your multiplexer address isn't 0x70, change it here (e.g., address=0x71)
        self.tca = adafruit_tca9548a.TCA9548A(self.i2c)

        # Initialize sensors
        for ch in channels:
            if not (0 <= ch <= 7):
                raise ValueError("Channel must be between 0 and 7")
            
            print(f"Attempting to connect to VL53L0X on channel {ch}...")
            try:
                sensor = adafruit_vl53l0x.VL53L0X(self.tca[ch])
                sensor.measurement_timing_budget = timing_budget
                self.sensors[ch] = sensor
                print(f"-> Success! Sensor found on channel {ch}")
            except Exception as e:
                # We raise the error here instead of ignoring it to see the traceback
                print(f"-> CRITICAL ERROR on channel {ch}: {e}")
                raise e 

        print(f"\nSuccessfully initialized {len(self.sensors)} sensor(s).")

    def read(self):
        readings = {}
        if not self.sensors:
            return "No sensors active to read!"

        for ch, sensor in self.sensors.items():
            try:
                readings[ch] = sensor.range
            except Exception as e:
                print(f"Error reading channel {ch}: {e}")
                readings[ch] = None
        return readings

# --- Main Program ---
# Start with just channel 0
multiplexer = VL53L0XArray([0])

while True:
    print(multiplexer.read())
    time.sleep(0.5)