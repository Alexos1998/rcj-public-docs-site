/*
 * ═══════════════════════════════════════════════════════════════════════
 *  ROBOCUP RESCUE ESP32-S3 FIRMWARE V6
 *  RAB-style serial protocol:
 *    Jetson → ESP32:  "f 300\r"  "l 90\r"  "r 90\r"  "s\r"  "c L1\r"
 *    ESP32  → Jetson: echo first ("f\r"), then result ("OK\r" / "OK B\r")
 *    Button ESTOP:    "ESTOP\r"  (broadcast during navigation only)
 *
 *  Self-correction support:
 *    f accepts optional distance  → "f 310\r"
 *    l / r accept optional angle  → "l 92\r"
 *
 *  Button behaviour (PIN 9):
 *    CALIBRATION     → read colour step (debounce 250ms)
 *    START_DETECTION → detect start tile (debounce 250ms)
 *    NAVIGATION      → ESTOP broadcast (debounce 500ms, 1s lockout after start)
 * ═══════════════════════════════════════════════════════════════════════
 */

#include <Arduino.h>
#include <ESP32Servo.h>

// ── Pins ─────────────────────────────────────────────────────────────────
#define PIN_BUTTON      9
#define PIN_LED        10
#define MBUILD_RX      18
#define MBUILD_TX      17

HardwareSerial mBuildSerial(1);

// ── Colour sensor ─────────────────────────────────────────────────────────
enum ColorType { WHITE=0, SILVER=1, BLACK=2, BLUE=3, RED=4 };
const char* colorCodes[] = {"W","S","B","U","R"};

// ── State machine ─────────────────────────────────────────────────────────
enum SystemState { STATE_CALIBRATION, STATE_START_DETECTION, STATE_NAVIGATION };
enum MotionState { MOTION_IDLE, MOTION_STRAIGHT, MOTION_TURNING };

SystemState currentState  = STATE_CALIBRATION;
MotionState motionState   = MOTION_IDLE;
bool        motorsInitialized = false;

// ── Calibration ───────────────────────────────────────────────────────────
uint8_t calibrationStep = 0;

struct RGBValue { uint16_t r, g, b; };

struct CalibrationData {
  RGBValue white, silver, black, blue, red;
  bool isValid;
} calibration = {{0,0,0},{0,0,0},{0,0,0},{0,0,0},{0,0,0},false};

// ── Servo ─────────────────────────────────────────────────────────────────
#define SERVO_PIN      16
#define HOME_POS       70
#define LEFT_RELEASE    0
#define LEFT_KICK     100
#define RIGHT_RELEASE 140
#define RIGHT_KICK     40
#define RELEASE_DELAY 1000
#define KICK_DELAY    1000
#define HOME_DELAY     500
#define BETWEEN_KICKS  500
Servo dropperServo;

// ── Motors ────────────────────────────────────────────────────────────────
#define TICKS_PER_REV      2881
#define WHEEL_DIAMETER_MM  115.8f
#define WHEEL_BASE_MM      280.0f
#define WHEEL_CIRC_MM      (WHEEL_DIAMETER_MM * 3.14159265f)
#define TICKS_PER_MM       (TICKS_PER_REV / WHEEL_CIRC_MM)
#define DEFAULT_MOVE_MM    300

#define PWM_MIN         180
#define PWM_CRUISE      170
#define PWM_CREEP       160
#define RAMP_UP_TICKS   250
#define RAMP_DOWN_TICKS 500
#define CREEP_TICKS      80
#define Ks               2.0f
#define SYNC_MAX         40
#define STOP_TICKS        2
#define LOOP_MS          10
#define MOVE_TIMEOUT_MS  30000
#define AUTO_STOP_MS     3000
#define PWM_FREQ         5000
#define PWM_RES             8

#define FL_ENA  5
#define FL_IN1  6
#define FL_IN2  7
#define FL_ENC 41
#define FL_CH   0

#define RL_ENB  3
#define RL_IN3 11
#define RL_IN4  8
#define RL_ENC 42
#define RL_CH   1

#define RR_ENA 38
#define RR_IN1 37
#define RR_IN2 36
#define RR_ENC 40
#define RR_CH   2

#define FR_ENB  2
#define FR_IN3 35
#define FR_IN4  1
#define FR_ENC 39
#define FR_CH   3

struct Motor {
  uint8_t in1, in2, enaPin, ledcCh, encPin;
  volatile long encCount;
  int8_t direction;
  long   targetTicks;
};
Motor motors[4];

// ── Button ────────────────────────────────────────────────────────────────
#define DEBOUNCE_CALIB_MS   250
#define DEBOUNCE_NAV_MS     500
#define NAV_BUTTON_LOCKOUT_MS 1000

volatile bool     buttonPressed  = false;
volatile uint32_t lastButtonTime = 0;
uint32_t          navStartTime   = 0;

// ── mBuild packet ─────────────────────────────────────────────────────────
uint8_t      packetBuf[64];
uint8_t      packetLen  = 0;
volatile bool packetReady = false;

// ── Auto-stop watchdog ────────────────────────────────────────────────────
uint32_t lastCommandTime = 0;
bool     autoStopArmed   = false;

// ── Emergency stop ────────────────────────────────────────────────────────
volatile bool emergencyStopRequested = false;

// ── Camera command ────────────────────────────────────────────────────────
bool   cameraCommandReceived = false;
String cameraCommand         = "";

// ═══════════════════════════════════════════════════════════════════════
// ENCODER ISRs
// ═══════════════════════════════════════════════════════════════════════

void IRAM_ATTR isr_FL() { if (motorsInitialized) motors[0].encCount += motors[0].direction; }
void IRAM_ATTR isr_RL() { if (motorsInitialized) motors[1].encCount += motors[1].direction; }
void IRAM_ATTR isr_RR() { if (motorsInitialized) motors[2].encCount += motors[2].direction; }
void IRAM_ATTR isr_FR() { if (motorsInitialized) motors[3].encCount += motors[3].direction; }

// ═══════════════════════════════════════════════════════════════════════
// BUTTON ISR — context-aware debounce
// ═══════════════════════════════════════════════════════════════════════

void IRAM_ATTR buttonISR() {
  uint32_t now      = millis();
  uint32_t debounce = (currentState == STATE_NAVIGATION)
                      ? DEBOUNCE_NAV_MS
                      : DEBOUNCE_CALIB_MS;
  if (now - lastButtonTime > debounce) {
    buttonPressed  = true;
    lastButtonTime = now;
  }
}

// ═══════════════════════════════════════════════════════════════════════
// LED
// ═══════════════════════════════════════════════════════════════════════

void ledStaticOn()  { digitalWrite(PIN_LED, HIGH); }
void ledStaticOff() { digitalWrite(PIN_LED, LOW);  }

void ledBlink(int times, int onMs, int offMs) {
  for (int i = 0; i < times; i++) {
    digitalWrite(PIN_LED, HIGH); delay(onMs);
    digitalWrite(PIN_LED, LOW);  delay(offMs);
  }
  digitalWrite(PIN_LED, HIGH);
}

// ═══════════════════════════════════════════════════════════════════════
// SERIAL PROTOCOL — RAB STYLE
// ═══════════════════════════════════════════════════════════════════════

void send_echo(char cmd) {
  Serial0.print(cmd);
  Serial0.print('\r');
  Serial0.flush();
}

void send_done(ColorType result = WHITE) {
  if (result == WHITE) {
    Serial0.print("OK\r");
  } else {
    Serial0.print("OK ");
    Serial0.print(colorCodes[result]);
    Serial0.print('\r');
  }
  Serial0.flush();
}

void send_cr(ColorType c) {
  Serial0.print("CR ");
  Serial0.print(colorCodes[c]);
  Serial0.print('\r');
  Serial0.flush();
}

void send_estop() {
  Serial0.print("ESTOP\r");
  Serial0.flush();
}

// ═══════════════════════════════════════════════════════════════════════
// MBUILD SENSOR
// ═══════════════════════════════════════════════════════════════════════

void readMBuildPackets() {
  static uint8_t buf[64];
  static uint8_t idx = 0;

  while (mBuildSerial.available()) {
    uint8_t b = mBuildSerial.read();
    if (b == 0xF0 || b == 0xF1) idx = 0;
    if (idx < 64) buf[idx++] = b;
    if (b == 0xF7 && idx == 10 && buf[0] == 0xF0) idx = 0;
    if (b == 0xF6 && buf[0] == 0xF1) {
      memcpy(packetBuf, buf, idx);
      packetLen   = idx;
      packetReady = true;
      idx = 0;
    }
  }
}

RGBValue extractRGB() {
  RGBValue rgb = {0, 0, 0};
  if (packetLen < 48 || packetBuf[0] != 0xF1) return rgb;
  if (packetBuf[3] == 0x02) rgb.r = packetBuf[4]  | (packetBuf[5]  << 8);
  if (packetBuf[6] == 0x02) rgb.g = packetBuf[7]  | (packetBuf[8]  << 8);
  if (packetBuf[9] == 0x02) rgb.b = packetBuf[10] | (packetBuf[11] << 8);
  return rgb;
}

// uint32_t prevents overflow — sum can reach 3×65535 = 196605 > uint16_t max
uint32_t rgbDist(RGBValue a, RGBValue b) {
  uint32_t dr = (a.r > b.r) ? (a.r - b.r) : (b.r - a.r);
  uint32_t dg = (a.g > b.g) ? (a.g - b.g) : (b.g - a.g);
  uint32_t db = (a.b > b.b) ? (a.b - b.b) : (b.b - a.b);
  return dr + dg + db;
}

ColorType detectColor() {
  readMBuildPackets();
  if (!packetReady || !calibration.isValid) return WHITE;
  packetReady = false;

  RGBValue d = extractRGB();
  if (d.r == 0 && d.g == 0 && d.b == 0) return WHITE;

  uint32_t dW = rgbDist(d, calibration.white);
  uint32_t dS = rgbDist(d, calibration.silver);
  uint32_t dB = rgbDist(d, calibration.black);
  uint32_t dU = rgbDist(d, calibration.blue);
  uint32_t dR = rgbDist(d, calibration.red);

  uint32_t  mn   = dW;
  ColorType best = WHITE;
  if (dS < mn) { mn = dS; best = SILVER; }
  if (dB < mn) { mn = dB; best = BLACK;  }
  if (dU < mn) { mn = dU; best = BLUE;   }
  if (dR < mn) { mn = dR; best = RED;    }
  return best;
}

// ═══════════════════════════════════════════════════════════════════════
// CALIBRATION
// ═══════════════════════════════════════════════════════════════════════

void initMotors();  // forward declaration

void calibrationMode() {
  if (calibrationStep > 4) return;

  ledBlink(3, 150, 150);
  readMBuildPackets();
  if (!packetReady) return;
  packetReady = false;

  RGBValue rgb = extractRGB();
  if (rgb.r == 0 && rgb.g == 0 && rgb.b == 0) return;

  switch (calibrationStep) {
    case 0: calibration.white  = rgb; send_cr(WHITE);  break;
    case 1: calibration.silver = rgb; send_cr(SILVER); break;
    case 2: calibration.black  = rgb; send_cr(BLACK);  break;
    case 3: calibration.blue   = rgb; send_cr(BLUE);   break;
    case 4: calibration.red    = rgb; send_cr(RED);    break;
  }
  calibrationStep++;

  if (calibrationStep >= 5) {
    calibration.isValid = true;
    currentState = STATE_START_DETECTION;
    ledStaticOn();          // red LED on
    delay(1000);            // hold 1 second
    ledStaticOff();         // turn off — calibration complete
    initMotors();
    motorsInitialized = true;
    dropperServo.attach(SERVO_PIN);   // attach servo after motors to avoid LEDC conflicts
    Serial0.println("[CAL] Done — press button to detect start tile");
  } else {
    ledStaticOn();
  }
  delay(500);
}

// ═══════════════════════════════════════════════════════════════════════
// MOTORS
// ═══════════════════════════════════════════════════════════════════════

void initMotors() {
  motors[0].in1 = FL_IN1; motors[0].in2 = FL_IN2;
  motors[0].enaPin = FL_ENA; motors[0].ledcCh = FL_CH; motors[0].encPin = FL_ENC;

  motors[1].in1 = RL_IN3; motors[1].in2 = RL_IN4;
  motors[1].enaPin = RL_ENB; motors[1].ledcCh = RL_CH; motors[1].encPin = RL_ENC;

  motors[2].in1 = RR_IN1; motors[2].in2 = RR_IN2;
  motors[2].enaPin = RR_ENA; motors[2].ledcCh = RR_CH; motors[2].encPin = RR_ENC;

  motors[3].in1 = FR_IN3; motors[3].in2 = FR_IN4;
  motors[3].enaPin = FR_ENB; motors[3].ledcCh = FR_CH; motors[3].encPin = FR_ENC;

  for (int i = 0; i < 4; i++) {
    motors[i].encCount    = 0;
    motors[i].direction   = 0;
    motors[i].targetTicks = 0;
    pinMode(motors[i].in1,   OUTPUT);
    pinMode(motors[i].in2,   OUTPUT);
    ledcSetup(motors[i].ledcCh, PWM_FREQ, PWM_RES);
    ledcAttachPin(motors[i].enaPin, motors[i].ledcCh);
    ledcWrite(motors[i].ledcCh, 0);
    pinMode(motors[i].encPin, INPUT_PULLUP);
  }

  attachInterrupt(digitalPinToInterrupt(FL_ENC), isr_FL, CHANGE);
  attachInterrupt(digitalPinToInterrupt(RL_ENC), isr_RL, CHANGE);
  attachInterrupt(digitalPinToInterrupt(RR_ENC), isr_RR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(FR_ENC), isr_FR, CHANGE);
}

void motor_raw(uint8_t idx, int spd) {
  Motor &m = motors[idx];
  if      (spd > 0) { digitalWrite(m.in1, HIGH); digitalWrite(m.in2, LOW);  m.direction =  1; }
  else if (spd < 0) { digitalWrite(m.in1, LOW);  digitalWrite(m.in2, HIGH); m.direction = -1; }
  else              { digitalWrite(m.in1, LOW);  digitalWrite(m.in2, LOW);  m.direction =  0; }
  ledcWrite(m.ledcCh, constrain(abs(spd), 0, 255));
}

void motor_brake(uint8_t idx) {
  Motor &m = motors[idx];
  digitalWrite(m.in1, HIGH);
  digitalWrite(m.in2, HIGH);
  ledcWrite(m.ledcCh, 0);
  m.direction = 0;
}

void brake_all()      { for (int i = 0; i < 4; i++) motor_brake(i); }
void reset_encoders() {
  noInterrupts();
  for (int i = 0; i < 4; i++) motors[i].encCount = 0;
  interrupts();
}

int base_pwm(long rem, long trav) {
  if (rem <= CREEP_TICKS)      return PWM_CREEP;
  if (rem <= RAMP_DOWN_TICKS)  return constrain((int)map(rem,  CREEP_TICKS, RAMP_DOWN_TICKS, PWM_CREEP, PWM_CRUISE), PWM_CREEP, PWM_CRUISE);
  if (trav <= RAMP_UP_TICKS)   return constrain((int)map(trav, 0,           RAMP_UP_TICKS,   PWM_MIN,   PWM_CRUISE), PWM_MIN,   PWM_CRUISE);
  return PWM_CRUISE;
}

void update_straight() {
  float avg = 0;
  for (int i = 0; i < 4; i++) avg += (float)motors[i].encCount;
  avg /= 4.0f;

  for (int i = 0; i < 4; i++) {
    Motor &m      = motors[i];
    long rem      = m.targetTicks - m.encCount;
    long absR     = abs(rem);
    long trav     = abs(m.encCount);
    int  dir      = (rem > 0) ? 1 : -1;

    if (absR <= STOP_TICKS) { motor_brake(i); continue; }

    float err = avg - (float)m.encCount;
    if (dir < 0) err = -err;
    int pwm = base_pwm(absR, trav) + constrain((int)(Ks * err), -SYNC_MAX, SYNC_MAX);
    pwm = (absR <= CREEP_TICKS)
          ? constrain(pwm, PWM_CREEP - 10, PWM_CREEP + 10)
          : constrain(pwm, PWM_MIN,        PWM_CRUISE + SYNC_MAX);
    motor_raw(i, dir * pwm);
  }
}

void update_turn() {
  float la = (abs(motors[0].encCount) + abs(motors[1].encCount)) / 2.0f;
  float ra = (abs(motors[2].encCount) + abs(motors[3].encCount)) / 2.0f;

  // Left side: motors 0,1   Right side: motors 2,3
  uint8_t left_idx[2]  = {0, 1};
  uint8_t right_idx[2] = {2, 3};

  for (int side = 0; side < 2; side++) {
    float sa = (side == 0) ? la : ra;
    for (int i = 0; i < 2; i++) {
      uint8_t idx = (side == 0) ? left_idx[i] : right_idx[i];
      Motor &m    = motors[idx];
      long rem    = m.targetTicks - m.encCount;
      long absR   = abs(rem);
      long trav   = abs(m.encCount);
      int  dir    = (rem > 0) ? 1 : -1;

      if (absR <= STOP_TICKS) { motor_brake(idx); continue; }

      int pwm = base_pwm(absR, trav)
              + constrain((int)(Ks * (sa - abs((float)m.encCount))), -SYNC_MAX, SYNC_MAX);
      pwm = (absR <= CREEP_TICKS)
            ? constrain(pwm, PWM_CREEP - 10, PWM_CREEP + 10)
            : constrain(pwm, PWM_MIN,        PWM_CRUISE + SYNC_MAX);
      motor_raw(idx, dir * pwm);
    }
  }
}

bool all_done() {
  for (int i = 0; i < 4; i++)
    if (abs(motors[i].targetTicks - motors[i].encCount) > STOP_TICKS) return false;
  return true;
}

long traveled_avg() {
  long t = 0;
  for (int i = 0; i < 4; i++) t += abs(motors[i].encCount);
  return t / 4;
}

// ═══════════════════════════════════════════════════════════════════════
// START DETECTION
// ═══════════════════════════════════════════════════════════════════════

void startDetection() {
  if (!buttonPressed) return;
  buttonPressed = false;

  // Wait for a fresh packet — retry up to 20 times (200ms max)
  packetReady = false;
  for (int attempt = 0; attempt < 20; attempt++) {
    readMBuildPackets();
    if (packetReady) break;
    delay(10);
  }

  ColorType c = detectColor();
  send_cr(c);
  ledBlink(1, 200, 200);

  currentState    = STATE_NAVIGATION;
  navStartTime    = millis();
  autoStopArmed   = true;
  lastCommandTime = millis();
  Serial0.println("[START] Navigation started");
}

// ═══════════════════════════════════════════════════════════════════════
// CAMERA SERVO
// ═══════════════════════════════════════════════════════════════════════

void execServo() {
  int  reps = cameraCommand.endsWith("2") ? 2 : 1;
  bool left = cameraCommand.startsWith("L");
  int  rel  = left ? LEFT_RELEASE  : RIGHT_RELEASE;
  int  kik  = left ? LEFT_KICK     : RIGHT_KICK;

  for (int k = 0; k < reps; k++) {
    dropperServo.write(rel);      delay(RELEASE_DELAY);
    dropperServo.write(kik);      delay(KICK_DELAY);
    dropperServo.write(HOME_POS); delay(HOME_DELAY);
    if (k == 0 && reps > 1) delay(BETWEEN_KICKS);
  }
  cameraCommandReceived = false;
  cameraCommand         = "";
  send_done();
}

// ═══════════════════════════════════════════════════════════════════════
// FORWARD MOVE
// ═══════════════════════════════════════════════════════════════════════

void moveForward(int distance_mm, String &buf) {
  reset_encoders();
  emergencyStopRequested = false;

  long ticks = (long)(distance_mm * TICKS_PER_MM);
  for (int i = 0; i < 4; i++) motors[i].targetTicks = ticks;

  uint32_t start = millis(), lastUpd = millis();

  while (!all_done()) {
    // Check for incoming serial during motion
    while (Serial0.available() > 0) {
      char c = Serial0.read();
      if (c == '\r' || c == '\n') {
        buf.trim();
        if (buf == "s")              emergencyStopRequested = true;
        else if (buf.startsWith("c ")) { cameraCommandReceived = true; cameraCommand = buf.substring(2); }
        lastCommandTime = millis();
        buf = "";
      } else { buf += c; }
    }

    if (emergencyStopRequested) {
      brake_all(); reset_encoders();
      emergencyStopRequested = false;
      motionState = MOTION_IDLE;
      send_done();
      return;
    }
    if (cameraCommandReceived) { brake_all(); execServo(); return; }

    ColorType color = detectColor();

    // BLACK — stop and reverse
    if (color == BLACK) {
      brake_all();
      ledBlink(2, 150, 150);
      long trav = traveled_avg();
      reset_encoders();
      for (int i = 0; i < 4; i++) motors[i].targetTicks = -trav;
      uint32_t rs = millis();
      while (!all_done() && millis() - rs < 5000) {
        if (millis() - lastUpd >= LOOP_MS) { lastUpd = millis(); update_straight(); }
      }
      brake_all(); reset_encoders();
      motionState = MOTION_IDLE;
      send_done(BLACK);
      return;
    }

    // BLUE — complete move then pause 5s
    if (color == BLUE) {
      while (!all_done() && millis() - start < MOVE_TIMEOUT_MS) {
        while (Serial0.available() > 0) {
          char c = Serial0.read();
          if (c == '\r' || c == '\n') {
            buf.trim();
            if (buf == "s") emergencyStopRequested = true;
            lastCommandTime = millis();
            buf = "";
          } else { buf += c; }
        }
        if (emergencyStopRequested) {
          brake_all(); reset_encoders();
          emergencyStopRequested = false;
          motionState = MOTION_IDLE;
          send_done();
          return;
        }
        if (millis() - lastUpd >= LOOP_MS) { lastUpd = millis(); update_straight(); }
      }
      brake_all();
      ledBlink(1, 150, 150);
      delay(5000);
      reset_encoders();
      motionState = MOTION_IDLE;
      send_done(BLUE);
      return;
    }

    if (millis() - start > MOVE_TIMEOUT_MS) break;
    if (millis() - lastUpd >= LOOP_MS) { lastUpd = millis(); update_straight(); }
  }

  brake_all(); delay(200);
  ColorType fin = detectColor();
  reset_encoders();
  motionState = MOTION_IDLE;
  if      (fin == SILVER) { ledBlink(1, 150, 150); send_done(SILVER); }
  else if (fin == RED)    { ledBlink(1, 150, 150); send_done(RED);    }
  else                    { send_done(); }
}

// ═══════════════════════════════════════════════════════════════════════
// TURN
// angle_deg: positive = right, negative = left
// ═══════════════════════════════════════════════════════════════════════

void doTurn(float angle_deg, String &buf) {
  float arc   = (abs(angle_deg) / 360.0f) * 3.14159265f * WHEEL_BASE_MM;
  long  ticks = (long)(arc * TICKS_PER_MM);

  reset_encoders();
  emergencyStopRequested = false;

  if (angle_deg > 0) {
    motors[0].targetTicks =  ticks; motors[1].targetTicks =  ticks;
    motors[2].targetTicks = -ticks; motors[3].targetTicks = -ticks;
  } else {
    motors[0].targetTicks = -ticks; motors[1].targetTicks = -ticks;
    motors[2].targetTicks =  ticks; motors[3].targetTicks =  ticks;
  }

  uint32_t start = millis(), lastUpd = millis();

  while (!all_done()) {
    while (Serial0.available() > 0) {
      char c = Serial0.read();
      if (c == '\r' || c == '\n') {
        buf.trim();
        if (buf == "s")              emergencyStopRequested = true;
        else if (buf.startsWith("c ")) { cameraCommandReceived = true; cameraCommand = buf.substring(2); }
        lastCommandTime = millis();
        buf = "";
      } else { buf += c; }
    }

    if (emergencyStopRequested) {
      brake_all(); reset_encoders();
      emergencyStopRequested = false;
      motionState = MOTION_IDLE;
      send_done();
      return;
    }
    if (cameraCommandReceived) { brake_all(); execServo(); return; }

    if (millis() - start > MOVE_TIMEOUT_MS) break;
    if (millis() - lastUpd >= LOOP_MS) { lastUpd = millis(); update_turn(); }
  }

  brake_all(); reset_encoders(); delay(200);
  motionState = MOTION_IDLE;
  send_done();
}

// ═══════════════════════════════════════════════════════════════════════
// NAVIGATION MODE
// ═══════════════════════════════════════════════════════════════════════

void navigationMode() {
  static String buf = "";

  // Auto-stop watchdog
  if (autoStopArmed && millis() - lastCommandTime > AUTO_STOP_MS) {
    if (motionState != MOTION_IDLE) {
      brake_all(); reset_encoders(); motionState = MOTION_IDLE;
    }
  }

  while (Serial0.available() > 0) {
    char c = Serial0.read();
    if (c == '\r' || c == '\n') {
      buf.trim();
      if (buf.length() == 0) { buf = ""; continue; }

      lastCommandTime = millis();
      autoStopArmed   = true;

      if (buf[0] == 'f') {
        send_echo('f');
        int mm = (buf.length() > 2) ? buf.substring(2).toInt() : DEFAULT_MOVE_MM;
        if (mm <= 0 || mm > 600) mm = DEFAULT_MOVE_MM;
        motionState = MOTION_STRAIGHT;
        moveForward(mm, buf);
      }
      else if (buf[0] == 'l') {
        send_echo('l');
        float deg = (buf.length() > 2) ? buf.substring(2).toFloat() : 90.0f;
        if (deg <= 0 || deg > 180) deg = 90.0f;
        motionState = MOTION_TURNING;
        doTurn(-deg, buf);
      }
      else if (buf[0] == 'r') {
        send_echo('r');
        float deg = (buf.length() > 2) ? buf.substring(2).toFloat() : 90.0f;
        if (deg <= 0 || deg > 180) deg = 90.0f;
        motionState = MOTION_TURNING;
        doTurn(deg, buf);
      }
      else if (buf[0] == 's') {
        send_echo('s');
        brake_all(); reset_encoders();
        motionState = MOTION_IDLE;
        send_done();
      }
      else if (buf.startsWith("c ")) {
        send_echo('c');
        cameraCommandReceived = true;
        cameraCommand         = buf.substring(2);
        execServo();
      }

      buf = "";
    } else {
      buf += c;
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════
// SETUP
// ═══════════════════════════════════════════════════════════════════════

void setup() {
  Serial0.begin(115200);
  mBuildSerial.begin(115200, SERIAL_8N1, MBUILD_RX, MBUILD_TX);

  pinMode(PIN_BUTTON, INPUT_PULLUP);
  pinMode(PIN_LED,    OUTPUT);
  attachInterrupt(digitalPinToInterrupt(PIN_BUTTON), buttonISR, FALLING);

  // Servo attached only after motors init (inside calibrationMode)
  // to avoid LEDC channel conflicts during startup

  delay(500);
  ledStaticOn();

  currentState    = STATE_CALIBRATION;
  calibrationStep = 0;
}

// ═══════════════════════════════════════════════════════════════════════
// LOOP
// ═══════════════════════════════════════════════════════════════════════

void loop() {
  readMBuildPackets();

  if (currentState == STATE_CALIBRATION) {
    if (buttonPressed) {
      buttonPressed = false;
      calibrationMode();
    }
  }
  else if (currentState == STATE_START_DETECTION) {
    startDetection();
  }
  else if (currentState == STATE_NAVIGATION) {
    // ESTOP button during navigation
    if (buttonPressed) {
      buttonPressed = false;
      if (millis() - navStartTime >= NAV_BUTTON_LOCKOUT_MS) {
        brake_all();
        reset_encoders();
        motionState            = MOTION_IDLE;
        emergencyStopRequested = false;
        send_estop();
        ledBlink(3, 100, 100);
      }
    }
    navigationMode();
  }

  delay(5);
}
