#!/usr/bin/env python3
"""
COMBINED DUAL CAMERA — FULL PARALLEL DETECTION
════════════════════════════════════════════════════════════════════════════════
Both cameras independently run TWO tasks on every frame:

  TASK A — TARGET RING DETECTOR
    • Hough circle detection + concentric colour ring analysis
    • Colours: black / red / yellow / green / blue
    • Circle coordinates smoothed with a rolling 5-frame average

  TASK B — GREEK LETTER DETECTOR
    • CNN classifies Phi / Psi / Omega / Empty
    • Sends 2-char serial command to ESP32 (e.g. 'L2', 'R1')
    • Blinks RGB LED on Omega (no serial)
    • Requires CONFIRM_FRAMES consecutive detections before acting

Per-frame thread layout (4 workers, all joined before display):
    L-Ring   L-Greek
    R-Ring   R-Greek

Serial commands are independent per camera side ('L' vs 'R').
Each camera has its own greek confirmation counter.

Shared hardware
    • Dual CSI cameras (sensor_id 0 = LEFT, sensor_id 1 = RIGHT)
    • Single serial port → ESP32
    • Jetson GPIO RGB LED

Display layout (each camera panel):
    ┌──────────────────────────────────┐
    │  [LEFT/RIGHT]  RING | GREEK      │  ← task labels
    │  R1: red   │ Phi:  45.2%  ████  │
    │  R2: blue  │ Psi:  12.1%  ██    │
    │  R3: green │ Omega: 5.3%  █     │
    │  R4: yellow│ Empty:37.4%  ██████│
    │  R5: black │                    │
    │  (circle drawn by Hough)        │
    └──────────────────────────────────┘
    Bottom bar: L rings/5 | serial | L-greek cmd | R rings/5 | R-greek cmd

Keyboard: D=Dual  L=Left only  R=Right only  Q/ESC=Quit
════════════════════════════════════════════════════════════════════════════════
"""

# ── GPU memory growth (must precede all other TF imports) ────────────────────
import tensorflow as tf
gpus = tf.config.list_physical_devices('GPU')
if gpus:
    try:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        print(f"[GPU] Memory growth enabled ({len(gpus)} GPU)")
    except RuntimeError as e:
        print(f"[GPU] Config error: {e}")
else:
    print("[GPU] No GPU — running on CPU")

import cv2
import numpy as np
import collections
import threading
import time
import pickle
import json
import serial
import serial.tools.list_ports
from pathlib import Path
from tensorflow import keras
import Jetson.GPIO as GPIO


# ══════════════════════════════════════════════════════════════════════════════
#  CONFIG — RING DETECTOR
# ══════════════════════════════════════════════════════════════════════════════

COLOUR_DEFS = {
    "black":  {"bgr": (30,  30,  30),  "bands": [(np.array([0,   0,   0]),   np.array([180, 255,  65]))]},
    "red":    {"bgr": (0,   0,   255), "bands": [(np.array([0,   150, 60]),  np.array([10,  255, 255])),
                                                  (np.array([170, 150, 60]),  np.array([180, 255, 255]))]},
    "yellow": {"bgr": (0,   255, 255), "bands": [(np.array([20,  100, 100]), np.array([35,  255, 255]))]},
    "green":  {"bgr": (0,   255, 0),   "bands": [(np.array([40,  70,  50]),  np.array([90,  255, 255]))]},
    "blue":   {"bgr": (255, 0,   0),   "bands": [(np.array([95,  120, 50]),  np.array([130, 255, 255]))]},
}


# ══════════════════════════════════════════════════════════════════════════════
#  CONFIG — GREEK LETTER DETECTOR
# ══════════════════════════════════════════════════════════════════════════════

IMG_SIZE             = 64
GREEK_LETTERS        = ['Phi', 'Psi', 'Omega', 'Empty']
CONFIDENCE_THRESHOLD = 60.0

DEPLOY_FOLDER = Path('/home/orin_nano/Documents/RMaze_test_code/greek_letter/greek_data_balanced_11')
MODEL_NAME    = 'greek_balanced'

SERIAL_PORT     = '/dev/ttyACM0'
SERIAL_BAUDRATE = 115200
SERIAL_TIMEOUT  = 1

LETTER_COMMANDS = {
    'Phi'  : '2',    # 2 kicks
    'Psi'  : '1',    # 1 kick
    'Omega': None,   # LED blink only, no serial
    'Empty': 'skip', # do nothing
}

CONFIRM_FRAMES = 5

# ── GPIO pins ────────────────────────────────────────────────────────────────
LED_R        = 33
LED_G        = 31
LED_B        = 32
BLINK_COUNT  = 2
BLINK_ON_MS  = 0.15
BLINK_OFF_MS = 0.15

CLASS_COLORS = {
    'Phi'  : (0,   255,  80),
    'Psi'  : (0,   200, 255),
    'Omega': (255, 180,   0),
    'Empty': (100, 100, 100),
}


# ══════════════════════════════════════════════════════════════════════════════
#  CSI CAMERA
# ══════════════════════════════════════════════════════════════════════════════

class CSI_Camera:
    """Thread-safe CSI camera wrapper (GStreamer / NVMM)."""

    def __init__(self):
        self.video_capture = None
        self.frame     = None
        self.grabbed   = False
        self.read_lock = threading.Lock()
        self.read_thread = None
        self.running   = False

    def open(self, pipeline):
        try:
            self.video_capture = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)
            self.grabbed, self.frame = self.video_capture.read()
        except RuntimeError:
            self.video_capture = None
            print("Unable to open camera: " + pipeline)

    def start(self):
        if self.running or self.video_capture is None:
            return self
        self.running     = True
        self.read_thread = threading.Thread(target=self._update, daemon=True)
        self.read_thread.start()
        return self

    def stop(self):
        self.running = False
        if self.read_thread is not None:
            self.read_thread.join()
            self.read_thread = None

    def _update(self):
        while self.running:
            try:
                grabbed, frame = self.video_capture.read()
                with self.read_lock:
                    self.grabbed = grabbed
                    self.frame   = frame
            except RuntimeError:
                print("Could not read image from camera")

    def read(self):
        with self.read_lock:
            if self.frame is None:
                return False, None
            return self.grabbed, self.frame.copy()

    def release(self):
        self.stop()
        if self.video_capture is not None:
            self.video_capture.release()
            self.video_capture = None

    def is_open(self):
        return self.video_capture is not None and self.video_capture.isOpened()


def gstreamer_pipeline(sensor_id=0,
                       capture_width=640, capture_height=480,
                       display_width=320, display_height=240,
                       framerate=30, flip_method=2):
    return (
        "nvarguscamerasrc sensor-id=%d ! "
        "video/x-raw(memory:NVMM), width=(int)%d, height=(int)%d, framerate=(fraction)%d/1 ! "
        "nvvidconv flip-method=%d ! "
        "video/x-raw, width=(int)%d, height=(int)%d, format=(string)BGRx ! "
        "videoconvert ! video/x-raw, format=(string)BGR ! appsink"
        % (sensor_id, capture_width, capture_height, framerate,
           flip_method, display_width, display_height)
    )


# ══════════════════════════════════════════════════════════════════════════════
#  GPIO / LED
# ══════════════════════════════════════════════════════════════════════════════

def setup_gpio():
    GPIO.setmode(GPIO.BOARD)
    for pin in (LED_R, LED_G, LED_B):
        GPIO.setup(pin, GPIO.OUT)
    time.sleep(0.1)
    led_off()
    print(f"  GPIO LED ready  : R={LED_R} G={LED_G} B={LED_B}")

# LED command map — W blinked once, others solid
LED_COMMANDS = {
    'W': (True,  True,  True),   # white — single blink
    'S': (True,  True,  True),   # silver — solid white
    'B': (True,  False, True),   # blue
    'U': (False, False, True),   # blue (alternate)
    'R': (True,  False, False),  # red
}

# Blink control
_nav_blink_thread = None
_nav_blink_stop   = threading.Event()

def set_led(r, g, b):
    try:
        GPIO.output(LED_R, GPIO.LOW if r else GPIO.HIGH)
        GPIO.output(LED_G, GPIO.LOW if g else GPIO.HIGH)
        GPIO.output(LED_B, GPIO.LOW if b else GPIO.HIGH)
    except:
        pass

def led_off():
    global _nav_blink_stop
    _nav_blink_stop.set()   # stop any running blink
    try:
        GPIO.output(LED_R, GPIO.HIGH)
        GPIO.output(LED_G, GPIO.HIGH)
        GPIO.output(LED_B, GPIO.HIGH)
    except:
        pass

def led_white():
    GPIO.output(LED_R, GPIO.LOW)
    GPIO.output(LED_G, GPIO.LOW)
    GPIO.output(LED_B, GPIO.LOW)

def _blink_thread():
    for _ in range(BLINK_COUNT):
        led_white(); time.sleep(BLINK_ON_MS)
        led_off();   time.sleep(BLINK_OFF_MS)

def trigger_blink():
    threading.Thread(target=_blink_thread, daemon=True).start()

def _nav_blink_worker(r, g, b, interval):
    """Single blink then off — for white tile detection."""
    set_led(r, g, b)
    time.sleep(interval)
    try:
        GPIO.output(LED_R, GPIO.HIGH)
        GPIO.output(LED_G, GPIO.HIGH)
        GPIO.output(LED_B, GPIO.HIGH)
    except:
        pass

def light_color(color_code):
    """Show tile colour on LED — white blinks once, others solid."""
    global _nav_blink_thread, _nav_blink_stop

    _nav_blink_stop.set()
    if _nav_blink_thread and _nav_blink_thread.is_alive():
        _nav_blink_thread.join(timeout=0.5)
    _nav_blink_stop.clear()

    if color_code not in LED_COMMANDS:
        led_off()
        return

    r, g, b = LED_COMMANDS[color_code]

    if color_code == 'W':
        _nav_blink_thread = threading.Thread(
            target=_nav_blink_worker,
            args=(True, True, True, 0.3),
            daemon=True
        )
        _nav_blink_thread.start()
    else:
        set_led(r, g, b)


# ══════════════════════════════════════════════════════════════════════════════
#  SERIAL
# ══════════════════════════════════════════════════════════════════════════════

class SerialReader:
    """Background thread that drains incoming bytes from ESP32."""

    def __init__(self, ser):
        self.ser  = ser
        self.last = ""
        self.lock = threading.Lock()
        self.running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while self.running:
            try:
                if self.ser and self.ser.is_open and self.ser.in_waiting > 0:
                    line = self.ser.readline().decode('utf-8', errors='ignore').strip()
                    if line:
                        with self.lock:
                            self.last = line
                        print(f"  ESP32 -> '{line}'")
                else:
                    time.sleep(0.01)
            except Exception as e:
                print(f"  Serial read error: {e}")
                time.sleep(0.1)

    def get(self):
        with self.lock:
            return self.last

    def stop(self):
        self.running = False


def init_serial():
    print(f"  Trying port     : {SERIAL_PORT}")
    print("  Available ports :")
    for p in serial.tools.list_ports.comports():
        print(f"    {p.device}  --  {p.description}")
    try:
        ser = serial.Serial(SERIAL_PORT, SERIAL_BAUDRATE, timeout=SERIAL_TIMEOUT)
        time.sleep(2)
        ser.reset_input_buffer()
        print(f"  Serial connected: {SERIAL_PORT} @ {SERIAL_BAUDRATE} baud  OK")
        return ser
    except serial.SerialException as e:
        print(f"  WARNING: Cannot open {SERIAL_PORT} -> {e}")
        print("  Running without serial.")
        return None


def send_command(ser, label, last_sent, cam_side):
    """Send 2-char command to ESP32 (e.g. 'L2', 'R1').
    Returns the new last_sent value (unchanged if nothing was sent).
    cam_side: 'L' or 'R'.
    """
    if label == last_sent:
        return last_sent

    cmd = LETTER_COMMANDS.get(label)
    if cmd == 'skip':
        return last_sent
    if cmd is None:
        # Omega — LED blink only
        print(f"  [{cam_side}] {label} -> LED blink only")
        trigger_blink()
        return label

    if ser is not None and ser.is_open:
        full_cmd = (cam_side + cmd).encode()
        try:
            ser.write(full_cmd)
            ser.flush()
            print(f"  [{cam_side}] Sent -> '{full_cmd.decode()}' ({label})")
            trigger_blink()
        except serial.SerialException as e:
            print(f"  Serial write error: {e}")
    else:
        print(f"  [{cam_side}] Serial offline — would send '{cam_side}{cmd}' for {label}")

    return label


# ══════════════════════════════════════════════════════════════════════════════
#  RING DETECTION CORE
# ══════════════════════════════════════════════════════════════════════════════

def _get_ring_mask(shape, cx, cy, r_out, r_in):
    mask = np.zeros(shape[:2], dtype=np.uint8)
    cv2.circle(mask, (cx, cy), int(r_out), 255, -1)
    if r_in > 0:
        cv2.circle(mask, (cx, cy), int(r_in), 0, -1)
    return mask


def _identify_ring_color(hsv, mask):
    best, best_n = "none", 0
    for name, data in COLOUR_DEFS.items():
        cm = np.zeros(hsv.shape[:2], dtype=np.uint8)
        for lo, hi in data["bands"]:
            cm = cv2.bitwise_or(cm, cv2.inRange(hsv, lo, hi))
        n = np.count_nonzero(cv2.bitwise_and(cm, mask))
        if n > best_n and n > 100:
            best_n, best = n, name
    return best


def process_ring_frame(frame, history):
    """
    Detect target rings.
    Returns (annotated_frame, ring_results).
    ring_results: list of (ring_idx 1-5, colour_name).
    Always works on an internal copy — never modifies original frame.
    """
    out = frame.copy()   # always annotate a copy

    lab = cv2.cvtColor(out, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    l   = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8)).apply(l)
    hsv = cv2.cvtColor(cv2.merge([l, a, b]), cv2.COLOR_LAB2BGR)
    hsv = cv2.cvtColor(hsv, cv2.COLOR_BGR2HSV)

    # Use original frame for circle detection (better edges)
    gray    = cv2.medianBlur(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY), 5)
    circles = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT,
                               dp=1.2, minDist=150,
                               param1=100, param2=45,
                               minRadius=40, maxRadius=250)
    ring_results = []
    if circles is not None:
        history.append(np.round(circles[0]).astype("int")[0])
        cx, cy, r = np.mean(history, axis=0).astype(int)
        rw = r / 5
        for i in range(5):
            r_out = r - i * rw
            r_in  = r - (i + 1) * rw
            mask  = _get_ring_mask(out.shape, cx, cy, r_out, r_in)
            color = _identify_ring_color(hsv, mask)
            ring_results.append((i + 1, color))
            bgr = COLOUR_DEFS.get(color, {"bgr": (127, 127, 127)})["bgr"]
            cv2.circle(out, (cx, cy), int(r_out), bgr, 2)
            cv2.putText(out, f"R{i+1}:{color}",
                        (cx + 10, cy - int(r_out) + 15),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.38, (255, 255, 255), 1)
    return out, ring_results


# ══════════════════════════════════════════════════════════════════════════════
#  GREEK LETTER DETECTION CORE
# ══════════════════════════════════════════════════════════════════════════════

_CLAHE_GRAY = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(4, 4))


def enhance_frame(bgr):
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    return cv2.cvtColor(_CLAHE_GRAY.apply(gray), cv2.COLOR_GRAY2BGR)


def load_model():
    arch_p    = DEPLOY_FOLDER / f'{MODEL_NAME}_config.json'
    weights_p = DEPLOY_FOLDER / f'{MODEL_NAME}_weights.pkl'
    if not arch_p.exists():
        raise FileNotFoundError(f"Architecture not found: {arch_p}")
    if not weights_p.exists():
        raise FileNotFoundError(f"Weights not found: {weights_p}")

    print("  Loading architecture...", end=' ', flush=True)
    with open(str(arch_p)) as f:
        model = keras.models.model_from_json(f.read())
    print("OK")

    print("  Loading weights...",      end=' ', flush=True)
    with open(str(weights_p), 'rb') as f:
        model.set_weights(pickle.load(f))
    print("OK")

    cfg_p = DEPLOY_FOLDER / 'config.json'
    if cfg_p.exists():
        with open(str(cfg_p)) as f:
            cfg = json.load(f)
        print(f"  Model accuracy  : {cfg.get('test_accuracy', 0)*100:.1f}%")
    return model


def preprocess_greek(frame):
    h, w   = frame.shape[:2]
    side   = min(h, w)
    sq     = frame[(h-side)//2:(h-side)//2+side, (w-side)//2:(w-side)//2+side]
    gray   = cv2.cvtColor(sq, cv2.COLOR_BGR2GRAY)
    res    = cv2.resize(gray, (IMG_SIZE, IMG_SIZE), interpolation=cv2.INTER_AREA)
    return (res.astype(np.float32) / 255.0).reshape(1, IMG_SIZE, IMG_SIZE, 1)


# ══════════════════════════════════════════════════════════════════════════════
#  PER-CAMERA WORKER  (runs ring + greek in two sub-threads)
# ══════════════════════════════════════════════════════════════════════════════

class CameraWorker:
    """
    One instance per camera.
    Holds the latest results for both tasks and spawns threads to refresh them.
    """

    def __init__(self, cam_side):
        self.cam_side   = cam_side          # 'L' or 'R'
        self.history    = collections.deque(maxlen=5)

        # Ring state
        self.ring_frame   = None
        self.ring_results = []

        # Greek state
        self.greek_label  = '?'
        self.greek_conf   = 0.0
        self.greek_probs  = np.ones(len(GREEK_LETTERS)) / len(GREEK_LETTERS)

        self._lock = threading.Lock()

    # ── Ring sub-thread ───────────────────────────────────────────────────────
    def _run_ring(self, frame):
        annotated, rings = process_ring_frame(frame, self.history)
        with self._lock:
            self.ring_frame   = annotated
            self.ring_results = rings

    # ── Greek sub-thread ──────────────────────────────────────────────────────
    def _run_greek(self, model, frame):
        probs = model.predict(preprocess_greek(frame), verbose=0)[0]
        pred  = int(np.argmax(probs))
        with self._lock:
            self.greek_label = GREEK_LETTERS[pred]
            self.greek_conf  = float(probs[pred]) * 100
            self.greek_probs = probs

    # ── Public: fire both sub-threads and return thread handles ───────────────
    def run(self, model, frame):
        t_ring  = threading.Thread(target=self._run_ring,
                                   args=(frame.copy(),), daemon=True)
        t_greek = threading.Thread(target=self._run_greek,
                                   args=(model, frame.copy()), daemon=True)
        t_ring.start()
        t_greek.start()
        return t_ring, t_greek

    def get_ring(self):
        with self._lock:
            return self.ring_frame, list(self.ring_results)

    def get_greek(self):
        with self._lock:
            return self.greek_label, self.greek_conf, self.greek_probs.copy()


# ══════════════════════════════════════════════════════════════════════════════
#  DRAWING
# ══════════════════════════════════════════════════════════════════════════════

_CAM_COLOR = {'L': (0, 200, 255), 'R': (255, 180, 0)}

def draw_panel(frame, cam_side, ring_results, greek_label, greek_conf, greek_probs):
    """
    Overlay ring results (left column) and greek probability bars (right column)
    onto a single camera panel.
    """
    h, w      = frame.shape[:2]
    side_name = "LEFT" if cam_side == 'L' else "RIGHT"
    hdr_color = _CAM_COLOR[cam_side]

    # ── Header ──────────────────────────────────────────────────────────────
    cv2.putText(frame, f"[{side_name}]  RING  |  GREEK",
                (w // 2 - 95, 18), cv2.FONT_HERSHEY_SIMPLEX,
                0.55, hdr_color, 2)

    # ── Ring list — top-left ─────────────────────────────────────────────────
    for i, (ridx, colour) in enumerate(ring_results):
        bgr = COLOUR_DEFS.get(colour, {"bgr": (180, 180, 180)})["bgr"]
        cv2.putText(frame, f"R{ridx}: {colour}",
                    (6, 36 + i * 19),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.38, bgr, 1)

    # ── Greek probability bars — top-right ───────────────────────────────────
    detected = greek_conf >= CONFIDENCE_THRESHOLD
    bar_w    = 100
    sx       = w - bar_w - 8
    sy       = 28
    for i, (letter, prob) in enumerate(zip(GREEK_LETTERS, greek_probs)):
        color  = CLASS_COLORS.get(letter, (200, 200, 200))
        if not detected:
            color = tuple(int(c * 0.35) for c in color)
        filled = int(bar_w * prob)
        by     = sy + i * 32

        cv2.rectangle(frame, (sx, by), (sx + bar_w, by + 18), (40, 40, 40), -1)
        if filled > 0:
            cv2.rectangle(frame, (sx, by), (sx + filled, by + 18), color, -1)
        cv2.rectangle(frame, (sx, by), (sx + bar_w, by + 18), (100, 100, 100), 1)
        cv2.putText(frame, f"{letter}:{prob*100:.0f}%",
                    (sx + 2, by + 13),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.38, (230, 230, 230), 1)

    # ── Active greek label (large, centre-bottom of panel) ───────────────────
    if detected:
        cv2.putText(frame, greek_label,
                    (w // 2 - 35, h - 38),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9,
                    CLASS_COLORS.get(greek_label, (255, 255, 255)), 2)
        cv2.putText(frame, f"{greek_conf:.0f}%",
                    (w // 2 - 20, h - 18),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)


def draw_status_bar(display,
                    L_rings, L_greek_sent,
                    R_rings, R_greek_sent,
                    serial_ok):
    """Unified bottom bar across the full display."""
    h, w = display.shape[:2]
    cv2.rectangle(display, (0, h - 26), (w, h), (25, 25, 25), -1)

    def cmd_str(label):
        c = LETTER_COMMANDS.get(label)
        return c if isinstance(c, str) and c != 'skip' else '-'

    L_ring_n = sum(1 for _, c in L_rings if c != "none")
    R_ring_n = sum(1 for _, c in R_rings if c != "none")

    items = [
        (10,      f"L-rings:{L_ring_n}/5",             (0, 200, 255)),
        (w//6,    f"L-greek:{L_greek_sent or '-'}->{cmd_str(L_greek_sent)}", (160, 230, 160)),
        (w//2-30, "SERIAL:" + ("OK" if serial_ok else "OFF"),
                  (0, 255, 80) if serial_ok else (60, 60, 200)),
        (w//2+60, f"R-rings:{R_ring_n}/5",             (255, 180, 0)),
        (w*3//4,  f"R-greek:{R_greek_sent or '-'}->{cmd_str(R_greek_sent)}", (160, 230, 160)),
        (w-115,   "D/L/R  Q=Quit",                     (120, 120, 120)),
    ]
    for x, text, color in items:
        cv2.putText(display, text, (x, h - 7),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.38, color, 1)


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════════════

def run_combined():
    print("=" * 68)
    print("  COMBINED DUAL CAMERA — RING + GREEK (BOTH CAMERAS)")
    print("=" * 68)
    print("  Each camera independently runs:")
    print("    • Target ring colour detection  (Hough circles)")
    print("    • Greek letter CNN detection    (Phi/Psi/Omega/Empty)")
    print("  Serial: cam-side prefix + kick count  e.g. 'L2', 'R1'")
    print("=" * 68)

    # ── GPIO ─────────────────────────────────────────────────────────────────
    print("\nSetting up GPIO LED...")
    setup_gpio()

    # ── Model ─────────────────────────────────────────────────────────────────
    print("\nLoading Greek letter model...")
    model = load_model()
    model.predict(np.zeros((1, IMG_SIZE, IMG_SIZE, 1), np.float32), verbose=0)
    print("Model warmed up.")

    # ── Serial ────────────────────────────────────────────────────────────────
    print("\nInitialising serial...")
    ser        = init_serial()
    serial_ok  = ser is not None
    ser_reader = SerialReader(ser) if serial_ok else None

    # ── Cameras ───────────────────────────────────────────────────────────────
    left_cam  = CSI_Camera()
    right_cam = CSI_Camera()
    left_cam.open(gstreamer_pipeline(sensor_id=0))
    right_cam.open(gstreamer_pipeline(sensor_id=1))

    if not (left_cam.is_open() and right_cam.is_open()):
        print("WARNING: CSI cameras not available — falling back to USB.")
        left_cam.video_capture  = cv2.VideoCapture(0)
        right_cam.video_capture = cv2.VideoCapture(1)
        left_cam.grabbed,  left_cam.frame  = left_cam.video_capture.read()
        right_cam.grabbed, right_cam.frame = right_cam.video_capture.read()

    left_cam.start()
    right_cam.start()

    # ── Per-camera workers ────────────────────────────────────────────────────
    L_worker = CameraWorker('L')
    R_worker = CameraWorker('R')

    # ── Greek confirmation state (independent per camera) ─────────────────────
    L_confirm_label = None;  L_confirm_count = 0;  L_last_sent = None
    R_confirm_label = None;  R_confirm_count = 0;  R_last_sent = None

    # ── Cached display frames (shown while new ones compute) ──────────────────
    L_rings      = []
    R_rings      = []

    view_mode    = 'D'
    window_title = "Dual Cam — Ring + Greek (L & R)"
    cv2.namedWindow(window_title, cv2.WINDOW_AUTOSIZE)

    print("\nControls: D=Dual  L=Left only  R=Right only  Q/ESC=Quit")
    print("=" * 68)

    try:
        while True:
            ok_l, left_frame  = left_cam.read()
            ok_r, right_frame = right_cam.read()

            if not ok_l or left_frame is None:
                continue
            if not ok_r or right_frame is None:
                right_frame = left_frame.copy()

            # ── Dispatch 4 parallel threads ───────────────────────────────────
            tL_ring, tL_greek = L_worker.run(model, left_frame)
            tR_ring, tR_greek = R_worker.run(model, right_frame)
            tL_ring.join();  tL_greek.join()
            tR_ring.join();  tR_greek.join()

            # ── Collect results ───────────────────────────────────────────────
            lf, L_rings           = L_worker.get_ring()
            L_label, L_conf, L_pr = L_worker.get_greek()

            rf, R_rings           = R_worker.get_ring()
            R_label, R_conf, R_pr = R_worker.get_greek()

            if lf is None: lf = left_frame.copy()
            if rf is None: rf = right_frame.copy()

            # Apply CLAHE-enhanced display base for greek readability
            lf_disp = enhance_frame(lf)
            rf_disp = enhance_frame(rf)

            # Copy Hough circle drawings from raw lf/rf onto enhanced base
            # (ring annotations are already drawn into lf/rf by process_ring_frame)
            lf_disp = cv2.addWeighted(lf_disp, 0.6, lf, 0.4, 0)
            rf_disp = cv2.addWeighted(rf_disp, 0.6, rf, 0.4, 0)

            # ── Greek confirmation gates ──────────────────────────────────────
            # LEFT camera
            if L_conf >= CONFIDENCE_THRESHOLD:
                if L_label == L_confirm_label:
                    L_confirm_count += 1
                else:
                    L_confirm_label = L_label
                    L_confirm_count = 1
                if L_confirm_count >= CONFIRM_FRAMES:
                    L_last_sent = send_command(ser, L_label, L_last_sent, 'L')
            else:
                L_confirm_count = 0
                L_confirm_label = None

            # RIGHT camera
            if R_conf >= CONFIDENCE_THRESHOLD:
                if R_label == R_confirm_label:
                    R_confirm_count += 1
                else:
                    R_confirm_label = R_label
                    R_confirm_count = 1
                if R_confirm_count >= CONFIRM_FRAMES:
                    R_last_sent = send_command(ser, R_label, R_last_sent, 'R')
            else:
                R_confirm_count = 0
                R_confirm_label = None

            # ── Draw overlays onto each panel ─────────────────────────────────
            draw_panel(lf_disp, 'L', L_rings, L_label, L_conf, L_pr)
            draw_panel(rf_disp, 'R', R_rings, R_label, R_conf, R_pr)

            # ── Compose display ───────────────────────────────────────────────
            if view_mode == 'D':
                display = np.hstack((lf_disp, rf_disp))
            elif view_mode == 'L':
                display = lf_disp
            else:
                display = rf_disp

            draw_status_bar(display,
                            L_rings, L_last_sent,
                            R_rings, R_last_sent,
                            serial_ok)

            cv2.imshow(window_title, display)

            # ── Keys ──────────────────────────────────────────────────────────
            key = cv2.waitKey(1) & 0xFF
            if key in (ord('q'), 27):
                print("\nQuitting...")
                break
            elif key == ord('d'):
                view_mode = 'D'; print("  View -> DUAL")
            elif key == ord('l'):
                view_mode = 'L'; print("  View -> LEFT only")
            elif key == ord('r'):
                view_mode = 'R'; print("  View -> RIGHT only")

            if cv2.getWindowProperty(window_title, cv2.WND_PROP_AUTOSIZE) < 0:
                break

    finally:
        print("\nCleaning up...")
        if ser_reader:
            ser_reader.stop()
        if ser and ser.is_open:
            ser.close()
            print("  Serial port closed.")
        left_cam.stop();  left_cam.release()
        right_cam.stop(); right_cam.release()
        cv2.destroyAllWindows()
        led_off()
        GPIO.cleanup()
        print("  GPIO cleaned up.")
        print("Detection session ended.")


if __name__ == "__main__":
    run_combined()