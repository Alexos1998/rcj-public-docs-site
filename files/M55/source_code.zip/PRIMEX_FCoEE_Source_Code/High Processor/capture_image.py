# Greek Letter Dual CSI Camera Capture
# Supports NVIDIA Jetson Nano / Xavier NX dual CSI camera setup
#
# CONTROLS:
#   1 / 2 / 3 / 4 - Switch capture class (Phi / Psi / Omega / Empty)
#   L / R          - Switch active camera (Left / Right)
#   SPACE          - Capture image (center square crop, grayscale)
#   B              - Toggle display mode (Binary / Grayscale / Color)
#   S              - Toggle side-by-side preview (both cameras)
#   Q / ESC        - Quit

import cv2
import threading
import numpy as np
from pathlib import Path
from datetime import datetime


# ==================== CONFIG ====================
OUTPUT_DIR  = "/home/orin_nano/Documents/RMaze_test_code/greek_letter/captured_dataset_3"
IMAGE_SIZE  = 500   # saved image size (matches training)

CLASSES = {
    ord('1'): 'Phi',
    ord('2'): 'Psi',
    ord('3'): 'Omega',
    ord('4'): 'Empty',
}

# Display modes — press B to cycle
DISPLAY_MODES = ['binary', 'grayscale', 'color']


# ==================== DISPLAY PROCESSING ====================
def to_binary(bgr_frame):
    """Adaptive threshold — black letter on white background.
    Best for verifying letter is clearly visible before capturing.
    """
    gray   = cv2.cvtColor(bgr_frame, cv2.COLOR_BGR2GRAY)
    binary = cv2.adaptiveThreshold(
        gray, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        blockSize=11,
        C=4
    )
    return cv2.cvtColor(binary, cv2.COLOR_GRAY2BGR)


def to_grayscale(bgr_frame):
    """Plain grayscale — same as what gets saved."""
    gray = cv2.cvtColor(bgr_frame, cv2.COLOR_BGR2GRAY)
    return cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)


def process_display(bgr_frame, mode):
    """Apply selected display mode."""
    if mode == 'binary':
        return to_binary(bgr_frame)
    elif mode == 'grayscale':
        return to_grayscale(bgr_frame)
    else:
        return bgr_frame.copy()   # color


# ==================== CSI CAMERA CLASS ====================
class CSI_Camera:
    """Thread-safe CSI camera reader (JetsonHacks, MIT License 2019-2022)."""

    def __init__(self):
        self.video_capture = None
        self.frame         = None
        self.grabbed       = False
        self.read_thread   = None
        self.read_lock     = threading.Lock()
        self.running       = False

    def open(self, gstreamer_pipeline_string):
        try:
            self.video_capture = cv2.VideoCapture(
                gstreamer_pipeline_string, cv2.CAP_GSTREAMER
            )
            self.grabbed, self.frame = self.video_capture.read()
        except RuntimeError:
            self.video_capture = None
            print("Unable to open camera")
            print("Pipeline: " + gstreamer_pipeline_string)

    def start(self):
        if self.running:
            print("Video capturing is already running")
            return None
        if self.video_capture is not None:
            self.running     = True
            self.read_thread = threading.Thread(target=self._update, daemon=True)
            self.read_thread.start()
        return self

    def stop(self):
        self.running = False
        if self.read_thread is not None:
            self.read_thread.join()
            self.read_thread = None

    def _update(self):
        while self.running:
            try:
                grabbed, frame = self.video_capture.read()
                with self.read_lock:
                    self.grabbed = grabbed
                    self.frame   = frame
            except RuntimeError:
                print("Could not read image from camera")

    def read(self):
        with self.read_lock:
            if self.frame is None:
                return False, None
            return self.grabbed, self.frame.copy()

    def release(self):
        self.stop()
        if self.video_capture is not None:
            self.video_capture.release()
            self.video_capture = None

    def is_open(self):
        return self.video_capture is not None and self.video_capture.isOpened()


# ==================== GSTREAMER PIPELINE ====================
def gstreamer_pipeline(
    sensor_id=0,
    capture_width=640,
    capture_height=480,
    display_width=640,
    display_height=480,
    framerate=30,
    flip_method=2,
):
    return (
        "nvarguscamerasrc sensor-id=%d ! "
        "video/x-raw(memory:NVMM), width=(int)%d, height=(int)%d, framerate=(fraction)%d/1 ! "
        "nvvidconv flip-method=%d ! "
        "video/x-raw, width=(int)%d, height=(int)%d, format=(string)BGRx ! "
        "videoconvert ! "
        "video/x-raw, format=(string)BGR ! appsink"
        % (sensor_id, capture_width, capture_height, framerate,
           flip_method, display_width, display_height)
    )


# ==================== HELPERS ====================
def count_images(class_name):
    folder = Path(OUTPUT_DIR) / class_name
    if not folder.exists():
        return 0
    return len(list(folder.glob("*.png"))) + len(list(folder.glob("*.jpg")))


def setup_folders():
    for class_name in CLASSES.values():
        (Path(OUTPUT_DIR) / class_name).mkdir(parents=True, exist_ok=True)
        print(f"  Folder ready: {OUTPUT_DIR}/{class_name}")


def draw_overlay(frame, class_name, cam_label, show_dual, display_mode):
    """Draw HUD + center square crop indicator."""
    h, w = frame.shape[:2]

    # Center square crop indicator
    side = min(h, w)
    sx   = (w - side) // 2
    sy   = (h - side) // 2
    cv2.rectangle(frame, (sx, sy), (sx+side, sy+side), (0, 255, 80), 1)

    # Mode label color
    mode_colors = {
        'binary'    : (255, 100, 100),
        'grayscale' : (200, 200, 200),
        'color'     : (100, 255, 100),
    }
    mode_color = mode_colors.get(display_mode, (200, 200, 200))

    # HUD text
    cv2.putText(frame, f"Class : {class_name}",              (10, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 80),   1)
    cv2.putText(frame, f"Camera: {cam_label}",               (10, 42), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 200, 255),  1)
    cv2.putText(frame, f"Saved : {count_images(class_name)}",(10, 62), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 220, 0),  1)
    cv2.putText(frame, f"View  : {display_mode.upper()}",    (10, 82), cv2.FONT_HERSHEY_SIMPLEX, 0.55, mode_color,     1)

    mode_text = "DUAL" if show_dual else "SINGLE"
    cv2.putText(frame, f"Mode: {mode_text}",
                (10, h - 30), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1)
    cv2.putText(frame, "SPC=Capture 1-4=Class L/R=Cam B=View S=Dual Q=Quit",
                (10, h - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.38, (180, 180, 180), 1)


def capture_image(frame, class_name, cam_label):
    """Center square crop -> plain grayscale -> resize -> save.
    Display mode does NOT affect saved images — always plain grayscale.
    """
    h, w = frame.shape[:2]

    side   = min(h, w)
    x      = (w - side) // 2
    y      = (h - side) // 2
    square = frame[y:y+side, x:x+side]

    gray    = cv2.cvtColor(square, cv2.COLOR_BGR2GRAY)
    resized = cv2.resize(gray, (IMAGE_SIZE, IMAGE_SIZE), interpolation=cv2.INTER_AREA)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:19]
    idx       = count_images(class_name)
    filename  = f"{class_name}_{cam_label}_{idx:04d}_{timestamp}.png"
    save_path = Path(OUTPUT_DIR) / class_name / filename

    cv2.imwrite(str(save_path), resized)
    print(f"  Saved [{cam_label}] -> {save_path}  ({idx + 1} total in {class_name})")

    # Preview flash — show binary so you can verify letter quality
    binary_preview = cv2.adaptiveThreshold(
        resized, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        blockSize=11, C=4
    )
    preview = cv2.resize(binary_preview, (300, 300), interpolation=cv2.INTER_NEAREST)
    cv2.imshow("Captured — Binary Preview", preview)
    cv2.waitKey(800)
    cv2.destroyWindow("Captured — Binary Preview")


# ==================== MAIN ====================
def run_capture():
    print("=" * 60)
    print("  GREEK LETTER DUAL CSI CAPTURE")
    print("  Press B to cycle: BINARY -> GRAYSCALE -> COLOR")
    print("  Saved files always: plain grayscale 500x500")
    print("=" * 60)
    setup_folders()
    print("=" * 60)

    left_cam  = CSI_Camera()
    right_cam = CSI_Camera()

    left_cam.open(gstreamer_pipeline(sensor_id=0))
    right_cam.open(gstreamer_pipeline(sensor_id=1))

    if not (left_cam.is_open() and right_cam.is_open()):
        print("WARNING: Could not open one or both CSI cameras.")
        print("Falling back to USB webcam (index 0).")
        left_cam.video_capture  = cv2.VideoCapture(0)
        right_cam.video_capture = cv2.VideoCapture(0)
        left_cam.grabbed,  left_cam.frame  = left_cam.video_capture.read()
        right_cam.grabbed, right_cam.frame = right_cam.video_capture.read()

    left_cam.start()
    right_cam.start()

    active_cam    = 'L'
    current_class = CLASSES[ord('1')]
    show_dual     = False
    display_mode  = 'binary'          # start in binary mode
    window_title  = "Greek Letter CSI Capture"

    cv2.namedWindow(window_title, cv2.WINDOW_AUTOSIZE)
    print(f"\n  Active camera  : Left  |  Class: {current_class}")
    print(f"  Display mode   : {display_mode.upper()} (press B to change)")
    print("  Green box      : exact area saved to file")
    print("  Press H for controls reminder.\n")

    try:
        while True:
            ok_l, left_frame  = left_cam.read()
            ok_r, right_frame = right_cam.read()

            if not ok_l or left_frame is None:
                print("Left camera read failed — skipping frame.")
                continue
            if not ok_r or right_frame is None:
                right_frame = left_frame.copy()

            cam_label = "LEFT" if active_cam == 'L' else "RIGHT"

            # Apply selected display mode
            lf_disp = process_display(left_frame,  display_mode)
            rf_disp = process_display(right_frame, display_mode)

            if show_dual:
                lf_display = lf_disp.copy()
                rf_display = rf_disp.copy()
                if active_cam == 'L':
                    draw_overlay(lf_display, current_class, "LEFT",  show_dual, display_mode)
                else:
                    draw_overlay(rf_display, current_class, "RIGHT", show_dual, display_mode)
                display = np.hstack((lf_display, rf_display))
            else:
                active_disp = lf_disp if active_cam == 'L' else rf_disp
                active_display = active_disp.copy()
                draw_overlay(active_display, current_class, cam_label, show_dual, display_mode)
                display = active_display

            cv2.imshow(window_title, display)

            key = cv2.waitKey(30) & 0xFF

            if key in (ord('q'), 27):
                print("\n  Quitting...")
                break

            elif key in CLASSES:
                current_class = CLASSES[key]
                print(f"  Class -> {current_class}")

            elif key == ord('l'):
                active_cam = 'L'
                print("  Camera -> LEFT")

            elif key == ord('r'):
                active_cam = 'R'
                print("  Camera -> RIGHT")

            elif key == ord('s'):
                show_dual = not show_dual
                print(f"  Dual preview -> {'ON' if show_dual else 'OFF'}")

            elif key == ord('b'):
                # Cycle through display modes
                idx_now      = DISPLAY_MODES.index(display_mode)
                display_mode = DISPLAY_MODES[(idx_now + 1) % len(DISPLAY_MODES)]
                print(f"  Display mode -> {display_mode.upper()}")

            elif key == ord('h'):
                print("\n  CONTROLS:")
                print("    1 / 2 / 3 / 4 : Class  (Phi / Psi / Omega / Empty)")
                print("    L / R         : Active camera")
                print("    SPACE         : Capture (saves plain grayscale)")
                print("    B             : Cycle display (Binary/Grayscale/Color)")
                print("    S             : Toggle dual side-by-side preview")
                print("    Q / ESC       : Quit\n")

            elif key == ord(' '):
                raw_frame = left_frame if active_cam == 'L' else right_frame
                capture_image(raw_frame, current_class, cam_label)

            if cv2.getWindowProperty(window_title, cv2.WND_PROP_AUTOSIZE) < 0:
                break

    finally:
        left_cam.stop()
        left_cam.release()
        right_cam.stop()
        right_cam.release()
        cv2.destroyAllWindows()

    print("\n" + "=" * 60)
    print("  CAPTURE SESSION COMPLETE")
    print("=" * 60)
    for class_name in CLASSES.values():
        print(f"    {class_name:<8s}: {count_images(class_name):4d} images")
    total = sum(count_images(c) for c in CLASSES.values())
    print(f"    {'TOTAL':<8s}: {total:4d} images")
    print("=" * 60)


if __name__ == "__main__":
    run_capture()