import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.preprocessing.image import ImageDataGenerator

import numpy as np
import cv2
import pickle
import json
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.utils import class_weight, resample

print("="*60)
print("FIXED TRAINING - BALANCED")
print("="*60)

# ==================== CONFIG ====================
IMG_SIZE   = 64
BATCH_SIZE = 16
EPOCHS     = 50
MODEL_NAME = 'greek_balanced'

DATA_PATH  = ('/home/orin_nano/Documents/RMaze_test_code/greek_letter/captured_dataset_3')

GREEK_LETTERS = ['Phi', 'Psi', 'Omega', 'Empty']

DEPLOY_FOLDER = Path('/home/orin_nano/Documents/RMaze_test_code/greek_letter/greek_data_balanced_11')


# ==================== LOAD DATA ====================
def load_images_from_named_folders(data_path, img_size=IMG_SIZE):
    """Load images from named folders: Phi/, Psi/, Omega/"""
    data_path = Path(data_path)

    if not data_path.exists():
        print(f"ERROR: Path not found -> {data_path.absolute()}")
        exit(1)

    print(f"\nLoading from: {data_path.absolute()}")

    images = []
    labels = []

    print("\n" + "="*60)
    print("LOADING IMAGES")
    print("="*60)

    for label_idx, letter_name in enumerate(GREEK_LETTERS):
        folder = data_path / letter_name

        if not folder.exists():
            print(f"  WARNING: Folder not found -> {folder}")
            continue

        img_files = (list(folder.glob('*.png')) +
                     list(folder.glob('*.jpg')) +
                     list(folder.glob('*.jpeg')))

        print(f"  {letter_name:<8s} (label {label_idx})...", end=' ')
        count = 0

        for img_file in img_files:
            try:
                img = cv2.imread(str(img_file), cv2.IMREAD_GRAYSCALE)
                if img is None:
                    continue

                img = cv2.resize(img, (img_size, img_size))
                img = img.astype(np.float32) / 255.0

                images.append(img)
                labels.append(label_idx)
                count += 1

            except Exception:
                continue

        print(f"{count} images")

    if len(images) == 0:
        print("\nERROR: No images loaded. Check DATA_PATH and folder names.")
        exit(1)

    return np.array(images), np.array(labels)


X, y = load_images_from_named_folders(DATA_PATH)
X = X.reshape(-1, IMG_SIZE, IMG_SIZE, 1)

print(f"\n{'='*60}")
print("DATASET ANALYSIS")
print("="*60)
print(f"Total    : {len(X)} images")
print(f"Img size : {IMG_SIZE}x{IMG_SIZE} px")
print(f"Shape    : {X.shape}")

# Class distribution
unique, counts = np.unique(y, return_counts=True)
print(f"\nClass distribution:")

max_count       = max(counts)
min_count       = min(counts)
imbalance_ratio = max_count / min_count

for u, c in zip(unique, counts):
    letter     = GREEK_LETTERS[u]
    percentage = c / len(y) * 100
    bar        = '#' * int(percentage // 2)
    print(f"  {letter:<8s}: {c:4d} ({percentage:5.1f}%) {bar}")

print(f"\nImbalance ratio: {imbalance_ratio:.2f}:1")

if imbalance_ratio > 2.0:
    print("WARNING: SEVERE IMBALANCE DETECTED — using class weights + oversampling.")

# Class weights
class_weights      = class_weight.compute_class_weight(
    'balanced', classes=np.unique(y), y=y
)
class_weights_dict = {i: w for i, w in enumerate(class_weights)}

print(f"\nClass weights (higher = more important):")
for i, w in class_weights_dict.items():
    print(f"  {GREEK_LETTERS[i]:<8s}: {w:.3f}")


# ==================== BALANCE DATASET ====================
print(f"\n{'='*60}")
print("BALANCING DATASET")
print("="*60)

X_balanced = []
y_balanced = []

target_size = int(max_count * 0.8)
print(f"Target size per class: {target_size}")

for class_idx in range(len(GREEK_LETTERS)):
    mask    = y == class_idx
    X_class = X[mask]
    y_class = y[mask]
    current = len(X_class)

    if current == 0:
        print(f"  {GREEK_LETTERS[class_idx]:<8s}: no samples — skipped")
        continue

    if current < target_size:
        X_res, y_res = resample(X_class, y_class,
                                n_samples=target_size, random_state=42)
        print(f"  {GREEK_LETTERS[class_idx]:<8s}: {current} -> {target_size} (oversampled)")
    else:
        X_res = X_class[:target_size]
        y_res = y_class[:target_size]
        print(f"  {GREEK_LETTERS[class_idx]:<8s}: {current} -> {target_size} (kept)")

    X_balanced.append(X_res)
    y_balanced.append(y_res)

X = np.vstack(X_balanced)
y = np.concatenate(y_balanced)

print(f"\nBalanced dataset: {len(X)} images")

# Shuffle
idx = np.random.permutation(len(X))
X, y = X[idx], y[idx]

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
print(f"Split: {len(X_train)} train  |  {len(X_test)} test")


# ==================== DATA AUGMENTATION ====================
datagen = ImageDataGenerator(
    rotation_range=20,
    width_shift_range=0.2,
    height_shift_range=0.2,
    zoom_range=0.2,
    shear_range=0.15,
    fill_mode='constant',
    cval=0
)


# ==================== MODEL ====================
def create_model(input_shape, num_classes):
    model = keras.Sequential([
        layers.Input(shape=input_shape),

        layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
        layers.BatchNormalization(),
        layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
        layers.MaxPooling2D((2, 2)),
        layers.Dropout(0.3),

        layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
        layers.BatchNormalization(),
        layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
        layers.MaxPooling2D((2, 2)),
        layers.Dropout(0.4),

        layers.Flatten(),
        layers.Dense(128, activation='relu'),
        layers.BatchNormalization(),
        layers.Dropout(0.5),
        layers.Dense(num_classes, activation='softmax')
    ])
    return model


num_classes = len(GREEK_LETTERS)
model = create_model(input_shape=(IMG_SIZE, IMG_SIZE, 1), num_classes=num_classes)

model.compile(
    optimizer=keras.optimizers.Adam(learning_rate=0.0005),
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

print("\n" + "="*60)
print("MODEL")
print("="*60)
model.summary()


# ==================== TRAINING ====================
print("\n" + "="*60)
print("TRAINING")
print("="*60)

callbacks = [
    keras.callbacks.EarlyStopping(
        monitor='val_accuracy',
        patience=15,
        restore_best_weights=True,
        verbose=1
    ),
    keras.callbacks.ReduceLROnPlateau(
        monitor='val_loss',
        factor=0.5,
        patience=7,
        verbose=1
    )
]

history = model.fit(
    datagen.flow(X_train, y_train, batch_size=BATCH_SIZE),
    validation_data=(X_test, y_test),
    epochs=EPOCHS,
    steps_per_epoch=len(X_train) // BATCH_SIZE,
    callbacks=callbacks,
    class_weight=class_weights_dict,
    verbose=1
)


# ==================== EVALUATE ====================
print("\n" + "="*60)
print("EVALUATION")
print("="*60)

test_loss, test_acc = model.evaluate(X_test, y_test, verbose=0)
print(f"Test Accuracy: {test_acc*100:.2f}%")

y_pred         = model.predict(X_test, verbose=0)
y_pred_classes = np.argmax(y_pred, axis=1)

print(f"\nPer-class accuracy:")
for i in range(num_classes):
    mask = y_test == i
    if mask.sum() > 0:
        class_acc = (y_pred_classes[mask] == i).mean()
        print(f"  {GREEK_LETTERS[i]:<8s}: {class_acc*100:.1f}%")

print(f"\nPrediction distribution on test set:")
for i in range(num_classes):
    count      = (y_pred_classes == i).sum()
    percentage = count / len(y_pred_classes) * 100
    print(f"  {GREEK_LETTERS[i]:<8s}: {count:3d} predictions ({percentage:.1f}%)")


# ==================== SAVE (pickle — no h5py needed) ====================
print("\n" + "="*60)
print("SAVING")
print("="*60)

DEPLOY_FOLDER.mkdir(parents=True, exist_ok=True)

# 1 — Save model architecture as JSON
arch_path = DEPLOY_FOLDER / f'{MODEL_NAME}_config.json'
with open(str(arch_path), 'w') as f:
    f.write(model.to_json())
print(f"Saved architecture : {arch_path}")

# 2 — Save weights using pickle (handles mixed layer shapes, no h5py)
weights      = model.get_weights()
weights_path = DEPLOY_FOLDER / f'{MODEL_NAME}_weights.pkl'
with open(str(weights_path), 'wb') as f:
    pickle.dump(weights, f)
print(f"Saved weights      : {weights_path}")

# 3 — Save labels
labels_path = DEPLOY_FOLDER / 'labels.txt'
with open(str(labels_path), 'w') as f:
    for letter in GREEK_LETTERS:
        f.write(f"{letter}\n")
print(f"Saved labels       : {labels_path}")

# 4 — Save config
config = {
    'img_size'     : IMG_SIZE,
    'num_classes'  : num_classes,
    'test_accuracy': float(test_acc),
    'labels'       : GREEK_LETTERS,
    'weights_file' : f'{MODEL_NAME}_weights.pkl',
    'arch_file'    : f'{MODEL_NAME}_config.json',
    'data_path'    : DATA_PATH,
}
config_path = DEPLOY_FOLDER / 'config.json'
with open(str(config_path), 'w') as f:
    json.dump(config, f, indent=2)
print(f"Saved config       : {config_path}")

# 5 — Show file sizes
arch_size    = arch_path.stat().st_size / 1024
weights_size = weights_path.stat().st_size / 1024
print(f"\nFile sizes:")
print(f"  Architecture : {arch_size:.1f} KB")
print(f"  Weights      : {weights_size:.1f} KB")
print(f"  Total        : {arch_size + weights_size:.1f} KB")
print(f"\nAccuracy       : {test_acc*100:.1f}%")

print("\n" + "="*60)
print("HOW TO LOAD IN detect_live.py:")
print("="*60)
print("="*60)