#!/usr/bin/env python3
"""
ROBOCUP RESCUE - JETSON UNIFIED SYSTEM V6
Protocol:  RAB-style — echo + OK, carriage-return terminated
           f <mm>\r  → f\r (echo) → OK [tile]\r
Self-corr: wall snap (SR/SL) + front distance step sizing (FR/FL)
ESTOP:     ESP32 button sends ESTOP\r at any time — unblocks everything
"""

import time
import cv2
import numpy as np
import Jetson.GPIO as GPIO
from smbus2 import SMBus
import threading
import os
import queue
import serial
import serial.tools.list_ports

# =========================================================
# CONFIG
# =========================================================

GPIO.setmode(GPIO.BOARD)
I2C_BUS = 7

SENSORS_TOF = {
    'FR': {'pin': 13,  'addr': 0x31, 'name': 'Front-Right'},
    'FC': {'pin': 15, 'addr': 0x32, 'name': 'Front-Center'},
    'SR': {'pin': 16, 'addr': 0x33, 'name': 'Side-Right'},
    'SL': {'pin': 11, 'addr': 0x34, 'name': 'Side-Left'},
}

LED_R = 33
LED_G = 31
LED_B = 32


LED_COMMANDS = {
    'W': (True,  True,  True),   # white — blinked once by _blink_worker
    'S': (True,  True,  True),
    'B': (True,  False, True),
    'U': (False, False, True),
    'R': (True,  False, False),
}

# Navigation wall detection
WALL_THRESHOLD_MM      = 300
# Emergency stop — must be much tighter to avoid false triggers
EMERGENCY_THRESHOLD_MM = 50

# Self-correction
CELL_MM               = 300   # nominal tile size
FRONT_STANDOFF_MM     = 150   # expected distance from wall to cell centre
FRONT_STEP_MIN_MM     = 200   # clamp range for front-distance step sizing
FRONT_STEP_MAX_MM     = 400
SNAP_TOLERANCE_MM     = 25    # lateral offset threshold for wall snap log
SIDE_STANDOFF_MM      = 150   # expected side standoff in a corridor

SERIAL_PORT      = '/dev/ttyACM0'
SERIAL_BAUDRATE  = 115200
SERIAL_TIMEOUT   = 0.1        # short timeout — we poll in a thread

# RAB protocol timeouts
ECHO_TIMEOUT_SEC = 0.5        # max wait for echo after sending command
DONE_TIMEOUT_SEC = 30.0       # max wait for OK after echo

NORTH = 0
EAST  = 90
SOUTH = 180
WEST  = 270

# GUI
MAP_PANEL_PX   = 500
MAP_CELL_MIN   = 8
WALL_THICKNESS = 3

COLOR_BACKGROUND = (40,  40,  40)
COLOR_WALL       = (220, 220, 220)
COLOR_ROBOT      = (0,   0,   255)
COLOR_VISITED    = (60,  120, 200)
COLOR_DISCOVERED = (100, 100, 100)
COLOR_UNKNOWN    = (80,  160, 255)   # light orange

TILE_FILL_BGR = {
    'WHITE':  (230, 230, 230),
    'SILVER': (160, 160, 160),
    'BLACK':  (20,  20,  20),
    'BLUE':   (200, 80,  0),
    'RED':    (0,   0,   200),
}

# =========================================================
# STATE MACHINE
# =========================================================

STATE_CALIBRATION    = 0
STATE_START_DETECTION = 1
STATE_NAVIGATION     = 2

# Serial wait states
SERIAL_IDLE      = 0   # ready to send
SERIAL_WAIT_ECHO = 1   # sent command, waiting for echo
SERIAL_WAIT_DONE = 2   # got echo, waiting for OK

# =========================================================
# GLOBALS
# =========================================================

readings_tof           = {}
current_color          = "UNKNOWN"
running                = True
bus                    = None
offsets                = {}
ser                    = None

# RAB-style serial state
serial_state           = SERIAL_IDLE
last_command_sent      = ""
last_response_received = ""
last_send_time         = 0.0
send_retry_count       = 0
MAX_RETRIES            = 1

system_state           = STATE_CALIBRATION
calibration_count      = 0
nav_start_time         = 0.0   # timestamp when navigation started (for button lockout)

# Emergency
emergency_stop_active    = False
emergency_stop_reason    = ""
emergency_recovery_until = 0.0

# ESTOP button
estop_active             = False
estop_paused             = False   # True = full pause (second press)
estop_until              = 0.0    # auto-resume timestamp

# Self-correction
heading_correction_deg   = 0.0    # accumulated heading correction
lateral_offset_log       = []     # recent SR/SL offset readings

# LED blink control
_blink_thread = None
_blink_stop   = threading.Event()

# =========================================================
# RGB LED
# =========================================================

def setup_gpio():
    try:
        GPIO.setup(LED_R, GPIO.OUT)
        GPIO.setup(LED_G, GPIO.OUT)
        GPIO.setup(LED_B, GPIO.OUT)
        time.sleep(0.1)
        led_off()
        print(f"✓ RGB LED ready\n")
    except Exception as e:
        print(f"GPIO error: {e}\n")

def led_off():
    global _blink_stop
    _blink_stop.set()   # stop any running blink
    try:
        GPIO.output(LED_R, GPIO.HIGH)
        GPIO.output(LED_G, GPIO.HIGH)
        GPIO.output(LED_B, GPIO.HIGH)
    except:
        pass

def set_led(r, g, b):
    try:
        GPIO.output(LED_R, GPIO.LOW if r else GPIO.HIGH)
        GPIO.output(LED_G, GPIO.LOW if g else GPIO.HIGH)
        GPIO.output(LED_B, GPIO.LOW if b else GPIO.HIGH)
    except:
        pass

def _blink_worker(r, g, b, interval):
    """Background thread — blinks LED once then stops."""
    set_led(r, g, b)
    time.sleep(interval)
    try:
        GPIO.output(LED_R, GPIO.HIGH)
        GPIO.output(LED_G, GPIO.HIGH)
        GPIO.output(LED_B, GPIO.HIGH)
    except:
        pass

def light_color(color_code):
    global _blink_thread, _blink_stop

    # stop any existing blink
    _blink_stop.set()
    if _blink_thread and _blink_thread.is_alive():
        _blink_thread.join(timeout=0.5)
    _blink_stop.clear()

    if color_code not in LED_COMMANDS:
        led_off()
        return

    r, g, b = LED_COMMANDS[color_code]

    if color_code == 'W':
        # White tile — single blink
        _blink_thread = threading.Thread(
            target=_blink_worker,
            args=(True, True, True, 0.3),
            daemon=True
        )
        _blink_thread.start()
    else:
        set_led(r, g, b)

# =========================================================
# TILE MAP
# =========================================================

class TileMap:
    COLOR_NAMES = {'W':'WHITE','S':'SILVER','B':'BLACK','U':'BLUE','R':'RED'}

    def __init__(self):
        self.tiles = {}

    def record_tile(self, x, y, color_code):
        name = self.COLOR_NAMES.get(color_code, 'UNKNOWN')
        self.tiles[(x, y)] = name
        print(f"  ✓ Tile ({x},{y}) = {name}")

    def get_tile(self, x, y):
        return self.tiles.get((x, y), None)

    def is_black_tile(self, x, y):
        return self.get_tile(x, y) == 'BLACK'

# =========================================================
# MAP ROBOT
# =========================================================

class MapRobot:
    def __init__(self):
        self.x       = 4
        self.y       = 4
        self.heading = EAST

        self.visited     = {(self.x, self.y)}
        self.visit_count = {(self.x, self.y): 1}
        self.discovered  = {(self.x, self.y)}
        self.memory_walls = {}
        self.last_action  = ""

    def update_walls_from_sensors(self, fc, sr, sl):
        directional = {
            'FRONT': (self.heading,              fc),
            'RIGHT': ((self.heading + 90) % 360, sr),
            'LEFT':  ((self.heading - 90) % 360, sl),
        }
        for _, (hdg, dist) in directional.items():
            if dist >= 0:
                self.memory_walls[(self.x, self.y, hdg)] = (dist < WALL_THRESHOLD_MM)
        self.discovered.add((self.x, self.y))

    def knows_wall(self, x, y, direction):
        return self.memory_walls.get((x, y, direction), None)

    def next_pos(self, heading):
        if heading == NORTH: return self.x, self.y - 1
        if heading == EAST:  return self.x + 1, self.y
        if heading == SOUTH: return self.x, self.y + 1
        return self.x - 1, self.y

    def map_bounds(self):
        all_cells = self.discovered | self.visited | {(self.x, self.y)}
        xs = [c[0] for c in all_cells]
        ys = [c[1] for c in all_cells]
        return min(xs)-1, min(ys)-1, max(xs)+1, max(ys)+1

    def grid_span(self):
        mnx, mny, mxx, mxy = self.map_bounds()
        return (mxx - mnx + 1), (mxy - mny + 1)

    def cell_size(self):
        cols, rows = self.grid_span()
        return max(MAP_CELL_MIN, MAP_PANEL_PX // max(cols, rows))

    def move_forward(self):
        self.x, self.y = self.next_pos(self.heading)
        self.visited.add((self.x, self.y))
        self.visit_count[(self.x, self.y)] = self.visit_count.get((self.x, self.y), 0) + 1
        self.discovered.add((self.x, self.y))

    def turn_left(self):
        self.heading = (self.heading - 90) % 360

    def turn_right(self):
        self.heading = (self.heading + 90) % 360

    def choose_next_move(self, tile_map):
        candidates = [
            ("MR LFT", (self.heading - 90) % 360),
            ("MR FWD",  self.heading),
            ("MR RGT", (self.heading + 90) % 360),
        ]
        options = []
        for cmd, hdg in candidates:
            if self.memory_walls.get((self.x, self.y, hdg), None) is True:
                continue
            nx, ny = self.next_pos(hdg)
            if tile_map.is_black_tile(nx, ny):
                continue
            score = self.visit_count.get((nx, ny), 0)
            if (nx, ny) not in self.discovered:
                score -= 50
            options.append((cmd, hdg, score))

        if not options:
            self.last_action = "U-TURN"
            return "U-TURN"

        best_cmd, _, _ = min(options, key=lambda x: x[2])
        self.last_action = best_cmd
        return best_cmd

# =========================================================
# SENSOR OFFSETS
# =========================================================

def load_offsets():
    global offsets
    offsets = {}
    if os.path.exists('sensor_offsets.txt'):
        try:
            with open('sensor_offsets.txt', 'r') as f:
                for line in f:
                    parts = line.strip().split(': ')
                    if len(parts) == 2:
                        offsets[parts[0]] = float(parts[1])
            print(f"✓ Loaded {len(offsets)} offsets\n")
        except Exception as e:
            print(f"Offset load error: {e}\n")
    else:
        print("No sensor_offsets.txt\n")

# =========================================================
# VL53L0X
# =========================================================

def init_vl53l0x(addr):
    bus.write_byte_data(addr, 0x89, 0x01)
    bus.write_byte_data(addr, 0x88, 0x00)
    bus.write_byte_data(addr, 0x80, 0x01)
    bus.write_byte_data(addr, 0xFF, 0x01)
    bus.write_byte_data(addr, 0x00, 0x00)
    stop_var = bus.read_byte_data(addr, 0x91)
    bus.write_byte_data(addr, 0x00, 0x01)
    bus.write_byte_data(addr, 0xFF, 0x00)
    bus.write_byte_data(addr, 0x80, 0x00)

    tuning = [
        (0xFF,0x01),(0x00,0x00),(0xFF,0x00),(0x09,0x00),(0x10,0x00),(0x11,0x00),
        (0x24,0x01),(0x25,0xFF),(0x75,0x00),(0xFF,0x01),(0x4E,0x2C),(0x48,0x00),
        (0x30,0x20),(0xFF,0x00),(0x30,0x09),(0x54,0x00),(0x31,0x04),(0x32,0x03),
        (0x40,0x83),(0x46,0x25),(0x60,0x00),(0x27,0x00),(0x50,0x06),(0x51,0x00),
        (0x52,0x96),(0x56,0x08),(0x57,0x30),(0x61,0x00),(0x62,0x00),(0x64,0x00),
        (0x65,0x00),(0x66,0xA0),(0xFF,0x01),(0x22,0x32),(0x47,0x14),(0x49,0xFF),
        (0x4A,0x00),(0xFF,0x00),(0x7A,0x0A),(0x7B,0x00),(0x78,0x21),(0xFF,0x01),
        (0x23,0x34),(0x42,0x00),(0x44,0xFF),(0x45,0x26),(0x46,0x05),(0x40,0x40),
        (0x0E,0x06),(0x20,0x1A),(0x43,0x40),(0xFF,0x00),(0x34,0x03),(0x35,0x44),
        (0xFF,0x01),(0x31,0x04),(0x4B,0x09),(0x4C,0x05),(0x4D,0x04),(0xFF,0x00),
        (0x44,0x00),(0x45,0x20),(0x47,0x08),(0x48,0x28),(0x67,0x00),(0x70,0x04),
        (0x71,0x01),(0x72,0xFE),(0x76,0x00),(0x77,0xFF),(0xFF,0x01),(0x0D,0x01),
        (0xFF,0x00),(0x80,0x01),(0x01,0xF8),(0xFF,0x01),(0x8E,0x01),(0x00,0x01),
        (0xFF,0x00),(0x80,0x00),
    ]
    for reg, val in tuning:
        bus.write_byte_data(addr, reg, val)

    bus.write_byte_data(addr, 0x0A, 0x04)
    v = bus.read_byte_data(addr, 0x84)
    bus.write_byte_data(addr, 0x84, v | 0x10)
    bus.write_byte_data(addr, 0x0B, 0x01)
    bus.write_byte_data(addr, 0x01, 0xE8)

    for phase, seq in [(0x01, 0x01), (0x02, 0x02)]:
        bus.write_byte_data(addr, 0x01, phase)
        bus.write_byte_data(addr, 0x00, 0x01)
        for _ in range(100):
            if bus.read_byte_data(addr, 0x13) & 0x07: break
            time.sleep(0.005)
        bus.write_byte_data(addr, 0x0B, 0x01)
        bus.write_byte_data(addr, 0x00, 0x00)

    bus.write_byte_data(addr, 0x01, 0xE8)
    bus.write_byte_data(addr, 0x80, 0x01)
    bus.write_byte_data(addr, 0xFF, 0x01)
    bus.write_byte_data(addr, 0x00, 0x00)
    bus.write_byte_data(addr, 0x91, stop_var)
    bus.write_byte_data(addr, 0x00, 0x01)
    bus.write_byte_data(addr, 0xFF, 0x00)
    bus.write_byte_data(addr, 0x80, 0x00)
    bus.write_byte_data(addr, 0x04, 0x00)
    bus.write_byte_data(addr, 0x00, 0x02)
    time.sleep(0.1)

def read_distance(addr):
    try:
        for _ in range(50):
            if bus.read_byte_data(addr, 0x13) & 0x07: break
            time.sleep(0.001)
        h = bus.read_byte_data(addr, 0x1E)
        l = bus.read_byte_data(addr, 0x1F)
        d = (h << 8) | l
        bus.write_byte_data(addr, 0x0B, 0x01)
        return d if d < 8000 else -1
    except:
        return -1

def read_distance_with_offset(addr, sensor_id):
    raw = read_distance(addr)
    if raw < 0: return -1
    return raw + offsets.get(sensor_id, 0)

def init_tof_sensors():
    global bus
    bus = SMBus(I2C_BUS)
    print("\n" + "="*60)
    print("Initializing TOF sensors (FR FL SR SL)...")
    print("="*60 + "\n")

    for sid, cfg in SENSORS_TOF.items():
        GPIO.setup(cfg['pin'], GPIO.OUT)
        GPIO.output(cfg['pin'], GPIO.LOW)
    time.sleep(1.0)

    initialized = []
    for sid, cfg in SENSORS_TOF.items():
        success = False
        for attempt in range(3):
            try:
                print(f"[{sid}] attempt {attempt+1}...", end=" ", flush=True)
                GPIO.output(cfg['pin'], GPIO.HIGH)
                time.sleep(0.25)
                init_vl53l0x(0x29)
                bus.write_byte_data(0x29, 0x8A, cfg['addr'] & 0x7F)
                time.sleep(0.15)
                model = bus.read_byte_data(cfg['addr'], 0xC0)
                if model != 0xEE:
                    raise ValueError(f"Bad model 0x{model:02X}")
                print(f"✓ 0x{cfg['addr']:02X}")
                initialized.append(sid)
                success = True
                break
            except Exception as e:
                print(f"✗ {e}")
                GPIO.output(cfg['pin'], GPIO.LOW)
                time.sleep(0.3)
        if not success:
            print(f"[{sid}] *** failed ***")

    print(f"\n✓ {len(initialized)}/4 ready\n")
    return initialized

# =========================================================
# SERIAL — RAB STYLE
# =========================================================

def open_serial():
    global ser
    print("Connecting to ESP32...")
    for port in [SERIAL_PORT, '/dev/ttyUSB0', '/dev/ttyUSB1', '/dev/ttyACM1']:
        try:
            ser = serial.Serial(port, SERIAL_BAUDRATE, timeout=SERIAL_TIMEOUT)
            time.sleep(2)
            ser.reset_input_buffer()
            print(f"✓ Serial: {port}\n")
            return True
        except:
            pass
    print("WARNING: No serial connection\n")
    return False

def _raw_send(command):
    """Send a command terminated with carriage return."""
    if not ser:
        return False
    try:
        ser.write((command + "\r").encode())
        ser.flush()
        return True
    except:
        return False

def send_command(command):
    """
    Send command and enter WAIT_ECHO state.
    Returns False if already waiting or serial not available.
    """
    global serial_state, last_command_sent, last_send_time, send_retry_count
    if serial_state != SERIAL_IDLE:
        return False
    if not _raw_send(command):
        return False
    last_command_sent  = command
    last_send_time     = time.time()
    serial_state       = SERIAL_WAIT_ECHO
    send_retry_count   = 0
    print(f"  → {command}")
    return True

def send_raw_estop_ack():
    """Send nothing — ESTOP from ESP32 needs no reply."""
    pass

# =========================================================
# SELF-CORRECTION HELPERS
# =========================================================

def compute_forward_mm():
    """
    Self-correction 2 — front distance step sizing.
    If a front wall is visible, use its distance to determine
    how far to move instead of always using CELL_MM.
    """
    fc = readings_tof.get('FC', -1)
    if fc < 0:
        return CELL_MM
    front_dist = fc
    if front_dist > FRONT_STEP_MAX_MM + FRONT_STANDOFF_MM:
        return CELL_MM   # wall too far to use for sizing — default
    move_mm = front_dist - FRONT_STANDOFF_MM
    move_mm = max(FRONT_STEP_MIN_MM, min(FRONT_STEP_MAX_MM, move_mm))
    print(f"  [STEP] front={front_dist}mm → move={move_mm:.0f}mm")
    return int(move_mm)

def check_wall_snap():
    """
    Self-correction 1 — wall snap.
    After a forward move, if both side walls are present,
    compute lateral offset and log heading correction suggestion.
    Returns correction_deg (+ve = nudge right, -ve = nudge left).
    """
    global heading_correction_deg, lateral_offset_log
    sr = readings_tof.get('SR', -1)
    sl = readings_tof.get('SL', -1)

    sr_wall = sr >= 0 and sr < WALL_THRESHOLD_MM
    sl_wall = sl >= 0 and sl < WALL_THRESHOLD_MM

    if not (sr_wall and sl_wall):
        return 0.0   # not in a corridor — can't snap

    # Positive offset → drifted right (SR closer than SL)
    offset_mm = sr - sl
    lateral_offset_log.append(offset_mm)
    if len(lateral_offset_log) > 5:
        lateral_offset_log.pop(0)

    if abs(offset_mm) < SNAP_TOLERANCE_MM:
        return 0.0

    # Convert lateral offset to approximate heading correction
    # For a 300mm cell width: 1mm offset ≈ 0.19° heading error
    correction = offset_mm * 0.19
    heading_correction_deg = correction
    print(f"  [SNAP] SR={sr}mm SL={sl}mm offset={offset_mm:+.0f}mm → correction={correction:+.1f}°")
    return correction

def get_turn_angle(base_angle_deg):
    """
    Apply accumulated heading correction to a turn.
    base_angle_deg: +90 for right, -90 for left.
    """
    global heading_correction_deg
    corrected = base_angle_deg + heading_correction_deg
    # Clamp: don't correct more than 5° per turn
    corrected = max(base_angle_deg - 5, min(base_angle_deg + 5, corrected))
    if corrected != base_angle_deg:
        print(f"  [TURN] {base_angle_deg:+.0f}° → {corrected:+.1f}° (correction {heading_correction_deg:+.1f}°)")
    heading_correction_deg = 0.0   # consume correction
    return corrected

# =========================================================
# SERIAL RECEIVE + PROTOCOL STATE MACHINE
# =========================================================

robot    = MapRobot()
tile_map = TileMap()

# Queue for passing completed motion results to draw_gui
motion_result_queue = queue.Queue()

def process_line(line):
    """
    Parse one line from ESP32 and advance the protocol state machine.
    Called from serial_thread only.
    """
    global serial_state, last_response_received, last_send_time
    global system_state, calibration_count, current_color
    global emergency_stop_active, emergency_stop_reason, emergency_recovery_until
    global estop_active, estop_paused, estop_until
    global nav_start_time

    if not line:
        return
    last_response_received = line
    parts = line.split()

    # ── ESTOP from button — accepted at ANY time ──────────────────
    if parts[0] == "ESTOP":
        print(f"  !! ESTOP received from ESP32 button !!")
        serial_state         = SERIAL_IDLE   # unblock immediately
        emergency_stop_active = False
        emergency_recovery_until = 0.0

        if estop_active and time.time() < estop_until:
            # Second press within freeze window → full pause
            estop_paused = True
            estop_until  = 0.0
            print(f"  [ESTOP] Full pause — press button again to resume")
        elif estop_paused:
            # Third press → unpause
            estop_paused = False
            estop_active = False
            print(f"  [ESTOP] Resumed")
        else:
            # First press → freeze 5 seconds then auto-resume
            estop_active = True
            estop_paused = False
            estop_until  = time.time() + 5.0
            print(f"  [ESTOP] Frozen for 5s — auto-resume at t+5s")
        motion_result_queue.put(('ESTOP', None))
        return

    # ── Echo — confirms command was received by ESP32 ─────────────
    if serial_state == SERIAL_WAIT_ECHO:
        # Echo is the command letter (first char of what we sent)
        expected_echo = last_command_sent[0] if last_command_sent else ''
        if parts[0] == expected_echo or line.startswith(expected_echo):
            print(f"  ← echo: {line}")
            serial_state   = SERIAL_WAIT_DONE
            # Reset timer for the longer DONE timeout
            last_send_time = time.time()
            return

    # ── OK [tile] — motion complete ───────────────────────────────
    if serial_state == SERIAL_WAIT_DONE and parts[0] == "OK":
        tile_code = parts[1][0] if len(parts) >= 2 else None
        serial_state = SERIAL_IDLE
        print(f"  ← OK{(' ' + parts[1]) if tile_code else ''}")

        if tile_code and system_state == STATE_NAVIGATION:
            current_color = parts[1]
            light_color(tile_code)

            if tile_code == 'B':
                bx, by = robot.next_pos(robot.heading)
                tile_map.record_tile(bx, by, 'B')
                rev = (robot.heading + 180) % 360
                robot.x, robot.y = robot.next_pos(rev)
                robot.visited.add((robot.x, robot.y))
                robot.visit_count[(robot.x, robot.y)] = \
                    robot.visit_count.get((robot.x, robot.y), 0) + 1
                robot.discovered.add((robot.x, robot.y))
                print(f"  [BLACK] map ({bx},{by}), robot back to ({robot.x},{robot.y})")
            elif tile_code != 'W':
                tile_map.record_tile(robot.x, robot.y, tile_code)

        # Check wall snap after forward move
        if last_command_sent.startswith('f'):
            check_wall_snap()

        motion_result_queue.put(('OK', tile_code))
        return

    # ── CR — calibration and start detection ─────────────────────
    if parts[0] == "CR" and len(parts) >= 2:
        value         = parts[1]
        current_color = value
        color_code    = value[0] if value else ''

        if system_state == STATE_CALIBRATION:
            light_color(color_code)   # show colour during calibration
            calibration_count += 1
            print(f"  ✓ Calibration {calibration_count}/5: {value}")
            if calibration_count >= 5:
                system_state = STATE_START_DETECTION
                # red is already lit — hold 1s then turn off
                def _delayed_off():
                    time.sleep(1.0)
                    led_off()
                threading.Thread(target=_delayed_off, daemon=True).start()
                print(f"\n  → CALIBRATION → START_DETECTION\n")

        elif system_state == STATE_START_DETECTION:
            light_color(color_code)
            print(f"  ✓ START: {value}")
            tile_map.record_tile(robot.x, robot.y, color_code)
            system_state   = STATE_NAVIGATION
            nav_start_time = time.time()
            print(f"  → START_DETECTION → NAVIGATION\n")

        motion_result_queue.put(('CR', value))
        return

def serial_thread():
    """
    Read lines from ESP32 and feed them to process_line.
    Also handles echo timeout / retry logic.
    """
    global serial_state, last_send_time, send_retry_count
    global running

    buf = ""
    while running:
        # ── Timeout checks ────────────────────────────────────────
        now = time.time()

        if serial_state == SERIAL_WAIT_ECHO:
            if now - last_send_time > ECHO_TIMEOUT_SEC:
                if send_retry_count < MAX_RETRIES:
                    send_retry_count += 1
                    print(f"  ✗ Echo timeout — retry {send_retry_count}")
                    _raw_send(last_command_sent)
                    last_send_time = now
                else:
                    print(f"  ✗ Echo timeout — giving up on: {last_command_sent}")
                    serial_state = SERIAL_IDLE
                    motion_result_queue.put(('TIMEOUT', 'echo'))

        elif serial_state == SERIAL_WAIT_DONE:
            if now - last_send_time > DONE_TIMEOUT_SEC:
                print(f"  ✗ Done timeout — robot may be stuck")
                serial_state = SERIAL_IDLE
                motion_result_queue.put(('TIMEOUT', 'done'))

        # ── Read bytes ────────────────────────────────────────────
        if ser and ser.in_waiting > 0:
            try:
                chunk = ser.read(ser.in_waiting).decode('utf-8', errors='ignore')
                buf  += chunk
                while '\r' in buf or '\n' in buf:
                    for sep in ('\r\n', '\r', '\n'):
                        if sep in buf:
                            line, buf = buf.split(sep, 1)
                            line = line.strip()
                            if line:
                                process_line(line)
                            break
            except:
                pass

        time.sleep(0.005)

# =========================================================
# TOF THREAD
# =========================================================

def tof_thread():
    global running, readings_tof
    time.sleep(1)
    sensor_ids = list(SENSORS_TOF.keys())
    first_read = True

    while running:
        if first_read:
            for sid in sensor_ids:
                read_distance_with_offset(SENSORS_TOF[sid]['addr'], sid)
                time.sleep(0.01)
            first_read = False
            time.sleep(0.2)
            continue

        for sid in sensor_ids:
            readings_tof[sid] = read_distance_with_offset(
                SENSORS_TOF[sid]['addr'], sid)
            time.sleep(0.01)

        fc = readings_tof.get('FC', -1)
        sr = readings_tof.get('SR', -1)
        sl = readings_tof.get('SL', -1)
        robot.update_walls_from_sensors(fc, sr, sl)
        time.sleep(0.05)

# =========================================================
# DECISION MAKING
# =========================================================

def check_emergency():
    fc = readings_tof.get('FC', -1)
    sr = readings_tof.get('SR', -1)
    sl = readings_tof.get('SL', -1)
    if fc >= 0 and fc < EMERGENCY_THRESHOLD_MM: return True, f"FC {fc:.0f}mm"
    if sr >= 0 and sr < EMERGENCY_THRESHOLD_MM: return True, f"SR {sr:.0f}mm"
    if sl >= 0 and sl < EMERGENCY_THRESHOLD_MM: return True, f"SL {sl:.0f}mm"
    return False, ""

def make_next_move():
    """
    Decide and return the next serial command string, or None if not ready.
    Incorporates:
      - ESTOP pause check
      - Emergency sensor check (with cooldown)
      - Front distance step sizing for forward moves
      - Heading correction for turns
    """
    global emergency_stop_active, emergency_stop_reason, emergency_recovery_until
    global estop_active, estop_paused, estop_until

    if system_state != STATE_NAVIGATION:
        return None
    if serial_state != SERIAL_IDLE:
        return None

    # ── ESTOP pause ───────────────────────────────────────────────
    if estop_paused:
        return None
    if estop_active:
        if time.time() < estop_until:
            return None
        else:
            estop_active = False   # auto-resume
            print("  [ESTOP] Auto-resumed")

    # ── 1-second lockout after state transition ───────────────────
    if time.time() - nav_start_time < 1.0:
        return None

    # ── Emergency sensor check ────────────────────────────────────
    if time.time() > emergency_recovery_until:
        emg, reason = check_emergency()
        if emg:
            print(f"[EMG] {reason}")
            emergency_stop_active    = True
            emergency_stop_reason    = reason
            emergency_recovery_until = time.time() + 3.0
            return "s"   # stop command

    # ── Navigation decision ───────────────────────────────────────
    decision = robot.choose_next_move(tile_map)

    if decision == "U-TURN":
        robot.turn_right()
        robot.turn_right()
        angle = get_turn_angle(90.0)
        return f"r {angle:.0f}"

    if decision == "MR LFT":
        robot.turn_left()
        robot.move_forward()
        angle = get_turn_angle(-90.0)
        return f"l {abs(angle):.0f}"

    if decision == "MR FWD":
        robot.move_forward()
        mm = compute_forward_mm()
        return f"f {mm}"

    if decision == "MR RGT":
        robot.turn_right()
        robot.move_forward()
        angle = get_turn_angle(90.0)
        return f"r {angle:.0f}"

    return None

# =========================================================
# GUI
# =========================================================

def draw_wall_map(img, offset_x, offset_y, memory_mode):
    cs   = robot.cell_size()
    mnx, mny, mxx, mxy = robot.map_bounds()
    wall_thick = max(1, cs // 14)

    for x in range(mnx, mxx + 1):
        for y in range(mny, mxy + 1):
            sx = offset_x + (x - mnx) * cs
            sy = offset_y + (y - mny) * cs
            tile = tile_map.get_tile(x, y)
            if tile and tile in TILE_FILL_BGR:
                bg = TILE_FILL_BGR[tile]
            elif (x, y) in robot.visited:
                bg = COLOR_VISITED
            elif (x, y) in robot.discovered:
                bg = COLOR_DISCOVERED
            else:
                bg = COLOR_UNKNOWN
            cv2.rectangle(img, (sx, sy), (sx+cs, sy+cs), bg, -1)

    for x in range(mnx, mxx + 1):
        for y in range(mny, mxy + 1):
            for direction in [NORTH, EAST, SOUTH, WEST]:
                if robot.knows_wall(x, y, direction) is not True:
                    continue
                sx = offset_x + (x - mnx) * cs
                sy = offset_y + (y - mny) * cs
                x2, y2 = sx + cs, sy + cs
                if direction == NORTH: cv2.line(img,(sx,sy),(x2,sy),COLOR_WALL,wall_thick)
                elif direction == SOUTH: cv2.line(img,(sx,y2),(x2,y2),COLOR_WALL,wall_thick)
                elif direction == EAST:  cv2.line(img,(x2,sy),(x2,y2),COLOR_WALL,wall_thick)
                elif direction == WEST:  cv2.line(img,(sx,sy),(sx,y2),COLOR_WALL,wall_thick)

    cols = mxx - mnx + 1
    rows = mxy - mny + 1
    cv2.rectangle(img,(offset_x,offset_y),
                  (offset_x+cols*cs, offset_y+rows*cs), COLOR_WALL, wall_thick)

    rx = offset_x + int((robot.x - mnx + 0.5) * cs)
    ry = offset_y + int((robot.y - mny + 0.5) * cs)
    robot_r   = max(3, cs // 4)
    arrow_len = max(4, cs // 2 - 2)
    cv2.circle(img, (rx, ry), robot_r, COLOR_ROBOT, -1)
    hdx = {NORTH:(0,-1),EAST:(1,0),SOUTH:(0,1),WEST:(-1,0)}
    dx, dy = hdx.get(robot.heading, (1,0))
    cv2.arrowedLine(img,(rx,ry),(rx+int(dx*arrow_len),ry+int(dy*arrow_len)),
                    (0,255,0), max(1,cs//20), tipLength=0.4)


def get_state_name():
    if system_state == STATE_CALIBRATION:
        return f"CALIBRATION ({calibration_count}/5)"
    if system_state == STATE_START_DETECTION:
        return "START_DETECTION"
    if system_state == STATE_NAVIGATION:
        return "NAVIGATION"
    return "UNKNOWN"


def draw_gui():
    global running
    global emergency_stop_active, emergency_stop_reason, emergency_recovery_until
    global estop_active, estop_paused, estop_until
    WIN = "RoboCup Rescue V6"
    cv2.namedWindow(WIN, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(WIN, 1400, 620)

    auto_mode    = True
    uturn_queued = False

    WIN_W, WIN_H = 1400, 620
    PAD      = 12
    LABEL_H  = 28
    BOTTOM_H = 50
    RIGHT_W  = 340
    MAPS_W   = WIN_W - RIGHT_W - PAD * 3
    EACH_MAP_W = MAPS_W // 2 - PAD

    while running:
        img = np.ones((WIN_H, WIN_W, 3), dtype=np.uint8) * 40

        cs             = robot.cell_size()
        cols, rows     = robot.grid_span()
        grid_lbl       = f"{cols}x{rows} | cell={cs}px"
        is_ready       = (serial_state == SERIAL_IDLE)

        map1_x = PAD
        map2_x = PAD + EACH_MAP_W + PAD * 2
        map_y  = LABEL_H + PAD

        cv2.putText(img, "SENSOR WALLS",
                    (map1_x, LABEL_H-4), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200,200,200), 1)
        cv2.putText(img, "ROBOT MEMORY",
                    (map2_x, LABEL_H-4), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200,200,200), 1)
        cv2.putText(img, grid_lbl,
                    (map2_x+170, LABEL_H-4), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (110,110,110), 1)

        draw_wall_map(img, map1_x, map_y, memory_mode=False)
        draw_wall_map(img, map2_x, map_y, memory_mode=True)

        div_x = WIN_W - RIGHT_W - PAD
        cv2.line(img, (div_x,0), (div_x, WIN_H-BOTTOM_H), (80,80,80), 1)

        legend_y = WIN_H - BOTTOM_H - 16
        lx = PAD
        for lc, lt in [(COLOR_VISITED,"Visited"),(COLOR_DISCOVERED,"Seen"),
                       (COLOR_UNKNOWN,"Unseen"),(TILE_FILL_BGR['BLACK'],"Black")]:
            cv2.rectangle(img,(lx,legend_y-10),(lx+14,legend_y+4),lc,-1)
            cv2.putText(img,lt,(lx+18,legend_y+2),cv2.FONT_HERSHEY_SIMPLEX,0.38,(160,160,160),1)
            lx += 100

        # ── RIGHT PANEL ───────────────────────────────────────────
        rx = div_x + PAD
        ry = PAD + 10

        fc = readings_tof.get('FC', -1)
        sr = readings_tof.get('SR', -1)
        sl = readings_tof.get('SL', -1)

        def sc(d):
            if d < 0: return (70,70,70)
            if d < EMERGENCY_THRESHOLD_MM: return (30,30,200)
            if d < WALL_THRESHOLD_MM:      return (30,130,200)
            return (30,160,60)

        cv2.putText(img,"TOF",(rx,ry+14),cv2.FONT_HERSHEY_SIMPLEX,0.55,(200,200,200),1)
        gs, gap = 60, 5
        tof_grid = [["","FC",""],["SL","·","SR"],["","",""]]
        tof_dist = [[-1,fc,-1],[sl,-1,sr],[-1,-1,-1]]
        for row in range(3):
            for col in range(3):
                bx = rx+50+col*(gs+gap)
                by = ry+row*(gs+gap)
                lbl = tof_grid[row][col]
                d   = tof_dist[row][col]
                if lbl == "·":
                    cv2.rectangle(img,(bx,by),(bx+gs,by+gs),(60,80,110),-1)
                    cv2.circle(img,(bx+gs//2,by+gs//2),7,COLOR_ROBOT,-1)
                elif lbl:
                    cv2.rectangle(img,(bx,by),(bx+gs,by+gs),sc(d),-1)
                    cv2.putText(img,lbl,(bx+6,by+20),cv2.FONT_HERSHEY_SIMPLEX,0.48,(230,230,230),1)
                    cv2.putText(img,f"{int(d)}mm" if d>=0 else "---",
                                (bx+4,by+46),cv2.FONT_HERSHEY_SIMPLEX,0.36,(230,230,230),1)
                else:
                    cv2.rectangle(img,(bx,by),(bx+gs,by+gs),(40,40,40),-1)

        ry += 3*(gs+gap)+12
        cv2.putText(img,"red=danger  orange=wall  green=open",
                    (rx,ry),cv2.FONT_HERSHEY_SIMPLEX,0.33,(100,100,100),1)
        ry += 22
        cv2.line(img,(rx,ry),(rx+RIGHT_W-PAD,ry),(70,70,70),1)
        ry += 16

        # Tile swatch
        tile_code_map = {'W':'WHITE','S':'SILVER','B':'BLACK','U':'BLUE','R':'RED'}
        tile_sz = 50
        cv2.putText(img,"TILE",(rx,ry+12),cv2.FONT_HERSHEY_SIMPLEX,0.42,(130,130,130),1)
        if current_color and current_color != "UNKNOWN":
            cc   = current_color[0]
            name = tile_code_map.get(cc,'')
            fill = TILE_FILL_BGR.get(name,(70,70,70))
            cv2.rectangle(img,(rx+55,ry),(rx+55+tile_sz,ry+tile_sz),fill,-1)
            border = (120,120,120) if name=='WHITE' else (60,60,60)
            cv2.rectangle(img,(rx+55,ry),(rx+55+tile_sz,ry+tile_sz),border,1)
            cv2.putText(img,name,(rx+55+tile_sz+8,ry+20),
                        cv2.FONT_HERSHEY_SIMPLEX,0.48,(180,180,180),1)
        else:
            cv2.rectangle(img,(rx+55,ry),(rx+55+tile_sz,ry+tile_sz),(55,55,55),-1)
            cv2.putText(img,"---",(rx+55+tile_sz+8,ry+20),
                        cv2.FONT_HERSHEY_SIMPLEX,0.48,(100,100,100),1)
        cv2.putText(img,f"recorded: {len(tile_map.tiles)}",(rx+55,ry+tile_sz+14),
                    cv2.FONT_HERSHEY_SIMPLEX,0.38,(100,100,100),1)
        ry += tile_sz + 28
        cv2.line(img,(rx,ry),(rx+RIGHT_W-PAD,ry),(70,70,70),1)
        ry += 16

        # Serial state
        serial_labels = {SERIAL_IDLE:"IDLE", SERIAL_WAIT_ECHO:"WAIT ECHO",
                         SERIAL_WAIT_DONE:"WAIT DONE"}
        sl_label = serial_labels.get(serial_state,"?")
        sl_color = (40,180,40) if serial_state==SERIAL_IDLE else (60,60,200)
        cv2.putText(img,"SERIAL",(rx,ry+12),cv2.FONT_HERSHEY_SIMPLEX,0.42,(150,150,150),1)
        cv2.putText(img,sl_label,(rx+68,ry+12),cv2.FONT_HERSHEY_SIMPLEX,0.42,sl_color,1)
        ry += 24
        cv2.putText(img,f"  > {last_command_sent[-22:]}",(rx,ry),
                    cv2.FONT_HERSHEY_SIMPLEX,0.38,(120,170,220),1)
        ry += 20
        cv2.putText(img,f"  < {last_response_received[-22:]}",(rx,ry),
                    cv2.FONT_HERSHEY_SIMPLEX,0.38,(120,210,120),1)
        ry += 24
        cv2.line(img,(rx,ry),(rx+RIGHT_W-PAD,ry),(70,70,70),1)
        ry += 16

        # State + nav info
        state_colors = {STATE_CALIBRATION:(120,120,255),
                        STATE_START_DETECTION:(120,200,255),
                        STATE_NAVIGATION:(80,210,80)}
        cv2.putText(img,get_state_name(),(rx,ry+14),
                    cv2.FONT_HERSHEY_SIMPLEX,0.46,state_colors.get(system_state,(180,180,180)),1)
        ry += 28

        if system_state == STATE_NAVIGATION:
            hdgs = {NORTH:'N',EAST:'E',SOUTH:'S',WEST:'W'}
            mode_str = "AUTO" if auto_mode else "MANUAL"
            cv2.putText(img,f"  {mode_str} ({robot.x},{robot.y}) {hdgs.get(robot.heading,'?')}",
                        (rx,ry),cv2.FONT_HERSHEY_SIMPLEX,0.42,(180,180,100),1)
            ry += 22
            cv2.putText(img,f"  visited:{len(robot.visited)} found:{len(robot.discovered)}",
                        (rx,ry),cv2.FONT_HERSHEY_SIMPLEX,0.42,(130,130,130),1)
            ry += 22
            cv2.putText(img,f"  last: {robot.last_action}",
                        (rx,ry),cv2.FONT_HERSHEY_SIMPLEX,0.42,(130,130,130),1)
            ry += 22
            if estop_paused:
                cv2.putText(img,"  !! PAUSED (press button) !!",(rx,ry),
                            cv2.FONT_HERSHEY_SIMPLEX,0.45,(40,40,220),1)
            elif estop_active:
                remain = max(0, estop_until - time.time())
                cv2.putText(img,f"  !! ESTOP ({remain:.1f}s) !!",(rx,ry),
                            cv2.FONT_HERSHEY_SIMPLEX,0.45,(40,180,220),1)
            elif emergency_stop_active:
                cv2.putText(img,"  !! SENSOR ESTOP !!",(rx,ry),
                            cv2.FONT_HERSHEY_SIMPLEX,0.45,(40,40,220),1)
            # Self-correction info
            ry += 22
            if lateral_offset_log:
                avg_offset = sum(lateral_offset_log)/len(lateral_offset_log)
                cv2.putText(img,f"  snap: {avg_offset:+.0f}mm corr:{heading_correction_deg:+.1f}°",
                            (rx,ry),cv2.FONT_HERSHEY_SIMPLEX,0.38,(130,170,130),1)

        bar_y = WIN_H - BOTTOM_H + 16
        cv2.line(img,(0,WIN_H-BOTTOM_H),(WIN_W,WIN_H-BOTTOM_H),(70,70,70),1)
        cv2.putText(img,"F=Fwd  L=Left  R=Right  A=Auto/Manual  Q=Quit",
                    (PAD,bar_y),cv2.FONT_HERSHEY_SIMPLEX,0.48,(140,140,200),1)
        cv2.putText(img,grid_lbl,(WIN_W-220,bar_y),
                    cv2.FONT_HERSHEY_SIMPLEX,0.42,(100,100,100),1)

        cv2.imshow(WIN, img)
        key = cv2.waitKey(100) & 0xFF

        if key in (ord('q'),ord('Q'),27):
            running = False
            break
        elif key in (ord('a'),ord('A')):
            if system_state == STATE_NAVIGATION:
                auto_mode = not auto_mode
        elif key in (ord('f'),ord('F')):
            if system_state == STATE_NAVIGATION and is_ready:
                robot.move_forward()
                send_command(f"f {CELL_MM}")
        elif key in (ord('l'),ord('L')):
            if system_state == STATE_NAVIGATION and is_ready:
                robot.turn_left()
                send_command("l 90")
        elif key in (ord('r'),ord('R')):
            if system_state == STATE_NAVIGATION and is_ready:
                robot.turn_right()
                send_command("r 90")

        # ── Auto navigation ────────────────────────────────────────
        if system_state == STATE_NAVIGATION and auto_mode and is_ready:
            # Handle second leg of U-turn
            if uturn_queued:
                uturn_queued = False
                robot.turn_right()
                robot.move_forward()
                angle = get_turn_angle(90.0)
                send_command(f"r {angle:.0f}")
            else:
                cmd = make_next_move()
                if cmd:
                    if robot.last_action == "U-TURN":
                        uturn_queued = True
                    send_command(cmd)

        # Drain motion_result_queue (results already applied in process_line)
        while not motion_result_queue.empty():
            try:
                motion_result_queue.get_nowait()
            except:
                pass

        # Handle emergency stop recovery in GUI loop
        if emergency_stop_active and is_ready:
            print(f"[SAFETY] {emergency_stop_reason} — turning right")
            robot.turn_right()
            emergency_stop_active = False
            send_command(f"r {get_turn_angle(90.0):.0f}")

        time.sleep(0.05)

    cv2.destroyAllWindows()

# =========================================================
# MAIN
# =========================================================

def main():
    global running
    try:
        print("\n" + "="*60)
        print("ROBOCUP RESCUE V6 — RAB PROTOCOL + SELF-CORRECTION")
        print("="*60)

        setup_gpio()
        load_offsets()
        init_tof_sensors()
        time.sleep(1)
        open_serial()
        time.sleep(1)

        threading.Thread(target=tof_thread,    daemon=True).start()
        threading.Thread(target=serial_thread, daemon=True).start()

        print("="*60)
        print("WAITING FOR CALIBRATION (5 colour button presses)...")
        print("="*60 + "\n")

        draw_gui()

    except KeyboardInterrupt:
        print("\nInterrupted")
    finally:
        running = False
        time.sleep(0.5)
        led_off()
        if bus:  bus.close()
        if ser:  ser.close()
        GPIO.cleanup()
        cv2.destroyAllWindows()
        print("\n✓ Cleanup complete\n")

if __name__ == "__main__":
    main()