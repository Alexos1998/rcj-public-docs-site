RoboCup Rescue Maze — Source Code
==================================

Two folders:

  high_processor/
    Contains Jetson Orin Nano Python code.
    - Main navigation sequence
    - Greek letter detection
    - Cognitive target ring detection
    - Model training and dataset capture

  low_processor/
    Contains ESP32-S3 Arduino firmware.
    - Motor control and serial communication


How to access
-------------

Clone or download the repository, then navigate into the folder you need:

  cd high_processor/     for Jetson code
  cd low_processor/      for ESP32 code


Running
-------

  Jetson (high_processor):
    python3 <filename>.py

  ESP32 (low_processor):
    Open .ino file in Arduino IDE and flash to ESP32-S3
