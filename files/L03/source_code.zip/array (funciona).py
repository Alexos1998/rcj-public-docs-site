#!/usr/bin/env pybricks-micropython

from pybricks.hubs import EV3Brick
from pybricks.ev3devices import Motor, ColorSensor
from pybricks.parameters import Port, Color
from pybricks.robotics import DriveBase
import time

bloque = EV3Brick()

motor_inferiorI = Motor(Port.B)
motor_inferiorD = Motor(Port.C)
motor_izquierdo = Motor(Port.A)
motor_derecho = Motor(Port.D)
sensor_izquierdo = ColorSensor(Port.S2)
sensor_derecho = ColorSensor(Port.S1)
robot = DriveBase(motor_izquierdo, motor_derecho, wheel_diameter=55, axle_track=120)

def sync_slaves():
    motor_inferiorI.run(motor_derecho.speed())
    motor_inferiorD.run(motor_izquierdo.speed())

def Mover(Izq, Der, Base):
    motor_izquierdo.run(Base + Izq)
    motor_derecho.run(Base + Der)
    motor_inferiorD.run(Base + Der)
    motor_inferiorI.run(Base + Izq)

def Parar():
    motor_izquierdo.run(0)
    motor_derecho.run(0)
    motor_inferiorD.run(0)
    motor_inferiorI.run(0)

# Configuración
VELOCIDAD = 120
GANANCIA_PROPORCIONAL = 15
CHECK = 0.3

# Necesarios para que el código funcione
ultimo_check = time.time()

color_der = sensor_derecho.color()
color_izq = sensor_izquierdo.color()

#  Guardar el color anterior (antes del verde)
color_anterior_der = sensor_derecho.color()
color_anterior_izq = sensor_izquierdo.color()

# Sensor izquierdo
if time.time() - ultimo_check >= CHECK:
    color_izq = sensor_izquierdo.color()
    color_der = sensor_derecho.color()
    if color_izq == Color.GREEN or color_der == Color.GREEN:
        Parar()
        time.sleep(1)
        Mover(-20, -20, 0)
        time.sleep(1)
        Parar()
        time.sleep(3)
        color_izq = sensor_izquierdo.color()
        color_der = sensor_derecho.color()
        time.sleep(1)

        # Si detecta verde, mostramos qué había antes
        if color_izq == Color.GREEN and color_der == Color.GREEN:
            bloque.screen.clear()
            bloque.screen.print("Verde AMBOS")
            bloque.screen.print("IZQ antes:", color_anterior_izq)
            bloque.screen.print("DER antes:", color_anterior_der)
            ultimo_check = time.time()
            bloque.speaker.beep()
            Mover(100, -100, 0)  # Girar hacia la derecha
            time.sleep(2)
            while color_izq != Color.BLACK:
                Mover(100, -100, 0)
                color_izq = sensor_izquierdo.color()
            Parar()


        if color_izq == Color.GREEN and color_der != Color.GREEN:
            robot.stop()
            bloque.screen.clear()
            bloque.screen.print("Verde IZQ")
            bloque.screen.print("Antes:", color_anterior_izq)
            bloque.speaker.beep()
            robot.stop()
            #ultimo_check = time.time()
            wait(500)

        if color_der == Color.GREEN and color_izq != Color.GREEN:
            robot.stop()
            bloque.screen.clear()
            bloque.screen.print("Verde DER")
            bloque.screen.print("Antes:", color_anterior_der)
            bloque.speaker.beep()
            robot.stop()
            #ultimo_check = time.time()
            wait(500)

    if color_der != Color.GREEN: # Guardamos el color anterior mientras NO sea verde
        color_anterior_der = color_der

    if color_izq != Color.GREEN: # Guardamos el color anterior mientras NO sea verde
        color_anterior_izq = color_izq

    ultimo_check = time.time()
