#!/usr/bin/env python3
"""
EV3 — seguidor de línea PID + control de grúa por serial

Arquitectura:
  Arduino Nano → envía error PID cada 50ms por /dev/ttyUSB0
  EV3          → lee el error, ajusta velocidad de motores
  EV3          → envía comandos para la grua al Arduino
  Arduino      → mueve el servo de la grúa y responde.


Hilo servo (ciclo_servo):
  - Alterna 
/BAJAR cada 5 segundos (modo de prueba)
  - En producción: reemplazar por lógica de detección de víctimas

Nota: ev3dev usa Python 3.5 — no usar f-strings, usar .format()
"""

from ev3dev2.motor import LargeMotor, OUTPUT_A, OUTPUT_B, OUTPUT_C, OUTPUT_D, SpeedPercent
import serial
import time
import threading


PUERTO_MOTOR_IZQ_TRASERO   = OUTPUT_A
PUERTO_MOTOR_IZQ_DELANTERO = OUTPUT_B
PUERTO_MOTOR_DER_DELANTERO = OUTPUT_C
PUERTO_MOTOR_DER_TRASERO   = OUTPUT_D


POLARIDAD_IZQUIERDO = 1
POLARIDAD_DERECHO   = 1

# Kp: ganancia propo
# Kd: ganancia derivativa. Amortigua la oscilación.
Kp = 0.03
Kd = 0.005
VELOCIDAD_BASE = 25  

# True si el robot tiene 4 motores de tracción (2 por lado)
CUATRO_MOTORES = True
# ================================================================

# Inicializar motores
motor_izquierdo_trasero   = LargeMotor(PUERTO_MOTOR_IZQ_TRASERO)
motor_derecho_trasero     = LargeMotor(PUERTO_MOTOR_DER_TRASERO)
if CUATRO_MOTORES:
    motor_izquierdo_delantero = LargeMotor(PUERTO_MOTOR_IZQ_DELANTERO)
    motor_derecho_delantero   = LargeMotor(PUERTO_MOTOR_DER_DELANTERO)

# Abrir serial hacia el Arduino Nano (CH340 → siempre ttyUSB0 en ev3dev)
# timeout=0.1 para no bloquear el loop si no llegan datos
puerto_serial = serial.Serial('/dev/ttyUSB0', 9600, timeout=0.1)
time.sleep(2)  # esperar reset del Arduino al abrir el puerto (obligatorio)

print("Seguidor de linea iniciado. Ctrl+C para parar.")


def mover_motores(velocidad_izquierda, velocidad_derecha):
    """Aplica velocidades a los motores de tracción, respetando polaridad y límites."""
    velocidad_izquierda = max(-100, min(100, velocidad_izquierda)) * POLARIDAD_IZQUIERDO
    velocidad_derecha   = max(-100, min(100, velocidad_derecha))   * POLARIDAD_DERECHO
    motor_izquierdo_trasero.on(SpeedPercent(velocidad_izquierda))
    motor_derecho_trasero.on(SpeedPercent(velocidad_derecha))
    if CUATRO_MOTORES:
        motor_izquierdo_delantero.on(SpeedPercent(velocidad_izquierda))
        motor_derecho_delantero.on(SpeedPercent(velocidad_derecha))


def ciclo_servo():
    """
    Hilo de prueba: alterna LIFT/DOWN cada 5 segundos.
    En producción reemplazar por detección de víctimas con sensor de color.
    """
    secuencia = ['LEVANTAR', 'BAJAR']
    indice = 0
    while True:
        time.sleep(5)
        comando = secuencia[indice % 2]
        puerto_serial.write((comando + '\n').encode('utf-8'))
        print("Servo: " + comando)
        indice += 1


# Lanzar hilo del servo como daemon (ES UN HILO APARTE ES DECIR COMO DOS PROGRAMAS QUE FUNCIONAN A LA VEZ)
threading.Thread(target=ciclo_servo, daemon=True).start()

error_anterior = 0

try:
    while True:
        linea = puerto_serial.readline().decode('utf-8').strip()

        # Ignorar líneas vacías y respuestas del Arduino (ACK/ERR)
        if not linea or linea.startswith('Resp:') or linea.startswith('ERR:'):
            continue

        try:
            error = int(linea)
        except ValueError:
            continue  # ignorar cualquier texto inesperado

        # Control PD
        # error > 0 → línea a la derecha → girar derecha (frenar izq, acelerar der)
        # error < 0 → línea a la izquierda → girar izquierda
        correccion = Kp * error + Kd * (error - error_anterior)
        error_anterior = error

        mover_motores(VELOCIDAD_BASE - correccion, VELOCIDAD_BASE + correccion)

except KeyboardInterrupt:
    print("Detenido por el usuario.")
finally:
    mover_motores(0, 0)
    puerto_serial.close()
