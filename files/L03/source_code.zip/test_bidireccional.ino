/*
 * Arduino → EV3:
 * Manda continuamente el error del QTR-8.
 *
 * EV3 → Arduino:
 * LEVANTAR → servo a 90°
 * BAJAR    → servo a 0°
 * AGARRAR  → reservado
 * SOLTAR   → reservado
 */

#include <Servo.h>


// Pines del QTR-8
const int pinesSensor[8] = {A7, A6, A5, A4, A3, A2, A1, A0};


// Encendido LEDs infrarrojos del QTR
const int PIN_LEDON = 10;


// Pesos del error
const int pesos[8] = {
  -3500,
  -2500,
  -1500,
  -500,
   500,
   1500,
   2700,
   4000
};


// Servo grúa
Servo servoGrua;

const int PIN_SERVO = 9;

const int POS_ABAJO = 0;
const int POS_ARRIBA = 90;


// Comunicación serial
String bufferEntrada = "";



void setup() {

  Serial.begin(9600);


  // Prender LEDs IR del QTR-8
  pinMode(PIN_LEDON, OUTPUT);
  digitalWrite(PIN_LEDON, HIGH);


  // Servo
  servoGrua.attach(PIN_SERVO);
  servoGrua.write(POS_ABAJO);

}




void verificarComando() {


  while (Serial.available()) {


    char caracter = Serial.read();


    if (caracter == '\n') {


      bufferEntrada.trim();


      if (bufferEntrada.length() > 0) {

        ejecutarComando(bufferEntrada);

      }


      bufferEntrada = "";

    }


    else if (caracter != '\r') {

      bufferEntrada += caracter;

    }

  }

}




void ejecutarComando(String comando) {


  if (comando == "LEVANTAR") {


    servoGrua.write(POS_ARRIBA);

    Serial.println("Resp:LEVANTAR");


  }


  else if (comando == "BAJAR") {


    servoGrua.write(POS_ABAJO);

    Serial.println("Resp:BAJAR");


  }


  else if (comando == "AGARRAR") {


    Serial.println("Resp:AGARRAR");


  }


  else if (comando == "SOLTAR") {


    Serial.println("Resp:SOLTAR");


  }


  else {


    Serial.print("ERR:DESCONOCIDO:");

    Serial.println(comando);


  }

}




void loop() {


  // Revisar comandos del EV3
  verificarComando();



  // Leer QTR
  long numerador = 0;

  long denominador = 0;



  for (int i = 0; i < 8; i++) {


    int valor = 1023 - analogRead(pinesSensor[i]);


    numerador += (long)valor * pesos[i];

    denominador += valor;


  }



  int error = 0;



  if (denominador != 0) {

    error = numerador / denominador;

  }



  // Enviar error al EV3

  Serial.println(error);



  delay(50);

}