import unittest
import math

# HACK(Richo): Since python is such a complicated mess I had to add the
# following lines to be able to import the classes in the src folder.
# There is probably a better way but, in any case, it shouldn't be so
# difficult. Python sucks.
import sys
sys.path.append("src") 

from vector import Vector

class VectorTest(unittest.TestCase):
    def assertAlmostEqual(self, first, second, places=None, msg=None, delta=None):
        if isinstance(first, Vector) and isinstance(second, Vector):
            self.assertAlmostEqual(first.x, second.x, places, msg, delta)
            self.assertAlmostEqual(first.y, second.y, places, msg, delta)
        else:
            super().assertAlmostEqual(first, second, places, msg, delta)

    def test_distance_1(self):
        a = Vector(1, 0)
        b = Vector(1, 1)
        actual = a.distance_to(b)
        expected = 1
        self.assertEqual(actual, expected)

    def test_distance_2(self):
        a = Vector(1, 1)
        b = Vector(2, 2)
        actual = a.distance_to(b)
        expected = 1.41421356
        self.assertAlmostEqual(actual, expected)

    def test_normalized_1(self):
        a = Vector(0.5, 0)
        actual = a.normalized()
        expected = Vector(1, 0)
        self.assertAlmostEqual(actual, expected)

    def test_normalized_2(self):
        a = Vector(1.5, 0.5)
        actual = a.normalized()
        expected = Vector(0.948683, 0.316228)
        self.assertAlmostEqual(actual, expected, 6)

    def test_length(self):
        actual = Vector(1, 1).length()
        expected = 1.41421356
        self.assertAlmostEqual(actual, expected)

    def test_angle_1(self):
        actual = Vector(1, -1).angle()
        expected = -math.pi/4
        self.assertAlmostEqual(actual, expected)
        
    def test_angle_2(self):
        actual = Vector(-1, 0).angle()
        expected = math.pi/2
        self.assertAlmostEqual(actual, expected)

    def test_angle_up(self):
        actual = Vector.UP.angle()
        expected = 0
        self.assertAlmostEqual(actual, expected)
        
    def test_angle_down(self):
        actual = Vector.DOWN.angle()
        expected = math.pi
        self.assertAlmostEqual(actual, expected)
        
    def test_angle_left(self):
        actual = Vector.LEFT.angle()
        expected = math.pi/2
        self.assertAlmostEqual(actual, expected)
        
    def test_angle_right(self):
        actual = Vector.RIGHT.angle()
        expected = -math.pi/2
        self.assertAlmostEqual(actual, expected)

    def test_angle_to(self):
        a = Vector.UP
        b = Vector(-1, -1)
        c = Vector(1, -1)
        self.assertAlmostEqual(a.angle_to(b), math.pi/4)
        self.assertAlmostEqual(a.angle_to(c), -math.pi/4)
        self.assertAlmostEqual(c.angle_to(b), math.pi/2)

    def test_rotated(self):
        cases = [
            [Vector.UP.rotated(math.pi/2), Vector.LEFT],
            [Vector.UP.rotated(-math.pi/2), Vector.RIGHT],
            [Vector.RIGHT.rotated(-math.pi/4), Vector(1, 1).normalized()],
            [Vector.RIGHT.rotated(math.pi/2), Vector.UP],
            [Vector(1, 1).rotated(-math.pi/2), Vector(-1, 1)]
        ]
        for i in range(len(cases)):
            actual, expected = cases[i]
            self.assertAlmostEqual(actual, expected, 5, f"(case {i})")

    def test_add(self):
        self.assertAlmostEqual(Vector.ONE + Vector.UP, Vector(1, 0))
        self.assertAlmostEqual(Vector.ZERO + Vector.DOWN, Vector(0, 1))
        self.assertAlmostEqual(Vector.ONE + Vector.RIGHT, Vector(2, 1))
        self.assertAlmostEqual(Vector.ONE + Vector(5, 3), Vector(6, 4))
        self.assertAlmostEqual(Vector.ONE + Vector(-5, -3), Vector(-4, -2))

    def test_sub(self):
        self.assertAlmostEqual(Vector.ONE - Vector.UP, Vector(1, 2))
        self.assertAlmostEqual(Vector.ZERO - Vector.DOWN, Vector(0, -1))
        self.assertAlmostEqual(Vector.ONE - Vector.RIGHT, Vector(0, 1))
        self.assertAlmostEqual(Vector.ONE - Vector(5, 3), Vector(-4, -2))
        self.assertAlmostEqual(Vector.ONE - Vector(-5, -3), Vector(6, 4))

    def test_mul(self):
        self.assertAlmostEqual(Vector.UP * 2, Vector(0, -2))
        self.assertAlmostEqual(Vector(1, 1) * 42, Vector(42, 42))
        self.assertAlmostEqual(Vector(1, -1) * 42, Vector(42, -42))
        self.assertAlmostEqual(Vector(-3, 1) * -4, Vector(12, -4))

        self.assertAlmostEqual(2*Vector.UP, Vector(0, -2))
        self.assertAlmostEqual(42*Vector(1, 1), Vector(42, 42))
        self.assertAlmostEqual(42*Vector(1, -1), Vector(42, -42))
        self.assertAlmostEqual(-4*Vector(-3, 1), Vector(12, -4))

    def test_div(self):
        self.assertAlmostEqual(Vector.ONE/2, Vector(0.5, 0.5))
        self.assertAlmostEqual(Vector(4, 4)/2, Vector(2, 2))
        self.assertAlmostEqual(Vector.RIGHT/0.5, Vector(2, 0))

if __name__ == '__main__':
    unittest.main()