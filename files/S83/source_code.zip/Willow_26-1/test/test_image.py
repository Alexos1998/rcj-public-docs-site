import unittest
import math

# HACK(Richo): Since python is such a complicated mess I had to add the
# following lines to be able to import the classes in the src folder.
# There is probably a better way but, in any case, it shouldn't be so
# difficult. Python sucks.
import sys
sys.path.append("src") 

from image import ImageProcessor

class ImageProcessorTest(unittest.TestCase):
    def assertEqual(self, first, second, msg = None):
        return super().assertEqual(first, second, msg)