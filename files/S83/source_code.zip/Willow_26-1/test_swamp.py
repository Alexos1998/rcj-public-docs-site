MINITILE_SIZE_PX = 12  # int(200 * 0.06)

base_penalty    = 8.0
additional_cost = 8
detour_cost     = 24   # extra pixels to go around 1 swamp tile (~2 cardinal moves)
max_passes      = 8
pixel_dist      = MINITILE_SIZE_PX
increments_to_test = [0.5, 1, 1.5, 2, 3]

avoidance_threshold = (detour_cost - base_penalty) / additional_cost
path_base = pixel_dist + detour_cost

print("=" * 70)
print("SWAMP COST ANALYSIS")
print(f"  base_penalty={base_penalty}, additional_cost={additional_cost}")
print(f"  pixel_dist={pixel_dist}, detour_cost={detour_cost}  (detour path total={path_base})")
print(f"  Avoidance threshold: visits > {avoidance_threshold:.2f}")
print("=" * 70)

for increment in increments_to_test:
    print(f"\n--- increment = {increment} ---")
    print(f"{'Pass':>4} | {'visits':>6} | {'Swamp cost':>10} | {'Detour cost':>11} | {'Avoids?':>8}")
    print("-" * 50)
    visits = 0
    first_avoidance = None
    for pass_num in range(1, max_passes + 1):
        visits += increment
        swamp_cost = pixel_dist + base_penalty + visits * additional_cost
        avoids = swamp_cost > path_base
        if avoids and first_avoidance is None:
            first_avoidance = pass_num
        flag = "<-- first avoidance" if pass_num == first_avoidance else ""
        print(f"{pass_num:>4} | {visits:>6.1f} | {swamp_cost:>10.1f} | {path_base:>11.1f} | {'YES' if avoids else 'no':>8}  {flag}")
    if first_avoidance is None:
        print(f"  >> Robot NEVER avoids this swamp with increment={increment}")
    else:
        print(f"  >> Robot starts avoiding from pass #{first_avoidance}")

print()
print("=" * 70)
print("RECOMMENDATION")
print(f"  To start avoiding from pass N, use:  increment > (detour - base) / (additional * N)")
for target_pass in [1, 2, 3, 4]:
    min_inc = (detour_cost - base_penalty) / (additional_cost * target_pass)
    print(f"    Avoid from pass #{target_pass}: increment > {min_inc:.2f}  (e.g. {min_inc + 0.01:.1f})")
print("=" * 70)
