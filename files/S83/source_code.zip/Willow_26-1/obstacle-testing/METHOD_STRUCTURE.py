



def possible_obstacle(self, lidar,diff_distance = 0.1, distance = 0.1):
    to_verification = 0
    SMALL_OBSTACLE = False
    CURRENT_OBSTACLE = False
    possible_rays = []
    obstacle_points = []

    distance_sensor = self.robot.distance_sensor.getValue()

    b, g, r = self.robot.get_central_pixel(self.robot.front_camera)

    if not self.image_processor.is_exclude_color(b, g, r):
        to_verification += 1
    
    image = lidar.getRangeImage()   

    layer1 = image[:512]
    layer4 = image[1537:2048]
    
    frontlayer1 = layer1[256] 
    frontlayer4 = layer4[256] 

    front_lidar = layer4[206:306]
    
    left_zone = front_lidar[:33]
    center_zone = front_lidar[33:67]
    right_zone = front_lidar[67:]   

    total_left = sum(1 for dis in left_zone if dis > diff_distance)
    total_mid = sum(1 for dis in center_zone if dis > diff_distance)
    total_right = sum(1 for dis in right_zone if dis > diff_distance)

    if distance_sensor < 0.1:
        if abs(distance_sensor - frontlayer4) > 0.034: 
            SMALL_OBSTACLE = True
        elif frontlayer4 > 0.045:
            if abs(distance_sensor - frontlayer1) < 1: 
                CURRENT_OBSTACLE = True

    if not CURRENT_OBSTACLE:
        if frontlayer4 < 0.08:
            if (total_mid < 6) and (total_left > 5) and (total_right > 5):
                for i in range(len(front_lidar)):
                    actual_distance = front_lidar[i]
                    if actual_distance < distance:
                        index = (i + 206)
                        actual_angle = index * (360.0 / 512.0)  
                        possible_rays.append([actual_distance, actual_angle])
                # to_verification += 1
                CURRENT_OBSTACLE = True
        print(f"CURRENT OBSTACLE: {CURRENT_OBSTACLE}")
    
    if SMALL_OBSTACLE and not CURRENT_OBSTACLE:
        if r != 0: 
            distance_from_center = distance_sensor + ROBOT_RADIUS
            obstacle_pos = robot_pos + robot_direction * distance_from_center
            x_final = obstacle_pos.x
            z_final = obstacle_pos.y
            print(f"Distance sensor position: {x_final}, {z_final}")

    elif CURRENT_OBSTACLE or SMALL_OBSTACLE:
        number_of_rays = len(possible_rays)
        center = number_of_rays // 2
        
        raw_distance_to_obstacle = possible_rays[center][0] 
        ray_angle = possible_rays[center][1]
        
        x_robot = robot_pos.x
        z_robot = robot_pos.y

        angle_rad = math.radians(ray_angle - 180.0)

        x_obstacle = raw_distance_to_obstacle * math.sin(angle_rad)
        z_obstacle = raw_distance_to_obstacle * math.cos(angle_rad)

        x_final = x_robot + (x_obstacle * math.cos(yaw) - z_obstacle * math.sin(yaw))
        z_final = z_robot - (x_obstacle * math.sin(yaw) + z_obstacle * math.cos(yaw))
        
        print(f"Calculated final obstacle position: ({x_final}, {z_final}) after adjusting with distance sensor position.")
    else:
        return False



    if obstaculo petiso
    
        CALCULOS

    else:   
        obstaculo alto

        CALCULOS