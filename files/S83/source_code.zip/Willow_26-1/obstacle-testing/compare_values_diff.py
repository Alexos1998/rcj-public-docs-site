from controller import Robot
robot = Robot()

TIMESTEP = 32

lidar = robot.getDevice("lidar")
lidar.enable(TIMESTEP)

distance_s = robot.getDevice("distance sensor1")
distance_s.enable(TIMESTEP)

def diff():
    ds = distance_s.getValue()
    image = lidar.getRangeImage()
    layer4 = image[1536:]
    frontlayer4 = layer4[256]
    diff = abs(ds - frontlayer4)
    print(f"DS: {ds} -- FRONTLAYER4: {frontlayer4} -- DIFF: {diff}")
    
while robot.step(TIMESTEP)!=-1:
    diff()
    print("-"*60)