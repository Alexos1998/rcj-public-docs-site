import numpy as np
from controller import Robot

robot = Robot()
TIME_STEP = 32
lidar = robot.getDevice("lidar")
lidar.enable(TIME_STEP)

distance_sensor = robot.getDevice("distance sensor1")
distance_sensor.enable(TIME_STEP)

front_camera = robot.getDevice("camaraFrontal")
front_camera.enable(TIME_STEP)

# colour_sensor = robot.getDevice("colour_sensor")
# colour_sensor.enable(TIME_STEP)

lidar = robot.getDevice("lidar")
lidar.enable(TIME_STEP)


def possible_obstacle():
    image = lidar.getRangeImage()
    capa4 = image[1536:]
    frontlayer4 = capa4[256]
    distance = distance_sensor.getValue()
    real_distance = (distance + 0.035)
    image = front_camera.getImage()
    h = front_camera.getHeight()
    w = front_camera.getWidth()
    imagenp = np.frombuffer(image, np.uint8).reshape((h, w, 4))
    centro_h = (h//2)
    centro_w = (w//2)
    pixel = imagenp[centro_h, centro_w]
    b = pixel[0]
    g = pixel[1]
    r = pixel[2]
    if image is None:
        return None
    # bc, gc, rc, _ = colour_sensor.getImage()
    print(f"Camera - b: {b}, g: {g}, r: {r}")
    # print("Colour sensor:", bc, gc, rc)
    distance_robot_ds = (distance + 0.035)
    real_distance = (0.201 * distance_robot_ds) + 0.03
    print(f"Distance sensor: {distance_robot_ds} --- Rayo frontal capa 4: {frontlayer4} --- Distancia calculada: {real_distance}")
    if 0 <= r <= 25:
        print(f"Distance sensor: {distance_robot_ds} --- Rayo frontal capa 4: {frontlayer4} --- Distancia calculada: {real_distance}")
    elif 25 < r <= 50:
        real_distance += 0.0035
        print(f"Distance sensor: {distance_robot_ds} --- Rayo frontal capa 4: {frontlayer4} --- Distancia calculada: {real_distance}")  
    elif 50 < r <= 75:
        real_distance += 0.011
        print(f"Distance sensor: {distance_robot_ds} --- Rayo frontal capa 4: {frontlayer4} --- Distancia calculada: {real_distance}")  
    elif 75 < r <= 100:
        real_distance += 0.014
        print(f"Distance sensor: {distance_robot_ds} --- Rayo frontal capa 4: {frontlayer4} --- Distancia calculada: {real_distance}")  
    else:
        print("Color mayor a 50")

while robot.step(TIME_STEP)!=-1:
    possible_obstacle()
    print("--"*20)





    #






    def possible_obstacle(self, lidar, diff_distance = 0.1, distance = 0.1):
        to_verification = 0
        SMALL_OBSTACLE = False
        CURRENT_OBSTACLE = False
        possible_rays = []
        obstacle_points = []

        distance_sensor = self.robot.distance_sensor.getValue()

        b, g, r = self.robot.get_central_pixel(self.robot.front_camera)

        if not self.image_processor.is_exclude_color(b, g, r):
            to_verification += 1
        
        image = lidar.getRangeImage()   
    
        layer1 = image[:512]
        layer4 = image[1537:2048]
        
        frontlayer1 = layer1[256] 
        frontlayer4 = layer4[256] 

        front_lidar = layer4[206:306]
        
        left_zone = front_lidar[:33]
        center_zone = front_lidar[33:67]
        right_zone = front_lidar[67:]   

        total_left = sum(1 for dis in left_zone if dis > diff_distance)
        total_mid = sum(1 for dis in center_zone if dis > diff_distance)
        total_right = sum(1 for dis in right_zone if dis > diff_distance)
        
        if distance_sensor < 0.1:
            if abs(distance_sensor - frontlayer4) > 0.034: 
                # to_verification += 1
                SMALL_OBSTACLE = True
            elif frontlayer4 > 0.045:
                if abs(distance_sensor - frontlayer1) < 1: 
                    # to_verification += 1
                    CURRENT_OBSTACLE = True


        if frontlayer4 < 0.08:
            if (total_mid < 6) and (total_left > 5) and (total_right > 5):
                for i in range(len(front_lidar)):
                    actual_distance = front_lidar[i]
                    if actual_distance < distance:
                        index = (i + 206)
                        actual_angle = index * (360.0 / 512.0)  
                        possible_rays.append([actual_distance, actual_angle])
                # to_verification += 1
                CURRENT_OBSTACLE = True

        yaw = self.robot.get_rotation()
        robot_pos = self.robot.get_position() + self.robot.start_pos

        robot_direction = self.robot.get_forward_vector()

        if SMALL_OBSTACLE and not CURRENT_OBSTACLE:
            print("SMALL OBSTACLE")
            distance_from_center = distance_sensor + ROBOT_RADIUS 
            final_value = (0.201 * distance_from_center + 0.030)
            obstacle_pos = robot_pos + robot_direction * final_value
            x_final = obstacle_pos.x
            z_final = obstacle_pos.y
            print(f"DISTANCE SENSOR: {distance_sensor} --- LIDAR: {frontlayer4} --- CALCULO DISTANCE SENSOR: {final_value}")
            print(f"Distance sensor position: {x_final}, {z_final}")
    
           
        elif CURRENT_OBSTACLE or SMALL_OBSTACLE:
            print("OBSTACLE IN FRONT")
            number_of_rays = len(possible_rays)
            center = number_of_rays // 2
            
            raw_distance_to_obstacle = possible_rays[center][0] 
            ray_angle = possible_rays[center][1]
            
            x_robot = robot_pos.x
            z_robot = robot_pos.y

            angle_rad = math.radians(ray_angle - 180.0)

            x_obstacle = raw_distance_to_obstacle * math.sin(angle_rad)
            z_obstacle = raw_distance_to_obstacle * math.cos(angle_rad)

            x_final = x_robot + (x_obstacle * math.cos(yaw) - z_obstacle * math.sin(yaw))
            z_final = z_robot - (x_obstacle * math.sin(yaw) + z_obstacle * math.cos(yaw))
            
            print(f"Calculated final obstacle position: ({x_final}, {z_final}) after adjusting with distance sensor position.")
        else:
            return False

        final_point = (x_final, z_final)
        obstacle_points.append(final_point)
        return obstacle_points