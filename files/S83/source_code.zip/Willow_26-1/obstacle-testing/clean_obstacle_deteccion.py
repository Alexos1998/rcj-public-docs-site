import math
import numpy as np

from controller import Robot
robot = Robot()

TIME_STEP = 32

lidar = robot.getDevice("lidar")
lidar.enable(TIME_STEP)

gps = robot.getDevice("gps")
gps.enable(TIME_STEP)

front_camera = robot.getDevice("camaraFrontal")
front_camera.enable(TIME_STEP)

imu = robot.getDevice("inertial_unit")
imu.enable(TIME_STEP)

distance_sensor = robot.getDevice("distance sensor1")
distance_sensor.enable(TIME_STEP)

def is_exclude_color(b, g, r):
    excluded_colors = [(134, 123, 59), (139, 127, 61),
                       (32, 30, 18), (0, 0, 207),
                       (207, 0, 0), (0, 207, 0), 
                       (0, 207, 207), 
                       (21, 21, 21), (20, 20, 20),
                       (240, 239, 239), (207, 207, 207)]
                             
    if (b, g, r) in excluded_colors or (0 <= b <= 3 and 0 <= g <= 3 and 0 <= r <= 3):
        return True
    return False

def possible_obstacle(diff_distance = 0.1, distance = 0.075):
    to_verification = False
    possible_rays = []
    obstacle_points = []   
    
    camera_image = front_camera.getImage()
    h = front_camera.getHeight()
    w = front_camera.getWidth()
    imagenp = np.frombuffer(camera_image, np.uint8).reshape((h, w, 4))
    pixel = imagenp[h // 2, w // 2]
    b, g, r = pixel[0], pixel[1], pixel[2]

    if is_exclude_color(b, g, r):
        return obstacle_points
    
    image = lidar.getRangeImage()
    layer4 = image[1537:2048]
    frontlayer4 = layer4[256]

    if frontlayer4 < 0.08:      
        front_lidar = layer4[206:306]
        left_zone = front_lidar[:33]
        center_zone = front_lidar[33:67]
        right_zone = front_lidar[67:]   

        total_left = sum(1 for dis in left_zone if dis > diff_distance)
        total_mid = sum(1 for dis in center_zone if dis > diff_distance)
        total_right = sum(1 for dis in right_zone if dis > diff_distance)  

        if (total_mid < 6) and (total_left > 5) and (total_right > 5):

            for i in range(len(front_lidar)):
                actual_distance = front_lidar[i]
                if actual_distance < distance:
                    index = (i + 206)
                    actual_angle = index * (360.0 / 512.0)  
                    possible_rays.append([actual_distance, actual_angle])
            to_verification = True
        
        else:
            if distance_sensor < 0.1:
                if abs(distance_sensor - frontlayer4) > 0.034: 
                    to_verification = True

            elif frontlayer4 > 0.045:
                layer1 = image[:512]
                frontlayer1 = layer1[256] 
                if abs(distance_sensor - frontlayer1) < 1: 
                    to_verification = True
    
    if to_verification and len(possible_rays) > 0:
        print("Obstacle detected")
        _, _, yaw = imu.getRollPitchYaw()
        x_gps, _, z_gps = gps.getValues()

        for dist, angle_deg in possible_rays:
            relative_angle_rad = math.radians(angle_deg - 180.0)
    
            x_obstacle = dist * math.cos(relative_angle_rad)
            z_obstacle = dist * math.sin(relative_angle_rad)

            x_final = x_gps + (x_obstacle * math.cos(yaw) - z_obstacle * math.sin(yaw))
            z_final = z_gps + (-x_obstacle * math.sin(yaw) + z_obstacle * math.cos(yaw)) 

            final_point = (x_final, z_final)
            obstacle_points.append({"point": final_point})
            print("final_point:", final_point)
        
    return obstacle_points 

while robot.step(TIME_STEP)!=-1:
    possible_obstacle()
    print("-"*60)