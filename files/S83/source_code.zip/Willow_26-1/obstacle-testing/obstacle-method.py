from controller import Robot
import math

robot = Robot()

TIME_STEP=32
d1 = robot.getDevice("distance sensor1")
d2 = robot.getDevice("distance sensor2")
d3 = robot.getDevice("distance sensor3")   
d4 = robot.getDevice("distance sensor4")
d5 = robot.getDevice("distance sensor5")
d6 = robot.getDevice("distance sensor6")
d7 = robot.getDevice("distance sensor7")
d8 = robot.getDevice("distance sensor8")
d1.enable(TIME_STEP)
d2.enable(TIME_STEP)
d3.enable(TIME_STEP)
d4.enable(TIME_STEP)
d5.enable(TIME_STEP)
d6.enable(TIME_STEP)
d7.enable(TIME_STEP)
d8.enable(TIME_STEP)
ruedaI = robot.getDevice("wheel2 motor")
ruedaD = robot.getDevice("wheel1 motor")
ruedaI.setPosition(float("inf"))
ruedaD.setPosition(float("inf"))
ruedaI.setVelocity(0)
ruedaD.setVelocity(0)
colour_sensor = robot.getDevice("colour_sensor")
colour_sensor.enable(TIME_STEP)
lidar = robot.getDevice("lidar")
lidar.enable(TIME_STEP)
imu = robot.getDevice("inertial_unit")
imu.enable(TIME_STEP)
def obstaculo(distance=0.065):

    sensores_distancia = [d1.getValue(),d2.getValue(),d3.getValue(),d4.getValue(),d5.getValue(),d6.getValue(),d7.getValue(),d8.getValue()]
    
    image = lidar.getRangeImage()
    layer = image[1024:1536]
    #tomo la parte frontal y la divido en 3 partes de 20.
    front = layer[226:286]
    izquierdad = front[:19]
    mid = front[20:39]
    derecha = front[39:]

    #Sumo 1 cada vez que la distancia actual es mayor a la distancia determinada.
    sum_iz = sum(1 for d in izquierdad if d < distance)
    sum_mid = sum(1 for d in mid if d < distance)
    sum_der = sum(1 for d in derecha if d < distance)


    print(f"suma de izquierda {sum_iz}    -------  suma de frente {sum_mid}   -------  suma de dercha  {sum_der}")
    UMBRAL_PARED = 0.055
    UMBRAL_OBSTACULO = 0.025
    
    if any(d < distance for d in front):
        for i,value in enumerate(sensores_distancia):
            #Si es mayor a umbral obstaculo es pared.
            if value < UMBRAL_OBSTACULO:
                print(f"NADA DETECTADO: sensor {i+1} con distancia {value}")
            if value > UMBRAL_PARED: 
                print(f"PARED DETECTADA: sensor {i+1} con distancia {value}")
            elif value > UMBRAL_OBSTACULO and value < UMBRAL_PARED:
                print(f"OBSTACULO DETECTADO: sensor {i+1}: {value} ")
            if i >= 7:
                print("\n")

while robot.step(TIME_STEP)!=-1:
    obstaculo()