from controller import Robot
robot = Robot()
TIMESTEP = 32
distance_sensor= []

lidar = robot.getDevice("lidar")
lidar.enable(TIMESTEP)

for i in range(1,9):
    sensor = robot.getDevice(f"distance sensor{i}")
    sensor.enable(TIMESTEP)
    distance_sensor.append(sensor)

def get_distance_sensor():
    values = []
    for sensor in distance_sensor:
        values.append(sensor.getValue())
    return values

while robot.step(TIMESTEP)!=-1:
    values = get_distance_sensor()
    print(values[3])
    image = lidar.getRangeImage()
    layer1 = image[:512]
    layer4 = image[1537:]
    frontalayer1 = layer1[256]
    frontlayer4 = layer4[256]
    print(frontalayer1, frontlayer4)