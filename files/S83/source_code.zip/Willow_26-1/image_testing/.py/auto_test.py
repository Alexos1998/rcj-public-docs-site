import cv2
from image_test import ImageProcessor
from vector import Vector
import shutil
import os



path = "image_testing//images not seen//victims//"

for folder in ["victims", "Not victims", "None"]:
    if not os.path.exists("imgs\\" + folder):
        os.makedirs("imgs\\" + folder)
    else:
        for f in os.listdir("imgs\\" + folder):
            os.remove("imgs\\" + folder + "\\" + f)

imageProcessor = ImageProcessor()
for f in os.listdir(path):
    img = cv2.imread(path + f)
    if img is None:
        continue
    # result = imageProcessor.analyze_zoomed_image(img, Vector(0, 1), Vector(1, 0))
    # if result == "S":
    #     shutil.copy(path + f, "imgs\\S\\" + f)
    # elif result == "C":
    #     shutil.copy(path + f, "imgs\\C\\" + f)
    # elif result == "P":
    #     shutil.copy(path + f, "imgs\\P\\" + f)
    # elif result == "F":
    #     shutil.copy(path + f, "imgs\\F\\" + f)
    # elif result == "O":aa
    #     shutil.copy(path + f, "imgs\\O\\" + f)
    # elif result == "H":
    #     shutil.copy(path + f, "imgs\\H\\" + f)
    # elif result == "U":
    #     shutil.copy(path + f, "imgs\\U\\" + f)
    # else:
    #     shutil.copy(path + f, "imgs\\None\\" + f)
    
    # result = imageProcessor.analyze_image(img, Vector(0, 0), Vector(1, 0))
    # if result == 'H':
    #     shutil.copy(path + f, "imgs\\H\\" + f)
    # elif result == 'S':
    #     shutil.copy(path + f, "imgs\\S\\" + f)
    # elif result == 'U':
    #     shutil.copy(path + f, "imgs\\U\\" + f)
    # else:
    #     shutil.copy(path + f, "imgs\\None\\" + f)

    # result = imageProcessor.get_diameter(path + f)
    print(f"Processing {f}...")
    result = imageProcessor.is_victim(img)
    if result:
        shutil.copy(path + f, "imgs\\victims\\" + f)
    elif result == False:
        shutil.copy(path + f, "imgs\\Not victims\\" + f)
    else:
        shutil.copy(path + f, "imgs\\None\\" + f)

    # result = imageProcessor.clean_circle(img)
    # if result is not None:
    #     aux_img, thresh = result
    #     cv2.imwrite("imgs\\CT drawns\\" + f, aux_img)
    #     cv2.imwrite("imgs\\CT drawns\\thresh_" + f, thresh)
    # else:
    #     shutil.copy(path + f, "imgs\\None\\" + f)
    # if result == "C":
    #     shutil.copy(path + f, "imgs\\C\\" + f)
    # elif result == "P":
    #     shutil.copy(path + f, "imgs\\P\\" + f)
    # elif result == "F":
    #     shutil.copy(path + f, "imgs\\F\\" + f)
    # elif result == "O":
    #     shutil.copy(path + f, "imgs\\O\\" + f)
    # elif result == "None":
    #     shutil.copy(path + f, "imgs\\None\\" + f)
    # elif result == "Z":
    #     shutil.copy(path + f, "imgs\\Z\\" + f)