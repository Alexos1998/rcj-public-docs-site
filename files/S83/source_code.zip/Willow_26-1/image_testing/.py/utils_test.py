import numpy as np

import logging
logger = logging.getLogger("willow")
logging.basicConfig(filename='willow.log', encoding='utf-8', level=logging.DEBUG)

def log_debug(msg):
    logger.debug(msg)

def clamp(val, min_val, max_val):
    if val < min_val: return min_val
    if val > max_val: return max_val
    return val

def point_on_horizontal_border(robot_position, tolerance = 0.0025):
    aux = robot_position.y - 0.06
    return near_multiple(aux, 0.12, tolerance)
 
def point_on_vertical_border(robot_position, tolerance = 0.0025):
    aux = robot_position.x - 0.06
    return near_multiple(aux, 0.12, tolerance)

def near_multiple(num, base = 0.12, tolerance = 1e-6):
    # Encuentra el múltiplo más cercano de la base
    closest_multiple = round(num / base) * base
    # Verifica si la diferencia es menor que la tolerancia
    return abs(num - closest_multiple) < tolerance

def sort_cw(list_points):
    list_aux = list_points.copy()
    # Ordena los puntos en sentido horario
    aux=[]
    sum_min = 1000
    first = 0
    for i in range(4):
        sum_points = list_aux[i][0] + list_aux[i][1]
        if sum_points < sum_min:
            sum_min = sum_points
            first = i
    # remove an element of numpy array
    pos_1 = list_aux[first]
    list_aux = np.delete(list_aux, first, axis=0)

    sum_max =- 10000
    third = 0
    for i in range(3):
        sum_points = list_aux[i][0] + list_aux[i][1]
        if sum_points > sum_max:
            sum_max = sum_points
            third = i
    pos_3 = list_aux[third]
    list_aux = np.delete(list_aux, third, axis=0)

    if list_aux[0][0] > list_aux[1][0]:
        pos_2 = list_aux[0]
        pos_4 = list_aux[1]
    else:
        pos_2 = list_aux[1]
        pos_4 = list_aux[0]
    return np.array([pos_1, pos_2, pos_3, pos_4], dtype = np.float32)

def get_target_contour(contours, hierarchy, is_letter_contour = False):
    hierarchy = hierarchy[0]
    for component in zip(contours, hierarchy):
        current_contour = component[0]
        current_hierarchy = component[1]
        print(f"Current hierarchy: {current_hierarchy} in get_target_contour")
        if not is_letter_contour:
            # print(f"current_hierarchy: {current_hierarchy} in get_target_contour")
            if current_hierarchy[2] >= 0:
                contour = current_contour
                # if True:
                    # print(f"contour found! {contour}")
                return contour
        else:
            # print(f"Contour hierarchy: {current_hierarchy} in get_target_contour")
            # print(f"Hierarchy[2]: {current_hierarchy[2]}, Hierarchy[3]: {current_hierarchy[3]}")
            if current_hierarchy[2] < 0 and current_hierarchy[3] >= 0: # NOTE (Martu): Here it says: "if the contour has no children and has a parent". This should be changed for new victims...
            # if current_hierarchy[3] >= 0: # NOTE (Martu): Because of omega, we will now try just looking for the contours with a parent; 
                # now the letter contour can contain an inner contour.
                contour = current_contour
                return contour
    print(f"Returning None in get_target_contour")
    return None

def get_percentage(a, b):
    total = a + b
    if total == 0: return None
    a_percentage = round((a / total) * 100)
    b_percentage = round((b / total) * 100)
    return a_percentage, b_percentage