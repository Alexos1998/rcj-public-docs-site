import numpy as np
from vector import Vector
from tile_classifier import TileType
from mapping.map import Map, TILE_SIZE, SCALE
import math
from enum import Enum
import cv2
import utils

TILE_SIZE_PX = int(TILE_SIZE * SCALE)

class Tile:
    def __init__(self, tile_type, pos):
        self.tile_type = tile_type
        self.pos = pos
        self.rep = np.zeros((5,5), dtype=int)
        self.area = None
        
    def __repr__(self):
        return f"Tile({self.tile_type}, {self.pos}, Area {self.area})"

    def __str__(self):
        return f"Tile({self.tile_type}, {self.pos}, Area {self.area})"
    
class Curve(Enum):
    LEFT_TOP = 6
    RIGHT_TOP = 7
    RIGHT_BOTTOM = 8
    LEFT_BOTTOM = 9
    VALUES_REPLACED_BY_1 = 10
    # OBSTACLE = 11

class Mapper:
    
    def __init__(self):
        self.signs = {}
        self.tiles = {}
        self.visited_tiles = []
        self.map = Map()
        # self.obstacles_tiles = set()
        self.obstacles = set()

    def set_area(self, tile, area):
        """Sets the area of a Tile object."""
        if self.is_color_passage(tile): return None
        tile.area = area
    
    def is_color_passage(self, tile):
        """Evaluates if a Tile object is or not a color passage."""
        colored_types = [TileType.BLUE, TileType.YELLOW, TileType.GREEN, \
                         TileType.PURPLE, TileType.ORANGE, TileType.RED]
        return tile.tile_type in colored_types
    
    def get_new_area(self, area, tile):
        """Gets the new possible areas of a tile after visiting a color passage."""
        color = tile.tile_type
        possible_areas = {
            (1, TileType.BLUE): 2, #area 1, blue? area 2
            (1, TileType.YELLOW): 3,
            (1, TileType.GREEN): 4,
            (2, TileType.BLUE): 1, #area 2, blue? area 1
            (2, TileType.PURPLE): 3, #""
            (2, TileType.ORANGE): 4,
            (3, TileType.YELLOW): 1,
            (3, TileType.PURPLE): 2,
            (3, TileType.RED): 4,
            (4, TileType.GREEN): 1,
            (4, TileType.ORANGE): 2,
            (4, TileType.RED): 3
        }
        change_of_area = (area, color)
        if change_of_area in possible_areas:
            return possible_areas[change_of_area] 
        return None
    
    def get_tile_at_pos(self, pos):
        """Returns the Tile object from a specific pos in the tiles dict. If theres no pos, None."""
        return self.tiles.get(pos, None)
    
    def get_visited_tile_at_pos(self, pos):
        """Returns the Tile object from a specific pos in the visited_tiles dict list. If theres no pos, None."""
        for visited_tiles_dict in self.visited_tiles:
            if pos in visited_tiles_dict:
                return visited_tiles_dict[pos]
        return None
    
    def is_tile_in_visited_tiles(self, pos):
        """Returns true if the tile in the pos is in the visited_tiles dict list."""
        for visited_tiles_dict in self.visited_tiles:
            if pos in visited_tiles_dict:
                return True
        return False
     
    def add_sign(self, letter, pos, tile_pos):
        """Adds a sign from a world position to the sign dict (pos -> (tile_pos, letter)) """
        self.signs[pos] = (tile_pos,letter)        
        # print(f"Carteles: {self.signs}")

    def add_tile(self, tile):
        """Adds any new tile to the tile dict (tile_pos -> tile)"""
        if tile.pos not in self.tiles:
            # print(f"Adding tile: {tile} at pos {tile.pos}")
            self.tiles[tile.pos] = tile

    def add_visited_tile(self, tile):
        """Adds any new tile to the visited tile dict list [{(tile_pos -> tile)}]"""
        for visited_tiles_dict in self.visited_tiles:
            if tile.pos in visited_tiles_dict:
                return
        self.visited_tiles.append({tile.pos: tile})

    def add_tiles(self, tile_list):
        """Adds a  of tiles to the tile dict"""
        for pos, tile_type in tile_list.items(): 
            tile=Tile(tile_type, pos)
            self.add_tile(tile)

    def update(self, robot_pos, lidar_points, surrounding_tiles):
        """Updates tiles dict and the map image"""
        self.add_tiles(surrounding_tiles)
        self.map.update(robot_pos, lidar_points, surrounding_tiles)

    def add_obstacles(self, obstacle_pos):
        self.obstacles.add(obstacle_pos)

        if obstacle_pos in self.tiles:
            self.tiles[obstacle_pos].tile_type = TileType.OBSTACLE
        else:
            self.tiles[obstacle_pos] = Tile(TileType.OBSTACLE, obstacle_pos)

    def pixel_to_tile(self, pixel):
        """Converts a pixel coord into tile coord"""
        col=int(pixel[0]/TILE_SIZE_PX)
        row=int(pixel[1]/TILE_SIZE_PX)
        return (col, row)
    
    def set_left_straight_wall(self, tile_rep, row_quarter_map, col_quarter_map):
        """Sets a left straight wall itno a quarter tile"""
        tile_rep[row_quarter_map, col_quarter_map] = 1
        tile_rep[row_quarter_map + 1, col_quarter_map] = 1
        tile_rep[row_quarter_map + 2, col_quarter_map] = 1

    def set_right_straight_wall(self, tile_rep, row_quarter_map, col_quarter_map):
        """Sets a right straight wall itno a quarter tile"""
        tile_rep[row_quarter_map, col_quarter_map + 2] = 1
        tile_rep[row_quarter_map + 1, col_quarter_map + 2] = 1
        tile_rep[row_quarter_map + 2, col_quarter_map + 2] = 1

    def set_top_straight_wall(self, tile_rep, row_quarter_map, col_quarter_map):
        """Sets a top straight wall itno a quarter tile"""
        tile_rep[row_quarter_map, col_quarter_map] = 1
        tile_rep[row_quarter_map, col_quarter_map + 1] = 1
        tile_rep[row_quarter_map,col_quarter_map + 2] = 1

    def set_bottom_straight_wall(self, tile_rep, row_quarter_map, col_quarter_map):
        """Sets a bottom straight wall itno a quarter tile"""
        tile_rep[row_quarter_map + 2,col_quarter_map] = 1
        tile_rep[row_quarter_map + 2,col_quarter_map + 1] = 1
        tile_rep[row_quarter_map + 2,col_quarter_map + 2] = 1

    def set_left_top_curve_wall(self, tile_rep, row_quarter_map, col_quarter_map):
        """Sets a left top curve wall (in convex terms) into a quarter tile and adds a special decodification to its vertex"""
        tile_rep[row_quarter_map, col_quarter_map + 2] = 1
        tile_rep[row_quarter_map + 1, col_quarter_map + 2] = 1
        tile_rep[row_quarter_map + 2, col_quarter_map] = 1
        tile_rep[row_quarter_map + 2, col_quarter_map + 1] = 1
        tile_rep[row_quarter_map + 2, col_quarter_map + 2] = Curve.LEFT_TOP.value

    def set_right_top_curve_wall(self, tile_rep, row_quarter_map, col_quarter_map):
        """Sets a right top curve wall (in convex terms) into a quarter tile and adds a special decodification to its vertex"""
        tile_rep[row_quarter_map,col_quarter_map] = 1
        tile_rep[row_quarter_map + 1, col_quarter_map] = 1
        tile_rep[row_quarter_map + 2, col_quarter_map + 1] = 1
        tile_rep[row_quarter_map + 2, col_quarter_map + 2] = 1
        tile_rep[row_quarter_map + 2, col_quarter_map]= Curve.RIGHT_TOP.value

    def set_right_bottom_curve_wall(self, tile_rep, row_quarter_map, col_quarter_map):
        """Sets a right bottom curve wall (in convex terms) into a quarter tile and adds a special decodification to its vertex"""
        tile_rep[row_quarter_map,col_quarter_map + 1] = 1
        tile_rep[row_quarter_map,col_quarter_map + 2] = 1
        tile_rep[row_quarter_map + 1, col_quarter_map] = 1
        tile_rep[row_quarter_map + 2, col_quarter_map] = 1
        tile_rep[row_quarter_map, col_quarter_map] = Curve.RIGHT_BOTTOM.value

    def set_left_bottom_curve_wall(self, tile_rep, row_quarter_map, col_quarter_map):
        """Sets a left bottom curve wall (in convex terms) into a quarter tile and adds a special decodification to its vertex"""
        tile_rep[row_quarter_map, col_quarter_map] = 1
        tile_rep[row_quarter_map, col_quarter_map + 1] = 1
        tile_rep[row_quarter_map + 1, col_quarter_map + 2] = 1
        tile_rep[row_quarter_map + 2, col_quarter_map + 2] = 1
        tile_rep[row_quarter_map, col_quarter_map + 2] = Curve.LEFT_BOTTOM.value


    def set_curve_walls(self, quarter_tile, tile_rep, row_quarter_map, col_quarter_map):
        """Logic of setting curve walls in terms of convex. e.g -> concave: right bottom = convex: left top"""
        # Upper left convex wall
        if quarter_tile[3,5]==quarter_tile[4,5]==quarter_tile[5,3]==quarter_tile[5,4]==quarter_tile[4,4]==1 or \
        quarter_tile[2,4]==quarter_tile[3,4]==quarter_tile[4,2]==quarter_tile[4,3]==quarter_tile[3,3]==1:
                self.set_left_top_curve_wall(tile_rep, row_quarter_map, col_quarter_map)

        # Uper right left convex wall
        if quarter_tile[3,0]==quarter_tile[4,0]==quarter_tile[5,1]==quarter_tile[5,2]==quarter_tile[4,1]==1 or \
            quarter_tile[2,1]==quarter_tile[3,1]==quarter_tile[4,2]==quarter_tile[4,3]==quarter_tile[3,2]==1:
                self.set_right_top_curve_wall(tile_rep, row_quarter_map, col_quarter_map)

        # Lower left convex wall
        if quarter_tile[0,3]==quarter_tile[0,4]==quarter_tile[1,5]==quarter_tile[2,5]==quarter_tile[1,4]==1 or \
            quarter_tile[1,2]==quarter_tile[1,3]==quarter_tile[2,4]==quarter_tile[3,4]== quarter_tile[2,3]==1:
                self.set_left_bottom_curve_wall(tile_rep, row_quarter_map, col_quarter_map)

        # Lower right convex wall
        if quarter_tile[0,1]==quarter_tile[0,2]==quarter_tile[1,0]==quarter_tile[2,0]==quarter_tile[1,1]==1 or \
            quarter_tile[1,2]==quarter_tile[1,3]==quarter_tile[2,1]==quarter_tile[3,1]==quarter_tile[2,2]==1:
                self.set_right_bottom_curve_wall(tile_rep, row_quarter_map, col_quarter_map)

        # print(f"Quarter tile map después: \n {tile_rep[row_quarter_map:row_quarter_map+3,col_quarter_map:col_quarter_map+3]}")

    def set_straight_walls(self, quarter_tile, tile_rep, row_quarter_map, col_quarter_map):
        """Logic of setting straight walls (quarter tiles)"""
        # print(f"Tile rep: \n {tile_rep}\n")
        # print(f"Quarter tile: \n {quarter_tile}\n")
        if (quarter_tile[0,0]==quarter_tile[1,0]==quarter_tile[2,0]==quarter_tile[3,0]==quarter_tile[4,0]==quarter_tile[5,0]==1):
            self.set_left_straight_wall(tile_rep, row_quarter_map, col_quarter_map)

        if quarter_tile[0,5]==quarter_tile[1,5]==quarter_tile[2,5]==quarter_tile[3,5]==quarter_tile[4,5]==quarter_tile[5,5]==1:
            # print("Tiene pared derecha")
            self.set_right_straight_wall(tile_rep, row_quarter_map, col_quarter_map)

        if quarter_tile[0,0]==quarter_tile[0,1]==quarter_tile[0,2]==quarter_tile[0,3]==quarter_tile[0,4]==quarter_tile[0,5]==1:
            # print("Tiene pared superior")
            self.set_top_straight_wall(tile_rep, row_quarter_map, col_quarter_map)
        
        if quarter_tile[5,0]==quarter_tile[5,1]==quarter_tile[5,2]==quarter_tile[5,3]==quarter_tile[5,4]==quarter_tile[5,5]==1:
            # print("Tiene pared abajo")
            self.set_bottom_straight_wall(tile_rep, row_quarter_map, col_quarter_map)

    def custom_round(self, value):
        """An own round in wich positive values are increased when rounding, an the negatives are decreased."""
        if value > 0:
            return math.ceil(value)  # 3.1 -> 4
            # return int(value)
        else:
            return math.floor(value)  # -3.1 -> -4

    def clean_map(self, img, min_col, min_row, max_col, max_row):
        """Cleans the image in case of having a little noice of black pixels out of the map range.
        This is because, as we extended our lidar range, it may be some noise in the image of the map,
        we considered that every tile must have, at least, four black pixels."""
        img = img.copy()
        print(f"Cleaning map with min_col: {min_col}, min_row: {min_row}, max_col: {max_col}, max_row: {max_row}")
        if min_row > 1:
            cv2.rectangle(img, (0, 0), (img.shape[1] - 1, min_row), (255, 255, 255), thickness=-1)
        if max_row < img.shape[0] - 1:
            cv2.rectangle(img, (0, max_row), (img.shape[1] - 1, img.shape[0] - 1), (255, 255, 255), thickness=-1)
        if min_col > 1:
            cv2.rectangle(img, (0, 0), (min_col, img.shape[0] - 1), (255, 255, 255), thickness=-1)
        if max_col < img.shape[1] - 1:
            cv2.rectangle(img, (max_col, 0), (img.shape[1] - 1, img.shape[0] - 1), (255, 255, 255), thickness=-1)
        # cv2.imwrite("Mapa que recortamos en map_rect, dentro del clean_map.png", img)
        return img
    
    def clean_unkown_tiles(self, map_rect, tile_pos):
        # Tile_pos received in pixels % 12 = 0
        # TODO (Martu): Implementar!
        pass

    def clean_extra_tiles(self, img, min_col, min_row, max_col, max_row):
        img = img[min_row: max_row + 1, min_col: max_col + 1]
        cv2.imwrite("Mapa que recortamos en map_rect, después de recortar tiles fuera del mapa.png", img)
        return img

    THRESHOLD=254
    def mapping_pixels(self, robot_start_pos):
        # print(f"Estos son los tiles hasta ahora: {self.tiles}")
        """Whole mapping logic"""

        """Gets the map image and looks for its limits"""
        img = self.map.img
        cv2.imwrite("Mapa que nos mandaron.png", img)
        # print(f"Img channels: {img.shape}")
        thresh = cv2.threshold(img, self.THRESHOLD, 255, cv2.THRESH_BINARY)[1]
        cv2.imwrite("Mapa umbralizado.png", thresh)
        img = thresh.copy()

        init_pixel = self.map.world_to_pixel(Vector(0,0))
        
        init_pixel.x=init_pixel.x-6
        init_pixel.y=init_pixel.y-6
        print(f"Init pixel: {init_pixel}")
        
        # Get the row of the pixel that is 0 in the image
        # Hacer que busque el primer pixel negro que sea múltiplo de TILE_SIZE_PX
        min_pixel_row = np.where(np.any(img == 0, axis=1))[0]
        min_pixel_col = np.where(np.any(img == 0, axis=0))[0]
        max_pixel_row = np.where(np.any(img == 0, axis=1))[0][::-1]
        max_pixel_col = np.where(np.any(img == 0, axis=0))[0][::-1]

        print(f"Cols with zeros: {min_pixel_col}")
        print(f"Rows with zeros: {min_pixel_row}")
        print("-"*15)
        
        min_pixel_row = min_pixel_row[0]
        min_pixel_col = min_pixel_col[0]
        max_pixel_row = max_pixel_row[0]
        max_pixel_col = max_pixel_col[0]


        # print(f"Limits: min_pixel_row: {min_pixel_row}, min_pixel_col: {min_pixel_col}, max_pixel_row: {max_pixel_row}, max_pixel_col: {max_pixel_col}")

        # print(f"Antes de la corrección: min_pixel_row: {min_pixel_row}, min_pixel_col: {min_pixel_col}, max_pixel_row: {max_pixel_row}, max_pixel_col: {max_pixel_col}")

        min_pixel_row = max(init_pixel.y-self.custom_round((init_pixel.y-min_pixel_row)/TILE_SIZE_PX)*TILE_SIZE_PX, 0)
        min_pixel_col = max(init_pixel.x-self.custom_round((init_pixel.x-min_pixel_col)/TILE_SIZE_PX)*TILE_SIZE_PX, 0)
        max_pixel_row = min(init_pixel.y+self.custom_round((max_pixel_row-init_pixel.y)/TILE_SIZE_PX)*TILE_SIZE_PX, img.shape[0])
        max_pixel_col = min(init_pixel.x+self.custom_round((max_pixel_col-init_pixel.x)/TILE_SIZE_PX)*TILE_SIZE_PX, img.shape[1])
        # print(f"Después de la corrección: min_pixel_row: {min_pixel_row}, min_pixel_col: {min_pixel_col}, max_pixel_row: {max_pixel_row}, max_pixel_col: {max_pixel_col}")

        crop_row_offset = min_pixel_row
        crop_col_offset = min_pixel_col
        map_rect = img[min_pixel_row: max_pixel_row, min_pixel_col: max_pixel_col]
        np.savetxt("Mapa que recortamos en map_rect, antes del clean_map.txt", map_rect, fmt='%03d', delimiter=';')
        cv2.imwrite("Mapa que recortamos en map_rect, antes del clean_map.png", map_rect)

        """Map_rect represents a matrix where tiles are represented as 12x12 pixels,
        this rep will be the first step to build the representation of the tile and the
        final matrix that will be used to build the map (tiles * 4 + 1)."""
        # print(f"Map rect shape before clean_map: {map_rect.shape}")

        min_pixel_row = max(utils.get_nearest_multiple(np.where(np.any(map_rect == 0, axis=1))[0][0], 6) - 1, 0)
        min_pixel_col = max(utils.get_nearest_multiple(np.where(np.any(map_rect == 0, axis=0))[0][0], 6) - 1, 0)
        max_pixel_row = min(utils.get_nearest_multiple(np.where(np.any(map_rect == 0, axis=1))[0][::-1][0], 6) + 1, map_rect.shape[0])
        max_pixel_col = min(utils.get_nearest_multiple(np.where(np.any(map_rect == 0, axis=0))[0][::-1][0], 6) + 1, map_rect.shape[1])
        print(f"Limits after cropping img: min_pixel_row: {min_pixel_row}, min_pixel_col: {min_pixel_col}, max_pixel_row: {max_pixel_row}, max_pixel_col: {max_pixel_col}")

        map_rect = self.clean_map(map_rect, min_pixel_col, min_pixel_row, max_pixel_col, max_pixel_row)
        np.savetxt("Mapa después del primer clean_map.txt", map_rect, fmt='%03d', delimiter=';')
        cv2.imwrite("Mapa después del primer clean_map.png", map_rect)
        print(f"Map rect shape after clean_map: {map_rect.shape}")

        # TODO (Martu): Recortar de la imagen los tiles que quedan fuera del mapa (límites de min_row, min_col, max_row, max_col)

        # # init pixel está como columna, fila
        init_pixel.x = init_pixel.x - crop_col_offset
        init_pixel.y = init_pixel.y - crop_row_offset
        print(f"Init pixel after adjusting to map_rect: {init_pixel}")
        aux_rect = map_rect.copy()
        cv2.circle(aux_rect, (init_pixel.x, init_pixel.y), 3, (0,100,127), thickness=-1)
        cv2.imwrite("Mapa que recortamos en map_rect, con el pixel inicial marcado.png", aux_rect)

        min_pixel_row = np.where(np.any(map_rect == 0, axis=1))[0][0]
        min_pixel_col = np.where(np.any(map_rect == 0, axis=0))[0][0]
        max_pixel_row = np.where(np.any(map_rect == 0, axis=1))[0][::-1][0]
        max_pixel_col = np.where(np.any(map_rect == 0, axis=0))[0][::-1][0]

        map_rect = self.clean_extra_tiles(map_rect, min_pixel_col, min_pixel_row, max_pixel_col, max_pixel_row)

        # Ajustamos el init pixel con los valores calculados ANTES de clean_extra_tiles,
        # ya que ese recorte desplaza la imagen min_pixel_col/row píxeles.
        # (Recalcular min_pixel_col/row después del recorte siempre da 0 y no corrige nada.)
        init_pixel.x = init_pixel.x - min_pixel_col
        init_pixel.y = init_pixel.y - min_pixel_row
        print(f"Init pixel after adjusting to cleaned map_rect: {init_pixel}")

        init_tile=self.pixel_to_tile((init_pixel.x, init_pixel.y))
        print(f"Init tile: {init_tile}") # The left upper tile

        """The image values should be changed to matrix values, where no walls(255) are '0' and walls(0) are '1'."""
        map_rect[map_rect == 0] = 1
        map_rect[map_rect == 255] = 0
        np.savetxt("Mapa que recortamos, después de cambiar 0 por 1 y 255 por 0.txt", map_rect, fmt='%d', delimiter=';')

        # Straight walls 
        """Setting straight walls"""

        for col_tile_pixel in range(0, map_rect.shape[1], TILE_SIZE_PX):
            for row_tile_pixel in range(0, map_rect.shape[0], TILE_SIZE_PX):
                # Placing in the centre of the tile
                print(f"Taking pixel: {(col_tile_pixel+int(TILE_SIZE_PX/2), row_tile_pixel+int(TILE_SIZE_PX/2))}")
                tile_pos = self.pixel_to_tile((col_tile_pixel+int(TILE_SIZE_PX/2), row_tile_pixel+int(TILE_SIZE_PX/2)))
                # Making pos. relative to start
                tile_pos=(tile_pos[0]-init_tile[0],tile_pos[1]-init_tile[1])
                print(f"Tile pos: {tile_pos}")
                """Maps could contain tiles that are not in the map and that are not traversable that should be mapped and represented in the matrix,
                thats why these are created as 'UNKNOWN'"""
                if tile_pos not in self.tiles:
                    self.add_tiles({tile_pos:TileType.UNKNOWN})
                    # continue
                
                tile_rep = self.tiles[tile_pos].rep
                print(f"Tile rep before: \n {tile_rep}\n")
                tile_area = self.tiles[tile_pos].area

                for row_quarter_pixel in range(0, TILE_SIZE_PX, int(TILE_SIZE_PX/2)):
                    for col_quarter_pixel in range(0, TILE_SIZE_PX, int(TILE_SIZE_PX/2)):
                        quarter_tile = map_rect[row_tile_pixel + row_quarter_pixel: row_tile_pixel + row_quarter_pixel + int(TILE_SIZE_PX/2), \
                                              col_tile_pixel + col_quarter_pixel: col_tile_pixel + col_quarter_pixel + int(TILE_SIZE_PX/2)]

                        if col_quarter_pixel == 0:
                            col_quarter_map = 0
                        else:
                            col_quarter_map = 2
                        if row_quarter_pixel == 0:
                            row_quarter_map = 0
                        else:
                            row_quarter_map = 2
                        
                        self.set_straight_walls(quarter_tile, tile_rep, row_quarter_map, col_quarter_map)        
        
        # Curved walls (always talking in terms of convex walls)
                if tile_area != 1 and tile_area != 2 and tile_area != 4:
                    for row_quarter_pixel in range(0, TILE_SIZE_PX, int(TILE_SIZE_PX/2)):
                        for col_quarter_pixel in range(0, TILE_SIZE_PX, int(TILE_SIZE_PX/2)):
                            quarter_tile = map_rect[row_tile_pixel + row_quarter_pixel: row_tile_pixel + row_quarter_pixel + int(TILE_SIZE_PX/2), \
                                                    col_tile_pixel + col_quarter_pixel: col_tile_pixel + col_quarter_pixel + int(TILE_SIZE_PX/2)]

                            if col_quarter_pixel == 0:
                                col_quarter_map = 0
                            else:
                                col_quarter_map = 2
                            if row_quarter_pixel == 0:
                                row_quarter_map = 0
                            else:
                                row_quarter_map = 2
                            
                            self.set_curve_walls(quarter_tile, tile_rep, row_quarter_map, col_quarter_map)

                print(f"Tile rep after: \n {tile_rep}\n")

        print(f"Map rect with tile reps: \n {map_rect}\n")
        print("-"*25)

        print(f"Tiles with their representation: {self.tiles}")
        print("-"*15)

        """Starting the construction of final matrix, tiles will be represented as 5x5, but sharing walls,
        so it would finally be 4x4 + 1"""
        min_row = min(t[1] for t in self.tiles.keys())
        min_col = min(t[0] for t in self.tiles.keys())
        max_row = max(t[1] for t in self.tiles.keys())
        max_col = max(t[0] for t in self.tiles.keys())
        tile_rows = max_row - min_row + 1
        tile_cols = max_col - min_col + 1

        # construct a matrix full of zeros       
        final_matrix = np.zeros((tile_rows * 4 + 1,tile_cols * 4 + 1), dtype=int)
        matrix_col = 0
        # Iterating through every col
        for tile_col in range(min_col, max_col + 1):
            matrix_row = 0
            for tile_row in range(min_row, max_row + 1):
                # By every row
                tile_pos = (tile_col, tile_row)
                if tile_pos not in self.tiles:
                    matrix_row += 4 # in order to continue with the next tile
                    continue
                tile_rep = self.tiles[tile_pos].rep
                # print(f"Tile rep: {tile_rep}")
                for col in range(5):
                    for row in range(5):
                        new = tile_rep[row, col]
                        old = final_matrix[matrix_row + row, matrix_col + col]
                        """For the supervisor, the tiles only have right and bottom walls (except for the corner col, rows) 
                        and always replace old values for the new ones. This is a problem for curve walls,
                        thats why we have to evaluate the new value of the quarter and the type of curve."""
                        if (new == 1 and old == 0) or (old == 1 and new == 0):
                            final_matrix[matrix_row + row, matrix_col + col] = 1
                        elif new in [Curve.LEFT_TOP.value, Curve.RIGHT_TOP.value, Curve.RIGHT_BOTTOM.value, Curve.LEFT_BOTTOM.value]:
                            # print(f"Tile {tile_pos} tiene curva {new}")
                            final_matrix[matrix_row + row, matrix_col + col] = new
                        # elif old == TileType.STANDARD.value and new == TileType.OBSTACLE.value:
                        #     final_matrix[matrix_row + row, matrix_col + col] = TileType.OBSTACLE.value
                            """We made a special decodification for each curve wall vertex to recognise them while placing signs,
                            even if the wall's vertex should be replaced by a 1 in the final matrix."""
                       
                        elif old == Curve.LEFT_BOTTOM.value:
                            # print(f"Tile {tile_pos} tiene curva {old}")
                            if col == 0 and row == 2 and new == 1:
                                if tile_rep[2, 1] == 1 and tile_rep[2, 2] == 1: # Horizontal wall
                                    final_matrix[matrix_row + row, matrix_col + col] = Curve.VALUES_REPLACED_BY_1.value
                            elif col == 0 and row == 0 and new == 1:
                                if tile_rep[0, 1] == 1 and tile_rep[0, 2] == 1:
                                    final_matrix[matrix_row + row, matrix_col + col] = Curve.VALUES_REPLACED_BY_1.value
                            else:
                                final_matrix[matrix_row + row, matrix_col + col] = Curve.LEFT_BOTTOM.value

                        elif old == Curve.LEFT_TOP.value:
                            if col == 4 and row == 0 and new == 1:
                                if (tile_rep[1, 4] == tile_rep[2, 4] == 1):
                                    final_matrix[matrix_row + row, matrix_col + col] = Curve.VALUES_REPLACED_BY_1.value
                            elif col == 0 and row == 4 and new == 1:
                                if tile_rep[4, 1] == 1 and tile_rep[4, 2] == 1: # Horizontal wall
                                    final_matrix[matrix_row + row, matrix_col + col] = Curve.VALUES_REPLACED_BY_1.value
                            elif col == 0 and row == 2 and new == 1:
                                if tile_rep[2, 1] == 1 and tile_rep[2, 2] == 1: # Horizontal wall
                                    final_matrix[matrix_row + row, matrix_col + col] = Curve.VALUES_REPLACED_BY_1.value
                            elif col == 2 and row == 0 and new == 1:
                                if tile_rep[1, 2] == 1 and tile_rep[2, 2] == 1: # Horizontal wall
                                    final_matrix[matrix_row + row, matrix_col + col] = Curve.VALUES_REPLACED_BY_1.value

                        elif old == Curve.RIGHT_TOP.value:
                            if col == 2 and row == 0 and new == 1:
                                if tile_rep[1, 2] == 1 and tile_rep[2, 2] == 1: # Vertical wall
                                    final_matrix[matrix_row + row, matrix_col + col] = Curve.VALUES_REPLACED_BY_1.value
                            elif col == 0 and row == 4 and new == 1:
                                if tile_rep[4, 1] == 1 and tile_rep[4, 2] == 1: # Horizontal wall
                                    final_matrix[matrix_row + row, matrix_col + col] = Curve.RIGHT_TOP.value
                            elif col == 0 and row == 0 and new == 1:
                                if tile_rep[0, 1] == 1 and tile_rep[0, 2] == 1: # Horizontal wall
                                    final_matrix[matrix_row + row, matrix_col + col] = Curve.RIGHT_TOP.value
                                elif (tile_rep[1, 0] == tile_rep[2, 0] == 1): # Vertical wall
                                    final_matrix[matrix_row + row, matrix_col + col] = Curve.RIGHT_TOP.value

                        elif old == Curve.VALUES_REPLACED_BY_1.value and new == 1:
                            final_matrix[matrix_row + row, matrix_col + col] = Curve.VALUES_REPLACED_BY_1.value 
                matrix_row += 4
            matrix_col += 4

        final_matrix=final_matrix.astype(str)
        np.savetxt("Matriz final después de poner las paredes.txt", final_matrix, fmt='%s', delimiter=';')

        """Stablish the types of tiles in the matrix, acording to its setted type values"""
        for tile_col in range(min_col, max_col + 1):
            for tile_row in range(min_row, max_row + 1):
                tile_pos = (tile_col, tile_row)
                if tile_pos not in self.tiles:
                    matrix_row += 4
                    continue
                print(f"Tile pos: {tile_pos}")
                
                tile_type = self.tiles[tile_pos].tile_type
                tile_area = self.tiles[tile_pos].area
                if tile_type == TileType.STANDARD or tile_type == TileType.UNKNOWN: # Don't draw anything, bc they do not have a specific type
                    matrix_row += 4
                    continue
                else:
                    matrix_row = (tile_row - min_row) * 4
                    matrix_col = (tile_col - min_col) * 4
                    final_matrix[matrix_row + 1, matrix_col + 1] = tile_type.value
                    final_matrix[matrix_row + 1, matrix_col + 3] = tile_type.value
                    final_matrix[matrix_row + 3, matrix_col + 1] = tile_type.value
                    final_matrix[matrix_row + 3, matrix_col + 3] = tile_type.value
                matrix_row += 4
            matrix_col += 4

        """Placing signs."""

        top_left_pos = Vector(round(robot_start_pos.x,2) - 0.12 / 2 + 0.12 * min_col, round(robot_start_pos.y,2) - 0.12 / 2 + 0.12 * min_row)
        bottom_right_pos = Vector(round(robot_start_pos.x,2) + 0.12 / 2 + 0.12 * max_col, round(robot_start_pos.y,2) + 0.12 / 2 + 0.12 * max_row)
        signs=[]
        for pos, tile_pos_and_let in self.signs.items():
            """Obtaining the right grid pos of the signs"""
            map_col = round(self.map_range(round(pos.x,2), top_left_pos.x, bottom_right_pos.x, 0, final_matrix.shape[1] - 1), 0)
            map_row = round(self.map_range(round(pos.y,2), top_left_pos.y, bottom_right_pos.y, 0, final_matrix.shape[0] - 1), 0) #NOTE: The last argument is not necessary
            signs.append((tile_pos_and_let[0], (map_row, map_col), tile_pos_and_let[1], pos))
        # sort signs by the first element of the first element of the tuple
        signs.sort(key=lambda x: (x[0][1], x[0][0], pos.y, pos.x))

        for sign in signs:
            map_row = int(sign[1][0])
            map_col = int(sign[1][1])
            letter = sign[2]
            tile_row = sign[0][1]
            tile_col = sign[0][0]

            type_of_wall = self.type_of_wall(map_row, map_col, final_matrix)
            quarter_side=self.world_to_quarter_side(sign[3], tile_cols, tile_rows)
            
            if type_of_wall != "c": #Straight wall
                
                self.place_letter(letter, map_row, map_col, final_matrix)
                continue

            # In which quarter is the letter?
            quarter_side = self.world_to_quarter_side(sign[3], tile_cols, tile_rows)
            if quarter_side == 0:
                row_off = 0
                col_off = 0
            elif quarter_side == 1:
                row_off = 0
                col_off = 2
            elif quarter_side == 2:
                row_off = 2
                col_off = 0
            elif quarter_side == 3:
                row_off = 2
                col_off = 2

            # Obtain that specific quarter of the tile rep.
            quarter_mat = final_matrix[(tile_row - min_row) * 4 + row_off: (tile_row - min_row) * 4 + row_off + 3, \
                                        (tile_col - min_col) * 4 + col_off: (tile_col - min_col) * 4 + col_off + 3]
            
            if quarter_mat[0,2] != '0' and quarter_mat[1,2] != '0' and quarter_mat[2,0] != '0' and quarter_mat[2,1] != '0' and (quarter_mat[2,2] == '9' or quarter_mat[2,2] == '8' \
                    or quarter_mat[2,2] == '7' or quarter_mat[2,2] == '6' or quarter_mat[2,2] == '10'):
                
                self.place_letter(letter, 2, 1, quarter_mat) # Upper left convex

            elif quarter_mat[0,0] != '0' and quarter_mat[1,0] != '0' and quarter_mat[2,1] != '0' and quarter_mat[2,2] != '0' and (quarter_mat[2,0] =='9' or quarter_mat[2,0] == '8') \
                    or (quarter_mat[2,0] == '7' or quarter_mat[2,0] == '6' or quarter_mat[2,0] == '10'):
                
                self.place_letter(letter, 2, 1, quarter_mat) # Upper right convex

            elif quarter_mat[0,0] != '0' and quarter_mat[0,1] != '0' and quarter_mat[1,2] != '0' and quarter_mat[2,2] != '0' and (quarter_mat[0,2] == '9' or quarter_mat[0,2] == '8') \
                    or (quarter_mat[0,2] == '7' or quarter_mat[0,2] == '6' or quarter_mat[0,2] == '10'):
                
                self.place_letter(letter, 0, 1, quarter_mat) # Lower left convex

            elif quarter_mat[0,1] != '0' and quarter_mat[0,2]!='0' and quarter_mat[1,0]!='0' and quarter_mat[2,0] != '0' and (quarter_mat[0,0] == '9' or quarter_mat[0,0] == '8') \
                    or (quarter_mat[0,0] == '7' or quarter_mat[0,0] == '6' or quarter_mat[0,0] == '10'):
                
                self.place_letter(letter, 0, 1, quarter_mat) # Lower right convex
            else:
                print("The letter position is not defined, this should be IMPOSSIBLE!!")
                print(f"Quarter mat: \n {quarter_mat}")
                print(f"letter: {letter}")

        """Completing area 4 tiles"""
        self.flood_fill_area_4()

        for tile_row in range(min_row, max_row+1):
            for tile_col in range(min_col, max_col+1):
                tile_pos=(tile_col, tile_row)
                if tile_pos not in self.tiles:
                    continue
                tile = self.tiles[tile_pos]
                if tile.area == 4:
                    matrix_row = (tile_row - min_row) * 4
                    matrix_col = (tile_col - min_col) * 4
                    final_matrix[matrix_row: matrix_row + 5, matrix_col: matrix_col + 5] = '*'
                    print(f"Tile {tile_pos} is area 4, setting it to '*' in the final matrix")

        """Replacing curved wall vertex with 0 and obstacles with X"""
        final_matrix[final_matrix == '6'] = '0' # TODO: Here it should be instead of '6', etc. str(Curve.(...)) as in the line 534...
        final_matrix[final_matrix == '7'] = '0'
        final_matrix[final_matrix == '8'] = '0'
        final_matrix[final_matrix == '9'] = '0'    
        final_matrix[final_matrix == str(Curve.VALUES_REPLACED_BY_1.value)] = '1'
        # final_matrix[final_matrix == str(Curve.OBSTACLE.value)] = 'X'

        # Guardar el mapa final
        np.savetxt("Mapa final.txt", final_matrix, fmt='%s', delimiter=';')
        # print(f"Saved final matrix: \n {final_matrix}")

        return final_matrix
    
    def flood_fill_area_4(self):
        a4_tiles = [tile for tile in self.tiles.values() if tile.area==4]
        if len(a4_tiles) == 0: return
        start = a4_tiles[0]
        frontier = [start]
        reached = set()
        reached.add(start)

        while not len(frontier) == 0:
            current = frontier.pop(0)
            # print(f"Flood fill: Current tile {current.pos} with area {current.area}")

            if current.area == None:
                # print(f"Flood fill: Setting tile {current.pos} to area 4")
                current.area = 4

            if current.tile_type == TileType.UNKNOWN:
                continue

            for next in self.get_valid_neighbours(current):
                # if current.pos == (7, -3):
                #     print(f"ACAACA {next}")
                if next.area == 1 or next.area == 2 or next.area == 3:
                    continue

                if self.is_color_passage(next):
                    continue                

                if next not in reached:
                    frontier.append(next)
                    reached.add(next)

    def get_valid_neighbours(self, tile):
        row = tile.pos[1]
        col = tile.pos[0]
        result = []

        # Upper tile
        row_to_check = row - 1
        col_to_check = col
        neighbour_tile = self.tiles.get((col_to_check, row_to_check))
        if neighbour_tile is not None:
            if not (neighbour_tile.rep[4,1] != 0 and neighbour_tile.rep[4,2] != 0 and neighbour_tile.rep[4,3] != 0) and \
                not (tile.rep[0,1] != 0 and tile.rep[0,2] != 0 and tile.rep[0,3] != 0):
                result.append(neighbour_tile)

        # Lower tile
        row_to_check = row + 1
        col_to_check = col
        neighbour_tile = self.tiles.get((col_to_check, row_to_check))
        if neighbour_tile is not None:
            if not(neighbour_tile.rep[0,1] != 0 and neighbour_tile.rep[0,2] != 0 and neighbour_tile.rep[0,3] != 0) and \
                not (tile.rep[4,1] != 0 and tile.rep[4,2] != 0 and tile.rep[4,3] != 0):
                result.append(neighbour_tile)
 
        # Left tile
        row_to_check = row
        col_to_check = col - 1
        neighbour_tile = self.tiles.get((col_to_check, row_to_check))
        if neighbour_tile is not None:
            if not(neighbour_tile.rep[1,4] != 0 and neighbour_tile.rep[2,4] != 0 and neighbour_tile.rep[3,4] != 0) and \
                not (tile.rep[1,0] != 0 and tile.rep[2,0] != 0 and tile.rep[3,0] != 0):
                result.append(neighbour_tile)
        
        # Right tile
        row_to_check = row
        col_to_check = col + 1
        neighbour_tile = self.tiles.get((col_to_check, row_to_check))
        if neighbour_tile is not None:
            if not(neighbour_tile.rep[1,0] != 0 and neighbour_tile.rep[2,0] != 0 and neighbour_tile.rep[3,0] != 0) and \
                not (tile.rep[1,4] != 0 and tile.rep[2,4] != 0 and tile.rep[3,4] != 0):
                result.append(neighbour_tile)

        return result
    
    def neighbour_area4_counter_no_walls(self, tile):
        row = tile.pos[1]
        col = tile.pos[0]
        count = 0

        # Upper tile
        row_to_check = row - 1
        col_to_check = col
        neighbour_tile = self.tiles.get((col_to_check, row_to_check))
        if neighbour_tile is not None and neighbour_tile.area == 4:
            if not(neighbour_tile.rep[4,1] != 0 and neighbour_tile.rep[4,2] != 0 and neighbour_tile.rep[4,3] != 0): #Si no tiene pared
                count += 1

        # Lower tile
        row_to_check = row + 1
        col_to_check = col
        neighbour_tile = self.tiles.get((col_to_check, row_to_check))
        if neighbour_tile is not None and neighbour_tile.area == 4:
            if not(neighbour_tile.rep[0,1] != 0 and neighbour_tile.rep[0,2] != 0 and neighbour_tile.rep[0,3] != 0):
                count += 1
 
        # Left tile
        row_to_check = row
        col_to_check = col - 1
        neighbour_tile = self.tiles.get((col_to_check, row_to_check))
        if neighbour_tile is not None and neighbour_tile.area == 4:
            if not(neighbour_tile.rep[1,4] != 0 and neighbour_tile.rep[2,4] != 0 and neighbour_tile.rep[3,4] != 0):
                count += 1
        
        # Right tile
        row_to_check = row
        col_to_check = col + 1
        neighbour_tile = self.tiles.get((col_to_check, row_to_check))
        if neighbour_tile is not None and neighbour_tile.area == 4:
            if not(neighbour_tile.rep[1,0] != 0 and neighbour_tile.rep[2,0] != 0 and neighbour_tile.rep[3,0] != 0):
                count += 1

        return count

    def neighbour_area4_counter(self, tile):
        row = tile.pos[1]
        col = tile.pos[0]
        neighbour_tiles = [(-1,0), (1,0), (0,-1), (0,1)] # Cardinal directions
        count = 0
        for step in neighbour_tiles:
            row_to_check = row + step[0]
            col_to_check = col + step[1]
            neighbour_tile = self.tiles.get((col_to_check, row_to_check))
            if neighbour_tile is not None and neighbour_tile.area == 4:
                count += 1
        return count


    def find_matrix_coords(self, pos, start, prt = False):
        """Finds matrix coords as the supervisor."""
        x = pos.x
        x_count = 0
        while x - start.x > 0.03:
            x -= 0.03
            x_count += 1

        y = pos.y
        z_count = 0

        while y - start.y > 0.03:
            y -= 0.03
            z_count += 1 

        x_count = int(x_count/2)
        z_count = int(z_count/2)
        row_temp = 2 * z_count + 1
        col_temp = 2 * x_count + 1 # NOTE: This is a main supervisour's mistake, if the row is zero this fails. :)
        return (col_temp, row_temp)

    def place_letter(self, letter, row, col, map_matrix):
        if map_matrix[row][col] == '0' or map_matrix[row][col] == '1':
            map_matrix[row][col] = letter
        else:
            map_matrix[row][col] += letter

    def map_range(self, value, ori_min, ori_max, dest_min, dest_max):
        return dest_min + (dest_max - dest_min) * (value - ori_min) / (ori_max - ori_min)        

    def type_of_wall(self, row, col, final_matrix):
        """Returns the value of a wall, based on if its an external or internal (vertical, horizontal), or if its curve."""
        if col % 4 == 0 and final_matrix[row-1][col] != '0' and final_matrix[row + 1][col] != '0':
            return "ev"
        if row % 4 == 0 and final_matrix[row][col-1] != '0' and final_matrix[row][col + 1] != '0':
            return "eh"
        if col % 4 == 2 and (row % 4 == 1 or row % 4 == 3) and final_matrix[row - 1][col] == final_matrix[row + 1][col] != '0':
            return "iv"
        if row%4==2 and (col%4==1 or col%4==3) and final_matrix[row][col-1]==final_matrix[row][col+1]!='0':
            return "ih"
        return "c"

    def world_to_quarter_side(self, pos, total_col, total_row):
        # 0 Upper left
        # 1 Upper right
        # 2 Lower left
        # 3 Lower right
        left = False
        sup = False
        abs_x = pos.x % 0.12
        abs_y = pos.y % 0.12
        if total_col % 2 == 0:
            if abs_x > 0.06 and abs_x < 0.12:
                left = True
            else:
                left = False
        
        if total_col % 2 == 1:
            if abs_x > 0 and abs_x < 0.06:
                left = True
            else:
                left = False

        if total_row % 2 == 0:
            if abs_y > 0.06 and abs_y < 0.12:
                sup = True
            else:
                sup = False

        if total_row % 2 == 1:
            if abs_y > 0 and abs_y < 0.06:
                sup = True
            else:
                sup = False

        if left and sup: return 0
        elif not left and sup: return 1
        elif left and not sup: return 2
        else: return 3
