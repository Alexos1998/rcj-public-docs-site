from controller import Robot as WebotsRobot # type: ignore
import math
import utils
import numpy as np
from vector import Vector
from side import Side
from filter import FrontLidarPositioner, EncoderPositioner
import traceback

MAX_VEL = 6.28
TIME_STEP = 16
LIMIT_STEPS = 100
WHEEL_RADIUS = 0.026
DIST_BETWEEN_WHEELS = 0.104
MIN_POINTS_ICP = 4
MAX_LIDAR_DIST = 1
LIMIT_AVERAGE = 1000

DEBUGGING = False
DEBUGGING_3_CAMS = True
DEBUGGPSOK = False   # True: activa y usa gps_ok para comparar posición; False: no lo habilita

class Robot:
    def __init__(self):
        self.robot = WebotsRobot()

        self.wheel_left = self.robot.getDevice("wheel2 motor")
        self.wheel_right = self.robot.getDevice("wheel1 motor")
        self.wheel_left.setPosition(float('inf'))
        self.wheel_right.setPosition(float('inf'))
        self.stop()

        self.enc_left = self.wheel_left.getPositionSensor()
        self.enc_right = self.wheel_right.getPositionSensor()
        self.enc_left.enable(TIME_STEP)
        self.enc_right.enable(TIME_STEP)
        
        self.gps = self.robot.getDevice("gps")
        self.gps.enable(TIME_STEP)

        self.gps_ok = None
        if DEBUGGPSOK:
            self.gps_ok = self.robot.getDevice("gps_ok")
            self.gps_ok.enable(TIME_STEP)

        self.imu = self.robot.getDevice("inertial_unit")
        self.imu.enable(TIME_STEP)

        self.lidar = self.robot.getDevice("lidar")
        self.lidar.enable(TIME_STEP)

        self.front_camera = self.robot.getDevice("camaraFrontal")
        self.front_camera.enable(TIME_STEP)

        self.left_camera = self.robot.getDevice("camaraIzquierda")
        self.left_camera.enable(TIME_STEP)

        self.right_camera = self.robot.getDevice("camaraDerecha")
        self.right_camera.enable(TIME_STEP)

        self.distance_sensor = self.robot.getDevice("distance sensor1")
        self.distance_sensor.enable(TIME_STEP)

        self.receiver = self.robot.getDevice("receiver")
        self.receiver.enable(TIME_STEP)
        self.emitter = self.robot.getDevice("emitter")

        self.is_moving = False
        self.is_lop = False
        self.previous_position = Vector.ZERO
        self.previous_direction = Vector.ZERO
        self.start_pos = None
        self.stuck_counter = 0
        self.step_callbacks = []

        self.start_pos = None
        self._last_time = None
        self.first_dists = {}

        self.is_the_same_position = True
        self.same_position_counter = 0
        self.is_saving_gps_samples = False
        self.max_diff_x = 0
        self.max_diff_y = 0
        
        # utils.log_debug("Robot initialized")
        self.raw_step()

        self.gps_pos = np.array([Vector.ZERO for _ in range(LIMIT_AVERAGE)], dtype=object)

        self.first_update = True
        self.step_counter = 0
        self.is_rotating = True
        self.pos = Vector(0,0)

        #self.odometry = FrontLidarPositioner(init_pos = Vector(0, 0))
        self.odometry = EncoderPositioner(init_pos = Vector(0, 0))

        self.step()
        # utils.log_debug("First step completed")
        raw_start_pos = self.get_absolute_position()
        self.start_pos = utils.get_corrected_position(raw_start_pos, 0.06)
        print(f"Robot start position set to: {self.start_pos}") 

        self.last_absolute_position = self.start_pos

    def set_corrected_position(self, pos, margin):
        pos = utils.get_corrected_position(pos, margin)
        self.odometry.set_position(pos - self.start_pos)

    def raw_step(self):
        self.update_stuck_counter()
        for callback in self.step_callbacks:
            callback()
        return self.robot.step(TIME_STEP) != -1

    def to_dict(self):
        return {
            "position": self.get_position(),
            "rotation": self.get_rotation(),
        }

    def on_step(self, callback):
        self.step_callbacks.append(callback)

    def extract_stack(self):
        call_stack = traceback.extract_stack()
        functions = ""
        idx = 0
        for frame_summary in call_stack[2:-2]:
            if idx > 0:
                functions += "/"
            functions += (frame_summary.name)
            idx += 1

        with open("steps.txt", "a", encoding="utf-8") as f:
            f.write(functions + "\n")

    def step(self):
        self.step_counter += 1
        utils.log_debug(f"Step counter: {self.step_counter}")
        
        if not self.is_saving_gps_samples and self.is_the_same_position:
            self.is_saving_gps_samples = True
        elif self.is_saving_gps_samples and not self.is_the_same_position:
            x = [pos.x for pos in self.gps_pos[:self.same_position_counter]]
            y = [pos.y for pos in self.gps_pos[:self.same_position_counter]]
            self.odometry.set_position(Vector(np.mean(x), np.mean(y)))
            self.is_saving_gps_samples = False
            self.same_position_counter = 0
        
        if self.is_saving_gps_samples and self.same_position_counter < LIMIT_AVERAGE:
            self.gps_pos[self.same_position_counter] = self.gps_relative_position()
            self.same_position_counter += 1

        self.update_odometry()
        if DEBUGGPSOK:
            est = self.get_position()
            real = self.gps_ok_relative_position()
            diff_x = abs(est.x - real.x)
            diff_y = abs(est.y - real.y)
            self.max_diff_x = max(self.max_diff_x, diff_x)
            self.max_diff_y = max(self.max_diff_y, diff_y)
            # print(f"Dif X: {diff_x:.4f}  Y: {diff_y:.4f}  |  Max X: {self.max_diff_x:.4f}  Max Y: {self.max_diff_y:.4f}")
        self.update_stuck_counter()
        for callback in self.step_callbacks:
            callback()
        return self.robot.step(TIME_STEP) != -1

    def update_stuck_counter(self):
        if self.start_pos == None: return
        if not self.is_moving:
            self.stuck_counter = 0
            return

        current_pos = self.get_position()
        vel = current_pos - self.previous_position

        current_dir = self.get_forward_vector()
        vang = current_dir.angle_to(self.previous_direction)

        if vel.length() < 0.0005 and vang < 0.001:
            self.stuck_counter += 1
        else:
            self.stuck_counter = 0

        self.previous_position = current_pos
        self.previous_direction = current_dir

    def is_stuck(self, step_threshold=LIMIT_STEPS):
        return self.stuck_counter > step_threshold

    def delay(self, ms):
        init_time = self.robot.getTime()
        while self.step():
            if (self.robot.getTime() - init_time) * 1000.0 >= ms:
                break

    def set_velocity(self, l, r):
        self.wheel_left.setVelocity(utils.clamp(l, -MAX_VEL, MAX_VEL))
        self.wheel_right.setVelocity(utils.clamp(r, -MAX_VEL, MAX_VEL))
        if l == 0 and r == 0:
            self.stuck_counter = 0
            self.is_moving = False
        else:
            self.is_moving = True

        if l == r:
            self.is_rotating = False
        else:
            self.is_rotating = True

        if (l==-r):
            self.is_the_same_position=True
        else:
            self.is_the_same_position=False
        
    def stop(self):
        self.set_velocity(0, 0)

    def get_lidar_image(self):
        image = self.lidar.getRangeImage()
        distances = image[1024:1536]
        return distances

    def get_lidar_points(self):
        roll, pitch, _ = self.imu.getRollPitchYaw()
        # utils.log_debug("Got roll, pitch, yaw from IMU")
        if abs(roll) > 0.01 or abs(pitch) > 0.01:
            return []

        # utils.log_debug("IMU roll and pitch are within limits, processing LiDAR data")
        distances = self.get_lidar_image()
        # utils.log_debug("Got LiDAR distances (get_lidar_image())")
        current_vector = self.get_forward_vector().get_opposite()
        delta_angle = -(math.pi * 2) / 512
        result = []
        # utils.log_debug("Processing LiDAR points")
        for i in range(0, 512):
            if not distances[i] == float('inf'):
                point = current_vector * distances[i]
                result.append(point)
            current_vector = current_vector.rotated(delta_angle)
        return result
    
    def __update_odometry(self):
        """Actualiza el ICP con el yaw del IMU y el scan LiDAR del step actual."""
        yaw = self.get_rotation()
        # print(f"Current yaw: {yaw} radians")
        result = utils.cardinal_ray_indices(yaw)
        if result == None: return
        f_ray, b_ray, l_ray, r_ray = result
        # print(f"Cardinal ray indices: F: {f_ray}, B: {b_ray}, L: {l_ray}, R: {r_ray}")
        lidar_image = self.get_lidar_image()

        prev_f_ray, foll_f_ray = utils.get_prev_follow_index(f_ray)
        prev_b_ray, foll_b_ray = utils.get_prev_follow_index(b_ray)
        prev_l_ray, foll_l_ray = utils.get_prev_follow_index(l_ray)
        prev_r_ray, foll_r_ray = utils.get_prev_follow_index(r_ray)

        delta_ang = 2 * math.pi / 512

        prev_f_delta = (f_ray - prev_f_ray) * delta_ang
        prev_b_delta = (b_ray - prev_b_ray) * delta_ang
        prev_l_delta = (l_ray - prev_l_ray) * delta_ang
        prev_r_delta = (r_ray - prev_r_ray) * delta_ang

        foll_f_delta = (foll_f_ray - f_ray) * delta_ang
        foll_b_delta = (foll_b_ray - b_ray) * delta_ang
        foll_l_delta = (foll_l_ray - l_ray) * delta_ang
        foll_r_delta = (foll_r_ray - r_ray) * delta_ang

        f_dist = min(math.cos(foll_f_delta) * lidar_image[foll_f_ray], MAX_LIDAR_DIST)
        b_dist = min(math.cos(foll_b_delta) * lidar_image[foll_b_ray], MAX_LIDAR_DIST)
        l_dist = min(math.cos(foll_l_delta) * lidar_image[foll_l_ray], MAX_LIDAR_DIST)
        r_dist = min(math.cos(foll_r_delta) * lidar_image[foll_r_ray], MAX_LIDAR_DIST)

        # f_dist = min(math.cos(prev_f_delta) * lidar_image[prev_f_ray], MAX_LIDAR_DIST)
        # b_dist = min(math.cos(prev_b_delta) * lidar_image[prev_b_ray], MAX_LIDAR_DIST)
        # l_dist = min(math.cos(prev_l_delta) * lidar_image[prev_l_ray], MAX_LIDAR_DIST)
        # r_dist = min(math.cos(prev_r_delta) * lidar_image[prev_r_ray], MAX_LIDAR_DIST)

        if self.first_update:
            self.odometry.set_base_distances(f_dist, b_dist, r_dist, l_dist)
            self.first_update = False

        self.odometry.update(f_dist, b_dist, r_dist, l_dist, yaw, self.pos)
        self.pos = self.odometry.get_position()

    def update_odometry(self):
        # print(f"Updating odometry with pos: {self.get_position()}")
        yaw = self.get_rotation()
        front_ray = 256
        front_dist = min(self.get_lidar_image()[front_ray], 1) # NOTE: Used min function in case lidar dist = inf.
        if self.first_update:
            self.odometry.set_base_distances(front_dist)
            print(f"First update - setting base front distance: {front_dist}")
            self.first_update = False
        # print(f"Updating odometry with front distance: {front_dist} and yaw: {yaw}")    
        self.odometry.set_encoders(self.enc_left.getValue(), self.enc_right.getValue())
        self.odometry.set_gps(self.gps_relative_position())
        self.odometry.update(front_dist, yaw, self.get_position(), self.is_rotating)
        self.pos = self.odometry.get_position()

    def get_position(self):
        """Retorna la posición estimada por ICP + IMU."""
        return self.odometry.get_position() # pos
    
    def gps_relative_position(self):                # NOISY-GPS
        abs_pos = self.get_absolute_position()
        if abs_pos is None or self.start_pos is None:
            return Vector.ZERO
        return abs_pos - self.start_pos
    
    def get_absolute_position(self):
        x, z, y = self.gps.getValues()
        return Vector(x, y)

    def gps_ok_relative_position(self):
        if not DEBUGGPSOK or self.gps_ok is None:
            return Vector.ZERO
        x, z, y = self.gps_ok.getValues()
        abs_pos = Vector(x, y)
        if self.start_pos is None:
            return Vector.ZERO
        return abs_pos - self.start_pos

    def get_rotation(self):
        roll, pitch, yaw = self.imu.getRollPitchYaw()
        return yaw

    def convert_camera(self, img, height, width):
        converted_image = np.array(np.frombuffer(img, np.uint8).reshape((height, width, 4)))
        return converted_image

    def get_camera_from_side(self, side):
        if side == Side.LEFT:
            camera = self.left_camera
        else:
            if side == Side.RIGHT:
                camera = self.right_camera
            else:
                camera = self.front_camera
        return self.convert_camera(camera.getImage(), 40, 40)

    def get_forward_vector(self):
        return Vector.from_angle(self.get_rotation())

    def look_at(self, direction, margin=0.001, *, blocking_steps=-1):
        # print(f"Looking at {direction} with margin {margin} and blocking_steps {blocking_steps}")
        is_done = False
        steps = 0
        while not self.is_stuck() and not self.is_lop:
            angle = self.get_forward_vector().angle_to(direction)
            if abs(angle) < margin:
                is_done = True
                self.stop()
                break

            vel = MAX_VEL / 0.25 * abs(angle)
            if angle < 0:
                self.set_velocity(vel, -vel)
            else:
                self.set_velocity(-vel, vel)

            if blocking_steps == steps:
                break

            if not self.step():
                break

            steps += 1

        return is_done

    def turn(self, angle, margin=0.001, *, blocking_steps=-1):
        # print(f"Robot state: turning!")
        target = self.get_forward_vector().rotated(angle)
        return self.look_at(target, margin, blocking_steps=blocking_steps)

    def advance(self, distance, margin=0.001, *, blocking_steps=-1):
        # print(f"Robot state: advancing!")
        # if self.is_the_same_position:
        #     self.is_the_same_position = False
        #     self.step()
        initial_pos = self.get_position()
        # print(f"Initial pos before advance loop: {initial_pos}")
        is_done = False
        steps = 0
        while not self.is_stuck() and not self.is_lop:
            # print(f"-Current pos: {self.get_position()} Current OK pos: {self.get_relative_position_ok()}")
            # print(f"Is saving gps samples? {self.is_saving_gps_samples} - Is in the same position? {self.is_the_same_position}")
            traveled_dist = self.get_position().distance_to(initial_pos)
            diff = abs(distance) - traveled_dist
            # print(f"Traveled distance: {traveled_dist} - Target distance: {distance} - Diff: {diff}")
            if diff <= margin:
                is_done = True
                self.stop()
                break

            vel = min(max(diff/0.01, 0.1), 1) * MAX_VEL
            if distance < 0: vel *= -1

            self.set_velocity(vel, vel)

            if blocking_steps == steps:
                break
            if not self.step():
                break

            steps += 1

        return is_done

    def __move_to_point(self, target, margin=0.001, *, blocking_steps=-1):
        ANGLE_DEAD_ZONE = math.radians(3)

        is_done = False
        steps = 0
        while not self.is_stuck() and not self.is_lop:
            position = self.get_position()
            dist = position.distance_to(target)

            if dist < margin:
                is_done = True
                self.stop()
                break

            angle = self.get_forward_vector().angle_to(target - position)

            # if abs(angle) < ANGLE_DEAD_ZONE:
            #     angle = 0

            vel = -MAX_VEL/math.radians(15) * abs(angle) + MAX_VEL
            # print(f"Moving to point calculated vel: {utils.clamp(vel, -MAX_VEL, MAX_VEL)}")

            if angle < 0:
                self.set_velocity(MAX_VEL, vel)
            else:
                self.set_velocity(vel, MAX_VEL)
            # else:
            #     self.set_velocity(MAX_VEL, MAX_VEL)

            if blocking_steps == steps:
                break
            if not self.step():
                break

            steps += 1

        return is_done
    
    def move_to_point(self, target, margin=0.001, *, blocking_steps=-1):
        ANGLE_MIN = math.pi / 42

        is_done = False
        steps = 0
        while not self.is_stuck() and not self.is_lop:
            position = self.get_position()
            dist = position.distance_to(target)

            if dist < margin:
                is_done = True
                self.stop()
                break

            angle = self.get_forward_vector().angle_to(target - position)
            # print(f"Angle to target: {math.degrees(angle)} degrees")

            if abs(angle) < ANGLE_MIN:
                self.set_velocity(MAX_VEL, MAX_VEL)
                self.is_rotating = False
            else:
                # Velocidad proporcional al ángulo, con mínimo para que no se detenga
                turn_vel = utils.clamp(abs(angle) / (math.pi / 4) * MAX_VEL, MAX_VEL * 0.3, MAX_VEL)
                if angle < 0:
                    self.set_velocity(turn_vel, -turn_vel)
                else:
                    self.set_velocity(-turn_vel, turn_vel)
                self.is_rotating = True
            # print(f"Is robot rotating? {self.is_rotating}")
            if blocking_steps == steps:
                break
            if not self.step():
                break

            steps += 1

        return is_done
        
    def get_central_pixel(self, camera):
        camera_image = camera.getImage()
        h = camera.getHeight()
        w = camera.getWidth()
        imagenp = np.frombuffer(camera_image, np.uint8).reshape((h, w, 4))

        pixel = imagenp[h // 2, w // 2]
        b, g, r = pixel[0], pixel[1], pixel[2]

        return (b,g,r)