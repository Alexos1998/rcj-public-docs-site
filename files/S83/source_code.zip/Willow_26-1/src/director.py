from robot import Robot, MAX_VEL
from navigation.navigator import Navigator
from tile_classifier import TileClassifier, TileType
from image import ImageProcessor
from lidar import LidarProcessor, Side
from comm import Comm
from comm import MessageType
from mapping.mapper import Mapper
from mapping.map import TILE_SIZE
import math
import cv2
import utils
from visualization.visualizer import Visualizer
from vector import Vector
from collections import deque
from datetime import datetime
import statistics

VICTIMS_SENDING_DIST = 0.052 # Wall distance when analyzing images
COGNITIVE_SENDING_DIST = 0.057
COGNITIVE_ANALYZING_DIST = 0.072
LIMIT_STEPS = 100
POS_SAMPLES = 4

BASE_TESTING_DIST = 0.17508681

ACCURACY = TILE_SIZE/4
ROBOT_RADIUS = 0.035

DEBUGGING_3_CAMS = True

class GameState:
    def __init__(self):
        self.game_score = 0
        self.time_remaining = 10000
        self.real_time_remaining = 10000

class Director:
    def __init__(self, config):
        self.config = config
        self.robot = Robot()
        self.last_robot_pos = self.robot.get_position()
        self.navigator = Navigator()
        self.tile_classifier = TileClassifier()
        self.image_processor = ImageProcessor()
        self.lidar_processor = LidarProcessor()
        self.comm = Comm(self.robot)
        self.game_state = GameState()
        self.mapper=Mapper()
        self.path = None
        self.target_idx = -1
        self.img_counter = 0
        self.current_robot_area = None
        self.last_robot_area = None
        self.visualizer = Visualizer(config)

        self.step_counter = 0
        self.robot.on_step(self.on_step)

        self.detected_signs = {}
        self.pending_signs = []

        self.robot_state = None

        # self.pos_recount = deque(maxlen = POS_SAMPLES)
        # self.average_pos = Vector(0, 0)

        # self.last_front_ray_idx = None

        self.swamps_visits = {}

        self.grid_pos_path = []

    def on_step(self):
        """Director's step, in which key actions are performed without making the robot class 'knowing' the director class,
        in order to mantain our code's architecture (callback algorithm)"""
        self.step_counter += 1
        self.process_messages()

        # print(f"Gps pos diff: {abs(gps_pos.x) - abs(self.last_gps_robot_pos.x):.5f}, {abs(gps_pos.y) - abs(self.last_gps_robot_pos.y):.5f}")
        # print(f"Robot GPS pos: {gps_pos} - Last GPS pos: {self.last_gps_robot_pos}")

        if self.step_counter % 10 == 0:
            self.comm.send_gamescore_and_time_remaining_request()

        if self.step_counter == 1:
            lidar_image = self.robot.get_lidar_image()
            print(f"Initial lidar image 256: {lidar_image[256]:.5f} - 384: {lidar_image[384]:.5f} - 128: {lidar_image[128]:.5f} - 0: {lidar_image[0]:.5f}")
        # print(f"Robot pos: {self.robot.get_position()} before marking position as visited")
        self.navigator.mark_position_as_visited(self.robot.get_position())

        self.visualizer.step()
        self.visualizer.send_robot(self.robot)

        self.update_pending_signs()
        # print(f"Pending signs: {self.pending_signs}")
        # print("-------------------------------------------------------------")

    def __on_step(self): #DEBUG ON_STEP
        return     

    def update_pending_signs(self):
        """Updates our pending_signs list while the robot is navigating, basing on the camera's output."""
        nearby_signs = self.get_nearby_signs()
        for est_sign_pos in nearby_signs:
            if self.get_pending_sign_index(est_sign_pos) == -1:
                self.pending_signs.append(est_sign_pos)
                # print(f"Added pending sign at pos: {est_sign_pos[0]} with analyzing target pos: {est_sign_pos[1]}")

    def get_pending_sign_index(self, sign_pos):
        """With a recieved est. sign pos, we verify if the sign is already in the list or really close to an already detected one, to return its index, 
        or if its not, and the robot detected a new sign."""
        sign_index = 0
        for pending_sign_pos in self.pending_signs:
            if pending_sign_pos[0].distance_to(sign_pos[0]) < 0.0335:
                return sign_index
            sign_index += 1
        return -1
    
    def get_nearby_signs(self):
        """All sign detection/update logic."""
        if DEBUGGING_3_CAMS:
            return self.get_nearby_signs_with_3_cams()
        print("Getting nearby signs with 2 cameras")
        lidar_image = self.robot.get_lidar_image()
        robot_direction = self.robot.get_forward_vector()
        pending_signs_pos = []
        is_cognitive = False
        
        for side in Side:
            if self.lidar_processor.is_wall_at_side(lidar_image, side):
                if self.lidar_processor.is_aligned_to_wall(lidar_image, side, robot_direction):
                    point = self.get_estimated_sign_pos(lidar_image[side.value], side.get_angle())
                    if not self.is_sign_detected(point):
                        if side != Side.RIGHT:
                            image = self.robot.get_camera_from_side(side)
                            if self.image_processor.is_victim(image):
                                is_cognitive = False
                            elif self.image_processor.is_cognitive(image):
                                is_cognitive = True
                            elif self.image_processor.is_image_zoomed_in(image):
                                if not min(lidar_image[side.value - 6:side.value + 6]) <= 0.05: continue
                                is_cognitive = False
                            else:
                                continue
                        else:
                                continue

                        ray_offset = 0 # NOTE (Martu): At first, as we had 3 cameras, we tried to here find the sign as much centered as possible, now,
                        # with the colour sensor, our priority is to unify the logic for all sides, so we do not calculate the center of the sign or the
                        # ray offset for any side. Afterwards, the update cameras uses the front camera to properly center the signs added as pending.
                        token_pos, target_pos = self.get_estimated_analyzing_pos(side, ray_offset, is_cognitive) # Best transitable point for the robot to analyze the sign.
                        if target_pos is None: continue
                        pending_signs_pos.append((token_pos, target_pos, is_cognitive))
        return pending_signs_pos
    
    def get_nearby_signs_with_3_cams(self):
        """All sign detection/update logic."""
        # print("Checking nearby signs with 3 cams...")
        lidar_image = self.robot.get_lidar_image()
        robot_direction = self.robot.get_forward_vector()
        pending_signs_pos = []
        is_cognitive = False
        
        for side in Side:
            if self.lidar_processor.is_wall_at_side(lidar_image, side):
                if self.lidar_processor.is_aligned_to_wall(lidar_image, side, robot_direction):
                    point = self.get_estimated_sign_pos(lidar_image[side.value], side.get_angle())
                    if not self.is_sign_detected(point):
                        image = self.robot.get_camera_from_side(side)
                        if self.image_processor.is_victim(image):
                            is_cognitive = False
                        elif self.image_processor.is_cognitive(image):
                            is_cognitive = True
                        elif self.image_processor.is_image_zoomed_in(image):
                            if not min(lidar_image[side.value - 6: side.value + 6]) <= 0.05: 
                                continue
                            is_cognitive = False
                        else:
                            continue

                        centre = self.image_processor.get_contour_centre(image, is_cognitive)
                        if centre is None: continue
                        ray_offset = self.calculate_lidar_offset(centre - 20, lidar_image, side)
                        # print(f"Detected sign at side {side.name} with ray offset {ray_offset} pixels from the center")
                        token_pos, target_pos = self.get_estimated_analyzing_pos(side, ray_offset, is_cognitive) # Best transitable point for the robot to analyze the sign.
                        if target_pos is None: continue
                        pending_signs_pos.append((token_pos, target_pos, is_cognitive))

        return pending_signs_pos

    def update_visualizer(self):
        self.visualizer.update(self)

    def  __start(self): # DEBUG
        while self.robot.step():
            # max_dist_per_step = 0.002
            # rot = self.robot.get_rotation()
            # print(f"Rotation: {rot}")
            # print(f"Sin(rot): {math.sin(rot) * max_dist_per_step}, Cos(rot): {math.cos(rot) * max_dist_per_step}")
            # self.robot.update_odometry()
            self.robot.set_velocity(0.1*MAX_VEL, 0.1*MAX_VEL)
            self.update_maps()

    def start(self):
        self.current_robot_area = 1
        self.previous_robot_area = 1
        self.mapper.add_tiles({(0,0): TileType.STARTING})
        self.mapper.set_area(self.mapper.get_tile_at_pos((0,0)), self.current_robot_area)
        self.mapper.add_visited_tile(self.mapper.get_tile_at_pos((0,0)))

        while True:
            # print(f"Current robot area: {self.current_robot_area}")
            # print(f"Step: {self.step_counter}")
            robot_pos = self.robot.get_position()
            # print(f"Is robot on vertical border? {utils.point_on_vertical_border(robot_pos)} - Is robot on horizontal border? {utils.point_on_horizontal_border(robot_pos)}")
            abs_pos = self.robot.get_absolute_position()
            utils.log_debug(f"Robot pos: {robot_pos}")
            # utils.log_debug(f"Robot GPS pos: {self.robot.gps_relative_position()}")
            # utils.log_debug(f"Robot rotation: {self.robot.get_rotation()}")

            self.update_maps()
            self.update_visits(robot_pos)
            self.update_path()
            self.update_cameras()
            self.pending_signs = []
            self.update_visualizer()
            self.record(False)

            # If the path is empty, we break out of the loop
            if self.path is not None and len(self.path) == 0:
                self.navigator.map.increase_visit_count((0, 0), 0)
                break

            # If theres no time left, we send an early exit
            if self.game_state.time_remaining <= 10 or self.game_state.real_time_remaining <= 10:
                break

                    # minitiles = self.navigator.map.get_minitiles_from_tile(self.tile_classifier.position_to_grid(target))

            self.move_to_target()

            # Save the robot position at the beginning of the loop in order to
            # mark this point as not traversable in case of LOP
            self.last_robot_pos = robot_pos
            self.robot.last_absolute_position = abs_pos
            # self.last_gps_robot_pos = gps_robot_pos

            if self.robot.is_lop:
                # print(f"LoP detected in main loop!")
                self.robot.set_corrected_position(self.robot.get_absolute_position(), 0.06)
                self.robot.is_lop = False
            
            utils.log_debug("-"*30)

        nav_map_img = self.navigator.map.get_image()
        if nav_map_img is not None:
            cv2.imwrite("nav_map.png", nav_map_img)
            
        self.visualizer.stop()
        final_map = self.mapper.mapping_pixels(self.robot.start_pos)
        self.comm.send_map(final_map)
        self.robot.stop()
        self.robot.delay(5000)
        self.comm.send_exit()


    def move_to_target(self):
        if self.path is None: return
        target = self.path[self.target_idx]
        if not self.robot.move_to_point(target, 0.015, blocking_steps=1): # If the robot did not arrive to dest.
            if self.robot.is_stuck():
                print(f"{self.step_counter} THE ROBOT IS STUCK!")
                self.navigator.mark_position_as_obstructed(target)
                self.robot.stop()
                self.target_idx += 1
                if self.target_idx >= len(self.path):
                    self.path = None
                    self.target_idx = -1
            return

        # If execution reaches this line, we arrived to the target
        self.robot.stop()
        self.navigator.mark_position_as_visited(target)

        self.target_idx += 1
        if self.target_idx >= len(self.path):
            self.path = None
            self.target_idx = -1
        # print(f"Minitiles dict after moving to target: {self.navigator.map.minitiles}")

    def process_messages(self):
        self.robot.is_lop = False
        messages = self.comm.get_messages()
        for message in messages:  #[('G', 12.2, 14, 28), ('L')]
            if message[0] == MessageType.GAME_INFO:
                self.game_state.game_score = message[1]
                self.game_state.time_remaining = message[2]
                self.game_state.real_time_remaining = message[3]
            elif message[0] == MessageType.LOP:
                print(f"LOP detected in process_messages!")
                self.robot.is_lop = True
                self.navigator.mark_lop(self.last_robot_pos)
                self.visualizer.send_debug({"lop": self.last_robot_pos})
                self.path = None
                self.target_idx = -1

    def update_maps(self):
        robot_pos = self.robot.get_position()
        lidar_points = self.robot.get_lidar_points()
        surrounding_tiles = self.tile_classifier.get_surrounding_tiles(self.robot)
        # print(f"Surrounding tiles: {surrounding_tiles}")
        self.mapper.update(robot_pos, lidar_points, surrounding_tiles)
        self.navigator.update(robot_pos, lidar_points, surrounding_tiles)
        # obstacle_average = None
        obstacle_points = self.possible_obstacle(self.robot.lidar)
        if obstacle_points:
            # print(f"Obstacle points detected: {obstacle_points}")
            obstacle_pos = Vector(obstacle_points[0][0], obstacle_points[0][1])
            # print(f"Obstacle position: {obstacle_pos}")
            obstacle_relative = obstacle_pos - self.robot.start_pos
            obstacle_tile = self.tile_classifier.position_to_grid(obstacle_relative)
            # print(f"OBSTACLE GRID TILE: {obstacle_tile}")
            # relative_obstacle_points = [(p[0] - self.robot.start_pos.x, p[1] - self.robot.start_pos.y) for p in obstacle_points]
            # print(f"Obstacle points detected: {obstacle_points}")
            # print("-"*30)
            # amount_of_points = len(obstacle_points)
            # print(f"Obstacle at tile: {self.tile_classifier.position_to_grid(robot_pos)}")
            # self.mapper.add_obstacles([obstacle_points[amount_of_points//2]])

            # self.tile_classifier.position_to_grid(obstacle_average)
            self.mapper.add_obstacles(obstacle_tile)
        
        
        current_grid_pos = self.tile_classifier.position_to_grid(robot_pos)
        # print(f"Current grid pos: {current_grid_pos}")
        is_current_tile_visited = self.mapper.is_tile_in_visited_tiles(current_grid_pos)
        # print(f"Is current tile visited? {is_current_tile_visited}")
        # print(f"Is not current tile visited? {not is_current_tile_visited}")
        current_tile = self.mapper.get_tile_at_pos(current_grid_pos)
        # print(f"Current tile: {current_tile}")
        if len(self.grid_pos_path) == 0 or self.grid_pos_path[-1] != current_grid_pos:
            self.grid_pos_path.append(current_grid_pos)
            # print(f"Current grid pos: {self.grid_pos_path}")

        if not is_current_tile_visited and current_tile is not None:
            if not self.mapper.is_color_passage(current_tile):
                if len(self.mapper.visited_tiles) > 1:
                    idx = -2
                    last_grid_pos_visited = self.grid_pos_path[idx] # NOTE(Martu): The last index of the list is the current tile, we want the one before it.
                    last_added_tile = self.mapper.get_visited_tile_at_pos(last_grid_pos_visited)
                    # print(f"Last visited tile: {last_added_tile} at grid pos {last_grid_pos_visited}")
                    # print(f"Mapper visited tiles: {self.mapper.visited_tiles}")
                    if last_added_tile is None:
                        for visited_grid_pos in self.grid_pos_path[:-1][::-1]: # We iterate the grid pos path backwards, starting from the one before the current tile, to find the last visited tile.
                            """Here we are trying to fix the problem of the tile_classifier do not finding a surrounded tile, which causes the mapper to do not
                            add the tile to the visited tiles, and then, when we find a new tile, we do not have any reference of the area of the last tile to 
                            calculate the new tile's area. This bug raises an error, so now if we do not find any visited tile, we iterate the grid pos path backwards
                            to find the last visited tile, which should be the last tile added to the visited tiles."""
                            idx -= 1
                            last_added_tile = self.mapper.get_visited_tile_at_pos(visited_grid_pos)
                            if last_added_tile is not None:
                                print(f"Found last added tile: {last_added_tile} at grid pos {visited_grid_pos}")
                                break
                    if self.mapper.is_color_passage(last_added_tile):
                        # print(f"Calculating area for tile {current_tile} based on last passage tile {last_added_tile}")
                        last_area_before_passage = self.mapper.get_visited_tile_at_pos(self.grid_pos_path[idx - 1]).area
                        last_area_before_passage = list(self.mapper.visited_tiles[-2].values())[0].area
                        # print(f"Last area before passage: {last_area_before_passage}")
                        area = self.mapper.get_new_area(last_area_before_passage, last_added_tile)
                        current_tile.area = area
                        # print(f"Assigned area {area} to tile {current_tile}")
                    else:
                        current_tile.area = last_added_tile.area
                else:
                    current_tile.area = 1
            else:
                current_tile.area = None

            self.mapper.add_visited_tile(current_tile)
        #     print(f"visited tiles: {self.mapper.visited_tiles}")
        #     print(f"Added visited tile: {current_tile} - Area: {current_tile.area}")
        # # self.current_robot_area = current_tile.area
        # print("----------------------------------------------------------------------------")

    def update_path(self):
        robot_pos = self.robot.get_position()
        target = self.path[self.target_idx] if self.path is not None else None
        if target is None or not self.navigator.is_traversable(target):
            print(f"Target {target} is not traversable anymore, or its None; recalculating path...")
            utils.log_debug(f"Target {target} is not traversable anymore, or its None; recalculating path...")
            if target is not None:
                for i in range(self.target_idx, len(self.path)):
                    print(f"Marking position {self.path[i]} as obstructed")
                    utils.log_debug(f"Marking position {self.path[i]} as obstructed")
                    self.navigator.mark_position_as_obstructed(self.path[i])
            path = self.navigator.find_path(robot_pos)
            self.path = path
            self.target_idx = 0

    def update_visits(self, robot_pos):
        last_minitile_vector = self.navigator.map.world_to_minitile(self.last_robot_pos)
        last_minitile = (last_minitile_vector.x, last_minitile_vector.y)
        actual_minitile_vector = self.navigator.map.world_to_minitile(robot_pos)
        actual_minitile = (actual_minitile_vector.x, actual_minitile_vector.y)
        if last_minitile != actual_minitile:
            if last_minitile in self.swamps_visits:
                # print(F"ya estuve aqui")
                increment = self.swamps_visits[last_minitile] + 1.5
                # self.swamps_visits[last_minitile] = increment
            else:
                increment = 1.5 # recomendado por Claude después de analizar el costo de los swamps, 
            # para que el robot empiece a evitarlos después de 2 visitas (siendo el costo de la visita 8 + 1.5 * visits, y el costo del desvío 24)
            self.swamps_visits[last_minitile] = increment
            self.navigator.map.increase_visit_count(last_minitile, increment)
            # print(f"LAST MINITILE {last_minitile} ------- INCREMENT {increment}")
            

    def calculate_lidar_offset(self, centre_offset, lidar_image, side):
        delta_angle = math.pi * 2 / 512
        total_angle = 27 * delta_angle

        dist_offset = math.tan(total_angle) * lidar_image[side.value]
        dist_offset = (centre_offset * dist_offset) / 20
        # print(f"Dist offset: {dist_offset}")
        offset_angle = math.atan2(dist_offset, lidar_image[side.value])
        # print(f"Offset angle: {offset_angle}")
        # print(f"Delta angle: {delta_angle}")
        rays = math.floor(offset_angle / delta_angle)
        return rays

    def update_cameras(self):
        # return
        while not len(self.pending_signs) == 0:
            pos = self.robot.get_position()
            self.pending_signs.sort(key=lambda x: x[1].distance_to(pos))
            token_point, target_pos, is_cognitive = self.pending_signs[0]
            # print(f"Is cognitive? {is_cognitive}")
            # print(f"Dist between sign pos and its target analyzing pos: {token_point.distance_to(target_pos)}")

            if target_pos.distance_to(pos) > TILE_SIZE: 
                self.pending_signs = []
                return None

            # 1) Move to target pos (given by get_estimated_analyzing_pos)
            self.robot.look_at(target_pos - self.robot.get_position())
            # print(f"Moving to analyzing position at {target_pos}, distance: {target_pos.distance_to(pos)}")
            print(f"Is target pos transitable? {self.navigator.is_traversable(target_pos)}")
            self.robot.advance(self.robot.get_position().distance_to(target_pos), 0.002)
            # self.record()

            # 2) Look at token point (sign's centre)
            self.robot.look_at(token_point - self.robot.get_position(), 0.001)

            # ACAACA! Si es ct, el centrado va a ser: dejar algún borde del cartel a 2px del borde de la imagen.
            self.try_center_sign(analyzing_after_placing = True)
            self.try_approach_sign(is_cognitive)

            self.robot.stop()

            if self.robot.is_lop: 
                """If a lop happens in this point, we stop the analyze, so on the next step, the robot will be able to recover from it.
                Here, the robot will crash"""
                self.pending_signs = []
                return None
            
            # self.record()
            # self.analyze_sign(token_point, is_cognitive = is_cognitive)
            if is_cognitive:
                self.analyze_cognitive_sign()
            else:
                self.analyze_victim_sign()
            self.pending_signs.pop(0)

    def get_angle_to_look_at_sign(self):
        lidar_image = self.robot.get_lidar_image()
        robot_direction = self.robot.get_forward_vector()
        for side in Side:
            if self.lidar_processor.is_wall_at_side(lidar_image, side) and self.lidar_processor.is_aligned_to_wall(lidar_image, side, robot_direction):
                point = self.get_estimated_sign_pos(lidar_image[side.value], side.get_angle())
                if not self.is_sign_detected(point):
                    if self.image_processor.is_image(self.robot.get_camera_from_side(side)):
                        return side.get_angle()
                    else:
                        if min(lidar_image[side.value - 6:side.value + 6]) <= 0.05 and self.image_processor.is_image_zoomed_in(self.robot.get_camera_from_side(side)):
                            return side.get_angle()
        return None

    def get_estimated_sign_pos(self, lidar_dist, target_rot):
        rot = self.robot.get_forward_vector().rotated(target_rot)
        sign_pos = self.robot.get_position() + rot * lidar_dist
        return sign_pos

    def is_sign_detected(self, sign_pos):
        position = self.robot.get_position()
        for key in self.detected_signs.keys():
            dict_sign_pos = key[0]
            dict_robot_pos = key[1]
            # print(f"Distance between signs: {dict_sign_pos.distance_to(sign_pos)}")
            # print(f"Distance between robots: {dict_robot_pos.distance_to(position)}")
            if dict_sign_pos.distance_to(sign_pos) < 0.0335 and dict_robot_pos.distance_to(position) < 0.0335:
                return True
        return False
    
    def possible_obstacle(self, lidar,diff_distance = 0.1, distance = 0.1):
        to_verification = 0
        SMALL_OBSTACLE = False
        CURRENT_OBSTACLE = False
        possible_rays = []
        obstacle_points = []

        distance_sensor = self.robot.distance_sensor.getValue()

        b, g, r = self.robot.get_central_pixel(self.robot.front_camera)
      
        image = lidar.getRangeImage()   
    
        layer1 = image[:512]
        layer4 = image[1537:2048]
        
        frontlayer1 = layer1[256] 
        frontlayer4 = layer4[256] 

        front_lidar = layer4[206:306]
        
        left_zone = front_lidar[:32]
        center_zone = front_lidar[33:67]
        right_zone = front_lidar[67:]   

        total_left = sum(1 for dis in left_zone if dis > diff_distance)
        total_mid = sum(1 for dis in center_zone if dis > diff_distance)
        total_right = sum(1 for dis in right_zone if dis > diff_distance)
        
        if distance_sensor < 0.1:

            if abs(distance_sensor - frontlayer4) > 0.05:
                # print("A SMALL OBSTALCE")
                SMALL_OBSTACLE = True
            elif frontlayer4 > 0.045:
                if abs(distance_sensor - frontlayer1) < 1: 
                    CURRENT_OBSTACLE = True
        

        if frontlayer4 < 0.08:
            if (total_mid < 6) and (total_left > 5) and (total_right > 5):
        
                for i in range(len(front_lidar)):
                    actual_distance = front_lidar[i]
                    if actual_distance < distance:
                        index = (i + 206)
                        actual_angle = index * (360.0 / 512.0)  
                        possible_rays.append([actual_distance, actual_angle])
                CURRENT_OBSTACLE = True


        yaw = self.robot.get_rotation()
        robot_pos = self.robot.get_position() + self.robot.start_pos
        robot_direction = self.robot.get_forward_vector()

        print(f"SMALL OBSTACLE {SMALL_OBSTACLE}")
        print(f"CURRENT OBSTACLE: {CURRENT_OBSTACLE}")

        if SMALL_OBSTACLE and not CURRENT_OBSTACLE:
            if self.image_processor.is_exclude_color(b, g, r):
                return None
            # if r == 0: # POSSIBLE COMPARATION
            # print(f"Obstaculo chico")
            calculated_distance = (0.201 * distance_sensor + 0.030)
            obstacle_pos = robot_pos + robot_direction * calculated_distance
            x_final = obstacle_pos.x
            z_final = obstacle_pos.y
            # print(f"LIDAR VALUE: {frontlayer4} --- CALCULATED VALUE: {calculated_distance}")
            # print(f"Calculated final obstacle position with distance sensor: {x_final}, {z_final} --- A low obstacle...")

        elif (CURRENT_OBSTACLE or SMALL_OBSTACLE) and len(possible_rays) > 0:
            if self.image_processor.is_exclude_color(b, g, r):
                return None
            # print(f"Obtaculo chico? {SMALL_OBSTACLE}   Obstaculo Grande {CURRENT_OBSTACLE}")
            number_of_rays = len(possible_rays)
            # print(f"numero de rayos  {number_of_rays}")
            center = number_of_rays // 2
            # print(f"centro {center}")
            raw_distance_to_obstacle = possible_rays[center][0] 
            # print(f"raw distance {raw_distance_to_obstacle}")
            ray_angle = possible_rays[center][1]
            # print(f"angulo del rayo {ray_angle}")
            x_robot = robot_pos.x
            z_robot = robot_pos.y
            
            angle_rad = math.radians(ray_angle - 180.0)

            x_obstacle = raw_distance_to_obstacle * math.sin(angle_rad)
            z_obstacle = raw_distance_to_obstacle * math.cos(angle_rad)

            x_final = x_robot + (x_obstacle * math.cos(yaw) - z_obstacle * math.sin(yaw))
            z_final = z_robot - (x_obstacle * math.sin(yaw) + z_obstacle * math.cos(yaw))
            
            # print(f"Calculated final obstacle position with lidar: ({x_final}, {z_final} --- A normal obstacle...")
        else:
            return False

        final_point = (x_final, z_final)
        obstacle_points.append(final_point)
        return obstacle_points

    def try_center_sign(self, min_tol = 18, max_tol = 21, analyzing_after_placing = False):
        # print(f"Intentando centrar en step {self.step_counter}")
        steps = 0
        while not self.robot.is_stuck() and not self.robot.is_lop:
            # print(f"Step {steps}")
            img = self.robot.get_camera_from_side(Side.FRONT)
            centre = self.image_processor.get_contour_centre(img, analyzing_after_placing)
            if steps >= LIMIT_STEPS:
                # print(f"Could not center sign after {steps} steps, breaking.")
                break

            if centre is None: break
            centre = round(centre, 4)
            # print(f"Contour centre: {centre}")
            vel = 6.28/12
            if centre > max_tol:
                self.robot.set_velocity(vel, -vel)
            elif centre < min_tol:
                self.robot.set_velocity(-vel, vel)
            else:
                break

            if not self.robot.step():
                # print(f"Robot is stuck while trying to center sign, breaking.")
                break

            steps += 1

        self.robot.stop()

    def move_and_centre(self, distance, margin=0.001, *, blocking_steps=-1):
        initial_pos = self.robot.get_position()

        is_done = False
        steps = 0
        while not self.robot.is_stuck() and not self.robot.is_lop:
            self.try_center_sign()

            traveled_dist = self.robot.get_position().distance_to(initial_pos)
            diff = abs(distance) - traveled_dist
            print(f"Diff of move and centre: {diff}")
            if diff <= margin:
                is_done = True
                self.robot.stop()
                break

            vel = min(max(diff/0.01, 0.1), 1) * 6.28
            if distance < 0: vel *= -1

            self.robot.set_velocity(vel, vel)

            if blocking_steps == steps:
                break
            if not self.robot.step():
                break

            steps += 1

        return is_done

    def get_estimated_analyzing_pos(self, side, ray_offset, is_cognitive=False):
        """Calculates the most accurate analyzing position for the robot based on the estimated sign position."""
        central_ray = side.value
        delta_ang = -math.pi*2/512
        target_rot = side.get_angle() + ray_offset*delta_ang

        dist_a = self.robot.get_lidar_image()[central_ray + ray_offset]
        # dist_a = 0.12
        dist_b = self.robot.get_lidar_image()[central_ray + ray_offset + 2]
        # print(f"dist_a: {dist_a}, dist_b: {dist_b}")

        direction = self.robot.get_forward_vector().rotated(target_rot)
        # print(f"Direction: {direction}, delta_ang: {delta_ang}")
        a = self.robot.get_position() + (direction * dist_a)
        b = self.robot.get_position() + (direction * dist_b).rotated(delta_ang * 2)

        # print(f"b: {b}, a: {a}")
        if not is_cognitive:
            c = (b - a).normalized() * VICTIMS_SENDING_DIST
        else:
            c = (b - a).normalized() * COGNITIVE_SENDING_DIST
        c = c.rotated(-math.pi/2)
        c += a

        target = self.navigator.find_closest_traversable_point(c, self.robot.get_position(), True)
        if target is not None and self.get_pending_sign_index((a, target)) == -1:
            self.visualizer.send_debug({"a": a,
                            "b": b,
                            "t": target})

        if not abs(target.distance_to(a)) > 0.09:
            return a, target
        return None, None

    def try_approach_sign(self, is_cognitive=False):
        # is_cognitive = self.image_processor.is_cognitive(self.robot.get_camera_from_side(Side.FRONT))
        # is_victim = self.image_processor.is_victim(self.robot.get_camera_from_side(Side.FRONT))
        # front_tol = None
        # print(f"Approaching sign, is cognitive: {is_cognitive}, is victim: {is_victim}")
        # if is_victim:
        #     front_tol = (min(self.robot.get_lidar_image()[240: 282]) - VICTIMS_SENDING_DIST)
        # elif is_cognitive:
        #     front_tol = (min(self.robot.get_lidar_image()[240: 282]) - COGNITIVE_ANALYZING_DIST)
        front_tol = None
        if is_cognitive:
            front_tol = (min(self.robot.get_lidar_image()[240: 282]) - COGNITIVE_ANALYZING_DIST)
        else:
            front_tol = (min(self.robot.get_lidar_image()[240: 282]) - VICTIMS_SENDING_DIST)
        if front_tol is not None:
            self.move_and_centre(front_tol, 0.002, blocking_steps = LIMIT_STEPS)

    def analyze_victim_sign(self):
        token = None
        if False: # self.robot.is_fake_sign():
            print(f"Fake sign detected!")
            token = 'Z' # Just as the fake cognitive signs values...
        else:
            # print(f"Analyzing victim dist: {min(self.robot.get_lidar_image()[240: 272])}")
            if min(self.robot.get_lidar_image()[240: 272]) < 0.04:
                token = self.image_processor.analyze_zoomed_image(self.robot.get_camera_from_side(Side.FRONT), self.robot.get_position(), self.robot.get_forward_vector())
            else:
                # print(f"Analyzing victim sign!")
                token = self.image_processor.analyze_image(self.robot.get_camera_from_side(Side.FRONT), self.robot.get_position(), self.robot.get_forward_vector())
        if token is not None:
            print(f"Victim token: {token}")
            token_pos = self.sending_and_mapping_sign(token)
            print("-"*60)
            return token_pos
        
    def analyze_cognitive_sign(self):
        token = None
        # print(f"Analyzing cognitive sign!")
        self.try_center_sign(min_tol = 19, max_tol = 20)
        token = self.image_processor.analyze_image(self.robot.get_camera_from_side(Side.FRONT), self.robot.get_position(), self.robot.get_forward_vector())
        if min(self.robot.get_lidar_image()[240: 272]) >= 0.06:
            self.robot.advance(min(self.robot.get_lidar_image()[240: 272]) - COGNITIVE_SENDING_DIST, 0.002)
        if token is not None:
            print(f"Cognitive token: {token}")
            token_pos = self.sending_and_mapping_sign(token)
            print("-"*60)
            return token_pos
    
    def sending_and_mapping_sign(self, token):
        # print(f"Sending and mapping sign: {token}")
        robot_direction = self.robot.get_forward_vector()
        absolute_pos = self.robot.get_absolute_position() # TODO: Revise! This is not OK... We never "fix" the absolute position
        relative_pos = self.robot.get_position()
        dist = self.robot.get_lidar_image()[256]
        absolute_token_pos = absolute_pos + robot_direction * dist
        relative_token_pos = relative_pos + robot_direction * dist
        # self.send_voc_message(token, pos)
        if token != 'Z' and token != 'X': # If the token is not a fake sign (victim/cognitive) and a obstacle.
            self.send_voc_message(token, absolute_token_pos)
            if not self.current_robot_area == 4:
                self.mapper.add_sign(token, absolute_token_pos, self.tile_classifier.position_to_grid(relative_token_pos))
        self.detected_signs[(relative_token_pos, relative_pos)] = token
        return relative_token_pos

    def send_voc_message(self, input, pos):
        self.robot.stop()
        self.robot.delay(1500)
        self.comm.send_token(int(pos.x * 100), int(pos.y * 100), input)
        self.robot.delay(100)

    def record(self, special_case = False, camera = None): # JUST FOR TESTING!
        if not self.config.get("record_enabled", False): return
        if not special_case:
            cv2.imwrite(f"CI{str(self.step_counter).rjust(4, '0')}.png", self.robot.get_camera_from_side(Side.LEFT))
            cv2.imwrite(f"CF{str(self.step_counter).rjust(4, '0')}.png", self.robot.get_camera_from_side(Side.FRONT))
        elif special_case and camera is not None:
            if camera == "left":
                cv2.imwrite(f"IMG LEFT{str(self.step_counter).rjust(4, '0')}.png", self.robot.get_camera_from_side(Side.LEFT))
            elif camera == "front":
                cv2.imwrite(f"IMG FRONT{str(self.step_counter).rjust(4, '0')}.png", self.robot.get_camera_from_side(Side.FRONT))
        else:
            cv2.imwrite(f"special left{str(self.step_counter).rjust(4, '0')}.png", self.robot.get_camera_from_side(Side.LEFT))
            cv2.imwrite(f"special front{str(self.step_counter).rjust(4, '0')}.png", self.robot.get_camera_from_side(Side.FRONT))