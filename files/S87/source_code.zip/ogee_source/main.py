from controller import Robot
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import math
import numpy as np
import cv2 
import heapq  # Replaced deque with heapq for Dijkstra

COLOR_MAP = np.array([
    [25, 25, 25],  # 0 -> White
    [64, 64, 64],   # 1 -> Light Blue (BGR: 65, 212, 255)
    [0, 0, 128],   # 2 -> Yellow (BGR: 255, 214, 69)
    [0, 0, 255]       # 3 -> Red
], dtype=np.uint8)

BASE_DIRECTIONS = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]

def find_exploration_path_dijkstra(start, hitbox, visited, current_heading, rotation_weight=20.0):
    global robot_x, robot_y, heading, rightDistance, leftDistance, start_grid, start_grid_x, start_grid_y
    if not (0 <= start[0] < hitbox.shape[1] and 0 <= start[1] < hitbox.shape[0]):
        return []

    # Queue stores: (cumulative_cost, x, y, prev_dx, prev_dy)
    queue = [(0.0, start[0], start[1], 0, 0)]
    costs = {start: 0.0}
    parent = {} 
    candidates = []
    MAX_CANDIDATES = 10 

    while queue:
        current_cost, cx, cy, pdx, pdy = heapq.heappop(queue)

        # Skip if we already found a cheaper path to this node
        if current_cost > costs.get((cx, cy), float('inf')):
            continue

        if visited[cy, cx] == 0:
            if (cx, cy) not in candidates:
                candidates.append((cx, cy))
            if len(candidates) >= MAX_CANDIDATES:
                break
            continue # dont bfs from unvisiteds

        for dx, dy in BASE_DIRECTIONS:
            nx, ny = cx + dx, cy + dy
            if 0 <= nx < hitbox.shape[1] and 0 <= ny < hitbox.shape[0]:
                if hitbox[ny, nx] == 0:

                    if dx != 0 and dy != 0:
                        if hitbox[cy + dy, cx] != 0 or hitbox[cy, cx + dx] != 0:
                            continue
                    
                    # 1. Base distance cost (1.0 straight, 1.41 diagonal)
                    move_cost = 1.41 if (dx != 0 and dy != 0) else 1.0
                    
                    # 2. Turn penalty (5.0 if direction changes)
                    turn_penalty = 0.0
                    if (pdx, pdy) != (0, 0) and (dx, dy) != (pdx, pdy):
                        turn_penalty = 5.0
                        
                    new_cost = current_cost + move_cost + turn_penalty
                    
                    if new_cost < costs.get((nx, ny), float('inf')):
                        costs[(nx, ny)] = new_cost
                        parent[(nx, ny)] = (cx, cy)
                        heapq.heappush(queue, (new_cost, nx, ny, dx, dy))

    if not candidates:
        return []

    best_path = []
    best_score = float('inf')

    for target in candidates:
        path = []
        curr = target
        while curr != start:
            path.append(curr)
            curr = parent[curr]
        path.append(start)
        path.reverse()

        path_len_cost = costs[target] # Use Dijkstra cost instead of pure length
        if len(path) > 1:
            lookahead_node = min(3, len(path) - 1)
            dx = path[lookahead_node][0] - start[0]
            dy = path[lookahead_node][1] - start[1]
            initial_path_heading = math.atan2(dy, dx)
            
            angle_diff = initial_path_heading - current_heading
            angle_diff = (angle_diff + math.pi) % (2 * math.pi) - math.pi
            
            score = path_len_cost + (rotation_weight * abs(angle_diff))
        else:
            score = path_len_cost

        if score < best_score:
            best_score = score
            best_path = path

    return best_path


def find_path_to_target_dijkstra(start, target, hitbox):
    global robot_x, robot_y, heading, rightDistance, leftDistance, start_grid, start_grid_x, start_grid_y
    if start == target:
        return [start]
    if not (0 <= start[0] < hitbox.shape[1] and 0 <= start[1] < hitbox.shape[0]):
        return []

    queue = [(0.0, start[0], start[1], 0, 0)]
    costs = {start: 0.0}
    parent = {}
    found = False

    while queue:
        current_cost, cx, cy, pdx, pdy = heapq.heappop(queue)

        if (cx, cy) == target:
            found = True
            break

        if current_cost > costs.get((cx, cy), float('inf')):
            continue

        for dx, dy in BASE_DIRECTIONS:
            nx, ny = cx + dx, cy + dy
            if 0 <= nx < hitbox.shape[1] and 0 <= ny < hitbox.shape[0]:
                if hitbox[ny, nx] == 0:

                    if dx != 0 and dy != 0:
                        if hitbox[cy + dy, cx] != 0 or hitbox[cy, cx + dx] != 0:
                            continue

                    # 1. Base distance cost
                    move_cost = 1.41 if (dx != 0 and dy != 0) else 1.0
                    
                    # 2. Turn penalty
                    turn_penalty = 0.0
                    if (pdx, pdy) != (0, 0) and (dx, dy) != (pdx, pdy):
                        turn_penalty = 5.0
                        
                    new_cost = current_cost + move_cost + turn_penalty
                    
                    if new_cost < costs.get((nx, ny), float('inf')):
                        costs[(nx, ny)] = new_cost
                        parent[(nx, ny)] = (cx, cy)
                        heapq.heappush(queue, (new_cost, nx, ny, dx, dy))

    if not found:
        return []

    path = []
    curr = target
    while curr != start:
        path.append(curr)
        curr = parent.get(curr)
        if curr is None: 
            break
    path.append(start)
    path.reverse()
    return path

def fix_angle(angle):
    return (angle + math.pi) % (math.pi * 2) - math.pi

def is_meaningful_arc(binary_mask, box_diagonal, max_error=0.15):
    # 1. Extract the outermost contour of the blob
    contours, _ = cv2.findContours(binary_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not contours:
        return False
        
    contour = max(contours, key=cv2.contourArea).reshape(-1, 2)
    if len(contour) < 10:
        return False
        
    x = contour[:, 0]
    y = contour[:, 1]
    
    # 2. Least Squares Circle Fit (Kasa Method)
    X_mat = np.column_stack((x, y, np.ones_like(x)))
    Z = x**2 + y**2
    
    try:
        coeffs, _, _, _ = np.linalg.lstsq(X_mat, Z, rcond=None)
        A, B, C = coeffs[0], coeffs[1], coeffs[2]
        xc, yc = A / 2.0, B / 2.0
        R = np.sqrt(max(0, C + xc**2 + yc**2))
    except:
        return False
        
    if R > box_diagonal * 3 or R == 0:
        return False
        
    dists = np.sqrt((x - xc)**2 + (y - yc)**2)
    std_dev = np.std(dists)
    
    error_ratio = std_dev / R
    
    return error_ratio < max_error

def detect_cognitive(camera):
    raw_image = camera.getImage()
        
    frame = np.frombuffer(raw_image, np.uint8).reshape((camera.getHeight(), camera.getWidth(), 4))
    frame_bgr = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
    hsv = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HSV)
    debug_frame = frame_bgr.copy()
    
    # 1. Generate the Master Color Mask
    h, s, v = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]
    vibrant = (s >= 190) & (v >= 190)
    
    masks = {
        "Black":  (v < 25),
        "White":  (v >= 200) & (s < 25),
        "Red":    vibrant & ((h < 10) | (h > 165)),
        "Yellow": vibrant & ((h >= 15) & (h < 35)),
        "Green":  vibrant & ((h >= 45) & (h < 85)),
        "Blue":   vibrant & ((h >= 100) & (h < 140))
    }
    
    target_mask = (masks["Black"] | masks["Red"] | masks["Yellow"] | masks["Green"] | masks["Blue"]).astype(np.uint8) * 255
    
    # 2. Find the main target clusters
    num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(target_mask)
    for label in range(1, num_labels):
        if stats[label, cv2.CC_STAT_AREA] < 30: 
            continue
            
        bx, by, bw, bh = stats[label, cv2.CC_STAT_LEFT], stats[label, cv2.CC_STAT_TOP], stats[label, cv2.CC_STAT_WIDTH], stats[label, cv2.CC_STAT_HEIGHT]
        
        # Isolate the entire master blob for this target
        cluster_mask = (labels == label).astype(np.uint8) * 255
        cluster_diag = np.hypot(bw, bh)
        
        if not is_meaningful_arc(cluster_mask, cluster_diag, max_error=0.20):
            continue
        
        detected_layers = []
        
        # 3. Process every color inside this geometrically-validated target cluster
        for color_name, color_boolean_mask in masks.items():
            specific_color_mask = ((labels == label) & color_boolean_mask).astype(np.uint8) * 255
            sub_num, sub_labels, sub_stats, _ = cv2.connectedComponentsWithStats(specific_color_mask)
            
            for sub_label in range(1, sub_num):
                sub_area = sub_stats[sub_label, cv2.CC_STAT_AREA]
                if sub_area < 5: 
                    continue
                    
                # A: Diagonal Span
                sw, sh = sub_stats[sub_label, cv2.CC_STAT_WIDTH], sub_stats[sub_label, cv2.CC_STAT_HEIGHT]
                diag_span = np.hypot(sw, sh)
                
                # B: Distance Transform 
                sub_isolated = (sub_labels == sub_label).astype(np.uint8) * 255
                dt = cv2.distanceTransform(sub_isolated, cv2.DIST_L2, 3)
                max_dt = np.max(dt)
                layer_thickness = max_dt * 2 
                
                detected_layers.append({
                    "color": color_name,
                    "diag": diag_span,
                    "thickness": layer_thickness,
                    "pixels": sub_area,
                    "box": (sub_stats[sub_label, cv2.CC_STAT_LEFT], sub_stats[sub_label, cv2.CC_STAT_TOP], sw, sh)
                })
        
        # 4. HIERARCHICAL SORTING: Sort by diagonal span
        detected_layers.sort(key=lambda layer: layer["diag"])
        
        # 5. PREDICTION ENGINE: Global 5-Ring Apportionment        
        if len(detected_layers) > 0:
            
            # Identify the Bullseye and normalize its metric
            inner = detected_layers[0]
            inner["is_bullseye"] = (inner["thickness"] / inner["diag"]) > 0.45
            
            # A full circle's max distance transform calculates its full radius. 
            # A ring's max distance transform calculates half its width.
            # We halve the bullseye's thickness score so it compares fairly 1:1 against a single ring.
            if inner["is_bullseye"]:
                inner["weight"] = inner["thickness"] / 2.0
            else:
                inner["weight"] = inner["thickness"]
                
            for i in range(1, len(detected_layers)):
                detected_layers[i]["is_bullseye"] = False
                detected_layers[i]["weight"] = detected_layers[i]["thickness"]

            if len(detected_layers) > 5:
                detected_layers = detected_layers[:5]

            for layer in detected_layers:
                layer["count"] = 1
                
            rings_to_distribute = 5 - len(detected_layers)
            
            for _ in range(rings_to_distribute):
                target_layer = max(detected_layers, key=lambda l: l["weight"] / l["count"])
                target_layer["count"] += 1
                
            # Construct the final sequence
            final_sequence = []
            print(f"\n--- Target Hierarchy Map (5-Ring Enforced) ---")
            
            y_offset = by
            for rank, layer in enumerate(detected_layers):
                c = layer["color"]
                count = layer["count"]
                lbx, lby, lbw, lbh = layer["box"]
                
                # Append the color to the sequence 'count' times
                for _ in range(count):
                    final_sequence.append(c)
                    
                print(f" Layer {rank+1} -> Color: {c:<7} | Weight: {layer['weight']:.1f} | Assigned: x{count}")
                
                # Visual Debugging
                cv2.rectangle(debug_frame, (lbx, lby), (lbx + lbw, lby + lbh), (0, 255, 255), 1)
                cv2.putText(debug_frame, f"{rank+1}:{c[0]}(x{count})", (lbx - 15, y_offset), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)
                y_offset += 10

            print(f" FINAL SEQUENCE: {final_sequence}")

            # Draw outer target bounding box
            cv2.rectangle(debug_frame, (bx, by), (bx + bw, by + bh), (0, 255, 0), 1)

def detect_victim(camera):
    raw_image = camera.getImage()
        
    frame = np.frombuffer(raw_image, np.uint8).reshape((camera.getHeight(), camera.getWidth(), 4))
    frame_bgr = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
    hsv = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HSV)
    debug_frame = frame_bgr.copy()
    
    # 1. Generate the Master Color Mask
    h, s, v = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]
    vibrant = (s >= 190) & (v >= 190)
    
    masks = {
        "Black":  (v < 25),
        "White":  (v >= 200) & (s < 25),
        "Red":    vibrant & ((h < 10) | (h > 165)),
        "Yellow": vibrant & ((h >= 15) & (h < 35)),
        "Green":  vibrant & ((h >= 45) & (h < 85)),
        "Blue":   vibrant & ((h >= 100) & (h < 140))
    }
    
    victim_mask = (masks["Black"] | masks["White"]).astype(np.uint8) * 255
    num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(victim_mask)

    for label in range(1, num_labels):
        if stats[label, cv2.CC_STAT_AREA] < 250: 
            continue
            
        bx, by, bw, bh = stats[label, cv2.CC_STAT_LEFT], stats[label, cv2.CC_STAT_TOP], stats[label, cv2.CC_STAT_WIDTH], stats[label, cv2.CC_STAT_HEIGHT]
        #cx, cy = int(centroids[label][0]), int(centroids[label][1])

        if bw / bh > 1.25 or bh / bw > 1.25:
            print("too cropped")
            continue

        hit_left = bx == 0
        hit_top = by == 0
        hit_right = bx + bw == 40
        hit_bottom = by + bh == 40

        true_width = (not hit_left) and (not hit_right)
        true_height = (not hit_top) and (not hit_bottom)

        if true_width and true_height:
            cx = bx + bw // 2
            cy = by + bh // 2
        elif true_width:
            cx = bx + bw // 2
            if hit_bottom:
                cy = by + bw // 2
            else:
                cy = by + bh - bw // 2
        elif true_height:
            cy = by + bh // 2
            if hit_right:
                cx = bx + bh // 2
            else:
                cx = bx + bw - bh // 2
        else:
            cx = bx + bw // 2
            cy = by + bh // 2
            #print("center the victim and try again")
            #continue
        
        # Calculate radius (1/3 of the component's smaller dimension)
        radius = int(stats[label, cv2.CC_STAT_AREA] ** 0.5 / 4.5)
        
        # 2. Extract the local ROI for the white mask
        white_roi = masks["White"][by:by+bh, bx:bx+bw].astype(np.uint8) * 255
        
        # 3. Create the circular mask relative to local ROI coordinates
        local_cx = cx - bx
        local_cy = cy - by
        
        circle_mask = np.zeros_like(white_roi)
        cv2.circle(circle_mask, (local_cx, local_cy), radius, 255, -1) # -1 fills the circle completely
        
        # 4. Crop the white mask down to *only* what is inside the circle
        circular_white_roi = cv2.bitwise_and(white_roi, circle_mask)
        
        # 5. RENDER THE CIRCLE MASK IN THE RIGHT PLACE ON THE DEBUG WINDOW
        # Create a 3-channel version of the circular white ROI to match the debug BGR frame
        colored_circle_roi = cv2.merge([circular_white_roi, circular_white_roi, circular_white_roi])
        
        colored_circle_roi[circular_white_roi > 0] = [0, 255, 0] 
        
        # Blend or directly paste it over the debug frame inside the bounding box
        # Only overwrite pixels where the circle mask is active to keep the background visible
        roi_debug_area = debug_frame[by:by+bh, bx:bx+bw]
        roi_debug_area[circle_mask > 0] = cv2.bitwise_or(
            cv2.bitwise_and(roi_debug_area, roi_debug_area, mask=cv2.bitwise_not(circle_mask)),
            colored_circle_roi, mask=circle_mask
        )[circle_mask > 0]
        
        mask_overlay = debug_frame.copy()
        cv2.circle(mask_overlay, (cx, cy), radius, (0, 255, 255), -1) # Solid yellow zone
        cv2.addWeighted(mask_overlay, 0.3, debug_frame, 0.7, 0, dst=debug_frame) # 30% opacity overlay
        
        # 6. Count the unique components inside that circular zone using 4-way connectivity
        w_num, w_labels, w_stats, _ = cv2.connectedComponentsWithStats(circular_white_roi, connectivity=4)
        
        white_component_count = 0
        for w_label in range(1, w_num):
            if w_stats[w_label, cv2.CC_STAT_AREA] >= 1: # Ignore single pixel noise
                white_component_count += 1

        letters = "XΩΦXΨXXXXXXXXXXXXXXXX"   
        print(f"White Comps {white_component_count}, Identified Victim: {letters[white_component_count]}")
        
        if white_component_count == 1:
            return 0
        if white_component_count == 2:
            return 1
        if white_component_count == 4:
            return 2
        return -1

def update_path():
    global grid_path, robot_x, robot_y, heading, rightDistance, leftDistance, start_grid, start_grid_x, start_grid_y, current_target
    if current_target:
        tx, ty = current_target
        if visited_grid[ty, tx] != 0 or hitbox_grid[ty, tx] != 0:
            current_target = None
            
    best_new_path = find_exploration_path_dijkstra(start_grid, hitbox_grid, visited_grid, heading, ROTATION_WEIGHT)
    
    if not current_target:
        if best_new_path:
            current_target = best_new_path[-1]
            grid_path = best_new_path
        else:
            grid_path = []
    else:
        current_path = find_path_to_target_dijkstra(start_grid, current_target, hitbox_grid)
        if not current_path:
            if best_new_path:
                current_target = best_new_path[-1]
                grid_path = best_new_path
            else:
                current_target = None
                grid_path = []
        else:
            dist_current = len(current_path)
            dist_new = len(best_new_path) if best_new_path else float('inf')
            
            if dist_new < (dist_current - SIGNIFICANCE_THRESHOLD_CELLS):
                current_target = best_new_path[-1]
                grid_path = best_new_path
            else:
                grid_path = current_path

def follow_path(grid_path):
    global robot_x, robot_y, heading, rightDistance, leftDistance, start_grid, start_grid_x, start_grid_y
    lookahead_idx = min(4, len(grid_path) - 1)
    target_grid_x, target_grid_y = grid_path[lookahead_idx]
    
    target_x = (target_grid_x - ORIGIN_X) * GRID_RESOLUTION
    target_y = (target_grid_y - ORIGIN_Y) * GRID_RESOLUTION
    
    dx = target_x - robot_x
    dy = target_y - robot_y
    target_heading = math.atan2(dy, dx)
    
    angle_diff = target_heading - heading
    angle_diff = (angle_diff + math.pi) % (2 * math.pi) - math.pi  
    
    MAX_SPEED = 6.28
    if abs(angle_diff) > 0.4:
        v = angle_diff * 4.0
        v_left, v_right = -v, v
    else:
        base_forward_speed = 4.0
        steering_gain = 3.0
        v_left = base_forward_speed - (steering_gain * angle_diff)
        v_right = base_forward_speed + (steering_gain * angle_diff)
        
    wheel1.setVelocity(max(-MAX_SPEED, min(MAX_SPEED, v_left)))
    wheel2.setVelocity(max(-MAX_SPEED, min(MAX_SPEED, v_right)))
                
robot = Robot()
timestep = int(robot.getBasicTimeStep())

camera1 = robot.getDevice('camera1')
camera1.enable(timestep)
camera2 = robot.getDevice('camera2')
camera2.enable(timestep)
camera3 = robot.getDevice('camera3')
camera3.enable(timestep)

lidar = robot.getDevice('lidar')
lidar.enable(timestep)
lidar.enablePointCloud() 
max_range = lidar.getMaxRange()

gps = robot.getDevice('gps')
gps.enable(timestep)

imu = robot.getDevice('inertial_unit') 
imu.enable(timestep)

GRID_RESOLUTION = 0.005
MAP_WIDTH_METER = 1.5 
MAP_HEIGHT_METER = 1.5

GRID_WIDTH = int(MAP_WIDTH_METER / GRID_RESOLUTION)
GRID_HEIGHT = int(MAP_HEIGHT_METER / GRID_RESOLUTION)

occupancy_grid = np.zeros((GRID_HEIGHT, GRID_WIDTH), dtype=np.uint8)
hitbox_grid = np.zeros((GRID_HEIGHT, GRID_WIDTH), dtype=np.uint8)
visited_grid = np.zeros((GRID_HEIGHT, GRID_WIDTH), dtype=np.uint8)

ORIGIN_X = GRID_WIDTH // 2
ORIGIN_Y = GRID_HEIGHT // 2

# --- HITBOX INFLATION PARAMETERS ---
R = 0.025
R_cells = int(R / GRID_RESOLUTION)
y_idx, x_idx = np.ogrid[-R_cells:R_cells+1, -R_cells:R_cells+1]
circle_mask = (x_idx**2 + y_idx**2 <= R_cells**2).astype(np.uint8)

# --- HOLE INFLATION PARAMETERS ---
R_hole = 0.02
R_hole_cells = int(R_hole / GRID_RESOLUTION)
y_hidx, x_hidx = np.ogrid[-R_hole_cells:R_hole_cells+1, -R_hole_cells:R_hole_cells+1]
circle_mask_hole = (x_hidx**2 + y_hidx**2 <= R_hole_cells**2).astype(np.uint8)

# --- ROBOT COVERAGE PATH CONFIGURATION ---
R_visit = 0.02
R_visit_cells = int(R_visit / GRID_RESOLUTION)
y_vidx, x_vidx = np.ogrid[-R_visit_cells:R_visit_cells+1, -R_visit_cells:R_visit_cells+1]
circle_mask_visit = (x_vidx**2 + y_vidx**2 <= R_visit_cells**2).astype(np.uint8)

wheel1 = robot.getDevice("wheel1 motor")
wheel2 = robot.getDevice("wheel2 motor")
wheel1.setPosition(float("inf"))
wheel2.setPosition(float("inf"))
wheel1.setVelocity(0.0)
wheel2.setVelocity(0.0)

guncelleme_sayaci = 0
grid_path = []

targets = set()

current_target = None
SIGNIFICANCE_THRESHOLD_CELLS = 30  
ROTATION_WEIGHT = 0  

u_rob, v_rob = 0.0, 0.0
u_tgt, v_tgt = 0.0, 0.0

target_id = 0

cv2.namedWindow("Autonomous Exploration Map", cv2.WINDOW_NORMAL)
cv2.resizeWindow("Autonomous Exploration Map", 400, 400)

def update_robot():
    global guncelleme_sayaci, robot_x, robot_y, heading, rightDistance, leftDistance, start_grid, start_grid_x, start_grid_y
    robot_x = gps_vals[0]
    robot_y = gps_vals[2] 
    heading = fix_angle(-rpy[2] - math.pi/2)

    leftDistance = None
    rightDistance = None
    for point in noktalar:
        if abs(point.x) < 0.01 and point.y < 0 and point.layer == 2:
            leftDistance = -point.y
        if abs(point.x) < 0.01 and point.y > 0 and point.layer == 2:
            rightDistance = -point.y

    guncelleme_sayaci += 1
    
    start_grid_x = int(robot_x / GRID_RESOLUTION) + ORIGIN_X
    start_grid_y = int(robot_y / GRID_RESOLUTION) + ORIGIN_Y
    start_grid = (start_grid_x, start_grid_y)

def detect_and_mark(camera, cam_angle):
    global target_id, current_victim, robot_state
    raw_image = camera.getImage()
    if raw_image:
        frame = np.frombuffer(raw_image, np.uint8).reshape((camera.getHeight(), camera.getWidth(), 4))
        frame_bgr = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
        hsv = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HSV)
        
        # 1. Generate the Master Color Mask
        h, s, v = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]
        vibrant = (s >= 190) & (v >= 190)
        
        masks = {
            "Black":  (v < 25),
            "White":  (v >= 200) & (s < 25),
            "Red":    vibrant & ((h < 10) | (h > 165)),
            "Yellow": vibrant & ((h >= 15) & (h < 35)),
            "Green":  vibrant & ((h >= 45) & (h < 85)),
            "Blue":   vibrant & ((h >= 100) & (h < 140))
        }
        
        target_mask = (masks["White"] | masks["Black"] | masks["Red"] | masks["Yellow"] | masks["Green"] | masks["Blue"]).astype(np.uint8) * 255
        victim_mask = (masks["Black"] | masks["White"]).astype(np.uint8) * 255
        
        # 2. Find the main target clusters
        num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(target_mask)

        # 1. Pre-process and sort Lidar points radially for neighbor sampling
        layer_points = [pt for pt in noktalar if pt.layer == 2 and not (math.isinf(pt.x) or math.isnan(pt.x))]
        layer_points.sort(key=lambda pt: math.atan2(pt.y, pt.x))

        for label in range(1, num_labels):
            if stats[label, cv2.CC_STAT_AREA] < 60:
                continue
            
            cx, cy = centroids[label]
            bx, by, bw, bh = stats[label, cv2.CC_STAT_LEFT], stats[label, cv2.CC_STAT_TOP], stats[label, cv2.CC_STAT_WIDTH], stats[label, cv2.CC_STAT_HEIGHT]

            # Aggressive filtering to remove floor false positives
            if bh / bw > 1.3 or bw / bh > 1.3: continue
            if by > 16: continue

            # Dynamically calculate angle based on actual camera width instead of hardcoding 20
            cam_width = camera.getWidth()
            angle = cam_angle + (cx - (cam_width / 2)) * -0.02

            # 2. Find the closest Lidar point index
            closest_idx = -1
            closest_idx2 = -1
            min_angle_diff = float('inf')
            min_angle_diff2 = float('inf')
            
            for i, pt in enumerate(layer_points):
                pt_angle = math.atan2(pt.y, pt.x)
                diff = fix_angle(angle - pt_angle)
                if diff >= 0 and diff < min_angle_diff:
                    min_angle_diff = diff
                    closest_idx = i
            
            for i, pt in enumerate(layer_points):
                pt_angle = math.atan2(pt.y, pt.x)
                diff = fix_angle(angle - pt_angle)
                if diff < 0 and -diff < min_angle_diff2:
                    min_angle_diff2 = -diff
                    closest_idx2 = i

            wall_angle = math.atan2(layer_points[closest_idx2].y - layer_points[closest_idx].y, layer_points[closest_idx2].x - layer_points[closest_idx].x)

            if closest_idx != -1 and min_angle_diff < 0.05:
                # 3. Sample neighbors to find the wall's slope
                WINDOW = 3 # Look 3 Lidar points to the left and right
                
                left_idx = max(0, closest_idx - WINDOW)
                right_idx = min(len(layer_points) - 1, closest_idx + WINDOW)
                
                p_left = layer_points[left_idx]
                p_right = layer_points[right_idx]
                
                # Edge Case: Prevent calculating a slope across a gap or corner
                dist_between = math.hypot(p_right.x - p_left.x, p_right.y - p_left.y)
                if dist_between > 0.15: # If points are more than 15cm apart, shrink the window
                    left_idx = max(0, closest_idx - 1)
                    right_idx = min(len(layer_points) - 1, closest_idx + 1)
                    p_left = layer_points[left_idx]
                    p_right = layer_points[right_idx]

                # 4. Calculate wall tangent in the robot's local frame
                wall_dy = p_right.y - p_left.y
                wall_dx = p_right.x - p_left.x
                wall_angle_local = math.atan2(wall_dy, wall_dx)
                
                # 5. The normal points 90 degrees out from the wall.
                target_normal_local = fix_angle(wall_angle_local - math.pi / 2)
                
                # Convert the normal to global heading
                target_dir = fix_angle(heading + angle + math.pi)
                # for i in range(4):
                #     if fix_angle(target_dir - math.pi / 2 * i) <= math.pi / 4:
                #         target_dir = fix_angle(math.pi / 2 * i)
                #         break
                
                # Calculate global position
                p = layer_points[closest_idx]
                rot_x = p.x * math.cos(heading) + p.y * math.sin(heading)
                rot_y = -p.x * math.sin(heading) + p.y * math.cos(heading)
                target_x = robot_x - rot_x
                target_y = robot_y + rot_y
                
                # Check for duplicates
                already_exists = False
                for tx, ty, tdir, tid in targets:
                    if math.hypot(target_x - tx, target_y - ty) < 0.05 and abs(fix_angle(tdir - target_dir)) < math.pi / 2:
                        already_exists = True
                        
                if not already_exists: 
                    target_id += 1
                    target = (target_x, target_y, target_dir, target_id)
                    targets.add(target)
                    print(current_victim)
                    if robot_state == 0 or current_victim == None:
                        print("set victim")
                        current_victim = target
                        robot_state = 1
                    print(f"Victim Acquired - X: {target_x:.2f}, Y: {target_y:.2f}, Normal: {target_dir:.2f} rad")

def gorsellestir(gosterge_matrisi, grid_path, start_grid, heading, targets):
        global robot_x, robot_y, rightDistance, leftDistance, start_grid_x, start_grid_y
        gosterge_matrisi = np.zeros_like(occupancy_grid)
        gosterge_matrisi[visited_grid == 1] = 1   
        gosterge_matrisi[hitbox_grid == 1] = 2    
        gosterge_matrisi[occupancy_grid == 1] = 3  
        
        canvas = COLOR_MAP[gosterge_matrisi]
        
        if len(grid_path) > 1:
            pts = np.array(grid_path, dtype=np.int32).reshape((-1, 1, 2))
            cv2.polylines(canvas, [pts], isClosed=False, color=(0, 255, 0), thickness=1)
            
        cv2.rectangle(canvas, (start_grid_x-1, start_grid_y-1), (start_grid_x+1, start_grid_y+1), color=(0, 255, 255), thickness=-1)
        
        for target_x, target_y, target_dir, target_id in targets:
            target_face_x = target_x + math.cos(target_dir) * 0.06
            target_face_y = target_y + math.sin(target_dir) * 0.06
            grid_target_x = int(target_x / GRID_RESOLUTION + ORIGIN_X)
            grid_target_y = int(target_y / GRID_RESOLUTION + ORIGIN_Y)
            grid_target_x2 = int(target_face_x / GRID_RESOLUTION + ORIGIN_X)
            grid_target_y2 = int(target_face_y / GRID_RESOLUTION + ORIGIN_Y)
            cv2.rectangle(canvas, (grid_target_x-1, grid_target_y-1), (grid_target_x+1, grid_target_y+1), color=(255, 255, 0), thickness=-1)
            cv2.rectangle(canvas, (grid_target_x2-1, grid_target_y2-1), (grid_target_x2+1, grid_target_y2+1), color=(255, 0, 255), thickness=-1)
        
        cv2.imshow("Autonomous Exploration Map", canvas)
def update_visited_grid(robot_x, robot_y, heading):
        global rightDistance, leftDistance, start_grid_x, start_grid_y
        CAM_THICKNESS = 0.01
        CAM_SIDE_REACH = 0.07
        local_corners = [
            ( CAM_THICKNESS,  CAM_SIDE_REACH), 
            ( CAM_THICKNESS, -CAM_SIDE_REACH), 
            (-CAM_THICKNESS, -CAM_SIDE_REACH), 
            (-CAM_THICKNESS,  CAM_SIDE_REACH)  
        ]
        
        grid_corners = []
        cos_h = math.cos(heading)
        sin_h = math.sin(heading)
        
        for lx, ly in local_corners:
            rot_x = lx * cos_h + ly * sin_h
            rot_y = -lx * sin_h + ly * cos_h
            
            glob_x = robot_x - rot_x
            glob_y = robot_y + rot_y
            
            g_x = int(glob_x / GRID_RESOLUTION) + ORIGIN_X
            g_y = int(glob_y / GRID_RESOLUTION) + ORIGIN_Y
            
            g_x = max(0, min(GRID_WIDTH - 1, g_x))
            g_y = max(0, min(GRID_HEIGHT - 1, g_y))
            grid_corners.append([g_x, g_y])
            
        pts = np.array(grid_corners, dtype=np.int32)

        fov_working_canvas = np.zeros_like(occupancy_grid)
        cv2.fillPoly(fov_working_canvas, [pts], color=255)
        fov_working_canvas[occupancy_grid == 1] = 0
        
        start_grid_x = max(0, min(GRID_WIDTH - 1, start_grid_x))
        start_grid_y = max(0, min(GRID_HEIGHT - 1, start_grid_y))
        fov_working_canvas[start_grid_y, start_grid_x] = 255
        
        ff_mask = np.zeros((GRID_HEIGHT + 2, GRID_WIDTH + 2), dtype=np.uint8)
        cv2.floodFill(fov_working_canvas, ff_mask, (start_grid_x, start_grid_y), 128)
        visited_grid[fov_working_canvas == 128] = 1
def update_lidar_obstacles(noktalar):
    global robot_x, robot_y, heading, rightDistance, leftDistance, start_grid, start_grid_x, start_grid_y
    for p in noktalar:
        if p.layer != 2 or math.isinf(p.x) or math.isnan(p.x): 
            continue
            
        mesafe = math.sqrt(p.x**2 + p.y**2)
        if not bad_position and 0.05 < mesafe < (max_range * 0.95):
            #rot_x = p.x * math.cos(heading) + p.y * math.cos(heading + math.pi / 2)
            #rot_y = p.x * math.sin(heading) + p.y * math.sin(heading + math.pi / 2)

            rot_x = -p.x * math.cos(heading) - p.y * math.sin(heading)
            rot_y = -p.x * math.sin(heading) + p.y * math.cos(heading)
            
            global_x = robot_x + rot_x
            global_y = robot_y + rot_y
            
            grid_x = int(global_x / GRID_RESOLUTION) + ORIGIN_X
            grid_y = int(global_y / GRID_RESOLUTION) + ORIGIN_Y
            
            if 0 <= grid_x < GRID_WIDTH and 0 <= grid_y < GRID_HEIGHT and occupancy_grid[grid_y, grid_x] != 1:
                occupancy_grid[grid_y, grid_x] = 1
                
                x_start = max(0, grid_x - R_cells)
                x_end = min(GRID_WIDTH, grid_x + R_cells + 1)
                y_start = max(0, grid_y - R_cells)
                y_end = min(GRID_HEIGHT, grid_y + R_cells + 1)
                
                mask_x_start = x_start - (grid_x - R_cells)
                mask_x_end = mask_x_start + (x_end - x_start)
                mask_y_start = y_start - (grid_y - R_cells)
                mask_y_end = mask_y_start + (y_end - y_start)
                
                hitbox_grid[y_start:y_end, x_start:x_end] |= circle_mask[mask_y_start:mask_y_end, mask_x_start:mask_x_end]
def escape_from_black(camera):
    global robot_x, robot_y, heading, rightDistance, leftDistance, start_grid, start_grid_x, start_grid_y
    floor_raw = camera.getImage()
    if floor_raw:
        frame = np.frombuffer(floor_raw, np.uint8).reshape((camera.getHeight(), camera.getWidth(), 4))
        frame_bgr = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
        hsv = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HSV)
        h, s, v = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]
        vibrant = (s >= 190) & (v >= 190)
        
        masks = {
            "Black":  (v < 35) & (s < 150),
            "White":  (v >= 200) & (s < 25),
            "Red":    vibrant & ((h < 10) | (h > 165)),
            "Yellow": vibrant & ((h >= 15) & (h < 35)),
            "Green":  vibrant & ((h >= 45) & (h < 85)),
            "Blue":   vibrant & ((h >= 100) & (h < 140))
        }

        robot_front_x = robot_x + math.cos(heading) * 0.06
        robot_front_y = robot_y + math.sin(heading) * 0.06
        step_x = math.cos(heading + math.pi / 2) * 0.001
        step_y = math.sin(heading + math.pi / 2) * 0.001
        
        cam_width = camera.getWidth() 
        
        for x in range(cam_width):
            if np.sum(masks["Black"][:, x]) > 3:
                # print("Çizgi tespit edildi! Kamera X:", x)
                offset = (x - (cam_width / 2))
                hole_x = robot_front_x + offset * step_x
                hole_y = robot_front_y + offset * step_y
                
                grid_x = int(hole_x / GRID_RESOLUTION) + ORIGIN_X
                grid_y = int(hole_y / GRID_RESOLUTION) + ORIGIN_Y
                
                if 0 <= grid_x < GRID_WIDTH and 0 <= grid_y < GRID_HEIGHT:
                    x_start = max(0, grid_x - R_hole_cells)
                    x_end = min(GRID_WIDTH, grid_x + R_hole_cells + 1)
                    y_start = max(0, grid_y - R_hole_cells)
                    y_end = min(GRID_HEIGHT, grid_y + R_hole_cells + 1)
                    
                    mask_x_start = x_start - (grid_x - R_hole_cells)
                    mask_x_end = mask_x_start + (x_end - x_start)
                    mask_y_start = y_start - (grid_y - R_hole_cells)
                    mask_y_end = mask_y_start + (y_end - y_start)
                    
                    hitbox_grid[y_start:y_end, x_start:x_end] |= circle_mask_hole[mask_y_start:mask_y_end, mask_x_start:mask_x_end]

robot_state = 0 # 0 discovery, 1 move to target
done_targets = []
current_victim = None

while robot.step(timestep) != -1:
    noktalar = lidar.getPointCloud()
    gps_vals = gps.getValues()
    rpy = imu.getRollPitchYaw()

    bad_position = abs(rpy[0]) > 0.01 or abs(rpy[1]) > 0.01

    if bad_position:
        continue
    
    if not noktalar or math.isnan(gps_vals[0]) or math.isnan(rpy[0]):
        continue
    
    update_robot()
    
    if 0 <= start_grid_x < GRID_WIDTH and 0 <= start_grid_y < GRID_HEIGHT:
        update_visited_grid(robot_x, robot_y, heading)
    
    update_lidar_obstacles(noktalar)
        
    if guncelleme_sayaci % 10 == 0:
        update_path()
    
    detect_and_mark(camera1, -math.pi / 2)
    detect_and_mark(camera2, math.pi / 2)
    
    escape_from_black(camera3)
    
    if robot_state == 0:
        if len(grid_path) > 1:
            follow_path(grid_path)
        else:
            wheel1.setVelocity(0.0)
            wheel2.setVelocity(0.0)
    if robot_state == 1:
        if current_victim:
            desired_dist = 0.06
            goal_pos = (current_victim[0] + math.cos(current_victim[2]) * desired_dist,
                        current_victim[1] + math.sin(current_victim[2]) * desired_dist)
            goal_pos_grid = (int(goal_pos[0] / GRID_RESOLUTION + ORIGIN_X), int(goal_pos[1] / GRID_RESOLUTION + ORIGIN_Y))
            current_dist = math.hypot(robot_x - goal_pos[0], robot_y - goal_pos[1])
            if current_dist > 0.01:
                path = find_path_to_target_dijkstra(start_grid, goal_pos_grid, hitbox_grid)
                if path:
                    print("follow target path")
                    follow_path(path)
                else:
                    print("no path?")
                    wheel1.setVelocity(0.0)
                    wheel2.setVelocity(0.0)
                    robot_state = 0
            else:
                robot_state = 2
        else:
            robot_state = 0
    elif robot_state == 2:
        camera1_angle_dist = fix_angle(heading - math.pi / 2 - current_victim[2] + math.pi)
        camera2_angle_dist = fix_angle(heading + math.pi / 2 - current_victim[2] + math.pi)
        if abs(camera1_angle_dist) < abs(camera2_angle_dist):
            best_dist = camera1_angle_dist
        else:
            best_dist = camera2_angle_dist
        if abs(best_dist) < 0.1:
            wheel1.setVelocity(0.0)
            wheel2.setVelocity(0.0)
            mycamera = camera1 if best_dist == camera1_angle_dist else camera2
            detect_cognitive(mycamera)
            detect_victim(mycamera)

            done_targets.append(current_victim[3])

            current_victim = None

            for tx, ty, tdir, tid in targets:
                if not (tid in done_targets):
                    current_victim = (tx, ty, tdir, tid)

            if current_victim == None:
                robot_state = 0
            else:
                robot_state = 1

        else:
            print("turning!")
            v = 4 * best_dist
            wheel1.setVelocity(v)
            wheel2.setVelocity(-v)
    
    # 100 if bad performance, 10 for better pc
    if guncelleme_sayaci % 100 == 0:
        gorsellestir(occupancy_grid, grid_path, start_grid, heading, targets)
    cv2.waitKey(1)