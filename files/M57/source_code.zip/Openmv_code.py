import sensor, image, time, math, ml
from pyb import UART
from ulab import numpy as np

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_vflip(True)
sensor.set_framesize(sensor.QVGA)
sensor.set_windowing((240, 240))
sensor.skip_frames(time=2000)
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
sensor.set_auto_exposure(False, exposure_us=22000)

clock = time.clock()
uart = UART(1, 115200, timeout_char=1000)

senal_silence_until = 0
SENAL_SILENCE_MS    = 4000

letras_cooldown      = {}
COOLDOWN_LETRA_MS    = 12000
ultima_letra_enviada = None

targets_cooldown   = {}
COOLDOWN_TARGET_MS = 12000

net = ml.Model("trained.tflite", load_to_fb=True)
try:
    labels = [line.rstrip('\n') for line in open("labels.txt")]
except Exception:
    labels = ["omega", "phi", "psi"]

min_confidence       = 0.96
threshold_list       = [(math.ceil(min_confidence * 255), 255)]
CONFIRM_FRAMES_LETRA = 2
contador_modelo      = 0
letra_candidata      = None

CONFIRM_FRAMES_TARGET  = 4
MAX_MISS_FRAMES_TARGET = 3
contador_target        = 0
miss_frames_target     = 0
target_candidato_kits  = None

IMG_W, IMG_H = 240, 240
ROI = (2, 2, IMG_W - 4, IMG_H - 4)

UMBRAL_BLANCO = (55, 100, -25, 25, -25, 25)

BLOB_AREA_MIN    = 300
BLOB_PIXELS_MIN  = 200
BLOB_DENSIDAD    = 0.55
BLOB_ASPECT_MIN  = 0.45
BLOB_ASPECT_MAX  = 2.2
BLOB_AB_STDEV    = 9

R_MIN          = 12
MIN_R_ANALISIS = 30

RING_OFFSETS     = [0.10, 0.30, 0.50, 0.70, 0.90]
SUB_OFFSETS      = [-0.04, 0.0, 0.04]
SAMPLES_PER_RING = 16
MIN_MUESTRAS     = 20
MIN_VOTOS_RATIO  = 0.55

LAB_CENTROIDES = {
    "N" : (20,  -2,  -5),
    "R" : (53,  65,  45),
    "Y" : (75,   5,  50),
    "V" : (40, -35,  25),
    "A" : (75, -10, -35),
    "?" : (95,   0,   0),
}

COLOR_VALUES = {
    "N": -2, "R": -1, "Y": 0, "V": 1, "A": 2, "?": None
}

SUMAS_VALIDAS = (0, 1, 2)

def senal_is_silent():
    return time.ticks_diff(senal_silence_until, time.ticks_ms()) > 0

def reset_deteccion():
    global contador_modelo, letra_candidata
    contador_modelo = 0
    letra_candidata = None

def reset_deteccion_target():
    global contador_target, target_candidato_kits, miss_frames_target
    contador_target        = 0
    target_candidato_kits  = None
    miss_frames_target     = 0

def letra_a_kits(letra):
    letra = letra.lower().strip()
    if letra == "omega": return 0
    if letra == "psi":   return 1
    if letra == "phi":   return 2
    return None

def enviar_kits_uart(cantidad):
    try:
        cantidad = int(cantidad)
        if cantidad not in SUMAS_VALIDAS:
            print("E")
            return None
        uart.write("{}\n".format(cantidad).encode('utf-8'))
        print(cantidad)
        return cantidad
    except ValueError:
        print("E")
        return None

def letra_en_cooldown(letra):
    letra = letra.lower().strip()
    now = time.ticks_ms()
    if letra in letras_cooldown:
        return time.ticks_diff(letras_cooldown[letra], now) > 0
    return False

def target_en_cooldown(kits):
    now = time.ticks_ms()
    if kits in targets_cooldown:
        return time.ticks_diff(targets_cooldown[kits], now) > 0
    return False

def enviar_senal_letra(dato):
    global senal_silence_until, ultima_letra_enviada
    letra = dato.replace("L:", "").lower().strip()
    if letra_en_cooldown(letra):
        print("C")
        return
    kits = letra_a_kits(letra)
    if kits is None:
        print("?")
        return
    enviar_kits_uart(kits)
    ultima_letra_enviada = letra
    letras_cooldown[letra] = time.ticks_add(time.ticks_ms(), COOLDOWN_LETRA_MS)
    senal_silence_until    = time.ticks_add(time.ticks_ms(), SENAL_SILENCE_MS)
    reset_deteccion()

def fomo_post_process(model, inputs, outputs):
    ob, oh, ow, oc = model.output_shape[0]
    x_scale  = inputs[0].roi[2] / ow
    y_scale  = inputs[0].roi[3] / oh
    scale    = min(x_scale, y_scale)
    x_offset = ((inputs[0].roi[2] - (ow * scale)) / 2) + inputs[0].roi[0]
    y_offset = ((inputs[0].roi[3] - (oh * scale)) / 2) + inputs[0].roi[1]
    out = [[] for _ in range(oc)]
    for i in range(oc):
        channel_data = np.array(outputs[0][0, :, :, i], dtype=np.float)
        img_channel  = image.Image(channel_data * 255.0)
        blobs = img_channel.find_blobs(
            threshold_list, x_stride=1, y_stride=1,
            area_threshold=1, pixels_threshold=1
        )
        for b in blobs:
            rect = b.rect()
            x, y, w, h = rect
            score = img_channel.get_statistics(thresholds=threshold_list, roi=rect).l_mean() / 255.0
            x = int((x * scale) + x_offset)
            y = int((y * scale) + y_offset)
            w = int(w * scale)
            h = int(h * scale)
            out[i].append((x, y, w, h, score))
    return out

def classify_color(lab):
    L, A, B = lab
    chroma = math.sqrt(A * A + B * B)
    if L < 30 and chroma < 35:
        return "N"
    if L > 82 and chroma < 18:
        return "?"
    best_color = "?"
    best_dist  = 1e9
    for name, (Lc, Ac, Bc) in LAB_CENTROIDES.items():
        d = ((L - Lc) * 0.5) ** 2 + (A - Ac) ** 2 + (B - Bc) ** 2
        if d < best_dist:
            best_dist  = d
            best_color = name
    return best_color

def buscar_blob_target(img):
    blobs = img.find_blobs(
        [UMBRAL_BLANCO], invert=True, roi=ROI,
        x_stride=2, y_stride=2, merge=True, margin=12,
        area_threshold=BLOB_AREA_MIN, pixels_threshold=BLOB_PIXELS_MIN
    )
    if not blobs:
        return None
    for b in sorted(blobs, key=lambda b: b.pixels(), reverse=True):
        w, h = b.w(), b.h()
        if min(w, h) < 2 * R_MIN:
            continue
        densidad = b.pixels() / float(w * h)
        if densidad < BLOB_DENSIDAD:
            continue
        aspect = w / float(h)
        if not (BLOB_ASPECT_MIN <= aspect <= BLOB_ASPECT_MAX):
            continue
        st = img.get_statistics(roi=b.rect())
        if st.a_stdev() < BLOB_AB_STDEV and st.b_stdev() < BLOB_AB_STDEV:
            continue
        return b
    return None

def analyze_target(img, cx, cy, rx, ry):
    colors = []
    values = []
    for mult in RING_OFFSETS:
        votos = {}
        n = 0
        for sub in SUB_OFFSETS:
            f = mult + sub
            if f < 0.02:
                f = 0.02
            for j in range(SAMPLES_PER_RING):
                ang = 2.0 * math.pi * j / SAMPLES_PER_RING
                px = int(cx + rx * f * math.cos(ang))
                py = int(cy + ry * f * math.sin(ang))
                if 0 <= px < img.width() and 0 <= py < img.height():
                    lab = image.rgb_to_lab(img.get_pixel(px, py))
                    c = classify_color(lab)
                    votos[c] = votos.get(c, 0) + 1
                    n += 1
        if n < MIN_MUESTRAS:
            color = "?"
        else:
            ganador, cnt = "?", 0
            for c in votos:
                if votos[c] > cnt:
                    ganador, cnt = c, votos[c]
            color = ganador if cnt >= MIN_VOTOS_RATIO * n else "?"
        colors.append(color)
        values.append(COLOR_VALUES.get(color, None))

    valid = all(v is not None for v in values)
    total = sum(values) if valid else None
    return colors, total, valid
