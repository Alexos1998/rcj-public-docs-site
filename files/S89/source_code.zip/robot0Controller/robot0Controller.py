"""
RoboCup Junior Rescue Simulation 2026 – Erebus/Webots
Controlador BCL — versão integrada com Kalman + Mapeamento

Módulos externos (mesmo directório):
  kalman.py — EKF para estimativa de pose (x, z, θ)
  mapa.py   — grelha de ocupação (occupancy grid) com log-odds

Sensores disponíveis no robot personalizado "Erebus_Bot":
  Navegação : lidar 360° (sem ps0–ps7, que só existem no e-puck padrão)
  Encoders  : "wheel1 sensor" / "wheel2 sensor" (acedidos directamente)
  Pose      : gps + inertial_unit → fundidos no EKF
"""

from controller import Robot
from typing import Optional, List
import json
import math
import os
import random
import struct

from kalman import KalmanPose
from mapa   import OccupancyGrid

# ════════════════════════════════════════════════════════════════════════════════
# PARÂMETROS
# ════════════════════════════════════════════════════════════════════════════════

# — Velocidades (rad/s)
MAX_V  = 6.28
FWD_V  = 5.5
TURN_V = 4.0

# — Navegação: distâncias de reação (metros)
D_FRONT_STOP  = 0.15
D_FRONT_TURN  = 0.25
D_SIDE_PUSH   = 0.12
D_SIDE_ACTIVE = 0.30

# — Lidar 360°
# Se o robot andar para trás: LIDAR_FRONT_IDX = LIDAR_N // 2
# Se esquerda/direita trocadas: LIDAR_CCW = -1
LIDAR_FRONT_IDX  = 0
LIDAR_CCW        = -1   # Sensor physical hardware sweep (CW)
SECTOR_FRONT_DEG = 25
SECTOR_SIDE_DEG  = 40

# — Controlo de heading (mantém direcção rectilínea em P4)
HDG_GAIN     = 4.0   # ganho proporcional da correcção de heading
HDG_MAX_CORR = 2.0   # correcção máxima (rad/s) aplicada a cada roda
HDG_SNAP_DEG = 45.0  # arredonda para múltiplos de 45° ao sair de P1

# — Anti-stuck via GPS (usa posição estimada pelo KF)
GPS_STUCK_N  = 50
GPS_MIN_MOVE = 0.002  # robot move 3.5 mm/step em frente → 2 mm distingue avançar de girar

# — Anti-stuck via encoders
ENC_STUCK_N  = 55
ENC_MIN_RAD  = 0.05

# — Anti-spinning
SPIN_N       = 60
SPIN_GPS_MIN = 0.002

# — Cooldown e locks de steering
COOL_N        = 100
P3_MIN_STEPS  = 8
P1_LOCK_STEPS = 5    # passos extra após frente limpar (5×5.6°≈28°); era 20→112° overshoot

# — Câmara (getWidth/getHeight falham em PROTO no Webots R2023b — hardcoded)
CAM_W = 64
CAM_H = 64

# — Deteção de vítimas
SCAN_EVERY  = 25
VICTIM_GRID = 12   # fator de grid para deduplicação (antes do KF)

# — Deteção de buracos
HOLE_THRESH    = 120
HOLE_COOL_N    = 80    # steps de cooldown após escape de sensor (2.56 s)
TELEPORT_THRESH = 0.40  # salto GPS (m) que indica teleportação pelo supervisor
TELEPORT_COOL_N = 200   # cooldown mais longo após teleportação (6.4 s)

# — Kalman: frequência de actualização do GPS (cada N steps)
# 1 = cada step. Aumenta se o GPS der saltos anómalos.
KF_GPS_EVERY = 1

# — Mapeamento
MAP_UPDATE_N = 10    # steps entre actualizações da grelha
MAP_PRINT_N  = 500   # steps entre impressão ASCII do mapa (0 = desligado)

# — Visualizador KF (kf_viewer.py)
KF_LOG_EVERY    = 5              # steps entre escritas do ficheiro de estado
KF_STATE_FILE   = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "kf_state.json")
KF_TRAIL_MAX    = 400            # posições máximas no historial
KF_GPS_HIST_MAX = 200

# ════════════════════════════════════════════════════════════════════════════════
# INIT — DISPOSITIVOS
# ════════════════════════════════════════════════════════════════════════════════

robot = Robot()
TS    = int(robot.getBasicTimeStep())

wl = robot.getDevice("wheel2 motor")
wr = robot.getDevice("wheel1 motor")
wl.setPosition(float("inf"))
wr.setPosition(float("inf"))
wl.setVelocity(0.0)
wr.setVelocity(0.0)

enc_l = robot.getDevice("wheel2 sensor")
enc_r = robot.getDevice("wheel1 sensor")
if enc_l: enc_l.enable(TS)
if enc_r: enc_r.enable(TS)
print(f"  [{'OK' if enc_l else '--'}] wheel2 sensor (esquerdo)")
print(f"  [{'OK' if enc_r else '--'}] wheel1 sensor (direito)")

lidar = robot.getDevice("lidar")
if lidar:
    lidar.enable(TS)
    LIDAR_N         = lidar.getHorizontalResolution()
    LIDAR_FOV       = lidar.getFov()
    LIDAR_MAX_RANGE = lidar.getMaxRange()
    LIDAR_LAYERS    = lidar.getNumberOfLayers()
    try:
        LIDAR_VFOV = lidar.getVerticalFieldOfView()
    except Exception:
        LIDAR_VFOV = 0.0
    print(f"  [OK] lidar — {LIDAR_N} pts × {LIDAR_LAYERS} layer(s), "
          f"FOV={math.degrees(LIDAR_FOV):.0f}°, "
          f"VFOV={math.degrees(LIDAR_VFOV):.1f}°, "
          f"maxRange={LIDAR_MAX_RANGE:.2f} m")
else:
    LIDAR_N         = 512
    LIDAR_FOV       = 2 * math.pi
    LIDAR_MAX_RANGE = 1.0
    LIDAR_LAYERS    = 1
    LIDAR_VFOV      = 0.0
    print("  [--] lidar não encontrado")

# Camada do lidar usada para mapeamento (0 = mais inclinada; varia com a PROTO)
LIDAR_MAP_LAYER = 0

gps = robot.getDevice("gps")
if gps:
    gps.enable(TS)
    print("  [OK] gps")
else:
    print("  [--] gps")

imu = robot.getDevice("inertial_unit")
if imu:
    imu.enable(TS)
    print("  [OK] inertial_unit")
else:
    print("  [--] inertial_unit")

camera = robot.getDevice("camera1")
if camera:
    camera.enable(TS)
    print(f"  [OK] camera1 ({CAM_W}×{CAM_H} hardcoded)")
else:
    print("  [--] camera1")

colour = robot.getDevice("colour_sensor")
if colour:
    colour.enable(TS)
    print("  [OK] colour_sensor")
else:
    print("  [--] colour_sensor")

emitter = robot.getDevice("emitter")
if emitter:
    print("  [OK] emitter")
else:
    print("  [--] emitter")

for _ in range(5):
    robot.step(TS)

# ── Diagnóstico de camadas do lidar ───────────────────────────────────────────
if lidar and LIDAR_LAYERS > 1:
    diag_lines = []
    diag_lines.append("[LIDAR] Distribuição de distâncias por camada:")
    for _li in range(LIDAR_LAYERS):
        _lr = lidar.getLayerRangeImage(_li) or []
        _fin = [v for v in _lr if math.isfinite(v) and v > 0]
        if _fin:
            _fin.sort()
            _close = sum(1 for v in _fin if v < 0.5)
            diag_lines.append(f"    layer {_li}: min={_fin[0]:.3f} m  "
                              f"median={_fin[len(_fin)//2]:.3f} m  "
                              f"leituras<0.5m: {_close}/{len(_fin)}")
    print("\n".join(diag_lines))
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "lidar_diagnostic.txt"), "w") as f:
            f.write("\n".join(diag_lines) + "\n")
    except Exception:
        pass

def get_imu_yaw() -> float:
    if not imu:
        return 0.0
    # Adicionar +90 graus (math.pi/2 rad) para compensar a rotação física do slot do sensor
    val = imu.getRollPitchYaw()[2] + math.pi / 2.0
    return ((val + math.pi) % (2 * math.pi)) - math.pi

print("\n=== BCL Controlador iniciado ===\n")

# ── Filtro de Kalman ──────────────────────────────────────────────────────────
# Inicialização adiada até à primeira leitura do GPS
kf: Optional[KalmanPose] = None

# ── Grelha de ocupação ────────────────────────────────────────────────────────
grid = OccupancyGrid(resolution=0.05, size_m=6.0)

# ════════════════════════════════════════════════════════════════════════════════
# LIDAR — LEITURA DE SECTORES
# ════════════════════════════════════════════════════════════════════════════════

def _sector_hw(deg: float) -> int:
    return max(1, int((deg / 360.0) * LIDAR_N))


def _sector_min(ranges, center: int, hw: int) -> float:
    best = float("inf")
    for d in range(-hw, hw + 1):
        v = ranges[(center + d) % LIDAR_N]
        if 0.0 < v < best:
            best = v
    return best if best < float("inf") else 1.0


def read_lidar() -> dict:
    global _last_lidar_ranges
    if not lidar:
        return dict(front=1.0, front_l=1.0, front_r=1.0, left=1.0, right=1.0)
    ranges = lidar.getRangeImage()
    if not ranges:
        return dict(front=1.0, front_l=1.0, front_r=1.0, left=1.0, right=1.0)
    _last_lidar_ranges = ranges

    fw  = _sector_hw(SECTOR_FRONT_DEG)
    sw  = _sector_hw(SECTOR_SIDE_DEG)
    n4  = LIDAR_N // 4

    fi   = LIDAR_FRONT_IDX
    li   = (fi + LIDAR_CCW * n4)       % LIDAR_N
    ri   = (fi - LIDAR_CCW * n4)       % LIDAR_N
    fli  = (fi + LIDAR_CCW * (n4 // 2)) % LIDAR_N
    fri  = (fi - LIDAR_CCW * (n4 // 2)) % LIDAR_N

    return dict(
        front   = _sector_min(ranges, fi,  fw),
        front_l = _sector_min(ranges, fli, fw),
        front_r = _sector_min(ranges, fri, fw),
        left    = _sector_min(ranges, li,  sw),
        right   = _sector_min(ranges, ri,  sw),
    )

# ════════════════════════════════════════════════════════════════════════════════
# MOVIMENTO
# ════════════════════════════════════════════════════════════════════════════════

def drive(l: float, r: float) -> None:
    wl.setVelocity(max(-MAX_V, min(MAX_V, l)))
    wr.setVelocity(max(-MAX_V, min(MAX_V, r)))


# ── KF helpers (invocados também dentro das funções de movimento bloqueantes) ─
# Separados do loop principal para que go_steps / rotate_deg mantenham
# o KF actualizado enquanto o loop principal está bloqueado nessas funções.

def _kf_update(cur_el: float, cur_er: float) -> None:
    """Predição + correcção KF para um step. NÃO actualiza last_enc_l/r."""
    global kf
    if kf is None and gps is not None:
        p = gps.getValues()
        if not all(math.isnan(v) for v in p):
            theta0 = get_imu_yaw() if imu else 0.0
            kf = KalmanPose(p[0], p[2], theta0)
            print(f"[KF] Inicializado: "
                  f"pos=({p[0]:.3f}, {p[2]:.3f})  "
                  f"θ={math.degrees(theta0):.1f}°")
    if kf is None:
        return
    if last_enc_l is not None:
        kf.predict(cur_el - last_enc_l, cur_er - last_enc_r)
    if imu:
        kf.update_imu(get_imu_yaw())
    if gps:
        p = gps.getValues()
        if not any(math.isnan(v) for v in p):
            kf.update_gps(p[0], p[2])


def _write_kf_state() -> None:
    """Actualiza trail e escreve kf_state.json para o visualizador."""
    global _last_lidar_ranges
    if kf is None:
        return
    # Refresh lidar data on every call so blocking functions (rotate_deg,
    # go_steps) don't project stale scan data at the updated heading.
    if lidar:
        _fresh = lidar.getLayerRangeImage(LIDAR_MAP_LAYER)
        if _fresh:
            _last_lidar_ranges = _fresh
    pos = kf.pos
    kf_trail.append([pos[0], pos[1]])
    if len(kf_trail) > KF_TRAIL_MAX:
        kf_trail.pop(0)
    if gps:
        gv = gps.getValues()
        if not any(math.isnan(v) for v in gv):
            kf_gps_hist.append([gv[0], gv[2]])
            if len(kf_gps_hist) > KF_GPS_HIST_MAX:
                kf_gps_hist.pop(0)
    # Downsample lidar to ~72 rays and convert to world coords for viewer
    lidar_hits: list = []
    if _last_lidar_ranges and kf:
        rx, rz = kf.pos
        hdg    = kf.heading
        n      = len(_last_lidar_ranges)
        step_r = max(1, n // 72)
        twoπ_n = 2.0 * math.pi / n
        for i in range(0, n, step_r):
            d = _last_lidar_ranges[i]
            if math.isfinite(d) and 0.01 < d < LIDAR_MAX_RANGE * 0.98:
                angle_robot = ((i - LIDAR_FRONT_IDX) % n) * twoπ_n * LIDAR_CCW
                angle = hdg + angle_robot
                lidar_hits.append([round(rx + d * math.cos(angle), 3),
                                   round(rz - d * math.sin(angle), 3)])

    try:
        tmp = KF_STATE_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump({
                "step":        step_count,
                "x":           pos[0],
                "z":           pos[1],
                "theta":       kf.heading,
                "std_pos":     kf.std_pos,
                "std_heading": kf.std_heading,
                "trail":       kf_trail[-200:],
                "gps_hist":    kf_gps_hist[-100:],
                "victims":     victim_log,
                "occ_cells":   grid.viewer_cells(),
                "lidar_hits":  lidar_hits,
            }, f)
        os.replace(tmp, KF_STATE_FILE)
    except OSError:
        pass


def stop() -> None:
    global last_enc_l, last_enc_r
    drive(0.0, 0.0)
    for _ in range(3):
        if robot.step(TS) == -1:
            break
        cur_el = enc_l.getValue() if enc_l else 0.0
        cur_er = enc_r.getValue() if enc_r else 0.0
        _kf_update(cur_el, cur_er)
        _write_kf_state()
        last_enc_l, last_enc_r = cur_el, cur_er


def go_steps(n: int, speed: float) -> bool:
    global last_enc_l, last_enc_r
    for _ in range(n):
        if robot.step(TS) == -1:
            return False
        cur_el = enc_l.getValue() if enc_l else 0.0
        cur_er = enc_r.getValue() if enc_r else 0.0
        drive(speed, speed)
        _kf_update(cur_el, cur_er)
        _write_kf_state()
        last_enc_l, last_enc_r = cur_el, cur_er
    return True


def adiff(a: float, b: float) -> float:
    return ((a - b) + math.pi) % (2 * math.pi) - math.pi


def snap_hdg(h: float) -> float:
    """Arredonda heading para o múltiplo mais próximo de HDG_SNAP_DEG."""
    step = math.radians(HDG_SNAP_DEG)
    return round(h / step) * step


def rotate_deg(deg: float) -> None:
    global last_enc_l, last_enc_r
    rad  = math.radians(deg)
    sign = 1.0 if rad >= 0 else -1.0
    if imu:
        target = get_imu_yaw() + rad
        while robot.step(TS) != -1:
            cur_el = enc_l.getValue() if enc_l else 0.0
            cur_er = enc_r.getValue() if enc_r else 0.0
            err = adiff(target, get_imu_yaw())
            _kf_update(cur_el, cur_er)
            _write_kf_state()
            last_enc_l, last_enc_r = cur_el, cur_er
            if abs(err) < 0.06:
                break
            spd = max(1.0, min(TURN_V, abs(err) * 5.0))
            drive(-sign * spd, sign * spd)
    else:
        steps = max(1, int(abs(deg) / 90 * 22))
        for _ in range(steps):
            if robot.step(TS) == -1:
                break
            cur_el = enc_l.getValue() if enc_l else 0.0
            cur_er = enc_r.getValue() if enc_r else 0.0
            drive(-sign * TURN_V, sign * TURN_V)
            _kf_update(cur_el, cur_er)
            _write_kf_state()
            last_enc_l, last_enc_r = cur_el, cur_er

# ════════════════════════════════════════════════════════════════════════════════
# POSE ESTIMADA (KF ou GPS raw como fallback)
# ════════════════════════════════════════════════════════════════════════════════

def estimated_pos() -> Optional[tuple]:
    """Posição estimada: KF se disponível, GPS raw se não."""
    if kf is not None:
        return kf.pos
    if gps:
        p = gps.getValues()
        return (p[0], p[2])
    return None


def estimated_heading() -> float:
    """Heading estimado: KF se disponível, IMU raw se não."""
    if kf is not None:
        return kf.heading
    if imu:
        return get_imu_yaw()
    return 0.0

# ════════════════════════════════════════════════════════════════════════════════
# ANTI-STUCK — ESCAPE
# ════════════════════════════════════════════════════════════════════════════════

def do_escape(reason: str, left: float, right: float, esc_n: int) -> Optional[tuple]:
    print(f"[ESCAPE #{esc_n}] Causa: {reason}  "
          f"σ_pos={kf.std_pos*100:.1f} cm" if kf else f"[ESCAPE #{esc_n}]")
    go_steps(30, -FWD_V * 0.7)
    base      = 90 if left > right else -90
    variation = random.choice([0, 45, 90, 135, -45])
    angle     = 180 if esc_n % 3 == 0 else base + variation
    rotate_deg(angle)
    go_steps(20, FWD_V * 0.7)
    return estimated_pos()

# ════════════════════════════════════════════════════════════════════════════════
# DETEÇÃO DE BURACOS
# ════════════════════════════════════════════════════════════════════════════════

def _avg_brightness(img, w: int, h: int, cx: int, cy: int, r: int = 1) -> float:
    vals = []
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            x = max(0, min(w - 1, cx + dx))
            y = max(0, min(h - 1, cy + dy))
            vals.append(colour.imageGetGray(img, w, x, y))
    return sum(vals) / len(vals)


def is_hole() -> bool:
    if not colour:
        return False
    img = colour.getImage()
    if not img:
        return False
    w, h = colour.getWidth(), colour.getHeight()
    return _avg_brightness(img, w, h, w // 2, h // 2) < HOLE_THRESH


def escape_hole() -> None:
    print("[BURACO] Detetado! A recuar e girar 180°...")
    stop()
    go_steps(50, -FWD_V * 0.7)   # ~12 cm de recuo para afastar o sensor do buraco
    rotate_deg(180.0)
    print("[BURACO] Evitado.")

# ════════════════════════════════════════════════════════════════════════════════
# DETEÇÃO DE VÍTIMAS
# ════════════════════════════════════════════════════════════════════════════════

COLOR_THRESHOLDS = {
    "black":  lambda r, g, b: max(r, g, b) < 60,
    "red":    lambda r, g, b: r > 150 and r > g * 1.8 and r > b * 1.8,
    "yellow": lambda r, g, b: r > 150 and g > 150 and b < 100,
    "green":  lambda r, g, b: g > 120 and g > r * 1.5 and g > b * 1.3,
    "blue":   lambda r, g, b: b > 120 and b > r * 1.5 and b > g * 1.3,
    "white":  lambda r, g, b: min(r, g, b) > 180,
}
COLOR_VALUES = {"black": -2, "red": -1, "yellow": 0, "green": 1, "blue": 2}
HAZMAT_MAP   = {0: ("F", "Flammable Gas"), 1: ("P", "Poison"),
                2: ("C", "Corrosive"),     3: ("O", "Organic Peroxide")}
LETTER_MAP   = {"Φ": ("H", "Harmed"), "Ψ": ("S", "Stable"), "Ω": ("U", "Unharmed")}


def _classify(r: int, g: int, b: int) -> str:
    for name, fn in COLOR_THRESHOLDS.items():
        if fn(r, g, b):
            return name
    return "unknown"


def _detect_cognitive(img) -> Optional[tuple]:
    cx, cy = CAM_W // 2, CAM_H // 2
    max_r  = min(cx, cy)
    if max_r == 0:
        return None
    ring_colors = []
    for frac in [0.10, 0.22, 0.34, 0.44, 0.52]:
        r_s   = max(1, int(frac * max_r))
        votes = {}
        for deg in range(0, 360, 30):
            angle = math.radians(deg)
            px = max(0, min(CAM_W - 1, int(cx + r_s * math.cos(angle))))
            py = max(0, min(CAM_H - 1, int(cy + r_s * math.sin(angle))))
            c  = _classify(camera.imageGetRed(img, CAM_W, px, py),
                            camera.imageGetGreen(img, CAM_W, px, py),
                            camera.imageGetBlue(img, CAM_W, px, py))
            if c not in ("white", "unknown"):
                votes[c] = votes.get(c, 0) + 1
        if not votes:
            return None
        ring_colors.append(max(votes, key=votes.get))
    total = sum(COLOR_VALUES.get(c, 0) for c in ring_colors)
    if total not in HAZMAT_MAP:
        return None
    code, name = HAZMAT_MAP[total]
    print(f"  [COG] Anéis: {ring_colors} → soma={total} → {code}")
    return code, f"Cognitive target: {name} ({code})"


def _detect_letter(img) -> Optional[tuple]:
    def dark(x0, x1, y0, y1):
        n = 0
        for y in range(max(0, y0), min(CAM_H, y1)):
            for x in range(max(0, x0), min(CAM_W, x1)):
                avg = (camera.imageGetRed(img, CAM_W, x, y) +
                       camera.imageGetGreen(img, CAM_W, x, y) +
                       camera.imageGetBlue(img, CAM_W, x, y)) // 3
                if avg < 50:
                    n += 1
        return n

    if dark(0, CAM_W, 0, CAM_H) / (CAM_W * CAM_H) < 0.20:
        return None

    cx, cy = CAM_W // 2, CAM_H // 2
    qw, qh = CAM_W // 4, CAM_H // 4

    top  = dark(qw, 3*qw, 0, cy)
    bot  = dark(qw, 3*qw, cy, CAM_H)
    lft  = dark(0, cx, qh, 3*qh)
    rgt  = dark(cx, CAM_W, qh, 3*qh)
    ctr  = dark(cx - qw//2, cx + qw//2, 0, CAM_H)

    scores = {
        "Φ": (lft + rgt) - ctr * 0.5,
        "Ψ": ctr + bot - lft * 0.3 - rgt * 0.3,
        "Ω": top - bot * 0.5,
    }
    best       = max(scores, key=scores.get)
    code, name = LETTER_MAP[best]
    return code, f"Letter victim: {name} ({code})"


def _report(victim_char: str, pos: tuple) -> None:
    """Envia posição + tipo ao supervisor via emitter (9 bytes: int int char)."""
    if not emitter:
        return
    x_cm = int(pos[0] * 100)
    z_cm = int(pos[1] * 100)
    emitter.send(struct.pack('i i c', x_cm, z_cm, victim_char.encode()))
    print(f"  [REPORTE ✓] {victim_char}  pos=({x_cm} cm, {z_cm} cm)")


def analyze_camera(step_count: int, reported_victims: list) -> None:
    if not camera:
        return
    try:
        img = camera.getImage()
        if not img:
            return

        n_col = n_wht = n_blk = 0
        for y in range(0, CAM_H, 2):
            for x in range(0, CAM_W, 2):
                c = _classify(camera.imageGetRed(img, CAM_W, x, y),
                               camera.imageGetGreen(img, CAM_W, x, y),
                               camera.imageGetBlue(img, CAM_W, x, y))
                if c in COLOR_VALUES:   n_col += 1
                elif c == "white":      n_wht += 1
                elif c == "black":      n_blk += 1

        total   = max(1, (CAM_W // 2) * (CAM_H // 2))
        pct_col = n_col / total * 100
        pct_wht = n_wht / total * 100
        pct_blk = n_blk / total * 100

        result = None
        if pct_col > 10 and pct_wht > 5:
            result = _detect_cognitive(img)
        elif pct_wht > 45 and pct_blk > 8 and pct_col < 6:
            result = _detect_letter(img)

        if not result:
            return

        victim_char, desc = result
        pos = estimated_pos()
        if pos is None:
            return

        # Deduplicação por posição KF (mais precisa que GPS raw)
        key = (round(pos[0] * VICTIM_GRID), round(pos[1] * VICTIM_GRID))
        if key in reported_victims:
            return

        reported_victims.append(key)
        victim_log.append({"x": pos[0], "z": pos[1], "type": victim_char})
        grid.mark_victim(pos[0], pos[1], victim_char)

        stop()
        print(f"\n{'='*55}")
        print(f"  DETEÇÃO — step={step_count}")
        if kf:
            print(f"  Pose KF: ({pos[0]:.3f}, {pos[1]:.3f})  "
                  f"θ={math.degrees(kf.heading):.1f}°  "
                  f"σ={kf.std_pos*100:.1f} cm")
        print(f"    → {desc}")
        _report(victim_char, pos)
        print(f"{'='*55}\n")

    except Exception as e:
        print(f"  [CAM ERR] {e}")

# ════════════════════════════════════════════════════════════════════════════════
# ESTADO
# ════════════════════════════════════════════════════════════════════════════════

gps_stuck     = 0
gps_stuck_base_p = None
enc_stuck     = 0
spin_stuck    = 0
cool          = 0
last_p        = None
last_enc_l    = None
last_enc_r    = None
esc_n         = 0

steer_smooth  = 0.0
p3_hold       = 0
turn_lock     = 0
turn_lock_dir = 0
nav_hdg: Optional[float] = None   # heading alvo para P4 (None = re-adquirir)

step_count       = 0
reported_victims: list = []
victim_log:       list = []   # [{"x": float, "z": float, "type": str}]
hole_cool        = 0
prev_gps_xy: Optional[tuple] = None   # GPS bruto do step anterior para detetar teleportação

kf_trail:           list = []
kf_gps_hist:        list = []
_last_lidar_ranges: list = []   # cached every step for the KF viewer

random.seed(42)

# ════════════════════════════════════════════════════════════════════════════════
# LOOP PRINCIPAL
# ════════════════════════════════════════════════════════════════════════════════

while robot.step(TS) != -1:
    step_count += 1

    # ── GPS bruto antes do KF (para detetar teleportação) ─────────────────────
    _raw = gps.getValues() if gps else None
    cur_gps_xy = (_raw[0], _raw[2]) \
        if _raw and not any(math.isnan(v) for v in _raw) else None

    # ── Actualizar KF ─────────────────────────────────────────────────────────
    cur_el = enc_l.getValue() if enc_l else 0.0
    cur_er = enc_r.getValue() if enc_r else 0.0
    _kf_update(cur_el, cur_er)

    # ── Deteção de teleportação (buraco sem sensor escuro) ────────────────────
    if (cur_gps_xy is not None and prev_gps_xy is not None
            and hole_cool == 0):
        _jump = math.hypot(cur_gps_xy[0] - prev_gps_xy[0],
                           cur_gps_xy[1] - prev_gps_xy[1])
        if _jump > TELEPORT_THRESH:
            hx, hz = prev_gps_xy
            print(f"[BURACO] Teleportação! salto={_jump:.2f}m  "
                  f"buraco≈({hx:.2f}, {hz:.2f})")
            grid.mark_obstacle(hx, hz)
            hole_cool    = TELEPORT_COOL_N
            gps_stuck    = enc_stuck = spin_stuck = 0
            gps_stuck_base_p = None
            steer_smooth = 0.0
            p3_hold      = 0
            turn_lock    = 0
            turn_lock_dir = 0
            nav_hdg      = None
            rotate_deg(180.0)
            nav_hdg = estimated_heading()
    prev_gps_xy = cur_gps_xy

    # ── Ler lidar ─────────────────────────────────────────────────────────────
    d       = read_lidar()
    front   = d["front"]
    front_l = d["front_l"]
    front_r = d["front_r"]
    left    = d["left"]
    right   = d["right"]

    front_diff  = front_l - front_r
    is_corridor = abs(front_diff) > 0.12 and front < D_FRONT_TURN

    # ── Actualizar mapa ───────────────────────────────────────────────────────
    if step_count % MAP_UPDATE_N == 0 and lidar:
        ranges = lidar.getLayerRangeImage(LIDAR_MAP_LAYER)
        if ranges:
            pos = estimated_pos()
            hdg = estimated_heading()
            if pos:
                # Alinhamento de scan (Scan Matching) contra o mapa existente
                corr_pos, corr_hdg = grid.scan_match(pos[0], pos[1], hdg, ranges, LIDAR_N,
                                                     LIDAR_FRONT_IDX, LIDAR_CCW, LIDAR_MAX_RANGE)
                
                # Calcular correção aplicada para diagnóstico interno
                dx = corr_pos[0] - pos[0]
                dz = corr_pos[1] - pos[1]
                dh = corr_hdg - hdg
                dh = ((dh + math.pi) % (2 * math.pi)) - math.pi
                
                # Se a correção for aceita (diferente da pose anterior), atualiza o EKF suavemente (soft update)
                # Isso amortece a transição e elimina oscilações violentas
                if abs(dx) > 1e-5 or abs(dz) > 1e-5 or abs(dh) > 1e-5:
                    alpha = 0.3
                    if kf is not None:
                        kf.state[0] += alpha * dx
                        kf.state[1] += alpha * dz
                        kf.state[2] = ((kf.state[2] + alpha * dh + math.pi) % (2 * math.pi)) - math.pi
                    pos = (pos[0] + alpha * dx, pos[1] + alpha * dz)
                    hdg = ((hdg + alpha * dh + math.pi) % (2 * math.pi)) - math.pi
                
                # Desenhar/atualizar o mapa com a pose alinhada
                grid.update(pos[0], pos[1], hdg, ranges, LIDAR_N,
                            LIDAR_FRONT_IDX, LIDAR_CCW, LIDAR_MAX_RANGE)

    if MAP_PRINT_N > 0 and step_count % MAP_PRINT_N == 0:
        pos = estimated_pos()
        grid.print_ascii(pos[0] if pos else None,
                         pos[1] if pos else None)
        if kf:
            print(f"[KF] step={step_count}  "
                  f"pos=({kf.pos[0]:.3f}, {kf.pos[1]:.3f})  "
                  f"θ={math.degrees(kf.heading):.1f}°  "
                  f"σ_pos={kf.std_pos*100:.1f} cm  "
                  f"σ_θ={math.degrees(kf.std_heading):.2f}°")

    # ── Log do KF para o visualizador ─────────────────────────────────────────
    if step_count % KF_LOG_EVERY == 0:
        _write_kf_state()

    # ── Posição para anti-stuck (usa KF) ──────────────────────────────────────
    cur_p = estimated_pos()

    # ── Anti-stuck: actualizar contadores ────────────────────────────────────
    if cool > 0:
        cool      -= 1
        gps_stuck  = enc_stuck = spin_stuck = 0
        gps_stuck_base_p = None
        last_p     = cur_p
        last_enc_l = cur_el
        last_enc_r = cur_er
    else:
        prev_p = last_p
        if cur_p is not None:
            if gps_stuck_base_p is None:
                gps_stuck_base_p = cur_p
            dist_from_base = math.hypot(cur_p[0] - gps_stuck_base_p[0], cur_p[1] - gps_stuck_base_p[1])
            if dist_from_base >= 0.015:
                gps_stuck = 0
                spin_stuck = 0
                gps_stuck_base_p = cur_p
            else:
                gps_stuck += 1
                if last_enc_l is not None:
                    enc_moving = (abs(cur_el - last_enc_l) + abs(cur_er - last_enc_r)) / 2.0
                    if enc_moving > ENC_MIN_RAD * 2:
                        spin_stuck += 1
                    else:
                        spin_stuck = 0

        if last_enc_l is not None:
            enc_moving = (abs(cur_el - last_enc_l) + abs(cur_er - last_enc_r)) / 2.0
            enc_stuck  = enc_stuck + 1 if enc_moving < ENC_MIN_RAD else 0

        last_p = cur_p
        last_enc_l = cur_el
        last_enc_r = cur_er

    # ── Anti-stuck: disparar escape ───────────────────────────────────────────
    trigger = None
    if gps_stuck  >= GPS_STUCK_N: trigger = "GPS"
    if enc_stuck  >= ENC_STUCK_N: trigger = "encoder"
    if spin_stuck >= SPIN_N:      trigger = "spinning"

    if trigger:
        esc_n        += 1
        gps_stuck     = enc_stuck = spin_stuck = 0
        gps_stuck_base_p = None
        cool          = COOL_N
        steer_smooth  = 0.0
        p3_hold       = 0
        turn_lock     = 0
        turn_lock_dir = 0
        nav_hdg       = None
        last_p        = do_escape(trigger, left, right, esc_n)
        nav_hdg       = estimated_heading()
        last_enc_l    = enc_l.getValue() if enc_l else 0.0
        last_enc_r    = enc_r.getValue() if enc_r else 0.0
        continue

    # ── Deteção de buracos ────────────────────────────────────────────────────
    if hole_cool > 0:
        hole_cool -= 1
    elif is_hole():
        escape_hole()
        gps_stuck = enc_stuck = spin_stuck = 0
        gps_stuck_base_p = None
        steer_smooth  = 0.0
        p3_hold       = 0
        turn_lock     = 0
        turn_lock_dir = 0
        nav_hdg       = estimated_heading()
        hole_cool     = HOLE_COOL_N
        continue

    # ── Deteção de vítimas ────────────────────────────────────────────────────
    if step_count % SCAN_EVERY == 0:
        analyze_camera(step_count, reported_victims)

    # ════════════════════════════════════════════════════════════════════════════
    # COMPORTAMENTOS DE NAVEGAÇÃO (P1 → P4)
    # ════════════════════════════════════════════════════════════════════════════

    # P1 — parede muito perto em frente: girar no eixo
    if front < D_FRONT_STOP or turn_lock > 0:
        if front < D_FRONT_STOP:
            if turn_lock <= 0:
                turn_lock_dir = 1 if left > right else -1
                nav_hdg = None          # nova parede → descarta heading anterior
            turn_lock = P1_LOCK_STEPS
        else:
            turn_lock -= 1
            if turn_lock == 0:          # rotação terminou → fixa novo heading
                nav_hdg = estimated_heading()
        steer_smooth = 0.0
        p3_hold      = 0
        drive(-TURN_V, TURN_V) if turn_lock_dir == 1 else drive(TURN_V, -TURN_V)
        continue

    # P2 — parede lateral urgente (suprimido quando frente livre)
    if front < D_SIDE_ACTIVE:
        if left < D_SIDE_PUSH:
            steer_smooth = p3_hold = 0
            push = (D_SIDE_PUSH - left) / D_SIDE_PUSH
            drive(FWD_V, FWD_V * (1.0 - push * 1.5))
            continue
        if right < D_SIDE_PUSH:
            steer_smooth = p3_hold = 0
            push = (D_SIDE_PUSH - right) / D_SIDE_PUSH
            drive(FWD_V * (1.0 - push * 1.5), FWD_V)
            continue

    # P3 — parede a aproximar: desviar enquanto avança
    if front < D_FRONT_TURN or p3_hold > 0:
        p3_hold      = P3_MIN_STEPS if front < D_FRONT_TURN else p3_hold - 1
        nav_hdg      = None             # heading re-adquirido quando P4 regressar
        steer_dir    = (1 if front_diff > 0 else -1) if is_corridor else \
                       (1 if left > right else -1)
        ratio        = (max(front, D_FRONT_STOP) - D_FRONT_STOP) / (D_FRONT_TURN - D_FRONT_STOP)
        steer_smooth = 0.7 * steer_smooth + 0.3 * (1.0 - ratio) * TURN_V
        drive(FWD_V - steer_smooth, FWD_V + steer_smooth) if steer_dir == 1 \
            else drive(FWD_V + steer_smooth, FWD_V - steer_smooth)
        continue

    # P4 — livre: avança com controlo de heading pelo IMU/KF
    steer_smooth = 0.0
    if imu is not None or kf is not None:
        if nav_hdg is None:
            nav_hdg = estimated_heading()
        err  = adiff(nav_hdg, estimated_heading())
        corr = max(-HDG_MAX_CORR, min(HDG_MAX_CORR, err * HDG_GAIN))
        drive(FWD_V - corr, FWD_V + corr)
    else:
        drive(FWD_V, FWD_V)
