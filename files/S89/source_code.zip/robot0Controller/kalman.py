"""
Filtro de Kalman Estendido (EKF) para estimativa de pose 2D do robot.

Estado: [x, z, θ]
  x, z — posição no plano horizontal (metros, coordenadas Webots)
  θ    — heading/yaw (radianos, do IMU)

Predição:  cinemática de tração diferencial a partir dos deltas dos encoders.
Correções: GPS (x, z) e IMU (θ) como medições independentes.

Parâmetros físicos do robot (medidos na PROTO):
  WHEEL_RADIUS = 0.020 m  (raio da roda: cylinder radius 0.02 m)
  WHEEL_BASE   = 0.052 m  (distância entre rodas: wheels at ±0.026 m on X)
"""

import math
from typing import Tuple

# ── Parâmetros físicos ────────────────────────────────────────────────────────

WHEEL_RADIUS = 0.020   # metros
WHEEL_BASE   = 0.052   # metros

# ── Álgebra linear 3×3 em Python puro (evita dependência de numpy) ────────────

def _mm(A, B):
    """Multiplicação de matrizes 3×3."""
    return [
        [sum(A[i][k] * B[k][j] for k in range(3)) for j in range(3)]
        for i in range(3)
    ]


def _add(A, B):
    return [[A[i][j] + B[i][j] for j in range(3)] for i in range(3)]


def _sub(A, B):
    return [[A[i][j] - B[i][j] for j in range(3)] for i in range(3)]


def _T(A):
    return [[A[j][i] for j in range(3)] for i in range(3)]


def _eye():
    return [[1.0 if i == j else 0.0 for j in range(3)] for i in range(3)]


def _outer(v, w):
    """Produto externo de dois vetores 3D → matriz 3×3."""
    return [[v[i] * w[j] for j in range(3)] for i in range(3)]


def _inv2(M):
    """Inversa de uma matriz 2×2."""
    a, b, c, d = M[0][0], M[0][1], M[1][0], M[1][1]
    det = a * d - b * c
    det = det if abs(det) > 1e-12 else 1e-12
    return [[d / det, -b / det], [-c / det, a / det]]


def _wrap(a: float) -> float:
    return ((a + math.pi) % (2 * math.pi)) - math.pi


# ── Classe principal ──────────────────────────────────────────────────────────

class KalmanPose:
    """
    EKF para pose 2D do robot: estado = [x, z, θ].

    Exemplo de uso:
        kf = KalmanPose(x0, z0, theta0)
        # cada step:
        kf.predict(delta_enc_l, delta_enc_r)
        kf.update_imu(imu.getRollPitchYaw()[2])
        kf.update_gps(gps.getValues()[0], gps.getValues()[2])
        pos  = kf.pos      # (x, z) estimado
        hdng = kf.heading  # θ estimado
    """

    def __init__(self, x0: float = 0.0, z0: float = 0.0,
                 theta0: float = 0.0,
                 wheel_radius: float = WHEEL_RADIUS,
                 wheel_base: float   = WHEEL_BASE):

        self.state = [x0, z0, theta0]

        # Covariância inicial — incerteza moderada
        self.P: list = [
            [0.50, 0.00, 0.00],
            [0.00, 0.50, 0.00],
            [0.00, 0.00, 0.10],
        ]

        # Ruído de processo Q — incerteza acumulada no modelo de movimento
        self.Q: list = [
            [4e-4, 0.00, 0.00],
            [0.00, 4e-4, 0.00],
            [0.00, 0.00, 1e-4],
        ]

        # Ruído de medição GPS — aumentado para Erebus v26 (GPS com ruído)
        self.R_gps: list = [
            [0.04, 0.00],
            [0.00, 0.04],
        ]

        # Ruído de medição IMU — IMU é extremamente fiável no simulador
        self.R_imu: float = 1e-7

        self.r = wheel_radius
        self.b = wheel_base

    # ── Predição ──────────────────────────────────────────────────────────────

    def predict(self, delta_enc_l: float, delta_enc_r: float) -> None:
        """
        Passo de predição com cinemática diferencial.

        delta_enc_l, delta_enc_r: deslocamento angular dos encoders (rad)
            Obtidos como: cur_enc - prev_enc (de getDevice("wheel1 sensor"))
        """
        dl = delta_enc_l * self.r   # arco da roda esquerda (m)
        dr = delta_enc_r * self.r   # arco da roda direita  (m)
        dc = (dl + dr) / 2.0        # deslocamento linear central (m)
        dθ = (dr - dl) / self.b     # variação de heading (rad)

        x, z, θ = self.state
        mid = θ + dθ / 2.0

        self.state = [
            x + dc * math.cos(mid),
            z - dc * math.sin(mid),
            _wrap(θ + dθ),
        ]

        # Jacobiano F da transição de estado
        F = [
            [1.0, 0.0, -dc * math.sin(mid)],
            [0.0, 1.0, -dc * math.cos(mid)],
            [0.0, 0.0,  1.0],
        ]

        self.P = _add(_mm(_mm(F, self.P), _T(F)), self.Q)

    # ── Correções ─────────────────────────────────────────────────────────────

    def update_gps(self, gps_x: float, gps_z: float) -> None:
        """
        Correção com medição GPS (x, z) em metros.
        Modelo de observação: H = [[1,0,0],[0,1,0]]
        """
        x, z, _ = self.state
        y = [gps_x - x, gps_z - z]

        # S = H P H^T + R_gps  →  top-left 2×2 de P + R_gps
        S = [
            [self.P[0][0] + self.R_gps[0][0], self.P[0][1] + self.R_gps[0][1]],
            [self.P[1][0] + self.R_gps[1][0], self.P[1][1] + self.R_gps[1][1]],
        ]
        S_inv = _inv2(S)

        # K = P H^T S^{-1}  (3×2)
        PH = [[self.P[i][0], self.P[i][1]] for i in range(3)]
        K  = [[sum(PH[i][k] * S_inv[k][j] for k in range(2)) for j in range(2)]
              for i in range(3)]

        for i in range(3):
            self.state[i] += K[i][0] * y[0] + K[i][1] * y[1]
        self.state[2] = _wrap(self.state[2])

        # P = (I - K H) P
        KH = [[K[i][j] if j < 2 else 0.0 for j in range(3)] for i in range(3)]
        self.P = _mm(_sub(_eye(), KH), self.P)

    def update_imu(self, imu_theta: float) -> None:
        """
        Correção com medição de heading do IMU (radianos).
        Modelo de observação: H = [0, 0, 1]
        """
        innov = _wrap(imu_theta - self.state[2])
        S = self.P[2][2] + self.R_imu
        if abs(S) < 1e-12:
            return

        K = [self.P[i][2] / S for i in range(3)]
        for i in range(3):
            self.state[i] += K[i] * innov
        self.state[2] = _wrap(self.state[2])

        KH = _outer(K, [0.0, 0.0, 1.0])
        self.P = _mm(_sub(_eye(), KH), self.P)

    # ── Propriedades ──────────────────────────────────────────────────────────

    @property
    def pos(self) -> Tuple[float, float]:
        """Posição estimada (x, z) em metros."""
        return (self.state[0], self.state[1])

    @property
    def heading(self) -> float:
        """Heading estimado θ em radianos."""
        return self.state[2]

    @property
    def std_pos(self) -> float:
        """Desvio padrão de posição em metros (raiz do traço de P_xy)."""
        return math.sqrt(self.P[0][0] + self.P[1][1])

    @property
    def std_heading(self) -> float:
        """Desvio padrão do heading em radianos."""
        return math.sqrt(abs(self.P[2][2]))
