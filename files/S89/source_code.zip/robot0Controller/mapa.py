"""
Mapeamento por grelha de ocupação (occupancy grid) com log-odds.

Cada célula da grelha guarda um valor de log-odds:
  > OCC_THRESH  → parede/obstáculo
  < FREE_THRESH → espaço livre
  ≈ 0           → desconhecido (não explorado)

Atualização incremental a partir de scans do lidar 360°.
Exportação no formato de submissão do Erebus via to_erebus_bytes().
"""

import math
import struct
from typing import Optional, Tuple

import numpy as np

# ── Parâmetros de log-odds ────────────────────────────────────────────────────

L_OCC  =  1.2    # incremento por leitura de obstáculo (bloqueia em 2 hits)
L_FREE = -0.3    # decremento por raio livre (menos agressivo que -0.4)
L_MAX  =  4.0    # saturação (evita sobreconfiança)

OCC_THRESH  =  0.5   # acima disto → célula ocupada (para visualização/consulta)
FREE_THRESH = -0.2   # abaixo disto → célula livre
LOCK_THRESH =  2.0   # acima disto → célula confirmada (imune a raios livres; ~3 hits)
MIN_RANGE   =  0.02  # permite detetar paredes muito próximas (chassi tem de estar excluído ou não visível)


class OccupancyGrid:
    """
    Grelha de ocupação 2D com log-odds, actualizada por scans do lidar.

    Resolução recomendada: 0.05 m/célula.
    Tamanho recomendado: 6.0 m × 6.0 m (120×120 células).

    Exemplo de uso:
        grid = OccupancyGrid()
        # cada scan:
        grid.update(kf.pos[0], kf.pos[1], kf.heading,
                    lidar.getRangeImage(), LIDAR_N,
                    LIDAR_FRONT_IDX, LIDAR_CCW)
        # ao detetar vítima:
        grid.mark_victim(kf.pos[0], kf.pos[1], 'H')
        # debug:
        grid.print_ascii(kf.pos[0], kf.pos[1])
        # submissão ao supervisor:
        emitter.send(grid.to_erebus_bytes())
        emitter.send(struct.pack('c', b'M'))
    """

    def __init__(self, resolution: float = 0.05, size_m: float = 6.0):
        self.res    = resolution
        self.n      = int(size_m / resolution)
        self.origin = size_m / 2.0           # offset: world(0,0) → grid centre
        self.grid   = np.zeros((self.n, self.n), dtype=np.float32)
        self.victims: dict = {}              # (row, col) → char de vítima/hazmat
        print(f"  [MAPA] {self.n}×{self.n} células  "
              f"({self.n * self.res:.1f} m × {self.n * self.res:.1f} m)  "
              f"resolução {self.res * 100:.0f} cm/cel")

    # ── Coordenadas ───────────────────────────────────────────────────────────

    def _to_grid(self, x: float, z: float) -> Tuple[int, int]:
        col = int((x + self.origin) / self.res)
        row = int((z + self.origin) / self.res)
        return row, col

    def _valid(self, row: int, col: int) -> bool:
        return 0 <= row < self.n and 0 <= col < self.n

    # ── Alinhamento de Scan (Scan Matching) ───────────────────────────────────

    def scan_match(self, robot_x: float, robot_z: float, robot_theta: float,
                   ranges, lidar_n: int,
                   front_idx: int = 0, ccw: int = 1,
                   lidar_max: float = 1.0) -> Tuple[Tuple[float, float], float]:
        """
        Realiza o alinhamento do scan atual do LiDAR com o mapa de ocupação existente
        para corrigir a pose estimada do robô (x, z, theta).
        Retorna a pose corrigida ((x_corr, z_corr), theta_corr).
        """
        # Converter ranges para array numpy
        ranges = np.array(ranges, dtype=np.float32)
        
        # Filtro de leituras válidas (evita ruídos e infinito)
        indices = np.arange(len(ranges))
        valid_mask = np.isfinite(ranges) & (ranges >= MIN_RANGE) & (ranges < lidar_max * 0.98)
        
        if np.sum(valid_mask) < 15:
            # Se não houver pontos válidos suficientes, mantém a pose anterior
            return (robot_x, robot_z), robot_theta
            
        valid_ranges = ranges[valid_mask]
        valid_indices = indices[valid_mask]
        
        # Calcular os ângulos de cada feixe no referencial global
        angles_robot = ((valid_indices - front_idx) % lidar_n) * (2 * np.pi / lidar_n) * ccw
        angles_world = robot_theta + angles_robot
        
        # Coordenadas locais dos pontos no referencial do robô
        local_x = valid_ranges * np.cos(angles_robot)
        local_z = -valid_ranges * np.sin(angles_robot)
        
        # Verificar se há paredes suficientes mapeadas para fazer o alinhamento
        # Se o mapa estiver muito vazio, não há referências para alinhar
        occupied_cells = np.sum(self.grid > OCC_THRESH)
        if occupied_cells < 20:
            return (robot_x, robot_z), robot_theta
            
        # Calcular a sobreposição inicial para verificar se há contato com o mapa
        init_cos = np.cos(robot_theta)
        init_sin = np.sin(robot_theta)
        init_xw = robot_x + local_x * init_cos + local_z * init_sin
        init_zw = robot_z - local_x * init_sin + local_z * init_cos
        
        init_cols = ((init_xw + self.origin) / self.res).astype(np.int32)
        init_rows = ((init_zw + self.origin) / self.res).astype(np.int32)
        
        init_in_bounds = (init_rows >= 0) & (init_rows < self.n) & (init_cols >= 0) & (init_cols < self.n)
        
        if np.sum(init_in_bounds) > 0:
            init_vals = self.grid[init_rows[init_in_bounds], init_cols[init_in_bounds]]
            overlap = np.sum(init_vals > OCC_THRESH)
        else:
            overlap = 0
            
        if overlap < 8:
            # Sem sobreposição suficiente com as paredes conhecidas do mapa
            return (robot_x, robot_z), robot_theta
            
        # Definir espaço de busca coarse (grosseiro)
        # Limitar a translação a +-4cm para evitar falsos alinhamentos com tiles vizinhos (escala física de 12cm/tile)
        dx_coarse = np.linspace(-0.04, 0.04, 9)
        dz_coarse = np.linspace(-0.04, 0.04, 9)
        dtheta_coarse = np.radians(np.linspace(-6.0, 6.0, 9))
        
        # Gerar todas as combinações de busca
        grid_dx, grid_dz, grid_dtheta = np.meshgrid(dx_coarse, dz_coarse, dtheta_coarse, indexing='ij')
        candidates = np.stack([grid_dx.ravel(), grid_dz.ravel(), grid_dtheta.ravel()], axis=-1)
        
        # Avaliar candidatos coarse
        scores_coarse = self._evaluate_candidates(candidates, robot_x, robot_z, robot_theta, local_x, local_z)
        best_idx = np.argmax(scores_coarse)
        best_score = scores_coarse[best_idx]
        best_dx, best_dz, best_dtheta = candidates[best_idx]
        
        # Definir espaço de busca fine (refinado) em torno do melhor candidato coarse
        dx_fine = np.linspace(best_dx - 0.01, best_dx + 0.01, 9)
        dz_fine = np.linspace(best_dz - 0.01, best_dz + 0.01, 9)
        dtheta_fine = np.radians(np.linspace(np.degrees(best_dtheta) - 1.5, np.degrees(best_dtheta) + 1.5, 9))
        
        grid_dx_f, grid_dz_f, grid_dtheta_f = np.meshgrid(dx_fine, dz_fine, dtheta_fine, indexing='ij')
        candidates_fine = np.stack([grid_dx_f.ravel(), grid_dz_f.ravel(), grid_dtheta_f.ravel()], axis=-1)
        
        # Avaliar candidatos fine
        scores_fine = self._evaluate_candidates(candidates_fine, robot_x, robot_z, robot_theta, local_x, local_z)
        best_idx_fine = np.argmax(scores_fine)
        if scores_fine[best_idx_fine] > best_score:
            best_score = scores_fine[best_idx_fine]
            best_dx, best_dz, best_dtheta = candidates_fine[best_idx_fine]
            
        # Calcular score da pose original (sem deslocamento)
        prior_score = self._evaluate_candidates(np.array([[0.0, 0.0, 0.0]], dtype=np.float32), 
                                                robot_x, robot_z, robot_theta, local_x, local_z)[0]
                                                
        # Se a melhor pose encontrada for pior ou igual à pose original, mantém a original
        if best_score <= prior_score:
            return (robot_x, robot_z), robot_theta
            
        # Retorna a pose corrigida
        corrected_x = robot_x + best_dx
        corrected_z = robot_z + best_dz
        corrected_theta = ((robot_theta + best_dtheta + np.pi) % (2 * np.pi)) - np.pi
        
        return (corrected_x, corrected_z), corrected_theta

    def _evaluate_candidates(self, candidates: np.ndarray, robot_x: float, robot_z: float, robot_theta: float,
                             local_x: np.ndarray, local_z: np.ndarray) -> np.ndarray:
        """
        Função auxiliar vetorizada para avaliar um conjunto de poses candidatas.
        """
        C = candidates.shape[0]
        dx = candidates[:, 0:1]  # (C, 1)
        dz = candidates[:, 1:2]  # (C, 1)
        dtheta = candidates[:, 2:3]  # (C, 1)
        
        cos_t = np.cos(robot_theta + dtheta)
        sin_t = np.sin(robot_theta + dtheta)
        
        # Projetar coordenadas no referencial do mundo para cada candidato: (C, M)
        xw = (robot_x + dx) + local_x[np.newaxis, :] * cos_t + local_z[np.newaxis, :] * sin_t
        zw = (robot_z + dz) - local_x[np.newaxis, :] * sin_t + local_z[np.newaxis, :] * cos_t
        
        # Converter para coordenadas da grelha (pixels)
        cols = ((xw + self.origin) / self.res).astype(np.int32)
        rows = ((zw + self.origin) / self.res).astype(np.int32)
        
        # Máscara de limites da grelha
        in_bounds = (rows >= 0) & (rows < self.n) & (cols >= 0) & (cols < self.n)
        
        safe_rows = np.clip(rows, 0, self.n - 1)
        safe_cols = np.clip(cols, 0, self.n - 1)
        
        grid_vals = self.grid[safe_rows, safe_cols]
        
        # Penalizar fortemente pontos fora dos limites (equivalente a espaço livre)
        grid_vals[~in_bounds] = -2.0
        
        # Calcular pontuação:
        # - Células ocupadas (> OCC_THRESH) dão pontos positivos (valor de log-odds)
        # - Células livres (< FREE_THRESH) dão penalidade (metade do log-odds para suavizar)
        # - Células desconhecidas dão 0
        pos_scores = np.sum(np.where(grid_vals > OCC_THRESH, grid_vals, 0.0), axis=1)
        neg_scores = np.sum(np.where(grid_vals < FREE_THRESH, grid_vals * 0.5, 0.0), axis=1)
        
        # Penalização por afastamento da pose anterior (regularização L2/MAP)
        # Evita saltar em direções sem características (como ao longo de corredores)
        dx_val = candidates[:, 0]
        dz_val = candidates[:, 1]
        dtheta_val = candidates[:, 2]
        prior_penalty = 2000.0 * (dx_val**2 + dz_val**2) + 600.0 * (dtheta_val**2)
        
        return pos_scores + neg_scores - prior_penalty

    # ── Actualização ──────────────────────────────────────────────────────────

    def update(self, robot_x: float, robot_z: float, robot_theta: float,
               ranges, lidar_n: int,
               front_idx: int = 0, ccw: int = 1,
               lidar_max: float = 1.0,
               max_range_frac: float = 0.99) -> None:
        """
        Actualiza a grelha com um scan completo do lidar.

        robot_x, robot_z  — posição estimada pelo KF (metros)
        robot_theta       — heading estimado pelo KF (radianos)
        ranges            — lista de distâncias do lidar (getRangeImage())
        lidar_n           — número de pontos horizontais (getHorizontalResolution())
        front_idx         — índice que aponta para a frente (LIDAR_FRONT_IDX)
        ccw               — direcção de rotação do scan (LIDAR_CCW)
        lidar_max         — alcance máximo do lidar (getMaxRange())
        max_range_frac    — leituras ≥ lidar_max × frac → sem obstáculo (ignora ruído)
        """
        cutoff = lidar_max * max_range_frac

        for i, dist in enumerate(ranges):
            # Ângulo deste raio no referencial do robot
            angle_robot = ((i - front_idx) % lidar_n) * (2 * math.pi / lidar_n) * ccw
            angle_world = robot_theta + angle_robot
            cos_a = math.cos(angle_world)
            sin_a = math.sin(angle_world)

            if not math.isfinite(dist) or dist < MIN_RANGE:
                continue

            if dist >= cutoff:
                # Sem obstáculo no alcance: marca o raio como livre
                self._free_ray(robot_x, robot_z, cos_a, sin_a, cutoff)
            else:
                # Marca o raio como livre até ao obstáculo e a célula final como ocupada
                end_r, end_c = self._to_grid(robot_x + dist * cos_a,
                                             robot_z - dist * sin_a)
                self._free_ray(robot_x, robot_z, cos_a, sin_a, dist, end_cell=(end_r, end_c))
                if self._valid(end_r, end_c):
                    self.grid[end_r, end_c] = min(L_MAX,
                                                   self.grid[end_r, end_c] + L_OCC)

    def _free_ray(self, x0: float, z0: float,
                   cos_a: float, sin_a: float, length: float,
                   end_cell: Optional[Tuple[int, int]] = None) -> None:
        """Marca células ao longo do raio como livres (log-odds decrementa por L_FREE)."""
        # Usamos passo de metade da resolução para evitar pular células diagonalmente
        step_size = self.res * 0.5
        n_steps = max(1, int(length / step_size))
        for s in range(n_steps):
            t = s * step_size
            row, col = self._to_grid(x0 + t * cos_a, z0 - t * sin_a)
            if end_cell and (row, col) == end_cell:
                break
            if self._valid(row, col):
                # Células confirmadas (>= LOCK_THRESH) são imunes a raios livres.
                if float(self.grid[row, col]) < LOCK_THRESH:
                    self.grid[row, col] = max(-L_MAX,
                                              self.grid[row, col] + L_FREE)

    def mark_victim(self, x: float, z: float, victim_type: str) -> None:
        """Regista uma vítima ou hazmat na posição dada."""
        row, col = self._to_grid(x, z)
        self.victims[(row, col)] = victim_type

    def mark_obstacle(self, x: float, z: float,
                      radius_m: float = 0.20) -> None:
        """Satura células em torno de (x, z) a L_MAX (buraco/zona proibida)."""
        r_cells = max(1, int(radius_m / self.res))
        rc, cc  = self._to_grid(x, z)
        for dr in range(-r_cells, r_cells + 1):
            for dc in range(-r_cells, r_cells + 1):
                row, col = rc + dr, cc + dc
                if self._valid(row, col):
                    self.grid[row, col] = L_MAX

    # ── Consultas ─────────────────────────────────────────────────────────────

    def is_occupied(self, x: float, z: float) -> bool:
        row, col = self._to_grid(x, z)
        if self._valid(row, col):
            return float(self.grid[row, col]) > OCC_THRESH
        return False

    def occupancy_prob(self, x: float, z: float) -> float:
        """Probabilidade de ocupação em [0, 1]."""
        row, col = self._to_grid(x, z)
        if self._valid(row, col):
            lo = float(self.grid[row, col])
            return 1.0 / (1.0 + math.exp(-lo))
        return 0.5

    # ── Exportação Erebus ─────────────────────────────────────────────────────

    def to_erebus_bytes(self) -> bytes:
        """
        Converte a grelha para o formato de submissão do Erebus.

        Formato esperado pelo supervisor:
            struct.pack('2i', rows, cols)  — dimensões da matriz
            + ','.join(flat).encode()      — células separadas por vírgulas

        Células: '1' = parede, '0' = livre/desconhecido.
        Depois de enviar estes bytes, envia struct.pack('c', b'M') para pedir avaliação.
        """
        # Submissão à resolução de 0.1 m/célula (padrão Erebus)
        erebus_res = 0.10
        scale      = max(1, int(erebus_res / self.res))
        n_out      = self.n // scale

        out = np.full((n_out, n_out), '0', dtype='<U1')

        for r in range(n_out):
            for c in range(n_out):
                block = self.grid[r * scale:(r + 1) * scale,
                                   c * scale:(c + 1) * scale]
                if block.max() > OCC_THRESH:
                    out[r, c] = '1'

        for (row, col), vtype in self.victims.items():
            er, ec = row // scale, col // scale
            if 0 <= er < n_out and 0 <= ec < n_out:
                out[er, ec] = vtype

        s_bytes = struct.pack('2i', n_out, n_out)
        return s_bytes + ','.join(out.flatten()).encode('utf-8')

    # ── Exportação para visualizador externo ─────────────────────────────────

    def viewer_cells(self, subsample: int = 1) -> list:
        """Lista [[x, z], ...] das células ocupadas (para kf_viewer.py)."""
        cells = []
        for r in range(0, self.n, subsample):
            for c in range(0, self.n, subsample):
                if float(self.grid[r, c]) > OCC_THRESH:
                    wx = c * self.res - self.origin
                    wz = r * self.res - self.origin
                    cells.append([wx, wz])
        return cells

    # ── Visualização ──────────────────────────────────────────────────────────

    def print_ascii(self, robot_x: Optional[float] = None,
                     robot_z: Optional[float] = None,
                     view_m: float = 1.5) -> None:
        """
        Imprime uma representação ASCII da grelha em torno do robot.
        Legenda: █=parede  ·=livre  R=robot  V=vítima  espaço=desconhecido
        """
        if robot_x is None:
            rc = cc = self.n // 2
        else:
            rc, cc = self._to_grid(robot_x, robot_z)

        half = max(1, int(view_m / self.res))
        rmin, rmax = max(0, rc - half), min(self.n, rc + half)
        cmin, cmax = max(0, cc - half), min(self.n, cc + half)
        width = cmax - cmin

        print("┌" + "─" * width + "┐")
        for r in range(rmin, rmax, 2):
            row_str = "│"
            for c in range(cmin, cmax):
                has_robot = (robot_x is not None and
                             (abs(r - rc) <= 1 or (r + 1 < self.n and abs(r + 1 - rc) <= 1)) and
                             abs(c - cc) <= 1)
                has_victim = ((r, c) in self.victims or
                              (r + 1 < self.n and (r + 1, c) in self.victims))
                has_wall = (float(self.grid[r, c]) > OCC_THRESH or
                            (r + 1 < self.n and float(self.grid[r + 1, c]) > OCC_THRESH))
                has_free = (float(self.grid[r, c]) < FREE_THRESH or
                            (r + 1 < self.n and float(self.grid[r + 1, c]) < FREE_THRESH))

                if has_robot:
                    row_str += "R"
                elif has_victim:
                    row_str += "V"
                elif has_wall:
                    row_str += "█"
                elif has_free:
                    row_str += "·"
                else:
                    row_str += " "
            print(row_str + "│")
        print("└" + "─" * width + "┘")
