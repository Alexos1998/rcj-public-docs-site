/*
  比例制御とカラー

  v0: 比例制御にカラー検知とジャイロを追加
  v1: カラ検知をカウント制御に
*/

#include <Servo.h>
#include <Wire.h>

// ========== 定数宣言 ==========
// ラインセンサ
const byte LINE_RR_PIN = A0;        // ラインセンサ右端
const byte LINE_R_PIN = A1;         // ラインセンサ右
const byte LINE_C_PIN = A2;         // ラインセンサ中央
const byte LINE_L_PIN = A3;         // ラインセンサ左
const byte LINE_LL_PIN = A6;        // ラインセンサ左端

// タッチセンサ
const byte TOUCH_SW_PIN = 5;         // タッチセンサ

// 超音波センサ
const byte PING_R_PIN = 7;          // 超音波センサ右
const byte PING_L_PIN = 6;          // 超音波センサ左

// モータドライバ
const byte MOTOR_L_PIN = 9;         // MD-1 左
const byte MOTOR_R_PIN = 8;         // MD-1 右
const int16_t MOTOR_OFFSET = 4;        // ESCオフセット

// LED
const byte LED_L_PIN = 11;          // 超高輝度緑色
const byte LED_C_PIN = 12;          // 超高輝度赤色
const byte LED_R_PIN = 13;          // 超高輝度緑色

// スイッチ
const byte START_SW_PIN = 10;        // オンボードスタートSW

// ========== 変数宣言　==========
float P_Gain = 0.1; // 比例制御のゲイン
int Bease_Power = 15, Min_Power = -15, Max_Power = 15; // モータの速度設定
int Line_R_Value, Line_L_Value, Line_C_Value, Line_Diff; // ラインセンサの値
int Motor_L_Value, Motor_R_Value; // モータの速度
int Line_Out;
int Green_L_Count, Green_R_Count;

int Color_L, Color_R;

// サーボのインスタンス作成
Servo MD1_L;
Servo MD1_R;

// ========== プロトタイプ宣言 ==========
void colorGetRGB(int *r, int *g, int *b, char *side, bool print_value = false);
void colorGetHSV(int *h, float *s, int *v, char *side, bool print_value = false);
//char *colorGet(char *side, bool print_value = false);

void setup()
{
  // GPIO設定
  pinMode(MOTOR_L_PIN, OUTPUT);
  pinMode(MOTOR_R_PIN, OUTPUT);
  pinMode(START_SW_PIN, INPUT_PULLUP);

  delay(3000);

  // サーボ設定
  MD1_L.attach(MOTOR_L_PIN);
  MD1_R.attach(MOTOR_R_PIN);
  MD1_L.write(90 + MOTOR_OFFSET);
  MD1_R.write(90 + MOTOR_OFFSET);

  Serial.begin(9600); // シリアル通信のデータ転送レート
  colorSetup(); // カラーセンサの初期化

  setGYRO();

  // スタートSW待ち
  while (digitalRead(START_SW_PIN))
  {}
}
void loop()
{
  // センサ取得
  Line_C_Value = analogRead(LINE_C_PIN);
  Color_L = colorGet("left");
  Color_R = colorGet("right");

  // 制御

  // 緑検知
  while (Color_L == 2 || Color_R == 2) {
    MotorPower(15, 15);
    delay(5);
    Color_L = colorGet("left");
    Color_R = colorGet("right");
    if (Color_L == 2) {
      Green_L_Count += 1;
    }
    if (Color_R == 2) {
      Green_R_Count += 1;
    }
  }

  // 交差点検知
  if (Green_L_Count > 5 && Green_R_Count > 5) {
    rotation(180, 30);
  } else if (Green_L_Count > 5) {
    rotation(-90, 15);
  } else if (Green_R_Count > 5) {
    rotation(90, 15);
  }
  // カウントリセット
  Green_L_Count = 0;
  Green_R_Count = 0;

  if (Line_C_Value < 400) {
    // 比例制御
    lineTrace(0.1, 15, -15, 15);

  } else {

    // 白検知
    MotorPower(Min_Power, Min_Power);
    delay(200);
    MotorPower(0, 0);
    delay(500);
    // センサ取得
    Line_L_Value = analogRead(LINE_L_PIN);
    Line_R_Value = analogRead(LINE_R_PIN);

    if (min(Line_L_Value, Line_R_Value) > 224) {
      // ギャップ
      while (Line_C_Value > 100) {
        // ライントレース
        lineTrace(0.1, 15, -15, 15);
        delay(10);
      }
    } else {

      // 脱線
      Line_Out = 0; // 初期化
      while (Line_Out < 10) {
        // センサ取得
        Line_L_Value = analogRead(LINE_L_PIN);
        Line_R_Value = analogRead(LINE_R_PIN);
        Line_C_Value = analogRead(LINE_C_PIN);

        // 制御
        if (Line_L_Value > Line_R_Value) {
          // 右回転
          MotorPower(Max_Power, Min_Power);
        } else {
          // 左回転
          MotorPower(Min_Power, Max_Power);
        }

        if (Line_C_Value < 100) {
          Line_Out += 1;
        } else {
          Line_Out = 0;
        }

        delay(10);
      }
    }
  }
  delay(10);
}

// ========== 関数 - 動作 ==========

// ライントレース
void lineTrace(float P_gain, int bease_power, int min_power, int max_power) {
  int line_diff, motor_L_power, motor_R_power;

  // センサ取得
  Line_L_Value = analogRead(LINE_L_PIN);
  Line_R_Value = analogRead(LINE_R_PIN);
  Line_C_Value = analogRead(LINE_C_PIN);
  // 左右の値の差
  line_diff = Line_L_Value - Line_R_Value;

  // 比例制御
  motor_L_power = constrain(line_diff * P_gain + bease_power, min_power, max_power);
  motor_R_power = constrain(-line_diff * P_gain + bease_power, min_power, max_power);
  MotorPower(motor_L_power, motor_R_power);
}

// 指定度回転する関数
void rotation(int angle, int power) {
  // 変数宣言
  float now_angle = 0, tick;
  volatile int16_t gyro;

  // 回転方向
  if (angle > 0) {
    MotorPower(power, -power); // angleが正：右回転
  } else {
    MotorPower(-power, power); // angleが負：左回転
  }

  // 回転
  tick = micros(); // 開始時の時間
  while ( abs(angle) > abs(now_angle)) {
    delay(5);
    gyro = getGYRO(0);
    now_angle += (gyro * 0.0625) * ((float)(micros() - tick) / 1000000); // 回転量を求める
    tick = micros(); // 前回実行時間として格納
    Serial.print(gyro);
    Serial.print("\t");
    Serial.println(now_angle);
  }
  MotorPower(0, 0); // 回転終了
}

// ========== 関数 - システム ==========

// --- モータードライバ ---
int16_t MotorPower(int16_t MotorPower_L, int16_t MotorPower_R)  // モータードライバー用 MD-1制御
{

  MotorPower_L = constrain(MotorPower_L, -100, 100);
  MotorPower_L = map(MotorPower_L, -100, 100, 50 + MOTOR_OFFSET, 130 + MOTOR_OFFSET);
  //    MotorPower_L = map(MotorPower_L, -100, 100, 75 + MOTOR_OFFSET, 105 + MOTOR_OFFSET);
  MD1_L.write(MotorPower_L);

  MotorPower_R = constrain(MotorPower_R, -100, 100);
  MotorPower_R = map(MotorPower_R, -100, 100, 50 + MOTOR_OFFSET, 130 + MOTOR_OFFSET);
  //    MotorPower_R = map(MotorPower_R, -100, 100, 75 + MOTOR_OFFSET, 105 + MOTOR_OFFSET);
  MD1_R.write(MotorPower_R);
  /*    */
}

// --- カラーセンサ ---
float red_threshold[6] = {340, 20, 0.5, 1, 1000, 10000}; // 赤のしきい値
float green_threshold[6] = {110, 150, 0.5, 1, 1000, 10000}; // 緑のしきい値
// {h_low, h_high, s_low, s_high, v_low, v_high}

// カラーセンサ初期化関数
void colorSetup() {
  // アドレス
  const byte Slave_Addr = 0x2A; // カラーセンサのスレイブアドレス
  const byte Control_Register = 0x00; // コントロールレジスタアドレス

  Wire.begin(); // Write関数の呼び出し（１回だけ）　引数なし：マスター　あり(アドレス):スレイブ
  Wire1.begin();

  // カラーセンサの初期化
  // Wrie
  Wire.beginTransmission(Slave_Addr);
  Wire.write(Control_Register); // レジスタアドレスの指定
  Wire.write(0x84); // ADCリセット
  Wire.endTransmission(true); // 送信

  Wire.beginTransmission(Slave_Addr);
  Wire.write(Control_Register); // レジスタアドレスの指定
  Wire.write(0x0A); // 動作設定
  Wire.endTransmission(true); // 送信

  delay(2);

  // Wrie1
  Wire1.beginTransmission(Slave_Addr);
  Wire1.write(Control_Register); // レジスタアドレスの指定
  Wire1.write(0x84); // ADCリセット
  Wire1.endTransmission(true); // 送信

  Wire1.beginTransmission(Slave_Addr);
  Wire1.write(Control_Register); // レジスタアドレスの指定
  Wire1.write(0x0A); // 動作設定
  Wire1.endTransmission(true); // 送信


}

// RGB取得関数
void colorGetRGB(int *r, int *g, int *b, char *side, bool print_value) {
  // アドレス
  const byte Slave_Addr = 0x2A; // カラーセンサのスレイブアドレス
  const byte Red_Data_Register_High = 0x03; // Red上位バイトのレジスタアドレス
  // データ格納
  byte data[8]; // I2cの返り値を格納
  int red_value, green_value, blue_value; // RGBの値

  if (side == "right") {
    // 通信開始
    Wire.beginTransmission(Slave_Addr); // スレイブとの通信を開始
    Wire.write(Red_Data_Register_High); // レジスタアドレス
    Wire.endTransmission(false); // データを送信 bool=接続を切るか(初期:True→接続を切る)
    Wire.requestFrom(Slave_Addr, 6, true); // データを要求　bool=接続を切るか(初期:True→接続を切る)

    // 値を取得
    for (int i = 0; i < 8; i++) {
      data[i] = Wire.read();
    }

  } else {
    // 通信開始
    Wire1.beginTransmission(Slave_Addr); // スレイブとの通信を開始
    Wire1.write(Red_Data_Register_High); // レジスタアドレス
    Wire1.endTransmission(false); // データを送信 bool=接続を切るか(初期:True→接続を切る)
    Wire1.requestFrom(Slave_Addr, 6, true); // データを要求　bool=接続を切るか(初期:True→接続を切る)

    // 値を取得
    for (int i = 0; i < 8; i++) {
      data[i] = Wire1.read();
    }
  }

  // 上位バイトと下位バイトを合わせる
  red_value = data[0] << 8 | data[1];
  green_value = data[2] << 8 | data[3];
  blue_value = data[4] << 8 | data[5];

  // 値の出力
  if (print_value) {
    Serial.print("R:");
    Serial.print(red_value);
    Serial.print("\t");
    Serial.print("G:");
    Serial.print(green_value);
    Serial.print("\t");
    Serial.print("B:");
    Serial.print(blue_value);
    Serial.print("\n");
  }

  // 値の代入
  *r = red_value;
  *g = green_value;
  *b = blue_value;
}

// HSV取得関数
void colorGetHSV(int *h, float *s, int *v, char *side,  bool print_value) {
  // 変数宣言
  int red_value, green_value, blue_value; // RGBの値
  int max_RGB, min_RGB; // RGBの最大値、最低値
  int hue, value; // H,Vの値
  float saturation; //　Sの値

  // RGB取得
  colorGetRGB(&red_value, &green_value, &blue_value, side);

  // hueを求める
  if (red_value == green_value && green_value == blue_value) {
    // すべて等しい場合
    hue = 0;
    max_RGB = red_value;
    min_RGB = red_value;

  } else if (red_value > green_value && red_value > blue_value) {
    // redが最大値
    max_RGB = red_value;
    // 最低値取得
    if (green_value < blue_value) {
      // greenが最低値
      min_RGB = green_value;
    } else {
      // blueが最低値
      min_RGB = blue_value;
    }
    // 計算
    hue = 60 * ((float)(green_value - blue_value) / (max_RGB - min_RGB));

  } else if (green_value > red_value && green_value > blue_value) {
    // greenが最大
    max_RGB = green_value;
    if (red_value < blue_value) {
      // redが最低値
      min_RGB = red_value;
    } else {
      // blueが最低値
      min_RGB = blue_value;
    }
    // 計算
    hue = 60 * ((float)(blue_value - red_value) / (max_RGB - min_RGB)) + 120;

  } else {
    // blueが最大
    max_RGB = blue_value;
    if (red_value < green_value) {
      // redが最低値
      min_RGB = red_value;
    } else {
      // greenが最低値
      min_RGB = green_value;
    }
    // 計算
    hue = 60 * ((float)(red_value - green_value) / (max_RGB - min_RGB)) + 240;
  }

  // hueが負の場合、360を足して0~360の間に収める
  while (hue < 0) {
    hue += 360;
  }

  // 彩度を求める
  if (max_RGB != 0) {
    saturation = (float)(max_RGB - min_RGB) / max_RGB;
  } else {
    // ゼロ除算
    saturation = 0;
  }

  // 明度を求める
  value = max_RGB;

  // 値の出力
  if (print_value) {
    Serial.print("H:");
    Serial.print(hue);
    Serial.print("\t");
    Serial.print("S:");
    Serial.print(saturation);
    Serial.print("\t");
    Serial.print("V:");
    Serial.print(value);
    Serial.print("\n");
  }

  // 値の代入
  *h = hue;
  *s = saturation;
  *v = value;
}

int colorGet(char *side) {
  // 変数宣言
  int hue, value; // H,Vの値
  float saturation; //　Sの値

  // HSV取得

  colorGetHSV(&hue, &saturation, &value, side);


  // カラー取得
  if ((red_threshold[0] < hue || red_threshold[1] > hue) && (red_threshold[2] < saturation && red_threshold[3] > saturation) && (red_threshold[4] < value && red_threshold[5] > value)) {
    // 赤
    return 1;
  } else if ((green_threshold[0] < hue && green_threshold[1] > hue) && (green_threshold[2] < saturation && green_threshold[3] > saturation) && (green_threshold[4] < value && green_threshold[5] > value)) {
    // 緑
    return 2;
  } else {
    // 色なし
    return 0;
  }
}

// --- 加速度センサ ---

#define BNO055 0x29       //9軸センサ　IICアドレス

volatile int16_t RET_MSG;
volatile int16_t DIR;
volatile int16_t GYRO;
volatile int16_t PITCH;
volatile int16_t ROLL;

const byte Wait_ms = 2;

void setGYRO() {
  Wire.begin();       //I2C通信開始
  Wire.setClock(400000);      // fSCL = 400kHz
  Wire.beginTransmission(BNO055);
  Wire.write(0x3B);       //register設定
  Wire.write(0x00);
  RET_MSG = Wire.endTransmission();   // データの送信と終了処理
  if (RET_MSG == 0) {
  }
  else {
    Serial.print("ERROR NO.=");   //通信出来ない
    Serial.println(RET_MSG);
  }

  Wire.beginTransmission(BNO055);
  Wire.write(0x41);       //register設定
  Wire.write(0x21);
  Wire.write(0x04);
  RET_MSG = Wire.endTransmission();   // データの送信と終了処理
  if (RET_MSG == 0) {
  }
  else {
    Serial.print("ERROR NO.=");   //通信出来ない
    Serial.println(RET_MSG);
  }

  Wire.beginTransmission(BNO055);
  Wire.write(0x3D);       //register設定
  Wire.write(0x0C);
  RET_MSG = Wire.endTransmission();   // データの送信と終了処理
  if (RET_MSG == 0) {
  }
  else {
    Serial.print("ERROR NO.=");   //通信出来ない
    Serial.println(RET_MSG);
  }
}

uint16_t getGYRO(unsigned char)     //ジャイロ角度を読み込み。
{
  typedef union {       //受信データ用共用体
    uint16_t W;
    struct {
      unsigned char L;
      unsigned char H;
    };
  } uint16_t;
  uint16_t data;        // 受信データ
  int reg;          //レジスターアドレス
  reg = 0x18;         // Register 0x1E:GYRO_DATA_Z (LSB-MSB)
  Wire.beginTransmission(BNO055);   //通信開始
  Wire.write(reg);        //register
  Wire.endTransmission();     //通信終了

  Wire.requestFrom(BNO055, 2);
  if (Wire.available() > 1) {
    data.L = Wire.read();     //１バイト分のデータの読み込み
    data.H = Wire.read();     //次の１バイト分のデータを読み込み
  }
  delay(Wait_ms);
  return (data.W);
}

uint16_t getDIR(unsigned char)      //ヘッドアップ角度を読み込み。
{
  typedef union {       //受信データ用共用体
    uint16_t W;
    struct {
      unsigned char L;
      unsigned char H;
    };
  } uint16_t;
  uint16_t data;        // 受信データ
  int reg;          //レジスターアドレス
  reg = 0x1A;         // Register 0x1A:dir(EUL_DATA_X LSB-MSB)
  Wire.beginTransmission(BNO055);   //通信開始
  Wire.write(reg);        //register
  Wire.endTransmission();     //通信終了

  Wire.requestFrom(BNO055, 2);
  if (Wire.available() > 1) {
    data.L = Wire.read();     //１バイト分のデータの読み込み
    data.H = Wire.read();     //次の１バイト分のデータを読み込み
  }
  data.W = data.W / 16;
  delay(Wait_ms);
  return (data.W);
}

uint16_t getROLL(unsigned char)     //ロール角度を読み込み。
{
  typedef union {       //受信データ用共用体
    uint16_t W;
    struct {
      unsigned char L;
      unsigned char H;
    };
  } uint16_t;
  uint16_t data;        // 受信データ
  int reg;          //レジスターアドレス
  reg = 0x1C;         // Register  0x1C:ROLL(EUL_DATA_Y LSB-MSB)
  Wire.beginTransmission(BNO055);   //通信開始
  Wire.write(reg);        //register
  Wire.endTransmission();     //通信終了

  Wire.requestFrom(BNO055, 2);
  if (Wire.available() > 1) {
    data.L = Wire.read();     //１バイト分のデータの読み込み
    data.H = Wire.read();     //次の１バイト分のデータを読み込み
  }
  delay(Wait_ms);
  return (data.W);
}

uint16_t getPITCH(unsigned char)    //ピッチ角度を読み込み。
{
  typedef union {       //受信データ用共用体
    uint16_t W;
    struct {
      unsigned char L;
      unsigned char H;
    };
  } uint16_t;
  uint16_t data;        // 受信データ
  int reg;          //レジスターアドレス
  reg = 0x1E;         // Register 0x1E:PITCH(LSB-MSB)
  Wire.beginTransmission(BNO055);   //通信開始
  Wire.write(reg);        //register
  Wire.endTransmission();     //通信終了

  Wire.requestFrom(BNO055, 2);
  if (Wire.available() > 1) {
    data.L = Wire.read();     //１バイト分のデータの読み込み
    data.H = Wire.read();     //次の１バイト分のデータを読み込み
  }
  delay(Wait_ms);
  return (data.W);
}
