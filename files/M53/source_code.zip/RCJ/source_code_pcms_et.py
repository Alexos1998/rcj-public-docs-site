from machine import Pin, PWM, SoftI2C, UART,ADC
import ssd1306,machine
import time
import ustruct
import struct
#-------------------GPIO SETTING------------------------
adc1 = ADC(Pin(2))  # GPIO2讀取類比信號,presure sensor
adc2 = ADC(Pin(4))  # GPIO2讀取類比信號,presure sensor
button = Pin(27, Pin.IN)  # GP27 button
led = Pin(4, Pin.OUT)  # GP01 button
#-------------------GPIO SETTING------------------------

#-------------------speed setting------------------------
speed = 90
sp1 = -1*speed
sp2 = -1*speed
sp3 = 1*speed
sp4 = -1*speed

#-------------------speed setting------------------------

#-------------------UART cam data------------------------
uart1 = UART(1, 115200, tx=10, rx=5)
buf = bytearray()
cam_data_value = 0
receiving = False

def get_cam_data():
    global buf, cam_data_value, receiving
    
    if uart1.any():
        data = uart1.read()
        
        for b in data:
            if b == 0x24:  # '$' 的 ASCII 碼
                buf = bytearray()
                receiving = True
            elif b == 0x23:  # '#' 的 ASCII 碼
                if receiving and len(buf) > 0:
                    try:
                        # 將 bytearray 轉為字串再轉整數
                        num_str = buf.decode('utf-8')
                        cam_data_value = int(num_str)
                    except:
                        pass
                receiving = False
                buf = bytearray()
            elif receiving:
                buf.append(b)
    
    return cam_data_value

def cam_data():
    while True:
        time.sleep(0.1)
        if get_cam_data() is not None:
            return get_cam_data()
        
        
#-------------------UART cam data------------------------

#-------------------UART READ LASER 1 TO 10------------------------
read_laser = 0

# 初始化串口
uart = UART(2, baudrate=115200, rx=17, tx=9)  # 9號引腳不用

# 添加全局緩衝區
buffer = ""

# 定義變數來儲存解析後的數據
d1 = d2 = d3 = d4 = d5 = d6 = d7 = d8 = d9 = d10 = 9999


def parse_serial_data():
    global d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, buffer

    if uart.any():
        # 讀取當前所有可用數據
        raw = uart.read()
        try:
            # 使用 ignore 忽略解碼錯誤
            buffer += raw.decode('utf-8', 'ignore')
        except:
            pass

        # 限制緩衝區長度，避免記憶體溢出
        if len(buffer) > 1000:
            buffer = buffer[-500:]

        # 尋找最新的完整封包 (從後往前找最新的)
        start_index = buffer.rfind('$')
        end_index = buffer.rfind('#')

        if start_index != -1 and end_index != -1 and end_index > start_index:
            packet = buffer[start_index:end_index + 1]
            # 解析後清空緩衝區，確保下一輪是新鮮數據
            buffer = ""

            content = packet[1:-1]
            parts = content.split('@')

            # 封包格式：$S1@S2@S3@S4@S5@S6@S7@S8@S9@S10#
            if len(parts) >= 10:
                validate_and_convert_data(*parts[:10])
                return True
    return False



def validate_and_convert_data(d1_str, d2_str, d3_str, d4_str, d5_str, d6_str, d7_str, d8_str, d9_str, d10_str):
    """檢驗並轉換 1~10 號激光數據"""
    global d1, d2, d3, d4, d5, d6, d7, d8, d9, d10

    d_strings = [d1_str, d2_str, d3_str, d4_str, d5_str, d6_str, d7_str, d8_str, d9_str, d10_str]
    d_values = []

    for i, d_str in enumerate(d_strings, 1):
        if d_str and d_str != "":
            try:
                d_val = int(d_str)
                d_values.append(d_val)
            except ValueError:
                print(f"警告: d{i}='{d_str}' 無法轉換為整數，設為9999")
                d_values.append(9999)
        else:
            d_values.append(9999)

    d1, d2, d3, d4, d5, d6, d7, d8, d9, d10 = d_values


def read_multiple_data(times=1, timeout=150):
    """讀取數據，取得第一筆有效結果即返回（優化版：減少不必要的多次讀取）"""
    success_count = 0
    last_d_values = [9999] * 10

    start_time = time.ticks_ms()

    while success_count < times and time.ticks_diff(time.ticks_ms(), start_time) < timeout:
        if parse_serial_data():
            # 記錄當前所有變數的值
            last_d_values = [d1, d2, d3, d4, d5, d6, d7, d8, d9, d10]
            
            # 檢查是否全部都是 9999
            if all(val == 9999 for val in last_d_values):
                print("讀取到全部 9999，重新讀取...")
                continue # 放棄這次結果，繼續迴圈嘗試讀取
                
            success_count += 1
            break  # 取得第一筆有效數據後立即返回

        time.sleep_ms(5)  # 縮短輪詢間隔

    return last_d_values


def wait_for_valid_data(timeout=800):
    global buffer

    # 開始前先清空 UART 舊數據
    if uart.any():
        uart.read()

    buffer = ""
    # 清空後短暫等待，讓發送端有時間送出下一個完整封包
    time.sleep_ms(5)
    start_time = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), start_time) < timeout:
        if parse_serial_data():
            # 檢查是否全部都是 9999
            current_values = [d1, d2, d3, d4, d5, d6, d7, d8, d9, d10]
            if all(val == 9999 for val in current_values):
                # 如果全部都是 9999，則繼續等待下一次有效數據
                pass
            else:
                return True
        time.sleep_ms(5)  # 縮短輪詢間隔
    return False


def read_data_5():
    global read_laser, buffer

    # 等待獲取有效的數據包（timeout=800ms）
    if wait_for_valid_data(timeout=800):
        # 成功獲取到有效數據，再讀取1次確認最新值（timeout=150ms）
        final_d_values = read_multiple_data(1, timeout=150)
        print(f"\n最終使用的數據:")
        print(f"  D1-D10: {final_d_values}")
        read_laser = 1
    else:
        print("無法獲取有效數據，使用現有數據")
        read_laser = 0

    buffer = ""
    #print("緩衝區已清理，準備下一輪讀取")

#-------------------UART READ LASER 1 TO 10----------------------
    
#--------------------------------GYRO----------------------------------
# JY901 I2C 地址
JY901_ADDRESS = 0x50

# 角度暫存器地址
REG_ANGLE_X = 0x3D
REG_ANGLE_Y = 0x3E
REG_ANGLE_Z = 0x3F

# I2C 初始化 (ESP32 預設 SDA=21, SCL=22)
# 請根據您的 ESP32 開發板實際接線調整 Pin 腳
i2c = SoftI2C(scl=Pin(22), sda=Pin(21), freq=100000)

def read_word(reg):
    try:
        # 讀取兩個位元組
        data = i2c.readfrom_mem(JY901_ADDRESS, reg, 2)
        return struct.unpack('<h', data)[0]
    except Exception as e:
        # 如果讀取失敗，返回一個特殊的標記值（例如 0 或上一次的值）
        # print("I2C 讀取失敗:", e)
        return 0 

def get_angle(reg):
    raw_value = read_word(reg)
    # 如果 read_word 因為錯誤返回 0，這裡也會返回 0
    angle = raw_value / 32768.0 * 180.0
    return angle

    
#--------------------------------GYRO----------------------------------   
#--------------------------------OLED---------------------------------
# OLED SSD1306 I2C設定
i2c_oled = SoftI2C(sda=Pin(21), scl=Pin(22))  # OLED I2C
oled = ssd1306.SSD1306_I2C(128, 64, i2c_oled)

def oled_display(x, y, data):
    """
    在OLED指定位置顯示數據
    """
    try:
        oled.text(str(data), x, y)
        oled.show()
    except Exception as e:
        print("OLED顯示錯誤:", e)

def clear_display():
    """清除整個OLED顯示"""
    oled.fill(0)
    oled.show()

def clear_area(x, y, width, height):
    """清除指定區域"""
    oled.fill_rect(x, y, width, height, 0)
    oled.show()
#--------------------------------OLED---------------------------------
#------------------------------Encoder--------------------------------
class RotaryEncoder:
    def __init__(self, name, pin_a, pin_b):
        self.name = name
        self.pin_a = machine.Pin(pin_a, machine.Pin.IN, machine.Pin.PULL_UP)
        self.pin_b = machine.Pin(pin_b, machine.Pin.IN, machine.Pin.PULL_UP)
        self.counter = 0
        self.last_a = self.pin_a.value()
        
        # 設定中斷
        try:
            self.pin_a.irq(trigger=machine.Pin.IRQ_RISING | machine.Pin.IRQ_FALLING, handler=self.handle_irq)
        except:
            pass

    def handle_irq(self, pin):
        a = self.pin_a.value()
        b = self.pin_b.value()
        
        if pin == self.pin_a and a != self.last_a:
            if a == 1:
                self.counter += 1 if b == 0 else -1
            else:
                self.counter += 1 if b == 1 else -1
            self.last_a = a

    def get_value(self):
        return self.counter

    def reset(self):
        self.counter = 0

# 建立兩個編碼器
enc1 = RotaryEncoder("編碼器1", 34, 35)
enc2 = RotaryEncoder("編碼器2", 36, 39)

def encoder(num):
    """讀取編碼器值: encoder(1) 或 encoder(2)"""
    if num == 1:
        return enc1.get_value()
    elif num == 2:
        return enc2.get_value()
    return 0

def encoder_reset(num=None):
    """重置編碼器: None=全部, 1=編碼器1, 2=編碼器2"""
    if num is None:
        enc1.reset()
        enc2.reset()
        return "所有編碼器已重置"
    elif num == 1:
        enc1.reset()
        return "編碼器1已重置"
    elif num == 2:
        enc2.reset()
        return "編碼器2已重置"

def get_both():
    """同時讀取兩個編碼器"""
    return {
        'enc1': encoder(1),
        'enc2': encoder(2),
        'diff': encoder(1) - encoder(2)
    }
#------------------------------Encoder--------------------------------    
#--------------------------------COLOR SENSOR-------------------------
class TCS34725:
    def __init__(self, i2c, address=0x29):
        self.i2c = i2c
        self.address = address
        self._init_sensor()
    
    def _write8(self, reg, value):
        self.i2c.writeto_mem(self.address, reg, bytes([value]))
    
    def _read8(self, reg):
        return self.i2c.readfrom_mem(self.address, reg, 1)[0]
    
    def _read16(self, reg):
        data = self.i2c.readfrom_mem(self.address, reg, 2)
        return data[0] + (data[1] << 8)
    
    def _init_sensor(self):
        # 電源開啟
        self._write8(0x80 | 0x00, 0x01)  # 開啟
        time.sleep(0.01)
        self._write8(0x80 | 0x00, 0x01 | 0x02)  # 開啟 + RGB 感測
        time.sleep(0.01)
        
        # 設置積分時間和增益
        self._write8(0x80 | 0x01, 0xF6)  # ATIME = 101 (101ms)
        self._write8(0x80 | 0x0F, 0x00)  # GAIN = 1x
        
        time.sleep(0.1)  # 等待傳感器準備
    
    @property
    def color_raw(self):
        """讀取原始顏色數據"""
        c = self._read16(0x80 | 0x14)  # Clear
        r = self._read16(0x80 | 0x16)  # Red
        g = self._read16(0x80 | 0x18)  # Green
        b = self._read16(0x80 | 0x1A)  # Blue
        return (r, g, b, c)
    
    @property 
    def color_rgb_bytes(self):
        """返回 RGB 字節值"""
        r, g, b, c = self.color_raw
        if c == 0:
            return (0, 0, 0)
        # 歸一化並轉換為 8 位
        r = min(255, int((r / c) * 255))
        g = min(255, int((g / c) * 255))
        b = min(255, int((b / c) * 255))
        return (r, g, b)
    
    @property
    def color(self):
        """返回 RGB 顏色值"""
        r, g, b = self.color_rgb_bytes
        return (r << 16) | (g << 8) | b
    
    @property
    def lux(self):
        """計算照度"""
        r, g, b, c = self.color_raw
        # 簡單的照度計算
        return c * 0.048  # 調整此係數以獲得準確的 lux 值

def get_color_and_lux():
    """
    獲取顏色傳感器的 RGB 值和照度
    返回: (r, g, b, lux) 元組
    """
    try:
        # 使用與OLED相同的I2C引腳，但創建新的I2C實例
        i2c_color = SoftI2C(scl=Pin(22), sda=Pin(21), freq=100000)
        
        # 掃描設備
        devices = i2c_color.scan()
        print("I2C 設備:", [hex(d) for d in devices])
        
        if 0x29 in devices:
            sensor = TCS34725(i2c_color)
            
            # 讀取顏色和照度
            color_rgb = sensor.color_rgb_bytes
            lux = sensor.lux
            
            # 返回 (r, g, b, lux) 元組
            return color_rgb[0], color_rgb[1], color_rgb[2], lux
        else:
            print("未找到 TCS34725 傳感器！")
            return (0, 0, 0, 0.0)
    except Exception as e:
        print("顏色感測器讀取錯誤:", e)
        return (0, 0, 0, 0.0)
#------------------------------COLOR SENSOR----------------------------
    
#--------------------------------MOTOR---------------------------------    
# 定義第一個TB6612FNG引腳連接（馬達A和B）
PWMA1 = PWM(Pin(0))     # GP0
AIN1_1 = Pin(13, Pin.OUT)   # GP2  AIN1_1 = Pin(13, Pin.OUT)   # GP2
AIN2_1 = Pin(32, Pin.OUT)  # GP32

PWMB1 = PWM(Pin(26))    # GP26
BIN1_1 = Pin(33, Pin.OUT)  # GP33
BIN2_1 = Pin(25, Pin.OUT)  # GP25

# 定義第二個TB6612FNG引腳連接（馬達C和D）
PWMA2 = PWM(Pin(23))    # GP23
AIN1_2 = Pin(14, Pin.OUT)   # GP3   AIN1_2 = Pin(14, Pin.OUT)
AIN2_2 = Pin(12, Pin.OUT)   # GP1    AIN2_2 = Pin(12, Pin.OUT) 

PWMB2 = PWM(Pin(15))    # GP15
BIN1_2 = Pin(19, Pin.OUT)  # GP19
BIN2_2 = Pin(18, Pin.OUT)  # GP18

# 設置PWM頻率
PWMA1.freq(1000)
PWMB1.freq(1000)
PWMA2.freq(1000)
PWMB2.freq(1000)
 
def motor_control(speed_a, speed_b, speed_c, speed_d):
    """
    控制四個馬達的速度和方向
    """
    # 限制速度範圍在-100到100之間
    speed_a = max(-100, min(100, speed_a))
    speed_b = max(-100, min(100, speed_b))
    speed_c = max(-100, min(100, speed_c))
    speed_d = max(-100, min(100, speed_d))
    
    # 馬達A控制
    if speed_a > 0:
        AIN1_1.on()
        AIN2_1.off()
        PWMA1.duty_u16(int(speed_a * 655.35))
    elif speed_a < 0:
        AIN1_1.off()
        AIN2_1.on()
        PWMA1.duty_u16(int(-speed_a * 655.35))
    else:
        AIN1_1.off()
        AIN2_1.off()
        PWMA1.duty_u16(0)
    
    # 馬達B控制
    if speed_b > 0:
        BIN1_1.on()
        BIN2_1.off()
        PWMB1.duty_u16(int(speed_b * 655.35))
    elif speed_b < 0:
        BIN1_1.off()
        BIN2_1.on()
        PWMB1.duty_u16(int(-speed_b * 655.35))
    else:
        BIN1_1.off()
        BIN2_1.off()
        PWMB1.duty_u16(0)
    
    # 馬達C控制
    if speed_c > 0:
        AIN1_2.on()
        AIN2_2.off()
        PWMA2.duty_u16(int(speed_c * 655.35))
    elif speed_c < 0:
        AIN1_2.off()
        AIN2_2.on()
        PWMA2.duty_u16(int(-speed_c * 655.35))
    else:
        AIN1_2.off()
        AIN2_2.off()
        PWMA2.duty_u16(0)
    
    # 馬達D控制
    if speed_d > 0:
        BIN1_2.on()
        BIN2_2.off()
        PWMB2.duty_u16(int(speed_d * 655.35))
    elif speed_d < 0:
        BIN1_2.off()
        BIN2_2.on()
        PWMB2.duty_u16(int(-speed_d * 655.35))
    else:
        BIN1_2.off()
        BIN2_2.off()
        PWMB2.duty_u16(0)

def stop_all_motors():
    """停止所有馬達"""
    AIN1_1.off()
    AIN2_1.off()
    BIN1_1.off()
    BIN2_1.off()
    PWMA1.duty_u16(0)
    PWMB1.duty_u16(0)
    
    AIN1_2.off()
    AIN2_2.off()
    BIN1_2.off()
    BIN2_2.off()
    PWMA2.duty_u16(0)
    PWMB2.duty_u16(0)
#--------------------------------MOTOR---------------------------------
#-----------------------------MOTOR_MC---------------------------------
def motor_mc(sp1, sp2, sp3, sp4, encoder_num, target_value):
    """
    控制馬達直到編碼器達到目標值
    encoder_num: 使用哪個編碼器判斷 (1 或 2)
    target_value: 要達到的脈衝數差值
    """
    encoder_reset(1)
    encoder_reset(2)    
    # 紀錄起始編碼器值
    flag1 = abs(encoder(1))
    flag2 = abs(encoder(2))
    # 啟動馬達 (全部向前)
    motor_control(sp1 , sp2 , sp3 , sp4 )
    count = 0
    # 等待直到達到目標
    while True:
        motor_control(sp1 , sp2 , sp3 , sp4 )
        #print(abs(encoder(1)))
        #print(abs(encoder(2)))
        if encoder_num == 1:
            if adc2.read() > 500 and adc1.read() > 500:
                motor_mc2(sp1,sp2,sp3,sp4,2,300)
                time.sleep(0.1)
                motor_mc2(-sp1,-sp2,-sp3,-sp4,2,200)
            elif adc2.read() > 500:
                motor_mc2(-sp1,-sp2,-sp3,-sp4,2,100)
                time.sleep(0.1)
                motor_mc2(-sp1,-sp2, sp3, sp4,2,200)
                time.sleep(0.1)
                motor_mc2(sp1,sp2,sp3,sp4,2,100)
                time.sleep(0.1)
                motor_mc2(sp1,sp2, -sp3, -sp4,2,50)
                time.sleep(0.1)
                count = count + 1
            elif adc1.read() > 500:
                motor_mc2(-sp1, -sp2, -sp3, -sp4,2,100)
                time.sleep(0.1)
                motor_mc2(sp1,sp2, -sp3, -sp4,2,200)
                time.sleep(0.1)
                motor_mc2(sp1, sp2, sp3, sp4,2,100)
                time.sleep(0.1)
                motor_mc2(-sp1, -sp2, sp3, sp4,2,50)
                time.sleep(0.1)
                count = count + 1
            elif abs(encoder(1)) >= target_value or count > 3:
                break
            
        elif encoder_num == 2:
            if adc2.read() > 500: 
                motor_mc2(-sp1,-sp2,-sp3,-sp4,2,100)
                time.sleep(0.1)
                motor_mc2(-sp1,-sp2, sp3, sp4,2,200)
                time.sleep(0.1)
                motor_mc2(sp1,sp2,sp3,sp4,2,50)
                time.sleep(0.1)
                motor_mc2(sp1,sp2, -sp3, -sp4,2,10)
                time.sleep(0.1)
                count = count + 1
            elif adc1.read() > 500:
                motor_mc2(-sp1, -sp2, -sp3, -sp4,2,100)
                time.sleep(0.1)
                motor_mc2(sp1,sp2, -sp3, -sp4,2,200)
                time.sleep(0.1)
                motor_mc2(sp1, sp2, sp3, sp4,2,50)
                time.sleep(0.1)
                motor_mc2(-sp1, -sp2, sp3, sp4,2,10)
                time.sleep(0.1)
                count = count + 1
            elif abs(encoder(2)) >= target_value or count > 4:
                break
            #motor_control(sp1 , sp2 , sp3 , sp4 )          
    # 停止馬達
    motor_control(0, 0, 0, 0)

#-----------------------------MOTOR_MC---------------------------------
    
#-----------------------------MOTOR_MC2---------------------------------    
def motor_mc2(sp1, sp2, sp3, sp4, encoder_num, target_value):
    """
    控制馬達直到編碼器達到目標值
    encoder_num: 使用哪個編碼器判斷 (1 或 2)
    target_value: 要達到的脈衝數差值
    """
    encoder_reset(1)
    encoder_reset(2)    
    # 紀錄起始編碼器值
    flag1 = abs(encoder(1))
    flag2 = abs(encoder(2))

    # 啟動馬達 (全部向前)
    motor_control(sp1 , sp2 , sp3 , sp4 )
    
    # 等待直到達到目標
    while True:
        
        if encoder_num == 1:
            if abs(encoder(1)) - flag1 >= target_value:
                break
        elif encoder_num == 2:
            if abs(encoder(2)) - flag2 >= target_value:
                break
            
    # 停止馬達
    motor_control(0, 0, 0, 0)
#-----------------------------MOTOR_MC2---------------------------------       
    
#--------------------------------SERVO----------------------------------
class SG90Servo:
    def __init__(self, pin_number=14):
        self.pwm = PWM(Pin(pin_number))
        self.pwm.freq(50)
        
        self.min_pulse = 500
        self.max_pulse = 2500
        
        self.min_duty = int((self.min_pulse / 20000) * 65535)
        self.max_duty = int((self.max_pulse / 20000) * 65535)
    
    def set_angle(self, angle):
        angle = max(0, min(180, angle))
        pulse_width = self.min_pulse + (angle / 180) * (self.max_pulse - self.min_pulse)
        duty = int((pulse_width / 20000) * 65535)
        self.pwm.duty_u16(duty)
        
        #print(f"伺服馬達設定為 {angle} 度")
        return angle
    
    def deinit(self):
        self.pwm.deinit()

# 創建伺服馬達物件
servo = SG90Servo(16)  
#--------------------------------SERVO---------------------------------

#--------------------------------MAZE---------------------------------
# 1. 初始化座標與方向 (0:北, 1:東, 2:南, 3:西)
current_x = 0
current_y = 0
current_direction = 0

# 新增路徑記錄數組
visited_path = []
dropped_path = []
blink_path = []
order_list = []
# 新增檢查函數
def is_visited(x, y):
    """
    檢查指定座標是否走過
    走過返回 1，否則返回 0
    """
    if [x, y] in visited_path:
        return 1
    return 0

def is_dropped(x, y):
    """
    檢查指定座標是否發現過人質
    發現返回 1，否則返回 0
    """
    if [x, y] in dropped_path:
        return 1
    return 0

def is_blink(x, y):
    """
    檢查指定座標是否閃燈
    發現返回 1，否則返回 0
    """
    if [x, y] in blink_path:
        return 1
    return 0

def order():
    read_data_5()
    if d4 < 250:
        order_list.append("right")
        order_list.append("front")
        order_list.append("left")
    else:
        order_list.append("left")
        order_list.append("front")
        order_list.append("right")


def left_no_wall():
    if d4 > 250:
        return 1
    else:
        return 0

def front_no_wall():
    if d2 > 250:
        return 1
    else:
        return 0
    
def right_no_wall():
    if d6 > 200:
        return 1
    else:
        return 0
           
def turn_left(angle):
    start_angle = get_angle(REG_ANGLE_Z)
    total_turned = 0
    last_angle = start_angle   
    # 啟動馬達
    motor_control(-sp1, -sp2, sp3, sp4)   
    while total_turned < angle:
        current_angle = get_angle(REG_ANGLE_Z)
        
        # 計算這一次循環轉動了多少度 (處理 180/-180 跳變)
        diff = current_angle - last_angle
        
        # 如果發生跳變 (例如從 179 變到 -179)，diff 會是 -358
        # 我們需要把它修正回正確的左轉增量 (2 度)
        if diff < -180:
            diff += 360
        elif diff > 180:
            diff -= 360
            
        # 左轉時，角度應該是增加的
        # 如果感測器數值是左轉增加，則 diff 為正
        total_turned += diff
        last_angle = current_angle
        
        # 為了避免死迴圈，可以加入一個極小的延遲
        time.sleep_ms(1)
        
    # 停止馬達
    motor_control(0, 0, 0, 0)
    
def turn_right(angle):
    start_angle = get_angle(REG_ANGLE_Z)
    total_turned = 0
    last_angle = start_angle
    
    # 啟動馬達 (請根據您的馬達接線調整正負號)
    # 通常右轉的馬達輸出與左轉相反
    motor_control(sp1, sp2, -sp3, -sp4)
    
    while total_turned < angle:
        current_angle = get_angle(REG_ANGLE_Z)
        
        # 計算這一次循環轉動了多少度 (處理 180/-180 跳變)
        diff = current_angle - last_angle
        
        # 處理跨越 180/-180 度的跳變邏輯
        if diff < -180:
            diff += 360
        elif diff > 180:
            diff -= 360
            
        # 右轉時，角度會減少，所以 diff 為負值
        # 我們減去 diff (等於加上絕對值) 來累加轉動總量
        total_turned -= diff
        last_angle = current_angle
        
        # 短暫延遲，讓 I2C 通訊穩定
        time.sleep_ms(1)
        
    # 停止馬達
    motor_control(0, 0, 0, 0)
    
def turn_left_find():
    global current_direction
    turn_left(80)
    adjust_left_right()
    find_victim()
    current_direction = (current_direction - 1 + 4) % 4
    
def turn_right_find():
    global current_direction
    turn_right(80)
    adjust_left_right() 
    find_victim()
    current_direction = (current_direction + 1) % 4
    

def ramp():
    angle_x = get_angle(REG_ANGLE_X)
    if angle_x < -80:
        # 持续控制电机，直到角度大于 -70
        while True:
            motor_control(sp1, sp2, sp3, sp4)
            angle_x = get_angle(REG_ANGLE_X)
            if angle_x > -70:
                motor_mc2(sp1,sp2,sp3,sp4,2,500)
                if current_direction == 0:   # 北
                    current_y += 1
                elif current_direction == 1: # 東
                    current_x += 1
                elif current_direction == 2: # 南
                    current_y -= 1
                elif current_direction == 3: # 西
                    current_x -= 1
                print("上斜坡")
                break
                
    if angle_x > -45:
        # 持续控制电机，直到角度大于 -70
        while True:
            motor_control(sp1, sp2, sp3, sp4)
            angle_x = get_angle(REG_ANGLE_X)
            if angle_x < -60:
                motor_mc2(sp1,sp2,sp3,sp4,2,500)
                if current_direction == 0:   # 北
                    current_y += 1
                elif current_direction == 1: # 東
                    current_x += 1
                elif current_direction == 2: # 南
                    current_y -= 1
                elif current_direction == 3: # 西
                    current_x -= 1
                print("下斜坡")
                break

'''def blue():
    r, g, b, lux = get_color_and_lux()
    if b > 90:
        print("blue ground")
        time.sleep(3.5)
        '''

def led_blink():
    for i in range(5):
        led.value(1)
        time.sleep(0.4)
        led.value(0)
        time.sleep(0.4)
    blink_path.append([current_x, current_y])

def drop_kits(direc, times):
    if direc == 1:
        for i in range(times):
            angle = servo.set_angle(80)
            time.sleep(0.5)
            angle = servo.set_angle(175)
            time.sleep(0.5)
            angle = servo.set_angle(80)
            time.sleep(0.5)
            
    elif direc == 2:
        for i in range(times):
            angle = servo.set_angle(80)
            time.sleep(0.5)
            angle = servo.set_angle(0)
            time.sleep(0.5)
            angle = servo.set_angle(90)
            time.sleep(0.5)
                      
def find_victim():
    global current_x, curren_y
    print(f"blink:{blink_path}")
    read_data_5() 
    print(cam_data())
    time.sleep(2)
    if [current_x, current_y] not in blink_path:
        if (cam_data() == 14 or cam_data() == 11) and (d4 < 195 or d5 < 195):
            led_blink()
            drop_kits(1,2)
        elif(cam_data() == 15 or cam_data() == 13) and (d4 < 195 or d5 < 195):
            led_blink()
            drop_kits(1,1)
        elif (cam_data() == 16 or cam_data() == 12) and (d4 < 195 or d5 < 195):
            led_blink()
        elif( cam_data() == 4 or cam_data() == 1 )and (d6 < 195 or d7 < 195):
            led_blink()
            drop_kits(2,2)
        elif( cam_data() == 5 or cam_data() == 3 )and (d6 < 195 or d7 < 195):
            print("hi")
            led_blink()
            drop_kits(2,1)
        elif( cam_data() == 6 or cam_data() == 2 )and (d6 < 195 or d7 < 195):
            led_blink()
        if cam_data() > 0:
            dropped_path.append([current_x, current_y])
        
        
def adjust_left_right():
    read_data_5() #讀LASER 和GYRO值函數
    if d4 < 180 : 
        if (d4+10) > d5:
            error = (d4+10) - d5
            motor_mc(-sp1, -sp2, sp3, sp4,2,error*2) # 左TURN 45度
        elif (d4+10) < d5 :
            error = d5 - (d4+10) 
            motor_mc(sp1, sp2, -sp3, -sp4,2,error*2) # 左TURN 45度
    elif d7 < 180 :
        if (d7+5) > d6 :
            error = (d7+5)  - d6
            motor_mc(sp1, sp2, -sp3, -sp4,2,error*2) # 左TURN 45度
        elif d7 < d6:
            error = d6 - (d7+5) 
            motor_mc(-sp1, -sp2, sp3, sp4,2,error*2) # 左TURN 45度            
                  
def adjust_back():
    read_data_5() #讀LASER 和GYRO值函數
    if d8 > d10 and d9 < 110:
        error = d8 - d10
        motor_mc(-sp1, -sp2, sp3, sp4,2,error*5) # 左TURN 45度
    elif d10 > d8 and d9 < 110:
        error = d10 - d8
        motor_mc(sp1, sp2, -sp3, -sp4,2,error*5) # 左TURN 45度
            
def adjust_front():   
    read_data_5() #讀LASER 和GYRO值函數
    if d2 < 250 and d2 > 40:
        motor_mc2(sp1, sp2, sp3, sp4,2,d2*4.5)
        time.sleep(0.2)
        motor_mc2(-sp1, -sp2, -sp3, -sp4,2,200)
        
def forward():
    global sp1, sp2, sp3, sp4, speed 
    global current_x, current_y,current_direction #座標
    read_data_5() #read laser
    #左或右太靠近墻︳左右調速
    '''if (d4 > 20 and d4 < 100) or (d6 > 100 and d6 < 300):
        sp3 = 0.9*sp3
        sp4 = 0.9*sp4
    if (d6 > 20 and d6 < 100) or (d4 > 100 and d4 < 300):
        sp1 = 0.9*sp1
        sp2 = 0.9*sp2'''
    #左右調速
    motor_mc(sp1, sp2, sp3, sp4,2,700)#forward 15cm
    time.sleep(0.1)
    #black ground
    r, g, b, lux = get_color_and_lux()  #color read ground 
    if lux < 4 and b < 100:#black
        print(f"顏色讀數: R={r}, G={g}, B={b}, Lux={lux:.2f}")
        motor_mc(-sp1, -sp2, -sp3, -sp4,2,600)
        time.sleep(0.5)
        turn_left(170)
        current_direction = (current_direction + 2) % 4 
    #---------------black ground---------------------------
    else:
        #motor_mc(sp1, sp2, sp3, sp4,2,100)
        motor_mc(sp1, sp2, sp3, sp4,2,700)        
        # 4. 更新座標
        if current_direction == 0:   # 北
            current_y += 1
        elif current_direction == 1: # 東
            current_x += 1
        elif current_direction == 2: # 南
            current_y -= 1
        elif current_direction == 3: # 西
            current_x -= 1
            
        print(f"dir:{current_direction},x:{current_x},y:{current_y},訪問過:{is_visited(current_x,current_y)},已找過有人質:{is_dropped(current_x,current_y)}")
        if is_visited(current_x, current_y)==1:
            print("已經走過")

        visited_path.append([current_x, current_y])
        print(visited_path)
        print(dropped_path)
    time.sleep(0.5)
    ramp()
    adjust_front()
    find_victim()
    #blue() blue ground
    
def maze_explore():
    global current_x, current_y, current_direction

    # 回到起點，END GAME
    if current_x == 0 and current_y == 0 and is_visited(0, 0):
        for i in range(5):
            led.value(1)
            time.sleep(1)
            led.value(0)
            time.sleep(1)
        # return # 結束探索

    # 初始位置記錄，如果是空數組就將0,0加進去
    if not visited_path:
        visited_path.append([current_x, current_y])

    read_data_5()

    # 除錯資訊：印出當前雷射數值
    print(f"雷射數據: 前(d2)={d2}, 左(d4)={d4}, 右(d6)={d6}")

    # 判斷可走的路徑
    possible_moves = []

    # 檢查左方
    if left_no_wall():
        possible_moves.append("left")

    # 檢查前方
    if front_no_wall():
        possible_moves.append("front")

    # 檢查右方
    if right_no_wall():
        possible_moves.append("right")

    # 根據當前方向和可能的移動，計算下一個座標並檢查訪問狀態
    paths_info = []
    for move in possible_moves:
        temp_x, temp_y, temp_direction = current_x, current_y, current_direction
        
        if move == "front":
            if temp_direction == 0:   # 北
                temp_y += 1
            elif temp_direction == 1: # 東
                temp_x += 1
            elif temp_direction == 2: # 南
                temp_y -= 1
            elif temp_direction == 3: # 西
                temp_x -= 1
        elif move == "right":
            # 模擬右轉後的方向
            new_dir = (temp_direction + 1) % 4
            if new_dir == 0:   # 北
                temp_y += 1
            elif new_dir == 1: # 東
                temp_x += 1
            elif new_dir == 2: # 南
                temp_y -= 1
            elif new_dir == 3: # 西
                temp_x -= 1
        elif move == "left":
            # 模擬左轉後的方向
            new_dir = (temp_direction - 1 + 4) % 4
            if new_dir == 0:   # 北
                temp_y += 1
            elif new_dir == 1: # 東
                temp_x += 1
            elif new_dir == 2: # 南
                temp_y -= 1
            elif new_dir == 3: # 西
                temp_x -= 1
        
        # 計算該座標在 visited_path 中的索引（如果未走過則設為 None）
        visited_index = None
        for idx, pos in enumerate(visited_path):
            if pos[0] == temp_x and pos[1] == temp_y:
                visited_index = idx
                break
        
        paths_info.append({
            "move": move,
            "coords": [temp_x, temp_y],
            "visited": visited_index is not None,
            "index": visited_index  # 走過的順序索引，越小越早走過
        })

    # 分離未走過和已走過的路徑
    unvisited_paths = [p for p in paths_info if not p["visited"]]
    visited_paths = [p for p in paths_info if p["visited"]]

    chosen_move = None

    # 1. 優先走未走過的路（左 → 前 → 右）
    if unvisited_paths:
        for move_order in order_list:
            for p in unvisited_paths:
                if p["move"] == move_order:
                    chosen_move = move_order
                    break
            if chosen_move:
                break

    # 2. 如果都走過了，則選擇最早走過的那條路（index 最小）
    elif visited_paths:
        # 找 index 最小的路徑（最早走過）
        earliest_path = min(visited_paths, key=lambda p: p["index"])
        chosen_move = earliest_path["move"]
        print(f"所有路徑都已走過，選擇最早走過的路: {chosen_move} (index={earliest_path['index']})")

    # 執行動作
    if chosen_move == "left":
        print(f"決策: 左轉進入座標 {next(p['coords'] for p in paths_info if p['move']=='left')}")
        turn_left_find()
        forward()
    elif chosen_move == "front":
        print(f"決策: 直行進入座標 {next(p['coords'] for p in paths_info if p['move']=='front')}")
        forward()
    elif chosen_move == "right":
        print(f"決策: 右轉進入座標 {next(p['coords'] for p in paths_info if p['move']=='right')}")
        turn_right_find()
        forward()
    else:  # 真的無路可走 (死胡同)
        print("決策: 無路可走，執行 180 度迴轉")
        turn_left_find()
        

#--------------------------------MAZE---------------------------------
    
#----------------------------MAIN LOOP---------------------------------

#陀螺儀轉0~180 右轉0~負180
if __name__ == "__main__":
    
    angle = servo.set_angle(80)
    order()
    
    #angle = servo.set_angle(90)
    #time.sleep(5)
    #angle = servo.set_angle(85)
    while True:
        angle = servo.set_angle(80)
        if button.value() == 0:
            print("==============START===========")
            '''
            motor_mc(sp1, sp2, sp3, sp4,2,1100)
            time.sleep(2)
            motor_mc(-sp1, -sp2, -sp3, -sp4,2,1100)
            time.sleep(2)
            '''
            #turn_right_find()
            
            # 讀取10激光和陀螺儀數值
            #read_data_5() #讀LASER 值函數
            #angle = servo.set_angle(90)
            #time.sleep(2)
            #angle = servo.set_angle(170)
            #time.sleep(5)
            #angle = servo.set_angle(0)
            #time.sleep(5)  

            #print(read_laser_gyro)
            #r, g, b, lux = get_color_and_lux()  #讀COLOR SENSOR函數
            #print(f"初始顏色讀數: R={r}, G={g}, B={b}, Lux={lux:.2f}")
            #motor_mc(sp1, sp2, sp3, sp4,2,600)
            #time.sleep(2)
            #angle_x = get_angle(REG_ANGLE_X)
            #angle_y = get_angle(REG_ANGLE_Y)            
            #angle_z = get_angle(REG_ANGLE_Z)
            #print(f"X軸角度: {angle_x:.2f} 度, Y軸角度: {angle_y:.2f} 度, Z軸角度: {angle_z:.2f} 度")
            #print(f"左觸碰: {adc1.read()}, 右觸碰: {adc2.read()}")
            #print(cam_data()) #讀CAMERA函數
            #find_victim() #找到人質
            #led_blink()
            maze_explore()
            print("==============START===========")
            buffer = ""#清空LASER串口緩存，////不能刪/////            
        else:
            print("==============PAUSE===========")
            motor_control(0 , 0 , 0 , 0 )
            angle = servo.set_angle(80)      
            read_data_5() #讀LASER值函數
            r, g, b, lux = get_color_and_lux() #讀COLOR SENSOR函數
            print(f"初始顏色讀數: R={r}, G={g}, B={b}, Lux={lux:.2f}")
            #print(read_laser_gyro)
            
            angle_x = get_angle(REG_ANGLE_X)
            angle_y = get_angle(REG_ANGLE_Y)            
            angle_z = get_angle(REG_ANGLE_Z)
            print(f"X軸角度: {angle_x:.2f} 度, Y軸角度: {angle_y:.2f} 度, Z軸角度: {angle_z:.2f} 度")
            print(f"左觸碰: {adc1.read()}, 右觸碰: {adc2.read()}")
            print(left_no_wall())
            print(right_no_wall())
            print(front_no_wall())
            
            clear_display()
            
            oled_display(0, 0,  f"d1:{d1}")
            oled_display(0, 16, f"d2:{d2}")
            oled_display(0, 32, f"d3:{d3}")
            oled_display(0, 48, f"d4:{d4}")
            
            oled_display(58, 0,  f"d5:{d5}")
            oled_display(58, 16, f"d6:{d6}")
            oled_display(58, 32, f"d7:{d7}")
            oled_display(58, 48, f"{b},{lux:.1f}")
            
            print("==============PAUSE===========")
            #time.sleep(0.01) # 主循環延時
            buffer = ""  #清空LASER串口緩存////不能刪///// 


            '''
            # 讀取 X, Y, Z 軸角度
            angle_x = get_angle(REG_ANGLE_X)
            angle_y = get_angle(REG_ANGLE_Y)
            angle_z = get_angle(REG_ANGLE_Z)

            print(f"X軸角度: {angle_x:.2f} 度, Y軸角度: {angle_y:.2f} 度, Z軸角度: {angle_z:.2f} 度")
            time.sleep(0.1)            
            '''
            # 控制LED
            #led_blink(5)
            
            
            '''
            # 控制伺服馬達
            angle = servo.set_angle(0)
            time.sleep(1)       
            angle = servo.set_angle(90)
            time.sleep(1)
            
            # 控制馬達
            motor_control(speed, -speed, -speed, speed)
            time.sleep(3)
            print(encoder(1))
            motor_control(-speed, speed, speed, -speed)
            time.sleep(3)
            print(encoder(2))
            motor_control(0, 0, 0, 0)
            time.sleep(1)
            encoder_reset(1)
            encoder_reset(2)
            print(encoder(1))
            print(encoder(2))
            motor_mc(speed, -speed, -speed, speed,2,500)
            print(encoder(1))
            print(encoder(2))
            
            #presure sensor
            print(adc1.read())
            print(adc2.read())
            
            count += 1
            # 在OLED上顯示所有數據
            clear_display()
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr            oled_display(0, 0,  f"R:{r}")
            oled_display(0, 16, f"G:{g}")
            oled_display(0, 32, f"B:{b}")
            oled_display(0, 48, f"L:{lux:.0f}")
            
            oled_display(64, 0,  f"F1:{count}")
            oled_display(64, 16, f"F2:{count}")
            oled_display(64, 32, f"L1:{count}")
            oled_display(64, 48, f"L2:{count}")
            '''

