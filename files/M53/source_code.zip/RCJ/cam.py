from maix.v1 import lcd, sensor
from maix import uart, time
import math

# ==================== UART ====================
serial0 = uart.UART("/dev/ttyS0", 115200)
SEND_INTERVAL = 100   # ms
last_send_time = 0

# ==================== 鏡頭初始化 ====================
lcd.init()
sensor.reset()
sensor.set_framesize(sensor.QVGA)   # 320x240
sensor.run(1)

# ==================== LAB 顏色閾值 ====================
# 格式：(L_min, L_max, A_min, A_max, B_min, B_max)
# ★ 請用 MaixPy IDE → Tools → Machine Vision → Threshold Editor 現場微調
THRESHOLDS = {
    "Black":  [(0,  40, -20,  20, -20,  20)],
    "Red":    [(30, 80,  30,  90,  10,  70)],
    "Yellow": [(50, 95, -20,  20,  40,  90)],
    "Green":  [(20, 80, -60, -20,   0,  50)],
    "Blue":   [(20, 70, -10,  30, -60, -20)],
}

# 顏色數值
COLOR_VALUE = {"Black": -2, "Red": -1, "Yellow": 0, "Green": 1, "Blue": 2}

# LCD 顯示顏色 (RGB tuple for draw functions)
DRAW_COLOR = {
    "Black":       (180, 180, 180),
    "Red":         (255,  50,  50),
    "Yellow":      (255, 220,   0),
    "Green":       ( 50, 220,  80),
    "Blue":        ( 80, 160, 255),
    "None":        (255, 255, 255),
    "Harmed":      (255,  30,  30),
    "Stable":      ( 30, 200,  80),
    "Unharmed":    ( 60, 140, 255),
    "Fake Target": (160, 160, 160),
    "No Target":   (200, 200, 200),
}

# ==================== 輔助函式 ====================

def get_status(total):
    """根據 sum 值回傳狀態字串"""
    if   total == 0: return "Unharmed"
    elif total == 1: return "Stable"
    elif total == 2: return "Harmed"
    else:            return "Fake Target"


def classify_pixel(img, x, y, roi_size=8):
    """
    對畫面上 (x, y) 附近小區域取色，回傳最接近的顏色名稱。
    在小 ROI 內對每種顏色跑 find_blobs，取像素數最多的顏色。
    """
    x = max(roi_size, min(319 - roi_size, x))
    y = max(roi_size, min(239 - roi_size, y))
    roi = (x - roi_size//2, y - roi_size//2, roi_size, roi_size)

    best_color  = "None"
    best_pixels = 0
    for color_name, thresh in THRESHOLDS.items():
        blobs = img.find_blobs(thresh, roi=roi, merge=True)
        if blobs:
            px = max(blobs, key=lambda b: b.pixels()).pixels()
            if px > best_pixels:
                best_pixels = px
                best_color  = color_name
    return best_color


def find_target(img):
    """
    在畫面中定位靶圖圓心與最外圈半徑。
    策略：合併所有顏色的 blobs，找面積最大且最接近圓形的色塊。
    回傳 (cx, cy, radius) 或 None。
    """
    all_thresh = []
    for t in THRESHOLDS.values():
        all_thresh += t

    blobs = img.find_blobs(all_thresh, merge=True, margin=8)
    if not blobs:
        return None

    best = None
    best_score = 0
    for b in blobs:
        if b.pixels() < 300:
            continue
        rect_area = b.w() * b.h()
        if rect_area == 0:
            continue
        # 圓形度 = 實際像素 / 外接矩形面積（越接近 1 越圓）
        circularity = b.pixels() / rect_area
        score = b.pixels() * circularity
        if score > best_score:
            best_score = score
            best = b

    if best is None:
        return None

    cx = best.cx()
    cy = best.cy()
    radius = min(best.w(), best.h()) // 2
    return (cx, cy, radius)


# ==================== 方法 A：同心圓採樣點取色 ====================

def method_A_sampling(img, cx, cy, R):
    """
    在 5 個環的中線半徑上各取 4 方向採樣點（上下左右），
    投票決定每環顏色，回傳 [ring1, ring2, ring3, ring4, ring5]（內→外）。
    """
    # 各環中線半徑比例（內→外）
    ratios = [0.10, 0.30, 0.50, 0.70, 0.90]
    ring_colors = []

    for ratio in ratios:
        r = int(R * ratio)
        if r < 2:
            r = 2

        # 4 方向採樣點
        sample_pts = [
            (cx + r, cy),
            (cx - r, cy),
            (cx,     cy + r),
            (cx,     cy - r),
        ]

        # 投票
        votes = {}
        for sx, sy in sample_pts:
            c = classify_pixel(img, sx, sy)
            if c != "None":
                votes[c] = votes.get(c, 0) + 1

        # 取票數最多的顏色
        best_c = "None"
        best_v = 0
        for c, v in votes.items():
            if v > best_v:
                best_v = v
                best_c = c
        ring_colors.append(best_c)

    return ring_colors


# ==================== 方法 B：水平掃描線取色 ====================

def method_B_scanline(img, cx, cy, R):
    """
    從圓心向右掃描水平線，每次顏色切換代表進入下一個環。
    回傳 [ring1, ring2, ring3, ring4, ring5]（內→外）。
    注意：掃描方向是從內到外，所以第一個顏色是最內圈。
    """
    colors = []
    prev_color = None
    # 從圓心向右掃描到 R+5 的範圍
    for x in range(cx, min(cx + R + 5, 319)):
        c = classify_pixel(img, x, cy, roi_size=6)
        if c != "None" and c != prev_color:
            colors.append(c)
            prev_color = c
        if len(colors) == 5:
            break

    # 不足 5 個則補 None
    while len(colors) < 5:
        colors.append("None")

    return colors


# ==================== 雙重驗證合併 ====================

def merge_results(colors_A, colors_B):
    """
    合併方法 A 與方法 B 的結果：
    - 若兩者一致，直接採用
    - 若不一致，優先採用方法 A（採樣點投票較穩定）
    - 若方法 A 為 None，改用方法 B
    """
    merged = []
    for a, b in zip(colors_A, colors_B):
        if a != "None":
            merged.append(a)
        elif b != "None":
            merged.append(b)
        else:
            merged.append("None")
    return merged


# ==================== 主迴圈 ====================

# 狀態平滑：連續 N 幀相同才更新輸出（防抖動）
CONFIRM_FRAMES = 3
confirm_buffer = []
confirmed_status = "No Target"
confirmed_sum    = 0
confirmed_rings  = ["None"] * 5

while True:
    img = sensor.snapshot()

    # ---- Step 1：定位靶圖 ----
    result = find_target(img)

    if result:
        cx, cy, R = result

        # ---- Step 2A：同心圓採樣 ----
        colors_A = method_A_sampling(img, cx, cy, R)

        # ---- Step 2B：掃描線 ----
        colors_B = method_B_scanline(img, cx, cy, R)

        # ---- Step 3：合併結果 ----
        ring_colors = merge_results(colors_A, colors_B)

        # ---- Step 4：計算 sum 與狀態 ----
        if "None" not in ring_colors:
            total = sum(COLOR_VALUE[c] for c in ring_colors)
            status = get_status(total)
        else:
            total  = 0
            status = "No Target"

        # ---- Step 5：防抖動（連續 N 幀確認）----
        confirm_buffer.append(status)
        if len(confirm_buffer) > CONFIRM_FRAMES:
            confirm_buffer.pop(0)

        if confirm_buffer.count(status) >= CONFIRM_FRAMES:
            confirmed_status = status
            confirmed_sum    = total
            confirmed_rings  = ring_colors

        # ---- Step 6：LCD 顯示 ----
        # 畫各環採樣圓圈
        ratios = [0.10, 0.30, 0.50, 0.70, 0.90]
        for i, ratio in enumerate(ratios):
            r = int(R * ratio)
            c_name = ring_colors[i] if i < len(ring_colors) else "None"
            img.draw_circle(cx, cy, r, DRAW_COLOR[c_name], thickness=2)

        img.draw_cross(cx, cy, color=(255, 255, 255), size=6)

        # 各環顏色縮寫
        abbrev = {"Black":"Bk","Red":"R","Yellow":"Y","Green":"G","Blue":"Bl","None":"?"}
        ring_str = "->".join([abbrev.get(c, "?") for c in ring_colors])
        img.draw_string(4,  4, "A: " + "->".join([abbrev.get(c,"?") for c in colors_A]),
                        (200, 200, 200), scale=1.0)
        img.draw_string(4, 18, "B: " + "->".join([abbrev.get(c,"?") for c in colors_B]),
                        (180, 180, 180), scale=1.0)
        img.draw_string(4, 32, "Sum: " + str(confirmed_sum),
                        (255, 220, 0), scale=1.5)

    else:
        confirmed_status = "No Target"
        confirmed_sum    = 0
        confirmed_rings  = ["None"] * 5
        confirm_buffer.clear()
        img.draw_string(4, 4, "No Target", (200, 200, 200), scale=1.5)

    # 最終狀態大字顯示（固定在畫面下方）
    sc = DRAW_COLOR.get(confirmed_status, (255, 255, 255))
    img.draw_string(4, 80, confirmed_status, sc, scale=2.5)

    lcd.display(img)

    # ---- Step 7：UART 傳送 ----
    # 格式：$Status@Sum@R1@R2@R3@R4@R5#
    # 例如：$Harmed@2@Blue@Yellow@Yellow@Yellow@Yellow#
    current_time = time.ticks_ms()
    if current_time - last_send_time >= SEND_INTERVAL:
        r = confirmed_rings
        msg = ('$' + confirmed_status +
               '@' + str(confirmed_sum) +
               '@' + r[0] + '@' + r[1] + '@' + r[2] + '@' + r[3] + '@' + r[4] +
               '#')
        serial0.write_str(msg)
        print("Sent:", msg)
        last_send_time = current_time

    time.sleep_ms(5)	