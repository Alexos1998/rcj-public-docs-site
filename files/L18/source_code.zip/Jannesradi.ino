#include <FastLED.h>
#include<Arduino.h>
#include<Servo.h>
#include<cmath>
#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h>
#include <EEPROM.h>


#define pm pinMode
#define dw digitalWrite
#define dr digitalRead
#define aw analogWrite
#define ar analogRead

Servo desnaruka;
Servo lijevaruka;
Servo desni;
Servo lijevi;
Servo gyat;

int counter=0;

const int findball=300;

int udaljenost;

int loptacount=0;

int vrijeme,sad;
int veri=0;

String msg;
String pravo;

bool istina;
int imaga=0;

String smjer;
float okret;

const int tipl = 33;
const int tipk = 21;
const int tipd = 31;

const uint8_t liddg1 = 3;
const int lids1 = 17;
const int lidlg = 5;
const uint8_t lidld1 = 6;

const int prepko = 12;

const int imalopte = 20;

const int pwml = 29;
const int motl1 = 26;
const int motl2 = 27;

const int pwmd = 28;
const int motd1 = 25;
const int motd2 = 24;
const int stby = 30;

const int rrchek = 21;

char ch1 = '1';
char ch2 = '6';
char ch3 = '0';
char chz = 'n';
char chb = 'n';
int time_t1=0;
int time_p=0;

Adafruit_BNO055 bno = Adafruit_BNO055(55);
 
#define NUM_LEDS_PER_STRIP 8
CRGB redLeds[NUM_LEDS_PER_STRIP];
CRGB greenLeds[NUM_LEDS_PER_STRIP];
 

void setup() {
  //Serial1.begin(9600);
  Serial.begin(9600);

  bno.setExtCrystalUse(true);

  pinMode(34, OUTPUT);
  pinMode(motl1, OUTPUT);
  pinMode(motl2, OUTPUT);
  pinMode(pwml, OUTPUT);
  pinMode(motd1, OUTPUT);
  pinMode(motd2, OUTPUT);
  pinMode(pwmd, OUTPUT);
  pinMode(stby, OUTPUT);
  digitalWrite(stby, HIGH);


  pinMode(lidlg, INPUT_PULLUP);
  pinMode(tipl, INPUT_PULLUP);
  pinMode(tipk, INPUT_PULLUP);

  pinMode(imalopte, INPUT);
  pinMode(rrchek, INPUT);

  pinMode(prepko, INPUT);

  desni.attach(8);
  lijevi.attach(9);

  desnaruka.attach(10);
  desnaruka.write(70);
  delay(100);
  desnaruka.detach();



 delay(1000);
 Serial1.begin(115200);
 dilej(1000);
 gore_s();
 //dolje();
 Serial1.end();
 Serial1.begin(9600);
 for(int i = 0; i < 10; i++) {
    Serial1.print("l");
    delay(180);
 }
 Serial1.end();

 Serial1.begin(115200);
 //EEPROM.write(0,0);
 
 if(!bno.begin())
  {
    Serial.print("Ooops, no BNO055 detected ... Check your wiring or I2C ADDR!");
    //while(1);
  }
  loptacount = int (EEPROM.read(0));

  dolje();


 
}
 
void loop() { 
  //sensors_event_t event;
  //bno.getEvent(&event);
  //Serial.println(ar(imalopte));
  //izlazi_van();
  //Serial.print(dr(tipl));
  //Serial.println(dr(lidlg));
  //lids();
  //Serial.println(millis());
  /*
  lids();
  Serial.println(udaljenost);
  while(udaljenost>61){

  
    
    lids();
    //gomez(140,140);
  }
  gomez(0,0);
  */
  //izlazi_van1();
  
  
  rr();
  readpi();
  pid();
  crv();
  zel();
  krit();
  kos();
  prep1();
  
  
  //ulazi_unutra();
  
  //prep();
  
  
  //kos();
  //msg=Serial1.read();
  //delay(1000);
/*
  Serial1.begin(9600);
  for(int i = 0; i < 10; i++) {
    Serial1.print("a");
    delay(180);
  }
  Serial1.end();
  while(1>0){
  okretanje();
  }
  */


  

}




