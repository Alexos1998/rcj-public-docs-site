
void neopixel(){

  for(int i = 0; i < NUM_LEDS_PER_STRIP; i++) {
    // set our current dot to red, green, and blue
    //redLeds[i] = CRGB::Yellow;
    FastLED.setBrightness(50);
    FastLED.show();
    // clear our current dot before we move on
    //redLeds[i] = CRGB::Black;  
    //greenLeds[i] = CRGB::Black;
    delay(1);
  }
  delay(300);
  for(int i = 0; i < NUM_LEDS_PER_STRIP; i++) {
    // set our current dot to red, green, and blue
    //redLeds[i] = CRGB::Black;
    FastLED.setBrightness(50);
    FastLED.show();
    // clear our current dot before we move on
    //redLeds[i] = CRGB::Black;  
    //greenLeds[i] = CRGB::Black;
    delay(1);
  }
  delay(300);
  
}
void gomez(int l, int d) {
  if (l < 0) {
    digitalWrite(motd1, HIGH);
    digitalWrite(motd2, LOW);
    analogWrite(pwmd, -l);
  } else {
    digitalWrite(motd1, LOW);
    digitalWrite(motd2, HIGH);
    analogWrite(pwmd, l);
  }
  if (d < 0) {
    digitalWrite(motl1, HIGH);
    digitalWrite(motl2, LOW);
    analogWrite(pwml, -d);
  } else {
    digitalWrite(motl1, LOW);
    digitalWrite(motl2, HIGH);
    analogWrite(pwml, d);
  }
}




void gore() {
  desnaruka.attach(10);
  lijevaruka.attach(11);
  lijevaruka.write(20);
  desnaruka.write(110);
  desni.write(50);
  lijevi.write(130);
  //delay(100);
  //desni.write(18);
  //lijevi.write(162);
  delay(300);
  desnaruka.detach();
  lijevaruka.detach();
}
void gore_s() {
  desnaruka.attach(10);
  lijevaruka.attach(11);
  lijevaruka.write(110);
  desnaruka.write(40);
  desni.write(40);
  lijevi.write(140);
  //delay(100);
  //desni.write(18);
  //lijevi.write(162);
  delay(300);
  desnaruka.detach();
  lijevaruka.detach();
}

void dolje() {
  desni.write(180);
  lijevi.write(0);
}

void dokuta() {
  desnaruka.attach(10);
  lijevaruka.attach(11);
  lijevaruka.write(20);
  desnaruka.write(110);
  desni.write(180);
  lijevi.write(0);
  delay(500);

}

void open_ruke() {
  desnaruka.attach(10);
  lijevaruka.attach(11);
  lijevaruka.write(110);
  desnaruka.write(70);
  delay(500);
  desnaruka.detach();
  lijevaruka.detach();
}
void close_ruke() {
  desnaruka.attach(10);
  lijevaruka.attach(11);
  lijevaruka.write(40);
  desnaruka.write(110);
  delay(500);
  desnaruka.detach();
  lijevaruka.detach();
}
void bacanje(){
  gomez(0,0);
  open_ruke();
  desni.write(130);
  lijevi.write(50);
  delay(500);
  desni.write(50);
  lijevi.write(130);
}

void lids() {
  int16_t t4 = pulseIn(lids1, HIGH);
  udaljenost=1000;
  if (t4 == 0) {
    //Serial.println("timeout");
    udaljenost=1000;
  } else if (t4 > 1850) {
    //Serial.println(-1);<
    udaljenost = 1000;
  } else {
    int16_t ddg = (t4 - 1000) * 4;

    if (ddg < 0) { ddg = 0; }

    //Serial.println(ddg);
    udaljenost = ddg;
  }
}


void lidd() {
  int16_t t4 = pulseIn(liddg1, HIGH);
  udaljenost=1000;
  if (t4 == 0) {
    Serial.println("timeout");
  } else if (t4 > 1850) {
    Serial.println(-1);
    udaljenost = 10000;
  } else {
    int16_t ddg = (t4 - 1000) * 4;

    if (ddg < 0) { ddg = 0; }

    //Serial.println(ddg);
    udaljenost = ddg;
  }
}



void lidl() {
  int16_t t1 = pulseIn(lidld1, HIGH);
  udaljenost=1000;
  if (t1 == 0) {
    Serial.println("timeout");
    udaljenost = 1000;
  } else if (t1 > 1850) {
    Serial.println(-1);
    udaljenost = 1000;
  } else {
    int16_t dld = (t1 - 1000) * 4;

    if (dld < 0) { dld = 0; }

    //Serial.println(dld);
    udaljenost = dld;
  }
}


void turn(float d){
  sensors_event_t event;
  bno.getEvent(&event);
  if(d>0){
    float dokud;
    if ((d+float(event.orientation.x))>360){
      dokud=abs((d+float(event.orientation.x))-360);
      while(event.orientation.x>dokud){
        Serial.print(dokud);
        Serial.print(" ");
        Serial.println(event.orientation.x);
        bno.getEvent(&event);
        gomez(100,-100);
      }
      while(float(event.orientation.x)<dokud){
        Serial.print(dokud);
        Serial.print(" ");
        Serial.println(event.orientation.x);
        bno.getEvent(&event);
        gomez(100,-100);
      }

    }
    else{
      dokud=d+float(event.orientation.x);
      while(float(event.orientation.x)<dokud){
        Serial.print(dokud);
        Serial.print(" ");
        Serial.println(event.orientation.x);
        bno.getEvent(&event);
        gomez(100,-100);
      }
    }
    gomez(0,0);
  }



  if(d<0){
    float dokud;
    if ((d+float(event.orientation.x))<0){
      dokud=360-abs((d+float(event.orientation.x)));
      while(event.orientation.x<dokud){
        Serial.print(dokud);
        Serial.print(" ");
        Serial.println(event.orientation.x);
        bno.getEvent(&event);
        gomez(-100,100);
      }
      while(float(event.orientation.x)>dokud){
        Serial.print(dokud);
        Serial.print(" ");
        Serial.println(event.orientation.x);
        bno.getEvent(&event);
        gomez(-100,100);
      }

    }
    else{
      dokud=d+float(event.orientation.x);
      while(float(event.orientation.x)>dokud){
        Serial.print(dokud);
        Serial.print(" ");
        Serial.println(event.orientation.x);
        bno.getEvent(&event);
        gomez(-100,100);
      }
    }
    gomez(0,0);
  }

}




