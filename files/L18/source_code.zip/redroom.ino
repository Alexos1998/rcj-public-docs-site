void okretanje(){
  trazi_l();
  gomez(140,-140);
  delay(500);
  gomez(0,0);
  delay(1000);
  izadi();
}

void okretanjek(){
  detekcijak();
  gomez(140,-140);
  delay(900);
  gomez(0,0);
  delay(1000);
  izadi();
}

void trazi_k(){
  for(int i = 0; i < 10; i++) {
    Serial1.print("z");
    delay(180);
  }
  counter=0;
  while(1>0){
    okretanjek();
  }
}

void trazi_l(){
  detekcija();
  if(okret!=0){
    vrijeme=millis();
    sad=millis();
    dolje();
    gomez(0,0);
    delay(300);
    while(dr(tipl)==1 and dr(lidlg)==1){
      sad=millis();
      gomez(100,98);
      if(ar(imalopte)<findball){
        gomez(100,100);
        delay(100);
        gomez(0,0);
        close_ruke();
        desnaruka.attach(10);
        lijevaruka.attach(11);
        lijevaruka.write(20);
        desnaruka.write(110);
        gomez(-100,-100);
        delay(300);
        desnaruka.detach();
        lijevaruka.detach();
        gore();
        gomez(-100,-100);
        delay(abs(sad-vrijeme-700));
        gomez(0,0);
        Serial.begin(9600);
        delay(300);
        trazi_k();
      }
    }

    gomez(100,98);
    delay(500);
    if(ar(imalopte)<findball){
      gomez(100,100);
      delay(100);
      gomez(0,0);
      close_ruke();
      desnaruka.attach(10);
      lijevaruka.attach(11);
      lijevaruka.write(20);
      desnaruka.write(110);
      gomez(-100,-100);
      delay(300);
      desnaruka.detach();
      lijevaruka.detach();
      gore();
      gomez(-100,-100);
      delay(abs(sad-vrijeme-700));
      gomez(0,0);
      Serial.begin(9600);
      delay(300);
      trazi_k();
    }


    gomez(-100,-100);
    delay(abs(sad-vrijeme-400));
    gomez(0,0);
    gore();
    //delay(500);
    open_ruke();
  }
}

void detekcijak(){
  okret=0;
  vrijeme=millis();
  sad=millis();
  
  Serial1.begin(9600);
  delay(300);
  while(sad-vrijeme<300){
    
    sad=millis();
    msg=Serial1.read();
    if(msg=="d"){
      for(int i = 0; i < 4; i++) {
        istina=1;
        smjer="D";
        msg=Serial1.read();
        pravo=pravo+msg;
        delay(55);
      }
      if(isDigit(pravo[0]) and isDigit(pravo[2]) and isDigit(pravo[3]) ){
        Serial.print(smjer);
        Serial.println(pravo);
        okret=pravo.toFloat();
      }
    }
    if(msg=="l"){
      for(int i = 0; i < 4; i++) {
        istina=0;
        smjer="L";
        msg=Serial1.read();
        pravo=pravo+msg;
        delay(55);
      }
      if(isDigit(pravo[0]) and isDigit(pravo[2]) and isDigit(pravo[3]) ){
        Serial.print(smjer);
        Serial.println(pravo);
        okret=pravo.toFloat();
      }


    }
    
  }
  if(isDigit(pravo[0]) and isDigit(pravo[2]) and isDigit(pravo[3]) ){
        imaga=1;
  }
  //Serial.print(smjer);
  //Serial.println(okret);
  Serial1.end();
  delay(100);

  

  
  pravo="";


  
  if(istina==1 && imaga==1){
    gomez(100,-100);
    delay(okret*1000);
    gomez(0,0);
    Serial1.begin(9600);
    vrijeme=millis();
    sad=millis();
    //dokuta();
    gomez(140,140);
    delay(300);
    lids();
    while(udaljenost > 61){
      lids();
      //gomez(140,140);
      delay(10);
      sad=millis();
    }
    gomez(100,-100);
    delay(300);
    //gomez(0,0);
    //delay(400);
    //gore();
    gomez(100,100);
    delay(350);
    gomez(0,0);
    delay(200);
    bacanje();
    gomez(-100,100);
    delay(300);
    gomez(-140,-140);
    delay(abs(sad-vrijeme+100));
    gomez(0,0);

    if(loptacount==0){
      for(int i = 0; i < 10; i++) {
        Serial1.print("a");
        delay(180);
      }
      loptacount=1;
      EEPROM.write(0,1);
      Serial1.end();
      imaga=0;
      counter=0;
      while(1>0){
        okretanje();
      }
    }
    else if(loptacount==1){
      for(int i = 0; i < 10; i++) {
        Serial1.print("d");
        delay(180);
      }
      loptacount=2;
      EEPROM.write(0,2);
      Serial1.end();
      imaga=0;
      counter=0;
      while(1>0){
        okretanjec();
      }
    }
    else if(loptacount==2){
      while(1>0){
        delay(1000);
      }
    }
  }
  if(istina==0 && imaga==1){
    gomez(-100,100);
    delay(okret*1000);
    gomez(0,0);
    Serial1.begin(9600);
    sad=millis();
    vrijeme=millis();
    //dokuta();
    gomez(140,140);
    delay(300);

    lids();
    while(udaljenost>61){
      lids();
      delay(10);
      sad=millis();
      //gomez(140,140);
    }
    gomez(-100,100);
    delay(300);
    //gomez(0,0);
    //delay(400);
    //gore();
    gomez(100,100);
    delay(350);
    gomez(0,0);
    delay(200);
    bacanje();
    gomez(100,-100);
    delay(300);
    gomez(-140,-140);
    delay(abs(sad-vrijeme+100));
    gomez(0,0);


    if(loptacount==0){
      for(int i = 0; i < 10; i++) {
        Serial1.print("a");
        delay(180);
      }
      loptacount=1;
      EEPROM.write(0,1);
      Serial1.end();
      imaga=0;
      counter=0;
      while(1>0){
        okretanje();
      }
    }
    else if(loptacount==1){
      for(int i = 0; i < 10; i++) {
        Serial1.print("d");
        delay(180);
      }
      loptacount=2;
      EEPROM.write(0,2);
      Serial1.end();
      imaga=0;
      counter=0;
      while(1>0){
        okretanjec();
      }
    }
    else if(loptacount==2){
      while(1>0){
        delay(1000);
      }
    }

  }
  
  
}



void detekcija(){
  okret=0;
  vrijeme=millis();
  sad=millis();
  
  Serial1.begin(9600);
  delay(300);
  while(sad-vrijeme<500){
    
    sad=millis();
    msg=Serial1.read();
    if(msg=="d"){
      for(int i = 0; i < 4; i++) {
        istina=1;
        smjer="D";
        msg=Serial1.read();
        pravo=pravo+msg;
        delay(55);
      }
      if(isDigit(pravo[0]) and isDigit(pravo[2]) and isDigit(pravo[3]) ){
        Serial.print(smjer);
        Serial.println(pravo);
        okret=pravo.toFloat();
      }
    }
    if(msg=="l"){
      for(int i = 0; i < 4; i++) {
        istina=0;
        smjer="L";
        msg=Serial1.read();
        pravo=pravo+msg;
        delay(55);
      }
      if(isDigit(pravo[0]) and isDigit(pravo[2]) and isDigit(pravo[3]) ){
        Serial.print(smjer);
        Serial.println(pravo);
        okret=pravo.toFloat();
      }


    }
    
  }
  //Serial.print(smjer);
  //Serial.println(okret);
  Serial1.end();
  delay(100);

  

  
  pravo="";

  
  if(istina){
    gomez(90,-90);
    delay(okret*1000);
    gomez(0,0);
    delay(1000);
  }
  if(istina==0){
    gomez(-100,100);
    delay(okret*1000);
    gomez(0,0);
    delay(1000);

  }
}




void okretanjec(){
  trazi_lc();
  gomez(140,-140);
  delay(500);
  gomez(0,0);
  delay(1000);
  izadi();
}

void okretanjekc(){
  detekcijakc();
  gomez(140,-140);
  delay(900);
  gomez(0,0);
  delay(1000);
  izadi();
}

void trazi_kc(){
  for(int i = 0; i < 10; i++) {
    Serial1.print("c");
    delay(180);
  }
  counter=0;
  while(1>0){
    okretanjekc();
  }
}

void trazi_lc(){
  detekcijac();
  if(okret!=0){
    vrijeme=millis();
    sad=millis();
    dolje();
    delay(300);
    while(dr(tipl)==1 and dr(lidlg)==1){
      sad=millis();
      gomez(100,98);
      if(ar(imalopte)<findball){
        gomez(100,100);
        delay(100);
        gomez(0,0);
        close_ruke();
        desnaruka.attach(10);
        lijevaruka.attach(11);
        lijevaruka.write(20);
        desnaruka.write(110);
        gomez(-100,-100);
        delay(300);
        desnaruka.detach();
        lijevaruka.detach();
        gore();
        gomez(-100,-100);
        delay(abs(sad-vrijeme-700));
        gomez(0,0);
        

        trazi_kc();
      }
    }
    gomez(100,98);
    delay(500);
    if(ar(imalopte)<findball){
      gomez(100,100);
      delay(100);
      gomez(0,0);
      close_ruke();
      desnaruka.attach(10);
      lijevaruka.attach(11);
      lijevaruka.write(20);
      desnaruka.write(110);
      gomez(-100,-100);
      delay(300);
      desnaruka.detach();
      lijevaruka.detach();
      gore();
      gomez(-100,-100);
      delay(abs(sad-vrijeme-700));
      gomez(0,0);
      trazi_kc();
    }
    gomez(-100,-100);
    delay(abs(sad-vrijeme-400));
    gomez(0,0);
    gore();
    //delay(500);
    open_ruke();
  }
}

void detekcijakc(){
  okret=0;
  vrijeme=millis();
  sad=millis();
  
  Serial1.begin(9600);
  delay(300);
  while(sad-vrijeme<300){
    
    sad=millis();
    msg=Serial1.read();
    if(msg=="d"){
      for(int i = 0; i < 4; i++) {
        istina=1;
        smjer="D";
        msg=Serial1.read();
        pravo=pravo+msg;
        delay(55);
      }
      if(isDigit(pravo[0]) and isDigit(pravo[2]) and isDigit(pravo[3]) ){
        Serial.print(smjer);
        Serial.println(pravo);
        okret=pravo.toFloat();
      }
    }
    if(msg=="l"){
      for(int i = 0; i < 4; i++) {
        istina=0;
        smjer="L";
        msg=Serial1.read();
        pravo=pravo+msg;
        delay(55);
      }
      if(isDigit(pravo[0]) and isDigit(pravo[2]) and isDigit(pravo[3]) ){
        Serial.print(smjer);
        Serial.println(pravo);
        okret=pravo.toFloat();
      }


    }
    
  }
  if(isDigit(pravo[0]) and isDigit(pravo[2]) and isDigit(pravo[3]) ){
        imaga=1;
  }
  //Serial.print(smjer);
  //Serial.println(okret);
  Serial1.end();
  delay(100);

  

  
  pravo="";


  
  if(istina==1 && imaga==1){
    gomez(100,-100);
    delay(okret*1000);
    gomez(0,0);
    Serial1.begin(9600);
    sad=millis();
    vrijeme=millis();
    //dokuta();
    
    gomez(140,140);
    delay(300);
    lids();
    while(udaljenost>61){
      lids();
      delay(10);
      sad=millis();
      //gomez(140,140);
    }
    gomez(100,-100);
    delay(300);
    //gomez(0,0);
    //delay(400);
    //gore();
    gomez(100,100);
    delay(350);
    gomez(0,0);
    delay(200);
    bacanje();
    gomez(-100,100);
    delay(300);
    gomez(-100,-100);
    delay(700);
    dolje();
    gomez(-100,100);
    delay(1100);
    gomez(0,0);
    loptacount=3;
    EEPROM.write(0,3);
    gomez(0,0);
    delay(1000);
    while(1>0){
      izlazi_van1();
    }
  }
  if(istina==0 && imaga==1){
    gomez(-100,100);
    delay(okret*1000);
    gomez(0,0);
    Serial1.begin(9600);
    sad=millis();
    vrijeme=millis();
    //dokuta();
    gomez(140,140);
    delay(300);
    lids();
    while(udaljenost>61){
      lids();
      delay(10);
      sad=millis();
      //gomez(140,140);
    }
    gomez(-100,100);
    delay(300);
    //gomez(0,0);
    //delay(400);
    //gore();
    gomez(100,100);
    delay(350);
    gomez(0,0);
    delay(200);
    bacanje();
    gomez(100,-100);
    delay(300);
    gomez(-100,-100);
    delay(700);
    dolje();
    gomez(-100,100);
    delay(1100);
    gomez(0,0);
    loptacount=3;
    EEPROM.write(0,3);
    gomez(0,0);
    delay(1000);
    while(1>0){
      izlazi_van1();
    }

  }
  
}



void detekcijac(){
  okret=0;
  vrijeme=millis();
  sad=millis();

  Serial1.begin(9600);
  delay(300);
  while(sad-vrijeme<400){
    
    sad=millis();
    msg=Serial1.read();
    if(msg=="d"){
      for(int i = 0; i < 4; i++) {
        istina=1;
        smjer="D";
        msg=Serial1.read();
        pravo=pravo+msg;
        delay(55);
      }
      if(isDigit(pravo[0]) and isDigit(pravo[2]) and isDigit(pravo[3]) ){
        Serial.print(smjer);
        Serial.println(pravo);
        okret=pravo.toFloat();
      }
    }
    if(msg=="l"){
      for(int i = 0; i < 4; i++) {
        istina=0;
        smjer="L";
        msg=Serial1.read();
        pravo=pravo+msg;
        delay(55);
      }
      if(isDigit(pravo[0]) and isDigit(pravo[2]) and isDigit(pravo[3]) ){
        Serial.print(smjer);
        Serial.println(pravo);
        okret=pravo.toFloat();
      }


    }
    
  }
  //Serial.print(smjer);
  //Serial.println(okret);
  Serial1.end();
  delay(100);

  

  
  pravo="";


  
  if(istina){
    gomez(90,-90);
    delay(okret*1000);
    gomez(0,0);
    delay(1000);
  }
  if(istina==0){
    gomez(-100,100);
    delay(okret*1000);
    gomez(0,0);
    delay(1000);

  }
}


void prati_zid(){
  if(dr(tipl)==0 or dr(lidlg)==0){
    gomez(-100,-100);
    delay(500);
    gomez(0,120);
    delay(850);
  }
  gomez(110,100);
}

void izlazi_van(){
  if(dr(tipl)==0 or dr(lidlg)==0){
    lidd();
    if(udaljenost>400) {
      gomez(-100,-100);
      delay(500);
      gomez(0,0);
      gore_s();
      gomez(100,100);
      delay(500);
      gomez(100,-100);
      delay(1000);
      sad=millis();
      vrijeme=millis();
      int pizdun =0;
      while((sad-vrijeme)<1500){
        sad=millis();
        gomez(100,100);
        if(dr(rrchek)==0){
          pizdun=1;
        }
      }
      if(pizdun==0){
        gomez(0,0);
        Serial1.begin(9600);
        for(int i = 0; i < 10; i++) {
          Serial1.print("l");
          delay(180);
        }
        Serial1.end();
        gomez(-110,-110);
        delay(900);
        Serial1.begin(115200);
        while(1>0){
          readpi();
          pid();
          crv();
          zel();
          krit();
          //prep();
        }
          
      }
      pizdun=0;

      gomez(-100,-100);
      delay(2000);
      gomez(-100,100);
      delay(1300);
      gomez(-100,-100);
      delay(500);
      dolje();
      
      sad=millis();
      vrijeme=millis();
      while((sad-vrijeme)<2000){
        sad=millis();
        gomez(110,100);
        if(dr(tipl)==0 or dr(lidlg)==0){
          gomez(-100,-100);
          delay(500);
          gomez(0,120);
          delay(850);
        }
      }
    }
    else{
      gomez(-100,-100);
      delay(500);
      gomez(0,120);
      delay(850);
    }
  }
  gomez(120,100);
}

void izlazi_van1(){
  lidd();
  if(udaljenost>400){
    lidl();
    if(udaljenost>400) {
      gomez(-100,-100);
      delay(700);
      gomez(-100,100);
      delay(600);
      gomez(100,100);
      delay(600);
      gomez(100,-100);
      delay(400);
      gomez(0,0);
      gore_s();
      sad=millis();
      vrijeme=millis();

      gomez(0,0);
      Serial1.begin(9600);
      for(int i = 0; i < 10; i++) {
        Serial1.print("l");
        delay(180);
      }
      Serial1.end();
      gomez(0,0);
      Serial1.begin(115200);
      dolje();
      while(1>0){
        readpi();
        pid();
        crv();
        zel();
        krit();
        prep();
      }
          
      

      gomez(-100,-100);
      delay(2000);
      gomez(-100,100);
      delay(1300);
      gomez(-100,-100);
      delay(500);
      dolje();
      
      sad=millis();
      vrijeme=millis();
      while((sad-vrijeme)<2000){
        sad=millis();
        gomez(110,100);
        if(dr(tipl)==0 or dr(lidlg)==0){
          gomez(-100,-100);
          delay(500);
          gomez(0,120);
          delay(850);
        }
      }
    }
  }
  if(dr(tipl)==0 or dr(lidlg)==0){
    gomez(-100,-100);
    delay(500);
    gomez(0,120);
    delay(850);
  }
  gomez(120,100);
}

void izlazi_van2(){
  if(dr(tipl)==0 or dr(lidlg)==0){
    lidd();
    if(udaljenost>400) {
      gomez(-100,-100);
      delay(500);
      gomez(0,0);
      gore_s();
      gomez(100,100);
      delay(500);
      gomez(100,-100);
      delay(1000);
      sad=millis();
      vrijeme=millis();
      int pizdun =0;
      while((sad-vrijeme)<1500){
        sad=millis();
        gomez(100,100);
        if(dr(rrchek)==0){
          pizdun=1;
        }
      }
      if(pizdun==0){
        gomez(0,0);
        Serial1.begin(9600);
        for(int i = 0; i < 10; i++) {
          Serial1.print("l");
          delay(180);
        }
        Serial1.end();
        gomez(-110,-110);
        delay(900);
        Serial1.begin(115200);
        while(1>0){
          readpi();
          pid();
          crv();
          zel();
          krit();
          //prep();
        }
          
      }
      pizdun=0;

      gomez(-100,-100);
      delay(2000);
      gomez(-100,100);
      delay(1300);
      gomez(-100,-100);
      delay(500);
      dolje();
      
      sad=millis();
      vrijeme=millis();
      while((sad-vrijeme)<2000){
        sad=millis();
        gomez(110,100);
        if(dr(tipl)==0 or dr(lidlg)==0){
          gomez(-100,-100);
          delay(500);
          gomez(0,120);
          delay(850);
        }
      }
    }
    else{
      gomez(-100,-100);
      delay(500);
      gomez(0,120);
      delay(850);
    }
  }

  lidd();
  if(udaljenost>400){
    lidl();
    if(udaljenost>400) {
      gore_s();
      gomez(-100,-100);
      delay(1600);
      turn(-95);
      dolje();
      gomez(100,100);
      delay(1000);
    }
  }

  gomez(120,100);
}


void rr(){
  if(dr(rrchek)==0){
    gomez(0,0);
    delay(670);
    if(dr(rrchek)==0){
      dolje();
      while(1>0){

        for(int i = 0; i < 10; i++) {
          Serial1.print("r");
          delay(180);
        }
        Serial1.end();

        gomez(0,0);
        delay(1000);
        while(1>0){
          ulazi_unutra1();
        }
      }
    }

  }
}

void ulazi_unutra(){
  if(loptacount==3){
    for(int i = 0; i < 10; i++) {
        Serial1.print("d");
        delay(180);
    }
    gomez(0,0);
    delay(1000);
    while(1>0){
      izlazi_van1();
    }
  }
  
  gomez(100,100);
  delay(3500);
  turn(90);
  gomez(100,100);
  delay(3000);
  gomez(0,0);
  

  
    /*gomez(-100,-100);
    delay(600);
    gomez(0,0);
    gore();
    open_ruke();
    delay(300);
    turn(-90);
    gomez(100,100);
    delay(2800);
    gomez(0,0);*/
    
  gore_s();
  while(1>0){
    Serial1.begin(9600);
    for(int i = 0; i < 10; i++) {
      Serial1.print("a");
      delay(180);
    }
    Serial1.end();
    if(loptacount==0 or loptacount==1){
      while(1>0){
        okretanje();
      }
    }
    if(loptacount==2){
      while(1>0){
        okretanjec();
      }
    }
    else{
      while(1>0){
        okretanje();
      }
    }
  }
  
  
  /*
  gore_s();
  gomez(100,100);
  delay(3400);
  gomez(100,-100);
  delay(1300);
  gomez(100,100);
  delay(700);
  gomez(0,0);

  while(1>0){
    Serial1.begin(9600);
    for(int i = 0; i < 10; i++) {
      Serial1.print("a");
      delay(180);
    }
    Serial1.end();
    counter=0;
    while(1>0){
      okretanje();
    }
  }
  */
  gomez(110,100);
}

void ulazi_unutra1(){
  if(loptacount==3){
    for(int i = 0; i < 10; i++) {
        Serial1.print("d");
        delay(180);
    }
    gomez(0,0);
    delay(1000);
    while(1>0){
      izlazi_van1();
    }
  }
  if(dr(tipl)==0 or dr(lidlg)==0){
  /*
  gomez(100,100);
  delay(3500);
  turn(90);
  gomez(100,100);
  delay(3000);
  gomez(0,0);
  */

  
    gomez(-100,-100);
    delay(600);
    gomez(0,0);
    gore();
    open_ruke();
    delay(300);
    turn(-90);
    gomez(100,100);
    delay(2800);
    gomez(0,0);
    
    gore_s();
    while(1>0){
      Serial1.begin(9600);
      for(int i = 0; i < 10; i++) {
        Serial1.print("a");
        delay(180);
      }
      Serial1.end();
      if(loptacount==0 or loptacount==1){
        while(1>0){
          okretanje();
        }
      }
      if(loptacount==2){
        while(1>0){
          okretanjec();
        }
      }
      else{
        while(1>0){
          okretanje();
        }
      }
    }
  }
  
  
  /*
  gore_s();
  gomez(100,100);
  delay(3400);
  gomez(100,-100);
  delay(1300);
  gomez(100,100);
  delay(700);
  gomez(0,0);

  while(1>0){
    Serial1.begin(9600);
    for(int i = 0; i < 10; i++) {
      Serial1.print("a");
      delay(180);
    }
    Serial1.end();
    counter=0;
    while(1>0){
      okretanje();
    }
  }
  */
  gomez(110,100);
}

void izadi(){
  counter=counter+1;
  if(counter>=15){
    dolje();
    sad=millis();
    vrijeme=millis();
    while(sad-vrijeme<2000){
      if(dr(tipl)==0 or dr(lidlg)==0){
        gomez(-100,-100);
        delay(500);
        gomez(0,120);
        delay(850);
      }
      sad=millis();
      gomez(100,100);
    }
    gomez(0,0);
    delay(1000);
    while(1>0){
      izlazi_van1();
    }
  }
}