void dilej(float t){
  time_t1=millis();
  while(millis()-time_t1<t){
    readpi();
  }
}

void readpi(){
  String m = Serial1.readStringUntil('\n');
  ch1 = m[0];
  ch2 = m[1];
  ch3 = m[2];
  chz = m[3];
  chb = m[4];
  Serial.println(chz);
}

void prep(){
  if(dr(tipl)==0 or dr(lidlg)==0){
    gomez(0,0);
    delay(200);
    gomez(-100,-100);
    dilej(500);
    turn(-85);
    gomez(100,100);
    dilej(1800);
    turn(85);
    gomez(100,100);
    dilej(1500);
    turn(-85);
    gomez(0,0);
    dilej(500);
  }
}

void prep1(){
  if(dr(tipl)==0 or dr(lidlg)==0){
    gomez(0,0);
    delay(200);
    gomez(-100,-100);
    dilej(100);
    turn(90);
    gomez(100,100);
    dilej(1200);
    turn(-85);
    gomez(100,100);
    dilej(1900);
    turn(-90);
    gomez(100,100);
    dilej(1200);
    turn(85);
    gomez(0,0);
    dilej(500);
  }
}

void kos(){
  sensors_event_t event;
  bno.getEvent(&event);
  Serial.println(event.orientation.y);
  /*if(event.orientation.y<-23){
    time_t1=millis();
    while(millis()-time_t1<100){
      readpi();
      pidkos();
    }
    gomez(0,0);
    dolje();
    while(event.orientation.y<-13){
      readpi();
      pidkos();
      bno.getEvent(&event);
    }
    while(millis()-time_t1<500){
      readpi();
      pidkos();
    }
    gomez(0,0);
    gore_s();
  }*/

  //else:
  if(event.orientation.y>7){
    time_t1=millis();
    while(millis()-time_t1<100){
      readpi();
      pidkosd();
    }
    while(event.orientation.y>7){
      readpi();
      pidkosd();
      bno.getEvent(&event);
    }
  }
}

void kos1(){
  sensors_event_t event;
  bno.getEvent(&event);
  Serial.println(event.orientation.y);
  if(event.orientation.y<-23){
    gomez(100,100);
    delay(200);
    gomez(0,0);
    dolje();
    /*gomez(200,200);
    dilej(1000);*/
    while(event.orientation.y<-11){
      readpi();
      pidkos();
      bno.getEvent(&event);
    }
    gomez(100,100);
    delay(200);
    gomez(0,0);
    gore_s();
  }

  else if(event.orientation.y>7){
    time_t1=millis();
    while(millis()-time_t1<100){
      readpi();
      pidkosd();
    }
    while(event.orientation.y>7){
      readpi();
      pidkosd();
      bno.getEvent(&event);
    }
  }
}

void crv(){
  if(chz == 'c'){
    gomez(0,0);
    EEPROM.write(0,0);
    dilej(7000);
  }
}

void krit(){
  if (chz == 'g'){
    gomez(0,0);
    dilej(200);
    while (chb == 'n'){
      gomez(130,-130);
      dilej(10);
    }
  }
  else if (chz == 'h'){
    gomez(0,0);
    dilej(200);
    while (chb == 'n'){
      gomez(-130,130);
      dilej(10);
    }
  }
}

void zel(){
  Serial.println(chz);
  if (chz == 'l' or chz =='d' or chz == 'o'){
    time_t1=millis();
    while(millis()-time_t1 < 20){
      readpi();
      pid();
    }
    if (chz == 'o'){
      gomez(0,0);
      delay(200);
      gomez(100,-100);
      dilej(2300);
    }
    else if (chz == 'd'){
      gomez(0,0);
      delay(200);
      gomez(100,100);
      delay(450);
      gomez(130,-130);
      dilej(350);
      while (chb == 'n'){
        gomez(100,-100);
        dilej(10);
      }
    }
    else if (chz == 'l'){
      gomez(0,0);
      delay(200);
      gomez(100,100);
      delay(450);
      gomez(-130,130);
      dilej(350);
      while (chb == 'n'){
        gomez(-100,100);
        dilej(10);
    }
    }
  }
}

void pidkosdi(){
  //Serial.println((int(ch1)-48)*100+(int(ch2)-48)*10+int(ch3)-48);
  int k = (int(ch1)-48)*100+(int(ch2)-48)*10+int(ch3)-48;
  k=k-160;
  if (k>0){
    if (k>50){
      k=50;
    }
    int okretni;
    if(100-k*1.5<40){
      okretni=40;
    }
    else{
      okretni = 100-k*1.5;
    }
    gomez(100+k,okretni);
    delay(1);
  }
  else{
    if (k<-50){
      k=-50;
    }
    int okretni;
    if(100+k*1.5<40){
      okretni=40;
    }
    else{
      okretni = 100+k*1.5;
    }
    gomez(100+k*1.5,100-k);
    delay(1);
  }
}

void pidkosd(){
  //Serial.println((int(ch1)-48)*100+(int(ch2)-48)*10+int(ch3)-48);
  int k = (int(ch1)-48)*100+(int(ch2)-48)*10+int(ch3)-48;
  k=k-160;
  if(k>40){
    gomez(0,-100);
    dilej(500);
    gomez(80,80);
    dilej(500);
  }
  else if(k<-40){
    gomez(-100,0);
    dilej(500);
    gomez(80,80);
    dilej(500);
  }
  gomez(80,80);
  delay(1);
  /*if (k>0){
    if (k>100){
      k=100;
    }
    gomez(50+k,50-k);
    delay(1);
  }
  else{
    if (k<-100){
      k=-100;
    }
    gomez(50+k,50-k);
    delay(1);
  }*/
}

void pidkos(){
  //Serial.println((int(ch1)-48)*100+(int(ch2)-48)*10+int(ch3)-48);
  int k = (int(ch1)-48)*100+(int(ch2)-48)*10+int(ch3)-48;
  k=k-160;
  if (k>0){
    if (k>100){
      k=100;
    }
    gomez(150+k,150-k*2.5);
    delay(1);
  }
  else{
    if (k<-100){
      k=-100;
    }
    gomez(150+k*2.5,150-k);
    delay(1);
  }
}

void pid(){
  //Serial.println((int(ch1)-48)*100+(int(ch2)-48)*10+int(ch3)-48);
  int k = (int(ch1)-48)*100+(int(ch2)-48)*10+int(ch3)-48;
  k=k-160;
  /*time_t1=millis();
  while(k==160){
    readpi();
    if(millis()-time_t1){

    }
  }*/
  if (k>0){
    if (k>110){
      k=110;
    }
    gomez(120+k,120-k*3);
    delay(1);
  }
  else{
    if (k<-110){
      k=-110;
    }
    gomez(120+k*3,120-k);
    delay(1);
  }
}