from machine import Pin, PWM, ADC
from time import sleep_ms, sleep

# =====================
# MOTOR DRIVER PINS
# =====================

stby = Pin(14, Pin.OUT)
stby.value(1)

# Motor A (Left)
ain1 = Pin(26, Pin.OUT)
ain2 = Pin(27, Pin.OUT)
pwma = PWM(Pin(25))
pwma.freq(1000)

# Motor B (Right)
bin1 = Pin(17, Pin.OUT)
bin2 = Pin(21, Pin.OUT)
pwmb = PWM(Pin(18))
pwmb.freq(1000)

# =====================
# LINE SENSORS PINS
# =====================

s1 = ADC(Pin(32))
s2 = ADC(Pin(33))
s3 = ADC(Pin(34))
s4 = ADC(Pin(35))
s5 = ADC(Pin(36))

for s in [s1, s2, s3, s4, s5]:
    s.atten(ADC.ATTN_11DB)

# =====================
# PID SETTINGS
# =====================

Kp = 9
Ki = 0
Kd = 0.3

BASE_SPEED = 10000
MIN_SPEED = 4000
MAX_SPEED = 65535

integral = 0
last_error = 0

# =====================
# MOTOR FUNCTIONS FORWARD
# =====================


def set_motors(left_speed, right_speed):

    left_speed = int(max(0, min(MAX_SPEED, left_speed)))
    right_speed = int(max(0, min(MAX_SPEED, right_speed)))

    ain1.value(0)
    ain2.value(1)
    pwma.duty_u16(left_speed)

    bin1.value(0)
    bin2.value(1)
    pwmb.duty_u16(right_speed)

# =====================
# MOTOR FUNCTIONS REVERSE
# =====================


def set_motors_reverse(left_speed, right_speed):

    left_speed = int(max(0, min(MAX_SPEED, left_speed)))
    right_speed = int(max(0, min(MAX_SPEED, right_speed)))

    ain1.value(1)
    ain2.value(0)
    pwma.duty_u16(left_speed)

    bin1.value(1)
    bin2.value(0)
    pwmb.duty_u16(right_speed)


def stop():
    pwma.duty_u16(0)
    pwmb.duty_u16(0)


# =====================
# WHUTE SURFACE COUNTER 
#=====================
white_counter = 0

# =====================
# FIND LINE AFTER WHITE SURFACE/GAP
# =====================


def Find_B_after_W():
    print("Finding B after W...")
    while True:
        values = [
            s1.read(),
            s2.read(),
            s3.read(),
            s4.read(),
            s5.read()
        ]
        print(values)

        set_motors(15000, 15000)
        sleep(0.5)

        if s2.read() <= 1800 or s3.read() <= 1800 or s4.read() <= 1800:
            print("Line detected again, stopping search.")
            stop()
            break
        else:
            print("Still no line detected, continuing search.")
            continue

# =====================
# READ LINE POSITION / CORNER DETECTION
# =====================



def read_position():

    values = [
        s1.read(),
        s2.read(),
        s3.read(),
        s4.read(),
        s5.read()
    ]

    total = sum(values)

    print(values)

    # no line
    if total < 500:
        return None

    # 🚨 90° CORNER FIX
    if (
        s1.read() <= 1500 and
        s2.read() <= 1000 and
        s3.read() <= 700 and
        s4.read() <= 700 and
        s5.read() >= 1900
    ):
        print(values)
        white_counter = 0
        return "CORNER LEFT"

    if (
        s1.read() >= 1900 and
        s2.read() <= 700 and
        s3.read() <= 700 and
        s4.read() <= 1000 and
        s5.read() <= 1500
    ):
        print(values)
        white_counter = 0
        return "CORNER RIGHT"

    if (
        s1.read() >= 2500 and
        s2.read() >= 2500 and
        s3.read() >= 2500 and
        s4.read() >= 2500 and
        s5.read() >= 1900

    ):
        print(values)
        return "White Surface"

    position = (
        values[0] * -4 +
        values[1] * -2 +
        values[2] * 0 +
        values[3] * 2 +
        values[4] * 4
    ) / total

    return position

# =====================
# START
# =====================


print("Sleeping for 3 seconds...")
sleep(3)
print("Starting line follower")

# =====================
# MAIN LOOP
# =====================

while True:

    position = read_position()

    # =====================
    # LINE LOST
    # =====================

    if position is None:
        if last_error < 0:
            set_motors(0, 0)
        else:
            set_motors(0, 0)
        continue

    # =====================
    # 90° CORNER HANDLING
    # =====================
    if position == "CORNER LEFT":
        print("Left corner detected!")
        stop()
        sleep(3)
        set_motors(12000, 0)
        sleep(1.6)
        set_motors_reverse(12000, 12000)
        sleep(0.8)
        stop()
        continue

    if position == "CORNER RIGHT":
        print("Right corner detected!")
        stop()
        sleep(3)
        set_motors(0, 11800)
        sleep(1.6)
        set_motors_reverse(12000, 12000)
        sleep(0.6)
        stop()
        continue

    if white_counter == 2:
        Find_B_after_W()
        white_counter = 0
        continue

    if position == "White Surface":
        white_counter += 1
        print("White surface detected!")
        stop()
        sleep(1)
        set_motors_reverse(12000, 12000)
        sleep(1.5)
        stop()
        continue

    # =====================
    # PID CONTROL
    # =====================

    error = position

    integral += error
    derivative = error - last_error

    correction = (
        Kp * error +
        Ki * integral +
        Kd * derivative
    )

    turn_strength = abs(error)

    dynamic_base_speed = BASE_SPEED - int(turn_strength * 50)

    if dynamic_base_speed < MIN_SPEED:
        dynamic_base_speed = MIN_SPEED

    STEERING_SENSITIVITY = 4000

    left_speed = dynamic_base_speed + correction * STEERING_SENSITIVITY
    right_speed = dynamic_base_speed - correction * STEERING_SENSITIVITY

    set_motors(left_speed, right_speed)

    last_error = error

    sleep_ms(10)
