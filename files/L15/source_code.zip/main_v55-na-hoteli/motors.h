#ifndef MOTORS_H
#define MOTORS_H

#include <Servo.h>
#include "configuration.h"

// --- EXTERNÉ PREMENNÉ A FUNKCIE ---
extern bool emergencyStop;
extern void sensorRead();
#include <Adafruit_BNO055.h>
extern Adafruit_BNO055 bno;
extern imu::Vector<3> euler;

// --- OBJEKTY A PREMENNÉ ---
Servo servoZb;
long motorTime = 0;
Servo servos[4];
int servoPos[] = { 12, 55, 55, 50 };
int8_t motorSpeed[] = { 0, 0 };  // lavy speed, pravy speed

///////////////////////////////////////////////////////////////////////////////------MOVEMENT-----//////////////////////////////////////////////////////////////////

void stopMovement() {
  motorSpeed[0] = 0;
  motorSpeed[1] = 0;
  digitalWrite(pl_mot[0], HIGH);
  digitalWrite(pl_mot[1], HIGH);

  digitalWrite(zl_mot[0], HIGH);
  digitalWrite(zl_mot[1], HIGH);

  digitalWrite(pp_mot[0], HIGH);
  digitalWrite(pp_mot[1], HIGH);

  digitalWrite(zp_mot[0], HIGH);
  digitalWrite(zp_mot[1], HIGH);
}

void setMovement(int8_t leftSpeed, int8_t rightSpeed) {
  while (motorSpeed[0] != leftSpeed || motorSpeed[1] != rightSpeed) {
    // DBG("              || motorLeft - ");
    // DBG(motorSpeed[0]);
    // DBG("  rightSpeed - ");
    // DBG(motorSpeed[1]);
    if (motorSpeed[0] < leftSpeed) {
      motorSpeed[0] += 2;
    } else if (motorSpeed[0] > leftSpeed) {
      motorSpeed[0] -= 2;
    }

    if (motorSpeed[1] < rightSpeed) {
      motorSpeed[1] += 3;
    } else if (motorSpeed[1] > rightSpeed) {
      motorSpeed[1] -= 3;
    }
    if(abs(motorSpeed[0] - leftSpeed) < 5) motorSpeed[0] = leftSpeed;
    if(abs(motorSpeed[1] - rightSpeed) < 5) motorSpeed[1] = rightSpeed;
    if (motorSpeed[0] > 0) {  ///////////////////////////////////////////////////////-LEFT FORWARD
      uint8_t leftSpeedCorrection = ::map(motorSpeed[0], 0, 100, 0, 255);
      digitalWrite(pl_mot[0], LOW);
      analogWrite(pl_mot[1], leftSpeedCorrection);
      digitalWrite(zl_mot[0], LOW);
      analogWrite(zl_mot[1], leftSpeedCorrection);
    } else {  ///////////////////////////////////////////////////////////////////-LEFT BACKWARD
      uint8_t leftSpeedCorrection = ::map(motorSpeed[0], -100, 0, 0, 255);
      digitalWrite(pl_mot[0], HIGH);
      analogWrite(pl_mot[1], leftSpeedCorrection);
      digitalWrite(zl_mot[0], HIGH);
      analogWrite(zl_mot[1], leftSpeedCorrection);
    }

    if (motorSpeed[1] > 0) {  //////////////////////////////////////////////////////-RIGHT FORWARD
      uint8_t rightSpeedCorrection = ::map(motorSpeed[1], 0, 100, 0, 255);
      digitalWrite(pp_mot[0], LOW);
      analogWrite(pp_mot[1], rightSpeedCorrection);
      digitalWrite(zp_mot[0], LOW);
      analogWrite(zp_mot[1], rightSpeedCorrection);
    } else {  ///////////////////////////////////////////////////////////////////-RIGHT BACKWARD
      uint8_t rightSpeedCorrection = ::map(motorSpeed[1], -100, 0, 0, 255);
      digitalWrite(pp_mot[0], HIGH);
      analogWrite(pp_mot[1], rightSpeedCorrection);
      digitalWrite(zp_mot[0], HIGH);
      analogWrite(zp_mot[1], rightSpeedCorrection);
    }
    delay(2);
  }

  motorSpeed[0] = leftSpeed;
  motorSpeed[1] = rightSpeed;
}

void timeMovement(int8_t leftSpeed, int8_t rightSpeed, int time, bool stopMotors) {
  motorTime = millis();
  setMovement(leftSpeed, rightSpeed);
  while (millis() < motorTime + time) {
    if (emergencyStop) {
      stopMovement();
      return;
    }
  }
  if (stopMotors == true) {  ////////////////////-ZASTAVENIE
    stopMovement();
  }
}

void degMovement(int8_t leftSpeed, int8_t rightSpeed, int deg, bool stopMotors) {

  euler = bno.getVector(Adafruit_BNO055::VECTOR_EULER);  //////////////-NACITANIE HODNOT GYRA
  float startDeg = euler.x();

  float endDeg = fmod(startDeg + deg + 360.0, 360.0);  ////////////////-POKIAL SA MA TOCIT

  setMovement(leftSpeed, rightSpeed);
  while (true) {  /////////////////////////////////////////////////////-DOKYM SA NEDOSTANE NA POZADOVANU POLOHU
    sensorRead();
    if (emergencyStop) {
      stopMovement();
      return;
    }
    euler = bno.getVector(Adafruit_BNO055::VECTOR_EULER);
    float current = euler.x();

    float diff = fmod(endDeg - current + 540.0, 360.0) - 180.0;  ////-KOLKO SA ESTE TREBA DOTOCIT

    Serial.println(diff);
    if (fabs(diff) < 3) break;  ///////////////////////////////////-KED SA DOSTANE NA POZADOVANU HODNOTU

    delay(20);
  }

  if (stopMotors) stopMovement();
}

void yzMovement(int8_t lsp, int8_t hsp, int8_t endPos, bool stopMotors) {
  float target[2];                                       //////-dopredu/dozadu[0], dolava/doprava[1]
  euler = bno.getVector(Adafruit_BNO055::VECTOR_EULER);  //////////////-NACITANIE HODNOT GYRA
  float actualDeg[2] = { (float)euler.y(), (float)euler.z() };
  float direction = 0;
  float dot = 0;
  float angle = 0;
  float maxTilt = sqrt(actualDeg[0] * actualDeg[0] + actualDeg[1] * actualDeg[1]);
  DBG("  maxTilt: ");
  DBGLN(maxTilt);
  switch (endPos) {
    case 0:  //hore
      target[0] = -maxTilt;
      target[1] = 0;
      break;
    case 1:  //hore vpravo
      target[0] = -(maxTilt * sqrt(2) / 2);
      target[1] = maxTilt * sqrt(2) / 2;
      break;
    case 2:  //vpravo
      target[0] = 0;
      target[1] = maxTilt;
      break;
    case 3:  //dole vpravo
      target[0] = maxTilt * sqrt(2) / 2;
      target[1] = maxTilt * sqrt(2) / 2;
      break;
    case 4:  //dole
      target[0] = maxTilt;
      target[1] = 0;
      break;
    case 5:  //dole vlavo
      target[0] = (maxTilt * sqrt(2) / 2);
      target[1] = -(maxTilt * sqrt(2) / 2);
      break;
    case 6:  //vlavo
      target[0] = 0;
      target[1] = -maxTilt;
      break;
    case 7:  //hore vlavo
      target[0] = -(maxTilt * sqrt(2) / 2);
      target[1] = -(maxTilt * sqrt(2) / 2);
      break;
  }
  do {
    euler = bno.getVector(Adafruit_BNO055::VECTOR_EULER);  //////////////-NACITANIE HODNOT GYRA
    actualDeg[0] = (float)euler.y();
    actualDeg[1] = (float)euler.z();
    direction = actualDeg[0] * target[1] - actualDeg[1] * target[0];  ///-akokeby vypocita velkost jednej osi v jednotkovej kruznici
    dot = actualDeg[0] * target[0] + actualDeg[1] * target[1];        ////-druha os v jednotkovej kruznici

    angle = atan2(direction, dot) * 180 / PI;  ///////////-pouzije velkosti dvoch bodov na osiach aby si nasiel uhol od x-ovej po vysledny bod, ktory vyjde v radianoch, preto prevod na stupne
    DBGLN(angle);
    if (angle > 0) {  ////////////-toci sa dolava
      setMovement(lsp, hsp);
    } else {  ///////////////////-toci sa doprava
      setMovement(hsp, lsp);
    }
  } while (abs(angle) > 2);  ////////////-kym nieje na pozadovanej hodnote
  if (stopMotors) stopMovement();
}

void servoMovement(int servo, int newPos) {
  newPos = constrain(newPos, 0, 100);                                ////////////-preistotu aby sa nepresiahol limit
  int target = ::map(newPos, 0, 100, minMap[servo], maxMap[servo]);  //////////////////////-vypocet na ktoru hodnotu musi ist servo

  int step = (target > servoPos[servo]) ? 2 : -2;  //////////////-do ktorej strany sa ma servo tocit

  for (int i = servoPos[servo]; (step > 0) ? (i < target) : (i > target); i += step) {  ///-tocenie
    servos[servo].write(i);
    servoPos[servo] = i;
    delay(10);
  }

  // dorovnanie presne na target
  servos[servo].write(target);
  servoPos[servo] = target;
}
#endif