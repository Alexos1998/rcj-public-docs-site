#ifndef LOGIC_H
#define LOGIC_H

#include "sensors.h"
#include "motors.h"

long ballMillis = 0;
long timeFromSeen = 0;
long noBallMillis = 0;
bool seen = false;
long myTime = 0;
bool object = false;    //////////-nastavuje si podla toho ci prave pri obchadzani prekazky ma vedla seba prekazku alebo nie
bool obstacle = false;  //////-nastavuje si podla toho ci obchadza prekazku alebo nie
bool turned = true;
uint8_t turns = 0;
uint8_t ballType = 0;  // 0 - ziadna, 1- strieborna, 2- cierna
uint8_t balls = 0;
uint8_t silverCollected = 0;
uint8_t silverRemoved = 0;
bool greenCorner = false;
bool redCorner = false;
bool cornerCollected = false;  ////////-true ak najde danu gulicku popri tom ked je pri spravnom rohu
bool perimeterCollected = false;
bool blackRemoved = false;
uint8_t blackCollected = 0;
bool leaving = false;
bool leds = true;
long gapMillis = 0;
bool startTurning = false;
long turnMillis = 0;
bool leftSilver = false;
bool rightSilver = false;

void neopixel(uint8_t ledStart, uint8_t ledEnd, uint8_t r, uint8_t g, uint8_t b) {  // NEOPIXEL
  for (int i = ledStart; i < ledEnd; i++) {
    strip.setPixelColor(i, strip.Color(r, g, b));
    strip.show();
  }
}

void caseDecision() {
  if (vodivostRead() < 30) {
    LINE_STAV = 6;
  } else if (actualBlackPositions != 0) {  /////////////-RIADENIE SA PODLA CIARI
    if (LINE_STAV == 2) {
      gapMillis = millis();
    }
    LINE_STAV = 1;
  } else if (millis() - gapMillis > 200) {  ///////////////////////////////////////-POCAS TOHO AKO NEVIDI CIARU DLHSIU DOBU
    LINE_STAV = 2;
  }
  ///////////////////////////////////////////////-NA ZACIATKU PROGRAMU
  if (!asponJeden) {
    LINE_STAV = 0;
  }
  ///////////////////////////////////////////////-KONTROLA FARBY BLOCKOV
  for (int i = 0; i < colorBlocks; i++) {
    if (pixy.ccc.blocks[i].m_signature == 2 && pixy.ccc.blocks[i].m_y > 120) {  ///////////////////////////////-RED COLOR
      LINE_STAV = 4;
    } else if (pixy.ccc.blocks[i].m_signature == 1 && pixy.ccc.blocks[i].m_y > 80) {  /////////////////////////////////////////////////////////////////- COLOR
      LINE_STAV = 5;
    }
  }

  /////////////////////////////////////-AK SU STLACENE PREDNE TLACIDLA, TAK CASE 3
  if (touchVal[0] == 0 || touchVal[1] == 0) {
    LINE_STAV = 3;
  }
}
///////////////////////////////////////////////////////////////////////////////------LINE---------//////////////////////////////////////////////////////////////
void simpleLine() {
  /////////////////////////////////////-INTERNAL VARIABLES
  int8_t turnSpeed = 0;
  int turnTime = 20;
  int lastHighestValue = 0;
  int8_t lastHighestSenzor = 3;

  /////////////////////////////////////-KTORY SENZOR VIDI NAJVIAC CIERNEJ
  for (int i = 0; i < 7; i++) {
    if (bitRead(actualBlackPositions, i) == 1 && actualBlackValues[i] > lastHighestValue) {
      lastHighestValue = actualBlackValues[i];
      lastHighestSenzor = i;
    }
  }
  uint8_t distanceFromCenter = abs(lastHighestSenzor - 3);
  if (inclined == 1 || inclined == 3 || inclined == 4) {  ////////////////////////////////////////////////////////////////-AK JE NAKLON(NA KOPCI)
    DBG(" horekopec");
    downhill = true;
    turnSpeed = 50 - distanceFromCenter * 20;
    if (turnSpeed < 0) turnSpeed = 0;
  } else if (inclined == 2) {
    DBG(" dolekopec");
    MAINSPEED = 60;
    turnSpeed = 15;
  } else {  //////////////////////////////////////////////////////////////////////-AK NIEJE NAKLON(PO ROVINE)
    turnSpeed = -distanceFromCenter * 25;
    if (turnSpeed < -100) turnSpeed = -100;
  }
  if (lastHighestSenzor == 6 || lastHighestSenzor == 0) {
    turnTime = 330;
  }
  if (inclined == 5) {
    // timeMovement(MAINSPEED, MAINSPEED, 200, false);  //
    turnTime = 600;
  }
  if (lastHighestSenzor > 3 && direction <= 1) {  /////////////////////////////-VPRAVO
    timeMovement(MAINSPEED, turnSpeed, turnTime, false);
    if (lastHighestSenzor == 6 || lastHighestSenzor == 0) {
      timeMovement(MAINSPEED, MAINSPEED, 200, true);
    }
    if (startTurning == false) {
      startTurning = true;
      turnMillis = millis();
    }
    if (inclined == 5) {
      while (!(actualBlackPositions & 28)) {
        sensorRead();
        if (emergencyStop) {
          stopMovement();
          return;
        }
        if (startTurning == true) {
          startTurning = false;
        }
        setMovement(MAINSPEED, MAINSPEED);
      }
    }
  } else if (lastHighestSenzor < 3 && direction >= 1) {  //////////////////////-VLAVO
    timeMovement(turnSpeed, MAINSPEED, turnTime, false);
    if (lastHighestSenzor == 6 || lastHighestSenzor == 0) {
      timeMovement(MAINSPEED, MAINSPEED, 200, true);
    }
    if (startTurning == false) {
      startTurning = true;
      turnMillis = millis();
    }
    if (inclined == 5) {
      while (!(actualBlackPositions & 28)) {
        sensorRead();
        if (emergencyStop) {
          stopMovement();
          return;
        }

        setMovement(MAINSPEED, MAINSPEED);
      }
    }
  } else {  ///////////////////////////////////////////////////////////////////-ROVNO
    if (startTurning == true && inclined == 1) {
      startTurning = false;
      turnMillis = millis();
    }
    setMovement(MAINSPEED, MAINSPEED);
  }
  if (millis() - turnMillis > 2000 && inclined == 1) {
    timeMovement(MAINSPEED, MAINSPEED, 500, true);
    startTurning = false;
  }
  MAINSPEED = 100;
}


void intersections() {
  int8_t myDeg = 0;
  int8_t backwardSpeed = -100;
  if ((memoryBlackPositions & 65) == 65 && (actualBlackPositions & 65)) {
    setMovement(MAINSPEED, MAINSPEED);
  } else {  ///////////////////////////////////////////////////////////////////-KED VIDI IBA NA JEDNOM Z KRAJNYCH SENZOROV CIERNU
    if (actualBlackPositions & 1) {
      direction = 0;  /////////////////////////////////////////////////////////-IBA PRAVA STRANA LINIAKU
    } else {
      direction = 2;  /////////////////////////////////////////////////////////-IBA LAVA STRANA LINIAKU
    }
    while (actualBlackPositions & 65) {  //////////////////////////////////////-DOPREDU KYM VIDI CIERNU NA KRAJI
      sensorRead();

      if (emergencyStop) {
        stopMovement();
        return;
      }
      DBGLN("Podit si, kontrolujem stav krizovatky");
      simpleLine();
    }
    myTime = millis();
    while (millis() < myTime + 130) {  //////////////////////////////////////////-DOPREDU 130ms
      sensorRead();

      if (emergencyStop) {
        stopMovement();
        return;
      }
      simpleLine();
    }
    sensorRead();
    if (!actualBlackPositions) {
      if (inclined) {
        myDeg = 90;
      } else {
        myDeg = 80;
      }
      myTime = millis();
      switch (inclined) {
        case 1:  /////////////////- do kopca
          backwardSpeed = -30;
          while (millis() < myTime + 250) {  //////////////////////////////////////////-DOPREDU 250ms
            sensorRead();
            if (emergencyStop) {
              stopMovement();
              return;
            }
            simpleLine();
          }
          break;
        case 2:                                             ////////-z kopca
          timeMovement(-MAINSPEED, -MAINSPEED, 600, true);  /////// DOZADU ABY PERFECT TURN
          break;
        case 3:
          if (direction == 0) {
            timeMovement(MAINSPEED, MAINSPEED, 300, true);
          } else {
            timeMovement(-MAINSPEED, -MAINSPEED, 250, true);
          }
        case 4:
          if (direction == 0) {
            timeMovement(-MAINSPEED, -MAINSPEED, 300, true);
          } else {
            timeMovement(MAINSPEED, MAINSPEED, 250, true);
          }
          break;
      }
      if (direction == 0) {  /////////////-otacanie dolava
        neopixel(0, 1, 100, 100, 100);
        degMovement(backwardSpeed, MAINSPEED, -myDeg, true);
      } else {  /////////////////////////-otacanie doprava
        neopixel(3, 4, 100, 100, 100);
        degMovement(MAINSPEED, backwardSpeed, myDeg, true);
      }
      switch (inclined) {
        case 1:
          timeMovement(MAINSPEED, MAINSPEED, 600, true);
          break;
        case 3:
        case 4:
          timeMovement(MAINSPEED, MAINSPEED, 200, true);
      }
    }
  }
  neopixel(0, 4, 0, 0, 0);
}

bool victimCheck() {  ///////////////////////-pozera nahlu zmenu vzdialenosti
  timeFromSeen = millis() - ballMillis;
  Serial.print("millis: ");
  Serial.print(timeFromSeen);
  Serial.print("   ");
  if (infraVal[0] < 30 && seen == false) {                                                                                                          /////////////-ak vidi zmenu v zdialenosti ktora je mensia ako 40cm a naposledy nevidel taku vzdialenost
    ballMillis = millis();                                                                                                                          /////////-cas kedy nieco zschytil
    seen = true;                                                                                                                                    //////-nastavi si ze nieco vidi
  } else if (infraVal[0] > 30 && infraChange[0] > 3 && timeFromSeen < 200 && timeFromSeen > 60 && seen == true && millis() - noBallMillis > 500) {  ////////-moment kedy strati vec ktoru videl a je splneni casovu interval
    seen = false;
    return 1;                                                           ////-posle ze videl gulicku
  } else if (infraVal[0] > 30 && seen == true && infraChange[0] > 3) {  //////////////////-moment ked uz nic nevidi ale nieje to v case ktory by mohol znamenat gulicku
    if (timeFromSeen > 500) {
      noBallMillis = millis();
    }
    seen = false;
  }
  return 0;  //////////ak nevidel gulicku
}


void ballGrab(int timeMove) {
  float myDeg = euler.x();
  int8_t ballRotate = 0;
  ballRotate = 0.20 * (ballX - pixyDisplayWidth / 2);
  if (ballRotate > 3) {  // ak je gulicka na pravo
    degMovement(MAINSPEED, -MAINSPEED, ballRotate, true);
  } else if (ballRotate < -3) {
    degMovement(-MAINSPEED, MAINSPEED, ballRotate, true);
  }
  cornerCollected = false;
  timeMovement(-MAINSPEED, -MAINSPEED, 500, true);
  servoMovement(0, 100);
  delay(300);
  servoMovement(1, 0);
  servoMovement(2, 0);
  timeMovement(MAINSPEED, MAINSPEED, timeMove, false);
  servoMovement(1, 80);
  servoMovement(2, 80);
  stopMovement();
  delay(300);
  //////////////////////////
  ballType = 0;
  sensorRead();
  DBG("  vodivost:");
  DBG(vodivostRead());
  DBG("     ");
  delay(300);
  if (vodivostRead() < 30) {  ////////////-ak je vodiva
    ballType = 1;
  } else {  /////////////////////////////////////-ak nieje vodiva alebo nenasiel gulicku
    ballType = 2;
  }
  timeMovement(-MAINSPEED, -MAINSPEED, 400, true);
  servoMovement(0, 0);
  delay(400);
  sensorRead();
  if (touchVal[4] == 0 || ballType == 1) {
    if (redCorner || greenCorner) {
      cornerCollected = true;
    }
    balls++;
    if (ballType == 1) {  //////////-ak nasiel striebornu
      neopixel(0, 2, 100, 100, 100);
      silverCollected++;
      servoMovement(1, 0);
      delay(300);
      servoMovement(2, 90);
    } else if (ballType == 2) {  ///-ak nasiel ciernu
      blackCollected++;
      neopixel(2, 4, 100, 100, 100);
      servoMovement(2, 0);
      delay(300);
      servoMovement(1, 90);
    }
  }
  delay(300);
  servoMovement(0, 0);
  delay(300);
  //ruky do povodnej polohy
  servoMovement(0, 7);
  delay(300);
  servoMovement(1, servoDefPos[1]);
  servoMovement(2, servoDefPos[2]);
  float diff = fmod(myDeg - euler.x() + 540.0, 360.0) - 180.0;  ////-KOLKO SA treba otocit aby sa vyrovnal na start poziciu
  if (diff < 5) {
    degMovement(-MAINSPEED / 2, MAINSPEED / 2, diff, true);
  } else if (diff > 5) {
    degMovement(MAINSPEED / 2, -MAINSPEED / 2, diff, true);
  }
  timeMovement(-MAINSPEED, -MAINSPEED, 300, true);
  neopixel(0, 4, 0, 0, 150);
}


#endif
