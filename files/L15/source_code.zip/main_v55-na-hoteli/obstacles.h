#ifndef OBSTACLES_H
#define OBSTACLES_H

#include "sensors.h"
#include "motors.h"



//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////--------------------------ROVINA
//////////////////////////////////////////////////////////////////////////
void casualObst() {
  if (infraVal[1] < 15) {  //stena vpravo
    degMovement(-MAINSPEED, MAINSPEED, -80, true);
    timeMovement(MAINSPEED, MAINSPEED, 400, true);
    while (!(actualBlackPositions & 64)) {  /////////-kym nevidi ciaru(obchadza prekazku)
      sensorRead();
      if (emergencyStop) {
        stopMovement();
        return;
      }
      if (touchVal[0] == 0 || touchVal[1] == 0) {
        degMovement(-MAINSPEED, MAINSPEED, -35, true);
      } else {
        setMovement(MAINSPEED, 0);
      }
    }
    timeMovement(MAINSPEED, MAINSPEED, 600, true);  ////////-podide si
    degMovement(-MAINSPEED, MAINSPEED, 80, true);
  } else {  ///////////////////////- ak nieje stena vpravo
    degMovement(MAINSPEED, -MAINSPEED, 80, true);
    timeMovement(MAINSPEED, MAINSPEED, 400, true);
    while (!(actualBlackPositions & 1)) {  /////////-kym nevidi ciaru(ochadza prekazku)
      sensorRead();
      if (emergencyStop) {
        stopMovement();
        return;
      }
      if (touchVal[0] == 0 || touchVal[1] == 0) {
        degMovement(MAINSPEED, -MAINSPEED, 35, true);
      } else {
        setMovement(0, MAINSPEED);
      }
    }
    timeMovement(MAINSPEED, MAINSPEED, 600, true);  /////-podide si
    degMovement(MAINSPEED, -MAINSPEED, 80, true);
  }
}


//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////--------------------------DO KOPCA
//////////////////////////////////////////////////////////////////////////
void upHillObst() {
  uint8_t mySpeed = 15;
  float startDeg = euler.x();
  int myDeg = -180;
  degMovement(MAINSPEED, -MAINSPEED, 80, true);           /////pred flasou sa otoci
  float endDeg = fmod(euler.x() + myDeg + 360.0, 360.0);  ///-vypocet na endDeg
  while (!(actualBlackPositions & 1)) {                   /////////-kym nevidi ciaru(obchadza prekazku)
    sensorRead();
    if (emergencyStop) {
      stopMovement();
      return;
    }
    float current = euler.x();
    float diff = fmod(endDeg - current + 540.0, 360.0) - 180.0;  ////-KOLKO SA ESTE TREBA DOTOCIT
    if (fabs(diff) < 3.0) mySpeed = 0;                           ////-aby sa smerom dokopca nezasekol
    if (touchVal[0] == 0 || touchVal[1] == 0) {
      degMovement(MAINSPEED, -MAINSPEED, 35, true);
    } else {
      setMovement(mySpeed, MAINSPEED);
    }
  }
  switch (inclined) {  ///////////////ked narazi na ciaru tak sa pyta kde na nu narazil(ci dokopca, bokom alebo druhym bokom)
    case 1:            ///////-robot smerom dokopca(ciara sikmo)
      timeMovement(MAINSPEED, MAINSPEED, 700, true);
      sensorRead();
      while (!(actualBlackPositions & 1)) {
        sensorRead();
        if (emergencyStop) {
          stopMovement();
          return;
        }
        setMovement(50, -MAINSPEED);
      }
      break;
    case 2:
      yzMovement(-MAINSPEED, -20, 5, true);
      timeMovement(MAINSPEED, MAINSPEED, 700, true);
      yzMovement(-MAINSPEED, MAINSPEED, 4, true);
      sensorRead();
      while (actualBlackPositions == 0) {
        sensorRead();
        if (emergencyStop) {
          stopMovement();
          return;
        }
        setMovement(-MAINSPEED, -MAINSPEED);
      }
      timeMovement(-MAINSPEED, -MAINSPEED, 500, true);
      yzMovement(-MAINSPEED, 20, 6, true);
      break;
    case 4:  //////-robot sikmo(ciara horekopcom)
      degMovement(MAINSPEED, -30, 80, true);
      break;
  }  ///-koniec switchu po vrateni na ciaru
}

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////--------------------------DO KOPCA
//////////////////////////////////////////////////////////////////////////

void downHillObst() {
  uint8_t mySpeed = 0;
  float startDeg = euler.x();
  int myDeg = -180;
  degMovement(MAINSPEED, -MAINSPEED, 80, true);           /////pred flasou sa otoci
  float endDeg = fmod(euler.x() + myDeg + 360.0, 360.0);  ///-vypocet na endDeg
  while (!(actualBlackPositions & 1)) {                   /////////-kym nevidi ciaru(obchadza prekazku)
    sensorRead();
    if (emergencyStop) {
      stopMovement();
      return;
    }
    float current = euler.x();
    float diff = fmod(endDeg - current + 540.0, 360.0) - 180.0;  ////-KOLKO SA ESTE TREBA DOTOCIT
    if (fabs(diff) < 3.0) mySpeed = 15;                          ////-aby sa smerom dokopca nezasekol
    if (touchVal[0] == 0 || touchVal[1] == 0) {
      degMovement(MAINSPEED, -MAINSPEED, 35, true);
    } else {
      setMovement(mySpeed, MAINSPEED);
    }
  }
  switch (inclined) {  ///////////////ked narazi na ciaru tak sa pyta kde na nu narazil(ci dokopca, bokom alebo zhora)
    case 1:            ///////-robot smerom dokopca(ciara sikmo)
      timeMovement(MAINSPEED, MAINSPEED, 700, true);
      sensorRead();
      while (!(actualBlackPositions & 1)) {
        sensorRead();
        if (emergencyStop) {
          stopMovement();
          return;
        }
        setMovement(50, -MAINSPEED);
      }
      break;
    case 2:
      yzMovement(-MAINSPEED, -20, 5, true);
      timeMovement(MAINSPEED, MAINSPEED, 700, true);
      yzMovement(-MAINSPEED, MAINSPEED, 4, true);
      sensorRead();
      while (actualBlackPositions == 0) {
        sensorRead();
        if (emergencyStop) {
          stopMovement();
          return;
        }
        setMovement(-MAINSPEED, -MAINSPEED);
      }
      timeMovement(-MAINSPEED, -MAINSPEED, 500, true);
      yzMovement(-MAINSPEED, 20, 6, true);
      break;
    case 3:  //////-robot sikmo(ciara dolekopcom)
      timeMovement(-MAINSPEED, -MAINSPEED, 200, true);
      endDeg = fmod(startDeg + 0 + 360.0, 360.0);  ///-vypocet na endDeg
      while (true) {                               /////////////////////////////////////////////////-takyto sposob aby sa narovnal podla pozicie z ktorej startoval obchadzanie flase
        euler = bno.getVector(Adafruit_BNO055::VECTOR_EULER);
        sensorRead();
        if (emergencyStop) {
          stopMovement();
          return;
        }
        float current = euler.x();
        float diff = fmod(endDeg - current + 540.0, 360.0) - 180.0;  ////-KOLKO SA ESTE TREBA DOTOCIT
        if (fabs(diff) < 3.0) break;
        if (diff < 0) {
          setMovement(-MAINSPEED, MAINSPEED);
        } else {
          setMovement(MAINSPEED, -MAINSPEED);
        }
      }
      timeMovement(-MAINSPEED, -MAINSPEED, 500, true);
      break;
  }  ///-koniec switchu po vrateni na ciaru
}

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////--------------------------PO LAVEJ NAKLONENEJ ROVINE
//////////////////////////////////////////////////////////////////////////

void leftObst() {
  uint8_t mySpeed = 0;
  float startDeg = euler.x();
  int myDeg = 100;
  degMovement(-MAINSPEED, MAINSPEED, -80, true);          /////pred flasou sa otoci
  float endDeg = fmod(euler.x() + myDeg + 360.0, 360.0);  ///-vypocet na endDeg
  while (!(actualBlackPositions & 64)) {                  /////////-kym nevidi ciaru(obchadza prekazku)
    sensorRead();
    if (emergencyStop) {
      stopMovement();
      return;
    }
    float current = euler.x();
    float diff = fmod(endDeg - current + 540.0, 360.0) - 180.0;  ////-KOLKO SA ESTE TREBA DOTOCIT
    if (fabs(diff) < 3.0) mySpeed = 15;                          ////-aby sa smerom dokopca nezasekol
    if (touchVal[0] == 0 || touchVal[1] == 0) {
      degMovement(-MAINSPEED, MAINSPEED, -35, true);
    } else {
      setMovement(MAINSPEED, mySpeed);
    }
  }
  switch (inclined) {  ///////////////ked narazi na ciaru tak sa pyta kde na nu narazil(ci dokopca, bokom alebo druhym bokom)
    case 1:            ///////-robot smerom dokopca(ciara sikmo)
      timeMovement(MAINSPEED, MAINSPEED, 700, true);
      sensorRead();
      while (!(actualBlackPositions & 64)) {
        sensorRead();
        if (emergencyStop) {
          stopMovement();
          return;
        }
        setMovement(-MAINSPEED, 50);
      }
      break;
    case 3:  ////-robot sikmo(ciara horekopcom)
      degMovement(-30, MAINSPEED, -80, true);
      break;
    case 4:  //////-robot sikmo(ciara dolekopcom)
      timeMovement(-MAINSPEED, -MAINSPEED, 200, true);
      endDeg = fmod(startDeg + -90 + 360.0, 360.0);  ///-vypocet na endDeg
      while (true) {                                 /////////////////////////////////////////////////-takyto sposob aby sa narovnal podla pozicie z ktorej startoval obchadzanie flase
        euler = bno.getVector(Adafruit_BNO055::VECTOR_EULER);
        sensorRead();
        if (emergencyStop) {
          stopMovement();
          return;
        }
        float current = euler.x();
        float diff = fmod(endDeg - current + 540.0, 360.0) - 180.0;  ////-KOLKO SA ESTE TREBA DOTOCIT
        if (fabs(diff) < 3.0) break;
        if (diff < 0) {
          setMovement(-MAINSPEED, MAINSPEED);
        } else {
          setMovement(MAINSPEED, -MAINSPEED);
        }
      }
      timeMovement(-MAINSPEED, -MAINSPEED, 500, true);
      break;
  }  ///-koniec switchu po vrateni na ciaru
}

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////--------------------------PO PRAVEJ NAKLONENEJ ROVINE
//////////////////////////////////////////////////////////////////////////

void rightObst() {
  uint8_t mySpeed = 0;
  float startDeg = euler.x();
  int myDeg = -100;
  degMovement(MAINSPEED, -MAINSPEED, 80, true);           /////pred flasou sa otoci
  float endDeg = fmod(euler.x() + myDeg + 360.0, 360.0);  ///-vypocet na endDeg
  while (!(actualBlackPositions & 1)) {                   /////////-kym nevidi ciaru(obchadza prekazku)
    sensorRead();
    if (emergencyStop) {
      stopMovement();
      return;
    }
    float current = euler.x();
    float diff = fmod(endDeg - current + 540.0, 360.0) - 180.0;  ////-KOLKO SA ESTE TREBA DOTOCIT
    if (fabs(diff) < 3.0) mySpeed = 15;                          ////-aby sa smerom dokopca nezasekol
    if (touchVal[0] == 0 || touchVal[1] == 0) {
      degMovement(MAINSPEED, -MAINSPEED, 35, true);
    } else {
      setMovement(mySpeed, MAINSPEED);
    }
  }
  switch (inclined) {  ///////////////ked narazi na ciaru tak sa pyta kde na nu narazil(ci dokopca, bokom alebo druhym bokom)
    case 1:            ///////-robot smerom dokopca(ciara sikmo)
      timeMovement(MAINSPEED, MAINSPEED, 700, true);
      sensorRead();
      while (!(actualBlackPositions & 1)) {
        sensorRead();
        if (emergencyStop) {
          stopMovement();
          return;
        }
        setMovement(50, -MAINSPEED);
      }
      break;
    case 3:  ////-robot sikmo(ciara dolekopcom)
      timeMovement(-MAINSPEED, -MAINSPEED, 200, true);
      endDeg = fmod(startDeg + 90 + 360.0, 360.0);  ///-vypocet na endDeg
      while (true) {                                /////////////////////////////////////////////////-takyto sposob aby sa narovnal podla pozicie z ktorej startoval obchadzanie flase
        euler = bno.getVector(Adafruit_BNO055::VECTOR_EULER);
        sensorRead();
        if (emergencyStop) {
          stopMovement();
          return;
        }
        float current = euler.x();
        float diff = fmod(endDeg - current + 540.0, 360.0) - 180.0;  ////-KOLKO SA ESTE TREBA DOTOCIT
        if (fabs(diff) < 3.0) break;
        if (diff < 0) {
          setMovement(-MAINSPEED, MAINSPEED);
        } else {
          setMovement(MAINSPEED, -MAINSPEED);
        }
      }
      timeMovement(-MAINSPEED, -MAINSPEED, 500, true);
      break;
    case 4:  //////-robot sikmo(ciara horekopcom)
      degMovement(MAINSPEED, -30, 80, true);
      break;
  }  ///-koniec switchu po vrateni na ciaru
}
#endif