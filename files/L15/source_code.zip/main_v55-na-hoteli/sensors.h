#ifndef SENSORS_H
#define SENSORS_H

#include "configuration.h"
#include <Pixy2.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h>
#include <vector>
#include <SPI.h>
#include <Wire.h>
#include <utility/imumaths.h>
#include <Adafruit_NeoPixel.h>

//NEOPIXEL
#define NEO_PIN 21
#define LED_COUNT 4
Adafruit_NeoPixel strip(LED_COUNT, NEO_PIN, NEO_GRB + NEO_KHZ800);


using namespace std;

// --- EXTERNÉ FUNKCIE (z motors.h) ---
extern void stopMovement();
extern void servoMovement(int servo, int newPos);

bool mode = 0;  //0 - Line, 1 - Evacuation zone
uint8_t LINE_STAV = 0;
uint8_t EVAC_STAV = 0;

bool touchVal[5];
int infraVal[2];
int infraChange[2];


long lineMillis;                    //-posledny cas ked program precita liniak
vector<uint8_t> actualBlackValues;  //hodnoty liniaku v poli
bool asponJeden = false;
uint8_t lastBlackPositions = 0;                      // 1, 2, 4, 8, 16, 32, 64         ////-POSLEDNE VIDENE CIERNE
uint8_t memoryBlackPositions = 0;                    // 1, 2, 4, 8, 16, 32, 64         ////-VIDENE CIERNE ZA POSLEDNY CAS "lineMemoryTime"
uint8_t actualBlackPositions = 0;                    //1, 2, 4, 8, 16, 32, 64          ////-AKTUALNE CIERNE
long lineMemoryMillis[7] = { 0, 0, 0, 0, 0, 0, 0 };  /////////-POSLEDNE CASY KEDY VIDELI JEDNOTLIVE SENZORY CIERNU
long lastChangeTime = 0;                             /////////-CAS KEDY NAPOSLEDY UPDATOVAL HODNOTU LINIAKU NA INU HODNOTU
int whiteChange = 0;
long blackChange = 0;
uint8_t direction = 1;  /////////-KED 1 TAK SA RIADI PODLA CELEHO LINIAKU, KED 0 TAK IBA PODLA PRAVEJ STRANY LINIAKU,
// KED 2 TAK IBA PODLA LAVEJ STRANY LINIAKU
bool emergencyStop = true;  /////////-KED SA ZODVIHNE ROBOT DO VZDUCHU TAK TRUE
bool lastButtonState = HIGH;
bool rightGreen = false;
bool leftGreen = false;
int sucet = 780;  //////////////-premenna s ktorou si porovnava sucet liniaku pri zelenej

Pixy2 pixy;
uint8_t colorBlocks = 0;
uint8_t greenBlocks = 0;
uint8_t redBlocks = 0;
uint8_t ballDetect = 0;

///////////////////////////////////////-GYRO VARIABLES
Adafruit_BNO055 bno = Adafruit_BNO055(-1, 0x29, &Wire);
imu::Vector<3> euler;
long gyroTime = 0;
uint8_t inclined = 0;

bool downhill = false;

///////-EVACUATION ZONE VARIABLES
bool roch = 0;
long myAngle = 0;  //-ukladanie pozicie pred ty ako ide po gulicku aby perfect turn
int ballX = 0;

vector<uint8_t> liniakRead() {
  vector<uint8_t> actualBlackValues;
  for (int i = 0; i < 4; i++) {
    Wire.beginTransmission(PCF8591P_1);
    Wire.write(0x40 | i);
    Wire.endTransmission();

    Wire.requestFrom(PCF8591P_1, 2);
    Wire.read();
    actualBlackValues.push_back(Wire.read());
  }
  for (int i = 0; i < 3; i++) {
    Wire.beginTransmission(PCF8591P_2);
    Wire.write(0x40 | i);
    Wire.endTransmission();

    Wire.requestFrom(PCF8591P_2, 2);
    Wire.read();
    actualBlackValues.push_back(Wire.read());
  }

  return actualBlackValues;
}

int vodivostRead() {
  Wire.beginTransmission(PCF8591P_2);
  Wire.write(0x40 | 3);
  Wire.endTransmission();

  Wire.requestFrom(PCF8591P_2, 2);
  Wire.read();
  return Wire.read();
}


void sensorRead() {
  /////////////////////////////////////-MUSI BYT
  actualBlackPositions = 0;
  colorBlocks = 0;
  greenBlocks = 0;
  redBlocks = 0;
  ballDetect = 0;

  for (int i = 0; i < 5; i++) {
    touchVal[i] = digitalRead(touch[i]);
  }

  for (int i = 0; i < 2; i++) {
    infraVal[i] = ::map(analogRead(infra[i]), 670, 420, 0, 25);
    if (infraVal[i] < 50) {
      infraChange[i] = 0;
    } else if (infraVal[i] > 50) {
      infraChange[i]++;
    }
  }
  pixy.ccc.getBlocks();
  for (int i = 0; i < pixy.ccc.numBlocks - 1; i++) {          /////PREHADZUJE SI VIDENE BLOCKY TAK ABY ICH MAL ZORADENE PODLA Y-OVEJ OSY ZDOLA NAHOR
    for (int j = i + 1; j < pixy.ccc.numBlocks; j++) {        /////
      if (pixy.ccc.blocks[i].m_y < pixy.ccc.blocks[j].m_y) {  /////
        Block temp = pixy.ccc.blocks[i];                      /////VYTVORI SI DOCASNU PREMENNU S NAZVOM TEMP A DATOVYM TYPOM BLOCK
        pixy.ccc.blocks[i] = pixy.ccc.blocks[j];              /////
        pixy.ccc.blocks[j] = temp;                            /////
      }
    }
  }

  /////////////////////////////////////-CITANIE LINIAKU
  DBG("HODNOTY: ");
  if (lineMillis + 20 < millis()) {
    actualBlackValues = liniakRead();
    lineMillis = millis();
  }
  for (int i = 0; i < 7; i++) {
    ///////////////////////////////////PYTA SA CI VIDEL NA SENZORE BIELU ALEBO CIERNU  (ZAPISE SI TO DO "actualBlackPositions")
    if (LINE_STAV == 7) {
      if (actualBlackValues[i] < silverColor) {
        bitSet(actualBlackPositions, i);
      }
    } else {
      if (actualBlackValues[i] > blackColor) {
        bitSet(actualBlackPositions, i);
      }
    }
    DBG(actualBlackValues[i]);
    DBG(" ");
    DBG(bitRead(actualBlackPositions, i));
    DBG(" ");
  }
  /////////////////////////////////////-AK NASTALA ZMENA NA HODNOTACH LINIAKU
  if (actualBlackPositions != lastBlackPositions) {
    lastChangeTime = millis();
  }
  /////////////////////////////////////-AK VIDEL CIERNU, ZAPISE SI JU DO "lastBlackPositions"
  if (actualBlackPositions != 0) {
    lastBlackPositions = actualBlackPositions;
    whiteChange = 0;
  } else {  ///////////////////////////-KED STRATI CIARU VIDI VSETKO BIELE VIE ZE SA STRATIL :)
    whiteChange++;
  }


  /////////////////////////////////////STALE VYPISUJE KDE VIDEL NAPOSLEDY CIERNU
  asponJeden = false;
  for (int i = 0; i < 7; i++) {
    if (bitRead(lastBlackPositions, i) == 1) {
      asponJeden = true;
    }
  }


  /////////////////////////////////////-ZAPISUJE SI CIERNE KTORE VIDEL ZA POSLEDNY CAS
  for (int i = 0; i < 7; i++) {
    if (bitRead(actualBlackPositions, i)) {
      lineMemoryMillis[i] = millis();
      bitSet(memoryBlackPositions, i);
    } else if (millis() - lineMemoryMillis[i] > lineMemoryTime) {
      bitClear(memoryBlackPositions, i);
    } else {
    }
  }

  /////////////////////////////////////////////////////////////////////////////----SCAN PIXY----///////////////////////////////////////////////////////////////////////////////
  /////////////////////////////////////-AK VIDEL NAD SURADNICOU "Y" ALE NIE PO BOKOCH
  if (pixy.ccc.numBlocks) {
    if (mode == 0) {  // LINE
      if (pixy.ccc.blocks[0].m_y > 150 && pixyDisplayWidth / 2 - 120 < pixy.ccc.blocks[0].m_x && pixyDisplayWidth / 2 + 120 > pixy.ccc.blocks[0].m_x) {
        for (int i = 0; i < pixy.ccc.numBlocks; i++) {
          if (pixy.ccc.blocks[i].m_y > pixy.ccc.blocks[0].m_y - 30) {  // detail na sutazi pozret
            pixy.ccc.blocks[colorBlocks] = pixy.ccc.blocks[i];
            colorBlocks++;
          }
        }
      }
    } else {  // EVACUATION ZONE
      for (int i = 0; i < pixy.ccc.numBlocks; i++) {
        if (pixy.ccc.blocks[i].m_y > 30 && pixy.ccc.blocks[i].m_y < 120 && pixy.ccc.blocks[i].m_signature == 3 && pixy.ccc.blocks[i].m_width < 80 && pixy.ccc.blocks[i].m_height < 50 && pixy.ccc.blocks[i].m_x < pixyDisplayWidth - 45) {
          ballDetect++;
          ballX = pixy.ccc.blocks[i].m_x;
          break;
        } else if (pixy.ccc.blocks[i].m_signature == 1 && pixy.ccc.blocks[i].m_width > 60 && pixy.ccc.blocks[i].m_height > 60 && pixy.ccc.blocks[i].m_y < 120) {
          greenBlocks++;
          colorBlocks++;
        } else if (pixy.ccc.blocks[i].m_signature == 2 && pixy.ccc.blocks[i].m_width > 60 && pixy.ccc.blocks[i].m_height > 60 && pixy.ccc.blocks[i].m_y < 120) {
          colorBlocks++;
          redBlocks++;
        }
      }
    }
  }


  /////////////////////////////////////-EMERGENCY STOP
  if (lastButtonState == HIGH && (touchVal[3] == LOW || touchVal[2] == LOW) && touchVal[4] == LOW) {
    emergencyStop = !emergencyStop;
    stopMovement();
    DBGLN("EMERGENCY STOP");
    delay(700);
    touchVal[2] = HIGH;
    touchVal[3] = HIGH;
    touchVal[4] = HIGH;
    for (int i = 1; i < 4; i++) {
      servoMovement(i, servoDefPos[i]);
    }
    servoMovement(0, servoDefPos[0]);
  }
  lastButtonState = touchVal[3] || touchVal[2] || touchVal[4];
  /////////////////////////////////////-GYRO READ KAZDYCH 100ms
  if (millis() - gyroTime >= 100) {
    euler = bno.getVector(Adafruit_BNO055::VECTOR_EULER);
    gyroTime = millis();
    if (euler.y() < -14) {  ////////////////////////-AK IDE DOKOPCA
      inclined = 1;
      sucet = 700;
    } else if (euler.y() > 14) {  /////////////////-AK IDE ZKOPCA
      inclined = 2;
    } else if (euler.z() > 14) {  // naklonena rovina(doprava)
      inclined = 3;
      sucet = 700;
    } else if (euler.z() < -14) {  // naklonena rovina(vlavo)
      inclined = 4;
      sucet = 700;
    } else if (inclined > 0 && euler.y() < 10 && euler.y() > 3) {
      inclined = 5;
    } else if (inclined > 0 && fabs(euler.z()) < 10 && fabs(euler.y()) < 3) {  /////-AK UZ NIEJE NAKLON
      inclined = 0;
      sucet = 700;
    }
  }
  DBG(" inclined: ");
  DBG(inclined);
  DBG("    ");
  ///////////////////////////////////-EMERGENCY STOP
  if (emergencyStop) {
    DBGLN("");
    return;
  }
}
#endif
