#ifndef CONFIGURATION_H
#define CONFIGURATION_H

///////////////////////////////////////////////////////////////////////////////---DEBUG---///////////////////////////////////////////////////////////////////////////////////
#define SERIAL_DEBUG 1  // 1 = zapnuté, 0 = vypnuté

#if SERIAL_DEBUG
#define DBG(x) Serial.print(x)
#define DBGLN(x) Serial.println(x)
#else
#define DBG(x)
#define DBGLN(x)
#endif

///////////////////////////////////////-MOTORS VARIABLES
const uint8_t pl_mot[] = { 8, 7 };
const uint8_t zl_mot[] = { 11, 12 };
const uint8_t pp_mot[] = { 6, 5 };
const uint8_t zp_mot[] = { 10, 9 };


uint8_t MAINSPEED = 100;  ////////////////-HLAVNY SPEED MOTOROV

///////////////////////////////////////-SERVOS
const int servoPins[] = { 15, 13, 14, 16 };///-servo predne, lave, prave, zadne
const int minMap[] = { 0, 180, 0, 0 };
const int maxMap[] = { 175, 110, 70, 180 };
int servoDefPos[] = { 7, 35, 35, 50 };

///////////////////////////////////////-SENZOR VARIABLES
const int touch[] = { 18, 19, 22, 17, 26 };
const int infra[] = {28, 27};
///////////////////////////////////////-NEOPIXEL
#define neopin 21

///////////////////////////////////////-LINE VARIABLES
#define PCF8591P_1 0x48             ////I2c CIP 1
#define PCF8591P_2 0x49             ////I2c CIP 2
#define ledPin 20                   ////-pin na regulaciu svietenie lediek(od 3 do 5v)
#define lowerLight 150              ////-HODNOTA KOLKO SI MUSI SVIETIT CEZ PWM ABY VIDEL STRIEBORNU
#define higherLight 0
#define lineMemoryTime 500                           /////////-CAS AKO DLHO SI MA PAMETAT "memoryBlackPositions"
#define blackColor 200        /////////hodnota od kedy vidi ciernu ked tak opravit
#define silverColor 50       /////////-HODNOTA KEDY LINIAK VIDI STRIEBORNU FARBU(LEN KED JE NA ledPin HODNOTA loweLight)

///////////////////////////////////////-PIXY VARIABLES
#define PIN_MISO 4
#define PIN_MOSI 3
#define PIN_SCK 2
#define pixyDisplayWidth 315
#define pixyDisplayHeight 207
#define camColorBright 150

#endif