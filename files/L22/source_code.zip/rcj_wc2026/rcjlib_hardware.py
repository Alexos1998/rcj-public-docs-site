from gpiozero import *
from typing import *
from time import *

class Chassis:
    def __init__(self):
        #motor setting

        self.ML1 = OutputDevice(27)
        self.ML2 = OutputDevice(17)

        self.MR1 = OutputDevice(13)
        self.MR2 = OutputDevice(19)

        self.M1PWM = PWMOutputDevice(23)
        self.M1PWM.frequency = 1000 
        self.M3PWM = PWMOutputDevice(16)
        self.M3PWM.frequency = 1000 

    def leftmotor(self, speed):
        speed = max(min(speed, 100), -100)
        if speed >= 0:
            self.ML1.value = 1
            self.ML2.value = 0
            self.M1PWM.value = abs(speed/100)
        elif speed < 0:
            self.ML1.value = 0
            self.ML2.value = 1
            self.M1PWM.value = abs(speed/100)
        

    def rightmotor(self, speed):
        speed = max(min(speed, 100), -100)
        if speed >= 0:
            self.MR1.value = 1
            self.MR2.value = 0
            self.M3PWM.value = abs(speed/100)
        elif speed < 0:
            self.MR1.value = 0
            self.MR2.value = 1
            self.M3PWM.value = abs(speed/100)
        

    def stop(self):
        self.leftmotor(0)
        self.rightmotor(0)
