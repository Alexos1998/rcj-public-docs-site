from time import *
from luma.core.interface.serial import i2c
from luma.core.render import canvas
from luma.oled.device import sh1106

from PIL import Image, ImageDraw

class Oled:

    def __init__(self):

        #serial = i2c(port=1, address=0x3C)

        self.device = sh1106(i2c(port=1, address=0x3C))

        self.path = r"ikun.jpg"
        self.kun = Image.open(self.path)
        self.kun = self.kun.resize([64,64])

        self.display_img = Image.new(mode="RGB", size=(128, 64))
        self.display_img = self.display_img.convert("1")
        self.draw = ImageDraw.Draw(self.display_img)

        self.fps = 0
        self.starttime = 0


    def DrawItem(self,img,item, itemtype,pos):
        #global kun

        img.paste(self.kun,(64,0))

        if itemtype == "text":  
            output = ImageDraw.Draw(img)
            output.text(pos, str(item), fill=255)
        
        elif itemtype == "img":
            img.paste(item,pos)
        
        return img

    def ImgStart(self):
        display_img = Image.new(mode="RGB", size=(128, 64))
        display_img = display_img.convert("1")

        return display_img

    def display(self,img):
        #global fps
        self.starttime = time()
        

        display_img = self.DrawItem(img,"FPS" + ":" + str(round(self.fps,1)),"text",(0,0))
        self.device.display(display_img)


        self.fps = 1/(time() - self.starttime)

    def clear(self):
        self.starttime = time()

        self.device.clear()
    


if __name__ == "__main__":
    oled = Oled()
    a=0
    while True:
        a += 1
        #oled.clear()
        display_img = oled.ImgStart()
        display_img = oled.DrawItem(display_img,a,"text",(10,10))
        
        oled.display(display_img)
