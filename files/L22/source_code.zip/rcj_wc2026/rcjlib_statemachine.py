import time
from typing import *

class StateMachine: pass

class State(object):
    def __init__(self):
        pass

    def on_switch(self, sm: StateMachine, old_state_name: str):
        """
        Event handler whe other state switched to current state
        """
        pass

    def on_tick(self, sm: StateMachine, *args, **kwargs):
        """
        Event handler run every tick
        """
        pass

    def on_leave(self, sm: StateMachine, new_state_name: str):
        """
        Eventer handler run before current state switch to other state
        """
        pass

class EmptyState(State): pass


class StateMachine:
    def __init__(self, state: Type[State] = EmptyState, verbose=True):
        self.state_dict: Dict[str, Type[State]] = {"": EmptyState}
        self.state: State = state()
        self.state_name = ""
        self.start_time = time.time()
        self.elasped_time = 0
        self.ticks = 0
        self.verbose = verbose


    def register(self, name, state):
        """
        Register a State
        For example:
            sm.register("dummy", EmptyState)
        """
        self.state_dict[name] = state
 
    def switch(self, new_state_name: str, params: any = None):
        """
        Switch to another state
        """
        self.state.on_leave(sm=self, new_state_name=new_state_name)
        self.old_state_name = self.state_name
        self.start_time = time.time()   
        if new_state_name in self.state_dict:
            if params is None:
                self.state = self.state_dict[new_state_name]()
            else:
                self.state = self.state_dict[new_state_name](params)
            self.state_name = new_state_name
        else:
            raise NameError(f"state {new_state_name} not found")
        self.ticks = 0
        self.state.on_switch(sm=self, old_state_name=self.old_state_name)
        if self.verbose:
            print(f"[DEBUG] {self.old_state_name} -> {self.state_name}")
        return True
    
    def get_previous_state(self):
        """
        Get previous state
        """
        return self.old_state_name
    
    def get_elasped_time(self):
        """
        Get the time passed since switch from other state
        """
        self.elasped_time = time.time() - self.start_time
        return self.elasped_time
    
    def get_elasped_tick(self):
        """
        Get the ticks ran since switch from other state
        """
        return self.ticks

    def loop(self, *args, **kwargs):
        """
        The loop of state machine
        """
        self.ticks += 1
        self.elasped_time = time.time() - self.start_time
        self.state.on_tick(sm=self, *args, **kwargs)



class RepeaterState(State):
    """
    Dummy state which will back to the previous state
    """
    def on_tick(self, sm: StateMachine, *args, **kwargs):
        sm.switch(sm.get_previous_state())