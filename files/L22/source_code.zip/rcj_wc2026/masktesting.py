import tkinter as tk
import cv2
import numpy as np
from PIL import ImageGrab, Image, ImageTk
from time import *
############################################################

#exposure = 0

############################################################

ballcam = cv2.VideoCapture(0,cv2.CAP_V4L2)
ballcam.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
ballcam.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
ballcam.set(cv2.CAP_PROP_AUTOFOCUS,0)
ballcam.set(cv2.CAP_PROP_AUTO_EXPOSURE,1)
ballcam.set(cv2.CAP_PROP_EXPOSURE,0)
ballcam.set(cv2.CAP_PROP_FPS, 60)

############################################################

window = tk.Tk()
window.title("Mask Testing")
window.geometry("960x1080")

############################################################

def create_slider_row(parent, text, from_, to):
    frame = tk.Frame(parent)
    frame.pack(pady=0)
    
    # Label on the left (e.g. "r", "g", "b" or "H", "S", "V")
    label = tk.Label(frame, text=text, font=("Helvetica", 16, "bold"), width=len(text)+1)
    label.pack(side="left", padx=0)
    
    scale = tk.Scale(frame, from_=from_, to=to, orient='horizontal', length=800, width=25)
    scale.pack(side="left")
    return scale

exposure = create_slider_row(window, "Exposure", 0, 255)
exposure.set(150)

label = tk.Label(text="green: ", font=("Helvetica",16,"bold"))
label.pack(pady=5)

min_green_r = create_slider_row(window, "R_min", 0, 255)
min_green_r.set(0)
min_green_g = create_slider_row(window, "G_min", 0, 255)
min_green_g.set(64)
min_green_b = create_slider_row(window, "B_min", 0, 255)
min_green_b.set(0)
max_green_r = create_slider_row(window, "R_max", 0, 255)
max_green_r.set(23)
max_green_g = create_slider_row(window, "G_max", 0, 255)
max_green_g.set(255)
max_green_b = create_slider_row(window, "B_max", 0, 255)
max_green_b.set(77)

label2 = tk.Label(text="red: ", font=("Helvetica",16,"bold"))
label2.pack(pady=5)

min_red_r = create_slider_row(window, "R_min", 0, 255)
min_red_r.set(58)
min_red_g = create_slider_row(window, "G_min", 0, 255)
min_red_g.set(0)
min_red_b = create_slider_row(window, "B_min", 0, 255)
min_red_b.set(0)
max_red_r = create_slider_row(window, "R_max", 0, 255)
max_red_r.set(255)
max_red_g = create_slider_row(window, "G_max", 0, 255)
max_red_g.set(82)
max_red_b = create_slider_row(window, "B_max", 0, 255)
max_red_b.set(80)

window.update()
while True:
    captime = time()

    ballcam.set(cv2.CAP_PROP_EXPOSURE,exposure.get())
    
    ret, frame = ballcam.read()
    frame = cv2.flip(frame, 0)
    frame = cv2.flip(frame, 1)
    #display_frame = frame
    
    frame = cv2.resize(frame,(320,240))
    frame = frame[50:,:]
    display_frame = frame

    green_min = np.array([min_green_b.get(), min_green_g.get(), min_green_r.get()])
    green_max = np.array([max_green_b.get(), max_green_g.get(), max_green_r.get()])
    green_mask = cv2.inRange(frame, green_min, green_max)
    contours, _ = cv2.findContours(green_mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        #print(x,y,w,h)
        if w > 60 and h > 7:
            show_w = str(w)
            show_h = str(h)
            text = str("green  "+ "w: "+show_w+" h: "+ show_h)
            
            cv2.putText(display_frame,text, (x,y-5), cv2.FONT_HERSHEY_SIMPLEX,0.4,(0,255,0),1,cv2.LINE_AA)
            cv2.putText(display_frame,("x: " + str(x) + "y: " + str(y)), (x,y+10+h), cv2.FONT_HERSHEY_SIMPLEX,0.4,(0,255,0),1,cv2.LINE_AA)
            cv2.rectangle(display_frame, (x,y), ((x+w),(y+h)),(0,255,0), 2)
            

    

    red_min = np.array([min_red_b.get(), min_red_g.get(), min_red_r.get()])
    red_max = np.array([max_red_b.get(), max_red_g.get(), max_red_r.get()])
    red_mask = cv2.inRange(frame, red_min, red_max)

    contours, _ = cv2.findContours(red_mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        #print(x,y,w,h)
        if w > 60 and h > 7:
            show_w = str(w)
            show_h = str(h)
            text = str("red  "+ "w: "+show_w+" h: "+ show_h)
            cv2.putText(display_frame, text, (x,y-5), cv2.FONT_HERSHEY_SIMPLEX,0.4,(0,0,255),1,cv2.LINE_AA)
            cv2.putText(display_frame,("x: " + str(x) + "y: " + str(y)), (x,y+10+h), cv2.FONT_HERSHEY_SIMPLEX,0.4,(0,0,255),1,cv2.LINE_AA)
            cv2.rectangle(display_frame, (x,y), ((x+w),(y+h)),(0,0,255), 2)
            
    
    fps = str(int(1/(time()-captime)))
    cv2.putText(display_frame, "fps: " + fps, (25,25), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,0,0), 2, cv2.LINE_AA)

    cv2.imshow("frame", display_frame)
    cv2.imshow("green", green_mask)
    cv2.imshow("red", red_mask)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    window.update()

print("g_min: ", green_min, "g_max: ", green_max, "\n", "r_min: ", red_min, "r_max: ", red_max)

cv2.destroyAllWindows()


