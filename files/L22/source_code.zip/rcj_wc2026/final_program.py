import cv2
import numpy as np
from time import *
import math
from gpiozero import *
import board
import busio
from ultralytics import *
import rcjlib_colorfix as cf
from rcjlib_pid import PID
from rcjlib_hardware import Chassis
from rcjlib_statemachine import StateMachine, State, EmptyState
from picamera2 import Picamera2
import serial
from rcj_oled import Oled
import termios
import os
import random
from mpu6050 import mpu6050
import adafruit_bno055

# Initialize I2C bus using the board's default SCL and SDA pins
i2c = board.I2C()

# Initialize the BNO055 sensor
# Note: If your board has the ADR/COM pin pulled high, change the address to 0x29
sensor = adafruit_bno055.BNO055_I2C(i2c, address=0x28)


picked = 0
putted = 0

clipservo=OutputDevice(6)
backservo = OutputDevice(9)
pickservo = OutputDevice(4)
clipservo.value = 0
pickservo.value = 0
backservo.value = 0


ballmodel = YOLO(r"model/3_20ball_full_integer_quant_edgetpu.tflite", task="detect")
linemodel = YOLO(r"model/3_18line_full_integer_quant_edgetpu.tflite", task="classify")

DEBUG = True

dissensor = DistanceSensor(echo=22, trigger=25)
dissensor2 = DistanceSensor(echo=21, trigger=20)
# sensor2 = DistanceSensor(echo=23, trigger=12)
L = OutputDevice(10)
R = OutputDevice(11)

#mpu6050 setting
#load silver line model
print("[INIT] Loading Model")
chassis = Chassis()

obsdir = 0

print("[INIT] Setting up servos")
#servo setting
#button setting

#vl53l0x setting

lut_r = cf.generate_lut(0, 255, 20, 245)
lut_g = cf.generate_lut(0, 255, 20, 255)
lut_b = cf.generate_lut(60, 255, 0, 235)

def redline(frame):
    red_lower = np.array([0, 0,90])
    red_upper = np.array([80, 80, 255])

    red = cv2.inRange(frame, red_lower, red_upper)
    red = cv2.erode(red, None, iterations=3)
    red = cv2.dilate(red, None, iterations=30)
    red = cv2.erode(red, None, iterations=20)
    redcontours, _ = cv2.findContours(red, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    for contour in redcontours:
            x, y, w, h = cv2.boundingRect(contour)
            if w > 200 and h > 80:
                return True
    return False


def extract_polygon(img, slice_num=24):
    IMG_HEIGHT, IMG_WIDTH = img.shape
    X_DIV = int(IMG_HEIGHT/float(slice_num))
    kernelOpen = np.ones((5,5))
    kernelClose = np.ones((20,20))
    poly_points = [None] * slice_num
    detected_contours = [None] * slice_num
    
    for i in range(0, slice_num) :
        sliced_img = img[X_DIV*i + 1:X_DIV*(i+1), int(0):int(IMG_WIDTH)]
        maskOpen = cv2.morphologyEx(sliced_img,cv2.MORPH_OPEN,kernelOpen)
        maskClose=cv2.morphologyEx(maskOpen,cv2.MORPH_CLOSE,kernelClose)
        maskFinal = maskClose
        conts,_ = cv2.findContours(maskFinal.copy(),\
                    cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)

        if(len(conts)):
            c = max(conts, key = cv2.contourArea)
            
            M = cv2.moments(c)
            poly_points[i] = (int(M['m10']/M['m00']), int(M['m01']/M['m00']) + X_DIV * i)
            detected_contours[i] = c

    contours = [i for i in detected_contours if i is not None]
    points = [i for i in poly_points if i is not None]
    return points, contours

def evaluate_function(angle_part, translate_part, x, y):
    x = abs(x)
    return math.exp(-1*y/240/20.)*(
        (1 - 1.*x/320/2.0)*angle_part +
         .8*x/320 * translate_part)

def check_corner(img, threshold = 0.5):
    left = cv2.countNonZero(img[260:, :60])
    right = cv2.countNonZero(img[260:, 580:])
    return (left > 14400*threshold, right > 14400*threshold)

def preprocess_frame(frame):
    global lut_b,lut_g, lut_r
    frame = cv2.rotate(frame, cv2.ROTATE_180)
    frame = cv2.resize(frame,(320,240))
    frame = frame[10:220, 20:290]
    # frame = frame[:280,80:560]
    frame = cv2.resize(frame,(320,240))
    frame = cv2.medianBlur(frame, 5)
    frame = cv2.medianBlur(frame, 5)
    #frame = cv2.bilateralFilter(frame, 5, 10, 100)
    b, g, r = cv2.split(frame)
    r = cv2.LUT(r, lut_r)
    g = cv2.LUT(g, lut_g)
    b = cv2.LUT(b, lut_b)
    return cv2.merge((b,g,r))



def detect_green_boxes(frame, gray, display_buffer, size=65):

    green_lower = np.array([0,60,0])
    green_upper = np.array([60, 255, 100])

    mask = cv2.inRange(frame, green_lower, green_upper)

    mask = cv2.medianBlur(mask,ksize=5)
    kernel = np.ones((3, 3), np.uint8)
    mask = cv2.erode(mask, kernel, iterations=3)
    mask = cv2.dilate(mask, kernel, iterations=7)
    mask = cv2.erode(mask, kernel, iterations=5)
    cv2.imshow("mask", mask)
    contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    
    green_x = []
    green_y = []

    good_green_index = []
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        #print(x,y,w,h)
        if w > 25 and h > 40:
            center_x, center_y = x + w // 2, y + h // 2
            green_x.append(center_x)
            green_y.append(center_y)

            display_buffer = cv2.rectangle(display_buffer, (x, y), (x + h, y +h), (128, 255, 128), 2)
            #display_buffer = cv2.rectangle(display_buffer, (center_x - 10, y - 10), (center_x+10, y - 30), (128, 128, 128), 2)
            
    if len(green_y) == 0:
        return False, False

    
    for i, (x, y) in enumerate(zip(green_x, green_y)):
        
        if max(green_y) < 100: 
            continue
        # if center_y > 150:
        #     continue
        if x > 310 or x < 10: 
            continue
        
        
        upper_area = np.sum(gray[
            y - size // 2 - 40:y - size//2 - 20,
            x - 10: x + 10, ])
        
        display_buffer = cv2.rectangle(display_buffer, (x - 10, y - size // 2 - 20), (x+10, y - size // 2 - 40), (128, 128, 128), 2)
        print(upper_area/400)
        if upper_area / 400 < 55: 
            good_green_index.append(i)
            display_buffer = cv2.circle(display_buffer,(x,y),10,(255,0,0),-1)
    #print(len(good_green_index))
    if len(good_green_index) >= 2: return True, True
    if len(good_green_index) == 0: return False, False

    x = green_x[good_green_index[0]]
    y = green_y[good_green_index[0]]

    if x < size // 2 + 40: return True, False
    left_area = np.sum(gray[
        y-10:y+10, x-size // 2 - 40: x-size //2 - 20
    ])

    frame = cv2.rectangle(frame, (x - size // 2 - 40, y - 10), (x - size // 2 - 20, y + 10), (128, 128, 128), 3)


    if left_area / 400 > 70: return True, False
    
    return False, True
class ResetServoState(State):
    def on_tick(self, sm, *args, **kwargs):
        return sm.switch("")

class FollowState(State):
    def on_switch(self, sm, old_state_name):
        global obsdir
        if obsdir == 0:
            obsdir = 1
        else:
            obsdir = 0
    def __init__(self):
        self.goingup = False

    def calc_ctrl(self, points):
        self.edgepointlist = []
        self.pointx = 0
        self.ang = 0
        self.lineang = 0
        self.min = 14
        self.edgepointy = 8
        self.edgepoint = [160,0]
        if len(points) == 0:
            self.ang = 0
            self.lineang = 0
            self.Line = 0
        else:
            y = points[:, 1]
            x = points[:, 0].astype(np.float64)
            #x[x > 240] *= 1.1
            x = 160 - np.abs(x - 160)

            idx = np.argmin(np.min(np.array([x, y]), axis=0))
            self.edgepoint = list(points[idx])#[(x1,y1), (x2,y2)]

            
            self.lineang = math.degrees(math.atan((points[0][0] - points[-1][0]) / ((240 - points[0][1]) - (120 - points[-1][1]))))
            self.Line = (self.edgepoint[0]-160) + (points[0][0] - points[-1][0]) 
        
        self.Linedistance = math.sqrt((self.edgepoint[0]-160)**2 + (self.edgepoint[1]-120)**2)

        self.ctrl = controller.control(self.Line, 0)
        #print(self.Line, self.ang, self.lineang)

    def check_noise(self, points):
        hull = cv2.convexHull(points)
        area = cv2.contourArea(hull)

        #print(area)
        if area > 26000:
            print("noise")
            return True
        else:
            return False

    def on_tick(self, sm: StateMachine, points, frame, framegray, display_buffer, *args, **kwargs):
        #self.goingdown = False
        #print(sm.get_elasped_tick())
        linestate = "black"
        self.rampL = False
        self.rampR = False

        euler = sensor.euler

        yaw, roll, pitch = euler

        noise = False
        has_left, has_right = False, False
        self.goingdown = False



        points = np.array(points)
        # Normal Following, igrone noise
        
                
        if redline(frame):
            return sm.switch("RedStop")
        noise = False
            
        if len(points) > 1:
           noise = self.check_noise(points)
        self.calc_ctrl(points)
        self.speed = 70
        #print(self.ctrl)
        
            #print(angy, self.goingdown)
        if roll < -15:
            self.goingup = True
        elif roll > 8:
            self.goingdown = True
        else:
            self.goingup = False

        if pitch > -160 and pitch < 0:
            self.rampL = True
        elif pitch < 160 and pitch > 0:
            self.rampR = True
        #print(self.goingup)
        #print(self.goingup,accrange)
        has_left, has_right = detect_green_boxes(
            frame, 
            framegray, 
            display_buffer
        )
        linestate = "black"
        # if sum(sum(Blackline)) < 1000:
        #     linestate = "white"
        #print(has_left,has_right)
        silverframe = cv2.resize(frame,(224,224))
        if sm.get_elasped_tick() // 9 == 0 or sm.get_elasped_time() < 0.5:
            lineresults = linemodel.predict(silverframe, verbose=False, imgsz = 224)
        else:
            lineresults = None

        ##print(sum(sum(Blackline)))
        if lineresults != None:
            if lineresults[0].probs.top1 == 1:
                linestate = "silver"
                #print("silver")
            
            
            elif lineresults[0].probs.top1 == 0:
                linestate = "black"
        if sum(sum(Blackline)) < 1000:
            linestate = "white"
                #print("white")
            #print("black")
        #print(has_left,has_right)
        #print(self.goingdown)
        if linestate == "silver":
            if putted == 3:
                return sm.switch("FuckGo")
            else:
                return sm.switch("CheckSilver") 

        if L.value == 1 and R.value == 1:
            return sm.switch("Line_Obstacle")
        #if R.value == 1:
            #return sm.switch("BObsR")
        

        if self.goingup:
            if has_left and has_right:
                return sm.switch("Line_UTurn")
            elif has_left:
                return sm.switch("UpLine_Left")
            elif has_right:
                return sm.switch("UpLine_Right")
        else:
            if has_left and has_right:
                return sm.switch("Line_UTurn")
            elif has_left:
                return sm.switch("Line_Left")
            elif has_right:
                return sm.switch("Line_Right")

        #print(self.ctrl)
        #Linedistance = math.sqrt((self.edgepoint[0]-160)**2 + (self.edgepoint[1]-120)**2)
        #print(self.edgepoint)
        # if len(points) <= 10 and len(points) != 0 or (self.Linedistance < 80 and self.edgepoint[1]> 120) or self.Linedistance < 50:
        #     #if abs(160 - points[-1][0]) > 0:
        #         #pass
            
        #     self.ctrl = 0
        #     self.ang = self.lineang

        if DEBUG:
            for i in range(len(points) - 1):
                cv2.line(display_buffer, points[i] ,points[i + 1],(0, 255, 0),3)
                cv2.line(display_buffer, (160,120) ,self.edgepoint,(0, 0, 255),6) 
            cv2.circle(display_buffer, center=self.edgepoint, radius=10, color=(0, 255, 255), thickness=-1)
            #cv2.putText(display_buffer, "ctrl: " + str(int(self.ctrl)) , (25,55), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0,0,255), 1, cv2.LINE_AA)
            cv2.putText(display_buffer, "yaw: " + str(round(yaw)) + "pitch: " + str(round(pitch)) + "roll: " + str(round(roll)), (25,85), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255), 1, cv2.LINE_AA)
            cv2.putText(display_buffer, "line:"+str(int(self.Line)) + " " , (25,115), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0,0,255), 1, cv2.LINE_AA)
            cv2.putText(display_buffer, linestate , (25,145), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0,0,255), 1, cv2.LINE_AA)
            
        
                


        if linestate != "white":
            if self.goingup:
                #print("fuck")
                if noise:
                    chassis.leftmotor(50)
                    chassis.rightmotor(50)
                elif self.Line > 80:
                    chassis.leftmotor(50+self.Line/4.5)
                    chassis.rightmotor(0)
                elif self.Line < -80:
                    chassis.leftmotor(0)
                    chassis.rightmotor(50-self.Line/4.5)
                else:
                    chassis.leftmotor(90 + self.ctrl)
                    chassis.rightmotor(90 - self.ctrl)
                    #chassis.leftmotor(60)
                    #chassis.rightmotor(60)
            elif self.goingdown or self.rampR or self.rampL:
                self.speed = 30
                # #self.ctrl *= 0.15
                # if self.check_noise(points) and len(points) != 0:
                #     chassis.leftmotor(30)
                #     chassis.rightmotor(30)
                if self.Line < -80:
                    if self.rampL:
                        chassis.rightmotor(60)
                        chassis.leftmotor(-60)
                    elif self.rampR:
                        chassis.rightmotor(60)
                        chassis.leftmotor(-60)
                    else:
                        chassis.rightmotor(30)
                        chassis.leftmotor(-100)
                elif self.Line > 80:
                    if self.rampL:
                        chassis.rightmotor(-60)
                        chassis.leftmotor(60)
                    elif self.rampR:
                        chassis.rightmotor(-60)
                        chassis.leftmotor(60)
                    else:
                        chassis.rightmotor(-100)
                        chassis.leftmotor(30)
                else:
                    if self.rampL:
                        chassis.leftmotor(60)
                        chassis.rightmotor(80)
                    elif self.rampR:
                        chassis.leftmotor(80)
                        chassis.rightmotor(60)
                    else:
                        chassis.leftmotor(60)
                        chassis.rightmotor(60)
            else:
                if noise:
                #     chassis.rightmotor(50)
                    if self.Line > 100:
                        chassis.leftmotor(70+self.Line/5)
                        chassis.rightmotor(-80-self.Line/5)
                        sleep(0.3)
                    elif self.Line < -100:
                        chassis.leftmotor(-80+self.Line/5)
                        chassis.rightmotor(70-self.Line/5)
                        sleep(0.3)
                    else:
                        chassis.leftmotor(30)
                        chassis.rightmotor(30)
                elif self.Line > 90:
                    chassis.leftmotor(60+self.Line/6)
                    chassis.rightmotor(-80-self.Line/6)
                elif self.Line < -90:
                    chassis.leftmotor(-80+self.Line/6)
                    chassis.rightmotor(60-self.Line/6)
                else:
                    chassis.leftmotor(60 + self.ctrl)
                    chassis.rightmotor(60- self.ctrl)
                    #chassis.leftmotor(80)
                    #chassis.rightmotor(80)
        else:
            if self.rampL:
                chassis.leftmotor(30)
                chassis.rightmotor(100)
            elif self.rampR:
                chassis.leftmotor(100)
                chassis.rightmotor(30)
            else:
                chassis.leftmotor(60)
                chassis.rightmotor(60)
        
        
        #if gyroy > 30:
            #return sm.switch("LineGoBack")
        self.lastpoints = points
class BeforeObsL(State):
    def on_tick(self, sm: StateMachine, *args, **kwargs):
        chassis.stop()
        if sm.get_elasped_time() < 0.2:
            chassis.leftmotor(-30)
            chassis.rightmotor(-30)
        elif sm.get_elasped_time() < 0.4:
            chassis.leftmotor(-30)
            chassis.rightmotor(30)
        elif sm.get_elasped_time() < 0.8:
            chassis.leftmotor(30)
            chassis.rightmotor(30)
            if L.value == 1 and R.value == 1:
                return sm.switch("Line_Obstacle")
        else:
            return sm.switch("BObsL")


class CheckSilver(State):
    def on_tick(self, sm: StateMachine, points, frame, framegray, display_buffer, *args, **kwargs):
        silverframe = cv2.resize(frame,(224,224))
        linestate = "black"
        if sm.get_elasped_time() < 0.3:
            chassis.leftmotor(50)
            chassis.rightmotor(50)
            lineresults = linemodel.predict(silverframe, verbose=False, imgsz = 224)
            if sum(sum(Blackline)) < 1000:
                linestate = "white"
                print("white")
                
            elif lineresults[0].probs.top1 == 1:
                linestate = "silver"
                print("silver")
                return sm.switch("GoAway")
            elif lineresults[0].probs.top1 == 0:
                linestate = "black"
                print("black")
                return sm.switch("Line_Follow")
            


class BeforeObsR(State):
    def on_tick(self, sm: StateMachine,  *args, **kwargs):
        chassis.stop()
        chassis.stop()
        if sm.get_elasped_time() < 0.2:
            chassis.leftmotor(-30)
            chassis.rightmotor(-30)
        elif sm.get_elasped_time() < 0.4:
            chassis.leftmotor(30)
            chassis.rightmotor(-30)
        elif sm.get_elasped_time() < 0.8:
            chassis.leftmotor(30)
            chassis.rightmotor(30)
            if L.value == 1 and R.value == 1:
                return sm.switch("Line_Obstacle")
        else:
            return sm.switch("BObsR")


class LeftTurnState(State):
    def on_tick(self, sm: StateMachine, *args, **kwargs):
        if sm.get_elasped_time() < 0.1:
            chassis.leftmotor(20)
            chassis.rightmotor(20)
        elif sm.get_elasped_time() <= 1:
            chassis.leftmotor(-100)
            chassis.rightmotor(100)
        elif sm.get_elasped_time() <= 1.3:
            chassis.leftmotor(60)
            chassis.rightmotor(60)
        elif sm.get_elasped_time() <= 1.5:
            chassis.stop()
            pass
        else:
            return sm.switch("Line_Follow")

class RightTurnState(State):
    def on_tick(self, sm: StateMachine, *args, **kwargs):
        if sm.get_elasped_time() < 0.1:
            chassis.leftmotor(20)
            chassis.rightmotor(20)
        elif sm.get_elasped_time() <= 1:
            chassis.leftmotor(100)
            chassis.rightmotor(-100)
        elif sm.get_elasped_time() <= 1.3:
            chassis.leftmotor(60)
            chassis.rightmotor(60)
        elif sm.get_elasped_time() <= 1.5:
            chassis.stop()
            pass
        else:
            return sm.switch("Line_Follow")

class OBSLeftTurnState(State):
    def on_tick(self, sm: StateMachine, *args, **kwargs):

        if sm.get_elasped_time() <= 1.3:
            chassis.leftmotor(-40)
            chassis.rightmotor(80)
        elif sm.get_elasped_time() <= 1.4:
            chassis.leftmotor(-80)
            chassis.rightmotor(-100)
        else:
            return sm.switch("Line_Follow")

class OBSRightTurnState(State):
    def on_tick(self, sm: StateMachine, *args, **kwargs):

        if sm.get_elasped_time() <= 1.3:
            chassis.leftmotor(80)
            chassis.rightmotor(-40)
        elif sm.get_elasped_time() <= 1.4:
            chassis.leftmotor(-100)
            chassis.rightmotor(-80)
        else:
            return sm.switch("Line_Follow")

class UTurnState(State):
    def on_tick(self, sm: StateMachine, *args, **kwargs):
        if sm.get_elasped_time() <= 2.3:
            chassis.leftmotor(90)
            chassis.rightmotor(-90)
        elif sm.get_elasped_time() < 2.5:
            chassis.leftmotor(80)
            chassis.rightmotor(80)
        else:
            return sm.switch("Line_Follow")

class ObstacleState(State):
    def on_tick(self, sm: StateMachine, framegray, *args, **kwargs):
        global obsdir
        if L.value == 1:
            chassis.leftmotor(40)
            chassis.rightmotor(-100)
        if R.value == 1:
            chassis.leftmotor(-100)
            chassis.rightmotor(40)
        if sm.get_elasped_time() <= 0.2:
            chassis.leftmotor(-60)
            chassis.rightmotor(-60)
        elif sm.get_elasped_time() <= 1.1:
            if obsdir == 0:
                chassis.leftmotor(80)
                chassis.rightmotor(-80)
            else:
                chassis.leftmotor(-80)
                chassis.rightmotor(80)
        elif sm.get_elasped_time() <= 1.4:
            chassis.leftmotor(100)
            chassis.rightmotor(100)
        elif sm.get_elasped_tick() % 10<= 3:
            chassis.leftmotor(80)
            chassis.rightmotor(80)
        else:
        
            if obsdir == 0:
                chassis.leftmotor(-60)
                chassis.rightmotor(80)
            else:
                chassis.leftmotor(80)
                chassis.rightmotor(-60)

            avg_pix = np.sum(framegray[
                CAM_HEIGHT//2 - 25:CAM_HEIGHT//2 + 25,
                    CAM_WIDTH//2 - 25: CAM_WIDTH//2 + 25]) / 5000
            #print(avg_pix)
            if sm.get_elasped_time() > 2:
                if avg_pix < 50:
                    if obsdir == 0:
                        return sm.switch("Obs_Right")
                    else:
                        return sm.switch("Obs_Left")

 


class UpLeftTurnState(State):
    def on_tick(self, sm: StateMachine, *args, **kwargs):
        if sm.get_elasped_time() <= 0.5:
            chassis.leftmotor(70)
            chassis.rightmotor(70)
        elif sm.get_elasped_time() <= 1.5:
            chassis.leftmotor(-60)
            chassis.rightmotor(60)
        elif sm.get_elasped_time() <= 1.7:
            chassis.leftmotor(80)
            chassis.rightmotor(80)
        else:
            return sm.switch("Line_Follow")

class UpRightTurnState(State):
    def on_tick(self, sm: StateMachine, *args, **kwargs):
        if sm.get_elasped_time() <= 0.5:
            chassis.leftmotor(70)
            chassis.rightmotor(70)
        elif sm.get_elasped_time() <= 1.5:
            chassis.leftmotor(60)
            chassis.rightmotor(-60)
        elif sm.get_elasped_time() <= 1.7:
            chassis.leftmotor(80)
            chassis.rightmotor(80)
        else:
            return sm.switch("Line_Follow")

class DownLeftTurnState(State):
    def on_tick(self, sm: StateMachine, *args, **kwargs):
        if sm.get_elasped_time() <= 0.5:
            chassis.leftmotor(-60)
            chassis.rightmotor(-60)
        elif sm.get_elasped_time() <= 1.1:
            chassis.leftmotor(-100)
            chassis.rightmotor(30)
        elif sm.get_elasped_time() <= 1.3:
            chassis.leftmotor(40)
            chassis.rightmotor(60)
        elif sm.get_elasped_time() <= 1.5:
            chassis.leftmotor(-40)
            chassis.rightmotor(-40)
        else:
            return sm.switch("Line_Follow")

class DownRightTurnState(State):
    def on_tick(self, sm: StateMachine, *args, **kwargs):
        if sm.get_elasped_time() <= 0.5:
            chassis.leftmotor(-80)
            chassis.rightmotor(-80)
        elif sm.get_elasped_time() <= 1.8:
            chassis.leftmotor(30)
            chassis.rightmotor(-100)
        else:
            return sm.switch("Line_Follow")

class UpUTurnState(State):
    def on_tick(self, sm: StateMachine, *args, **kwargs):
        if sm.get_elasped_time() <= 0.1:
            chassis.leftmotor(80)
            chassis.rightmotor(80)
        elif sm.get_elasped_time() <= 2.9:
            chassis.leftmotor(80)
            chassis.rightmotor(-80)
        elif sm.get_elasped_time() < 3.1:
            chassis.leftmotor(80)
            chassis.rightmotor(80)
        else:
            return sm.switch("Line_Follow")

class LineGoBackState(State):
    def on_switch(self, sm, old_state_name):
        self.laststate = old_state_name
    def on_tick(self, sm, *args, **kwargs):
        if sm.get_elasped_time() < 0.8:
            chassis.leftmotor(-50)
            chassis.rightmotor(-50)
        else:
            if self.laststate == "FindBall":
                return sm.switch("FindBall")
            return sm.switch("Line_Follow") 

class StopState(EmptyState):
    def on_switch(self, sm, old_state_name):
        global putted,picked
        if old_state_name != "Stop":
            StopState.last_state_name = "Line_Follow"
        if old_state_name == "Put":
            if putted == 3:
                putted = 2
            elif putted == 2:
                putted = 0
            picked = putted


class RedStopState(State):
    def on_tick(self, sm: StateMachine, *args, **kwargs):
        if sm.get_elasped_time() <= 12:
            chassis.leftmotor(0)
            chassis.rightmotor(0)
        else:
            return sm.switch("Line_Follow")

class PickState(State):
    def on_tick(self, sm: StateMachine, *args, **kwargs):
        if sm.get_elasped_time() <= 0.6:
            chassis.leftmotor(-50)
            chassis.rightmotor(-50)
            
        elif sm.get_elasped_time() <= 2.1:
            pickservo.value = 1
            clipservo.value = 1
            chassis.leftmotor(40)
            chassis.rightmotor(40)
        elif sm.get_elasped_time() <= 2.2:
            clipservo.value = 0
        elif sm.get_elasped_time() <= 3:
            
            chassis.leftmotor(-20)
            chassis.rightmotor(-20)
        elif sm.get_elasped_time() <= 3.5:
            pickservo.value = 0
        elif sm.get_elasped_time() <= 4.3:
            chassis.leftmotor(-80)
            chassis.rightmotor(-80)
        else: 
            chassis.leftmotor(0)
            chassis.rightmotor(0)
            return sm.switch("FindBall")


        
class FindBallState(State):
    def __init__(self):
        self.color = 1
        
    
    def detectballs(self, ballframe, color):
        results = ballmodel.predict(ballframe, verbose=False, imgsz = 320)
        ballframe = results[0].plot()
        #cv2.imshow("Ball", self.ball_frame)
        # Visualize the results on the frame

        boxes = results[0].boxes

        for box in boxes:
            #print(box.cls)
            cx, cy, w, h = box.xywh[0]
            if int(box.cls) == color: #black-0 silver-1
                return cx,cy, w, h, ballframe
        return -1,-1, -1, -1, ballframe
    def on_switch(self, sm, old_state_name):
        self.laststate = old_state_name
        ballcam.set(cv2.CAP_PROP_EXPOSURE,30)#30
        
    def on_tick(self, sm: StateMachine, *args, **kwargs):
        global picked, ballframe, putted
        #print(self.laststate,picked)
        #print(putted, picked)
        if sm.get_elasped_time() > 0.7:
            if putted == 2:
                self.color = 0
                
            else:
                self.color = 1
                #ballcam.set(cv2.CAP_PROP_EXPOSURE,100)
            if putted == 3:
                chassis.leftmotor(0)
                chassis.rightmotor(0)
                return sm.switch("BGo")
            elif picked == 3:
                return sm.switch("FindPut", params=0)
            
            if picked == 2 and putted == 0:
                return sm.switch("FindPut", params=self.color)
            
            
            cx,cy, w, h, ballframe = self.detectballs(ballframe, self.color)
            #print(cx,cy,w,h)
            if not(cx == -1 and cy == -1):
                if cx > 140 and cx < 180:
                    if cy > 200:
                        return sm.switch("LineGoBack")
                    elif cy > 175:
                        chassis.leftmotor(0)
                        chassis.rightmotor(0)
                        picked += 1
                        return sm.switch("Pick")
                    elif cy < 80:
                        error = 160 - cx
                        chassis.leftmotor(50 - 0.4 * error)
                        chassis.rightmotor(50 + 0.4 * error)

                    else:
                        error = 160 - cx
                        chassis.leftmotor(25 - 0.7 * error)
                        chassis.rightmotor(25 + 0.7 * error)
                    

                else:
                    if cx > 230:
                        chassis.leftmotor(40)
                        chassis.rightmotor(0)
                    elif cx < 90:
                        chassis.leftmotor(0)
                        chassis.rightmotor(40)
                    

            else:
                if sm.get_elasped_time() > random.randint(6,10):
                    return sm.switch("GoAway")
                
                chassis.leftmotor(-60)
                chassis.rightmotor(60)
                return

class PutState(State):
    def on_tick(self, sm: StateMachine, *args, **kwargs):
        if sm.get_elasped_time() <= 2:
            chassis.leftmotor(100)
            chassis.rightmotor(100)
        elif sm.get_elasped_time() <= 3:
            chassis.leftmotor(-50)
            chassis.rightmotor(-50)
        elif sm.get_elasped_time() <= 5.2:
            chassis.leftmotor(-80)
            chassis.rightmotor(80)
        elif sm.get_elasped_time() <= 8.2:
            chassis.leftmotor(-100)
            chassis.rightmotor(-100)
        elif sm.get_elasped_time() <= 9.2:
            chassis.leftmotor(0)
            chassis.rightmotor(0)
            backservo.value = 1
        elif sm.get_elasped_time() <= 9.4:
            chassis.leftmotor(100)
            chassis.rightmotor(100)
        elif sm.get_elasped_time() <= 9.6:
            chassis.leftmotor(-100)
            chassis.rightmotor(-100)
        elif sm.get_elasped_time() <= 9.8:
            chassis.leftmotor(100)
            chassis.rightmotor(100)
        elif sm.get_elasped_time() <= 10.2:
            chassis.leftmotor(-100)
            chassis.rightmotor(-100)
        elif sm.get_elasped_time() <= 11.5:
            
            chassis.leftmotor(0)
            chassis.rightmotor(0)
        elif sm.get_elasped_time() <= 13:
            backservo.value = 0
            chassis.leftmotor(100)
            chassis.rightmotor(100)
        else:
            chassis.leftmotor(0)
            chassis.rightmotor(0)
            return sm.switch("FindBall")


class GoAwayState(State):
    def on_tick(self, sm, *args, **kwargs):
        if sm.get_elasped_time() < 1.5:
            chassis.leftmotor(80)
            chassis.rightmotor(80)
        else:
            return sm.switch("FindBall")

class FindPutState(State):
    def __init__(self, color = None):
        self.color = color
        self.have = False
        #ballcam.set(cv2.CAP_PROP_EXPOSURE,100)

    def on_tick(self, sm: StateMachine, ballframe, *args, **kwargs):
        global putted
        if sm.get_elasped_time() > 0.6:
            xs = []
            ws = []
            x = 320
            if self.color == 1:
            #green
                lower = np.array([40, 80,40])
                upper = np.array([100, 255, 100])
                ballcam.set(cv2.CAP_PROP_EXPOSURE,80)
            elif self.color == 0:
            #red
                lower = np.array([30, 30,70])
                upper = np.array([90, 65, 255])
                ballcam.set(cv2.CAP_PROP_EXPOSURE,30)
            mask = cv2.inRange(ballframe,lower, upper)
            #mask = cv2.dilate(mask, None, iterations=2)
            # mask = cv2.erode(mask, None, iterations=5)
            # mask = cv2.dilate(mask, None, iterations=12)
            cv2.imshow("mask",mask)
            contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

            self.have = False
            for contour in contours:
                x, y, w, h = cv2.boundingRect(contour)
                xs.append(x)
                ws.append(w)
                #print(x,y,w,h)
                if w > 60 and h > 10:
                    self.have = True
                    break
                
                    
            
            if self.have:
                x = xs[ws.index(max(ws))]
                #ballframe = cv2.rectangle(ballframe,(x,y),(x+w,y+h),(255,0,0),2)
                min_x = int(x + w/2)
                if (y > 85)and w > 230:
                    if self.color == 1:
                        putted = 2
                    elif self.color == 0:
                        putted = 3
                    return sm.switch("Put")
                elif min_x < 110:
                    chassis.leftmotor(-30)
                    chassis.rightmotor(40)
                elif min_x > 210:
                    chassis.leftmotor(40)
                    chassis.rightmotor(-30)
                else:
                    chassis.leftmotor(70)
                    chassis.rightmotor(70)
            else:
                chassis.leftmotor(90)
                chassis.rightmotor(-90)

            
class GoGoGo(State):
    def on_tick(self, sm, *args, **kwargs):
        
        if sm.get_elasped_time() < 0.6:
            chassis.leftmotor(60)
            chassis.rightmotor(60)
            if L.value == 1:
                return sm.switch("LB")
            if R.value == 1:
                return sm.switch("RB")

        else:
            return sm.switch("Line_Follow")


class MoveLState(State):
    def on_tick(self, sm, *args, **kwargs):
        if sm.get_elasped_time() < 0.6:
            chassis.leftmotor(0)
            chassis.rightmotor(-80)
        elif sm.get_elasped_time() < 1.5:
            chassis.leftmotor(-80)
            chassis.rightmotor(0)
        elif sm.get_elasped_time() < 2.3:
            chassis.leftmotor(80)
            chassis.rightmotor(80)
        else:
            chassis.stop()
            return sm.switch("Go")

class MoveRState(State):
    def on_tick(self, sm, *args, **kwargs):
        if sm.get_elasped_time() < 0.6:
            chassis.leftmotor(-80)
            chassis.rightmotor(0)
        elif sm.get_elasped_time() < 1.5:
            chassis.leftmotor(0)
            chassis.rightmotor(-80)
        elif sm.get_elasped_time() < 2.3:
            chassis.leftmotor(80)
            chassis.rightmotor(80)
        else:
            chassis.stop()
            return sm.switch("Go")
        
class GoState(State):
    def on_tick(self, sm: StateMachine, frame,Blackline,  *args, **kwargs):
        #if sm.get_elasped_time() > 0.5:
        if L.value == 1 or R.value == 1:
            return sm.switch("Turn")
        if dissensor.distance * 100 > 35:
            return sm.switch("Check")
        elif dissensor.distance * 100 < 4:
            return sm.switch("MoveL")
        elif dissensor.distance * 100 > 14:
            return sm.switch("MoveR")
        else:
            chassis.leftmotor(65)
            chassis.rightmotor(65)
            if L.value == 1 or R.value == 1:
                return sm.switch("Turn")
            linestate = "silver"
            silverframe = cv2.resize(frame,(224,224))
            lineresults = linemodel.predict(silverframe, verbose=False, imgsz=224)

            if sum(sum(Blackline)) < 3000:
                linestate = "white"
                print("white")
            elif lineresults[0].probs.top1 == 1:
                linestate = "silver"
                print("silver")
            elif lineresults[0].probs.top1 == 0:
                linestate = "black"
                print("black")

            if linestate == "black":
                return sm.switch("GoGoGo")
            elif linestate == "silver":
                return sm.switch("GoBack")
        # else:
        #     chassis.stop()
        
class CheckState(State):
    def __init__(self):
        self.TurnTime = 0
    def on_tick(self, sm: StateMachine, frame, *args, **kwargs):
        if sm.get_elasped_time() < 1.7:
            chassis.leftmotor(60)
            chassis.rightmotor(80)
            if L.value == 1 or R.value == 1:
                self.TurnTime = 0
        else:
            if self.TurnTime == 0:
                if sm.get_elasped_time() < 2.3:
                    chassis.leftmotor(-80)
                    chassis.rightmotor(-80)
                elif sm.get_elasped_time() < 3.7:
                    chassis.leftmotor(80)
                    chassis.rightmotor(-80)
                elif sm.get_elasped_time() < 4.2:
                    chassis.leftmotor(-100)
                    chassis.rightmotor(-100)
                elif sm.get_elasped_time() < 5.3:
                    chassis.leftmotor(80)
                    chassis.rightmotor(80)

                    silverframe = cv2.resize(frame,(224,224))
                    results = linemodel.predict(silverframe, verbose=False, imgsz=224)
                    self.line = results[0].probs.top1
                    if self.line == 1:
                        return sm.switch("GoBack")
                    elif sum(sum(Blackline)) > 3000 and self.line != 1:
                        return sm.switch("GoGoGo")
                else:
                    return sm.switch("GoBack")
                    
            if self.TurnTime == 1:
                if sm.get_elasped_time() < 2.3:
                    chassis.leftmotor(-80)
                    chassis.rightmotor(-80)
                elif sm.get_elasped_time() < 3.1:
                    chassis.leftmotor(80)
                    chassis.rightmotor(-80)
                elif sm.get_elasped_time() < 3.6:
                    chassis.leftmotor(-80)
                    chassis.rightmotor(-80)
                elif sm.get_elasped_time() < 4.7:
                    chassis.leftmotor(80)
                    chassis.rightmotor(80)

                    silverframe = cv2.resize(frame,(224,224))
                    results = linemodel.predict(silverframe, verbose=False, imgsz=224)
                    self.line = results[0].probs.top1
                    if self.line == 1:
                        return sm.switch("GoBack")
                    elif sum(sum(Blackline)) > 3000 and self.line != 1:
                        return sm.switch("GoGoGo")
                else:
                    return sm.switch("GoBack")
                    
            
    

class TurnState(State):
    def on_tick(self, sm: StateMachine, frame, *args, **kwargs):

        if sm.get_elasped_time() < 0.6:
            chassis.leftmotor(-80)
            chassis.rightmotor(80)
        else:
            return sm.switch("Go")
            

class GoBackState(State):
    def on_tick(self, sm, *args, **kwargs):
        if sm.get_elasped_time() < 1.1:
            chassis.leftmotor(-80)
            chassis.rightmotor(-80)
        elif sm.get_elasped_time() < 2.3:
            chassis.leftmotor(-80)
            chassis.rightmotor(80)
        elif sm.get_elasped_time() < 3:
            chassis.leftmotor(80)
            chassis.rightmotor(80)
        else:
            return sm.switch("Go") 

class BeforeGoState(State):
    def on_tick(self, sm, *args, **kwargs):
        if sm.get_elasped_time() < 1.5:
            chassis.leftmotor(-100)
            chassis.rightmotor(-100)
        elif sm.get_elasped_time() < 2.8:
            chassis.leftmotor(80)
            chassis.rightmotor(-80)
        else:
            chassis.stop()
            return sm.switch("Go")
        
class FuckGoState(State):
    def on_tick(self, sm, *args, **kwargs):
        if sm.get_elasped_time() < 1.6:
            chassis.leftmotor(80)
            chassis.rightmotor(80)
        else:
            return sm.switch("Go") 
        
class LeftBackState(State):
    def on_tick(self, sm, *args, **kwargs):
        if sm.get_elasped_time() < 0.3:
            chassis.leftmotor(80)
            chassis.rightmotor(-80)
        else:
            return sm.switch("GoGoGo") 
        
class RightBackState(State):
    def on_tick(self, sm, *args, **kwargs):
        if sm.get_elasped_time() < 0.3:
            chassis.leftmotor(-80)
            chassis.rightmotor(80)
        else:
            return sm.switch("GoGoGo") 

print("[INIT] Starting Camera")


# Open the video file

cam = Picamera2()
cam.configure(cam.create_video_configuration(main={"format": 'RGB888',"size": (2304, 1296)}))
cam.set_controls({"ExposureTime": 100, "Contrast": 1.6, "Brightness": 0, "Sharpness": 1.5, "Saturation":1, "ExposureValue":0.4}) #contrast 0-32 brightness +-1 sharpness 0-16 saturation 0-32 exposurevalue +-8
#cam.set_controls({ "Contrast": 1.2, "Brightness": 0, "Sharpness": 1, "Saturation":0.8})
cam.start()


ballcam = cv2.VideoCapture(0,cv2.CAP_V4L2)
ballcam.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
ballcam.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
ballcam.set(cv2.CAP_PROP_AUTOFOCUS,0)
ballcam.set(cv2.CAP_PROP_AUTO_EXPOSURE,1)
ballcam.set(cv2.CAP_PROP_EXPOSURE,20)
#cap.set(cv2.CAP_PROP_EXPOSURE,250)
#ballcam.set(cv2.CAP_PROP_BRIGHTNESS, 0)
ballcam.set(cv2.CAP_PROP_FPS, 60)

sm = StateMachine()
sm.register("Stop",                 StopState)
sm.register("GoGoGo",                 GoGoGo)
sm.register("Line_Follow",          FollowState)
sm.register("Line_Left",            LeftTurnState)
sm.register("Line_Right",           RightTurnState)
sm.register("Obs_Left",            OBSLeftTurnState)
sm.register("Obs_Right",           OBSRightTurnState)
sm.register("Line_UTurn",           UTurnState)
sm.register("Line_Obstacle",        ObstacleState)
sm.register("UpLine_Left",            UpLeftTurnState)
sm.register("UpLine_Right",           UpRightTurnState)
sm.register("DLine_Left",            DownLeftTurnState)
sm.register("DLine_Right",           DownRightTurnState)
sm.register("UpLine_UTurn",           UpUTurnState)
sm.register("RedStop",          RedStopState)
sm.register("FindBall",          FindBallState)
sm.register("Pick",          PickState)
sm.register("Put",          PutState)
sm.register("FindPut",        FindPutState)
sm.register("GoAway",        GoAwayState)
sm.register("MoveL",        MoveLState)
sm.register("MoveR",        MoveRState)
sm.register("CheckSilver",       CheckSilver)
sm.register("Reset",       ResetServoState)
sm.register("LineGoBack", LineGoBackState)
sm.register("BObsL", BeforeObsL)
sm.register("BObsR", BeforeObsR)
sm.register("Turn",        TurnState)
sm.register("GoBack",       GoBackState)
sm.register("Go",        GoState)
sm.register("BGo",        BeforeGoState)
sm.register("Check",        CheckState)
sm.register("FuckGo",        FuckGoState)
sm.register("RB",        LeftBackState)
sm.register("LB",        RightBackState)

sm.switch("Line_Follow")
#sm.switch("Go")
#sm.switch("FindBall")
#sm.switch("FindPut", params=1)
StopState.last_state_name = "Line_Follow"

frame = None
last_pressed_btn = ""
display_buffer = None

CAM_HEIGHT = 240
CAM_WIDTH = 320
CAM_PIXELS = CAM_HEIGHT * CAM_WIDTH

controller = PID(0.5, 0.0, 0.3)
Pid_X = PID(0.15, 0.65, 0.1)
Pid_Y = PID(0.15, 0.65, 0.1)

print("[INIT] Start!")


captime = time()

#oled = Oled()
oleddisplay = False

lastplay = 1


startbutton = InputDevice(5)

while True:
    #print(putted)
    captime = time()
    #print(obsdir)
    if startbutton.value == 0:
        chassis.stop()
        picked = putted
        last_pressed_btn = "STOP"
            
        if last_pressed_btn == "START":
                
            sm.switch("Stop")
            print(f"[INFO] Stop Button is pressed, State froze '{StopState.last_state_name}'")
        print("stop")
        

    if startbutton.value == 1:
        if last_pressed_btn == "STOP":
            last_pressed_btn = "START"
            print(f"[INFO] Start Button is pressed, back to '{StopState.last_state_name}'")
            sm.switch("Line_Follow")
    #print(lastplay)

    frame = cam.capture_array()
    #ballframe = frame
    success, ballframe = ballcam.read()

    # ballframe = cv2.flip(ballframe, 0)
    # ballframe = cv2.flip(ballframe, 1)
    #ballframe = ballframe[150:,:]
    try:
        ballframe = cv2.resize(ballframe,(320,320))
    except cv2.error:
        ballcam = cv2.VideoCapture(8,cv2.CAP_V4L2)
        ballcam.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        ballcam.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        ballcam.set(cv2.CAP_PROP_AUTOFOCUS,0)
        ballcam.set(cv2.CAP_PROP_AUTO_EXPOSURE,1)
        ballcam.set(cv2.CAP_PROP_EXPOSURE,20)
        #cap.set(cv2.CAP_PROP_EXPOSURE,250)
        #ballcam.set(cv2.CAP_PROP_BRIGHTNESS, 30)
        ballcam.set(cv2.CAP_PROP_FPS, 60)
        success, ballframe = ballcam.read()

        ballframe = cv2.flip(ballframe, 0)
        ballframe = cv2.flip(ballframe, 1)
        ballframe = cv2.resize(ballframe,(320,320))


    


    frame = cv2.resize(frame,(640,480))
    frame = preprocess_frame(frame)
    display_buffer = frame.copy()
    
    # Create masks for green signs and black lines
    framegray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    Blackline = cv2.inRange(framegray, 0, 30)
    kernel = np.ones((3, 3), np.uint8)
    Blackline = cv2.erode(Blackline, kernel, iterations=5)
    Blackline = cv2.dilate(Blackline, kernel, iterations=10)
    Blackline = cv2.erode(Blackline, kernel, iterations=10)
    Blackline = cv2.erode(Blackline, kernel, iterations=5)
    Blackline = cv2.dilate(Blackline, kernel, iterations=10)
    Blackline = cv2.erode(Blackline, kernel, iterations=0)
    #cv2.imshow("ilne", Blackline)
    points, contours = extract_polygon(Blackline)

    #cv2.imshow("Screen", display_buffer)
    avg_pix = np.sum(framegray[
                CAM_HEIGHT//2 - 25:CAM_HEIGHT//2 + 25,
                    CAM_WIDTH//2 - 25: CAM_WIDTH//2 + 25]) / 5000
    #print(avg_pix)
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

    sm.loop(
        points=points, 
        frame=frame, 
        framegray=framegray, 
        display_buffer=display_buffer,
        ballframe = ballframe,
        Blackline = Blackline,
    )
    if startbutton.value == 0:
        chassis.stop()
    fps = str(int(1/(time()-captime)))
    cv2.putText(display_buffer, "fps: " + fps, (25,25), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,0,255), 2, cv2.LINE_AA)
    
    ballframe = cv2.resize(ballframe, (320,240))
    #display_buffer = cv2.medianBlur(display_buffer, 25)
    cv2.imshow("ball", ballframe)
    cv2.imshow("Screen", display_buffer)
    

cv2.destroyAllWindows()



