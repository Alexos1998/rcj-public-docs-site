import numpy as np

def generate_lut(x1, x2, y1, y2):
    m = (y2 - y1) / (x2 - x1)
    c = y1 - m * x1
    lut = np.zeros(256, dtype=np.uint8)
    for i in range(256):
        lut[i] = np.clip(int(round(m*i+c)), 0, 255)

    return lut

#lut_r = generate_lut(36, 202, 15, 180)
#lut_g = generate_lut(33, 216, 15, 180)
#lut_b = generate_lut(22, 154, 10, 180)
lut_r = generate_lut(50, 202, 15, 180)
lut_g = generate_lut(55, 216, 15, 180)
lut_b = generate_lut(10, 144, 10, 180)