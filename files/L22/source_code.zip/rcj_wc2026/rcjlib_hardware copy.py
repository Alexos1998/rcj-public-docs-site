from gpiozero import Motor, PWMOutputDevice
from typing import *

class Chassis:
    def __init__(self, 
                 left_motor_gpios: Tuple[int, int ,int], 
                 right_motor_gpios: Tuple[int, int, int],
                 freq: int = 1024):
        #motor setting
        
        self.Lmotor = Motor(*left_motor_gpios[:2])
        self.Rmotor = Motor(*right_motor_gpios[:2])

        self.leftPWM = PWMOutputDevice(left_motor_gpios[2])
        self.leftPWM.frequency = freq
        self.rightPWM = PWMOutputDevice(right_motor_gpios[2])
        self.rightPWM.frequency = freq

    def leftmotor(self, speed):
        speed = max(min(speed, 100), -100)
        if speed > 0:
            self.Lmotor.forward()
            self.leftPWM.value = abs(speed / 100)
        elif speed < 0:
            self.Lmotor.backward()
            self.leftPWM.value = abs(speed / 100)
        else:
            self.Lmotor.stop()

    def rightmotor(self, speed):
        speed = max(min(speed, 100), -100)
        if speed > 0:
            self.Rmotor.forward()
            self.rightPWM.value = abs(speed / 100)
        elif speed < 0:
            self.Rmotor.backward()
            self.rightPWM.value = abs(speed / 100)
        else:
            self.Rmotor.stop()

    def stop(self):
        self.leftmotor(0)
        self.rightmotor(0)