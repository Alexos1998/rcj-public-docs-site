#include <setup.h>
const char* startup = "start";
String stop = "stop";
String command;
const char* Mode;

void setup() {
  // put your setup code here, to run once:
  motorSetup();
  resetPID();
  Serial1.begin(10000);
  Serial.begin(9600);
  linefollowingarraySetup();
  
}

void loop() {
  // put your main code here, to run repeatedly:
  //lineFollowing(80,0.8);
  while (Serial1.available() > 0) {
    int recievedData = Serial1.parseInt();
    Serial.println(receivedData);
    if (recievedData > 0) {
      if (recievedData >149){
        moveDist(200,200,'y');
        moveDist(200,200,'x');
        moveDist(200,-200,'y');
        moveDist(200,-200,'x');
      }
      else if (recievedData < 149)
      {
        singleMotor(1,100,counterclockwise);
        singleMotor(3,100,clockwise);
        delay(2000);
        stopmove();
        singleMotor(2,100,counterclockwise);
        singleMotor(4,100,clockwise);
        delay(2000);
        stopmove();
        singleMotor(1,100,clockwise);
        singleMotor(3,100,counterclockwise);
        delay(2000);
        stopmove();
        singleMotor(2,100,clockwise);
        singleMotor(4,100,counterclockwise);
        delay(2000);
        stopmove(); 
      }
    }
    else if (recievedData == 1) {
      Serial.println(recievedData);
      stopmove();
    }
  }
  /*
  while (Serial1.available() > 0) {
    command = Serial1.readString();
    command.trim();
    Mode = command.c_str();
    //Serial.println(Mode);
    if (strcmp(Mode, "start") == 0) {
      while(strcmp(Mode, "stop") != 0)
      {
        if (Serial1.available() > 0) {
          command = Serial1.readString();
          command.trim();
          Mode = command.c_str();
        }
        lineFollowing(35,1.5);
      }
    }
    if (strcmp(Mode, "stop") == 0)
    {
      stopmove();
    }
  }
  */

  //int State = getIRsensorState(3);
  //Serial.println(State);
  

  //Serial.println(lineerror);
  //Serial.print(" ");

  
  //Serial.println(lineCorrection);
  
  //Serial.print("not'ing");
}

