#include <Arduino.h>
#include "Wire.h"
#include <sensorbar.h>

//define Motor pinout

//Motor1 pinout
#define EN1 6 //EN4
#define PH1 4 //PH4

//Motor2 pinout
#define EN2 10 //EN3
#define PH2 5 //PH3

//Motor3 pinout
#define EN3 12 //EN1
#define PH3 3 //PH1

//Motor4 pinout
#define EN4 11 //EN2
#define PH4 7 //PH2

#define nSLEEP 13
//#define button 5

//button
#define button A6
bool buttonstate;
bool pressed = false;

//Motor control parameters
int Motor1 = 1; //topleft motor
int Motor2 = 2; //topright motor
int Motor3 = 3; //bottomright motor
int Motor4 = 4; //bottomleft motor
int clockwise = 0;
int counterclockwise = 1;

//Omniwheel parameters
int speed1;
int speed2;
int speed3;
int speed4; //Speed in PWM
int vector_angle = 45; // Angle of the rollers on the tires

//Time parameters
unsigned long startTime;
unsigned long duration;

//PID control && linefollowing
float PIDReturn [] = {0,0,0};
float lineguide = 0; //the vector should be 0 to enable straight driving
float lineerror, prevlineError, prevlineITerm, lineCorrection;
unsigned long PIDstarttime=0, PIDendtime;
float PLine = 1.3, ILine = 0.4, DLine = 0.2;
int ignoreGreen = 0;

const uint8_t SX1509_ADDRESS = 0x3E; //I2C address of the line following array

SensorBar mySensorBar(SX1509_ADDRESS);// object initialization

//UART communication
char receivedData [10];

// put function declarations here:
void linefollowingarraySetup();
void lineFollowing(int,double); //speed in mm/s
void move(int, int, int); //x-speed, y-speed, yaw-speed
void singleMotor(int,int,int);//Motor, speed, direction
void stopmove();
void motorSetup();
int xget_motorVector(double,float);
int yget_motorVector(double,float);
void moveDist(float,float,char); //speed, distance(mm), mode
//modes: y, x, 0 for rotation
void mainProgram();


// put function definitions here:

void linefollowingarraySetup()
{
  Serial.println("Setup started.");
  //The IR sensors will be turned on all the time.
  mySensorBar.clearBarStrobe();
  //Default dark on light
  mySensorBar.clearInvertBits();

  //Don't forget to call .begin() to get the bar ready.  This configures HW.
  uint8_t returnStatus = mySensorBar.begin();
  if(returnStatus)
  {
    Serial.println("sx1509 I2C communication OK");
  }
  else
  {
    Serial.println("sx1509 I2C communication FAILED!");
    while(1);
  }
  Serial.println();
  lineguide = 0;
}

int getXPWM(long xSpeed)
{
  xSpeed = map(xSpeed,0,310,0,170);
  xSpeed = (int) xSpeed;
  return xSpeed;
}

int getYPWM(long ySpeed)
{
  ySpeed = map(ySpeed,0,339,0,170);
  ySpeed = (int) ySpeed;
  return ySpeed;
}

int getYawPWM(long yawSpeed)
{
  yawSpeed = map(yawSpeed,0,339,0,170);
  yawSpeed = (int) yawSpeed;
  return yawSpeed;
}

int getIRsensorState(int sensorNumber)
{
  sensorNumber = 8 - sensorNumber;

  uint8_t rawValue = mySensorBar.getRaw();// get the Raw value from the array in binary form
  int IRsensorState = (rawValue >> sensorNumber) & 0x01; //the sensors are numbered in a rising order from the left
  return IRsensorState;
}

void move(int x_speed, int y_speed,int yaw_speed) 
{
  if (x_speed == 0 && yaw_speed == 0){
    if(y_speed > 0){
      y_speed = yget_motorVector((double)y_speed,45);
      singleMotor(Motor1,y_speed,counterclockwise);
      singleMotor(Motor2,y_speed,clockwise);
      singleMotor(Motor3,y_speed,clockwise);
      singleMotor(Motor4,y_speed,counterclockwise);
    }
    else if(y_speed < 0){
      y_speed = -1*y_speed;
      y_speed = yget_motorVector((double)y_speed,45);
      singleMotor(Motor1,y_speed,clockwise);
      singleMotor(Motor2,y_speed,counterclockwise);
      singleMotor(Motor3,y_speed,counterclockwise);
      singleMotor(Motor4,y_speed,clockwise);
    }
  }
  else if (y_speed == 0 && yaw_speed == 0) {
    if (x_speed > 0) {
      x_speed = xget_motorVector((double)x_speed,45);
      singleMotor(Motor1,x_speed,counterclockwise);
      singleMotor(Motor2,x_speed,counterclockwise);
      singleMotor(Motor3,x_speed,clockwise);
      singleMotor(Motor4,x_speed,clockwise);
    }
    else if (x_speed < 0) {
      x_speed = -1*x_speed;
      x_speed = xget_motorVector((double)x_speed,45);
      singleMotor(Motor1,x_speed,clockwise);
      singleMotor(Motor2,x_speed,clockwise);
      singleMotor(Motor3,x_speed,counterclockwise);
      singleMotor(Motor4,x_speed,counterclockwise);
    }
  }
  else if (x_speed == 0 && y_speed == 0) {
    if(yaw_speed < 0){
      yaw_speed = -1*yaw_speed;
      singleMotor(Motor1,yaw_speed,clockwise);
      singleMotor(Motor2,yaw_speed,clockwise);
      singleMotor(Motor3,yaw_speed,clockwise);
      singleMotor(Motor4,yaw_speed,clockwise);
    }
    else if(yaw_speed > 0){
      singleMotor(Motor1,yaw_speed,counterclockwise);
      singleMotor(Motor2,yaw_speed,counterclockwise);
      singleMotor(Motor3,yaw_speed,counterclockwise);
      singleMotor(Motor4,yaw_speed,counterclockwise);
    }
  }
}

void moveDist(int speed, float distance, char mode)
{
  if (mode == 'y') {
    if (distance > 0) {
      duration = (unsigned long)((distance/(float)speed)*1000);
      speed = getYPWM((long)speed);
    }
    else if (distance < 0) {
      distance = -1*distance;
      duration = (unsigned long)((distance/(float)speed)*1000);
      speed = getYPWM((long)speed);
      speed = -1*speed;
    }

    startTime = millis();
    unsigned long currTime = millis();
    while ((currTime - startTime) < duration) {
      currTime = millis();
      move(0,speed,0);
    }
    stopmove();
  }

  else if (mode == 'x') {
    if (distance > 0) {
      duration = (unsigned long)((distance/(float)speed)*1000);
      speed = getXPWM((long)speed);
    }
    else if (distance < 0) {
      distance = -1*distance;
      duration = (unsigned long)((distance/(float)speed)*1000);
      speed = getXPWM((long)speed);
      speed = -1*speed;
    }
    startTime = millis();
    unsigned long currTime = millis();
    while ((currTime - startTime) < duration) {
      currTime = millis();
      move(speed,0,0);
    }
    stopmove();
  }

  else if (mode == '0') {
    if (distance > 0) {
      duration = (unsigned long)((distance/(float)speed)*1000);
      speed = getYawPWM((long)speed);
    }
    else if (distance < 0) {
      distance = -1*distance;
      duration = (unsigned long)((distance/(float)speed)*1000);
      speed = getYawPWM((long)speed);
      speed = -1*speed;
    }
    
    startTime = millis();
    unsigned long currTime = millis();
    while ((currTime - startTime) < duration) {
      currTime = millis();
      move(0,0,speed);
    }
    stopmove();
  }
}

void PID_LineEquation(float Error, float P, float I, float D, float prevError, float prevITerm)
{
  float Pterm = P * Error;
  PIDendtime = micros();
  float Dt = float((PIDendtime - PIDstarttime)/1e6);
  float ITerm = prevITerm + (I * (Error + prevError)* Dt/3);
  if (ITerm > 120){
      ITerm = 120;
  }
  else if (ITerm < -120){
      ITerm = -120;
  }
  PIDendtime = micros();
  Dt = float((PIDendtime - PIDstarttime)/1e6);
  float Dterm = D * (Error - prevError)/Dt;
  PIDstarttime = micros();
  float PIDOutput = Pterm + ITerm + Dterm;
  if (PIDOutput > (float)150){
    PIDOutput = 150;
  }
  else if (PIDOutput < -150){
    PIDOutput = -150;
  }

  PIDReturn [0] = PIDOutput;
  PIDReturn [1] = Error;
  PIDReturn [2] = ITerm;

}

void lineFollowing(int speed, double corrSpeedFactor)
{
  float linevector = float(mySensorBar.getPosition()); //vector depending on arrays that detect a line

  int linearraydetected = mySensorBar.getDensity(); //number of arrays that detect a line

  if (linevector == 0 && linearraydetected > 0 && linearraydetected < 4) { // if the robot is still on track
    ignoreGreen = 0;
    move(0,speed,0);
  }
  else if (linevector != 0 && linearraydetected < 4) { // if the robot is drifting off the track

    lineerror = lineguide + linevector;
    
    int correctionSpeed = (int)((double)speed * corrSpeedFactor);
    
    prevlineError = PIDReturn [1];
    prevlineITerm = PIDReturn [2];

    PID_LineEquation(lineerror,PLine,ILine,DLine,prevlineError,prevlineITerm);

    float lineCorrection = PIDReturn [0];
    Serial.println(lineCorrection);
    

    if (lineCorrection < 0) {
      //Serial.println("turn left");
      lineCorrection = -1*lineCorrection;
      speed1 = (int)lineCorrection;
      speed2 = (int)lineCorrection;
      singleMotor(1,speed1,clockwise);
      singleMotor(2,speed2,clockwise);
    }
    else if (linevector > 0) {
      //Serial.println("turn right");
      speed1 = (int)lineCorrection;
      speed2 = (int)(lineCorrection + 10);
      singleMotor(1,speed1,counterclockwise);
      singleMotor(2,speed2,counterclockwise);
    }

    speed3 = correctionSpeed;
    speed4 = correctionSpeed;

    singleMotor(3,speed3,clockwise);
    singleMotor(4,speed4,counterclockwise);
  }
  else if (linevector != 0 && linearraydetected > 3) { // if an intersection is detected
    ignoreGreen = 1;
    move(0,speed,0);
  }
  else if (linevector == 0 && linearraydetected == 0) { // if the robot loses the line track
    Serial.println("no line");
    stopmove();
    moveDist(150,50,'y');
    unsigned long turnTime = millis();
    unsigned long checkTimer = millis();
    int IRsensor4State = getIRsensorState(5);
    while (IRsensor4State == 0 && (checkTimer-turnTime) < 2500) { // while the second IRsensor isn't on the line and a duration of 1.8 seconds hasn't elapsed
      move(0,0,-90);
      IRsensor4State = getIRsensorState(5);
      checkTimer = millis();
    }
    stopmove();
    if (IRsensor4State == 0 && (checkTimer-turnTime) >= 2500) { // if the duration of 1.8 seconds has elapsed and the second IRsensor isn't on the line
      int IRsensor7State = getIRsensorState(4);
      turnTime = millis();
      checkTimer = millis();
      while (IRsensor7State != 1 && (checkTimer-turnTime) < 3000) { // while the seventh IRsensor isn't on the line
        move(0,0,90);
        IRsensor7State = getIRsensorState(4);
        checkTimer = millis();
      }
      stopmove();
      if ((checkTimer-turnTime) >= 3000 && IRsensor7State == 0) {
        move(0,0,-90);
        turnTime = millis();
        checkTimer = millis();
        while ((checkTimer - startTime) < 3000) {
          checkTimer = millis();
          move(speed,0,-90);
        }
        stopmove();
      }
    }
  }
  else if(linevector == 0 && linearraydetected>7) {
    int climbSpeed=speed+10;
    move(0,climbSpeed,0);
  }
}

void mainProgram()
{
  
}

void resetPID()
{
  prevlineError = 0;
  prevlineITerm = 0;
  Serial.print("1: ");
  Serial.print(" ");
  Serial.print("  2: ");
  Serial.println();
}



void motorSetup()
{
  //setting outputs and inputs
  pinMode(nSLEEP,OUTPUT);
  pinMode(EN1,OUTPUT);
  pinMode(PH1,OUTPUT);
  pinMode(EN2,OUTPUT);
  pinMode(PH2,OUTPUT);
  pinMode(EN3,OUTPUT);
  pinMode(PH3,OUTPUT);
  pinMode(EN4,OUTPUT);
  pinMode(PH4,OUTPUT);
  pinMode(button,INPUT_PULLUP);
  
  //Setting the motors active
  digitalWrite(nSLEEP,HIGH);

  //Making sure the robot won't move yet
  stopmove();

}

int xget_motorVector(double speed, float angle) 
{
  double motorspeed = speed / cos(angle*PI/180);
  return (int)motorspeed;
}

int yget_motorVector(double speed,float angle)
{
  double motorspeed = speed / sin(angle*PI/180);
  return (int)motorspeed;
}

void singleMotor(int motor, int speed,int direction)
{
  if (direction == clockwise) {
    if (motor == 1) {
      analogWrite(EN1, speed);
      digitalWrite(PH1, 1);
    }
    else if (motor == 2) {
      analogWrite(EN2, speed);
      digitalWrite(PH2, 1);
    }
    else if (motor == 3) {
      analogWrite(EN3, speed);
      digitalWrite(PH3, 1);
    }
    else if (motor == 4) {
      analogWrite(EN4, speed);
      digitalWrite(PH4, 1);
    }
  }
  else if (direction == counterclockwise) {
    if (motor == 1) {
      //Serial.println("aaa");
      analogWrite(EN1, speed);
      digitalWrite(PH1, 0);
    }
    else if (motor == 2) {
      analogWrite(EN2, speed);
      digitalWrite(PH2, 0);
    }
    else if (motor == 3) {
      analogWrite(EN3, speed);
      digitalWrite(PH3, 0);
    }
    else if (motor == 4) {
      analogWrite(EN4, speed);
      digitalWrite(PH4, 0);
    }
  }
}

void stopmove()
{
  //Motor Topleft
  analogWrite(EN1, 0);
  digitalWrite(PH1, 1);

  //Motor TopRight
  analogWrite(EN2, 0);
  digitalWrite(PH2, 1);

  //Motor BottomRight
  analogWrite(EN3, 0);
  digitalWrite(PH3, 1);

  //Motor BottomLeft
  analogWrite(EN4, 0);
  digitalWrite(PH4, 1);
}


void forlater()
{
  while (Serial1.available() > 0) {
    int recievedData = Serial1.parseInt();
    Serial.println(receivedData);
    if (recievedData > 0) {
      if (recievedData >149){
        moveDist(150,100,'y');
        moveDist(150,100,'x');
        moveDist(150,-100,'y');
        moveDist(150,-100,'x');
      }
      else if (recievedData < 149)
      {
        move(0,0,100);
        delay(1000);
        stopmove();
      }
    }
    else if (recievedData == 1) {
      Serial.println(recievedData);
      stopmove();
    }
  }
  /*
  while (Serial1.available() > 0) {
    int recievedData = Serial1.parseInt();
    Serial.println(recievedData);
    if (recievedData != 0 && recievedData != 1) {
      if (recievedData < 0) {
        recievedData = recievedData *-1;
      }
      int speed1 = recievedData;
      int speed2 = recievedData-20;
      int speed3 = recievedData-20;
      int speed4 = recievedData-20;

      singleMotor(1,speed1,counterclockwise);
      singleMotor(2,speed2,clockwise);
      singleMotor(3,speed3,clockwise);
      singleMotor(4,speed4,counterclockwise);
     
    }
    else if (recievedData == 1) {
      Serial.println(recievedData);
      stopmove();
    }
  }
  */
  
/*
  if (buttonstate == pressed){
    Serial.print("pressed");
    delay(300);
    singleMotor(4,60,0);
    buttonstate = digitalRead(button);

    while (buttonstate != pressed){
      //m1Speed = getSpeed(1);
      buttonstate = digitalRead(button);
      //if (m1Speed != 0.00) {
        //Serial.println(m1Speed);
      //}
    }
    delay(300);
    stopmove();
  }
    */

  //Encoder A readings
  //attachInterrupt(digitalPinToInterrupt(ENC1A),motorPosition, RISING);

  /*
  pinMode(ENC1A, INPUT);
  pinMode(ENC2A, INPUT);
  pinMode(ENC3A, INPUT);
  pinMode(ENC4A, INPUT);
  pinMode(ENC1B, INPUT);
  pinMode(ENC2B, INPUT);
  pinMode(ENC3B, INPUT);
  pinMode(ENC4B, INPUT);
  */

}