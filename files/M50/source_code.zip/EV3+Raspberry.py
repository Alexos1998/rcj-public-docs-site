#EV3 code

from pybricks.hubs import EV3Brick
from pybricks.ev3devices import (Motor, TouchSensor, ColorSensor,
                                 InfraredSensor, UltrasonicSensor, GyroSensor)
from pybricks.parameters import (Port, Stop, Direction, Button, Color)
from pybricks.tools import wait  

ev3 = EV3Brick()

left_motor = Motor(Port.B)
right_motor = Motor(Port.C)

sensor_front = UltrasonicSensor(Port.S3)
sensor_right = UltrasonicSensor(Port.S1)
sensor_right2 = UltrasonicSensor(Port.S4)
color_sensor = ColorSensor(Port.S2)


def robot_left():
    left_motor.run(-368)
    right_motor.run(368)
    wait(1600)
    robot_back()

def robot_right():
    left_motor.run(368)
    right_motor.run(-368)
    wait(1550)

def robot_back():
    left_motor.run(-300)
    right_motor.run(-300)
    wait(200)

def robot_stop():
    left_motor.stop()
    right_motor.stop()
    wait(1000)

def robot_straight():
    left_motor.run(400)
    right_motor.run(400)
    wait(100)

def check_angle():
    if sensor_right.distance() < 200:  
        difference = sensor_right.distance()-sensor_right2.distance()
        if difference > 20:
            ev3.speaker.beep()
            left_motor.run(100)
            right_motor.run(-100)
            wait(100)
        elif difference < -20:
            ev3.speaker.beep()
            left_motor.run(-100)
            right_motor.run(100)
            wait(100)


def front_wall():
    if sensor_front.distance() < 65:
         robot_stop()
         robot_back()
         robot_left()
         robot_back()

def right_free():
    if sensor_right.distance() > 300:  
        robot_stop()
        robot_straight()
        wait(800)
        robot_stop()
        robot_right()
        robot_straight()
        wait(995)

def black_alarm():
    if color_sensor.color() == Color.BLACK:  
        robot_stop()
        robot_back()
        wait(700)
        robot_stop()
        robot_left()
        wait(200)
        if sensor_front.distance() > 250:
            left_motor.run(400)
            right_motor.run(400)
            wait(2500)
        else:
            robot_left()

def blue_stop():
    if color_sensor.color() == Color.BLUE:  
        left_motor.run(150)
        right_motor.run(150)
        wait(900)
        robot_stop()
        wait(5000)


# ---------------- START ----------------

ev3.speaker.beep()

while True:
    robot_straight()
    wait(110)

    right_free()
    check_angle()
    front_wall()
    black_alarm()
    blue_stop()





#Raspberry Pi Code:
from __future__ import annotations

import importlib
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

cv2 = importlib.import_module("cv2")
np = importlib.import_module("numpy")


TARGET_LETTERS = ("Φ", "Ψ", "Ω")
NORMALIZED_SIZE = 160
MATCH_THRESHOLD = 0.72
SOURCE_PATH: Path | None = None
REFERENCE_PATH = Path(__file__).with_name("image.png")
CAMERA_INDEX = 0
INTERVAL = 0.15


@dataclass(frozen=True)
class LetterTemplate:
	letter: str
	image: Any


def preprocess(image: Any) -> Any:
	if image.ndim == 3:
		image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
	_, binary = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
	return binary


def pad_to_square(image: Any, size: int = NORMALIZED_SIZE) -> Any:
	height, width = image.shape[:2]
	scale = min(size / max(height, 1), size / max(width, 1))
	resized = cv2.resize(image, (max(1, int(width * scale)), max(1, int(height * scale))), interpolation=cv2.INTER_AREA)
	canvas = np.zeros((size, size), dtype=np.uint8)
	y_offset = (size - resized.shape[0]) // 2
	x_offset = (size - resized.shape[1]) // 2
	canvas[y_offset : y_offset + resized.shape[0], x_offset : x_offset + resized.shape[1]] = resized
	return canvas


def extract_components(binary: Any) -> list[tuple[int, int, int, int]]:
	contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
	image_area = binary.shape[0] * binary.shape[1]
	boxes: list[tuple[int, int, int, int]] = []
	for contour in contours:
		x, y, width, height = cv2.boundingRect(contour)
		area = width * height
		if area < image_area * 0.01:
			continue
		if width < 10 or height < 10:
			continue
		boxes.append((x, y, width, height))
	boxes.sort(key=lambda box: box[0])
	return boxes


def build_templates(reference_path: Path) -> list[LetterTemplate]:
	reference_image = cv2.imread(str(reference_path), cv2.IMREAD_COLOR)
	if reference_image is None:
		raise FileNotFoundError("bad ref")

	binary = preprocess(reference_image)
	boxes = extract_components(binary)
	if len(boxes) < len(TARGET_LETTERS):
		raise ValueError("bad ref")

	templates: list[LetterTemplate] = []
	for letter, (x, y, width, height) in zip(TARGET_LETTERS, boxes):
		crop = binary[y : y + height, x : x + width]
		templates.append(LetterTemplate(letter=letter, image=pad_to_square(crop)))
	return templates


def score_match(candidate: Any, template: Any) -> float:
	if candidate.shape != template.shape:
		candidate = cv2.resize(candidate, (template.shape[1], template.shape[0]), interpolation=cv2.INTER_AREA)
	candidate_f = candidate.astype(np.float32) / 255.0
	template_f = template.astype(np.float32) / 255.0
	return float(cv2.matchTemplate(candidate_f, template_f, cv2.TM_CCOEFF_NORMED)[0, 0])


def detect_letters(image: Any, templates: Iterable[LetterTemplate]) -> list[tuple[str, float, tuple[int, int, int, int]]]:
	binary = preprocess(image)
	results: list[tuple[str, float, tuple[int, int, int, int]]] = []

	for x, y, width, height in extract_components(binary):
		crop = pad_to_square(binary[y : y + height, x : x + width])
		best_letter = ""
		best_score = -1.0
		for template in templates:
			score = score_match(crop, template.image)
			if score > best_score:
				best_score = score
				best_letter = template.letter
		if best_score >= MATCH_THRESHOLD:
			results.append((best_letter, best_score, (x, y, width, height)))

	return results


def run_once(source: Any, templates: list[LetterTemplate]) -> None:
	matches = detect_letters(source, templates)
	if not matches:
		print("no match")
		return

	for letter, score, (x, y, width, height) in matches:
		print(f"hit {letter}") # hier funktion mit letter als argument einsetzen oder so


def scan_camera(camera_index: int, templates: list[LetterTemplate], interval: float) -> None:
	capture = cv2.VideoCapture(camera_index)
	if not capture.isOpened():
		raise RuntimeError("open cam")

	try:
		while True:
			ok, frame = capture.read()
			if not ok:
				raise RuntimeError("read cam")
			run_once(frame, templates)
			time.sleep(interval)
	finally:
		capture.release()


def main() -> None:
	templates = build_templates(REFERENCE_PATH)

	if SOURCE_PATH is not None:
		source_image = cv2.imread(str(SOURCE_PATH), cv2.IMREAD_COLOR)
		if source_image is None:
			raise FileNotFoundError("bad input")
		run_once(source_image, templates)
		return

	scan_camera(CAMERA_INDEX, templates, INTERVAL)


if __name__ == "__main__":
	main()

