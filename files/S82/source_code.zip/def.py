from controller import Robot
import cv2
import numpy as np
from collections import deque
import math
import struct
from ultralytics import YOLO
import matplotlib.pyplot as plt

# ================== COSTANTI E SETUP ==================
robot = Robot()
timestep = int(robot.getBasicTimeStep())

left_motor = robot.getDevice("wheel1 motor"); left_motor.setPosition(float('inf'))
right_motor = robot.getDevice("wheel2 motor"); right_motor.setPosition(float('inf'))
left_encoder = robot.getDevice("wheel1 sensor"); left_encoder.enable(timestep)
lidar = robot.getDevice("lidar"); lidar.enable(timestep); lidar.enablePointCloud()
gps = robot.getDevice("gps"); gps.enable(timestep)
imu = robot.getDevice("inertial_unit"); imu.enable(timestep)
color_sensor = robot.getDevice("colour_sensor"); color_sensor.enable(timestep)
emitter = robot.getDevice("emitter")
receiver = robot.getDevice("receiver")
receiver.enable(timestep)

MAX_VELOCITY = 6.28 
BLACK_THRESHOLD = 130
WHEEL_RADIUS = 0.020

#debug
d_movimento = False
d_visione = False
d_mappatura = True

# ======= CLASSE VISORE =======
class Visore:
    def __init__(self, robot, timestep):
        self.timestep = timestep
        self.robot = robot
        self.step_counter = 0 
        
        self.camera1 = self.robot.getDevice("camera1")
        self.camera2 = self.robot.getDevice("camera2")

        if self.camera1:
            self.camera1.enable(self.timestep)
            self.width = self.camera1.getWidth()
            self.height = self.camera1.getHeight()
        else:
            print("ERRORE: 'camera1' non trovata.")
        if self.camera2:
            self.camera2.enable(self.timestep)

        else:
            print("ERRORE: 'camera2' non trovata.")
        
        model_path = r"C:\Users\marco\Desktop\erebus\Erebus\best.pt"
        
        try:
            self.model = YOLO(model_path)
            if d_visione: print("[VISORE] Modello YOLO caricato")
        except Exception as e:
            if d_visione: print(f"[VISORE] YOLO non caricato: {e}")
            self.model = None

    def victim_detection(self):
        n_victim = 0
        raw_image = []
        raw_image.append(self.camera1.getImage())
        raw_image.append(self.camera2.getImage())

        for i in range(2):
            # Converte il raw in matrice 
            img_array = np.frombuffer(raw_image[i], np.uint8).reshape((self.height, self.width, 4))
            # Rimuove la trasparenza
            frame= cv2.cvtColor(img_array, cv2.COLOR_BGRA2BGR)
            # Converte in hsv
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            # Crea le maschere per i colori
            mask_white = cv2.inRange(hsv, np.array([0,0,190]), np.array([10,10,220]))
            mask_black = cv2.inRange(hsv, np.array([0,0,0]),np.array([10,10,25]))
            mask_red = cv2.inRange(hsv, np.array([0, 250, 190]), np.array([10,255,230]))
            mask_green = cv2.inRange(hsv, np.array([50, 250, 190]), np.array([80, 255, 230]))
            mask_blue = cv2.inRange(hsv, np.array([100, 250, 190]), np.array([140, 255, 230]))
            mask_yellow = cv2.inRange(hsv, np.array([20, 255, 190]), np.array([40, 255, 230]))
            # Unisco tutte le maschere
            mask_color = cv2.bitwise_or(mask_red, mask_green)
            mask_color = cv2.bitwise_or(mask_color, mask_blue)
            mask_color = cv2.bitwise_or(mask_color, mask_yellow)
            mask_color = cv2.bitwise_or(mask_color, mask_black)
            mask_totale = cv2.bitwise_or(mask_white, mask_color)
            # Prendo tutti i contorni estermi (cv2.RETR_EXTERNAL)
            contours, _ = cv2.findContours(mask_totale, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            # Creo il puntatore al centro
            centro_x = self.width // 2
            centro_y = self.height // 2
            margine_x = int(self.width * 0.05)
            margine_y = int(self.height * 0.1)
            pt1_mirino = (centro_x - margine_x, centro_y - margine_y)
            pt2_mirino = (centro_x + margine_x, centro_y + margine_y)
            target = False
            render = frame.copy()
            cv2.rectangle(render, pt1_mirino, pt2_mirino, (255,255,0),1)


            for cnt in contours:
                # Controllo se la Mask si trova al centro della telecamera
                
                x, y, w, h = cv2.boundingRect(cnt)
                cx = int(x + (w/2))
                cy = int(y + (h/2))
                if cv2.contourArea(cnt) > 300: #Se l'obiettivo è abbastanza vicino
                    #print(f"Area: {cv2.contourArea(cnt)}")
                    if (abs(cy - centro_y) <=margine_y) and (abs(cx - centro_x) <= margine_x):
                        n_victim += (i+1)
                        if d_visione: cv2.rectangle(render, (x, y), (x+w, y+h), (0,255,0), 2)
                        
                    else:
                        if d_visione: cv2.rectangle(render, (x, y), (x+w, y+h), (0,0,255), 1)
            
            #Mostriamo le immagini e la mask
            if d_visione:
                zoom = cv2.resize(mask_totale, (self.width*8, self.height*8), interpolation=cv2.INTER_NEAREST)
                cv2.imshow(f"Camera {i+1} mask", zoom)
                cv2.waitKey(1)
                zoom = cv2.resize(render, (self.width*8, self.height*8), interpolation=cv2.INTER_NEAREST)
                cv2.imshow(f"Camera {i+1}", zoom)
                cv2.waitKey(1)            


        return n_victim

    def analizza_colore_hsv(self, h, s, v):
        # Logica per il Nero (molto scuro)
        if v < 50: 
            return -2, "Nero"
        
        # Logica per i colori (Saturazione alta)
        if s > 150:
            if 50 <= h <= 85:   return 1, "Verde"
            if 100 <= h <= 140: return 2, "Blu"
            if h < 10 or h > 170: return -1, "Rosso"
            if 20 <= h <= 40:   return 0, "Giallo"
        
        return 0, "Sconosciuto"

    def identifica_bersaglio(self, n_victim):
        raw_image = []
        raw_image.append(self.camera1.getImage())
        raw_image.append(self.camera2.getImage())
        res = []
        tipo_bersaglio = []
        l = [0,1] if n_victim == 3 else [n_victim-1]
        for i in l:     
            img_array = np.frombuffer(raw_image[i], np.uint8).reshape((self.height, self.width, 4))
            frame = cv2.cvtColor(img_array, cv2.COLOR_BGRA2BGR)
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            
            
            # --- CONTROLLO BIANCO (YOLO) ---
            h, w = hsv.shape[:2]
            fascia_hsv = hsv[(h//2)-5 : (h//2)+5, :] # Fascia di 10 pixel al centro

            mask_white = cv2.inRange(fascia_hsv, np.array([0, 0, 180]), np.array([180, 40, 255]))

            if cv2.countNonZero(mask_white) > 50:
                if self.model:
                    pred = self.model.predict(source=frame, conf=0.2, imgsz=160, verbose=False)
                    if len(pred[0].boxes) > 0:

                        res.append(self.model.names[int(pred[0].boxes[0].cls[0])])
                        tipo_bersaglio.append("lettera")
                        continue
                    else:
                        res.append("phi")
                        tipo_bersaglio.append("lettera")
                        continue
                        

            # --- LOGICA HAZMAT ---
            cy = self.height // 2
            riga_hsv = hsv[cy, :] 

            # Identifica cerchio
            indici_cerchio = [x for x, (h, s, v) in enumerate(riga_hsv) if v < 25 or s > 180]

            inizio_cerchio = min(indici_cerchio)
            fine_cerchio = max(indici_cerchio)            

            punti = range(inizio_cerchio, fine_cerchio)

            verde, blu, rosso, giallo, nero = 0, 0, 0, 0, 0

            # Calcolo valori
            somma = 0
            ultimo_nome = None
            conteggio_pixel_colore = 0
            valore_corrente = 0
            SPESSORE_ANELLO = len(punti) // 5  # Base per 1 colore
            if d_visione: print(f"Spessore Anello: {SPESSORE_ANELLO} | Numero punti: {len(punti)}")
            for px in punti:
                h_v, s_v, v_v = hsv[cy, px]
                val, nome = self.analizza_colore_hsv(h_v, s_v, v_v)             

                if nome == "Nero":
                    nero +=1
                elif nome == "Blu": 
                    blu += 1
                elif nome == "Verde":
                    verde +=1
                elif nome == "Giallo":
                    giallo += 1
                elif nome == "Rosso":
                    rosso += 1

            if SPESSORE_ANELLO != 0:
                somma = (round(nero / SPESSORE_ANELLO) * -2) + (round(blu  / SPESSORE_ANELLO) * 2) + (round(verde / SPESSORE_ANELLO) * 1) + (round(rosso / SPESSORE_ANELLO) * -1) #+ (giallo // SPESSORE_ANELLO * -2)
            else:
                somma = 5

            if d_visione: print(f"SOMMA FINALE: {somma}")
            nomi_hazmat = {0: "F", 1: "P", 2: "C", 3: "O"}
            risultato = nomi_hazmat.get(somma, "Sconosciuto")
            res.append(risultato)
            tipo_bersaglio.append("cerchio")
        return res, tipo_bersaglio

visore = Visore(robot, timestep)

# ========= CLASSE MAPPA =======
class Map:
    def __init__(self, size = 2.0, resolution = 0.01, lidar_offset = 0.04):
        self.resolution = resolution
        self.lidar_offset = lidar_offset
        self.grid_size = int(size / resolution)

        self.grid = np.zeros((self.grid_size,self.grid_size), dtype = np.int8)

        self.origin = self.grid_size // 2

        if d_mappatura:
            plt.ion()
            self.fig, self.ax = plt.subplots() # figsize=(6, 6)
            self.im = self.ax.imshow(self.grid, cmap = 'viridis', origin='lower',vmin = 0, vmax = 4)
            plt.title("### Map ###")

    def draw_map(self):
        if d_mappatura:
            self.im.set_data(self.grid)
            self.fig.canvas.draw()
            self.fig.canvas.flush_events()
            plt.pause(0.001)

    def get_yaw(self): return imu.getRollPitchYaw()[2]

    def get_gps_pos(self):
        v = gps.getValues()
        return v[0], v[2] # x, z

    def gps_to_grid(self, x, z):

        gx = int(round(x / self.resolution)) + self.origin
        gz = int(round(z / self.resolution)) + self.origin
        return gx, gz
    
    def get_lidar_pos(self):
        robot_x, robot_z = self.get_gps_pos()
        robot_yaw = self.get_yaw()
        
        lx = robot_x - self.lidar_offset * math.sin(robot_yaw)
        lz = robot_z - self.lidar_offset * math.cos(robot_yaw)
        
        return lx, lz
    
    def add_walls(self):
        robot_yaw = self.get_yaw() 
        range_image = lidar.getRangeImage() 
        
        if not range_image:
            return
        
        lx, lz = self.get_lidar_pos() 
        
        
        FRONT_IDX = 0 
        HALF_FOV  = 128      #  90° 
        MAX_DIST  = 0.18     
        padding_radius_m=0.02
        # Padding muri
        pad_cells = int(padding_radius_m / self.resolution)
        
        for offset in range(-HALF_FOV, HALF_FOV + 1): 
            # Indice reale nell'array 
            idx_in_layer = (FRONT_IDX + offset) % 512 
            real_index   = 512 + idx_in_layer   # Secondo strato del lidar
            
            distance = range_image[real_index] 
            
            
            if math.isinf(distance) or distance > MAX_DIST: 
                continue 
            
            # Angolo normalizzato
            local_angle = -idx_in_layer * (2 * math.pi / 512) 
            if local_angle > math.pi: 
                local_angle -= 2 * math.pi 
            
            total_angle = robot_yaw + local_angle
            
            gx = lx - distance * math.sin(total_angle) 
            gz = lz - distance * math.cos(total_angle) 
            
            row, col = self.gps_to_grid(gx, gz) 
            
            if 0 <= row < self.grid_size and 0 <= col < self.grid_size: 
                # Padding
                if self.grid[row, col] != 2:
                    self.grid[row, col] = 2 
                    
                    for pr in range(-pad_cells, pad_cells + 1):
                        for pc in range(-pad_cells, pad_cells + 1):
                            nr = row + pr
                            nc = col + pc
                            
                            # Confini della mappa
                            if 0 <= nr < self.grid_size and 0 <= nc < self.grid_size:
                                # Non sovrascrivere i muri
                                if self.grid[nr, nc] != 2:
                                    self.grid[nr, nc] = 3

    def add_cells(self, radius_m = 0.06):
        robot_x, robot_z = self.get_gps_pos()


        radius = int(radius_m / self.resolution)
        gx, gz = self.gps_to_grid(robot_x, robot_z)

        for r in range(gx - radius, gx + radius + 1):
            for c in range(gz - radius, gz + radius + 1):
                if 0 <= r < self.grid_size and 0 <= c < self.grid_size:
                    if self.grid[r,c] != 2 and  self.grid[r,c] != 3:
                        self.grid[r, c] = 1

    def save_map(self):
        if d_mappatura:
            self.draw_map()
            plt.savefig(r'C:\Users\marco\Desktop\mappa_labirinto.png', bbox_inches='tight', dpi=300)
            plt.ioff()  # Disattiva la modalità interattiva
            plt.show()
            plt.imshow(self.grid, cmap = 'viridis', origin='lower',vmin = 0, vmax = 3)
            plt.show()
map = Map()

# ================== FUNZIONI DI SUPPORTO ==================

def get_yaw(): 
    return imu.getRollPitchYaw()[2]

def normalizza_angolo(angolo):
    while angolo > np.pi: angolo -= 2 * np.pi
    while angolo < -np.pi: angolo += 2 * np.pi
    return angolo

def get_front_distance():
    range_image = lidar.getRangeImage()
    range_dist = range_image[512:536] + range_image[1000:1024]
    
    return min(range_dist)

def frena():
    left_motor.setVelocity(0); right_motor.setVelocity(0)

def gira_a_direzione(target_dir_idx):
    target_rads = {0: 0.0, 1: -1.5708, 2: 3.1415, 3: 1.5708}
    target_val = target_rads[target_dir_idx % 4]
    while robot.step(timestep) != -1:
        errore = target_val - get_yaw()
        errore = normalizza_angolo(errore)
        if abs(errore) < 0.01: break
        vel = np.clip(errore * 6.0, -3.0, 3.0)
        left_motor.setVelocity(vel); right_motor.setVelocity(-vel)
    frena()

def muovi_indietro_dist(distanza_m):
    start_enc = left_encoder.getValue()
    dist_rad = distanza_m / WHEEL_RADIUS
    left_motor.setVelocity(-2.5); right_motor.setVelocity(-2.5)
    while robot.step(timestep) != -1:
        if abs(left_encoder.getValue() - start_enc) >= dist_rad: break
    frena()

def muovi_avanti_dist(distanza_m):
    start_enc = left_encoder.getValue()
    dist_rad = distanza_m / WHEEL_RADIUS
    left_motor.setVelocity(2.5); right_motor.setVelocity(2.5)
    while robot.step(timestep) != -1:
        if abs(left_encoder.getValue() - start_enc) >= dist_rad: break
    frena()

def ruota_sinistra_mill(millisecondi):
    conta_step = 0
    for _ in range(int(millisecondi / timestep)):
        if robot.step(timestep) == -1: break

        n_victim = visore.victim_detection()
        if n_victim:
            esegui_procedura_vittima(n_victim)
        
        if conta_step%40 == 0:
            map.add_walls()
            map.add_cells()
            map.draw_map()
            conta_step = 0
        conta_step += 1

        left_motor.setVelocity(MAX_VELOCITY * 0.6)
        right_motor.setVelocity(-MAX_VELOCITY * 0.6)

def ruota_destra_mill(millisecondi):
    conta_step = 0
    for _ in range(int(millisecondi / timestep)):
        if robot.step(timestep) == -1: break

        n_victim = visore.victim_detection()
        if n_victim:
            esegui_procedura_vittima(n_victim)

        if conta_step%40 == 0:
            map.add_walls()
            map.add_cells()
            map.draw_map()
            conta_step = 0
        conta_step += 1
        left_motor.setVelocity(-MAX_VELOCITY * 0.6)
        right_motor.setVelocity(MAX_VELOCITY * 0.6)
                                
def ruota_verso(target_yaw):

    if d_movimento: print(f"[*] Rotazione verso l'angolo {target_yaw:.2f} rad")
    while robot.step(timestep) != -1:
        yaw_corrente = map.get_yaw() 
        errore_angolo = normalizza_angolo(target_yaw - yaw_corrente)
        
        if abs(errore_angolo) < 0.05:
            frena()
            break
            
        velocita_rotazione = MAX_VELOCITY * 0.4
        
        left_speed = -velocita_rotazione if errore_angolo > 0 else velocita_rotazione
        right_speed = velocita_rotazione if errore_angolo > 0 else -velocita_rotazione
        
        left_motor.setVelocity(right_speed)
        right_motor.setVelocity(left_speed)

# =============  FUNZIONI DI VISIONE  ==========

def verifica_3d():
    range_image = lidar.getRangeImage()
    if not range_image: return 
    dist = range_image[-20:-1] + range_image[0:20]
    if d_visione: 
        print("[-- 3D --]")
        for i, r in enumerate(dist):
            print(f"[{i}]: {r:.3f}")


vittime = [] # (bersaglio_x, bersaglio_z, tipo, robot_x, robot_z)
DISTANZA_MURO = 0.04
DISTANZA_ROBOT = 0.04


def esegui_procedura_vittima(n_victim):
    global vittime

    tipo_id, tipo_vittima = visore.identifica_bersaglio(n_victim)
    if d_visione: print(f"Tipo id = {len(tipo_id)}")

    # Mappatura lettere 
    mappa_codici = {
        'phi': b'H',    # Phi (Φ) -> Harmed
        'psi': b'S',    # Psi (Ψ) -> Stable
        'omega': b'U',  # Omega (Ω) -> Unharmed
        'F': b'F', 'P': b'P', 'C': b'C', 'O': b'O'
    }

    l = [0, 1] if n_victim == 3 else [n_victim-1]

    rx, rz = map.get_gps_pos()
    robot_yaw = map.get_yaw()
    range_image = lidar.getRangeImage()

    for i, lato in enumerate(l):

        if lato == 1:
            angolo_bersaglio = robot_yaw - (math.pi / 2)
            distanza_muro = range_image[512 + 128] 
        elif lato == 0:
            angolo_bersaglio = robot_yaw + (math.pi / 2)
            distanza_muro = range_image[512 - 128] 
            
        if math.isinf(distanza_muro) or math.isnan(distanza_muro):
            distanza_muro = 1.0

        bersaglio_x = rx - distanza_muro * math.sin(angolo_bersaglio)
        bersaglio_z = rz - distanza_muro * math.cos(angolo_bersaglio)
        
        # Controllo
        for vx, vz, tipo_salvato, rx_salvato, rz_salvato in vittime:
            
            # Distanza tra il punto osservato e la vittima in memoria
            dist_muro = math.sqrt((bersaglio_x - vx)**2 + (bersaglio_z - vz)**2)
            
            if dist_muro < DISTANZA_MURO:
                dist_robot = math.sqrt((rx - rx_salvato)**2 + (rz - rz_salvato)**2)
                
                if dist_robot < DISTANZA_ROBOT:
                    if d_visione: print(f"[VITTIMA] Obiettivo '{tipo_id[i]}' già noto dallo stesso lato")
                    return False 
                else:
                    if d_visione: print(f"[VITTIMA] Stesse coordinate muro, ma robot in posizione diversa. LATO OPPOSTO")

        if tipo_vittima[i] == "lettera":
            angolo_bersaglio = normalizza_angolo(angolo_bersaglio)
            ruota_verso(angolo_bersaglio)
            verifica_3d()
            ruota_verso(robot_yaw)

        char_to_send = b'L'

        if isinstance(tipo_id[i], str):
            for k, v in mappa_codici.items():
                if k in tipo_id[i]: char_to_send = v; break

        if d_visione: print(f"[VITTIMA] Trovato NUOVO bersaglio '{tipo_id[i]}' a X:{bersaglio_x:.2f}, Z:{bersaglio_z:.2f}!")
        if tipo_id[i] != "Sconosciuto":
            vittime.append((bersaglio_x, bersaglio_z, char_to_send.decode(), rx, rz))

          
        Fake = False
        
        if char_to_send != b'L': 
            frena()

            for _ in range(int(1500 / timestep)):
                robot.step(timestep)
            
            p_invio = gps.getValues()
            x_cm = int(round(p_invio[0] * 100))
            z_cm = int(round(p_invio[2] * 100))
            
            if not Fake and emitter:
                message = struct.pack("i i c", x_cm, z_cm, char_to_send)
                emitter.send(message)
                if d_visione: print(f"[INVIATO] -> X:{x_cm} Z:{z_cm} Tipo:{char_to_send.decode()}")
            for _ in range(int(1000 / timestep)):
                robot.step(timestep)
            
        else: 
            
            if d_visione: print("Bersaglio finto")
            return False
        
                
    return True

# ========= FUNZIONI DI MAPPATURA ============

tile_colorate = []

def analizza_tile():
    img = color_sensor.getImage()
    if not img: return '0'
    r = color_sensor.imageGetRed(img, 1, 0, 0)
    g = color_sensor.imageGetGreen(img, 1, 0, 0)
    b = color_sensor.imageGetBlue(img, 1, 0, 0)
    somma = r + g + b

    # Buco Nero
    if somma < BLACK_THRESHOLD: return '2'
    
    # Checkpoint 
    if r > 240 and g > 240 and b > 240: return '4'
        
    # Palude 
    if r > 190 and 150 < g < 200 and b < 130: return '3'

    if g > 200 and r < 100 and b < 100: return 'g' # Verde
    if b > 200 and r < 100 and g < 100: return 'b' # Blu
    if r > 200 and g < 100 and b < 100: return 'r' # Rosso
    if b > 200 and r > 120 and g < 100: return 'p' # Viola
    if r > 200 and g > 240 and b < 100: return 'y' # Giallo
    if r > 200 and g > 200 and b < 100: return 'o' # Arancione
    
    
    return '0'

def is_black_hole():
    return analizza_tile() == '2'

def invia_mappa_erebus():
    global vittime, tile_colorate
    
    if d_mappatura: 
        print("[MAPPA] Conversione e invio a Erebus")
        
    mappa_erebus = {}
    
    # 1. Muri e Pavimento
    for r in range(map.grid_size):
        for c in range(map.grid_size):
            valore = map.grid[r, c]
            
            if valore in [1, 2]: 
                x = (r - map.origin) * map.resolution
                z = (c - map.origin) * map.resolution
                
                ex = int(round(x / 0.03))
                ez = int(round(z / 0.03))
                
                if valore == 2: # MURO
                    raw_x = x / 0.03
                    raw_z = z / 0.03
                    
                    muro_struct_x = round((raw_x - 2) / 4) * 4 + 2
                    muro_struct_z = round((raw_z - 2) / 4) * 4 + 2
                    
                    distanza_da_x = abs(raw_x - muro_struct_x)
                    distanza_da_z = abs(raw_z - muro_struct_z)
                    
                    if distanza_da_x < distanza_da_z:
                        ex = int(muro_struct_x)
                        ez = int(round(raw_z))
                    else:
                        ex = int(round(raw_x))
                        ez = int(muro_struct_z)
                            
                    mappa_erebus[(ex, ez)] = '1'
                    
                elif valore == 1 and (ex, ez) not in mappa_erebus: # PAVIMENTO
                    mappa_erebus[(ex, ez)] = '0'

    # 2. Tile colorate
    for tx, tz, tipo in tile_colorate:
        tx_center = round(tx / 0.12) * 0.12
        tz_center = round(tz / 0.12) * 0.12
        
        # Conversione del centro in coordinate matrice Erebus
        ex_center = int(round(tx_center / 0.03))
        ez_center = int(round(tz_center / 0.03))
        
        for dx in [-1, 1]:
            for dz in [-1, 1]:
                mappa_erebus[(ex_center + dx, ez_center + dz)] = str(tipo)

    # 3. Vittime 
    for vx, vz, tipo, rx, rz in vittime:
        ex = int(round(vx / 0.03))
        ez = int(round(vz / 0.03))
        mappa_erebus[(ex, ez)] = str(tipo)
        
    if not mappa_erebus:
        if d_mappatura: 
            print("[MAPPA] Errore: mappa vuota.")
        return

    # 4. Creazione Matrice
    min_x = min(k[0] for k in mappa_erebus.keys())
    max_x = max(k[0] for k in mappa_erebus.keys())
    min_z = min(k[1] for k in mappa_erebus.keys())
    max_z = max(k[1] for k in mappa_erebus.keys())

    width = max_x - min_x + 1
    height = max_z - min_z + 1

    subMatrix = np.full((height, width), '0', dtype=object)

    for (ex, ez), char in mappa_erebus.items():
        subMatrix[ez - min_z, ex - min_x] = char

    # 5. Invio
    s = subMatrix.shape
    s_bytes = struct.pack('2i', *s)
    
    flatMap = ','.join(subMatrix.flatten())

    sub_bytes = flatMap.encode('utf-8')
    a_bytes = s_bytes + sub_bytes

    if emitter:
        emitter.send(a_bytes)
        map_evaluate_request = struct.pack('c', b'M')
        emitter.send(map_evaluate_request)
        
        if d_mappatura: 
            print(f"[MAPPA] INVIATA E VALUTATA (Dimensioni matrice: {width}x{height})")


def mappa_black_hole(map):
    rx, rz = map.get_gps_pos()
    
    robot_yaw = map.get_yaw()
    offset_sensore = 0.09 
    buco_x = rx - offset_sensore * math.sin(robot_yaw)
    buco_z = rz - offset_sensore * math.cos(robot_yaw)
    
    gx, gz = map.gps_to_grid(buco_x, buco_z)
    
    # Padding
    pad_cells_r = int(0.04 / map.resolution) 
    pad_cells_c = int(0.04 / map.resolution) 
    
    if 0 <= gx < map.grid_size and 0 <= gz < map.grid_size:
        
        map.grid[gx, gz] = 3 
        
        # Genera il padding 
        for pr in range(-pad_cells_r, pad_cells_r + 1):
            for pc in range(-pad_cells_c, pad_cells_c + 1): 
                if True:#pr**2 + pc**2 <= pad_cells_c**2:           
                    nr = gx + pr
                    nc = gz + pc
                    if 0 <= nr < map.grid_size and 0 <= nc < map.grid_size:
                        if map.grid[nr, nc] != 2: 
                            map.grid[nr, nc] = 3

# ========= FUNZIONI DI MOVIMENTO ======

TARGET_WALL_DIST = 0.06  # Distanza desiderata dal muro destro in metri
KP = 100.0                # Costante Proporzionale per il wall-following

def verifica_vicolo_cieco(map_obj):

    rx, rz = map_obj.get_gps_pos()
    gx, gz = map_obj.gps_to_grid(rx, rz)
    
    #Raggio di visione
    check_radius = int(0.09 / map_obj.resolution) 
    
    celle_libere = 0
    for r in range(gx - check_radius, gx + check_radius + 1):
        for c in range(gz - check_radius, gz + check_radius + 1):
            if 0 <= r < map_obj.grid_size and 0 <= c < map_obj.grid_size:

                if map_obj.grid[r, c] == 0:
                    celle_libere += 1

    return celle_libere < 5  

watchdog_state = {
    'last_pos': None,
    'stuck_counter': 0
}

def incastrato(map_obj, time = 30):

    global watchdog_state
    
    STUCK_THRESHOLD = time     
    DIST_TOLERANCE = 0.008   # tolleranza
    
    curr_pos = map_obj.get_gps_pos()
    
    # Inizializzazione
    if watchdog_state['last_pos'] is None:
        watchdog_state['last_pos'] = curr_pos
        return False
        
    # Calcolo della distanza
    last_x, last_z = watchdog_state['last_pos']
    curr_x, curr_z = curr_pos
    dist = math.sqrt((curr_x - last_x)**2 + (curr_z - last_z)**2)
    
    if dist < DIST_TOLERANCE:
        watchdog_state['stuck_counter'] += 1
    else:
        watchdog_state['stuck_counter'] = 0
        watchdog_state['last_pos'] = curr_pos
        
    if watchdog_state['stuck_counter'] > STUCK_THRESHOLD:
        if d_movimento: print("[ANTI-INCASTRO] Esecuzione manovra verso",end=' ')
        

        watchdog_state['stuck_counter'] = 0
        watchdog_state['last_pos'] = map_obj.get_gps_pos()
        
        return True 
        
    return False 

def avanza():

    if d_movimento: print("\n--- [ESPLORAZIONE CONTINUA] Wall-Following ---")
    conta_step = 0
    while robot.step(timestep) != -1:

        if conta_step%40 == 0:
            tile = analizza_tile()
            if tile != '0': 
                x, z = map.get_lidar_pos()                
                tile_colorate.append((x, z, tile))

            map.add_walls()
            map.add_cells()
            map.draw_map()
            conta_step = 0
        conta_step += 1
        
        n_victim = visore.victim_detection()
        if n_victim:
            esegui_procedura_vittima(n_victim)

        if verifica_vicolo_cieco(map):
            if d_movimento: print("[TRIGGER BFS] Zona esplorata o chiusa")
            frena()
            return False 
        
        if incastrato(map):

            if d_movimento: print("sinistra")
            ruota_sinistra_mill(400)

            muovi_avanti_dist(0.01)
            continue
        # 3. Lettura dei sensori LIDAR
        range_image = lidar.getRangeImage()
        if not range_image:
            continue

        if is_black_hole():
            if d_movimento: print("[OSTACOLO]: Black Hole")
            mappa_black_hole(map) 
            muovi_indietro_dist(0.03)
            ruota_sinistra_mill(300)
            muovi_avanti_dist(0.0) 
            
        front_dist = get_front_distance()  
        right_dist = range_image[512 + 128]
        #print(f"front: {front_dist}\t right: {right_dist}")
        
        # Gestione inf
        if math.isinf(right_dist):
            right_dist = 1.0 

        robot_yaw = map.get_yaw()
        rx, rz = map.get_gps_pos()
        
        angolo_destra = robot_yaw - (math.pi / 2)
        
        OFFSET_AVANTI = 0.04  # cm in avanti rispetto al centro del robot
        OFFSET_DESTRA = 0.07  # cm a destra rispetto al centro del robot
        
        check_x = rx - OFFSET_AVANTI * math.sin(robot_yaw) - OFFSET_DESTRA * math.sin(angolo_destra)
        check_z = rz - OFFSET_AVANTI * math.cos(robot_yaw) - OFFSET_DESTRA * math.cos(angolo_destra)
        
        gx, gz = map.gps_to_grid(check_x, check_z)
        
        #5. Verifica ostacolo
        if 0 <= gx < map.grid_size and 0 <= gz < map.grid_size:
            if map.grid[gx, gz] == 2 or map.grid[gx, gz] == 3 or map.grid[gx, gz] == 1:
               
                if right_dist > 0.15:
                    right_dist = 0.06

        left_speed = MAX_VELOCITY * 0.8
        right_speed = MAX_VELOCITY * 0.8
        
        #Muro frontale
        if front_dist < 0.025: 
            if d_movimento: print("Muro frontale")
            while get_front_distance() < 0.05:
                ruota_sinistra_mill(25)
                continue
           
            
        else:
            errore = right_dist - TARGET_WALL_DIST
            
            correzione = KP * errore
            
            left_speed += correzione
            right_speed -= correzione
            
        left_speed = np.clip(left_speed, -MAX_VELOCITY, MAX_VELOCITY)
        right_speed = np.clip(right_speed, -MAX_VELOCITY, MAX_VELOCITY)
        #print(f"left speed: {left_speed}\tright speed: {right_speed}")
        left_motor.setVelocity(right_speed)
        right_motor.setVelocity(left_speed)
        
def bfs(map_obj, max_padding_steps=0):

    rx, rz = map_obj.get_gps_pos()
    start_r, start_c = map_obj.gps_to_grid(rx, rz)
    
    if not (0 <= start_r < map_obj.grid_size and 0 <= start_c < map_obj.grid_size):
        return None

    coda = deque([(start_r, start_c, [], 0)])
    
    
    visitate = {}
    visitate[(start_r, start_c)] = 0
    
    movimenti = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    
    while coda:
        r, c, percorso, passi_padding = coda.popleft()
        
        if map_obj.grid[r, c] == 0:
            return percorso + [(r, c)]
            
        for dr, dc in movimenti:
            nr, nc = r + dr, c + dc
            
            if 0 <= nr < map_obj.grid_size and 0 <= nc < map_obj.grid_size:
                valore_cella = map_obj.grid[nr, nc]
                
                if valore_cella == 2:
                    continue 
                
                if valore_cella == 3:
                    nuovi_passi = passi_padding + 1
                else:
                    nuovi_passi = 0 
                
                if nuovi_passi <= max_padding_steps:
                    
                    if (nr, nc) not in visitate or visitate[(nr, nc)] > nuovi_passi:
                        visitate[(nr, nc)] = nuovi_passi
                        coda.append((nr, nc, percorso + [(nr, nc)], nuovi_passi))
    
    # Se il robot rimane incastrato per colpa del paddinf
    if max_padding_steps < 5:
        res = bfs(map_obj, max_padding_steps= max_padding_steps+1)
        return res                   
    return None

def linea_libera(map_obj, r1, c1, r2, c2):
    #Algoritmo di Bresenham 
  
    r, c = r1, c1
    dr = abs(r2 - r1)
    dc = abs(c2 - c1)
    sr = 1 if r1 < r2 else -1
    sc = 1 if c1 < c2 else -1
    err = dr - dc

    while True:
        if map_obj.grid[r, c] == 2 or map_obj.grid[r, c] == 3:
            return False
            
        if r == r2 and c == c2:
            break
            
        e2 = 2 * err
        if e2 > -dc:
            err -= dc
            r += sr
        if e2 < dr:
            err += dr
            c += sc
            
    return True

def ottimizza_path(map_obj, percorso_bfs):

    if not percorso_bfs or len(percorso_bfs) <= 2:
        return percorso_bfs 
        
    percorso_smussato = [percorso_bfs[0]]
    corrente = 0
    
    while corrente < len(percorso_bfs) - 1:
        piu_lontano = corrente + 1
        
        
        for j in range(len(percorso_bfs) - 1, corrente, -1):
            if linea_libera(map_obj, percorso_bfs[corrente][0], percorso_bfs[corrente][1], percorso_bfs[j][0], percorso_bfs[j][1]):
                piu_lontano = j
                break 
                
        percorso_smussato.append(percorso_bfs[piu_lontano])
        corrente = piu_lontano
        
    return percorso_smussato

def naviga_verso(target_r, target_c):


    target_x = (target_r - map.origin) * map.resolution
    target_z = (target_c - map.origin) * map.resolution
    
    DISTANZA_ARRIVO = 0.02 
    map.grid[target_r][target_c] = 4

    if d_movimento: print(f"[BACKTRACKING] Navigazione verso: x={target_x:.2f}, z={target_z:.2f}")
    conta_step = 0

    while robot.step(timestep) != -1:
        map.add_walls()
        map.add_cells()
            

        n_victim = visore.victim_detection()
        if n_victim:
            esegui_procedura_vittima(n_victim)

        if incastrato(map, time = 25):
            muovi_indietro_dist(0.01)
           
            dist = lidar.getRangeImage()[512:1024]
            r = min(dist[1:128])
            l = min(dist[-128:-1])

            if l > r:
                if d_movimento: print("sinistra")
                ruota_sinistra_mill(100)
            else:
                if d_movimento: print("destra")
                ruota_destra_mill(100)

            return False
        rx, rz = map.get_gps_pos()
        robot_yaw = map.get_yaw()
        
        dist_x = target_x - rx
        dist_z = target_z - rz
        distanza_totale = math.sqrt(dist_x**2 + dist_z**2)
        
        if distanza_totale < DISTANZA_ARRIVO:
            if d_movimento: print("[BACKTRACKING] Posizione raggiunta")
            frena()
            break
            

        if is_black_hole():
            if d_movimento: print("[BACKTRACKING] Black Hole")
            mappa_black_hole(map)
            frena()
            muovi_indietro_dist(0.02)
            return False

       
        angolo_target = math.atan2(-dist_x, -dist_z)
        
        errore_angolo = normalizza_angolo(angolo_target - robot_yaw)
        
        if abs(errore_angolo) > 0.3: 
            left_speed = -MAX_VELOCITY * 0.6 if errore_angolo > 0 else MAX_VELOCITY * 0.6
            right_speed = MAX_VELOCITY * 0.6 if errore_angolo > 0 else -MAX_VELOCITY * 0.6
        else:
            velocita_base = MAX_VELOCITY * 0.9
            correzione = errore_angolo * 10.0 # KP angolare
            left_speed = velocita_base - correzione
            right_speed = velocita_base + correzione
            
        left_speed = np.clip(left_speed, -MAX_VELOCITY, MAX_VELOCITY)
        right_speed = np.clip(right_speed, -MAX_VELOCITY, MAX_VELOCITY)
        
        left_motor.setVelocity(right_speed)
        right_motor.setVelocity(left_speed)
    
    return True

# ============ LOOP PRINCIPALE ========

while robot.step(timestep) != -1:
    v = gps.getValues()
    if not np.isnan(v[0]): 
        start_x, start_z = v[0], v[2]; break

tile_colorate.append((start_x, start_z, '5'))
current_dir=0
s_x, s_z = map.get_gps_pos()
x, z = map.gps_to_grid(s_x, s_z)
if d_movimento: print("--- [START]: Scansione iniziale ---")

map.add_walls()
ruota_sinistra_mill(200)
map.add_walls()
ruota_sinistra_mill(200)
map.add_walls()
ruota_sinistra_mill(200)
map.add_walls()
gira_a_direzione((current_dir + 1) % 4)


frena()
p_now = gps.getValues()
exit = False
time = 500

while robot.step(timestep) != -1:

    message = struct.pack('c', 'G'.encode()) # message = 'G' for game information
    emitter.send(message) # send message

    if not avanza():
        map.draw_map()
        if d_movimento: print("[BACKTRACKING]")
        
        percorso_bfs = bfs(map)

        if percorso_bfs is None:
            if d_movimento: print("Ritorno a casa")
            exit = True
            map.grid[x][z] = 0
            percorso_bfs = bfs(map)

        path_finale = ottimizza_path(map, percorso_bfs)

        if d_movimento: print("[BFS] Percorso calcolato")

        for r, c in path_finale:
            if not naviga_verso(r, c):
                break

    if receiver.getQueueLength() > 0:
        receivedData = receiver.getBytes()
        tup = struct.unpack('c f i i', receivedData) 
        if tup[0].decode("utf-8") == 'G':
            #print(f'Game Score: {tup[1]}  Remaining simulated time: {tup[2]} Remaining real time: {tup[3]}')
            time = min(tup[2],tup[3])
            receiver.nextPacket() 
    
    if time < 20 or exit:
        invia_mappa_erebus()
        print("Fine")
        #map.save_map()
        emitter.send(bytes('E', "utf-8"))
        break