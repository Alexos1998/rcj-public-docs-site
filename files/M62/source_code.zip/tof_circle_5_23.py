import sensor, image, time, pyb
import uasyncio as asyncio
from machine import I2C, Pin
from vl53l4cd import VL53L4CD
from pupremote import PUPRemoteSensor

rl = pyb.LED(1)                       # 빨간 LED
gl = pyb.LED(2)                       # 초록 LED
bl = pyb.LED(3)                       # 파란 LED
tlp = Pin("P0", Pin.IN, Pin.PULL_UP)  # 왼쪽 터치 센서
trp = Pin("P1", Pin.IN, Pin.PULL_UP)  # 오른쪽 터치 센서


# RGB LED를 지정한 색으로 켜거나 끈다.
def led(r, g, b):
    if r:
        rl.on()
    else:
        rl.off()

    if g:
        gl.on()
    else:
        gl.off()

    if b:
        bl.on()
    else:
        bl.off()


# 왼쪽과 오른쪽 터치 센서의 눌림 상태를 반환한다.
def touch():
    tl = 1 if tlp.value() == 0 else 0
    tr = 1 if trp.value() == 0 else 0
    return tl, tr


# 터치 센서 상태에 따라 LED 색을 바꾼다.
def tled(tl, tr):
    if tl and tr:
        led(1, 0, 1)
    elif tl:
        led(1, 1, 0)
    elif tr:
        led(0, 1, 1)
    else:
        led(0, 0, 0)


# ===== 카메라 설정 =====
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QQVGA)
sensor.skip_frames(time=2000)

sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
sensor.set_auto_exposure(False, exposure_us=8000)

clk = time.clock()  # FPS 측정용 시계
#False , True
roi_on = False                # 관심 영역 표시 여부
roi = (30, 0, 100, 120)       # 원을 찾을 카메라 영역
box_on = False                # 찾은 물체 테두리 표시
center_on = False             # 찾은 물체 중심 표시
edge_on = False               # 색상 확인 지점 표시
print_on = False              # 감지 결과 출력 여부
print_n = 5                   # 결과 출력 프레임 주기
circle_debug_on = True        # 원 색상 구역 판별 상세 출력
log_on = True                 # SD 카드에 텍스트 로그 저장
log_dir = "/sd/mission"       # 로그 폴더
log_file = "mission_log.txt"  # 한 실행의 이벤트를 순서대로 모을 파일
log_count = 0                 # 저장한 로그 줄 수
suspect_last_key = ""         # 마지막 의심 후보 로그 종류
suspect_last_ms = 0           # 마지막 의심 후보 로그 시간
suspect_min_ms = 500          # 같은 의심 후보 최소 기록 간격(ms)
mission_kind = "none"         # 마지막 인식 종류
mission_score = 0             # 마지막 인식 점수
mission_name = "NONE"         # 마지막 인식 이름
mission_ms = 0                # 마지막 인식 시간
last_circle_zones = ""        # 마지막 원 색상 판별 결과
last_circle_detail = ""       # 마지막 원 색상 판별 상세 샘플
last_circle_box = ""          # 마지막 원 후보 위치

dot_size = 1                  # 표시 점 크기
zone_off = 2                  # 색상 확인 지점 간격
zone_rs = [0.1, 0.3, 0.5, 0.7, 0.9]  # 원 중심부터 색상 확인 비율
color_min = 30                # 원으로 판단할 최소 색상 픽셀 수

# 색상별 LAB 임계값: 검정, 빨강, 초록, 파랑, 노랑, 흰색
bk_th = (0, 35, -20, 20, -20, 20)
rd_th = (20, 80, 15, 60, 0, 40)
gn_th = (15, 80, -70, -20, -10, 40)
bu_th = (40, 80, -30, 30, -70, -15)
yl_th = (40, 100, -40, 20, 50, 100)
wh_th = (70, 100, -20, 20, -20, 20)

target_ths = [
    bk_th,
    rd_th,
    gn_th,
    bu_th,
    yl_th
]

color_ths = [
    rd_th,
    gn_th,
    bu_th,
    yl_th
]

color_score = {
    "BLACK": -2,
    "RED": -1,
    "YELLOW": 0,
    "GREEN": 1,
    "BLUE": 2
}

# ===== 글자 인식 설정 =====
bin_th = (200, 255)          # 글자 이진화 임계값
text_roi = (30, 0, 100, 120) # 글자를 찾을 화면 영역
center_tol = 45              # 화면 중앙에서 허용할 글자 위치 차이
center_y_tol = 60            # 화면 세로 중앙에서 허용할 글자 위치 차이
mean_k = 5                   # 이진화 평균 필터 크기
mean_off = 20                # 이진화 보정값
cell_th = 0.24               # 3x3 칸이 채워졌다고 볼 비율
balance_band = 0.35          # 글자 가장자리 픽셀 균형 허용 폭
vote_n = 5                   # 글자 안정화에 사용할 최근 결과 수
vote_min = 1                 # 같은 글자가 이 횟수 이상 나오면 인정
hist = []                    # 최근 글자 판별 기록
rot_ang = None               # 직전 글자 회전 보정 각도
rot_step = 8                 # 프레임 사이 최대 회전 변화량
rot_alpha = 0.35             # 회전각 부드럽게 섞는 비율

text_min_area = 750          # 너무 작은 글자 후보 제거
text_min_pixels = 450        # 너무 작은 글자 검정 픽셀 제거
text_min_w = 24              # 너무 좁은 글자 후보 제거
text_min_h = 24              # 너무 낮은 글자 후보 제거
text_aspect_min = 0.82       # 글자 후보 가로/세로 최소 비율
text_aspect_max = 1.22       # 글자 후보 가로/세로 최대 비율
text_fill_min = 0.10         # 글자 후보 검정 픽셀 최소 채움
text_fill_max = 0.68         # 글자 후보 검정 픽셀 최대 채움

circle_min_color_pixels = 600 # 원 후보 안의 최소 색상 픽셀 수
circle_min_color_ratio = 0.08 # 원 후보 면적 중 색상이 차지해야 하는 최소 비율
circle_full_roi_color_ratio = 0.12 # ROI 전체처럼 큰 후보가 원으로 인정될 최소 색상 비율
circle_color_blob_min_pixels = 40 # 색상 노이즈를 버리기 위한 최소 색상 덩어리 크기
circle_color_blob_min_fill = 0.35 # 색상 덩어리 내부가 충분히 채워졌는지 확인
circle_min_w = 30            # 너무 좁은 원 후보 제거
circle_min_h = 30            # 너무 낮은 원 후보 제거
circle_aspect_min = 0.65     # 원 후보 가로/세로 최소 비율
circle_aspect_max = 1.45     # 원 후보 가로/세로 최대 비율
circle_min_center_y = 25     # 화면 너무 위쪽의 원 후보 제거
mission_center_x = 80        # 미션을 인정할 화면 중심 x
mission_center_y = 60        # 미션을 인정할 화면 중심 y
mission_center_tol_x = 30    # 중앙 인정 좌우 범위
mission_center_tol_y = 45    # 중앙 인정 상하 범위

text_score = {
    "OMEGA": 0,
    "PSI": 1,
    "PHI": 2
}


# SD 카드 로그 폴더를 준비한다.
def log_prepare():
    global log_dir

    try:
        import os
        for d in ("/sd/mission", "/sd", "mission", "/"):
            try:
                if d not in ("/sd", "/"):
                    try:
                        os.mkdir(d)
                    except OSError:
                        pass

                log_dir = d
                f = open(log_path(), "a")
                f.write("run_start\n")
                f.close()
                print("log dir:", log_dir)
                return True
            except Exception:
                pass
    except Exception as e:
        print("log prepare error:", type(e), e)

    print("log prepare failed")
    return False


def log_path():
    return "%s/%s" % (log_dir, log_file)


log_ready = log_prepare() if log_on else False


def append_log(line):
    global log_count

    if not log_on or not log_ready:
        return
    try:
        f = open(log_path(), "a")
        f.write(line)
        if not line.endswith("\n"):
            f.write("\n")
        f.close()
        log_count += 1
    except Exception as e:
        print("log write error:", type(e), e)


def tof_text():
    return "%d,%d,%d" % (t[0], t[1], t[2])


def event_base(event, kind, score, name):
    return (
        "event=%s frame=%d kind=%s score=%d name=%s tof=%s ms=%d"
        % (event, st["frame"], kind, int(score), name, tof_text(), st["ms"])
    )


def remember_mission(kind, score, name):
    global mission_kind, mission_score, mission_name, mission_ms

    mission_kind = kind
    mission_score = int(score)
    mission_name = name
    mission_ms = time.ticks_ms()

    line = event_base("detect", kind, score, name)
    if kind == "circle":
        line += " circle_box=%s circle_zones=%s circle_detail=%s" % (
            last_circle_box,
            last_circle_zones,
            last_circle_detail,
        )
    append_log(line)


def log_drop_cmd(v, name, q):
    age = time.ticks_diff(time.ticks_ms(), mission_ms)
    line = (
        "%s cmd=%d q=%d mission_kind=%s mission_score=%d mission_name=%s mission_age_ms=%d"
        % (event_base("cmd", "drop", v, name), int(v), q, mission_kind, int(mission_score), mission_name, age)
    )
    append_log(line)


def log_suspect(kind, reason, b=None, score=0, name="NONE"):
    global suspect_last_key, suspect_last_ms

    if not log_on or not log_ready:
        return
    now = time.ticks_ms()
    if b:
        box = "%d,%d,%d,%d" % (b.x(), b.y(), b.w(), b.h())
    else:
        box = "none"

    key = "%s:%s:%s:%s" % (kind, reason, name, box)
    if key == suspect_last_key and time.ticks_diff(now, suspect_last_ms) < suspect_min_ms:
        return

    suspect_last_key = key
    suspect_last_ms = now
    append_log("%s reason=%s box=%s" % (event_base("suspect", kind, score, name), reason, box))

# ===== ToF 거리 센서 설정 =====
ma = 0x70                         # I2C 멀티플렉서 주소
chs = [0, 1, 2]                   # 왼쪽, 정면, 오른쪽 채널
i2c = I2C(4, freq=400000)         # 거리 센서 통신
ss = []                           # 연결된 ToF 센서 목록
tof_min = 10                      # 최소 센서 읽기 간격(ms)
tof_max = 80                      # 최대 센서 읽기 간격(ms)

# 사용할 멀티플렉서 채널을 선택한다.
def mx(ch):
    i2c.writeto(ma, bytes([1 << ch]))
    time.sleep_ms(2)

# 모든 멀티플렉서 채널을 끈다.
def mx_off():
    try:
        i2c.writeto(ma, b"\x00")
        time.sleep_ms(20)
    except Exception as e:
        print("mux off error:", type(e), e)


# 세 ToF 센서가 모두 연결될 때까지 초기화를 반복한다.
def tof_init():
    global ss

    while True:
        ss = []
        led(0, 0, 1)
        print("tof check...")

        try:
            addrs = i2c.scan()
            print("scan:", addrs)
            if ma not in addrs:
                print("mux not found")
                raise OSError("mux")

            for c in chs:
                print("ch", c)
                mx(c)

                if 0x29 not in i2c.scan():
                    print("tof not found ch", c)
                    raise OSError("tof ch%d" % c)

                s = VL53L4CD(i2c)
                s.inter_measurement = 0
                s.timing_budget = 20
                s.start_ranging()
                ss.append(s)
                print("tof ok ch", c)

            led(0, 1, 0)
            print("tof all ok")
            time.sleep_ms(500)
            led(0, 0, 0)
            return

        except Exception as e:
            print("tof check fail:", type(e), e)
            mx_off()
            led(1, 0, 0)
            time.sleep_ms(300)
            led(0, 0, 0)
            time.sleep_ms(300)


tof_init()

p = PUPRemoteSensor()  # 허브 통신 객체
# 허브 전송 순서: 원, 원점수, 글자, 글자번호, 왼쪽 거리, 정면 거리, 오른쪽 거리, 왼쪽 터치, 오른쪽 터치
p.add_channel("vals", to_hub_fmt="bbbbBBBbb")

# ===== 미션 키트 배출 모터 설정 =====
DROP_NONE = 0
DROP_LEFT = 1
DROP_RIGHT = 2
DROP_Q_MAX = 4

servo_pin = "P9"
servo_freq = 50
stop_us = 1500

# 빠른 기준값 백업:
# right: 1000/2000, 230/238ms
# left: 2000/1000, 245/238ms
right_drop_us = 1200
right_return_us = 1800
left_drop_us = 1800
left_return_us = 1200
right_drop_ms = 382
right_return_ms = 389
left_drop_ms = 402
left_return_ms = 399
drop_stop_ms = 120

drop_q = []
drop_busy = False
servo_tim = pyb.Timer(4, freq=servo_freq)
servo_ch = servo_tim.channel(3, pyb.Timer.PWM, pin=pyb.Pin(servo_pin))


def servo_us(us):
    ticks = int((us * (servo_tim.period() + 1)) / 20000)
    servo_ch.pulse_width(ticks)


def servo_off():
    servo_ch.pulse_width(0)


async def drop_stop(ms=drop_stop_ms):
    servo_us(stop_us)
    await asyncio.sleep_ms(ms)
    servo_off()


async def drop_motion(drop_us, return_us, drop_ms, return_ms, name):
    global drop_busy

    drop_busy = True
    print(name, "start")
    led(1, 0, 0)
    servo_us(drop_us)
    await asyncio.sleep_ms(drop_ms)

    led(0, 1, 0)
    await drop_stop()

    led(0, 0, 1)
    servo_us(return_us)
    await asyncio.sleep_ms(return_ms)

    led(0, 1, 0)
    await drop_stop()
    led(0, 0, 0)
    drop_busy = False
    print(name, "done")


async def drop_left():
    await drop_motion(
        right_drop_us,
        right_return_us,
        right_drop_ms,
        right_return_ms,
        "DROP LEFT",
    )


async def drop_right():
    await drop_motion(
        left_drop_us,
        left_return_us,
        left_drop_ms,
        left_return_ms,
        "DROP RIGHT",
    )


def cmd(v):
    v = int(v)
    name = "none"
    if v == DROP_NONE or v == DROP_LEFT or v == DROP_RIGHT:
        if v == DROP_LEFT:
            name = "left"
        elif v == DROP_RIGHT:
            name = "right"
        else:
            name = "none"
    if v == DROP_LEFT or v == DROP_RIGHT:
        if len(drop_q) >= DROP_Q_MAX:
            drop_q.pop(0)
        drop_q.append(v)
        print("drop cmd queued", v, "q", len(drop_q))
    if v == DROP_NONE or v == DROP_LEFT or v == DROP_RIGHT:
        log_drop_cmd(v, name, len(drop_q))
    return len(drop_q)


p.add_command("cmd", to_hub_fmt="b", from_hub_fmt="b")

# 지정한 ToF 센서 하나의 거리, 읽는 시간, 새 값 여부, 오류 여부를 반환한다.
def rd1(i):
    t0 = time.ticks_ms()

    try:
        mx(chs[i])

        if ss[i].data_ready:
            cm = ss[i].get_distance()   # 이 라이브러리는 cm 반환
            ss[i].clear_interrupt()
            cm = int(cm)
            fresh = True
        else:
            cm = t[i]   # 새 값 준비 안됐으면 이전 값 유지
            fresh = False
        bad = False
    except Exception as e:
        print("tof read fail ch%d:" % chs[i], type(e), e)
        cm = -1
        fresh = False
        bad = True

    dt = time.ticks_diff(time.ticks_ms(), t0)
    return cm, dt, fresh, bad

t = [-1, -1, -1]        # 왼쪽, 정면, 오른쪽 거리값
ti = 0                   # 다음에 읽을 ToF 센서 번호
tms = tof_min            # 현재 ToF 읽기 간격
tt = time.ticks_ms()     # 마지막 ToF 읽기 시간
ta = [tt, tt, tt]        # 각 센서가 마지막으로 새 값을 보낸 시간
te = [0, 0, 0]           # 각 센서의 연속 읽기 오류 횟수

# ===== 카메라 처리 함수 =====

# 거리값을 0~255 범위로 정리한다. 오류값은 0으로 보낸다.
def u8(v):
    if v is None or v < 0:
        return 0
    if v > 255:
        return 255
    return int(v)

# 영상에 확인용 점을 그린다.
def dot(img, x, y, color):
    if dot_size == 1:
        img.draw_rectangle((x, y, 1, 1), color=color, fill=True)
    else:
        img.draw_rectangle((x, y, 2, 2), color=color, fill=True)

# 지정한 픽셀의 LAB 색상값을 반환한다.
def lab(img, x, y):
    x = int(x)
    y = int(y)
    if x < 0 or y < 0 or x >= img.width() or y >= img.height():
        return None
    st = img.get_statistics(roi=(x, y, 1, 1))
    return (st.l_mean(), st.a_mean(), st.b_mean())

# LAB 색상값이 임계값 범위 안인지 확인한다.
def in_th(l, a, b, th):
    l0, l1, a0, a1, b0, b1 = th
    return (l0 <= l <= l1) and (a0 <= a <= a1) and (b0 <= b <= b1)

# 지정한 픽셀이 흰색인지 확인한다.
def is_white(img, x, y):
    v = lab(img, x, y)
    if v is None:
        return False
    l, a, b = v
    return in_th(l, a, b, wh_th)

# LAB 색상값을 색상 이름으로 분류한다.
def color(l, a, b):
    if in_th(l, a, b, bk_th):
        return "BLACK"
    if in_th(l, a, b, bu_th):
        return "BLUE"
    if in_th(l, a, b, yl_th):
        return "YELLOW"
    if in_th(l, a, b, rd_th):
        return "RED"
    if in_th(l, a, b, gn_th):
        return "GREEN"
    if in_th(l, a, b, wh_th):
        return "WHITE"
    return "UNKNOWN"

# 가장 많이 감지된 유효 색상을 반환한다.
def maj(colors):
    cnt = {}
    for c in colors:
        if c in ("UNKNOWN", "WHITE"):
            continue
        cnt[c] = cnt.get(c, 0) + 1

    if not cnt:
        return "UNKNOWN"

    best = None
    bn = 0
    bs = 999
    for name, n in cnt.items():
        sc = color_score.get(name, 0)
        if n > bn or (n == bn and sc < bs):
            bn = n
            bs = sc
            best = name
    return best

# 색상 이름을 점수로 바꾼다.
def score(name):
    return color_score.get(name, 0)

# 모든 구역의 색상 점수를 합산한다.
def total(zones):
    val = 0
    for z in zones:
        val += score(z["color"])
    return val

# 글자 인식용 영상으로 바꾼다.
def prep_text(img):
    img.to_grayscale()
    img.gaussian(2)
    img.mean(mean_k, threshold=True, offset=mean_off, invert=True)

# 90도 기준으로 회전각을 정리한다.
def norm90(a):
    while a > 90:
        a -= 180
    while a <= -90:
        a += 180
    return a

# 90도 기준 두 각도의 차이를 구한다.
def diff90(a, b):
    d = a - b
    while d > 90:
        d -= 180
    while d < -90:
        d += 180
    return d

# 글자 판별 결과를 최근 기록으로 안정화한다.
def vote_text(name):
    global hist

    hist.append(name)
    if len(hist) > vote_n:
        hist.pop(0)

    best = "NONE"
    bn = 0
    for n in ("PHI", "PSI", "OMEGA"):
        c = 0
        for x in hist:
            if x == n:
                c += 1
        if c > bn:
            best = n
            bn = c

    if bn >= vote_min:
        return best
    return "NONE"

# 글자 후보가 너무 작거나 이상한 모양인지 확인한다.
def bad_text_blob(b, inner=False):
    if inner:
        if b.area() < 40:
            return True
        if b.w() < 6 or b.h() < 6:
            return True
        proportion = b.w() / b.h()
        if proportion < 0.25 or proportion > 3.0:
            return True
        fill = b.pixels() / b.area()
        if fill < 0.03 or fill > 0.95:
            return True
        return False

    if b.area() < text_min_area:
        return True
    if b.pixels() < text_min_pixels:
        return True
    if b.w() < text_min_w or b.h() < text_min_h:
        return True
    if b.w() > 120 or b.h() > 120:
        return True
    proportion = b.w() / b.h()
    if proportion < text_aspect_min or proportion > text_aspect_max:
        return True
    fill = b.pixels() / b.area()
    if fill < text_fill_min or fill > text_fill_max:
        return True
    return False


def edge_sum(img, roi):
    sm = 0
    for b in img.find_blobs([bin_th], roi=roi):
        sm += b.pixels()
    return sm


def balanced_text(img, b):
    w = b.w()
    h = b.h()
    if w < 15 or h < 15 or b.pixels() <= 0:
        return False

    top_h = max(1, h // 5)
    bot_y = max(0, h - top_h)
    left_w = max(1, w // 5)
    right_x = max(0, w - left_w)

    up = edge_sum(img, (0, 0, w, top_h))
    down = edge_sum(img, (0, bot_y, w, top_h))
    left = edge_sum(img, (0, 0, left_w, h))
    right = edge_sum(img, (right_x, 0, left_w, h))

    if up <= 0 or down <= 0 or left <= 0 or right <= 0:
        return False

    ud = down / up
    lr = left / right
    if ud < balance_band or ud > (1.0 / balance_band):
        return False
    if lr < balance_band or lr > (1.0 / balance_band):
        return False

    total = b.pixels()
    for v in (up, down, left, right):
        r = v / total
        if r < 0.1 or r > 0.75:
            return False

    return True


def in_mission_center(x, y):
    if abs(int(x) - mission_center_x) > mission_center_tol_x:
        return False
    if abs(int(y) - mission_center_y) > mission_center_tol_y:
        return False
    return True

# 화면 중앙 근처의 가장 큰 글자 후보를 찾는다.
def find_text_blob(img):
    blobs = img.find_blobs(
        [bin_th],
        roi=text_roi,
        x_stride=4,
        y_stride=4,
        area_threshold=text_min_area,
        pixels_threshold=text_min_pixels,
        merge=True
    )

    cx = img.width() // 2
    cy = img.height() // 2
    best = None
    ba = -1

    for b in blobs:
        if bad_text_blob(b):
            continue
        if not in_mission_center(b.cx(), b.cy()):
            continue
        if b.area() > ba:
            best = b
            ba = b.area()

    return best

# 글자 후보를 3x3 패턴으로 바꾼다.
def text_pattern(img, b):
    global rot_ang

    x = max(0, b.x() - 2)
    y = max(0, b.y() - 2)
    w = min(img.width() - x, b.w() + 4)
    h = min(img.height() - y, b.h() + 4)

    if w < 9 or h < 9:
        return None

    roi_img = img.crop(roi=(x, y, w, h))

    ths = []
    for ln in roi_img.find_lines(threshold=3500, theta_margin=20, rho_margin=20):
        if ln.length() > 35:
            ths.append(ln.theta())

    if len(ths) >= 2:
        ths.sort()
        a = norm90(ths[len(ths) // 2])
        if rot_ang is not None:
            d = diff90(a, rot_ang)
            if d > rot_step:
                a = rot_ang + rot_step
            elif d < -rot_step:
                a = rot_ang - rot_step
            a = norm90((rot_ang * (1.0 - rot_alpha)) + (a * rot_alpha))
        rot_ang = norm90(a)
        try:
            roi_img.rotation_corr(0, 0, -a)
        except Exception:
            pass

    blobs = roi_img.find_blobs([bin_th], merge=True)
    tb = None
    ta = -1

    for ib in blobs:
        if bad_text_blob(ib, True):
            continue
        if ib.area() > ta:
            tb = ib
            ta = ib.area()

    if tb is None:
        return None

    rx = tb.x()
    ry = tb.y()
    rw = tb.w() - (tb.w() % 3)
    rh = tb.h() - (tb.h() % 3)

    if rw < 15 or rh < 15:
        return None

    ch = roi_img.crop(roi=(rx, ry, rw, rh))
    if not balanced_text(ch, tb):
        return None

    dw = rw // 3
    dh = rh // 3

    if dw < 4 or dh < 4:
        return None

    pat = []
    for rr in range(3):
        for cc in range(3):
            cell = (cc * dw, rr * dh, dw, dh)
            bs = ch.find_blobs([bin_th], roi=cell)
            sm = 0
            for bl in bs:
                sm += bl.pixels()
            pat.append(1 if sm / (dw * dh) > cell_th else 0)

    return pat

# 3x3 패턴을 오메가/싸이/파이로 분류한다.
def text_name(pat):
    total = 0
    for v in pat:
        total += v

    if total < 4:
        return "NONE"

    center = pat[4] == 1
    top = pat[0] + pat[1] + pat[2]
    mid = pat[3] + pat[4] + pat[5]
    left = pat[0] + pat[3] + pat[6]
    right = pat[2] + pat[5] + pat[8]

    if center:
        if total >= 8:
            return "PHI"
        if total >= 5:
            return "PSI"
        return "NONE"

    if top >= 2 and left >= 2 and right >= 2 and pat[4] == 0:
        return "OMEGA"
    if mid >= 2 and left >= 2 and right >= 2 and pat[4] == 0:
        return "OMEGA"

    return "NONE"

# 영상에서 글자를 찾고 글자 발견 여부와 글자 번호를 반환한다.
def read_text(img):
    bin_img = img.copy()
    prep_text(bin_img)

    b = find_text_blob(bin_img)
    if b is None:
        set_dbg(0, 1)
        vote_text("NONE")
        return 0, -1, "NONE"

    set_dbg(3, 0, b)
    if box_on:
        img.draw_rectangle(b.rect(), color=(255, 180, 0))

    pat = text_pattern(bin_img, b)
    if pat is None:
        set_dbg(4, 2, b)
        vote_text("NONE")
        log_suspect("text", "pattern", b)
        return 0, -1, "NONE"

    pc = pat_code(pat)
    raw_name = text_name(pat)
    name = vote_text(raw_name)
    if name == "NONE":
        set_dbg(5, 3, b, pc)
        log_suspect("text", "vote", b, text_score.get(raw_name, -1), raw_name)
        return 0, -1, "NONE"

    set_dbg(6, text_score.get(name, 0), b, pc)
    if box_on:
        img.draw_rectangle(b.rect(), color=(0, 255, 255), thickness=2)

    return 1, text_score.get(name, -1), name

# 원 후보가 필터를 통과하는지 확인한다.
def circle_filter(img, b):
    if b.w() < circle_min_w or b.h() < circle_min_h:
        return False, "small", 0
    if b.cy() < circle_min_center_y:
        return False, "too_high", 0
    rt = b.w() / b.h() if b.h() != 0 else 999
    if rt < circle_aspect_min or rt > circle_aspect_max:
        return False, "aspect", 0
    if not in_mission_center(b.cx(), b.cy()):
        return False, "off_center", 0

    colored, color_pix = is_circle(img, b.rect())
    area = b.area() if b.area() > 0 else 1
    color_ratio = color_pix / area
    if not colored:
        return False, "no_color", color_pix
    if color_pix < circle_min_color_pixels or color_ratio < circle_min_color_ratio:
        return False, "color_pixels", color_pix

    rx, ry, rw, rh = roi
    if b.w() >= rw - 2 and b.h() >= rh - 2 and color_ratio < circle_full_roi_color_ratio:
        return False, "color_pixels", color_pix

    return True, "ok", color_pix


# 영상에서 원 후보 물체 중 가장 큰 것을 찾는다.
def find_circle_blob(img):
    blobs = img.find_blobs(
        target_ths,
        roi=roi,
        pixels_threshold=80,
        area_threshold=80,
        merge=True,
        margin=8
    )

    best = None
    bp = -1
    suspect = None
    suspect_reason = ""
    suspect_pix = -1

    for b in blobs:
        ok, reason, color_pix = circle_filter(img, b)
        if ok:
            if color_pix > bp:
                bp = color_pix
                best = b
        elif reason not in ("no_color", "color_pixels"):
            if color_pix > suspect_pix:
                suspect_pix = color_pix
                suspect = b
                suspect_reason = reason

    if best is None and suspect is not None:
        log_suspect("circle", suspect_reason, suspect)

    return best

# 후보 영역에 색상 픽셀이 충분한지 확인한다.
def is_circle(img, rect):
    bs = img.find_blobs(
        color_ths,
        roi=rect,
        pixels_threshold=10,
        area_threshold=10,
        merge=True,
        margin=2
    )

    pix = 0
    for cb in bs:
        fill = cb.pixels() / cb.area() if cb.area() > 0 else 0
        if cb.pixels() < circle_color_blob_min_pixels:
            continue
        if fill < circle_color_blob_min_fill:
            continue
        pix += cb.pixels()

    return pix >= color_min, pix

# 중심에서 지정 방향으로 이동하며 원의 바깥쪽 경계를 찾는다.
def find_edge(img, cx, cy, dx, dy, max_step=80):
    prev = None

    for step in range(1, max_step + 1):
        x = int(cx + dx * step)
        y = int(cy + dy * step)

        if x < 0 or y < 0 or x >= img.width() or y >= img.height():
            break

        if is_white(img, x, y):
            if prev is not None:
                px, py = prev
                return (px, py, step - 1)
            else:
                return (x, y, step)

        prev = (x, y)

    return None

# 원 중심을 기준으로 상하좌우 경계를 찾는다.
def find_edges(img, cx, cy):
    dirs = {
        "R": (1, 0),
        "L": (-1, 0),
        "D": (0, 1),
        "U": (0, -1),
    }

    out = {}
    for name, (dx, dy) in dirs.items():
        out[name] = find_edge(img, cx, cy, dx, dy, max_step=80)
    return out


# 원 후보 박스를 기준으로 안정적인 반지름을 만든다.
def find_box_edges(b, cx, cy):
    r = max(1, max(b.w(), b.h()) // 2)

    return {
        "R": (cx + r, cy, r),
        "L": (cx - r, cy, r),
        "D": (cx, cy + r, r),
        "U": (cx, cy - r, r),
    }

# 원의 한 구역 가운데 반지름에서 16방향 색상을 읽고 대표 색상을 반환한다.
def read_zone(img, cx, cy, edges, ratio, off=2):
    cs = []
    rs = []

    for key in ("R", "L", "D", "U"):
        ed = edges.get(key)
        if ed is not None:
            _, _, r = ed
            rs.append(r)

    if not rs:
        return "OUT", cs

    rr = int(min(rs) * ratio)
    if rr < 1:
        rr = 1

    dirs = (
        (1000, 0),
        (924, 383),
        (707, 707),
        (383, 924),
        (0, 1000),
        (-383, 924),
        (-707, 707),
        (-924, 383),
        (-1000, 0),
        (-924, -383),
        (-707, -707),
        (-383, -924),
        (0, -1000),
        (383, -924),
        (707, -707),
        (924, -383),
    )

    for dx, dy in dirs:
        sx = cx + int(rr * dx / 1000)
        sy = cy + int(rr * dy / 1000)

        v = lab(img, sx, sy)
        if v is None:
            continue

        l, a, b = v
        name = color(l, a, b)
        cs.append(name)

        if edge_on:
            dot(img, sx, sy, (255, 255, 0))

    name = maj(cs) if cs else "OUT"
    return name, cs

# 원의 모든 비율 구역에서 대표 색상을 읽는다.
def read_zones(img, cx, cy, edges):
    zones = []

    for zr in zone_rs:
        name, samples = read_zone(img, cx, cy, edges, zr, off=zone_off)
        zones.append({
            "ratio": zr,
            "color": name,
            "samples": samples
        })

    return zones


def zones_text(zones):
    out = []
    for z in zones:
        out.append("%s:%s" % (str(z["ratio"]), z["color"]))
    return ",".join(out)


def zones_debug_text(zones):
    out = []
    short = {
        "BLACK": "BK",
        "RED": "R",
        "YELLOW": "Y",
        "GREEN": "G",
        "BLUE": "BU",
        "WHITE": "W",
        "UNKNOWN": "U",
    }

    for z in zones:
        cnt = {}
        for name in z["samples"]:
            cnt[name] = cnt.get(name, 0) + 1

        parts = []
        for name in ("BLACK", "RED", "YELLOW", "GREEN", "BLUE", "WHITE", "UNKNOWN"):
            n = cnt.get(name, 0)
            if n:
                parts.append("%s%d" % (short[name], n))

        out.append("%s:%s/%s" % (str(z["ratio"]), z["color"], ",".join(parts)))
    return " | ".join(out)

# 카메라와 전송 작업이 함께 사용하는 현재 상태
st = {
    "frame": 0,
    "circle": 0,
    "score": 0,
    "text": 0,
    "tscore": -1,
    "ms": 0,
}

dbg = {
    "frame": 0,
    "stage": 0,
    "reason": 0,
    "x": 0,
    "y": 0,
    "w": 0,
    "h": 0,
    "pat": 0,
}


def u8dbg(v):
    v = int(v)
    if v < 0:
        return 0
    if v > 255:
        return 255
    return v


def set_dbg(stage, reason=0, b=None, pat=0):
    dbg["frame"] = st["frame"] & 255
    dbg["stage"] = u8dbg(stage)
    dbg["reason"] = u8dbg(reason)
    dbg["pat"] = u8dbg(pat)
    if b:
        dbg["x"] = u8dbg(b.x())
        dbg["y"] = u8dbg(b.y())
        dbg["w"] = u8dbg(b.w())
        dbg["h"] = u8dbg(b.h())
    else:
        dbg["x"] = 0
        dbg["y"] = 0
        dbg["w"] = 0
        dbg["h"] = 0


def pat_code(pat):
    code = 0
    if pat is None:
        return 0
    for i, v in enumerate(pat):
        if v:
            code |= (1 << i)
    return code & 255

# 카메라 영상을 반복해서 분석하고 원의 점수를 계산한다.
async def cam_task():
    global last_circle_zones, last_circle_detail, last_circle_box

    while True:
        if drop_busy:
            await asyncio.sleep_ms(20)
            continue

        start = time.ticks_ms()
        clk.tick()

        img = sensor.snapshot()
        img.lens_corr(1.8)
        st["frame"] += 1

        if roi_on:
            img.draw_rectangle(roi, color=(120, 120, 120))

        val = 0
        found = 0
        tfound = 0
        tscore = -1
        tname = "NONE"
        cx = 0
        cy = 0
        last_circle_zones = ""
        last_circle_detail = ""
        last_circle_box = ""

        b = find_circle_blob(img)
        if b:
            cx = b.x() + (b.w() // 2)
            cy = b.y() + (b.h() // 2)
            set_dbg(1, 0, b)

            if box_on:
                img.draw_rectangle(b.rect(), color=(255, 0, 0))

            if center_on:
                dot(img, cx, cy, (0, 255, 0))

            found = 1
            try:
                edges = find_box_edges(b, cx, cy)
                zones = read_zones(img, cx, cy, edges)
                last_circle_zones = zones_text(zones)
                last_circle_detail = zones_debug_text(zones)
                last_circle_box = "%d,%d,%d,%d center=%d,%d r=%d" % (b.x(), b.y(), b.w(), b.h(), cx, cy, edges["R"][2])
                val = total(zones)
                set_dbg(2, val + 128, b)
                if circle_debug_on and (st["frame"] % print_n == 0):
                    print(
                        "circle detail score=%d box=(%d,%d,%d,%d) center=(%d,%d) r=%d zones=%s"
                        % (
                            val,
                            b.x(),
                            b.y(),
                            b.w(),
                            b.h(),
                            cx,
                            cy,
                            edges["R"][2],
                            zones_debug_text(zones)
                        )
                    )
                if box_on:
                    img.draw_rectangle(b.rect(), color=(255, 0, 0))
                    img.draw_cross(cx, cy, color=(0, 255, 0), size=2)
                remember_mission("circle", val, "CIRCLE")
            except Exception as e:
                print("circle read error:", e)
                set_dbg(1, 9, b)
                val = 0

        if not found:
            try:
                tfound, tscore, tname = read_text(img)
                if tfound:
                    remember_mission("text", tscore, tname)
            except Exception as e:
                print("text read error:", e)
                tfound = 0
                tscore = -1
                tname = "NONE"

        st["circle"] = found
        st["score"] = val
        st["text"] = tfound
        st["tscore"] = tscore
        st["ms"] = time.ticks_diff(time.ticks_ms(), start)

        if print_on and (st["frame"] % print_n == 0):
            tl, tr = touch()
            print(
                "circle=%d score=%d text=%d tscore=%d name=%s tof=(%d,%d,%d) touch=(%d,%d) fps=%.1f ms=%d"
                % (
                    st["circle"],
                    st["score"],
                    st["text"],
                    st["tscore"],
                    tname,
                    t[0],
                    t[1],
                    t[2],
                    tl,
                    tr,
                    clk.fps(),
                    st["ms"]
                )
            )

        await asyncio.sleep_ms(0)

# 세 ToF 센서를 순서대로 읽고 적절한 읽기 간격을 유지한다.
async def tof_task():
    global ti, tt, tms, ta, te

    while True:
        try:
            now = time.ticks_ms()
            if time.ticks_diff(now, tt) >= tms:
                i = ti
                v, dt, fresh, bad = rd1(i)
                t[i] = v

                if fresh:
                    ta[i] = now
                    te[i] = 0
                elif bad:
                    te[i] += 1

                stale = time.ticks_diff(now, ta[i]) > 1000
                if te[i] >= 2 or stale:
                    print("tof recover ch%d err=%d stale=%d" % (chs[i], te[i], stale))
                    t[0] = -1
                    t[1] = -1
                    t[2] = -1
                    mx_off()
                    tof_init()
                    now = time.ticks_ms()
                    ti = 0
                    tt = now
                    tms = tof_min
                    ta = [now, now, now]
                    te = [0, 0, 0]
                    print("tof recovered")
                    continue

                ti = (i + 1) % 3
                tt = now

                need = dt + 2
                if need > tms:
                    tms = need
                elif tms > tof_min and need + 4 < tms:
                    tms -= 1

                if tms < tof_min:
                    tms = tof_min
                if tms > tof_max:
                    tms = tof_max

        # 예상하지 못한 오류가 발생해도 ToF 작업이 종료되지 않게 한다.
        except Exception as e:
            print("tof task fail:", type(e), e)
            t[0] = -1
            t[1] = -1
            t[2] = -1
            mx_off()
            tof_init()
            now = time.ticks_ms()
            ti = 0
            tt = now
            tms = tof_min
            ta = [now, now, now]
            te = [0, 0, 0]
            print("tof task recovered")

        await asyncio.sleep_ms(10)

# 센서값을 허브로 보내고 터치 상태를 LED로 표시한다.
async def tx_task():
    lt = 0
    ll = -1
    lr = -1

    while True:
        tl, tr = touch()
        p.update_channel(
            "vals",
            int(st["circle"]),
            int(st["score"]),
            int(st["text"]),
            int(st["tscore"]),
            u8(t[0]),
            u8(t[1]),
            u8(t[2]),
            tl,
            tr
        )
        p.process()

        now = time.ticks_ms()
        if not drop_busy and (tl != ll or tr != lr or time.ticks_diff(now, lt) > 200):
            tled(tl, tr)
            lt = now
            ll = tl
            lr = tr

        if not drop_busy and time.ticks_diff(now, lt) > 40:
            led(0, 0, 0)

        await asyncio.sleep_ms(1)


# 허브에서 받은 배출 명령을 순서대로 실행한다.
async def drop_task():
    while True:
        if drop_q and not drop_busy:
            v = drop_q.pop(0)
            if v == DROP_LEFT:
                await drop_left()
            elif v == DROP_RIGHT:
                await drop_right()
        await asyncio.sleep_ms(10)

# 카메라, 거리 센서, 허브 전송 작업을 동시에 실행한다.
async def main():
    asyncio.create_task(tof_task())
    asyncio.create_task(tx_task())
    asyncio.create_task(drop_task())
    await cam_task()

asyncio.run(main())
