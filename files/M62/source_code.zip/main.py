from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor
from pybricks.parameters import Button, Color, Direction, Port
from pybricks.tools import StopWatch, wait

from pupremote import PUPRemoteHub


hub = PrimeHub()  # 프라임 허브

sp = Port.C       # 카메라 센서 연결 포트
rm = 10           # 센서값 읽기 반복 간격(ms)
pe = 10           # 센서값 로그 출력 주기
db = False        # 디버그 출력 사용 여부
drive_db = False  # 주행 상세 로그 출력 여부
rx_only = False   # 모터를 움직이지 않고 OpenMV 수신값만 확인
run_color = Color.GREEN  # 프로그램 실행 중 표시할 색

fr = Motor(Port.F)                                
br = Motor(Port.E)                                
fl = Motor(Port.B, Direction.COUNTERCLOCKWISE)    
bl = Motor(Port.A, Direction.COUNTERCLOCKWISE)    

pw = 42           # 직진 주행 모터 출력
er = 0            # 현재 주행 보정 오차
pg = 3            # 자이로 비례 보정값

cd = 420          # 한 칸을 이동하는 모터 회전각
fw = 10           # 정면 장애물 정지 거리(cm)
fc = 18           # 정면 벽 판단 거리(cm)
sc = 18           # 측면 벽 판단 거리(cm)
tg = 9            # 측면 벽과 유지할 목표 거리(cm)
wg = 5          # 벽 거리 보정값
rs = 12           # 한 칸 이동 중 롤 변화가 이 값 이상이면 심한 흔들림으로 기록한다.
ab = 35           # 정면 벽 정렬 후 뒤로 물러나는 모터 회전각
ap = 38           # 정면 벽 정렬 때 사용할 전진 출력
at = 2000         # 정면 벽 정렬 최대 시간(ms)
am = 0            # 양쪽 터치 후 추가 밀착 시간(ms)
af = 10           # 평상시 정면 벽 정렬은 이 횟수마다 한 번만 한다.
hb = 80           # 충돌 회피 때 사용할 고정 후진 회전각

td = 90           # 한 번 회전할 각도
tp = 45           # 회전 모터 출력 설정값(현재 회전 함수에서는 사용하지 않음)
ts = 500          # 회전 모터 속도

x = 0             # 지도상의 현재 x 좌표
y = 0             # 지도상의 현재 y 좌표
di = 0            # 현재 방향: 0=북, 1=동, 2=남, 3=서
hd = 0            # 자이로 기준 목표 각도
ms = 40            # 최대 이동 칸 수
cams = []         # 이미 처리한 카메라 좌표 기록
grid = {}         # 좌표별 벽 정보와 방문 정보를 저장한다.
mission_pending = False # 미션 수행 후 아직 집에서 점수 정산 대기를 하지 않았는지 여부
route_log = [(0, 0)] # 집 도착 후 확인할 이동 좌표 순서
mission_log = []     # 집 도착 후 확인할 미션 수행 기록
hurdle_log = []      # 집 도착 후 확인할 허들/큰 흔들림 위치

DROP_NONE = 0       # 카메라 배출 모터 명령 없음
DROP_LEFT = 1       # 왼쪽으로 키트를 버린다.
DROP_RIGHT = 2      # 오른쪽으로 키트를 버린다.

cam_settle_ms = 200     # 미션 발견 후 로봇이 완전히 멈출 때까지 기다리는 시간
cam_confirm_ms = 800    # 정지 상태에서 카메라 점수를 다시 모을 시간
cam_confirm_dt = 40     # 점수 확인 간격


# 왼쪽 앞뒤 모터를 지정한 출력으로 움직인다.
def lmotor(p):
    fl.dc(p)
    bl.dc(p)


# 오른쪽 앞뒤 모터를 지정한 출력으로 움직인다.
def rmotor(p):
    fr.dc(p)
    br.dc(p)


# 왼쪽 앞뒤 모터를 지정한 속도로 움직인다.
def lrun(s):
    fl.run(s)
    bl.run(s)


# 오른쪽 앞뒤 모터를 지정한 속도로 움직인다.
def rrun(s):
    fr.run(s)
    br.run(s)


# 네 모터를 모두 브레이크로 정지한다.
def stop():
    fr.brake()
    br.brake()
    fl.brake()
    bl.brake()


# 이동 거리 측정을 위해 모든 모터의 회전각을 0으로 초기화한다.
def reset_deg():
    fl.reset_angle(0)
    fr.reset_angle(0)
    bl.reset_angle(0)
    br.reset_angle(0)


# 네 모터의 평균 회전각이 지정값에 도달할 때까지 지정 출력으로 이동한다.
def drive_deg(deg, p):
    reset_deg()
    while avg_deg() < deg:
        read_mv()
        lmotor(p)
        rmotor(p)
        wait(10)
    stop()
    wait_mv(200)
    reset_deg()


# 네 모터가 회전한 각도의 절댓값 평균을 반환한다.
def avg_deg():
    return (
        abs(fl.angle()) + abs(fr.angle()) + abs(bl.angle()) + abs(br.angle())
    ) / 4


# 거리 센서값이 측정 가능한 정상값인지 확인한다.
def ok(v):
    return v is not None and v > 0


# 벽 정보 출력용: 벽 있음=1, 없음=0, 모름=-.
def wv(v):
    if v is None:
        return "-"
    return int(v)


# 셀에 저장된 미션 정보를 짧은 문자열로 만든다.
def mission_text(mis):
    if not mis:
        return "-"

    out = ""
    for m in mis:
        if out:
            out += ","
        out += "%s:%d:%s:%d" % (m["k"], m["v"], m["wall"], m["deg"])
    return out


def mission_name(kind, val):
    if kind == "c":
        return "CIRCLE"
    if val >= 2:
        return "PHI"
    if val == 1:
        return "PSI"
    if val == 0:
        return "OMEGA"
    return "TEXT"


def mission_drop_count(kind, val):
    if kind == "c":
        if val >= 2:
            return 2
        if val == 1:
            return 1
        return 0
    if val >= 2:
        return 2
    if val == 1:
        return 1
    return 0


def add_hurdle(cx, cy, from_x, from_y, d, step_no, lo, hi):
    for h in hurdle_log:
        if h["x"] == cx and h["y"] == cy:
            return

    if lo is None:
        lo = 0
    if hi is None:
        hi = 0

    hurdle_log.append({
        "x": cx,
        "y": cy,
        "from_x": from_x,
        "from_y": from_y,
        "d": dir_name(d),
        "step": step_no,
        "lo": int(lo),
        "hi": int(hi),
    })


def print_route_report():
    print("route start")
    i = 0
    while i < len(route_log):
        s = "route"
        j = i
        while j < len(route_log) and j < i + 10:
            px, py = route_log[j]
            s += " %d:(%d,%d)" % (j, px, py)
            j += 1
        print(s)
        i = j
    print("route end")


def print_mission_report():
    print("mission start")
    if not mission_log:
        print("mission none")
    for i, m in enumerate(mission_log):
        print(
            "mission %d xy=(%d,%d) %s kind=%s val=%d drop=%d seen=%s wall=%s deg=%d"
            % (
                i + 1,
                m["x"],
                m["y"],
                m["name"],
                m["k"],
                m["v"],
                m["drop"],
                m["seen"],
                m["wall"],
                m["deg"],
            )
        )
    print("mission end")


def print_hurdle_report():
    print("hurdle start")
    if not hurdle_log:
        print("hurdle none")
    for i, h in enumerate(hurdle_log):
        print(
            "hurdle %d xy=(%d,%d) from=(%d,%d) d=%s step=%d roll=(%d,%d)"
            % (
                i + 1,
                h["x"],
                h["y"],
                h["from_x"],
                h["from_y"],
                h["d"],
                h["step"],
                h["lo"],
                h["hi"],
            )
        )
    print("hurdle end")


def print_final_report():
    print("final report start")
    print_route_report()
    print_mission_report()
    print_hurdle_report()
    print("final report end")


# 왼쪽, 정면, 오른쪽 센서값으로 각 방향의 벽 존재 여부를 반환한다.
def wall(l, c, r):
    wl = ok(l) and l <= sc
    wf = ok(c) and c <= fc
    wr = ok(r) and r <= sc
    return wl, wf, wr


# 허브 IMU에서 롤 각도를 읽는다. tilt()는 (pitch, roll)을 반환한다.
def roll_deg():
    try:
        return hub.imu.tilt(calibrated=True)[1]
    except:
        return None


# 현재 롤 값을 한 칸/회전 구간의 최소/최대 기록에 반영한다.
def record_roll():
    global rl, rh, sh

    rv = roll_deg()
    if rv is not None:
        if rl is None or rv < rl:
            rl = rv
        if rh is None or rv > rh:
            rh = rv
        if rh - rl >= rs:
            sh = True
    return rv


# 누적된 롤 흔들림 기록을 지운다.
def clear_roll():
    global rl, rh, sh

    rl = None
    rh = None
    sh = False


# 현재 방향 번호를 북, 동, 남, 서를 뜻하는 문자로 반환한다.
def dn():
    return ["n", "e", "s", "w"][di]


# 현재 바라보는 방향을 기준으로 지도 좌표를 한 칸 이동한다.
def move_xy():
    global x, y

    # 현재 방향이 북쪽이면 y 좌표를 증가시킨다.
    if di == 0:
        y += 1
    # 현재 방향이 동쪽이면 x 좌표를 증가시킨다.
    elif di == 1:
        x += 1
    # 현재 방향이 남쪽이면 y 좌표를 감소시킨다.
    elif di == 2:
        y -= 1
    else:
        x -= 1


# 방향 번호를 지도에서 쓰는 절대 방향 문자로 바꾼다.
def dir_name(d):
    return ["n", "e", "s", "w"][d % 4]


# 지정 방향의 반대 방향을 반환한다.
def opp_dir(d):
    return (d + 2) % 4


# 지정 좌표와 방향으로 한 칸 이동한 이웃 좌표를 반환한다.
def near_xy(cx, cy, d):
    d = d % 4
    if d == 0:
        return cx, cy + 1
    if d == 1:
        return cx + 1, cy
    if d == 2:
        return cx, cy - 1
    return cx - 1, cy


# 좌표 딕셔너리에 셀이 없으면 새로 만든다.
def cell(cx, cy):
    key = (cx, cy)
    if key not in grid:
        grid[key] = {
            "v": 0,
            "n": None,
            "e": None,
            "s": None,
            "w": None,
            "last": -1,
            "dead": False,
            "mis": [],
            "ex": [0, 0, 0, 0],
        }
    return grid[key]


# 한 셀의 특정 방향 벽 정보를 저장하고, 이웃 셀의 반대쪽 정보도 같이 맞춘다.
def set_wall(cx, cy, d, has_wall):
    c0 = cell(cx, cy)
    dn0 = dir_name(d)
    c0[dn0] = has_wall

    nx, ny = near_xy(cx, cy, d)
    c1 = cell(nx, ny)
    c1[dir_name(opp_dir(d))] = has_wall
    update_dead(cx, cy)
    update_dead(nx, ny)


# 현재 방향 기준 왼쪽/정면/오른쪽 벽 정보를 현재 좌표의 절대방향 벽 정보로 저장한다.
def update_cell(wl, wf, wr):
    c0 = cell(x, y)
    c0["v"] += 1
    c0["last"] = step

    update_walls(wl, wf, wr)


# 현재 좌표에 로봇 기준 왼쪽/정면/오른쪽 벽 정보만 저장한다.
def update_walls(wl, wf, wr):
    set_wall(x, y, (di + 3) % 4, wl)
    set_wall(x, y, di, wf)
    set_wall(x, y, (di + 1) % 4, wr)
    update_dead(x, y)


# 좌표에 미션 정보를 저장한다.
def add_mission(cx, cy, kind, val, raw_x, raw_y, deg):
    c0 = cell(cx, cy)
    seen = dir_name(di)
    wall_dir = dir_name(opp_dir(di))
    name = mission_name(kind, val)
    drops = mission_drop_count(kind, val)
    c0["mis"].append({
        "k": kind,
        "v": val,
        "name": name,
        "drop": drops,
        "seen": seen,
        "wall": wall_dir,
        "raw": (raw_x, raw_y),
        "deg": deg,
    })
    mission_log.append({
        "x": cx,
        "y": cy,
        "k": kind,
        "v": val,
        "name": name,
        "drop": drops,
        "seen": seen,
        "wall": wall_dir,
        "deg": deg,
    })

# 해당 좌표가 시작점이 아닌지 확인한다.
def is_home(cx, cy):
    return cx == 0 and cy == 0


# 벽과 이웃 dead 정보를 함께 보고 해당 셀이 막다른 길인지 계산한다.
def calc_dead(cx, cy):
    c0 = cell(cx, cy)
    if is_home(cx, cy):
        return False

    vals = [c0["n"], c0["e"], c0["s"], c0["w"]]
    if None in vals:
        return c0["dead"]

    open_count = 0
    for d in range(4):
        if c0[dir_name(d)] is False:
            nx, ny = near_xy(cx, cy, d)
            nc = grid.get((nx, ny))
            if nc is None or not nc["dead"] or is_home(nx, ny):
                open_count += 1

    return open_count <= 1


# 벽 정보와 이웃 dead 정보를 이용해 막다른 길을 주변으로 전파한다.
def update_dead(cx, cy):
    q = [(cx, cy)]
    qi = 0

    while qi < len(q):
        cx, cy = q[qi]
        qi += 1
        c0 = cell(cx, cy)
        old = c0["dead"]
        new = calc_dead(cx, cy)

        if old == new:
            continue

        c0["dead"] = new
        for d in range(4):
            if c0[dir_name(d)] is False:
                nx, ny = near_xy(cx, cy, d)
                if (nx, ny) in grid:
                    q.append((nx, ny))

# 지정 방향으로 가면 막다른 셀로 들어가는지 확인한다.
def dead_dir(d):
    nx, ny = near_xy(x, y, d)
    c0 = grid.get((nx, ny))
    if c0 is None:
        return False
    return c0["dead"]


# 우수법 순서를 유지하되, 현재 셀에서 덜 사용한 출구를 먼저 선택한다.
def choose_exit(wl, wf, wr):
    c0 = cell(x, y)
    opts = [
        ((di + 1) % 4, "r", wr),
        (di, "f", wf),
        ((di + 3) % 4, "l", wl),
    ]
    cand = []

    for i, opt in enumerate(opts):
        d, act, blocked = opt
        if not blocked and not dead_dir(d):
            nx, ny = near_xy(x, y, d)
            nc = grid.get((nx, ny))
            nv = 0 if nc is None else nc["v"]
            cand.append((c0["ex"][d], nv, i, d, act))

    if not cand:
        opts.append(((di + 2) % 4, "b", False))

    if not cand:
        for i, opt in enumerate(opts):
            d, act, blocked = opt
            if not blocked:
                nx, ny = near_xy(x, y, d)
                nc = grid.get((nx, ny))
                nv = 0 if nc is None else nc["v"]
                cand.append((c0["ex"][d], nv, i, d, act))

    cand.sort()
    d = cand[0][3]
    act = cand[0][4]
    c0["ex"][d] += 1
    return act


# 절대 방향을 현재 로봇 기준 동작 문자로 바꾼다.
def dir_to_act(d):
    d = d % 4
    if d == di:
        return "f"
    if d == (di + 1) % 4:
        return "r"
    if d == (di + 3) % 4:
        return "l"
    return "b"


# 저장된 벽 지도에서 현재 좌표부터 시작점까지 갈 첫 방향을 찾는다.
def home_dir():
    start = (x, y)
    if is_home(x, y):
        return None

    q = [start]
    qi = 0
    seen = {start: True}
    first = {}

    while qi < len(q):
        cx, cy = q[qi]
        qi += 1
        c0 = grid.get((cx, cy))
        if c0 is None:
            continue

        for d in range(4):
            if c0[dir_name(d)] is not False:
                continue

            nx, ny = near_xy(cx, cy, d)
            nk = (nx, ny)
            if nk in seen:
                continue

            seen[nk] = True
            first[nk] = d if (cx, cy) == start else first[(cx, cy)]
            if is_home(nx, ny):
                return first[nk]
            q.append(nk)

    return None


# 집으로 돌아갈 방향을 우선 선택하고, 길을 못 찾으면 기존 탐색 선택을 사용한다.
def choose_home_exit(wl, wf, wr):
    d = home_dir()
    if d is not None:
        cell(x, y)["ex"][d] += 1
        return dir_to_act(d)
    return choose_exit(wl, wf, wr)


# 디버그 모드일 때 현재 주행 상태와 센서값을 출력한다.
def log(tag, ci, l, c, r, wl, wf, wr):
    # 디버그 모드가 아니면 로그를 출력하지 않는다.
    if not db:
        return

    print(
        "%s step=%d xy=(%d,%d) d=%s di=%d hd=%d ci=%d cs=%d ti=%d tc=%d l=%d c=%d r=%d wl=%d wf=%d wr=%d deg=%d yaw=%d er=%d"
        % (
            tag,
            step,
            x,
            y,
            dn(),
            di,
            hd,
            ci,
            cs,
            ti,
            tc,
            l,
            c,
            r,
            wl,
            wf,
            wr,
            int(avg_deg()),
            hub.imu.heading(),
            er,
        )
    )


# 이동 중 카메라 미션을 발견했을 때 현재 칸인지 다음 칸인지 판단한다.
def mission_xy():
    deg = int(avg_deg())
    if deg >= cd / 2:
        return near_xy(x, y, di)
    return x, y


# 실제 경기장에서는 한 좌표에 미션이 하나만 있으므로 좌표 기준으로 한 번만 처리한다.
def cam_seen(cx, cy, kind):
    key = (cx, cy)
    for v in cams:
        if v == key:
            return True
    cams.append(key)
    return False


# 지정한 시간 동안 허브 불빛을 점멸한다.
def blink_light(color, on_ms, off_ms, total_ms):
    t = 0
    while t < total_ms:
        hub.light.on(color)
        wait_mv(on_ms)
        t += on_ms
        if t >= total_ms:
            break
        hub.light.off()
        wait_mv(off_ms)
        t += off_ms
    hub.light.on(run_color)


def pick_score(vals, fallback):
    if len(vals) == 0:
        return fallback

    cnt = {}
    for v in vals:
        cnt[v] = cnt.get(v, 0) + 1

    best = fallback
    bn = -1
    for v, n in cnt.items():
        if n > bn or (n == bn and v < best):
            best = v
            bn = n
    return best


def confirm_camera_score(kind, fallback):
    vals = []

    wait_mv(cam_settle_ms)

    t = 0
    while t < cam_confirm_ms:
        if read_mv():
            if kind == "c" and ci:
                vals.append(int(cs))
            elif kind == "t" and ti:
                vals.append(int(tc))
        wait(cam_confirm_dt)
        t += cam_confirm_dt

    val = pick_score(vals, int(fallback))
    if db:
        print("confirm", kind, "samples", vals, "=>", val)
    return val


# 집으로 복귀하기 전에 큰 알림음을 낸다.
def home_alarm():
    try:
        hub.speaker.volume(100)
    except:
        pass

    for i in range(3):
        hub.speaker.beep(900, 180)
        wait(60)
        hub.speaker.beep(1400, 180)
        wait(80)


# 원이나 글자를 처음 발견한 좌표에서만 정지하고 표시한다.
def cam_event(turning=False):
    global mission_pending

    if turning:
        mx, my = x, y
    else:
        mx, my = mission_xy()
    deg = int(avg_deg())

    if ci and not cam_seen(mx, my, "c"):
        stop()
        hub.speaker.beep(700, 120)
        sc = int(cs)
        add_mission(mx, my, "c", sc, x, y, deg)
        mission_pending = True
        send_drops(DROP_LEFT, circle_drop_count(sc))
        blink_light(Color.RED, 500, 500, 5000)
        return True

    if ti and not cam_seen(mx, my, "t"):
        stop()
        hub.speaker.beep(1100, 120)
        sc = int(tc)
        add_mission(mx, my, "t", sc, x, y, deg)
        mission_pending = True
        send_drops(DROP_LEFT, text_drop_count(sc))
        blink_light(Color.BLUE, 500, 500, 5000)
        return True

    return False


def cam_event_turning():
    if ci or ti:
        return cam_event(True)
    return False


def circle_drop_count(score):
    if score >= 2:
        return 2
    if score == 1:
        return 1
    return 0


def text_drop_count(score):
    if score >= 2:
        return 2
    if score == 1:
        return 1
    return 0


def send_drop(side):
    try:
        qn = remote.call("cmd", int(side), wait_ms=5)
        if db:
            print("drop cmd", side, "q", qn)
        return True
    except Exception as e:
        if db:
            print("drop cmd error", type(e), e)
        return False


def send_drops(side, count):
    ok = True
    count = int(count)
    if count <= 0:
        return send_drop(DROP_NONE)
    for i in range(count):
        if not send_drop(side):
            ok = False
        wait(30)
    return ok


# OpenMV의 원, 거리, 터치 정보를 읽어 최신값으로 저장한다.
def read_mv():
    global ci, cs, ti, tc, l, c, r, tl, tr

    try:
        ci, cs, ti, tc, l, c, r, tl, tr = remote.call("vals")
        return True
    except Exception as e:
        if db:
            print("mv read error", type(e), e)
        return False


# 정지 대기 중에도 OpenMV 정보를 계속 읽는다.
def wait_mv(ms):
    t = 0
    while t < ms:
        read_mv()
        wait(10)
        t += 10


# 지도 방향은 바꾸지 않고 지정한 각도만큼 회전한다. 양수는 오른쪽이다.
def turn_a(a):
    global hd

    hd += a
    t = 0

    if a > 0:
        while hub.imu.heading() < hd and t < 3000:
            read_mv()
            cam_event_turning()
            lrun(ts)
            rrun(-ts)
            wait(5)
            t += 5
    else:
        while hub.imu.heading() > hd and t < 3000:
            read_mv()
            cam_event_turning()
            lrun(-ts)
            rrun(ts)
            wait(5)
            t += 5

    stop()
    wait_mv(200)


# 자이로 각도와 측면 벽 거리를 이용해 직진 방향을 보정한다.
def trace(l, r):
    global er

    yaw = hub.imu.heading()                    # 현재 자이로 각도
    ge = (hd - yaw) * pg                       # 자이로 비례 보정량
    wc = 0                                     # 측면 벽 기준 보정량
    wm = "n"                                   # 벽 보정 기준: b=양쪽, l=왼쪽, r=오른쪽, n=없음

    # 양쪽 벽이 모두 가까우면 두 벽의 거리 차이로 주행을 보정한다.
    if ok(l) and ok(r) and l <= sc and r <= sc:
        wc = (r - l) * wg
        wm = "b"
    # 왼쪽 벽만 가까우면 왼쪽 목표 거리 기준으로 보정한다.
    elif ok(l) and l <= sc:
        wc = (tg - l) * wg
        wm = "l"
    # 오른쪽 벽만 가까우면 오른쪽 목표 거리 기준으로 보정한다.
    elif ok(r) and r <= sc:
        wc = (r - tg) * wg
        wm = "r"
    # 양쪽 벽이 모두 멀거나 센서값이 잘못되면 벽 보정 없이 자이로만 사용한다.
    else:
        wc = 0

    er = ge + wc
    lmotor(pw + er)
    rmotor(pw - er)


# 자이로 목표 각도까지 오른쪽으로 90도 회전한다.
def turn_right():
    global di, hd

    hd += td
    t = 0

    while hub.imu.heading() < hd and t < 3000:
        read_mv()
        cam_event_turning()
        lrun(ts)
        rrun(-ts)
        wait(5)
        t += 5

    stop()
    wait_mv(200)
    di = (di + 1) % 4


# 자이로 목표 각도까지 왼쪽으로 90도 회전한다.
def turn_left():
    global di, hd

    hd -= td
    t = 0

    while hub.imu.heading() > hd and t < 3000:
        read_mv()
        cam_event_turning()
        lrun(-ts)
        rrun(ts)
        wait(5)
        t += 5

    stop()
    wait_mv(200)
    di = (di + 3) % 4


# 중간에 멈추지 않고 오른쪽으로 180도 회전한다.
def turn_back():
    global di, hd

    hd += td * 2
    t = 0

    while hub.imu.heading() < hd and t < 5000:
        read_mv()
        cam_event_turning()
        lrun(ts)
        rrun(-ts)
        wait(5)
        t += 5

    stop()
    wait_mv(200)
    di = (di + 2) % 4


# 앞 터치 상태에 맞춰 벽에 평행하게 붙도록 민다.
def align_touch_drive():
    if tl and tr:
        lmotor(ap)
        rmotor(ap)
    elif tl:
        lmotor(0)
        rmotor(ap)
    elif tr:
        lmotor(ap)
        rmotor(0)
    else:
        lmotor(ap)
        rmotor(ap)


# 허들/계단 뒤 정면 벽이 있을 때 벽 기준으로 자세를 잡고 heading을 현재 지도 방향에 맞춘다.
def align_front():
    global hd

    old_hd = hd
    old_yaw = hub.imu.heading()
    if drive_db:
        print(
            "ALIGNSTART xy=(%d,%d) d=%s di=%d hd=%d yaw=%d"
            % (x, y, dn(), di, old_hd, old_yaw)
        )
    stop()
    wait_mv(100)
    read_mv()

    t = 0
    while not (tl and tr) and t < at:
        read_mv()
        align_touch_drive()
        wait(10)
        t += 10

    stop()
    wait_mv(50)
    read_mv()

    if not (tl and tr):
        if tl or tr:
            drive_deg(ab, -35)
        return False

    t = 0
    while t < am:
        read_mv()
        align_touch_drive()
        wait(10)
        t += 10

    stop()
    wait_mv(200)
    read_mv()

    before_reset_yaw = hub.imu.heading()
    hd = di * td
    hub.imu.reset_heading(hd)
    wait(100)
    if drive_db:
        print(
            "ALIGNRESET xy=(%d,%d) d=%s di=%d old_hd=%d old_yaw=%d before=%d new_hd=%d yaw=%d"
            % (x, y, dn(), di, old_hd, old_yaw, before_reset_yaw, hd, hub.imu.heading())
        )
    drive_deg(ab, -35)

    return True


# 카메라 센서와 통신이 연결될 때까지 반복해서 연결을 시도한다.
def connect():
    # 디버그 모드이면 연결 시작 정보를 출력한다.
    if db:
        print("start")
        print("port", sp)

    while True:
        try:
            # 디버그 모드이면 연결 시도 중임을 출력한다.
            if db:
                print("connect...")
            remote = PUPRemoteHub(sp)
            remote.add_channel("vals", to_hub_fmt="bbbbBBBbb")
            remote.add_command("cmd", to_hub_fmt="b", from_hub_fmt="b")
            # 디버그 모드이면 연결 성공을 출력한다.
            if db:
                print("connected")
            hub.light.on(Color.GREEN)
            return remote
        except OSError as e:
            # 디버그 모드이면 연결 오류를 출력한다.
            if db:
                print("connect error", e)
        except AssertionError as e:
            # 디버그 모드이면 모드 설정 오류를 출력한다.
            if db:
                print("mode error", e)
        except Exception as e:
            # 디버그 모드이면 그 밖의 설정 오류를 출력한다.
            if db:
                print("setup error", type(e), e)

        wait(200)


remote = connect()

wc = 0            # 시작 버튼 대기 중 센서값 읽기 횟수
we = 0            # 시작 버튼 대기 중 센서값 읽기 오류 횟수

while Button.LEFT not in hub.buttons.pressed():
    try:
        ci, cs, ti, tc, l, c, r, tl, tr = remote.call("vals")
        wc += 1

        we = 0

    except OSError as e:
        we += 1
        # 첫 오류와 오류가 계속될 때 약 1초마다 통신 오류를 출력한다.
        if db and (we == 1 or we % 20 == 0):
            print("wait read error", e)
    except Exception as e:
        we += 1
        # 첫 오류와 오류가 계속될 때 약 1초마다 일반 오류를 출력한다.
        if db and (we == 1 or we % 20 == 0):
            print("wait read error", type(e), e)

    wait(50)

while Button.LEFT in hub.buttons.pressed():
    wait(20)

stop()
wait(300)                  # 버튼을 놓은 뒤 모형이 완전히 멈출 때까지 기다린다.
hub.imu.reset_heading(0)   # 실제 출발 직전에 자이로를 한 번만 초기화한다.
hd = 0
er = 0
reset_deg()
sx = x
sy = y
sd = di
move_id = 0
wait(100)
hub.light.on(run_color)

timer = StopWatch()

# OpenMV 통신 확인 중에는 모터를 움직이지 않고 받은 값만 출력한다.
if rx_only:
    stop()
    n = 0
    same = 0
    err = 0
    old = None

    print("rx test start, press right to stop")

    while Button.RIGHT not in hub.buttons.pressed():
        try:
            ci, cs, ti, tc, l, c, r, tl, tr = remote.call("vals")
            n += 1
            now = (l, c, r)

            if now == old:
                same += 1
            else:
                print(
                    "rx change n=%d ci=%d cs=%d ti=%d tc=%d l=%d c=%d r=%d tl=%d tr=%d same=%d err=%d"
                    % (n, ci, cs, ti, tc, l, c, r, tl, tr, same, err)
                )
                old = now
                same = 0

            # 같은 거리값이 약 1초 동안 계속 들어오면 고정 상태를 출력한다.
            if same > 0 and same % 20 == 0:
                print(
                    "rx same n=%d l=%d c=%d r=%d same=%d err=%d"
                    % (n, l, c, r, same, err)
                )

            # 측정 불가능한 거리값은 즉시 출력한다.
            if not ok(l) or not ok(c) or not ok(r):
                print("rx bad n=%d l=%d c=%d r=%d" % (n, l, c, r))

        except Exception as e:
            err += 1
            print("rx error n=%d err=%d" % (n, err), type(e), e)

        wait(50)

    stop()
    hub.light.off()
    print("rx test end n=%d same=%d err=%d" % (n, same, err))
    raise SystemExit

cnt = 0           # 센서값을 읽은 횟수
step = 0          # 이동한 칸 수
re = 0            # 주행 중 센서값 읽기 오류 횟수
wc = [0, 0, 0]    # 왼쪽, 정면, 오른쪽 벽 감지 횟수
cc = 0            # 벽 상태를 확인한 횟수
fwc = 0           # 정면 벽을 만난 횟수
home_started = False # 집 복귀 모드 시작 여부
rl = None         # 현재 한 칸에서 측정한 최소 롤 각도
rh = None         # 현재 한 칸에서 측정한 최대 롤 각도
sh = False        # 현재 한 칸에서 심한 흔들림을 감지했는지 여부

while step < ms or not is_home(x, y):
    try:
        ci, cs, ti, tc, l, c, r, tl, tr = remote.call("vals")
        cnt += 1
        # 디버그 모드이고 이전에 읽기 오류가 있었다면 복구를 알린다.
        if db and re > 0:
            print("read ok")
        re = 0
    except OSError as e:
        re += 1
        # 디버그 모드이면 첫 오류와 매 50번째 통신 오류를 출력한다.
        if db and (re == 1 or re % 50 == 0):
            print("read error", e)
        stop()
        wait(rm)
        continue
    except Exception as e:
        re += 1
        # 디버그 모드이면 첫 오류와 매 50번째 일반 오류를 출력한다.
        if db and (re == 1 or re % 50 == 0):
            print("read error", type(e), e)
        stop()
        wait(rm)
        continue

    wl, wf, wr = wall(l, c, r)
    record_roll()
    front_wall_touch = (tl or tr) and wf

    # 원이나 글자를 처음 본 좌표에서는 5초 동안 멈추고 표시한다.
    if cam_event():
        continue

    # 왼쪽 또는 오른쪽 터치 센서가 눌리면 충돌 처리한다.
    if (tl or tr) and not front_wall_touch:
        stop()
        deg = int(avg_deg())

        # 양쪽 터치 센서가 모두 눌렸는지 판단한다.
        if tl and tr:
            hit = "both"
            hub.speaker.beep(1200, 80)
        # 왼쪽 터치 센서만 눌렸는지 판단한다.
        elif tl:
            hit = "left"
            hub.speaker.beep(800, 80)
        else:
            hit = "right"
            hub.speaker.beep(1000, 80)

        # 후진 중 터치값이 풀리기 전에 회피 방향을 확정한다.
        if hit == "both":
            a = -45 if l > r else 45
        elif hit == "left":
            a = 45
        else:
            a = -45

        # 충돌 회피는 실제 충돌 전 이동량과 무관하게 고정량만 사용한다.
        drive_deg(hb, -35)

        # 45도 대각선 이동 후 다시 후진하여 옆쪽 중앙으로 이동한다.
        turn_a(a)
        drive_deg(int(hb * 1.414), 35)
        turn_a(-a)
        drive_deg(hb, -35)

        wc = [0, 0, 0]
        cc = 0
        clear_roll()

        while tl or tr:
            try:
                ci, cs, ti, tc, l, c, r, tl, tr = remote.call("vals")
            except:
                tl = 0
                tr = 0
            wait(20)

        # 디버그 모드이면 충돌 센서 해제를 출력한다.
        if db:
            print("hit clear")
        continue

    # 한 칸 도착 직전에 최대 3번 벽 상태를 확인한다.
    if avg_deg() >= cd - 30 and cc < 3:
        wc[0] += 1 if wl else 0
        wc[1] += 1 if wf else 0
        wc[2] += 1 if wr else 0
        cc += 1
        # 디버그 모드이면 확인한 벽 상태를 출력한다.
        if db:
            print("check%d wl=%d wf=%d wr=%d l=%d c=%d r=%d" % (cc, wl, wf, wr, l, c, r))

    fs = front_wall_touch or (ok(c) and c <= fw)
    end_by_cd = avg_deg() >= cd

    # 정면 벽에 가까워졌거나 한 칸 주행 거리에 도달하면 동일하게 우수법을 실행한다.
    if fs or end_by_cd:
        end_deg = int(avg_deg())

        # 정면 벽에 가까우면 충돌하기 전에 먼저 정지한다.
        if fs:
            stop()
            log("front_stop", ci, l, c, r, wl, wf, wr)
            wait_mv(100)

        # 미리 벽을 확인하지 못했다면 현재 센서값으로 한 번 확인한다.
        if cc == 0:
            wc[0] += 1 if wl else 0
            wc[1] += 1 if wf else 0
            wc[2] += 1 if wr else 0
            cc = 1

        wl = wc[0] * 2 >= cc
        wf = wc[1] * 2 >= cc
        wr = wc[2] * 2 >= cc
        aligned = False
        align_tried = False

        # 허들 뒤에는 무조건 정렬하고, 평상시에는 정면 벽 10번 중 한 번만 정렬한다.
        if wf:
            fwc += 1
            if sh or fwc % af == 0:
                align_tried = True
                if drive_db:
                    print(
                        "ALIGNTRY step=%d xy=(%d,%d) d=%s di=%d reason=%s fwc=%d af=%d sh=%d hd=%d yaw=%d"
                        % (
                            step,
                            x,
                            y,
                            dn(),
                            di,
                            "hurdle" if sh else "count",
                            fwc,
                            af,
                            sh,
                            hd,
                            hub.imu.heading(),
                        )
                    )
                stop()
                wait_mv(50)
                read_mv()
                aligned = align_front()
                if drive_db:
                    print(
                        "ALIGNDONE step=%d xy=(%d,%d) d=%s di=%d ok=%d hd=%d yaw=%d"
                        % (step, x, y, dn(), di, aligned, hd, hub.imu.heading())
                    )

        if front_wall_touch and not aligned and not align_tried:
            drive_deg(ab, -35)

        if drive_db:
            print(
                "MOVECHK id=%d step=%d start=(%d,%d,%s) now=(%d,%d,%s) di=%d hd=%d yaw=%d end=%d fs=%d deg=%d wl=%d wf=%d wr=%d sh=%d align=%d"
                % (move_id, step, sx, sy, dir_name(sd), x, y, dn(), di, hd, hub.imu.heading(), end_by_cd, fs, end_deg, wl, wf, wr, sh, aligned)
            )
        moved_cell = end_deg >= cd // 2
        if moved_cell:
            px = x
            py = y
            pd = di
            if drive_db and (px != sx or py != sy or pd != sd):
                print(
                    "MOVEWARN id=%d step=%d start=(%d,%d,%s) move_from=(%d,%d,%s)"
                    % (move_id, step, sx, sy, dir_name(sd), px, py, dir_name(pd))
                )
            set_wall(px, py, pd, False)
            reset_deg()
            move_xy()
            step += 1
            route_log.append((x, y))
            if sh:
                add_hurdle(x, y, px, py, pd, step, rl, rh)
            if drive_db:
                print(
                    "MOVE id=%d step=%d from=(%d,%d) pd=%s to=(%d,%d) d=%s di=%d"
                    % (move_id, step, px, py, dir_name(pd), x, y, dn(), di)
                )
            update_cell(wl, wf, wr)
        else:
            if sh:
                add_hurdle(x, y, x, y, di, step, rl, rh)
            update_walls(wl, wf, wr)
            reset_deg()
        if x == 0 and y == 0:
            stop()
            if mission_pending:
                blink_light(Color.GREEN, 1000, 1000, 10000)
                mission_pending = False
        # 디버그 모드이면 갱신된 현재 칸과 방향을 출력한다.
        if db:
            print("step=%d xy=(%d,%d) d=%s" % (step, x, y, dn()))

        if step >= ms and is_home(x, y):
            break

        if step >= ms:
            if not home_started:
                home_started = True
                stop()
                home_alarm()
            act = choose_home_exit(wl, wf, wr)
        else:
            act = choose_exit(wl, wf, wr)
        will_turn = act != "f"

        clear_after_turn = align_tried or aligned or (not sh and not will_turn)
        if drive_db:
            print(
                "ACT step=%d xy=(%d,%d) d=%s di=%d act=%s wl=%d wf=%d wr=%d home=%d"
                % (step, x, y, dn(), di, act, wl, wf, wr, step >= ms)
            )

        # 선택된 출구가 오른쪽이면 우회전한다.
        if act == "r":
            stop()
            log("right_open", ci, l, c, r, wl, wf, wr)
            wait_mv(200)
            # 디버그 모드이면 오른쪽 회전 동작을 출력한다.
            if db:
                print("act=right")
            turn_right()
            if drive_db:
                print("TURN step=%d xy=(%d,%d) d=%s di=%d act=r hd=%d yaw=%d" % (step, x, y, dn(), di, hd, hub.imu.heading()))
        # 선택된 출구가 왼쪽이면 좌회전한다.
        elif act == "l":
            stop()
            log("front_wall", ci, l, c, r, wl, wf, wr)
            wait_mv(200)
            # 디버그 모드이면 왼쪽 회전 동작을 출력한다.
            if db:
                print("act=left")
            turn_left()
            if drive_db:
                print("TURN step=%d xy=(%d,%d) d=%s di=%d act=l hd=%d yaw=%d" % (step, x, y, dn(), di, hd, hub.imu.heading()))
        # 선택된 출구가 뒤쪽이면 180도 회전한다.
        elif act == "b":
            stop()
            log("front_wall", ci, l, c, r, wl, wf, wr)
            wait_mv(200)
            # 디버그 모드이면 뒤로 회전하는 동작을 출력한다.
            if db:
                print("act=back")
            turn_back()
            if drive_db:
                print("TURN step=%d xy=(%d,%d) d=%s di=%d act=b hd=%d yaw=%d" % (step, x, y, dn(), di, hd, hub.imu.heading()))

        if clear_after_turn:
            clear_roll()

        reset_deg()
        move_id += 1
        sx = x
        sy = y
        sd = di
        if drive_db:
            print("CELLSTART id=%d step=%d xy=(%d,%d) d=%s di=%d hd=%d yaw=%d" % (move_id, step, sx, sy, dn(), di, hd, hub.imu.heading()))
        wc = [0, 0, 0]
        cc = 0

    trace(l, r)
    wait(rm)

print_final_report()
stop()
hub.light.off()
