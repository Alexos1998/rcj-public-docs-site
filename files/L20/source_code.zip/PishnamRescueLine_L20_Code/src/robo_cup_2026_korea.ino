//*******you need pio to open this file******//
//******main evacuation algorithm: void evacuation_zone:ln 11732******//
//******main line follower: void line_follower_right:ln 2602******//
//******main intersectio: void act_intersection:ln 6623******//
//******main obstacle algorithm: void act_obstacle:ln 8123******//

#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include <Dynamixel2Arduino.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include <VL53L1X.h>
#include <WiFi.h>
#include <ArduinoOTA.h>

using namespace ControlTableItem;
using uint = unsigned int;
#define APDS_ADDR 0x39

const char *ssid = "arvin";
const char *password = "az1ta100";

#define DXL_SERIAL Serial1
#define RX_PIN 9
#define TX_PIN 8
#define DXL_DIR_PIN 18

Dynamixel2Arduino dxl(DXL_SERIAL, DXL_DIR_PIN);
VL53L1X sensor;

#define DXL_BAUD 57600

#define WRITE 0x02
#define READ 0x03

using uint = unsigned int;

//******************************************************

uint shift = 100;

#define speed_normal_eep_cell 1 + shift
#define speed_ramp_up_eep_cell 2 + shift
#define speed_ramp_down_eep_cell 3 + shift
#define speed_ramp_side_eep_cell 4 + shift

#define dir_obstacle_eep_cell 5 + shift
#define str_1_turn_eep_cell 6 + shift
#define deg_45_eep_cell 8 + shift
#define str_2_turn_eep_cell 10 + shift
#define arc_high_eep_cell 110 + shift
#define arc_low_eep_cell 112 + shift

#define sil_l1_eep_cell 14 + shift
#define sil_l2_eep_cell 16 + shift
#define sil_r1_eep_cell 18 + shift
#define sil_r2_eep_cell 20 + shift

#define tm_slow_eep_cell 22 + shift

#define ball_rescued_eep_cell 195 + shift
#define silver_rescued_eep_cell 197 + shift
#define black_rescued_eep_cell 199 + shift

#define vorood_eep_cell 28 + shift
#define chance_obs_eep_cell 29 + shift
#define going_out_evac_eep_cell 30 + shift
#define flag_eslahe_mic_eep_cell 31 + shift

#define d_c_eep_cell 32 + shift
#define d_r1_eep_cell 34 + shift
#define d_r2_eep_cell 36 + shift
#define d_r3_eep_cell 38 + shift
#define d_r4_eep_cell 40 + shift
#define d_r5_eep_cell 42 + shift
#define d_r6_eep_cell 44 + shift
#define d_r7_eep_cell 46 + shift
#define d_r8_eep_cell 48 + shift
#define d_r9_eep_cell 50 + shift
#define d_r10_eep_cell 52 + shift

#define d_l1_eep_cell 54 + shift
#define d_l2_eep_cell 56 + shift
#define d_l3_eep_cell 58 + shift
#define d_l4_eep_cell 60 + shift
#define d_l5_eep_cell 62 + shift
#define d_l6_eep_cell 64 + shift
#define d_l7_eep_cell 66 + shift
#define d_l8_eep_cell 68 + shift
#define d_l9_eep_cell 70 + shift
#define d_l10_eep_cell 72 + shift

#define d_sil_l1_eep_cell 74 + shift
#define d_sil_l2_eep_cell 76 + shift
#define d_sil_r1_eep_cell 78 + shift
#define d_sil_r2_eep_cell 80 + shift

#define d_l3_m_eep_cell 82 + shift
#define d_l2_m_eep_cell 84 + shift
#define d_l1_m_eep_cell 86 + shift
#define d_c_m_eep_cell 88 + shift
#define d_r1_m_eep_cell 90 + shift
#define d_r2_m_eep_cell 92 + shift
#define d_r3_m_eep_cell 94 + shift

#define d_l3_b_eep_cell 96 + shift
#define d_l2_b_eep_cell 98 + shift
#define d_l1_b_eep_cell 100 + shift
#define d_c_b_eep_cell 102 + shift
#define d_r1_b_eep_cell 104 + shift
#define d_r2_b_eep_cell 106 + shift
#define d_r3_b_eep_cell 108 + shift

//******************************************************

#define d_sil_l1 sensor_read_digital('l', 4, d_sil_l1_eep - 900 - extra_obs - extra_evac)
#define d_sil_l2 sensor_read_digital('l', 7, d_sil_l2_eep - 900 - extra_obs - extra_evac)

#define d_sil_r1 sensor_read_digital('r', 8, d_sil_r1_eep - 900 - extra_obs - extra_evac)
#define d_sil_r2 sensor_read_digital('r', 9, d_sil_r2_eep - 900 - extra_obs - extra_evac)

//******************************************************
#define d_c_g sensor_read_digital('l', 13, d_c_eep - 1500 - extra - extra_ramp)
#define d_l1_g sensor_read_digital('l', 11, d_l1_eep - 2000 - extra - extra_ramp)
#define d_l2_g sensor_read_digital('l', 11, d_l2_eep - 2000 - extra - extra_ramp)
#define d_r1_g sensor_read_digital('r', 5, d_r1_eep - 2000)
#define d_r2_g sensor_read_digital('r', 10, d_r2_eep - 2000 - extra - extra_ramp)

#define d_l1 sensor_read_digital('l', 11, d_l1_eep - 1000 - extra - extra_ramp)
#define d_c sensor_read_digital('l', 13, d_c_eep - 800 - extra - extra_ramp)
#define d_r1 sensor_read_digital('r', 5, d_r1_eep - 1000 - extra - extra_ramp)

#define d_r2 sensor_read_digital('r', 4, d_r2_eep - 1000 - extra - extra_ramp)
#define d_r3 sensor_read_digital('r', 2, d_r3_eep - 1000 - extra - extra_ramp)
#define d_r4 sensor_read_digital('r', 6, d_r4_eep - 900 - extra_ramp)
#define d_r5 sensor_read_digital('r', 3, d_r5_eep - 900 - extra_ramp)
#define d_r6 sensor_read_digital('r', 10, d_r6_eep - 900)
#define d_r7 sensor_read_digital('r', 11, d_r7_eep - 900)
#define d_r8 sensor_read_digital('r', 12, d_r8_eep - 900)
#define d_r9 sensor_read_digital('r', 13, d_r9_eep - 900)
#define d_r10 sensor_read_digital('r', 14, d_r10_eep - 900)

#define d_l2 sensor_read_digital('l', 10, d_l2_eep - 1000 - extra - extra_ramp)
#define d_l3 sensor_read_digital('l', 9, d_l3_eep - 1000 - extra - extra_ramp)
#define d_l4 sensor_read_digital('l', 12, d_l4_eep - 900 - extra_ramp)
#define d_l5 sensor_read_digital('l', 6, d_l5_eep - 900 - extra_ramp)
#define d_l6 sensor_read_digital('l', 5, d_l6_eep - 900)
#define d_l7 sensor_read_digital('l', 3, d_l7_eep - 900)
#define d_l8 sensor_read_digital('l', 2, d_l8_eep - 900)
#define d_l9 sensor_read_digital('l', 1, d_l9_eep - 900)
#define d_l10 sensor_read_digital('l', 0, d_l10_eep - 900)

//******************************************************

#define d_m_l3 sensor_read_digital('l', 8, d_l3_m_eep - 900 - extra_mid)
#define d_m_l2 sensor_read_digital('l', 14, d_l2_m_eep - 900 - extra_mid)
#define d_m_l1 sensor_read_digital('l', 15, d_l1_m_eep - 900 - extra_mid)

#define d_m_c sensor_read_digital('r', 15, d_c_m_eep - 900 - extra_mid - extra_gap)

#define d_m_r1 sensor_read_digital('r', 0, d_r1_m_eep - 900 - extra_mid)
#define d_m_r2 sensor_read_digital('r', 1, d_r2_m_eep - 900 - extra_mid)
#define d_m_r3 sensor_read_digital('r', 7, d_r3_m_eep - 900 - extra_mid)

//******************************************************

#define d_b_l3 sensor_read_digital('c', 14, d_l3_b_eep - 900 - extra_back)
#define d_b_l2 sensor_read_digital('c', 12, d_l2_b_eep - 900 - extra_back)
#define d_b_l1 sensor_read_digital('c', 13, d_l1_b_eep - 800 - extra_back)

#define d_b_c sensor_read_digital('c', 11, d_c_b_eep - 800 - extra_back - extra_gap)

#define d_b_r1 sensor_read_digital('c', 10, d_r1_b_eep - 900 - extra_back)
#define d_b_r2 sensor_read_digital('c', 9, d_r2_b_eep - 900 - extra_back)
#define d_b_r3 sensor_read_digital('c', 8, d_r3_b_eep - 900 - extra_back)

//******************************************************

#define a_sil_r2 sensor_read_analog('r', 9)
#define a_sil_r1 sensor_read_analog('r', 8)

#define a_sil_l1 sensor_read_analog('l', 4)
#define a_sil_l2 sensor_read_analog('l', 7)

#define a_c sensor_read_analog('l', 13)
#define a_r1 sensor_read_analog('r', 5)
#define a_r2 sensor_read_analog('r', 4)
#define a_r3 sensor_read_analog('r', 2)
#define a_r4 sensor_read_analog('r', 6)
#define a_r5 sensor_read_analog('r', 3)
#define a_r6 sensor_read_analog('r', 10)
#define a_r7 sensor_read_analog('r', 11)
#define a_r8 sensor_read_analog('r', 12)
#define a_r9 sensor_read_analog('r', 13)
#define a_r10 sensor_read_analog('r', 14)

#define a_l1 sensor_read_analog('l', 11)
#define a_l2 sensor_read_analog('l', 10)
#define a_l3 sensor_read_analog('l', 9)
#define a_l4 sensor_read_analog('l', 12)
#define a_l5 sensor_read_analog('l', 6)
#define a_l6 sensor_read_analog('l', 5)
#define a_l7 sensor_read_analog('l', 3)
#define a_l8 sensor_read_analog('l', 2)
#define a_l9 sensor_read_analog('l', 1)
#define a_l10 sensor_read_analog('l', 0)

#define a_m_l3 sensor_read_analog('l', 8)
#define a_m_l2 sensor_read_analog('l', 14)
#define a_m_l1 sensor_read_analog('l', 15)

#define a_m_c sensor_read_analog('r', 15)

#define a_m_r1 sensor_read_analog('r', 0)
#define a_m_r2 sensor_read_analog('r', 1)
#define a_m_r3 sensor_read_analog('r', 7)

#define a_b_l3 sensor_read_analog('c', 14)
#define a_b_l2 sensor_read_analog('c', 12)
#define a_b_l1 sensor_read_analog('c', 13)

#define a_b_c sensor_read_analog('c', 11)

#define a_b_r1 sensor_read_analog('c', 10)
#define a_b_r2 sensor_read_analog('c', 9)
#define a_b_r3 sensor_read_analog('c', 8)

#define ir_apds_r sensor_read_digital('c', 6, 1900 - 100)
#define ir_apds_l sensor_read_digital('c', 7, 2000 - 100)

//******************************************************

#define add_0_pin 40
#define add_1_pin 47
#define add_2_pin 42
#define add_3_pin 15
#define add_4_pin 37
#define add_5_pin 21

#define out_mux_r 7
#define out_mux_l 2
#define out_mux_m 1

#define out_mux_c 6
#define out_mux_main 4

#define e_pin 39

#define bat main_read_analog(7)

#define battery (((bat * 3.3) / 4095) * 4.3)

//******************************************************

#define mic_rb main_read_digital(0, 1000)
#define mic_lb main_read_digital(8, 1000)

#define mic_rf connector_read_digital(2, 1500)
#define mic_lf connector_read_digital(6, 1500)

#define but_u main_read_digital(12, 100)
#define but_d main_read_digital(15, 100)

#define but_r main_read_digital(13, 100)
#define but_l main_read_digital(14, 100)

#define resana connector_read_digital(3, 2400)

#define ir_obs connector_read_digital(4, 1000)
#define ir_ball connector_read_digital(1, 1000)

#define a_ir_obs connector_read_analog(4)
#define a_ir_ball connector_read_analog(1)
#define a_resana connector_read_analog(3)

//******************************************************

#define rf 1
#define rb 2
#define lb 3
#define lf 4

#define box 5

#define arm_f 6
#define arm_s 7

#define deg_arm_f (dxl.getPresentPosition(arm_f))
#define deg_arm_s (dxl.getPresentPosition(arm_s))

#define grip_l_id 10
#define grip_r_id 9
#define sep_id 8

#define grip_r_pos (dxl.getPresentPosition(grip_r_id))
#define grip_l_pos (dxl.getPresentPosition(grip_l_id))

#define distance_f_r vl_distance(3)
#define distance_f_c vl_distance(2)
#define distance_f_l vl_distance(1)

#define distance_d_r vl_distance(4)
#define distance_d_l vl_distance(6)
#define distance_u_l vl_distance(7)
#define distance_u_r vl_distance(5)

//******************************************************

#define led_blink_pin 3

//******************************************************

#define led_r_on main_write_digital(11, 1)
#define led_g_on main_write_digital(9, 1)
#define led_b_on main_write_digital(10, 1)
#define led_blink_on digitalWrite(led_blink_pin, 1)

#define led_blink_off digitalWrite(led_blink_pin, 0)
#define led_r_off main_write_digital(11, 0)
#define led_g_off main_write_digital(9, 0)
#define led_b_off main_write_digital(10, 0)

#define buzzer_on main_write_digital(2, 1)
#define buzzer_off main_write_digital(2, 0)

// #define sensor_viberetion sensor_read_digital('c', 2, 500)

//******************************************************

#define TFT_SCK 48
#define TFT_MOSI 36
#define TFT_CS 35
#define TFT_DC 38
#define TFT_RST -1
#define TFT_MISO -1

#define FRAM_CS 10
#define FRAM_MOSI 11
#define FRAM_SCK 12
#define FRAM_MISO 13

#define WREN 0x06

SPIClass spi(FSPI);
Adafruit_ST7735 tft = Adafruit_ST7735(&spi, TFT_CS, TFT_DC, TFT_RST);
SPISettings framSPI(79999999, MSBFIRST, SPI_MODE0);

//********************** Ramp ********************************

bool ramp_up, ramp_down, ramp_left, ramp_right, on_ramp;

int speed_ramp_up, speed_ramp_down, speed_ramp_side;

//********************** Menu ********************************

bool flag_stop, flag_ball_special_menu, flag_moving_menu;

char flag_sil;
char text[200];

unsigned long int t_b;

//********************** Eprom *******************************

unsigned int sil_l1_eep, sil_l2_eep, sil_r1_eep, sil_r2_eep;

bool chance_obs_eep;
char dir_obstacle_eep = 0;
uint str_1_turn_eep;
uint deg_45_eep;
uint str_2_turn_eep, arc_low_eep = 0, arc_high_eep = 0, going_out_evac_eep;

int speed_normal_eep;
int speed_ramp_up_eep, speed_ramp_down_eep, speed_ramp_side_eep;

uint tm_slow_eep;

uint d_l3_m_eep, d_l2_m_eep, d_l1_m_eep, d_c_m_eep, d_r1_m_eep, d_r2_m_eep, d_r3_m_eep;
uint d_l3_b_eep, d_l2_b_eep, d_l1_b_eep, d_c_b_eep, d_r1_b_eep, d_r2_b_eep, d_r3_b_eep;

//********************** Line ********************************

bool flag_gap, flag_small_gap;
bool flag_dead, flag_eslahe_mic_eep;
bool flag_line_2, flag_no_line_follower_gap, flag_not_on_line_mid, flag_not_on_line_back;
bool flag_not_wall;

bool tamrin;

unsigned int n_vl_r, n_vl_l;
unsigned long int dl, dr, dc, dlf, dld, drf, drd;

unsigned char n_check_wall;
long enc_r_c, enc_l_c, enc_first_r, enc_first_l;

unsigned long int tm_apd, t_gap, t1, tm, t_go_out, tm_wall, time_obs, time_cmps, tm_slow, t_l, t_r;
unsigned long int time_red, timer_green;

unsigned int n_black;

char dir_gap = 'r';

bool flag_start_turn, flag_zero, flag_red, flag_green, flag_after_int;

bool red_l, red_r, red_f;
bool green_l, green_r, green_f;
bool blue_l, blue_r, blue_f;
unsigned long int red, green, blue, ambient, prox;

//********************* Red Room******************************

bool flag_o, flag_dont_check_side, flag_disable, flag_search_side, flag_tarazed = 0, flag_back_special;
bool flag_found_ball_after_special, flag_ball_obs, flag_before_akh, flag_do_dont, random_evac, flag_akh_side;
bool flag_broke_by_dont_go_out, flag_khas_dont, flag_sucsses_ball, flag_dont_go_out, flag_silver_go, flag_black_go, flag_ball_failed;

char flag_dir_special, flag_catch_special_fake, flag_sucsses_out;

unsigned char n_do_near;

uint vorood;

int n_evac_side;

unsigned char n_str_20;

char dir_out = 'r';
char next_turn = 'r', dir_turn_evac = 'n';

unsigned int encoder_back_after_ball;

unsigned long int tm_red_khooroj, t_fake, tm_out_sil;

unsigned char black_rescued = 0, silver_rescued = 0, ball_rescued = 0, n_rescued;

char n_ball;
unsigned long t_turn;

int n_silver, n_side = 0;

//********************* cmps 14 *****************************

int pitch, roll, comp;
uint8_t cmps_id = 0x60;

float error = 0, zeroOffset = 0, zeroOffsetDebug = 0;

bool flag_stop_div_error = 0;

//*********************** IR Sensor **************************

int extra = 0, extra_obs = 0, extra_ramp = 0, extra_mid = 0, extra_evac = 0, extra_back = 0, extra_gap = 0;

uint max_sil_l2, max_sil_l1, max_l10, max_l9, max_l8, max_l7, max_l6, max_l5, max_l4, max_l3, max_l2, max_l1, max_c, max_r1, max_r2, max_r3, max_r4 = 0, max_r5, max_r6, max_r7, max_r8, max_r9, max_r10, max_sil_r1, max_sil_r2;
uint d_sil_l2_eep, d_sil_l1_eep, d_l10_eep, d_l9_eep, d_l8_eep, d_l7_eep, d_l6_eep, d_l5_eep, d_l4_eep, d_l3_eep, d_l2_eep, d_l1_eep, d_c_eep, d_r1_eep, d_r2_eep, d_r3_eep, d_r4_eep, d_r5_eep, d_r6_eep, d_r7_eep, d_r8_eep, d_r9_eep, d_r10_eep, d_sil_r1_eep, d_sil_r2_eep;

uint max_l3_m, max_l2_m, max_l1_m, max_c_m, max_r1_m, max_r2_m, max_r3_m;
uint max_l3_b, max_l2_b, max_l1_b, max_c_b, max_r1_b, max_r2_b, max_r3_b;

unsigned int max_value;

//********************* Arm *****************************

uint grip_close_ball_l = 4096 - 1763, grip_close_ball_r = 1763;
uint grip_open_l = 4096 - 2150, grip_open_r = 2150;
uint grip_open_l_red = 4096 - 2333, grip_open_r_red = 2333, grip_fully_closed = 1840;

uint arm_1_up = 1210, arm_1_ball = 200, arm_1_normal = 430;
uint arm_2_up = 3510, arm_2_ball = 2085, arm_2_normal = 1725;

uint Box_down = 2312, Box_ball = 1200;

uint sep_black = 1003, sep_silver = 2023;

//******************************************************

word convert_rgb(byte B, byte G, byte R)
{ // rgb 24 bit -> rgb 16 bit downloaded
  return ((R & 0xF8) << 8) | ((G & 0xFC) << 3) | (B >> 3);

  // 0xf8 1111 1000 : RRRR R000 0000 0000
  // oxfc 1111 1100 : 0000 0GGG GGG0 0000
  //      BBBB BBBB : 0000 0000 000B BBBB
  //                : RRRR RGGG GGGB BBBB
}

//******************************************************
word BLACK = convert_rgb(0, 0, 0);
word WHITE = convert_rgb(255, 255, 255);

word BLUE = convert_rgb(255, 0, 0);
word GREEN = convert_rgb(0, 255, 0);
word RED = convert_rgb(0, 0, 255);

word GRAY = convert_rgb(151, 151, 151);
word YELLOW = convert_rgb(0, 255, 255);
word ORANGE = convert_rgb(0, 165, 255);
word PURPLE = convert_rgb(255, 0, 255);
word PURPLE_LIGHT = convert_rgb(255, 0, 128);
word BLUE_LIGHT = convert_rgb(244, 200, 0);
word GREEN_DARK = convert_rgb(0, 135, 0);
word SILVER_LIGHT = convert_rgb(224, 224, 224);
word SILVER = convert_rgb(155, 155, 155);
word GOLD = convert_rgb(0, 215, 255);

word TEAL = convert_rgb(0, 128, 128);
word NAVY = convert_rgb(0, 0, 128);
word PINK = convert_rgb(255, 192, 203);

//******************************************************

uint sensor_read_analog(char which, char add)
{
  bool add_0, add_1, add_2, add_3;
  uint analog;

  add_0 = (add / 1) % 2; // convert address to binary
  add_1 = (add / 2) % 2;
  add_2 = (add / 4) % 2;
  add_3 = (add / 8) % 2;

  digitalWrite(add_0_pin, add_0);
  digitalWrite(add_1_pin, add_1);
  digitalWrite(add_2_pin, add_2);
  digitalWrite(add_3_pin, add_3);

  delayMicroseconds(100);

  if (which == 'c')
    analog = analogRead(out_mux_m);
  else if (which == 'r')
    analog = analogRead(out_mux_r);
  else
    analog = analogRead(out_mux_l);

  return analog;
}

//******************************************************

bool sensor_read_digital(char which, char add, uint offset)
{
  bool add_0, add_1, add_2, add_3;
  uint analog_dig;
  bool digital;

  add_0 = (add / 1) % 2; // converts address to binary
  add_1 = (add / 2) % 2;
  add_2 = (add / 4) % 2;
  add_3 = (add / 8) % 2;

  digitalWrite(add_0_pin, add_0);
  digitalWrite(add_1_pin, add_1);
  digitalWrite(add_2_pin, add_2);
  digitalWrite(add_3_pin, add_3);

  delayMicroseconds(100);

  if (which == 'c')
    analog_dig = analogRead(out_mux_m);
  else if (which == 'r')
    analog_dig = analogRead(out_mux_r);
  else
    analog_dig = analogRead(out_mux_l);

  if (analog_dig > offset)
    digital = 1;
  else
    digital = 0;

  return digital;
}

//******************************************************

uint connector_read_analog(char add)
{
  bool add_0, add_1, add_2;
  uint analog;

  pinMode(out_mux_c, INPUT);

  pinMode(add_0_pin, OUTPUT);
  pinMode(add_1_pin, OUTPUT);
  pinMode(add_2_pin, OUTPUT);

  add_0 = (add / 1) % 2; // convert address to binary
  add_1 = (add / 2) % 2;
  add_2 = (add / 4) % 2;

  digitalWrite(add_0_pin, add_0);
  digitalWrite(add_1_pin, add_1);
  digitalWrite(add_2_pin, add_2);

  delayMicroseconds(100);

  analog = analogRead(out_mux_c);

  return analog;
}

//******************************************************

bool connector_read_digital(char add, uint offset)
{
  bool add_0, add_1, add_2;
  uint analog_dig;

  pinMode(out_mux_c, INPUT);

  pinMode(add_0_pin, OUTPUT);
  pinMode(add_1_pin, OUTPUT);
  pinMode(add_2_pin, OUTPUT);

  add_0 = (add / 1) % 2; // converts address to binary
  add_1 = (add / 2) % 2;
  add_2 = (add / 4) % 2;

  digitalWrite(add_0_pin, add_0);
  digitalWrite(add_1_pin, add_1);
  digitalWrite(add_2_pin, add_2);

  delayMicroseconds(100);

  analog_dig = analogRead(out_mux_c);
  if (analog_dig > offset)
    return 1;
  else
    return 0;
}

//******************************************************

uint main_read_analog(char add)
{
  bool add_0, add_1, add_2, add_3;
  uint analog;

  add_0 = (add / 1) % 2; // converts address to binary
  add_1 = (add / 2) % 2;
  add_2 = (add / 4) % 2;
  add_3 = (add / 8) % 2;

  digitalWrite(add_0_pin, add_0);
  digitalWrite(add_1_pin, add_1);
  digitalWrite(add_2_pin, add_2);
  digitalWrite(add_3_pin, add_3);

  delayMicroseconds(100);

  pinMode(out_mux_main, INPUT);

  analog = analogRead(out_mux_main);

  return analog;
}

//******************************************************

bool main_read_digital(char add, uint offset)
{
  bool add_0, add_1, add_2, add_3;
  uint analog_dig;

  add_0 = (add / 1) % 2; // converts address to binary
  add_1 = (add / 2) % 2;
  add_2 = (add / 4) % 2;
  add_3 = (add / 8) % 2;

  digitalWrite(add_0_pin, add_0);
  digitalWrite(add_1_pin, add_1);
  digitalWrite(add_2_pin, add_2);
  digitalWrite(add_3_pin, add_3);

  delayMicroseconds(70);

  pinMode(out_mux_main, INPUT);

  analog_dig = analogRead(out_mux_main);
  pinMode(out_mux_main, OUTPUT);
  if (analog_dig > offset)
    return 1;
  else
    return 0;
}

//******************************************************

void main_write_digital(char add, bool on_off)
{
  bool add_0, add_1, add_2, add_3;
  pinMode(out_mux_main, OUTPUT);

  add_0 = (add / 1) % 2; // converts address to binary
  add_1 = (add / 2) % 2;
  add_2 = (add / 4) % 2;
  add_3 = (add / 8) % 2;

  digitalWrite(add_0_pin, add_0);
  digitalWrite(add_1_pin, add_1);
  digitalWrite(add_2_pin, add_2);
  digitalWrite(add_3_pin, add_3);

  delayMicroseconds(200);

  digitalWrite(out_mux_main, on_off);
}
//******************************************************

void buz(int time = 100)
{
  buzzer_on;
  delay(time);
  buzzer_off;
}

//******************************************************

void alarm_buz(int n = 10, int time = 100)
{
  for (int i = 0; i < n; i++)
  {
    buz(50);
    delay(time);
  }
  buzzer_off;
}

//******************************************************

void error_buz(int n)
{
  for (int i = 0; i < n; i++)
  {
    buz(100);
    delay(100);
  }
}

//******************************************************

void alarm_break()
{
  buzzer_on;
  delay(2000);
  buzzer_off;
}

//******************************************************

void motor(signed int sl, signed int sr, int time = 0)
{

  int sln = map(sl, -100, 100, -255, 255);
  int srn = map(sr, -100, 100, -255, 255);
  // sl = int((sl / 100) * 1023);
  //  sr = int((sr / 100) * 1023);

  ///////////////////////////////////// for gap

  if (sl < sr)
  {
    dir_gap = 'l';
  }
  else if (sr < sl)
  {
    dir_gap = 'r';
  }

  /////////////////////////////////////

  if (!dxl.setGoalVelocity(lf, sln)) // if goal velocity failed
    dxl.setGoalVelocity(lf, sln);
  if (!dxl.setGoalVelocity(rb, -srn))
    dxl.setGoalVelocity(rb, -srn);
  if (!dxl.setGoalVelocity(lb, sln))
    dxl.setGoalVelocity(lb, sln);
  if (!dxl.setGoalVelocity(rf, -srn))
    dxl.setGoalVelocity(rf, -srn);

  if (time > 0)
  {
    delay(time);

    if (!dxl.setGoalVelocity(lf, 0))
      dxl.setGoalVelocity(lf, 0);
    if (!dxl.setGoalVelocity(rb, 0))
      dxl.setGoalVelocity(rb, 0);
    if (!dxl.setGoalVelocity(lb, 0))
      dxl.setGoalVelocity(lb, 0);
    if (!dxl.setGoalVelocity(rf, 0))
      dxl.setGoalVelocity(rf, 0);
  }
}

//******************************************************

void motor_ramp(signed int sl, signed int sr, float zarib = 0.5, int time = 0)
{

  int sln = map(sl, -100, 100, -255, 255);
  int srn = map(sr, -100, 100, -255, 255);
  // sl = int((sl / 100) * 1023);
  //  sr = int((sr / 100) * 1023);

  ///////////////////////////////////// for gap

  if (sl < sr)
  {
    dir_gap = 'l';
  }
  else if (sr < sl)
  {
    dir_gap = 'r';
  }

  /////////////////////////////////////

  dxl.setGoalVelocity(lf, sln);
  dxl.setGoalVelocity(rb, -srn * zarib);
  dxl.setGoalVelocity(rf, -srn);
  dxl.setGoalVelocity(lb, sln * zarib);

  if (time > 0)
  {
    delay(time);

    dxl.setGoalVelocity(lf, 0);
    dxl.setGoalVelocity(rb, 0);
    dxl.setGoalVelocity(rf, 0);
    dxl.setGoalVelocity(lb, 0);
  }
}

//******************************************************

void motor_ramp_right(signed int sl, signed int sr, float zarib = 0.5, int time = 0)
{

  int sln = map(sl, -100, 100, -255, 255);
  int srn = map(sr, -100, 100, -255, 255);
  // sl = int((sl / 100) * 1023);
  //  sr = int((sr / 100) * 1023);

  ///////////////////////////////////// for gap

  if (sl < sr)
  {
    dir_gap = 'l';
  }
  else if (sr < sl)
  {
    dir_gap = 'r';
  }

  /////////////////////////////////////

  dxl.setGoalVelocity(lf, sln);
  dxl.setGoalVelocity(rb, -srn);
  dxl.setGoalVelocity(rf, -srn);
  dxl.setGoalVelocity(lb, sln * zarib);

  if (time > 0)
  {
    delay(time);

    dxl.setGoalVelocity(lf, 0);
    dxl.setGoalVelocity(rb, 0);
    dxl.setGoalVelocity(rf, 0);
    dxl.setGoalVelocity(lb, 0);
  }
}

//******************************************************

void motor_4_wheel(float slu, float sru, float sld, float srd, int time = 0)
{
  int slun = map(slu, -100, 100, -255, 255);
  int srun = map(sru, -100, 100, -255, 255);
  int sldn = map(sld, -100, 100, -255, 255);
  int srdn = map(srd, -100, 100, -255, 255);

  /////////////////////////////////////

  dxl.setGoalVelocity(lf, slun);
  dxl.setGoalVelocity(rb, -srdn);
  dxl.setGoalVelocity(rf, -srun);
  dxl.setGoalVelocity(lb, sldn);

  if (time > 0)
  {
    delay(time);

    dxl.setGoalVelocity(lf, 0);
    dxl.setGoalVelocity(rb, 0);
    dxl.setGoalVelocity(rf, 0);
    dxl.setGoalVelocity(lb, 0);
  }
}

//******************************************************

void motor_full(signed int sl, signed int sr, int time = 0)
{

  int sln = map(sl, -100, 100, -1023, 1023);
  int srn = map(sr, -100, 100, -1023, 1023);
  // sl = int((sl / 100) * 1023);
  //  sr = int((sr / 100) * 1023);

  ///////////////////////////////////// for gap

  if (sl < sr)
  {
    dir_gap = 'l';
  }
  else if (sr < sl)
  {
    dir_gap = 'r';
  }

  /////////////////////////////////////

  dxl.setGoalVelocity(lf, sln);
  dxl.setGoalVelocity(rb, -srn);
  dxl.setGoalVelocity(rf, -srn);
  dxl.setGoalVelocity(lb, sln);

  if (time > 0)
  {
    delay(time);

    dxl.setGoalVelocity(lf, 0);
    dxl.setGoalVelocity(rb, 0);
    dxl.setGoalVelocity(rf, 0);
    dxl.setGoalVelocity(lb, 0);
  }
}

//******************************************************

void stop(uint t)
{
  motor(0, 0, t);
}

//******************************************************

void enc_read()
{
  enc_first_r = dxl.getPresentPosition(rf);
  enc_first_l = dxl.getPresentPosition(lf);
}

//******************************************************

long enc_r()
{
  enc_r_c = Abs(dxl.getPresentPosition(rf) - enc_first_r);
  return enc_r_c;
}

//******************************************************

long enc_l()
{
  enc_l_c = Abs(dxl.getPresentPosition(lf) - enc_first_l);
  return enc_l_c;
}

//******************************************************

void motor_er(signed int sl, signed int sr, long n, uint stop_time)
{

  enc_first_r = dxl.getPresentPosition(rf);

  motor(sl, sr, 0);
  while (1)
  {
    if (Abs(dxl.getPresentPosition(rf) - enc_first_r) > n)
    {
      break;
    }
  }
  stop(stop_time);
}

//******************************************************

void motor_el(signed int sl, signed int sr, long n, uint stop_time)
{
  enc_first_l = dxl.getPresentPosition(lf);

  motor(sl, sr, 0);
  while (1)
  {
    if (Abs(dxl.getPresentPosition(lf) - enc_first_l) > n)
    {
      break;
    }
  }
  stop(stop_time);
}

//******************************************************

void turn_180_cmp(char dir, int n_enc, int deg = 90)
{
  float targetAngle;

  if (dir == 'r')
    targetAngle = deg;
  else
    targetAngle = -deg;

  targetAngle = normalizeAngle(targetAngle);

  enc_read();

  while (true)
  {
    float current = getZeroedHeading();
    if (current == -1)
      continue;

    float error = normalizeAngle(targetAngle - current);

    if (Abs(error) < 1)
      break; // close enough
    if (enc_r() > n_enc || enc_l() > n_enc)
      break;

    float absError = Abs(error);
    int step = (int)(absError / 15);
    int speed = (step + 1) * 14 - 6;
    if (speed > 80)
      speed = 80;

    int output = (error > 0) ? speed : -speed;

    motor(output, -output);
  }

  motor(0, 0); // full stop
}

//******************************************************

void turn_180_cmp_arc(char dir, int n_enc, int arc_low, int arc_high)
{
  float targetAngle;

  if (dir == 'r')
    targetAngle = -180;
  else if (dir == 'l')
    targetAngle = 180;
  else
    targetAngle = 0;

  targetAngle = normalizeAngle(targetAngle);

  enc_read();

  while (true)
  {

    if (mic_rf == 0 || mic_lf == 0)
      break;
    if (check_silver() == 1 || check_black() > 1)
    {
      break;
    }
    if (ir_ball == 1)
    {
      catch_the_victim();
    }

    float current = getZeroedHeading();
    if (current == -1)
      continue;

    float error = normalizeAngle(targetAngle - current);

    if (Abs(error) < 1)
      break; // close enough
    if (enc_r() > n_enc || enc_l() > n_enc)
      break;

    float absError = Abs(error);

    if (Abs(error) < 10 and flag_stop_div_error == 0)
    {
      arc_high = (int)(arc_high / 3);
      arc_low = (int)(arc_low / 3);

      flag_stop_div_error = 1;
    }

    if (dir == 'r')
    {
      motor(arc_low, arc_high);
    }
    else if (dir == 'l')
    {
      motor(arc_high, arc_low);
    }
    else
    {
      if (flag_before_akh == 'r')
        motor(-arc_low, -arc_high);
      else
        motor(-arc_high, -arc_low);
    }
  }
  flag_stop_div_error = 0;

  motor(0, 0); // full stop
}

//******************************************************

void turn_small_deg_cmp(char dir, int n_enc, int arc_low, int arc_high)
{
  float targetAngle;

  if (dir == 'r')
    targetAngle = -85;
  else if (dir == 'l')
    targetAngle = 85;
  else
    targetAngle = 0;

  targetAngle = normalizeAngle(targetAngle);

  enc_read();

  while (true)
  {

    if (mic_rf == 0 || mic_lf == 0)
      break;
    if (check_silver() == 1 || check_black() > 1)
    {
      break;
    }
    if (ir_ball == 1)
    {
      catch_the_victim();
    }

    float current = getZeroedHeading();
    if (current == -1)
      continue;

    float error = normalizeAngle(targetAngle - current);

    if (Abs(error) < 1)
      break; // close enough
    if (enc_r() > n_enc || enc_l() > n_enc)
      break;

    float absError = Abs(error);

    if (Abs(error) < 10 and flag_stop_div_error == 0)
    {
      arc_high = (int)(arc_high / 3);
      arc_low = (int)(arc_low / 3);

      flag_stop_div_error = 1;
    }

    if (dir == 'r')
    {
      motor(arc_low, arc_high);
    }
    else if (dir == 'l')
    {
      motor(arc_high, arc_low);
    }
    else
    {
      if (flag_before_akh == 'r')
        motor(-arc_low, -arc_high);
      else
        motor(-arc_high, -arc_low);
    }
  }
  flag_stop_div_error = 0;

  motor(0, 0); // full stop
}

//******************************************************

void cmps14()
{
  byte highByte_comp, lowByte_comp;

  Wire.beginTransmission(cmps_id);
  Wire.write(2);
  Wire.endTransmission();

  Wire.requestFrom(cmps_id, 4);
  while (Wire.available() < 4)
    ;

  highByte_comp = Wire.read();
  lowByte_comp = Wire.read();
  pitch = Wire.read();
  roll = Wire.read();

  comp = ((highByte_comp << 8) + lowByte_comp) / 10;
}

//******************************************************

float getheading()
{
  Wire.beginTransmission(cmps_id);
  Wire.write(2);
  Wire.endTransmission();

  Wire.requestFrom(cmps_id, 2);
  if (Wire.available() >= 2)
  {
    uint8_t highByte = Wire.read();
    uint8_t lowByte = Wire.read();
    float heading = (highByte << 8 | lowByte) / 10.0;

    return heading;
  }

  return -1;
}

//******************************************************

void zero_head()
{
  float head = getheading();
  zeroOffset = head;
  flag_zero = 0;

  if ((head > 358 or head < 2) and head != 0)
  {
    zeroOffset = 0;
    flag_zero = 1;
  }
}

//******************************************************

void writeRegister(uint8_t reg, uint8_t value)
{
  Wire.beginTransmission(cmps_id);
  Wire.write(reg);
  Wire.write(value);
  Wire.endTransmission();
}

//******************************************************

uint8_t readRegister(uint8_t reg)
{
  Wire.beginTransmission(cmps_id);
  Wire.write(reg);
  Wire.endTransmission();

  Wire.requestFrom(cmps_id, 1);
  if (Wire.available())
  {
    return Wire.read();
  }
  return 0;
}

//******************************************************

void zero_head_debug()
{
  float head = getheading();
  zeroOffsetDebug = head;
  flag_zero = 0;

  if ((head > 358 or head < 2) and head != 0)
  {
    zeroOffsetDebug = 0;
    flag_zero = 1;
  }
}

//******************************************************

float getZeroedHeading()
{
  float raw = getheading();

  // Validate first
  if (raw == -1)
    return -1;

  float heading = raw - zeroOffset;

  // Normalize to [0, 360) first if needed
  while (heading >= 360.0f)
    heading -= 360.0f;
  while (heading < 0.0f)
    heading += 360.0f;

  if (flag_zero == 1 && (heading > 358.0f || heading < 2.0f))
    heading = 0.0f;

  if (heading > 180.0f)
    heading -= 360.0f;

  return heading;
}

//******************************************************

float getZeroedHeading_debug()
{
  float raw = getheading();

  float heading = raw - zeroOffsetDebug;

  if (raw == -1)
    return -1;

  if (heading > 358 or heading < 2 and flag_zero == 1)
  {
    heading = 0;
  }

  if (heading > 180)
    heading -= 360;
  if (heading < -180)
    heading += 360;

  return heading;
}

//******************************************************

float normalizeAngle(float angle)
{
  while (angle > 180)
    angle -= 360;
  while (angle < -180)
    angle += 360;
  return angle;
}

//******************************************************

void cmp_turn_redroom(char dir, int n_enc)
{
  float targetAngle;
  int counter = 0;

  if (dir == 'r')
  {
    motor_er(90, -90, 2050, 20);
    targetAngle = 90;
  }
  else if (dir == 'l')
  {
    motor_er(-90, 90, 2050, 20);
    targetAngle = -90;
  }
  else if (dir == 'b')
    targetAngle = 0;

  targetAngle = normalizeAngle(targetAngle);

  enc_read();
  while (true)
  {
    float current = getZeroedHeading();
    if (current == -1)
      continue;

    float error = normalizeAngle(targetAngle - current);

    if (Abs(error) < 1)
    {
      stop(10);
      counter++;
    }

    if (counter > 3)
    {
      break;
    }

    if (enc_r() > n_enc || enc_l() > n_enc)
      break;

    int speed = 12;

    int output = (error > 0) ? speed : -speed;

    motor(output, -output);
  }

  motor(0, 0); // full stop
}

//******************************************************

void cmp_turn_step_15(char dir, int n_enc)
{
  float targetAngle;
  if (dir == 'r')
    targetAngle = 90;
  else if (dir == 'l')
    targetAngle = -90;
  else
    targetAngle = 0;

  targetAngle = normalizeAngle(targetAngle);

  enc_read();

  while (true)
  {
    float current = getZeroedHeading();
    if (current == -1)
      continue;

    float error = normalizeAngle(targetAngle - current);

    if (Abs(error) < 1)
      break; // close enough
    if (enc_r() > n_enc and enc_l() > n_enc)
    {
      buz(250);
      break;
    }

    float absError = Abs(error);
    int step = (int)(absError / 15);
    int speed = (step + 1) * 14;

    if (speed > 75)
      speed = 75;

    int output = (error > 0) ? speed : -speed;

    motor(output, -output);
  }

  motor(0, 0); // full stop
}

//******************************************************

void cmp_turn_45(char dir, int n_enc)
{
  float targetAngle;
  if (dir == 'r')
    targetAngle = 45;
  else if (dir == 'l')
    targetAngle = -45;
  else
    targetAngle = 0;

  targetAngle = normalizeAngle(targetAngle);

  enc_read();

  while (true)
  {
    float current = getZeroedHeading();
    if (current == -1)
      continue;

    float error = normalizeAngle(targetAngle - current);

    if (Abs(error) < 1.5)
      break; // close enough
    if (enc_r() > n_enc || enc_l() > n_enc)
      break;

    float absError = Abs(error);
    int step = (int)(absError / 15);
    int speed = (step + 1) * 14;

    if (speed > 80)
      speed = 80;

    int output = (error > 0) ? speed : -speed;

    motor(output, -output);
  }

  motor(0, 0); // full stop
}

//******************************************************

float cmp_target_angle(int targetAngle)
{
  return normalizeAngle(targetAngle - getZeroedHeading());
}

//******************************************************

void cmp_turn_90(char dir, int n_enc, int speed = 80)
{
  float targetAngle = (dir == 'r') ? 90 : -90;
  targetAngle = normalizeAngle(targetAngle);

  enc_read();

  while (true)
  {
    float current = getZeroedHeading();
    if (current == -1)
      continue;

    float error = normalizeAngle(targetAngle - current);
    if (Abs(error) < 1.5)
      break;
    if (enc_r() > n_enc || enc_l() > n_enc)
      break;

    // proportional in 15° steps
    int step = (int)(Abs(error) / 15);
    int output = (step + 1) * 11;
    if (output > speed)
      output = speed;

    if (error < 0)
      output = -output;

    motor(output, -output);
  }
  stop(1);
}

//******************************************************

inline void init_dynamixel_motors()
{
  DXL_SERIAL.begin(DXL_BAUD, SERIAL_8N1, RX_PIN, TX_PIN);
  dxl.begin();
  dxl.setPortProtocolVersion(2.0);

  dxl.torqueOff(rf);
  dxl.torqueOff(rb);
  dxl.torqueOff(lb);
  dxl.torqueOff(lf);
  dxl.torqueOff(sep_id);
  dxl.torqueOff(arm_f);
  dxl.torqueOff(arm_s);
  dxl.torqueOff(grip_r_id);
  dxl.torqueOff(grip_l_id);
  dxl.torqueOff(box);

  dxl.setOperatingMode(rb, OP_VELOCITY);
  dxl.setOperatingMode(rf, OP_VELOCITY);
  dxl.setOperatingMode(lf, OP_VELOCITY);
  dxl.setOperatingMode(lb, OP_VELOCITY);

  dxl.torqueOn(rb);
  dxl.torqueOn(rf);
  dxl.torqueOn(lf);
  dxl.torqueOn(lb);
  dxl.torqueOn(box);

  dxl.torqueOn(sep_id);
  dxl.torqueOn(arm_f);
  dxl.torqueOn(arm_s);

  dxl.torqueOn(grip_r_id);
  dxl.torqueOn(grip_l_id);
}

//******************************************************

void Box(uint speed, int deg, uint time = 0)
{

  dxl.writeControlTableItem(PROFILE_VELOCITY, box, speed);

  dxl.setGoalPosition(box, deg);

  if (time > 0)
    delay(time);
}

//******************************************************

void Box_timed(uint speed, int deg, uint time = 0)
{
  int i_p = 0;

  i_p = Abs(dxl.getPresentPosition(box) - deg);

  dxl.writeControlTableItem(PROFILE_VELOCITY, box, speed);

  dxl.setGoalPosition(box, deg);

  delay(time + (i_p * (1.1)));
}

//******************************************************

void line_follower_side_right(int speed) // when the robot is on a ramp
{
  unsigned long int time_no_act = 200;

  if (d_c == 1 and d_r1 == 1)
  {
    motor(speed, speed * .8, 0);
  }
  else if (d_l1 == 1 and d_c == 1)
  {
    motor(speed * .3, speed, 0);
  }
  else if (d_c)
  {
    motor(speed * 0.9, speed, 0);
  }

  /////////////////////////////////////////////////

  else if (d_r1 == 1)
  {
    motor(speed, -speed * 0.4, 0);
  }
  else if (d_l1 == 1)
  {
    motor_ramp(-speed * 0.6, speed, 0.3, 0);
  }
  /////////////////////////////////////////////////

  else if (d_r2)
  {
    motor(speed, -speed * .8, 0);
  }
  else if (d_l2)
  {
    motor_ramp(-speed * .8, speed, 0.3, 0);
  }

  /////////////////////////////////////////////////

  else if (d_r3 == 1)
  {
    motor(speed, -speed, 0);
  }
  else if (d_l3 == 1)
  {
    motor_ramp(-speed, speed, 0.3, 0);
  }

  //////////////////////////////////////////////

  else if (d_r4 == 1)
  {
    t_r = millis();

    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
    {
      motor(speed, -speed * 1.2, 0);
    }
  }

  else if (d_l4 == 1)
  {
    t_l = millis();
    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
    {
      motor_ramp(-speed * 1.2, speed, 0.3, 0);
    }
  }

  // for time no act or gap

  //  //////////////////////////////////////////////
  //
  else if (d_r5 == 1)
  {
    t_r = millis();
    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor(speed, -speed * 1.3, 0);
  }

  else if (d_l5 == 1)
  {
    t_l = millis();

    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor(-speed * 1.3, speed, 0);
  }

  //
  //  ///////////////////////////////////
  //
  else if (d_r6 == 1)
  {
    t_r = millis();
    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor(speed, -speed * 1.3, 0);
  }

  else if (d_l6 == 1)
  {
    t_l = millis();
    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor(-speed * 1.3, speed, 0);
  }

  /////////////////////////////////

  else if (d_r7 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
        motor(speed, -speed * 1.3, 0);
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  ////////////////////////////////////////////

  else if (d_l7 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
        motor(-speed * 1.3, speed, 0);
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  //  ///////////////////////////////
  else if (d_r8 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(speed, -speed * 1.4, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  else if (d_l8 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_l = millis();
      if ((t_l - t_r) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(-speed * 1.4, speed, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  ///////////////////////////////

  else if (d_r9 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(speed, -speed * 1.4, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  else if (d_l9 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_l = millis();

      if ((t_l - t_r) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(-speed * 1.2, speed, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  ///////////////////////////////

  else if (d_r10 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(speed, -speed * 1.2, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }
  else if (d_l10 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_l = millis();
      if ((t_l - t_r) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(-speed * 1.2, speed, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  /////////////////////////////////////////// gapppppppppp

  if (d_l8 == 0 && d_l7 == 0 && d_l6 == 0 && d_l5 == 0 && d_l4 == 0 && d_l3 == 0 && d_l2 == 0 && d_l1 == 0 && d_c == 0 && d_r1 == 0 && d_r2 == 0 && d_r3 == 0 && d_r4 == 0 && d_r5 == 0 && d_r6 == 0 && d_r7 == 0 && d_r8 == 0)
  {
    if (flag_gap == 0)
    {
      flag_gap = 1;
      enc_read();
    }

    if (enc_l() >= 500 or enc_r() >= 500)
    {
      if (flag_no_line_follower_gap == 0)
      {
        tft.fillScreen(WHITE);
        flag_no_line_follower_gap = 1;
      }
      motor(speed * .2, speed * .2, 0); // atten
      // line_follower_gap(1000);

      if (enc_l() >= 4500 or enc_r() >= 4500)
      {
        dont_lose_line(speed);
        motor(speed, speed);
      }
    }
  }

  else
  {
    if (flag_no_line_follower_gap == 1)
    {
      tft.fillScreen(BLACK);
      flag_no_line_follower_gap = 0;
    }

    flag_gap = 0;
  }
}

//****************************************************

void line_follower_side_left(int speed) // when the robot is on a ramp
{
  unsigned long int time_no_act = 200;

  if (d_c == 1 and d_r1 == 1)
  {
    motor(speed, speed * .3, 0);
  }
  else if (d_l1 == 1 and d_c == 1)
  {
    motor(speed * .8, speed, 0);
  }

  //  else if ((d_sil_l2 or d   _sil_l1 or d_sil_r1 or d_sil_r2) and d_c)
  //  {
  //    motor(speed * .5 , speed * .5, 0);
  //  }

  else if (d_c)
  {
    motor(speed * 0.8, speed * 0.8, 0);
  }

  /////////////////////////////////////////////////

  else if (d_r1 == 1)
  {
    motor(speed, -speed * 0.6, 0);
  }
  else if (d_l1 == 1)
  {
    motor(-speed * 0.4, speed, 0);
  }
  /////////////////////////////////////////////////

  else if (d_r2)
  {
    motor(speed, -speed * .8, 0);
  }
  else if (d_l2)
  {
    motor(-speed * .8, speed, 0);
  }
  //
  //  /////////////////////////////////////////////////
  //
  else if (d_r3 == 1)
  {
    motor(speed, -speed, 0);
  }
  else if (d_l3 == 1)
  {
    motor(-speed, speed, 0);
  }

  //////////////////////////////////////////////

  else if (d_r4 == 1)
  {
    t_r = millis();

    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
    {
      motor(speed, -speed * 1.2, 0);
    }
  }

  else if (d_l4 == 1)
  {
    t_l = millis();
    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
    {
      motor(-speed * 1.2, speed, 0);
    }
  }

  // for time no act or gap

  //  //////////////////////////////////////////////
  //
  else if (d_r5 == 1)
  {
    t_r = millis();
    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor(speed, -speed * 1.3, 0);
  }

  else if (d_l5 == 1)
  {
    t_l = millis();

    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor(-speed * 1.3, speed, 0);
  }

  //
  //  ///////////////////////////////////
  //
  else if (d_r6 == 1)
  {
    t_r = millis();
    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor(speed, -speed * 1.3, 0);
  }

  else if (d_l6 == 1)
  {
    t_l = millis();
    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor(-speed * 1.3, speed, 0);
  }

  //
  //  ///////////////////////////////
  //
  else if (d_r7 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
        motor(speed, -speed * 1.3, 0);
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  ////////////////////////////////////////////

  else if (d_l7 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
        motor(-speed * 1.3, speed, 0);
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  //  ///////////////////////////////
  else if (d_r8 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(speed, -speed * 1.4, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  else if (d_l8 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_l = millis();
      if ((t_l - t_r) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(-speed * 1.4, speed, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  ///////////////////////////////

  else if (d_r9 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(speed, -speed * 1.4, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  else if (d_l9 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_l = millis();

      if ((t_l - t_r) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(-speed * 1.2, speed, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  ///////////////////////////////

  else if (d_r10 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(speed, -speed * 1.2, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }
  else if (d_l10 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_l = millis();
      if ((t_l - t_r) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(-speed * 1.2, speed, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  /////////////////////////////////////////// gapppppppppp

  if (d_l8 == 0 && d_l7 == 0 && d_l6 == 0 && d_l5 == 0 && d_l4 == 0 && d_l3 == 0 && d_l2 == 0 && d_l1 == 0 && d_c == 0 && d_r1 == 0 && d_r2 == 0 && d_r3 == 0 && d_r4 == 0 && d_r5 == 0 && d_r6 == 0 && d_r7 == 0 && d_r8 == 0)
  {
    if (flag_gap == 0)
    {
      flag_gap = 1;
      enc_read();
    }

    if (enc_l() >= 500 or enc_r() >= 500)
    {
      if (flag_no_line_follower_gap == 0)
      {
        tft.fillScreen(WHITE);
        flag_no_line_follower_gap = 1;
      }
      motor(speed * .2, speed * .2, 0); // atten
      // line_follower_gap(1000);

      if (enc_l() >= 4500 or enc_r() >= 4500)
      {
        dont_lose_line(speed);
        motor(speed, speed);
      }
    }
  }

  else
  {
    if (flag_no_line_follower_gap == 1)
    {
      tft.fillScreen(BLACK);
      flag_no_line_follower_gap = 0;
    }

    flag_gap = 0;
  }
}

//******************************************************

int error_ir_mid()
{
  if (d_m_c == 1)
  {
    flag_not_on_line_mid = 0;
    return 0;
  }
  else if (d_m_r1 == 1)
  {
    flag_not_on_line_mid = 0;
    return 1;
  }
  else if (d_m_l1 == 1)
  {
    flag_not_on_line_mid = 0;
    return -1;
  }
  else if (d_m_r2 == 1)
  {
    flag_not_on_line_mid = 0;
    return 2;
  }
  else if (d_m_l2 == 1)
  {
    flag_not_on_line_mid = 0;
    return -2;
  }
  else if (d_m_r3 == 1)
  {
    flag_not_on_line_mid = 0;
    return 3;
  }
  else if (d_m_l3 == 1)
  {
    flag_not_on_line_mid = 0;
    return -3;
  }
  else
  {
    flag_not_on_line_mid = 1;
    return 0; // or your last known error
  }
}

//******************************************************

int error_ir_down()
{
  if (d_b_c == 1)
  {
    flag_not_on_line_back = 0;
    return 0;
  }
  else if (d_b_r1 == 1)
  {
    flag_not_on_line_back = 0;
    return 1;
  }
  else if (d_b_l1 == 1)
  {
    flag_not_on_line_back = 0;
    return -1;
  }
  else if (d_b_r2 == 1)
  {
    flag_not_on_line_back = 0;
    return 2;
  }
  else if (d_b_l2 == 1)
  {
    flag_not_on_line_back = 0;
    return -2;
  }
  else if (d_b_r3 == 1)
  {
    flag_not_on_line_back = 0;
    return 3;
  }
  else if (d_b_l3 == 1)
  {
    flag_not_on_line_back = 0;
    return -3;
  }
  else
  {
    flag_not_on_line_back = 1;
    return 0; // or your last known error
  }
}

//******************************************************

void line_follower_gap(int duration_ms)
{
  // due to its many bugs we got rid of it
}
//******************************************************

void dont_lose_line(int speed)
{
  if (dir_gap == 'l')
  {
    motor_er(-speed, -speed, 3500, 0);
    motor_er(-speed, speed, 900, 0);
    motor_er(speed, speed, 750, 0);
  }
  else
  {
    motor_er(-speed, -speed, 3500, 0);
    motor_el(speed, -speed, 900, 0);
    motor_er(speed, speed, 750, 0);
  }
}

//******************************************************

void line_follower_after_int(int speed)
{
  unsigned long int time_no_act = 150; // after the intersection we dont check our back sensors

  if (d_c == 1 and d_r1 == 1)
  {
    motor(speed, speed * .7, 0);
  }
  else if (d_l1 == 1 and d_c == 1)
  {
    motor(speed * .7, speed, 0);
  }
  else if (d_c)
  {
    motor(speed * 0.8, speed * 0.8, 0);
  }
  /////////////////////////////////////////////////

  else if (d_r1 == 1)
  {
    motor(speed, -speed * 0.7, 0);
  }
  else if (d_l1 == 1)
  {
    motor(-speed * 0.7, speed, 0);
  }

  /////////////////////////////////////////////////

  else if (d_r2)
  {
    motor(speed * 1.1, -speed * 1.3, 0);
  }
  else if (d_l2)
  {
    motor(-speed * 1.3, speed * 1.1, 0);
  }

  /////////////////////////////////////////////////

  else if (d_r3 == 1)
  {
    motor(speed * 1.2, -speed * 1.3, 0);
    // delay(100);
  }
  else if (d_l3 == 1)
  {
    motor(-speed * 1.3, speed * 1.2, 0);
    // delay(100);
  }

  //////////////////////////////////////////////

  else if (d_r4 == 1)
  {
    t_r = millis();

    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
    {
      motor(speed * 1.2, -speed * 1.4, 0);
    }
  }

  else if (d_l4 == 1)
  {
    t_l = millis();
    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
    {
      motor(-speed * 1.4, speed * 1.2, 0);
    }
  }

  else if (d_r5 == 1)
  {
    t_r = millis();

    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
    {
      motor(speed * 1.3, -speed * 1.5, 0);
    }
  }

  else if (d_l5 == 1)
  {
    t_l = millis();
    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
    {
      motor(-speed * 1.5, speed * 1.3, 0);
    }
  }

  ////////////////////////////
  // for time no act

  /////////////////////////// gapppppppppp

  if (d_l4 == 0 && d_l3 == 0 && d_l2 == 0 && d_l1 == 0 && d_c == 0 && d_r1 == 0 && d_r2 == 0 && d_r3 == 0 && d_r4 == 0)
  {
    if (flag_gap == 0)
    {
      flag_gap = 1;
      enc_read();
    }

    if (enc_l() >= 700 or enc_r() >= 700)
    {
      motor(speed * .4, speed * .4, 0);
      // line_follower_gap(speed);
    }
  }
  else
  {
    flag_gap = 0;
  }
}

//******************************************************

void line_follower_right(int speed)
{
  // main line follower

  unsigned long int time_no_act = 500;

  //  if (d_sil_l2  or d_sil_l1 )
  //  {
  //    dir_gap = 'l';
  //  }
  //  else if (d_sil_r1  or d_sil_r2 )
  //  {
  //    dir_gap = 'r';
  //  }

  ///////////////////////////////////////////////////
  if (d_c == 1 and d_r1 == 1)
  {
    motor(speed, speed * .7, 0);
  }
  else if (d_l1 == 1 and d_c == 1)
  {
    motor(speed * .7, speed, 0);
  }

  //  else if ((d_sil_l2 or d   _sil_l1 or d_sil_r1 or d_sil_r2) and d_c)
  //  {
  //    motor(speed * .5 , speed * .5, 0);
  //  }

  else if (d_c)
  {
    motor(speed * 0.7, speed * 0.7, 0);
  }

  /////////////////////////////////////////////////

  else if (d_r1 == 1)
  {
    motor(speed, -speed * 0.4, 0);
  }
  else if (d_l1 == 1)
  {
    motor(-speed * 0.4, speed, 0);
  }
  /////////////////////////////////////////////////

  else if (d_r2)
  {
    motor(speed, -speed * .8, 0);
  }
  else if (d_l2)
  {
    motor(-speed * .8, speed, 0);
  }
  //
  //  /////////////////////////////////////////////////
  //
  else if (d_r3 == 1)
  {
    motor(speed, -speed, 0);
  }
  else if (d_l3 == 1)
  {
    motor(-speed, speed, 0);
  }

  //////////////////////////////////////////////

  else if (d_r4 == 1)
  {
    t_r = millis();

    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .3, speed * .3, 0); // str
    }
    else
    {
      motor(speed, -speed * 1.2, 0);
    }
  }

  else if (d_l4 == 1)
  {
    t_l = millis();
    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .3, speed * .3, 0); // str
    }
    else
    {
      motor(-speed * 1.2, speed, 0);
    }
  }

  // for time no act or gap

  //  //////////////////////////////////////////////
  //
  else if (d_r5 == 1)
  {
    t_r = millis();
    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .3, speed * .3, 0); // str
    }
    else
      motor(speed * 1.1, -speed * 1.3, 0);
  }

  else if (d_l5 == 1)
  {
    t_l = millis();

    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .3, speed * .3, 0); // str
    }
    else
      motor(-speed * 1.3, speed * 1.1, 0);
  }

  //
  //  ///////////////////////////////////
  //
  else if (d_r6 == 1)
  {
    t_r = millis();
    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .3, speed * .3, 0); // str
    }
    else
      motor(speed, -speed * 1.5, 0);
  }

  else if (d_l6 == 1)
  {
    t_l = millis();
    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .3, speed * .3, 0); // str
    }
    else
      motor(-speed * 1.5, speed, 0);
  }

  //
  //  ///////////////////////////////
  //
  else if (d_r7 == 1)
  {
    t_r = millis();
    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .3, speed * .3, 0); // str
    }
    else
      motor(speed * 1.1, -speed * 1.6, 0);
  }

  ////////////////////////////////////////////

  else if (d_l7 == 1)
  {
    t_r = millis();
    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .3, speed * .3, 0); // str
    }
    else
      motor(-speed * 1.6, speed * 1.1, 0);
  }

  //  ///////////////////////////////
  else if (d_r8 == 1)
  {

    t_r = millis();
    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .3, speed * .3, 0); // str
    }
    else
    {
      motor(speed * 1.1, -speed * 1.6, 0);
      delay(300);
    }
  }

  else if (d_l8 == 1)
  {
    t_l = millis();
    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .3, speed * .3, 0); // str
    }
    else
    {
      motor(-speed * 1.6, speed * 1.2, 0);
      delay(300);
    }
  }

  ///////////////////////////////

  else if (d_r9 == 1)
  {

    t_r = millis();
    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .3, speed * .3, 0); // str
    }
    else
    {
      motor(speed * 1.2, -speed * 1.6, 0);
      delay(300);
    }
  }

  else if (d_l9 == 1)
  {
    t_l = millis();

    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .3, speed * .3, 0); // str
    }
    else
    {
      motor(-speed * 1.6, speed * 1.2, 0);
      delay(300);
    }
  }

  ///////////////////////////////

  else if (d_r10 == 1)
  {
    t_r = millis();
    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .3, speed * .3, 0); // str
    }
    else
    {
      motor(speed * 1.3, -speed * 1.6, 0);
      delay(300);
    }
  }
  else if (d_l10 == 1)
  {
    t_l = millis();
    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .3, speed * .3, 0); // str
    }
    else
    {
      motor(-speed * 1.6, speed * 1.3, 0);
      delay(300);
    }
  }
  /////////////////////////////////////////// gapppppppppp

  if (d_l8 == 0 && d_l7 == 0 && d_l6 == 0 && d_l5 == 0 && d_l4 == 0 && d_l3 == 0 && d_l2 == 0 && d_l1 == 0 && d_c == 0 && d_r1 == 0 && d_r2 == 0 && d_r3 == 0 && d_r4 == 0 && d_r5 == 0 && d_r6 == 0 && d_r7 == 0 && d_r8 == 0)
  {
    if (flag_gap == 0)
    {
      flag_gap = 1;
      enc_read();
    }

    if (enc_l() >= 500 or enc_r() >= 500)
    {
      if (flag_no_line_follower_gap == 0)
      {
        // tft.fillScreen(WHITE);
        flag_no_line_follower_gap = 1;
      }
      motor(speed * .2, speed * .2, 0); // atten
      // line_follower_gap(1000);

      if (enc_l() >= 4500 or enc_r() >= 4500)
      {
        dont_lose_line(speed);
        motor(speed, speed);
      }
    }
  }

  else
  {
    // if (flag_no_line_follower_gap == 1)
    // {
    //   tft.fillScreen(BLACK);
    //   flag_no_line_follower_gap = 0;
    // }

    flag_gap = 0;
  }
}

//******************************************************

void line_follower_up(int speed) // when the robot is on a ramp
{
  unsigned long int time_no_act = 200;

  //  if (d_sil_l2  or d_sil_l1 )
  //  {
  //    dir_gap = 'l';
  //  }
  //  else if (d_sil_r1  or d_sil_r2 )
  //  {
  //    dir_gap = 'r';
  //  }

  ///////////////////////////////////////////////////

  if (d_c == 1 and d_r1 == 1)
  {
    motor(speed, speed * .8, 0);
  }
  else if (d_l1 == 1 and d_c == 1)
  {
    motor(speed * .8, speed, 0);
  }

  //  else if ((d_sil_l2 or d   _sil_l1 or d_sil_r1 or d_sil_r2) and d_c)
  //  {
  //    motor(speed * .5 , speed * .5, 0);
  //  }

  else if (d_c)
  {
    motor(speed, speed, 0);
  }

  /////////////////////////////////////////////////

  else if (d_r1 == 1)
  {
    motor(speed, 0, 0);
  }
  else if (d_l1 == 1)
  {
    motor(0, speed, 0);
  }
  /////////////////////////////////////////////////

  else if (d_r2)
  {
    motor(speed, -speed * .1, 0);
  }
  else if (d_l2)
  {
    motor(-speed * .1, speed, 0);
  }
  //
  //  /////////////////////////////////////////////////
  //
  else if (d_r3 == 1)
  {
    motor(speed, -speed * 0.3, 0);
  }
  else if (d_l3 == 1)
  {
    motor(-speed * 0.3, speed, 0);
  }

  //////////////////////////////////////////////

  else if (d_r4 == 1)
  {
    t_r = millis();

    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
    {
      motor_ramp(speed * 1.2, -speed * .3);
    }
  }

  else if (d_l4 == 1)
  {
    t_l = millis();
    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
    {
      motor_ramp(-speed * .3, speed * 1.2);
    }
  }

  // for time no act or gap

  //  //////////////////////////////////////////////
  //
  else if (d_r5 == 1)
  {
    t_r = millis();
    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor_ramp(speed * 1.2, -speed * .4);
  }

  else if (d_l5 == 1)
  {
    t_l = millis();

    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor_ramp(-speed * .4, speed * 1.2);
  }

  //
  //  ///////////////////////////////////
  //
  else if (d_r6 == 1)
  {
    t_r = millis();
    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor_ramp(speed * 1.2, -speed * .6);
  }

  else if (d_l6 == 1)
  {
    t_l = millis();
    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor_ramp(-speed * .6, speed * 1.2);
  }

  //
  //  ///////////////////////////////
  //
  else if (d_r7 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
        motor_ramp(speed * 1.2, -speed * .6);
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  ////////////////////////////////////////////

  else if (d_l7 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
        motor_ramp(-speed * .6, speed * 1.2);
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  //  ///////////////////////////////
  else if (d_r8 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(speed * 1.3, -speed, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  else if (d_l8 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_l = millis();
      if ((t_l - t_r) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(-speed, speed * 1.3, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  ///////////////////////////////

  else if (d_r9 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(speed * 1.3, -speed, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  else if (d_l9 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_l = millis();

      if ((t_l - t_r) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(-speed, speed * 1.3, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  ///////////////////////////////

  else if (d_r10 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(speed * 1.3, -speed, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }
  else if (d_l10 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_l = millis();
      if ((t_l - t_r) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
      {
        motor(-speed, speed * 1.3, 0);
        delay(150);
      }
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  /////////////////////////////////////////// gapppppppppp

  if (d_l8 == 0 && d_l7 == 0 && d_l6 == 0 && d_l5 == 0 && d_l4 == 0 && d_l3 == 0 && d_l2 == 0 && d_l1 == 0 && d_c == 0 && d_r1 == 0 && d_r2 == 0 && d_r3 == 0 && d_r4 == 0 && d_r5 == 0 && d_r6 == 0 && d_r7 == 0 && d_r8 == 0)
  {
    if (flag_gap == 0)
    {
      flag_gap = 1;
      enc_read();
    }

    if (enc_l() >= 700 or enc_r() >= 700)
    {
      if (millis() - t_gap < 250)
      {
        motor(90, 40);
      }
      else if (millis() - t_gap < 500)
      {
        motor(40, 90);
      }
      else
      {
        t_gap = millis();
      }
    }
  }

  else
  {
    flag_gap = 0;
  }
}

//******************************************************

void line_follower_down(int speed) // when the robot is on a ramp
{
  unsigned long int time_no_act = 200;

  //  if (d_sil_l2  or d_sil_l1 )
  //  {
  //    dir_gap = 'l';
  //  }
  //  else if (d_sil_r1  or d_sil_r2 )
  //  {
  //    dir_gap = 'r';
  //  }

  ///////////////////////////////////////////////////

  //  else if ((d_sil_l2 or d   _sil_l1 or d_sil_r1 or d_sil_r2) and d_c)
  //  {
  //    motor(speed * .5 , speed * .5, 0);
  //  }

  // if (d_c) {
  //   motor(speed * 0.8, speed * 0.8, 0);
  // }

  /////////////////////////////////////////////////

  //  if (d_sil_l2  or d_sil_l1 )
  //  {
  //    dir_gap = 'l';
  //  }
  //  else if (d_sil_r1  or d_sil_r2 )
  //  {
  //    dir_gap = 'r';
  //  }

  ///////////////////////////////////////////////////

  if (d_c == 1 and d_r1 == 1)
  {
    motor_ramp(speed, speed * .8, 0.5, 0);
  }
  else if (d_l1 == 1 and d_c == 1)
  {
    motor_ramp(speed * .8, speed, 0.5, 0);
  }

  //  else if ((d_sil_l2 or d   _sil_l1 or d_sil_r1 or d_sil_r2) and d_c)
  //  {
  //    motor(speed * .5 , speed * .5, 0);
  //  }

  else if (d_c)
  {
    motor_ramp(speed * 0.8, speed * 0.8, 0.2, 0);
  }

  /////////////////////////////////////////////////

  else if (d_r1 == 1)
  {
    motor_ramp(speed * 0.6, -speed * 1.2, 1.2, 0);
  }
  else if (d_l1 == 1)
  {
    motor_ramp(-speed * 1.2, speed * 0.6, 1.2, 0);
  }
  /////////////////////////////////////////////////

  else if (d_r2)
  {
    motor_ramp(speed * 0.7, -speed * 1.4, 1.2, 0);
  }
  else if (d_l2)
  {
    motor_ramp(-speed * 1.4, speed * 0.7, 1.2, 0);
  }
  //
  //  /////////////////////////////////////////////////
  //
  else if (d_r3 == 1)
  {
    motor_ramp(speed * 0.8, -speed * 1.5, 1.2, 0);
  }
  else if (d_l3 == 1)
  {
    motor_ramp(-speed * 1.5, speed * 0.8, 1.2, 0);
  }

  //////////////////////////////////////////////

  else if (d_r4 == 1)
  {

    t_r = millis();

    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
    {
      motor_ramp(speed * 0.8, -speed * 1.4, 1.2, 0);
    }
  }

  else if (d_l4 == 1)
  {
    t_l = millis();
    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
    {
      motor_ramp(-speed * 1.4, speed * 0.8, 1.2, 0);
    }
  }

  // for time no act or gap

  //  //////////////////////////////////////////////
  //
  else if (d_r5 == 1)
  {
    t_r = millis();
    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor_ramp(speed, -speed * 1.3, 0.2, 0);
  }

  else if (d_l5 == 1)
  {
    t_l = millis();

    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor_ramp(-speed * 1.3, speed, 0.2, 0);
  }

  //
  //  ///////////////////////////////////
  //
  else if (d_r6 == 1)
  {
    t_r = millis();
    if ((t_r - t_l) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor_ramp(speed, -speed * 1.4, 0.2, 0);
  }

  else if (d_l6 == 1)
  {

    t_l = millis();
    if ((t_l - t_r) < time_no_act)
    {

      motor(speed * .5, speed * .5, 0); // str
    }
    else
      motor_ramp(-speed * 1.4, speed, 0.2, 0);
  }

  //
  //  ///////////////////////////////
  //
  else if (d_r7 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
        motor_ramp(speed, -speed * 1.5, 0.2, 0);
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  ////////////////////////////////////////////

  else if (d_l7 == 1)
  {
    if (d_m_l1 == 0 and d_m_c == 0 and d_m_r1 == 0 && d_m_r2 == 0 && d_m_l2 == 0)
    {
      t_r = millis();
      if ((t_r - t_l) < time_no_act)
      {

        motor(speed * .5, speed * .5, 0); // str
      }
      else
        motor_ramp(-speed * 1.5, speed, 0.2, 0);
    }
    else
    {
      flag_small_gap = 1;
      motor(speed / 2, speed / 2);
    }
  }

  //  ///////////////////////////////

  /////////////////////////////////////////// gapppppppppp

  if (d_l8 == 0 && d_l7 == 0 && d_l6 == 0 && d_l5 == 0 && d_l4 == 0 && d_l3 == 0 && d_l2 == 0 && d_l1 == 0 && d_c == 0 && d_r1 == 0 && d_r2 == 0 && d_r3 == 0 && d_r4 == 0 && d_r5 == 0 && d_r6 == 0 && d_r7 == 0 && d_r8 == 0)
  {
    if (flag_gap == 0)
    {
      flag_gap = 1;
      enc_read();
    }

    if (enc_l() >= 700 or enc_r() >= 700)
    {
      motor(speed * .2, speed * .2, 0); // atten

      if (enc_l() >= 4700 or enc_r() >= 4700)
      {
        dont_lose_line(speed);
        motor(speed, speed);
      }
    }
  }

  else
  {
    flag_gap = 0;
  }
}

//******************************************************

void framWriteEnable()
{
  spi.beginTransaction(framSPI);
  digitalWrite(FRAM_CS, LOW);
  spi.transfer(WREN);
  digitalWrite(FRAM_CS, HIGH);
  spi.endTransaction();
}

//******************************************************

void framWrite(uint16_t address, uint16_t value)
{
  framWriteEnable();

  spi.beginTransaction(framSPI);
  digitalWrite(FRAM_CS, LOW);

  spi.transfer(WRITE);
  spi.transfer((address >> 8) & 0xFF);
  spi.transfer(address & 0xFF);
  spi.transfer((value >> 8) & 0xFF);
  spi.transfer(value & 0xFF);

  digitalWrite(FRAM_CS, HIGH);
  spi.endTransaction();
}

//******************************************************

uint16_t framRead(uint16_t address)
{
  spi.beginTransaction(framSPI);
  digitalWrite(FRAM_CS, LOW);

  spi.transfer(READ);
  spi.transfer((address >> 8) & 0xFF);
  spi.transfer(address & 0xFF);
  uint8_t highByte = spi.transfer(0x00);
  uint8_t lowByte = spi.transfer(0x00);

  digitalWrite(FRAM_CS, HIGH);
  spi.endTransaction();

  return ((uint16_t)highByte << 8) | lowByte;
}

//******************************************************

float Abs(float x)
{
  return (x < 0) ? x * -1 : x;
}

//******************************************************
void setup_silver()
{
  static int n = 0;

  read_eeprom_setting();

  tft.fillScreen(BLACK);

  tft.setTextSize(2);
  tft.setTextColor(WHITE, RED);
  tft.setCursor(5, 2);
  tft.print("setup silver");

  //////////

  while (1)
  {
    tft.setTextSize(1);
    tft.setTextColor(WHITE, BLUE);
    tft.setCursor(5, 25);
    tft.print("BR=Set");

    tft.setCursor(5, 35);
    tft.print("BL=BK");

    tft.setCursor(110, 35);
    tft.print("BD=Next");

    tft.setTextSize(1);
    tft.setTextColor(WHITE, BLUE);
    tft.setCursor(5, 120);
    tft.print("LB=Dec             RB=Inc");

    /////////////

    tft.setTextSize(1);
    tft.setTextColor(YELLOW, BLACK);

    sprintf(text, "sil_l1=%-4d eep_l1=%-4d", a_sil_l1, sil_l1_eep);
    tft.setCursor(20, 50);
    tft.print(text);

    sprintf(text, "sil_l2=%-4d eep_l2=%-4d", a_sil_l2, sil_l2_eep);
    tft.setCursor(20, 60);
    tft.print(text);

    sprintf(text, "sil_r1=%-4d eep_r1=%-4d", a_sil_r1, sil_r1_eep);
    tft.setCursor(20, 70);
    tft.print(text);

    sprintf(text, "sil_r2=%-4d eep_r2=%-4d", a_sil_r2, sil_r2_eep);
    tft.setCursor(20, 80);
    tft.print(text);

    /////////////////////////////////////////////////////

    if (but_d == 0)
    {
      n++;
      if (n > 3)
        n = 0;

      buz(50);
      // delay(1);
      tft.fillRect(0, 50, 10, 70, BLACK);
    }
    ///////////////////

    if (check_silver() == 1)
    {
      tft.setTextSize(2);
      tft.setTextColor(BLUE, WHITE);
      tft.setCursor(25, 95);
      tft.print(" Silver=");
      tft.print(flag_sil);
    }
    else
    {
      tft.setTextSize(2);
      tft.setTextColor(BLUE, WHITE);
      tft.setCursor(25, 95);
      tft.print("          ");
    }

    //////////////////////////////////

    tft.setTextSize(1);
    tft.setTextColor(WHITE, RED);
    tft.setCursor(0, 50 + n * 10); // jaye flash
    tft.print(">");

    /////////////////////////////

    if (n == 0)
    {
      if (mic_rb == 0)
        sil_l1_eep += 5;
      else if (mic_lb == 0)
        sil_l1_eep -= 5;
    }
    else if (n == 1)
    {
      if (mic_rb == 0)
        sil_l2_eep += 5;
      else if (mic_lb == 0)
        sil_l2_eep -= 5;
    }
    else if (n == 2)
    {
      if (mic_rb == 0)
        sil_r1_eep += 5;
      else if (mic_lb == 0)
        sil_r1_eep -= 5;
    }
    else if (n == 3)
    {
      if (mic_rb == 0)
        sil_r2_eep += 5;
      else if (mic_lb == 0)
        sil_r2_eep -= 5;
    }

    /////////////////////////

    if (but_r == 0) // set
    {
      tft.fillScreen(SILVER);
      tft.setTextSize(2);
      tft.setTextColor(BLACK, SILVER);

      tft.setCursor(60, 10);
      tft.print(" SET ");

      if (n == 0)
      {

        framWrite(sil_l1_eep_cell, sil_l1_eep);

        tft.setCursor(10, 50);
        tft.print(" < Left_1 ");
      }

      else if (n == 1)
      {
        framWrite(sil_l2_eep_cell, sil_l2_eep);

        tft.setCursor(10, 50);
        tft.print(" < Left_2 ");
      }
      else if (n == 2)
      {

        framWrite(sil_r1_eep_cell, sil_r1_eep);

        tft.setCursor(10, 50);
        tft.print(" Right_1 > ");
      }
      else if (n == 3)
      {

        framWrite(sil_r2_eep_cell, sil_r2_eep);

        tft.setCursor(10, 50);
        tft.print(" Right_2 > ");
      }

      /////////////

      read_eeprom_setting();

      buz(500);
      tft.fillScreen(BLACK);
    }

    /////////////////////////

    if (but_l == 0)
    {
      menu_2();
      break;
    }
  }
}

//******************************************************

void setup_ir_mic()
{
  tft.fillScreen(BLACK);
  tft.setTextSize(1);
  tft.setTextColor(YELLOW, BLACK);
  tft.setCursor(20, 2);
  tft.print("Setup ir mic");

  //////////////////////////////////////

  while (1)
  {

    // distance_all();

    // if (vl_distance(2) < 150) {
    //   motor(-80, -80);
    // } else {
    //   motor(50, 50);
    // }
    tft.setTextSize(1);
    tft.setTextColor(YELLOW, BLACK);

    sprintf(text, "Resana:%d", resana);
    tft.setCursor(10, 30);
    tft.print(text);

    sprintf(text, "%4d", a_resana);
    tft.setCursor(100, 30);
    tft.print(text);

    /////////////////////////////////////////////////////

    sprintf(text, "ir_ball:%d", ir_ball);
    tft.setCursor(10, 50);
    tft.print(text);

    /////////////////////////////////////////////////////

    sprintf(text, "%4d", a_ir_ball);
    tft.setCursor(100, 50);
    tft.print(text);

    // /////////////////////////////////////////////////////

    sprintf(text, "ir_obs:%d", ir_obs);
    tft.setCursor(10, 70);
    tft.print(text);

    /////////////////////////////////////////////////////

    sprintf(text, "%4d", a_ir_obs);
    tft.setCursor(100, 70);
    tft.print(text);

    tft.drawLine(85, 30, 85, 100, RED);

    /////////////////////////////////////////////////////

    if (but_l == 0)
    {
      main_menu();
      break;
    }
  }
}

//******************************************************

void setup_ir_analog()
{
  tft.fillScreen(BLACK);

  /////////////////////////////

  tft.setTextSize(1);
  tft.setTextColor(YELLOW, BLACK);

  while (1)
  {
    yield();
    sprintf(text, "%-4d %-4d  sil  %-4d %-4d", a_sil_l2, a_sil_l1, a_sil_r1, a_sil_r2);
    tft.setCursor(0, 5);
    tft.print(text);

    sprintf(text, "%  -4d %-4d %-4d %-4d %-4d", a_l2, a_l1, a_c, a_r1, a_r2);
    tft.setCursor(5, 25);
    tft.print(text);

    sprintf(text, "   %-4d     3     %-4d   ", a_l3, a_r3);
    tft.setCursor(0, 35);
    tft.print(text);

    sprintf(text, "  %-4d      4      %-4d  ", a_l4, a_r4);
    tft.setCursor(0, 45);
    tft.print(text);

    sprintf(text, " %-4d       5       %-4d ", a_l5, a_r5);
    tft.setCursor(0, 55);
    tft.print(text);

    sprintf(text, "%-4d        6        %-4d", a_l6, a_r6);
    tft.setCursor(0, 65);
    tft.print(text);

    sprintf(text, "%-4d        7        %-4d", a_l7, a_r7);
    tft.setCursor(0, 75);
    tft.print(text);

    sprintf(text, "%-4d        8        %-4d", a_l8, a_r8);
    tft.setCursor(0, 85);
    tft.print(text);

    sprintf(text, "%-4d        9        %-4d", a_l9, a_r9);
    tft.setCursor(0, 95);
    tft.print(text);

    sprintf(text, "%-4d        10       %-4d", a_l10, a_r10);
    tft.setCursor(0, 105);
    tft.print(text);

    if (but_l == 0)
    {
      main_menu();
      break;
    }
  }
}

//******************************************************

void setup_ir_analog_middle()
{
  tft.fillScreen(BLACK);

  /////////////////////////////

  tft.setTextSize(1);
  tft.setTextColor(GREEN, BLACK);

  while (1)
  {
    yield();
    tft.setCursor(0, 5);
    tft.setTextColor(WHITE, BLUE);
    tft.print(" Setup ir middle and back");

    tft.setTextColor(YELLOW, BLACK);

    sprintf(text, "%-4d %-4d %-4d", a_m_l1, a_m_c, a_m_r1);
    tft.setCursor(40, 25);
    tft.print(text);

    sprintf(text, "%-4d %-4d", a_m_l3, a_m_l2);
    tft.setCursor(10, 40);
    tft.print(text);

    sprintf(text, "%-4d %-4d", a_m_r2, a_m_r3);
    tft.setCursor(100, 40);
    tft.print(text);

    tft.drawLine(0, 55, 160, 55, RED);

    sprintf(text, "      error down: %-3d   ", error_ir_down());
    tft.setCursor(0, 60);
    tft.print(text);

    sprintf(text, "      error mid: %-3d  ", error_ir_mid());
    tft.setCursor(0, 70);
    tft.print(text);

    tft.drawLine(0, 83, 160, 83, RED);

    sprintf(text, "%-4d %-4d %-4d", a_b_l1, a_b_c, a_b_r1);
    tft.setCursor(40, 95);
    tft.print(text);

    sprintf(text, "%-4d %-4d", a_b_l3, a_b_l2);
    tft.setCursor(10, 110);
    tft.print(text);

    sprintf(text, "%-4d %-4d", a_b_r2, a_b_r3);
    tft.setCursor(100, 110);
    tft.print(text);

    delay(100);
    if (but_l == 0)
    {
      main_menu();
      break;
    }
  }
}

//******************************************************

void setup_mic()
{
  tft.fillScreen(BLACK);
  tft.setTextSize(1);
  tft.setTextColor(YELLOW, BLACK);
  tft.setCursor(35, 2);
  tft.setTextSize(2);
  tft.print("Setup mic");

  //////////////////////////////////////

  while (1)
  {

    // distance_all();  //noon khamenei  ba taam basiji

    // if (vl_distance(2) < 150) {
    //   motor(-80, -80);
    // } else {
    //   motor(50, 50);
    // }
    tft.setTextSize(1);
    tft.setTextColor(YELLOW, BLACK);

    if (but_l == 1)
      tft.fillCircle(60, 65, 7, RED);
    else
      tft.fillCircle(60, 65, 7, GREEN);

    if (but_r == 1)
      tft.fillCircle(100, 65, 7, RED);
    else
      tft.fillCircle(100, 65, 7, GREEN);

    if (but_u == 1)
      tft.fillCircle(80, 45, 7, RED);
    else
      tft.fillCircle(80, 45, 7, GREEN);

    if (but_d == 1)
      tft.fillCircle(80, 85, 7, RED);
    else
      tft.fillCircle(80, 85, 7, GREEN);
    if (mic_lb == 1)
      tft.fillRoundRect(10, 105, 35, 15, 5, RED);
    else
      tft.fillRoundRect(10, 105, 35, 15, 5, GREEN);

    if (mic_rb == 1)
      tft.fillRoundRect(115, 105, 35, 15, 5, RED);
    else
      tft.fillRoundRect(115, 105, 35, 15, 5, GREEN);

    if (mic_lf == 1)
      tft.fillRoundRect(10, 25, 25, 15, 5, RED);
    else
      tft.fillRoundRect(10, 25, 25, 15, 5, GREEN);

    if (mic_rf == 1)
      tft.fillRoundRect(125, 25, 25, 15, 5, RED);
    else
      tft.fillRoundRect(125, 25, 25, 15, 5, GREEN);
    //////////////////////////////////////

    if (mic_rb == 0 and mic_lb == 0)
    {
      menu_2();
      break;
    }
  }
}

//******************************************************

void setup_dynam()
{
  static int n = 0;
  static uint grip_l_deg = 2048, grip_r_deg = 2048, joft_grip = 2048, sep_degree = sep_silver, Box_deg = Box_down, bazoo_1_deg = arm_1_normal, bazoo_2_deg = arm_2_normal;

  dxl.torqueOn(box);
  dxl.torqueOn(sep_id);

  tft.setTextSize(1);
  tft.setTextColor(WHITE, BLUE);

  tft.setCursor(50, 2);
  tft.print("dynamixel");

  tft.setTextColor(WHITE, RED);

  tft.setCursor(45, 14);
  tft.print("BK: but l <-");

  tft.setTextColor(YELLOW, BLACK); // aval galb galb
  tft.setTextSize(1);

  sprintf(text, "grip_L=%-4d", grip_l_deg);
  tft.setCursor(20, 30);
  tft.print(text);

  sprintf(text, "grip_R=%-4d", grip_r_deg);
  tft.setCursor(20, 40);
  tft.print(text);

  sprintf(text, "joft grip=%-4d", joft_grip);
  tft.setCursor(20, 50);
  tft.print(text);

  sprintf(text, "sep=%-4d", sep_degree);
  tft.setCursor(20, 60);
  tft.print(text);

  sprintf(text, "Box=%-4d", Box_deg);
  tft.setCursor(20, 70);
  tft.print(text);

  sprintf(text, "arm_1=%-4d", bazoo_1_deg);
  tft.setCursor(20, 80);
  tft.print(text);

  sprintf(text, "arm_2=%-4d", bazoo_2_deg);
  tft.setCursor(20, 90);
  tft.print(text);

  while (1)
  {

    if (but_d == 0)
    {
      delay(150);
      n++;
      if (n >= 7)
        n = 0;
      tft.fillRect(0, 0, 12, 128, BLACK);
    }

    if (but_u == 0)
    {
      delay(150);
      n--;
      if (n < 0)
        n = 6;
      tft.fillRect(0, 0, 10, 128, BLACK);
    }
    tft.setTextColor(WHITE, RED);
    tft.setCursor(0, 30 + n * 10); // jaye flash
    tft.print(">");
    tft.setTextColor(YELLOW, BLACK);

    if (n == 0)
    {
      if (mic_rb == 0)
      {
        delay(1);
        if (mic_rb == 0)
        {
          grip_l_deg += 15;
          grip_l(350, grip_l_deg, 0);
        }
      }

      if (mic_lb == 0)
      {
        delay(1);
        if (mic_lb == 0)
        {
          grip_l_deg -= 15;
          grip_l(350, grip_l_deg, 0);
        }
      }
      sprintf(text, "grip_L=%-4d", grip_l_deg);
      tft.setCursor(20, 30);
      tft.print(text);
    }
    if (n == 1)
    {
      if (mic_rb == 0)
      {
        delay(1);
        if (mic_rb == 0)
        {
          grip_r_deg += 15;
          grip_r(350, grip_r_deg, 0);
        }
      }

      if (mic_lb == 0)
      {
        delay(1);
        if (mic_lb == 0)
        {
          grip_r_deg -= 15;
          grip_r(350, grip_r_deg, 0);
        }
      }

      sprintf(text, "grip_R=%-4d", grip_r_deg);
      tft.setCursor(20, 40);
      tft.print(text);
    }
    if (n == 2)
    {
      if (mic_rb == 0)
      {
        delay(1);
        if (mic_rb == 0)
        {
          joft_grip += 15;
          grip_l(350, 4096 - joft_grip, 0);
          grip_r(350, joft_grip, 0);
        }
      }

      if (mic_lb == 0)
      {
        delay(1);
        if (mic_lb == 0)
        {
          joft_grip -= 15;
          grip_l(350, 4096 - joft_grip, 0);
          grip_r(350, joft_grip, 0);
        }
      }
      sprintf(text, "joft grip=%-4d", joft_grip);
      tft.setCursor(20, 50);
      tft.print(text);
    }
    if (n == 3)
    {
      if (mic_rb == 0)
      {
        delay(1);
        if (mic_rb == 0)
        {
          sep_degree += 15;
          separator(350, sep_degree, 0);
        }
      }

      if (mic_lb == 0)
      {
        delay(1);
        if (mic_lb == 0)
        {
          sep_degree -= 15;
          separator(350, sep_degree, 0);
        }
      }
      sprintf(text, "sep=%-4d", sep_degree);
      tft.setCursor(20, 60);
      tft.print(text);
    }
    if (n == 4)
    {
      if (mic_rb == 0)
      {
        delay(1);
        if (mic_rb == 0)
        {
          Box_deg += 15;
          Box(350, Box_deg, 0);
        }
      }

      if (mic_lb == 0)
      {
        delay(1);
        if (mic_lb == 0)
        {
          Box_deg -= 15;
          Box(350, Box_deg, 0);
        }
      }
      sprintf(text, "Box=%-4d", Box_deg);
      tft.setCursor(20, 70);
      tft.print(text);
    }
    if (n == 5)
    {
      if (mic_rb == 0)
      {
        delay(1);
        if (mic_rb == 0)
        {
          bazoo_1_deg += 15;
          arm_xc(350, bazoo_1_deg, 0);
        }
      }

      if (mic_lb == 0)
      {
        delay(1);
        if (mic_lb == 0)
        {
          bazoo_1_deg -= 15;
          arm_xc(350, bazoo_1_deg, 0);
        }
      }
      sprintf(text, "arm_1=%-4d", bazoo_1_deg);
      tft.setCursor(20, 80);
      tft.print(text);
    }
    if (n == 6)
    {
      if (mic_rb == 0)
      {
        delay(1);
        if (mic_rb == 0)
        {
          bazoo_2_deg += 15;
          arm_xl(350, bazoo_2_deg, 0);
        }
      }

      if (mic_lb == 0)
      {
        delay(1);
        if (mic_lb == 0)
        {
          bazoo_2_deg -= 15;
          arm_xl(350, bazoo_2_deg, 0);
        }
      }
      sprintf(text, "arm_2=%-4d", bazoo_2_deg);
      tft.setCursor(20, 90);
      tft.print(text);
    }

    if (but_l == 0)
    {
      dxl.torqueOff(box);
      dxl.torqueOff(sep_id);
      main_menu();
      break;
    }
  }
}

//******************************************************

void setup_ir_dig()
{
  tft.setTextSize(1);
  tft.setTextColor(YELLOW, BLACK);

  while (1)
  {

    if (ramp_up or ramp_down or ramp_right or ramp_left)
    {
      extra_ramp = 50;
    }
    else
    {
      extra_ramp = 0;
    }
    sprintf(text, "%d%d                      %d%d", d_sil_l2, d_sil_l1, d_sil_r1, d_sil_r2);
    tft.setCursor(0, 10);
    tft.print(text);

    sprintf(text, "    %d %d %d _ %d _ %d %d %d     ", d_l3, d_l2, d_l1, d_c, d_r1, d_r2, d_r3);
    tft.setCursor(0, 20);
    tft.print(text);

    sprintf(text, "   %d        4        %d    ", d_l4, d_r4);
    tft.setCursor(0, 30);
    tft.print(text);

    sprintf(text, "  %d         5         %d   ", d_l5, d_r5);
    tft.setCursor(0, 40);
    tft.print(text);

    sprintf(text, " %d    %d%d%d   %d   %d%d%d    %d", d_l6, d_m_l3, d_m_l2, d_m_l1, d_m_c, d_m_r1, d_m_r2, d_m_r3, d_r6);
    tft.setCursor(0, 50);
    tft.print(text);

    sprintf(text, "%d           7            %d ", d_l7, d_r7);
    tft.setCursor(0, 60);
    tft.print(text);

    sprintf(text, "%d           8            %d", d_l8, d_r8);
    tft.setCursor(0, 70);
    tft.print(text);

    sprintf(text, "%d           9            %d", d_l9, d_r9);
    tft.setCursor(0, 80);
    tft.print(text);

    sprintf(text, "%d     %d%d%d   %d   %d%d%d      %d", d_l10, d_b_l3, d_b_l2, d_b_l1, d_b_c, d_b_r1, d_b_r2, d_b_r3, d_r10);
    tft.setCursor(0, 90);
    tft.print(text);

    if (but_l == 0)
    {
      main_menu();
      break;
    }
  }
}

//******************************************************

void setup_obstacle()
{
  static int n = 0;

  read_eeprom_setting();

  tft.fillScreen(BLACK);
  tft.setTextColor(WHITE, BLACK);
  tft.setTextSize(1);

  sprintf(text, "str_1_turn=%-4d ", str_1_turn_eep);
  tft.setCursor(20, 60);
  tft.print(text);

  sprintf(text, "str_2_turn=%-4d ", str_2_turn_eep);
  tft.setCursor(20, 70);
  tft.print(text);

  sprintf(text, "turn_45=%3d", deg_45_eep);
  tft.setCursor(20, 80);
  tft.print(text);

  sprintf(text, "arc_low=%3d", arc_low_eep);
  tft.setCursor(20, 90);
  tft.print(text);

  sprintf(text, "arc_high=%3d", arc_high_eep);
  tft.setCursor(20, 100);
  tft.print(text);

  sprintf(text, "do act obstacle");
  tft.setCursor(20, 110);
  tft.print(text);

  motor(0, 0);

  while (1)
  {
    tft.setTextSize(2);
    tft.setTextColor(WHITE, RED);
    tft.setCursor(30, 5);
    tft.print("OBSTACLE");

    tft.setTextSize(1);
    tft.setTextColor(WHITE, BLUE);
    tft.setCursor(90, 45);
    tft.print("b R=Set");

    tft.setCursor(25, 45);
    tft.print("b L=Back");

    tft.setTextColor(WHITE, BLUE);
    tft.setCursor(90, 120);
    tft.print("LB=dec");

    tft.setCursor(25, 120);
    tft.print("RB=inc");

    sprintf(text, "%4d,%4d  IR  %4d,%4d", a_sil_l2, a_sil_l1, a_sil_r1, a_sil_r2);
    tft.setCursor(5, 30);
    tft.print(text);

    ////////////////////

    if (but_d == 0)
    {
      n++;
      if (n >= 6)
      {
        n = 0;
      }
      tft.fillRect(0, 40, 20, 127, BLACK);
      buz(50);
      delay(100);
    }
    if (but_u == 0)
    {
      n--;
      if (n < 0)
      {
        n = 5;
      }

      tft.fillRect(0, 40, 20, 127, BLACK);
      buz(50);
      delay(100);
    }

    ///////////////////

    tft.setTextColor(WHITE, RED);
    tft.setCursor(2, 60 + n * 10); // jaye flash
    tft.print(">");

    ///////////////

    tft.setTextColor(WHITE, BLACK);

    ///////////////

    if (n == 0)
    {
      if (mic_rf == 0)
      {
        delay(10);

        if (str_1_turn_eep < 20000)
          str_1_turn_eep += 30;
      }

      if (mic_lf == 0)
      {
        delay(10);

        if (str_1_turn_eep > 100)
          str_1_turn_eep -= 30;
      }
      sprintf(text, "str_1_turn=%-4d ", str_1_turn_eep);
      tft.setCursor(20, 60);
      tft.print(text);

      if (mic_rb == 0) // test
      {
        framWrite(str_1_turn_eep_cell, str_1_turn_eep);

        motor_el(100, 100, str_1_turn_eep, 200);

        stop(100);
        buz(1000);
      }
    }

    //////////////////

    else if (n == 1)
    {
      if (mic_rf == 0)
      {
        delay(10);

        if (str_2_turn_eep < 20000)
          str_2_turn_eep += 30;
      }

      if (mic_lf == 0)
      {
        delay(10);

        if (str_2_turn_eep > 50)
          str_2_turn_eep -= 30;
      }
      sprintf(text, "str_2_turn=%-4d ", str_2_turn_eep);
      tft.setCursor(20, 70);
      tft.print(text);

      if (mic_rb == 0) // test
      {
        framWrite(str_2_turn_eep_cell, str_2_turn_eep);
        motor_el(100, 100, str_2_turn_eep, 200);

        stop(100);
        buz(1000);
      }
    }

    /////////////////

    else if (n == 2)
    {
      if (mic_rf == 0)
      {
        delay(10);

        if (deg_45_eep < 10000)
          deg_45_eep += 5;
      }

      else if (mic_lf == 0)
      {
        delay(10);

        if (deg_45_eep > 50)
          deg_45_eep -= 5;
      }

      if (mic_rb == 0) // test
      {
        framWrite(deg_45_eep_cell, deg_45_eep);

        enc_read();
        while (enc_l() < deg_45_eep)
        {
          motor(150, -150, 0);
        }

        stop(100);
        buz(1000);
      }
      sprintf(text, "turn_45=%3d", deg_45_eep);
      tft.setCursor(20, 80);
      tft.print(text);
    }

    //////////////////

    else if (n == 3)
    {
      if (mic_rf == 0)
      {
        delay(10);

        if (arc_low_eep <= 100)
          arc_low_eep += 2;
      }

      else if (mic_lf == 0)
      {
        delay(10);

        if (arc_low_eep >= 2)
          arc_low_eep -= 2;
      }

      if (mic_rb == 0) // test
      {

        framWrite(arc_low_eep_cell, arc_low_eep);

        motor(arc_high_eep, arc_low_eep, 1000);
      }
      sprintf(text, "arc_low=%3d", arc_low_eep);
      tft.setCursor(20, 90);
      tft.print(text);
    }

    //////////////////////

    else if (n == 4)
    {
      if (mic_rf == 0)
      {
        delay(10);

        if (arc_high_eep < 255)
          arc_high_eep += 2;
      }

      else if (mic_lf == 0)
      {
        delay(10);

        if (arc_high_eep > 10)
          arc_high_eep -= 2;
      }

      if (mic_rb == 0) // test
      {

        framWrite(arc_high_eep_cell, arc_high_eep);

        motor(arc_high_eep, arc_low_eep, 1000);

        stop(100);
        buz(1000);
      }
      sprintf(text, "arc_high=%3d", arc_high_eep);
      tft.setCursor(20, 100);
      tft.print(text);
    }

    /////////////////

    else if (n == 5)
    {
      if (but_r == 0)
      {
        act_obstacle(1, 40);
      }

      sprintf(text, "do act obstacle");
      tft.setCursor(20, 110);
      tft.print(text);
    }

    ///////////////////

    if (but_l == 0)
    {
      main_menu();
      break;
    }
  }
}

//******************************************************

void setup_apds()
{
  int dif_bg;

  tft.fillScreen(BLACK);

  ///////////////

  while (1)
  {
    tft.setTextColor(WHITE, GREEN);
    tft.setTextSize(2);
    tft.setCursor(10, 5);
    tft.print("Apds");

    tft.setTextSize(1);
    tft.setTextColor(WHITE, BLACK);

    read_color('r');

    delay(100);

    sprintf(text, "R  %4d_%4d_%4d_%4d ", red, green, blue, ambient);
    tft.setCursor(0, 30);

    filter_green_amb('r');

    if (green_r == 1)
    {
      tft.setTextColor(BLACK, GREEN);
      tft.print(text);
    }
    else if (red_r == 1)
    {
      tft.setTextColor(BLACK, RED);
      tft.print(text);
    }
    else if (blue_r == 1)
    {
      tft.setTextColor(BLACK, BLUE);
      tft.print(text);
    }
    else
    {
      tft.setTextColor(WHITE, BLACK);
      tft.print(text);
    }

    ////////////////

    tft.setTextSize(1);
    tft.setTextColor(WHITE, BLACK);

    read_color('l');

    delay(100);

    sprintf(text, "L  %4d_%4d_%4d_%4d ", red, green, blue, ambient);
    tft.setCursor(0, 80);

    filter_red_amb('l');
    filter_green_amb('l');
    filter_blue_amb('l');

    if (red_l == 1)
    {
      tft.setTextColor(BLACK, RED);
      tft.print(text);
    }
    else if (green_l == 1)
    {
      tft.setTextColor(BLACK, GREEN);
      tft.print(text);
    }
    else if (blue_l == 1)
    {
      tft.setTextColor(BLACK, BLUE);
      tft.print(text);
    }
    else
    {
      tft.setTextColor(WHITE, BLACK);
      tft.print(text);
    }

    tft.setTextSize(1);
    tft.setTextColor(WHITE, BLACK);
    tft.setCursor(0, 45);

    read_color('r');

    tft.print("R/A=");
    tft.print((float)red / ambient);

    tft.print(" G/A=");
    tft.print((float)green / ambient);

    tft.print(" B/A=");
    tft.print((float)blue / ambient);

    tft.print("R/T=");
    tft.print((float)red / (green + blue + red));

    tft.print(" G/T=");
    tft.print((float)green / (green + blue + red));

    tft.print(" B/T=");
    tft.print((float)blue / (green + blue + red));

    tft.setCursor(5, 65);
    sprintf(text, "bk=%2d  R4:%d R5:%d P:%-4d", check_black(), d_r4, d_r5, prox);
    tft.print(text);

    ///////////////

    tft.drawLine(0, 75, 159, 75, RED);

    //////////////////////

    tft.setCursor(0, 30);

    read_color('l');

    tft.setTextSize(1);
    tft.setTextColor(WHITE, BLACK);
    tft.setCursor(0, 90);

    tft.print("R/A=");
    tft.print((float)red / ambient);

    tft.print(" G/A=");
    tft.print((float)green / ambient);

    tft.print(" B/A=");
    tft.print((float)blue / ambient);

    tft.print("R/T=");
    tft.print((float)red / (green + blue + red));

    tft.print(" G/T=");
    tft.print((float)green / (green + blue + red));

    tft.print(" B/T=");
    tft.print((float)blue / (green + blue + red));

    tft.setCursor(5, 115);
    sprintf(text, "bk=%2d  R4:%d R5:%d P:%-4d", check_black(), d_r4, d_r5, prox);
    tft.print(text);

    //////////////////

    if (but_l == 0)
    {
      menu_2();
      delay(500);
      break;
    }
  }
}

//******************************************************

void setup_apds_front()
{
  int dif_bg;

  tft.fillScreen(BLACK);

  ///////////////
  arm_xl(400, arm_2_ball, 600);
  arm_xc(400, arm_1_ball, 600);

  open_grip(1023, 400);

  while (1)
  {
    get_distance();

    drf = distance_f_r; // 35
    delay(5);
    dlf = distance_f_l; // 35  220*10  sokhti
    delay(5);

    tft.setTextColor(WHITE, GREEN);
    tft.setTextSize(2);

    tft.setTextSize(1);
    tft.setTextColor(WHITE, BLACK);

    ////////////////

    tft.setTextSize(1);
    tft.setTextColor(WHITE, BLACK);

    delay(100);

    sprintf(text, "F  %4d_%4d_%4d_%4d ", red, green, blue, ambient);
    tft.setCursor(0, 80);

    if (red_f == 1)
    {
      tft.setTextColor(BLACK, RED);
      tft.print(text);
    }
    else if (green_f == 1)
    {
      tft.setTextColor(BLACK, GREEN);
      tft.print(text);
    }
    else if (blue_f == 1)
    {
      tft.setTextColor(BLACK, BLUE);
      tft.print(text);
    }
    else
    {
      tft.setTextColor(WHITE, BLACK);
      tft.print(text);
    }

    tft.setTextSize(1);
    tft.setTextColor(WHITE, BLACK);
    tft.setCursor(0, 45);

    tft.setCursor(0, 30);

    tft.setTextSize(1);
    tft.setTextColor(WHITE, BLACK);

    tft.setCursor(0, 100);

    tft.print("R/A=");
    tft.print((float)red / ambient);

    tft.print(" G/A=");
    tft.print((float)green / ambient);

    tft.print(" B/A=");
    tft.print((float)blue / ambient);

    tft.print("R/T=");
    tft.print((float)red / (green + blue + red));

    tft.print(" G/T=");
    tft.print((float)green / (green + blue + red));

    tft.print(" B/T=");
    tft.print((float)blue / (green + blue + red));

    tft.setCursor(60, 10);

    tft.print("evac= ");
    tft.print(check_evacuation_point());

    tft.drawLine(0, 65, 160, 65, BLUE);
    tft.drawLine(0, 30, 160, 30, BLUE);

    sprintf(text, "%4d", distance_f_l); // vl joloo left
    tft.setCursor(25, 50);
    tft.print(text);

    sprintf(text, "%-4d", distance_f_c); // vl joloo center
    tft.setCursor(65, 40);
    tft.print(text);

    sprintf(text, "%-4d", distance_f_r); // vl joloo right
    tft.setCursor(105, 50);
    tft.print(text);

    if (but_u == 0)
    {
      arm_xl(400, arm_2_ball, 0);
      arm_xc(400, arm_1_ball, 0);

      delay(2000);

      close_grip_ball(1023, 400);
    }

    if (but_d == 0)
    {
      arm_xl(400, arm_2_ball, 0);
      arm_xc(400, arm_1_ball, 0);

      open_grip(1023, 400);

      delay(1000);
    }
    //////////////////

    if (but_l == 0)
    {
      menu_2();

      arm_xl(400, arm_2_normal, 0);
      arm_xc(400, arm_1_normal, 0);

      open_grip(1023, 400);

      delay(500);
      break;
    }
  }
}

//******************************************************

void setup_cmps14()
{
  tft.fillScreen(BLACK);
  tft.setTextColor(RED, BLUE);
  tft.setTextSize(2);
  tft.setCursor(40, 5);
  tft.print(" cmps ");

  while (1)
  {
    cmps14();

    tft.setTextColor(WHITE, BLACK);
    tft.setTextSize(1);

    sprintf(text, "Pitch= %-4d", pitch);
    tft.setCursor(5, 30);
    tft.print(text);

    sprintf(text, "Roll= %-4d", roll);
    tft.setCursor(5, 45);
    tft.print(text);

    sprintf(text, "CMP=%-4d GetZero=%-6.1f", comp, getZeroedHeading());
    tft.setCursor(5, 60);
    tft.print(text);

    if (mic_rb == 0)
    {
      zero_head();
    }

    check_ramp();

    tft.drawLine(80, 80, 80, 128, RED);
    tft.drawLine(0, 80, 160, 80, RED);

    sprintf(text, "up=%d", ramp_up);
    tft.setCursor(5, 90);
    tft.print(text);

    sprintf(text, "down=%d", ramp_down);
    tft.setCursor(100, 90);
    tft.print(text);

    sprintf(text, "left=%d", ramp_left);
    tft.setCursor(5, 105);
    tft.print(text);

    sprintf(text, "right=%d", ramp_right);
    tft.setCursor(100, 105);
    tft.print(text);

    tft.setCursor(5, 115);
    tft.setTextColor(RED, BLACK);
    tft.print("BD = calib cmps");

    if (but_d == 0)
    {
      tft.fillScreen(BLACK);
      tft.fillScreen(BLACK);

      tft.setTextColor(RED, BLACK);
      tft.setTextSize(4);
      tft.setCursor(20, 60);
      tft.print("CALIB");

      buz(2000);

      delay(500);

      tft.fillScreen(BLACK);

      motor(90, 90);

      while (1)
      {
        uint8_t calib = readRegister(0x1E);

        uint8_t mag = (calib >> 0) & 0x03;
        uint8_t acc = (calib >> 2) & 0x03;
        uint8_t gyro = (calib >> 4) & 0x03;
        uint8_t sys = (calib >> 6) & 0x03;

        tft.setTextColor(WHITE, BLACK);
        tft.setTextSize(1);

        sprintf(text, "mag= %-4d", mag);
        tft.setCursor(5, 30);
        tft.print(text);

        sprintf(text, "acc= %-4d", acc);
        tft.setCursor(5, 45);
        tft.print(text);

        sprintf(text, "gyro=%-4d ", gyro);
        tft.setCursor(5, 60);
        tft.print(text);

        sprintf(text, "sys= %-4d", sys);
        tft.setCursor(5, 75);
        tft.print(text);

        /*
           Important:
           Do not require gyro == 3 on CMPS14.
           Gyro feedback may stay 0.
        */
        if (mag == 3 && acc == 3 && sys == 3)

        {
          tft.fillScreen(BLACK);
          tft.setTextColor(RED, BLACK);
          tft.setTextSize(4);
          tft.setCursor(20, 60);
          tft.print("SAVING");

          // Save calibration profile
          writeRegister(0x00, 0xF0);
          delay(20);
          writeRegister(0x00, 0xF5);
          delay(20);
          writeRegister(0x00, 0xF6);
          delay(20);

          tft.fillScreen(BLACK);
          tft.setTextColor(GREEN, BLACK);
          tft.setTextSize(4);
          tft.setCursor(20, 60);
          tft.print("SAVED");

          buz(1000);
          delay(1000);

          stop(100);

          break;
        }

        delay(200);
      }
    }

    if (but_l == 0)
    {
      main_menu();
      delay(500);
      break;
    }
  }
}

//******************************************************

void setup_clean()
{
  static int n = 0, n_clean = 5;

  tft.fillScreen(BLACK);

  tft.setTextSize(2);
  tft.setTextColor(BLUE, BLACK);
  tft.setCursor(10, 2);
  tft.print("Setup Clean");

  tft.setTextSize(1);
  tft.setTextColor(RED, BLACK);

  tft.setCursor(25, 40);
  tft.print("RB : ");

  tft.setCursor(25, 50);
  tft.print("RF : ");

  tft.setCursor(25, 60);
  tft.print("LB : ");

  tft.setCursor(25, 70);
  tft.print("LF : ");

  //////////

  while (1)
  {

    if (but_d == 0)
    {
      delay(10);
      n++;
      if (n > 3)
        n = 0;

      buz(50);
      // delay(1);
      tft.fillRect(0, 40, 10, 70, BLACK);
    }
    /////////////////////////////

    tft.setTextSize(1);
    tft.setTextColor(WHITE, RED);
    tft.setCursor(0, 40 + n * 10); // jaye flash
    tft.print(">");

    tft.setTextSize(1);

    /////////////////////////////

    if (n == 0)
    {

      if (mic_rb == 0)
      {

        for (int i = 0; i < n_clean; i++)
        {
          dxl.setGoalVelocity(rb, 400);

          delay(1000);

          dxl.setGoalVelocity(rb, -400);

          delay(1000);
        }

        tft.setTextColor(GREEN, BLACK);
        tft.setCursor(25, 40);
        tft.print("RB : ");

        stop(1000);
      }
    }

    else if (n == 1)
    {

      if (mic_rb == 0)
      {

        for (int i = 0; i < n_clean; i++)
        {
          dxl.setGoalVelocity(rf, 400);

          delay(1000);

          dxl.setGoalVelocity(rf, -400);

          delay(1000);
        }

        tft.setTextColor(GREEN, BLACK);
        tft.setCursor(25, 50);
        tft.print("RF : ");

        stop(1000);
      }
    }

    else if (n == 2)
    {

      if (mic_rb == 0)
      {

        for (int i = 0; i < n_clean; i++)
        {
          dxl.setGoalVelocity(lb, 400);

          delay(1000);

          dxl.setGoalVelocity(lb, -400);

          delay(1000);
        }

        tft.setTextColor(GREEN, BLACK);
        tft.setCursor(25, 60);
        tft.print("LB : ");

        stop(1000);
      }
    }

    else if (n == 3)
    {

      if (mic_rb == 0)
      {

        for (int i = 0; i < n_clean; i++)
        {
          dxl.setGoalVelocity(lf, 400);

          delay(1000);

          dxl.setGoalVelocity(lf, -400);

          delay(1000);
        }

        tft.setTextColor(GREEN, BLACK);
        tft.setCursor(25, 70);
        tft.print("LF : ");

        stop(1000);
      }
    }

    if (but_l == 0)
    {
      menu_2();
      break;
    }
  }
}

//******************************************************

void setup_auto_callibrate()
{

  tft.fillScreen(BLACK);
  tft.setTextSize(2);
  tft.setTextColor(WHITE, BLACK);

  tft.setCursor(20, 40);
  tft.print("callibrate");

  //////////////////////////////////////////

  while (1)
  {

    if (a_sil_l2 > max_sil_l2)
    {
      max_sil_l2 = a_sil_l2;
    }
    if (a_sil_l1 > max_sil_l1)
    {
      max_sil_l1 = a_sil_l1;
    }
    if (a_sil_r1 > max_sil_r1)
    {
      max_sil_r1 = a_sil_r1;
    }
    if (a_sil_r2 > max_sil_r2)
    {
      max_sil_r2 = a_sil_r2;
    }

    if (a_m_l3 > max_l3_m)
    {
      max_l3_m = a_m_l3;
    }
    if (a_m_l2 > max_l2_m)
    {
      max_l2_m = a_m_l2;
    }
    if (a_m_l1 > max_l1_m)
    {
      max_l1_m = a_m_l1;
    }
    if (a_m_c > max_c_m)
    {
      max_c_m = a_m_c;
    }
    if (a_m_r1 > max_r1_m)
    {
      max_r1_m = a_m_r1;
    }
    if (a_m_r2 > max_r2_m)
    {
      max_r2_m = a_m_r2;
    }
    if (a_m_r3 > max_r3_m)
    {
      max_r3_m = a_m_r3;
    }

    if (a_b_l3 > max_l3_b)
    {
      max_l3_b = a_b_l3;
    }
    if (a_b_l2 > max_l2_b)
    {
      max_l2_b = a_b_l2;
    }
    if (a_b_l1 > max_l1_b)
    {
      max_l1_b = a_b_l1;
    }
    if (a_b_c > max_c_b)
    {
      max_c_b = a_b_c;
    }
    if (a_b_r1 > max_r1_b)
    {
      max_r1_b = a_b_r1;
    }
    if (a_b_r2 > max_r2_b)
    {
      max_r2_b = a_b_r2;
    }
    if (a_b_r3 > max_r3_b)
    {
      max_r3_b = a_b_r3;
    }

    if (a_c > max_c)
    {
      max_c = a_c;
    }

    if (a_r1 > max_r1)
    {
      max_r1 = a_r1;
    }
    if (a_r2 > max_r2)
    {
      max_r2 = a_r2;
    }
    if (a_r3 > max_r3)
    {
      max_r3 = a_r3;
    }
    if (a_r4 > max_r4)
    {
      max_r4 = a_r4;
    }
    if (a_r5 > max_r5)
    {
      max_r5 = a_r5;
    }
    if (a_r6 > max_r6)
    {
      max_r6 = a_r6;
    }
    if (a_r7 > max_r7)
    {
      max_r7 = a_r7;
    }
    if (a_r8 > max_r8)
    {
      max_r8 = a_r8;
    }
    if (a_r9 > max_r9)
    {
      max_r9 = a_r9;
    }
    if (a_r10 > max_r10)
    {
      max_r10 = a_r10;
    }

    if (a_l1 > max_l1)
    {
      max_l1 = a_l1;
    }
    if (a_l2 > max_l2)
    {
      max_l2 = a_l2;
    }
    if (a_l3 > max_l3)
    {
      max_l3 = a_l3;
    }
    if (a_l4 > max_l4)
    {
      max_l4 = a_l4;
    }
    if (a_l5 > max_l5)
    {
      max_l5 = a_l5;
    }
    if (a_l6 > max_l6)
    {
      max_l6 = a_l6;
    }
    if (a_l7 > max_l7)
    {
      max_l7 = a_l7;
    }
    if (a_l8 > max_l8)
    {
      max_l8 = a_l8;
    }
    if (a_l9 > max_l9)
    {
      max_l9 = a_l9;
    }
    if (a_l10 > max_l10)
    {
      max_l10 = a_l10;
    }

    if (but_d == 0)
    {
      flag_stop = !flag_stop;

      if (flag_stop == 1)
      {
        motor(0, 0);
      }
      else if (flag_stop == 0)
      {
        motor(12, -12);
      }

      while (but_d == 0)
        ;

      delay(500);
    }

    if (mic_rf == 0)
    {

      framWrite(d_sil_l2_eep_cell, max_sil_l2);

      framWrite(d_sil_l1_eep_cell, max_sil_l1);

      framWrite(d_sil_r1_eep_cell, max_sil_r1);

      framWrite(d_sil_r2_eep_cell, max_sil_r2);

      framWrite(d_l3_m_eep_cell, max_l3_m);

      framWrite(d_l2_m_eep_cell, max_l2_m);

      framWrite(d_l1_m_eep_cell, max_l1_m);

      framWrite(d_c_m_eep_cell, max_c_m);

      framWrite(d_r1_m_eep_cell, max_r1_m);

      framWrite(d_r2_m_eep_cell, max_r2_m);

      framWrite(d_r3_m_eep_cell, max_r3_m);

      framWrite(d_l3_b_eep_cell, max_l3_b);

      framWrite(d_l2_b_eep_cell, max_l2_b);

      framWrite(d_l1_b_eep_cell, max_l1_b);

      framWrite(d_c_b_eep_cell, max_c_b);

      framWrite(d_r1_b_eep_cell, max_r1_b);

      framWrite(d_r2_b_eep_cell, max_r2_b);

      framWrite(d_r3_b_eep_cell, max_r3_b);

      framWrite(d_c_eep_cell, max_c);

      framWrite(d_r1_eep_cell, max_r1);

      framWrite(d_r2_eep_cell, max_r2);

      framWrite(d_r3_eep_cell, max_r3);

      framWrite(d_r4_eep_cell, max_r4);

      framWrite(d_r5_eep_cell, max_r5);

      framWrite(d_r6_eep_cell, max_r6);

      framWrite(d_r7_eep_cell, max_r7);

      framWrite(d_r8_eep_cell, max_r8);

      framWrite(d_r9_eep_cell, max_r9);

      framWrite(d_r10_eep_cell, max_r10);

      framWrite(d_l1_eep_cell, max_l1);

      framWrite(d_l2_eep_cell, max_l2);

      framWrite(d_l3_eep_cell, max_l3);

      framWrite(d_l4_eep_cell, max_l4);

      framWrite(d_l5_eep_cell, max_l5);

      framWrite(d_l6_eep_cell, max_l6);

      framWrite(d_l7_eep_cell, max_l7);

      framWrite(d_l8_eep_cell, max_l8);

      framWrite(d_l9_eep_cell, max_l9);

      framWrite(d_l10_eep_cell, max_l10);

      alarm_buz(5, 100);
      break;
    }
  }
  tft.fillScreen(BLACK);
  tft.setTextSize(1);

  read_eeprom_setting();
  while (1)
  {
    motor(0, 0);

    sprintf(text, "%-4d %-4d  sil  %-4d %-4d", max_sil_l2, max_sil_l1, max_sil_r1, max_sil_r2);
    tft.setCursor(0, 5);
    tft.print(text);

    sprintf(text, "%  -4d %-4d %-4d %-4d %-4d", max_l2, max_l1, max_c, max_r1, max_r2);
    tft.setCursor(5, 25);
    tft.print(text);

    sprintf(text, "   %-4d     3     %-4d   ", max_l3, max_r3);
    tft.setCursor(0, 35);
    tft.print(text);

    sprintf(text, "  %-4d      4      %-4d  ", max_l4, max_r4);
    tft.setCursor(0, 45);
    tft.print(text);

    sprintf(text, " %-4d       5       %-4d ", max_l5, max_r5);
    tft.setCursor(0, 55);
    tft.print(text);

    sprintf(text, "%-4d        6        %-4d", max_l6, max_r6);
    tft.setCursor(0, 65);
    tft.print(text);

    sprintf(text, "%-4d        7        %-4d", max_l7, max_r7);
    tft.setCursor(0, 75);
    tft.print(text);

    sprintf(text, "%-4d        8        %-4d", max_l8, max_r8);
    tft.setCursor(0, 85);
    tft.print(text);

    sprintf(text, "%-4d        9        %-4d", max_l9, max_r9);
    tft.setCursor(0, 95);
    tft.print(text);

    sprintf(text, "%-4d        10       %-4d", max_l10, max_r10);
    tft.setCursor(0, 105);
    tft.print(text);

    if (mic_lf == 0)
    {
      tft.fillScreen(BLACK);
      delay(25);
      while (1)
      {
        sprintf(text, "      %-4d %-4d %-4d", max_l1_m, max_c_m, max_r1_m);
        tft.setCursor(0, 20);
        tft.print(text);

        sprintf(text, "%  -4d %-4d       %-4d %-4d", max_l3_m, max_l2_m, max_r2_m, max_r3_m);
        tft.setCursor(0, 40);
        tft.print(text);

        sprintf(text, "      %-4d %-4d %-4d", max_l1_b, max_c_b, max_r1_b);
        tft.setCursor(0, 60);
        tft.print(text);

        sprintf(text, "%  -4d %-4d       %-4d %-4d", max_l3_b, max_l2_b, max_r2_b, max_r3_b);
        tft.setCursor(0, 80);
        tft.print(text);

        if (but_l == 0)
        {
          break;
        }
      }
      tft.fillScreen(BLACK);
      menu_2();
      break;
    }
  }
}

//******************************************************

void setup_vl()
{
  tft.setTextSize(2);

  tft.setTextColor(YELLOW, RED);
  tft.setCursor(65, 2);
  tft.print("VL");
  tft.setTextSize(1);

  tft.setTextColor(YELLOW, BLACK);

  while (1)
  {

    sprintf(text, "%4d", distance_f_l); // vl joloo left
    tft.setCursor(25, 40);
    tft.print(text);

    sprintf(text, "%-4d", distance_f_c); // vl joloo center
    tft.setCursor(65, 30);
    tft.print(text);

    sprintf(text, "%-4d", distance_f_r); // vl joloo right
    tft.setCursor(105, 40);
    tft.print(text);

    tft.drawLine(0, 55, 160, 55, RED);

    sprintf(text, "%4d", distance_u_r);
    tft.setCursor(120, 75);
    tft.print(text);

    sprintf(text, "%4d", distance_d_r);
    tft.setCursor(120, 110);
    tft.print(text);

    sprintf(text, "%-4d", distance_d_l);
    tft.setCursor(10, 110);
    tft.print(text);

    sprintf(text, "%-4d", distance_u_l);
    tft.setCursor(10, 75);
    tft.print(text);

    if (but_l == 0) // back
    {
      main_menu();
      break;
    }
  }
}

//******************************************************

void setup_ball()
{
  int n;
  tft.setTextSize(2);

  tft.setTextColor(YELLOW, RED);
  tft.setCursor(25, 2);
  tft.print("BALL");
  tft.setTextSize(1);

  tft.setTextColor(YELLOW, BLACK);

  dxl.torqueOn(sep_id);

  sprintf(text, "moving: %-d", flag_moving_menu);
  tft.setCursor(20, 30);
  tft.print(text);

  sprintf(text, "special ball: %-d", flag_ball_special_menu);
  tft.setCursor(20, 40);
  tft.print(text);

  tft.setTextColor(WHITE, RED);
  tft.setCursor(2, 30 + n * 10); // jaye flash
  tft.print(">");
  tft.setTextColor(YELLOW, BLACK);

  arm_xl(200, arm_2_ball, 400);
  arm_xc(200, arm_1_ball, 400);

  open_grip(1023, 400);

  while (1)
  {
    if (but_d == 0)
    {
      n++;
      if (n > 1)
        n = 0;

      buz(50);
      delay(100);
      tft.fillRect(0, 20, 10, 50, BLACK);
    }

    if (but_u == 0)
    {
      n--;
      if (n < 0)
        n = 1;

      buz(50);
      delay(100);
      tft.fillRect(0, 20, 10, 120, BLACK);
    }

    tft.setTextColor(WHITE, RED);
    tft.setCursor(2, 30 + n * 10); // jaye flash
    tft.print(">");
    tft.setTextColor(YELLOW, BLACK);

    if (n == 0)
    {
      if (but_r == 0)
      {
        flag_moving_menu = !flag_moving_menu;
        delay(500);
      }

      sprintf(text, "moving: %-d", flag_moving_menu);
      tft.setCursor(20, 30);
      tft.print(text);
    }

    if (n == 1)
    {
      if (but_r == 0)
      {
        flag_ball_special_menu = !flag_ball_special_menu;
        delay(500);
      }

      sprintf(text, "special ball: %-d", flag_ball_special_menu);
      tft.setCursor(20, 40);
      tft.print(text);
    }

    get_distance();
    if (ir_ball == 1)
    {
      catch_the_victim();

      tft.fillScreen(BLACK);
      tft.setTextSize(1);

      tft.setTextColor(YELLOW, BLACK);

      sprintf(text, "moving: %-d", flag_moving_menu);
      tft.setCursor(20, 30);
      tft.print(text);

      sprintf(text, "special ball: %-d", flag_ball_special_menu);
      tft.setCursor(20, 40);
      tft.print(text);
    }

    if (flag_moving_menu == 1)
      motor(80, 80);
    else
      motor(0, 0);

    if (flag_ball_special_menu == 1)
    {
      check_victim_vl_side('n');
    }

    tft.drawLine(0, 65, 160, 65, RED);

    sprintf(text, "%4d", distance_u_r);
    tft.setCursor(120, 90);
    tft.print(text);

    sprintf(text, "%4d", distance_d_r);
    tft.setCursor(120, 110);
    tft.print(text);

    sprintf(text, "%-4d", distance_u_l);
    tft.setCursor(10, 90);
    tft.print(text);

    sprintf(text, "%-4d", distance_d_l);
    tft.setCursor(10, 110);
    tft.print(text);

    if (but_l == 0) // back
    {
      menu_2();
      motor(0, 0);
      break;
    }
  }
}

//******************************************************

void menu_2()
{
  static char last_page = 7;
  static int c = 0;

  tft.fillScreen(BLACK);

  tft.setTextSize(1);
  tft.setTextColor(WHITE, BLACK);

  tft.setCursor(20, 50);
  tft.print("Apds");

  tft.setCursor(20, 60);
  tft.print("check evac");

  tft.setCursor(20, 70);
  tft.print("Silver");

  tft.setCursor(20, 80);
  tft.print("auto callibrate");

  tft.setCursor(20, 90);
  tft.print("mic");

  tft.setCursor(20, 100);
  tft.print("ball");

  tft.setCursor(20, 110);
  tft.print("Clean");

  while (1)
  {
    tft.setTextSize(2);
    tft.setTextColor(YELLOW, BLACK);

    if (millis() - t_b > 250)
    {
      float v_battery = battery;
      if (v_battery >= 12.7)
      {
        t_b = millis();

        tft.setCursor(35, 5);
        tft.print("V=");
        tft.print("12.6");
      }
      else
      {
        t_b = millis();
        tft.setCursor(35, 5);
        tft.print("V=");
        tft.print(v_battery);
      }
    }

    /////////////

    if (but_d == 0)
    {
      c++;
      if (c >= last_page)
        c = 0;

      tft.fillRect(0, 40, 20, 127, BLACK);
      buz(50);
      delay(100);
    }

    if (but_u == 0)
    {
      c--;
      if (c < 0)
        c = last_page - 1;

      tft.fillRect(0, 40, 20, 127, BLACK);
      buz(50);
      delay(100);
    }
    //////////////////

    tft.setTextSize(1);
    tft.setTextColor(WHITE, RED);
    tft.setCursor(2, 50 + c * 10); // jaye flash
    tft.print(">");
    tft.setTextColor(YELLOW, BLACK);

    /////////////////////////

    if (but_r == 0)
    {
      tft.fillScreen(BLACK);

      switch (c)
      {
      case 0:
        setup_apds();
        break;
      case 1:
        setup_apds_front();
        break;
      case 2:
        setup_silver();
        break;
      case 3:
        setup_auto_callibrate();
        break;
      case 4:
        setup_mic();
        break;
      case 5:
        setup_ball();
        break;
      case 6:
        setup_clean();
        break;
      }
    }

    if (mic_lb == 0)
    {
      main_menu();
      buz(1000);
      break;
    }
  }
}

//******************************************************

void main_menu()
{
  static char last_page = 9;

  static int c = 0;

  tft.fillScreen(BLACK);

  tft.setTextSize(1);
  tft.setTextColor(WHITE, BLACK);

  tft.setCursor(20, 30);
  tft.print("DYNAMIXEL");

  tft.setCursor(20, 40);
  tft.print("IR_DIG");

  tft.setCursor(20, 50);
  tft.print("IR_ANALOG");

  tft.setCursor(20, 60);
  tft.print("IR_ANALOG_middle");

  tft.setCursor(20, 70);
  tft.print("cmps14");

  tft.setCursor(20, 80);
  tft.print("obstacle");

  tft.setCursor(20, 90);
  tft.print("setup motor");

  tft.setCursor(20, 100);
  tft.print("setup ir mic");

  tft.setCursor(20, 110);
  tft.print("setup vl");
  while (1)
  {

    tft.setTextSize(2);
    tft.setTextColor(RED, BLACK);

    if (millis() - t_b > 250)
    {
      float v_battery = battery;
      if (v_battery >= 12.7)
      {
        t_b = millis();

        tft.setCursor(35, 5);
        tft.print("V=");
        tft.print("12.6");
      }
      else
      {
        t_b = millis();
        tft.setCursor(35, 5);
        tft.print("V=");
        tft.print(v_battery);
      }
    }

    tft.setTextSize(1);
    tft.setTextColor(GREEN, BLACK);

    if (but_d == 0)
    {
      c++;
      if (c >= last_page)
        c = 0;

      tft.fillRect(0, 18, 10, 129, BLACK);
      buz(50);
      delay(100);
    }

    if (but_u == 0)
    {
      c--;
      if (c < 0)
        c = last_page - 1;

      tft.fillRect(0, 18, 10, 129, BLACK);
      buz(50);
      delay(100);
    }

    //////////////////

    tft.setTextColor(WHITE, RED);
    tft.setCursor(2, 30 + c * 10); // jaye flash
    tft.print(">");
    tft.setTextColor(YELLOW, BLACK);

    /////////////////////////

    if (but_r == 0)
    {

      tft.fillScreen(BLACK);
      switch (c)
      {
      case 0:
        setup_dynam();
        break;
      case 1:
        setup_ir_dig();
        break;
      case 2:
        setup_ir_analog();
        break;
      case 3:
        setup_ir_analog_middle();
        break;
      case 4:
        setup_cmps14();
        break;
      case 5:
        setup_obstacle();
        break;
      case 6:
        setup_motor();
        break;
      case 7:
        setup_ir_mic();
        break;
      case 8:
        setup_vl();
        break;
      }
    }
    if (mic_rb == 0)
    {
      menu_2();
      tft.fillScreen(BLACK);
      buz(1000);
      break;
    }
  }
}

//******************************************************

void setup_motor()
{
  static int n = 0;

  read_eeprom_setting();

  ///////////////////////

  tft.fillScreen(BLACK);

  tft.setTextSize(1);
  tft.setTextColor(WHITE, BLUE);
  tft.setCursor(20, 120);
  tft.print("LB=Dec        RB=Inc");

  /////////////////////

  tft.setTextSize(1);

  tft.setTextColor(YELLOW, RED);
  tft.setCursor(40, 2);
  tft.print(" setup motor ");

  tft.setTextColor(YELLOW, BLACK);

  sprintf(text, "speed = % -3d", speed_normal_eep);
  tft.setCursor(20, 30);
  tft.print(text);

  sprintf(text, "cmp_turn_90_right ");
  tft.setCursor(20, 40);
  tft.print(text);

  sprintf(text, "cmp_turn_90_left ");
  tft.setCursor(20, 50);
  tft.print(text);

  sprintf(text, "enc_F = R:%-4d L:%-4d ", enc_r(), enc_l());
  tft.setCursor(20, 60);
  tft.print(text);

  sprintf(text, "enc_B = R:%-4d L:%-4d ", enc_r(), enc_l());
  tft.setCursor(20, 70);
  tft.print(text);

  delay(500);

  enc_read();

  ///////////////////////////////////

  while (1)
  {
    tft.setTextSize(1);
    tft.setTextColor(WHITE, BLUE);

    tft.setCursor(5, 20);
    tft.print("BL = BK");

    tft.setCursor(100, 20);
    tft.print("BD = Next");

    ///////////////

    if (but_d == 0)
    {
      n++;
      if (n > 4)
        n = 0;

      buz(50);
      delay(100);
      tft.fillRect(0, 20, 10, 120, BLACK);
    }

    if (but_u == 0)
    {
      n--;
      if (n < 0)
        n = 4;

      buz(50);
      delay(100);
      tft.fillRect(0, 20, 10, 120, BLACK);
    }
    ///////////////////

    tft.setTextColor(WHITE, RED);
    tft.setCursor(2, 30 + n * 10); // jaye flash
    tft.print(">");
    tft.setTextColor(YELLOW, BLACK);

    ///////////

    if (n == 0)
    {
      if (mic_rb == 0)
      {
        if (speed_normal_eep < 100)
          speed_normal_eep += 1;
      }
      else if (mic_lb == 0)
      {
        if (speed_normal_eep > 5)
          speed_normal_eep -= 1;
      }

      sprintf(text, "speed = % -3d", speed_normal_eep);
      tft.setCursor(20, 30);
      tft.print(text);

      if (but_r == 0) // set & test
      {
        framWrite(speed_normal_eep_cell, speed_normal_eep);
        motor(speed_normal_eep, speed_normal_eep, 500);
      }
    }

    else if (n == 1)
    {

      sprintf(text, "cmp_turn_90_right");
      tft.setCursor(20, 40);
      tft.print("cmp_turn_90_right");

      if (but_r == 0)
      {
        zero_head();
        cmp_turn_step_15('r', 6000);
      }
    }

    else if (n == 2)
    {

      sprintf(text, "cmp_turn_90_left ");
      tft.setCursor(20, 50);
      tft.print("cmp_turn_90_left");

      if (but_r == 0)
      {
        zero_head();
        cmp_turn_step_15('l', 6000);
      }
    }

    else if (n == 3)
    {
      if (mic_lb == 0)
      {
        enc_read();
        sprintf(text, "enc_F = R:%-4d L:%-4d ", enc_r(), enc_l());
        tft.setCursor(20, 60);
        tft.print(text);
      }

      if (mic_rb == 0)
      {
        while (mic_rb == 0)
        {
          motor(speed_normal_eep, speed_normal_eep, 0);

          sprintf(text, "enc_F = R:%-4d L:%-4d ", enc_r(), enc_l());
          tft.setCursor(20, 60);
          tft.print(text);
        }
        motor(0, 0);
        delay(250);
      }
    }

    else if (n == 4)
    {
      if (mic_lb == 0)
      {
        enc_read();
        sprintf(text, "enc_B = R:%-4d L:%-4d ", enc_r(), enc_l());
        tft.setCursor(20, 70);
        tft.print(text);
      }
      if (mic_rb == 0)
      {
        while (mic_rb == 0)
        {
          motor(-speed_normal_eep, -speed_normal_eep);

          sprintf(text, "enc_B = R:%-4d L:%-4d ", enc_r(), enc_l());
          tft.setCursor(20, 70);
          tft.print(text);
        }
        motor(0, 0);
        delay(250);
      }
    }

    /////////////////////
    if (but_l == 0)
    {
      main_menu();
      break;
    }
  }
}

//******************************************************

void eeprom_reset(void)
{
  char flag_ok = 0;

  tft.fillScreen(BLACK);
  tft.setCursor(20, 45);
  tft.print("NO/YES");

  while (1)
  {
    if (but_r == 0) // yes
    {
      flag_ok = 1;
      break;
    }
    else if (mic_rb == 0)
    { // ball
      flag_ok = 2;
      break;
    }
    else if (mic_lb == 0)
    { // ir reset
      flag_ok = 3;
      break;
    }
    else if (but_l == 0) // no
    {
      buz(100);
      break;
    }
  }

  tft.fillScreen(BLACK);

  if (flag_ok == 1)
  {
    flag_ok = 0;

    flag_eslahe_mic_eep = 0;
    framWrite(flag_eslahe_mic_eep_cell, flag_eslahe_mic_eep);

    speed_normal_eep = 70;
    framWrite(speed_normal_eep_cell, speed_normal_eep);

    speed_ramp_up_eep = 24;
    framWrite(speed_ramp_up_eep_cell, speed_ramp_up_eep);

    speed_ramp_down_eep = 10;
    framWrite(speed_ramp_down_eep_cell, speed_ramp_down_eep);

    speed_ramp_side_eep = 10;
    framWrite(speed_ramp_side_eep_cell, speed_ramp_side_eep);

    dir_obstacle_eep = 'a';
    framWrite(dir_obstacle_eep_cell, dir_obstacle_eep);

    chance_obs_eep = 0;
    framWrite(chance_obs_eep_cell, chance_obs_eep);

    tm_slow_eep = 5000;
    framWrite(tm_slow_eep_cell, tm_slow_eep);

    str_1_turn_eep = 1040;
    framWrite(str_1_turn_eep_cell, str_1_turn_eep);

    deg_45_eep = 1100;
    framWrite(deg_45_eep_cell, deg_45_eep);

    str_2_turn_eep = 690;
    framWrite(str_2_turn_eep_cell, str_2_turn_eep);

    arc_high_eep = 90;
    framWrite(arc_high_eep_cell, arc_high_eep);

    arc_low_eep = 30;
    framWrite(arc_low_eep_cell, arc_low_eep);

    sil_l1_eep = 330;
    framWrite(sil_l1_eep_cell, sil_l1_eep);

    sil_l2_eep = 330;
    framWrite(sil_l2_eep_cell, sil_l2_eep);

    sil_r1_eep = 350;
    framWrite(sil_r1_eep_cell, sil_r1_eep);

    sil_r2_eep = 330;
    framWrite(sil_r2_eep_cell, sil_r2_eep);
  }
  else if (flag_ok == 2)
  {
    framWrite(ball_rescued_eep_cell, 0);
    framWrite(silver_rescued_eep_cell, 0);
    framWrite(black_rescued_eep_cell, 0);

    framWrite(vorood_eep_cell, 0);
  }
  else if (flag_ok == 3)
  { // reset ir

    max_value = 2800;

    framWrite(d_c_eep_cell, max_value);
    framWrite(d_r1_eep_cell, max_value);
    framWrite(d_r2_eep_cell, max_value);
    framWrite(d_r3_eep_cell, max_value);
    framWrite(d_r4_eep_cell, max_value);
    framWrite(d_r5_eep_cell, max_value);
    framWrite(d_r6_eep_cell, max_value);
    framWrite(d_r7_eep_cell, max_value);
    framWrite(d_r8_eep_cell, max_value);
    framWrite(d_r9_eep_cell, max_value);
    framWrite(d_r10_eep_cell, max_value);

    framWrite(d_l1_eep_cell, max_value);
    framWrite(d_l2_eep_cell, max_value);
    framWrite(d_l3_eep_cell, max_value);
    framWrite(d_l4_eep_cell, max_value);
    framWrite(d_l5_eep_cell, max_value);
    framWrite(d_l6_eep_cell, max_value);
    framWrite(d_l7_eep_cell, max_value);
    framWrite(d_l8_eep_cell, max_value);
    framWrite(d_l9_eep_cell, max_value);
    framWrite(d_l10_eep_cell, max_value);

    framWrite(d_sil_l2_eep_cell, max_value);
    framWrite(d_sil_l1_eep_cell, max_value);
    framWrite(d_sil_r1_eep_cell, max_value);
    framWrite(d_sil_r2_eep_cell, max_value);

    framWrite(d_l3_m_eep_cell, max_value);
    framWrite(d_l2_m_eep_cell, max_value);
    framWrite(d_l1_m_eep_cell, max_value);

    framWrite(d_c_m_eep_cell, max_value);

    framWrite(d_r1_m_eep_cell, max_value);
    framWrite(d_r2_m_eep_cell, max_value);
    framWrite(d_r3_m_eep_cell, max_value);

    framWrite(d_l3_b_eep_cell, max_value);
    framWrite(d_l2_b_eep_cell, max_value);
    framWrite(d_l1_b_eep_cell, max_value);

    framWrite(d_c_b_eep_cell, max_value);

    framWrite(d_r1_b_eep_cell, max_value);
    framWrite(d_r2_b_eep_cell, max_value);
    framWrite(d_r3_b_eep_cell, max_value);
  }

  tft.fillScreen(BLACK);
}

//******************************************************

void read_eeprom_setting()
{

  speed_normal_eep = framRead(speed_normal_eep_cell);
  speed_ramp_up_eep = framRead(speed_ramp_up_eep_cell);
  speed_ramp_down_eep = framRead(speed_ramp_down_eep_cell);
  speed_ramp_side_eep = framRead(speed_ramp_side_eep_cell);

  flag_eslahe_mic_eep = framRead(flag_eslahe_mic_eep_cell);

  dir_obstacle_eep = framRead(dir_obstacle_eep_cell);
  chance_obs_eep = framRead(chance_obs_eep_cell);

  silver_rescued = framRead(silver_rescued_eep_cell);
  black_rescued = framRead(black_rescued_eep_cell);
  ball_rescued = framRead(ball_rescued_eep_cell);

  vorood = framRead(vorood_eep_cell);
  going_out_evac_eep = framRead(going_out_evac_eep_cell);

  tm_slow_eep = framRead(tm_slow_eep_cell);

  str_1_turn_eep = framRead(str_1_turn_eep_cell);
  deg_45_eep = framRead(deg_45_eep_cell);
  str_2_turn_eep = framRead(str_2_turn_eep_cell);

  arc_low_eep = framRead(arc_low_eep_cell);
  arc_high_eep = framRead(arc_high_eep_cell);

  sil_l1_eep = framRead(sil_l1_eep_cell);
  sil_l2_eep = framRead(sil_l2_eep_cell);
  sil_r1_eep = framRead(sil_r1_eep_cell);
  sil_r2_eep = framRead(sil_r2_eep_cell);

  d_c_eep = framRead(d_c_eep_cell);

  d_r1_eep = framRead(d_r1_eep_cell);
  d_r2_eep = framRead(d_r2_eep_cell);
  d_r3_eep = framRead(d_r3_eep_cell);
  d_r4_eep = framRead(d_r4_eep_cell);
  d_r5_eep = framRead(d_r5_eep_cell);
  d_r6_eep = framRead(d_r6_eep_cell);
  d_r7_eep = framRead(d_r7_eep_cell);
  d_r8_eep = framRead(d_r8_eep_cell);
  d_r9_eep = framRead(d_r9_eep_cell);
  d_r10_eep = framRead(d_r10_eep_cell);

  d_l1_eep = framRead(d_l1_eep_cell);
  d_l2_eep = framRead(d_l2_eep_cell);
  d_l3_eep = framRead(d_l3_eep_cell);
  d_l4_eep = framRead(d_l4_eep_cell);
  d_l5_eep = framRead(d_l5_eep_cell);
  d_l6_eep = framRead(d_l6_eep_cell);
  d_l7_eep = framRead(d_l7_eep_cell);
  d_l8_eep = framRead(d_l8_eep_cell);
  d_l9_eep = framRead(d_l9_eep_cell);
  d_l10_eep = framRead(d_l10_eep_cell);

  d_sil_l2_eep = framRead(d_sil_l2_eep_cell);
  d_sil_l1_eep = framRead(d_sil_l1_eep_cell);
  d_sil_r1_eep = framRead(d_sil_r1_eep_cell);
  d_sil_r2_eep = framRead(d_sil_r2_eep_cell);

  d_l3_m_eep = framRead(d_l3_m_eep_cell);
  d_l2_m_eep = framRead(d_l2_m_eep_cell);
  d_l1_m_eep = framRead(d_l1_m_eep_cell);

  d_c_m_eep = framRead(d_c_m_eep_cell);

  d_r1_m_eep = framRead(d_r1_m_eep_cell);
  d_r2_m_eep = framRead(d_r2_m_eep_cell);
  d_r3_m_eep = framRead(d_r3_m_eep_cell);

  d_l3_b_eep = framRead(d_l3_b_eep_cell);
  d_l2_b_eep = framRead(d_l2_b_eep_cell);
  d_l1_b_eep = framRead(d_l1_b_eep_cell);

  d_c_b_eep = framRead(d_c_b_eep_cell);

  d_r1_b_eep = framRead(d_r1_b_eep_cell);
  d_r2_b_eep = framRead(d_r2_b_eep_cell);
  d_r3_b_eep = framRead(d_r3_b_eep_cell);
}

//******************************************************

void apds_init(char dir)
{
  select_apds(dir);

  Wire.beginTransmission(APDS_ADDR);
  Wire.write(0x80);
  Wire.write(0b00000111);
  Wire.endTransmission();
  delay(10);

  Wire.beginTransmission(APDS_ADDR);
  Wire.write(0x90);
  Wire.write(0xDB);
  Wire.endTransmission();
  delay(5);

  Wire.beginTransmission(APDS_ADDR);
  Wire.write(0x8F);
  Wire.write(0b00000011);
  Wire.endTransmission();
  delay(50);
}

//******************************************************

void act_intersection(char dir)
{
  zero_head();
  green_r = 0;
  green_l = 0;
  flag_green = 0;

  extra = 200;

  ////////////////////////////////

  // zero_head();

  //////////////////////

  int more = 80;
  int small = 55;

  int s = 600; // forward
  int b = 0;   // back

  /////////////////

  if (dir == 'r')
  {
    tft.fillScreen(GREEN);
    tft.setTextColor(WHITE, GREEN);

    tft.setCursor(60, 35);
    tft.setTextSize(8);
    tft.print("R");

    motor_er(50, 50, s, 0); // str

    if (d_l1 == 1 and d_c == 1 || d_c == 1 and d_r1 == 1)
    {

      for (int i = 0; i < 5; i++)
      {
        t_turn = millis();
        while (cmp_target_angle((more / 5) + i * (more / 5)) > 1 and millis() - t_turn < 650)
        {
          motor(75 - i * 6, -75 + i * 6);
        }
      }
    }
    else
    {
      for (int i = 0; i < 5; i++)
      {
        t_turn = millis();

        while (cmp_target_angle((small / 5) + i * (small / 5)) > 1 and millis() - t_turn < 450)
        {
          motor(75 - i * 6, -75 + i * 6);
        }
      }
    }
    motor_er(-30, -30, b, 0); // back
  }

  /////////////////////////

  else if (dir == 'l')
  {
    tft.fillScreen(GREEN);
    tft.setTextColor(WHITE, GREEN);

    tft.setCursor(60, 35);
    tft.setTextSize(8);
    tft.print("L");

    motor_er(50, 50, s, 0); // str

    if (d_l1 == 1 and d_c == 1 || d_c == 1 and d_r1 == 1)
    {
      for (int i = 0; i < 5; i++)
      {
        t_turn = millis();
        while (cmp_target_angle((-more / 5) - i * (more / 5)) < -1 and millis() - t_turn < 600)
        {
          motor(-75 + i * 6, 75 - i * 6);
        }
      }
    }
    else
    {
      for (int i = 0; i < 5; i++)
      {
        t_turn = millis();

        while (cmp_target_angle((-small / 5) - i * (small / 5)) < -1 and millis() - t_turn < 600)
        {
          motor(-75 + i * 6, 75 - i * 6);
        }
      }

      motor_er(-30, -30, b, 0); // back
    }
  }

  ////////////////////////

  else if (dir == 'u')
  {
    tft.fillScreen(GREEN);
    tft.setTextColor(WHITE, GREEN);

    tft.setCursor(60, 35);
    tft.setTextSize(8);
    tft.print("D");

    flag_dead = 1;

    motor_er(30, 30, 200, 0 + tamrin * 100); // str

    turn_180_cmp('r', 6000, 179);

    motor_er(-60, -60, 400, 0);
  }

  extra = 0;

  flag_after_int = 1;
  timer_green = millis();
  tft.fillScreen(GOLD);

  ////////////////////

  motor(70, 70, 0); // no stop
}

//******************************************************

void act_intersection_ramp(char dir)
{
  int more = 90;

  int s = 500;
  int b = 0;

  green_r = 0;
  green_l = 0;

  flag_green = 0;
  ////////////////////////////////
  extra = 100;

  check_ramp();

  //////////////////////

  if (ramp_up == 1)
  {
    if (dir == 'r')
    {
      tft.fillScreen(GREEN);
      tft.setTextColor(WHITE, GREEN);

      tft.setCursor(45, 35);
      tft.setTextSize(8);
      tft.print("R-U");

      motor_er(50, 50, 1400, 0); // str

      for (int i = 0; i < 5; i++)
      {
        t_turn = millis();
        while (cmp_target_angle((more / 5) + i * (more / 5)) > 1 and millis() - t_turn < 650)
        {
          motor(70 - i * 6, -30 + i * 6);
        }
      }
      motor_er(-10, -10, 500, 0);
    }

    /////////////////////////

    else if (dir == 'l')
    {
      tft.fillScreen(GREEN);
      tft.setTextColor(WHITE, GREEN);

      tft.setCursor(40, 35);
      tft.setTextSize(8);
      tft.print("L-U");

      motor_er(50, 50, 1400, 0); // str

      for (int i = 0; i < 5; i++)
      {
        t_turn = millis();
        while (cmp_target_angle((-more / 5) - i * (more / 5)) < -1 and millis() - t_turn < 600)
        {
          motor(-30 + i * 6, 70 - i * 6);
        }
      }
      motor_er(-10, -10, 500, 0);
    }

    ////////////////////////

    else if (dir == 'u')
    {
      tft.fillScreen(GREEN);
      tft.setTextColor(WHITE, GREEN);

      tft.setCursor(40, 35);
      tft.setTextSize(8);
      tft.print("D-U");

      motor_er(50, 50, 1200, 10);

      t_turn = millis();
      while (cmp_target_angle(150) >= 1 and millis() - t_turn < 2500)
      {
        motor(26, -55);
      }

      while (cmp_target_angle(179) >= 1 and millis() - t_turn < 1000)
      {
        motor(16, -22);
      }
      motor_er(30, -55, 600, 10);
      motor_er(-30, -30, 1250, 10);
    }
  }

  else if (ramp_down == 1)
  {

    if (dir == 'r')
    {
      tft.fillScreen(GREEN);
      tft.setTextColor(WHITE, GREEN);

      tft.setCursor(40, 35);
      tft.setTextSize(8);
      tft.print("R-D");

      motor_er(-10, -10, 100, 0);

      for (int i = 0; i < 5; i++)
      {
        t_turn = millis();
        while (cmp_target_angle((more / 5) + i * (more / 5)) > 1 and millis() - t_turn < 650)
        {
          motor(40 - i * 6, -72 + i * 6);
        }
      }

      motor_er(15, 15, 700, 0);
    }

    /////////////////////////

    else if (dir == 'l')
    {
      tft.fillScreen(GREEN);
      tft.setTextColor(WHITE, GREEN);

      tft.setCursor(40, 35);
      tft.setTextSize(8);
      tft.print("L-D");

      motor_er(-10, -10, 100, 0);

      for (int i = 0; i < 5; i++)
      {
        t_turn = millis();
        while (cmp_target_angle((-more / 5) - i * (more / 5)) < -1 and millis() - t_turn < 600)
        {
          motor(-40 + i * 6, 72 - i * 6);
        }
      }
      motor_er(15, 15, 700, 0);
    }

    else if (dir == 'u')
    {
      tft.fillScreen(GREEN);
      tft.setTextColor(WHITE, GREEN);

      tft.setCursor(60, 35);
      tft.setTextSize(8);
      tft.print("D-D");

      flag_dead = 1;

      t_turn = millis();
      while (cmp_target_angle(178) >= 2.5 and millis() - t_turn < 2500)
      {
        motor(50, -30);
      }
      motor_er(50, -30, 500, 50);
      motor_er(30, 30, 900, 50);
    }
  }

  else if (ramp_left == 1 or ramp_right == 1)
  {
    if (dir == 'r')
    {
      tft.fillScreen(GREEN);
      tft.setTextColor(WHITE, GREEN);

      tft.setCursor(40, 35);
      tft.setTextSize(8);
      tft.print("R-S");

      if (ramp_right == 1)
      {
        motor_er(15, 15, 300, 0); // str

        for (int i = 0; i < 5; i++)
        {
          t_turn = millis();
          while (cmp_target_angle((more / 5) + i * (more / 5)) > 1 and millis() - t_turn < 650)
          {
            motor(70 - i * 6, -50 + i * 6);
          }
        }
        stop(10 + 1 * tamrin);

        motor_er(-15, -15, 550, 10);
      }
      else
      {
        motor_er(15, 15, 700, 0);

        for (int i = 0; i < 5; i++)
        {
          t_turn = millis();
          while (cmp_target_angle((more / 5) + i * (more / 5)) > 1 and millis() - t_turn < 650)
          {
            motor(70 - i * 6, -50 + i * 6);
          }
        }

        stop(10 + 1 * tamrin);

        motor_er(20, 20, 800, 10);
      }
    }

    /////////////////////////

    else if (dir == 'l')
    {
      tft.fillScreen(GREEN);
      tft.setTextColor(WHITE, GREEN);

      tft.setCursor(40, 35);
      tft.setTextSize(8);
      tft.print("R-S");

      if (ramp_left == 1)
      {
        motor_er(15, 15, 400, 0); // str

        for (int i = 0; i < 5; i++)
        {
          t_turn = millis();
          while (cmp_target_angle((-more / 5) - i * (more / 5)) < -1 and millis() - t_turn < 600)
          {
            motor(-50 + i * 6, 70 - i * 6);
          }
        }
        stop(10 + 1 * tamrin);

        motor_er(-15, -15, 550, 10);
      }
      else
      {
        motor_er(15, 15, 900, 0);

        for (int i = 0; i < 5; i++)
        {
          t_turn = millis();
          while (cmp_target_angle((-more / 5) - i * (more / 5)) < -1 and millis() - t_turn < 600)
          {
            motor(-50 + i * 6, 70 - i * 6);
          }
        }

        stop(10 + 1 * tamrin);

        motor_er(20, 20, 800, 10);
      }
    }

    ////////////////////////

    else if (dir == 'u')
    {

      tft.fillScreen(GREEN);
      tft.setTextColor(WHITE, GREEN);

      tft.setCursor(60, 35);
      tft.setTextSize(8);
      tft.print("D-S");

      flag_dead = 1;

      if (ramp_left)
      {
        motor_er(25, 10, 400, 0);
        buzzer_on;
        t_turn = millis();
        zero_head();
        while (cmp_target_angle(178) >= 2.5 and millis() - t_turn < 2500)
        {
          motor(63, -13);
        }
        motor_er(63, -13, 200, 10);
        motor_er(15, 15, 100, 10);
      }
      else
      {
        motor_er(10, 25, 400, 0);
        t_turn = millis();
        zero_head();

        while (cmp_target_angle(178) >= 2.5 and millis() - t_turn < 2500)
        {
          motor(18, -62);
        }
        motor_er(13, -62, 400, 10);
        motor_er(15, 15, 200, 10);
      }
    }
  }
  else
  {
    stop(1);

    motor_er(20, 20, 400, 0);

    act_intersection(dir);
  }

  ////////////////////

  tft.fillScreen(BLACK);
  motor(speed_normal_eep, speed_normal_eep, 0); // no stop
  extra = 0;
}

//******************************************************

byte check_black(void)
{
  byte black = 0;

  if (d_sil_l2 == 1)
    black++;
  if (d_sil_l1 == 1)
    black++;

  if (d_l3 == 1)
    black++;
  if (d_l2 == 1)
    black++;
  if (d_l1 == 1)
    black++;
  if (d_c == 1)
    black++;

  if (d_sil_r2 == 1)
    black++;
  if (d_sil_r1 == 1)
    black++;

  if (d_r3 == 1)
    black++;
  if (d_r2 == 1)
    black++;
  if (d_r1 == 1)
    black++;

  return black;
}

//******************************************************

void select_apds(char dir)
{
  pinMode(add_0_pin, OUTPUT); // mux address
  pinMode(add_1_pin, OUTPUT); // mux address
  pinMode(add_2_pin, OUTPUT); // mux address
  pinMode(add_3_pin, OUTPUT); // mux address

  if (dir == 'r')
  { // CH0
    digitalWrite(e_pin, 1);
    delay(1);

    digitalWrite(add_0_pin, LOW);
    digitalWrite(add_1_pin, LOW);

    digitalWrite(add_2_pin, LOW);
    digitalWrite(add_3_pin, LOW);
  }

  else if (dir == 'l')
  { // CH1
    digitalWrite(e_pin, 1);
    delay(1);

    digitalWrite(add_0_pin, HIGH);
    digitalWrite(add_1_pin, HIGH);

    digitalWrite(add_2_pin, LOW);
    digitalWrite(add_3_pin, LOW);
  }

  else if (dir == 'f')
  { // CH1
    digitalWrite(e_pin, 1);
    delay(1);

    digitalWrite(add_0_pin, HIGH);
    digitalWrite(add_1_pin, LOW);

    digitalWrite(add_2_pin, LOW);
    digitalWrite(add_3_pin, HIGH);
  }
  delay(5);
}

//******************************************************

void read_color(char dir)
{

  unsigned char valH, valL;

  if (dir == 'r')
    select_apds('r');
  else if (dir == 'l')
    select_apds('l');
  else
    select_apds('f');

  ///////////////////////////

  Wire.beginTransmission(0x39);
  Wire.write(0x80); // Power ON
  Wire.write(7);    // 3= only ALS  5=only prox  7= ALS & prox
  Wire.endTransmission();

  Wire.beginTransmission(0x39);
  Wire.write(0x94); // Red, green, blue, and clear data is stored as 16-bit values. The read sequence must read byte pairs (low followed by high) starting on an even address boundary (0x94, 0x96, 0x98, or 0x9A)
  Wire.endTransmission();

  Wire.requestFrom(0x39, 8, 1);

  valL = Wire.read();
  valH = Wire.read();
  ambient = word(valH, valL);

  valL = Wire.read();
  valH = Wire.read();
  red = word(valH, valL);

  valL = Wire.read();
  valH = Wire.read();
  green = word(valH, valL);

  valL = Wire.read();
  valH = Wire.read();
  blue = word(valH, valL);

  Wire.endTransmission();

  //////////////////////////

  filter_green_amb(dir);
  filter_red_amb(dir);
  filter_blue_amb(dir);
}

//******************************************************

void filter_red_amb(char dir)
{
  float zarib_r_a_r = 0.71;
  float zarib_g_a_r = 0.46;
  float zarib_b_a_r = 0.49;

  float zarib_r_t_r = 0.42;
  float zarib_g_t_r = 0.28;
  float zarib_b_t_r = 0.30;

  ///////////////

  float zarib_r_a_l = 0.67;
  float zarib_g_a_l = 0.44;
  float zarib_b_a_l = 0.46;

  float zarib_r_t_l = 0.43;
  float zarib_g_t_l = 0.28;
  float zarib_b_t_l = 0.28;
  ///////////////

  float zarib_r_a_f = 0.52;
  float zarib_g_a_f = 0.32;
  float zarib_b_a_f = 0.31;

  float zarib_r_t_f = 0.46;
  float zarib_g_t_f = 0.27;
  float zarib_b_t_f = 0.27;

  ////////////////////////

  if (dir == 'r')
  {
    if ((red > green && blue > green && red > blue) && ((Abs(zarib_g_a_r - (float)green / ambient)) < 0.15 && (Abs(zarib_b_a_r - (float)blue / ambient)) < 0.15 && (Abs(zarib_r_a_r - (float)red / ambient)) < 0.15 && (Abs(zarib_g_t_r - ((float)green / (green + blue + red)))) < 0.05 && (Abs(zarib_b_t_r - ((float)blue / (green + blue + red)))) < 0.15 && (Abs(zarib_r_t_r - ((float)red / (green + blue + red)))) < 0.08) && (ambient > 200))
    {
      red_r = 1;
    }
    else
    {
      red_r = 0;
    }
  }

  //////////////////

  if (dir == 'l')
  {
    if ((red > green && blue > green) && (Abs(zarib_g_a_l - (float)green / ambient)) < 0.15 && (Abs(zarib_b_a_l - (float)blue / ambient)) < 0.08 && (Abs(zarib_r_a_l - (float)red / ambient)) < 0.15 && (Abs(zarib_g_t_l - (float)green / (green + blue + red)) < 0.05) && ((Abs(zarib_b_t_l - (float)blue / (green + blue + red)) < 0.07)) && ((Abs(zarib_r_t_l - (float)red / (green + blue + red))) < 0.1) && (ambient > 200))
    {
      red_l = 1;
    }
    else
    {
      red_l = 0;
    }
  }

  //////////////////

  if (dir == 'f')
  {
    if ((red > green && red > blue) && (Abs(zarib_g_a_f - (float)green / ambient)) < 0.2 && (Abs(zarib_b_a_f - (float)blue / ambient)) < 0.2 && (Abs(zarib_r_a_f - (float)red / ambient)) < 0.2 && (Abs(zarib_g_t_f - (float)green / (green + blue + red)) < 0.08) && ((Abs(zarib_b_t_f - (float)blue / (green + blue + red)) < 0.08)) && ((Abs(zarib_r_t_f - (float)red / (green + blue + red))) < 0.11) && (ambient > 150))
    {
      red_f = 1;
    }
    else
    {
      red_f = 0;
    }
  }
}

//******************************************************

void filter_green_amb(char dir)
{
  float zarib_r_a_r = 0.36; // 26 47
  float zarib_g_a_r = 0.57; // 51 52
  float zarib_b_a_r = 0.46; // 38 50

  float zarib_r_t_r = 0.26; // 22 32
  float zarib_g_t_r = 0.41; // 45 35
  float zarib_b_t_r = 0.33; // 33 33
  ///////////////

  float zarib_r_a_l = 0.34; // 46
  float zarib_g_a_l = 0.56; // 61
  float zarib_b_a_l = 0.47; //

  float zarib_r_t_l = 0.26;
  float zarib_g_t_l = 0.4;
  float zarib_b_t_l = 0.34;

  ///////////////

  float zarib_r_a_f = 0.29; //
  float zarib_g_a_f = 0.54; //
  float zarib_b_a_f = 0.33; //

  float zarib_r_t_f = 0.25; // 32
  float zarib_g_t_f = 0.47; // 35
  float zarib_b_t_f = 0.28; // 33

  ////////////////////////

  if (dir == 'r')
  {
    if ((blue > red && green > red && green > blue) && ((Abs(zarib_g_a_r - (float)green / ambient)) < 0.08 && (Abs(zarib_b_a_r - (float)blue / ambient)) < 0.1 && (Abs(zarib_r_a_r - (float)red / ambient)) < 0.1 && (Abs(zarib_g_t_r - ((float)green / (green + blue + red)))) < 0.1 && (Abs(zarib_b_t_r - ((float)blue / (green + blue + red)))) < 0.08 && (Abs(zarib_r_t_r - ((float)red / (green + blue + red)))) < 0.08))
    {
      green_r = 1;
    }
    else
    {
      green_r = 0;
    }
  }

  //////////////////

  else if (dir == 'l')
  {
    if ((blue > red && green > red && green > blue) && (Abs(zarib_g_a_l - (float)green / ambient)) < 0.1 && (Abs(zarib_b_a_l - (float)blue / ambient)) < 0.15 && (Abs(zarib_r_a_l - (float)red / ambient)) < 0.12 && (Abs(zarib_g_t_l - (float)green / (green + blue + red)) < 0.1) && ((Abs(zarib_b_t_l - (float)blue / (green + blue + red)) < 0.1)) && ((Abs(zarib_r_t_l - (float)red / (green + blue + red))) < 0.1))
    {
      green_l = 1;
    }
    else
    {
      green_l = 0;
    }
  }

  else if (dir == 'f')
  {
    if ((green > red && green > blue) && (Abs(zarib_g_a_f - (float)green / ambient)) < 0.11 && (Abs(zarib_b_a_f - (float)blue / ambient)) < 0.11 && (Abs(zarib_r_a_f - (float)red / ambient)) < 0.11 && (Abs(zarib_g_t_f - (float)green / (green + blue + red)) < 0.1) && ((Abs(zarib_b_t_f - (float)blue / (green + blue + red)) < 0.08)) && ((Abs(zarib_r_t_f - (float)red / (green + blue + red))) < 0.1) && (ambient > 220))
    {
      green_f = 1;
    }
    else
    {
      green_f = 0;
    }
  }
}

//******************************************************

void filter_blue_amb(char dir)
{
  float zarib_r_a_r = 0.38;
  float zarib_g_a_r = 0.64;
  float zarib_b_a_r = 0.52;

  float zarib_r_t_r = 0.25;
  float zarib_g_t_r = 0.42;
  float zarib_b_t_r = 0.33;
  ///////////////

  float zarib_r_a_l = 0.34;
  float zarib_g_a_l = 0.53;
  float zarib_b_a_l = 0.43;

  float zarib_r_t_l = 0.26;
  float zarib_g_t_l = 0.41;
  float zarib_b_t_l = 0.33;
  ///////////////

  float zarib_r_a_f = 0.34;
  float zarib_g_a_f = 0.53;
  float zarib_b_a_f = 0.43;

  float zarib_r_t_f = 0.26;
  float zarib_g_t_f = 0.41;
  float zarib_b_t_f = 0.33;

  ////////////////////////

  if (dir == 'r')
  {
    if ((blue > red && green > red && green > blue) && ((Abs(zarib_g_a_r - (float)green / ambient)) < 0.15 && (Abs(zarib_b_a_r - (float)blue / ambient)) < 0.1 && (Abs(zarib_r_a_r - (float)red / ambient)) < 0.15 && (Abs(zarib_g_t_r - ((float)green / (green + blue + red)))) < 0.05 && (Abs(zarib_b_t_r - ((float)blue / (green + blue + red)))) < 0.15 && (Abs(zarib_r_t_r - ((float)red / (green + blue + red)))) < 0.05) && (ambient > 500))
    {
      green_r = 1;
    }
    else
    {
      green_r = 0;
    }
  }

  //////////////////

  else if (dir == 'l')
  {
    if ((blue > red && green > red && green > blue) && (Abs(zarib_g_a_l - (float)green / ambient)) < 0.15 && (Abs(zarib_b_a_l - (float)blue / ambient)) < 0.15 && (Abs(zarib_r_a_l - (float)red / ambient)) < 0.15 && (Abs(zarib_g_t_l - (float)green / (green + blue + red)) < 0.1) && ((Abs(zarib_b_t_l - (float)blue / (green + blue + red)) < 0.05)) && ((Abs(zarib_r_t_l - (float)red / (green + blue + red))) < 0.05) && (ambient > 400))
    {
      green_l = 1;
    }
    else
    {
      green_l = 0;
    }
  }

  else if (dir == 'f')
  {
    if ((blue > red && green > red && green > blue) && (Abs(zarib_g_a_l - (float)green / ambient)) < 0.15 && (Abs(zarib_b_a_l - (float)blue / ambient)) < 0.15 && (Abs(zarib_r_a_l - (float)red / ambient)) < 0.15 && (Abs(zarib_g_t_l - (float)green / (green + blue + red)) < 0.1) && ((Abs(zarib_b_t_l - (float)blue / (green + blue + red)) < 0.05)) && ((Abs(zarib_r_t_l - (float)red / (green + blue + red))) < 0.05) && (ambient > 400))
    {
      green_f = 1;
    }
    else
    {
      green_f = 0;
    }
  }
}

//******************************************************

void check_act_green()
{

  read_color('r');
  filter_green_amb('r');
  read_color('l');
  filter_green_amb('l');

  ////////////////

  // if ((green_l == 1 || green_r == 1) && flag_green == 0) {
  //   flag_green = 1;

  //   timer_green = millis();

  //   // if (green_r == 1) led_r_green_u_on;
  //   // if (green_l == 1) led_l_green_u_on;
  // }

  // ////////////////////

  // if (flag_green == 1 && millis() - timer_green > 500) {
  //   flag_green = 0;

  //   green_l = 0;
  //   green_r = 0;

  //   // led_l_green_u_off;
  //   // led_r_green_u_off;
  // }

  ///////////////////

  if (check_black() >= 3)
  {

    if (green_l == 1 && green_r == 1 && d_l5 == 0 && d_l4 == 0 && d_r4 == 0 && d_r5 == 0 && d_r6 == 0 && d_l6 == 0 && d_l7 == 0 && d_r7 == 0)
    {
      stop(5);

      act_intersection('u'); // 180

      flag_line_2 = 1;
    }

    //////////////////////////////

    else if (green_r == 1 && d_r5 == 0 && d_r4 == 0 && d_r6 == 0 && d_r7 == 0) // agar samte rast did
    {
      stop(5);

      read_color('l');
      filter_green_amb('l');

      enc_read();

      while (enc_l() <= 180)
      {
        read_color('l');
        filter_green_amb('l');
        motor(9, -9, 0);

        if (green_l)
        {
          break;
        }
      }

      // stop(5);

      read_color('l');
      filter_green_amb('l');
      if (green_l == 1 && d_l9 == 0 && d_l10 == 0 && d_r9 == 0 && d_r10 == 0)
      {
        act_intersection('u');
      }

      else
      {
        act_intersection('r');
      }
    }

    /////////////////////////////////

    else if (green_l == 1 && d_l5 == 0 && d_l4 == 0 && d_l6 == 0 && d_l7 == 0) // agar samte chap did
    {
      stop(5);

      read_color('r');
      filter_green_amb('r');
      enc_read();

      while (enc_r() <= 180)
      {
        read_color('r');
        filter_green_amb('r');
        motor(-9, 9, 0);

        if (green_r)
        {
          break;
        }
      }

      // stop(5);

      read_color('r');
      filter_green_amb('r');
      if (green_r == 1 && d_l9 == 0 && d_l10 == 0 && d_r9 == 0 && d_r10 == 0)
      {
        act_intersection('u');
      }
      else
      {
        act_intersection('l');
      }
    }
  }
}

//******************************************************

void check_act_green_ramp()
{

  read_color('r');
  filter_green_amb('r');
  read_color('l');
  filter_green_amb('l');

  ////////////////

  if ((green_l == 1 || green_r == 1) && flag_green == 0)
  {
    zero_head();
  }

  ////////////////////

  if (flag_green == 1 && millis() - timer_green > 500)
  {
    flag_green = 0;

    green_l = 0;
    green_r = 0;
  }

  ///////////////////

  if (check_black() >= 3)
  {
    if (green_l == 1 && green_r == 1 && d_l5 == 0 && d_l4 == 0 && d_r4 == 0 && d_r5 == 0 && d_r6 == 0 && d_l6 == 0 && d_l7 == 0 && d_r7 == 0)
    {

      act_intersection_ramp('u'); // 180

      flag_line_2 = 1;
    }

    //////////////////////////////

    else if (green_r == 1 && d_r5 == 0 && d_r4 == 0 && d_r6 == 0 && d_r7 == 0) // agar samte rast did
    {

      if (ramp_down or ramp_up)
      {
        enc_read();
        while (enc_l() <= 225)
        {
          motor(15, 0);

          read_color('l');
          filter_green_amb('l');

          if (green_l == 1)
          {
            break;
          }
        }
      }

      if (ramp_right)
      {
        enc_read();
        while (enc_l() <= 250)
        {
          motor(18, -5);

          read_color('l');
          filter_green_amb('l');
          if (green_l == 1)
          {
            stop(1);
            break;
          }
        }
      }
      else if (ramp_left)
      {
        enc_read();
        while (enc_l() <= 250)
        {
          motor(18, -5);

          read_color('l');
          filter_green_amb('l');
          if (green_l == 1)
          {
            stop(1);
            break;
          }
        }
      }

      read_color('l');
      filter_green_amb('l');
      if (green_l == 1 && d_l9 == 0 && d_l10 == 0 && d_r9 == 0 && d_r10 == 0)
      {
        act_intersection_ramp('u');
        flag_line_2 = 1;
      }

      else
      {
        act_intersection_ramp('r');
        flag_line_2 = 1;
      }
    }

    /////////////////////////////////

    else if (green_l == 1 && d_l5 == 0 && d_l4 == 0 && d_l6 == 0 && d_l7 == 0) // agar samte chap did
    {
      zero_head();
      if (ramp_down or ramp_up)
      {
        enc_read();
        while (enc_r() <= 225)
        {
          motor(0, 15);

          read_color('r');
          filter_green_amb('r');
          if (green_r == 1)
          {
            break;
          }
        }
      }
      if (ramp_right)
      {
        enc_read();
        while (enc_r() <= 250)
        {
          motor(-5, 18);

          read_color('r');
          filter_green_amb('r');
          if (green_r == 1)
          {
            break;
          }
        }
      }
      else if (ramp_left)
      {
        enc_read();
        while (enc_r() <= 225)
        {
          motor(0, 15);

          read_color('r');
          filter_green_amb('r');
          if (green_r == 1)
          {
            break;
          }
        }
      }
      read_color('r');
      filter_green_amb('r');
      if (green_r == 1 && d_l9 == 0 && d_l10 == 0 && d_r9 == 0 && d_r10 == 0)
      {
        buz(50);
        act_intersection_ramp('u');
        flag_line_2 = 1;
      }
      else
      {
        buz(50);
        act_intersection_ramp('l');
        flag_line_2 = 1;
      }
    }
  }
}

//******************************************************

void act_red()
{
  stop(1);

  tft.fillScreen(RED);
  tft.setTextColor(WHITE, RED);
  tft.setTextSize(10);

  for (int i = 7; i > 0; i--)
  {
    tft.setCursor(10, 30);
    sprintf(text, "%2d", i);
    tft.print(text);

    delay(1000);
    buz(10);
  }

  tft.fillScreen(BLACK);
}

//******************************************************

void check_act_red()
{
  read_color('r');
  filter_red_amb('r');
  read_color('l');
  filter_red_amb('l');

  // if ((red_l == 1 || red_r == 1) && flag_red == 0) {
  //   flag_red = 1;

  //   time_red = millis();

  //   // if (red_r == 1)
  //   //   led_r_green_d_on;

  //   // if (red_l == 1)
  //   //   led_l_green_d_on;
  // }

  // if (flag_red == 1 && millis() - time_red > 600) {
  //   flag_red = 0;

  //   red_l = 0;
  //   red_r = 0;

  //   led_l_green_d_off;
  //   led_r_green_d_off;
  // }

  ///////////////////

  if (red_l == 1 && red_r == 1 && d_l5 == 0 && d_r5 == 0)
  {
    stop(1); // short time

    act_red();

    alarm_buz(5);
    motor(15, 15, 1000);
  }

  //////////////////////////////

  else if (red_r == 1 && d_r5 == 0) // agar samte rast red did
  {
    read_color('l');
    filter_red_amb('l');
    stop(50);
    read_color('l');
    filter_red_amb('l');
    motor(-10, -10, 80);

    enc_read();
    while (enc_l() <= 250) // agar ziyad jelo bere momkene sabzaye badi ro bekhoone
    {
      motor(5, 0);
      read_color('l');
      filter_red_amb('l');

      if (red_l == 1)
        break;
    }
    stop(50);

    // read_color('l');
    // filter_red_amb('l');

    if (red_l == 1 && red_r == 1 && d_l5 == 0 && d_r5 == 0)
    {
      stop(1); // short time

      act_red();

      alarm_buz(5);
      motor(15, 15, 1000);
    }
    else
    {
      motor(15, 15);
    }
  }

  /////////////////////////////////

  else if (red_l == 1 && d_l5 == 0) // agar samte chap did
  {
    read_color('r');
    filter_red_amb('r');
    stop(50);
    read_color('r');
    filter_red_amb('r');

    motor(-10, -10, 80);
    enc_read();
    while (enc_r() <= 250) // agar ziyad jelo bere momkene sabzaye badi ro bekhoone
    {
      motor(0, 5);
      read_color('r');
      filter_red_amb('r');

      if (red_r == 1)
        break;
    }
    stop(50);

    // read_color('r');
    // filter_red_amb('r');

    if (red_l == 1 && red_r == 1 && d_l5 == 0 && d_r5 == 0)
    {
      stop(1); // short time

      act_red();

      alarm_buz(5);
      motor(15, 15, 1000);
    }
    {
      motor(15, 15); // Tick
    }
  }
}

//******************************************************

void arm_xc(uint speed, uint deg_bazoo, uint time)
{
  dxl.writeControlTableItem(PROFILE_VELOCITY, arm_f, speed);

  dxl.setGoalPosition(arm_f, deg_bazoo);

  delay(time);
}

//******************************************************

void arm_xl(uint speed, uint deg_bazoo, uint time)
{

  dxl.writeControlTableItem(PROFILE_VELOCITY, arm_s, speed);

  dxl.setGoalPosition(arm_s, deg_bazoo);

  if (time > 0)
    delay(time);
}

//******************************************************

void arm_xc_timed(uint speed, uint deg, uint t2)
{
  int i_p = 0, calc;

  i_p = Abs(deg_arm_f - deg);

  dxl.writeControlTableItem(PROFILE_VELOCITY, arm_f, speed);

  dxl.setGoalPosition(arm_f, deg);

  calc = (int)(i_p * (1.2 * 100 / speed));

  delay(calc + t2);
}

//******************************************************

void arm_xl_timed(uint speed, uint deg, uint t2)
{
  int i_p = 0, calc;

  i_p = Abs(deg_arm_s - deg);

  dxl.writeControlTableItem(PROFILE_VELOCITY, arm_s, speed);

  dxl.setGoalPosition(arm_s, deg);

  calc = (int)(i_p * (2.5 * 100 / speed));

  delay(calc + t2);
}

//******************************************************

void grip_l(uint speed, uint deg_grip_l, uint time)
{
  dxl.writeControlTableItem(PROFILE_VELOCITY, grip_l_id, speed);

  dxl.setGoalPosition(grip_l_id, deg_grip_l);

  if (time > 0)
    delay(time);
}

//******************************************************

void grip_r(uint speed, uint deg_grip_r, uint time)
{
  dxl.writeControlTableItem(PROFILE_VELOCITY, grip_r_id, speed);

  dxl.setGoalPosition(grip_r_id, deg_grip_r);
  if (time > 0)
    delay(time);
}

//******************************************************

void grip_black()
{
  dxl.setGoalVelocity(grip_r_id, 30);
  dxl.setGoalVelocity(grip_l_id, 30);

  dxl.setGoalPosition(grip_l_id, grip_open_l); // hedaite
  delay(550);
  dxl.setGoalPosition(grip_r_id, grip_open_r + 250);
}

//******************************************************

void grip_silver()
{
  dxl.setGoalVelocity(grip_r_id, 30);
  dxl.setGoalVelocity(grip_l_id, 30);

  dxl.setGoalPosition(grip_r_id, grip_open_r);
  delay(550);
  dxl.setGoalPosition(grip_l_id, grip_open_l - 250);
}

//******************************************************

void open_grip(uint speed, uint time)
{

  dxl.writeControlTableItem(PROFILE_VELOCITY, grip_l_id, speed);
  dxl.writeControlTableItem(PROFILE_VELOCITY, grip_r_id, speed);

  dxl.setGoalPosition(grip_l_id, grip_open_l_red);
  dxl.setGoalPosition(grip_r_id, grip_open_r_red);

  delay(time);
}
//******************************************************

void separator(uint speed, uint deg_sep, uint time)
{
  dxl.writeControlTableItem(PROFILE_VELOCITY, sep_id, speed);

  dxl.setGoalPosition(sep_id, deg_sep);

  if (time > 0)
    delay(time);
}

//******************************************************

void close_grip_ball(int speed, int time)
{
  dxl.writeControlTableItem(PROFILE_VELOCITY, grip_l_id, 1023);
  dxl.writeControlTableItem(PROFILE_VELOCITY, grip_r_id, 1023);

  dxl.setGoalPosition(grip_l_id, grip_close_ball_l);
  dxl.setGoalPosition(grip_r_id, grip_close_ball_r);

  delay(time);
}

//******************************************************

void robot_normal()
{
  init_dynamixel_motors();
  tft.fillScreen(BLACK);
  tft.setTextSize(2);
  tft.setTextColor(WHITE);
  tft.setCursor(5, 50);
  tft.print("Robot Normal");

  // tft.setCursor(5, 80);
  // tft.print(dxl.getPresentPosition(sep_id));
  // delay(1000);

  arm_xl_timed(100, arm_2_normal, 0);
  arm_xc_timed(100, arm_1_normal, 0);

  grip_l(400, grip_open_l, 0);
  grip_r(400, grip_open_r, 0);

  delay(250);

  separator(400, sep_silver, 0);
  Box_timed(120, Box_down, 400);

  dxl.torqueOff(box);
  dxl.torqueOff(sep_id);

  tft.fillScreen(BLACK);
}

//******************************************************

void check_act_obstacle()
{
  if (millis() - time_obs > 200)
  {
    time_obs = millis();
    dc = distance_f_c;
    if (dc < 60 && dc > 5)
    {
      stop(50);
      dc = distance_f_c;
      if (dc < 60 && dc > 5)
      {
        drf = distance_f_r;
        dlf = distance_f_l;
        dc = distance_f_c;
        if ((dlf < 60 and dc < 60) or (dc < 60 and drf < 60))
        {
          check_ramp();

          if (ramp_right or ramp_left or ramp_up or ramp_down)
            act_obstacle_ramp(1, 35);
          else
            act_obstacle(1, 35);
        }
      }
      else
        motor(70, 70, 0);
    }
  }
}

//******************************************************

void check_ramp()
{
  cmps14();

  if (pitch <= 33 && pitch >= 18) // ramp down
  {
    ramp_up = 0;
    ramp_down = 1;
    ramp_left = 0;
    ramp_right = 0;
  }

  else if (pitch <= 240 && pitch > 220) // ramp up
  {
    ramp_up = 1;
    ramp_down = 0;
    ramp_left = 0;
    ramp_right = 0;
  }

  else if (roll <= 32 && roll >= 20) // ramp left
  {
    ramp_up = 0;
    ramp_down = 0;
    ramp_left = 1;
    ramp_right = 0;
  }

  else if (roll >= 230 && roll <= 245) // ramp right
  {
    ramp_up = 0;
    ramp_down = 0;
    ramp_left = 0;
    ramp_right = 1;
  }

  else // ramp normal
  {
    ramp_up = 0;
    ramp_down = 0;
    ramp_left = 0;
    ramp_right = 0;
  }
}

//******************************************************

void act_obstacle(bool no_stike, int dist)
{
  char dir;
  uint t_turn_break = 1650;

  extra_obs = 200;
  extra_mid = 400;
  extra_back = -100;

  tft.setTextSize(6);
  tft.setTextColor(WHITE, ORANGE);

  tft.fillScreen(ORANGE);
  tft.setCursor(65, 40);
  tft.print("O");

  delay(150);

  ///////////////////////////////

  // while (1) {
  //   motor(20, 20, 0);

  //   if (mic_lf == 0 or mic_rf == 0 or enc_r() > 400) {
  //     stop(0);
  //     break;
  //   }
  // }

  // if (ramp_up == 1) {
  //   //arm(200, arm_mid, 1500);
  //   act_obstacle_ramp(1, 55);
  // }

  // else {

  enc_read();

  dlf = distance_f_l;
  drf = distance_f_r;

  while (enc_r() < 700 && ir_obs == 0 && mic_rf == 1 && mic_lf == 1 && dlf > 25 && drf > 25)
  {

    dlf = distance_f_l;
    drf = distance_f_r;

    motor(10, 10);
  }

  ////////////////////////////

  motor_er(-40, -40, 600, 0); // BACK
  stop(50);

  //////////////////////////////

  dr = distance_u_r;
  dl = distance_u_l;

  // if (dir_obstacle_eep == 'a') {

  //   if (dr > 350 and dl > 350) {
  //     chance_obs_eep = !framRead(chance_obs_eep_cell);
  //     framWrite(chance_obs_eep_cell, chance_obs_eep);

  //     if (chance_obs_eep == 1) {
  //       dir = 'r';
  //     } else {
  //       dir = 'l';
  //     }
  //   }

  //   else {
  //     if (dr >= dl) {
  //       dir = 'r';
  //     } else {
  //       dir = 'l';
  //     }
  //   }
  // } else {
  //   if (dir_obstacle_eep == 'r') {
  //     dir = 'r';
  //   } else {
  //     dir = 'l';
  //   }
  // }
  for (int i = 0; i < 5; i++)
  {
    dr = distance_u_r;
    dl = distance_u_l;

    delay(100);

    if (dr > dl)
    {
      n_vl_r++;
    }
    else
    {
      n_vl_l++;
    }
  }

  if (n_vl_r > n_vl_l)
  {
    dir = 'r';

    tft.fillScreen(ORANGE);
    tft.setCursor(65, 40);
    tft.print("R");
  }
  else
  {
    dir = 'l';

    tft.fillScreen(ORANGE);
    tft.setCursor(65, 40);
    tft.print("L");
  }

  ///////////////////////////////////

  if (dir == 'r')
  {
    stop(100);
    zero_head();
    cmp_turn_step_15('r', 6000);

    motor_el(60, 60, str_1_turn_eep, 0);

    motor_el(-60, 60, deg_45_eep, 0);

    motor_el(60, 60, str_2_turn_eep, 0);

    ////////////////////////////

    while (d_sil_l2 == 0 or d_sil_l1 == 0)
    {
      motor(arc_low_eep, arc_high_eep, 0); // arc

      if (mic_lf == 0)
      {
        motor_er(-40, -40, 150, 0);
        motor_er(40, -40, 650, 0);

        motor_er(15, 15, 200, 0); // str
      }

      if (no_stike == 1)
      {
        dl = distance_u_l;
        if (dl < 30 && dl > 15) // chasbide be mane
        {
          motor_er(-20, -20, 350, 0);
          motor_er(20, -20, 400, 0); //

          motor_er(20, 20, 250, 10); // str
        }
      }
    }

    ///////////////////////

    enc_read();
    while (d_l6 == 0 and d_m_l3 == 0 and d_m_l2 == 0 and d_m_l1 == 0 and d_b_c == 0)
    {
      motor(70, 70);

      if (enc_l() > 2500)
      {
        stop(100);

        alarm_break();

        break;
      }
    }

    //////////////////////////////////////

    motor_el(80, -20, 1500, 0 + 900 * tamrin); // tak motor

    //////////////////////

    enc_read();
    while (d_b_c == 0 && d_b_r1 == 0) // charkhesh
    {
      motor(15, -15, 0);

      if (enc_l() > t_turn_break)
      {
        stop(50);
        alarm_break();

        tft.fillScreen(RED);

        break;
      }
    }
    stop(50);
  }

  ////////////////////////

  else if (dir == 'l')
  {
    stop(100);
    zero_head();

    cmp_turn_step_15('l', 6000);

    motor_el(60, 60, str_1_turn_eep, 0);

    motor_el(60, -60, deg_45_eep, 0);

    motor_el(60, 60, str_2_turn_eep, 0);

    while (d_sil_r1 == 0 or d_sil_r2 == 0)
    {
      if (d_sil_r1 == 1 or d_sil_r2 == 1)
        break;
      motor(arc_high_eep, arc_low_eep, 0); // arc

      if (mic_rf == 0)
      {
        motor_el(-40, -40, 150, 0);
        motor_el(-40, 40, 650, 0); // tik

        motor_el(15, 15, 200, 0); // str
      }

      if (no_stike == 1)
      {
        dr = distance_u_r;
        if (distance_u_r < 30 && distance_u_r > 15) // chasbide be mane
        {
          motor_el(-20, -20, 350, 0);
          motor_el(-20, 20, 400, 0); // tik

          motor_er(20, 20, 250, 10); // str
        }
      }
    }
    ///////////////////////
    enc_read();
    while (d_r6 == 0 and d_m_r3 == 0 and d_m_r2 == 0 and d_m_r1 == 0 and d_b_c == 0)
    {
      motor(70, 70);

      if (enc_l() > 2200)
      {
        alarm_break();

        break;
      }
    }

    //////////////////////////

    motor_er(0, 80, 1250, 0 + 900 * tamrin); // tak motor

    ////////////////////////////////

    enc_read();
    while (d_b_c == 0 && d_b_l1 == 0)
    {

      motor(-15, 15, 0);

      if (enc_r() > t_turn_break)
      { // sok naz azer
        stop(50);
        alarm_break();

        tft.fillScreen(RED);

        break;
      }
    }
  }

  enc_read();

  while (1)
  {
    motor(-15, -15);

    if (mic_lb == 0 or mic_rb == 0 or enc_r() > 900)
    {
      stop(0);

      break;
    }
  }
  // motor_er(-30, -30, 700, 0);

  /////////////////////////////

  extra_obs = 0;
  motor(70, 70, 0); // vai nasta
                    // }

  tft.fillScreen(BLACK);
}

//******************************************************

void act_obstacle_ramp(bool no_stike, int dist)
{
  char dir;
  uint t_turn_break = 1650;

  extra_obs = 200;
  extra_mid = 400;
  extra_back = 150;

  tft.setTextSize(6);
  tft.setTextColor(WHITE, ORANGE);

  tft.fillScreen(ORANGE);
  tft.setCursor(35, 40);
  tft.print("O-R");

  delay(150);

  ///////////////////////////////

  enc_read();

  dlf = distance_f_l;
  drf = distance_f_r;

  while (enc_r() < 700 && ir_obs == 0 && mic_rf == 1 && mic_lf == 1 && dlf > 30 && drf > 30)
  {

    dlf = distance_f_l;
    drf = distance_f_r;

    motor(10 + ramp_right * 5, 10 + ramp_left * 5);
  }

  ////////////////////////////

  if (ramp_left == 1 or ramp_right == 1)
    motor_er(-40, -40, 1200, 0); // BACK
  else if (ramp_up == 1)
    motor_er(-40, -40, 400, 0);
  else if (ramp_down == 1)
    motor_er(-40, -40, 1000, 0);

  //////////////////////////////

  dr = distance_u_r;
  dl = distance_u_l;

  for (int i = 0; i < 5; i++)
  {
    dr = distance_u_r;
    dl = distance_u_l;
    if (dr > dl)
    {
      n_vl_r++;
    }
    else
    {

      n_vl_l++;
    }
  }

  ///////////////////////////////////
  if (ramp_left == 1)
  {
    zero_head_debug();
    for (int i = 0; i < 5; i++)
    {
      t_turn = millis();
      zero_head();

      while (getZeroedHeading() < 12 and millis() - t_turn < 1200)
      {
        if (getZeroedHeading_debug() > 70)
          break;
        motor(45 + i * 2, -25 + i);
      }
    }
    stop(50);

    motor_er(60, 60, 2700, 10);

    ////////////////////////////

    while (d_sil_l2 == 0 or d_sil_l1 == 0)
    {
      motor(25, 90, 0); // arc

      if (mic_lf == 0)
      {
        motor_el(-40, -40, 150, 0);
        motor_el(40, -40, 650, 0);

        motor_el(15, 15, 200, 0); // str
      }

      if (no_stike == 1)
      {
        dl = distance_u_l;
        if (dl < 30 && dl > 15) // chasbide be mane
        {
          motor_el(25, -10, 450, 0); //

          motor_el(20, 20, 250, 10); // str
        }
      }
    }

    ///////////////////////

    enc_read();
    while (d_l6 == 0 and d_m_l3 == 0 and d_m_l2 == 0 and d_m_l1 == 0 and d_b_c == 0)
    {
      motor(70, 70);

      if (enc_l() > 2500)
      {
        stop(100);

        alarm_break();

        break;
      }
    }

    //////////////////////////////////////

    motor_er(80, -20, 1800, 0 + 900 * tamrin); // tak motor

    //////////////////////

    enc_read();
    while (d_b_c == 0 && d_b_r1 == 0) // charkhesh
    {
      motor(15, -15, 0);

      if (enc_l() > t_turn_break)
      {
        stop(50);
        alarm_break();

        tft.fillScreen(RED);

        break;
      }
    }
    stop(50);
  }

  else if (ramp_right == 1)
  {
    zero_head_debug();
    for (int i = 0; i < 5; i++)
    {
      t_turn = millis();
      zero_head();

      while (getZeroedHeading() > -12 and millis() - t_turn < 1200)
      {
        if (getZeroedHeading_debug() < -70)
          break;
        motor(-25 + i, 45 + i * 2);
      }
    }
    stop(50);

    motor_el(60, 60, 2700, 10);

    ////////////////////////////

    while (d_sil_r2 == 0 or d_sil_r1 == 0)
    {
      motor(90, 25, 0); // arc

      if (mic_lf == 0)
      {
        motor_er(-40, -40, 150, 0);
        motor_er(40, -40, 650, 0);

        motor_er(15, 15, 200, 0); // str
      }

      if (no_stike == 1)
      {
        dl = distance_u_l;
        if (dl < 30 && dl > 15) // chasbide be mane
        {
          motor_el(25, -10, 450, 0); //

          motor_el(20, 20, 250, 10); // str
        }
      }
    }

    ///////////////////////

    enc_read();
    while (d_r6 == 0 and d_m_r3 == 0 and d_m_r2 == 0 and d_m_r1 == 0 and d_b_c == 0)
    {
      motor(70, 70);

      if (enc_r() > 2500)
      {
        stop(100);

        alarm_break();

        break;
      }
    }

    //////////////////////////////////////

    motor_el(-20, 80, 1800, 0 + 900 * tamrin); // tak motor

    //////////////////////

    enc_read();
    while (d_b_c == 0 && d_b_l1 == 0) // charkhesh
    {
      motor(-15, 15, 0);

      if (enc_r() > t_turn_break)
      {
        stop(50);
        alarm_break();

        tft.fillScreen(RED);

        break;
      }
    }
    stop(50);
  }

  else if (ramp_up == 1)
  {

    for (int i = 0; i < 5; i++)
    {
      dr = distance_u_r;
      dl = distance_u_l;

      delay(100);

      if (dr > dl)
      {
        n_vl_r++;
      }
      else
      {

        n_vl_l++;
      }
    }

    if (n_vl_r > n_vl_l)
    {
      dir = 'r';

      tft.fillScreen(ORANGE);
      tft.setCursor(65, 40);
      tft.print("R");
    }
    else
    {
      dir = 'l';

      tft.fillScreen(ORANGE);
      tft.setCursor(65, 40);
      tft.print("L");
    }

    if (dir == 'r')
    {
      tft.setTextSize(2);

      for (int i = 0; i < 5; i++)
      {
        t_turn = millis();
        zero_head();
        tft.fillScreen(BLACK);

        while (getZeroedHeading() < 10 and millis() - t_turn < 1000)
        {
          if (getZeroedHeading() > 50)
            break;
          motor(50 - i * 4, -20 + i);
        }
      }
      stop(50);

      ////////////////////////////

      while (d_sil_l2 == 0 or d_sil_l1 == 0)
      {
        motor_full(10, 50);

        if (mic_lf == 0)
        {
          motor_er(-40, -40, 150, 0);
          motor_er(40, -40, 650, 0);

          motor_er(15, 15, 200, 0); // str
        }

        if (no_stike == 1)
        {
          dl = distance_u_l;
          if (dl < 30 && dl > 15) // chasbide be mane
          {
            motor_er(-20, -20, 200, 0);
            motor_er(20, -20, 350, 0); //

            motor_er(20, 20, 200, 10); // str
          }
        }
      }

      ///////////////////////

      enc_read();
      while (d_l9 == 0 and d_b_l3 == 0 and d_b_l2 == 0 and d_b_l1 == 0 and d_b_c == 0)
      {
        motor(70, 70);

        if (enc_l() > 2500)
        {
          stop(100);

          alarm_break();

          break;
        }
      }

      //////////////////////////////////////

      motor_el(80, 50, 1500, 0 + 900 * tamrin); // tak motor

      //////////////////////

      enc_read();
      while (d_b_c == 0 && d_b_r1 == 0) // charkhesh
      {
        motor(18, -15, 0);

        if (enc_l() > t_turn_break)
        {
          stop(50);
          alarm_break();

          tft.fillScreen(RED);

          break;
        }
      }
      stop(50);
    }

    ////////////////////////

    else if (dir == 'l')
    {
      tft.setTextSize(2);

      for (int i = 0; i < 5; i++)
      {
        t_turn = millis();
        zero_head();
        tft.fillScreen(BLACK);
        while (getZeroedHeading() > -10 and millis() - t_turn < 1000)
        {
          if (getZeroedHeading() < -50)
            break;

          motor(-20 + i, 50 - i * 4);
        }
      }
      stop(50);

      ////////////////////////////

      while (d_sil_r2 == 0 or d_sil_r1 == 0)
      {
        motor_full(50, 10);

        if (mic_lf == 0)
        {
          motor_el(-40, -40, 150, 0);
          motor_el(-40, 40, 650, 0);

          motor_el(15, 15, 200, 0); // str
        }

        if (no_stike == 1)
        {
          dl = distance_u_l;
          if (dl < 30 && dl > 15) // chasbide be mane
          {
            motor_el(-20, -20, 200, 0);
            motor_el(-20, 20, 350, 0); //

            motor_el(20, 20, 200, 10); // str
          }
        }
      }

      ///////////////////////

      enc_read();
      while (d_r9 == 0 and d_b_r3 == 0 and d_b_r2 == 0 and d_b_r1 == 0 and d_b_c == 0)
      {
        motor(70, 70);

        if (enc_r() > 2500)
        {
          stop(100);

          alarm_break();

          break;
        }
      }

      //////////////////////////////////////

      motor_er(50, 80, 1500, 0 + 900 * tamrin); // tak motor

      //////////////////////

      enc_read();
      while (d_b_c == 0 && d_b_l1 == 0) // charkhesh
      {
        motor(-15, 18, 0);

        if (enc_r() > t_turn_break)
        {
          stop(50);
          alarm_break();

          tft.fillScreen(RED);

          break;
        }
      }
      stop(50);

      ///////////////////////
    }
  }

  else if (ramp_down == 1)
  {

    for (int i = 0; i < 5; i++)
    {
      dr = distance_u_r;
      dl = distance_u_l;

      delay(100);

      if (dr > dl)
      {
        n_vl_r++;
      }
      else
      {

        n_vl_l++;
      }
    }

    if (n_vl_r > n_vl_l)
    {
      dir = 'r';

      tft.fillScreen(ORANGE);
      tft.setCursor(65, 40);
      tft.print("R");
    }
    else
    {
      dir = 'l';

      tft.fillScreen(ORANGE);
      tft.setCursor(65, 40);
      tft.print("L");
    }

    if (dir == 'r')
    {
      tft.setTextSize(2);

      for (int i = 0; i < 5; i++)
      {
        t_turn = millis();
        zero_head();
        tft.fillScreen(BLACK);

        while (getZeroedHeading() < 10 and millis() - t_turn < 1000)
        {
          if (getZeroedHeading() > 50)
            break;
          motor(30 - i * 2, -50 + i + 4);
        }
      }
      stop(50);

      ////////////////////////////

      while (d_sil_l2 == 0 or d_sil_l1 == 0)
      {
        motor_full(10, 30);

        if (mic_lf == 0)
        {
          motor_er(-40, -40, 150, 0);
          motor_er(40, -40, 650, 0);

          motor_er(15, 15, 200, 0); // str
        }

        if (no_stike == 1)
        {
          dl = distance_u_l;
          if (dl < 30 && dl > 15) // chasbide be mane
          {
            motor_er(-20, -20, 200, 0);
            motor_er(20, -20, 350, 0); //

            motor_er(20, 20, 200, 10); // str
          }
        }
      }

      ///////////////////////

      enc_read();
      while (d_l9 == 0 and d_b_l3 == 0 and d_b_l2 == 0 and d_b_l1 == 0 and d_b_c == 0)
      {
        motor(70, 70);

        if (enc_l() > 2500)
        {
          stop(100);

          alarm_break();

          break;
        }
      }

      //////////////////////////////////////

      motor_el(80, 50, 1500, 0 + 900 * tamrin); // tak motor

      //////////////////////

      enc_read();
      while (d_b_c == 0 && d_b_r1 == 0) // charkhesh
      {
        motor(18, -15, 0);

        if (enc_l() > t_turn_break)
        {
          stop(50);
          alarm_break();

          tft.fillScreen(RED);

          break;
        }
      }
      stop(50);
    }

    ////////////////////////

    else if (dir == 'l')
    {
      tft.setTextSize(2);

      for (int i = 0; i < 5; i++)
      {
        t_turn = millis();
        zero_head();
        tft.fillScreen(BLACK);
        while (getZeroedHeading() > -10 and millis() - t_turn < 1000)
        {
          if (getZeroedHeading() < -50)
            break;

          motor(-20 + i, 50 - i * 4);
        }
      }
      stop(50);

      ////////////////////////////

      while (d_sil_r2 == 0 or d_sil_r1 == 0)
      {
        motor_full(50, 10);

        if (mic_lf == 0)
        {
          motor_el(-40, -40, 150, 0);
          motor_el(-40, 40, 650, 0);

          motor_el(15, 15, 200, 0); // str
        }

        if (no_stike == 1)
        {
          dl = distance_u_l;
          if (dl < 30 && dl > 15) // chasbide be mane
          {
            motor_el(-20, -20, 200, 0);
            motor_el(-20, 20, 350, 0); //

            motor_el(20, 20, 200, 10); // str
          }
        }
      }

      ///////////////////////

      enc_read();
      while (d_r9 == 0 and d_b_r3 == 0 and d_b_r2 == 0 and d_b_r1 == 0 and d_b_c == 0)
      {
        motor(70, 70);

        if (enc_r() > 2500)
        {
          stop(100);

          alarm_break();

          break;
        }
      }

      //////////////////////////////////////

      motor_er(50, 80, 1500, 0 + 900 * tamrin); // tak motor

      //////////////////////

      enc_read();
      while (d_b_c == 0 && d_b_l1 == 0) // charkhesh
      {
        motor(-15, 18, 0);

        if (enc_r() > t_turn_break)
        {
          stop(50);
          alarm_break();

          tft.fillScreen(RED);

          break;
        }
      }
      stop(50);

      ///////////////////////
    }
  }

  ////////////////////////

  enc_read();

  while (1)
  {
    motor(-15, -15);

    if (mic_lb == 0 or mic_rb == 0 or enc_r() > 1250)
    {
      stop(0);

      break;
    }
  }

  // motor_er(-30, -30, 700, 0);

  /////////////////////////////

  extra_obs = 0;
  motor(50, 50, 0); // vai nasta
                    // }

  tft.fillScreen(BLACK);
}

//******************************************************

void align_forward(uint break_time, bool break_condition_1 = 0, bool break_condition_2 = 0)
{
  unsigned long int tt;

  flag_dont_go_out = 0;
  flag_broke_by_dont_go_out = 0;

  tt = millis();

  while (1)
  {
    dont_go_out();
    if (flag_dont_go_out == 1)
    {
      flag_dont_go_out = 0;
      flag_broke_by_dont_go_out = 1;
      break;
    }
    if (ir_ball == 1)
    {
      catch_the_victim();
      flag_sucsses_ball = 1;
      tt -= 3000;
    }

    if (mic_lf == 0 && mic_rf == 0)
    {
      flag_tarazed = 1;
      // buz(500);
      stop(1);
      for (int i = 0; i <= 25; i++)
      {
        if (ir_ball == 1)
        {
          catch_the_victim();
          break;
        }
        delay(1);
      }
      break;
    }
    else if (mic_lf == 1 && mic_rf == 1)
    {
      motor(80, 80, 0);
    }

    else if (mic_lf == 1 && mic_rf == 0)
    {
      motor(-30, -30, 3);
      motor(90, -15, 0);
      delay(100);
    }

    else if (mic_lf == 0 && mic_rf == 1)
    {
      motor(-30, -30, 3);
      motor(-15, 90, 0);
      delay(100);
    }

    if ((millis() - tt > break_time))
    {
      motor_er(-60, -60, 200, 10);
      break;
    }
    if (break_condition_1 == 1 || break_condition_2 == 1)
      break;
  }
  dont_go_out();

  if (flag_dont_check_side == 0)
  {
    if (n_side <= 3)
      flag_search_side = 1;
    else
    {
      flag_search_side = 0;
      flag_dont_check_side = 1;
    }
  }

  arm_xl(400, arm_2_ball + 10, 100);
  arm_xc(400, arm_1_ball, 100);

  check_flag_side();
}

//******************************************************

void align_forward_ball(uint break_time, bool break_condition_1 = 0, bool break_condition_2 = 0)
{
  unsigned long int tt;

  tt = millis();
  while (1)
  {
    // arm_2(400, arm_2_ball + 3, 0);
    // arm_1(400, arm_1_ball, 0);
    // open_grip(1023, 0);
    dont_go_out();

    get_distance();
    check_victim_vl_side('n');

    if (ir_ball == 1)
    {
      catch_the_victim();
      flag_sucsses_ball = 1;
      tt -= 3000;
    }

    if (mic_lf == 0 && mic_rf == 0)
    {
      flag_tarazed = 1;
      stop(1);
      for (int i = 0; i <= 25; i++)
      {
        if (ir_ball == 1)
        {
          catch_the_victim();
          break;
        }
        delay(1);
      }
      break;
    }

    else if (mic_lf == 1 && mic_rf == 1)
    {
      motor(80, 80, 0);
    }

    else if (mic_lf == 1 && mic_rf == 0)
    {
      motor(-30, -30, 3); // back
      motor(90, -15, 0);
      delay(100);
    }

    else if (mic_lf == 0 && mic_rf == 1)
    {
      motor(-30, -30, 3); // back
      motor(-15, 90, 0);
      delay(100);
    }

    if ((millis() - tt > break_time))
    {
      motor_er(-60, -60, 200, 10);
      break;
    }
    if (break_condition_1 == 1 || break_condition_2 == 1)
      break;
  }

  dont_go_out();
  // dont_go_out_vl(350);

  //  tft.fillScreen(BLACK);
  //  sprintf(text, "uf = % 4d", distance(uf, 20));
  //  tft.setCursor(0, 50);
  //  tft.print(text);

  if (flag_dont_check_side == 0)
  {
    if (n_side <= 3)
      flag_search_side = 1;
    else
    {
      flag_search_side = 0;
      flag_dont_check_side = 1;
    }
  }

  //////////////
  arm_xl(400, arm_2_ball + 10, 100);
  arm_xc(400, arm_1_ball, 100);
}

//******************************************************

void align_back(uint break_time, bool break_condition_1)
{
  unsigned long int tt;

  tt = millis();

  while (1)
  {
    if ((millis() - tt > break_time) || break_condition_1 == 1)
    {
      break;
    }

    dont_go_out_back();

    ///////////////////////////

    if (mic_lb == 1 && mic_rb == 1)
    {
      motor(-30, -30, 0);
      delay(50);
    }

    else if (mic_lb == 1 && mic_rb == 0)
    {
      motor(-15, 30, 0);
      delay(50);
    }

    else if (mic_lb == 0 && mic_rb == 1)
    {
      motor(30, -15, 0);
      delay(50);
    }

    else if (mic_lb == 0 && mic_rb == 0)
    {
      break;
    }
  }

  motor(-10, -10, 150);
  // buz(20);
}

//******************************************************

void check_if_robot_is_stuck(uint x)
{
  if (enc_r() > x)
  {
    alarm_buz(5);

    motor(-40, -40, 900);
    dont_go_out();
    // dont_go_out_vl(350);

    if (next_turn == 'r')
    {
      zero_head();
      cmp_turn_step_15('r', 6000);
    }
    else
    {
      zero_head();
      cmp_turn_step_15('l', 6000);
    }

    enc_read();
  }
}

//******************************************************

uint n_check_silver(void)
{
  uint silver = 0;

  if (a_sil_l2 <= sil_l2_eep)
    silver++;
  if (a_sil_l1 <= sil_l1_eep)
    silver++;
  if (a_sil_r2 <= sil_r2_eep)
    silver++;
  if (a_sil_r1 <= sil_r1_eep)
    silver++;

  return silver;
}

//******************************************************

bool check_silver(void)
{
  if (a_sil_l1 <= sil_l1_eep && a_sil_l2 <= sil_l2_eep && a_sil_r1 <= sil_r1_eep && a_sil_r2 <= sil_r2_eep)
  {
    flag_sil = '2';
    return 1;
  }
  else if (a_sil_l1 <= sil_l1_eep && a_sil_l2 <= sil_l2_eep)
  {
    flag_sil = 'l';
    return 1;
  }
  else if (a_sil_r1 <= sil_r1_eep && a_sil_r2 <= sil_r2_eep)
  {
    flag_sil = 'r';
    return 1;
  }
  else
    return 0;
}

//******************************************************

void align_mic_silver()
{
  if (mic_lf == 0)
  {
    flag_disable = 1;
    ///////////////////

    motor(-20, -20, 300);
    motor(20, -20, 150);
    while (check_silver() == 0)
    {
      motor(10, 10, 0);
    }
    stop(0);
    t1 = millis() - 500;

    motor(20, 20, 500);
    flag_disable = 0;
  }

  else if (mic_rf == 0)
  {
    flag_disable = 1;
    ///////////////////

    motor(-20, -20, 300);
    motor(-20, 20, 150);
    while (check_silver() == 0)
    {
      motor(10, 10, 0);
    }
    stop(0);
    t1 = millis() - 500;

    motor(20, 20, 500);
    flag_disable = 0;
  }
}

//******************************************************

void align_with_exit_evac(int tb)
{
  extra_evac = 300;
  motor_er(-20, -20, 650, 100);

  while (1)
  {
    motor(15, 15, 0);
    if (d_sil_l2 == 1 or d_sil_l1 == 1 or d_sil_r1 == 1 or d_sil_r2 == 1)
    {
      stop(0);
      break;
    }
  }
  check_silver();
  if ((d_sil_l2 == 0 and d_sil_l1 == 0) and (d_sil_r2 == 1 and d_sil_r1 == 1))
  {
    stop(100);
    t1 = millis();
    while (1)
    {
      motor(40, 0);

      align_mic_silver();

      if (d_sil_l1 && d_sil_l2)
      {
        stop(10);
        break;
      }

      if (millis() - t1 > tb)
      {
        stop(10);
        alarm_break();
        break;
      }
    }
    stop(10);

    motor_el(10, 0, 200, 0); // tik

    stop(200);
  }
  else if ((d_sil_l2 == 1 and d_sil_l1 == 1) and (d_sil_r2 == 0 and d_sil_r1 == 0))
  {
    stop(100);
    t1 = millis();
    while (1)
    {
      motor(0, 40);
      align_mic_silver();
      if (d_sil_r1 == 1 and d_sil_r2 == 1)
      {
        stop(10);
        break;
      }

      if (millis() - t1 > tb)
      {
        stop(10);
        alarm_break();
        break;
      }
    }

    stop(10);

    motor_er(0, 10, 200, 0); // tik

    stop(100 + tamrin * 3000);
  }
  else
  {
    stop(100);

    motor_er(50, 50, 1000, 200); // str
  }
}

//******************************************************

void dont_go_out(void)
{
  if (flag_sucsses_out == 0)
  {
    if (check_silver() == 1 || check_black() > 1)
    {
      stop(50);

      tft.fillScreen(RED);

      tft.setTextSize(2);
      tft.setTextColor(BLUE_LIGHT);

      tft.setCursor(10, 55);
      tft.print("Dont go out");

      flag_dont_go_out = 1;
      get_distance();
      if (dr > dl)
      {
        motor_el(-60, 0, 1000, 50);

        motor_er(0, -60, 1000, 50);

        motor_er(-60, -60, 800, 0);

        if (flag_khas_dont == 1)
        {
          stop(100);
          zero_head();
          turn_180_cmp('r', 6000, 179);
          flag_khas_dont = 0;
        }
        else if (flag_search_side == 1)
        {
          stop(100);
          zero_head();
          cmp_turn_step_15('r', 6000);
        }
        else if (dl < dr)
        {
          stop(100);
          zero_head();
          cmp_turn_step_15(next_turn, 6000);
          dir_turn_evac = 'r';
        }
        else
        {
          stop(100);
          zero_head();
          cmp_turn_step_15(next_turn, 6000);
          dir_turn_evac = 'l';
        }
      }
      else
      {
        motor_er(0, -60, 1000, 50);

        motor_el(-60, 0, 1000, 50);

        motor_er(-60, -60, 800, 0);

        if (flag_khas_dont == 1)
        {
          stop(100);
          zero_head();
          turn_180_cmp('r', 6000, 179);
          flag_khas_dont = 0;
        }
        else if (flag_search_side == 1)
        {
          stop(100);
          zero_head();
          cmp_turn_step_15('r', 6000);
        }
        else if (dl < dr)
        {
          stop(100);
          zero_head();
          cmp_turn_step_15(next_turn, 6000);
          dir_turn_evac = 'r';
        }
        else
        {
          stop(100);
          zero_head();
          cmp_turn_step_15(next_turn, 6000);
          dir_turn_evac = 'l';
        }
      }
      motor(20, 20, 0);
    }
    tft.fillScreen(BLACK);
  }
}

//******************************************************

void dont_go_out_silver(void)
{
  bool flag_align = 0;
  if (flag_sucsses_out == 0)
  {
    if (check_silver() == 1)
    {
      stop(50);
      alarm_buz(5);

      tft.fillScreen(RED);

      tft.setTextSize(2);
      tft.setTextColor(BLUE_LIGHT);

      tft.setCursor(10, 55);
      tft.print("Dont go out");

      flag_dont_go_out = 1;

      motor_el(-20, 0, 1500, 100);

      motor_er(0, -20, 1500, 100);

      motor_er(-20, -20, 800, 0);

      cmp_turn_90('l', 3000, 40);
    }
  }
  motor(20, 20, 0);

  flag_start_turn = 0;
}

//******************************************************

void dont_go_out_back(void)
{
  bool flag_align = 0;

  if ((a_r10 < 400 or a_l10 < 400 or a_b_c < 400) || (d_r10 or d_l10 or d_b_c))
  {
    stop(50);
    alarm(5);

    tft.fillScreen(RED);

    tft.setTextSize(2);
    tft.setTextColor(BLUE_LIGHT);

    tft.setCursor(10, 55);
    tft.print("Dont go out");

    flag_dont_go_out = 1;

    if (distance_u_r > distance_u_l)
    {
      motor_el(20, 0, 1500, 100);

      motor_er(0, 20, 1500, 100);

      motor_er(20, 20, 800, 0);

      if (distance_u_l < distance_u_r)
        cmp_turn_90('r', 3000, 40);
      else
        cmp_turn_90('l', 3000, 40);
    }
    else
    {
      motor_er(0, 20, 1500, 100);

      motor_el(20, 0, 1500, 100);

      motor_er(20, 20, 800, 0);

      if (distance_u_r < distance_u_l)
        cmp_turn_90('r', 3000, 40);
      else
        cmp_turn_90('l', 3000, 40);
    }
    motor(20, 20, 0);
  }
}

//******************************************************

void catch_the_victim(void)
{
  bool flag_dodo;
  flag_disable = 1;
  tft.fillScreen(BLACK);
  tft.setTextColor(YELLOW, BLACK);
  tft.setTextSize(2);

  // motor(20, 20);
  close_grip_ball(0, 600);
  if (grip_r_pos > 2100)
  {
    open_grip(1023, 500);
    motor_er(-50, -50, 120, 0);
    arm_xl(400, arm_2_ball + 18, 150);
    arm_xc(400, arm_1_ball, 150);
    close_grip_ball(0, 400);
  }

  stop(10);

  dir_turn_evac = 'n';

  close_grip_ball(0, 500);
  if (grip_r_pos < grip_fully_closed - 20)
  {
    open_grip(1023, 1000);
    arm_xl(400, arm_2_ball, 150);
    arm_xc(400, arm_1_ball, 150);
    t_fake = millis();
  }
  else
  {
    motor_er(-25, -25, 1500, 0); // back

    // grip_r(200, grip_open_r + 620, 0);  //nim baz
    // grip_l(200, grip_open_l - 620, 0);

    stop(200);

    if (ir_ball)
    {
      arm_xl(400, arm_2_ball - 10, 150);
      arm_xc(400, arm_1_ball - 10, 150);
      // close_grip_ball(1023, 400);

      if (resana == 1)
      {

        // arm_2(400, 1845, 400);
        // arm_1(400, 1995, 400);

        read_color('f');

        tft.print(ambient);

        // if (ambient > 700)
        // {
        //   motor_er(100, 100, 1500, 0); // back
        //   if (flag_catch_special_fake == 1)
        //   {
        //     if (flag_dir_special == 'r')
        //       motor_er(80, -80, 300, 10);
        //     else
        //       motor_er(-80, 80, 300, 10);
        //   }
        //   open_grip(1023, 1000);
        //   motor_er(-100, -100, 1000, 0);

        //   if (flag_catch_special_fake == 1)
        //   {
        //     val_ctrl_z = (enc_r() - 1400);
        //     ctrl_z();
        //     flag_catch_special_fake = 0;
        //   }
        //   else
        //   {
        //     if (next_turn == 'r')
        //     {
        //       distance_all();
        //       if (dr < 190)
        //       {
        //         zero_head();
        //         cmp_turn_45('l', 4000);
        //         zero_head();
        //         turn_kam_deg_cmp('l', 20000, 47, 90);
        //         zero_head();
        //         cmp_turn_45('l', 4000);
        //       }
        //       else
        //       {
        //         zero_head();
        //         cmp_turn_45('r', 4000);
        //         zero_head();
        //         turn_kam_deg_cmp('r', 20000, 47, 90);
        //         zero_head();
        //         cmp_turn_45('r', 4000);
        //       }
        //     }
        //     else
        //     {
        //       distance_all();
        //       if (dl < 190)
        //       {
        //         zero_head();
        //         cmp_turn_45('r', 4000);
        //         zero_head();
        //         turn_kam_deg_cmp('r', 20000, 47, 90);
        //         zero_head();
        //         cmp_turn_45('r', 4000);
        //       }
        //       else
        //       {
        //         zero_head();
        //         cmp_turn_45('l', 4000);
        //         zero_head();
        //         turn_kam_deg_cmp('l', 20000, 47, 90);
        //         zero_head();
        //         cmp_turn_45('l', 4000);
        //       }
        //     }
        //     motor_er(-80, -80, 600, 10);
        //   }
        // }
        // else
        // {
        arm_xc(100, arm_1_up, 0);
        arm_xl(80, arm_2_up + 300, 0);

        tm = millis();

        while (millis() - tm < 1200)
        {
          if (grip_r_pos < grip_fully_closed - 20)
          {
            arm_xc(120, arm_1_ball, 0);
            arm_xl(120, arm_2_ball, 700);

            motor_er(-40, -40, 200, 0);
            open_grip(100, 400);

            flag_ball_failed = 1;
            break;
          }
        }
        if (flag_ball_failed == 0)
        {
          tft.setCursor(50, 50);
          tft.print("Black");
          separator(1023, sep_black, 400);
          Box(100, Box_down, 1300 * tamrin);

          grip_black();

          n_black++;
          n_ball++;

          open_grip(1023, 1000);

          delay(500);
          separator(1023, sep_silver, 0);
          //}
        }
      }
      else
      {
        separator(1023, sep_silver, 400);
        arm_xc(100, arm_1_up, 0);
        arm_xl(80, arm_2_up + 300, 0);

        while (millis() - tm < 1200)
        {
          if (grip_r_pos < grip_fully_closed - 20)
          {
            arm_xc(120, arm_1_ball, 0);
            arm_xl(120, arm_2_ball, 700);

            motor_er(-40, -40, 200, 0);
            open_grip(100, 400);

            flag_ball_failed = 1;
            break;
          }
        }
        if (flag_ball_failed == 0)
        {
          tft.setCursor(50, 50);
          tft.print("Silver");
          Box(100, Box_down, 1000 * tamrin);

          grip_silver();
          n_silver++;
          n_ball++;

          separator(1023, sep_silver, 0);
          open_grip(1023, 500);
          flag_search_side = 1;
        }
      }

      arm_xl(400, arm_2_ball, 300);
      arm_xc(400, arm_1_ball, 400);

      tft.fillScreen(BLACK);
      tft.setTextSize(2);

      tft.setCursor(10, 50);
      sprintf(text, "n_ball: % d", n_ball);
      tft.print(text);

      tft.setCursor(10, 70);
      sprintf(text, "Silver: % d", n_silver);

      tft.print(text);
      tft.setCursor(10, 90);

      sprintf(text, "Black: % d", n_black);
      tft.print(text);

      flag_found_ball_after_special = 1;
    }
    else
    {
      stop(0);
      open_grip(0, 300);
      motor_er(-10, -10, 400, 0);
      arm_xc(400, arm_1_ball, 200);
      arm_xl(400, arm_2_ball, 200);
      flag_disable = 0;
    }
  }
  check_flag_side();
  if (flag_ball_obs == 1)
  {
    flag_ball_obs = 0;
    motor_er(80, 80, 1500, 0);
  }
  flag_ball_failed = 0;
}

//******************************************************

void drop(char dir)
{
  stop(1);
  alarm_buz(2);

  if (dir == 'b' && silver_rescued >= 2 && n_black >= 1)
  {
    separator(400, sep_black, 0);

    Box(200, Box_ball, 1250);

    black_rescued += n_black;
    ball_rescued += black_rescued;

    n_ball--;
    n_black = 0;

    black_rescued++;
    ball_rescued++;

    motor_er(10, 10, 200, 0); // agar topi vasat bood biofte

    tft.fillScreen(BLACK);
    tft.setTextSize(2);

    framWrite(ball_rescued_eep_cell, ball_rescued);
    framWrite(silver_rescued_eep_cell, silver_rescued);
    framWrite(black_rescued_eep_cell, black_rescued);

    tft.setCursor(10, 30);
    sprintf(text, "Ball res:%d", ball_rescued);
    tft.print(text);

    tft.setCursor(10, 60);
    sprintf(text, "Silver res:%d", silver_rescued);
    tft.print(text);

    tft.setCursor(10, 90);
    sprintf(text, "Black res :%d", black_rescued);
    tft.print(text);

    Box(200, Box_down, 1250);
    separator(400, sep_silver, 0);
  }

  else if (dir == 's' && (n_silver >= 1))
  {
    separator(400, sep_silver, 0);
    Box(200, Box_ball, 1250);

    silver_rescued += n_silver;
    ball_rescued += n_silver;

    n_ball -= n_silver;
    n_silver = 0;
    silver_rescued += n_silver;

    framWrite(ball_rescued_eep_cell, ball_rescued);
    framWrite(silver_rescued_eep_cell, silver_rescued);
    framWrite(black_rescued_eep_cell, black_rescued);

    tft.setCursor(10, 30);
    sprintf(text, "Ball res:%d", ball_rescued);
    tft.print(text);

    tft.setCursor(10, 60);
    sprintf(text, "Silver res:%d", silver_rescued);
    tft.print(text);

    tft.setCursor(10, 90);
    sprintf(text, "Black res :%d", black_rescued);
    tft.print(text);

    motor_er(10, 10, 200, 0); // agar topi vasat bood biofte

    Box(200, Box_down, 1250);
  }

  //////////////////////////

  n_str_20 = 0;

  flag_start_turn = 0;
}

//******************************************************

void str_20(uint masafat)
{
  motor(80, 80, 0);

  enc_read();
  while (enc_r() <= masafat)
  {

    if (flag_dont_go_out == 1)
    {
      flag_dont_go_out = 0;
      break;
    }
    motor(80, 80, 0);
    get_distance();

    check_victim_vl_side('n');

    if (ir_ball == 1)
    {
      catch_the_victim();
      motor(80, 80, 0);
    }

    if (mic_lf == 0 || mic_rf == 0)
    {
      motor_er(-15, -15, 80, 50); // back
      break;
    }

    //    if ( ir_obs == 1)
    //    {
    //      motor_er(-100, -100, 100 , 100);
    //      alarm_buz(3);
    //      break;
    //    }

    dont_go_out();
    // dont_go_out_vl(350);
  }

  stop(10);

  n_str_20++;
  if (n_str_20 >= 10)
  {
    n_str_20 = 0;
    flag_search_side = 1;
    n_side = 0;
    flag_dont_check_side = 0;
  }
}

//******************************************************

void check_obstacle_evacuation_go_out()
{
  if (ir_obs == 1)
  {
    stop(100);
    dr = distance_u_r;
    dl = distance_u_l;

    motor_er(-80, -80, 500, 10);

    ////////////////////////////

    zero_head();
    cmp_turn_step_15('r', 6000);
    motor_er(-80, 80, 50, 10);

    //////////////////////////////

    zero_head();
    turn_180_cmp_arc('r', 20000, 30, 90);

    zero_head();
    cmp_turn_step_15('r', 6000);
    /////////////////////////////

    motor(-25, 25, 700);
    /////////////////////////////////
    enc_read();
  }
}

//******************************************************

void check_obstacle_evacuation()
{
  if (ir_obs == 1)
  {
    flag_ball_obs = 1;
    char dir;
    stop(100);
    get_distance();

    motor_er(-80, -80, 500, 10);

    ////////////////////////////

    if (dl > 300 && dr > 300)
    {
      flag_o = !flag_o; // random

      if (flag_o == 0)
      {
        dl = 300;
        dr = 200;
      }
      else
      {
        dl = 200;
        dr = 300;
      }
    }

    ////////////////////////////
    get_distance();
    if (dr >= dl)
    {
      dir = 'r';
      zero_head();
      cmp_turn_step_15('r', 6000);
      motor_er(-80, 80, 50, 10);

      zero_head();
      turn_180_cmp_arc('r', 20000, 30, 90);

      dont_go_out();
      zero_head();
      motor_el(90, 0, 1500, 10);
      motor_er(0, 90, 1000, 10);
      motor_er(-80, -80, 600, 10);

      cmp_turn_step_15('r', 6000);
    }
    else
    {
      dir = 'l';
      zero_head();
      cmp_turn_step_15('l', 6000);
      motor_el(80, -80, 50, 10);

      zero_head();
      turn_180_cmp_arc('l', 20000, 30, 90);
      dont_go_out();
      zero_head();

      motor_er(0, 90, 1500, 10);
      motor_el(90, 0, 1000, 10);
      motor_er(-80, -80, 600, 10);

      cmp_turn_step_15('l', 6000);
    }

    /////////////////////////////////
    enc_read();
  }
}

//******************************************************

void align_forward_go_out(unsigned int break_time, bool break_condition_1 = 0, bool break_condition_2 = 0)
{
  unsigned long int tt;
  bool flag_do_obs = 0;

  tt = millis();
  while (1)
  {

    if (ir_obs == 1)
    {
      stop(0);
      break;
    }
    if (mic_lf == 0 && mic_rf == 0)
    {
      stop(50);
      break;
    }
    else if (mic_lf == 1 && mic_rf == 1)
    {
      motor(80, 80);
    }

    else if (mic_lf == 1 && mic_rf == 0)
    {
      if (distance_f_c < 90)
      {
        motor(-30, -30, 3); // back
        motor(90, -15, 0);
        delay(100);
      }
      if (mic_lf == 0 && mic_rf == 0)
      {
        stop(0);
      }
      else
      {
        motor_er(-60, -60, 500, 50);
        motor_er(60, -60, 700, 50);
      }
    }

    else if (mic_lf == 0 && mic_rf == 1)
    {
      flag_do_obs = 1;
      motor(-30, -30, 3); // back
      motor(-15, 90, 0);
      delay(100);
    }

    if ((millis() - tt > break_time) || break_condition_1 == 1 || break_condition_2 == 1)
    {
      break;
    }
  }

  flag_do_obs = 0;

  if (ir_obs == 0)
    motor(60, 60, 100); // akharesh bechasb be divar

  //  tft.fillScreen(BLACK);
  //  sprintf(text, "uf = % 4d", distance(uf, 20));
  //  tft.setCursor(0, 50);
  //  tft.print(text);

  //////////////

  buz(50);
}

//******************************************************

void change_dir_out()
{
  if (dir_out == 'r')
    dir_out = 'l';
  else
    dir_out = 'r';
}

//******************************************************

void enter_evacuation_zone()
{ // gyi
  uint ofs = 0;
  unsigned char n_dr, n_dl;

  dxl.torqueOn(box);
  dxl.torqueOn(sep_id);

  arm_xl(200, arm_2_ball, 600);
  arm_xc(200, arm_1_ball, 600);

  grip_l(400, grip_open_l_red, 0);
  grip_r(400, grip_open_r_red, 0);

  motor_er(50, 50, 3300, 0);
  motor(50, 50);

  if (ir_ball == 1)
  {
    catch_the_victim();
    motor_er(50, 50, 1500, 300);
  }

  for (int i = 0; i < 10; i++)
  {
    dl = distance_u_l;
    dr = distance_u_r; // ahai

    stop(45);

    if (dl > dr)
      n_dl++;
    else
      n_dr++;
  }

  get_distance();

  zero_head();
  if (n_dr > n_dl)
  {
    cmp_turn_step_15('r', 6000);
    next_turn = 'r';
  }
  else
  {
    cmp_turn_step_15('l', 6000);
    next_turn = 'l';
  }
}

//******************************************************

void align_forward_after_evacuation_point_go_out(unsigned int break_time, bool break_condition_1 = 0, bool break_condition_2 = 0)
{
  unsigned long int tt;

  tt = millis();
  while (1)
  {

    if (check_silver() == 1 || check_black() >= 1 || ir_obs == 1)
    {
      stop(50);
      motor_er(50, 50, 20, 10);
      if (check_silver() == 1)
        flag_silver_go == 1;
      else if (check_black() >= 1)
        flag_black_go = 1;
      // alarm_tone(2);

      tft.fillScreen(PURPLE);
      motor_er(-70, -70, 700, 10);

      motor_er(-60, 60, 1000, 500);
      flag_do_dont = 1;
      break;
    }
    if (mic_lf == 1 && mic_rf == 1)
    {
      motor(80, 80, 0);
      delay(30);
    }

    else if (mic_lf == 1 && mic_rf == 0)
    {
      motor(-30, -30, 3); // back
      motor(90, -10, 0);
      delay(100);
    }

    else if (mic_lf == 0 && mic_rf == 1)
    {
      motor(-30, -30, 3); // back
      motor(-10, 90, 0);
      delay(100);
    }

    else if (mic_lf == 0 && mic_rf == 0)
    {
      stop(50);
      break;
    }

    if ((millis() - tt > break_time) || break_condition_1 == 1 || break_condition_2 == 1)
    {
      break;
    }
  }

  motor(70, 70, 100); // akharesh bechasb be divar

  //////////////

  buz(100);
}

//******************************************************

void go_out_from_evacuation(int speed)
{
  extra_evac = 500;
  unsigned long int ttout;
  unsigned long int tlff, trff;
  char balance;
  dir_out = 'r';
  // motor(100 , 100 , 500);
  tft.setTextSize(2);
  tft.setTextColor(BLUE_LIGHT, BLACK);
  tft.setCursor(40, 55);

  change_dir_out();
  zero_head();
  cmp_turn_step_15('r', 6000);

  while (1)
  {

    get_distance();

    if ((mic_rf == 0 || mic_lf == 0) && (dc < 300))
    {
      align_forward_go_out(8000, ir_obs);

      motor(-60, -60, 300);
      zero_head();
      cmp_turn_step_15('r', 6000);

      break;
    }
    else
    {
      if (mic_lf == 0 && dc >= 300)
      {
        motor(-90, -90, 50);
        motor(90, -90, 100);
      }
      else if (mic_rf == 0 && dc >= 300)
      {
        motor(-90, -90, 50);
        motor(-90, 90, 100);
      }
      else if (dld < 75)
        motor(speed * 1.1, speed * 0.9, 0);
      else if (dld > 110 && dld < 190)
        motor(speed * 0.9, speed * 1.1);
      else
      {
        motor(speed * 0.9, speed * 0.9);
      }
    }
    if (check_silver() == 1)
    {
      motor_er(-80, 80, 400, 10);
      motor_er(-80, -80, 400, 10);
      zero_head();
      cmp_turn_step_15('r', 6000);

      motor_er(45, 90, 1400, 20);

      get_distance();

      stop(100);

      motor_er(45, 90, 2000, 20);

      get_distance();

      stop(100);

      break;
    }

    else if (check_black() >= 2)
    {
      motor_er(-80, 80, 400, 10);
      stop(500);

      arm_xc_timed(100, arm_1_normal, 0);
      arm_xl_timed(100, arm_2_normal, 0);
      delay(400);

      grip_l(400, grip_open_l, 0);
      grip_r(400, grip_open_r, 0);

      delay(300);

      separator(400, sep_silver, 0);
      Box_timed(120, Box_down, 0);

      delay(500);

      align_with_exit_evac(3000);

      motor_er(50, 50, 600, 10);

      ttout = millis();
      while (millis() - ttout <= 1000)
      {
        line_follower_right(45);
      }
      flag_sucsses_out = 1;
      break;
    }
  }
  change_dir_out();
  while (1)
  {
    get_distance();
    if (flag_sucsses_out == 1)
      break;
    ///////////////////////////
    check_obstacle_evacuation_go_out();
    //////////////////////////////////////
    if (check_black() >= 2)
    {
      stop(500);

      arm_xc_timed(100, arm_1_normal, 0);
      arm_xl_timed(100, arm_2_normal, 0);
      delay(400);

      grip_l(400, grip_open_l, 0);
      grip_r(400, grip_open_r, 0);

      delay(300);

      separator(400, sep_silver, 0);
      Box_timed(120, Box_down, 0);

      delay(500);

      align_with_exit_evac(3000);

      motor_er(50, 50, 600, 10);

      ttout = millis();
      while (millis() - ttout <= 1000)
      {
        line_follower_right(45);
      }
      flag_sucsses_out = 1;
      break;
    }
    /////////////////////////////////////////////////
    else if (check_silver() == 1)
    {
      stop(200);

      // tft.fillScreen(BLACK);
      // tft.print("Silver");

      motor_er(-90, -90, 800, 200);

      zero_head();
      cmp_turn_step_15(dir_out, 6000);
      change_next_turn();

      dl = distance_u_l;
      while (dl > 200)
      {
        motor(50, 50);
        dl = distance_u_l;
      }
      motor_er(60, 60, 700, 20);
    }
    /////////////////////////////////////////////////
    else if (dr >= 300 && dl >= 300 && flag_do_dont == 0)
    {
      stop(50);

      ttout = millis();
      while (1)
      {
        dl = distance_u_l;
        motor(-60, -60);

        if (millis() - ttout > 2000)
        {
          stop(0);
          break;
        }
        if (dl < 250)
        {
          stop(100);
          buz(50);
          break;
        }
        if (mic_rb == 0 || mic_lb == 0)
        {
          stop(100);
          buz(50);
          break;
        }
      }

      motor_el(90, 0, 1000, 10);
      motor_er(0, 90, 650, 10);

      motor_er(90, 90, 300, 10);
      stop(100);
      zero_head();
      cmp_turn_step_15('l', 6000);
      motor_er(80, -80, 100, 10);
      ////////
      tm = millis();
      ///////////////
      while (1)
      {
        motor(50, 50, 0);

        if (check_black() >= 2)
        {
          stop(500);

          arm_xc_timed(100, arm_1_normal, 0);
          arm_xl_timed(100, arm_2_normal, 0);
          delay(400);

          grip_l(400, grip_open_l, 0);
          grip_r(400, grip_open_r, 0);

          delay(300);

          separator(400, sep_silver, 0);
          Box_timed(120, Box_down, 0);

          delay(500);

          align_with_exit_evac(3000);
          ttout = millis();
          while (millis() - ttout <= 1000)
          {
            line_follower_right(45);
          }
          flag_sucsses_out = 1;

          break;
        }

        ///////////////////////////////////

        else if (check_silver() == 1)
        {
          stop(50);

          motor_er(-90, -90, 700, 10);
          zero_head();
          cmp_turn_step_15('r', 6000);

          dl = distance_u_l;
          tm_out_sil = millis();
          while (dl > 200)
          {
            if (millis() - tm_out_sil > 2500)
              break;

            if (mic_rf == 0 && mic_lf == 0)
            {
              motor_er(-60, -60, 300, 10);
              zero_head();
              cmp_turn_step_15('l', 6000);

              while (1)
              {
                motor(50, 50);

                if (ir_obs == 1)
                {
                  motor_er(-80, -80, 80, 50);
                  motor(-60, 90, 500);
                  if (mic_rf == 0)
                  {
                    motor(-50, -50, 400);
                    motor(-80, 80, 300);
                  }
                  else
                  {
                    motor(60, -60, 500);
                    //////////////////////////////////
                    motor(70, -50, 500);
                    if (mic_lf == 0)
                    {
                      motor(-70, -70, 400);
                      motor(90, -90, 200);
                    }
                    else
                      motor(-50, 50, 1000);
                  }
                }

                if (mic_lf == 0)
                {
                  tlff = millis();
                  if (Abs(tlff - trff) < 1000)
                  {
                    motor(90, -90, 500);
                    break;
                  }
                  else
                  {
                    motor(-60, -60, 100);
                    motor(90, -90, 120);
                  }
                }
                else if (mic_rf == 0)
                {
                  trff = millis();
                  if (Abs(tlff - trff) < 1000)
                  {
                    motor(-90, 90, 500);
                    break;
                  }
                  else
                  {
                    motor(-60, -60, 100);
                    motor(-90, 90, 120);
                  }
                }

                if (check_silver() == 1)
                {
                  motor_er(-60, -60, 300, 100);

                  zero_head();
                  turn_180_cmp('r', 6000, 179);
                  break;
                }

                if (check_black() >= 2)
                {
                  stop(500);

                  arm_xc_timed(100, arm_1_normal, 0);
                  arm_xl_timed(100, arm_2_normal, 0);
                  delay(400);

                  grip_l(400, grip_open_l, 0);
                  grip_r(400, grip_open_r, 0);

                  delay(300);

                  separator(400, sep_silver, 0);
                  Box_timed(120, Box_down, 0);

                  delay(500);

                  align_with_exit_evac(3000);
                  ttout = millis();
                  while (millis() - ttout <= 1000)
                  {
                    line_follower_right(45);
                  }
                  flag_sucsses_out = 1;

                  break;
                }

                if (flag_sucsses_out == 1)
                  break;
              }
            }
            motor(60, 60);
            dl = distance_u_l;
          }
          if (flag_sucsses_out == 0)
          {
            motor_er(45, 90, 1400, 20);

            get_distance();

            stop(100);
            break;
          }
        }
        ///////////////////////////////////
        ///////////////////////////////////

        if (ir_obs == 1)
        {
          motor_er(-80, -80, 80, 50);
          motor(-60, 90, 500);
          if (mic_rf == 0)
          {
            motor(-50, -50, 400);
            motor(-80, 80, 300);
          }
          else
          {
            motor(60, -60, 500);
            //////////////////////////////////
            motor(70, -50, 500);
            if (mic_lf == 0)
            {
              motor(-70, -70, 400);
              motor(90, -90, 200);
            }
            else
              motor(-50, 50, 1000);
          }
        }

        if (mic_lf == 0)
        {
          tlff = millis();
          if (Abs(tlff - trff) < 1000)
          {
            motor(90, -90, 500);
            break;
          }
          else
          {
            motor(-60, -60, 100);
            motor(90, -90, 120);
          }
        }
        else if (mic_rf == 0)
        {
          trff = millis();
          if (Abs(tlff - trff) < 1000)
          {
            motor(-90, 90, 500);
            break;
          }
          else
          {
            motor(-60, -60, 100);
            motor(-90, 90, 120);
          }
        }

        ////////////////////////////////////
      }
    }
    /////////////////////////////////////////////////
    else if ((mic_rf == 0 || mic_lf == 0) && (dc < 300))
    {
      align_forward_go_out(8000, ir_obs);
      check_obstacle_evacuation_go_out();

      if (check_evacuation_point() == 1)
      {
        n_evac_side++;
        motor(-60, -80, 100);
        zero_head();
        cmp_turn_step_15('r', 6000);
        align_forward_after_evacuation_point_go_out(6000, ir_obs);
      }

      if (flag_do_dont == 0)
      {
        motor(-60, -60, 300);
        zero_head();
        cmp_turn_step_15('r', 4000);

        motor(0, 90, 500);
        motor(90, 0, 400);

        motor(-90, -90, 450);
      }
      else
      {
        if (flag_silver_go == 1)
        {
          motor_er(-50, -50, 200, 10);
          zero_head();
          cmp_turn_step_15('r', 4000);
          motor_er(60, 60, 1500, 10);

          get_distance();
          flag_silver_go = 0;
        }
        else if (flag_black_go == 1)
        {
          stop(500);

          arm_xc_timed(100, arm_1_normal, 0);
          arm_xl_timed(100, arm_2_normal, 0);
          delay(400);

          grip_l(400, grip_open_l, 0);
          grip_r(400, grip_open_r, 0);

          delay(300);

          separator(400, sep_silver, 0);
          Box_timed(120, Box_down, 0);

          delay(500);

          align_with_exit_evac(3000);

          motor_er(50, 50, 600, 10);

          ttout = millis();
          while (millis() - ttout <= 1000)
          {
            line_follower_right(45);
          }
          flag_sucsses_out = 1;
          break;
        }
      }
      ///////////////////////////////////
    }
    /////////////////////////////////////////////////
    else
    {
      flag_do_dont = 0;
      if (mic_lf == 0 && dc >= 300)
      {
        motor(-90, -90, 50);
        motor(90, -90, 100);
      }
      else if (mic_rf == 0 && dc >= 300)
      {
        motor(-90, -90, 50);
        motor(-90, 90, 100);
      }
      else if (dld < 75)
        motor(speed * 1.1, speed * 0.9, 0);
      else if (dld > 110 && dld < 190)
        motor(speed * 0.9, speed * 1.1);
      else
      {
        motor(speed * 0.9, speed * 0.9);
      }
    }
  }
}

//******************************************************

void back(int speed, int enc)
{
  motor_el(-speed, -speed, enc, 50);
}

//******************************************************

char change_next_turn()
{
  if (next_turn == 'r')
    next_turn = 'l';
  else
    next_turn = 'r';

  return next_turn;
}

//******************************************************

bool check_evacuation_point()
{
  read_color('f');
  filter_red_amb('f');
  filter_green_amb('f');

  if ((green_f == 1 || red_f == 1) && (mic_rf == 0 || mic_lf == 0))
  {
    // tft.print("Evacuation");
    if (dc > 100 && dc > drf && dc > dlf)
      return 1;
    else
      return 0;
  }

  else
  {
    // tft.setCursor(0, 50);
    // tft.print("Wall");
    // delay(50);
    // tft.fillScreen(BLUE);

    return 0;
  }
}

//******************************************************

void align_with_silver_tape(int tb)
{
  motor_er(-20, -20, 650, 100);

  while (1)
  {
    motor(15, 15, 0);
    if (check_silver() >= 1)
    {
      stop(0);
      break;
    }
  }
  check_silver();
  if (flag_sil == 'r')
  {
    stop(100);
    t1 = millis();
    while (1)
    {
      motor(40, 0);

      align_mic_silver();

      if (a_sil_l1 <= sil_l1_eep && a_sil_l2 <= sil_l2_eep)
      {
        stop(10);
        break;
      }

      if (millis() - t1 > tb)
      {
        stop(10);
        alarm_break();
        break;
      }
    }
    stop(10);

    motor_el(10, 0, 200, 0); // tik

    stop(200 + tamrin * 2000);
  }
  else if (flag_sil == 'l')
  {
    stop(100);
    t1 = millis();
    while (1)
    {
      motor(0, 40);
      align_mic_silver();
      if (a_sil_r1 <= sil_r1_eep && a_sil_r2 <= sil_r2_eep)
      {
        stop(10);
        break;
      }

      if (millis() - t1 > tb)
      {
        stop(10);
        alarm_break();
        break;
      }
    }

    stop(10);

    motor_er(0, 10, 200, 0); // tik

    stop(100 + tamrin * 3000);
  }
  else
  {
    stop(100);

    motor_er(50, 50, 1000, 200); // str
  }
}

//******************************************************

bool is_victim_right_detected(int space_from_ball_r)
{
  return (dr - drd > 80 && drd < 180 && dr > 200 && dr != 2000);
}

//******************************************************

bool is_victim_left_detected(int space_from_ball_l)
{
  return (dl - dld > 80 && dld < 180 && dl > 200 && dl != 2000);
}

//******************************************************

bool verify_victim_distance(int distance, int distance_side)
{
  return (distance - distance_side > 40 && distance_side < 350 && distance > 120);
}

//******************************************************

void perform_side_backward_move(char direction, int space_distance)
{
  if (space_distance < 75)
  {
    if (direction == 'r')
    {
      motor_er(-80, -80, 2300, 0);
      motor_er(0, -80, 1400, 0);
    }
    else
    { // left
      motor_er(-80, -80, 2300, 50);
      motor_el(-80, 0, 1400, 0);
    }
  }
  else
  {
    if (direction == 'r')
    {
      motor_er(-80, -80, 1500, 0);
      motor_er(0, -80, 1700, 0);
    }
    else
    { // left
      motor_er(-80, -80, 1500, 50);
      motor_el(-80, 0, 1700, 0);
    }
  }
}

//******************************************************

void hunt_for_ball(int timeout_ms)
{
  tm = millis();
  enc_read();

  while (millis() - tm < timeout_ms)
  {
    // Check for silver/black victims
    if (check_silver() == 1 || check_black() > 1)
      break;

    // Check for obstacles
    if (ir_obs == 1)
      break;

    dont_go_out();

    // Check for microphone triggers (wall detected)
    if (mic_rf == 0 && mic_lf == 0)
    {
      flag_back_special = 1;
      break;
    }

    motor(80, 80);

    // Check if ball found
    if (ir_ball == 1)
    {
      catch_the_victim();
      break;
    }
  }
}

//******************************************************

void handle_right_victim(int space_from_ball_r, int turns_after_approach)
{
  if (!is_victim_right_detected(space_from_ball_r))
    return;

  stop(1);
  motor_er(80, 80, 700, 50);

  // Re-verify distance after approach
  for (int i = 0; i < turns_after_approach; i++)
  {
    get_distance();
    delay(5);
  }

  if (verify_victim_distance(dr, drd))
    return; // False alarm

  // Confirmed victim found on right
  flag_catch_special_fake = 1;
  flag_dir_special = 'r';
  zero_head();

  perform_side_backward_move('r', space_from_ball_r);
  motor_er(80, -80, 1000, 50);

  hunt_for_ball(2500);

  encoder_back_after_ball = (enc_r() - 1100);
  go_back_after_victim();
}

//******************************************************

void handle_left_victim(int space_from_ball_l, int turns_after_approach)
{
  if (!is_victim_left_detected(space_from_ball_l))
    return;

  stop(1);
  motor_er(80, 80, 700, 50);
  get_distance();

  // Re-verify distance after approach
  for (int i = 0; i < turns_after_approach; i++)
  {
    get_distance();
    delay(5);
  }

  if (verify_victim_distance(dl, dld))
    return; // False alarm

  // Confirmed victim found on left
  flag_catch_special_fake = 1;
  flag_dir_special = 'l';
  zero_head();

  perform_side_backward_move('l', space_from_ball_l);
  motor_er(-80, 80, 1000, 50);

  hunt_for_ball(2500);

  encoder_back_after_ball = (enc_l() - 1100);
  go_back_after_victim();
}

//******************************************************

void check_victim_vl_side(char dir)
{
  int space_from_ball_l = dld;
  int space_from_ball_r = drd;

  // Check if victim detected on side and conditions met
  bool victim_detected = (is_victim_right_detected(space_from_ball_r) ||
                          is_victim_left_detected(space_from_ball_l)) &&
                         (ir_obs == 0) &&
                         (n_ball + n_rescued < 3);

  if (!victim_detected)
    return;

  // Initial approach
  motor_er(50, 50, 20, 0);
  get_distance();
  flag_found_ball_after_special = 0;

  // Direction: NORTH (check both sides)
  if (dir == 'n')
  {
    handle_right_victim(space_from_ball_r, 2);
    handle_left_victim(space_from_ball_l, 2);
  }
  // Direction: RIGHT (prioritize right side)
  else if (dir == 'r')
  {
    handle_right_victim(space_from_ball_r, 2);
  }
  // Direction: LEFT (prioritize left side)
  else
  {
    handle_left_victim(space_from_ball_l, 3);
  }
}

//******************************************************

void align_forward_ff_after_evac(unsigned int break_time, bool break_condition_1 = 0, bool break_condition_2 = 0)
{
  unsigned long int tt;

  bool flag_do_dont;

  tt = millis();
  while (1)
  {
    get_distance();

    if (next_turn = 'r' or flag_search_side == 1)
      check_victim_vl_side('r');
    else
      check_victim_vl_side('l');

    arm_xl(400, arm_2_ball + 3, 0);
    arm_xc(400, arm_1_ball, 0);
    open_grip(1023, 0);

    if (check_silver() == 1 || check_black() >= 1 || ir_obs == 1)
    {
      stop(50);
      // alarm_tone(2);

      flag_akh_side = 1;

      motor_er(-80, -80, 1000, 10);
      if (next_turn == 'r' || flag_search_side == 1)
      {
        zero_head();
        cmp_turn_45('r', 4000);
        motor_er(80, -80, 120, 10);
      }
      else
      {
        zero_head();
        cmp_turn_45('l', 4000);
        motor_er(-80, 80, 120, 10);
      }
      motor_er(80, 80, 150, 100);

      flag_do_dont = 1;
      break;
    }
    if (mic_lf == 1 && mic_rf == 1)
    {
      motor(50, 50, 0);
      delay(30);
    }

    else if (mic_lf == 1 && mic_rf == 0)
    {
      motor(-20, -20, 3); // back
      motor(70, -10, 0);
      delay(100);
    }

    else if (mic_lf == 0 && mic_rf == 1)
    {
      motor(-20, -20, 3); // back
      motor(-10, 70, 0);
      delay(100);
    }

    else if (mic_lf == 0 && mic_rf == 0)
    {
      stop(10);
      break;
    }

    if ((millis() - tt > break_time) || break_condition_1 == 1 || break_condition_2 == 1)
    {
      break;
    }
  }

  enc_read();
  while (enc_r() < 200)
  {
    motor(50, 50);
    open_grip(1023, 0);
  }

  for (int i = 0; i <= 10; i++)
  {
    if (ir_ball == 1)
    {
      catch_the_victim();
    }
  }
  //////////////

  check_flag_side();
}

//******************************************************

void after_evacuation_point()
{
  unsigned long int tb;
  bool flag_do_dont;
  char next_turn_before;
  back(80, 200);
  next_turn_before = next_turn;
  check_flag_side();

  if (flag_search_side == 1)
  {
    zero_head();
    cmp_turn_redroom('r', 4000);
  }
  else
  {
    zero_head();
    cmp_turn_redroom(next_turn, 4000);
  }

  tb = millis();
  while (1)
  {
    motor(-60, -60, 0);

    if (ir_ball == 1)
    {
      catch_the_victim();
    }

    // if (check_black_silver_redroom() == 1)
    //   break;

    if (mic_lb == 0 || mic_rb == 0)
      break;

    if (millis() - tb > 1500)
      break;
  }

  if (next_turn == 'r' || flag_search_side == 1)
  {
    motor_er(0, 70, 1000, 10);
    motor_el(50, 0, 700, 10);
  }
  else
  {
    motor_el(70, 0, 1000, 10);
    motor_er(0, 50, 700, 10);
  }

  motor_er(-70, -70, 400, 50);

  align_forward_ff_after_evac(12000, ir_obs);

  if (flag_search_side == 0)
  {
    change_next_turn();
  }

  if (ir_ball == 1)
  {
    catch_the_victim();
    motor(60, 60);
  }

  if (flag_search_side == 0)
  {
    motor_er(-50, -50, 900, 50); // back

    //////////////////////////////

    random_evac = !random_evac;

    if (random_evac == 0 && flag_search_side == 0)
    {
      if (flag_akh_side == 1)
      {
        zero_head();
        cmp_turn_redroom(next_turn, 4000);
      }
      else
      {
        stop(100);
        zero_head();
        turn_180_cmp('r', 6000, 179);
        motor_er(-60, -60, 250, 50);
        change_next_turn();
      }
    }
    else
    {
      if (flag_search_side == 1)
      {
        zero_head();
        cmp_turn_redroom('r', 4000);
      }
      else
      {
        if (flag_akh_side == 0)
        {
          zero_head();
          cmp_turn_redroom(next_turn, 4000);
        }
      }
    }
  }

  if (flag_akh_side == 0 && flag_search_side == 1)
  {
    zero_head();
    cmp_turn_redroom('r', 4000);
  }
  flag_akh_side = 0;
}

//******************************************************

void near_side_f()
{
  // agar ziyad nazdike divar bashd. momken ast dar gardesh be divar bokhorad
  n_do_near++;
  unsigned int n_zarbe = 0;
  char flag_dir;
  get_distance();

  while (dc < 100)
  {
    motor(-70, -70);
    dc = distance_f_c;
    delay(5);
  }
  stop(0);

  if (dl < dr)
  {
    if (dl < 110)
      motor_er(-80, 80, 400, 10);
    else
    {
      motor_er(-80, 80, 600, 10);
      motor_er(80, 80, 400, 0);
    }
    flag_dir = 'l';
  }
  else
  {
    if (dr < 110)
      motor_er(80, -80, 400, 10);
    else
    {
      motor_er(80, -80, 600, 10);
      motor_er(80, 80, 400, 0);
    }
    flag_dir = 'r';
  }

  while (1)
  {
    get_distance();
    if (n_zarbe >= 1)
    {
      stop(0);
      break;
    }
    if (ir_ball == 1)
    {
      catch_the_victim();
      break;
    }

    if (dl < dr)
    {
      motor_er(0, 80, 400, 0);
      motor_er(90, 90, 1600, 10);
      for (int j = 0; j < 2; j++)
      {
        motor_er(90, 90, 850, 0);
        motor_er(100, -90, 800, 0);
        motor_er(-90, -90, 100, 0);
        motor_er(-90, 100, 500, 0);
        motor_er(90, 90, 150, 0);
      }
      motor_er(80, 80, 600, 10);
      align_forward(6000, ir_obs);
      arm_xl(300, arm_2_ball + 15, 150);
      arm_xc(300, arm_1_ball, 150);
      n_zarbe++;
    }

    //////////////////////////

    else
    {
      motor_el(80, 0, 400, 0);
      motor_er(90, 90, 1600, 10);
      for (int j = 0; j < 2; j++)
      {
        motor_er(90, 90, 850, 0);
        motor_er(-90, 100, 800, 0);
        motor_er(-90, -90, 100, 0);
        motor_er(100, -90, 500, 0);
        motor_er(90, 90, 150, 0);
      }
      motor_er(80, 80, 600, 10);
      align_forward(6000, ir_obs);
      arm_xl(300, arm_2_ball + 20, 150);
      arm_xc(300, arm_1_ball, 150);
      n_zarbe++;
    }

    stop(50);

    align_forward(2000, ir_obs);
    if (flag_sucsses_ball == 1)
    {
      flag_sucsses_ball = 0;
      break;
    }

    motor_er(-50, -50, 500, 100);
  }

  get_distance(); // sokhti
  ////////////////////////

  if (flag_dir == 'l')
  {
    motor_el(-60, 0, 700, 10);
    motor_er(-50, -50, 300, 10);
    motor_er(0, -60, 1400, 10);
  }

  else
  {
    motor_er(0, -60, 700, 10);
    motor_er(-50, -50, 300, 10);
    motor_el(-60, 0, 1400, 10);
  }

  align_forward(8000, ir_obs);

  open_grip(1023, 300);
}

//*****************************************************

void check_victim_align()
{
  align_forward(12000);

  for (int i = 0; i < 3; i++)
  {
    if (ir_ball == 1)
    {
      catch_the_victim();
    }
  }
}

//*****************************************************

void go_back_after_victim()
{
  if (flag_back_special == 1)
    motor_er(-80, -80, encoder_back_after_ball - 800, 50);
  else if (flag_found_ball_after_special == 1)
    motor_er(-80, -80, encoder_back_after_ball - 1500, 50);
  else
    motor_er(-80, -80, encoder_back_after_ball - 300, 50);

  if (mic_rb == 0 || mic_lb == 0)
    motor_er(80, 80, 200, 10);
  cmp_turn_step_15('b', 6000);
  motor_er(80, 80, 600, 50);
  flag_back_special = 0;
}

//*****************************************************

char check_evac_double()
{
  unsigned char n_ev, n_green_f, n_red_f;

  for (int i = 0; i < 10; i++)
  {
    dc = distance_f_c;
    drf = distance_f_r;
    dlf = distance_f_l;

    if (check_evacuation_point() == 1)
    {
      n_ev++;

      if (green_f == 1)
        n_green_f++;
      else if (red_f == 1)
        n_red_f++;
    }
    delay(2);
  }
  if (n_ev >= 1)
  {
    if (n_green_f > n_red_f)
      return 'g';

    return 'r';
  }
  return 'n';
}

//******************************************************

void align_with_evacuation_point(unsigned int n_enc)
{
  enc_read();
  while (enc_r() < n_enc)
  {
    motor(70, 70);
    if (mic_rf == 0 && mic_lf == 0)
    {
      stop(10);
      motor_er(60, 60, 200, 10);
      break;
    }
  }
}

//******************************************************

void check_flag_side()
{
  if (n_silver >= 1 || (ball_rescued >= 2 && n_black >= 1))
    flag_search_side = 1;
}

//******************************************************

void evacuation_zone(int evacuation_zone_speed)
{
  bool flag_back;
  flag_search_side = 1;
  enc_read();

  tm_red_khooroj = millis();
  while (1)
  {
    check_flag_side();
    if (flag_sucsses_out == 1)
      break;

    if (ir_ball == 1)
      catch_the_victim();

    get_distance();
    check_victim_vl_side('n');

    check_if_robot_is_stuck(25000);
    dont_go_out();

    dont_go_out();
    if (ir_ball == 1)
      catch_the_victim();

    if (dc < 200)
      motor(evacuation_zone_speed * 0.8, evacuation_zone_speed * 0.8, 0); // slowly
    else if (dr < 45 && dr > 10)
      motor(evacuation_zone_speed, evacuation_zone_speed * 1.2, 0);
    else if (dl < 45 && dr > 10)
      motor(evacuation_zone_speed * 1.2, evacuation_zone_speed, 0);
    else
    {
      if (flag_search_side == 0)
        motor(evacuation_zone_speed, evacuation_zone_speed, 0);
      else
        motor(90, 90, 0);
    }

    if ((mic_rf == 0 || mic_lf == 0) && flag_search_side == 0)
    {
      dont_go_out();
      check_victim_align();
      char evac_val_double = check_evac_double();
      tft.fillScreen(BLUE);

      if (evac_val_double == 'g')
      {
        motor_er(50, 50, 500, 10);
        tft.fillScreen(GREEN);
        drop('s');

        if ((ball_rescued >= 3 || vorood >= 3 || millis() - tm_red_khooroj > 240000) && flag_search_side == 0)
        {
          go_out_from_evacuation(90);
          if (flag_sucsses_out == 1)
            break;
        }
        after_evacuation_point();
        tft.fillScreen(BLACK);
      }
      else if (evac_val_double == 'r')
      {
        motor_er(50, 50, 500, 10);
        tft.fillScreen(RED);
        drop('b');
        if ((ball_rescued >= 3 || vorood >= 3 || millis() - tm_red_khooroj > 240000) && flag_search_side == 0)
        {
          go_out_from_evacuation(90);
          if (flag_sucsses_out == 1)
            break;
        }
        after_evacuation_point();
        tft.fillScreen(BLACK);
      }
      else if (flag_search_side == 1)
      {
        motor_er(-70, -70, 600, 50);
        zero_head();
        cmp_turn_step_15(next_turn, 4000);
      }
      else
      {
        arm_xl(400, arm_2_ball + 20, 100);
        arm_xc(400, arm_1_ball, 100);

        get_distance();

        if (next_turn == 'l' && dl < 180)
          change_next_turn();
        else if (next_turn == 'r' && dr < 180)
          change_next_turn();

        if (flag_search_side == 0)
        {
          motor_er(-90, -90, 1400, 100);
          dont_go_out();

          zero_head();
          cmp_turn_step_15(next_turn, 4000);
          change_next_turn();
          str_20(3800);
          stop(100);
          zero_head();
          cmp_turn_step_15(next_turn, 4000);
          flag_khas_dont = 1;
          align_forward(10000, ir_obs);
          flag_khas_dont = 0;
          if (flag_broke_by_dont_go_out == 0)
          {
            buz(2000);
            check_victim_align();
            for (int i = 0; i < 3; i++)
            {
              if (ir_ball == 1)
              {
                catch_the_victim();
              }
            }
            if (check_evac_double() == 'g')
            {
              motor_er(50, 50, 500, 10);
              tft.fillScreen(GREEN);
              drop('s'); // hulu dellu

              after_evacuation_point();
              tft.fillScreen(BLACK);
              if ((ball_rescued >= 3 || vorood >= 3 || millis() - tm_red_khooroj > 240000) && flag_search_side == 0)
              {
                go_out_from_evacuation(90);
                if (flag_sucsses_out == 1)
                  break;
              }
            }
            else if (check_evac_double() == 'r')
            {
              motor_er(50, 50, 500, 10);
              tft.fillScreen(RED);
              drop('b');

              after_evacuation_point();
              tft.fillScreen(BLACK);
              if ((ball_rescued >= 3 || vorood >= 3 || millis() - tm_red_khooroj > 240000) && flag_search_side == 0)
              {
                go_out_from_evacuation(90);
                if (flag_sucsses_out == 1)
                  break;
              }
            }
            else
            {
              motor_er(-80, -80, 600, 100);
              zero_head();
              turn_180_cmp('r', 6000, 179);
            }
          }
          else
          {
            flag_broke_by_dont_go_out = 0;
          }
        }
        else
        {
          check_victim_align();
          for (int i = 0; i < 3; i++)
          {
            if (ir_ball == 1)
            {
              catch_the_victim();
            }
          }
          if (check_evac_double() == 'g')
          {
            motor_er(50, 50, 500, 10);
            tft.fillScreen(GREEN);
            drop('s'); // hulu dellu

            after_evacuation_point();
            tft.fillScreen(BLACK);
            if ((ball_rescued >= 3 || vorood >= 3 || millis() - tm_red_khooroj > 240000) && flag_search_side == 0)
            {
              go_out_from_evacuation(90);
              if (flag_sucsses_out == 1)
                break;
            }
          }
          else if (check_evac_double() == 'r')
          {
            motor_er(50, 50, 500, 10);
            tft.fillScreen(RED);
            drop('b');

            after_evacuation_point();
            tft.fillScreen(BLACK);
            if ((ball_rescued >= 3 || vorood >= 3 || millis() - tm_red_khooroj > 240000) && flag_search_side == 0)
            {
              go_out_from_evacuation(90);
              if (flag_sucsses_out == 1)
                break;
            }
          }
        }
      }
    }
    else if ((mic_rf == 0 || mic_lf == 0) && flag_search_side == 1)
    {
      stop(100);
      check_victim_align();

      n_side++;
      char evac_val_double = check_evac_double();

      if (evac_val_double == 'g')
      {
        motor_er(50, 50, 500, 10);
        tft.fillScreen(GREEN);
        drop('s'); // hulu dellu

        if ((ball_rescued >= 3 || vorood >= 3 || millis() - tm_red_khooroj > 240000) && flag_search_side == 0)
        {
          go_out_from_evacuation(90);
          if (flag_sucsses_out == 1)
            break;
        }
        after_evacuation_point();
        tft.fillScreen(BLACK);
      }
      else if (evac_val_double == 'r')
      {
        motor_er(50, 50, 500, 10);
        tft.fillScreen(RED);
        drop('b');
        if ((ball_rescued >= 3 || vorood >= 3 || millis() - tm_red_khooroj > 240000) && flag_search_side == 0)
        {
          go_out_from_evacuation(90);
          if (flag_sucsses_out == 1)
            break;
        }
        after_evacuation_point();
        tft.fillScreen(BLACK);
      }
      else
      {
        if (dc < 200 && (dr < 160 || dl < 160) && n_do_near < 3 && check_evacuation_point() == 0 && (n_silver + n_rescued + n_black < 3))
          near_side_f();
        zero_head();
        cmp_turn_redroom('r', 4000);
      }

      check_flag_side();
    }

    if (flag_search_side == 1)
    {
      digitalWrite(3, 1);
    }
    else if (flag_search_side == 0)
    {
      digitalWrite(3, 0);
    }
  }

  motor(40, 40);
}

//******************************************************

void select_vl(unsigned int wich)
{

  pinMode(e_pin, OUTPUT);
  pinMode(add_0_pin, OUTPUT);
  pinMode(add_1_pin, OUTPUT);
  pinMode(add_2_pin, OUTPUT);
  pinMode(add_3_pin, OUTPUT);
  pinMode(add_4_pin, OUTPUT);
  pinMode(add_5_pin, OUTPUT);

  digitalWrite(e_pin, HIGH);
  delayMicroseconds(100);

  if (wich == 3)
  {
    digitalWrite(e_pin, HIGH);
    delayMicroseconds(100);

    digitalWrite(add_0_pin, HIGH);
    digitalWrite(add_1_pin, LOW);
    delayMicroseconds(100);

    digitalWrite(add_2_pin, HIGH);
    digitalWrite(add_3_pin, LOW);
  }

  else if (wich == 2)
  {
    digitalWrite(e_pin, HIGH);
    delayMicroseconds(100);

    digitalWrite(add_0_pin, HIGH);
    digitalWrite(add_1_pin, LOW);
    delayMicroseconds(100);

    digitalWrite(add_2_pin, HIGH);
    digitalWrite(add_3_pin, HIGH);
  }

  else if (wich == 1)
  {
    digitalWrite(e_pin, HIGH);
    delayMicroseconds(100);

    digitalWrite(add_0_pin, HIGH);
    digitalWrite(add_1_pin, LOW);
    delayMicroseconds(100);

    digitalWrite(add_2_pin, LOW);
    digitalWrite(add_3_pin, LOW);
  }

  else if (wich == 4)
  { // right down
    digitalWrite(e_pin, HIGH);
    delayMicroseconds(100);

    digitalWrite(add_0_pin, HIGH);
    digitalWrite(add_1_pin, LOW);
    delayMicroseconds(100);

    digitalWrite(add_2_pin, LOW);
    digitalWrite(add_3_pin, HIGH);
    delayMicroseconds(100);

    digitalWrite(add_4_pin, LOW);
    digitalWrite(add_5_pin, LOW);

    delayMicroseconds(100);
    digitalWrite(e_pin, LOW);
  }

  else if (wich == 5)
  { // right up
    digitalWrite(e_pin, HIGH);
    delayMicroseconds(100);

    digitalWrite(add_0_pin, HIGH);
    digitalWrite(add_1_pin, LOW);
    delayMicroseconds(100);

    digitalWrite(add_2_pin, LOW);
    digitalWrite(add_3_pin, HIGH);
    delayMicroseconds(100);

    digitalWrite(add_4_pin, LOW);
    digitalWrite(add_5_pin, HIGH);

    delayMicroseconds(100);
    digitalWrite(e_pin, LOW);
  }

  else if (wich == 6)
  { // left down
    digitalWrite(e_pin, HIGH);
    delayMicroseconds(100);

    digitalWrite(add_0_pin, HIGH);
    digitalWrite(add_1_pin, LOW);
    delayMicroseconds(100);

    digitalWrite(add_2_pin, LOW);
    digitalWrite(add_3_pin, HIGH);
    delayMicroseconds(100);

    digitalWrite(add_4_pin, HIGH);
    digitalWrite(add_5_pin, HIGH);

    delayMicroseconds(100);
    digitalWrite(e_pin, LOW);
  }

  else if (wich == 7)
  { // left up
    digitalWrite(e_pin, HIGH);
    delayMicroseconds(100);

    digitalWrite(add_0_pin, HIGH);
    digitalWrite(add_1_pin, LOW);
    delayMicroseconds(100);

    digitalWrite(add_2_pin, LOW);
    digitalWrite(add_3_pin, HIGH);
    delayMicroseconds(100);

    digitalWrite(add_4_pin, HIGH);
    digitalWrite(add_5_pin, LOW);

    delayMicroseconds(100);
    digitalWrite(e_pin, LOW);
  }

  else if (wich == 8)
  { // reserve
    digitalWrite(e_pin, HIGH);
    delayMicroseconds(100);

    digitalWrite(add_1_pin, HIGH);
    digitalWrite(add_0_pin, LOW);
    delayMicroseconds(100);

    digitalWrite(add_2_pin, LOW);
    digitalWrite(add_3_pin, HIGH);
    delayMicroseconds(100);

    digitalWrite(add_0_pin, LOW);
    digitalWrite(add_1_pin, HIGH);
    delayMicroseconds(100);
  }
}

//******************************************************

void vl_init()
{
  for (int i = 1; i <= 7; i++)
  {
    select_vl(i);
    sensor.setTimeout(250);
    if (!sensor.init())
    {
      Serial.println("Failed to detect and initialize sensor!");
      while (1)
        ;
    }
    else
    {
      Serial.println("OK");
    }
    sensor.setDistanceMode(VL53L1X::Short);
    sensor.setMeasurementTimingBudget(15000);
    sensor.startContinuous(20);
  }
}

//******************************************************

unsigned int vl_distance(int wich)
{
  int dist = 0;
  select_vl(wich);
  delay(1);

  dist = sensor.read(false);

  if (sensor.timeoutOccurred())
  {
    sensor.stopContinuous();
    sensor.init();
    sensor.setDistanceMode(VL53L1X::Short);
    sensor.setMeasurementTimingBudget(15000);
    sensor.startContinuous(20);
  }

  if (sensor.ranging_data.range_status == VL53L1X::OutOfBoundsFail) // out of bounds
  {
    return 2000;
  }

  return dist;
}

//******************************************************

void check_mic()
{
  bool flag_spec_wall;

  int back = 200;
  int str = 190;
  int turn = 520;

  if (mic_rf == 0)
  {
    stop(100);
    motor_er(30, 30, 150, 10);
    stop(100);
    drf = distance_f_r;
    dc = distance_f_c;
    dlf = distance_f_l;

    if (dlf < 90 && drf < 90 && dc < 90)
    {
      flag_not_wall = 1;
      flag_spec_wall = 1;
    }
    if (dlf > 180 && dc > 180)
    {
      stop(100);
      drf = distance_f_r;
      dc = distance_f_c;
      dlf = distance_f_l;
      if (dlf > 180 && dc > 180)
      {
        tft.setTextColor(BLUE_LIGHT, SILVER);
        tft.fillScreen(SILVER);
        tft.setTextSize(8);
        tft.setCursor(60, 35);

        tft.print("P");

        motor_er(-70, -70, back, 70);
        motor_er(-70, 70, turn, 70);
        motor_er(70, 70, str, 70);

        motor(70, 70, 0); // no stop
      }
    }
    else if (flag_not_wall == 0)
    {
      motor_er(70, -70, turn * 1.4, 70);
      drf = distance_f_r;
      dc = distance_f_c;
      dlf = distance_f_l;
      if (dlf < drf && drf < 400)
      { // wall
        tft.setTextColor(BLACK, WHITE);
        tft.fillScreen(WHITE);
        tft.setTextSize(8);
        tft.setCursor(60, 35);

        tft.print("W");

        motor_er(-70, 70, turn, 70);
        motor_er(70, 70, 300, 10);
        n_check_wall++;
      }
      else
      {
        stop(100);
        drf = distance_f_r;
        dc = distance_f_c;
        dlf = distance_f_l;
        if (dlf < drf && drf < 400)
        { // wall
          tft.setTextColor(BLACK, WHITE);
          tft.fillScreen(WHITE);
          tft.setTextSize(8);
          tft.setCursor(60, 35);

          tft.print("W");
          motor_er(-70, 70, turn, 70);
          motor_er(70, 70, 300, 10);
          n_check_wall++;
        }
        else
        {
          motor_er(70, -70, turn / 1.5, 70);
          act_obstacle(1, 40);
        }
      }
      {
        motor_er(70, -70, turn / 2, 70);
        dlf = distance_f_l;
        if (dlf > 180)
        { // wall
          motor_er(70, -70, turn, 70);
          motor_el(-70, -50, 200, 10);
        }
        else
        {
          motor_er(-70, 70, turn / 1.5, 70);
          act_obstacle(1, 40);
        }
      }
    }
  }

  else if (mic_lf == 0)
  {
    stop(100);
    motor_er(30, 30, 150, 10);
    stop(100);
    drf = distance_f_r;
    dc = distance_f_c;
    dlf = distance_f_l;

    if (dlf < 90 && drf < 90 && dc < 90)
    {
      flag_not_wall = 1;
      flag_spec_wall = 1;
    }
    if (dlf > 180 && dc > 180)
    {
      stop(100);
      drf = distance_f_r;
      dc = distance_f_c;
      dlf = distance_f_l;
      if (dlf > 180 && dc > 180)
      {
        tft.setTextColor(BLUE_LIGHT, SILVER);
        tft.fillScreen(SILVER);
        tft.setTextSize(8);
        tft.setCursor(60, 35);

        tft.print("P");

        motor_er(-70, -70, back, 70);
        motor_er(70, -70, turn, 70);
        motor_er(70, 70, str, 70);

        motor(70, 70, 0); // no stop
      }
    }
    else if (flag_not_wall == 0)
    {
      motor_er(70, -70, turn * 1.4, 70);
      drf = distance_f_r;
      dc = distance_f_c;
      dlf = distance_f_l;
      if (dlf < drf && drf < 400)
      { // wall
        tft.setTextColor(BLACK, WHITE);
        tft.fillScreen(WHITE);
        tft.setTextSize(8);
        tft.setCursor(60, 35);

        tft.print("W");

        motor_er(70, -70, turn, 70);
        motor_er(70, 70, 300, 10);
        n_check_wall++;
      }
      else
      {
        stop(100);
        drf = distance_f_r;
        dc = distance_f_c;
        dlf = distance_f_l;
        if (dlf < drf && drf < 400)
        { // wall
          tft.setTextColor(BLACK, WHITE);
          tft.fillScreen(WHITE);
          tft.setTextSize(8);
          tft.setCursor(60, 35);

          tft.print("W");
          motor_er(70, -70, turn, 70);
          motor_er(70, 70, 300, 10);
          n_check_wall++;
        }
        else
        {
          motor_er(-70, 70, turn / 1.5, 70);
          act_obstacle(1, 40);
        }
      }
    }
    else if (flag_not_wall == 1)
    {
      motor_er(70, -70, 400, 10);
    }
  }
}

//*****************************************************

void check_ir_obs()
{
  int back = 550;
  int str = 200;
  int turn = 600;

  if (ir_obs == 1)
  {
    motor_er(20, 20, 80, 0);
    if (ir_obs == 1)
    {
      stop(100);
      drf = distance_f_r;
      dc = distance_f_c;
      dlf = distance_f_l;
      if (dc < 80 && (drf < 80 || dlf < 80))
      {
        act_obstacle(1, 40);
      }
      else
      {
        motor_er(-70, -70, back, 70);
        if (dir_gap == 'r')
          motor_er(70, -70, turn, 70);
        else
          motor_er(70, -70, turn, 70);
        motor_er(70, 70, str, 70);

        motor(70, 70, 0); // no stop
      }
    }
  }
}

//*****************************************************

void check_sensor_data()
{
  if (millis() - tm_apd > 5)
  {

    if (ramp_up or ramp_down or ramp_left or ramp_right)
      check_act_green_ramp();
    else
      check_act_green();

    check_act_red();
    tm_apd = millis();
  }

  if (millis() - time_cmps > 250)
  {
    time_cmps = millis();
    check_ramp();
  }

  if (millis() - timer_green >= 3500)
  {
    tft.fillScreen(BLACK);
    flag_after_int = 0;
  }

  if (ramp_up == 1 || ramp_down == 1 || ramp_right == 1 || ramp_left == 1)
  {
    tm_slow = millis();
  }
}

//*****************************************************

void get_distance()
{
  drd = distance_d_r;
  dc = distance_f_c;
  dld = distance_d_l;
  dl = distance_u_l;
  dr = distance_u_r;
}

//*****************************************************

void check_line_follower()
{
  if (ramp_up == 1)
    line_follower_up(55);
  else if (ramp_down == 1)
    line_follower_down(55);
  else if (ramp_left == 1)
    line_follower_side_left(60);
  else if (ramp_right == 1)
    line_follower_side_right(25);
  else if ((flag_sucsses_out == 1 && millis() - t_go_out < 3500) or (flag_after_int == 1))
    line_follower_after_int(75);
  else if (millis() - tm_slow < 1500)
    line_follower_right(50);
  else
    line_follower_right(75);
}

//*****************************************************

void setup()
{
  spi.begin(TFT_SCK, TFT_MISO, TFT_MOSI, TFT_CS);
  tft.initR(INITR_BLACKTAB);
  tft.setRotation(1);
  tft.fillScreen(ST7735_BLACK);

  robot_normal();

  pinMode(FRAM_CS, OUTPUT);
  digitalWrite(FRAM_CS, HIGH);

  SPI.begin();
  spi.begin(FRAM_SCK, FRAM_MISO, FRAM_MOSI, FRAM_CS);
  Serial.begin(115200);
  Wire.begin(16, 17);

  Wire.setClock(300000);

  delay(50);

  //**********************************

  pinMode(led_blink_pin, OUTPUT); // led

  //**********************************

  pinMode(out_mux_r, INPUT); // mux
  pinMode(out_mux_l, INPUT); // mux
  pinMode(out_mux_m, INPUT); // mux

  pinMode(out_mux_main, OUTPUT);

  pinMode(out_mux_c, INPUT); // mux

  pinMode(add_0_pin, OUTPUT); // mux address
  pinMode(add_1_pin, OUTPUT); // mux address
  pinMode(add_2_pin, OUTPUT); // mux address
  pinMode(add_3_pin, OUTPUT); // mux address
  pinMode(add_4_pin, OUTPUT); // mux address
  pinMode(add_5_pin, OUTPUT); // mux address

  pinMode(e_pin, OUTPUT);

  //**********************************

  read_eeprom_setting();

  //**********************************

  apds_init('r');
  apds_init('l');
  apds_init('f');

  delay(50);

  vl_init();

  tft.setTextSize(3);
  tft.setTextColor(BLUE, BLACK);

  if (but_d == 0)
    eeprom_reset();

  if (mic_rb == 0)
    menu_2();

  if (mic_lb == 0)
    main_menu();

  if (but_u == 0)
  {

    dxl.torqueOff(rf);
    dxl.torqueOff(lf);
    dxl.torqueOff(rb);
    dxl.torqueOff(lb);

    dxl.torqueOff(box);

    dxl.torqueOff(arm_f);
    dxl.torqueOff(arm_s);

    dxl.torqueOff(sep_id);

    dxl.torqueOff(grip_r_id);
    dxl.torqueOff(grip_l_id);

    WiFi.mode(WIFI_STA);
    ArduinoOTA.setHostname("pishnam line esp32");
    WiFi.begin(ssid, password);

    tft.setTextColor(WHITE, BLACK);
    tft.setCursor(40, 90);
    tft.setTextSize(2);
    tft.print("waiting");

    while (WiFi.status() != WL_CONNECTED)
    {
      delay(500);
    }

    tft.setCursor(0, 20);
    tft.setTextSize(2);
    tft.print(WiFi.localIP());

    ArduinoOTA.onStart([]()
                       {
                         tft.fillScreen(BLACK);
                         tft.fillRect(30, 50, 90, 30, RED);
                         tft.setCursor(30, 90);
                         tft.setTextColor(WHITE, BLACK);
                         tft.print("uploading"); });

    ArduinoOTA.onProgress([](unsigned int progress, unsigned int total)
                          {
                            int percent = (progress * 100) / total;
                            tft.fillRect(30,50,(int)(percent*0.9),30,GREEN); });

    ArduinoOTA.onEnd([]()
                     {
    for(int i=0;i<10;i++)
    {
      buz(25+ i* 4);
      delay(50-i*3);
    } });

    ArduinoOTA.begin();

    while (1)
    {
      ArduinoOTA.handle();
      yield();
    }

    WiFi.disconnect();
  }

  motor(70, 70);

  tm_wall = millis();
}

void loop()
{
  check_sensor_data();

  check_line_follower();

  check_act_obstacle();
  check_ir_obs();

  if (n_check_silver() >= 2)
  {
    tft.setTextColor(BLACK, SILVER);
    tft.fillScreen(SILVER);
    tft.setTextSize(8);
    tft.setCursor(60, 35);

    tft.print("V");

    align_with_silver_tape(1500);
    vorood++;
    framWrite(vorood_eep_cell, vorood);
    enter_evacuation_zone();
    evacuation_zone(80);

    get_distance();
    delay(50);

    motor(20, 20);
    tft.fillScreen(BLACK);
  }
}