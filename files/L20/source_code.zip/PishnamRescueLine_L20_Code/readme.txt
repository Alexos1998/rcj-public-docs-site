please install pio before opening file so you can correctly view the code without errors 


(●'◡'●)  (●'◡'●)  (●'◡'●)  (●'◡'●)  (●'◡'●)  (●'◡'●)  (●'◡'●)  (●'◡'●)  (●'◡'●)  (●'◡'●)  (●'◡'●)  