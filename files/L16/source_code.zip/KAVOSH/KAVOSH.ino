#include <Arduino.h>
#include <Wire.h>
#include <VL53L1X.h>


#define DEBUG_SERIAL 1


const uint8_t MUX_A_PIN = 20;
const uint8_t MUX_B_PIN = 21;
const uint8_t MUX_C_PIN = 22;


const uint8_t LINE_RIGHT_ANALOG_PIN = A0;
const uint8_t LINE_LEFT_ANALOG_PIN  = A1;


const bool LINE_BLACK_IS_HIGH = false;


const uint16_t LINE_THRESHOLD[16] = {
  520, 520, 520, 520, 520, 520, 520, 520,
  520, 520, 520, 520, 520, 520, 520, 520
};


const uint8_t LINE_ANALOG_PIN[16] = {
  LINE_LEFT_ANALOG_PIN, LINE_LEFT_ANALOG_PIN, LINE_LEFT_ANALOG_PIN, LINE_LEFT_ANALOG_PIN,
  LINE_LEFT_ANALOG_PIN, LINE_LEFT_ANALOG_PIN, LINE_LEFT_ANALOG_PIN, LINE_LEFT_ANALOG_PIN,
  LINE_RIGHT_ANALOG_PIN, LINE_RIGHT_ANALOG_PIN, LINE_RIGHT_ANALOG_PIN, LINE_RIGHT_ANALOG_PIN,
  LINE_RIGHT_ANALOG_PIN, LINE_RIGHT_ANALOG_PIN, LINE_RIGHT_ANALOG_PIN, LINE_RIGHT_ANALOG_PIN
};

const uint8_t LINE_MUX_CHANNEL[16] = {
  7, 6, 5, 4, 3, 2, 1, 0,
  0, 1, 2, 3, 4, 5, 6, 7
};

const char *LINE_NAME[16] = {
  "L8", "L7", "L6", "L5", "L4", "L3", "L2", "L1",
  "R1", "R2", "R3", "R4", "R5", "R6", "R7", "R8"
};


const uint8_t I2C_CH_APDS_LEFT   = 0;
const uint8_t I2C_CH_APDS_RIGHT  = 1;
const uint8_t I2C_CH_APDS_SAFE   = 4;

const uint8_t I2C_CH_TOF_FRONT_L = 2;
const uint8_t I2C_CH_TOF_FRONT_R = 3;
const uint8_t I2C_CH_TOF_SIDE_L  = 5;
const uint8_t I2C_CH_TOF_SIDE_R  = 6;


HardwareSerial &DXL = Serial1;
const uint8_t DXL_DIR_PIN = 2;
const uint8_t DXL_TX_MODE = HIGH;
const uint8_t DXL_RX_MODE = LOW;
const uint32_t DXL_BAUD = 57600;

const uint8_t MOTOR_FL_ID = 1;
const uint8_t MOTOR_FR_ID = 2;
const uint8_t MOTOR_BL_ID = 3;
const uint8_t MOTOR_BR_ID = 4;


const int32_t DXL_MAX_SPEED = 1023;


const uint8_t AX_ARM_ID        = 10;
const uint8_t XL_GRIPPER_L_ID  = 30;
const uint8_t XL_GRIPPER_R_ID  = 31;
const uint8_t XL_BASKET_ID     = 32;


const uint16_t ARM_UP_POS        = 785;
const uint16_t ARM_DOWN_POS      = 200;
const uint16_t GRIPPER_L_OPEN    = 320;
const uint16_t GRIPPER_R_OPEN    = 635;
const uint16_t GRIPPER_L_CLOSED  = 555;
const uint16_t GRIPPER_R_CLOSED  = 455;
const uint16_t BASKET_UP_POS     = 470;
const uint16_t BASKET_DOWN_POS   = 810;


const uint8_t SW_FRONT_LEFT_PIN  = 37;
const uint8_t SW_FRONT_RIGHT_PIN = 38;
const uint8_t SW_GRIPPER_PIN     = 39;
const uint8_t SW_BASKET_PIN      = 40;


const bool USE_BNO055 = true;
const uint8_t BNO055_ADDR = 0x28;


const int LINE_BASE_SPEED = 340;
const int LINE_MAX_SPEED  = 680;
const float LINE_KP = 0.060f;
const float LINE_KD = 0.030f;

const uint16_t OBSTACLE_FRONT_MM = 130;
const uint16_t WALL_NEAR_MM      = 95;
const uint16_t WALL_FAR_MM       = 230;
const uint16_t VICTIM_DETECT_MM  = 120;

const uint16_t GAP_FORWARD_MS    = 180;
const uint16_t GAP_SEARCH_MS     = 900;
const uint16_t LINE_LOST_LIMIT   = 8;

const uint16_t EVAC_SWEEP_SPEED  = 260;
const uint16_t EVAC_TURN_SPEED   = 230;
const uint16_t EVAC_LANE_MS      = 850;
const uint8_t  EVAC_MAX_LANES    = 10;


enum RobotState {
  ST_LINE_FOLLOW,
  ST_INTERSECTION_DECISION,
  ST_OBSTACLE_AVOID,
  ST_GAP_RECOVERY,
  ST_EVAC_ENTER,
  ST_EVAC_SEARCH,
  ST_VICTIM_COLLECT,
  ST_SAFE_ZONE_PLACE,
  ST_EVAC_EXIT_SEARCH,
  ST_STOPPED
};

RobotState state = ST_LINE_FOLLOW;
RobotState previousState = ST_LINE_FOLLOW;

struct LineData {
  uint16_t raw[16];
  bool black[16];
  uint8_t count;
  int error;
  bool any;
  bool centered;
  bool leftMarkerArea;
  bool rightMarkerArea;
  bool fullWidthTape;
};

LineData lineData;

struct RGBData {
  uint16_t clear;
  uint16_t red;
  uint16_t green;
  uint16_t blue;
  bool ok;
};

RGBData apdsLeft, apdsRight, apdsSafe;

enum ColorName {
  COLOR_NONE,
  COLOR_WHITE,
  COLOR_BLACK,
  COLOR_GREEN,
  COLOR_RED,
  COLOR_SILVER
};

ColorName colorLeft = COLOR_NONE;
ColorName colorRight = COLOR_NONE;
ColorName colorSafe = COLOR_NONE;

struct TofData {
  uint16_t frontL;
  uint16_t frontR;
  uint16_t sideL;
  uint16_t sideR;
  bool okFrontL;
  bool okFrontR;
  bool okSideL;
  bool okSideR;
};

TofData tofData;
VL53L1X tofFrontL, tofFrontR, tofSideL, tofSideR;

int lastLineError = 0;
int previousLineError = 0;
uint8_t lostLineCounter = 0;
unsigned long stateStartMs = 0;
unsigned long lastDebugMs = 0;
uint8_t evacLane = 0;
int8_t sweepDir = 1;
bool carryingVictim = false;
bool carryingLiveVictim = false;


void setState(RobotState next) {
  if (state != next) {
    previousState = state;
    state = next;
    stateStartMs = millis();
#if DEBUG_SERIAL
    Serial.print("STATE -> ");
    Serial.println((int)state);
#endif
  }
}

int32_t clamp32(int32_t value, int32_t lo, int32_t hi) {
  if (value < lo) return lo;
  if (value > hi) return hi;
  return value;
}

void selectMux(uint8_t channel) {
  digitalWrite(MUX_A_PIN, (channel & 0x01) ? HIGH : LOW);
  digitalWrite(MUX_B_PIN, (channel & 0x02) ? HIGH : LOW);
  digitalWrite(MUX_C_PIN, (channel & 0x04) ? HIGH : LOW);
  delayMicroseconds(80);
}

bool switchPressed(uint8_t pin) {
  return digitalRead(pin) == LOW;
}


const uint8_t DXL2_BROADCAST_ID = 0xFE;
const uint8_t DXL2_INST_PING = 0x01;
const uint8_t DXL2_INST_WRITE = 0x03;
const uint8_t DXL2_INST_SYNC_WRITE = 0x83;

const uint16_t XC_ADDR_OPERATING_MODE = 11;
const uint16_t XC_ADDR_VELOCITY_LIMIT = 44;
const uint16_t XC_ADDR_TORQUE_ENABLE  = 64;
const uint16_t XC_ADDR_GOAL_VELOCITY  = 104;
const uint8_t  XC_MODE_VELOCITY       = 1;

const uint16_t XL_ADDR_TORQUE_ENABLE  = 24;
const uint16_t XL_ADDR_GOAL_POSITION  = 30;
const uint16_t XL_ADDR_MOVING_SPEED   = 32;
const uint16_t XL_ADDR_OPERATING_MODE = 11;
const uint8_t  XL_MODE_JOINT          = 2;

uint16_t dxlUpdateCRC(uint16_t crc_accum, const uint8_t *data_blk_ptr, uint16_t data_blk_size) {
  static const uint16_t crc_table[256] = {
    0x0000,0x8005,0x800F,0x000A,0x801B,0x001E,0x0014,0x8011,
    0x8033,0x0036,0x003C,0x8039,0x0028,0x802D,0x8027,0x0022,
    0x8063,0x0066,0x006C,0x8069,0x0078,0x807D,0x8077,0x0072,
    0x0050,0x8055,0x805F,0x005A,0x804B,0x004E,0x0044,0x8041,
    0x80C3,0x00C6,0x00CC,0x80C9,0x00D8,0x80DD,0x80D7,0x00D2,
    0x00F0,0x80F5,0x80FF,0x00FA,0x80EB,0x00EE,0x00E4,0x80E1,
    0x00A0,0x80A5,0x80AF,0x00AA,0x80BB,0x00BE,0x00B4,0x80B1,
    0x8093,0x0096,0x009C,0x8099,0x0088,0x808D,0x8087,0x0082,
    0x8183,0x0186,0x018C,0x8189,0x0198,0x819D,0x8197,0x0192,
    0x01B0,0x81B5,0x81BF,0x01BA,0x81AB,0x01AE,0x01A4,0x81A1,
    0x01E0,0x81E5,0x81EF,0x01EA,0x81FB,0x01FE,0x01F4,0x81F1,
    0x81D3,0x01D6,0x01DC,0x81D9,0x01C8,0x81CD,0x81C7,0x01C2,
    0x0140,0x8145,0x814F,0x014A,0x815B,0x015E,0x0154,0x8151,
    0x8173,0x0176,0x017C,0x8179,0x0168,0x816D,0x8167,0x0162,
    0x8123,0x0126,0x012C,0x8129,0x0138,0x813D,0x8137,0x0132,
    0x0110,0x8115,0x811F,0x011A,0x810B,0x010E,0x0104,0x8101,
    0x8303,0x0306,0x030C,0x8309,0x0318,0x831D,0x8317,0x0312,
    0x0330,0x8335,0x833F,0x033A,0x832B,0x032E,0x0324,0x8321,
    0x0360,0x8365,0x836F,0x036A,0x837B,0x037E,0x0374,0x8371,
    0x8353,0x0356,0x035C,0x8359,0x0348,0x834D,0x8347,0x0342,
    0x03C0,0x83C5,0x83CF,0x03CA,0x83DB,0x03DE,0x03D4,0x83D1,
    0x83F3,0x03F6,0x03FC,0x83F9,0x03E8,0x83ED,0x83E7,0x03E2,
    0x83A3,0x03A6,0x03AC,0x83A9,0x03B8,0x83BD,0x83B7,0x03B2,
    0x0390,0x8395,0x839F,0x039A,0x838B,0x038E,0x0384,0x8381,
    0x0280,0x8285,0x828F,0x028A,0x829B,0x029E,0x0294,0x8291,
    0x82B3,0x02B6,0x02BC,0x82B9,0x02A8,0x82AD,0x82A7,0x02A2,
    0x82E3,0x02E6,0x02EC,0x82E9,0x02F8,0x82FD,0x82F7,0x02F2,
    0x02D0,0x82D5,0x82DF,0x02DA,0x82CB,0x02CE,0x02C4,0x82C1,
    0x8243,0x0246,0x024C,0x8249,0x0258,0x825D,0x8257,0x0252,
    0x0270,0x8275,0x827F,0x027A,0x826B,0x026E,0x0264,0x8261,
    0x0220,0x8225,0x822F,0x022A,0x823B,0x023E,0x0234,0x8231,
    0x8213,0x0216,0x021C,0x8219,0x0208,0x820D,0x8207,0x0202
  };

  for (uint16_t j = 0; j < data_blk_size; j++) {
    uint16_t i = ((uint16_t)(crc_accum >> 8) ^ data_blk_ptr[j]) & 0xFF;
    crc_accum = (crc_accum << 8) ^ crc_table[i];
  }
  return crc_accum;
}

void dxl2SendPacket(uint8_t id, uint8_t instruction, const uint8_t *params, uint16_t param_len) {
  uint16_t length = param_len + 3;
  uint8_t packet[160];
  uint16_t idx = 0;

  packet[idx++] = 0xFF;
  packet[idx++] = 0xFF;
  packet[idx++] = 0xFD;
  packet[idx++] = 0x00;
  packet[idx++] = id;
  packet[idx++] = length & 0xFF;
  packet[idx++] = (length >> 8) & 0xFF;
  packet[idx++] = instruction;

  for (uint16_t i = 0; i < param_len; i++) packet[idx++] = params[i];

  uint16_t crc = dxlUpdateCRC(0, packet, idx);
  packet[idx++] = crc & 0xFF;
  packet[idx++] = (crc >> 8) & 0xFF;

  digitalWrite(DXL_DIR_PIN, DXL_TX_MODE);
  delayMicroseconds(5);
  DXL.write(packet, idx);
  DXL.flush();
  delayMicroseconds(5);
  digitalWrite(DXL_DIR_PIN, DXL_RX_MODE);
}

void dxl2Write1(uint8_t id, uint16_t address, uint8_t value) {
  uint8_t params[3] = {(uint8_t)(address & 0xFF), (uint8_t)(address >> 8), value};
  dxl2SendPacket(id, DXL2_INST_WRITE, params, 3);
}

void dxl2Write2(uint8_t id, uint16_t address, uint16_t value) {
  uint8_t params[4] = {
    (uint8_t)(address & 0xFF), (uint8_t)(address >> 8),
    (uint8_t)(value & 0xFF), (uint8_t)(value >> 8)
  };
  dxl2SendPacket(id, DXL2_INST_WRITE, params, 4);
}

void dxl2Write4(uint8_t id, uint16_t address, int32_t value) {
  uint8_t params[6] = {
    (uint8_t)(address & 0xFF), (uint8_t)(address >> 8),
    (uint8_t)(value & 0xFF), (uint8_t)(value >> 8),
    (uint8_t)(value >> 16), (uint8_t)(value >> 24)
  };
  dxl2SendPacket(id, DXL2_INST_WRITE, params, 6);
}

void xcTorque(uint8_t id, bool enable) {
  dxl2Write1(id, XC_ADDR_TORQUE_ENABLE, enable ? 1 : 0);
  delay(20);
}

void xcSetVelocityMode(uint8_t id) {
  xcTorque(id, false);
  delay(20);
  dxl2Write1(id, XC_ADDR_OPERATING_MODE, XC_MODE_VELOCITY);
  delay(20);
  dxl2Write4(id, XC_ADDR_VELOCITY_LIMIT, DXL_MAX_SPEED);
  delay(20);
  xcTorque(id, true);
  delay(20);
}

void addInt32LE(uint8_t *buffer, uint16_t &idx, int32_t value) {
  buffer[idx++] = value & 0xFF;
  buffer[idx++] = (value >> 8) & 0xFF;
  buffer[idx++] = (value >> 16) & 0xFF;
  buffer[idx++] = (value >> 24) & 0xFF;
}

int32_t toDxlVelocity(int32_t speed) {
  speed = clamp32(speed, -DXL_MAX_SPEED, DXL_MAX_SPEED);
  return -speed;
}

void moveRaw(int32_t fl, int32_t fr, int32_t bl, int32_t br) {
  uint8_t params[32];
  uint16_t idx = 0;

  params[idx++] = XC_ADDR_GOAL_VELOCITY & 0xFF;
  params[idx++] = (XC_ADDR_GOAL_VELOCITY >> 8) & 0xFF;
  params[idx++] = 4;
  params[idx++] = 0;

  params[idx++] = MOTOR_FL_ID; addInt32LE(params, idx, toDxlVelocity(fl));
  params[idx++] = MOTOR_FR_ID; addInt32LE(params, idx, toDxlVelocity(fr));
  params[idx++] = MOTOR_BL_ID; addInt32LE(params, idx, toDxlVelocity(bl));
  params[idx++] = MOTOR_BR_ID; addInt32LE(params, idx, toDxlVelocity(br));

  dxl2SendPacket(DXL2_BROADCAST_ID, DXL2_INST_SYNC_WRITE, params, idx);
}

void driveLR(int32_t leftSpeed, int32_t rightSpeed) {
  leftSpeed = clamp32(leftSpeed, -LINE_MAX_SPEED, LINE_MAX_SPEED);
  rightSpeed = clamp32(rightSpeed, -LINE_MAX_SPEED, LINE_MAX_SPEED);
  moveRaw(-leftSpeed, rightSpeed, -leftSpeed, rightSpeed);
}

void stopAll() {
  moveRaw(0, 0, 0, 0);
}


void dxl1SendPacket(uint8_t id, uint8_t instruction, const uint8_t *params, uint8_t param_len) {
  uint8_t packet[32];
  uint8_t idx = 0;
  packet[idx++] = 0xFF;
  packet[idx++] = 0xFF;
  packet[idx++] = id;
  packet[idx++] = param_len + 2;
  packet[idx++] = instruction;
  uint8_t checksum = id + param_len + 2 + instruction;
  for (uint8_t i = 0; i < param_len; i++) {
    packet[idx++] = params[i];
    checksum += params[i];
  }
  packet[idx++] = ~checksum;

  digitalWrite(DXL_DIR_PIN, DXL_TX_MODE);
  delayMicroseconds(5);
  DXL.write(packet, idx);
  DXL.flush();
  delayMicroseconds(5);
  digitalWrite(DXL_DIR_PIN, DXL_RX_MODE);
}

void dxl1Write2(uint8_t id, uint8_t address, uint16_t value) {
  uint8_t params[3] = {address, (uint8_t)(value & 0xFF), (uint8_t)(value >> 8)};
  dxl1SendPacket(id, 0x03, params, 3);
}

void axMove(uint8_t id, uint16_t pos, uint16_t speed) {
  if (pos > 1023) pos = 1023;
  if (speed > 1023) speed = 1023;
  dxl1Write2(id, 32, speed);
  dxl1Write2(id, 30, pos);
}

void xl320Torque(uint8_t id, bool enable) {
  dxl2Write1(id, XL_ADDR_TORQUE_ENABLE, enable ? 1 : 0);
}

void xl320Move(uint8_t id, uint16_t pos, uint16_t speed) {
  if (pos > 1023) pos = 1023;
  if (speed > 1023) speed = 1023;
  dxl2Write2(id, XL_ADDR_MOVING_SPEED, speed);
  dxl2Write2(id, XL_ADDR_GOAL_POSITION, pos);
}

void gripperOpen() {
  xl320Torque(XL_GRIPPER_L_ID, true);
  xl320Torque(XL_GRIPPER_R_ID, true);
  xl320Move(XL_GRIPPER_L_ID, GRIPPER_L_OPEN, 300);
  xl320Move(XL_GRIPPER_R_ID, GRIPPER_R_OPEN, 300);
}

void gripperClose() {
  xl320Torque(XL_GRIPPER_L_ID, true);
  xl320Torque(XL_GRIPPER_R_ID, true);
  xl320Move(XL_GRIPPER_L_ID, GRIPPER_L_CLOSED, 300);
  xl320Move(XL_GRIPPER_R_ID, GRIPPER_R_CLOSED, 300);
}

void armUp() {
  axMove(AX_ARM_ID, ARM_UP_POS, 250);
}

void armDown() {
  axMove(AX_ARM_ID, ARM_DOWN_POS, 250);
}

void basketUp() {
  xl320Torque(XL_BASKET_ID, true);
  xl320Move(XL_BASKET_ID, BASKET_UP_POS, 300);
}

void basketDown() {
  xl320Torque(XL_BASKET_ID, true);
  xl320Move(XL_BASKET_ID, BASKET_DOWN_POS, 300);
}


uint16_t readMuxAnalog(uint8_t analogPin, uint8_t channel) {
  selectMux(channel);
  delayMicroseconds(50);
  return analogRead(analogPin);
}

void readLineSensors() {
  static const int SENSOR_WEIGHT[16] = {
    -7500, -6500, -5500, -4500, -3500, -2500, -1500, -500,
      500,  1500,  2500,  3500,  4500,  5500,  6500,  7500
  };

  long weightedSum = 0;
  uint8_t blackCount = 0;

  for (uint8_t i = 0; i < 16; i++) {
    uint16_t raw = readMuxAnalog(LINE_ANALOG_PIN[i], LINE_MUX_CHANNEL[i]);
    lineData.raw[i] = raw;
    bool isBlack = LINE_BLACK_IS_HIGH ? (raw > LINE_THRESHOLD[i]) : (raw < LINE_THRESHOLD[i]);
    lineData.black[i] = isBlack;
    if (isBlack) {
      weightedSum += SENSOR_WEIGHT[i];
      blackCount++;
    }
  }

  lineData.count = blackCount;
  lineData.any = blackCount > 0;
  lineData.error = blackCount ? (int)(weightedSum / blackCount) : lastLineError;
  lineData.centered = lineData.black[7] || lineData.black[8];

  uint8_t leftMarkerCount = 0;
  uint8_t rightMarkerCount = 0;
  for (uint8_t i = 0; i < 5; i++) if (lineData.black[i]) leftMarkerCount++;
  for (uint8_t i = 11; i < 16; i++) if (lineData.black[i]) rightMarkerCount++;
  lineData.leftMarkerArea = leftMarkerCount >= 3;
  lineData.rightMarkerArea = rightMarkerCount >= 3;
  lineData.fullWidthTape = blackCount >= 11;

  if (lineData.any) {
    lastLineError = lineData.error;
    lostLineCounter = 0;
  } else {
    lostLineCounter++;
  }
}

void followLineWeighted() {
  readLineSensors();

  if (!lineData.any) {
    if (lostLineCounter >= LINE_LOST_LIMIT) setState(ST_GAP_RECOVERY);
    else driveLR(190, 190);
    return;
  }

  int derivative = lineData.error - previousLineError;
  previousLineError = lineData.error;

  int correction = (int)(LINE_KP * lineData.error + LINE_KD * derivative);
  correction = clamp32(correction, -380, 380);

  int leftSpeed = LINE_BASE_SPEED + correction;
  int rightSpeed = LINE_BASE_SPEED - correction;

  leftSpeed = clamp32(leftSpeed, -LINE_MAX_SPEED, LINE_MAX_SPEED);
  rightSpeed = clamp32(rightSpeed, -LINE_MAX_SPEED, LINE_MAX_SPEED);

  driveLR(leftSpeed, rightSpeed);
}

bool markerCandidateDetected() {
  return lineData.leftMarkerArea || lineData.rightMarkerArea;
}

bool evacuationEntryDetected() {

  return lineData.fullWidthTape;
}


const uint8_t APDS9960_ADDR = 0x39;
const uint8_t APDS_ENABLE   = 0x80;
const uint8_t APDS_ATIME    = 0x81;
const uint8_t APDS_CONTROL  = 0x8F;
const uint8_t APDS_CDATAL   = 0x94;

bool i2cWrite8(uint8_t addr, uint8_t reg, uint8_t value) {
  Wire.beginTransmission(addr);
  Wire.write(reg);
  Wire.write(value);
  return Wire.endTransmission() == 0;
}

bool i2cReadBytes(uint8_t addr, uint8_t reg, uint8_t *buf, uint8_t len) {
  Wire.beginTransmission(addr);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  uint8_t got = Wire.requestFrom(addr, len);
  if (got != len) return false;
  for (uint8_t i = 0; i < len; i++) buf[i] = Wire.read();
  return true;
}

bool initAPDSChannel(uint8_t channel) {
  selectMux(channel);
  bool ok = true;
  ok &= i2cWrite8(APDS9960_ADDR, APDS_ENABLE, 0x03);
  ok &= i2cWrite8(APDS9960_ADDR, APDS_ATIME,  219);
  ok &= i2cWrite8(APDS9960_ADDR, APDS_CONTROL, 0x01);
  delay(10);
  return ok;
}

bool readAPDSChannel(uint8_t channel, RGBData &out) {
  selectMux(channel);
  uint8_t buf[8];
  if (!i2cReadBytes(APDS9960_ADDR, APDS_CDATAL, buf, 8)) {
    out.ok = false;
    return false;
  }
  out.clear = (uint16_t)buf[0] | ((uint16_t)buf[1] << 8);
  out.red   = (uint16_t)buf[2] | ((uint16_t)buf[3] << 8);
  out.green = (uint16_t)buf[4] | ((uint16_t)buf[5] << 8);
  out.blue  = (uint16_t)buf[6] | ((uint16_t)buf[7] << 8);
  out.ok = true;
  return true;
}

ColorName classifyColor(const RGBData &c) {
  if (!c.ok || c.clear < 40) return COLOR_NONE;


  if (c.green > c.red * 1.18f && c.green > c.blue * 1.10f && c.clear > 55) {
    return COLOR_GREEN;
  }
  if (c.red > c.green * 1.15f && c.red > c.blue * 1.10f && c.clear > 55) {
    return COLOR_RED;
  }
  return COLOR_WHITE;
}

void updateColorSensors() {
  readAPDSChannel(I2C_CH_APDS_LEFT, apdsLeft);
  readAPDSChannel(I2C_CH_APDS_RIGHT, apdsRight);
  readAPDSChannel(I2C_CH_APDS_SAFE, apdsSafe);
  colorLeft = classifyColor(apdsLeft);
  colorRight = classifyColor(apdsRight);
  colorSafe = classifyColor(apdsSafe);
}


bool initTofOnChannel(uint8_t channel, VL53L1X &sensor) {
  selectMux(channel);
  sensor.setTimeout(80);
  if (!sensor.init()) {
#if DEBUG_SERIAL
    Serial.print("VL53L1X init failed on channel ");
    Serial.println(channel);
#endif
    return false;
  }
  sensor.setDistanceMode(VL53L1X::Short);
  sensor.setMeasurementTimingBudget(30000);
  sensor.startContinuous(50);
  delay(60);
  return true;
}

bool initTofSensors() {
  bool ok = true;
  ok &= initTofOnChannel(I2C_CH_TOF_FRONT_L, tofFrontL);
  ok &= initTofOnChannel(I2C_CH_TOF_FRONT_R, tofFrontR);
  ok &= initTofOnChannel(I2C_CH_TOF_SIDE_L,  tofSideL);
  ok &= initTofOnChannel(I2C_CH_TOF_SIDE_R,  tofSideR);
  return ok;
}

uint16_t readTofOnChannel(uint8_t channel, VL53L1X &sensor, bool &ok) {
  selectMux(channel);
  uint16_t mm = sensor.read();
  ok = !sensor.timeoutOccurred() && mm > 0 && mm < 4000;
  return mm;
}

void updateTofSensors() {
  tofData.frontL = readTofOnChannel(I2C_CH_TOF_FRONT_L, tofFrontL, tofData.okFrontL);
  tofData.frontR = readTofOnChannel(I2C_CH_TOF_FRONT_R, tofFrontR, tofData.okFrontR);
  tofData.sideL  = readTofOnChannel(I2C_CH_TOF_SIDE_L,  tofSideL,  tofData.okSideL);
  tofData.sideR  = readTofOnChannel(I2C_CH_TOF_SIDE_R,  tofSideR,  tofData.okSideR);
}

uint16_t frontDistanceMin() {
  uint16_t best = 4000;
  if (tofData.okFrontL && tofData.frontL < best) best = tofData.frontL;
  if (tofData.okFrontR && tofData.frontR < best) best = tofData.frontR;
  return best;
}

bool obstacleDetected() {
  return frontDistanceMin() < OBSTACLE_FRONT_MM;
}

bool victimDetected() {


  if (tofData.okSideL && tofData.sideL > 20 && tofData.sideL < VICTIM_DETECT_MM) return true;
  if (tofData.okSideR && tofData.sideR > 20 && tofData.sideR < VICTIM_DETECT_MM) return true;
  if (frontDistanceMin() > 20 && frontDistanceMin() < VICTIM_DETECT_MM) return true;
  return false;
}


bool initBNO055() {
  if (!USE_BNO055) return false;

  i2cWrite8(BNO055_ADDR, 0x3D, 0x00);
  delay(25);
  i2cWrite8(BNO055_ADDR, 0x3F, 0x20);
  delay(650);
  i2cWrite8(BNO055_ADDR, 0x3D, 0x0C);
  delay(30);
  return true;
}

float readYawDeg() {
  if (!USE_BNO055) return 0.0f;
  uint8_t buf[2];
  if (!i2cReadBytes(BNO055_ADDR, 0x1A, buf, 2)) return 0.0f;
  int16_t raw = (int16_t)((uint16_t)buf[0] | ((uint16_t)buf[1] << 8));
  return raw / 16.0f;
}

void turnInPlaceMs(int speed, unsigned long ms, bool right) {
  unsigned long t0 = millis();
  while (millis() - t0 < ms) {
    if (right) driveLR(speed, -speed);
    else driveLR(-speed, speed);
    delay(5);
  }
  stopAll();
  delay(80);
}

void turnByApproxDeg(int deg) {
  bool right = deg > 0;
  int absDeg = abs(deg);

  const float TURN_MS_PER_DEG = 5.2f;
  turnInPlaceMs(EVAC_TURN_SPEED, (unsigned long)(absDeg * TURN_MS_PER_DEG), right);
}


void handleGapRecovery() {
  unsigned long elapsed = millis() - stateStartMs;
  readLineSensors();

  if (lineData.any) {
    setState(ST_LINE_FOLLOW);
    return;
  }

  if (elapsed < GAP_FORWARD_MS) {
    driveLR(180, 180);
  } else if (elapsed < GAP_FORWARD_MS + GAP_SEARCH_MS) {
    if (lastLineError < 0) driveLR(-160, 160);
    else driveLR(160, -160);
  } else {
    driveLR(-150, -150);
    delay(120);
    turnByApproxDeg(lastLineError < 0 ? -25 : 25);
    setState(ST_LINE_FOLLOW);
  }
}

void handleIntersectionDecision() {
  stopAll();
  delay(80);
  updateColorSensors();

  bool greenL = colorLeft == COLOR_GREEN;
  bool greenR = colorRight == COLOR_GREEN;
  bool redL   = colorLeft == COLOR_RED;
  bool redR   = colorRight == COLOR_RED;

#if DEBUG_SERIAL
  Serial.print("Intersection colors L/R: ");
  Serial.print((int)colorLeft);
  Serial.print(" / ");
  Serial.println((int)colorRight);
#endif


  if (greenL && greenR) {
    driveLR(210, 210);
    delay(180);
    turnByApproxDeg(180);
  } else if (greenL) {
    driveLR(220, 220);
    delay(140);
    turnByApproxDeg(-82);
  } else if (greenR) {
    driveLR(220, 220);
    delay(140);
    turnByApproxDeg(82);
  } else if (redL || redR) {

    driveLR(-180, -180);
    delay(180);
    turnByApproxDeg(redL ? 60 : -60);
  } else {

    driveLR(220, 220);
    delay(120);
  }

  setState(ST_LINE_FOLLOW);
}

void reacquireLineAfterObstacle() {
  unsigned long t0 = millis();
  while (millis() - t0 < 2500) {
    readLineSensors();
    if (lineData.any) return;
    if (lastLineError <= 0) driveLR(-170, 170);
    else driveLR(170, -170);
    delay(5);
  }
}

void handleObstacleAvoid() {
  stopAll();
  delay(120);
  updateTofSensors();

  bool goLeft = true;
  if (tofData.okSideL && tofData.okSideR) {
    goLeft = tofData.sideL > tofData.sideR;
  } else if (tofData.okSideL) {
    goLeft = tofData.sideL > WALL_FAR_MM;
  } else if (tofData.okSideR) {
    goLeft = !(tofData.sideR > WALL_FAR_MM);
  }


  driveLR(-220, -220);
  delay(260);
  stopAll();
  delay(60);

  turnByApproxDeg(goLeft ? -70 : 70);
  driveLR(260, 260);
  delay(650);
  turnByApproxDeg(goLeft ? 70 : -70);
  driveLR(280, 280);
  delay(950);
  turnByApproxDeg(goLeft ? 70 : -70);
  driveLR(230, 230);
  delay(500);
  turnByApproxDeg(goLeft ? -70 : 70);

  reacquireLineAfterObstacle();
  setState(ST_LINE_FOLLOW);
}

void handleEvacEnter() {
  stopAll();
  delay(100);

  driveLR(260, 260);
  delay(600);
  stopAll();
  evacLane = 0;
  sweepDir = 1;
  setState(ST_EVAC_SEARCH);
}

void sweepLaneStep() {
  updateTofSensors();

  if (victimDetected()) {
    setState(ST_VICTIM_COLLECT);
    return;
  }


  if (frontDistanceMin() < WALL_NEAR_MM || switchPressed(SW_FRONT_LEFT_PIN) || switchPressed(SW_FRONT_RIGHT_PIN)) {
    stopAll();
    delay(100);
    driveLR(-180, -180);
    delay(220);

    if (evacLane >= EVAC_MAX_LANES) {
      setState(ST_SAFE_ZONE_PLACE);
      return;
    }

    if (sweepDir > 0) {
      turnByApproxDeg(90);
      driveLR(EVAC_SWEEP_SPEED, EVAC_SWEEP_SPEED);
      delay(EVAC_LANE_MS);
      turnByApproxDeg(90);
    } else {
      turnByApproxDeg(-90);
      driveLR(EVAC_SWEEP_SPEED, EVAC_SWEEP_SPEED);
      delay(EVAC_LANE_MS);
      turnByApproxDeg(-90);
    }

    sweepDir *= -1;
    evacLane++;
    return;
  }


  int left = tofData.okSideL ? tofData.sideL : 200;
  int right = tofData.okSideR ? tofData.sideR : 200;
  int corr = 0;
  if (left < WALL_NEAR_MM) corr += 70;
  if (right < WALL_NEAR_MM) corr -= 70;
  if (left > WALL_FAR_MM && right < WALL_FAR_MM) corr -= 35;
  if (right > WALL_FAR_MM && left < WALL_FAR_MM) corr += 35;

  driveLR(EVAC_SWEEP_SPEED + corr, EVAC_SWEEP_SPEED - corr);
}

void handleVictimCollect() {
  stopAll();
  delay(120);


  armDown();
  gripperOpen();
  unsigned long t0 = millis();
  while (millis() - t0 < 1200) {
    updateTofSensors();
    if (switchPressed(SW_GRIPPER_PIN) || frontDistanceMin() < 55) break;
    driveLR(110, 110);
    delay(5);
  }

  stopAll();
  gripperClose();
  delay(350);
  armUp();
  delay(450);


  carryingVictim = true;
  carryingLiveVictim = true;


  gripperOpen();
  delay(250);
  armDown();
  delay(250);

  setState(ST_EVAC_SEARCH);
}

void handleSafeZonePlace() {
  stopAll();
  updateColorSensors();


  unsigned long t0 = millis();
  while (millis() - t0 < 6000) {
    updateColorSensors();
    if ((carryingLiveVictim && colorSafe == COLOR_GREEN) || (!carryingLiveVictim && colorSafe == COLOR_RED)) {
      stopAll();
      delay(100);
      basketUp();
      delay(900);
      basketDown();
      delay(500);
      carryingVictim = false;
      setState(ST_EVAC_EXIT_SEARCH);
      return;
    }
    driveLR(180, -180);
    delay(5);
  }


  setState(ST_EVAC_SEARCH);
}

void handleEvacExitSearch() {
  readLineSensors();
  if (lineData.any && !lineData.fullWidthTape) {
    setState(ST_LINE_FOLLOW);
    return;
  }
  driveLR(230, 230);
}


void printDebug() {
#if DEBUG_SERIAL
  if (millis() - lastDebugMs < 300) return;
  lastDebugMs = millis();

  Serial.print("S="); Serial.print((int)state);
  Serial.print(" lineCnt="); Serial.print(lineData.count);
  Serial.print(" err="); Serial.print(lineData.error);
  Serial.print(" colors L/R/S=");
  Serial.print((int)colorLeft); Serial.print('/');
  Serial.print((int)colorRight); Serial.print('/');
  Serial.print((int)colorSafe);
  Serial.print(" tof FL/FR/SL/SR=");
  Serial.print(tofData.frontL); Serial.print('/');
  Serial.print(tofData.frontR); Serial.print('/');
  Serial.print(tofData.sideL); Serial.print('/');
  Serial.print(tofData.sideR);
  Serial.print(" yaw="); Serial.println(readYawDeg());
#endif
}

void setup() {
  Serial.begin(115200);
  delay(300);

  pinMode(MUX_A_PIN, OUTPUT);
  pinMode(MUX_B_PIN, OUTPUT);
  pinMode(MUX_C_PIN, OUTPUT);
  selectMux(0);

  pinMode(SW_FRONT_LEFT_PIN, INPUT_PULLUP);
  pinMode(SW_FRONT_RIGHT_PIN, INPUT_PULLUP);
  pinMode(SW_GRIPPER_PIN, INPUT_PULLUP);
  pinMode(SW_BASKET_PIN, INPUT_PULLUP);

  analogReadResolution(10);

  Wire.begin();
  Wire.setClock(400000);

  pinMode(DXL_DIR_PIN, OUTPUT);
  digitalWrite(DXL_DIR_PIN, DXL_RX_MODE);
  DXL.begin(DXL_BAUD);
  delay(300);

#if DEBUG_SERIAL
  Serial.println("Kavosh Line 2026 No-Menu booting...");
#endif

  xcSetVelocityMode(MOTOR_FL_ID);
  xcSetVelocityMode(MOTOR_FR_ID);
  xcSetVelocityMode(MOTOR_BL_ID);
  xcSetVelocityMode(MOTOR_BR_ID);
  stopAll();

  xl320Torque(XL_GRIPPER_L_ID, true);
  xl320Torque(XL_GRIPPER_R_ID, true);
  xl320Torque(XL_BASKET_ID, true);
  gripperOpen();
  basketDown();
  armUp();

  bool colorOK = true;
  colorOK &= initAPDSChannel(I2C_CH_APDS_LEFT);
  colorOK &= initAPDSChannel(I2C_CH_APDS_RIGHT);
  colorOK &= initAPDSChannel(I2C_CH_APDS_SAFE);

  bool tofOK = initTofSensors();
  initBNO055();

#if DEBUG_SERIAL
  Serial.print("APDS init: "); Serial.println(colorOK ? "OK" : "CHECK CHANNELS");
  Serial.print("VL53L1X init: "); Serial.println(tofOK ? "OK" : "CHECK CHANNELS");
  Serial.println("Ready. Robot will start line-following in 1 second.");
#endif

  delay(1000);
  stateStartMs = millis();
}

void loop() {
  readLineSensors();

  static unsigned long lastColorMs = 0;
  static unsigned long lastTofMs = 0;
  if (millis() - lastColorMs > 35) {
    updateColorSensors();
    lastColorMs = millis();
  }
  if (millis() - lastTofMs > 55) {
    updateTofSensors();
    lastTofMs = millis();
  }

  printDebug();


  if (state == ST_LINE_FOLLOW) {
    if (obstacleDetected()) {
      setState(ST_OBSTACLE_AVOID);
    } else if (evacuationEntryDetected()) {
      setState(ST_EVAC_ENTER);
    } else if (markerCandidateDetected() || colorLeft == COLOR_GREEN || colorRight == COLOR_GREEN || colorLeft == COLOR_RED || colorRight == COLOR_RED) {
      setState(ST_INTERSECTION_DECISION);
    }
  }

  switch (state) {
    case ST_LINE_FOLLOW:
      followLineWeighted();
      break;

    case ST_INTERSECTION_DECISION:
      handleIntersectionDecision();
      break;

    case ST_OBSTACLE_AVOID:
      handleObstacleAvoid();
      break;

    case ST_GAP_RECOVERY:
      handleGapRecovery();
      break;

    case ST_EVAC_ENTER:
      handleEvacEnter();
      break;

    case ST_EVAC_SEARCH:
      sweepLaneStep();
      break;

    case ST_VICTIM_COLLECT:
      handleVictimCollect();
      break;

    case ST_SAFE_ZONE_PLACE:
      handleSafeZonePlace();
      break;

    case ST_EVAC_EXIT_SEARCH:
      handleEvacExitSearch();
      break;

    case ST_STOPPED:
    default:
      stopAll();
      break;
  }
}
