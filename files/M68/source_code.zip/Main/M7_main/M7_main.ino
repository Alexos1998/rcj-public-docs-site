#include <mbed.h> // access arduino mbed OS
#include <RPC.h> // RPC
#include <Wire.h>

#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h>
#include <utility/imumaths.h>


#include <ArduinoQueue.h> // queue
#include <Vector.h> // vector

#include "timer.h"
#include "gyro.h"
#include "dispenser.h"

#define MIN_DIST 120         // mm (tune this)
#define TILE_MM 300         // one tile = 300mm (RCJ tile)
#define BLACK_THRESHOLD 0.10 // color clear-channel threshold ratio for black
#define SILVER_THRESHOLD 800 // tun3
float clear; 

#include "MazeTile.h"

// set up mux and distance senosrs
VL53L0X sensors[7];
QWIICMUX myMux;
// shut down allcall
#define PCA_ADDR 0x60
#define MODE1    0x00
#define ALLCALL_BIT 0x01  // MODE1 bit0

// set up color sensor

// set up gyro
Adafruit_BNO055 bno = Adafruit_BNO055(55, 0x28);
gyro myGyro;
// set up motorshield and motors.




// detection classes

char classes[6] = {'H','S','U','R','Y','G'};

// create stepper object
const int steps_per_revolution = 2048;
Stepper myStepper = Stepper(steps_per_revolution, 8, 9,10,11); 
// map size variables
const int MAP_SIZE=20;
Tile mapGrid[MAP_SIZE][MAP_SIZE]; // array of tiles
// queue


//states that the robot will be in
enum RobotState {
  SENSE_TILE,
  UPDATE_MAP,
  PLAN_NEXT,
  VICTIM_DETECT,
  EXECUTE_MOVE,
  BOTCHED_TURN_RECOVERY,
  BACKPEDAL,
  PAUSE,
  RETURN
};
// coord struct
struct coord {
  int x;
  int y;
};


// initialize 

Direction currentDir = NORTH;     // robot heading in map coords (0..3)
int plannedTurnDeg = 0;           // -90,0,+90,180
Direction plannedMoveDir = NORTH; // absolute direction robot will move next
bool turnCompletedForMove = false;
int x_pos = MAP_SIZE/2;
int y_pos = MAP_SIZE/2;
RobotState state = SENSE_TILE;
// maze return to start condition variables
int medkits = 8;
timer mazeTime;
// black blue toggles
bool blacktoggle = false;
bool bluetoggle = false;
bool climbtoggle = false;
// victim toggle
bool isVictim = false;
// GET RID OF THESE EXTRA TOGGLES
// LED pins
const int pinHarmed = 41;
const int pinStable = 37;
const int pinUnharmed = 29;
// camera GPIOs
const int gpio1 = 13;
const int gpio2 = 12;

// stepper variables
const int angle_offset = 44;
const int angle_increment = 22;
dispenser disp(angle_increment,angle_offset,steps_per_revolution);
// logic switch pin
const int logicswitch = 31;
volatile bool Pausemaze = false;
// pause maze thread

rtos::Thread pauseThread;
void pauseTask(){
  while(true){
    if(digitalRead(logicswitch)==true) Pausemaze = true;
    rtos::ThisThread::sleep_for(std::chrono::milliseconds(10));
  }
}
int x_checkpoint=0;int y_checkpoint=0;
bool tilecheck = false;





void fwd(int distanceMm) {
  isVictim = false;
  RPC.call("fwd", distanceMm);
  Tile &t = mapGrid[x_pos][y_pos];
  while(RPC.call("isFwdComplete").as<bool>()==false){
    if(readSerial1()!=-1&&isVictim==false&&t.getVictim()==false){ //left camera
          if(RPC.call("detectWall",3).as<int>()==0){
            RPC.call("togglestop",true);
            Serial.println("victim at left");
            clearSerialBuffer1();
            detectCam1();
            isVictim = true;
            RPC.call("togglestop",false);
          }
        }
    else if(readSerial2()!=-1&&isVictim == false&&t.getVictim()==false){ // right camera
      if(RPC.call("detectWall",1).as<int>()==0){
        RPC.call("togglestop",true);
        Serial.println("victim at right");
        clearSerialBuffer2();
        detectCam2();
        isVictim = true;
        RPC.call("togglestop",false);
      }
    }
    // label victim in maze.
    if(isVictim){
      markVictimAtEncoderPosition(300);
    }
  }
}

void absoluteturn(int targetDirectionOrDeg) {
  isVictim = false;
  RPC.call("absoluteturn", targetDirectionOrDeg);
  Tile &t = mapGrid[x_pos][y_pos]; // define tile pointer
  while(RPC.call("isTurnComplete").as<bool>()==false){
    if(readSerial1()!=-1&&isVictim==false&&t.getVictim()==false){ //left camera
          if(RPC.call("detectWall",3).as<int>()==0){
            RPC.call("togglestop",true);
            Serial.println("victim at left");
            clearSerialBuffer1();
            detectCam1();
            isVictim = true;
            RPC.call("togglestop",false);
          }
        }
    else if(readSerial2()!=-1&&isVictim == false&&t.getVictim()==false){ // right camera
      if(RPC.call("detectWall",3).as<int>()==0){
        RPC.call("togglestop",true);
        Serial.println("victim at right");
        clearSerialBuffer2();
        detectCam2();
        isVictim = true;
        RPC.call("togglestop",false);
      }
    }
    
    if(isVictim){
      mapGrid[x_pos][y_pos].setVictim(true);
      mapGrid[x_pos][y_pos].setDiscovered(true);
    }
  }
}
void setup(){
  // initialize LED puns
  pinMode(pinHarmed,OUTPUT);
  pinMode(pinStable,OUTPUT);
  pinMode(pinUnharmed,OUTPUT);
  // initialize camera gpio pins
  pinMode(gpio1, INPUT);
  pinMode(gpio2, INPUT);
  // initialize logic switch pin
  pinMode(logicswitch,INPUT);
  // begin UART communication.
  Serial.begin(115200);
  Serial2.begin(115200); // switch to 9600 for reliability
  Serial3.begin(115200);
  flashLED('S');
  

 
  //detect();
  //initialize map
  initializeMap();
  x_pos=MAP_SIZE/2;
  y_pos=MAP_SIZE/2;
  mapGrid[x_pos][y_pos].setDiscovered(true); 
  currentDir = NORTH;
  state = SENSE_TILE;
  pauseThread.start(pauseTask); // start pause thread
  RPC.begin();
  delay(2000); // wait for camera to start.
  
  
}
int iterator = 0;
void loop(){
  static bool wallF, wallR, wallB, wallL;
  switch (state) {
    case SENSE_TILE: {
      // reset toggles
      blacktoggle = false; bluetoggle = false; climbtoggle = false;
      // Read for walls
      readWallsRel(wallF, wallR, wallB, wallL);
      delay(500);
      state = UPDATE_MAP; // next state.
      if(Pausemaze == true) state = PAUSE;
      break;
    }
    case UPDATE_MAP: {
      writeWallsToCurrentTile(wallF, wallR, wallB, wallL);
      updateFullyExploredAt(x_pos, y_pos);
      state = PLAN_NEXT;
      if(Pausemaze == true) state = PAUSE;
      break;
    }
    case PLAN_NEXT: {
      plannedMoveDir = pickNextDirection();

      plannedTurnDeg = turnNeededDeg(plannedMoveDir);
      turnCompletedForMove = false;
      Serial.println(plannedTurnDeg);
      state = EXECUTE_MOVE;
      if(Pausemaze == true) state = PAUSE;
      break;
    }
    case EXECUTE_MOVE: {
      if (turnCompletedForMove == false) {
        if(plannedMoveDir != currentDir){
          absoluteturn(plannedTurnDeg);
        }
        delay(200);
        RPC.call("parallel");
        delay(100);

       
        currentDir = plannedMoveDir;
        turnCompletedForMove = true;
      }
      
      // 2) drive one tile
      fwd(TILE_MM);
      // obtain tile type by querying M4
      bluetoggle = RPC.call("queryBlue").as<bool>();
      blacktoggle = RPC.call("queryBlack").as<bool>();
      climbtoggle = RPC.call("queryClimb").as<bool>();
      
      // update ramps to the map
      int cnt = RPC.call("queryRamps").as<int>();
      if(climbtoggle == true){
        for(int i = 0; i<cnt;i++){
          Serial.println("adding ramp to map");
          markEdgeBothWays(x_pos, y_pos, currentDir);
          stepForward(currentDir, x_pos, y_pos);
          writeWallsToCurrentTile(0, 1, 0, 1);
          updateFullyExploredAt(x_pos, y_pos);
        }
      }
      // 3) update map + robot position only on successful move
      if(bluetoggle == true){ // stop for 5 seconds on the blue tile.
        mapGrid[x_pos][y_pos].setBlue(true);
      }
      bluetoggle = false;
      if(blacktoggle == false){
        markEdgeBothWays(x_pos, y_pos, currentDir);
        stepForward(currentDir, x_pos, y_pos);
      }
      else{
        state = BACKPEDAL;
        turnCompletedForMove = false;
        break;
      }
      if(blacktoggle == true) mapGrid[x_pos][y_pos].setType(3);
      delay(200);
      RPC.call("parallel");
      delay(100);
      iterator += 1;
      
      isVictim = false;
      turnCompletedForMove = false;
      tilecheck = false;
      state = SENSE_TILE;
      if(Pausemaze == true) state = PAUSE;
      //if(mazeTime.getTime() >= 1000000*60*6) state = RETURN;
      //if(medkits <= 0) state = RETURN;
      if(iterator >= 15) state = RETURN;
      break;
     
    }
    case BACKPEDAL: {
      plannedMoveDir = pickNextDirection();
     
      plannedTurnDeg = turnNeededDeg(plannedMoveDir);
      turnCompletedForMove = false;
      state = EXECUTE_MOVE;
      blacktoggle = false;
      if(Pausemaze == true) state = PAUSE;
      delay(500);
      break;
    }
    case RETURN: {
      coord currentpos = {x_pos,y_pos};
      coord endpos = {MAP_SIZE/2,MAP_SIZE/2};
      coord path[MAP_SIZE*MAP_SIZE];
      flashLED('H');
      flashLED('U');
      Serial.println("starting bfs");
      int length = BFS(currentpos,mapGrid,endpos,path);
      Serial.println("path calculated");
      for(int i = length;i>0;i--){
        // coorinates to direction
        if(path[i-1].y-path[i].y == 0){
          if(path[i-1].x-path[i].x == 1){
            plannedTurnDeg = turnNeededDeg(1);
            absoluteturn(plannedTurnDeg);
            delay(200);
            RPC.call("parallel");
            delay(100);
            //update currentDir
            currentDir = 1;
            // 2) drive one tile
            fwd(TILE_MM);
          }
          else if(path[i-1].x-path[i].x == -1){
            plannedTurnDeg = turnNeededDeg(3);
            absoluteturn(plannedTurnDeg);
            delay(200);
            RPC.call("parallel");
            delay(100);
            //update currentDir
            currentDir = 3;
            // 2) drive one tile
            fwd(TILE_MM);
          }
        }
        else{
          if(path[i-1].y-path[i].y == 1){
            plannedTurnDeg = turnNeededDeg(0);
            absoluteturn(plannedTurnDeg);
            delay(200);
            RPC.call("parallel");
            delay(100);
            //update currentDir
            currentDir = 2;
            // 2) drive one tile
            fwd(TILE_MM);
          }
          else if(path[i-1].y-path[i].y == -1){
            plannedTurnDeg = turnNeededDeg(2);
            absoluteturn(plannedTurnDeg);
            delay(200);
            RPC.call("parallel");
            delay(100);
            //update currentDir
            currentDir = 4;
            // 2) drive one tile
            fwd(TILE_MM);
          }
        }
        
      }
      flashLED('H');
      while(true){
        continue;
      }
    }
    case PAUSE: {
      RPC.call("togglestop",true);
      delay(200);
      RPC.call("fullstop");
      x_pos = x_checkpoint; y_pos = y_checkpoint;
      if(digitalRead(logicswitch)==LOW){

        RPC.call("togglestop",false);
        Pausemaze = false;
        Direction snapped = (Direction)RPC.call("headingToCardinal").as<int>(); // snap to this direction
        absoluteturn(turnNeededDeg(snapped));
        currentDir = snapped;
        state = PLAN_NEXT;
        break;
      }
    }
 }
 



}
