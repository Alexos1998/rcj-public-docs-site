// =============================================================================
// === ROBOCUP RESCUE MAZE 2026 — CYTRON FIRMWARE — WF3 ========================
// =============================================================================
// *** WF3 (forked from RescueMaze_WF2 on 2026-06-10). WF2 is preserved as the
// *** known-good fallback. New in WF3:
// ***   - Blue-tile slow-down while crossing (colour 'B' caps drive speed)
// ***   - LED_FLASH <color> [ms] one-shot (checkpoint white flash)
// ***   - YAW_REREF (re-anchor grid yaw after a LoP placement)
// ***   - Full ramp traversal: pitch-only sustained detect -> climb to flat ->
// ***     (up) reverse to find the crest edge / (down) rear-contact geometry ->
// ***     advance to the next tile centre. Emits RAMP UP/DOWN.
// ***   - Tilt-corrected wall-follow (Pi dashboard trig ported): on obstacles/
// ***     ramps the WF + F/B readings are cos-projected and height-gated.
// ***   - Chained moves ("MOVE_TILE C"): no full stop between known tiles —
// ***     ACK while slow-rolling, next MOVE_TILE takes over seamlessly.
// ***
// *** What's new vs the original (see the "WF2" comment tags below):
// ***   1. ToF-check STRAFE: when 1-wall-following and the ultrasonic error is
// ***      in a mid band, stop, turn 90° to face the wall, drive by the side-
// ***      ToF error, turn back & snap, resume — keeps heading dead-straight
// ***      instead of yawing to correct.
// ***   2. Ram WIGGLE/shimmy after backing into a wall (L,R,L,R wheels).
// ***   3. Slightly faster centering ram + tighter post-turn yaw snap.
// ***   4. START/STOP/PAUSE/RESUME UART commands (dashboard run-state control).
// ***   5. case=<...> telemetry field (what the bot is currently doing).
// *** NOTE: this is the SINGLE-FILE build; the modular ../ToF_Sensors/ set is
// *** NOT kept in sync with this experimental copy.
// =============================================================================
// Single-file consolidated build. Open this folder in Arduino IDE and upload.
//
// What this firmware does:
//   - Initialises 4× VL53L0X ToF (front/left/right/back via PCA9548A mux),
//     BNO055 IMU, AS7341 colour sensor (with EEPROM-stored calibration).
//   - Drives 4 H-bridge motors with a per-motor invert array so bot-frame
//     primitives (moveForward, turnRightInPlace, ...) stay intuitive even
//     though 3 of 4 motors are wired backward.
//   - Runs a state-machine motion layer for closed-loop primitives:
//        TURN_R / TURN_L     90° in-place turn with IMU yaw ramp-down
//        MOVE_TILE           drive one tile w/ wall-following + quadratic
//                            slowdown + automatic black-tile abort+reverse
//        RAM_F / RAM_B       ram a wall and detect contact via ToF stall
//        CENTER              longitudinal recentre
//        WAIT_BLUE [ms]      blue-tile pause (rule 5.5)
//        CAL_TILE            measure tile pitch from lateral walls -> g_tileLenMm
//   - Accepts the above as line commands over Serial1 from the Pi mapper.
//     Each completion emits "ACK <name> ok" or "ACK <name> fail reason=...".
//   - Two-button state machine: tap = pause/resume, 5-s hold = stop/start.
//     Boot goes to STOPPED — user must hold a button 5 s to enter RUNNING.
//   - Two NeoPixels on GP23: pixel 0 = referee-facing regulation blink
//     (500/500 ms × 5 s victim, 1/1 s × 10 s exit); pixel 1 = team status
//     cue (blue tile, victim color, alarm, etc).
//   - Streams telemetry to the Pi every loop tick:
//        tick=N F=mm L=mm R=mm B=mm Y=deg P=deg R=deg cal=SGAM col=X
//        sum=N state=S|R|P busy=0|1
//
// Required Arduino libraries (Library Manager):
//   Adafruit VL53L0X, Adafruit BNO055 (pulls Adafruit_Sensor + BusIO),
//   Adafruit AS7341, Adafruit NeoPixel.
// Board: "Raspberry Pi Pico 2" (Earle Philhower RP2350 core) or
//        "Cytron Motion 2350 Pro" if it appears in your boards list.
//
// Wiring (HANDOFF.md S3, S5, S6):
//   I²C1 SDA=GP18 SCL=GP19 -> PCA9548A @ 0x70
//     ch1=Front ToF (0x29)  ch2=Left ToF  ch3=Right ToF  ch4=Back ToF
//     ch5=AS7341 (0x39)     ch6=BNO055 (0x28)
//     ch0=WF-Left ToF       ch7=WF-Right ToF   (wall-follow VL53L0X pair)
//   UART0 (Serial1): TX=GP0 -> Pi RXD (pin 10); RX=GP1 <- Pi TXD (pin 8)
//   Motors:  M1 GP8/9   = Front-Right (not inverted)
//            M2 GP10/11 = Back-Right  (not inverted)
//            M3 GP12/13 = Front-Left  (INVERTED)
//            M4 GP14/15 = Back-Left   (INVERTED)   — see MOTOR_INVERT (verified 2026-06-06)
//   Buttons: GP20, GP21 (active-low INPUT_PULLUP, either fires the same
//            state-machine events)
//   NeoPix:  GP23 (2 pixels, GRB, 800 kHz)
// =============================================================================

#include <Arduino.h>
#include <Wire.h>
#include <EEPROM.h>
#include "Adafruit_VL53L0X.h"   // all 6 ToFs (mapping + wall-follow) are VL53L0X now
#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h>
#include <Adafruit_AS7341.h>
#include <Adafruit_NeoPixel.h>

// =============================================================================
// === SECTION 0: TUNABLES — EDIT VALUES HERE ==================================
// =============================================================================
// Every behavioural knob lives in this block. Change a value, re-upload, done.
// Hardware identity (pin numbers, I²C addresses, MOTOR_INVERT, colour-cal
// magic) stays down in §1 / §6 because it tracks the physical bot, not tuning.
// Cross-reference: HANDOFF.md §14 has the full "bump up if… bump down if…"
// guide for every value below.

// --- LOOP DELAY -------------------------------------------------------------
// Tail delay at the bottom of loop(). Lower = faster sensor/motion ticks but
// less I²C breathing room. 5 ms is safe; 0 ms also works but hammers the bus.
static const uint32_t LOOP_TAIL_DELAY_MS = 5;

// --- FAST SENSOR PIPELINE (WF2 06-10, loop-rate overhaul) --------------------
// The old loop did SIX blocking VL53L0X single-shot reads (~33 ms each) plus a
// blocking ~110 ms AS7341 read every iteration -> ~5 Hz control loop. EVERY
// motion behaviour (wall-follow PD, turn confirm, stop checks, centering) was
// sampling at that rate, which is where the overshoot / oscillation / "WF is
// unresponsive" symptoms came from. The fixes, each individually revertable:
//
// TOF_CONTINUOUS_ENABLED: run all 6 VL53L0X in hardware continuous-ranging mode
//   (they measure autonomously every TOF_CONT_PERIOD_MS); the loop just polls
//   "is a new result ready?" (~1 ms per sensor) instead of blocking for a full
//   measurement. Loop drops ~200 ms -> ~15 ms. If a sensor stops producing for
//   TOF_STALE_MS it's flagged offline (-2) and retryFailedSensors re-inits it.
//   ⚠ Same-side sensors (WF-L ch0 + mapping-L ch2, WF-R ch7 + mapping-R ch3)
//   now range SIMULTANEOUSLY — if side readings get noticeably noisier than
//   before (IR crosstalk), set this false to restore sequential single-shot.
// COLOR_ASYNC_ENABLED: AS7341 reads via its non-blocking start/check/get API.
//   Same ~110 ms data refresh (black-abort latency unchanged), zero loop block.
// TELEM_INTERVAL_MS / USB_DEBUG_INTERVAL_MS: telemetry + USB debug used to
//   print every loop. At a 15 ms loop that would spend ~11 ms/loop blocking on
//   the 115200-baud UART, so both are now rate-limited. 50 ms = 20 Hz to the
//   Pi (was effectively 5-15 Hz — the Pi gets MORE data than before).
static const bool     TOF_CONTINUOUS_ENABLED = true;
static const uint32_t TOF_CONT_PERIOD_MS     = 33;    // >= the sensor's ~33 ms timing budget
static const uint32_t TOF_STALE_MS           = 400;   // no fresh sample this long -> offline
static const bool     COLOR_ASYNC_ENABLED    = true;
static const uint32_t TELEM_INTERVAL_MS      = 50;    // UART telemetry to the Pi (20 Hz)
static const uint32_t USB_DEBUG_INTERVAL_MS  = 200;   // human-readable USB print (5 Hz)

// --- WF3 06-10: BLUE TILE CROSSING --------------------------------------------
// Rule 3.2.5: blue = puddle/hard terrain; the bot must STOP 5 s on it (the Pi
// mapper sends WAIT_BLUE). While the colour sensor sees blue mid-move, also cap
// the drive speed so the crossing itself is gentle.
static const int      BLUE_SLOW_SPEED = 45;

// --- WF3 06-10: CHAINED MOVES ("MOVE_TILE C") ---------------------------------
// When the mapper KNOWS the next step continues straight through a known tile,
// it sends "MOVE_TILE C". The move then skips the stop/settle at the end: it
// folds the dead-reckon residual, ACKs while still slow-rolling forward, and
// keeps coasting up to CHAIN_COAST_MS waiting for the next command (the next
// MOVE_TILE takes over seamlessly; any other command stops the motors first).
// If no command arrives in time, the bot stops. Net effect: no full stop
// between tiles on routed straight runs, slow near each tile centre — which is
// also when the (future) side cameras get their victim look.
static const uint32_t CHAIN_COAST_MS    = 350;
static const int      CHAIN_COAST_SPEED = 48;   // just above the 45 stall floor

// --- WF3 06-10: RAMP TRAVERSAL -------------------------------------------------
// Detection: SUSTAINED bot-pitch change with minimal bot-roll change (an
// obstacle bumps both axes briefly; a ramp pitches one axis and holds it).
// Up:   climb until flat for RAMP_FLAT_MS (ramp done) -> reverse slowly until
//       pitch starts changing again = rear wheels at the crest edge = the tile
//       boundary -> advance to that tile's centre.
// Down: ride the decline until flat; at that instant the REAR WHEEL CONTACT is
//       at the ramp-base edge (= tile boundary) -> advance to centre.
// Geometry: front-end -> rear-wheel contact patch = 111 mm (user-measured),
// front-end -> bot centre = 93 mm; so when the rear contact sits on a boundary
// the bot centre is 18 mm past it, and centre-of-next-tile needs
// (tile/2 - 18) mm of forward travel.
static const float    RAMP_ROLL_MAX_DEG     = 6.0f;   // roll dev above this = obstacle, NOT a ramp
static const float    RAMP_FLAT_TOL_DEG     = 4.0f;   // |pitch dev| below this counts as flat
static const uint32_t RAMP_FLAT_MS          = 400;    // flat this long = ramp finished
static const int      RAMP_CLIMB_SPEED      = 75;     // PWM up/down the ramp (motors need torque uphill)
static const float    RAMP_STEER_KP         = 0.5f;   // P-only wall-follow gain on the ramp
static const uint32_t RAMP_CLIMB_TIMEOUT_MS = 20000;  // give up (fail=stuck) if never flattens
static const int      RAMP_EDGE_REV_SPEED   = 45;     // reverse crawl hunting the crest edge
static const float    RAMP_EDGE_PITCH_DEG   = 4.0f;   // pitch dev while reversing = edge found
static const uint32_t RAMP_EDGE_TIMEOUT_MS  = 4000;   // can't find the edge -> just advance
static const int      BOT_FRONT_TO_REAR_CONTACT_MM = 111;  // user-measured 11.1 cm
static const int      BOT_FRONT_TO_CENTER_MM       = 93;   // body 186/2

// --- WF3 06-10: TILT-CORRECTED READINGS (port of the Pi dashboard trig) -------
// On obstacles/ramps, raw ToF slant readings inflate (raw/cos(tilt)) and the
// beam can clear the wall top or dip into the floor. Same math the Pi runs for
// the mapping sensors (_estimate_one in serial_relay.py): horizontal = slant *
// cos(tilt), reject when the ray height leaves the 0..WALL_H band. Used for the
// WF pair (steering) and F/B (stop checks) whenever |tilt dev| exceeds the
// threshold. Sign-agnostic band check (the firmware frame isn't mount-remapped).
static const float TILT_CORRECT_MIN_DEG = 3.0f;
static const int   WALL_H_MM       = 150;
static const int   SENSOR_H_F_MM   = 67;   // sensor heights above floor — keep in sync with
static const int   SENSOR_H_B_MM   = 67;   // SENSOR_H_* in serial_relay (67.5/78.5/79.5/67.5)
static const int   SENSOR_H_WFL_MM = 78;   // ⚠ VERIFY on bot: WF heights assumed = mapping L/R
static const int   SENSOR_H_WFR_MM = 79;

// --- FORWARD-DRIVE SPEED SHAPE (LINEAR, used by MOVE_TILE) -------------------
// v(d) = clamp(V_MIN, V_MIN + (V_MAX-V_MIN)*(d - D_BRAKE)/SPEED_RAMP_MM, V_MAX)
// d = mm of room left before the stop point — far out = V_MAX, eases to V_MIN.
static const int   SPEED_V_MIN      = 50;     // WF2 06-08: ->50 (user) — min ramp speed; below ~45 the gearbox stalls
static const int   SPEED_V_MAX      = 75;     // WF2 06-09: 100->75 (user) — slower tile cruise so the wall-follow has more time per mm to correct (less overshoot)
static const int   SPEED_D_BRAKE_MM = 60;     // start braking when d <= this many mm of room
static const int   SPEED_RAMP_MM    = 240;    // distance over which speed ramps V_MIN..V_MAX
// WF2 06-08 (user): EVERY "drive until a sensor reads a target" move (CENTER,
// FRONT_ALIGN, TILE_SETTLE, recovery-centre) uses a LINEAR ramp by remaining
// error — MOVE_MAX_SPEED when far, MOVE_MIN_SPEED(=50) when close — so it slows
// into the target (accurate) but never stalls and never overshoots hard.
// WF2 06-10: 28/45 -> 45/60. 28 PWM is BELOW the documented 45-PWM gearbox
// stall floor (MOTOR_MIN_PWM) — the final nudge was commanding stalled motors,
// so CENTER/FRONT_ALIGN burned their full timeouts and accepted imperfect
// positions. The oscillation that motivated 28 was the ~5 Hz control loop
// (fixed by TOF_CONTINUOUS_ENABLED: stop checks now run ~70 Hz, so a 45-PWM
// nudge brakes within ~1 mm of crossing the target instead of ~40 mm past it).
// If settles oscillate again, lower MOVE_MAX_SPEED first; keep MIN >= 45.
static const int   MOVE_MIN_SPEED   = 45;     // = MOTOR_MIN_PWM, the real torque floor
static const int   MOVE_MAX_SPEED   = 60;
static const int   MOVE_RAMP_MM     = 120;    // err >= this -> MAX; 0 -> MIN (linear between)

// --- TURN RAMP (linear PWM(remain°) for MS_TURN_90) -------------------------
//   spd = TURN_MIN_SPEED + (TURN_SPEED - TURN_MIN_SPEED) * (remain / 90)
// In y = m·x + b form with x = remain° to go:
//      slope     m = (TURN_SPEED - TURN_MIN_SPEED) / 90
//      intercept b = TURN_MIN_SPEED         (= PWM at remain=0°, end of turn)
// Start of turn (remain=90°) -> TURN_SPEED. End of turn (remain=0°) -> TURN_MIN_SPEED.
// 2026-05-31: lowered peak 255 -> 160 and intercept 77 -> 45 because TURN_L
// overshot 90° badly and ran too fast. The intercept is the PWM still being
// commanded as the bot nears the target (remain≈0); too high = momentum carries
// it past 90°. 45 = the gearbox stall floor (MOTOR_MIN_PWM), so the turn still
// finishes the last degree but coasts far less.
//   Bump TURN_SPEED toward ~200 if the bot is sluggish to START the turn.
//   Lower TURN_MIN_SPEED toward 40 if it STILL overshoots the last few °
//   (don't go below 40 — motors stall, and there's NO turn timeout to bail).
// WF2 06-10: 40/35 -> 70/45. TURN_MIN_SPEED=35 was BELOW the 45-PWM gearbox
// stall floor — a turn that decelerated into the last few degrees could stall
// just outside the 2° tolerance and hang FOREVER (turns have no timeout; the
// 06-09 note itself warned about this). 45 = the documented floor, so the turn
// always finishes. The erratic/overshooting turns that motivated 40 were the
// ~5 Hz yaw sampling (fixed by TOF_CONTINUOUS_ENABLED: tickTurn90 now checks
// yaw ~70 Hz); 70 start speed cuts a 90° turn from ~3 s to ~1 s while the ramp
// + 150 ms confirm-hold keeps the landing accurate. If turns overshoot, lower
// TURN_SPEED toward 55 — never take TURN_MIN_SPEED below 45.
static const int      TURN_SPEED       = 70;
static const int      TURN_MIN_SPEED   = 45;    // = MOTOR_MIN_PWM; below this the turn can stall and never complete
// WF2 06-08: turns are now a SINGLE linear ramp straight to the absolute cardinal
// (no separate oscillating snap phase). Stop when within TURN_TOL_DEG and HELD
// there for TURN_CONFIRM_MS (so it doesn't latch on a flyby / overshoot). This
// killed the post-turn wiggle.
static const float    TURN_TOL_DEG     = 2.0f;  // final accuracy of a turn
static const uint32_t TURN_CONFIRM_MS  = 150;   // must stay within tol this long before declaring done
static const uint32_t TURN_TIMEOUT_MS  = 12000; // legacy; TURN has no overall timeout per user spec — kept so struct fields compile

// --- TURN LATERAL OFFSET (WF2 2026-06-06, placeholder — wiring next step) ----
// The bot drifts laterally as it pivots (slop/slip). These let a turn ALSO nudge
// the bot sideways to compensate: positive = mm to shift toward that side during
// a turn / any turning action (centering, recovery, etc). User will measure the
// values; both default 0 (no-op) until then. NOTE: not yet applied anywhere —
// created so the constants exist; the lateral-compensation logic comes next.
// TURN LATERAL DRIFT (measured 2026-06-06): reading discrepancy (side-before vs
// front-after) = 55 mm on a left turn, 30 mm on a right turn. Subtract the
// 15.5 mm sensor-geometry term (front sensor 71.5 mm out vs side 56 mm out) =>
// real lateral drift: ~40 mm LEFT on a left turn, ~15 mm RIGHT on a right turn.
// The compensation is applied during centering: the firmware CENTER command now
// takes a signed (f-b) setpoint offset ("CENTER <mm>"), and the mapper
// (TURN_DRIFT_L_MM / TURN_DRIFT_R_MM in mapper.py) sends the pre-compensation on
// the FULL_CENTER lateral pass. Values live in mapper.py to avoid a sync footgun.

// --- RAM-WALL (slam into a wall, detect contact via ToF stall) --------------
static const int      RAM_SPEED        = 90;   // WF2: bumped 70->90 (slightly harder ram for cleaner centering). Watch §9 brown-out.
static const uint32_t RAM_STALL_MS     = 350;   // distance unchanged for this long = wall hit
static const int      RAM_STALL_DELTA  = 6;     // mm of change below this counts as "no change"
static const uint32_t RAM_TIMEOUT_MS   = 4000;  // give up after this even if no stall registered

// --- RAM WIGGLE / SHIMMY (WF2) ----------------------------------------------
// After a backward ram stalls against a wall, spin the wheels in a L,R,L,R
// shimmy (one side at a time) to shake out any residual skew so the bot ends
// up squared against the wall. Runs after RAM_B and the recovery ram.
static const bool     WIGGLE_ENABLED   = true;
static const int      WIGGLE_STEPS     = 4;     // L,R,L,R
static const uint32_t WIGGLE_STEP_MS   = 250;   // ~0.25 s per side (user spec)
static const int      WIGGLE_SPEED     = 170;   // WF2: bumped 120->170 — harder shimmy to square up despite uneven motors

// --- CENTER (longitudinal recentre against F or B wall) ---------------------
// Targets from §4 geometry: centred in a 300 mm tile, body 186×170 mm w/ spacers
//   centred ⇒ F ≈ 76 mm, B ≈ 81 mm, L = R ≈ 94 mm.
static const int      CENTER_TARGET_F   = 76;
static const int      CENTER_TARGET_B   = 81;
static const int      CENTER_TARGET_LR  = 94;   // also the 1-wall lateral target during MOVE_TILE
static const int      CENTER_TOL_MM     = 8;    // within this many mm of target = done
static const int      CENTER_SPEED      = 40;   // PWM for nudging — slow enough not to overshoot
static const uint32_t CENTER_TIMEOUT_MS = 5000;
// WF2 square-tile deduction + post-center verify (see tickCenterTile):
static const int      CENTER_WALL_MAX_MM   = 250; // a ToF below this counts as a wall to centre against
static const int      TILE_NOMINAL_MM      = 310; // nominal tile size

// --- MID-MOVE EDGE CORRECTION (WF2 06-10, user spec) ------------------------
// To stop exactly in the middle of each tile, the bot watches for the physical
// wall edge (which occurs exactly halfway through a tile move: g_tileLenMm / 2).
// When the bot reaches the "slowdown window" near the middle of the tile, it
// drops to EDGE_APPROACH_SPEED and watches the side ToFs. If a wall drops
// (distance spikes out of range), the bot stops, squares its yaw to cardinal,
// reverses slowly (EDGE_REVERSE_SPEED) until the wall returns, then drives forward
// exactly (g_tileLenMm / 2) + EDGE_TO_CENTER_OFFSET_MM to reach the absolute center.
static const bool     EDGE_CORRECTION_ENABLED    = true; // WF2 06-10: master kill switch (untested on-bot — flip false if it misbehaves)
static const int      EDGE_DETECT_WINDOW_MM      = 60;  // activate ± this mm around g_tileLenMm / 2
static const int      EDGE_APPROACH_SPEED        = 50;  // PWM to crawl through the window to catch the edge
static const int      EDGE_REVERSE_SPEED         = 50;  // PWM to creep back until wall re-appears
static const int      EDGE_FWD_SPEED             = 50;  // PWM to drive the final half-tile
static const int      EDGE_TO_CENTER_OFFSET_MM   = 0;   // tuning offset: added to the final half-tile drive

static const int      SENSOR_SPAN_LR_MM    = 112; // L<->R sensor spacing (§4); used to deduce tile size
// WF-Left<->WF-Right sensor spacing. The wall-follow ToFs (ch0/ch7) sit at a
// different lateral span than the mapping L/R ToFs. Used by CAL_TILE to deduce
// tile size from the WF pair as an independent cross-check of the L/R deduction.
// VERIFY ON BOT: measure the actual WF-L..WF-R beam-to-beam distance; 112 is a
// placeholder copied from the L/R span. If CAL_TILE reports a WF width far off
// the L/R width, this constant is wrong.
static const int      SENSOR_SPAN_WF_MM    = 112;
static const int      SENSOR_SPAN_FB_MM    = 143; // Front<->Back sensor spacing (§4); CAL_TILE PREFERS this pair (the front/back ToFs are more reliable than the flaky side ToFs)
static const int      CENTER_VERIFY_TOL_MM = 20;  // post-centre: re-centre if the residual exceeds this
static const int      CENTER_MAX_RETRIES   = 2;   // cap on centre retries before accepting

// --- MEASURED TILE SIZE (CAL_TILE) ------------------------------------------
// At start-of-run the Pi issues CAL_TILE once the bot is longitudinally centred.
// The firmware deduces the true tile pitch from the lateral wall pair(s):
//   width_LR = L + R + SENSOR_SPAN_LR_MM        (mapping side ToFs, ch2/ch3)
//   width_WF = WFL + WFR + SENSOR_SPAN_WF_MM    (wall-follow ToFs, ch0/ch7)
// averaged over whichever pairs are visible, then ASSUMED SQUARE so the same
// value is the forward (longitudinal) tile pitch. The L+R sum is invariant to
// lateral position, so longitudinal-only startup centring is enough. The result
// (g_tileLenMm) drives the MOVE_TILE stop distance instead of the 300 nominal.
// Clamped to a sane band so one bad read can't make the bot under/over-shoot.
static const int      TILE_MIN_MM          = 250; // reject deduced tile below this (keep nominal)
static const int      TILE_MAX_MM          = 360; // reject deduced tile above this (keep nominal)
static const int      TILE_BACK_MARGIN_MM  = 10;  // no-front stop: back must grow by (tile - this)
// WF2 06-08 (user): open-tile dead-reckon over/undershoots, so after the back-delta
// stop NUDGE forward/back until within TILE_SETTLE_TOL_MM of the target travel,
// then carry the leftover into g_tilePosErrMm so the NEXT move cancels it.
static const int      TILE_SETTLE_TOL_MM      = 25;   // accept within this of target travel (user 2-3 cm)
static const int      TILE_SETTLE_SPEED       = 60;   // PWM for the corrective nudge
static const uint32_t TILE_SETTLE_COAST_MS    = 250;  // brake & let the bot coast to rest before judging travel
static const uint32_t TILE_SETTLE_TIMEOUT_MS  = 1500; // bail (accept) if it can't settle
static const float    SET_TILE_YAW_TOL_DEG    = 6.0f; // reject a tile recal if the bot is more crooked than this off its grid cardinal (slant corrupts f/b)
static const float    YAW_SQUARE_TOL_DEG      = 3.0f; // YAW_SQUARE: re-square only if the bot is more than this off its grid cardinal (else no-op)

// --- MOVE_TILE (forward one tile w/ wall-follow, stuck detect, recovery) ----
static const uint32_t MOVE_TILE_TIMEOUT_MS = 20000; // legacy; MOVE_TILE has no overall timeout per user spec
static const int      MOVE_FRONT_STOP_MM   = 60;    // WF2 06-08: 80->60 (user) — let the bot push deeper toward a front wall (less "stops near the edge"); FRONT_ALIGN then settles it to 93mm

// --- BLIND ODOMETRY FALLBACK (06-10/11, user — "7-tile corridor skips tiles") --
// Ported from WF2. VL53L0X readings beyond TOF_ODOM_MAX_MM are junk-prone (8190
// spikes, drift), and the old stop logic trusted ANY positive read: a junk
// startFront made targetFront absurd so the next junk read "reached" it
// (skipped tiles), and with BOTH walls out of range the move had NO stop
// condition at all. Now: F/B reads >= TOF_ODOM_MAX_MM are never used as travel
// references. With neither valid the move runs BLIND:
//   - fixed slow BLIND_SPEED so the time-based estimate is predictable
//     (travel ≈ elapsed / BLIND_MS_PER_MM — calibrate from DIAG blind lines),
//   - a tracked side wall ENDING re-anchors the estimate (wall edges sit on
//     tile boundaries; release-debounce lag is compensated),
//   - the moment the front wall comes into range, the stop target snaps onto
//     the grid that wall defines (FRONT_ALIGN_TARGET + k*tile).
static const int   TOF_ODOM_MAX_MM = 800;   // F/B usable for odometry only below this
static const int   BLIND_SPEED     = 70;    // fixed PWM while driving blind (= WF2's effective blind cap, so BLIND_MS_PER_MM calibrates the same on both builds)
static const float BLIND_MS_PER_MM = 6.0f;  // ms of drive per mm at BLIND_SPEED — TUNE ON BOT: blind tiles run LONG -> lower it; SHORT -> raise it

// --- POST-MOVE FRONT ALIGN (WF2 2026-06-07, user spec) ----------------------
// After every MOVE_TILE, if a front wall sits within ~one tile (the bot ended
// up partway into the tile), nudge forward/back until the front ToF reads
// FRONT_ALIGN_TARGET_MM. Squares the bot up against the front wall at a known
// clearance so the next sense/turn starts from a clean longitudinal position.
// Skipped when the front is open (no wall within FRONT_ALIGN_TRIGGER_MM).
static const int      FRONT_ALIGN_TARGET_MM  = 60;   // WF2 06-08: 100->93 (user) — desired front clearance after a move
static const int      FRONT_ALIGN_TRIGGER_MM = 200;  // only align if front wall is within this (≈ one tile)
static const int      FRONT_ALIGN_TOL_MM     = 5;    // within this of target = done
static const uint32_t FRONT_ALIGN_TIMEOUT_MS = 2500; // bail (accept) if it can't settle
// Max distance the front-align is allowed to drive FORWARD to reach the target
// (06-08). Backing up to fix an overshoot is uncapped (safe), but driving
// forward is capped so the bot can NEVER lunge a whole tile toward a far wall
// under the guise of "snapping". If the target needs more than this much forward
// travel, it just accepts the current position.
static const int      FRONT_ALIGN_FWD_CAP_MM = 70;

// --- CONTINUOUS CORRIDOR DRIVE (multi-tile, user spec 2026-06-07) ------------
// One MOVE_TILE drives straight through a fully-walled corridor in a single
// smooth motion instead of stopping every tile. It emits a "TILE n=.. L=.. R=..
// F=.." line at each tile CENTRE (so the mapper counts + maps each tile),
// slow-rolls at each centre so the side cameras can catch victims, and ends the
// move at the first DECISION POINT: a side wall opens (possible turn) or a wall
// appears ahead. Tile distance comes from the BACK wall (recedes) handed off to
// the FRONT wall (approaches) — reliable for straight runs within ToF range
// (~6 tiles). Flip CORRIDOR_DRIVE_ENABLED false to revert to one-tile-per-move.
static const bool CORRIDOR_DRIVE_ENABLED = false;  // 06-07: OFF — rolling per-tile reads set false walls -> explorer quit early + rammed. Back to reliable one-tile-per-move + stopped sensing.
static const int  BACK_ODO_MAX_MM      = 1100; // back wall usable for odometry below this mm
static const int  FRONT_ODO_MAX_MM     = 1100; // front wall usable for odometry below this mm
static const int  FRONT_BLOCK_MM       = 180;  // front wall within this at a centre = wall ahead -> stop
static const int  CORRIDOR_SLOWZONE_MM = 70;   // slow-roll within this many mm of a tile centre
static const int  CORRIDOR_SLOW_SPEED  = 72;   // PWM at tile centres (camera slow-roll; ~gearbox floor)
static const int  CORRIDOR_CRUISE_SPEED= 100;  // PWM cruising between centres (wall-follow can track this)

// --- WALL-FOLLOW lateral correction (during MOVE_TILE driving) --------------
// MOVE_TILE lateral steering = PURE ULTRASONIC P-CONTROL. No yaw heading-hold
// in the wall-follow — the correction comes entirely from the HC-SR04 readings
// with Kp gains tuned on-bot 2026-06-01.
//
// INFLIGHT_LATERAL_ENABLED: legacy ToF wall-follow. LOCKED false — ultrasonic
// Kp replaces it entirely. Don't flip true.
static const bool  INFLIGHT_LATERAL_ENABLED = false;
// What counts as "have a wall" on a side during MOVE_TILE: side ToF must be
// valid AND below this distance for wall-follow / recovery to use it.
static const int   WALL_FOLLOW_SIDE_MAX_MM = 220;
// Yaw-cos correction: only correct side ToFs when |yawOff| exceeds this (deg).
// Avoids noise-amplification when the bot is essentially straight.
static const float WALL_FOLLOW_YAW_COS_MIN_DEG = 1.5f;

// --- WF2 YAW GUARD (during MOVE_TILE driving) -------------------------------
// Hard cap on how far the bot may yaw off the move's cardinal heading while
// wall-following. User: "2 degrees of yaw is all i can afford." Within the
// deadband: nothing. Past it: a gentle corrective bias. Past YAW_GUARD_MAX_DEG:
// suppress the wall-follow lateral bias and straighten HARD until back in
// budget. Keeps the bot on the grid axis (anti "turns into a wall"). This
// deliberately re-introduces a SMALL gyro term into the otherwise pure
// wall-follow — scoped only to capping heading, not steering to walls.
// 06-08: gyro-only first move STILL swerved -> the gyro/yaw term is the culprit,
// not the wall-follow. YAW_GUARD_ENABLED=false removes the gyro heading-hold from
// the drive entirely; MOVE_TILE then steers on wall-follow (WF ToF) ONLY. With no
// walls it runs open-loop (straight-ish) rather than yawing off a bad gyro read.
static const bool  YAW_GUARD_ENABLED    = false;
static const float YAW_GUARD_MAX_DEG    = 2.0f;   // the budget — never exceed
static const float YAW_GUARD_DEAD_DEG   = 0.5f;   // below this: no correction
static const float YAW_GUARD_GAIN_SOFT  = 3.0f;   // PWM bias per deg, within budget
static const float YAW_GUARD_GAIN_HARD  = 7.0f;   // PWM bias per deg, over budget
static const int   YAW_GUARD_BIAS_MAX   = 25;     // clamp the yaw bias

// --- ULTRASONIC WALL-FOLLOW (HC-SR04 ×2, lateral steering during MOVE_TILE) -
// Pure P-control: lateralBias = error * Kp, clamped to ±US_WF_BIAS_MAX.
// NO yaw heading-hold — ultrasonics alone keep the bot centred.
// Reads alternate L/R each tick to halve blocking time.
//   Left  sonar: TRIG=GP3, ECHO=GP2
//   Right sonar: TRIG=GP5, ECHO=GP4
// !! RP2350 GPIO is 3.3 V and NOT 5 V tolerant. ECHO lines need a divider
//    if using 5 V HC-SR04s. TRIG at 3.3 V is fine.
static const bool     US_WALL_FOLLOW_ENABLED = true;
static const int      US_LEFT_TRIG   = 3;
static const int      US_LEFT_ECHO   = 2;
static const int      US_RIGHT_TRIG  = 5;
static const int      US_RIGHT_ECHO  = 4;
static const int      US_WF_TARGET_MM   = 100;   // legacy fallback only — real targets are the per-side g_us_wf_target_L=127 / _R=96
static const int      US_WF_SIDE_MAX_MM = 300;   // WF2 06-09: 220->300 (user) — a wall at ~23cm was BEYOND detection so the bot never followed it. 300 = follow walls within ~one tile; still rejects the truly-open side.
static const int      US_MAX_RANGE_MM   = 2000;
static const uint32_t US_ECHO_TIMEOUT_US = 2500; // pulseIn timeout (~43 cm); tuned down from 4000
// Kp gains — tuned on-bot 2026-06-01 (pure ultrasonic, no yaw).
//   Higher Kp = snappier correction, risks oscillation.
//   Lower Kp  = gentler, smoother, slower to react.
static float US_WF_KP_2WALLS = 0.05f;
static float US_WF_KP_1WALL  = 0.05f;
// WF2 06-09: PD wall-follow. P (Kp·error) corrects toward the target distance; D
// (Kd·Δerror) damps the approach so a big offset does NOT overshoot/swerve INTO
// the wall. No dead-zone — it corrects ALL errors (the old dead-zone left the bot
// uncorrected at 23 cm). Pure ultrasonic, no gyro.
//   Kp too high -> oscillates;  Kd too high -> sluggish / jittery on sensor noise.
static float US_WF_KD = 3.0f;   // derivative gain (per-tick Δerror; WF tick is fixed 12 ms)
static const int US_WF_BIAS_MAX = 40;    // clamp total lateral bias to ±this
// EMA smoothing: smoothed = (smoothed * EMA_KEEP + raw * EMA_NEW) / EMA_DIV
//   WF2 06-09: 50/50 was too laggy (user: "unresponsive — overcorrects then
//   corrects back extremely slowly"). 25/75 = far snappier; the PD's D term now
//   provides the damping, so the heavy smoothing isn't needed. Lower NEW toward
//   50/50 only if the flaky WF sensors make it twitchy.
static const int   WALL_FOLLOW_EMA_KEEP    = 1;
static const int   WALL_FOLLOW_EMA_NEW     = 3;
static const int   WALL_FOLLOW_EMA_DIV     = 4;

// --- LOOP TIMING ------------------------------------------------------------
static const uint32_t WALLFOLLOW_INTERVAL_US = 12000; // ~83 Hz for PID loop

// (ToF-check STRAFE removed 06-08 — user found it useless; it stopped mid-corridor,
//  turned to face the wall, rammed and turned back, reading as a swerve. 1-wall
//  follow now relies on the P-steer + the periodic YAW_SQUARE.)

// --- YAW-SNAP AFTER TURN ----------------------------------------------------
// Used by the in-place snap helper turnTowardYaw (recovery-snap + wall-drop snap).
// (The old adaptive post-turn snap is gone — turns now ramp+confirm in tickTurn90.)
static const float    SNAP_TOL_DEG     = 0.8f;  // turnTowardYaw "settled" tolerance
// WF2 06-10: 30/40 -> 55/55. Both were below TURN_MIN_SPEED (turnTowardYaw
// floors at TURN_MIN_SPEED anyway, so caps below it were dead values) and below
// the 45-PWM stall floor. 55 gives the snap real torque headroom.
static const int      SNAP_SPEED       = 55;    // recovery-snap turnTowardYaw cap speed
static const int      SNAP_SPEED_START  = 55;   // wall-drop snap turnTowardYaw cap speed
static const uint32_t SNAP_TIMEOUT_MS  = 2000;  // recovery-snap (turnTowardYaw) safety net

// --- WALL-DROP SNAP (WF2 06-08, user) ---------------------------------------
// When the bot is following BOTH side walls and one of them ends (2-wall ->
// 1-wall), it stops, rotates in place to square its heading onto the expected
// grid cardinal, then resumes the same forward move. Stops a freshly-opened
// side from yanking the wall-follow error term and swerving the bot into the
// remaining wall. Bounded by this timeout so a jittery yaw can't stall the move.
static const uint32_t WALLDROP_SNAP_TIMEOUT_MS = 1500;
// WF2 06-09: after the wall-drop yaw straighten, re-center against the REMAINING
// wall (turn to face it, drive out the error, turn back, repeat) until within tol.
static const int      WD_RECENTER_TOL_MM = 20;   // accept within 2 cm of the wall target (user)
static const int      WD_MOVE_TOL_MM     = 8;    // corrective-drive "reached the error" tolerance
static const uint8_t  WD_MAX_ITERS       = 3;    // cap the face-move-back loop

// --- OBSTACLE DETECTION (pitch/roll deviation during MOVE_TILE) -------------
// If either pitch or roll deviates more than this many degrees from the start
// angle, mark onObstacle = true and suppress lateral correction for the rest
// of the move (gyro-only). Stops bad lateral commands when chassis tilts.
static const float OBSTACLE_TILT_DEG = 5.0f;

// --- RAMP DETECTION (sustained bot pitch during MOVE_TILE) ------------------
// Bot pitch corresponds to the firmware's roll_deg axis (BNO055 is mounted
// such that chip-roll = bot-pitch — see remap_imu in serial_relay.py). If
// |roll_dev| > RAMP_TILT_DEG sustained for RAMP_SUSTAIN_MS during a MOVE_TILE,
// emit a single "RAMP UP"/"RAMP DOWN" line on Serial1; mapper bumps its floor
// counter on receipt (rule 5.6.9 + exit-bonus SRN). Threshold > OBSTACLE_TILT_
// DEG so a 1-cm speed bump won't trip it; max-25° ramp spec easily clears 10°.
// WF3 06-11 (user): 10 -> 15 — fewer false ramp triggers from bumps/obstacles.
// The rules cap ramp incline at 25° (less outside the danger zone), so 15 still
// clears every legal ramp with margin while a chunky obstacle tilt won't trip it.
static const float    RAMP_TILT_DEG   = 15.0f;
static const uint32_t RAMP_SUSTAIN_MS = 1000;

// --- BLACK-TILE ABORT --------------------------------------------------------
// Detected mid-MOVE_TILE. Reverse for up to BLACK_RECOVER_MS, or until back
// ToF returns to ≈ startBack (back at previous tile centre).
// BLACK_DETECT_WARMUP_MS suppresses false triggers from the colour sensor in
// the first few ms of a move while we're still over the previous tile.
static const uint32_t BLACK_RECOVER_MS       = 1200;
static const uint32_t BLACK_DETECT_WARMUP_MS = 300;

// --- STUCK DETECTION (during MOVE_TILE) -------------------------------------
// If back-ToF hasn't moved more than STUCK_DELTA_MM in STUCK_WINDOW_MS AND
// the move has run for at least STUCK_WARMUP_MS, give up with reason=stuck.
static const int      STUCK_DELTA_MM   = 15;
static const uint32_t STUCK_WINDOW_MS  = 1500;
static const uint32_t STUCK_WARMUP_MS  = 600;
// Minimum mm of forward travel before wall-loss recovery is allowed to fire.
// Stops the recovery state machine from triggering on a wall-blind start.
static const int      RECOVERY_MIN_TRAVEL_MM = 50;
// WF2: a side wall must persist at least this long before we treat it as an
// ESTABLISHED wall whose disappearance triggers reverse+ram recovery. A wall
// glimpsed for less than this at the start of a move is just the trailing EDGE
// of the wall we were following before the last turn — ignore its loss, don't
// chase/ram it (that was corrupting the map). Set ~0.75 s per the field report.
static const uint32_t WALL_ESTABLISH_MS = 750;
// WF2: anti-fluke debounce for ToF wall PRESENCE. A side wall (WF or mapping
// ToF) must read present continuously for this long before it counts as present,
// and absent this long before it counts as gone. Kills single-read flukes that
// flip wall-follow mode / fire recovery. Timestamp-based — zero loop-time cost.
// ASYMMETRIC debounce. A wall must read PRESENT continuously for
// WALL_DEBOUNCE_MS before we start following it (anti-fluke per user spec), but
// once we're following, it only needs to read ABSENT for WALL_RELEASE_MS before
// we stop — otherwise the bot keeps steering toward the ghost of a wall that
// already ended ("follows the edge even when it's gone"). Keep release short
// but above a single-read fluke.
static const uint32_t WALL_DEBOUNCE_MS = 500;   // WF2 06-07: present must hold 0.5 s before it counts
// WF2 06-10: was 1 (one millisecond!) — a SINGLE flaky-ToF frame reading -1
// instantly dropped the wall, flapping wfMode and spuriously firing the
// wall-drop / edge-correction stop-and-square dances mid-corridor (the flaky
// WF-Left ToF does exactly this). 100 ms = the originally documented intent:
// still drops a truly-ended wall fast, but one bad frame can't.
static const uint32_t WALL_RELEASE_MS  = 100;

// --- CORNER BEAMS (comp-arena aluminium posts at every tile corner) ---------
// Detection logic isn't wired yet. Flip USE_CORNER_BEAMS true when the arena
// is confirmed to have them; side ToFs will treat a brief
// CENTER_TARGET_LR ± BEAM_WINDOW_MM blip as a mid-move alignment ping.
static const bool USE_CORNER_BEAMS = false;
static const int  BEAM_WINDOW_MM   = 25;

// --- BUTTONS -----------------------------------------------------------------
static const uint32_t HOLD_THRESH_MS = 5000;  // press-and-hold this long to STOP/START
static const uint32_t DEBOUNCE_MS    = 50;    // edge debounce window

// --- SENSOR HEALTH -----------------------------------------------------------
static const uint32_t SENSOR_RETRY_INTERVAL_MS = 5000; // how often to retry init on offline sensors

// =============================================================================
// === END SECTION 0 ===========================================================
// =============================================================================


// =============================================================================
// === SECTION 1: HARDWARE CONFIGURATION ======================================
// =============================================================================

// --- I²C mux / sensor addresses ---
#define PCA9548A_ADDR 0x70
#define BNO055_ADDR   0x28
#define AS7341_ADDR   0x39
#define CH_FRONT 1
#define CH_LEFT  2
#define CH_RIGHT 3
#define CH_BACK  4
#define CH_COLOR 5
#define CH_IMU   6
// WF2: dedicated wall-follow ToFs — now VL53L0X (same chip as the mapping ToFs;
// were VL6180X, swapped 2026-06-06 after a fry — long-range now, retune targets)
#define CH_WF_LEFT  0
#define CH_WF_RIGHT 7
#define I2C_BUS Wire1   // I²C1 on GP18/GP19

// --- Buttons (active-low INPUT_PULLUP) ---
#define BTN_START 20
#define BTN_LOP   21

// --- Motor pins ---
#define M1A   8
#define M1B   9
#define M2A   10
#define M2B   11
#define M3A   12
#define M3B   13
#define M4A   14
#define M4B   15
// Motor index convention: 0=M1=FR, 1=M2=BR, 2=M3=FL, 3=M4=BL.
static const int motorPinsA[4]   = {M1A, M2A, M3A, M4A};
static const int motorPinsB[4]   = {M1B, M2B, M3B, M4B};
// true => invert this motor's "forward" so bot-frame primitives stay sane.
// Re-verified 2026-06-06 on the new chassis via Motor_Test 'A': RIGHT side
// (FR/BR) A-pin = bot-forward (not inverted); LEFT side (FL/BL) A-pin =
// bot-backward (inverted). So the inverted pair is now the LEFT motors.
static const bool MOTOR_INVERT[4] = { false, false, true, true };
#define MOTOR_MIN_PWM 45
#define MOTOR_MAX_PWM 255

// --- NeoPixel ---
#define NEOPIXEL_PIN   23
#define NEOPIXEL_COUNT 2

// --- Colour fallback thresholds (used only when no EEPROM calibration) ---
static const uint32_t COLOR_BLACK_MAX  = 1500;
static const uint32_t COLOR_SILVER_MIN = 80000;
static const float    COLOR_BLUE_RATIO = 1.5f;
static const float    COLOR_RED_RATIO  = 1.5f;

// --- Calibration storage (keep in sync with Color_Calibrate.ino) ---
#define CAL_MAGIC   0xCA110055UL
#define CAL_VERSION 2

struct ColorRef       { uint32_t sum, blue, red; };
struct CalibrationData {
  uint32_t magic;
  uint16_t version;
  uint16_t _pad;
  ColorRef black, white, silver, blueRef, redRef;
};
CalibrationData cal;
bool calLoaded = false;

// =============================================================================
// === SECTION 2: SENSOR INSTANCES + GLOBAL STATE =============================
// =============================================================================

Adafruit_VL53L0X loxFront;
Adafruit_VL53L0X loxLeft;
Adafruit_VL53L0X loxRight;
Adafruit_VL53L0X loxBack;
Adafruit_VL53L0X loxWFL;   // WF2: wall-follow LEFT  ToF (VL53L0X, mux ch0)
Adafruit_VL53L0X loxWFR;   // WF2: wall-follow RIGHT ToF (VL53L0X, mux ch7)
Adafruit_BNO055  bno    = Adafruit_BNO055(55, BNO055_ADDR, &I2C_BUS);
Adafruit_AS7341  color;
Adafruit_NeoPixel strip(NEOPIXEL_COUNT, NEOPIXEL_PIN, NEO_GRB + NEO_KHZ800);

bool frontOK = false, leftOK = false, rightOK = false, backOK = false;
bool okWFL = false, okWFR = false;   // WF2: wall-follow ToFs (ch0 L / ch7 R)
bool bnoOK = false, colorOK = false;
uint32_t tick = 0;

// Latest sensor readings, refreshed each main-loop iteration. Motion code
// and the run-state machine read from here; nobody else does I²C.
struct Sensors {
  int   front_mm;
  int   left_mm;
  int   right_mm;
  int   back_mm;
  float yaw_deg;
  float pitch_deg;
  float roll_deg;
  bool  imu_trusted;
  char  color;
  uint32_t ts_ms;
};
Sensors g_sensors = { -2, -2, -2, -2, 0, 0, 0, false, '-', 0 };

// Last ultrasonic wall-follow readings (mm). Updated each MOVE_TILE driving
// tick, emitted in telemetry as uL=/uR= for tuning. -2 = not read yet (idle /
// not driving), -1 = no echo / out of range, else mm to the side wall.
int g_usL_mm = -2;
int g_usR_mm = -2;

// Per-side wall-follow targets (mm). Mutable so the Pi's startup CAL_US
// command can write them from live readings after the first CENTER, giving
// each sensor its own calibr ated "centred" reference (mount offsets between
// L and R aren't perfectly symmetric in practice). Both init to the pre-cal
// fallback US_WF_TARGET_MM defined in §0.
int g_us_wf_target_L = 95;
int g_us_wf_target_R = 135;
// WF2 (2026-06-06): capture the WF targets from the AS-PLACED bot at startup,
// BEFORE the first ram/center. Centering wheel-slip was shifting the bot toward
// the right wall, so a post-center CAL_US captured a bad (asymmetric) baseline.
// Once this is set, CAL_US is ignored (the startup baseline wins). "for now."
bool g_usWfCaptured = false;

// Cardinal yaw reference captured via CAL_REF after the first alignment.
// All turn-snaps target the nearest (g_yawRef0 + N*90). -1 = not yet captured.
float g_yawRef0 = -1.0f;          // RAW BNO frame. The grid's cardinal axis (g_yawRef0 + N*90).
bool  g_yawRefCaptured = false;
// WF2 06-08 TWO-SAMPLE YAW REFERENCE (user). g_yawRef0 is provisionally captured
// at power-on, then REFINED from two readings that should lie on the same 90°
// grid: sample A right after the FIRST ram, sample B just before the FIRST
// MOVE_TILE. If they disagree modulo 90 by > YAWREF_GRID_DISAGREE_DEG (e.g. a
// brownout reset offset one of them ~45°), trust the LATER one (B); otherwise
// average them. After that the reference is fixed — no further recalibration.
float g_yawSampleA = 0.0f;        // RAW frame yaw captured after the first ram
bool  g_yawSampleAValid = false;
bool  g_yawRefReconciled = false; // true once the A/B reconciliation has run
static const float YAWREF_GRID_DISAGREE_DEG = 20.0f;

// ToF reference readings captured alongside the yaw reference.
// Used for opposite-wall centering fallback distances.
int g_tofRef_F = -1;
int g_tofRef_B = -1;
int g_tofRef_L = -1;
int g_tofRef_R = -1;

// Measured tile pitch (mm), deduced by CAL_TILE from the lateral wall pair(s).
// Defaults to the nominal until CAL_TILE runs (and stays nominal if no lateral
// walls are visible). MOVE_TILE uses this for its forward/back stop distance.
int g_tileLenMm = TILE_NOMINAL_MM;

// WF2 06-08 (user): carried position error for the dead-reckon stop. Each MOVE_TILE
// targets travel = (g_tileLenMm - g_tilePosErrMm); after the move the leftover is
// folded back in so the NEXT move cancels it (no cumulative over/undershoot). A
// front-wall align is an absolute fix, so it RESETS this to 0. Clamped so a glitch
// can't push the target travel absurd.
float g_tilePosErrMm = 0.0f;
static const float TILE_POSERR_CLAMP_MM = 80.0f;

// One-shot: when true, the NEXT MOVE_TILE drives on gyro/yaw-hold only (no
// wall-follow lateral bias). Set by the WF_OFF_NEXT command, consumed (cleared)
// at the start of the next MOVE_TILE. Used to drive the first tile of a run
// purely on gyro (swerve isolation).
bool g_wfOffNext = false;

// =============================================================================
// === SECTION 3: TYPES SHARED ACROSS SECTIONS =================================
// =============================================================================

enum RunState : uint8_t {
  RUN_STOPPED = 0,
  RUN_RUNNING,
  RUN_PAUSED,
};
static RunState g_runState = RUN_STOPPED;

// ButtonState lives up here (not down by its consumers) because Arduino's
// auto-prototyper emits `serviceButton(ButtonState&, int)` at the very top
// of the combined .ino - the struct must be visible at that point or the
// prototype itself fails to compile.
struct ButtonState {
  bool     pressed;
  uint32_t lastEdgeMs;
  uint32_t pressStartMs;
  bool     holdFired;
};

// Per-sensor health + retry bookkeeping. Same hoisting concern as above:
// referenced by retryFailedSensors() and the loop() telemetry emit.
struct SensorHealth {
  uint32_t lastRetryMs;
  uint32_t recoveredCount;   // diagnostic - how many times this sensor came back
};
static SensorHealth g_health = { 0, 0 };

// WF2: generic boolean debounce (hoisted here like ButtonState so the auto-
// prototyper sees the type). `stable` only flips once `raw` has held its new
// value for the debounce window. Used for ToF wall-presence anti-fluke.
struct DebounceBool {
  bool     stable;
  bool     lastRaw;
  uint32_t sinceMs;
};
// Four wall-presence debouncers: WF ToFs (ch0/ch7) + mapping side ToFs (ch2/ch3).
static DebounceBool g_dbWfL  = { false, false, 0 };
static DebounceBool g_dbWfR  = { false, false, 0 };
static DebounceBool g_dbSideL = { false, false, 0 };
static DebounceBool g_dbSideR = { false, false, 0 };

// =============================================================================
// === SECTION 4: FORWARD DECLARATIONS =========================================
// =============================================================================
// Arduino's auto-prototyper handles most cases, but we make the cross-section
// API explicit here for readability.

void motorsInit();
void motorsAllStop();
void driveMotor(int idx, bool forward, int speed);
void moveForward(int s);
void moveBackward(int s);
void turnLeftInPlace(int s);
void turnRightInPlace(int s);
void driveTank(int leftSigned, int rightSigned);

void ledsInit();
void ledsTick();
void ledVictim(char type);
void ledExitStart();
void ledTeam(const char* color);

void buttonsInit();
void buttonsTick();
// Explicit prototype (ButtonState is visible here, defined in §3): pre-empts the
// Arduino auto-prototyper, which was emitting this at the top of the combined
// .ino where ButtonState isn't yet declared -> "ButtonState was not declared".
static bool serviceButton(ButtonState& bs, int pin);
static bool debounceBool(DebounceBool& d, bool raw, uint32_t now,
                         uint32_t onMs, uint32_t offMs);
RunState getRunState();
const char* runStateName(RunState s);
char runStateChar(RunState s);
bool isRunning();

void motionTick();
bool motionIsBusy();
void motionStart_Turn90(int dir);
void motionStart_MoveTile(bool chain = false);   // WF3: chain = "MOVE_TILE C"
void motionStart_RamWall(uint8_t side);
void motionStart_CenterTile(int latOffset = 0);
void motionStart_WaitBlue(uint32_t ms);
void motionHalt();

void commandsTick();

// =============================================================================
// === SECTION 5: I²C MUX + SENSOR INIT/READ ===================================
// =============================================================================

void tcaSelect(uint8_t channel) {
  if (channel > 7) return;
  I2C_BUS.beginTransmission(PCA9548A_ADDR);
  I2C_BUS.write(1 << channel);
  I2C_BUS.endTransmission();
}

bool initSensor(Adafruit_VL53L0X &lox, uint8_t channel, const char *name) {
  for (uint8_t attempt = 1; attempt <= 3; attempt++) {
    tcaSelect(channel);
    delay(50);
    if (lox.begin(0x29, false, &I2C_BUS)) {
      Serial.print("OK:   "); Serial.print(name);
      Serial.print(" on mux ch "); Serial.print(channel);
      Serial.print(" (attempt "); Serial.print(attempt); Serial.println(")");
      return true;
    }
    delay(100);
  }
  Serial.print("FAIL: "); Serial.print(name);
  Serial.print(" on mux ch "); Serial.print(channel);
  Serial.println(" - begin() failed 3x");
  return false;
}

void scanI2CBus() {
  Serial.println("Scanning I²C bus (expect 0x70 for the PCA9548A)...");
  uint8_t count = 0;
  for (uint8_t addr = 1; addr < 127; addr++) {
    I2C_BUS.beginTransmission(addr);
    if (I2C_BUS.endTransmission() == 0) {
      Serial.print("  found 0x");
      if (addr < 16) Serial.print("0");
      Serial.println(addr, HEX);
      count++;
    }
  }
  if (!count) Serial.println("  >>> NOTHING on the bus. Check SDA/SCL/GND/pull-ups.");
}

void scanMuxChannels() {
  Serial.println("Probing each mux channel (VL53L0X@0x29, BNO055@0x28, AS7341@0x39)...");
  static const uint8_t probe_addrs[] = {0x28, 0x29, 0x39};
  for (uint8_t ch = 0; ch < 8; ch++) {
    tcaSelect(ch);
    delay(5);
    for (uint8_t i = 0; i < sizeof(probe_addrs); i++) {
      uint8_t addr = probe_addrs[i];
      I2C_BUS.beginTransmission(addr);
      if (I2C_BUS.endTransmission() == 0) {
        Serial.print("  ch "); Serial.print(ch);
        Serial.print(": device at 0x"); Serial.println(addr, HEX);
      }
    }
  }
}

int readDistance(Adafruit_VL53L0X &lox, uint8_t channel) {
  tcaSelect(channel);
  VL53L0X_RangingMeasurementData_t m;
  lox.rangingTest(&m, false);
  return (m.RangeStatus != 4) ? (int)m.RangeMilliMeter : -1;
}

// ----- WF2 06-10: ToF continuous-ranging fast path ---------------------------
// With TOF_CONTINUOUS_ENABLED each VL53L0X free-runs a measurement every
// TOF_CONT_PERIOD_MS in hardware; tofRead() just polls "result ready?" and
// fetches it (~1 ms) instead of blocking ~33 ms per sensor. Between fresh
// results the last value is reused (it is at most one period old). A sensor
// that stops producing results for TOF_STALE_MS gets flagged offline via the
// caller's ok-flag so retryFailedSensors() re-inits it (and re-starts
// continuous mode) — self-healing, and the loop NEVER blocks on a wedged chip.
struct TofCache { int mm; uint32_t freshMs; };
static TofCache g_tofCache[8] = {};   // indexed by mux channel

static void tofStartContinuous(Adafruit_VL53L0X &lox, uint8_t channel) {
  if (!TOF_CONTINUOUS_ENABLED) return;
  tcaSelect(channel);
  lox.startRangeContinuous(TOF_CONT_PERIOD_MS);
  g_tofCache[channel].mm      = -1;
  g_tofCache[channel].freshMs = millis();
}

// Returns mm; -1 = out of range / no echo (matching readDistance semantics).
// Sets okFlag=false (sensor offline) when the chip has gone stale.
static int tofRead(Adafruit_VL53L0X &lox, uint8_t channel, bool &okFlag) {
  if (!TOF_CONTINUOUS_ENABLED) return readDistance(lox, channel);
  tcaSelect(channel);
  if (lox.isRangeComplete()) {
    uint16_t mm = lox.readRangeResult();      // 0xFFFF = out of range (status 4)
    g_tofCache[channel].mm      = (mm == 0xFFFF) ? -1 : (int)mm;
    g_tofCache[channel].freshMs = millis();
  } else if (millis() - g_tofCache[channel].freshMs > TOF_STALE_MS) {
    okFlag = false;   // wedged — retryFailedSensors() will re-init + restart continuous
    return -2;
  }
  return g_tofCache[channel].mm;
}

// WF2 (2026-06-06): wall-follow ToFs (ch0/ch7) are now VL53L0X — they use the
// same initSensor()/readDistance() as the mapping ToFs. The old VL6180X-specific
// initVL6180()/readVL6180() are gone, and so is the Adafruit_VL6180X dependency.

// ----- HC-SR04 ultrasonic (wall-follow only, see SECTION 0) -----------------
// 10 us trigger pulse, time the echo-high width, convert to mm. Blocking via
// pulseIn(), but only called during MOVE_TILE driving so turns stay fast.
// Returns -1 on timeout (no wall within range) or absurd reads.
//   distance = echo_us / 5.8   (~58 us per cm round-trip => 5.8 us per mm)
int readUltrasonic(int trigPin, int echoPin) {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  unsigned long dur = pulseIn(echoPin, HIGH, US_ECHO_TIMEOUT_US);
  if (dur == 0) return -1;                 // timeout: no echo in range
  int mm = (int)(dur / 5.8f);
  if (mm > US_MAX_RANGE_MM) return -1;       // clamp absurd reads to "no wall"
  return mm;
}

void ultrasonicInit() {
  pinMode(US_LEFT_TRIG,  OUTPUT);
  pinMode(US_LEFT_ECHO,  INPUT);
  pinMode(US_RIGHT_TRIG, OUTPUT);
  pinMode(US_RIGHT_ECHO, INPUT);
  digitalWrite(US_LEFT_TRIG,  LOW);
  digitalWrite(US_RIGHT_TRIG, LOW);
}

bool initBNO055() {
  tcaSelect(CH_IMU);
  delay(10);
  // IMUPLUS mode = gyro + accelerometer fusion only, no magnetometer. We
  // never need absolute heading (only relative 90° turns) and the mag
  // calibration ritual is impossibly painful next to brushed motors. With
  // mag fusion disabled, the BNO055 trust digits go up after the easy two
  // steps: hold still (gyro) + 6-face tilt (accel). Yaw will drift slightly
  // over the run, which we compensate for by re-ramming walls.
  if (!bno.begin(OPERATION_MODE_IMUPLUS)) {
    Serial.print("FAIL: BNO055 not found at 0x28 on mux ch ");
    Serial.println(CH_IMU);
    return false;
  }
  delay(50);
  bno.setExtCrystalUse(true);
  Serial.print("OK:   BNO055 at 0x28 on mux ch "); Serial.print(CH_IMU);
  Serial.println(" (mode: IMUPLUS - gyro+accel, no mag)");
  return true;
}

bool initAS7341() {
  tcaSelect(CH_COLOR);
  delay(10);
  if (!color.begin(AS7341_ADDR, &I2C_BUS)) {
    Serial.print("FAIL: AS7341 not found at 0x39 on mux ch ");
    Serial.println(CH_COLOR);
    return false;
  }
  color.setATIME(29);
  color.setASTEP(599);
  color.setGain(AS7341_GAIN_256X);
  color.setLEDCurrent(40);
  color.enableLED(true);
  Serial.print("OK:   AS7341 at 0x39 on mux ch "); Serial.println(CH_COLOR);
  return true;
}

// Periodically re-attempt init on any sensor that was offline. Handles the
// flaky-back-ToF case the user has been seeing (reseated wiring + I²C glitch
// recovery). When a sensor comes back online we emit "RECOVERED <name>" on
// Serial1 so the Pi dashboard can log the event.
// SENSOR_RETRY_INTERVAL_MS hoisted to SECTION 0 at the top of the file.

void retryFailedSensors() {
  uint32_t now = millis();
  if (now - g_health.lastRetryMs < SENSOR_RETRY_INTERVAL_MS) return;
  // WF2 06-10: NEVER re-init mid-motion. A failed begin() blocks ~450 ms
  // (3 attempts × 150 ms of delays), which used to stall the control loop in
  // the middle of a MOVE_TILE every 5 s whenever a sensor was down. Retries
  // now wait for idle (the mapper stops between tiles, so recovery is at most
  // one move away).
  if (motionIsBusy()) return;
  g_health.lastRetryMs = now;

  bool was[6] = { frontOK, leftOK, rightOK, backOK, bnoOK, colorOK };

  if (!frontOK) { frontOK = initSensor(loxFront, CH_FRONT, "Front (retry)"); if (frontOK) tofStartContinuous(loxFront, CH_FRONT); }
  if (!leftOK)  { leftOK  = initSensor(loxLeft,  CH_LEFT,  "Left  (retry)"); if (leftOK)  tofStartContinuous(loxLeft,  CH_LEFT); }
  if (!rightOK) { rightOK = initSensor(loxRight, CH_RIGHT, "Right (retry)"); if (rightOK) tofStartContinuous(loxRight, CH_RIGHT); }
  if (!backOK)  { backOK  = initSensor(loxBack,  CH_BACK,  "Back  (retry)"); if (backOK)  tofStartContinuous(loxBack,  CH_BACK); }
  if (!okWFL)   { okWFL   = initSensor(loxWFL,   CH_WF_LEFT,  "WF-L  (retry)"); if (okWFL) tofStartContinuous(loxWFL, CH_WF_LEFT); }   // WF2 (VL53L0X)
  if (!okWFR)   { okWFR   = initSensor(loxWFR,   CH_WF_RIGHT, "WF-R  (retry)"); if (okWFR) tofStartContinuous(loxWFR, CH_WF_RIGHT); }  // WF2 (VL53L0X)
  if (!bnoOK)   bnoOK   = initBNO055();
  if (!colorOK) colorOK = initAS7341();

  bool now_ok[6] = { frontOK, leftOK, rightOK, backOK, bnoOK, colorOK };
  const char* names[6] = { "Front", "Left", "Right", "Back", "IMU", "Color" };
  for (int i = 0; i < 6; i++) {
    if (!was[i] && now_ok[i]) {
      Serial1.print("RECOVERED "); Serial1.println(names[i]);
      Serial.print("[health] recovered "); Serial.println(names[i]);
      g_health.recoveredCount++;
    }
  }
}

// =============================================================================
// === SECTION 6: COLOUR CLASSIFICATION + CALIBRATION ==========================
// =============================================================================

static char classifyByCalibration(uint32_t s, uint32_t b, uint32_t r) {
  const char chars[5]    = { 'K', 'N', 'S', 'B', 'R' };
  const ColorRef *refs[5] = { &cal.black, &cal.white, &cal.silver,
                              &cal.blueRef, &cal.redRef };
  uint64_t best = (uint64_t)-1;
  char bestCh = 'N';
  for (int i = 0; i < 5; i++) {
    int64_t ds = (int64_t)s - (int64_t)refs[i]->sum;
    int64_t db = (int64_t)b - (int64_t)refs[i]->blue;
    int64_t dr = (int64_t)r - (int64_t)refs[i]->red;
    uint64_t dist = (uint64_t)(ds*ds) + (uint64_t)(db*db) + (uint64_t)(dr*dr);
    if (dist < best) { best = dist; bestCh = chars[i]; }
  }
  return bestCh;
}

// Shared classification math (blocking + async paths both use this).
static char classifyRawColor(const uint16_t *raw_out, uint32_t *sum_out) {
  uint32_t sum = (uint32_t)raw_out[0] + raw_out[1] + raw_out[2] + raw_out[3] +
                 (uint32_t)raw_out[6] + raw_out[7] + raw_out[8] + raw_out[9];
  if (sum_out) *sum_out = sum;
  uint32_t blueBand = (uint32_t)raw_out[1] + raw_out[2];
  uint32_t redBand  = (uint32_t)raw_out[8] + raw_out[9];
  if (calLoaded) return classifyByCalibration(sum, blueBand, redBand);
  if (sum < COLOR_BLACK_MAX)  return 'K';
  if (sum > COLOR_SILVER_MIN) return 'S';
  if (blueBand > (uint32_t)(redBand * COLOR_BLUE_RATIO))  return 'B';
  if (redBand  > (uint32_t)(blueBand * COLOR_RED_RATIO))  return 'R';
  return 'N';
}

char readColor(uint16_t *raw_out) {
  tcaSelect(CH_COLOR);
  if (!color.readAllChannels(raw_out)) return 'X';
  return classifyRawColor(raw_out, nullptr);
}

// WF2 06-10: NON-BLOCKING AS7341 read. readAllChannels() blocks ~110 ms (two
// SMUX integration cycles) — it was THE loop bottleneck whenever colour was
// needed (idle + most of every MOVE_TILE). This drives the library's async
// start/check/get API instead: kick off a reading, poll it each loop, classify
// when done. Same ~110 ms data-refresh rate (black-abort latency unchanged),
// but the loop never blocks. `wantColor` gates STARTING a new reading (same
// motionNeedsColor() policy as before); an in-flight reading is always polled
// to completion so the state machine can't strand.
static bool     g_colorReadActive = false;
static char     g_colorChAsync    = '-';
static uint32_t g_colorSumAsync   = 0;

static void colorTickAsync(bool wantColor) {
  if (!colorOK) return;
  tcaSelect(CH_COLOR);
  if (!g_colorReadActive) {
    if (wantColor) {
      color.startReading();
      g_colorReadActive = true;
    }
    return;
  }
  if (color.checkReadingProgress()) {
    uint16_t raw[12] = {0};
    if (color.getAllChannels(raw)) {
      g_colorChAsync = classifyRawColor(raw, &g_colorSumAsync);
    } else {
      g_colorChAsync = 'X';
    }
    g_colorReadActive = false;   // next loop starts a fresh reading if wanted
  }
}

bool loadCalibration() {
  EEPROM.begin(sizeof(CalibrationData) + 16);
  EEPROM.get(0, cal);
  if (cal.magic != CAL_MAGIC || cal.version != CAL_VERSION) {
    Serial.println("Calibration: NONE saved (run Color_Calibrate.ino)");
    return false;
  }
  Serial.println("Calibration: loaded from flash-EEPROM");
  return true;
}

// =============================================================================
// === SECTION 7: MOTOR DRIVE LAYER ============================================
// =============================================================================

void motorsInit() {
  for (int i = 0; i < 4; i++) {
    pinMode(motorPinsA[i], OUTPUT);
    pinMode(motorPinsB[i], OUTPUT);
    analogWrite(motorPinsA[i], 0);
    analogWrite(motorPinsB[i], 0);
  }
}

void driveMotor(int idx, bool forward, int speed) {
  if (idx < 0 || idx > 3) return;
  if (speed < 0) speed = 0;
  if (speed > MOTOR_MAX_PWM) speed = MOTOR_MAX_PWM;
  bool dir = MOTOR_INVERT[idx] ? !forward : forward;
  if (dir) { analogWrite(motorPinsA[idx], speed); analogWrite(motorPinsB[idx], 0); }
  else     { analogWrite(motorPinsA[idx], 0);     analogWrite(motorPinsB[idx], speed); }
}

void motorsAllStop() {
  for (int i = 0; i < 4; i++) {
    analogWrite(motorPinsA[i], 0);
    analogWrite(motorPinsB[i], 0);
  }
}

void moveForward(int s)  { for (int k = 0; k < 4; k++) driveMotor(k, true,  s); }
void moveBackward(int s) { for (int k = 0; k < 4; k++) driveMotor(k, false, s); }

// Turn-in-place: right wheels go one way, left wheels the other.
void turnLeftInPlace(int s) {
  driveMotor(0, true,  s); driveMotor(1, true,  s);   // FR, BR fwd
  driveMotor(2, false, s); driveMotor(3, false, s);   // FL, BL bwd
}
void turnRightInPlace(int s) {
  driveMotor(0, false, s); driveMotor(1, false, s);
  driveMotor(2, true,  s); driveMotor(3, true,  s);
}

// Signed per-side speeds for in-motion wall-following corrections.
void driveTank(int leftSigned, int rightSigned) {
  bool leftFwd  = leftSigned  >= 0;
  bool rightFwd = rightSigned >= 0;
  int  leftAbs  = leftSigned  >= 0 ? leftSigned  : -leftSigned;
  int  rightAbs = rightSigned >= 0 ? rightSigned : -rightSigned;
  driveMotor(0, rightFwd, rightAbs);
  driveMotor(1, rightFwd, rightAbs);
  driveMotor(2, leftFwd,  leftAbs);
  driveMotor(3, leftFwd,  leftAbs);
}

// =============================================================================
// === SECTION 8: NEOPIXEL STATE MACHINE =======================================
// =============================================================================
// pixel 0 = SCORE (referee-facing regulation blink ONLY)
// pixel 1 = TEAM  (team-facing color cue: blue tile, victim color, etc.)

static inline uint32_t rgb(uint8_t r, uint8_t g, uint8_t b) {
  return ((uint32_t)r << 16) | ((uint32_t)g << 8) | b;
}

enum ScoreMode : uint8_t { SCORE_OFF = 0, SCORE_VICTIM, SCORE_EXIT };
struct ScoreCtx { ScoreMode mode; uint32_t startMs, halfPeriodMs; uint8_t cyclesTotal; };
static ScoreCtx score = { SCORE_OFF, 0, 500, 5 };

enum TeamMode  : uint8_t { TEAM_OFF = 0, TEAM_SOLID, TEAM_ALARM, TEAM_FLASH };  // WF3: FLASH = one-shot
struct TeamCtx  { TeamMode mode; uint32_t color; uint32_t startMs; };
static TeamCtx team = { TEAM_OFF, 0, 0 };
static uint32_t g_teamFlashMs = 600;   // WF3: duration of a LED_FLASH one-shot

static uint32_t lastScoreColor = 0x80000000ul;
static uint32_t lastTeamColor  = 0x80000000ul;

void ledsInit() {
  strip.begin(); strip.clear(); strip.show();
  lastScoreColor = 0; lastTeamColor = 0;
  Serial.println("[leds] NeoPixels ready (2 px on GP23)");
}

static uint32_t computeScoreColor(uint32_t now) {
  if (score.mode == SCORE_OFF) return 0;
  uint32_t elapsed = now - score.startMs;
  uint32_t full = score.halfPeriodMs * 2;
  uint32_t total = full * score.cyclesTotal;
  if (elapsed >= total) { score.mode = SCORE_OFF; return 0; }
  return (elapsed % full < score.halfPeriodMs) ? rgb(255, 255, 255) : 0;
}

static uint32_t computeTeamColor(uint32_t now) {
  switch (team.mode) {
    case TEAM_OFF:   return 0;
    case TEAM_SOLID: return team.color;
    case TEAM_ALARM: {
      uint32_t phase = ((now - team.startMs) / 500) & 1;
      return phase == 0 ? rgb(255, 0, 0) : rgb(255, 200, 0);
    }
    case TEAM_FLASH:   // WF3: solid for g_teamFlashMs, then auto-off
      if (now - team.startMs >= g_teamFlashMs) { team.mode = TEAM_OFF; return 0; }
      return team.color;
  }
  return 0;
}

void ledsTick() {
  uint32_t now = millis();
  uint32_t s = computeScoreColor(now);
  uint32_t t = computeTeamColor(now);
  if (s != lastScoreColor || t != lastTeamColor) {
    strip.setPixelColor(0, s);
    strip.setPixelColor(1, t);
    strip.show();
    lastScoreColor = s;
    lastTeamColor  = t;
  }
}

void ledVictim(char type) {
  score.mode = SCORE_VICTIM; score.startMs = millis();
  score.halfPeriodMs = 500;  score.cyclesTotal = 5;
  team.mode = TEAM_SOLID; team.startMs = millis();
  switch (type) {
    case 'R': case 'r': team.color = rgb(255, 0,   0);   break;
    case 'Y': case 'y': team.color = rgb(255, 200, 0);   break;
    case 'G': case 'g': team.color = rgb(0,   255, 0);   break;
    default:            team.color = rgb(40,  40,  40);  break;
  }
}

void ledExitStart() {
  score.mode = SCORE_EXIT; score.startMs = millis();
  score.halfPeriodMs = 1000; score.cyclesTotal = 5;
  team.mode = TEAM_SOLID; team.startMs = millis(); team.color = rgb(255, 255, 255);
}

void ledTeam(const char* c) {
  team.startMs = millis();
  if      (!strncmp(c, "blue",   4)) { team.mode = TEAM_SOLID; team.color = rgb(0,   0,   255); }
  else if (!strncmp(c, "red",    3)) { team.mode = TEAM_SOLID; team.color = rgb(255, 0,   0); }
  else if (!strncmp(c, "yellow", 6)) { team.mode = TEAM_SOLID; team.color = rgb(255, 200, 0); }
  else if (!strncmp(c, "green",  5)) { team.mode = TEAM_SOLID; team.color = rgb(0,   255, 0); }
  else if (!strncmp(c, "white",  5)) { team.mode = TEAM_SOLID; team.color = rgb(255, 255, 255); }
  else if (!strncmp(c, "alarm",  5)) { team.mode = TEAM_ALARM; team.color = 0; }
  else if (!strncmp(c, "off",    3)) { team.mode = TEAM_OFF;   team.color = 0; }
}

// WF3: one-shot flash — solid `c` for `ms`, then auto-off (checkpoint cue etc).
void ledFlash(const char* c, uint32_t ms) {
  ledTeam(c);                      // parses the colour name into team.color
  team.mode    = TEAM_FLASH;
  team.startMs = millis();
  g_teamFlashMs = (ms > 0) ? ms : 600;
}

// =============================================================================
// === SECTION 9: MOTION STATE MACHINE =========================================
// =============================================================================
// Closed-loop primitives, advanced by motionTick() each main-loop iteration.

enum MotionState : uint8_t {
  MS_IDLE = 0,
  MS_TURN_90,
  MS_MOVE_TILE,
  MS_RAM_WALL,
  MS_CENTER_TILE,
  MS_WAIT_BLUE,
  MS_RECOVER_BLACK,
};

// MOVE_TILE has internal sub-states for the wall-loss recovery sequence
// (user spec: "from 2/1 walls to 0 walls, back up to the previous tile,
// ram, re-center, THEN proceed").
enum MoveSubState : uint8_t {
  MOVE_SUB_DRIVING = 0,         // normal forward driving
  MOVE_SUB_REC_REVERSE,         // reversing to find walls again
  MOVE_SUB_REC_RAM,             // ram backward into the recovered wall
  MOVE_SUB_REC_CENTER,          // longitudinal recenter against the wall
  MOVE_SUB_REC_SNAP,            // WF2: snap yaw to cardinal after the ram, before resuming forward
  MOVE_SUB_FRONT_ALIGN,         // WF2 06-07: after the move, settle front-ToF to FRONT_ALIGN_TARGET_MM
  MOVE_SUB_WALLDROP_SNAP,       // WF2 06-08: 2-wall->1-wall transition — stop, square heading to expected cardinal
  MOVE_SUB_TILE_SETTLE,         // WF2 06-08: open-tile dead-reckon — nudge to within TILE_SETTLE_TOL_MM of target travel
  MOVE_SUB_EDGE_SNAP,           // WF2 edge detect: square heading to cardinal when edge detected
  MOVE_SUB_EDGE_REVERSE,        // WF2 edge detect: reverse until the wall is detected again
  MOVE_SUB_EDGE_FWD,            // WF2 edge detect: drive forward exact distance to center
  MOVE_SUB_RAMP_CLIMB,          // WF3: ride the ramp until the floor is flat again
  MOVE_SUB_RAMP_EDGE,           // WF3 (up only): reverse until pitch returns = crest edge found
  MOVE_SUB_RAMP_ADV             // WF3: advance from the found edge to the next tile centre
};

struct MotionCtx {
  MotionState state;
  uint32_t    startMs;
  char        ackName[16];
  // turn-90
  float       startYaw;
  int8_t      turnDir;
  uint32_t    turnTimeoutMs;
  // move-tile
  int         startFront, startBack;
  bool        useFrontTarget;
  bool        gyroOnly;           // this move drives on gyro/yaw-hold only, NO wall-follow (set via WF_OFF_NEXT)
  int         targetFront;        // front-distance to stop at (one tile worth of travel, clamped to MOVE_FRONT_STOP_MM)
  int         targetTravel;       // WF2 06-08: back-delta travel target this move (= g_tileLenMm - posErr)
  uint32_t    moveTimeoutMs;
  int         smoothedBias;       // exponentially-smoothed wheel speed differential (anti-lurch on wall transitions)
  float       wfPrevError;        // WF2 06-09: previous wall-follow error (for the PD derivative term)
  bool        prevHadWalls;       // tracks wall-presence transitions for yaw re-anchor
  uint32_t    sideWallSinceMs;    // WF2: when the current contiguous side-wall presence began (0 = none)
  bool        wallEstablished;    // WF2: side wall has persisted >= WALL_ESTABLISH_MS (real wall, not a trailing edge)
  // Recovery sub-state machine
  MoveSubState moveSubState;
  bool         recoveryDone;
  uint32_t     subStartMs;
  // Edge detection tracking
  bool         edgeDetectArmed;
  int8_t       edgeSide;          // 1=left, 2=right
  uint8_t      wfMode;            // WF2: last wall-follow mode (0 none,1 left,2 right,3 both) — for case= telem
  // WF2 ram wiggle/shimmy (shared by RAM_WALL + recovery ram)
  bool         wiggling;
  uint8_t      wiggleStep;
  uint32_t     wiggleStartMs;
  // Stuck detection
  int          stuckRefBack;      // back reading at last "stuck check" point
  int          stuckRefFront;     // WF2 06-08: front reading at last "stuck check" — progress = back grew OR front shrank
  uint32_t     stuckLastChangeMs;
  // Obstacle detection (pitch/roll deviation from start = bot on something)
  float        startPitch;
  float        startRoll;
  bool         onObstacle;
  // Ramp detection (sustained pitch; emits one RAMP UP/DOWN per MOVE_TILE)
  uint32_t     rampStartMs;
  bool         rampNotified;
  int8_t       rampDir;           // WF3: +1 climbing up, -1 going down, 0 none
  uint32_t     rampFlatSinceMs;   // WF3: when the floor went flat during a ramp ride
  bool         chain;             // WF3: "MOVE_TILE C" — ACK while rolling, no stop/settle
  // 06-10/11: blind odometry fallback (no valid F/B travel reference)
  bool         odomBlind;        // driving on the time estimate
  uint32_t     blindStartMs;     // time-fallback reference (rebased by edge events)
  bool         prevSideL, prevSideR;       // last debounced side-wall presence (edge watch)
  uint32_t     sideLSinceMs, sideRSinceMs; // when that presence state began
  int          frontAlignStartF;  // front-ToF when FRONT_ALIGN began (forward-cap reference)
  // WF2 06-07: continuous corridor drive (multi-tile) odometry + tile counting.
  long         odoTraveled;   // mm travelled this command (back->front ToF handoff)
  long         odoBase;       // mm accumulated from prior odo segments (frozen at handoff)
  uint8_t      odoMode;       // 0 = none/acquire, 1 = back-ref, 2 = front-ref
  int          odoRef;        // ToF reading captured at the current segment start
  int          tilesEmitted;  // tile centres crossed (TILE events sent) this command
  // ram
  uint8_t     ramSide;
  int         lastRamDist;
  uint32_t    ramLastChangeMs;
  uint32_t    ramTimeoutMs;
  // center
  uint8_t     centerPhase;
  uint8_t     centerRetries;   // WF2: post-center verify retry counter
  int         centerLatOffset; // WF2: signed mm = desired (f-b) setpoint delta (+ => end nearer the BACK wall). Pre-compensates the upcoming turn-back drift on the FULL_CENTER lateral pass. 0 = plain center.
  // wait
  uint32_t    waitUntilMs;
  // yaw target for TURN_90 / YAW_SQUARE; snapInTolSince = confirm-hold timer (tickTurn90)
  float       snapTarget;
  uint32_t    snapInTolSince;
};
static MotionCtx motion = { MS_IDLE };

// --- Tunables hoisted to SECTION 0 at the top of the file --- edit there.
//   SPEED_V_MIN / SPEED_V_MAX / SPEED_D_BRAKE_MM / SPEED_RAMP_MM
//   MOVE_MIN_SPEED / MOVE_MAX_SPEED / MOVE_RAMP_MM   (measurement-seeking ramp)
//   TURN_SPEED / TURN_MIN_SPEED / TURN_TOL_DEG / TURN_CONFIRM_MS
//   SNAP_TOL_DEG / SNAP_SPEED / SNAP_SPEED_START / SNAP_TIMEOUT_MS  (turnTowardYaw)
//   RAM_SPEED / RAM_STALL_MS / RAM_STALL_DELTA / RAM_TIMEOUT_MS
//   CENTER_TARGET_F / CENTER_TARGET_B / CENTER_TARGET_LR / CENTER_TOL_MM
//   MOVE_TILE_TIMEOUT_MS / MOVE_FRONT_STOP_MM
//   US_WF_KP_* / US_WF_BIAS_MAX / WALL_FOLLOW_EMA_*
//   OBSTACLE_TILT_DEG / BLACK_RECOVER_MS / STUCK_*

// --- helpers ---
static float angleDiff(float a, float b) {
  float d = a - b;
  while (d >  180) d -= 360;
  while (d < -180) d += 360;
  return d;
}

// WF2 06-08: the firmware does ALL turn math directly in the RAW BNO frame
// (g_sensors.yaw_deg = orientation.x). EMPIRICAL (live log 11:01 PM): a commanded
// turnRightInPlace INCREASES raw yaw. With target = base + turnDir*90 and the
// direction rule "err>0 -> turnLeft / err<0 -> turnRight" (err = angleDiff(raw,
// target)), turns CONVERGE and TURN_R is a physical right turn. A bot-frame
// (360-raw) experiment INVERTED the snap direction (it turned the wrong way and
// "aligned the wrong yaw") — reverted. The Pi separately remaps raw->bot_yaw for
// the dashboard; the firmware never needs that.

// WF2: ASYMMETRIC boolean debounce. `stable` adopts a new `raw` after it has
// held continuously for onMs (when going true) or offMs (when going false).
// Lets a wall take its time to assert (anti-fluke) but drop quickly when it
// ends. Non-blocking (pure timestamp math). Returns the debounced value.
static bool debounceBool(DebounceBool& d, bool raw, uint32_t now,
                         uint32_t onMs, uint32_t offMs) {
  if (raw != d.lastRaw) { d.lastRaw = raw; d.sinceMs = now; }   // edge -> restart timer
  uint32_t need = raw ? onMs : offMs;                           // assert vs release
  if (now - d.sinceMs >= need) d.stable = raw;                  // held long enough -> commit
  return d.stable;
}

// WF2: nearest 90° cardinal to `yaw`, derived from the placement reference
// g_yawRef0 (so the grid frame can't drift). Same math the post-turn snap uses.
static float nearestCardinalYaw(float yaw) {
  while (yaw < 0)     yaw += 360;
  while (yaw >= 360)  yaw -= 360;
  float best = g_yawRef0, bestDist = 999;
  for (int i = 0; i < 4; i++) {
    float c = fmodf(g_yawRef0 + i * 90.0f, 360.0f);
    float d = fabs(angleDiff(yaw, c));
    if (d < bestDist) { bestDist = d; best = c; }
  }
  return best;
}

// WF2: nearest grid cardinal to `yaw`. Uses the g_yawRef0 frame once captured;
// before any capture, falls back to the absolute nearest-90 so early turns still
// have a sane target (should be rare — turns are gated on imu_trusted).
static float gridCardinalYaw(float yaw) {
  if (g_yawRefCaptured) return nearestCardinalYaw(yaw);
  while (yaw < 0)    yaw += 360.0f;
  while (yaw >= 360) yaw -= 360.0f;
  float c = roundf(yaw / 90.0f) * 90.0f;
  while (c >= 360.0f) c -= 360.0f;
  while (c < 0.0f)    c += 360.0f;
  return c;
}

// WF2 06-08: reconcile the two yaw samples (RAW frame) that should both lie on
// the same 90° grid. resid = how far they are from a clean N*90 relationship.
// Big resid => one was corrupted (e.g. brownout offset ~45°) => trust the LATER
// sample (b). Small resid => consistent => average them on the grid for accuracy.
static void reconcileYawRef(float a, float b) {
  float d = angleDiff(a, b);                  // signed a-b in (-180,180]
  float resid = fabsf(d);
  while (resid >= 90.0f) resid -= 90.0f;      // fold into [0,90)
  if (resid > 45.0f) resid = 90.0f - resid;   // distance to the nearest multiple of 90
  if (resid > YAWREF_GRID_DISAGREE_DEG) {
    g_yawRef0 = b;                            // disagree -> trust the later reading
    Serial1.print("DIAG YAWREF2 disagree resid="); Serial1.print(resid, 1);
    Serial1.print(" a="); Serial1.print(a, 1);
    Serial1.print(" b="); Serial1.print(b, 1);
    Serial1.println(" -> trust_later(b)");
  } else {
    float k        = roundf(d / 90.0f);        // # of 90° steps between a and b
    float aAligned = a - k * 90.0f;            // map a onto b's branch
    g_yawRef0 = b + angleDiff(aAligned, b) * 0.5f;  // circular mean of the two close angles
    Serial1.print("DIAG YAWREF2 agree resid="); Serial1.print(resid, 1);
    Serial1.print(" a="); Serial1.print(a, 1);
    Serial1.print(" b="); Serial1.print(b, 1);
    Serial1.print(" -> avg="); Serial1.println(g_yawRef0, 1);
  }
  while (g_yawRef0 < 0.0f)    g_yawRef0 += 360.0f;
  while (g_yawRef0 >= 360.0f) g_yawRef0 -= 360.0f;
  g_yawRefCaptured  = true;
  g_yawRefReconciled = true;
}

// WF2 06-08: sample A of the two-sample reference — the RAW frame heading right
// after the FIRST ram squares the bot flush against a wall. Reads the IMU fresh
// (the ram loop doesn't). One-shot; ignored once reconciled.
static void captureYawSampleA() {
  if (g_yawSampleAValid || g_yawRefReconciled) return;
  if (bnoOK) {
    tcaSelect(CH_IMU);
    sensors_event_t orient;
    bno.getEvent(&orient);
    g_sensors.yaw_deg = orient.orientation.x;
  }
  g_yawSampleA = g_sensors.yaw_deg;
  g_yawSampleAValid = true;
  Serial1.print("DIAG YAWREF2 sampleA(after ram, bot)="); Serial1.println(g_yawSampleA, 1);
}

// WF2 06-08 (user): linear ramp for measurement-seeking moves (CENTER / FRONT_ALIGN
// / TILE_SETTLE / recovery-centre). absErrMm = |current - target|.
static int seekSpeed(int absErrMm) {
  if (absErrMm < 0) absErrMm = 0;
  if (absErrMm >= MOVE_RAMP_MM) return MOVE_MAX_SPEED;
  return MOVE_MIN_SPEED + (int)((long)(MOVE_MAX_SPEED - MOVE_MIN_SPEED) * absErrMm / MOVE_RAMP_MM);
}

// WF2 06-08: LINEAR speed ramp (like the turn ramp) — slows down near the end.
static int driveSpeed(int dist_mm) {
  if (dist_mm <= SPEED_D_BRAKE_MM) return SPEED_V_MIN;
  float over = (float)(dist_mm - SPEED_D_BRAKE_MM);
  float frac = over / (float)SPEED_RAMP_MM;
  if (frac > 1.0f) frac = 1.0f;
  if (frac < 0.0f) frac = 0.0f;
  int v = SPEED_V_MIN + (int)((SPEED_V_MAX - SPEED_V_MIN) * frac);
  return v;
}

// --- WF2 helpers -------------------------------------------------------------

// WF3: port of the Pi dashboard trig (_estimate_one in serial_relay.py).
// Cos-project a slant ToF reading to horizontal and REJECT it (-1 = "open")
// when the tilted beam would leave the wall band (clear the wall top or dip
// into the floor). Sign-agnostic band check: the firmware tilt isn't mount-
// remapped like the Pi's, so we gate on |height change| against both bounds —
// slightly conservative, never wrong. Below the threshold tilt, raw is
// returned unchanged (cos ≈ 1).
static int tiltCorrectSide(int raw_mm, float tiltDeg, int sensorH) {
  if (raw_mm <= 0) return raw_mm;
  float a = fabs(tiltDeg);
  if (a < TILT_CORRECT_MIN_DEG) return raw_mm;
  if (a > 60.0f) return -1;                       // absurd tilt — no usable wall read
  float tr = a * 3.14159265f / 180.0f;
  float horiz = raw_mm * cosf(tr);
  float dh = horiz * tanf(tr);                    // |beam height change| at the wall
  if (sensorH + dh > WALL_H_MM || sensorH - dh < 0) return -1;   // beam may miss the wall band
  return (int)horiz;
}

// WF3: chained-move coast — after a "MOVE_TILE C" ACKs, motors keep slow-
// rolling until this deadline so the NEXT MOVE_TILE takes over seamlessly.
// loop() stops the motors if the deadline passes while motion is still idle.
static uint32_t g_coastUntilMs = 0;

// In-place ramped turn toward an absolute yaw target. Returns true once settled
// within SNAP_TOL_DEG (motors stopped). Used by the recovery-snap + wall-drop
// snap; callers read the IMU fresh each tick so g_sensors.yaw_deg is current.
static bool turnTowardYaw(float target, int speed) {
  float err = angleDiff(g_sensors.yaw_deg, target);
  if (fabs(err) < SNAP_TOL_DEG) { motorsAllStop(); return true; }
  // WF2 06-08: RAMP the speed by |err| (cap at the caller's `speed`, floor at
  // TURN_MIN_SPEED) so it crawls into the target instead of hunting/overshooting.
  int spd = TURN_MIN_SPEED + (int)((float)(speed - TURN_MIN_SPEED) * (fabs(err) / 45.0f));
  if (spd > speed)          spd = speed;
  if (spd < TURN_MIN_SPEED) spd = TURN_MIN_SPEED;
  // err > 0 = bot is CW of target -> turn CCW (left). (06-08 sign flip reverted.)
  if (err > 0) turnLeftInPlace(spd);
  else         turnRightInPlace(spd);
  return false;
}

// Ram shimmy: spin one side's wheels backward at a time (L,R,L,R), WIGGLE_STEP_MS
// each, to square the bot against the wall it just rammed. Caller arms it by
// setting wiggling=true, wiggleStep=0, wiggleStartMs=0. Returns true when done.
static bool runWiggle() {
  if (!WIGGLE_ENABLED || WIGGLE_STEPS <= 0) { motorsAllStop(); return true; }
  uint32_t now = millis();
  if (motion.wiggleStartMs == 0) motion.wiggleStartMs = now;
  if (now - motion.wiggleStartMs >= WIGGLE_STEP_MS) {
    motion.wiggleStep++;
    motion.wiggleStartMs = now;
  }
  if (motion.wiggleStep >= (uint8_t)WIGGLE_STEPS) { motorsAllStop(); return true; }
  // even step -> LEFT wheels backward (idx 2,3); odd step -> RIGHT wheels (idx 0,1)
  if ((motion.wiggleStep & 1) == 0) {
    driveMotor(0, false, 0);            driveMotor(1, false, 0);
    driveMotor(2, false, WIGGLE_SPEED); driveMotor(3, false, WIGGLE_SPEED);
  } else {
    driveMotor(0, false, WIGGLE_SPEED); driveMotor(1, false, WIGGLE_SPEED);
    driveMotor(2, false, 0);            driveMotor(3, false, 0);
  }
  return false;
}

// WF2: short label for what the motion layer is currently doing (case= telem).
static const char* motionCaseName() {
  switch (motion.state) {
    case MS_IDLE:          return "idle";
    case MS_TURN_90:       return motion.turnDir > 0 ? "turn_R" : "turn_L";
    case MS_RAM_WALL:      return motion.wiggling ? "ram_wiggle"
                                  : (motion.ramSide == 0 ? "ram_F" : "ram_B");
    case MS_CENTER_TILE:   return "center";
    case MS_WAIT_BLUE:     return "wait_blue";
    case MS_RECOVER_BLACK: return "recover_black";
    case MS_MOVE_TILE:
      switch (motion.moveSubState) {
        case MOVE_SUB_DRIVING:
          switch (motion.wfMode) {
            case 1:  return "follow_L";
            case 2:  return "follow_R";
            case 3:  return "center_LR";
            default: return "drive";
          }
        case MOVE_SUB_REC_REVERSE:      return "rec_reverse";
        case MOVE_SUB_REC_RAM:          return motion.wiggling ? "rec_wiggle" : "rec_ram";
        case MOVE_SUB_REC_CENTER:       return "rec_center";
        case MOVE_SUB_REC_SNAP:         return "rec_snap";
        case MOVE_SUB_FRONT_ALIGN:      return "front_align";
        case MOVE_SUB_WALLDROP_SNAP:    return "wd_yaw";
        case MOVE_SUB_TILE_SETTLE:      return "tile_settle";
        case MOVE_SUB_EDGE_SNAP:        return "edge_snap";     // WF2 06-10
        case MOVE_SUB_EDGE_REVERSE:     return "edge_rev";      // WF2 06-10
        case MOVE_SUB_EDGE_FWD:         return "edge_fwd";      // WF2 06-10
        case MOVE_SUB_RAMP_CLIMB:       return "ramp_climb";    // WF3
        case MOVE_SUB_RAMP_EDGE:        return "ramp_edge";     // WF3
        case MOVE_SUB_RAMP_ADV:         return "ramp_adv";      // WF3
      }
      return "move";
  }
  return "?";
}

static void ackOk(const char* n)                { Serial1.print("ACK "); Serial1.print(n); Serial1.println(" ok"); }
static void ackFail(const char* n, const char* r) { Serial1.print("ACK "); Serial1.print(n); Serial1.print(" fail reason="); Serial1.println(r); }

static void motionEnd(bool ok, const char* reason) {
  motorsAllStop();
  if (ok) ackOk(motion.ackName);
  else    ackFail(motion.ackName, reason);
  motion.state = MS_IDLE;
}

bool motionIsBusy() { return motion.state != MS_IDLE; }

// Whether the loop should bother running the AS7341 colour read this iteration.
// Colour is only needed at IDLE (so SENSE sees the tile) and during MOVE_TILE
// (so the black-tile abort can fire). For TURN/RAM/CENTER/WAIT we skip the
// ~110 ms integration to massively bump loop rate -> sharper gyro sampling.
bool motionNeedsColor() {
  if (motion.state == MS_IDLE) return true;
  if (motion.state == MS_RECOVER_BLACK) return true;
  if (motion.state == MS_MOVE_TILE) {
    // Skip the AS7341 read once we've travelled past ~75% of one tile. If we
    // haven't seen black by then, we won't — the colour sensor is centred on
    // the bot's underside and would have already crossed the new tile's
    // colour. Dropping color in the last quarter buys ~110 ms of loop time
    // per iteration -> tighter ToF + IMU feedback for the final approach.
    if (motion.startBack > 0 && g_sensors.back_mm > 0) {
      int traveled = g_sensors.back_mm - motion.startBack;
      if (traveled > (g_tileLenMm * 3) / 4) return false;   // WF2 06-10: was hardcoded 225 (75% of a nominal 300 tile)
    }
    return true;   // back-blind: keep colour on (can't tell where we are)
  }
  return false;
}

// --- TURN 90 ---
void motionStart_Turn90(int dir) {
  // Use the specific name for the early-reject ACKs too. The mapper pairs
  // ACK->pending by exact name match, so emitting "TURN" instead of "TURN_R"
  // here used to make rejection invisible to the Pi.
  const char* name = (dir >= 0) ? "TURN_R" : "TURN_L";
  // Preemption: any incoming motion command halts whatever's running. Gives
  // direct UART commands (from the dashboard or curl) highest priority over
  // mapper-issued motion. motionHalt emits ACK <prev> fail reason=halted.
  if (motion.state != MS_IDLE) motionHalt();
  if (!g_sensors.imu_trusted)  { ackFail(name, "imu_untrusted"); return; }
  motion.state         = MS_TURN_90;
  motion.startMs       = millis();
  motion.startYaw      = g_sensors.yaw_deg;          // RAW frame; kept for the DIAG traveled report
  motion.turnDir       = (dir >= 0) ? +1 : -1;
  motion.turnTimeoutMs = TURN_TIMEOUT_MS;
  // WF2 06-08: ABSOLUTE cardinal targeting. Snap the CURRENT heading to its
  // nearest grid cardinal (removing accumulated drift), then add/subtract 90
  // for the commanded direction. The turn ends at (base + turnDir*90), NOT at
  // (current + 90) — so if the bot entered the turn a few degrees off-axis, the
  // turn lands it back on a true grid cardinal instead of carrying the error
  // forward. turnRight raises yaw (+), turnLeft lowers it (-); base+turnDir*90
  // is therefore reached by turning in the commanded physical direction.
  float base   = gridCardinalYaw(g_sensors.yaw_deg);
  float target = base + motion.turnDir * 90.0f;
  while (target >= 360.0f) target -= 360.0f;
  while (target < 0.0f)    target += 360.0f;
  motion.snapTarget    = target;              // absolute heading the turn drives to
  motion.snapInTolSince = 0;                   // fresh confirm window
  strncpy(motion.ackName, name, sizeof(motion.ackName));
}

// WF2 06-08 (user): YAW_SQUARE — "check yaw, and if it's off, re-square to the
// grid cardinal." Used by the mapper every 3 tiles. No-op ACK if already within
// YAW_SQUARE_TOL_DEG; otherwise reuses the SAME clean ramp+confirm turn (MS_TURN_90)
// to the nearest cardinal — no oscillating snap. Pure in-place rotation.
void motionStart_YawSquare() {
  if (motion.state != MS_IDLE) motionHalt();
  if (!g_sensors.imu_trusted) { ackFail("YAW_SQUARE", "imu_untrusted"); return; }
  if (bnoOK) {
    tcaSelect(CH_IMU);
    sensors_event_t o; bno.getEvent(&o);
    g_sensors.yaw_deg = o.orientation.x;
  }
  float target = gridCardinalYaw(g_sensors.yaw_deg);
  float dev    = fabs(angleDiff(g_sensors.yaw_deg, target));
  if (dev <= YAW_SQUARE_TOL_DEG) {
    Serial1.print("DIAG YAW_SQUARE ok (already square) dev="); Serial1.println(dev, 1);
    ackOk("YAW_SQUARE");
    return;
  }
  Serial1.print("DIAG YAW_SQUARE snapping dev="); Serial1.print(dev, 1);
  Serial1.print(" -> target="); Serial1.println(target, 1);
  motion.state          = MS_TURN_90;          // reuse the ramp+confirm turn
  motion.startMs        = millis();
  motion.startYaw       = g_sensors.yaw_deg;
  motion.turnDir        = (angleDiff(g_sensors.yaw_deg, target) > 0) ? -1 : +1;  // for DIAG only; tickTurn90 steers by err
  motion.snapTarget     = target;
  motion.snapInTolSince = 0;
  strncpy(motion.ackName, "YAW_SQUARE", sizeof(motion.ackName));
}

static void tickTurn90() {
  if (bnoOK) {
    tcaSelect(CH_IMU);
    sensors_event_t orient;
    bno.getEvent(&orient);
    g_sensors.yaw_deg = orient.orientation.x;
  }
  // No turn timeout — bot may be turning slowly on an obstacle. Let it
  // finish whenever it physically reaches the target. HALT manually if stuck.
  // WF2 06-08: drive toward the ABSOLUTE target heading (motion.snapTarget,
  // = base + turnDir*90). err = yaw - target: >0 means we're CW of target, so
  // turn left (CCW) to reduce it; <0 means turn right (CW). Both shrink |err|.
  // Direction is derived from err (shortest path), so it can't "turn the wrong
  // way" — and on overshoot it self-corrects rather than running off.
  float err    = angleDiff(g_sensors.yaw_deg, motion.snapTarget);
  float remain = fabs(err);
  // Within tolerance: stop and HOLD. Only declare done after TURN_CONFIRM_MS of
  // staying in tol (so a fast flyby / momentary overshoot doesn't latch). If it
  // drifts back out during the hold, resume correcting. No separate snap phase —
  // this single ramp+confirm IS the accurate stop (kills the post-turn wiggle).
  if (remain < TURN_TOL_DEG) {
    motorsAllStop();
    if (motion.snapInTolSince == 0) motion.snapInTolSince = millis();
    if (millis() - motion.snapInTolSince >= TURN_CONFIRM_MS) {
      Serial1.print("DIAG TURN_DONE traveled=");
      Serial1.print(fabs(angleDiff(g_sensors.yaw_deg, motion.startYaw)), 1);
      Serial1.print(" target="); Serial1.print(motion.snapTarget, 1);
      Serial1.print(" err=");    Serial1.println(err, 1);
      motionEnd(true, "");
    }
    return;
  }
  motion.snapInTolSince = 0;   // out of tol — keep correcting
  // Linear ramp by remaining angle: TURN_SPEED far out, TURN_MIN_SPEED near 0,
  // so it crawls into the target instead of overshooting. err>0 -> turn left
  // (lowers raw yaw toward target); err<0 -> turn right. Direction from err =
  // shortest path, so it can't run the wrong way.
  float frac = remain / 90.0f;
  if (frac > 1.0f) frac = 1.0f;
  if (frac < 0.0f) frac = 0.0f;
  int spd = TURN_MIN_SPEED + (int)((TURN_SPEED - TURN_MIN_SPEED) * frac);
  if (err > 0) turnLeftInPlace(spd); else turnRightInPlace(spd);
}

// --- MOVE ONE TILE ---
//
// Goal: move forward by exactly one tile (300 mm) when the geometry allows,
// or stop at the wall when there's less than a tile of clearance ahead.
//
// Strategy:
//   1. Record startFront. Compute targetFront = startFront - 300 mm, clamped
//      to a minimum of MOVE_FRONT_STOP_MM so we never crash a wall.
//      => "Move one tile, or until ~2 cm before contact, whichever comes
//         first." Sensor reads ~78 mm when bot is centred against a wall.
//   2. If startFront is -1 (dead zone OR saturated > 2 m), target falls to
//      MOVE_FRONT_STOP_MM so we still stop if a wall comes into range
//      mid-move. Back-delta + short time-fallback handle the dead-reckon
//      cases (see tickMoveTile).
//   3. Speed shape uses driveSpeed(refDist) [linear ramp] - the closer the target, the
//      slower the drive. Blind starts cap at SPEED_V_MIN + 20.
void motionStart_MoveTile(bool chain) {
  if (motion.state != MS_IDLE) motionHalt();   // preempt any in-flight motion
  g_coastUntilMs = 0;   // WF3: this move owns the motors now (seamless chain handoff)
  // No-clearance guard: if the front is already near the stop-point, MOVE_TILE
  // would "succeed" after a few cm of travel, corrupting the mapper's pose by a
  // whole phantom tile. Fail explicitly so the mapper records a wall here.
  // WF2 06-10: threshold 80 -> 150. Geometry: a centred bot reads ~76 mm when
  // its OWN front boundary is walled and ~376 mm when the NEXT one is; even
  // with the ±80 mm carried-error clamp those bands never overlap 150. Any
  // front reading at/below 150 therefore means "forward is blocked" — the old
  // 80 threshold accepted e.g. a 110 mm read (post-FRONT_ALIGN is 93!) and
  // counted a ~30 mm creep as a full tile.
  if (g_sensors.front_mm > 0 && g_sensors.front_mm <= 150) {
    ackFail("MOVE_TILE", "no_clearance");
    return;
  }
  motion.state          = MS_MOVE_TILE;
  motion.startMs        = millis();
  motion.startFront     = g_sensors.front_mm;
  motion.startBack      = g_sensors.back_mm;
  // WF2 06-08 TWO-SAMPLE YAW REFERENCE: this is the FIRST move of the run — take
  // sample B now (RAW frame) and reconcile it with sample A (captured after the
  // first ram) to lock g_yawRef0. Done once. If no ram happened first, sample A
  // is invalid and we just adopt B.
  if (!g_yawRefReconciled && g_sensors.imu_trusted) {
    float b = g_sensors.yaw_deg;
    if (g_yawSampleAValid) {
      reconcileYawRef(g_yawSampleA, b);
    } else {
      g_yawRef0 = b; g_yawRefCaptured = true; g_yawRefReconciled = true;
      Serial1.print("DIAG YAWREF2 no_ram_sample -> b="); Serial1.println(b, 1);
    }
  }
  // Snap startYaw to the nearest grid cardinal (RAW frame) so the heading-hold
  // targets a true cardinal even if the prior TURN landed a few degrees off. The
  // bot only ever moves cardinal; residual yaw is drift, not signal.
  motion.startYaw = gridCardinalYaw(g_sensors.yaw_deg);
  // 06-10/11: only trust references within TOF_ODOM_MAX_MM. A startFront of
  // e.g. 8190 (out-of-range junk) made targetFront absurd, so any later junk
  // read "reached" it and the move ended early — the tile-skip bug.
  motion.useFrontTarget = (g_sensors.front_mm > 0 && g_sensors.front_mm < TOF_ODOM_MAX_MM);
  if (motion.startBack >= TOF_ODOM_MAX_MM) motion.startBack = -1;   // junk-prone — don't dead-reckon off it
  motion.odomBlind    = (!motion.useFrontTarget && motion.startBack <= 0);
  motion.blindStartMs = millis();
  motion.prevSideL = motion.prevSideR = false;
  motion.sideLSinceMs = motion.sideRSinceMs = millis();
  if (motion.odomBlind) Serial1.println("DIAG MOVE_TILE blind start (no F/B ref) -> time fallback");
  motion.gyroOnly = g_wfOffNext;   // consume the one-shot gyro-only flag
  g_wfOffNext = false;
  if (motion.gyroOnly) Serial1.println("DIAG MOVE_TILE gyro_only (no wall-follow)");
  // WF2 06-08: residual-carry. This move targets (g_tileLenMm - carried error) so
  // the previous tile's over/undershoot is cancelled here. Clamped to a sane floor.
  int travel = g_tileLenMm - (int)lroundf(g_tilePosErrMm);
  if (travel < 120) travel = 120;
  motion.targetTravel = travel;
  if ((int)lroundf(g_tilePosErrMm) != 0) {
    Serial1.print("DIAG MOVE_TILE travel="); Serial1.print(travel);
    Serial1.print(" (tile="); Serial1.print(g_tileLenMm);
    Serial1.print(" - posErr="); Serial1.print(g_tilePosErrMm, 1); Serial1.println(")");
  }
  int tgt = MOVE_FRONT_STOP_MM;
  if (motion.useFrontTarget) {
    int candidate = g_sensors.front_mm - travel;        // one (corrected) tile of travel
    if (candidate > MOVE_FRONT_STOP_MM) tgt = candidate;
  }
  motion.targetFront    = tgt;
  motion.moveTimeoutMs  = MOVE_TILE_TIMEOUT_MS;
  motion.smoothedBias   = 0;
  motion.wfPrevError    = 0.0f;   // WF2 06-09: fresh PD derivative reference each move
  motion.prevHadWalls   = false;
  motion.sideWallSinceMs = 0;        // WF2 edge filter
  motion.wallEstablished = false;    // WF2 edge filter
  g_dbWfL = g_dbWfR = g_dbSideL = g_dbSideR = { false, false, 0 };  // WF2: fresh wall-debounce each move
  motion.moveSubState   = MOVE_SUB_DRIVING;
  motion.recoveryDone   = false;
  motion.edgeDetectArmed = EDGE_CORRECTION_ENABLED;   // WF2 edge detect (06-10 kill switch)
  motion.edgeSide       = 0;         // WF2 edge detect
  motion.subStartMs     = millis();
  motion.stuckRefBack   = g_sensors.back_mm;
  motion.stuckRefFront  = g_sensors.front_mm;
  motion.stuckLastChangeMs = millis();
  motion.startPitch     = g_sensors.pitch_deg;
  motion.startRoll      = g_sensors.roll_deg;
  motion.onObstacle     = false;
  motion.rampStartMs    = 0;
  motion.rampNotified   = false;
  motion.rampDir        = 0;          // WF3
  motion.rampFlatSinceMs = 0;         // WF3
  motion.chain          = chain;      // WF3
  if (chain) Serial1.println("DIAG MOVE_TILE chained (no stop at end)");
  motion.wfMode            = 0;       // WF2
  motion.wiggling          = false;   // WF2
  motion.wiggleStep        = 0;       // WF2
  motion.wiggleStartMs     = 0;       // WF2
  // WF2 06-07: corridor-drive odometry. Prefer the back wall as the initial
  // reference (it's behind us and recedes as we drive); fall back to the front
  // wall; else acquire later once a wall comes into range.
  motion.odoTraveled  = 0;
  motion.odoBase      = 0;
  motion.tilesEmitted = 0;
  if (motion.startBack > 0 && motion.startBack < BACK_ODO_MAX_MM) {
    motion.odoMode = 1; motion.odoRef = motion.startBack;
  } else if (motion.startFront > 0 && motion.startFront < FRONT_ODO_MAX_MM) {
    motion.odoMode = 2; motion.odoRef = motion.startFront;
  } else {
    motion.odoMode = 0; motion.odoRef = 0;
  }
  strncpy(motion.ackName, "MOVE_TILE", sizeof(motion.ackName));
}

// ----- Forward decls for the sub-state ticks -----
static void tickMoveDriving();
static void tickMoveRecReverse();
static void tickMoveRecRam();
static void tickMoveRecCenter();
static void recResumeDriving();        // WF2: shared "resume forward driving after recovery"
static void tickMoveRecSnap();         // WF2
static void tickMoveFrontAlign();      // WF2 06-07: post-move front clearance settle
static void tickMoveWallDropSnap();    // WF2 06-08: 2->1 wall transition yaw snap
static void startWallDropSequence(int8_t remainingWall);  // WF2 06-09
static void tickMoveEdgeSnap();        // WF2 06-10: mid-move edge correction
static void tickMoveEdgeReverse();     // WF2 06-10
static void tickMoveEdgeFwd();         // WF2 06-10
static void tickMoveRampClimb();       // WF3: ride the ramp until flat
static void tickMoveRampEdge();        // WF3: reverse to find the crest edge (up)
static void tickMoveRampAdv();         // WF3: advance from edge to tile centre
static void startRampAdvance();        // WF3
static void tickMoveTileSettle();      // WF2 06-08: open-tile travel settle (residual carry)

// MOVE_TILE dispatcher. Each tick: fresh IMU read, then route to the active
// sub-state. No overall timeout — the real safety nets are inside the
// sub-states (DRIVING has time_fallback / stuck-detection, recovery sub-
// states each have their own bail timers). Black-tile abort + final
// motionEnd only fire from MOVE_SUB_DRIVING.
static void tickMoveTile() {
  if (bnoOK) {
    tcaSelect(CH_IMU);
    sensors_event_t orient;
    bno.getEvent(&orient);
    g_sensors.yaw_deg = orient.orientation.x;
  }
  switch (motion.moveSubState) {
    case MOVE_SUB_DRIVING:          tickMoveDriving();        break;
    case MOVE_SUB_REC_REVERSE:      tickMoveRecReverse();     break;
    case MOVE_SUB_REC_RAM:          tickMoveRecRam();         break;
    case MOVE_SUB_REC_CENTER:       tickMoveRecCenter();      break;
    case MOVE_SUB_REC_SNAP:         tickMoveRecSnap();        break;  // WF2
    case MOVE_SUB_FRONT_ALIGN:      tickMoveFrontAlign();     break;  // WF2 06-07
    case MOVE_SUB_WALLDROP_SNAP:    tickMoveWallDropSnap();   break;  // WF2 06-08
    case MOVE_SUB_TILE_SETTLE:      tickMoveTileSettle();     break;  // WF2 06-08
    case MOVE_SUB_EDGE_SNAP:        tickMoveEdgeSnap();       break;
    case MOVE_SUB_EDGE_REVERSE:     tickMoveEdgeReverse();    break;
    case MOVE_SUB_EDGE_FWD:         tickMoveEdgeFwd();        break;
    case MOVE_SUB_RAMP_CLIMB:       tickMoveRampClimb();      break;  // WF3
    case MOVE_SUB_RAMP_EDGE:        tickMoveRampEdge();       break;  // WF3
    case MOVE_SUB_RAMP_ADV:         tickMoveRampAdv();        break;  // WF3
  }
}

// ===== WF3 RAMP TRAVERSAL =====================================================
// Entered from tickMoveDriving when a sustained pitch-only tilt is confirmed.
// rampDir: +1 up, -1 down (RAMP UP/DOWN already emitted at detection).

// Simple P-only wall-follow bias on the ramp, using tilt-corrected WF readings
// (the walls flanking the ramp are vertical; the bot is pitched, so the side
// beams need the cos/height-gate treatment). Returns the lateral bias, same
// sign convention as the main WF block.
static int rampSteerBias() {
  float rollDev = g_sensors.imu_trusted
                    ? angleDiff(g_sensors.pitch_deg, motion.startPitch) : 0.0f;
  int l = tiltCorrectSide(g_usL_mm, rollDev, SENSOR_H_WFL_MM);
  int r = tiltCorrectSide(g_usR_mm, rollDev, SENSOR_H_WFR_MM);
  bool hl = (l > 0 && l < US_WF_SIDE_MAX_MM);
  bool hr = (r > 0 && r < US_WF_SIDE_MAX_MM);
  float err = 0;
  if (hl && hr)      err = (float)((r - g_us_wf_target_R) - (l - g_us_wf_target_L));
  else if (hl)       err = -(float)(l - g_us_wf_target_L);
  else if (hr)       err =  (float)(r - g_us_wf_target_R);
  int bias = (int)(err * RAMP_STEER_KP);
  if (bias >  US_WF_BIAS_MAX) bias =  US_WF_BIAS_MAX;
  if (bias < -US_WF_BIAS_MAX) bias = -US_WF_BIAS_MAX;
  return bias;
}

// Set up the edge->centre advance. The rear wheel contact patch sits ON the
// tile boundary right now (crest edge after the reverse hunt, or ramp base the
// moment a decline flattens), so the bot centre is (111-93)=18 mm past the
// boundary; the next tile's centre needs (tile/2 - 18) mm more.
static void startRampAdvance() {
  motorsAllStop();
  motion.moveSubState = MOVE_SUB_RAMP_ADV;
  motion.subStartMs   = millis();
  motion.startFront   = g_sensors.front_mm;   // re-anchor odometry refs at the edge
  motion.startBack    = g_sensors.back_mm;
  motion.targetTravel = g_tileLenMm / 2
                        - (BOT_FRONT_TO_REAR_CONTACT_MM - BOT_FRONT_TO_CENTER_MM);
  Serial1.print("DIAG RAMP advance="); Serial1.print(motion.targetTravel);
  Serial1.print("mm dir=");            Serial1.println(motion.rampDir);
}

// Ride the ramp (up or down) until the floor has been flat for RAMP_FLAT_MS.
static void tickMoveRampClimb() {
  uint32_t now = millis();
  if (now - motion.subStartMs > RAMP_CLIMB_TIMEOUT_MS) {
    motorsAllStop(); motionEnd(false, "stuck"); return;
  }
  float dPitch = g_sensors.imu_trusted
                   ? angleDiff(g_sensors.roll_deg, motion.startRoll) : 0.0f;
  if (fabs(dPitch) < RAMP_FLAT_TOL_DEG) {
    if (motion.rampFlatSinceMs == 0) motion.rampFlatSinceMs = now;
    if (now - motion.rampFlatSinceMs >= RAMP_FLAT_MS) {
      motorsAllStop();
      if (motion.rampDir > 0) {
        // UP: overshot the crest by some unknown amount — reverse to find the
        // exact edge (the spot where reversing further starts pitching down).
        motion.moveSubState = MOVE_SUB_RAMP_EDGE;
        motion.subStartMs   = now;
        Serial1.println("DIAG RAMP flat (up) -> reversing to find crest edge");
      } else {
        // DOWN: the instant the decline ends, the rear contact IS the base
        // edge — geometry is known right now, advance straight away.
        Serial1.println("DIAG RAMP flat (down) -> rear contact at base edge");
        startRampAdvance();
      }
      return;
    }
  } else {
    motion.rampFlatSinceMs = 0;
  }
  int bias = rampSteerBias();
  driveTank(RAMP_CLIMB_SPEED + bias, RAMP_CLIMB_SPEED - bias);
}

// UP only: crawl backward until the bot starts pitching again — that's the
// rear wheels touching the slope, i.e. the rear contact at the crest edge.
static void tickMoveRampEdge() {
  uint32_t now = millis();
  float dPitch = g_sensors.imu_trusted
                   ? angleDiff(g_sensors.roll_deg, motion.startRoll) : 0.0f;
  if (fabs(dPitch) > RAMP_EDGE_PITCH_DEG) {
    Serial1.println("DIAG RAMP crest edge found");
    startRampAdvance();
    return;
  }
  if (now - motion.subStartMs > RAMP_EDGE_TIMEOUT_MS) {
    Serial1.println("DIAG RAMP edge hunt timeout -> advancing from here");
    startRampAdvance();
    return;
  }
  moveBackward(RAMP_EDGE_REV_SPEED);
}

// Drive the computed edge->centre distance, then finish the move. A ramp
// traversal is an ABSOLUTE position re-anchor, so the carried dead-reckon
// error resets. If a front wall is near, FRONT_ALIGN does the precise settle.
// WF3 06-11 (user): NO wall-follow during the off-ramp advance — the WF
// sensors catch the ramp's side rails / edges right at the exit and yanked the
// bot sideways ("wall follows to the side too much"). Drive STRAIGHT; distance
// comes from the front/back ToFs only (time as the last-resort fallback).
static void tickMoveRampAdv() {
  int f = g_sensors.front_mm;
  int b = g_sensors.back_mm;
  int frontShrunk = (motion.startFront > 0 && f > 0) ? (motion.startFront - f) : -1;
  int backGrew    = (motion.startBack  > 0 && b > 0) ? (b - motion.startBack)  : -1;
  int traveled = (frontShrunk >= 0) ? frontShrunk
               : (backGrew    >= 0) ? backGrew
               : (int)((millis() - motion.subStartMs) / 10);   // ~100 mm/s fallback
  if (traveled < motion.targetTravel) {
    moveForward(seekSpeed(motion.targetTravel - traveled));   // straight, no WF bias
    return;
  }
  motorsAllStop();
  g_tilePosErrMm = 0.0f;
  if (f > 0 && f < FRONT_ALIGN_TRIGGER_MM) {
    motion.moveSubState     = MOVE_SUB_FRONT_ALIGN;
    motion.subStartMs       = millis();
    motion.frontAlignStartF = f;
    return;
  }
  Serial1.print("DIAG MOVE_DONE ramp traveled="); Serial1.println(traveled);
  motionEnd(true, "");
}

// ----- FRONT ALIGN sub-state: settle front-ToF to FRONT_ALIGN_TARGET_MM ------
// Runs once at the end of a MOVE_TILE when a front wall is within ~one tile.
// Backs OFF (uncapped) to fix an overshoot, and drives FORWARD to close a gap —
// but the forward travel is hard-CAPPED at FRONT_ALIGN_FWD_CAP_MM (06-08) so the
// bot can never lunge a whole tile toward a far wall under the guise of
// snapping. If the target needs more forward travel than the cap allows, it
// just accepts the current position.
// WF2 06-08: a front-wall align is an ABSOLUTE position fix (bot ends
// FRONT_ALIGN_TARGET_MM off the wall regardless of tile size), so the carried
// dead-reckon error is meaningless past here — reset it.
static void finalizeFrontAlignMove() {
  motorsAllStop();
  g_tilePosErrMm = 0.0f;
  Serial1.print("DIAG MOVE_DONE front_align f="); Serial1.print(g_sensors.front_mm);
  Serial1.println(" (posErr reset 0)");
  motionEnd(true, "");
}

// WF2 06-08: open-tile (dead-reckon) finish — fold the leftover travel error into
// g_tilePosErrMm (clamped) so the NEXT move cancels it, then end.
static void finalizeTileMove(int actualTravel) {
  if (actualTravel > 0) {
    g_tilePosErrMm += (float)(actualTravel - g_tileLenMm);
    if (g_tilePosErrMm >  TILE_POSERR_CLAMP_MM) g_tilePosErrMm =  TILE_POSERR_CLAMP_MM;
    if (g_tilePosErrMm < -TILE_POSERR_CLAMP_MM) g_tilePosErrMm = -TILE_POSERR_CLAMP_MM;
  }
  Serial1.print("DIAG MOVE_DONE tile="); Serial1.print(g_tileLenMm);
  Serial1.print(" target=");  Serial1.print(motion.targetTravel);
  Serial1.print(" actual=");  Serial1.print(actualTravel);
  Serial1.print(" posErr=");  Serial1.println(g_tilePosErrMm, 1);
  motionEnd(true, "");
}

static void tickMoveFrontAlign() {
  int f = g_sensors.front_mm;
  if (millis() - motion.subStartMs > FRONT_ALIGN_TIMEOUT_MS) { finalizeFrontAlignMove(); return; }
  if (f <= 0) { finalizeFrontAlignMove(); return; }   // lost the wall — accept
  int err = f - FRONT_ALIGN_TARGET_MM;
  if (abs(err) <= FRONT_ALIGN_TOL_MM) { finalizeFrontAlignMove(); return; }
  int spd = seekSpeed(abs(err));                          // linear ramp, min 50
  if (err < 0) { moveBackward(spd); return; }            // too close (overshot) -> back off (uncapped)
  // too far -> drive forward, but only up to the forward cap
  int forwardMoved = motion.frontAlignStartF - f;        // how far we've closed so far
  if (forwardMoved >= FRONT_ALIGN_FWD_CAP_MM) { finalizeFrontAlignMove(); return; }  // hit cap -> accept
  moveForward(spd);
}

// WF2 06-08: open-tile travel settle. The back-delta stop coasts past the target;
// nudge forward/back until back-delta is within TILE_SETTLE_TOL_MM of targetTravel,
// then finalize (which carries the residual). Only entered with a valid back wall
// and NO near front wall (so creeping forward is safe). Time-bounded.
static void tickMoveTileSettle() {
  uint32_t el = millis() - motion.subStartMs;
  // Phase 1: brake and let the bot COAST to rest before judging travel — the
  // back-delta stop fires ~TILE_BACK_MARGIN_MM early while still rolling.
  if (el < TILE_SETTLE_COAST_MS) { motorsAllStop(); return; }
  int b = g_sensors.back_mm;
  if (b <= 0 || el > TILE_SETTLE_TIMEOUT_MS) {
    int actual = (b > 0 && motion.startBack > 0) ? (b - motion.startBack) : motion.targetTravel;
    motorsAllStop();
    finalizeTileMove(actual);
    return;
  }
  int backGrew = b - motion.startBack;
  int err = backGrew - motion.targetTravel;     // + = overshot (went too far)
  if (abs(err) <= TILE_SETTLE_TOL_MM) {
    motorsAllStop();
    finalizeTileMove(backGrew);
    return;
  }
  int spd = seekSpeed(abs(err));                 // linear ramp, min 50
  if (err > 0) moveBackward(spd);                // overshot -> back up toward target
  else         moveForward(spd);                 // short  -> creep forward (open ahead)
}

// --- MID-MOVE EDGE CORRECTION SUB-STATES ---

// 1. Edge Snap: Square heading to the cardinal axis so reversing is straight.
static void tickMoveEdgeSnap() {
  if (!bnoOK) {
    // If IMU is dead, skip snapping.
    motion.moveSubState = MOVE_SUB_EDGE_REVERSE;
    motion.subStartMs = millis();
    return;
  }
  float cardinal = gridCardinalYaw(g_sensors.yaw_deg);
  float dev = angleDiff(g_sensors.yaw_deg, cardinal);
  if (fabs(dev) <= TURN_TOL_DEG) {
    motorsAllStop();
    motion.moveSubState = MOVE_SUB_EDGE_REVERSE;
    motion.subStartMs = millis();
    return;
  }
  int p = (int)(fabs(dev) * 2.0f);
  if (p < TURN_MIN_SPEED) p = TURN_MIN_SPEED;
  if (p > TURN_SPEED) p = TURN_SPEED;
  if (dev > 0) turnLeftInPlace(p);
  else         turnRightInPlace(p);
}

// 2. Edge Reverse: Creep back until the missing wall is detected again.
static void tickMoveEdgeReverse() {
  // Timeout: if we reverse too long and never see the wall, bail to FWD.
  if (millis() - motion.subStartMs > 3000) {
    motorsAllStop();
    motion.moveSubState = MOVE_SUB_EDGE_FWD;
    motion.subStartMs = millis();
    motion.startFront = g_sensors.front_mm;
    motion.startBack = g_sensors.back_mm;
    return;
  }
  
  bool seeWall = false;
  if (motion.edgeSide == 1 || motion.edgeSide == 3) {
    if (g_usL_mm > 0 && g_usL_mm < US_WF_SIDE_MAX_MM) seeWall = true;
  }
  if (motion.edgeSide == 2 || motion.edgeSide == 3) {
    if (g_usR_mm > 0 && g_usR_mm < US_WF_SIDE_MAX_MM) seeWall = true;
  }

  if (seeWall) {
    motorsAllStop();
    Serial1.println("DIAG MOVE_TILE edge_found -> edge_fwd");
    motion.moveSubState = MOVE_SUB_EDGE_FWD;
    motion.subStartMs = millis();
    motion.startFront = g_sensors.front_mm;
    motion.startBack = g_sensors.back_mm;
    return;
  }

  moveBackward(EDGE_REVERSE_SPEED);
}

// 3. Edge Fwd: Drive exactly half a tile (plus optional offset) to center.
static void tickMoveEdgeFwd() {
  int targetTravel = (g_tileLenMm / 2) + EDGE_TO_CENTER_OFFSET_MM;
  
  int backGrew = (motion.startBack > 0 && g_sensors.back_mm > 0) ? (g_sensors.back_mm - motion.startBack) : -1;
  int frontShrunk = (motion.startFront > 0 && g_sensors.front_mm > 0) ? (motion.startFront - g_sensors.front_mm) : -1;
  
  int traveled = backGrew >= 0 ? backGrew : frontShrunk;
  if (traveled < 0) {
    traveled = (int)((millis() - motion.subStartMs) / 10); // time fallback
  }

  if (traveled >= targetTravel) {
    motorsAllStop();
    Serial1.print("DIAG MOVE_DONE edge_fwd traveled="); Serial1.println(traveled);
    g_tilePosErrMm = 0.0f; // Perfect fix, no carry-over
    motionEnd(true, "");
    return;
  }

  // Heading hold during the final push
  int latBias = 0;
  int yawBias = 0;
  if (YAW_GUARD_ENABLED && g_sensors.imu_trusted) {
    float yawDev = angleDiff(g_sensors.yaw_deg, motion.startYaw);
    float a = fabs(yawDev);
    if (a > YAW_GUARD_MAX_DEG) {
      yawBias = (int)(-YAW_GUARD_GAIN_HARD * yawDev);
    } else if (a > YAW_GUARD_DEAD_DEG) {
      yawBias = (int)(-YAW_GUARD_GAIN_SOFT * yawDev);
    }
    if (yawBias >  YAW_GUARD_BIAS_MAX) yawBias =  YAW_GUARD_BIAS_MAX;
    if (yawBias < -YAW_GUARD_BIAS_MAX) yawBias = -YAW_GUARD_BIAS_MAX;
  }
  driveTank(EDGE_FWD_SPEED - latBias + yawBias,
            EDGE_FWD_SPEED + latBias - yawBias);
}

// 06-10/11: blind-odometry edge re-anchor (ported from WF2). A tracked side
// wall just ENDED — wall segments end on tile boundaries, so the side sensor
// (mounted at the bot's longitudinal centre) crossed a boundary
// WALL_RELEASE_MS ago. Rebase the time-fallback clock so the remaining blind
// travel = half a tile minus the debounce lag.
static void blindEdgeRebase(char side) {
  int lagMm = (int)(WALL_RELEASE_MS / BLIND_MS_PER_MM);
  int remaining = g_tileLenMm / 2 - lagMm;
  if (remaining < 20) remaining = 20;
  long doneMm = (long)motion.targetTravel - remaining;
  if (doneMm < 0) doneMm = 0;
  motion.blindStartMs = millis() - (uint32_t)(doneMm * BLIND_MS_PER_MM);
  Serial1.print("DIAG MOVE_TILE blind edge("); Serial1.print(side);
  Serial1.print(") -> remaining="); Serial1.println(remaining);
}

// ----- DRIVING sub-state: normal forward, with recovery + stuck triggers ---
static void tickMoveDriving() {
  int f = g_sensors.front_mm;
  int b = g_sensors.back_mm;
  int l = g_sensors.left_mm;
  int r = g_sensors.right_mm;

  // WF3: tilt-correct the front/back readings (obstacle/speed-bump crossing).
  // Bot-pitch = firmware roll axis (BNO mount). Below TILT_CORRECT_MIN_DEG this
  // is a no-op; tilted, it cos-projects and rejects beams leaving the wall band
  // so the stop checks can't fire on a floor/over-wall ghost.
  if (g_sensors.imu_trusted) {
    float pitchDev = angleDiff(g_sensors.roll_deg, motion.startRoll);
    f = tiltCorrectSide(f, pitchDev, SENSOR_H_F_MM);
    b = tiltCorrectSide(b, pitchDev, SENSOR_H_B_MM);
  }

  // ---- yaw-cos correction for side ToF readings ----
  // L/R sensors sit at the mid-sides of the bot, beams pointing perpendicular
  // to bot-forward. If the bot is rotated yawOff degrees from where the move
  // started, those beams hit the side wall at an angle - reading comes back
  // as raw/cos(yawOff), i.e. larger than the true perpendicular distance.
  // Multiplying by cos(yawOff) recovers the perpendicular distance, so wall-
  // follow doesn't mistake a yaw-drifted bot for one that's drifted away.
  if (g_sensors.imu_trusted) {
    float yawOff = angleDiff(g_sensors.yaw_deg, motion.startYaw);
    if (fabs(yawOff) > WALL_FOLLOW_YAW_COS_MIN_DEG) {
      float c = cosf(yawOff * 3.14159265f / 180.0f);
      if (c > 0.1f) {                       // sanity: don't divide by ~0 at extreme yaw
        if (l > 0) l = (int)(l * c);
        if (r > 0) r = (int)(r * c);
      }
    }
  }

  // ---- obstacle detection ----
  // pitch/roll drift > OBSTACLE_TILT_DEG from start = bot on a beam/ramp/debris.
  // Mark via DIAG (mapper flags the tile), but DON'T stop - just keep going
  // and trust gyro to hold heading. No centring on obstacle tiles.
  if (g_sensors.imu_trusted && !motion.onObstacle) {
    float dPitch = fabs(angleDiff(g_sensors.pitch_deg, motion.startPitch));
    float dRoll  = fabs(angleDiff(g_sensors.roll_deg,  motion.startRoll));
    if (dPitch > OBSTACLE_TILT_DEG || dRoll > OBSTACLE_TILT_DEG) {
      motion.onObstacle = true;
      Serial1.print("DIAG MOVE_TILE on_obstacle pitch_dev=");
      Serial1.print(dPitch, 1);
      Serial1.print(" roll_dev=");
      Serial1.println(dRoll, 1);
    }
  }

  // ---- ramp detection (WF3: full traversal) ----
  // A ramp = SUSTAINED bot-pitch change (firmware roll axis) with minimal
  // bot-roll change (firmware pitch axis) — an obstacle bumps both axes
  // briefly, a ramp pitches one axis and HOLDS it. On confirmation: emit
  // RAMP UP/DOWN (mapper bumps its floor + applies the ramp transition on the
  // move's ACK) and hand the move to the ramp traversal sub-states.
  if (g_sensors.imu_trusted && !motion.rampNotified) {
    float dPitchBot = angleDiff(g_sensors.roll_deg,  motion.startRoll);
    float dRollBot  = fabs(angleDiff(g_sensors.pitch_deg, motion.startPitch));
    if (fabs(dPitchBot) > RAMP_TILT_DEG && dRollBot < RAMP_ROLL_MAX_DEG) {
      if (motion.rampStartMs == 0) motion.rampStartMs = millis();
      else if (millis() - motion.rampStartMs > RAMP_SUSTAIN_MS) {
        motion.rampNotified  = true;
        motion.rampDir       = (dPitchBot > 0) ? +1 : -1;
        Serial1.println(motion.rampDir > 0 ? "RAMP UP" : "RAMP DOWN");
        Serial1.print("DIAG RAMP confirmed dPitch="); Serial1.print(dPitchBot, 1);
        Serial1.print(" dRoll=");                     Serial1.println(dRollBot, 1);
        motion.moveSubState    = MOVE_SUB_RAMP_CLIMB;
        motion.rampFlatSinceMs = 0;
        motion.subStartMs      = millis();
        return;
      }
    } else {
      motion.rampStartMs = 0;
    }
  }

  // ---- side-wall presence (debounced) — used by the corridor decision below
  //      AND the wall-loss recovery further down ----
  bool haveL = debounceBool(g_dbSideL, (l > 0 && l < WALL_FOLLOW_SIDE_MAX_MM), millis(), WALL_DEBOUNCE_MS, WALL_RELEASE_MS);
  bool haveR = debounceBool(g_dbSideR, (r > 0 && r < WALL_FOLLOW_SIDE_MAX_MM), millis(), WALL_DEBOUNCE_MS, WALL_RELEASE_MS);
  bool hasWalls = haveL || haveR;

  // ---- STOP when we've travelled one tile (simple front/back delta) ----
  // The whole "moved one tile?" decision is just: has the FRONT-ToF shrunk by a
  // tile (we drove up to the target / a wall), OR has the BACK-ToF grown by a
  // tile (we left the previous tile by ~300 mm)? Either is enough — use whichever
  // wall is in range. No odometry handoff, no tile-event scheme; that
  // over-engineering ran straight through open space because it had no wall to
  // measure against. This is the proven one-tile behaviour.
  // 06-10/11: range-gated references — junk reads (8190 spikes / >800 mm
  // drift) must never count as travel. backGrew allows legit growth up to
  // start + one tile; anything bigger is a spike, not progress.
  int  backGrew  = (motion.startBack > 0 && b > 0
                    && b < TOF_ODOM_MAX_MM + g_tileLenMm) ? (b - motion.startBack) : -1;
  bool frontStop = (f > 0 && f < TOF_ODOM_MAX_MM && f <= motion.targetFront);
  bool backStop  = (backGrew >= (motion.targetTravel - TILE_BACK_MARGIN_MM));

  // BLIND mode: front wall finally in range -> snap the stop target onto the
  // grid that wall defines (centres sit at FRONT_ALIGN_TARGET + k*tile from
  // it, since FRONT_ALIGN settles every wall-stop to that clearance).
  // Absolute re-anchor: absorbs the accumulated time-estimate error.
  if (motion.odomBlind && f > 0 && f < TOF_ODOM_MAX_MM) {
    int blindTravel  = (int)((millis() - motion.blindStartMs) / BLIND_MS_PER_MM);
    int estRemaining = motion.targetTravel - blindTravel;
    if (estRemaining < 0) estRemaining = 0;
    int candidate = f - estRemaining;          // est. stop position on the front scale
    int k = (int)lroundf((float)(candidate - FRONT_ALIGN_TARGET_MM) / (float)g_tileLenMm);
    int target = FRONT_ALIGN_TARGET_MM + k * g_tileLenMm;
    if (target < MOVE_FRONT_STOP_MM) target = MOVE_FRONT_STOP_MM;
    motion.targetFront    = target;
    motion.useFrontTarget = true;
    motion.odomBlind      = false;
    Serial1.print("DIAG MOVE_TILE blind front reacquire f="); Serial1.print(f);
    Serial1.print(" est_rem="); Serial1.print(estRemaining);
    Serial1.print(" -> targetFront="); Serial1.println(target);
  }

  // BLIND mode: side-wall edge watch + time-based stop. Only a RELEASE of a
  // wall that was stably present (>= WALL_ESTABLISH_MS) counts as a boundary —
  // the per-move debouncers always assert ~0.5 s into the move, which is NOT
  // an edge.
  bool blindStop = false;
  if (motion.odomBlind) {
    uint32_t nowB = millis();
    if (haveL != motion.prevSideL) {
      if (!haveL && nowB - motion.sideLSinceMs >= WALL_ESTABLISH_MS) blindEdgeRebase('L');
      motion.prevSideL = haveL; motion.sideLSinceMs = nowB;
    }
    if (haveR != motion.prevSideR) {
      if (!haveR && nowB - motion.sideRSinceMs >= WALL_ESTABLISH_MS) blindEdgeRebase('R');
      motion.prevSideR = haveR; motion.sideRSinceMs = nowB;
    }
    int blindTravel = (int)((nowB - motion.blindStartMs) / BLIND_MS_PER_MM);
    if (blindTravel >= motion.targetTravel) {
      blindStop = true;
      Serial1.print("DIAG MOVE_TILE blind stop est="); Serial1.println(blindTravel);
    }
  }

  if (frontStop || backStop || blindStop) {
    motorsAllStop();
    // 06-09 (user): the wall-drop yaw-straighten + re-center has PRIORITY over
    // front-align. If we were on both walls and exactly one just dropped, run the
    // wall-drop sequence first (don't bake the skew into a front-align).
    // WF2 06-10: uses the DEBOUNCED wall states — a single flaky-ToF frame must
    // not fire a stop-and-square dance (the flaky WF-Left does exactly that).
    {
      bool wfL = g_dbWfL.stable;
      bool wfR = g_dbWfR.stable;
      if (motion.wfMode == 3 && (wfL != wfR) && backGrew > RECOVERY_MIN_TRAVEL_MM
          && g_sensors.imu_trusted) {
        startWallDropSequence(wfL ? -1 : +1);
        return;
      }
    }
    // WF3 CHAIN: the mapper already knows the next step continues straight —
    // fold the residual, ACK NOW while slow-rolling, and coast briefly so the
    // next MOVE_TILE takes over without a stop. Skipped when a front wall is
    // near (end of the straight run — do the normal precise stop instead).
    // (06-11: never chain off a BLIND stop — the end position is a guess, so do
    // the full stop + let the next move's sense re-ground things.)
    if (motion.chain && !motion.odomBlind && !(f > 0 && f < FRONT_ALIGN_TRIGGER_MM)) {
      if (backGrew > 0) {
        g_tilePosErrMm += (float)(backGrew - g_tileLenMm);
        if (g_tilePosErrMm >  TILE_POSERR_CLAMP_MM) g_tilePosErrMm =  TILE_POSERR_CLAMP_MM;
        if (g_tilePosErrMm < -TILE_POSERR_CLAMP_MM) g_tilePosErrMm = -TILE_POSERR_CLAMP_MM;
      }
      Serial1.print("DIAG MOVE_DONE chain actual="); Serial1.print(backGrew);
      Serial1.print(" posErr=");                     Serial1.println(g_tilePosErrMm, 1);
      moveForward(CHAIN_COAST_SPEED);
      g_coastUntilMs = millis() + CHAIN_COAST_MS;
      ackOk(motion.ackName);          // (motionEnd would stop the motors)
      motion.state = MS_IDLE;
      return;
    }

    // Front wall within ~one tile -> FRONT_ALIGN (absolute fix, resets posErr).
    if (f > 0 && f < FRONT_ALIGN_TRIGGER_MM) {
      motion.moveSubState     = MOVE_SUB_FRONT_ALIGN;
      motion.subStartMs       = millis();
      motion.frontAlignStartF = f;   // forward-cap reference
      return;
    }
    // Open tile (no near front wall): hand off to the settle, which coasts to
    // rest, then nudges to within TILE_SETTLE_TOL_MM of target and carries the
    // residual. (backStop fires ~margin early while still rolling, so we must let
    // it coast before measuring.) No back reference at all -> just finalize.
    if (backGrew >= 0) {
      motion.moveSubState = MOVE_SUB_TILE_SETTLE;
      motion.subStartMs   = millis();
      return;
    }
    finalizeTileMove(backGrew);
    return;
  }

  // 06-10/11 (ported from WF2): mid-move blind transition. If the references
  // drop out of range mid-move, switch to the time fallback, seeded with the
  // best travel estimate so far.
  {
    bool hasFrontRef = (motion.useFrontTarget && f > 0 && f < TOF_ODOM_MAX_MM);
    bool hasBackRef  = (motion.startBack > 0 && b > 0 && b < TOF_ODOM_MAX_MM + g_tileLenMm);
    if (!motion.odomBlind && !hasFrontRef && !hasBackRef) {
      motion.odomBlind = true;
      int traveledSoFar = 0;
      if (motion.startBack > 0 && motion.stuckRefBack > 0) {
        traveledSoFar = motion.stuckRefBack - motion.startBack;
      } else if (motion.useFrontTarget && motion.startFront > 0 && motion.stuckRefFront > 0) {
        traveledSoFar = motion.startFront - motion.stuckRefFront;
      } else {
        traveledSoFar = (int)((millis() - motion.startMs) / 10);
      }
      if (traveledSoFar < 0) traveledSoFar = 0;
      motion.blindStartMs = millis() - (uint32_t)(traveledSoFar * BLIND_MS_PER_MM);
      Serial1.print("DIAG MOVE_TILE mid-move blind transition, traveledSoFar=");
      Serial1.println(traveledSoFar);
    }
  }

  // Black-tile abort
  if (g_sensors.color == 'K' && (millis() - motion.startMs) > BLACK_DETECT_WARMUP_MS) {
    motorsAllStop();
    motion.state = MS_RECOVER_BLACK;
    motion.startMs = millis();
    motion.moveTimeoutMs = BLACK_RECOVER_MS;
    return;
  }

  // Stuck detection (06-08 user fix): progress = the back-ToF GREW or the
  // front-ToF SHRANK by > STUCK_DELTA_MM. The old back-only check mis-fired
  // when there was no near back wall — the bot drove forward (front shrinking
  // 203->113) but the back sat at ~730, so a perfectly-moving bot read as
  // "stuck". Watching either wall fixes that. Seed a ref if its wall only comes
  // into range mid-move. Only fire when at least one ref is valid.
  {
    bool fValid = (f > 0 && f < TOF_ODOM_MAX_MM);                  // 06-11: range-gated (junk reads aren't progress)
    bool bValid = (b > 0 && b < TOF_ODOM_MAX_MM + g_tileLenMm);
    if (fValid && motion.stuckRefFront <= 0) motion.stuckRefFront = f;
    if (bValid && motion.stuckRefBack  <= 0) motion.stuckRefBack  = b;
    bool progressed = false;
    if (bValid && motion.stuckRefBack  > 0 && abs(b - motion.stuckRefBack)  > STUCK_DELTA_MM) progressed = true;
    if (fValid && motion.stuckRefFront > 0 && abs(f - motion.stuckRefFront) > STUCK_DELTA_MM) progressed = true;
    if (progressed) {
      if (bValid) motion.stuckRefBack  = b;
      if (fValid) motion.stuckRefFront = f;
      motion.stuckLastChangeMs = millis();
    } else if ((motion.stuckRefBack > 0 || motion.stuckRefFront > 0)
               && millis() - motion.stuckLastChangeMs > STUCK_WINDOW_MS
               && millis() - motion.startMs > STUCK_WARMUP_MS) {
      motorsAllStop();
      motionEnd(false, "stuck"); return;
    }
  }

  // ---- recovery trigger: walls just disappeared ----
  // User spec: "from 2/1 walls to 0 walls, come back to the previous tile,
  // ram, re-center, THEN proceed." We require traveled > RECOVERY_MIN_TRAVEL_MM
  // so we don't trigger from a noisy start-of-move sample. recoveryDone gates
  // re-firing after a successful recovery so we can actually drive the foyer.
  // (haveL / haveR / hasWalls were computed above for the corridor decision.)
  int traveled;
  if (motion.startBack > 0 && b > 0 && b < TOF_ODOM_MAX_MM + g_tileLenMm) {
    traveled = b - motion.startBack;
  } else if (motion.odomBlind) {
    traveled = (int)((millis() - motion.blindStartMs) / BLIND_MS_PER_MM);   // 06-11: blind estimate
  } else {
    traveled = (int)((millis() - motion.startMs) / 10);  // ~100 mm/s estimate
  }

  // WF2 EDGE FILTER: only treat a wall as "established" once it has persisted
  // for WALL_ESTABLISH_MS. A side wall seen briefly right after a turn is just
  // the trailing edge of the wall we were following before the turn — its
  // disappearance must NOT fire recovery (that made the bot chase the edge,
  // watch it end, reverse and ram the wrong wall, wrecking the map).
  uint32_t nowMs = millis();
  if (hasWalls) {
    if (motion.sideWallSinceMs == 0) motion.sideWallSinceMs = nowMs;
    if (nowMs - motion.sideWallSinceMs >= WALL_ESTABLISH_MS) motion.wallEstablished = true;
  } else {
    motion.sideWallSinceMs = 0;
  }

  // WF2 (user 2026-06-10): going BLIND (an established wall vanished, nothing
  // left to follow) no longer triggers the reverse->ram->center recovery dance.
  // That was slow and, on a bad yaw, drove the bot into things. Instead just
  // STRAIGHTEN the heading to the grid cardinal IN PLACE and keep driving. The
  // bot only rotates (no translation), so the tile-travel measurement stays
  // valid — reuse the wall-drop snap path, which rotates to motion.startYaw and
  // resumes via wdResumeDriving() WITHOUT resetting startBack/Front/targetFront.
  // (The old REC_REVERSE/REC_RAM/REC_CENTER/REC_SNAP states are now unreachable.)
  // Gated on imu_trusted: with no IMU we can't square up, so just drive on
  // open-loop rather than ram blindly.
  if (!motion.recoveryDone && motion.wallEstablished && !hasWalls
      && traveled > RECOVERY_MIN_TRAVEL_MM && g_sensors.imu_trusted) {
    motorsAllStop();
    motion.wallEstablished = false;
    motion.startYaw     = g_yawRefCaptured ? nearestCardinalYaw(g_sensors.yaw_deg)
                                           : g_sensors.yaw_deg;
    motion.smoothedBias = 0;
    motion.subStartMs   = millis();
    motion.moveSubState = MOVE_SUB_WALLDROP_SNAP;   // straighten -> resume (no ram)
    Serial1.println("DIAG MOVE_TILE walls_lost -> straighten + continue (no ram)");
    return;
  }
  // Yaw re-anchor when an ESTABLISHED wall disappears (not a transient edge).
  // CRITICAL (06-08): re-anchor to the nearest CARDINAL, never to the raw current
  // yaw. If the bot is mid-curve when a wall drops, capturing the raw yaw makes
  // the yaw guard treat that curved heading as "straight" and hold it — so the
  // bot keeps curving into the wall and the guard never corrects it. Snapping to
  // the grid cardinal keeps the heading-hold pinned to the true axis.
  if (motion.wallEstablished && !hasWalls && g_sensors.imu_trusted) {
    motion.startYaw = g_yawRefCaptured ? nearestCardinalYaw(g_sensors.yaw_deg)
                                       : g_sensors.yaw_deg;
  }
  // Once walls are gone, clear the established flag (a fresh wall must re-arm it).
  if (!hasWalls) motion.wallEstablished = false;
  motion.prevHadWalls = hasWalls;

  // --- Mid-Move Edge Correction ---
  if (motion.edgeDetectArmed && g_sensors.imu_trusted) {
    int targetMidpoint = g_tileLenMm / 2;
    int distFromMid = abs(traveled - targetMidpoint);
    
    if (distFromMid <= EDGE_DETECT_WINDOW_MM) {
      // WF2 06-10: DEBOUNCED wall states (WALL_RELEASE_MS), not instant reads —
      // a single flaky frame inside the window must not trigger the whole
      // stop / snap / reverse / re-drive sequence.
      bool wfL = g_dbWfL.stable;
      bool wfR = g_dbWfR.stable;

      // If we were following a wall and it suddenly disappeared
      if (motion.wfMode == 1 && !wfL) {
        motion.edgeSide = 1;
      } else if (motion.wfMode == 2 && !wfR) {
        motion.edgeSide = 2;
      } else if (motion.wfMode == 3) {
        if (!wfL && wfR) motion.edgeSide = 1;
        else if (!wfR && wfL) motion.edgeSide = 2;
        else if (!wfL && !wfR) motion.edgeSide = 3;
      }

      if (motion.edgeSide != 0) {
        Serial1.print("DIAG MOVE_TILE edge_detected side="); Serial1.println(motion.edgeSide);
        motorsAllStop();
        motion.edgeDetectArmed = false;
        motion.moveSubState = MOVE_SUB_EDGE_SNAP;
        motion.subStartMs = millis();
        return;
      }
    } else if (traveled > targetMidpoint + EDGE_DETECT_WINDOW_MM) {
      motion.edgeDetectArmed = false; // passed the window
    }
  }

  // ---- speed shape: quadratic decel toward the one-tile stop point ----
  int refDist;
  if (f > 0) {
    refDist = f - motion.targetFront;                       // room left to the front target
    if (refDist < 0) refDist = 0;
  } else if (motion.startBack > 0 && b > 0) {
    int t2 = b - motion.startBack;                          // back-delta progress
    refDist = (motion.targetTravel - TILE_BACK_MARGIN_MM) - t2;   // room left on the back measure (residual-corrected target)
    if (refDist < 0) refDist = 0;
  } else {
    refDist = SPEED_D_BRAKE_MM * 4;                         // no wall reference — cruise
  }
  int spd = driveSpeed(refDist);
  if (motion.startFront <= 0 && spd > SPEED_V_MIN + 20) spd = SPEED_V_MIN + 20;  // go gentle when blind
  // 06-11: BLIND mode drives at a FIXED speed so the time-based travel
  // estimate (BLIND_MS_PER_MM) actually corresponds to a known speed.
  if (motion.odomBlind) spd = BLIND_SPEED;
  if (motion.edgeDetectArmed && abs(traveled - (g_tileLenMm / 2)) <= EDGE_DETECT_WINDOW_MM) {
    if (spd > EDGE_APPROACH_SPEED) spd = EDGE_APPROACH_SPEED; // slow down to catch the edge
  }
  // WF3: crossing a blue tile (puddle/rough terrain, rule 3.2.5) — go gentle.
  if (g_sensors.color == 'B' && spd > BLUE_SLOW_SPEED) spd = BLUE_SLOW_SPEED;

  // ---- combined heading + lateral correction ----
  // On obstacle: trust gyro only. Wall readings are unreliable when bot is
  // tilted, and the user spec says "no centring on obstacle tiles - just
  // keep it straight via gyro".
  // INFLIGHT_LATERAL_ENABLED=false (default 2026-05-30) skips the lateral
  // block entirely — drive runs on yaw-hold only and the mapper-side
  // PERP_RECENTER fixes drift between tiles.
  // ---- ULTRASONIC wall-follow (pure P-control, NO yaw) ----
  // HC-SR04 L/R drive the lateral bias with Kp gains. Alternating reads:
  // one sensor per tick to halve blocking time. Suppressed on obstacle.
  // Side ToFs (haveL/haveR) still own recovery/mapping — untouched.
  // ENFORCED 12ms TIMING: the EMA PID needs a stable dt, and pulseIn blocks.
  static uint32_t lastWallFollowUs = 0;
  uint32_t nowUs = micros();
  if (nowUs - lastWallFollowUs >= WALLFOLLOW_INTERVAL_US) {
    lastWallFollowUs = nowUs;
    int lateralBias = 0;
    // gyroOnly: skip wall-follow entirely -> lateralBias stays 0, the bot drives
    // on the yaw guard (pure gyro heading-hold) only.
    // WF3: wall-follow STAYS ON during obstacle crossings (was suppressed) —
    // the readings are tilt-corrected below, same trig as the Pi dashboard.
    if (US_WALL_FOLLOW_ENABLED && !motion.gyroOnly) {
      // WF2: the wall-follow ToFs (VL53L0X, ch0 L / ch7 R) are read once per main
      // loop (see loop()), so g_usL_mm/g_usR_mm are already fresh + both-sides
      // current here — no per-tick read needed. They hold ToF mm: -2 offline,
      // -1 out-of-range.
      // WF3: tilt-correct the WF readings with the bot-roll deviation (firmware
      // pitch axis). Flat ground -> pass-through; tilted (obstacle/bump) ->
      // cos-projection + wall-band gate so a tilted beam can't fake a distance.
      float rollDev = g_sensors.imu_trusted
                        ? angleDiff(g_sensors.pitch_deg, motion.startPitch) : 0.0f;
      int usL = tiltCorrectSide(g_usL_mm, rollDev, SENSOR_H_WFL_MM);
      int usR = tiltCorrectSide(g_usR_mm, rollDev, SENSOR_H_WFR_MM);

      // Debounced (WALL_DEBOUNCE_MS) so a fluke read can't flip wall-follow mode.
      bool haveLU = debounceBool(g_dbWfL, (usL > 0 && usL < US_WF_SIDE_MAX_MM), millis(), WALL_DEBOUNCE_MS, WALL_RELEASE_MS);
      bool haveRU = debounceBool(g_dbWfR, (usR > 0 && usR < US_WF_SIDE_MAX_MM), millis(), WALL_DEBOUNCE_MS, WALL_RELEASE_MS);
      float error = 0;
      float kp    = 0;
      // WF2 wall-follow policy (PER-SIDE targets g_us_wf_target_L / _R — L=127,
      // R=96, different on purpose: the WF sensors read different distances at
      // the correct centred position):
      //   both walls -> hold each side to ITS OWN target (wfMode 3). error =
      //                 (R - target_R) - (L - target_L); zero when both sides sit
      //                 at their own target, so an on-spec bot has zero error and
      //                 does NOT steer. (A single shared target made this R-L and
      //                 swerved the bot into the wall.)
      //   left only  -> follow LEFT  to target_L (wfMode 1)
      //   right only -> follow RIGHT to target_R (wfMode 2)
      //   neither    -> no lateral bias (wfMode 0); wall-loss recovery owns this
      // WF2 06-08: motion.wfMode persists across ticks, so its value HERE is the
      // previous WF-tick's mode — capture it to detect a 2-wall -> 1-wall drop.
      int8_t wfBefore = motion.wfMode;
      if (haveLU && haveRU) {
        float driftR = (float)(usR - g_us_wf_target_R);   // WF3: tilt-corrected reads
        float driftL = (float)(usL - g_us_wf_target_L);
        error = driftR - driftL;
        kp    = US_WF_KP_2WALLS;
        motion.wfMode = 3;
      } else if (haveLU) {
        error = -(float)(usL - g_us_wf_target_L);
        kp    = US_WF_KP_1WALL;
        motion.wfMode = 1;
      } else if (haveRU) {
        error = (float)(usR - g_us_wf_target_R);
        kp    = US_WF_KP_1WALL;
        motion.wfMode = 2;
      } else {
        motion.wfMode = 0;
      }

      // WF2 06-09: on a wall-config change, reset the PD derivative reference to
      // the current error so the first-tick Δerror doesn't spike a lurch.
      if (motion.wfMode != wfBefore) motion.wfPrevError = error;

      // WF2 06-08 (user): were following BOTH walls and one just ended (2->1).
      // Stop, square the heading onto the expected grid cardinal, then resume
      // the same move — so the freshly-opened side doesn't yank the wall-follow
      // error term and swerve the bot. Gated on traveled distance so a noisy
      // start-of-move sample can't trip it. Hand off to MOVE_SUB_WALLDROP_SNAP.
      if (wfBefore == 3 && (motion.wfMode == 1 || motion.wfMode == 2)
          && traveled > RECOVERY_MIN_TRAVEL_MM && g_sensors.imu_trusted) {
        startWallDropSequence(motion.wfMode == 1 ? -1 : +1);   // remaining wall: 1=left, 2=right
        return;
      }

      // PD-steer: P (error*Kp) corrects toward target; D (Δerror*Kd) damps the
      // approach so a big offset doesn't overshoot/swerve INTO the wall. Corrects
      // ALL errors (no dead-zone). Only runs when a wall is present.
      if (motion.wfMode != 0) {
        float deriv = error - motion.wfPrevError;       // per-tick change (WF tick fixed 12ms)
        motion.wfPrevError = error;
        lateralBias = (int)(error * kp + deriv * US_WF_KD);
        if (lateralBias >  US_WF_BIAS_MAX) lateralBias =  US_WF_BIAS_MAX;
        if (lateralBias < -US_WF_BIAS_MAX) lateralBias = -US_WF_BIAS_MAX;
      } else {
        lateralBias = 0;
      }
    }

    // No yaw bias — pure ultrasonic P-control.

    motion.smoothedBias = (motion.smoothedBias * WALL_FOLLOW_EMA_KEEP
                            + lateralBias      * WALL_FOLLOW_EMA_NEW)
                            / WALL_FOLLOW_EMA_DIV;
  }
  
  // WF2 yaw guard: cap heading deviation from the move's cardinal at
  // ±YAW_GUARD_MAX_DEG. (06-08 sign flip reverted to -gain — the original was
  // correct; the yaw problems were the snap target, not the sign.) Still gated
  // off (YAW_GUARD_ENABLED=false) per "no gyro in wall-follow".
  int latBias = motion.smoothedBias;
  int yawBias = 0;
  if (YAW_GUARD_ENABLED && g_sensors.imu_trusted) {
    float yawDev = angleDiff(g_sensors.yaw_deg, motion.startYaw);
    float a = fabs(yawDev);
    if (a > YAW_GUARD_MAX_DEG) {
      latBias = 0;                                     // over budget: straighten first
      yawBias = (int)(-YAW_GUARD_GAIN_HARD * yawDev);
    } else if (a > YAW_GUARD_DEAD_DEG) {
      yawBias = (int)(-YAW_GUARD_GAIN_SOFT * yawDev);
    }
    if (yawBias >  YAW_GUARD_BIAS_MAX) yawBias =  YAW_GUARD_BIAS_MAX;
    if (yawBias < -YAW_GUARD_BIAS_MAX) yawBias = -YAW_GUARD_BIAS_MAX;
  }
  driveTank(spd + latBias + yawBias, spd - latBias - yawBias);
}

// ----- RECOVERY: reverse until walls return -----
static void tickMoveRecReverse() {
  uint32_t elapsed = millis() - motion.subStartMs;
  if (elapsed > 3000) {
    Serial1.println("DIAG MOVE_TILE recovery_reverse_timeout -> resume_driving");
    motion.recoveryDone = true;
    motion.moveSubState = MOVE_SUB_DRIVING;
    motion.prevHadWalls = false;
    return;
  }
  int l = g_sensors.left_mm;
  int r = g_sensors.right_mm;
  bool wallsBack = (l > 0 && l < WALL_FOLLOW_SIDE_MAX_MM)
                || (r > 0 && r < WALL_FOLLOW_SIDE_MAX_MM);
  if (wallsBack) {
    Serial1.println("DIAG MOVE_TILE walls_returned -> recovery_ram");
    motorsAllStop();
    motion.moveSubState   = MOVE_SUB_REC_RAM;
    motion.subStartMs     = millis();
    motion.lastRamDist    = g_sensors.back_mm;
    motion.ramLastChangeMs = millis();
    return;
  }
  moveBackward(SPEED_V_MIN);
}

// ----- RECOVERY: ram backward into the recovered wall (+ WF2 wiggle) -----
static void tickMoveRecRam() {
  uint32_t now = millis();
  // WF2: post-ram shimmy, then hand off to recenter
  if (motion.wiggling) {
    if (runWiggle()) {
      motion.wiggling     = false;
      motion.moveSubState = MOVE_SUB_REC_CENTER;
      motion.subStartMs   = millis();
    }
    return;
  }
  if (now - motion.subStartMs > RAM_TIMEOUT_MS) {
    Serial1.println("DIAG MOVE_TILE recovery_ram_timeout -> recovery_center");
    motion.moveSubState = MOVE_SUB_REC_CENTER;
    motion.subStartMs   = millis();
    return;
  }
  int cur = g_sensors.back_mm;
  moveBackward(RAM_SPEED);
  bool ramDone     = false;
  bool bothValid   = (cur > 0 && motion.lastRamDist > 0);
  bool bothInvalid = (cur < 0 && motion.lastRamDist < 0);
  if (bothValid) {
    if (abs(cur - motion.lastRamDist) < RAM_STALL_DELTA) {
      if (now - motion.ramLastChangeMs > RAM_STALL_MS) ramDone = true;
    } else motion.ramLastChangeMs = now;
  } else if (bothInvalid) {
    if (now - motion.ramLastChangeMs > RAM_STALL_MS) ramDone = true;
  } else motion.ramLastChangeMs = now;
  if (ramDone) {
    motorsAllStop();
    if (WIGGLE_ENABLED) {
      Serial1.println("DIAG MOVE_TILE recovery_ram_done -> wiggle");
      motion.wiggling = true; motion.wiggleStep = 0; motion.wiggleStartMs = 0;
    } else {
      Serial1.println("DIAG MOVE_TILE recovery_ram_done -> recovery_center");
      motion.moveSubState = MOVE_SUB_REC_CENTER;
      motion.subStartMs   = millis();
    }
    return;
  }
  motion.lastRamDist = cur;
}

// Re-anchor + resume DRIVING with recoveryDone=true. Don't keep retrying.
// Also reset startMs so the post-recovery DRIVING gets a fresh time-fallback
// budget — otherwise the bot resumes with most of the 3.5 s already burned
// by the recovery sequence, and immediately falls through time_fallback.
// Shared by tickMoveRecCenter (no yaw ref) and tickMoveRecSnap (after the snap).
static void recResumeDriving() {
  Serial1.println("DIAG MOVE_TILE recovery_done -> resume_driving");
  motorsAllStop();
  motion.recoveryDone   = true;
  motion.moveSubState   = MOVE_SUB_DRIVING;
  motion.prevHadWalls   = false;
  motion.sideWallSinceMs = 0;            // WF2: fresh edge-filter state after recovery
  motion.wallEstablished = false;
  motion.startMs        = millis();      // <-- fresh time budget for post-recovery drive
  motion.startBack      = g_sensors.back_mm;
  motion.startFront     = g_sensors.front_mm;
  motion.startYaw       = g_sensors.yaw_deg;
  // Re-derive targetFront from the new startFront (use this move's targetTravel)
  int tgt = MOVE_FRONT_STOP_MM;
  if (motion.startFront > 0) {
    int candidate = motion.startFront - motion.targetTravel;
    if (candidate > MOVE_FRONT_STOP_MM) tgt = candidate;
  }
  motion.targetFront    = tgt;
  motion.stuckRefBack   = g_sensors.back_mm;
  motion.stuckRefFront  = g_sensors.front_mm;
  motion.stuckLastChangeMs = millis();
}

// ----- RECOVERY: longitudinal centre, then snap yaw + resume DRIVING -----
static void tickMoveRecCenter() {
  // After centering: snap yaw to the nearest cardinal BEFORE driving forward
  // again (the ram squares us laterally, the snap squares us angularly). If we
  // have no yaw reference yet, skip straight to driving.
  auto doneCenter = []() {
    motorsAllStop();
    if (g_yawRefCaptured) {
      motion.snapTarget   = nearestCardinalYaw(g_sensors.yaw_deg);
      motion.subStartMs   = millis();
      motion.moveSubState = MOVE_SUB_REC_SNAP;
      Serial1.print("DIAG MOVE_TILE recovery_center_done -> rec_snap target=");
      Serial1.println(motion.snapTarget, 1);
    } else {
      recResumeDriving();
    }
  };
  if (millis() - motion.subStartMs > 3000) { doneCenter(); return; }
  int f = g_sensors.front_mm;
  int b = g_sensors.back_mm;
  if (f > 0 && f < 250) {
    int err = f - CENTER_TARGET_F;
    if (abs(err) < CENTER_TOL_MM) { doneCenter(); return; }
    int spd = seekSpeed(abs(err));               // linear ramp, min 50
    if (err > 0) moveForward(spd);
    else         moveBackward(spd);
    return;
  }
  if (b > 0 && b < 250) {
    int err = b - CENTER_TARGET_B;
    if (abs(err) < CENTER_TOL_MM) { doneCenter(); return; }
    int spd = seekSpeed(abs(err));               // linear ramp, min 50
    if (err > 0) moveBackward(spd);
    else         moveForward(spd);
    return;
  }
  doneCenter();   // no F/B reference, accept current longitudinal pose
}

// ----- RECOVERY: snap yaw to cardinal, then resume DRIVING -----
// User request: after reversing + ramming the perpendicular wall, square the
// heading to the grid before going forward again, so accumulated turn/pivot
// drift doesn't get baked into the resumed move.
static void tickMoveRecSnap() {
  if (millis() - motion.subStartMs > SNAP_TIMEOUT_MS) {
    Serial1.println("DIAG MOVE_TILE recovery_snap_timeout -> resume_driving");
    recResumeDriving();
    return;
  }
  if (turnTowardYaw(motion.snapTarget, SNAP_SPEED)) {
    Serial1.println("DIAG MOVE_TILE recovery_snap_done -> resume_driving");
    recResumeDriving();
  }
}

// ===== WALL-DROP: 2-wall -> 1-wall transition (WF2 06-09, user) =============
// Sequence after both walls drop to one:
//   1. straighten yaw to the grid cardinal (WALLDROP_SNAP)
//   2. check the REMAINING wall's distance vs its target
//   3. if off by > WD_RECENTER_TOL_MM: turn to FACE it, drive out the error,
//      turn BACK, then re-check (repeat up to WD_MAX_ITERS)
//   4. else resume driving. The bot only rotated/strafed laterally — do NOT
//      reset startBack/startFront/targetFront (that would restart the tile measure).

static void wdResumeDriving() {
  motorsAllStop();
  motion.moveSubState      = MOVE_SUB_DRIVING;
  motion.smoothedBias      = 0;
  motion.wfPrevError       = 0.0f;
  motion.stuckRefBack      = g_sensors.back_mm;
  motion.stuckRefFront     = g_sensors.front_mm;
  motion.stuckLastChangeMs = millis();
}

// 1. straighten yaw, then resume.
static void tickMoveWallDropSnap() {
  bool done = (millis() - motion.subStartMs > WALLDROP_SNAP_TIMEOUT_MS);
  if (done) {
    Serial1.println("DIAG MOVE_TILE walldrop_snap_timeout");
  } else if (turnTowardYaw(motion.startYaw, SNAP_SPEED_START)) {
    Serial1.println("DIAG MOVE_TILE walldrop_snap_done");
    done = true;
  }
  if (!done) return;
  wdResumeDriving();
}

// Set up the whole wall-drop sequence (called from the stop-check + the WF block).
static void startWallDropSequence(int8_t remainingWall) {
  motorsAllStop();
  motion.smoothedBias  = 0;
  motion.subStartMs    = millis();
  motion.moveSubState  = MOVE_SUB_WALLDROP_SNAP;
  Serial1.print("DIAG MOVE_TILE wall_dropped 2->1 remain=");
  Serial1.print(remainingWall < 0 ? "L" : "R");
  Serial1.print(" -> straighten yaw target="); Serial1.println(motion.startYaw, 1);
}

// --- RECOVER BLACK ---
// Reverse out until the back sensor reads ~ startBack (= we're back at the
// position where MOVE_TILE started, i.e. centred in the previous tile).
// Falls back to fixed 1.2 s timer when back is blind.
static void tickRecoverBlack() {
  if (millis() - motion.startMs > motion.moveTimeoutMs) { motionEnd(false, "black"); return; }
  int b = g_sensors.back_mm;
  // If we have a back reference, stop when we're within 20 mm of startBack
  if (motion.startBack > 0 && b > 0 && b <= motion.startBack + 20) {
    motorsAllStop();
    motionEnd(false, "black"); return;
  }
  moveBackward(SPEED_V_MIN);
}

// --- RAM WALL (front or back only; L/R = upper layer should turn first) ---
void motionStart_RamWall(uint8_t side) {
  const char* name = (side == 0) ? "RAM_F" : (side == 3) ? "RAM_B" : "RAM";
  if (motion.state != MS_IDLE) motionHalt();
  if (side != 0 && side != 3)  { ackFail(name, "side_unsupported"); return; }
  motion.state           = MS_RAM_WALL;
  motion.startMs         = millis();
  motion.ramSide         = side;
  motion.lastRamDist     = (side == 0) ? g_sensors.front_mm : g_sensors.back_mm;
  motion.ramLastChangeMs = millis();
  motion.ramTimeoutMs    = RAM_TIMEOUT_MS;
  motion.wiggling        = false;   // WF2
  motion.wiggleStep      = 0;       // WF2
  motion.wiggleStartMs   = 0;       // WF2
  strncpy(motion.ackName, name, sizeof(motion.ackName));
}

static void tickRamWall() {
  uint32_t now = millis();
  // WF2: post-ram shimmy (backward rams only), then complete
  if (motion.wiggling) {
    if (runWiggle()) {
      motion.wiggling = false;
      captureYawSampleA();   // squared flush after the back-ram -> two-sample ref A
      motionEnd(true, "");
    }
    return;
  }
  if (now - motion.startMs > motion.ramTimeoutMs) { motionEnd(false, "timeout"); return; }
  int cur = (motion.ramSide == 0) ? g_sensors.front_mm : g_sensors.back_mm;
  if (motion.ramSide == 0) moveForward(RAM_SPEED); else moveBackward(RAM_SPEED);
  bool ramDone     = false;
  bool bothValid   = (cur > 0 && motion.lastRamDist > 0);
  bool bothInvalid = (cur < 0 && motion.lastRamDist < 0);
  if (bothValid) {
    if (abs(cur - motion.lastRamDist) < RAM_STALL_DELTA) {
      if (now - motion.ramLastChangeMs > RAM_STALL_MS) ramDone = true;
    } else motion.ramLastChangeMs = now;
  } else if (bothInvalid) {
    if (now - motion.ramLastChangeMs > RAM_STALL_MS) ramDone = true;
  } else motion.ramLastChangeMs = now;
  if (ramDone) {
    motorsAllStop();
    // WF2: shimmy after a BACKWARD ram (wheels-back squares us into the wall);
    // forward rams just complete.
    if (WIGGLE_ENABLED && motion.ramSide == 3) {
      motion.wiggling = true; motion.wiggleStep = 0; motion.wiggleStartMs = 0;
    } else {
      captureYawSampleA();   // squared flush after the ram -> two-sample ref A
      motionEnd(true, "");
    }
    return;
  }
  motion.lastRamDist = cur;
}

// --- CENTER ---
void motionStart_CenterTile(int latOffset) {
  if (motion.state != MS_IDLE) motionHalt();
  motion.state          = MS_CENTER_TILE;
  motion.startMs        = millis();
  motion.centerPhase    = 0;
  motion.centerRetries  = 0;   // WF2
  motion.centerLatOffset = latOffset;  // WF2: turn-drift pre-compensation (0 = plain center)
  strncpy(motion.ackName, "CENTER", sizeof(motion.ackName));
}

static void tickCenterTile() {
  if (millis() - motion.startMs > CENTER_TIMEOUT_MS) { motionEnd(false, "timeout"); return; }
  int f = g_sensors.front_mm;
  int b = g_sensors.back_mm;
  int l = g_sensors.left_mm;
  int r = g_sensors.right_mm;

  // --- WF2 square-tile deduction ---
  // If the LATERAL pair (L+R) is visible, deduce the true tile size from it
  // (W = L + R + sensor-span) and shift the single-wall longitudinal target by
  // the same per-side growth (W-300)/2. Assuming a square tile, that puts the
  // bot mid-tile even when the lone wall has no opposite partner and the tile
  // isn't exactly 300 mm. (§4 geometry.)
  int latAdjust = 0;
  bool haveLR = (l > 0 && l < CENTER_WALL_MAX_MM && r > 0 && r < CENTER_WALL_MAX_MM);
  if (haveLR) {
    int wLat  = l + r + SENSOR_SPAN_LR_MM;            // deduced tile width
    latAdjust = (wLat - TILE_NOMINAL_MM) / 2;         // per-side growth vs nominal
  }
  int fTarget = CENTER_TARGET_F + latAdjust;
  int bTarget = CENTER_TARGET_B + latAdjust;

  bool haveF = (f > 0 && f < CENTER_WALL_MAX_MM);
  bool haveB = (b > 0 && b < CENTER_WALL_MAX_MM);

  if (motion.centerPhase == 0) {
    // Prefer opposite-wall centering (F+B both visible): drive until equidistant
    // — the most imperfection-robust, needs no target at all.
    // WF2: centerLatOffset shifts the setpoint to pre-compensate turn drift.
    // It's expressed as a desired (f-b) delta; a single-wall target shifts by
    // half that (moving x toward back changes f-b by 2x).
    int latOff  = motion.centerLatOffset;
    int latOffH = latOff / 2;
    if (haveF && haveB) {
      int err = (f - b) - latOff;   // positive = closer to back, move forward
      if (abs(err) < CENTER_TOL_MM * 2) { motorsAllStop(); motion.centerPhase = 1; return; }
      int spd = seekSpeed(abs(err) / 2);   // (f-b) moves 2x per mm of travel; linear ramp, min 50
      if (err > 0) moveForward(spd); else moveBackward(spd);
      return;
    }
    // Single longitudinal wall: drive to the square-deduced target (offset-shifted).
    if (haveF) {
      int err = f - (fTarget + latOffH);
      if (abs(err) < CENTER_TOL_MM) { motorsAllStop(); motion.centerPhase = 1; return; }
      int spd = seekSpeed(abs(err));       // linear ramp, min 50
      if (err > 0) moveForward(spd); else moveBackward(spd);
      return;
    }
    if (haveB) {
      int err = b - (bTarget - latOffH);
      if (abs(err) < CENTER_TOL_MM) { motorsAllStop(); motion.centerPhase = 1; return; }
      int spd = seekSpeed(abs(err));       // linear ramp, min 50
      if (err > 0) moveBackward(spd); else moveForward(spd);
      return;
    }
    motion.centerPhase = 1;   // no longitudinal wall to centre against
    return;
  }

  // ----- WF2 phase 1: VERIFY we actually ended up centred -----
  // Bot is stopped here, so these reads are clean. Residual = how far off the
  // centring reference we are; latAdj shows the deduced tile correction.
  int residual = -1;   // -1 = nothing to verify against (offset-aware, matches phase 0)
  if (haveF && haveB)      residual = abs((f - b) - motion.centerLatOffset);
  else if (haveF)          residual = abs(f - (fTarget + motion.centerLatOffset / 2));
  else if (haveB)          residual = abs(b - (bTarget - motion.centerLatOffset / 2));

  Serial1.print("DIAG CENTER_VERIFY F="); Serial1.print(f);
  Serial1.print(" B=");        Serial1.print(b);
  Serial1.print(" L=");        Serial1.print(l);
  Serial1.print(" R=");        Serial1.print(r);
  Serial1.print(" latAdj=");   Serial1.print(latAdjust);
  Serial1.print(" residual="); Serial1.print(residual);
  Serial1.print(" latres=");   Serial1.println(haveLR ? abs(l - r) : -1);  // |L-R| = lateral centering quality

  if (residual > CENTER_VERIFY_TOL_MM && motion.centerRetries < CENTER_MAX_RETRIES) {
    motion.centerRetries++;
    Serial1.print("DIAG CENTER off by "); Serial1.print(residual);
    Serial1.print(" mm -> retry "); Serial1.println(motion.centerRetries);
    motion.centerPhase = 0;   // re-centre
    return;
  }
  if (residual > CENTER_VERIFY_TOL_MM) {
    Serial1.print("DIAG CENTER imperfect (gave up), residual="); Serial1.println(residual);
  }
  motionEnd(true, "");
}

// --- WAIT (blue-tile 5 s pause) ---
void motionStart_WaitBlue(uint32_t ms) {
  if (motion.state != MS_IDLE) motionHalt();
  motion.state       = MS_WAIT_BLUE;
  motion.startMs     = millis();
  motion.waitUntilMs = motion.startMs + ms;
  motorsAllStop();
  strncpy(motion.ackName, "WAIT_BLUE", sizeof(motion.ackName));
}

static void tickWaitBlue() {
  if (millis() >= motion.waitUntilMs) motionEnd(true, "");
}

// --- HALT (interrupt any motion) ---
void motionHalt() {
  motorsAllStop();
  g_coastUntilMs = 0;   // WF3: a halt also kills any chained-move coast
  if (motion.state != MS_IDLE) ackFail(motion.ackName, "halted");
  motion.state = MS_IDLE;
}

void motionTick() {
  switch (motion.state) {
    case MS_IDLE:           return;
    case MS_TURN_90:        tickTurn90();       break;
    case MS_MOVE_TILE:      tickMoveTile();     break;
    case MS_RAM_WALL:       tickRamWall();      break;
    case MS_CENTER_TILE:    tickCenterTile();   break;
    case MS_WAIT_BLUE:      tickWaitBlue();     break;
    case MS_RECOVER_BLACK:  tickRecoverBlack(); break;
  }
}

// =============================================================================
// === SECTION 10: BUTTON STATE MACHINE ========================================
// =============================================================================

RunState getRunState() { return g_runState; }
bool isRunning()       { return g_runState == RUN_RUNNING; }
const char* runStateName(RunState s) {
  switch (s) { case RUN_STOPPED: return "STOPPED";
               case RUN_RUNNING: return "RUNNING";
               case RUN_PAUSED:  return "PAUSED"; }
  return "?";
}
char runStateChar(RunState s) {
  switch (s) { case RUN_STOPPED: return 'S';
               case RUN_RUNNING: return 'R';
               case RUN_PAUSED:  return 'P'; }
  return '?';
}

// HOLD_THRESH_MS, DEBOUNCE_MS hoisted to SECTION 0 at the top of the file.

// ButtonState struct is defined up in Section 3 (forced by Arduino auto-
// prototype). Only the instances live here.
static ButtonState btnA = { false, 0, 0, false };
static ButtonState btnB = { false, 0, 0, false };

static void emitEvent(const char* tag) {
  Serial1.println(tag);
  Serial.print("[btn] "); Serial.println(tag);
}

static void onTap() {
  if (g_runState == RUN_RUNNING) {
    motionHalt(); g_runState = RUN_PAUSED;  emitEvent("BTN_PAUSE");
  } else if (g_runState == RUN_PAUSED) {
    g_runState = RUN_RUNNING; emitEvent("BTN_RESUME");
  } else {
    Serial.println("[btn] tap ignored (STOPPED - hold 5 s to start)");
  }
}

static void onHold() {
  if (g_runState == RUN_STOPPED) {
    g_runState = RUN_RUNNING; emitEvent("BTN_RUN");
  } else {
    motionHalt(); g_runState = RUN_STOPPED; emitEvent("BTN_STOP");
  }
}

static bool serviceButton(ButtonState& bs, int pin) {
  bool rawPressed = (digitalRead(pin) == LOW);
  uint32_t now = millis();
  bool fired = false;
  if (rawPressed != bs.pressed && now - bs.lastEdgeMs > DEBOUNCE_MS) {
    bs.lastEdgeMs = now; bs.pressed = rawPressed;
    if (rawPressed) { bs.pressStartMs = now; bs.holdFired = false; }
    else if (!bs.holdFired) { onTap(); fired = true; }
  } else if (bs.pressed && !bs.holdFired
             && (now - bs.pressStartMs) >= HOLD_THRESH_MS) {
    bs.holdFired = true; onHold(); fired = true;
  }
  return fired;
}

void buttonsInit() {
  Serial.print("[btn] initial state = "); Serial.println(runStateName(g_runState));
  Serial1.print("BTN_STATE "); Serial1.println(runStateName(g_runState));
}

void buttonsTick() {
  bool fired = serviceButton(btnA, BTN_START);
  if (!fired) serviceButton(btnB, BTN_LOP);
}

// =============================================================================
// === SECTION 11: COMMAND PARSER (Pi -> Cytron) ==============================
// =============================================================================

#define CMD_BUF_SZ 64
static char    cmdBuf[CMD_BUF_SZ];
static uint8_t cmdLen = 0;

static void cmdReject(const char* reason) {
  Serial1.print("ACK ? fail reason="); Serial1.println(reason);
}

static bool isMotionCmd(const char* l) {
  return strncmp(l, "MOVE_TILE", 9) == 0
      || strncmp(l, "TURN_",     5) == 0
      || strncmp(l, "RAM_",      4) == 0
      || strncmp(l, "CENTER",    6) == 0
      || strncmp(l, "WAIT_BLUE", 9) == 0;
}

static void dispatch(const char* line) {
  while (*line == ' ' || *line == '\t') line++;
  if (*line == '\0' || *line == '#') return;

  if (!strncmp(line, "PING", 4)) { Serial1.println("PONG"); return; }
  if (!strncmp(line, "HALT", 4)) { motionHalt(); Serial1.println("ACK HALT ok"); return; }

  // WF2: dashboard run-state control. Mirrors the physical-button events so the
  // Pi's run_state tracking stays in sync (RUN_START/RUN_STOP/BTN_PAUSE/RESUME).
  if (!strncmp(line, "START",  5)) { g_runState = RUN_RUNNING; emitEvent("RUN_START");  Serial1.println("ACK START ok");  return; }
  if (!strncmp(line, "STOP",   4)) { motionHalt(); g_runState = RUN_STOPPED; emitEvent("RUN_STOP");  Serial1.println("ACK STOP ok");   return; }
  if (!strncmp(line, "PAUSE",  5)) { motionHalt(); g_runState = RUN_PAUSED;  emitEvent("BTN_PAUSE"); Serial1.println("ACK PAUSE ok");  return; }
  if (!strncmp(line, "RESUME", 6)) { g_runState = RUN_RUNNING; emitEvent("BTN_RESUME"); Serial1.println("ACK RESUME ok"); return; }

  // Commands always honoured regardless of run-state. The motion primitives
  // themselves preempt any in-flight motion (motionHalt at top of each
  // motionStart_*), so direct UART commands have the highest priority and
  // override whatever the mapper is doing.

  if (!strncmp(line, "MOVE_TILE", 9)) {
    // WF3: "MOVE_TILE C" = chained — ACK while slow-rolling, no stop/settle.
    const char* a = line + 9;
    while (*a == ' ') a++;
    motionStart_MoveTile(*a == 'C');
    return;
  }
  if (!strncmp(line, "CENTER",    6)) {
    // Optional signed lateral offset: "CENTER -15" pre-compensates turn drift.
    int latOff = 0;
    const char* a = line + 6;
    while (*a == ' ') a++;
    if (*a) latOff = atoi(a);
    motionStart_CenterTile(latOff);
    return;
  }
  if (!strncmp(line, "TURN_L",    6)) { motionStart_Turn90(-1);   return; }
  if (!strncmp(line, "TURN_R",    6)) { motionStart_Turn90(+1);   return; }
  if (!strncmp(line, "YAW_SQUARE",10)) { motionStart_YawSquare(); return; }
  if (!strncmp(line, "RAM_F",     5)) { motionStart_RamWall(0);   return; }
  if (!strncmp(line, "RAM_B",     5)) { motionStart_RamWall(3);   return; }
  if (!strncmp(line, "WAIT_BLUE", 9)) {
    uint32_t ms = 5000;
    const char* p = line + 9;
    while (*p == ' ') p++;
    if (*p) {
      long parsed = atol(p);
      ms = (parsed > 0) ? (uint32_t)parsed : 5000;   // never 0 (rule needs >= 5 s)
    }
    motionStart_WaitBlue(ms); return;
  }
  if (!strncmp(line, "LED_VICTIM ", 11)) { ledVictim(line[11]); Serial1.println("ACK LED_VICTIM ok"); return; }
  if (!strncmp(line, "LED_EXIT",    8)) { ledExitStart();       Serial1.println("ACK LED_EXIT ok");   return; }
  if (!strncmp(line, "LED_TEAM ",   9)) { ledTeam(line + 9);    Serial1.println("ACK LED_TEAM ok");   return; }
  // WF3: LED_FLASH <color> [ms] — one-shot solid flash then auto-off
  // (checkpoint cue = "LED_FLASH white 800").
  if (!strncmp(line, "LED_FLASH ", 10)) {
    const char* a = line + 10;
    uint32_t ms = 600;
    const char* sp = strchr(a, ' ');
    if (sp) { long v = atol(sp + 1); if (v > 0) ms = (uint32_t)v; }
    ledFlash(a, ms);
    Serial1.println("ACK LED_FLASH ok");
    return;
  }
  // WF3: YAW_REREF — re-anchor the grid yaw frame to the bot's CURRENT heading.
  // Used on a LoP resume: the captain has just placed the bot square on the
  // grid, so its heading IS a cardinal (also covers a BNO brown-out reset
  // during handling). All later turns/snaps target (new yaw0 + N*90).
  if (!strncmp(line, "YAW_REREF", 9)) {
    if (bnoOK) {
      tcaSelect(CH_IMU);
      sensors_event_t o; bno.getEvent(&o);
      g_sensors.yaw_deg = o.orientation.x;
    }
    g_yawRef0          = g_sensors.yaw_deg;
    g_yawRefCaptured   = true;
    g_yawRefReconciled = true;
    Serial1.print("DIAG YAW_REREF yaw0="); Serial1.println(g_yawRef0, 1);
    Serial1.println("ACK YAW_REREF ok");
    return;
  }

  // CAL_US BOTH | CAL_US L | CAL_US R
  //   Sample the ultrasonic(s) and store as g_us_wf_target_L/R for in-flight
  //   wall-follow. Pi runs this after the startup CENTER once it's positioned
  //   the bot against the relevant wall(s). Bot must be stationary — pulseIn
  //   is blocking, but called from idle so it doesn't cost a motion tick.
  //   Reads of -1 (no echo / out of range) are NOT written to the target;
  //   the previous value (default US_WF_TARGET_MM) is preserved.
  if (!strncmp(line, "CAL_US ", 7)) {
    // WF2: the startup capture (as-placed, pre-ram) is authoritative. Ignore the
    // mapper's post-center CAL_US so centering slip can't poison the baseline.
    if (g_usWfCaptured) {
      Serial1.print("DIAG CAL_US ignored (startup baseline) tgtL="); Serial1.print(g_us_wf_target_L);
      Serial1.print(" tgtR="); Serial1.println(g_us_wf_target_R);
      Serial1.println("ACK CAL_US ok");
      return;
    }
    const char* arg = line + 7;
    while (*arg == ' ') arg++;
    // WF2 06-10: use the loop-fresh cached readings (≤ one loop / one ToF
    // period old; the bot is stationary here). A blocking rangingTest would
    // fight the continuous-ranging mode.
    int lUS = g_usL_mm;
    int rUS = g_usR_mm;
    bool wantL = false, wantR = false;
    if      (!strncmp(arg, "BOTH", 4)) { wantL = true; wantR = true; }
    else if (arg[0] == 'L')            { wantL = true; }
    else if (arg[0] == 'R')            { wantR = true; }
    else { cmdReject("cal_us_arg"); return; }
    if (wantL && lUS > 0) g_us_wf_target_L = lUS;
    if (wantR && rUS > 0) g_us_wf_target_R = rUS;
    Serial1.print("DIAG CAL_US ");
    Serial1.print(arg);
    Serial1.print(" raw L="); Serial1.print(lUS);
    Serial1.print(" R=");     Serial1.print(rUS);
    Serial1.print(" -> tgtL="); Serial1.print(g_us_wf_target_L);
    Serial1.print(" tgtR=");    Serial1.println(g_us_wf_target_R);
    Serial1.println("ACK CAL_US ok");
    return;
  }

  // CAL_TILE — measure the true tile pitch from the lateral wall pair(s).
  //   Issued once at start-of-run after the longitudinal-only centre, while the
  //   bot still sits at its as-placed lateral pose (the L+R sum is invariant to
  //   lateral offset, so we don't need lateral centring first). Deduces tile
  //   width from the mapping L/R ToFs and, independently, from the WF ToFs,
  //   averages whichever pairs are visible, assumes a square tile, clamps to a
  //   sane band, and stores g_tileLenMm for MOVE_TILE. If no lateral pair is
  //   visible, keeps the previous value (nominal). Bot must be stationary.
  if (!strncmp(line, "CAL_TILE", 8)) {
    // WF2 06-10: all from the loop-fresh cache (bot is stationary for CAL_TILE;
    // values are ≤ one ToF period old). Blocking reads would fight continuous mode.
    int fr  = g_sensors.front_mm;
    int bk  = g_sensors.back_mm;
    int l   = g_sensors.left_mm;
    int r   = g_sensors.right_mm;
    int wfl = g_usL_mm;
    int wfr = g_usR_mm;
    int wFB = -1, wLR = -1, wWF = -1;
    // FRONT+BACK pair (PREFERRED — the mapper turns the bot so a wall sits in
    // front and behind, and the F/B ToFs are more reliable than the side ToFs).
    if (fr > 0 && fr < CENTER_WALL_MAX_MM && bk > 0 && bk < CENTER_WALL_MAX_MM) {
      wFB = fr + bk + SENSOR_SPAN_FB_MM;
    }
    if (l > 0 && l < CENTER_WALL_MAX_MM && r > 0 && r < CENTER_WALL_MAX_MM) {
      wLR = l + r + SENSOR_SPAN_LR_MM;
    }
    if (wfl > 0 && wfl < US_WF_SIDE_MAX_MM && wfr > 0 && wfr < US_WF_SIDE_MAX_MM) {
      wWF = wfl + wfr + SENSOR_SPAN_WF_MM;
    }
    // Prefer front/back; else fall back to the side pairs (avg L/R + WF).
    int deduced = -1;
    if      (wFB > 0)              deduced = wFB;
    else if (wLR > 0 && wWF > 0)   deduced = (wLR + wWF) / 2;
    else if (wLR > 0)             deduced = wLR;
    else if (wWF > 0)             deduced = wWF;
    bool applied = false;
    if (deduced >= TILE_MIN_MM && deduced <= TILE_MAX_MM) {
      g_tileLenMm = deduced;
      applied = true;
    }
    Serial1.print("DIAG CAL_TILE F="); Serial1.print(fr);
    Serial1.print(" B=");     Serial1.print(bk);
    Serial1.print(" L=");     Serial1.print(l);
    Serial1.print(" R=");     Serial1.print(r);
    Serial1.print(" WFL=");   Serial1.print(wfl);
    Serial1.print(" WFR=");   Serial1.print(wfr);
    Serial1.print(" wFB=");   Serial1.print(wFB);
    Serial1.print(" wLR=");   Serial1.print(wLR);
    Serial1.print(" wWF=");   Serial1.print(wWF);
    Serial1.print(" deduced="); Serial1.print(deduced);
    Serial1.print(applied ? " -> tile=" : " (rejected, keep tile="); Serial1.print(g_tileLenMm);
    Serial1.println(applied ? "" : ")");
    Serial1.println("ACK CAL_TILE ok");
    return;
  }

  // CAL_REF — capture yaw and ToF reference readings after first center-align.
  // Must be issued when bot is stationary and centred. All subsequent turn-snaps
  // reference the captured yaw as the grid's cardinal axes.
  if (!strncmp(line, "CAL_REF", 7)) {
    // WF2: g_yawRef0 is now fixed at startup (see loop()); CAL_REF no longer
    // re-anchors the yaw frame — it only refreshes the ToF references. Stops a
    // slightly-misaligned re-cal from corrupting the grid heading mid-run.
    g_tofRef_F = g_sensors.front_mm;
    g_tofRef_B = g_sensors.back_mm;
    g_tofRef_L = g_sensors.left_mm;
    g_tofRef_R = g_sensors.right_mm;
    Serial1.print("DIAG CAL_REF yaw="); Serial1.print(g_yawRef0, 1);
    Serial1.print(" F="); Serial1.print(g_tofRef_F);
    Serial1.print(" B="); Serial1.print(g_tofRef_B);
    Serial1.print(" L="); Serial1.print(g_tofRef_L);
    Serial1.print(" R="); Serial1.println(g_tofRef_R);
    Serial1.println("ACK CAL_REF ok");
    return;
  }

  // WF_OFF_NEXT — make the NEXT MOVE_TILE drive on gyro/yaw-hold only (no
  // wall-follow). One-shot, consumed by that move. Used to drive the first tile
  // of a run purely on gyro (swerve isolation).
  if (!strncmp(line, "WF_OFF_NEXT", 11)) {
    g_wfOffNext = true;
    Serial1.println("ACK WF_OFF_NEXT ok");
    return;
  }

  // SET_TILE <mm> — set the measured tile pitch (g_tileLenMm) used by the
  // MOVE_TILE front/back-delta stop. The Pi measures the real tile size by
  // driving a corridor and dividing (front+back+span) by the tile count, then
  // sends it here. Clamped to a sane band.
  if (!strncmp(line, "SET_TILE", 8)) {
    const char* a = line + 8;
    while (*a == ' ') a++;
    int v = atoi(a);
    // WF2 06-08 (user): "check yaw" before trusting a recal. A crooked bot reads
    // front/back at a slant, so the corridor measurement is wrong — reject it.
    if (g_yawRefCaptured && g_sensors.imu_trusted) {
      float dev = fabs(angleDiff(g_sensors.yaw_deg, nearestCardinalYaw(g_sensors.yaw_deg)));
      if (dev > SET_TILE_YAW_TOL_DEG) {
        Serial1.print("DIAG SET_TILE rejected (crooked) yawDev="); Serial1.println(dev, 1);
        Serial1.println("ACK SET_TILE fail reason=crooked");
        return;
      }
    }
    if (v >= TILE_MIN_MM && v <= TILE_MAX_MM) {
      // WF2 06-08: ALWAYS running-average with the current value (which starts at
      // TILE_NOMINAL_MM). No single corridor reading dominates, so a one-off
      // over-read (e.g. a slight slant inflating f/b) gets damped toward nominal
      // instead of being adopted outright.
      g_tileLenMm = (g_tileLenMm + v) / 2;
      Serial1.print("DIAG SET_TILE in="); Serial1.print(v);
      Serial1.print(" -> tile="); Serial1.println(g_tileLenMm);
      Serial1.println("ACK SET_TILE ok");
    } else {
      Serial1.print("DIAG SET_TILE rejected (out of band) v="); Serial1.println(v);
      Serial1.println("ACK SET_TILE fail reason=out_of_band");
    }
    return;
  }

  cmdReject("unknown");
}

void commandsTick() {
  while (Serial1.available()) {
    int b = Serial1.read();
    if (b < 0) break;
    if (b == '\n' || b == '\r') {
      if (cmdLen > 0) { cmdBuf[cmdLen] = '\0'; dispatch(cmdBuf); cmdLen = 0; }
      continue;
    }
    if (cmdLen + 1 < CMD_BUF_SZ) cmdBuf[cmdLen++] = (char)b;
    else { cmdLen = 0; cmdReject("overflow"); }
  }
}

// =============================================================================
// === SECTION 12: SETUP + LOOP ================================================
// =============================================================================

void setup() {
  Serial.begin(115200);
  Serial1.begin(115200);
  unsigned long t0 = millis();
  while (!Serial && millis() - t0 < 5000) {}
  Serial1.println();
  Serial1.println("[boot] Cytron RescueMaze firmware up");

  pinMode(BTN_START, INPUT_PULLUP);
  pinMode(BTN_LOP,   INPUT_PULLUP);

  motorsInit();
  ultrasonicInit();
  ledsInit();
  buttonsInit();

  I2C_BUS.setSDA(18);
  I2C_BUS.setSCL(19);
  I2C_BUS.begin();
  I2C_BUS.setClock(100000);

  Serial.println();
  Serial.println("=== Sensor diagnostic startup ===");
  scanI2CBus();
  scanMuxChannels();
  Serial.println("--- calibration ---");
  calLoaded = loadCalibration();
  Serial.println("--- init ---");
  bnoOK   = initBNO055();
  colorOK = initAS7341();
  frontOK = initSensor(loxFront, CH_FRONT, "Front");
  leftOK  = initSensor(loxLeft,  CH_LEFT,  "Left ");
  rightOK = initSensor(loxRight, CH_RIGHT, "Right");
  backOK  = initSensor(loxBack,  CH_BACK,  "Back ");
  okWFL   = initSensor(loxWFL,   CH_WF_LEFT,  "WF-L ");   // WF2 (VL53L0X)
  okWFR   = initSensor(loxWFR,   CH_WF_RIGHT, "WF-R ");   // WF2 (VL53L0X)
  // WF2 06-10: kick every online ToF into hardware continuous-ranging so the
  // loop can poll results (~1 ms) instead of blocking ~33 ms per sensor.
  if (TOF_CONTINUOUS_ENABLED) {
    if (frontOK) tofStartContinuous(loxFront, CH_FRONT);
    if (leftOK)  tofStartContinuous(loxLeft,  CH_LEFT);
    if (rightOK) tofStartContinuous(loxRight, CH_RIGHT);
    if (backOK)  tofStartContinuous(loxBack,  CH_BACK);
    if (okWFL)   tofStartContinuous(loxWFL,   CH_WF_LEFT);
    if (okWFR)   tofStartContinuous(loxWFR,   CH_WF_RIGHT);
    Serial.println("ToF continuous-ranging mode started (all online sensors)");
  }
  Serial.println("--- summary ---");
  Serial.print("Front ToF: "); Serial.println(frontOK ? "ok" : "FAIL");
  Serial.print("Left  ToF: "); Serial.println(leftOK  ? "ok" : "FAIL");
  Serial.print("Right ToF: "); Serial.println(rightOK ? "ok" : "FAIL");
  Serial.print("Back  ToF: "); Serial.println(backOK  ? "ok" : "FAIL");
  Serial.print("IMU      : "); Serial.println(bnoOK   ? "ok" : "FAIL");
  Serial.print("Color    : "); Serial.println(colorOK ? "ok" : "FAIL");
  Serial.print("Color cal: "); Serial.println(calLoaded ? "loaded" : "missing (fallback)");
  Serial.println("================================");
}

void loop() {
  // --- buttons (tap = pause/resume, 5 s hold = stop/start) ---
  buttonsTick();

  // --- raw sensor reads ---
  // WF2 06-10: tofRead() = continuous-mode poll (~1 ms/sensor) when
  // TOF_CONTINUOUS_ENABLED, else the old blocking single-shot. A stale sensor
  // clears its own ok-flag (self-healing via retryFailedSensors).
  int front = frontOK ? tofRead(loxFront, CH_FRONT, frontOK) : -2;
  int left  = leftOK  ? tofRead(loxLeft,  CH_LEFT,  leftOK)  : -2;
  int right = rightOK ? tofRead(loxRight, CH_RIGHT, rightOK) : -2;
  int back  = backOK  ? tofRead(loxBack,  CH_BACK,  backOK)  : -2;
  // WF2: read the wall-follow ToFs (VL53L0X, ch0 L / ch7 R) every loop so they're
  // live for the debug print below AND fresh for the wall-follow tick. -2 when
  // the sensor failed init (begin() never succeeded), -1 on out-of-range.
  g_usL_mm = okWFL ? tofRead(loxWFL, CH_WF_LEFT,  okWFL) : -2;
  g_usR_mm = okWFR ? tofRead(loxWFR, CH_WF_RIGHT, okWFR) : -2;

  float yaw = 0, roll = 0, pitch = 0;
  uint8_t cSys = 0, cGyro = 0, cAccel = 0, cMag = 0;
  if (bnoOK) {
    tcaSelect(CH_IMU);
    sensors_event_t orient;
    bno.getEvent(&orient);
    yaw   = orient.orientation.x;
    roll  = orient.orientation.y;
    pitch = orient.orientation.z;
    bno.getCalibration(&cSys, &cGyro, &cAccel, &cMag);
  }

  // AS7341 colour. Async path (default): poll the in-flight reading, never
  // block; refresh rate is still ~110 ms (integration time), so the black-tile
  // abort latency is unchanged — the loop just doesn't stall for it anymore.
  // Blocking fallback kept behind COLOR_ASYNC_ENABLED=false. Both paths gate
  // on motionNeedsColor() (skip colour for turns/rams/centering).
  char     colorCh  = g_sensors.color;
  uint32_t colorSum = 0;
  if (colorOK) {
    if (COLOR_ASYNC_ENABLED) {
      colorTickAsync(motionNeedsColor());
      colorCh  = g_colorChAsync;
      colorSum = g_colorSumAsync;
    } else if (motionNeedsColor()) {
      uint16_t cRaw[12] = {0};
      colorCh = readColor(cRaw);
      colorSum = (uint32_t)cRaw[0] + cRaw[1] + cRaw[2] + cRaw[3] +
                 (uint32_t)cRaw[6] + cRaw[7] + cRaw[8] + cRaw[9];
    }
  }

  // --- publish to motion layer ---
  g_sensors.front_mm    = front;
  g_sensors.left_mm     = left;
  g_sensors.right_mm    = right;
  g_sensors.back_mm     = back;
  g_sensors.yaw_deg     = yaw;
  // WF2 06-08 (user): DON'T wait to recalibrate the gyro. Capture a PROVISIONAL
  // g_yawRef0 (RAW frame) from the first valid post-boot yaw after a short settle
  // — no cGyro gate (no hold-still wait). This serves any turns before the first
  // move; the two-sample A/B reconciliation (after the first ram + before the
  // first move) then refines it once. cGyro logged for reference only.
  {
    static const uint32_t YAWREF_SETTLE_MS = 500;
    static uint32_t yawRefStartMs = 0;
    if (bnoOK && !g_yawRefCaptured) {
      if (yawRefStartMs == 0) yawRefStartMs = millis();
      if (millis() - yawRefStartMs > YAWREF_SETTLE_MS) {
        g_yawRef0 = yaw;
        g_yawRefCaptured = true;
        Serial1.print("DIAG YAWREF0 startup raw="); Serial1.print(g_yawRef0, 1);
        Serial1.print(" cGyro="); Serial1.print(cGyro);
        Serial1.println(" (provisional - no cal wait)");
      }
    }
  }
  // WF2 06-08: the per-side wall-follow targets are the FIXED values declared at
  // g_us_wf_target_L / g_us_wf_target_R (L=127, R=96 — different on purpose: the
  // WF sensors read different distances at the correct centred position). Do NOT
  // overwrite them here (an earlier build clobbered both to 100, which made the
  // 2-wall steering drive toward L==R and swerve into a wall even when the bot
  // was on-spec). Just mark captured so a stray CAL_US can't change them.
  if (!g_usWfCaptured) {
    g_usWfCaptured = true;
    Serial1.print("DIAG WFREF fixed target tgtL="); Serial1.print(g_us_wf_target_L);
    Serial1.print(" tgtR=");                         Serial1.println(g_us_wf_target_R);
  }
  g_sensors.pitch_deg   = pitch;
  g_sensors.roll_deg    = roll;
  // Trust the IMU whenever the BNO is online — NO calibration gate (dropped
  // 2026-05-31 per user: the cGyro digit rarely/never flips near the brushed
  // motors, so the old `cGyro != 0` gate blocked turns forever). The gyro
  // gives usable relative-yaw integration even at cal=0 for a quick 90° turn.
  // cSys/cGyro/cAccel/cMag are still read + emitted for telemetry visibility.
  g_sensors.imu_trusted = bnoOK;
  g_sensors.color       = colorOK ? colorCh : '-';
  g_sensors.ts_ms       = millis();

  // --- USB Serial debug (verbose human-readable) ---
  // WF2 06-10: rate-limited. With the fast sensor pipeline the loop runs every
  // ~15 ms; printing ~140 chars over USB every loop is pure overhead. 5 Hz is
  // plenty for a human watching the monitor.
  static uint32_t lastUsbMs = 0;
  if (millis() - lastUsbMs >= USB_DEBUG_INTERVAL_MS) {
    lastUsbMs = millis();
    Serial.print("["); Serial.print(tick); Serial.print("] ");
    Serial.print("F:");  Serial.print(front); Serial.print("mm ");
    Serial.print("L:");  Serial.print(left);  Serial.print("mm ");
    Serial.print("R:");  Serial.print(right); Serial.print("mm ");
    Serial.print("B:");  Serial.print(back);  Serial.print("mm ");
    Serial.print("WFL:"); Serial.print(g_usL_mm); Serial.print("mm ");   // VL53L0X ch0
    Serial.print("WFR:"); Serial.print(g_usR_mm); Serial.print("mm | "); // VL53L0X ch7
    if (bnoOK) {
      Serial.print("Y:"); Serial.print(yaw,   1);
      Serial.print(" P:"); Serial.print(pitch, 1);
      Serial.print(" R:"); Serial.print(roll,  1);
      Serial.print("deg cal:");
      Serial.print(cSys); Serial.print(cGyro); Serial.print(cAccel); Serial.print(cMag);
    } else Serial.print("IMU offline");
    Serial.print(" | ");
    if (colorOK) {
      Serial.print("Col:"); Serial.print(colorCh);
      Serial.print(" sum:"); Serial.print(colorSum);
    } else Serial.print("Color offline");
    Serial.print(" | state:"); Serial.print(runStateChar(g_runState));
    Serial.print(" busy:"); Serial.print(motionIsBusy() ? 1 : 0);
    Serial.println();
  }

  // --- compact telemetry to Pi ---
  // ok=FLRBIC where each char is '1' (online) / '0' (offline). The Pi parses
  // this and renders a health panel; combined with the periodic retry above,
  // sensors that drop out can come back without a reboot.
  // WF2 06-10: rate-limited to TELEM_INTERVAL_MS (20 Hz — MORE than the old
  // effective 5-15 Hz, but no longer once per loop: a ~130-char line at 115200
  // baud blocks ~11 ms, which would have eaten the fast loop alive). tick now
  // counts EMITTED telemetry lines.
  static uint32_t lastTelemMs = 0;
  if (millis() - lastTelemMs >= TELEM_INTERVAL_MS) {
    lastTelemMs = millis();
    char okStr[7];
    okStr[0] = frontOK ? '1' : '0';
    okStr[1] = leftOK  ? '1' : '0';
    okStr[2] = rightOK ? '1' : '0';
    okStr[3] = backOK  ? '1' : '0';
    okStr[4] = bnoOK   ? '1' : '0';
    okStr[5] = colorOK ? '1' : '0';
    okStr[6] = '\0';

    char buf[240];
    snprintf(buf, sizeof(buf),
             "tick=%lu F=%d L=%d R=%d B=%d Y=%d P=%d R=%d cal=%d%d%d%d col=%c sum=%lu state=%c busy=%d ok=%s uL=%d uR=%d case=%s",
             (unsigned long)tick,
             front, left, right, back,
             bnoOK ? (int)yaw   : -999,
             bnoOK ? (int)pitch : -999,
             bnoOK ? (int)roll  : -999,
             cSys, cGyro, cAccel, cMag,
             colorOK ? colorCh : '-',
             (unsigned long)colorSum,
             runStateChar(g_runState),
             motionIsBusy() ? 1 : 0,
             okStr,
             g_usL_mm, g_usR_mm,
             motionCaseName());
    // Plain blocking write. (A 2026-05-31 availableForWrite() guard here once
    // suppressed ALL telemetry — on this core availableForWrite() caps at the
    // 32 B hardware FIFO, so it never reported room for a ~130 B line. Don't
    // re-add it.) If a Pi brown-out under ram current ever stops draining the
    // UART, this CAN block the loop — fix the power (§9), don't band-aid here.
    Serial1.println(buf);
    tick++;
  }

  // --- advance motion / commands / LEDs / health retry ---
  motionTick();
  // WF3: chained-move coast expiry — if a "MOVE_TILE C" ACKed and no follow-up
  // command arrived in time, stop rolling. (Any motion command that DID arrive
  // owns the motors already; this only fires while genuinely idle.)
  if (motion.state == MS_IDLE && g_coastUntilMs != 0 && millis() > g_coastUntilMs) {
    motorsAllStop();
    g_coastUntilMs = 0;
    Serial1.println("DIAG chain coast expired -> stopped");
  }
  commandsTick();
  ledsTick();
  retryFailedSensors();

  delay(5);
}
