// === AS7341 COLOR CALIBRATION SKETCH ===
//
// Walks the user through capturing reference readings for each Rescue-Maze
// floor color (black, white, silver, blue, red) and writes them to the
// RP2350's emulated EEPROM in flash. The main diagnostic / competition sketch
// reads the same struct back and uses it for classification.
//
// User interface:
//   - Button on GP21 (active low, internal pull-up) advances to the next step
//   - 2 NeoPixels on GP23 give the cue for what color to place under the sensor:
//        2 white flashes  -> BLACK
//        1 white flash    -> WHITE (normal floor)
//        3 white flashes  -> SILVER (checkpoint)
//        2 blue  flashes  -> BLUE  (puddle / stop-5s tile)
//        2 red   flashes  -> RED   (danger-zone entrance)
//     Each pattern loops until the button is pressed. While the sensor is
//     reading samples the pixels go purple; after a sample is captured they
//     flash green. On final save: rainbow + solid green if EEPROM write
//     succeeds, looping red if it fails.
//
// Same hardware/wiring as the diagnostic sketch:
//   PCA9548A on I2C1 (SDA=GP18, SCL=GP19), AS7341 on mux ch 5 at 0x39.

#include <Wire.h>
#include <Adafruit_AS7341.h>
#include <Adafruit_NeoPixel.h>
#include <EEPROM.h>

#define I2C_BUS         Wire1
#define PCA9548A_ADDR   0x70
#define AS7341_ADDR     0x39
#define CH_COLOR        5

#define BTN_PIN         21
#define NEOPIXEL_PIN    23
#define NUM_PIXELS      2   // Cytron Motion 2350 Pro onboard pixel count

#define SAMPLES_PER_COLOR 30
#define SAMPLE_INTERVAL_MS 50

// ====== Calibration storage format ======
// IMPORTANT: keep this struct in sync with the matching definition at the top
// of ToF_Sensors.ino. If you change layout, bump CAL_VERSION on both sides.
#define CAL_MAGIC   0xCA110055UL
#define CAL_VERSION 2   // bumped when AS7341 ATIME/ASTEP changed (v1 -> v2)

struct ColorRef {
  uint32_t sum;    // F1+F2+F3+F4+F5+F6+F7+F8
  uint32_t blue;   // F2 + F3
  uint32_t red;    // F7 + F8
};

struct CalibrationData {
  uint32_t magic;
  uint16_t version;
  uint16_t _pad;
  ColorRef black;
  ColorRef white;
  ColorRef silver;
  ColorRef blueRef;
  ColorRef redRef;
};

Adafruit_AS7341  color;
Adafruit_NeoPixel pixels(NUM_PIXELS, NEOPIXEL_PIN, NEO_GRB + NEO_KHZ800);
CalibrationData  cal;

// --- helpers -----------------------------------------------------------------

void tcaSelect(uint8_t channel) {
  if (channel > 7) return;
  I2C_BUS.beginTransmission(PCA9548A_ADDR);
  I2C_BUS.write(1 << channel);
  I2C_BUS.endTransmission();
}

void setAll(uint8_t r, uint8_t g, uint8_t b) {
  for (int i = 0; i < NUM_PIXELS; i++) pixels.setPixelColor(i, r, g, b);
  pixels.show();
}

bool pressed() {
  return digitalRead(BTN_PIN) == LOW;
}

void debouncedWaitForRelease() {
  delay(40);
  while (pressed()) delay(10);
  delay(40);
}

// Flashes `count` times in given color, OR returns early if the button is
// pressed during the flash.
bool flashPattern(uint8_t r, uint8_t g, uint8_t b, int count) {
  for (int i = 0; i < count; i++) {
    setAll(r, g, b);
    for (int t = 0; t < 25; t++) { if (pressed()) return true; delay(10); }
    setAll(0, 0, 0);
    for (int t = 0; t < 20; t++) { if (pressed()) return true; delay(10); }
  }
  return false;
}

void waitForButtonWithPattern(uint8_t r, uint8_t g, uint8_t b, int count) {
  while (!pressed()) {
    if (flashPattern(r, g, b, count)) break;
    // small gap before repeating the pattern
    for (int t = 0; t < 40; t++) { if (pressed()) break; delay(10); }
  }
  debouncedWaitForRelease();
}

bool initColorSensor() {
  tcaSelect(CH_COLOR);
  delay(10);
  if (!color.begin(AS7341_ADDR, &I2C_BUS)) return false;
  // Must match ToF_Sensors.ino exactly so the reference fingerprints
  // captured here are numerically comparable to live diagnostic readings.
  color.setATIME(29);
  color.setASTEP(599);
  color.setGain(AS7341_GAIN_256X);
  color.setLEDCurrent(40);
  color.enableLED(true);
  return true;
}

// Take SAMPLES_PER_COLOR readings, average sum/blue/red bands into `out`.
void sampleColor(ColorRef &out) {
  uint64_t sumAcc = 0, blueAcc = 0, redAcc = 0;
  uint16_t r[12];
  int valid = 0;
  setAll(40, 0, 40);  // purple while reading
  for (int i = 0; i < SAMPLES_PER_COLOR; i++) {
    tcaSelect(CH_COLOR);
    if (color.readAllChannels(r)) {
      sumAcc  += (uint32_t)r[0] + r[1] + r[2] + r[3] +
                 (uint32_t)r[6] + r[7] + r[8] + r[9];
      blueAcc += (uint32_t)r[1] + r[2];
      redAcc  += (uint32_t)r[8] + r[9];
      valid++;
    }
    delay(SAMPLE_INTERVAL_MS);
  }
  if (valid == 0) {
    out.sum = out.blue = out.red = 0;
  } else {
    out.sum  = (uint32_t)(sumAcc  / valid);
    out.blue = (uint32_t)(blueAcc / valid);
    out.red  = (uint32_t)(redAcc  / valid);
  }
  setAll(0, 60, 0);    // green = done with this color
  delay(600);
  setAll(0, 0, 0);
}

void calibrateOne(const char *name, ColorRef &ref,
                  uint8_t r, uint8_t g, uint8_t b, int flashCount) {
  Serial.print("\n=== ");
  Serial.print(name);
  Serial.println(" ===");
  Serial.print("Place sensor over the ");
  Serial.print(name);
  Serial.println(" surface, then press the GP21 button.");
  waitForButtonWithPattern(r, g, b, flashCount);
  Serial.println("Reading samples...");
  sampleColor(ref);
  Serial.print("  -> sum=");  Serial.print(ref.sum);
  Serial.print("  blue=");    Serial.print(ref.blue);
  Serial.print("  red=");     Serial.println(ref.red);
}

// --- main -------------------------------------------------------------------

void setup() {
  Serial.begin(115200);
  unsigned long t0 = millis();
  while (!Serial && millis() - t0 < 4000) { }

  pinMode(BTN_PIN, INPUT_PULLUP);

  pixels.begin();
  pixels.setBrightness(60);
  setAll(0, 0, 0);

  I2C_BUS.setSDA(18);
  I2C_BUS.setSCL(19);
  I2C_BUS.begin();
  I2C_BUS.setClock(100000);

  Serial.println("\n=== AS7341 calibration ===");
  if (!initColorSensor()) {
    Serial.println("FAIL: AS7341 not detected on mux ch 5.");
    while (1) { setAll(80, 0, 0); delay(400); setAll(0,0,0); delay(400); }
  }
  Serial.println("AS7341 ready.");
  Serial.println("Press the GP21 button to begin walking through the colors.");

  // Purple = waiting to start
  while (!pressed()) {
    setAll(20, 0, 20); delay(400);
    setAll(0, 0, 0);   delay(400);
  }
  debouncedWaitForRelease();

  cal.magic   = CAL_MAGIC;
  cal.version = CAL_VERSION;

  // Patterns chosen per user spec:
  //   2 white flashes -> black, 1 white -> normal/white, 3 white -> silver,
  //   2 blue -> blue, 2 red -> red
  calibrateOne("BLACK",  cal.black,   255, 255, 255, 2);
  calibrateOne("WHITE",  cal.white,   255, 255, 255, 1);
  calibrateOne("SILVER", cal.silver,  255, 255, 255, 3);
  calibrateOne("BLUE",   cal.blueRef,   0,   0, 255, 2);
  calibrateOne("RED",    cal.redRef,  255,   0,   0, 2);

  // Save
  Serial.println("\nSaving calibration to flash-EEPROM...");
  EEPROM.begin(sizeof(CalibrationData) + 16);
  EEPROM.put(0, cal);
  bool ok = EEPROM.commit();
  if (ok) {
    Serial.println("OK: calibration written.");
    Serial.println("Summary:");
    auto pr = [](const char *n, const ColorRef &c) {
      Serial.print("  "); Serial.print(n);
      Serial.print(": sum="); Serial.print(c.sum);
      Serial.print(" blue="); Serial.print(c.blue);
      Serial.print(" red=");  Serial.println(c.red);
    };
    pr("black ", cal.black);
    pr("white ", cal.white);
    pr("silver", cal.silver);
    pr("blue  ", cal.blueRef);
    pr("red   ", cal.redRef);

    // Brief rainbow then steady green to indicate done.
    for (int i = 0; i < 360; i += 6) {
      uint32_t c = pixels.ColorHSV(i * 182);   // 182 ~= 65535/360
      uint8_t rr = (c >> 16) & 0xFF;
      uint8_t gg = (c >>  8) & 0xFF;
      uint8_t bb = (c >>  0) & 0xFF;
      setAll(rr, gg, bb);
      delay(20);
    }
    setAll(0, 80, 0);
  } else {
    Serial.println("FAIL: EEPROM commit failed.");
    Serial.println("Calibration was NOT persisted. Re-run the sketch.");
    while (1) {
      setAll(120, 0, 0); delay(300);
      setAll(0, 0, 0);   delay(300);
    }
  }
}

void loop() {
  // Calibration is one-shot. Stay in steady-green so the user knows it ended cleanly.
  delay(1000);
}
