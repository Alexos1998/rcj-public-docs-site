# Edge Impulse - OpenMV FOMO Object Detection Example
#
# This work is licensed under the MIT license.
# Copyright (c) 2013-2024 OpenMV LLC. All rights reserved.
# https://github.com/openmv/openmv/blob/master/LICENSE

import sensor, image, time, ml, math, uos, gc
from pyb import Pin, Timer
from pyb import UART
sensor.reset()                         # Reset and initialize the sensor.
sensor.set_pixformat(sensor.RGB565)    # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QQVGA)      # Set frame size to QVGA (320x240)
sensor.set_windowing((240, 240))       # Set 240x240 window.
sensor.skip_frames(time=2000)
sensor.set_vflip(True)  # 垂直翻转
sensor.set_hmirror(True)  # 水平翻转# Let the camera adjust.

uart = UART(3, 115200, timeout_char=200)
light = Timer(2, freq=50000).channel(1, Timer.PWM, pin=Pin("P6"))
light.pulse_width_percent(0)
n =None
net =min_circle= None
labels = None
min_confidence = 0.3
black_threshold=(0, 49, -25, 8, -19, 20)
rd = 255#randint(0, 127) + 128
gd = 255#randint(0, 127) + 128
bd = 255#randint(0, 127) + 128
labe = (60,60,100,90)
try:
    # load the model, alloc the model file on the heap if we have at least 64K free after loading
    net = ml.Model("trained.tflite", load_to_fb=uos.stat('trained.tflite')[6] > (gc.mem_free() - (64*1024)))
except Exception as e:
    raise Exception('Failed to load "trained.tflite", did you copy the .tflite and labels.txt file onto the mass-storage device? (' + str(e) + ')')

try:
    labels = [line.rstrip('\n') for line in open("labels.txt")]
except Exception as e:
    raise Exception('Failed to load "labels.txt", did you copy the .tflite and labels.txt file onto the mass-storage device? (' + str(e) + ')')

colors = [ # Add more colors if you are detecting more than 7 types of classes at once.
    (255,   0,   0),
    (  0, 255,   0),
    (255, 255,   0),
    (  0,   0, 255),
    (255,   0, 255),
    (  0, 255, 255),
    (255, 255, 255),
]

threshold_list = [(math.ceil(min_confidence * 255), 255)]
def draw():
    img.draw_line(labe[0], 0, labe[0], 120, color=(rd, gd, bd), thickness=1)
    img.draw_line(labe[2], 0, labe[2], 120, color=(rd, gd , bd), thickness=1)
    img.draw_line(labe[0], labe[1], labe[2], labe[1], color=(rd, gd, bd), thickness=1)
    img.draw_line(0, labe[3], 160, labe[3], color=(rd, gd, bd), thickness=1)
def ball():

    if x>labe[0] and x<labe[2] and y<=labe[3]and y>=labe[1]:
        print(1)
        uart.writechar(1)
    elif y>=labe[3]:
        print(4)#左上
        uart.writechar(4)
    elif x>=labe[2]:
        print(5)#左下
        uart.writechar(5)
    elif x>labe[0] and x<labe[2] and y<labe[1]:
        print(3)#中上
        uart.writechar(3)
    elif x<=labe[0]:
        print(2)#中上
        uart.writechar(2)

def fomo_post_process(model, inputs, outputs):
    ob, oh, ow, oc = model.output_shape[0]

    x_scale = inputs[0].roi[2] / ow
    y_scale = inputs[0].roi[3] / oh

    scale = min(x_scale, y_scale)

    x_offset = ((inputs[0].roi[2] - (ow * scale)) / 2) + inputs[0].roi[0]
    y_offset = ((inputs[0].roi[3] - (ow * scale)) / 2) + inputs[0].roi[1]

    l = [[] for i in range(oc)]

    for i in range(oc):
        img = image.Image(outputs[0][0, :, :, i] * 255)
        blobs = img.find_blobs(
            threshold_list, x_stride=1, y_stride=1, area_threshold=1, pixels_threshold=1
        )
        for b in blobs:
            rect = b.rect()
            x, y, w, h = rect
            score = (
                img.get_statistics(thresholds=threshold_list, roi=rect).l_mean() / 255.0
            )
            x = int((x * scale) + x_offset)
            y = int((y * scale) + y_offset)
            w = int(w * scale)
            h = int(h * scale)
            l[i].append((x, y, w, h, score))
    return l

clock = time.clock()
while(True):

    if uart.any():
        n = uart.read()
    img = sensor.snapshot()
    if n == b'\x01':

        light = Timer(2, freq=50000).channel(1, Timer.PWM, pin=Pin("P6"))
        light.pulse_width_percent(100)
        if uart.any():
            n = uart.read()
        best_detection = None
        max_y = -1
        best_label = None
        best_color = None

            # 逐類別處理偵測結果
        for i, detection_list in enumerate(net.predict([img], callback=fomo_post_process)):
            if i == 0:
                continue  # 跳過背景
            if len(detection_list) == 0:
                continue  # 沒有偵測結果

            for x, y, w, h, score in detection_list:
                center_y = math.floor(y + (h / 2))
                if center_y > max_y:
                        max_y = center_y
                        best_detection = (x, y, w, h)
                        best_label = labels[i]
                        best_color = colors[i]

            # 如果有找到最大 Y 的物件，就畫出並傳座標
            if best_detection and best_label=='sliver':
                x1, y1, w, h = best_detection
                x = math.floor(x1 + w / 2)
                y = math.floor(y1 + h / 2)
                print(f"x={x}\ty={y}\t{best_label}")
                img.draw_circle((x, y, w), color=best_color)
                ball()  # 呼叫你原本的 UART 傳送函數
        draw()

    while(n==b'\x02'):
        img = sensor.snapshot()
        min_circle=None
        light = Timer(2, freq=50000).channel(1, Timer.PWM, pin=Pin("P6"))
        light.pulse_width_percent(100)
        if uart.any():
            n = uart.read()
        for c in img.find_circles(threshold = 3000, x_margin = 10, y_margin = 10, r_margin = 10,
                r_min = 10, r_max = 23, r_step = 2):

            if min_circle is None:
                min_circle = c
            elif c.y() > min_circle.y():
                min_circle = c
            #print(c)
        #print(max_circle)


        if min_circle:
            r = min_circle.r()
            blob = img.find_blobs([black_threshold],pixels_threshold=500,area_threshold=500,merge=True,roi = (min_circle.x()-r,min_circle.y()-r,r*2,r*2))
            if blob:

                img.draw_circle(min_circle.x(), min_circle.y(), min_circle.r(), color = (255, 0, 0))

                y = min_circle.y()
                x = min_circle.x()

                r = min_circle.r()
                ball()
                img.draw_line(x-r,y,x+r,y, color=(0, 0, 255), thickness=1)
                img.draw_line(x,y-r,x,y+r, color=(0, 255, 0), thickness=1)
        draw()

    if n==b'\x03':

        light = Timer(2, freq=50000).channel(1, Timer.PWM, pin=Pin("P6"))
        light.pulse_width_percent(0)
        if uart.any():
            n = uart.read()

    if n==b'\x04':

        light = Timer(2, freq=50000).channel(1, Timer.PWM, pin=Pin("P6"))
        light.pulse_width_percent(100)
        if uart.any():
            n = uart.read()



    #print(clock.fps(), "fps", end="\n\n")
