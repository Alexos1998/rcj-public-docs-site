#ifndef _CROSS_SUB_
#define _CROSS_SUB_
#include <stm32f4xx.h>
#include <SetTenthS.h>
#include <SetMotor2.h>
#include <SetInMusicStop.h>
#include <SetCentiS.h>
#include <SetInBeep.h>


#include "HardwareInfo.c"
#include "turn_around_sub.c"
#include "green_right_sub.c"
#include "green_left_sub.c"
#include "line_sub.c"
void cross_sub()
{
    // extern global var
    extern double I3;
    extern double I4;
    extern double I5;
    extern double I6;
    extern double I7;
    extern double I8;
    extern long COLOR1;
    extern long COLOR2;
    extern double speed;
    extern double ERROR1;
    extern double ERROR2;
    extern double KP;
    extern double KD;
    extern double PD_VAL;
    extern double SPEED;
    extern double M1;
    extern double M2;
    extern double I1;
    extern double I2;
    extern long TIME;

    long LA = 0;
    long RA = 0;
      COLOR1=GetColorSensor( _COLOR_1_,1 ,4 );
      COLOR2=GetColorSensor( _COLOR_2_,1 ,4 );
     
    if ( COLOR1==2&&COLOR2==2 )
    {
            for (int _FOR_1_ = 0; _FOR_1_ < 2; _FOR_1_++ )
            {
                SetInBeep(1);
                SetTenthS(1);
                SetInMusicStop();
                SetTenthS(1);
            }  
        turn_around_sub();
    }
    else
    {
        if ( COLOR2==2&&COLOR1!=2 )
        {
                SetInBeep(1);
                SetTenthS(1);
                SetInMusicStop();
                   
            green_right_sub();
        }
        else
        {
            if ( COLOR1==2 )
            {
                    SetInBeep(1);
                    SetTenthS(1);
                    SetInMusicStop();
                       
                green_left_sub();
            }
            else
            {
                line_sub();
            }
        }
    }
}
#endif

