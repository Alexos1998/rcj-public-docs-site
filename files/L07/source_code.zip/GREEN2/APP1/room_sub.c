#ifndef _ROOM_SUB_
#define _ROOM_SUB_
#include <stm32f4xx.h>
#include <SetMotor2.h>
#include <SetTenthS.h>

#include "HardwareInfo.c"
#include <GetCompassB.h>
#include <GetData.h>
#include "turnleft_angle.c"
#include "turnright_angle.c"
#include <SetTenthS.h>
#include <SetUartData.h>
#include <GetUartData.h>
#include <SetLCDClear.h>
#include "lookball_sub.c"
#include <SetNS.h>
#include <SetInBeep.h>
#include "lookball2_sub.c"
#include "Exit_Right_sub.c"
#include "Exit_Lift_sub.c"
void room_sub()
{
    // extern global var
    extern double ANGLE1;
    extern long ball;
    extern int ball1;
    extern long ball2;
    extern long ball22;
    extern long B;
    extern long distance1;
    extern long distance2;
    extern long distance3;
    extern long distance4;
    extern long distance5;
    extern long TOUCH1;
    extern long TOUCH2;
    extern long TOUCH3;
    extern long TOUCH4;
    extern long TOUCH5;
    extern long TOUCH6;
    extern long TOUCH7;
    extern double I5;
    extern long ENT;
    extern long SilverBall;
    extern long BlackBall;
    extern long BlackBallOK;
    extern long SilverBallOK;
    extern long V;
    extern double I4;
    extern long Q;

    double ANGLE = 0;
    int i = 0;
    long A = 0;
    long time = 0;
    ANGLE = GetCompassB(_COMPASS_1_);
    B=2;
    ANGLE1 = GetData(B);
    if ( ANGLE<90 )
    {
        turnleft_angle();
    }
    else
    {
        if ( ANGLE>270 )
        {
            turnright_angle();
        }
        else
        {
            turnleft_angle();
        }
    }
        SetMotor2(1, 70);
        SetMotor2(2, 70);
    SetTenthS(13);
        SetMotor2(1, 0);
        SetMotor2(2, 0);
    
    B=3;
    ANGLE1 = GetData(B);
    turnright_angle();
    SetUartData(1, 1, 6);
    SetUartData(2, 4, 6);
        SetMotor2(  1 , 50 );
        SetMotor2(  2 , 50 );
    SetTenthS(10);
        SetMotor2(  1 , -50 );
        SetMotor2(  2 , -50 );
    SetTenthS(3);
        time=0;
        SetMotor2(  1 , 0 );
        SetMotor2(  2 , 0 );
    for (int _FOR_1_ = 0; _FOR_1_ < 500; _FOR_1_++ )
    {
        ball1 = GetUartData(1, 6);
    }
        time=0;
        ball=0;
        ball1=0;
        V=0;
        SetMotor2(  1 , 0 );
        SetMotor2(  2 , 0 );
    SetLCDClear(BLACK);
    while ( !GetGpioState(_COMPASS_11_,1,1) )
    {
        ball1 = GetUartData(1, 6);
        if ( ball1>0&&ball1<10 )
        {
            SetMotor2(  1 , 0 );
            SetMotor2(  2 , 0 );
            
            SetTenthS(2);
            break;
        }
        else
        {
            SetMotor2(  1 , 40 );
            SetMotor2(  2 , -40 );
            
        }
    }
    while ( !GetGpioState(_COMPASS_11_,1,1) )
    {
        Sysdelayus(100);
        time++;
        if ( time>=100000 )
        {
            ball=0;
            break;
        }
        else
        {
            SetMotor2(  1 , 40 );
            SetMotor2(  2 , -40 );
            
            lookball_sub();
            if ( V==1 )
            {
                break;
            }
        }
    }
    while ( !GetGpioState(_COMPASS_11_,1,1) )
    {
        B=3;
        ANGLE1 = GetData(B);
        turnright_angle();
        SetUartData(1, 1, 6);
        SetUartData(2, 4, 6);
        SetNS(1);
            time=0;
            ball=0;
            ball1=0;
            V=0;
            SetMotor2(  1 , 0 );
            SetMotor2(  2 , 0 );
        for (int _FOR_0_ = 0; _FOR_0_ < 500; _FOR_0_++ )
        {
            ball1 = GetUartData(1, 6);
        }
            time=0;
            ball=0;
            ball1=0;
            V=0;
            SetMotor2(  1 , 0 );
            SetMotor2(  2 , 0 );
        SetLCDClear(BLACK);
        while ( !GetGpioState(_COMPASS_11_,1,1) )
        {
            ball1 = GetUartData(1, 6);
            if ( ball1>0&&ball1<4 )
            {
                SetMotor2(  1 , 0 );
                SetMotor2(  2 , 0 );
                
                SetTenthS(2);
                break;
            }
            else
            {
                SetMotor2(  1 , 40 );
                SetMotor2(  2 , -40 );
                
            }
        }
        while ( !GetGpioState(_COMPASS_11_,1,1) )
        {
            Sysdelayus(100);
            time++;
            if ( time>=1000000 )
            {
                ball=0;
                break;
            }
            else
            {
                SetMotor2(  1 , 40 );
                SetMotor2(  2 , -40 );
                
                lookball_sub();
                if ( V==1 )
                {
                    break;
                }
            }
        }
        if ( SilverBallOK>=2 )
        {
            SetMotor2(  1 , 0 );
            SetMotor2(  2 , 0 );
            
            break;
        }
    }
    B=3;
    ANGLE1 = GetData(B);
    turnright_angle();
    SetUartData(1, 2, 6);
    SetUartData(2, 4, 6);
    SetNS(1);
        time=0;
        ball=0;
        ball1=0;
        V=0;
        SetMotor2(  1 , 0 );
        SetMotor2(  2 , 0 );
    for (int _FOR_2_ = 0; _FOR_2_ < 500; _FOR_2_++ )
    {
        ball1 = GetUartData(1, 6);
    }
        time=0;
        ball=0;
        ball1=0;
        V=0;
        SetMotor2(  1 , 0 );
        SetMotor2(  2 , 0 );
    SetLCDClear(BLACK);
    while ( !GetGpioState(_COMPASS_11_,1,1) )
    {
        ball1 = GetUartData(1, 6);
        if ( ball1>0&&ball1<4 )
        {
            SetMotor2(  1 , 0 );
            SetMotor2(  2 , 0 );
            
            SetTenthS(2);
            break;
        }
        else
        {
            SetMotor2(  1 , 40 );
            SetMotor2(  2 , -40 );
            
        }
    }
    SetInBeep(1);
    while ( !GetGpioState(_COMPASS_11_,1,1) )
    {
        Sysdelayus(100);
        time++;
        if ( time>=1000000 )
        {
            ball=0;
            break;
        }
        else
        {
            SetMotor2(  1 , 40 );
            SetMotor2(  2 , -40 );
            
            lookball2_sub();
            if ( BlackBallOK>0 )
            {
                break;
            }
        }
    }
    SetNS(2);
    Q = GetData(1);
    if ( Q==1 )
    {
        Exit_Right_sub();
    }
    else
    {
        Exit_Lift_sub();
    }
}
#endif

