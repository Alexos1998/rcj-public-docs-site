#ifndef _TURN_AROUND_SUB_
#define _TURN_AROUND_SUB_
#include <stm32f4xx.h>
#include <GetColorSensor.h>
#include <SetTenthS.h>
#include <SetMotor2.h>
#include <SetInMusicStop.h>
#include <SetCentiS.h>
#include <SetInBeep.h>


#include "HardwareInfo.c"
#include <SetCentiS.h>
#include <SetTenthS.h>
#include "line2_sub.c"
void turn_around_sub()
{
    // extern global var
    extern double I3;
    extern double I4;
    extern double I5;
    extern double I6;
    extern double I7;
    extern double I8;
    extern long COLOR1;
    extern long COLOR2;
    extern double speed;
    extern double ERROR1;
    extern double ERROR2;
    extern double KP;
    extern double KD;
    extern double PD_VAL;
    extern double SPEED;
    extern double M1;
    extern double M2;
    extern double I1;
    extern double I2;
    extern long time;

    long LA = 0;
    long RA = 0;
        SetMotor2( 1 ,50 ) ;
        SetMotor2( 2 ,50 ) ;
        
    SetCentiS(10);
        SetMotor2( 1 ,60 ) ;
        SetMotor2( 2 ,-60 ) ;
        
    SetTenthS(11);
    for (int _FOR_0_ = 0; _FOR_0_ < 1500; _FOR_0_++ )
    {
        line2_sub();
    }
}
#endif

