#ifndef _PINCHBALL_SUB_
#define _PINCHBALL_SUB_
#include <stm32f4xx.h>
#include <SetMotor2.h>
#include "JMDKernel.h"


#include "HardwareInfo.c"
#include <SetServo.h>
#include <SetTenthS.h>
#include "touch_sub.c"
#include <SetInSound.h>
#include <SetInBeep.h>
#include <SetInMusicStop.h>
void PinchBall_sub()
{
    // extern global var
    extern long TOUCH6;
    extern long SilverBall;
    extern long BlackBall;
    extern long TOUCH7;
    extern long TOUCH1;
    extern long TOUCH2;
    extern long TOUCH3;
    extern long TOUCH4;
    extern long TOUCH5;

    SetServo(_SERVO_1_, 90);
    SetTenthS(2);
    SetServo(_SERVO_2_, 40);
    SetTenthS(3);
    SetServo(_SERVO_1_, 137);
    SetTenthS(10);
    SetMotor2( 1 ,40 );
    SetMotor2( 2 ,40 );
    
    SetTenthS(7);
    SetMotor2( 1 ,0 );
    SetMotor2( 2 ,0 );
    
    SetServo(_SERVO_2_, 22);
    SetTenthS(10);
    SetMotor2( 1 ,-30 );
    SetMotor2( 2 ,-30 );
    
    SetTenthS(11);
    SetMotor2( 1 ,0 );
    SetMotor2( 2 ,0 );
    
    SetServo(_SERVO_2_, 2);
    SetTenthS(10);
    SetServo(_SERVO_1_, 22);
    SetTenthS(8);
    touch_sub();
    if ( TOUCH5==0 )
    {
        SilverBall=SilverBall+1;
        SetInSound(440, 100);
        SetServo(_SERVO_2_, 17);
    }
    else
    {
        if ( TOUCH4==0 )
        {
            SetInBeep(ON);
            SetTenthS(5);
            SetInMusicStop();
            SetServo(_SERVO_2_, 40);
        }
        else
        {
            BlackBall=BlackBall+1;
            SetServo(_SERVO_2_, 17);
        }
    }
}
#endif

