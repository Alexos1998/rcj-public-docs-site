#ifndef _EXIT_RIGHT_SUB_
#define _EXIT_RIGHT_SUB_
#include <stm32f4xx.h>
#include <GetADScable10.h>
#include <GetColorSensor.h>
#include <SetTenthS.h>
#include <SetMotor2.h>
#include <SetInMusicStop.h>
#include <SetCentiS.h>
#include <SetInBeep.h>

#include "HardwareInfo.c"
#include <GetData.h>
#include "turnleft_angle.c"
#include "touch_sub.c"
#include "turnright_angle.c"
#include <GetADScable10.h>
#include "JMSub2.c"
#include "JMSub3.c"
void Exit_Right_sub()
{
    // extern global var
    extern double ANGLE1;
    extern long ball;
    extern int ball1;
    extern long ball2;
    extern long ball22;
    extern long B;
    extern long distance1;
    extern long distance2;
    extern long distance3;
    extern long distance4;
    extern long distance5;
    extern long TOUCH1;
    extern long TOUCH2;
    extern long TOUCH3;
    extern long TOUCH4;
    extern long TOUCH5;
    extern long TOUCH6;
    extern long TOUCH7;
    extern double I5;
    extern long ENT;
    extern long SilverBall;
    extern long BlackBall;
    extern long SilverBallOk;
    extern long BlackBallOk;
    extern double I4;
    extern double Exit;
    extern double I2;
    extern double I3;

    double ANGLE = 0;
    int i = 0;
    long A = 0;
    B=2;
    ANGLE1 = GetData(B);
    turnleft_angle();
    while ( !GetGpioState(_COMPASS_11_,1,1) )
    {
        touch_sub();
        if ( TOUCH2==1||TOUCH3==1 )
        {
            SetMotor2(1,-40 );
            SetMotor2(2,-40 );
            SetTenthS(2);
            SetMotor2(  1 , 0 );
            SetMotor2(  2 , 0 );
            
            break;
        }
        else
        {
            SetMotor2(  1 , 40 );
            SetMotor2(  2 , 40 );
            
            
            
        }
    }
    B=3;
    ANGLE1 = GetData(B);
    turnright_angle();
    while ( !GetGpioState(_COMPASS_11_,1,1) )
    {
        I4 = GetADScable10(_SCABLEAD_4_);
        touch_sub();
        SetMotor2(  1 , 40 );
        SetMotor2(  2 , 40 );
        
        if ( I4>=700 )
        {
            SetMotor2(  1 , 40 );
            SetMotor2(  2 , -40 );
            SetTenthS(6);
            SetMotor2(  1 , 0 );
            SetMotor2(  2 , 0 );
            
            
            Exit=1;
            break;
        }
        else
        {
            if ( TOUCH2==1||TOUCH3==1 )
            {
                SetMotor2(  1 , 0 );
                SetMotor2(  2 , 0 );
                
                break;
            }
        }
    }
    while ( !GetGpioState(_COMPASS_11_,1,1) )
    {
        touch_sub();
        if ( TOUCH2==1||TOUCH3==1 )
        {
            SetMotor2(  1 , -40 );
            SetMotor2(  2 , -40 );
            SetTenthS(5);
            SetMotor2( 1 , 40 );
            SetMotor2( 2 , -40 );
            SetTenthS(5);
            SetMotor2(  1 , 0 );
            SetMotor2(  2 , 0 );
            
            
        }
        else
        {
            JMSub2();
            JMSub3();
            if (  distance2>=32&& distance3>=32 )
            {
                SetMotor2(  1 , 40 );
                SetMotor2(  2 , 40 );
                SetTenthS(3);
                SetMotor2(  1 , 0 );
                SetMotor2(  2 , 0 );
                
                
                break;
            }
            else
            {
                I2 = GetADScable10(_SCABLEAD_2_);
                I3 = GetADScable10(_SCABLEAD_3_);
                if ( I2>=700||I3>=700 )
                {
                    SetMotor2(  1 , 40 );
                    SetMotor2(  2 , -40 );
                    SetTenthS(5);
                    SetMotor2(  1 , 0 );
                    SetMotor2(  2 , 0 );
                    
                    
                    break;
                }
                else
                {
                    if ( Exit==1 )
                    {
                        break;
                    }
                    else
                    {
                        SetMotor2(  1 , 40 );
                        SetMotor2(  2 , 40 );
                        SetTenthS(3);
                    }
                }
            }
        }
    }
    B=2;
    ANGLE1 = GetData(B);
    turnright_angle();
    SetMotor2(  1 , 0 );
    SetMotor2(  2 , 0 );
    SetTenthS(500000);
}
#endif

