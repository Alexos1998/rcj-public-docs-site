#ifndef _SIDEBALL_SUB_
#define _SIDEBALL_SUB_
#include <stm32f4xx.h>

#include "HardwareInfo.c"
#include <SetLCDBack.h>
#include <GetUartData.h>
#include <SetLCD3Char.h>
#include <SetInSound.h>
#include <SetUartData.h>
#include "PinchBallside_sub.c"
void sideball_sub()
{
    // extern global var
    extern double ANGLE1;
    extern long ball22;
    extern long ball2;
    extern long B;
    extern long ball;
    extern int ball1;

    double ANGLE = 0;
    int i = 0;
    long A = 0;
    long time = 0;
    SetLCDBack(1);
    ball2 = GetUartData(2, 2);
    ball2=ball2-48;
    if ( ball2>0&&ball2<=7 )
    {
        ball22=0;
        ball2=0;
            SetMotor2(1, 15);
            SetMotor2(2, 15);
        while ( !GetGpioState(_COMPASS_11_,1,1) )
        {
            ball2 = GetUartData(2, 2);
            ball2=ball2-48;
            if ( ball2>0&&ball2<=7 )
            {
                ball22=ball22+1;
            }
            SetLCD3Char(0, 40, ball22, YELLOW, BLACK);
            Sysdelayus(10);
            time++;
            if ( time>=1000 )
            {
                ball22=0;
                break;
            }
            else
            {
                if ( ball22>=5 )
                {
                    SetInSound(440, 100);
                    SetLCD3Char(0, 20, ball2, YELLOW, BLACK);
                    break;
                }
            }
        }
    }
    if ( ball22>=5 )
    {
        while ( !GetGpioState(_COMPASS_11_,1,1) )
        {
            ball2 = GetUartData(2, 2);
            ball2=ball2-48;
            if ( ball2==2||ball2==5 )
            {
                SetMotor2( 1 , -50 );
                SetMotor2( 2 ,  -50 );
                
                A=0;
            }
            else
            {
                if ( ball2==3||ball2==6 )
                {
                    SetMotor2( 1 ,  50 );
                    SetMotor2( 2 , 50 );
                    
                    A=0;
                }
                else
                {
                    if ( ball2==1||ball2==4||ball2==7 )
                    {
                        SetUartData(2, 0, 2);
                        SetUartData(1, 0, 2);
                          SetMotor2( 1 ,0 );
                          SetMotor2( 2 ,0 );
                        
                        
                        PinchBallside_sub();
                        ball2 =0;
                        ball22   =0;
                        SetUartData(1, 1, 2);
                        SetUartData(2, 1, 2);
                        break;
                    }
                    else
                    {
                        Sysdelayus(10);
                        time++;
                        if ( time>=200000 )
                        {
                            ball=0;
                            break;
                        }
                    }
                }
            }
        }
    }
    ball22=0;
    ball2=0;
}
#endif

