#ifndef _ROOM1_SUB_
#define _ROOM1_SUB_
#include <stm32f4xx.h>
#include <SetNS.h>
#include <SetMotor2.h>
#include <SetTenthS.h>

#include "HardwareInfo.c"
#include <GetCompassB.h>
#include "turnleft_angle.c"
#include "turnright_angle.c"
#include <SetTenthS.h>
#include <SetUartData.h>
#include <GetUartData.h>
#include <SetLCDClear.h>
#include "lookball_sub.c"
#include <GetData.h>
#include <SetNS.h>
void room1_sub()
{
    // extern global var
    extern double ANGLE1;
    extern long ball;
    extern int ball1;
    extern long ball2;
    extern long ball22;
    extern long B;
    extern long distance1;
    extern long distance2;
    extern long distance3;
    extern long distance4;
    extern long distance5;
    extern long TOUCH1;
    extern long TOUCH2;
    extern long TOUCH3;
    extern long TOUCH4;
    extern long TOUCH5;
    extern long TOUCH6;
    extern long TOUCH7;
    extern double I5;
    extern long ENT;
    extern long SilverBall;
    extern long BlackBall;
    extern long BlackBallOK;
    extern long SilverBallOK;
    extern long V;
    extern double I4;
    extern long D;
    extern long E;
    extern long g_0;

    double ANGLE = 0;
    long A = 0;
    long time = 0;
    long time1 = 0;
    long var0 = 0;
    ANGLE = GetCompassB(_COMPASS_1_);
    ANGLE1=0;
    if ( ANGLE<90 )
    {
        turnleft_angle();
    }
    else
    {
        if ( ANGLE>270 )
        {
            turnright_angle();
        }
        else
        {
            turnleft_angle();
        }
    }
        SetMotor2(1, 65);
        SetMotor2(2, 70);
    SetTenthS(16);
        SetMotor2(1, 0);
        SetMotor2(2, 0);
    
    SetTenthS(2);
    SetUartData(1, 1, 6);
    SetUartData(2, 4, 6);
        SetMotor2(  1 , -50 );
        SetMotor2(  2 , -50 );
    SetTenthS(2);
        time=0;
        time1=0;
        SetMotor2(  1 , 0 );
        SetMotor2(  2 , 0 );
    for (int _FOR_0_ = 0; _FOR_0_ < 500; _FOR_0_++ )
    {
        ball1 = GetUartData(1, 6);
    }
        time=0;
        ball=0;
        ball1=0;
        V=0;
        SetMotor2(  1 , 0 );
        SetMotor2(  2 , 0 );
    SetLCDClear(BLACK);
    while ( !GetGpioState(_COMPASS_11_,1,1) )
    {
        ball1 = GetUartData(1, 6);
                if ( ball1>0&&ball1<=5 )
                {
                    ball=ball+1;
                }
                else
                {  
                    if ( time1>=800 )    //�ɶ����n�ݨ�y
                    {
                            time1=0;
                            ball=0;
                    }
                }
                
                Sysdelayus(1000);   //�C0.001�p��
                time1++;
                time++;
                if ( time>=10000 )   //10���ᵲ����y
                {
                    ball=0;
                    break;
                }
                else
                {
                    if ( ball>=4 )    //�ݨ�y����
                    {
                        SetInSound(440, 100);
                        break;
                    }
                    else
                    {
                        
                            SetMotor2(  1 , 40 );
                            SetMotor2(  2 , -40 );
                    }
                }
    }
    if ( ball>0 )
    {
        lookball_sub();
    }
        SetMotor2(  1 , 0 );
        SetMotor2(  2 , 0 );
        SetTenthS( 2);
    if ( V==1 )
    {
        D = GetData(18);
    }
    else
    {
        D = GetData(6);
           D=D+67;
           if (D>=360)
           {
               D=D-360;
           }
        
    }
    ANGLE1=D;
    turnright_angle();
        time=0;
        time1=0;
        ball=0;
        ball1=0;
        SetMotor2(  1 , 0 );
        SetMotor2(  2 , 0 );
    for (int _FOR_2_ = 0; _FOR_2_ < 1500; _FOR_2_++ )
    {
        ball1 = GetUartData(1, 6);
    }
    while ( !GetGpioState(_COMPASS_11_,1,1) )
    {
        ball1 = GetUartData(1, 6);
                if ( ball1>0&&ball1<=5 )
                {
                    ball=ball+1;
                }
                else
                {  
                    if ( time1>=800 )    //�ɶ����n�ݨ�y
                    {
                            time1=0;
                            ball=0;
                    }
                }
                
                Sysdelayus(1000);   //�C0.001�p��
                time1++;
                time++;
                if ( time>=10000 )   //10���ᵲ����y
                {
                    ball=0;
                    break;
                }
                else
                {
                    if ( ball>=4 )    //�ݨ�y����
                    {
                        SetInSound(440, 100);
                        break;
                    }
                    else
                    {
                        
                            SetMotor2(  1 , 40 );
                            SetMotor2(  2 , -40 );
                    }
                }
    }
    if ( ball>0 )
    {
        lookball_sub();
    }
        SetMotor2(  1 , 0 );
        SetMotor2(  2 , 0 );
        SetTenthS( 2);
    if ( V==1 )
    {
        D = GetData(18);
    }
    else
    {
        D = GetData(6);
           D=D+67;
           if (D>=360)
           {
               D=D-360;
           }
        
    }
    ANGLE1=D;
    turnright_angle();
        time=0;
        time1=0;
        ball=0;
        ball1=0;
        SetMotor2(  1 , 0 );
        SetMotor2(  2 , 0 );
    SetNS(1);
        SetMotor2(1, 35);
        SetMotor2(2, 70);
    
    SetTenthS(25);
        SetMotor2(1, 0);
        SetMotor2(2, 0);
    
    SetTenthS(100);
}
#endif

