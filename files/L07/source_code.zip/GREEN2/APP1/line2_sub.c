#ifndef _LINE2_SUB_
#define _LINE2_SUB_
#include <stm32f4xx.h>
#include <GetColorSensor.h>
#include <SetTenthS.h>
#include <SetMotor2.h>
#include <SetInMusicStop.h>
#include <SetCentiS.h>
#include <SetInBeep.h>


#include "HardwareInfo.c"
void line2_sub()
{
    // extern global var
    extern double I3;
    extern double I4;
    extern double I5;
    extern double I6;
    extern double I7;
    extern double I8;
    extern long COLOR1;
    extern long COLOR2;
    extern double speed;
    extern double KP;
    extern double KD;
    extern double SPEED;
    extern double I1;
    extern double I2;

    long LA = 0;
    long RA = 0;
    double ERROR1 = 0;
    double M1 = 0;
    double M2 = 0;
    long ERROR2 = 0;
    double PD_VAL = 0;
      I1=GetADScable10( _SCABLEAD_1_ );
      I2=GetADScable10( _SCABLEAD_2_ );
      I3=GetADScable10( _SCABLEAD_3_ );
      I4=GetADScable10( _SCABLEAD_4_ );
      I5=GetADScable10( _SCABLEAD_5_ );
      I6=GetADScable10( _SCABLEAD_6_ );
      I7=GetADScable10( _SCABLEAD_7_ );
      I8=GetADScable10( _SCABLEAD_8_ );
        
      ERROR1=(I7*30+I6*20+I5*10-I4*10-I3*30-I2*30)/(I2+I3+I4+I5+I6+I7);
      PD_VAL=ERROR1*30+(ERROR1-ERROR2)*20;
      ERROR2=ERROR1;
      M1=0+PD_VAL;
      M2=0-PD_VAL;
      
      if (M1>=100)
      {
          M1=100;
      }
      else    // �����߮�
      {
          if (M1<=-100)
          {
              M1=-100;
          }
      }
      
      if (M2>=100)
      {
          M2=100;
      }
      else    // �����߮�
      {
          if (M2<=-100)
          {
              M2=-100;
          }
      }
        
         SetMotor2( 1 ,M1) ;
         SetMotor2( 2 ,M2)  ;
      
        
}
#endif

