#ifndef _ANGLE_KEEP_
#define _ANGLE_KEEP_
#include <stm32f4xx.h>

#include "HardwareInfo.c"
#include <GetCompassB.h>
#include <SetMotor2.h>
#include "stop_sub.c"
void angle_keep()
{
    // extern global var
    extern double ANGLE1;

    double ERROR1 = 0;
    double ERROR2 = 0;
    double PD = 0;
    double M1 = 0;
    double M2 = 0;
    double INTEGRAL = 0;
    double KI = 3;
    long A = 0;
    double KD1 = 6;
    double KP1 = 4;
    double ANGLE = 0;
    A=0;
    while (1)
    {
        ANGLE = GetCompassB(_COMPASS_1_);
        if ( ANGLE1>=300 )
        {
            if ( ANGLE>180 )
            {
                ERROR1=ANGLE1-ANGLE;
            }
            else
            {
                ERROR1=ANGLE1-ANGLE-360;
            }
        }
        else
        {
            if ( ANGLE1<60 )
            {
                if ( ANGLE>180 )
                {
                    ERROR1=ANGLE1-ANGLE+360;
                }
                else
                {
                    ERROR1=ANGLE1-ANGLE;
                }
            }
            else
            {
                ERROR1=ANGLE1-ANGLE;
            }
        }
        INTEGRAL=INTEGRAL*0.67+ERROR1;
        PD=ERROR1*KP1+(ERROR1-ERROR2)*KD1+INTEGRAL*KI;
        M1=0+PD;
        M2=0-PD;
        ERROR2=ERROR1;
        if ( M1>=30 )
        {
            M1=50;
        }
        else
        {
            if ( M1<=0-50 )
            {
                M1=0-50;
            }
        }
        if ( M2>=50 )
        {
            M2=50;
        }
        else
        {
            if ( M2<=0-50 )
            {
                M2=0-50;
            }
        }
        SetMotor2(1, M1);
        SetMotor2(2, M2);
        if ( ERROR1<=5&&ERROR1>=0-5 )
        {
            A=A+1;
        }
        else
        {
            A=0;
        }
        if ( A>=5 )
        {
            stop_sub();
            break;
        }
    }
}
#endif

