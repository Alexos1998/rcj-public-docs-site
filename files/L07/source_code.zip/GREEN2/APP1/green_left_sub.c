#ifndef _GREEN_LEFT_SUB_
#define _GREEN_LEFT_SUB_
#include <stm32f4xx.h>
#include <GetColorSensor.h>
#include <SetTenthS.h>
#include <SetMotor2.h>
#include <SetInMusicStop.h>
#include <SetCentiS.h>
#include <SetInBeep.h>
#include <GetADScable10.h>

#include "HardwareInfo.c"
#include "turn_around_sub.c"
#include "eyes_sub.c"
#include <SetCentiS.h>
#include "line2_sub.c"
void green_left_sub()
{
    // extern global var
    extern double I3;
    extern double I4;
    extern double I5;
    extern double I6;
    extern double I7;
    extern double I8;
    extern long COLOR1;
    extern long COLOR2;
    extern double speed;
    extern double ERROR1;
    extern double ERROR2;
    extern double KP;
    extern double KD;
    extern double PD_VAL;
    extern double SPEED;
    extern double M1;
    extern double M2;
    extern double I1;
    extern double I2;
    extern long TIME;

    long LA = 0;
    long RA = 0;
    LA=0;
    for (int _FOR_0_ = 0; _FOR_0_ < 55; _FOR_0_++ )
    {
        if ( COLOR2==2&&I6>=1500 )
        {
            turn_around_sub();
            LA=1;
            break;
        }
        else
        {
              I1=GetADScable10( _SCABLEAD_1_ );
              I2=GetADScable10( _SCABLEAD_2_ );
              I3=GetADScable10( _SCABLEAD_3_ );
              I4=GetADScable10( _SCABLEAD_4_ );
              I5=GetADScable10( _SCABLEAD_5_ );
              I6=GetADScable10( _SCABLEAD_6_ );
              I7=GetADScable10( _SCABLEAD_7_ );
              I8=GetADScable10( _SCABLEAD_8_ );
              COLOR1=GetColorSensor( _COLOR_1_,1 ,4 );
              COLOR2=GetColorSensor( _COLOR_2_,1 ,4 );
               
              ERROR1=(I5*10-I4*10)/(I4+I5);
              PD_VAL=ERROR1*8+(ERROR1-ERROR2)*5;
              ERROR2=ERROR1;
              M1=SPEED+PD_VAL;
              M2=SPEED-PD_VAL;
              
              if (M1>=70)
              {
                  M1=70;
              }
              else    // �����߮�
              {
                  if (M1<=-70)
                  {
                      M1=-70;
                  }
              }
              
              if (M2>=70)
              {
                  M2=70;
              }
              else    // �����߮�
              {
                  if (M2<=0-70)
                  {
                      M2=0-70;
                  }
              }
              
              if (I2<700&&I3<700&&I4<700&&I5<700&&I6<700&&I7<700)
              {
                  SetMotor2( 1,-70);
                  SetMotor2( 2,70);
                       
              }
              else    // �����߮�
              {
                 SetMotor2( 1 ,M1) ;
                 SetMotor2( 2 ,M2)  ;
              }  
                
        }
    }
    if ( LA==0 )
    {
            SetMotor2(1, 50 );
            SetMotor2(2, 50 );
            
        
        while (1)
        {
            eyes_sub();
            if ( I3<=700 )
            {
                SetCentiS(4);
                break;
            }
            else
            {
                  I1=GetADScable10( _SCABLEAD_1_ );
                  I2=GetADScable10( _SCABLEAD_2_ );
                  I3=GetADScable10( _SCABLEAD_3_ );
                  I4=GetADScable10( _SCABLEAD_4_ );
                  I5=GetADScable10( _SCABLEAD_5_ );
                  I6=GetADScable10( _SCABLEAD_6_ );
                  I7=GetADScable10( _SCABLEAD_7_ );
                  I8=GetADScable10( _SCABLEAD_8_ );
                  COLOR1=GetColorSensor( _COLOR_1_,1 ,4 );
                  COLOR2=GetColorSensor( _COLOR_2_,1 ,4 );
                   
                  ERROR1=(I5*10-I4*10)/(I4+I5);
                  PD_VAL=ERROR1*8+(ERROR1-ERROR2)*5;
                  ERROR2=ERROR1;
                  M1=SPEED+PD_VAL;
                  M2=SPEED-PD_VAL;
                  
                  if (M1>=70)
                  {
                      M1=70;
                  }
                  else    // �����߮�
                  {
                      if (M1<=-70)
                      {
                          M1=-70;
                      }
                  }
                  
                  if (M2>=70)
                  {
                      M2=70;
                  }
                  else    // �����߮�
                  {
                      if (M2<=0-70)
                      {
                          M2=0-70;
                      }
                  }
                  
                  if (I2<700&&I3<700&&I4<700&&I5<700&&I6<700&&I7<700)
                  {
                      SetMotor2( 1,-70);
                      SetMotor2( 2,70);
                           
                  }
                  else    // �����߮�
                  {
                     SetMotor2( 1 ,M1) ;
                     SetMotor2( 2 ,M2)  ;
                  }  
                    
            }
        }
            SetMotor2(1, -50 );
            SetMotor2(2, 50 );
            
        
        while (1)
        {
            eyes_sub();
            if ( I3>=700 )
            {
                break;
            }
        }
        while (1)
        {
            eyes_sub();
            if ( I3<=600 )
            {
                break;
            }
        }
    }
    for (int _FOR_1_ = 0; _FOR_1_ < 900; _FOR_1_++ )
    {
        line2_sub();
    }
}
#endif

