#ifndef _TOUCH_SUB_
#define _TOUCH_SUB_
#include <stm32f4xx.h>
#include "JMDKernel.h"

#include "HardwareInfo.c"


void touch_sub()
{
    // extern global var
    extern long distance2;
    extern long TOUCH1;
    extern long TOUCH2;
    extern long TOUCH3;
    extern long TOUCH4;
    extern long TOUCH5;
    extern long TOUCH6;
    extern long TOUCH7;

        SetX4RCU_IO(_COMPASS_11_,1,1);
        SetX4RCU_IO(_COMPASS_12_,1,1);
        SetX4RCU_IO(_COMPASS_13_,1,1);
        SetX4RCU_IO(_COMPASS_14_,1,1);
        SetX4RCU_IO(_COMPASS_15_,1,1);
    
        TOUCH1=GetGpioState(_COMPASS_11_,1,1);
        TOUCH2=GetGpioState(_COMPASS_12_,1,1);
        TOUCH3=GetGpioState(_COMPASS_13_,1,1);
        TOUCH4=GetGpioState(_COMPASS_14_,1,1);
        TOUCH5=GetGpioState(_COMPASS_15_,1,1);
    
        
}
#endif

