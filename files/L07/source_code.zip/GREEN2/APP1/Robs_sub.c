#ifndef _ROBS_SUB_
#define _ROBS_SUB_
#include <stm32f4xx.h>
#include <SetMotor2.h>
#include "JMDKernel.h"

#include "HardwareInfo.c"


#include "touch_sub.c"
#include <SetInBeep.h>
#include <SetTenthS.h>
#include <SetInMusicStop.h>
#include "JMSub2.c"
#include <GetADScable10.h>
#include "line2_sub.c"
void Robs_sub()
{
    // extern global var
    extern long distance2;
    extern long TOUCH1;
    extern long TOUCH2;
    extern long TOUCH3;
    extern long TOUCH4;
    extern long TOUCH5;
    extern long TOUCH6;
    extern long TOUCH7;

    long I = 0;
    long B = 0;
    touch_sub();
    if ( TOUCH2==1||TOUCH3==1 )
    {
            SetMotor2( 1 , 0 );
            SetMotor2( 2 , 0 );
        
        SetInBeep(ON);
        SetTenthS(2);
        SetInMusicStop();
            B=0;    
            SetMotor2( 1,-50);
            SetMotor2( 2 ,-50);
            SetTenthS(4);
            SetMotor2( 1,50);
            SetMotor2( 2,-50);
            SetTenthS(6);
            
            SetMotor2(1,50 );
            SetMotor2(2,50 );
            SetTenthS( 5 );
              
        for (int _FOR_0_ = 0; _FOR_0_ < 6; _FOR_0_++ )
        {
            SetMotor2( 1,60 );
            SetMotor2( 2,60 );
            while ( !GetGpioState(_COMPASS_11_,1,1) )
            {
                JMSub2();
                if ( distance2>=10 )
                {
                    break;
                }
            }
            SetMotor2( 1,-30 );
            SetMotor2( 2,60 );
            while ( !GetGpioState(_COMPASS_11_,1,1) )
            {
                JMSub2();
                if ( distance2<=5 )
                {
                    break;
                }
            }
        }
        while ( !GetGpioState(_COMPASS_11_,1,1) )
        {
            SetMotor2( 1,60 );
            SetMotor2( 2,60 );
            while ( !GetGpioState(_COMPASS_11_,1,1) )
            {
                I = GetADScable10(_SCABLEAD_5_);
                JMSub2();
                if ( I>=1000 )
                {
                    B=1;
                    break;
                }
                if ( distance2>=8 )
                {
                    break;
                }
            }
            SetMotor2( 1,-30 );
            SetMotor2( 2,60 );
            while ( !GetGpioState(_COMPASS_11_,1,1) )
            {
                I = GetADScable10(_SCABLEAD_1_);
                JMSub2();
                if ( I>=1000||B==1 )
                {
                    B=1;
                    break;
                }
                if ( distance2<=5 )
                {
                    break;
                }
            }
            if ( B==1 )
            {
                    /*
                    B=0;    
                    SetMotor2( 1,-50);
                    SetMotor2( 2 ,-50);
                    SetTenthS(3);
                    
                    SetMotor2( 1, 50);
                    SetMotor2( 2,-50);
                    SetTenthS(4);
                    */
                    SetMotor2( 1,50);
                    SetMotor2( 2,50);
                    SetTenthS(2);
                    
                 
                    
                    SetMotor2( 1,0);
                    SetMotor2( 2,0);
                
                while ( !GetGpioState(_COMPASS_11_,1,1) )
                {
                    I = GetADScable10(_SCABLEAD_5_);
                    if ( I>=1000 )
                    {
                            SetMotor2( 1,0);
                            SetMotor2( 2,0);
                        
                        break;
                    }
                    else
                    {
                            SetMotor2( 1,50);
                            SetMotor2( 2,-50);
                        
                    }
                }
                break;
            }
        }
        for (int _FOR_1_ = 0; _FOR_1_ < 700; _FOR_1_++ )
        {
            line2_sub();
        }
    }
}
#endif

