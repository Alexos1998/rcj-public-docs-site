#ifndef _LOOKBALL_SUB_
#define _LOOKBALL_SUB_
#include <stm32f4xx.h>
#include <SetTenthS.h>
#include <SetMotor2.h>

#include "HardwareInfo.c"
#include <GetUartData.h>
#include <SetLCD3Char.h>
#include <SetNS.h>
#include <SetServo.h>
#include <SetTenthS.h>
#include <SetInBeep.h>
#include <SetInMusicStop.h>
#include <SetUartData.h>
#include "lookball1_sub.c"
void lookball_sub()
{
    // extern global var
    extern double ANGLE1;
    extern long ball;
    extern int ball1;
    extern long B;
    extern long V;
    extern long BlackBall;

    double ANGLE = 0;
    int i = 0;
    long A = 0;
    long time = 0;
    SetMotor2( 1 , 0 );
    SetMotor2( 2 , 0 );
    SetTenthS( 2 );
    ball1=0;
    while ( !GetGpioState(_COMPASS_11_,1,1) )
    {
        ball1 = GetUartData(1, 6);
        if ( ball1>0&&ball1<=5 )
        {
            SetLCD3Char(0, 60, ball1, YELLOW, BLACK);
            if ( ball1==2 )
            {
                SetMotor2( 1 , -40 );
                SetMotor2( 2 ,  40 );
                
                A=0;
            }
            else
            {
                if ( ball1==3 )
                {
                    SetMotor2( 1 , 40 );
                    SetMotor2( 2 , -40 );
                    
                    A=0;
                }
                else
                {
                    if ( ball1==1 )
                    {
                        SetMotor2( 1 , 37 );
                        SetMotor2( 2 , 40 );
                        
                        A=0;
                    }
                    else
                    {
                        if ( ball1==4 )
                        {
                            SetMotor2( 1 , -40 );
                            SetMotor2( 2 , -40 );
                            
                            A=0;
                        }
                        else
                        {
                            if ( ball1==5 )
                            {
                                SetMotor2( 1 , 0 );
                                SetMotor2( 2 , 0 );
                                
                                if ( BlackBall>0 )
                                {
                                    SetMotor2( 1 , -50 );
                                    SetMotor2( 2 , 50 );
                                    
                                    SetNS(1);
                                    SetMotor2( 1 , 0 );
                                    SetMotor2( 2 , 0 );
                                    
                                    SetServo(_SERVO_1_, 135);
                                    SetTenthS(5);
                                    SetServo(_SERVO_2_, 35);
                                    SetTenthS(3);
                                    SetServo(_SERVO_1_, 22);
                                    SetTenthS(5);
                                    SetMotor2( 1 , 50 );
                                    SetMotor2( 2 , -50 );
                                    
                                    SetNS(1);
                                    SetMotor2( 1 , 0 );
                                    SetMotor2( 2 , 0 );
                                    BlackBall=0;
                                }
                                SetInBeep(ON);
                                SetTenthS(10);
                                SetInMusicStop();
                                SetMotor2( 1 , 0 );
                                SetMotor2( 2 , 0 );
                                
                                SetUartData(2, 1, 6);
                                SetUartData(1, 3, 6);
                                SetTenthS(3);
                                lookball1_sub();
                                ball=0;
                                ball1=0;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
    V=1;
}
#endif

