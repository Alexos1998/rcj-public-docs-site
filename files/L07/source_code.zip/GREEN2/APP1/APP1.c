#include <stm32f4xx.h>
#include <SetLCD3Char.h>
#include <SetInBeep.h>
#include <SetInMusicStop.h>
#include <SetTenthS.h>
#include <GetData.h>
#include <GetADScable10.h>
#include <GetColorSensor.h>
#include <SetMotor2.h>
#include "HardwareInfo.c"

//��l�Ƥ�?�Ҧ�
//which:�ݤf 
// pin: ��?�G0�OS  ,1 �OD
//state:0�O?�X�Ҧ��A1�O?�J�Ҧ�
  u8 SetX4RCU_IO(unsigned long which,u8 pin,u8 state)
  {
			struct select *information=&which;
		   u32 port1=portarray[information->group1];
		   u32 port2=portarray[information->group2];
		   u8 bit1=information->bit1;
		   u8 bit2=information->bit2;
   
			if(pin == 0)//S��?
			{
			//�t�m��?
			   		if(state == 0) GPIO_Setting((GPIO_TypeDef*)port1,bit1,GPIO_Mode_OUT,GPIO_OType_PP,GPIO_PuPd_UP);//?�X�Ҧ�
					if(state == 1)//?�J�Ҧ�
					{
							GPIO_Setting((GPIO_TypeDef*)port1,bit1,GPIO_Mode_IN,0,GPIO_PuPd_NOPULL);//
						// GPIO_Setting((GPIO_TypeDef*)port1,bit1,GPIO_Mode_IN,0,GPIO_PuPd_UP);//
						//GPIO_Setting((GPIO_TypeDef*)port1,bit1,GPIO_Mode_IN,0,GPIO_PuPd_DOWN);//
					}
			 }
			 else if(pin == 1)//D��?
			{
					//�t�m��?
					if(state == 0) GPIO_Setting((GPIO_TypeDef*)port2,bit2,GPIO_Mode_OUT,GPIO_OType_PP,GPIO_PuPd_UP);//?�X�Ҧ�
				   if(state == 1)//?�J�Ҧ�
					{
					      GPIO_Setting((GPIO_TypeDef*)port2,bit2,GPIO_Mode_IN,0,GPIO_PuPd_NOPULL);//
					  // GPIO_Setting((GPIO_TypeDef*)port2,bit2,GPIO_Mode_IN,0,GPIO_PuPd_UP);//
					  //GPIO_Setting((GPIO_TypeDef*)port2,bit2,GPIO_Mode_IN,0,GPIO_PuPd_DOWN);//
					}
			 }
  }
  
  //?�m��???
 //which:�ݤf 
// pin: ��?�G0�OS  ,1 �OD
//state:0�O?�X�C?���A1�O?�X��?��
  u8 SetGpioState(unsigned long which,u8 pin,u8 state)
  {
  
  	struct select *information=&which;
		   u32 port1=portarray[information->group1];
		   u32 port2=portarray[information->group2];
		   u8 bit1=information->bit1;
		   u8 bit2=information->bit2;
   
			if(pin == 0)//S��?
			{
			
					//�t�m��?
					if(state == 1) GPIO_SetBits((GPIO_TypeDef*)port1,(1<<bit1));//S��?�m��?��
					else GPIO_ResetBits((GPIO_TypeDef*)port1,( 1<<bit1));//S��?�m�C?��
			 
	
			 }
			 else if(pin == 1)//D��?
			{
					//�t�m��?
					if(state==1) GPIO_SetBits((GPIO_TypeDef*)port2,(1<<bit2));//D��?�m��?��
					else GPIO_ResetBits((GPIO_TypeDef*)port2,( 1<<bit2));//D��?�m�C?��
			 
			 }
  
  }
  
  
      u8 GetGpioState(unsigned long which,u8 pin,u8 state)
  {
			struct select *information=&which;
		   u32 port1=portarray[information->group1];
		   u32 port2=portarray[information->group2];
		   u8 bit1=information->bit1;
		   u8 bit2=information->bit2;
			u8 value =0;
			
			if(pin == 0)//S��?
			{
			    if (state==1)
			    {
			       GPIO_Setting((GPIO_TypeDef*)port1,bit1,GPIO_Mode_IN,0,GPIO_PuPd_UP);
			       value=GPIO_ReadInputDataBit((GPIO_TypeDef*)port1,(1<<bit1));//?��S��???
			       }
			       else
			       value=GPIO_ReadInputDataBit((GPIO_TypeDef*)port1,(1<<bit1));//?��S��???
			     
			 }
			else  if(pin == 1)//D��?
			{
			     if(state==1)
			     {
			       GPIO_Setting((GPIO_TypeDef*)port2,bit2,GPIO_Mode_IN,0,GPIO_PuPd_UP);
			       value=GPIO_ReadInputDataBit((GPIO_TypeDef*)port2,(1<<bit2));//?��D��???
			       }
			     else
			      value=GPIO_ReadInputDataBit((GPIO_TypeDef*)port2,(1<<bit2));//?��D��??? 
			        
			 }
			 return value;
			 
  }

#include "JMLib.c"
#include "PinchBall_sub.c"
// define global var
double I1 = 0;
double I2 = 0;
double I3 = 0;
double I4 = 0;
double I5 = 0;
double I6 = 0;
double ERROR2 = 0;
double PD_VAL = 0;
double ERROR1 = 0;
double M1 = 0;
double M2 = 0;
double I7 = 0;
double I8 = 0;
long COLOR1 = 0;
long COLOR2 = 0;
long time = 0;
double KP = 7;
double SPEED = 55;
double KD = 10;
long TIME = 0;
long COMPASS = 0;
long TOUCH1 = 0;
long TOUCH2 = 0;
long TOUCH3 = 0;
long TOUCH4 = 0;
long TOUCH5 = 0;
double ANGLE1 = 0;
long ENT = 0;
double ANGLE = 0;
long ball = 0;
int ball1 = 0;
int ball3 = 0;
long ball22 = 0;
long B = 0;
long distance1 = 0;
long distance2 = 0;
long distance3 = 0;
long distance4 = 0;
long distance5 = 0;
long TOUCH6 = 0;
long TOUCH7 = 0;
long BlackBall = 0;
long SilverBall = 0;
long BlackBallOK = 0;
long SilverBallOK = 0;
long RA = 0;
long LA = 0;
long ball2 = 0;
long V = 0;
long T = 0;
double Exit = 0;
long D = 0;
long Q = 0;

int main(void)
{
    X4RCU_Init();
    long pitch = 0;
    long time1 = 0;
    long up = 0;
    long down = 0;
    long up1 = 0;
    while (1)
    {
        PinchBall_sub();
    }
    while(1);
}

