#ifndef _PINCHBALL1_SUB_
#define _PINCHBALL1_SUB_
#include <stm32f4xx.h>
#include <SetMotor2.h>
#include "JMDKernel.h"


#include "HardwareInfo.c"
#include <SetServo.h>
#include <SetTenthS.h>
#include "touch_sub.c"
#include <SetInSound.h>
#include <SetInBeep.h>
#include <SetInMusicStop.h>
void PinchBall1_sub()
{
    // extern global var
    extern long TOUCH6;
    extern long SilverBall;
    extern long BlackBall;
    extern long TOUCH7;
    extern long TOUCH1;
    extern long TOUCH2;
    extern long TOUCH3;
    extern long TOUCH4;
    extern long TOUCH5;

    SetServo(_SERVO_1_, 90);
    SetTenthS(2);
    SetServo(_SERVO_2_, 35);
    SetTenthS(3);
    SetServo(_SERVO_1_, 137);
    SetTenthS(1);
    SetServo(_SERVO_2_, 22);
    SetTenthS(5);
    SetServo(_SERVO_1_, 5);
    SetTenthS(10);
    touch_sub();
    if ( TOUCH5==0 )
    {
        SetServo(_SERVO_3_, 130);
        SetTenthS(3);
        
        SetInSound(440, 100);
    }
    else
    {
        if ( TOUCH4==0 )
        {
            SetInBeep(ON);
            SetTenthS(3);
            SetInMusicStop();
        }
        else
        {
            SetServo(_SERVO_3_, 70);
            SetTenthS(3);
            
        }
    }
    SetServo(_SERVO_2_, 35);
    SetTenthS(1);
}
#endif

