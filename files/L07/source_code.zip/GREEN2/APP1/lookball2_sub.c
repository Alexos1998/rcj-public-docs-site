#ifndef _LOOKBALL2_SUB_
#define _LOOKBALL2_SUB_
#include <stm32f4xx.h>
#include <SetMotor2.h>

#include "HardwareInfo.c"
#include <SetLCDBack.h>
#include <GetUartData.h>
#include <SetInBeep.h>
#include <SetTenthS.h>
#include <SetInMusicStop.h>
#include <SetInSound.h>
#include <SetLCD3Char.h>
#include <SetUartData.h>
#include "lookball3_sub.c"
void lookball2_sub()
{
    // extern global var
    extern double ANGLE1;
    extern long ball;
    extern int ball1;
    extern long B;
    extern long V;
    extern long BlackBall;

    double ANGLE = 0;
    int i = 0;
    long A = 0;
    long time = 0;
    SetLCDBack(1);
    ball1 = GetUartData(1, 6);
    if ( ball1>0&&ball1<4 )
    {
        ball=0;
        ball1=0;
            SetMotor2(1, 0);
            SetMotor2(2, 0);
        SetInBeep(ON);
        SetTenthS(5);
        SetInMusicStop();
        while ( !GetGpioState(_COMPASS_11_,1,1) )
        {
            ball1 = GetUartData(1, 6);
            if ( ball1>0&&ball1<4 )
            {
                ball=ball+1;
            }
            Sysdelayus(10);
            time++;
            if ( time>=1000 )
            {
                ball=0;
                break;
            }
            else
            {
                if ( ball>=4 )
                {
                    SetInSound(440, 100);
                    SetLCD3Char(0, 40, ball1, YELLOW, BLACK);
                    break;
                }
            }
        }
        time=0;
    }
    if ( ball>0 )
    {
        SetInBeep(ON);
        SetTenthS(2);
        SetInMusicStop();
        while ( !GetGpioState(_COMPASS_11_,1,1) )
        {
            ball1 = GetUartData(1, 6);
            SetLCD3Char(0, 60, ball1, YELLOW, BLACK);
            if ( ball1==2 )
            {
                SetMotor2( 1 , -30 );
                SetMotor2( 2 ,  40 );
                
                A=0;
            }
            else
            {
                if ( ball1==3 )
                {
                    SetMotor2( 1 , 40 );
                    SetMotor2( 2 , -30 );
                    
                    A=0;
                }
                else
                {
                    if ( ball1==1 )
                    {
                        SetMotor2( 1 , 30 );
                        SetMotor2( 2 , 40 );
                        
                        A=0;
                    }
                    else
                    {
                        if ( ball1==4 )
                        {
                            SetMotor2( 1 , -40 );
                            SetMotor2( 2 , -40 );
                            
                            A=0;
                        }
                        else
                        {
                            if ( ball1==5||ball1==6||ball1==4 )
                            {
                                SetMotor2( 1 , 0 );
                                SetMotor2( 2 , 0 );
                                
                                SetUartData(2, 2, 6);
                                SetUartData(1, 4, 6);
                                SetTenthS(3);
                                lookball3_sub();
                                ball=0;
                                ball1=0;
                                break;
                            }
                        }
                    }
                }
            }
        }
        V=1;
    }
}
#endif

