#ifndef _TURNRIGHT_ANGLE_
#define _TURNRIGHT_ANGLE_
#include <stm32f4xx.h>

#include "HardwareInfo.c"
#include <GetCompassB.h>
#include <SetMotor2.h>
#include "angle_keep.c"
void turnright_angle()
{
    // extern global var
    extern double ANGLE1;

    double ANGLE = 0;
    if ( ANGLE1>=0&&ANGLE1<60 )
    {
        while (1)
        {
            ANGLE = GetCompassB(_COMPASS_1_);
            SetMotor2(1, 70);
            SetMotor2(2, -70);
            if ( ANGLE>=ANGLE1+300||ANGLE<=ANGLE1 )
            {
                angle_keep();
                break;
            }
        }
    }
    else
    {
        while (1)
        {
            ANGLE = GetCompassB(_COMPASS_1_);
            SetMotor2(1, 70);
            SetMotor2(2, -70);
            if ( ANGLE>=ANGLE1-60&&ANGLE<=ANGLE1 )
            {
                angle_keep();
                break;
            }
        }
    }
}
#endif

