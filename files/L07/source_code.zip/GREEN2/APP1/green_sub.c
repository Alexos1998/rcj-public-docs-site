#ifndef _GREEN_SUB_
#define _GREEN_SUB_
#include <stm32f4xx.h>
#include <GetADScable10.h>
#include <GetColorSensor.h>
#include <SetTenthS.h>
#include <SetMotor2.h>
#include <SetInMusicStop.h>
#include <SetCentiS.h>
#include <SetInBeep.h>


#include "HardwareInfo.c"
#include <SetCentiS.h>
#include "turn_around_sub.c"
#include "green_right_sub.c"
#include "green_left_sub.c"
#include "line_sub.c"
#include "turn_right_sub.c"
#include "turn_left_sub.c"
void green_sub()
{
    // extern global var
    extern double I3;
    extern double I4;
    extern double I5;
    extern double I6;
    extern double I7;
    extern double I8;
    extern long COLOR1;
    extern long COLOR2;
    extern double speed;
    extern double ERROR1;
    extern double ERROR2;
    extern double KP;
    extern double KD;
    extern double PD_VAL;
    extern double SPEED;
    extern double M1;
    extern double M2;
    extern double I1;
    extern double I2;
    extern long TIME;
    extern long LA;
    extern long RA;

        SetMotor2( 1 ,0 ) ;
        SetMotor2( 2 ,0 ) ;
        
    SetCentiS(10);
      COLOR1=GetColorSensor( _COLOR_1_,1 ,4 );
      COLOR2=GetColorSensor( _COLOR_2_,1 ,4 );
    
    if ( COLOR1==2||COLOR2==2 )
    {
        SetCentiS(5);
          COLOR1=GetColorSensor( _COLOR_1_,1 ,4 );
          COLOR2=GetColorSensor( _COLOR_2_,1 ,4 );
        
        if ( COLOR1==2&&COLOR2==2 )
        {
                        for (int _FOR_0_ = 0; _FOR_0_ < 1; _FOR_0_++ )
                        {
                            SetInBeep(1);
                            SetCentiS( 50);
                            SetInMusicStop();
                            SetCentiS( 20);
                        }
            turn_around_sub();
        }
        else
        {
            if ( COLOR2==2 )
            {
                            for (int _FOR_0_ = 0; _FOR_0_ < 2; _FOR_0_++ )
                            {
                                SetInBeep(1);
                                SetCentiS( 5);
                                SetInMusicStop();
                                SetCentiS( 5);
                            }
                green_right_sub();
            }
            else
            {
                if ( COLOR1==2 )
                {
                                for (int _FOR_0_ = 0; _FOR_0_ < 1; _FOR_0_++ )
                                {
                                    SetInBeep(1);
                                    SetCentiS( 5);
                                    SetInMusicStop();
                                    SetCentiS( 5);
                                }
                    green_left_sub();
                }
                else
                {
                    line_sub();
                }
            }
        }
    }
    else
    {
        if ( I4>=700&&I5>=700&&I6>=700 )
        {
            turn_right_sub();
        }
        else
        {
            if ( I4>=700&&I5>=700&&I3>=700 )
            {
                turn_left_sub();
            }
            else
            {
                if ( I5>=700&&I7>=700 )
                {
                    turn_right_sub();
                }
                else
                {
                    if ( I4>=700&&I2>=700 )
                    {
                        turn_left_sub();
                    }
                    else
                    {
                        line_sub();
                    }
                }
            }
        }
    }
}
#endif

