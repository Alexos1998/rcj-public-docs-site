#ifndef _PINCHBALLSIDE_SUB_
#define _PINCHBALLSIDE_SUB_
#include <stm32f4xx.h>
#include <SetMotor2.h>

#include "HardwareInfo.c"
#include <GetData.h>
#include "turnleft_angle.c"
#include <SetUartData.h>
#include <SetTenthS.h>
#include <GetADScable10.h>
#include "lookball_sub.c"
#include "turnright_angle.c"
#include <GetUartData.h>
void PinchBallside_sub()
{
    // extern global var
    extern double ANGLE1;
    extern long ball;
    extern int ball1;
    extern long B;
    extern long ball2;

    double ANGLE = 0;
    int i = 0;
    long A = 0;
    long time = 0;
    long I = 0;
        if (B==2)
        {
          B=5;
        }
        else    // �����߮�
        {
         B=B-1;
        }
    ANGLE1 = GetData(B);
    turnleft_angle();
    SetUartData(1, 1, 2);
    SetTenthS(5);
    while ( !GetGpioState(_COMPASS_13_,1,1)&&!GetGpioState(_COMPASS_11_,1,1)&&!GetGpioState(_COMPASS_12_,1,1) )
    {
        SetMotor2( 1 , 40 );
        SetMotor2( 2 , 40 );
        
        I = GetADScable10(_SCABLEAD_5_);
        lookball_sub();
        if ( ball>=5 )
        {
            break;
        }
        else
        {
            if ( I>=1300 )
            {
                break;
            }
        }
    }
    SetMotor2( 1 , -50 );
    SetMotor2( 2 , -50 );
    
    SetTenthS(5);
        if (B==5)
        {
          B=2;
        }
        else    // �����߮�
        {
         B=B+1;
        }
    ANGLE1 = GetData(B);
    turnright_angle();
    for (int _FOR_0_ = 0; _FOR_0_ < 1000; _FOR_0_++ )
    {
        ball1 = GetUartData(2, 2);
        ball1 = GetUartData(1, 2);
    }
    ball1=0;
    ball=0;
}
#endif

