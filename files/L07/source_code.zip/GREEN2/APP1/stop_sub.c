#ifndef _STOP_SUB_
#define _STOP_SUB_
#include <stm32f4xx.h>

#include "HardwareInfo.c"
#include <SetMotor2.h>
void stop_sub()
{
    SetMotor2(1, 0);
    SetMotor2(2, 0);
}
#endif

