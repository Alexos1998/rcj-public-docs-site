#ifndef _POUROUTS_SUB_
#define _POUROUTS_SUB_
#include <stm32f4xx.h>
#include <GetCompassB.h>
#include <SetCentiS.h>
#include <SetInBeep.h>
#include <SetNS.h>
#include <SetTenthS.h>
#include <SetMotor2.h>
#include <GetADScable10.h>
#include <SetInMusicStop.h>

#include "HardwareInfo.c"
#include <GetUartData.h>
#include <SetLCDBack.h>
#include <SetTenthS.h>
#include <SetInSound.h>
#include <SetLCD3Char.h>
#include <SetInBeep.h>
#include <SetInMusicStop.h>
#include "touch_sub.c"
#include <SetServo.h>
#include <GetData.h>
void PourOutS_sub()
{
    // extern global var
    extern long TOUCH3;
    extern long TOUCH4;
    extern long S1;
    extern long S2;
    extern long DIS1;
    extern long DIS3;
    extern long DIS2;
    extern long DIS4;
    extern double ANGLE1;
    extern double INTEGRAL;
    extern long TOUCH1;
    extern long TOUCH2;
    extern long TOUCH5;
    extern long ball2;
    extern long SilverBall;
    extern long BlackBall;
    extern long ball;
    extern int ball1;
    extern long BlackBallOk;
    extern long SilverBallOk;
    extern long B;
    extern long D;

    long time = 0;
    long A = 0;
    long AVGL1 = 0;
    for (int _FOR_0_ = 0; _FOR_0_ < 500; _FOR_0_++ )
    {
        ball1 = GetUartData(1, 6);
    }
    while ( !GetGpioState(_COMPASS_11_,1,1) )
    {
        SetMotor2( 1 , 45 );
        SetMotor2( 2 , -40 );
        
        ball=0;
        ball1=0;
        SetLCDBack(1);
        ball1 = GetUartData(1, 6);
        if ( ball1>0&&ball1==8 )
        {
            ball=0;
            ball1=0;
                SetMotor2(1, 0);
                SetMotor2(2, 0);
            SetTenthS(5);
            while ( !GetGpioState(_COMPASS_11_,1,1) )
            {
                ball1 = GetUartData(1, 6);
                if ( ball1>0&&ball1==8 )
                {
                    ball=ball+1;
                }
                Sysdelayus(10);
                time++;
                if ( time>=1000 )
                {
                    ball=0;
                    break;
                }
                else
                {
                    if ( ball>=5 )
                    {
                        SetInSound(440, 100);
                        SetLCD3Char(0, 40, ball1, YELLOW, BLACK);
                        break;
                    }
                }
            }
            time=0;
        }
        if ( ball>=5 )
        {
            SetInBeep(1);
            SetTenthS(2);
            SetInMusicStop();
            while ( !GetGpioState(_COMPASS_11_,1,1) )
            {
                ball1 = GetUartData(1, 6);
                SetLCD3Char(0, 60, ball1, YELLOW, BLACK);
                if ( ball1==2 )
                {
                    SetMotor2( 1 , -35 );
                    SetMotor2( 2 ,  45 );
                    
                    A=0;
                }
                else
                {
                    if ( ball1==3 )
                    {
                        SetMotor2( 1 , 45 );
                        SetMotor2( 2 , -35 );
                        
                        A=0;
                    }
                    else
                    {
                        if ( ball1==1 )
                        {
                            SetMotor2( 1 , 50 );
                            SetMotor2( 2 , 50 );
                            
                            while ( !GetGpioState(_COMPASS_11_,1,1) )
                            {
                                touch_sub();
                                if ( TOUCH2==1&&TOUCH3==1 )
                                {
                                    SetMotor2( 1 , 0 );
                                    SetMotor2( 2 , 0 );
                                    
                                    SetTenthS(20000);
                                    SetServo(_SERVO_1_, 90);
                                    SetTenthS(2);
                                    SetServo(_SERVO_2_, 30);
                                    SetTenthS(3);
                                    SetServo(_SERVO_1_, 22);
                                        D=GetCompassB( _COMPASS_1_ );
                                        D=D-67;
                                        
                                        if (D<0)
                                        {
                                            D=D+360;
                                        }
                                        SetData(18, D);
                                    
                                    break;
                                }
                                else
                                {
                                    if ( TOUCH2==1&&TOUCH3==0 )
                                    {
                                        SetMotor2( 1 , -10 );
                                        SetMotor2( 2 , 70 );
                                        
                                    }
                                    else
                                    {
                                        if ( TOUCH2==0&&TOUCH3==1 )
                                        {
                                            SetMotor2( 1 , 70 );
                                            SetMotor2( 2 , -10 );
                                            
                                        }
                                        else
                                        {
                                            SetMotor2( 1 , 55 );
                                            SetMotor2( 2 , 50 );
                                            
                                        }
                                    }
                                }
                            }
                            break;
                        }
                        else
                        {
                            SetMotor2( 1 , 50 );
                            SetMotor2( 2 , -50 );
                            
                        }
                    }
                }
            }
            time=0;
            ANGLE1 = GetData(B);
            break;
        }
    }
}
#endif

