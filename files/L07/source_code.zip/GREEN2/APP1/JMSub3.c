#ifndef _JMSUB3_
#define _JMSUB3_
#include <stm32f4xx.h>
#include "JMDKernel.h"

#include "HardwareInfo.c"


#include <SetThousandthS.h>
#include <SetLCD5Char.h>
void JMSub3()
{
    // extern global var
    extern long distance3;

    long var0 = 0;
    long var1 = 0;
    long time = 0;
    long error_flag = 0;
    long distance = 0;
    long distime = 0;
        SetX4RCU_IO(_COMPASS_23_,0,1);//�t�mA1�ݤf�AS��??�J�Ҧ��A��EchoPin
        SetX4RCU_IO(_COMPASS_23_,1,0);//�t�mA1�ݤf�AD��??�X�Ҧ��A��TrigPin
    
    error_flag=0;time=0;distance3=0;distime=0;;
    SetGpioState(_COMPASS_23_,1,0);
    SetThousandthS(1);
    SetGpioState(_COMPASS_23_,1,1);
    Sysdelayus(60);
    SetGpioState(_COMPASS_23_,1,0);
    while ( !GetGpioState(_COMPASS_23_,0,0) )
    {
        Sysdelayus(10);
        time++;
        if ( time>=3000 )
        {
            error_flag=1;
            break;
        }
    }
    while ( GetGpioState(_COMPASS_23_,0,0)&&(error_flag==0) )
    {
        Sysdelayus(29);
        distime++;
        if ( distime>=1000 )
        {
            error_flag=1;
            break;
        }
    }
    distance3=distime/2;
    SetLCD5Char(0, 60, distance3, YELLOW, BLACK);
}
#endif

