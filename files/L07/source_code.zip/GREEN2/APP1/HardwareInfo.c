#ifndef _SCABLEAD_
#define _SCABLEAD_ unsigned long
#endif
#ifndef _SERVO_
#define _SERVO_ unsigned long
#endif
#ifndef _COMPASS_
#define _COMPASS_ unsigned long
#endif
#ifndef _COLOR_
#define _COLOR_ unsigned long
#endif
#ifndef _SCABLEAD_1_
#define _SCABLEAD_1_ 0
#endif
#ifndef _SCABLEAD_2_
#define _SCABLEAD_2_ 128
#endif
#ifndef _SCABLEAD_3_
#define _SCABLEAD_3_ 416
#endif
#ifndef _SCABLEAD_5_
#define _SCABLEAD_5_ 384
#endif
#ifndef _SCABLEAD_6_
#define _SCABLEAD_6_ 512
#endif
#ifndef _SCABLEAD_7_
#define _SCABLEAD_7_ 640
#endif
#ifndef _SCABLEAD_8_
#define _SCABLEAD_8_ 768
#endif
#ifndef _SCABLEAD_4_
#define _SCABLEAD_4_ 288
#endif
#ifndef _SERVO_1_
#define _SERVO_1_ 1168
#endif
#ifndef _SERVO_2_
#define _SERVO_2_ 144
#endif
#ifndef _SERVO_3_
#define _SERVO_3_ 1232
#endif
#ifndef _COMPASS_11_
#define _COMPASS_11_ 26624
#endif
#ifndef _COMPASS_1_
#define _COMPASS_1_ 170880
#endif
#ifndef _COMPASS_13_
#define _COMPASS_13_ 57632
#endif
#ifndef _COMPASS_16_
#define _COMPASS_16_ 152576
#endif
#ifndef _COMPASS_21_
#define _COMPASS_21_ 186912
#endif
#ifndef _COMPASS_22_
#define _COMPASS_22_ 220720
#endif
#ifndef _COMPASS_23_
#define _COMPASS_23_ 23568
#endif
#ifndef _COMPASS_24_
#define _COMPASS_24_ 41120
#endif
#ifndef _COMPASS_25_
#define _COMPASS_25_ 9552
#endif
#ifndef _COMPASS_12_
#define _COMPASS_12_ 199168
#endif
#ifndef _COMPASS_14_
#define _COMPASS_14_ 215424
#endif
#ifndef _COMPASS_15_
#define _COMPASS_15_ 90240
#endif
#ifndef _COLOR_1_
#define _COLOR_1_ 154272
#endif
#ifndef _COLOR_2_
#define _COLOR_2_ 24608
#endif
