#ifndef _LINE1_SUB_
#define _LINE1_SUB_
#include <stm32f4xx.h>
#include <GetColorSensor.h>
#include <SetTenthS.h>
#include <SetMotor2.h>
#include <SetInMusicStop.h>
#include <SetCentiS.h>
#include <SetInBeep.h>


#include "HardwareInfo.c"
void line1_sub()
{
    // extern global var
    extern double I3;
    extern double I4;
    extern double I5;
    extern double I6;
    extern double I7;
    extern double I8;
    extern long COLOR1;
    extern long COLOR2;
    extern double speed;
    extern double ERROR1;
    extern double ERROR2;
    extern double KP;
    extern double KD;
    extern double PD_VAL;
    extern double SPEED;
    extern double M1;
    extern double M2;
    extern double I1;
    extern double I2;
    extern long TIME;

    long LA = 0;
    long RA = 0;
      I1=GetADScable10( _SCABLEAD_1_ );
      I2=GetADScable10( _SCABLEAD_2_ );
      I3=GetADScable10( _SCABLEAD_3_ );
      I4=GetADScable10( _SCABLEAD_4_ );
      I5=GetADScable10( _SCABLEAD_5_ );
      I6=GetADScable10( _SCABLEAD_6_ );
      I7=GetADScable10( _SCABLEAD_7_ );
      I8=GetADScable10( _SCABLEAD_8_ );
        
      ERROR1=(I5*10-I4*10)/(I4+I5);
      PD_VAL=ERROR1*KP+(ERROR1-ERROR2)*KD;
      ERROR2=ERROR1;
      M1=SPEED+PD_VAL;
      M2=SPEED-PD_VAL;
      
      if (M1>=100)
      {
          M1=100;
      }
      else    // �����߮�
      {
          if (M1<=-100)
          {
              M1=-100;
          }
      }
      
      if (M2>=100)
      {
          M2=100;
      }
      else    // �����߮�
      {
          if (M2<=-100)
          {
              M2=-100;
          }
      }
      
      if (I2<700&&I3<700&&I4<700&&I5<700&&I6<700&&I7<700)
      {
         if (I1>=1300&&I8<=700)
         {
           SetMotor2( 1 ,-70 ) ;
           SetMotor2( 2 , 70 )  ;
           SetTenthS( 2 ) ;
         }
         else    // �����߮�
         {
             if (I8>=1300&&I1<=700)
             {
               SetMotor2( 1 ,70 ) ;
               SetMotor2( 2 , -70 )  ;
               SetTenthS( 2 ) ;
             }
             else    // �����߮�
             {
               SetMotor2( 1 ,70) ;
               SetMotor2( 2 ,70)  ;
             }
         }       
      }
      else    // �����߮�
      {
         SetMotor2( 1 ,M1) ;
         SetMotor2( 2 ,M2)  ;
      }  
        
}
#endif

