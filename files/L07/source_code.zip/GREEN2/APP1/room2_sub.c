#ifndef _ROOM2_SUB_
#define _ROOM2_SUB_
#include <stm32f4xx.h>
#include <SetMotor2.h>
#include <SetTenthS.h>
#include <SetLCD3Char.h>
#include <SetInBeep.h>
#include <SetInMusicStop.h>
#include <SetTenthS.h>
#include <GetData.h>

#include "HardwareInfo.c"
#include "touch_sub.c"
#include "lookball_sub.c"
#include "sideball_sub.c"
#include "JMSub1.c"
#include "JMSub2.c"
#include "JMSub3.c"
#include <GetADScable10.h>
#include <SetUartData.h>
#include <SetTenthS.h>
#include <GetUartData.h>
#include <GetData.h>
#include "turnright_angle.c"
#include "PourOutS_sub.c"
#include "turnleft_angle.c"
#include "PourOutB_sub.c"
#include "Exit_sub.c"
void room2_sub()
{
    // extern global var
    extern double ANGLE1;
    extern long ball;
    extern int ball1;
    extern long ball2;
    extern long ball22;
    extern long B;
    extern long distance1;
    extern long distance2;
    extern long distance3;
    extern long distance4;
    extern long distance5;
    extern long TOUCH1;
    extern long TOUCH2;
    extern long TOUCH3;
    extern long TOUCH4;
    extern long TOUCH5;
    extern long TOUCH6;
    extern long TOUCH7;
    extern double I5;
    extern long ENT;
    extern long SilverBall;
    extern long BlackBall;
    extern long SilverBallOk;
    extern long BlackBallOk;

    double ANGLE = 0;
    int i = 0;
    long A = 0;
    while ( !GetGpioState(_COMPASS_11_,1,1) )
    {
        touch_sub();
        lookball_sub();
        sideball_sub();
        JMSub1();
        JMSub2();
        JMSub3();
        I5 = GetADScable10(_SCABLEAD_5_);
        if ( distance3<=20&&distance3>2 )
        {
            SetUartData(1, 3, 2);
            SetUartData(2, 0, 2);
                SetMotor2(1, 0);
                SetMotor2(2, 0);
              
            SetTenthS(5);
            for (int _FOR_0_ = 0; _FOR_0_ < 5; _FOR_0_++ )
            {
                ball1 = GetUartData(1, 2);
                ball1=ball1-48;
            }
            if ( ball1>7&&ball1<=10 )
            {
                SetUartData(1, 0, 2);
                if ( SilverBall>0&&ball1==8 )
                {
                                     for (int _FOR_0_ = 0; _FOR_0_ < 3; _FOR_0_++ )
                            {
                                SetInBeep(ON);
                                SetTenthS(1);
                                SetInMusicStop();
                                SetTenthS(1);
                            }
                        SetMotor2(1, -50);
                        SetMotor2(2, -50);
                      
                    SetTenthS(2);
                        if (B==5)
                        {
                          B=2;
                        }
                        else    // �����߮�
                        {
                         B=B+1;
                        }
                    ANGLE1 = GetData(B);
                       ANGLE1=ANGLE1+45;
                         if (ANGLE1>=360)
                        {
                          ANGLE1=ANGLE1-360;
                        }
                      
                    turnright_angle();
                        SetMotor2(1, -40);
                        SetMotor2(2, -40);
                      
                    SetTenthS(5);
                        SetMotor2(1, 0);
                        SetMotor2(2, 0);
                      
                    PourOutS_sub();
                    SilverBallOk=SilverBallOk+SilverBall;
                    SilverBall=0;
                    
                        if (B==2)
                        {
                          B=5;
                        }
                        else    // �����߮�
                        {
                         B=B-1;
                        }
                    ANGLE1 = GetData(B);
                    turnleft_angle();
                }
                else
                {
                    if ( SilverBallOk>=2&&ball1==9&&BlackBall>=1 )
                    {
                                         for (int _FOR_0_ = 0; _FOR_0_ < 2; _FOR_0_++ )
                                {
                                    SetInBeep(ON);
                                    SetTenthS(1);
                                    SetInMusicStop();
                                    SetTenthS(1);
                                }
                            SetMotor2(1, -50);
                            SetMotor2(2, -50);
                          
                        SetTenthS(2);
                            if (B==5)
                            {
                              B=2;
                            }
                            else    // �����߮�
                            {
                             B=B+1;
                            }
                        ANGLE1 = GetData(B);
                           ANGLE1=ANGLE1+45;
                             if (ANGLE1>=360)
                            {
                              ANGLE1=ANGLE1-360;
                            }
                          
                        turnright_angle();
                            SetMotor2(1, -40);
                            SetMotor2(2, -40);
                          
                        SetTenthS(5);
                            SetMotor2(1, 0);
                            SetMotor2(2, 0);
                          
                        PourOutB_sub();
                        Exit_sub();
                        BlackBallOk=BlackBallOk+BlackBall;
                        BlackBall=0;
                            if (B==2)
                            {
                              B=5;
                            }
                            else    // �����߮�
                            {
                             B=B-1;
                            }
                        ANGLE1 = GetData(B);
                        turnleft_angle();
                    }
                }
            }
            break;
        }
        else
        {
            if ( TOUCH2==1||TOUCH3==1 )
            {
                SetUartData(1, 0, 2);
                SetUartData(2, 0, 2);
                    SetMotor2(1, -50);
                    SetMotor2(2, -50);
                  
                SetTenthS(5);
                break;
            }
            else
            {
                if ( I5<=ENT||I5>=1300 )
                {
                    SetUartData(1, 0, 2);
                    SetUartData(2, 0, 2);
                        SetMotor2(1, -50);
                        SetMotor2(2, -50);
                      
                    SetTenthS(5);
                    break;
                }
                else
                {
                    if ( distance2<=15&&distance1<=15 )
                    {
                            SetMotor2(1, 60);
                            SetMotor2(2, 50);
                          
                    }
                    else
                    {
                        if ( distance1<=80&&distance2>=25&&distance2<=80 )
                        {
                                SetMotor2(1, 50);
                                SetMotor2(2, 60);
                              
                        }
                        else
                        {
                                SetMotor2(1, 50);
                                SetMotor2(2, 50);
                              
                        }
                    }
                }
            }
        }
    }
}
#endif

