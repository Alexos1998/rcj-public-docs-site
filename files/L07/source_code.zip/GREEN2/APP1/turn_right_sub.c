#ifndef _TURN_RIGHT_SUB_
#define _TURN_RIGHT_SUB_
#include <stm32f4xx.h>
#include <GetColorSensor.h>
#include <SetTenthS.h>
#include <SetMotor2.h>
#include <SetInMusicStop.h>
#include <SetCentiS.h>
#include <SetInBeep.h>


#include "HardwareInfo.c"
#include "eyes_sub.c"
#include <SetCentiS.h>
#include "line2_sub.c"
void turn_right_sub()
{
    // extern global var
    extern double I3;
    extern double I4;
    extern double I5;
    extern double I6;
    extern double I7;
    extern double I8;
    extern long COLOR1;
    extern long COLOR2;
    extern double speed;
    extern double ERROR1;
    extern double ERROR2;
    extern double KP;
    extern double KD;
    extern double PD_VAL;
    extern double SPEED;
    extern double M1;
    extern double M2;
    extern double I1;
    extern double I2;
    extern long TIME;
    extern long LA;
    extern long RA;

    long R1 = 0;
    RA=0;
    R1=0;
    for (int _FOR_0_ = 0; _FOR_0_ < 70; _FOR_0_++ )
    {
        eyes_sub();
        if ( I1>1000&&I8>=1000 )
        {
            R1=1;
        }
        if ( I4<=700&&I5<=700 )
        {
                SetMotor2(1, 0 );
                SetMotor2(2, 0 );
                
            
            RA=0;
            break;
        }
        else
        {
            if ( COLOR1==2||COLOR2==2 )
            {
                    SetMotor2(1, 0 );
                    SetMotor2(2, 0 );
                    
                
                RA=1;
                break;
            }
            else
            {
                  I1=GetADScable10( _SCABLEAD_1_ );
                  I2=GetADScable10( _SCABLEAD_2_ );
                  I3=GetADScable10( _SCABLEAD_3_ );
                  I4=GetADScable10( _SCABLEAD_4_ );
                  I5=GetADScable10( _SCABLEAD_5_ );
                  I6=GetADScable10( _SCABLEAD_6_ );
                  I7=GetADScable10( _SCABLEAD_7_ );
                  I8=GetADScable10( _SCABLEAD_8_ );
                 
                  //ERROR1=(I7*30+I6*20+I5*10-I4*10-I3*20-I2*30)/(I2+I3+I4+I5+I6+I7);
                  //ERROR1=(I6*20+I5*10-I4*10-I3*20)/(I3+I4+I5+I6);
                  ERROR1=(I5*10-I4*10)/(I4+I5);  
                  
                  PD_VAL=ERROR1*3+(ERROR1-ERROR2)*2;
                  ERROR2=ERROR1;
                  M1=SPEED+PD_VAL;
                  M2=SPEED-PD_VAL;
                  
                  if (M1>=70)
                  {
                      M1=70;
                  }
                  else    // �����߮�
                  {
                      if (M1<=0-70)
                      {
                          M1=0-70;
                      }
                  }
                  
                  if (M2>=70)
                  {
                      M2=70;
                  }
                  else    // �����߮�
                  {
                      if (M2<=0-70)
                      {
                          M2=0-70;
                      }
                  }
                  
                   
                  //if(I2<700&&I3<700&&I4<700&&I5<700&&I6<700&&I7<700)
                  //if (I3<700&&I4<700&&I5<700&&I6<700)
                  if (I4<700&&I5<700)
                  
                  {
                      
                     //if(I1>1000)
                     //if (I1>1000||I2>1000)
                     if (I1>1000||I2>1000||I3>1000)
                     
                     {
                       SetMotor2( 1 ,-50 ) ;
                       SetMotor2( 2 , 50 )  ;
                       SetTenthS( 1 ) ;
                     }
                     else    // �����߮�
                     {
                         //if (I8>1000)
                         //if (I8>1000||I7>1000)
                         if (I8>1000||I7>1000||I6>1000)
                         
                         {
                           SetMotor2( 1 ,50 ) ;
                           SetMotor2( 2 , -50 )  ;
                           SetTenthS( 1 ) ;
                         }
                         else    // �����߮�
                         {
                           SetMotor2( 1 ,60) ;
                           SetMotor2( 2 ,-60)  ;
                         }
                     }       
                  }
                  else    // �����߮�
                  {
                     SetMotor2( 1 ,M1) ;
                     SetMotor2( 2 ,M2)  ;
                  }  
                    
                  
            }
        }
    }
    if ( RA==0 )
    {
        while (1)
        {
            eyes_sub();
            if ( I4<=700&&I5<=700 )
            {
                    SetMotor2(1, 50 );
                    SetMotor2(2, 50 );
                    
                
                SetCentiS(12);
                while (1)
                {
                        SetMotor2(1, 60 );
                        SetMotor2(2,-60 );
                        
                    
                    eyes_sub();
                    if ( I4>=700&&I5>=700&&I6<=700 )
                    {
                        for (int _FOR_1_ = 0; _FOR_1_ < 1100; _FOR_1_++ )
                        {
                            line2_sub();
                        }
                        break;
                    }
                }
                break;
            }
            else
            {
                if ( I6<=700 )
                {
                    break;
                }
                else
                {
                      I1=GetADScable10( _SCABLEAD_1_ );
                      I2=GetADScable10( _SCABLEAD_2_ );
                      I3=GetADScable10( _SCABLEAD_3_ );
                      I4=GetADScable10( _SCABLEAD_4_ );
                      I5=GetADScable10( _SCABLEAD_5_ );
                      I6=GetADScable10( _SCABLEAD_6_ );
                      I7=GetADScable10( _SCABLEAD_7_ );
                      I8=GetADScable10( _SCABLEAD_8_ );
                     
                      //ERROR1=(I7*30+I6*20+I5*10-I4*10-I3*20-I2*30)/(I2+I3+I4+I5+I6+I7);
                      //ERROR1=(I6*20+I5*10-I4*10-I3*20)/(I3+I4+I5+I6);
                      ERROR1=(I5*10-I4*10)/(I4+I5);  
                      
                      PD_VAL=ERROR1*3+(ERROR1-ERROR2)*2;
                      ERROR2=ERROR1;
                      M1=SPEED+PD_VAL;
                      M2=SPEED-PD_VAL;
                      
                      if (M1>=70)
                      {
                          M1=70;
                      }
                      else    // �����߮�
                      {
                          if (M1<=0-70)
                          {
                              M1=0-70;
                          }
                      }
                      
                      if (M2>=70)
                      {
                          M2=70;
                      }
                      else    // �����߮�
                      {
                          if (M2<=0-70)
                          {
                              M2=0-70;
                          }
                      }
                      
                       
                      //if(I2<700&&I3<700&&I4<700&&I5<700&&I6<700&&I7<700)
                      //if (I3<700&&I4<700&&I5<700&&I6<700)
                      if (I4<700&&I5<700)
                      
                      {
                          
                         //if(I1>1000)
                         //if (I1>1000||I2>1000)
                         if (I1>1000||I2>1000||I3>1000)
                         
                         {
                           SetMotor2( 1 ,-50 ) ;
                           SetMotor2( 2 , 50 )  ;
                           SetTenthS( 1 ) ;
                         }
                         else    // �����߮�
                         {
                             //if (I8>1000)
                             //if (I8>1000||I7>1000)
                             if (I8>1000||I7>1000||I6>1000)
                             
                             {
                               SetMotor2( 1 ,50 ) ;
                               SetMotor2( 2 , -50 )  ;
                               SetTenthS( 1 ) ;
                             }
                             else    // �����߮�
                             {
                               SetMotor2( 1 ,60) ;
                               SetMotor2( 2 ,-60)  ;
                             }
                         }       
                      }
                      else    // �����߮�
                      {
                         SetMotor2( 1 ,M1) ;
                         SetMotor2( 2 ,M2)  ;
                      }  
                        
                      
                }
            }
        }
    }
}
#endif

