#ifndef _ROOM_MID_
#define _ROOM_MID_
#include <stm32f4xx.h>
#include <SetMotor2.h>
#include <SetTenthS.h>
#include <SetLCD3Char.h>
#include <SetInBeep.h>
#include <SetInMusicStop.h>
#include <SetTenthS.h>
#include <GetData.h>

#include "HardwareInfo.c"
#include "touch_sub.c"
#include "JMSub1.c"
#include "JMSub2.c"
#include "JMSub3.c"
#include <GetCompassB.h>
#include <GetData.h>
#include "turnleft_angle.c"
#include "turnright_angle.c"
#include "PinchBall1_sub.c"
#include <SetUartData.h>
#include "lookball_sub.c"
#include <SetNS.h>
void room_mid()
{
    // extern global var
    extern double ANGLE1;
    extern long ball;
    extern long ball1;
    extern long ball2;
    extern long ball22;
    extern long B;
    extern long distance1;
    extern long distance2;
    extern long distance3;
    extern long distance4;
    extern long distance5;
    extern long TOUCH1;
    extern long TOUCH2;
    extern long TOUCH3;
    extern long TOUCH4;
    extern long TOUCH5;
    extern long TOUCH6;
    extern long TOUCH7;
    extern double I5;
    extern long ENT;
    extern long SilverBall;
    extern long BlackBall;
    extern long SilverBallOk;
    extern long BlackBallOk;

    double ANGLE = 0;
    int i = 0;
    long A = 0;
    while ( !GetGpioState(_COMPASS_11_,1,1) )
    {
        touch_sub();
        JMSub1();
        JMSub2();
        JMSub3();
        ANGLE = GetCompassB(_COMPASS_1_);
        B=2;
        ANGLE1 = GetData(B);
        if ( ANGLE<90 )
        {
            turnleft_angle();
        }
        else
        {
            if ( ANGLE>270 )
            {
                turnright_angle();
            }
            else
            {
                turnleft_angle();
            }
        }
        PinchBall1_sub();
        SetUartData(1, 1, 2);
            SetMotor2(1, 0);
            SetMotor2(2, 0);
            SetTenthS(5);
        
        ball1=0;
        ball=0;
        for (int _FOR_0_ = 0; _FOR_0_ < 100; _FOR_0_++ )
        {
            lookball_sub();
        }
        while (1)
        {
            JMSub3();
                SetMotor2(1, 50);
                SetMotor2(2, 50);
              
            if ( distance3<=30 )
            {
                    SetMotor2(1, 0);
                    SetMotor2(2, 0);
                  
                break;
            }
            else
            {
                    SetMotor2(1, 50);
                    SetMotor2(2, 50);
                  
            }
        }
        SetNS(50);
    }
}
#endif

