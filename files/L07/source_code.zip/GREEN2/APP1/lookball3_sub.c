#ifndef _LOOKBALL3_SUB_
#define _LOOKBALL3_SUB_
#include <stm32f4xx.h>
#include <SetMotor2.h>

#include "HardwareInfo.c"
#include <GetUartData.h>
#include <SetLCDBack.h>
#include <SetTenthS.h>
#include <SetInSound.h>
#include <SetUartData.h>
#include "PinchBall_sub.c"
#include <SetNS.h>
#include "PourOutB_sub.c"
#include <GetData.h>
void lookball3_sub()
{
    // extern global var
    extern double ANGLE1;
    extern long ball;
    extern int ball3;
    extern long B;
    extern long SilverBall;
    extern long BlackBall;
    extern long SilverBallOK;
    extern long BlackBallOK;

    double ANGLE = 0;
    int i = 0;
    long A = 0;
    long time = 0;
        SetMotor2(1, 0);
        SetMotor2(2, 0);
    for (int _FOR_0_ = 0; _FOR_0_ < 1000; _FOR_0_++ )
    {
        ball3 = GetUartData(2, 6);
    }
    while ( !GetGpioState(_COMPASS_11_,1,1) )
    {
        SetLCDBack(1);
        ball3 = GetUartData(2, 6);
        if ( ball3>0&&ball3<6 )
        {
            ball=0;
            ball3=0;
                SetMotor2(1, 0);
                SetMotor2(2, 0);
            SetTenthS(3);
            while ( !GetGpioState(_COMPASS_11_,1,1) )
            {
                ball3 = GetUartData(2, 6);
                if ( ball3>0&&ball3<6 )
                {
                    ball=ball+1;
                }
                Sysdelayus(10);
                time++;
                if ( time>=1000 )
                {
                    ball=0;
                    break;
                }
                else
                {
                    if ( ball>=4 )
                    {
                        SetInSound(440, 100);
                        break;
                    }
                }
            }
            time=0;
        }
        else
        {
                SetMotor2(1, 40);
                SetMotor2(2, -30);
        }
        if ( ball>0 )
        {
            while ( !GetGpioState(_COMPASS_11_,1,1) )
            {
                ball3 = GetUartData(2, 6);
                if ( ball3==2 )
                {
                    SetMotor2( 1 , -35 );
                    SetMotor2( 2 ,  45);
                    
                    A=0;
                }
                else
                {
                    if ( ball3==5 )
                    {
                        SetMotor2( 1 , 45);
                        SetMotor2( 2 , -35 );
                        
                        A=0;
                    }
                    else
                    {
                        if ( ball3==3 )
                        {
                            SetMotor2( 1 , 35 );
                            SetMotor2( 2 , 35 );
                            
                            A=0;
                        }
                        else
                        {
                            if ( ball3==4 )
                            {
                                SetMotor2( 1 , -40 );
                                SetMotor2( 2 , -40 );
                                
                                A=0;
                            }
                            else
                            {
                                if ( ball3==1 )
                                {
                                    SetMotor2( 1 , 0 );
                                    SetMotor2( 2 , 0 );
                                    
                                    SetUartData(2, 3, 6);
                                    PinchBall_sub();
                                    if ( BlackBall>0 )
                                    {
                                        SetUartData(1, 3, 6);
                                        SetNS(2);
                                        SetMotor2( 1 , 45 );
                                        SetMotor2( 2 , -40 );
                                        
                                        PourOutB_sub();
                                        SetMotor2( 1 , -50 );
                                        SetMotor2( 2 , -50 );
                                        BlackBall=0;
                                        BlackBallOK=BlackBallOK+1;
                                        SetTenthS(20);
                                        SetMotor2( 1 , 0 );
                                        SetMotor2( 2 , 0 );
                                        
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            time=0;
            ANGLE1 = GetData(B);
            break;
        }
    }
}
#endif

