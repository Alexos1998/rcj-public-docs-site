# Edge Impulse - OpenMV FOMO Object Detection Example
#
# MIT License (c) 2013-2024 OpenMV LLC.
# https://github.com/openmv/openmv/blob/master/LICENSE

import sensor, image, time, ml, math, uos, gc
from pyb import Pin, Timer, UART

#---------------------- 相機初始化 ----------------------
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QQVGA)
sensor.set_windowing((240, 240))
sensor.skip_frames(time=2000)
sensor.set_vflip(True)
sensor.set_hmirror(True)

#---------------------- UART 與燈光設定 ----------------------
uart = UART(3, 115200, timeout_char=200)
light = Timer(2, freq=50000).channel(1, Timer.PWM, pin=Pin("P6"))
light.pulse_width_percent(0)

#---------------------- 模型與標籤 ----------------------
n = b'\x01'# #  b'\x01'#
net = None
labels = None
min_confidence = 0.3

rd = 255
gd = 255
bd = 255
labe = (60, 80, 100, 30)

try:
    net = ml.Model("trained.tflite", load_to_fb=uos.stat('trained.tflite')[6] > (gc.mem_free() - (64*1024)))
except Exception as e:
    raise Exception('Failed to load "trained.tflite". (' + str(e) + ')')

try:
    labels = [line.rstrip('\n') for line in open("labels.txt")]
except Exception as e:
    raise Exception('Failed to load "labels.txt". (' + str(e) + ')')

colors = [
    (255,   0,   0),
    (  0, 255,   0),
    (255, 255,   0),
    (  0,   0, 255),
    (255,   0, 255),
    (  0, 255, 255),
    (255, 255, 255),
]

threshold_list = [(math.ceil(min_confidence * 255), 255)]

#---------------------- 輔助函式 ----------------------
def draw():
    img.draw_line(labe[0], 0, labe[0], 120, color=(rd, gd, bd), thickness=1)
    img.draw_line(labe[2], 0, labe[2], 120, color=(rd, gd, bd), thickness=1)
    img.draw_line(0, labe[1], 160, labe[1], color=(rd, gd, bd), thickness=1)
    img.draw_line(labe[0], labe[0], labe[2], labe[0], color=(rd, gd, bd), thickness=1)
def ball():
    if x > labe[0] and x < labe[2] and y < labe[0]:
        print(1)
        uart.writechar(1)
    elif x >= 50  and x <= 100 and y <= 80 and y >= 60:
        print(5)  # 右
        uart.writechar(2)
    elif x <50:
        print(3)  # 左
        uart.writechar(3)
    elif x >= 100:
        print(2)  # 中上
        uart.writechar(5)
    elif y > 80:
        print(4)  # 中上
        uart.writechar(4)
def fomo_post_process(model, inputs, outputs):
    ob, oh, ow, oc = model.output_shape[0]
    x_scale = inputs[0].roi[2] / ow
    y_scale = inputs[0].roi[3] / oh
    scale = min(x_scale, y_scale)
    x_offset = ((inputs[0].roi[2] - (ow * scale)) / 2) + inputs[0].roi[0]
    y_offset = ((inputs[0].roi[3] - (ow * scale)) / 2) + inputs[0].roi[1]
    l = [[] for i in range(oc)]
    for i in range(oc):
        img_out = image.Image(outputs[0][0, :, :, i] * 255)
        blobs = img_out.find_blobs(threshold_list, x_stride=1, y_stride=1, area_threshold=1, pixels_threshold=1)
        for b in blobs:
            rect = b.rect()
            x_, y_, w_, h_ = rect
            score = img_out.get_statistics(thresholds=threshold_list, roi=rect).l_mean() / 255.0
            x_ = int((x_ * scale) + x_offset)
            y_ = int((y_ * scale) + y_offset)
            w_ = int(w_ * scale)
            h_ = int(h_ * scale)
            l[i].append((x_, y_, w_, h_, score))
    return l

#---------------------- 主程式 ----------------------
clock = time.clock()

while(True):
    if uart.any():
        n = uart.read()

    img = sensor.snapshot()

    #---------------------------------------------------------------
    # 模式 1：FOMO 偵測銀球
    #---------------------------------------------------------------
    if n == b'\x01' :
        if uart.any(): n = uart.read()
        best_detection = None
        max_y = -1
        best_label = None
        best_color = None

        for i, detection_list in enumerate(net.predict([img], callback=fomo_post_process)):
            if i == 0 or len(detection_list) == 0:
                continue
            for x_, y_, w_, h_, score in detection_list:
                center_y = math.floor(y_ + (h_ / 2))
                if center_y > max_y:
                    max_y = center_y
                    best_detection = (x_, y_, w_, h_)
                    best_label = labels[i]
                    best_color = colors[i]
        if best_detection:
            x1, y1, w, h = best_detection
            x = math.floor(x1 + w / 2)
            y = math.floor(y1 + h / 2)
            img.draw_circle((x, y, w), color=best_color)
            if best_label == "sliver":
                ball()
                print(f"x={x}\ty={y}\t{best_label}")
        #else:
        # uart.writechar(0)
        # print(0)
        draw()
    #---------------------------------------------------------------
    # 模式 2：FOMO 偵測黑球（與模式1相同邏輯）
    #---------------------------------------------------------------
    if n == b'\x02':
        if uart.any(): n = uart.read()
        best_detection = None
        max_y = -1
        best_label = None
        best_color = None

        for i, detection_list in enumerate(net.predict([img], callback=fomo_post_process)):
            if i == 0 or len(detection_list) == 0:
                continue
            for x_, y_, w_, h_, score in detection_list:
                center_y = math.floor(y_ + (h_ / 2))
                if center_y > max_y:
                   max_y = center_y
                   best_detection = (x_, y_, w_, h_)
                   best_label = labels[i]
                   best_color = colors[i]
        if best_detection:
            x1, y1, w, h = best_detection
            x = math.floor(x1 + w / 2)
            y = math.floor(y1 + h / 2)
            img.draw_circle((x, y, w), color=best_color)
            if best_label == "black":
                ball()
                print(f"x={x}\ty={y}\t{best_label}")

        draw()

    #---------------------------------------------------------------
    # 模式 3：找紅色方塊
    #---------------------------------------------------------------
    if n == b'\x03':
        if uart.any(): n = uart.read()
        img = sensor.snapshot()

        red_threshold = (0, 30, 15, 50, 10, 35)  # 紅色色域（LAB）
        blobs = img.find_blobs([red_threshold], pixels_threshold=100, area_threshold=100, merge=True)

        if blobs:
            largest_blob = max(blobs, key=lambda b: b.pixels())
            x = largest_blob.cx()
            y = largest_blob.cy()
            img.draw_rectangle(largest_blob.rect(), color=(255, 0, 0))
            img.draw_cross(x, y, color=(255, 0, 0))
            print("紅色方塊座標:", x, y,"7")
            uart.writechar(7)
            ball()


    #---------------------------------------------------------------
    # 模式 4：找綠色方塊
    #---------------------------------------------------------------
    if n == b'\x04':
        if uart.any(): n = uart.read()
        img = sensor.snapshot()

        green_threshold = (5, 20, -20, -10, -10, 10)  # 綠色色域（LAB）
        blobs = img.find_blobs([green_threshold], pixels_threshold=100, area_threshold=100, merge=True)

        if blobs:
            largest_blob = max(blobs, key=lambda b: b.pixels())
            x = largest_blob.cx()
            y = largest_blob.cy()
            img.draw_rectangle(largest_blob.rect(), color=(0, 255, 0))
            img.draw_cross(x, y, color=(0, 255, 0))
            print("綠色方塊座標:", x, y,"8")
            uart.writechar(8)
            ball()


    #print(clock.fps(), "fps")
