#ifndef _EYES_SUB_
#define _EYES_SUB_
#include <stm32f4xx.h>
#include <SetNS.h>
#include <GetADScable10.h>
#include <GetColorSensor.h>
#include <SetTenthS.h>
#include <SetMotor2.h>
#include <SetInMusicStop.h>
#include <SetCentiS.h>
#include <SetInBeep.h>


#include "HardwareInfo.c"
void eyes_sub()
{
    // extern global var
    extern double I3;
    extern double I4;
    extern double I5;
    extern double I6;
    extern double I7;
    extern double I8;
    extern long COLOR1;
    extern long COLOR2;
    extern double speed;
    extern double ERROR1;
    extern double ERROR2;
    extern double KP;
    extern double KD;
    extern double PD_VAL;
    extern double SPEED;
    extern double M1;
    extern double M2;
    extern double I1;
    extern double I2;
    extern long TIME;

    long LA = 0;
    long RA = 0;
      I1=GetADScable10( _SCABLEAD_1_ );
      I2=GetADScable10( _SCABLEAD_2_ );
      I3=GetADScable10( _SCABLEAD_3_ );
      I4=GetADScable10( _SCABLEAD_4_ );
      I5=GetADScable10( _SCABLEAD_5_ );
      I6=GetADScable10( _SCABLEAD_6_ );
      I7=GetADScable10( _SCABLEAD_7_ );
      I8=GetADScable10( _SCABLEAD_8_ );
      COLOR1=GetColorSensor( _COLOR_1_ ,1 ,4 )  ;
      COLOR2=GetColorSensor( _COLOR_2_ ,1 ,4 )  ;
     
}
#endif

