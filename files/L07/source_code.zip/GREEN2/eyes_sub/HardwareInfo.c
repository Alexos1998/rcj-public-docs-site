#ifndef _SCABLEAD_
#define _SCABLEAD_ unsigned long
#endif
#ifndef _COLOR_
#define _COLOR_ unsigned long
#endif
#ifndef _SCABLEAD_1_
#define _SCABLEAD_1_ 384
#endif
#ifndef _SCABLEAD_2_
#define _SCABLEAD_2_ 512
#endif
#ifndef _SCABLEAD_3_
#define _SCABLEAD_3_ 640
#endif
#ifndef _SCABLEAD_4_
#define _SCABLEAD_4_ 768
#endif
#ifndef _SCABLEAD_5_
#define _SCABLEAD_5_ 0
#endif
#ifndef _SCABLEAD_6_
#define _SCABLEAD_6_ 128
#endif
#ifndef _SCABLEAD_7_
#define _SCABLEAD_7_ 416
#endif
#ifndef _SCABLEAD_8_
#define _SCABLEAD_8_ 288
#endif
#ifndef _COLOR_1_
#define _COLOR_1_ 170880
#endif
#ifndef _COLOR_2_
#define _COLOR_2_ 41120
#endif
