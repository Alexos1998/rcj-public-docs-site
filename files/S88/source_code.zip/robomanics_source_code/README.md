# Robomanics - RoboCupJunior Rescue Simulation 2026

This source code package represents the main software architecture for Team Robomanics.

## Main Features
- Occupancy-grid mapping
- GPS + IMU localization
- Autonomous navigation
- Path planning
- YOLO-based victim detection
- Cognitive target detection
- Recovery logic
- Main controller loop

## Programming Language
Python

## Main Entry Point
Run:

```bash
python main_controller.py
```

## Team
- Laila Hassan Elhadidy Abdelalim Nawara - Navigation & Detection
- Fareeda Hossameldin Abd El Gaber - Navigation & Detection
- Ziad Basem Haroun Abdelaziz ElGamal - Mapping

Coach: Dr. Amal Mehanna  
Co-Coach: AL. Ibrahim Tagen
