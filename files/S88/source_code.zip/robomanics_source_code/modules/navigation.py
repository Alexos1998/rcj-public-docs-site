from collections import deque


class NavigationModule:
    def __init__(self):
        self.replan_required = False

    def select_next_goal(self, grid, current_position):
        unexplored = self._find_unexplored_cells(grid)
        if not unexplored:
            return current_position

        return min(
            unexplored,
            key=lambda cell: abs(cell[0] - current_position[0]) + abs(cell[1] - current_position[1])
        )

    def generate_path(self, grid, start, goal):
        # Breadth-first search path planning.
        start = tuple(map(int, start))
        goal = tuple(map(int, goal))

        queue = deque([(start, [start])])
        visited = set()

        while queue:
            current, path = queue.popleft()

            if current == goal:
                return path

            if current in visited:
                continue

            visited.add(current)

            for neighbor in self._neighbors(current):
                if self._is_safe(grid, neighbor) and neighbor not in visited:
                    queue.append((neighbor, path + [neighbor]))

        return []

    def path_to_command(self, path):
        if len(path) < 2:
            return "STOP"

        current = path[0]
        next_cell = path[1]

        dx = next_cell[0] - current[0]
        dy = next_cell[1] - current[1]

        if dx > 0:
            return "MOVE_RIGHT"
        if dx < 0:
            return "MOVE_LEFT"
        if dy > 0:
            return "MOVE_DOWN"
        if dy < 0:
            return "MOVE_UP"

        return "STOP"

    def mission_completed(self, grid):
        return not self._find_unexplored_cells(grid)

    def _find_unexplored_cells(self, grid):
        cells = []
        for y in range(grid.shape[0]):
            for x in range(grid.shape[1]):
                if grid[y, x] == -1:
                    cells.append((x, y))
        return cells

    def _neighbors(self, cell):
        x, y = cell
        return [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]

    def _is_safe(self, grid, cell):
        x, y = cell
        if not (0 <= y < grid.shape[0] and 0 <= x < grid.shape[1]):
            return False

        blocked_states = {1, 2}
        return grid[y, x] not in blocked_states
