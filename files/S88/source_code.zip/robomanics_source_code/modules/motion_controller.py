class MotionController:
    def execute(self, command):
        # Replace this with Webots motor commands.
        print(f"Executing movement command: {command}")

        if command == "STOP":
            return True

        return True

    def return_to_start(self):
        print("Returning to start tile...")

    def send_exit_command(self):
        print("Sending exit command...")
