try:
    from ultralytics import YOLO
except ImportError:
    YOLO = None


class VictimDetectionModule:
    def __init__(self, model_path="models/yolo_victim_model.pt"):
        self.model = YOLO(model_path) if YOLO else None
        self.confidence_threshold = 0.5

    def detect(self, frame):
        if frame is None or self.model is None:
            return None

        results = self.model(frame)

        for result in results:
            for box in result.boxes:
                confidence = float(box.conf[0])
                class_id = int(box.cls[0])

                if confidence >= self.confidence_threshold:
                    return {
                        "class_id": class_id,
                        "confidence": confidence,
                        "bbox": box.xyxy[0].tolist()
                    }

        return None

    def report(self, victim, position):
        print(f"Victim detected at {position}: {victim}")
