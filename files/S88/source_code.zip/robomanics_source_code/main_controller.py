from modules.mapping import MappingModule
from modules.navigation import NavigationModule
from modules.victim_detection import VictimDetectionModule
from modules.cognitive_detection import CognitiveTargetDetectionModule
from modules.motion_controller import MotionController
from modules.recovery import RecoveryModule


class RobomanicsController:
    def __init__(self):
        self.mapping = MappingModule()
        self.navigation = NavigationModule()
        self.victim_detection = VictimDetectionModule()
        self.cognitive_detection = CognitiveTargetDetectionModule()
        self.motion = MotionController()
        self.recovery = RecoveryModule()
        self.running = True

    def read_sensor_data(self):
        # Replace this mock data with Webots sensor readings.
        return {
            "gps": (0, 0),
            "imu": 0,
            "lidar": [],
            "distance": [],
            "camera_frame": None
        }

    def run(self):
        while self.running:
            sensor_data = self.read_sensor_data()

            position = sensor_data["gps"]
            heading = sensor_data["imu"]

            self.mapping.update_map(
                position=position,
                heading=heading,
                lidar_data=sensor_data["lidar"],
                distance_data=sensor_data["distance"]
            )

            victim = self.victim_detection.detect(sensor_data["camera_frame"])
            if victim:
                self.mapping.mark_victim(position, victim)
                self.victim_detection.report(victim, position)

            cognitive_target = self.cognitive_detection.detect(sensor_data["camera_frame"])
            if cognitive_target:
                self.mapping.mark_cognitive_target(position, cognitive_target)
                self.cognitive_detection.report(cognitive_target, position)

            next_goal = self.navigation.select_next_goal(self.mapping.grid, position)
            path = self.navigation.generate_path(self.mapping.grid, position, next_goal)

            movement_command = self.navigation.path_to_command(path)
            movement_success = self.motion.execute(movement_command)

            if not movement_success:
                recovered = self.recovery.attempt_recovery()
                if not recovered:
                    self.navigation.replan_required = True

            if self.navigation.mission_completed(self.mapping.grid):
                self.motion.return_to_start()
                self.motion.send_exit_command()
                self.running = False


if __name__ == "__main__":
    controller = RobomanicsController()
    controller.run()
