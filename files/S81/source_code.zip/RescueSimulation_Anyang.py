from controller import Robot, Motor, DistanceSensor, Camera, Emitter, GPS, Lidar, InertialUnit
import struct
import numpy as np
import matplotlib.pyplot as plt
import cv2
import pathlib
from pathlib import Path
pathlib.PosixPath = pathlib.WindowsPath
from typing import Optional, Literal
import torch
import sys
import time
import math
import heapq
import colorsys
 
try:
    from skimage.draw import line as draw_line
    _HAS_SKIMAGE = True
except ImportError:
    _HAS_SKIMAGE = False
 
import threading
import queue
import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
 
np.set_printoptions(threshold=sys.maxsize)
 
# ══════════════════════════════════════════════════════════════════════════
#  하드웨어 초기화
# ══════════════════════════════════════════════════════════════════════════
timeStep     = 32
max_velocity = 6.28
 
robot         = Robot()
colour_sensor = robot.getDevice("CS");      colour_sensor.enable(timeStep)
Ca1           = robot.getDevice("Ca1");     Ca1.enable(timeStep)
Ca2           = robot.getDevice("Ca2");     Ca2.enable(timeStep)
gps           = robot.getDevice("gps");     gps.enable(timeStep)
 
wheel1 = robot.getDevice("wheel1 motor")
wheel2 = robot.getDevice("wheel2 motor")
wheel1.setPosition(float("inf"))
wheel2.setPosition(float("inf"))
 
s1 = robot.getDevice("d2");               s1.enable(timeStep)   # 전방
s2 = robot.getDevice("d1");               s2.enable(timeStep)   # 좌 전방 대각
s3 = robot.getDevice("d3");               s3.enable(timeStep)   # 우 전방 대각
s4 = robot.getDevice("distance sensor4"); s4.enable(timeStep)   # 좌 측면
s5 = robot.getDevice("distance sensor5"); s5.enable(timeStep)   # 우 측면
 
lidar = Lidar('lidar');  lidar.enable(timeStep);  lidar.enablePointCloud()
inertial_unit = InertialUnit('inertial_unit');     inertial_unit.enable(timeStep)
emitter = robot.getDevice("emitter")
receiver = robot.getDevice("receiver")
 
# ══════════════════════════════════════════════════════════════════════════
#  상수
# ══════════════════════════════════════════════════════════════════════════
CONF_TH    = 0.78
YOLO_SIZE  = (320, 320)
 
VALID_TYPES   = {'C', 'F', 'O', 'P', 'H', 'S', 'U'}
CIRCLE_TYPES  = {'C', 'F', 'O', 'P'}
YOLO_TYPES    = {'H', 'S', 'U'}
YOLO_CLASS_MAP = {'H': 'H', 'S': 'S', 'U': 'U'}
 
CAMERA_FOV             = 45
MAX_DETECTION_DISTANCE = 0.25
VICTIM_HEIGHT          = 0.05
 
victim_check_counter      = 0
VICTIM_CHECK_INTERVAL     = 2.5
reported_victims          = set()
_processed_victim_tiles   = set()
_victim_attempt_count = {}   # key: (ix, iz, camera_side) → 시도 횟수
VICTIM_MAX_RETRY = 2
last_report_pos           = None
POSITION_CHANGE_THRESHOLD = 0.041
pos_change                = 0
 
M_TO_CM         = 100
CELL_SIZE  = 0.01 
TILE_CM         = 12
TILE_M          = 0.12
HALF_T          = TILE_M / 2
 
_UNDEFINED    = -1
_FREE         =  0
_WALL         =  1
_HOLES        =  2
_SWAMPS       =  3
_CHECKPOINT   =  4
_STARTINGTILE =  5
_COLOR        = ['b', 'p', 'r', 'g', 'o', 'y']

_LIDAR_LAYER       = 2
_LIDAR_POINTS      = 512
_MAX_RANGE         = 0.22
_WALL_THICKNESS_CM = 0
LIDAR_THRESHOLD    = 0.1
VISITED_THRESHOLD = HALF_T * 0.6   # 중심 3.6cm 이내

# ── 피해자 감지 상태 플래그 (중복 처리 방지) ──────────────────────────────
_victim_processing = False   # 현재 피해자 처리 중이면 True
_victim_cooldown   = 0       # 처리 완료 후 쿨다운 카운터 (tick 수)
VICTIM_COOLDOWN_TICKS = 0
_victim_start_tile: tuple = None  # 처리 완료 후 이 틱 수만큼 재진입 금지
_victim_prev_tile   = None

_TILE_OFFSETS = [
    (0.00,   0.00),   (0.00,   HALF_T), (0.00,   TILE_M),
    (HALF_T, 0.00),   (HALF_T, HALF_T), (HALF_T, TILE_M),
    (TILE_M, 0.00),   (TILE_M, HALF_T), (TILE_M, TILE_M),
]
 
_NODE_CELL_REFS = [
    [(0,0,0,0),(-1,0,0,4),(0,-1,4,0),(-1,-1,4,4)],
    [(0,0,0,2),(0,-1,4,2)],
    [(0,0,0,4),(1,0,0,0),(0,-1,4,4),(1,-1,4,0)],
    [(0,0,2,0),(-1,0,2,4)],
    [(0,0,2,2)],
    [(0,0,2,4),(1,0,2,0)],
    [(0,0,4,0),(-1,0,4,4),(0,1,0,0),(-1,1,0,4)],
    [(0,0,4,2),(0,1,0,2)],
    [(0,0,4,4),(1,0,4,0),(0,1,0,4),(1,1,0,0)],
]

_COLOR_TO_ZONE = {
    'b': (1, 2), 'p': (2, 3), 'r': (3, 4),
    'g': (4, 1), 'o': (2, 4), 'y': (1, 3)
}
SWAMP_COST_MULTIPLIER = 8.0  

_ICONS = {
    -1:'?', 0:' ', 1:'▮', 2:'2', 3:'3', 4:'4', 5:'5',
    'C':'C','F':'F','O':'O','P':'P','H':'H','S':'S','U':'U',
    'b':'b','p':'p','r':'r','g':'g','o':'o','y':'y'
}
 
_NR_COLOR_BGR = {
    'Red':(0,0,221),'Green':(0,221,0),
    'Yellow':(0,221,221),'Blue':(221,0,0),'Black':(0,0,0),
}
_NR_SCORE  = {'Red':-1,'Yellow':0,'Green':1,'Blue':2,'Black':-2}
_NR_RESULT = {0:'F',1:'P',2:'C',3:'O'}
 
SIDE_SENSOR_THRESHOLD_WHITE = 0.25
WHITE_PIXEL_RATIO = 0.04
_WALL_NEAR   = 0.20
_WALL_TARGET = 0.09
_KP          = 5.0
_KD          = 1.5
_prev_error  = 0.0
 
# ── 벽 평행 정렬 파라미터 ─────────────────────────────────────────────────
# 좌측 카메라(Ca1) 를 위해 왼쪽 벽과 평행: 라이다 왼쪽 영역(60°~120°) 사용
# 우측 카메라(Ca2) 를 위해 오른쪽 벽과 평행: 라이다 오른쪽 영역(240°~300°) 사용
ALIGN_LIDAR_SAMPLES   = 20    # 벽 거리 측정에 사용할 라이다 빔 수
ALIGN_TOLERANCE_DEG   = 1.5   # 이 각도 이내면 정렬 완료
ALIGN_MAX_ITER        = 150   # 최대 정렬 스텝 수
ALIGN_ROTATE_SPEED    = max_velocity * 0.08  # 정렬 회전 속도
LIDAR_VICTIM_DIST = HALF_T

_CHECKPOINT_HSV = {
    'min': (115, 0.00, 0.55),
    'max': (245, 0.03, 0.95)
}


# DEBUG_GRAPH_PATH = "C:/Users/nhyee/OneDrive/바탕 화면/ROBOT/2526RS/map_img/Node_Graph_0414.png"
# DEBUG_MAP_FOLDER = "C:/Users/nhyee/OneDrive/바탕 화면/ROBOT/2526RS/map_img"
 
# ══════════════════════════════════════════════════════════════════════════
#  YOLO 모델 로드
# ══════════════════════════════════════════════════════════════════════════
try:
    import yolov5
except ImportError as exc:
    raise ImportError(
        "yolov5 is not installed in the Python environment running this script. "
        "Install it in the same Python environment used to run this file."
    ) from exc

yolov5_dir = Path(yolov5.__file__).resolve().parent
if str(yolov5_dir) not in sys.path:
    sys.path.insert(0, str(yolov5_dir))

import torch.serialization
import torch.nn
import torch.nn.modules.container
import torch.nn.modules.conv
import torch.nn.modules.batchnorm
import torch.nn.modules.activation
import torch.nn.modules.pooling
import torch.nn.modules.upsampling

_SAFE_GLOBALS_LIST = [
    torch.nn.modules.container.Sequential,
    torch.nn.modules.container.ModuleList,
    torch.nn.modules.container.ModuleDict,
    torch.nn.modules.conv.Conv2d,
    torch.nn.modules.batchnorm.BatchNorm2d,
    torch.nn.modules.activation.SiLU,
    torch.nn.modules.activation.LeakyReLU,
    torch.nn.modules.activation.ReLU,
    torch.nn.modules.pooling.MaxPool2d,
    torch.nn.modules.upsampling.Upsample,
]
try:
    from models.yolo import DetectionModel
    _SAFE_GLOBALS_LIST.append(DetectionModel)
except Exception: pass
try:
    from models.common import (Conv, C3, SPPF, Bottleneck, BottleneckCSP,
                                SPP, Focus, GhostConv, GhostBottleneck, C3Ghost)
    _SAFE_GLOBALS_LIST += [Conv, C3, SPPF, Bottleneck, BottleneckCSP,
                           SPP, Focus, GhostConv, GhostBottleneck, C3Ghost]
except Exception: pass
try:
    from models.experimental import MixConv2d, CrossConv
    _SAFE_GLOBALS_LIST += [MixConv2d, CrossConv]
except Exception: pass

torch.serialization.add_safe_globals(_SAFE_GLOBALS_LIST)
_original_torch_load = torch.load

def _patched_torch_load(f, map_location=None, pickle_module=None,
                        weights_only=None, mmap=None, **kwargs):
    return _original_torch_load(f, map_location=map_location,
                                 pickle_module=pickle_module, weights_only=False, **kwargs)
torch.load = _patched_torch_load

model_path = Path("../../rescue-simulation/models/best.pt").resolve()
import yolov5
yolo_model      = yolov5.load(str(model_path))
yolo_model.conf = CONF_TH
torch.load = _original_torch_load

def calculate_victim_distance(bbox, image_width, image_height):
    bbox_height = bbox['ymax'] - bbox['ymin']
    if bbox_height > 0:
        return (VICTIM_HEIGHT * image_height) / (bbox_height * 2 * np.tan(np.radians(CAMERA_FOV / 2)))
    return float('inf')

def detect_tile_type(r, g, b) -> int:
    """컬러센서 RGB로 바닥 타입 반환"""
    if r < 60 and g < 60 and b < 60:
        return _HOLES
    if 190 < r < 255 and 170 < g < 230 and 80 < b < 150:
        return _SWAMPS
    return 0

def get_tile_color(r, g, b) -> str:
    """컬러센서 RGB로 존 전환 색상 반환"""
    if r < 85 and g < 85 and b > 245:
        return 'b'
    elif 155 < r < 175 and g < 85 and 230 < b < 250:
        return 'p'
    elif r > 245 and g < 85 and b < 85:
        return 'r'
    elif r < 85 and g > 245 and b < 85:
        return 'g'
    elif r > 245 and 230 < g < 248 and b < 85:
        return 'o'
    elif r > 245 and g > 248 and b < 85:
        return 'y'
    return None

CS_OFFSET = 0.024672566425   # 컬러센서-GPS 간 거리 (m)

def get_color_sensor_pos(x, z):
    """GPS 위치에서 컬러센서 실제 위치 계산 (전방 3cm)"""
    curr_angle = getAngle()                        # 북=0, 시계방향, degree
    angle_rad = math.radians(curr_angle)           # sin/cos용 라디안으로 변환
    cs_x = x + math.sin(angle_rad) * CS_OFFSET
    cs_z = z - math.cos(angle_rad) * CS_OFFSET
    return cs_x, cs_z

# ══════════════════════════════════════════════════════════════════════════
#  GUI (별도 스레드)
# ══════════════════════════════════════════════════════════════════════════
_gui_queue   = queue.Queue(maxsize=60)
_gui_running = True
 
class DebugGUI(threading.Thread):
    RING_COLORS = {
        'Red':'#FF4444','Green':'#44FF44',
        'Yellow':'#FFFF00','Blue':'#4488FF','Black':'#888888',
    }
    def __init__(self):
        super().__init__(daemon=True)
        self._img_refs = {}
 
    def run(self):
        self.root = tk.Tk()
        self.root.title("Webots 실시간 디버그 뷰어")
        self.root.configure(bg='#1a1a2e')

        # 화면 절반 크기로 설정 (우측 절반에 배치)
        screen_w = self.root.winfo_screenwidth()
        screen_h = self.root.winfo_screenheight()
        win_w    = screen_w // 2
        win_h    = screen_h
        pos_x    = screen_w // 2   # 화면 오른쪽 절반
        pos_y    = 0
        self.root.geometry(f'{win_w}x{win_h}+{pos_x}+{pos_y}')
        self.root.minsize(500, 600)

        self._build_ui()
        self._poll()
        self.root.mainloop()
 
    def _build_ui(self):
        BG='#1a1a2e'; BG2='#16213e'; FG='#e0e0e0'
        FONT=('Consolas',10); HDR=('Consolas',11,'bold'); PAD=6
 
        main_canvas = tk.Canvas(self.root, bg=BG, highlightthickness=0)
        scrollbar   = ttk.Scrollbar(self.root, orient='vertical', command=main_canvas.yview)
        main_canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right', fill='y')
        main_canvas.pack(side='left', fill='both', expand=True)
 
        inner     = tk.Frame(main_canvas, bg=BG)
        inner_win = main_canvas.create_window((0,0), window=inner, anchor='nw')
 
        def _on_frame_configure(e): main_canvas.configure(scrollregion=main_canvas.bbox('all'))
        def _on_canvas_configure(e): main_canvas.itemconfig(inner_win, width=e.width)
        def _on_mousewheel(e): main_canvas.yview_scroll(int(-1*(e.delta/120)), 'units')
        inner.bind('<Configure>', _on_frame_configure)
        main_canvas.bind('<Configure>', _on_canvas_configure)
        main_canvas.bind_all('<MouseWheel>', _on_mousewheel)
 
        # 카메라 라이브
        top = tk.Frame(inner, bg=BG)
        top.pack(fill='x', padx=PAD, pady=(PAD,0))
        for key, label in [('ca1','📷 Ca1 (좌) – LIVE'),('ca2','📷 Ca2 (우) – LIVE')]:
            f = tk.LabelFrame(top, text=label, bg=BG, fg='#00ff88', font=HDR, bd=1, relief='solid')
            f.pack(side='left', expand=True, fill='both', padx=PAD)
            lbl = tk.Label(f, bg=BG2, text='신호 대기 중…', fg='#555')
            lbl.pack(padx=4, pady=4)
            self._img_refs[f'raw_{key}'] = lbl
 
        # 동심원
        mid = tk.Frame(inner, bg=BG)
        mid.pack(fill='x', padx=PAD, pady=(PAD,0))
        for key, label in [('orig','동심원 오버레이'),('viz','정규화 동심원')]:
            f = tk.LabelFrame(mid, text=label, bg=BG, fg=FG, font=HDR, bd=1, relief='solid')
            f.pack(side='left', expand=True, fill='both', padx=PAD)
            lbl = tk.Label(f, bg=BG2, text='분석 대기 중…', fg='#555')
            lbl.pack(padx=4, pady=4)
            self._img_refs[f'ring_{key}'] = lbl
 
        vote_outer = tk.LabelFrame(inner, text='링별 색상 투표 현황', bg=BG, fg=FG, font=HDR, bd=1, relief='solid')
        vote_outer.pack(fill='x', padx=PAD+4, pady=(PAD,0))
        self._vote_frame = tk.Frame(vote_outer, bg=BG)
        self._vote_frame.pack(fill='x', padx=4, pady=4)
        self._vote_bars = []
        for i in range(5):
            row = tk.Frame(self._vote_frame, bg=BG)
            row.pack(fill='x', pady=1)
            tk.Label(row, text=f'R{i+1}', width=3, bg=BG, fg=FG, font=FONT).pack(side='left')
            canvas = tk.Canvas(row, height=18, bg=BG2, highlightthickness=0)
            canvas.pack(side='left', fill='x', expand=True, padx=(4,0))
            info_lbl = tk.Label(row, text='', width=28, bg=BG, fg=FG, font=FONT, anchor='w')
            info_lbl.pack(side='left', padx=4)
            self._vote_bars.append((canvas, info_lbl))
 
        self._result_lbl = tk.Label(inner, text='결과 대기 중…',
                                    font=('Consolas',22,'bold'), bg=BG, fg='#ffffff', pady=8)
        self._result_lbl.pack(fill='x', padx=PAD)
 
        # YOLO
        yolo_outer = tk.LabelFrame(inner, text='YOLO 처리 과정 (H/S/U)',
                                   bg=BG, fg='#ffdd44', font=HDR, bd=1, relief='solid')
        yolo_outer.pack(fill='x', padx=PAD+4, pady=(PAD,0))
        for row_key, labels in [('in', [('ca1','Ca1 입력'),('ca2','Ca2 입력')]),
                                  ('out',[('ca1','Ca1 결과'),('ca2','Ca2 결과')])]:
            yrow = tk.Frame(yolo_outer, bg=BG)
            yrow.pack(fill='x', padx=4, pady=(4,0) if row_key=='in' else (0,4))
            for key, label in labels:
                f = tk.LabelFrame(yrow, text=label, bg=BG, fg=FG, font=FONT, bd=1, relief='solid')
                f.pack(side='left', expand=True, fill='both', padx=PAD)
                lbl = tk.Label(f, bg=BG2, text='대기중…', fg='#555')
                lbl.pack(padx=4, pady=4)
                self._img_refs[f'yolo_{row_key}_{key}'] = lbl
        self._yolo_status = tk.Label(yolo_outer, text='YOLO 대기 중…',
                                     font=('Consolas',13,'bold'), bg=BG, fg='#ffdd44', pady=4)
        self._yolo_status.pack(fill='x', padx=PAD)
 
        # 흰색 감지 + 정렬 상태
        white_outer = tk.LabelFrame(inner, text='흰색 감지 / 벽 평행 정렬 상태',
                                    bg=BG, fg='#88aaff', font=HDR, bd=1, relief='solid')
        white_outer.pack(fill='x', padx=PAD+4, pady=(PAD,0))
        white_row = tk.Frame(white_outer, bg=BG)
        white_row.pack(fill='x', padx=4, pady=(4,0))
        self._white_labels = {}
        for key, label in [('ca1','Ca1 (좌)'),('ca2','Ca2 (우)')]:
            f = tk.Frame(white_row, bg=BG)
            f.pack(side='left', expand=True, fill='x', padx=8)
            tk.Label(f, text=label, bg=BG, fg=FG, font=FONT).pack(side='left')
            lbl = tk.Label(f, text='●  대기', bg=BG, fg='#555555', font=('Consolas',11,'bold'))
            lbl.pack(side='left', padx=6)
            self._white_labels[key] = lbl
        self._align_lbl = tk.Label(white_outer, text='정렬 대기중…',
                                   font=('Consolas',11), bg=BG, fg='#aaddff', pady=3)
        self._align_lbl.pack(fill='x', padx=PAD)
 
        # 탐색 상태
        nav_outer = tk.LabelFrame(inner, text='탐색 상태 (FrontierExplorer)',
                                  bg=BG, fg='#88ffcc', font=HDR, bd=1, relief='solid')
        nav_outer.pack(fill='x', padx=PAD+4, pady=(PAD,0))
        self._nav_lbl = tk.Label(nav_outer, text='대기중…', font=FONT, bg=BG, fg='#88ffcc', pady=4)
        self._nav_lbl.pack(fill='x', padx=PAD)
 
        # 로그
        log_frame = tk.LabelFrame(inner, text='로그', bg=BG, fg=FG, font=HDR, bd=1, relief='solid')
        log_frame.pack(fill='both', expand=True, padx=PAD, pady=PAD)
        self._log_text = tk.Text(log_frame, bg='#0d0d1a', fg='#a0ffa0',
                                 font=FONT, wrap='word', state='disabled', height=12, bd=0)
        sb = ttk.Scrollbar(log_frame, orient='vertical', command=self._log_text.yview)
        self._log_text.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._log_text.pack(fill='both', expand=True, padx=2, pady=2)
 
        # 실시간 CloudMap
        map_outer = tk.LabelFrame(inner, text='실시간 점유 격자 지도 (CloudMap)',
                                  bg=BG, fg='#ffaa44', font=HDR, bd=1, relief='solid')
        map_outer.pack(fill='x', padx=PAD+4, pady=(PAD,0))
        self._map_lbl = tk.Label(map_outer, bg=BG2, text='지도 대기 중…', fg='#555')
        self._map_lbl.pack(padx=4, pady=4)
        self._img_refs['cloudmap'] = self._map_lbl

    def _poll(self):
        global _gui_running
        if not _gui_running: self.root.destroy(); return
        try:
            while True:
                msg_type, payload = _gui_queue.get_nowait()
                if   msg_type == 'frame':  self._update_raw(payload)
                elif msg_type == 'rings':  self._update_rings(payload)
                elif msg_type == 'log':    self._append_log(payload)
                elif msg_type == 'yolo':   self._update_yolo(payload)
                elif msg_type == 'white':  self._update_white(payload)
                elif msg_type == 'align':  self._align_lbl.configure(text=payload)
                elif msg_type == 'nav':    self._nav_lbl.configure(text=payload)
                elif msg_type == 'cloudmap': self._update_cloudmap(payload)
        except queue.Empty: pass
        self.root.after(16, self._poll)
        
    def _update_cloudmap(self, payload):
        arr = payload.get('img')
        if arr is None: return
        lbl = self._img_refs.get('cloudmap')
        if lbl is None: return
        # BGR → RGB 변환 후 표시
        rgb = cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(rgb).resize((400, 400), Image.NEAREST)
        photo = ImageTk.PhotoImage(img)
        lbl.configure(image=photo, text='')
        lbl.image = photo
        
    def _update_raw(self, payload):
        for key in ('ca1','ca2'):
            arr = payload.get(key)
            if arr is None: continue
            lbl = self._img_refs[f'raw_{key}']
            photo = self._to_photo(arr, size=(300,220))
            lbl.configure(image=photo, text=''); lbl.image = photo
 
    def _update_rings(self, payload):
        for key in ('orig','viz'):
            arr = payload.get(key)
            if arr is None: continue
            lbl = self._img_refs[f'ring_{key}']
            photo = self._to_photo(arr, size=(260,200))
            lbl.configure(image=photo, text=''); lbl.image = photo
        results = payload.get('results', [])
        for i, (canvas, info_lbl) in enumerate(self._vote_bars):
            canvas.delete('all')
            if i >= len(results): info_lbl.configure(text=''); continue
            color, pct, votes = results[i]
            total = max(sum(votes.values()), 1)
            sv    = sorted(votes.items(), key=lambda x: -x[1])
            x_off = 0; w = canvas.winfo_width() or 300
            for c_name, cnt in sv:
                seg_w = int(w * cnt / total)
                hex_c = self.RING_COLORS.get(c_name, '#888888')
                canvas.create_rectangle(x_off, 0, x_off+seg_w, 18, fill=hex_c, outline='')
                if seg_w > 20:
                    canvas.create_text(x_off+seg_w//2, 9, text=c_name[:3], fill='#000', font=('Consolas',8))
                x_off += seg_w
            info_lbl.configure(text=f'{color}  {pct:.0f}%  [{", ".join(f"{c}:{n}" for c,n in sv[:3])}]')
        result = payload.get('result'); cam = payload.get('cam','?')
        COLOR_MAP = {'F':'#ff6b35','P':'#f7c59f','C':'#efefd0','O':'#004e89',
                     'H':'#1a936f','S':'#88d498','U':'#c6dabf'}
        if result:
            bg = COLOR_MAP.get(result, '#333')
            self._result_lbl.configure(text=f'  [{cam}]  결과:  {result}  ',
                                       bg=bg, fg='#000' if result in ('P','C','U') else '#fff')
        else:
            self._result_lbl.configure(text=f'  [{cam}]  분석 완료 – 미분류', bg='#333', fg='#fff')
 
    def _update_yolo(self, payload):
        cam_key = payload.get('cam_key', 'ca1')
        in_arr  = payload.get('input_img')
        out_arr = payload.get('result_img')
        status  = payload.get('status', '')
        if in_arr is not None:
            lbl = self._img_refs.get(f'yolo_in_{cam_key}')
            if lbl:
                photo = self._to_photo(in_arr, size=(240,180))
                lbl.configure(image=photo, text=''); lbl.image = photo
        if out_arr is not None:
            lbl = self._img_refs.get(f'yolo_out_{cam_key}')
            if lbl:
                photo = self._to_photo(out_arr, size=(240,180))
                lbl.configure(image=photo, text=''); lbl.image = photo
        if status:
            self._yolo_status.configure(text=status, fg='#ffdd44')
 
    def _update_white(self, payload):
        for key in ('ca1','ca2'):
            detected = payload.get(key)
            if detected is None: continue
            lbl = self._white_labels[key]
            if detected: lbl.configure(text='●  흰색 감지! 정렬 중', fg='#ffffff')
            else:        lbl.configure(text='●  흰색 없음', fg='#44aa44')
 
    def _append_log(self, text):
        self._log_text.configure(state='normal')
        self._log_text.insert('end', text+'\n')
        self._log_text.see('end')
        self._log_text.configure(state='disabled')
 
    @staticmethod
    def _to_photo(arr, size=(240,180)):
        rgb = cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(rgb).resize(size, Image.LANCZOS)
        return ImageTk.PhotoImage(img)
 
def _gui_log(msg):
    try: _gui_queue.put_nowait(('log', msg))
    except queue.Full: pass
 
def _gui_send(t, p):
    try: _gui_queue.put_nowait((t, p))
    except queue.Full: pass
 
_debug_gui = DebugGUI()
_debug_gui.start()
_gui_log("컨트롤러 시작 – GUI 실행 중")
 
# ══════════════════════════════════════════════════════════════════════════
#  유틸 함수
# ══════════════════════════════════════════════════════════════════════════
def numToBlock(num):
    for thr, ch in [(0.7,'▁'),(0.6,'▂'),(0.5,'▃'),(0.4,'▄'),
                    (0.3,'▅'),(0.2,'▆'),(0.1,'▇'),(0,'█')]:
        if num > thr: return ch
 
def delay(ms):
    initTime = robot.getTime()
    while robot.step(timeStep) != -1:
        if (robot.getTime() - initTime) * 1000.0 > ms:
            break

 
# ══════════════════════════════════════════════════════════════════════════
#  카메라 유틸
# ══════════════════════════════════════════════════════════════════════════
def _read_camera_bgr(camera_device):
    img_raw = camera_device.getImage()
    if img_raw is None: return None
    w, h = camera_device.getWidth(), camera_device.getHeight()
    arr  = np.frombuffer(img_raw, np.uint8).reshape((h, w, 4))
    bgr  = cv2.cvtColor(arr, cv2.COLOR_BGRA2BGR)
    cam_key = 'ca1' if '1' in camera_device.getName() else 'ca2'
    _gui_send('frame', {cam_key: bgr})
    return bgr
 
def _detect_white(bgr):
    r_ch = bgr[:,:,2].astype(np.float32)
    g_ch = bgr[:,:,1].astype(np.float32)
    b_ch = bgr[:,:,0].astype(np.float32)
    white_mask = (r_ch > 200) & (g_ch > 200) & (b_ch > 200)
    ratio = float(np.sum(white_mask)) / (bgr.shape[0] * bgr.shape[1])
    return ratio >= WHITE_PIXEL_RATIO
 
def _ca1_close(): return s4.getValue() <= SIDE_SENSOR_THRESHOLD_WHITE
def _ca2_close(): return s5.getValue() <= SIDE_SENSOR_THRESHOLD_WHITE
 
# ══════════════════════════════════════════════════════════════════════════
#  벽 평행 정렬 (라이다 기반)
#
#  원리:
#    로봇 중심선을 기준으로 왼쪽(Ca1) 또는 오른쪽(Ca2) 벽과 평행이 되도록
#    포인트턴으로 정렬.
#
#    해당 방향의 라이다 빔 중 가까운 유효 빔 N개를 수집,
#    선형 회귀(최소제곱)로 벽의 기울기를 구한 뒤
#    기울기가 0이 되도록(= 벽과 평행) 로봇을 회전.
#
#  라이다 좌표계:
#    rotate_LidarValue 로 회전된 curr_cloud_rotated 를 사용하므로
#    인덱스 0 = 로봇 정면, 시계방향 증가.
#    → 좌측 빔: 약 60°~120°  (인덱스 85~170)
#    → 우측 빔: 약 240°~300° (인덱스 341~426)
# ══════════════════════════════════════════════════════════════════════════
_LIDAR_LEFT_RANGE  = (330, 360)  # 전방 좌측 → 정면 축 기준 왼쪽 벽
_LIDAR_RIGHT_RANGE = (0,   30)   # 전방 우측 → 정면 축 기준 오른쪽 벽

_LIDAR_LEFT_PERP_RANGE  = (197, 247)  
_LIDAR_RIGHT_PERP_RANGE = (113, 163)

def _get_lidar_wall_points(cloud_rotated, angle_min_deg, angle_max_deg,
                           max_dist=0.30, min_points=5):
    n = len(cloud_rotated)
    pts = []
    for deg in range(angle_min_deg, angle_max_deg + 1):
        idx = int(round(deg * n / 360.0)) % n
        dist = cloud_rotated[idx]
        if dist is None or math.isnan(dist) or math.isinf(dist): continue
        if dist <= 0.005 or dist > max_dist: continue
        rad = math.radians(deg)
        x_rel =  dist * math.sin(rad)
        z_rel = -dist * math.cos(rad)
        pts.append((x_rel, z_rel))
    if len(pts) < min_points:
        return None
    return pts

def _wall_angle_error(pts):
    xs = np.array([p[0] for p in pts])
    zs = np.array([p[1] for p in pts])
    if np.std(xs) < 1e-6:
        return 0.0
    coeffs = np.polyfit(xs, zs, 1)
    slope = coeffs[0]
    angle_error_rad = math.atan(slope)
    return math.degrees(angle_error_rad)

def _align_parallel_to_wall(camera_device, camera_side,
                              tolerance=ALIGN_TOLERANCE_DEG,
                              max_iter=ALIGN_MAX_ITER):
    """
    정렬 완료 직후 카메라 이미지를 캡처해서 함께 반환.
    반환: (성공여부: bool, 정렬완료순간_bgr: ndarray or None)
    """
    angle_range = _LIDAR_LEFT_RANGE if camera_side == 'left' else _LIDAR_RIGHT_RANGE
    side_label  = '좌(Ca1)' if camera_side == 'left' else '우(Ca2)'

    print(f"\n[ALIGN] {side_label} 벽 평행 정렬 시작")
    _gui_log(f"[ALIGN] {side_label} 벽 평행 정렬 시작")

    wheel1.setVelocity(0); wheel2.setVelocity(0)
    for _ in range(3): robot.step(timeStep)

    for iteration in range(max_iter):
        raw      = lidar.range_image[512 * _LIDAR_LAYER : 512 * (_LIDAR_LAYER + 1):]
        curr_ang = getAngle()
        rotated  = rotate_LidarValue(raw, curr_ang)
        rotated  = rotate_LidarValue(rotated, 180)

        pts = _get_lidar_wall_points(rotated, angle_range[0], angle_range[1])

        if pts is None:
            msg = f"[ALIGN] 벽 포인트 부족 → 정렬 생략"
            print(msg); _gui_log(msg); _gui_send('align', msg)
            wheel1.setVelocity(0); wheel2.setVelocity(0)
            return False, None

        err_deg = _wall_angle_error(pts)
        d_front = s1.getValue()
        msg = (f"[ALIGN iter={iteration+1:03d}] "
               f"pts={len(pts)}  err={err_deg:+.2f}°  "
               f"s1={d_front:.3f}  robot={curr_ang:.1f}°")
        print(msg)
        _gui_send('align', msg)

        if abs(err_deg) <= tolerance:
            wheel1.setVelocity(0); wheel2.setVelocity(0)

            # ★ 정렬 완료 순간 — 바퀴 멈춘 직후 바로 사진 촬영 ★
            # robot.step() 한 번으로 카메라 버퍼만 갱신하고 즉시 캡처
            robot.step(timeStep)
            captured_bgr = _read_camera_bgr(camera_device)

            done_msg = f"[ALIGN] ✓ 완료! err={err_deg:+.2f}°  robot={getAngle():.1f}°"
            print(done_msg); _gui_log(done_msg)
            _gui_send('align', done_msg)
            return True, captured_bgr, getAngle()

        sign = -1.0 if camera_side == 'left' else 1.0
        if err_deg * sign > 0:
            wheel1.setVelocity(-ALIGN_ROTATE_SPEED)
            wheel2.setVelocity( ALIGN_ROTATE_SPEED)
        else:
            wheel1.setVelocity( ALIGN_ROTATE_SPEED)
            wheel2.setVelocity(-ALIGN_ROTATE_SPEED)

        robot.step(timeStep)

    wheel1.setVelocity(0); wheel2.setVelocity(0)
    timeout_msg = f"[ALIGN] ⚠ 최대 반복({max_iter}) 도달"
    print(timeout_msg); _gui_log(timeout_msg)
    _gui_send('align', timeout_msg)
    return False, None

# 카메라 장착 각도 상수 (로봇 정면 기준, 시계방향 +)
CA1_MOUNT_ANGLE = -42.3   # 좌전방
CA2_MOUNT_ANGLE = +42.3   # 우전방
VICTIM_FREEZE_TICKS = 30
_victim_freeze_ticks_remaining = 0

def _align_perpendicular_to_wall(camera_device, camera_side,
                                  tolerance=ALIGN_TOLERANCE_DEG,
                                  max_iter=ALIGN_MAX_ITER):
    side_label  = '좌(Ca1)' if camera_side == 'left' else '우(Ca2)'
    mount_angle = CA1_MOUNT_ANGLE if camera_side == 'left' else CA2_MOUNT_ANGLE
    scan_range  = (240, 300) if camera_side == 'left' else (60, 120)

    print(f"\n[ALIGN-PERP] {side_label} 수직 정렬 시작 (장착각={mount_angle:+.1f}°)")
    _gui_log(f"[ALIGN-PERP] {side_label} 수직 정렬 시작")

    wheel1.setVelocity(0); wheel2.setVelocity(0)
    for _ in range(3): robot.step(timeStep)

    for iteration in range(max_iter):
        raw      = lidar.range_image[512 * _LIDAR_LAYER : 512 * (_LIDAR_LAYER + 1):]
        curr_ang = getAngle()

        # ── 좌표계: rotate 두 번 적용 전 raw 그대로 사용 ──────────
        # raw 인덱스 0 = 로봇 정면
        # deg=0 → 로봇 정면, 시계방향 증가
        pts = _get_lidar_wall_points_raw(raw, scan_range[0], scan_range[1])
        if pts is None:
            msg = "[ALIGN-PERP] 벽 포인트 부족 → 정렬 생략"
            print(msg); _gui_log(msg); _gui_send('align', msg)
            wheel1.setVelocity(0); wheel2.setVelocity(0)
            return False, None, None

        # ── 벽 접선 (로봇 로컬 기준) ─────────────────────────────
        xs = np.array([p[0] for p in pts])
        zs = np.array([p[1] for p in pts])

        if np.std(xs) < 1e-6:
            tangent_local = 90.0
        else:
            slope = np.polyfit(xs, zs, 1)[0]
            tangent_local = math.degrees(math.atan2(1.0, -slope)) % 360.0

        # ── 벽 법선 (로봇 로컬) → 로봇 쪽 방향 선택 ─────────────
        normal_a = (tangent_local + 90.0) % 360.0
        normal_b = (tangent_local - 90.0) % 360.0

        wall_cx = float(np.mean(xs))
        wall_cz = float(np.mean(zs))
        wall_dir_local = math.degrees(math.atan2(wall_cx, -wall_cz)) % 360.0

        diff_a = abs(_angle_diff(normal_a, wall_dir_local))
        diff_b = abs(_angle_diff(normal_b, wall_dir_local))
        wall_normal_local = normal_a if diff_a < diff_b else normal_b

        # ── 로컬 법선 → 월드 법선 ────────────────────────────────
        wall_normal_world = (curr_ang + wall_normal_local) % 360.0

        # ── 카메라 장착각 보정 → 로봇 목표각 ─────────────────────
        target_world = (wall_normal_world - mount_angle) % 360.0
        err_deg      = _angle_diff(target_world, curr_ang)

        msg = (f"[ALIGN-PERP iter={iteration+1:03d}] "
               f"tangent_local={tangent_local:.1f}°  "
               f"normal_world={wall_normal_world:.1f}°  "
               f"target={target_world:.1f}°  "
               f"curr={curr_ang:.1f}°  err={err_deg:+.2f}°")
        print(msg)
        _gui_send('align', msg)

        # ── 완료 판정 ─────────────────────────────────────────────
        if abs(err_deg) <= tolerance:
            # ★ 바퀴 완전 정지 후 절대로 움직이지 않도록 ★
            wheel1.setVelocity(0); wheel2.setVelocity(0)
            wheel1.setPosition(wheel1.getTargetPosition() if hasattr(wheel1, 'getTargetPosition') else float('inf'))

            # 여러 틱 동안 정지 유지
            for _ in range(10):
                wheel1.setVelocity(0); wheel2.setVelocity(0)
                robot.step(timeStep)

            captured_bgr = _read_camera_bgr(camera_device)
            done_msg = (f"[ALIGN-PERP] ✓ 완료!  "
                        f"normal={wall_normal_world:.1f}°  "
                        f"robot={getAngle():.1f}°")
            print(done_msg); _gui_log(done_msg); _gui_send('align', done_msg)
            return True, captured_bgr, getAngle()

        # ── 회전 ─────────────────────────────────────────────────
        spd = ALIGN_ROTATE_SPEED
        if err_deg > 0:
            wheel1.setVelocity(-spd); wheel2.setVelocity( spd)
        else:
            wheel1.setVelocity( spd); wheel2.setVelocity(-spd)

        robot.step(timeStep)

    wheel1.setVelocity(0); wheel2.setVelocity(0)
    return False, None, None


def _get_lidar_wall_points_raw(raw_cloud, angle_min_deg, angle_max_deg,
                                max_dist=0.30, min_points=5):
    """
    rotate 없이 raw 라이다 데이터에서 포인트 추출.
    인덱스 0 = 로봇 정면, 시계방향 증가.
    반환 좌표는 로봇 로컬 기준.
    """
    n = len(raw_cloud)
    pts = []
    for deg in range(angle_min_deg, angle_max_deg + 1):
        idx  = int(round(deg * n / 360.0)) % n
        dist = raw_cloud[idx]
        if dist is None or math.isnan(dist) or math.isinf(dist): continue
        if dist <= 0.005 or dist > max_dist: continue
        rad   = math.radians(deg)
        x_rel =  dist * math.sin(rad)
        z_rel = -dist * math.cos(rad)
        pts.append((x_rel, z_rel))
    if len(pts) < min_points:
        return None
    return pts

import os
from datetime import datetime

DEBUG_SAVE_DIR = r"C:\Users\naeun\OneDrive\Desktop\ROBOT\2026 Robocup in INCHEON\Debug"
#os.makedirs(DEBUG_SAVE_DIR, exist_ok=True)


def _save_debug_img(img, label):
    """디버그 이미지를 타임스탬프 파일명으로 저장"""
    ts = datetime.now().strftime("%H%M%S_%f")[:-3]
    fname = os.path.join(DEBUG_SAVE_DIR, f"{ts}_{label}.jpg")
    cv2.imwrite(fname, img)
    _gui_log(f"[SAVE] {fname}")
    return fname


# ══════════════════════════════════════════════════════════════════════════
#  벽 맵핑 헬퍼 — 임의 각도 대응 버전
# ══════════════════════════════════════════════════════════════════════════

CA1_MOUNT_ANGLE = -42.3   # 로봇 전방 기준, 좌전방
CA2_MOUNT_ANGLE = +42.3   # 로봇 전방 기준, 우전방

# Cell[r][c] 에서 각 "면"이 어느 방향(월드 각도)으로부터 접근하면
# 해당 면이 되는지를 나타내는 매핑.
# 벽의 "접근 각도" = 벽 GPS 기준 로봇이 어느 방향에 있는지
# (= camera_dir + 180)를 가장 가까운 45° 구간으로 분류.
#
# 면 우선순위 (5×5 Cell):
#   [0][2] = 상단 중앙 (위쪽 벽)
#   [4][2] = 하단 중앙 (아래쪽 벽)
#   [2][0] = 좌측 중앙 (왼쪽 벽)
#   [2][4] = 우측 중앙 (오른쪽 벽)
#
# 방향 → (row, col) 매핑
# 월드각도 기준: 0=북, 90=동, 180=남, 270=서
_APPROACH_TO_CELL_FACE = {
    # 로봇이 벽의 '북쪽'에서 접근 → 벽의 상단면 [0][2]
    'N':  (0, 2),
    # 로봇이 벽의 '남쪽'에서 접근 → 벽의 하단면 [4][2]
    'S':  (4, 2),
    # 로봇이 벽의 '서쪽'에서 접근 → 벽의 좌측면 [2][0]
    'W':  (2, 0),
    # 로봇이 벽의 '동쪽'에서 접근 → 벽의 우측면 [2][4]
    'E':  (2, 4),
}

def _world_angle_to_compass(angle_deg: float) -> str:
    """
    월드 각도(0=북, 시계방향) → N/S/E/W 문자열.
    45° 단위 8방향을 4방향으로 병합.
    """
    a = angle_deg % 360
    if a < 45 or a >= 315:
        return 'N'
    elif 45 <= a < 135:
        return 'E'
    elif 135 <= a < 225:
        return 'S'
    else:
        return 'W'

def _find_wall_cell_and_face(robot_x, robot_z, approach_world_angle, my_map, cld_map):
    
    # 로봇 현재 셀
    robot_result = my_map.get_cell_index(robot_x, robot_z)
    if robot_result is None:
        print(f"[WALL-CELL] ❌ 로봇 셀 범위 밖")
        return None
    
    robot_ix, robot_iz = robot_result

    # ── 현재 셀 중심 좌표로 스냅 (경계 오차 제거) ──────────────────
    tile_cx, tile_cz = _tile_index_to_world(my_map, cld_map, robot_ix, robot_iz)
    print(f"[WALL-CELL] 로봇GPS=({robot_x:.4f},{robot_z:.4f}) "
          f"셀[{robot_ix}][{robot_iz}] 중심=({tile_cx:.4f},{tile_cz:.4f})")

    compass = _world_angle_to_compass(approach_world_angle)

    neighbor_offset = {
        'N': ( 0, -1),
        'S': ( 0, +1),
        'E': (+1,  0),
        'W': (-1,  0),
    }

    dix, diz = neighbor_offset[compass]
    target_ix = robot_ix + dix
    target_iz = robot_iz + diz

    if not my_map._in_bounds(target_ix, target_iz):
        print(f"[WALL-CELL] ❌ 인접 셀 범위 밖")
        return None

    cell = my_map.grid[target_ix][target_iz]
    cell.explored = True
    cell.visited = True

    opposite = {'N': 'S', 'S': 'N', 'E': 'W', 'W': 'E'}
    face_compass = opposite[compass]
    row, col = _APPROACH_TO_CELL_FACE[face_compass]

    print(f"[WALL-CELL] robot[{robot_ix}][{robot_iz}] → "
          f"target[{target_ix}][{target_iz}] compass={compass} face[{row}][{col}]")
    return cell, target_ix, target_iz, row, col

def _report_victim_v2(victim_type: str, camera_side: str,
                       aligned_robot_angle: float = None,
                       original_pos: tuple = None):
    global last_report_pos, reported_victims

    pos = gps.getValues()
    robot_x, robot_z = pos[0], pos[2]
    robot_angle = aligned_robot_angle if aligned_robot_angle is not None else getAngle()
    base_x = original_pos[0] if original_pos is not None else robot_x
    base_z = original_pos[1] if original_pos is not None else robot_z
    # ── 카메라 장착각 계산 대신 라이다로 실제 가장 가까운 벽 방향 탐색 ──
    raw_cloud = lidar.range_image[512 * _LIDAR_LAYER: 512 * (_LIDAR_LAYER + 1):]
    
    # Ca1(left)은 로봇 왼쪽(210°~330° 로컬), Ca2(right)는 오른쪽(30°~150° 로컬) 탐색
    if camera_side == 'left':
        search_min, search_max = 30, 150    # CCW 기준 왼쪽
    else:
        search_min, search_max = 210, 330

    n = len(raw_cloud)
    min_dist = float('inf')
    min_local_deg = (search_min + search_max) // 2  # 기본값: 중앙

    for deg in range(search_min, search_max + 1):
        idx = int(round(deg * n / 360.0)) % n
        d = raw_cloud[idx]
        if d is None or math.isnan(d) or math.isinf(d):
            continue
        if d <= 0.005 or d > 0.25:
            continue
        if d < min_dist:
            min_dist = d
            min_local_deg = deg

    cam_world_angle = (robot_angle + min_local_deg) % 360
    dist = min_dist if not math.isinf(min_dist) else TILE_M

    print(f"[REPORT-V2] cam_side={camera_side} "
          f"robot={robot_angle:.1f}° "
          f"wall_local={min_local_deg}° "
          f"wall_world={cam_world_angle:.1f}° "
          f"dist={dist:.3f}m")
    _gui_log(f"[REPORT-V2] {camera_side} wall_world={cam_world_angle:.1f}° dist={dist:.3f}m")

    # ── 벽 GPS 계산 ─────────────────────────────────────────────────
    cam_angle_rad = math.radians(cam_world_angle)
    wall_x = robot_x + math.sin(cam_angle_rad) * dist
    wall_z = robot_z - math.cos(cam_angle_rad) * dist

    print(f"[REPORT-V2] 벽 GPS 예상: ({wall_x:.4f}, {wall_z:.4f})")
    _gui_log(f"[REPORT-V2] 벽 GPS=({wall_x:.4f},{wall_z:.4f})")

    # ── 위치 중복 체크 ───────────────────────────────────────────────
    if last_report_pos is not None:
        dist_from_last = math.sqrt(
            (robot_x - last_report_pos[0]) ** 2 +
            (robot_z - last_report_pos[2]) ** 2)
        if dist_from_last < POSITION_CHANGE_THRESHOLD:
            print(f"[REPORT-V2 스킵] 위치 변화 없음 ({dist_from_last:.3f}m)")
            _gui_log(f"[REPORT-V2] 위치 변화 없음→스킵")
            return

    # ── Cell 맵핑 ────────────────────────────────────────────────────
    base_x = original_pos[0] if original_pos is not None else robot_x
    base_z = original_pos[1] if original_pos is not None else robot_z

    victim_gps_x = robot_x + math.sin(cam_angle_rad) * (dist - HALF_T)
    victim_gps_z = robot_z - math.cos(cam_angle_rad) * (dist - HALF_T)

    print(f"[REPORT-V2] 피해자 GPS: ({victim_gps_x:.4f}, {victim_gps_z:.4f})")
    _gui_log(f"[REPORT-V2] victim GPS=({victim_gps_x:.4f},{victim_gps_z:.4f})")

    victim_result = My_Map.get_cell_index(victim_gps_x, victim_gps_z)
    ix, iz, row, col = None, None, None, None   # 범위 밖일 경우 대비

    if victim_result is None:
        print(f"[REPORT-V2] ❌ 피해자 타일 범위 밖")
    else:
        ix, iz = victim_result
        cell   = My_Map.grid[ix][iz]
        cell.explored = True
        cell.visited  = True

        # 면(face) 결정: 벽 방향의 반대 면이 로봇을 바라보는 면
        compass      = _world_angle_to_compass(cam_world_angle)
        opposite     = {'N': 'S', 'S': 'N', 'E': 'W', 'W': 'E'}
        face_compass = opposite[compass]
        row, col     = _APPROACH_TO_CELL_FACE[face_compass]

        victim_key = (ix, iz, row, col, victim_type)
        if victim_key not in reported_victims:
            My_Map.update_cloud_wall(robot_x, robot_z, Cld_Map)
            explorer._rebuild_graph = True

            cell.cell[row][col] = victim_type
            cell.explored = True
            reported_victims.add(victim_key)
            _processed_victim_tiles.add(My_Map.get_cell_index(robot_x, robot_z))

            My_Map.display()
            global prev_explored_count
            prev_explored_count = sum(
                1 for bx in range(My_Map.width)
                for bz in range(My_Map.height)
                if My_Map.grid[bx][bz].explored
            )
            print(f"[REPORT-V2] ✓ MAPPED {victim_type} → "
                  f"Cell[{ix}][{iz}].cell[{row}][{col}]")
            print(f"[DEBUG] cell[{row}][{col}] = {cell.cell[row][col]}")

    # ── 이미터 전송 (1초 정지) ─────────────────────────────────────
    wheel1.setVelocity(0)
    wheel2.setVelocity(0)
    delay(1000)

    x_int = int(robot_x * 100)
    z_int = int(robot_z * 100)
    msg = struct.pack("i i c", x_int, z_int, bytes(victim_type, "utf-8"))
    emitter.send(msg)

    last_report_pos = pos
    print(f"[REPORT-V2] 전송 완료: {victim_type} cm=({x_int},{z_int})")
    _gui_log(f"[REPORT-V2] ✓ {victim_type} cm=({x_int},{z_int})")

    # 디버그 (None 체크 포함)
    if ix is not None:
        print(f"[DEBUG] Cell[{ix}][{iz}].explored = {My_Map.grid[ix][iz].explored}")
        print(f"[DEBUG] Cell[{ix}][{iz}].cell[{row}][{col}] = "
              f"{My_Map.grid[ix][iz].cell[row][col]}")

    for dbx in range(My_Map.width):
        for dbz in range(My_Map.height):
            if My_Map.grid[dbx][dbz].explored:
                c = My_Map.grid[dbx][dbz]
                has_v = any(c.cell[r][cc] in VALID_TYPES for r in range(5) for cc in range(5))
                if has_v:
                    print(f"[DEBUG] victim 있는 셀: [{dbx}][{dbz}] explored={c.explored}")
                    
# ══════════════════════════════════════════════════════════════════════════
#  흰색 감지 → 벽 평행 정렬 → 피해자 감지
# ══════════════════════════════════════════════════════════════════════════
def _nr_has_circle_close(bgr, max_dist_m=0.12):
    """
    원형이 있고 추정 거리가 max_dist_m 이내일 때만 True 반환
    반환: (bool, float or None)
    """
    cx, cy, outer_r, inner_r,  ellipses_by_color = _nr_find_concentric(bgr)
    if cx is None or outer_r is None or outer_r < 8:
        return False, None
    
    if ellipses_by_color is None or len(ellipses_by_color) < 2:
        return False, None
    
    FOCAL = 64 / (2 * math.tan(math.radians(CAMERA_FOV / 2)))
    REAL_RADIUS = 0.025  # 실제 반지름 2.5cm

    estimated_dist = (REAL_RADIUS * FOCAL) / outer_r
    print(f"[CIRCLE DIST] outer_r={outer_r:.1f}px → 추정거리={estimated_dist:.3f}m")
    _gui_log(f"[CIRCLE DIST] outer_r={outer_r:.1f}px → 추정거리={estimated_dist:.3f}m")

    return estimated_dist <= max_dist_m, estimated_dist

# ══════════════════════════════════════════════════════════════════════════
#  흰색 피해자 감지 - 각도 샘플링으로 fake 필터링
# ══════════════════════════════════════════════════════════════════════════

# 각도 샘플링 파라미터
FAKE_CHECK_ANGLE_STEP  = 15   # 한 번에 회전할 각도 (도)
FAKE_CHECK_MIN_CONFIRM = 2    # 이 횟수 이상 같은 클래스면 진짜
FAKE_CHECK_ROTATE_SPEED = max_velocity * 0.2

def _rotate_by_angle(delta_deg, speed=FAKE_CHECK_ROTATE_SPEED, tolerance=2.0, max_iter=200):
    """
    현재 각도 기준으로 delta_deg 만큼 상대 회전.
    delta_deg > 0: 시계방향, < 0: 반시계방향
    """
    start_angle = getAngle()
    target_angle = (start_angle + delta_deg) % 360

    for _ in range(max_iter):
        curr = getAngle()
        err  = _angle_diff(target_angle, curr)
        if abs(err) < tolerance:
            break
        if err > 0:
            wheel1.setVelocity(-speed)
            wheel2.setVelocity( speed)
        else:
            wheel1.setVelocity( speed)
            wheel2.setVelocity(-speed)
        robot.step(timeStep)

    wheel1.setVelocity(0)
    wheel2.setVelocity(0)
    for _ in range(5):
        wheel1.setVelocity(0)
        wheel2.setVelocity(0)
        robot.step(timeStep)


def _yolo_single_shot(camera_device, cam_key):
    """
    카메라 이미지 1장 촬영 후 YOLO 추론.
    반환: 감지된 victim_type str or None
    """
    for _ in range(5):
        robot.step(timeStep)

    bgr = _read_camera_bgr(camera_device)
    if bgr is None:
        return None

    img_resized = cv2.resize(bgr, YOLO_SIZE)

    img_rgb    = cv2.cvtColor(img_resized, cv2.COLOR_BGR2RGB)
    results    = yolo_model(img_rgb)
    detections = results.pandas().xyxy[0]

    result_img = img_resized.copy()
    found_type = None

    # ── 모든 감지 결과를 result_img에 그린 뒤 저장 ──────────────────
    if len(detections) == 0:
        # 아무것도 안 잡혔을 때도 원본 + 텍스트 저장
        cv2.putText(result_img, "NO DETECTION", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
    else:
        for idx in range(len(detections)):
            confidence  = detections['confidence'][idx]
            name        = detections['name'][idx]
            victim_type = YOLO_CLASS_MAP.get(name)
            bbox        = detections.iloc[idx]
            distance    = calculate_victim_distance(bbox, YOLO_SIZE[0], YOLO_SIZE[1])

            x1,y1,x2,y2 = int(bbox['xmin']),int(bbox['ymin']),int(bbox['xmax']),int(bbox['ymax'])

            # 통과 여부에 따라 색 구분 (초록=통과, 빨강=탈락)
            passed = (victim_type is not None
                      and confidence > CONF_TH
                      and distance <= MAX_DETECTION_DISTANCE)
            color = (0, 255, 0) if passed else (0, 0, 255)

            cv2.rectangle(result_img, (x1,y1),(x2,y2), color, 2)

            # conf / distance / 통과여부 한 줄로
            label = (f"{name} conf={confidence:.3f} "
                     f"dist={distance:.3f}m "
                     f"{'[PASS]' if passed else '[FAIL]'}")
            cv2.putText(result_img, label,
                        (x1, max(y1-5, 15)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)

            if passed and found_type is None:
                found_type = victim_type

    # CONF_TH / MAX_DETECTION_DISTANCE 기준선도 이미지 상단에 표시
    cv2.putText(result_img,
                f"CONF_TH={CONF_TH}  MAX_DIST={MAX_DETECTION_DISTANCE}m",
                (5, YOLO_SIZE[1] - 8),
                cv2.FONT_HERSHEY_SIMPLEX, 0.35, (200, 200, 0), 1)

    # 입력 원본 + 결과 나란히 저장
    #_save_debug_img(img_resized, f"{cam_key}_input")
    #_save_debug_img(result_img,  f"{cam_key}_result_{found_type or 'none'}")

    print(f"[ANGLE-SHOT] {cam_key} → {found_type}")
    _gui_log(f"[ANGLE-SHOT] {cam_key} → {found_type}")
    return found_type

def _strafe_move(direction, dist_m=0.04, speed_ratio=0.3, max_iter=300):
    """
    로봇을 측면으로 직선 이동.
    direction: 'left' or 'right'
    dist_m: 이동 거리 (m)
    """
    # 현재 각도 기준 측면 방향 계산
    curr_angle = getAngle()
    if direction == 'left':
        side_angle = (curr_angle - 90) % 360
    else:
        side_angle = (curr_angle + 90) % 360

    angle_rad = math.radians(side_angle)
    gps_vals = gps.getValues()
    start_x, start_z = gps_vals[0], gps_vals[2]
    target_x = start_x + math.sin(angle_rad) * dist_m
    target_z = start_z - math.cos(angle_rad) * dist_m

    base_speed = max_velocity * speed_ratio
    print(f"[STRAFE] {direction} {dist_m*100:.1f}cm → target=({target_x:.4f},{target_z:.4f})")
    _gui_log(f"[STRAFE] {direction} {dist_m*100:.1f}cm")

    for _ in range(max_iter):
        robot.step(timeStep)
        gps_vals = gps.getValues()
        cx, cz = gps_vals[0], gps_vals[2]
        remaining = math.hypot(target_x - cx, target_z - cz)
        if remaining < 0.008:
            break

        # 목표 방향
        move_angle = (math.degrees(math.atan2(target_x - cx, -(target_z - cz)))) % 360
        curr_ang = getAngle()
        ang_diff = _angle_diff(move_angle, curr_ang)

        if abs(ang_diff) > 8.0:
            spd = max_velocity * 0.3
            if ang_diff > 0:
                wheel1.setVelocity(-spd); wheel2.setVelocity(spd)
            else:
                wheel1.setVelocity(spd); wheel2.setVelocity(-spd)
        else:
            ratio = min(remaining / 0.02, 1.0)
            spd = max(0.8, base_speed * ratio)
            wheel1.setVelocity(spd); wheel2.setVelocity(spd)

    wheel1.setVelocity(0); wheel2.setVelocity(0)
    for _ in range(5):
        wheel1.setVelocity(0); wheel2.setVelocity(0)
        robot.step(timeStep)
    print(f"[STRAFE] 완료")

def _run_victim_detection(camera_device, cam_key, camera_side, original_pos=None):
    """
    흰색 배경 피해자(H/S/U) 감지.
    수직 정렬 후 3각도 샘플링으로 fake 필터링.

    판정 기준:
      - 3회 샘플(수직 / +40° / -80°) 중 같은 클래스가 2회 이상 → 진짜
      - 그 외 → fake
    """
    cam_name = f"Ca{'1' if cam_key == 'ca1' else '2'}"
    print(f"\n{'='*50}")
    print(f"[VICTIM-YOLO] {cam_name} 각도 샘플링 감지 시작")
    _gui_log(f"[VICTIM-YOLO] {cam_name} 각도 샘플링 시작")

    # ── 1. 수직 정렬 ────────────────────────────────────────────────
    print(f"[VICTIM-YOLO] 전진으로 거리 좁힘 (중앙 유지)")
    _advance_centered_for_victim(670, base_speed_ratio=0.5,
                              wall_near=0.20, wall_target=0.15,
                              kp=6.0, kd=1.5,
                              victim_side=camera_side)
    delay(150)

    print(f"[VICTIM-YOLO] 수직 정렬 시작")
    success, captured_bgr, aligned_robot_angle = _align_perpendicular_to_wall(camera_device, camera_side)
    wheel1.setVelocity(0); wheel2.setVelocity(0)
    delay(200)

    aligned_robot_angle = getAngle()
    print(f"[VICTIM-YOLO] 정렬 완료 각도: {aligned_robot_angle:.1f}°")

    # ── 2. 각도별 샘플링 ────────────────────────────────────────────
    # 샘플 계획:
    #   shot0: 수직 정렬 직후 (0°)
    #   shot1: +FAKE_CHECK_ANGLE_STEP 회전 후
    #   shot2: -(FAKE_CHECK_ANGLE_STEP * 2) 회전 후 (반대쪽으로)
    angle_offsets = [0, FAKE_CHECK_ANGLE_STEP, -(FAKE_CHECK_ANGLE_STEP * 2)]
    votes = {}   # victim_type → 감지 횟수

    for shot_idx, delta in enumerate(angle_offsets):
        if delta != 0:
            print(f"[VICTIM-YOLO] 회전 {delta:+}°")
            _gui_log(f"[VICTIM-YOLO] 회전 {delta:+}°")
            _rotate_by_angle(delta)
            delay(100)

        found = _yolo_single_shot(camera_device, cam_key)
        if found is not None:
            votes[found] = votes.get(found, 0) + 1
        print(f"[VICTIM-YOLO] shot{shot_idx} (누적 delta={sum(angle_offsets[:shot_idx+1]):+}°) → {found}")

    # ── 3. 원래 각도로 복귀 ─────────────────────────────────────────
    # 총 이동량: 0 + STEP + (-STEP*2) = -STEP
    # 따라서 +STEP 만큼 돌아오면 원위치
    print(f"[VICTIM-YOLO] 원위치 복귀 +{FAKE_CHECK_ANGLE_STEP}°")
    _rotate_by_angle(FAKE_CHECK_ANGLE_STEP)
    delay(100)

    # ── 4. 판정 ─────────────────────────────────────────────────────
    print(f"[VICTIM-YOLO] 투표 결과: {votes}")
    _gui_log(f"[VICTIM-YOLO] 투표: {votes}")

    final_type = None
    for vtype, cnt in votes.items():
        if cnt >= FAKE_CHECK_MIN_CONFIRM and vtype in YOLO_TYPES:
            final_type = vtype
            break

    if final_type:
        print(f"[VICTIM-YOLO] ✓ 진짜 피해자: {final_type} ({votes[final_type]}/3회 확인)")
        _gui_log(f"[VICTIM-YOLO] ✓ 진짜: {final_type}")
        _gui_send('yolo', {
            'cam_key': cam_key,
            'input_img': None,
            'result_img': None,
            'status': f"[{cam_key}] ✓ 진짜 {final_type}  ({votes[final_type]}/3)"
        })
        _report_victim_v2(final_type, camera_side, original_pos=original_pos)
    else:
        print(f"[VICTIM-YOLO] fake 또는 미감지 → 스킵  votes={votes}")
        _gui_log(f"[VICTIM-YOLO] fake 스킵  votes={votes}")
        _gui_send('yolo', {
            'cam_key': cam_key,
            'input_img': None,
            'result_img': None,
            'status': f"[{cam_key}] fake 판정 또는 미감지"
        })

    print(f"{'='*50}\n")

def check_and_align_for_victim():
    global _victim_processing, _victim_cooldown
    global _victim_start_tile, _victim_prev_tile

    gps_vals = gps.getValues()
    cur_tile = My_Map.get_cell_index(gps_vals[0], gps_vals[2])
    if cur_tile is not None and cur_tile != _victim_prev_tile:
        _victim_cooldown  = 0
        _victim_prev_tile = cur_tile

    if _victim_cooldown > 0:
        _victim_cooldown -= 1
        return

    if _victim_processing:
        return
    
    if cur_tile is not None and cur_tile in _processed_victim_tiles:
        # 실제 마킹됐는지 확인
        result = My_Map.get_cell_index(gps_vals[0], gps_vals[2])
        if result:
            ix, iz = result
            cell = My_Map.grid[ix][iz]
            # Cell의 어딘가에 victim 타입이 실제로 있으면 차단
            has_victim = any(
                cell.cell[r][c] in VALID_TYPES
                for r in range(5) for c in range(5)
            )
            if has_victim:
                return
            else:
                # 맵핑 실패했던 타일이면 차단 해제하고 재시도
                print(f"[VICTIM] 타일 {cur_tile} 재시도 (이전 맵핑 실패)")
                _processed_victim_tiles.discard(cur_tile)
        else:
            return
    
    # ── 카메라 이미지 먼저 취득 ──────────────────────────────────────
    bgr1_pre = _read_camera_bgr(Ca1)
    bgr2_pre = _read_camera_bgr(Ca2)

    white1 = _detect_white(bgr1_pre) if bgr1_pre is not None else False
    white2 = _detect_white(bgr2_pre) if bgr2_pre is not None else False

    circle1, dist1_est = (False, None)
    circle2, dist2_est = (False, None)
    if not white1 and bgr1_pre is not None:
        circle1, dist1_est = _nr_has_circle_close(bgr1_pre, max_dist_m=0.08)
    if not white2 and bgr2_pre is not None:
        circle2, dist2_est = _nr_has_circle_close(bgr2_pre, max_dist_m=0.08)

    _gui_send('white', {'ca1': white1, 'ca2': white2})

    if not white1 and not white2 and not circle1 and not circle2:
        return

    # ── 조건 1: 거리 센서로 실제 인접 확인 ──────────────────────────
    # Ca1 → s4, Ca2 → s5, 0.15m 이하일 때만 처리
    d4 = s4.getValue()
    d5 = s5.getValue()

    ca1_trigger = (white1 and d4 <= 0.15) or (circle1 and d4 <= 0.08)
    ca2_trigger = (white2 and d5 <= 0.15) or (circle2 and d5 <= 0.08)

    if cur_tile is not None:
        if ca1_trigger:
            key1 = (cur_tile[0], cur_tile[1], 'left')
            if _victim_attempt_count.get(key1, 0) >= VICTIM_MAX_RETRY:
                ca1_trigger = False
                print(f"[VICTIM] Ca1 {cur_tile} 최대 시도 초과 → 스킵")
        if ca2_trigger:
            key2 = (cur_tile[0], cur_tile[1], 'right')
            if _victim_attempt_count.get(key2, 0) >= VICTIM_MAX_RETRY:
                ca2_trigger = False
                print(f"[VICTIM] Ca2 {cur_tile} 최대 시도 초과 → 스킵")

    print(f"[VICTIM CHECK] s4={d4:.3f} s5={d5:.3f} "
          f"ca1_trigger={ca1_trigger} ca2_trigger={ca2_trigger}")
    _gui_log(f"[VICTIM] s4={d4:.3f} s5={d5:.3f} ca1={ca1_trigger} ca2={ca2_trigger}")

    if not ca1_trigger and not ca2_trigger:
        return

    # ── 조건 2: 정렬 전 살짝 직진 ───────────────────────────────────
    wheel1.setVelocity(0); wheel2.setVelocity(0)
    _victim_processing = True
    _victim_start_tile = cur_tile

    saved_state  = explorer.state
    saved_target = explorer._target
    explorer.state   = explorer.IDLE
    explorer._target = None

    # ★ 전진 전 각도와 GPS 저장 (finally 블록에서 복귀 & 맵핑 기준점에 사용) ★
    saved_angle     = getAngle()
    pre_advance_gps = (gps_vals[0], gps_vals[2])

    # 전진 전 라이다로 벽 방향/거리 미리 측정
    raw_cloud_pre = lidar.range_image[512*_LIDAR_LAYER:512*(_LIDAR_LAYER+1):]
    if ca1_trigger:
        search_min, search_max = 30, 150
    else:
        search_min, search_max = 210, 330

    n = len(raw_cloud_pre)
    pre_min_dist = float('inf')
    pre_min_local_deg = (search_min + search_max) // 2

    for deg in range(search_min, search_max + 1):
        idx = int(round(deg * n / 360.0)) % n
        d = raw_cloud_pre[idx]
        if d is None or math.isnan(d) or math.isinf(d):
            continue
        if d <= 0.005 or d > 0.25:
            continue
        if d < pre_min_dist:
            pre_min_dist = d
            pre_min_local_deg = deg

    pre_wall_angle = (saved_angle + pre_min_local_deg) % 360

    # 살짝 직진 - 피해자 방향 벽에서 멀어지도록 파라미터 조정
    print("[VICTIM] 정렬 전 직진 시작 (중앙 유지)")
    _advance_centered_for_victim(200, base_speed_ratio=0.5,
                                wall_near=0.20, wall_target=0.15,
                                kp=6.0, kd=1.5,
                                victim_side='left' if ca1_trigger else 'right')
    delay(200)

    try:
        # ── Ca1 처리 ─────────────────────────────────────────────────
        if ca1_trigger:
            if white1:
                _run_victim_detection(Ca1, 'ca1', 'left',
                                      original_pos=pre_advance_gps)   # ← 추가
            elif circle1:
                # 흰색 victim과 동일하게: 전진 → 수직 정렬 → 촬영
                _advance_centered_for_victim(670, base_speed_ratio=0.5,
                                            wall_near=0.20, wall_target=0.15,
                                            kp=6.0, kd=1.5,
                                            victim_side='left')
                delay(150)
                success, captured_bgr, aligned_angle = _align_perpendicular_to_wall(Ca1, 'left')
                wheel1.setVelocity(0); wheel2.setVelocity(0)
                delay(200)

                bgr1_fresh = captured_bgr if captured_bgr is not None else _read_camera_bgr(Ca1)
                if bgr1_fresh is not None:
                    #_save_debug_img(bgr1_fresh, 'ca1_circle_final')
                    result = detect_cognitive_target(bgr1_fresh, 'Ca1')
                    if result in CIRCLE_TYPES:
                        _report_victim_v2(result, 'left', original_pos=pre_advance_gps) # ← 추가

        # ── Ca2 처리 ─────────────────────────────────────────────────
        if ca2_trigger:
            if white2:
                _run_victim_detection(Ca2, 'ca2', 'right',
                                      original_pos=pre_advance_gps)   # ← 추가
            elif circle2:
                _advance_centered_for_victim(670, base_speed_ratio=0.5,
                                            wall_near=0.20, wall_target=0.15,
                                            kp=6.0, kd=1.5,
                                            victim_side='right')
                delay(150)
                success, captured_bgr, aligned_angle = _align_perpendicular_to_wall(Ca2, 'right')
                wheel1.setVelocity(0); wheel2.setVelocity(0)
                delay(200)

                bgr2_fresh = captured_bgr if captured_bgr is not None else _read_camera_bgr(Ca2)
                if bgr2_fresh is not None:
                    #_save_debug_img(bgr2_fresh, 'ca2_circle_final')
                    result = detect_cognitive_target(bgr2_fresh, 'Ca2')
                    if result in CIRCLE_TYPES:
                        _report_victim_v2(result, 'right', original_pos=pre_advance_gps)
    finally:
        wheel1.setVelocity(0); wheel2.setVelocity(0)
        _victim_processing = False
        _victim_cooldown   = VICTIM_COOLDOWN_TICKS

        if cur_tile is not None:
            if ca1_trigger:
                key1 = (cur_tile[0], cur_tile[1], 'left')
                _victim_attempt_count[key1] = _victim_attempt_count.get(key1, 0) + 1
                print(f"[VICTIM] Ca1 {cur_tile} 시도 횟수: {_victim_attempt_count[key1]}")
            if ca2_trigger:
                key2 = (cur_tile[0], cur_tile[1], 'right')
                _victim_attempt_count[key2] = _victim_attempt_count.get(key2, 0) + 1
                print(f"[VICTIM] Ca2 {cur_tile} 시도 횟수: {_victim_attempt_count[key2]}")

        # ── 실제 맵핑 성공한 경우만 재진입 차단 ──────────────────────
        if cur_tile is not None:
            result = My_Map.get_cell_index(gps_vals[0], gps_vals[2])
            if result:
                ix, iz = result
                cell = My_Map.grid[ix][iz]
                has_victim = any(
                    cell.cell[r][c] in VALID_TYPES
                    for r in range(5) for c in range(5)
                )
                if has_victim:
                    _processed_victim_tiles.add(cur_tile)
                    print(f"[VICTIM] 타일 {cur_tile} 맵핑 성공 → 재진입 차단")
                else:
                    print(f"[VICTIM] 타일 {cur_tile} 맵핑 실패 → 재진입 허용")

        # ★ explorer 상태 복원 전에 충분히 정지 ★
        for _ in range(15):
            wheel1.setVelocity(0); wheel2.setVelocity(0)
            robot.step(timeStep)

        # ★ 수정 1: 피해자 처리 전 원래 각도로 복귀 ★
        print(f"[VICTIM] 원래 각도 {saved_angle:.1f}° 로 복귀")
        _gui_log(f"[VICTIM] 원래 각도 {saved_angle:.1f}° 복귀")
        _turn_to_angle(saved_angle)
        
        explorer._failed_targets.clear()
        print(f"[VICTIM] 피해자 처리 후 failed_targets 초기화")
        
        explorer.state   = explorer.IDLE
        explorer._target = None
        explorer._rebuild_graph = True
        print(f"[VICTIM] 완료 → 재계획 강제")
        _gui_log(f"[VICTIM] 완료 → 재계획")

# ══════════════════════════════════════════════════════════════════════════
#  주행 제어
# ══════════════════════════════════════════════════════════════════════════
def _turn_to_angle(target_deg, tolerance=2.0, max_iter=300):
    for _ in range(max_iter):
        curr = getAngle()
        err  = (target_deg - curr + 180) % 360 - 180
        if abs(err) < tolerance: break
        spd = max_velocity * min(0.5, abs(err) / 30.0) * (1.0 if err > 0 else -1.0)
        wheel1.setVelocity(-spd); wheel2.setVelocity(spd)
        robot.step(timeStep)
    wheel1.setVelocity(0); wheel2.setVelocity(0)
    for _ in range(5):
        wheel1.setVelocity(0); wheel2.setVelocity(0)
        robot.step(timeStep)
    wheel1.setVelocity(0); wheel2.setVelocity(0)
 
def _drive_straight_pd(dist1, d4, d5):
    global _prev_error
    if d4 < _WALL_NEAR and d5 < _WALL_NEAR: error = d4 - d5
    elif d4 < _WALL_NEAR: error = -(_WALL_TARGET - d4)
    elif d5 < _WALL_NEAR: error = (_WALL_TARGET - d5)
    else:                  error = 0.0
    d_error     = error - _prev_error
    _prev_error = error
    correction  = _KP * error + _KD * d_error
    correction  = max(-max_velocity * 0.4, min(max_velocity * 0.4, correction))
    if dist1 < 0.12:   base = max_velocity * 0.25
    elif dist1 < 0.18: base = max_velocity * (0.25 + 0.75 * (dist1 - 0.12) / 0.06)
    else:              base = max_velocity
    return max(0.0, min(max_velocity, base + correction)), max(0.0, min(max_velocity, base - correction))
 
# ══════════════════════════════════════════════════════════════════════════
#  동심원 인식 (C/F/O/P)
# ══════════════════════════════════════════════════════════════════════════
def _nr_get_strict_masks(hsv):
    return [
        cv2.inRange(hsv,(0,190,150),(10,255,240)) | cv2.inRange(hsv,(170,190,150),(180,255,240)),
        cv2.inRange(hsv,(48,100,100),(75,255,255)),
        cv2.inRange(hsv,(18,80,100),(45,255,255)),
        cv2.inRange(hsv,(105,100,100),(135,255,255)),
    ]
 
def _nr_classify_pixel(img, x, y):
    if y<0 or y>=img.shape[0] or x<0 or x>=img.shape[1]: return None
    b,g,r = float(img[y,x,0]),float(img[y,x,1]),float(img[y,x,2])
    if b<40 and g<40 and r<40: return 'Black'
    hp = cv2.cvtColor(img[y:y+1,x:x+1],cv2.COLOR_BGR2HSV)[0,0]
    hv,sv,vv = float(hp[0]),float(hp[1]),float(hp[2])
    if sv < 70 or vv < 70: return None
    if hv<=15 or hv>=165:    return 'Red'
    if 48<=hv<=75:           return 'Green'   # 55-65 → 48-75
    if 18<=hv<=45:           return 'Yellow'  # 25-35 → 18-45
    if 105<=hv<=135:         return 'Blue'    # 115-125 → 105-135
    return None
 
def _nr_find_concentric(img, max_center_dist=20):
    """
    실제 타원 피팅으로 가장 바깥 원과 가장 안쪽 원의 반지름을 모두 반환.
    반환: (cx, cy, outer_r, inner_r, ellipses_by_color)
    inner_r = 가장 작은 타원의 반지름 (없으면 outer_r * 0.15)
    """
    h, w = img.shape[:2]
    hsv   = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    masks = _nr_get_strict_masks(hsv)
    color_names = ['Red', 'Green', 'Yellow', 'Blue']

    ellipses_by_color = []
    all_radii = []   # (major_r, center_x, center_y)
    all_colored_pts = []

    for i, mask in enumerate(masks):
        pts = np.argwhere(mask > 0)[:, ::-1]   # (x, y)
        if len(pts) < 5:
            continue
        all_colored_pts.append(pts)
        try:
            e = cv2.fitEllipse(pts.reshape(-1, 1, 2).astype(np.int32))
        except Exception:
            continue
        major_r = max(e[1]) / 2
        minor_r = min(e[1]) / 2
        if major_r < 8:
            continue
        if minor_r > 0 and major_r / minor_r > 4.0:
            continue
        ellipses_by_color.append((color_names[i], e))
        all_radii.append((major_r, e[0][0], e[0][1]))

    if not all_radii:
        return None, None, None, None, None

    # ── 공통 중심 계산 ──────────────────────────────────────────────
    if all_colored_pts:
        stacked = np.vstack(all_colored_pts)
        cx = float(np.mean(stacked[:, 0]))
        cy = float(np.mean(stacked[:, 1]))
    else:
        cx = float(np.mean([r[1] for r in all_radii]))
        cy = float(np.mean([r[2] for r in all_radii]))

    # ── 각 타원의 중심 기준 실제 거리 분포로 outer/inner 결정 ──────
    # 전체 색상 픽셀의 중심으로부터 거리 분포
    stacked = np.vstack(all_colored_pts) if all_colored_pts else np.array([[cx, cy]])
    dists   = np.sqrt((stacked[:, 0] - cx) ** 2 + (stacked[:, 1] - cy) ** 2)

    outer_r = float(np.percentile(dists, 97))   # 상위 3% 제거 → 바깥 반지름
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    circles = cv2.HoughCircles(
        blurred, cv2.HOUGH_GRADIENT, dp=1.2, minDist=img.shape[0]//2,
        param1=60, param2=25,
        minRadius=int(outer_r * 0.8),
        maxRadius=int(min(img.shape[:2]) // 2)
    )
    if circles is not None:
        best_r = float(circles[0][0][2])
        if best_r > outer_r * 1.05:          # 10% 이상 크면 교체
            outer_r = best_r * 0.95
            print(f"[HOUGH] outer_r 보정: {outer_r:.1f}px")
    inner_r = float(np.percentile(dists,  3))   # 하위 3% 제거 → 안쪽 반지름

    border = 4
    dark   = (img[:, :, 0] < 50) & (img[:, :, 1] < 50) & (img[:, :, 2] < 50)
    ys, xs = np.where(dark)
    valid  = (ys > border) & (ys < h - border) & (xs > border) & (xs < w - border)
    if valid.sum() > 5:
        dp = np.column_stack([xs[valid], ys[valid]])
        dd = np.sqrt((dp[:, 0] - cx) ** 2 + (dp[:, 1] - cy) ** 2)
        ring_mask = (dd >= outer_r * 0.6) & (dd <= outer_r * 2.0)
        rb = dd[ring_mask]
        if len(rb) > 20:
            angles   = np.arctan2(dp[ring_mask, 1] - cy, dp[ring_mask, 0] - cx)
            quadrant = np.histogram(angles, bins=4, range=(-np.pi, np.pi))[0]
            if np.all(quadrant > 0):
                outer_r = float(np.percentile(rb, 95))

    # inner_r 최솟값 보정
    if inner_r < 2.0:
        inner_r = outer_r * 0.08

    concentric_count = sum(
        1 for _, e in ellipses_by_color
        if np.sqrt((e[0][0] - cx) ** 2 + (e[0][1] - cy) ** 2) <= max_center_dist
    )
    if concentric_count < 2:
        return None, None, None, None, None

    return cx, cy, outer_r, inner_r, ellipses_by_color
 
def _nr_normalize_rings(img, canvas_px=300, n_rings=5,
                         target_r_px=125, n_angles=180, n_radii=8):
    cx, cy, outer_r, inner_r, ellipses_by_color = _nr_find_concentric(img)
    if cx is None:
        return None, [], None

    # ★ 항상 중심(0)부터 시작 — inner_r 무시
    inner_r = 0.0
    span = outer_r

    band_edges = [span * (k / n_rings) for k in range(n_rings + 1)]

    ring_results = []
    for ring_idx in range(n_rings):
        r_lo  = band_edges[ring_idx]
        r_hi  = band_edges[ring_idx + 1]
        votes = {}
        for frac_r in np.linspace(r_lo + 0.3, r_hi - 0.3, n_radii):
            for theta in np.linspace(0, 2 * np.pi, n_angles, endpoint=False):
                px = int(round(cx + frac_r * np.cos(theta)))
                py = int(round(cy + frac_r * np.sin(theta)))
                c  = _nr_classify_pixel(img, px, py)
                if c is not None:
                    votes[c] = votes.get(c, 0) + 1
        total = sum(votes.values())
        if total == 0:
            ring_results.append(('Black', 0.0, {}))
            continue
        dominant, best_n = max(votes.items(), key=lambda x: x[1])
        ring_results.append((dominant, best_n / total * 100, votes))

    # 캔버스
    canvas = np.ones((canvas_px, canvas_px, 3), np.uint8) * 255
    CX, CY = canvas_px // 2, canvas_px // 2

    for i, (color, pct, _) in enumerate(ring_results):
        r_in  = int(target_r_px * (i     / n_rings))
        r_out = int(target_r_px * ((i+1) / n_rings))
        mo = np.zeros((canvas_px, canvas_px), np.uint8)
        cv2.circle(mo, (CX, CY), r_out, 255, -1)
        mi = np.zeros((canvas_px, canvas_px), np.uint8)
        if r_in > 0:
            cv2.circle(mi, (CX, CY), r_in, 255, -1)
        canvas[mo - mi == 255] = _NR_COLOR_BGR.get(color, (0, 0, 0))

    viz = canvas.copy()
    for i, (color, pct, _) in enumerate(ring_results):
        r_in  = int(target_r_px * (i     / n_rings))
        r_out = int(target_r_px * ((i+1) / n_rings))
        cv2.circle(viz, (CX, CY), r_out, (150, 150, 150), 1)
        mid_r = (r_in + r_out) // 2
        lx = CX + int(mid_r * np.cos(np.deg2rad(40))) + 2
        ly = CY - int(mid_r * np.sin(np.deg2rad(40)))
        txt_col = (200, 200, 200) if color == 'Black' else (50, 50, 50)
        cv2.putText(viz, f"R{i+1}:{color[:3]}({pct:.0f}%)",
                    (lx, ly), cv2.FONT_HERSHEY_SIMPLEX, 0.26, txt_col, 1)

    return viz, ring_results, (cx, cy, outer_r, ellipses_by_color)

def detect_cognitive_target(bgr, cam_name='?'):
    _gui_log(f"[{cam_name}] 동심원 분석 시작")
    viz,ring_results,info=_nr_normalize_rings(bgr)
    if viz is None or not ring_results:
        _gui_log(f"[{cam_name}] 동심원 미검출")
        _gui_send('rings',{'cam':cam_name,'viz':None,'orig':bgr,'results':[],'result':None}); return None
    cx,cy,outer_r,ellipses_by_color=info
    orig_overlay=bgr.copy()
    cv2.circle(orig_overlay,(int(cx),int(cy)),4,(0,0,255),-1)
    cv2.circle(orig_overlay,(int(cx),int(cy)),int(outer_r),(0,255,0),2)
    for i in range(1,5): cv2.circle(orig_overlay,(int(cx),int(cy)),int(outer_r*i/5),(0,255,255),1)
    scores=[]
    for i,(color,pct,votes) in enumerate(ring_results):
        score=_NR_SCORE.get(color); scores.append(score)
        sv=sorted(votes.items(),key=lambda x:-x[1])
        _gui_log(f"  Ring{i+1} {color}({pct:.0f}%) score={f'{score:+d}' if score is not None else 'None'} "
                 f"[{', '.join(f'{c}:{n}' for c,n in sv[:3])}]")
    result=None
    if all(s is not None for s in scores):
        total=sum(scores); result=_NR_RESULT.get(total)
        if result: _gui_log(f"[{cam_name}] scores={scores} sum={total} → {result}")
        else:      _gui_log(f"[{cam_name}] scores={scores} sum={total} → 범위외")
    else:
        _gui_log(f"[{cam_name}] Ring미확인: {[i+1 for i,s in enumerate(scores) if s is None]}")
    _gui_send('rings',{'cam':cam_name,'viz':viz,'orig':orig_overlay,'results':ring_results,'result':result})
    return result
 
# ══════════════════════════════════════════════════════════════════════════
#  YOLO 인식 (H/S/U)
# ══════════════════════════════════════════════════════════════════════════
def _advance_centered_for_victim(duration_ms, base_speed_ratio=0.5,
                                  wall_near=0.15, wall_target=0.09,
                                  kp=4.0, kd=1.0,
                                  victim_side=None):
    """
    duration_ms 동안 전진하면서 s4(좌)/s5(우) 거리센서로 통로 중앙 유지.
    한쪽 벽이 wall_near 이하로 가까워지면 반대 방향으로 조향 보정.

    오차 부호 규약 (_drive_straight_pd 와 동일):
      error > 0  →  우측 벽 가까움  →  correction > 0  →  v1(오른쪽 바퀴) 빠름  →  좌로 틀기
      error < 0  →  좌측 벽 가까움  →  correction < 0  →  v2(왼쪽 바퀴) 빠름   →  우로 틀기
    """
    base_speed = max_velocity * base_speed_ratio
    prev_error = 0.0

    _gui_log(f"[ADVANCE-CENTER] 전진 시작 {duration_ms}ms  speed={base_speed:.2f}")
    print(f"[ADVANCE-CENTER] 전진 시작 {duration_ms}ms  speed={base_speed:.2f}")

    init_time = robot.getTime()
    while robot.step(timeStep) != -1:
        if (robot.getTime() - init_time) * 1000.0 >= duration_ms:
            break
                 # 양쪽 여유 있음 → 직진

        d4 = s4.getValue()   # 좌 측면
        d5 = s5.getValue()   # 우 측면
        d2 = s2.getValue()   # 좌 전방 대각 (sensor1 = d1)
        d3 = s3.getValue()   # 우 전방 대각 (sensor3 = d3)

        # ── 측면 센서 오차 ────────────────────────────────────────────
        if d4 < wall_near and d5 < wall_near:
            if victim_side == 'left':
                error_side = +(wall_target - d4) * 1.5
            elif victim_side == 'right':
                error_side = -(wall_target - d5) * 1.5
            else:
                error_side = d4 - d5
        elif d4 < wall_near:
            error_side = +(wall_target - d4)
        elif d5 < wall_near:
            error_side = -(wall_target - d5)
        else:
            error_side = 0.0

        # ── 전방 대각 센서 오차 (측면보다 짧은 임계·낮은 가중치) ──────
        DIAG_NEAR   = 0.12   # 대각 센서 임계값
        DIAG_WEIGHT = 0.5    # 대각 센서 가중치
        error_diag  = 0.0
        if d2 < DIAG_NEAR:   # 좌전방 가까움 → 우로 틀기
            error_diag -= (DIAG_NEAR - d2) * DIAG_WEIGHT
        if d3 < DIAG_NEAR:   # 우전방 가까움 → 좌로 틀기
            error_diag += (DIAG_NEAR - d3) * DIAG_WEIGHT

        error = error_side + error_diag

        d_error    = error - prev_error
        prev_error = error

        correction = kp * error + kd * d_error
        # 최대 보정량: 기본 속도의 60%
        correction = max(-base_speed * 0.6, min(base_speed * 0.6, correction))

        v1 = max(0.0, min(max_velocity, base_speed + correction))
        v2 = max(0.0, min(max_velocity, base_speed - correction))

        wheel1.setVelocity(v1)
        wheel2.setVelocity(v2)

        print(f"  [ADVANCE-CENTER] "
              f"d4={d4:.3f} d5={d5:.3f} d2={d2:.3f} d3={d3:.3f} "
              f"side={error_side:+.4f} diag={error_diag:+.4f} "
              f"err={error:+.4f} corr={correction:+.3f} v=({v1:.2f},{v2:.2f})")
        
    wheel1.setVelocity(0)
    wheel2.setVelocity(0)
    _gui_log("[ADVANCE-CENTER] 완료")
    print("[ADVANCE-CENTER] 완료")

def _align_and_capture_circle(camera_device, camera_side, max_attempts=3):
    """
    90도 정렬 → 촬영 → 원 중심 확인 → 위치 조정 반복
    반환: 분석용 bgr 이미지 or None
    """
    IMG_W, IMG_H = camera_device.getWidth(), camera_device.getHeight()
    CENTER_X = IMG_W / 2
    CENTER_Y = IMG_H / 2
    OFFSET_THRESHOLD = IMG_W * 0.15  # 15% 이내면 OK

    for attempt in range(max_attempts):
        print(f"[ALIGN-CAPTURE] 시도 {attempt+1}/{max_attempts}")

        # 1. 90도 정렬
        success, captured_bgr, aligned_robot_angle = _align_perpendicular_to_wall(camera_device, camera_side)
        wheel1.setVelocity(0); wheel2.setVelocity(0)
        delay(200)

        # 2. 촬영
        bgr = captured_bgr if captured_bgr is not None else _read_camera_bgr(camera_device)
        if bgr is None:
            continue

        # 3. 원 중심 확인
        cx, cy, outer_r, inner_r, _ = _nr_find_concentric(bgr)
        if cx is None:
            _gui_log(f"[ALIGN-CAPTURE] 원 미검출 → 재시도")
            continue

        offset_x = cx - CENTER_X
        offset_y = cy - CENTER_Y
        print(f"[ALIGN-CAPTURE] cx={cx:.1f} cy={cy:.1f} offset_x={offset_x:+.1f} offset_y={offset_y:+.1f}")
        _gui_log(f"[ALIGN-CAPTURE] offset_x={offset_x:+.1f} offset_y={offset_y:+.1f}")
        #_save_debug_img(bgr, f"{camera_side}_attempt{attempt+1}")

        # 4. 원이 충분히 중앙에 있으면 완료
        if abs(offset_x) <= OFFSET_THRESHOLD:
            _gui_log(f"[ALIGN-CAPTURE] ✓ 원 중앙 정렬 완료")
            return bgr

        # 5. 위치 조정
        # Ca1(좌후방): offset_x > 0(오른쪽) → 전진, offset_x < 0(왼쪽) → 후진
        # Ca2(우후방): 반대
        sign = 1.0 if camera_side == 'left' else -1.0
        if offset_x * sign > 0:
            print(f"[ALIGN-CAPTURE] 전진")
            _gui_log(f"[ALIGN-CAPTURE] 전진 (offset_x={offset_x:+.1f})")
            wheel1.setVelocity(max_velocity * 0.25)
            wheel2.setVelocity(max_velocity * 0.25)
        else:
            print(f"[ALIGN-CAPTURE] 후진")
            _gui_log(f"[ALIGN-CAPTURE] 후진 (offset_x={offset_x:+.1f})")
            wheel1.setVelocity(-max_velocity * 0.25)
            wheel2.setVelocity(-max_velocity * 0.25)

        delay(400)
        wheel1.setVelocity(0); wheel2.setVelocity(0)
        delay(150)

    # 최대 시도 후 마지막 이미지라도 반환
    _gui_log(f"[ALIGN-CAPTURE] 최대 시도 도달 → 마지막 이미지 사용")
    return _read_camera_bgr(camera_device)





def rgb_to_hsv(r, g, b) -> tuple:
    """RGB(0~255) → HSV(h: 0~360, s: 0~1, v: 0~1)"""
    h, s, v = colorsys.rgb_to_hsv(r / 255., g / 255., b / 255.)
    return int(h * 360), round(s, 3), round(v, 3)

def detect_tile_type(r, g, b) -> int:
    """컬러센서 RGB로 바닥 타입 반환"""
    if r < 60 and g < 60 and b < 60:
        return _HOLES
    if 190 < r < 255 and 170 < g < 230 and 80 < b < 150:
        return _SWAMPS
    return 0

def get_tile_color(r, g, b) -> str:
    """컬러센서 RGB로 존 전환 색상 반환"""
    if r < 85 and g < 85 and b > 245:
        return 'b'
    elif 155 < r < 175 and g < 85 and 230 < b < 250:
        return 'p'
    elif r > 245 and g < 85 and b < 85:
        return 'r'
    elif r < 85 and g > 245 and b < 85:
        return 'g'
    elif r > 245 and 230 < g < 248 and b < 85:
        return 'o'
    elif r > 245 and g > 248 and b < 85:
        return 'y'
    return None

def is_checkpoint(r, g, b) -> bool:
    """HSV 범위로 체크포인트 판별"""
    h, s, v = rgb_to_hsv(r, g, b)
    mn, mx = _CHECKPOINT_HSV['min'], _CHECKPOINT_HSV['max']
    return mn[0] <= h <= mx[0] and mn[1] <= s <= mx[1] and mn[2] <= v <= mx[2]

def getAngle() -> float:
    """
    Gets the current angle in radiants and converts it to normal degrees(0 is north and goes clockwise)

    @return: The direction you're looking at in degrees
    """
    angle = (inertial_unit.getRollPitchYaw()[2] * 180 / math.pi + 360) % 360
    if angle > 180:
        angle = 360 - angle
    else:
        angle = -angle
    return angle % 360

def rotate_LidarValue(cloud, angle):
    index_ray = int(round(((360-angle) % 360) * (512.0/360.0))) % 512  # Multiply by the ratio 512 / 360
    return cloud[index_ray:] + cloud[:index_ray]

def getLidarValue(angle: int, lidar_value) -> float:

    if lidar_value is None:
        return float('inf')

    index_central_ray = round((angle % 360) * 1.422) - 1  # Multiply by the ratio 512 / 360
    # Get the 3 rays around that angle
    rays = [
        lidar_value[(index_central_ray - 1) % 512],
        lidar_value[index_central_ray % 512],
        lidar_value[(index_central_ray + 1) % 512]
    ]
    average = sum(rays) / 3
    standard_deviation = math.sqrt(((rays[0] - average) ** 2 + (rays[1] - average) ** 2 + (rays[2] - average) ** 2) / 3)

    if standard_deviation >= 0.02:
        avg_left = (rays[0] + rays[1]) / 2
        sd_left = math.sqrt(((rays[0] - avg_left) ** 2 + (rays[1] - avg_left) ** 2) / 2)

        avg_right = (rays[1] + rays[2]) / 2
        sd_right = math.sqrt(((rays[1] - avg_right) ** 2 + (rays[2] - avg_right) ** 2) / 2)

        if sd_left >= 0.02 and sd_right >= 0.02:
            return min(rays)
        elif sd_left < 0.02 and sd_right < 0.02:
            return average
        else:
            if sd_left < 0.02:
                return min(avg_left, rays[2])

            if sd_right < 0.02:
                return min(rays[0], avg_right)

    return average 

class Cell:
    def __init__(self, explored=False, c_t= 0, center=_UNDEFINED, 
                 cc=_UNDEFINED, cf=_UNDEFINED, cr=_UNDEFINED, cb=_UNDEFINED, cl=_UNDEFINED,
                 dsf=_UNDEFINED, dsr=_UNDEFINED, dsb=_UNDEFINED, dsl=_UNDEFINED,
                 ds0=_UNDEFINED, ds1=_UNDEFINED, ds2=_UNDEFINED, ds3=_UNDEFINED,
                 ds4=_UNDEFINED, ds5=_UNDEFINED, ds6=_UNDEFINED, ds7=_UNDEFINED,
                 fr=_UNDEFINED, br=_UNDEFINED, fl=_UNDEFINED, bl=_UNDEFINED):
        
        
     self.cell = [
            [fl, ds0, dsf, ds1, fr],
            [ds7, c_t, cf, c_t, ds2],
            [dsl, cl, cc, cr, dsr],
            [ds6, c_t, cb, c_t, ds3],
            [bl, ds5, dsb, ds4, br]
        ]
     self.explored = explored
     self.center = center 
     self.visited = False

    def get_rotated_cell(self, angle):
        times = (angle // 90) % 4

        res = [row[:] for row in self.cell]
        
        for _ in range(times):
            rotated = [[0]*5 for _ in range(5)]
            for i in range(5):
                for j in range(5):
                    rotated[4 - j][i] = res[i][j]
            res = rotated
            
        # 새로운 Cell 객체를 생성하고 기존의 상태(explored, center)를 복사
        new_cell = Cell(explored=self.explored, center=self.center)
        # 회전된 2차원 리스트를 새 객체의 cell 속성에 할당
        new_cell.cell = res
        
        return new_cell
    
    def beautiful_my_cell(self):
        #if self.explored == False: return
        
        if self.cell[2][2] == _UNDEFINED:
            if self.cell[1][2] not in VALID_TYPES:
                self.cell[1][2] = _UNDEFINED
            if self.cell[3][2] not in VALID_TYPES:
                self.cell[3][2] = _UNDEFINED
            if self.cell[2][1] not in VALID_TYPES:
                self.cell[2][1] = _UNDEFINED
            if self.cell[2][3] not in VALID_TYPES:
                self.cell[2][3] = _UNDEFINED
        else:
            self.explored = True
            self.visited = True

        path = [[0, 2], [2, 4], [4, 2], [2, 0]]
        for r, c in path:
            if self.cell[r][c] == _UNDEFINED:
                if c == 2:
                    if self.cell[r][c+1] not in VALID_TYPES:
                        self.cell[r][c+1] = _UNDEFINED
                    if self.cell[r][c-1] not in VALID_TYPES:
                        self.cell[r][c-1] = _UNDEFINED
                else:
                    if self.cell[r+1][c] not in VALID_TYPES:
                        self.cell[r+1][c] = _UNDEFINED
                    if self.cell[r-1][c] not in VALID_TYPES:
                        self.cell[r-1][c] = _UNDEFINED

np.set_printoptions(threshold=np.inf, linewidth=np.inf)
'''
plt.ion()

fig, ax = plt.subplots(figsize=(6, 6))
scat = ax.scatter([], [], s=2, c='red') # 점(Scatter) 객체 생성

# 축 설정 (라이다 최대 거리가 2m라면 -2 ~ 2 정도로 설정)
ax.set_xlim(-0.2, 0.2)
ax.set_ylim(-0.2, 0.2)
ax.set_aspect('equal')
ax.grid(True)
'''
class CloudMap:
    """
    1cm×1cm 해상도 점유 격자 지도.
 
    Parameters
    ----------
    n : int   — 가로 타일 수  (맵 폭 = (2n-1)*12 cm)
    m : int   — 세로 타일 수  (맵 높이 = (2m-1)*12 cm)
    lidar_points : int   — 라이다 수평 포인트 수 (기본 512)
    max_range    : float — 유효 라이다 최대 거리 m (기본 1.2)
    """
 
    def __init__(self, n: int, m: int,
                 lidar_points: int = _LIDAR_POINTS,
                 max_range: float  = _MAX_RANGE):
 
        self.n = n
        self.m = m
        self.lidar_points = lidar_points
        self.max_range    = max_range
 
        self.rows = (2 * n - 1) * TILE_CM +1     # Z 방향
        self.cols = (2 * m - 1) * TILE_CM +1     # X 방향
 
        self.map = np.full((self.rows, self.cols), _UNDEFINED, dtype=np.int8)
 
        self._origin_x: float | None = None   # m 단위
        self._origin_z: float | None = None   # m 단위
 
        self._center_row = self.rows // 2
        self._center_col = self.cols // 2

        self._smooth_x = None
        self._smooth_z = None
        self._alpha = 1.0
 
    # 배열 인덱스 변환
    def coords_to_index(self, gps_x: float, gps_z: float) -> tuple[int, int]:
        """
        GPS 절대 좌표(m)를 numpy 배열의 (row, col) 인덱스로 변환.
 
        * GPS 원점이 아직 설정되지 않았으면 현재 위치를 원점으로 저장.
        * 범위를 벗어나면 None 반환.
 
        Parameters
        ----------
        gps_x : float — GPS X 좌표 (m)
        gps_z : float — GPS Z 좌표 (m)
 
        Returns
        -------
        (row, col) : tuple[int, int] | None
        """
        self._ensure_origin(gps_x, gps_z)
 
        # 원점 기준 상대 좌표 (m)
        rel_x = gps_x - self._origin_x
        rel_z = gps_z - self._origin_z
 
        # m → cm
        dx_cm = rel_x * M_TO_CM
        dz_cm = rel_z * M_TO_CM
 
        # 배열 인덱스 (row = Z, col = X)
        row = self._center_row + int(round(dz_cm))
        col = self._center_col + int(round(dx_cm))
 
        if not self._in_bounds(row, col):
            return None
 
        return (row, col)
 
    def update(self, gps_x: float, gps_z: float,
               point_cloud: list | np.ndarray) -> None:
        """
        현재 로봇 위치 + 라이다 값으로 맵을 갱신.
 
        Parameters
        ----------
        gps_x      : float       — GPS X 좌표 (m)
        gps_z      : float       — GPS Z 좌표 (m)
        yaw_deg    : float       — 로봇 Yaw 각도 (도, 북=0 시계방향+)
        point_cloud: array-like  — 라이다 거리 배열 (m, 길이=lidar_points)
                                   보통 lidar.range_image[512*layer : 512*(layer+1)]
 
        내부 동작
        ----------
        * 각 라이다 빔에 대해 레이캐스팅 → 빔 경로는 FREE(0), 끝점은 WALL(1)
        * 거리가 max_range 이상이면 끝점 마킹 없이 경로만 FREE 처리
        """
        self._ensure_origin(gps_x, gps_z)

         # GPS 노이즈 스무딩 (지수 이동 평균)
        if self._smooth_x is None:
            self._smooth_x = gps_x
            self._smooth_z = gps_z
        else:
            self._smooth_x = self._alpha * gps_x + (1 - self._alpha) * self._smooth_x
            self._smooth_z = self._alpha * gps_z + (1 - self._alpha) * self._smooth_z

        robot_idx = self.coords_to_index(self._smooth_x, self._smooth_z)
        print(f"robot_index: {robot_idx}")
        if robot_idx is None:
            return
        robot_row, robot_col = robot_idx
 
        n_pts = min(len(point_cloud), self.lidar_points)

        for i in range(n_pts):
            dist = point_cloud[i]
 
            if dist is None or math.isnan(dist) or math.isinf(dist):
                continue
            if dist <= 0:
                continue
 
            # 빔 방향 (라이다는 반시계 방향으로 스캔, 인덱스 0 = 로봇 정면)
            beam_angle = (2 * math.pi * i / self.lidar_points)
 
            hit = dist < self.max_range
 
            # 끝점 거리 
            trace_dist = dist if hit else self.max_range
 
            # 끝점의 절대 좌표 (m)
            end_x = self._smooth_x - trace_dist * math.sin(beam_angle)
            end_z = self._smooth_z + trace_dist * math.cos(beam_angle)
            #print(f"end coordinates... {end_x}, {end_z}")
 
            # 끝점 인덱스
            end_idx = self.coords_to_index(end_x, end_z)
            
            if end_idx is None:
                continue
            end_row, end_col = end_idx
 
            # ── 레이캐스팅으로 경로 FREE 마킹 ──
            self._raycast_free(robot_row, robot_col, end_row, end_col)
 
            # ── 끝점 WALL 마킹 ──
            if hit:
                self._mark_WALL(end_row, end_col)
 
    # ──────────────────────────────────────

    def reset_map(self) -> None:
        """전체 맵을 -1(unknown)으로 초기화."""
        self.map[:] = _UNDEFINED
 
    def get_value(self, gps_x: float, gps_z: float) -> int | None:
        """해당 GPS 좌표 셀의 현재 값(-1/0/1) 반환. 범위 밖이면 None."""
        idx = self.coords_to_index(gps_x, gps_z)
        if idx is None:
            return None
        return int(self.map[idx])
 
    def visualize(self, show: bool = True, save_path: str | None = None):
        """
        matplotlib으로 맵을 시각화.
        -1=회색, 0=흰색, 1=검정
        """
        visual_map = np.zeros_like(self.map, dtype=np.uint8)
        visual_map[self.map == -1] = 127
        visual_map[self.map == 0] = 255
        visual_map[self.map == 1] = 0

        if self._smooth_x is not None:
            idx = self.coords_to_index(self._smooth_x, self._smooth_z)
            if idx:
                r, c = idx
                visual_map[r-1:r+1, c-1:c+1] = 180  # 로봇 위치 회색 점
        
        try:
            plt.imsave(save_path, visual_map, cmap='gray') 
            print(f"✅ 저장 완료: {save_path}")
        except Exception as e:
            print(f"❌ 저장 실패: {e}")
 
    # ──────────────────────────────────────
    def _ensure_origin(self, x: float, z: float) -> None:
        """GPS 원점이 없으면 현재 위치로 초기화."""
        if self._origin_x is None:
            self._origin_x = x
            self._origin_z = z
 
    def _in_bounds(self, row: int, col: int) -> bool:
        return 0 <= row < self.rows and 0 <= col < self.cols
 
    def _raycast_free(self, r0: int, c0: int, r1: int, c1: int) -> None:
        if _HAS_SKIMAGE:
            rr, cc = draw_line(r0, c0, r1, c1)
        else:
            rr, cc = self._bresenham(r0, c0, r1, c1)

        for r, c in zip(rr, cc):
            if self._in_bounds(r, c):
                if self.map[r, c]==_UNDEFINED:
                    self.map[r, c] = _FREE
 
    def _mark_WALL(self, row: int, col: int) -> None:
        t = _WALL_THICKNESS_CM
        for dr in range(-t, t + 1):
            for dc in range(-t, t + 1):
                r, c = row + dr, col + dc
                if self._in_bounds(r, c):
                    self.map[r, c] = _WALL  # 조건 없이 항상 WALL로 덮어씀
    
    @staticmethod
    def _bresenham(r0: int, c0: int, r1: int, c1: int):
        rows, cols = [], []
        dr = abs(r1 - r0);  dc = abs(c1 - c0)
        sr = 1 if r0 < r1 else -1
        sc = 1 if c0 < c1 else -1
        err = dr - dc
        r, c = r0, c0
        while True:
            rows.append(r); cols.append(c)
            if r == r1 and c == c1:
                break
            e2 = 2 * err
            if e2 > -dc:  err -= dc; r += sr
            if e2 <  dr:  err += dr; c += sc
        return rows, cols
 
    # ──────────────────────────────────────
    # dunder
    def __repr__(self) -> str:
        origin = (f"({self._origin_x:.3f}, {self._origin_z:.3f})"
                  if self._origin_x is not None else "not set")
        return (f"CloudMap(n={self.n}, m={self.m}, "
                f"map={self.rows}×{self.cols}cm, origin={origin})")


class GridMap:
    def __init__(self, n: int, m: int):
        self.width = 2 * n - 1
        self.height = 2 * m - 1 
        self.center_x = n - 1
        self.center_z = m - 1
            
        #2차원 배열 
        self.grid = [[Cell() for _ in range(self.height)] for _ in range(self.width)]

    def get_cell_index(self, gps_x: float, gps_z: float)-> tuple[int, int]:
        """
        GPS 절대 좌표(m)를 Cell index (x, z)로 변환.
        """
        if Cld_Map._origin_x != None:
            rel_x = gps_x - Cld_Map._origin_x
            rel_z = gps_z - Cld_Map._origin_z
 
        # m → cm, 
        dx_cm = (rel_x * M_TO_CM)/TILE_CM
        dz_cm = (rel_z * M_TO_CM)/TILE_CM
 
        # 배열 인덱스 (row = Z, col = X)
        ix = self.center_x + int(round(dx_cm))
        iz = self.center_z + int(round(dz_cm))
 
        if not self._in_bounds(ix, iz):
            return None
 
        return (ix, iz)
    
    def get_cell(self, gps_x: float, gps_z: float):

        # Cell 반환(귀찮잖아~)

        result = self.get_cell_index(gps_x, gps_z)
        if result is None:          # ← None 체크 추가
            return None
        ix, iz = result
        return self.grid[ix][iz]
    def _in_bounds(self, x: int, z: int) -> bool:
        return 0 <= x < self.width and 0 <= z < self.height
    
    def update_cloud_wall(self, x: float, z: float, cloud_map: CloudMap):
        """
        여러개(십자)
        """
        ix, iz = self.get_cell_index(x, z)
        if ix is None or iz is None:
            return

        self.update_single_cell(ix, iz, cloud_map, True)

        # 업데이트할 대상 리스트: (상, 하, 좌, 우)
        targets = [
            (ix + 1, iz), (ix - 1, iz),
            (ix, iz + 1), (ix, iz - 1)
        ]

        for tx, tz in targets:
            if self._in_bounds(tx, tz):
                self.update_single_cell(tx, tz, cloud_map, False)
    
    def update_single_cell(self, ix: int, iz: int, cloud_map: CloudMap, mark_explored: bool, cell=None):
        """
        GridMap Cell 업데이트 - 하나
        """
        if not cell:
            cell = self.grid[ix][iz]
        #if mark_explored: cell.explored = True  
        
        HALF_TILE = TILE_CM // 2  # 6cm
        WALL_THRESHOLD = 1
        ignore_indices = {(1, 1), (1, 3), (3, 1), (3, 3)}

        R_BREAKS = [0, 3, 5, 7, 9, 12]  # 5구간: [0,2),[2,5),[5,7),[7,10),[10,12)
        C_BREAKS = [0, 3, 5, 7, 9, 12]

        col_c = cloud_map._center_col + (ix - self.center_x) * TILE_CM
        row_c = cloud_map._center_row + (iz - self.center_z) * TILE_CM

        r_start = row_c - TILE_CM // 2
        c_start = col_c - TILE_CM // 2

        for i in range(5):
            for j in range(5):
                if (i, j) in ignore_indices:
                    continue

                sub_r_s = r_start + R_BREAKS[i]
                sub_r_e = r_start + R_BREAKS[i+1]
                sub_c_s = c_start + C_BREAKS[j]
                sub_c_e = c_start + C_BREAKS[j+1]

                if sub_r_s >= sub_r_e or sub_c_s >= sub_c_e:
                    continue
                if not (0 <= sub_r_s and sub_r_e <= cloud_map.rows and
                        0 <= sub_c_s and sub_c_e <= cloud_map.cols):
                    continue

                sub_patch = cloud_map.map[sub_r_s:sub_r_e, sub_c_s:sub_c_e]
                if np.sum(sub_patch == _WALL) >= WALL_THRESHOLD:
                    if cell.cell[i][j] not in VALID_TYPES:
                        cell.cell[i][j] = _WALL

        cell.beautiful_my_cell()
    
    def update_explored_by_cloud(self, cloud_map: CloudMap, gps_x: float, gps_z: float, undefined_max: int = 20):
        """
        로봇 현재 위치 중심 5×5 Cell만 순회하며
        CloudMap 타일 영역의 _UNDEFINED 픽셀이 undefined_max 이하이면 explored = True로 세팅.
        """
        result = self.get_cell_index(gps_x, gps_z)
        if result is None:
            return
        cx, cz = result

        for ix in range(cx - 2, cx + 3):
            for iz in range(cz - 2, cz + 3):
                if not self._in_bounds(ix, iz):
                    continue
                cell = self.grid[ix][iz]
                if cell.explored:
                    continue

                col_c = cloud_map._center_col + (ix - self.center_x) * TILE_CM
                row_c = cloud_map._center_row + (iz - self.center_z) * TILE_CM

                r_s = max(row_c - TILE_CM // 2, 0)
                r_e = min(row_c + TILE_CM // 2, cloud_map.rows)
                c_s = max(col_c - TILE_CM // 2, 0)
                c_e = min(col_c + TILE_CM // 2, cloud_map.cols)

                if r_e <= r_s or c_e <= c_s:
                    continue

                tile_patch = cloud_map.map[r_s:r_e, c_s:c_e]
                if int(np.sum(tile_patch == _UNDEFINED)) <= undefined_max:
                    cell.explored = True
                self.update_single_cell(ix, iz, cloud_map, True, cell)
    
    def display(self):
        # 1. 탐색 영역 계산 (Bounding Box)
        min_x, max_x = self.width, -1
        min_z, max_z = self.height, -1
        found_explored = False

        for x in range(self.width):
            for z in range(self.height):
                if self.grid[x][z].explored:
                    if x < min_x: min_x = x
                    if x > max_x: max_x = x
                    if z < min_z: min_z = z
                    if z > max_z: max_z = z
                    found_explored = True

        if not found_explored:
            print("아직 탐색된 구역이 없습니다.")
            return

        # 2. 출력 시작
        for z in range(min_z, max_z + 1):
            lines = ["", "", "", "", ""]
            for x in range(min_x, max_x + 1):
                t_cell = self.grid[x][z]

                for r in range(5):
                    dis_str = ""
                    for c in range(5):
                        v = t_cell.cell[r][c]
                        ic = _ICONS.get(v, str(v))
                        
                        
                        if r == 2 and c == 2:
                            ic = str(int(t_cell.explored))

                        if not ic: ic = "  "

                        # --- 핵심 수정 구간: 글자 너비 강제 정규화 ---
                        # ▮ 처럼 이미 2칸인 놈은 그대로, ?, 1 처럼 1칸인 놈은 뒤에 공백 하나 추가
                        if len(ic) == 1:
                            target_ic = f"{ic} " 
                        else:
                            target_ic = ic
                        
                        dis_str += target_ic
                    
                    # 타일 사이 구분선은 너비 1짜리 세로선 사용
                    lines[r] += dis_str + "│"
            
            # 5줄 출력
            for line in lines:
                print(line)
            
            # 3. 가로 구분선 (타일 너비는 10칸 + 세로선 1칸 = 11칸)
            current_width_count = (max_x - min_x + 1)
            # '─' 도 전각 문자라 너비가 2니까, 11을 2로 나눈 값만큼 반복
            print("─" * (current_width_count * 5) + "─" * current_width_count)
    
def _tile_index_to_world(my_map, cld_map, ix: int, iz: int) -> tuple[float, float]:
    #GridMap 인덱스 → 타일 중심 월드 좌표(m)
    dx_tile = ix - my_map.center_x
    dz_tile = iz - my_map.center_z
    wx = cld_map._origin_x + dx_tile * TILE_M
    wz = cld_map._origin_z + dz_tile * TILE_M
    return wx, wz

def find_frontiers(my_map, cld_map) -> list[tuple[float, float]]:
    """
    My_Map 에서 프론티어 Cell 을 찾아 월드 좌표(m) 목록을 반환한다.
 
    프론티어 조건:
      - cell.explored == True
      - 상하좌우 중 하나 이상이 explored == False
 
    반환값: [(world_x, world_z), ...] — 프론티어 Cell 절대좌표
    """
    frontiers: list[tuple[float, float]] = []
    W = my_map.width
    H = my_map.height
 
    for ix in range(W):
        for iz in range(H):
            cell = my_map.grid[ix][iz]
            if not cell.explored:
                continue
 
            # 상하좌우 중 미탐색 Cell 이 있는지 확인
            has_unexplored_neighbor = False
            for dix, diz in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nix, niz = ix + dix, iz + diz
                if 0 <= nix < W and 0 <= niz < H:
                    if not my_map.grid[nix][niz].explored:
                        has_unexplored_neighbor = True
                        break
 
            if not has_unexplored_neighbor:
                continue
 
            # 타일 중심이 CloudMap 상에서 이동 가능(FREE)한지 확인
            wx, wz = _tile_index_to_world(my_map, cld_map, ix, iz)
            cval = cld_map.get_value(wx, wz)
            if cval == _FREE:
                frontiers.append((wx, wz))
 
    return frontiers

def find_frontiers_by_nodes(my_map, cld_map, node_positions, adjacency) -> list[tuple[float, float]]:
    """
    Cell 단위가 아닌, A* 그래프 상의 노드(경계선)를 프론티어로 추출합니다.
    """
    frontiers = {}   # key → 케이스 번호(1 or 2)
    W, H = my_map.width, my_map.height


    for ix in range(W):
        for iz in range(H):
            cell = my_map.grid[ix][iz]
            if not cell.explored:
                continue

            tile_ox, tile_oz = _tile_top_left(my_map, cld_map, ix, iz)

            # visited=False인 탐색된 셀 → 중심 노드를 프론티어로 (케이스 2)
            if not cell.visited:
                if (cell.cell[2][2] == _WALL
                    or cell.cell[2][2] == _HOLES
                    or cell.cell[1][1] == _SWAMPS):
                    continue
                center_key = (round(tile_ox + HALF_T, 4),
                              round(tile_oz + HALF_T, 4))
                if (center_key in node_positions
                        and len(adjacency.get(center_key, [])) > 0):
                    frontiers[center_key] = 2   # ← set.add → dict[key]=2
                continue

            # visited=True → 인접 미탐색 셀 경계 노드 (케이스 1)
            directions = [
                (-1, 0, [(dr, 0.00)   for dr in (0.00, HALF_T, TILE_M)]),
                ( 1, 0, [(dr, TILE_M) for dr in (0.00, HALF_T, TILE_M)]),
                ( 0,-1, [(0.00, dc)   for dc in (0.00, HALF_T, TILE_M)]),
                ( 0, 1, [(TILE_M, dc) for dc in (0.00, HALF_T, TILE_M)]),
            ]
            for dx, dz, edge_offsets in directions:
                nix, niz = ix + dx, iz + dz
                if 0 <= nix < W and 0 <= niz < H:
                    if not my_map.grid[nix][niz].explored:
                        for dr, dc in edge_offsets:
                            node_key = (round(tile_ox + dc, 4),
                                        round(tile_oz + dr, 4))
                            if (node_key in node_positions
                                    and len(adjacency.get(node_key, [])) > 0):
                                frontiers[node_key] = 1   # ← set.add → dict[key]=1

    return frontiers
 

def select_frontier(frontiers: dict[tuple, int],
                    robot_x: float, robot_z: float,
                    my_map, cld_map,
                    unvisited_bonus: float = 0.2) -> Optional[tuple]:
    """
    가장 가까운 프론티어를 선택.
    explored=True & visited=False인 셀의 중심 노드(케이스 2)는
    거리에 unvisited_bonus를 곱해 우선 선택되도록 함.
    """
    if not frontiers:
        return None

    def score(item):
        key, ftype = item
        dist = math.hypot(key[0] - robot_x, key[1] - robot_z)
        if ftype == 2:
            return dist * unvisited_bonus  # ← 거리 감소 = 우선순위 증가
        return dist
    
    return min(frontiers.items(), key=score)[0]

class NavNode:
    """A* 그래프 노드 — 월드 좌표(m)를 키로 사용"""
    __slots__ = ("x", "z", "key")
 
    def __init__(self, x: float, z: float):
        #인접 타일 공유 노드를 합산
        self.x   = round(x, 4)
        self.z   = round(z, 4)
        self.key = (self.x, self.z)
 
    def __eq__(self, other):  return self.key == other.key
    def __hash__(self):       return hash(self.key)
    def __lt__(self, other):  return self.key < other.key
 
 
def build_nav_graph(my_map, cld_map,
                    passable_check_samples: int = 2
                    ) -> dict[tuple, list[tuple[tuple, float]]]:

    node_dict: dict[tuple, NavNode] = {}
    explored_tiles: list[tuple[int, int]] = []

    # 노드 인덱스(0~8) → 참조할 셀 목록 [(dix, diz, r, c), ...]
    # dix/diz: 현재 타일(ix,iz) 기준 인접 타일 오프셋
    # r, c: 해당 타일 Cell[r][c]

    for ix in range(my_map.width):
        for iz in range(my_map.height):
            if not my_map.grid[ix][iz].explored:
                continue
            explored_tiles.append((ix, iz))
            tile_origin_x, tile_origin_z = _tile_top_left(my_map, cld_map, ix, iz)

            for node_idx, (dr, dc) in enumerate(_TILE_OFFSETS):
                refs = _NODE_CELL_REFS[node_idx]
                
                # 참조 셀 중 하나라도 explored & WALL이면 노드 생성 안 함
                is_wall = False
                for dix, diz, r, c in refs:
                    nix, niz = ix + dix, iz + diz
                    if not my_map._in_bounds(nix, niz):
                        continue
                    ref_cell = my_map.grid[nix][niz]
                    if not ref_cell.explored:
                        continue  # 미탐색 셀은 무시
                    if ref_cell.cell[r][c] == _WALL:
                        is_wall = True
                        break

                if is_wall:
                    continue

                node = NavNode(tile_origin_x + dc, tile_origin_z + dr)
                val = cld_map.get_value(node.x, node.z)
                if val != _WALL:          # ← WALL이면 노드 자체를 만들지 않음
                    node_dict[node.key] = node

    # 간선 생성 
    adjacency: dict[tuple, list[tuple[tuple, float]]] = {k: [] for k in node_dict}
 
    # 각 타일 내부 + 이웃 타일 간 경계 간선
    for ix, iz in explored_tiles:
        tile_ox, tile_oz = _tile_top_left(my_map, cld_map, ix, iz)
 
        # 이 타일의 9 노드
        tile_nodes = [
            NavNode(tile_ox + dc, tile_oz + dr) for dr, dc in _TILE_OFFSETS
        ]
 
        # 인접 쌍 정의 (행 방향 + 열 방향 + 대각선 포함)
        neighbor_pairs = [
            (0, 1), (1, 2),          # 윗 행
            (3, 4), (4, 5),          # 중간 행
            (6, 7), (7, 8),          # 아랫 행
            (0, 3), (3, 6),          # 왼 열
            (1, 4), (4, 7),          # 중간 열
            (2, 5), (5, 8),          # 오른 열
            (0, 4), (4, 8),          # 대각선
            (2, 4), (4, 6),          # 역대각선
        ]
 
        for i, j in neighbor_pairs:
            a = tile_nodes[i]
            b = tile_nodes[j]
            if a.key not in node_dict or b.key not in node_dict:
                continue
            cost = _edge_cost(a, b, cld_map, my_map, passable_check_samples)
            if cost > 0:
                adjacency[a.key].append((b.key, cost))
                adjacency[b.key].append((a.key, cost))
 
    # 중복 제거
    for k in adjacency:
        adjacency[k] = list({nk: c for nk, c in adjacency[k]}.items())
 
    return adjacency
 
 
def _tile_top_left(my_map, cld_map, ix: int, iz: int) -> tuple[float, float]:
    """타일 좌상단 월드 좌표 (m)"""
    cx, cz = _tile_index_to_world(my_map, cld_map, ix, iz)
    return cx - HALF_T, cz - HALF_T
 
 
def _edge_passable(a: NavNode, b: NavNode,
                   cld_map, samples: int = 2) -> bool:
    """
    두 노드를 잇는 직선을 samples 개 점으로 샘플링해
    CloudMap 에 WALL 이 없으면 True 반환.
    """
    for t in [i / (samples - 1) for i in range(samples)]:
        mx = a.x + (b.x - a.x) * t
        mz = a.z + (b.z - a.z) * t
        val = cld_map.get_value(mx, mz)
        if val == _WALL:
            return False
    return True

def _edge_cost(a: NavNode, b: NavNode, cld_map, my_map, samples: int = 2) -> float:
    """
    늪 경유: SWAMP_COST_MULTIPLIER * 실제거리 반환
    일반: 실제거리 반환

    두 노드를 잇는 직선의 모든 픽셀을 순회하여
    _WALL 픽셀이 3개 이상이면 통과 불가
    """

    idx_a = cld_map.coords_to_index(a.x, a.z)
    idx_b = cld_map.coords_to_index(b.x, b.z)

    if idx_a is None or idx_b is None:
        return -1.0

    r0, c0 = idx_a
    r1, c1 = idx_b
    # Bresenham 직선 위 모든 픽셀 순회
    rr, cc = CloudMap._bresenham(r0, c0, r1, c1)

    wall_count = 0
    is_swamp   = False

    for r, c in zip(rr, cc):
        val = cld_map.map[r, c] if cld_map._in_bounds(r, c) else _WALL

        if val == _WALL:
            wall_count += 1
            if wall_count >= 3:          
                return -1.0
    # 늪 확인
    for t in [i / (samples - 1) for i in range(samples)]:
        mx = a.x + (b.x - a.x) * t
        mz = a.z + (b.z - a.z) * t
        cell = my_map.get_cell(mx, mz)
        if cell and cell.cell[2][2] == _SWAMPS:
            is_swamp = True
            break

    dist = math.hypot(a.x - b.x, a.z - b.z)
    return dist * (SWAMP_COST_MULTIPLIER if is_swamp else 1.0)


# A* 알고리즘
def astar(adjacency: dict[tuple, list[tuple[tuple, float]]],
          start_key: tuple,
          goal_key: tuple,
          node_positions: dict[tuple, tuple]  # key → (x, z)
          ) -> Optional[list[tuple]]:
    """
    A* 탐색.
    반환: 노드 key 의 순서 리스트, 경로 없으면 None.
    """
    def heuristic(k):
        ax, az = node_positions[k]
        gx, gz = node_positions[goal_key]
        return math.hypot(ax - gx, az - gz)
 
    open_heap: list[tuple[float, tuple]] = []
    heapq.heappush(open_heap, (0.0 + heuristic(start_key), start_key))
 
    g: dict[tuple, float] = {start_key: 0.0}
    parent: dict[tuple, Optional[tuple]] = {start_key: None}
 
    while open_heap:
        f, curr = heapq.heappop(open_heap)
 
        if curr == goal_key:
            return _reconstruct(parent, goal_key)
 
        for nk, cost in adjacency.get(curr, []):
            ng = g[curr] + cost
            if ng < g.get(nk, math.inf):
                g[nk] = ng
                parent[nk] = curr
                heapq.heappush(open_heap, (ng + heuristic(nk), nk))
 
    return None
 
 
def _reconstruct(parent: dict, goal: tuple) -> list[tuple]:
    path = []
    node = goal
    while node is not None:
        path.append(node)
        node = parent[node]
    return list(reversed(path))
 
 
# 가장 가까운 그래프 노드 탐색
def nearest_node(pos_x: float, pos_z: float,
                 node_positions: dict[tuple, tuple]) -> Optional[tuple]:
    """월드 좌표에서 가장 가까운 그래프 노드 key 반환"""
    if not node_positions:
        return None
    return min(node_positions, key=lambda k: math.hypot(
        node_positions[k][0] - pos_x, node_positions[k][1] - pos_z))
 
REVERSE_THRESHOLD = 175  # 이 각도 이상이면 후진 처리 
# 로봇 이동 제어
class WaypointFollower:
    """
    경로(waypoint)를 하나씩
    """
 
    # 튜닝 파라미터
    ARRIVE_DIST  = 0.02   # 도착 판정 반경 (m)
    ANGLE_TOL    = 6     # 각도 허용 오차 (도)
    ROTATE_SPEED = max_velocity * 0.94   # 회전 속도 (rad/s)
    MOVE_SPEED   = max_velocity    # 직진 속도 (rad/s)
    SLOW_DIST    = 0.01    # 감속 시작 거리 (m)
    STUCK_DIST_THRESHOLD = 0.030  # 이 거리 미만으로 n틱 동안 움직이면 스턱
    STUCK_TICK_LIMIT     = 50
 
    def __init__(self, wheel1, wheel2, get_angle_fn, max_vel: float = 6.28):
        self.wheel1       = wheel1
        self.wheel2       = wheel2
        self.get_angle    = get_angle_fn   # () -> float (도, 북=0 시계방향)
        self.max_vel      = max_vel
        self._path: list[tuple[float, float]] = []
        self._idx         = 0
        self._stuck_ticks = 0
        self._last_wp_idx = -1   # ← 추가: 직전 틱의 웨이포인트 인덱스
        self.on_waypoint_skip = None
 
    # 공개 인터페이스 
 
    def set_path(self, waypoints: list[tuple[float, float]]):
        """새 경로 설정. waypoints = [(x,z), ...]"""
        self._path = waypoints
        self._idx  = 0
        self._stuck_ticks = 0    
        self._last_pos    = None 
        self._last_wp_idx = -1   # ← 리셋
        self._stop()
 
    def update(self, robot_x: float, robot_z: float) -> bool:
        """
        현재 웨이포인트를 향해 이동한다.
        모든 웨이포인트 통과 시 True 반환.
        """
        if self._idx >= len(self._path):
            self._stop()
            return True
 
        tx, tz = self._path[self._idx]
        dx = tx - robot_x
        dz = tz - robot_z
        dist = math.hypot(dx, dz)
        
        # 도착 판정
        if dist < self.ARRIVE_DIST:
            self._idx += 1
            #self._stop()
            self._last_wp_idx = -1   # ← 웨이포인트 전진 시 리셋
            return self._idx >= len(self._path)
        
        if self._idx == self._last_wp_idx:
            self._stuck_ticks += 1
        else:
            # 웨이포인트가 바뀌었으면 카운터 리셋
            self._stuck_ticks = 0
            self._last_wp_idx = self._idx

        if self._stuck_ticks >= self.STUCK_TICK_LIMIT:
            print(f"[STUCK] {self.STUCK_TICK_LIMIT}틱 동안 같은 웨이포인트({self._idx}) 정체 → 스킵")
            skipped_key = self._path[self._idx]
            prev_key    = self._path[self._idx - 1] if self._idx > 0 else None

            # ← 콜백 호출: FrontierExplorer에서 간선 삭제 처리
            if self.on_waypoint_skip:
                self.on_waypoint_skip(prev_key, skipped_key)

            self._stuck_ticks = 0
            self._last_wp_idx = -1
            self._idx += 1
            return self._idx >= len(self._path)
 
        # 목표 방향 (북=0, 시계방향 증가)
        target_angle = (math.degrees(math.atan2(dx, -dz))) % 360
        curr_angle   = self.get_angle()
        angle_diff   = _angle_diff(target_angle, curr_angle)
        
        print(f"    → target=({tx:.4f},{tz:.4f}), dist={dist:.4f}, angle_diff={angle_diff:.1f}°")
        
        

        if abs(angle_diff) >= REVERSE_THRESHOLD:
            # 목표가 거의 정반대 방향 → 회전 없이 후진
            ratio = min(dist / self.SLOW_DIST, 1.0)
            spd   = max(1.5, self.MOVE_SPEED * ratio)
            self._set_vel(-spd, -spd)   # 두 바퀴 모두 역방향 = 후진
        elif abs(angle_diff) > self.ANGLE_TOL:
            # 일반 회전 우선
            spd = min(self.ROTATE_SPEED, self.max_vel)
            if angle_diff > 0:
                self._set_vel(-spd, spd)
            else:
                self._set_vel(spd, -spd)
        else:
            # 직진 (감속 포함)
            ratio  = min(dist / self.SLOW_DIST, 1.0)
            spd    = max(1.5, self.MOVE_SPEED * ratio)
            self._set_vel(spd, spd)
 
        return False
 
    def is_idle(self) -> bool:
        return self._idx >= len(self._path)
 
    # ── 내부 헬퍼 ───────────────────────────────
 
    def _set_vel(self, v1: float, v2: float):
        self.wheel1.setVelocity(v1)
        self.wheel2.setVelocity(v2)
 
    def _stop(self):
        self._set_vel(0.0, 0.0)
 
 
def _angle_diff(target: float, current: float) -> float:
    """target - current 를 [-180, 180] 범위로 정규화"""
    d = (target - current + 360) % 360
    if d > 180:
        d -= 360
    return d
 
 
# 탐색 상태 머신
class FrontierExplorer:
    """
    메인 루프 통합 클래스.
 
    사용 예 (기존 while 루프 내부):
        explorer = FrontierExplorer(My_Map, Cld_Map, wheel1, wheel2,
                                    getAngle, max_velocity)
        while robot.step(timeStep) != -1:
            gps_vals = gps.getValues()
            x, z = gps_vals[0], gps_vals[2]
            curr_cloud = ...  # 기존 라이다 처리
            explorer.step(x, z, curr_cloud)
    """
 
    # 상태
    IDLE          = "IDLE"           # 시작 또는 모든 탐색 완료
    PLANNING      = "PLANNING"       # 경로계획 중
    FOLLOWING     = "FOLLOWING"      # 경로 이동 중
    ADVANCING     = "ADVANCING"
    UPDATING_MAP  = "UPDATING_MAP"   # 도착 후 맵 업데이트
 
    def __init__(self, my_map, cld_map, wheel1, wheel2, get_angle_fn, max_vel):
        self.my_map    = my_map
        self.cld_map   = cld_map
        self.follower  = WaypointFollower(wheel1, wheel2, get_angle_fn, max_vel)
        self.state     = self.IDLE
        self._target: Optional[tuple[float, float]] = None
        self._rebuild_graph = True   # 맵 갱신 후 그래프 재빌드 플래그
        self._adjacency: dict = {}
        self._node_pos: dict  = {}
        self._failed_targets: set = set() 
        self._advance_target: tuple = None
        self._blacklist: set = set()   # 충돌한 노드 좌표
        self._start_node: tuple = None      # 시작 타일 중심 노드
        self._returning_home: bool = False  # 귀환 중 플래그
        self._home_reached: bool = False  # ← 귀환 완료 신호
        self._explored_tiles: set = set()
        self._frontier_types: dict = {}
        self._on_case2_arrival = None # fn(robot_x, robot_z) — 케이스 2 도달 콜백
        self._on_case1_advance_done = None # 2cm 전진 완료 신호
        self._stuck_ticks = 0        # ← 추가
        self._last_pos    = None 
        self.follower.on_waypoint_skip = self._on_waypoint_skip
        
 
    def step(self, robot_x: float, robot_z: float,
             curr_cloud, force_replan: bool = False):
        """
        메인 루프의 한 틱(tick)에 해당하는 처리.
 
        Parameters
        ----------
        robot_x, robot_z : 현재 GPS 좌표 (m)
        curr_cloud       : 현재 라이다 포인트 클라우드 (회전 보정 완료된 것)
        force_replan     : 외부에서 경로 재계획 강제 (예: 충돌 감지)
        """
        if force_replan:
            self.state = self.IDLE
            self._target = None

        if self.state == self.IDLE:
            self._enter_planning(robot_x, robot_z)
            # IDLE에서 PLANNING으로 바뀌면 같은 틱에 바로 _plan()도 실행
            if self.state == self.PLANNING:
                success = self._plan(robot_x, robot_z)
                if not success:
                    print("경로계획 실패")
                    self.state = self.IDLE

        elif self.state == self.PLANNING:
            success = self._plan(robot_x, robot_z)
            if not success:
                print("경로계획 실패")
                self.state = self.IDLE

        elif self.state == self.FOLLOWING:
            print(f"  [FOLLOWING] waypoint {self.follower._idx}/{len(self.follower._path)}")
            done = self.follower.update(robot_x, robot_z)
            if done:
                if self._returning_home:
                    print("🏠 시작 타일 귀환 완료!")
                    self.state = self.IDLE
                    self._returning_home = False
                    self._home_reached = True   # ← 완료 신호
                else:
                    print("✅ 프론티어 도달! 전진 시작")
                    self._frontier_pos = (robot_x, robot_z)
                    # 케이스 2 도달 시 컬러 매핑 실행
                    if self._frontier_types.get(self._target) == 2:
                        if self._on_case2_arrival:
                            self._on_case2_arrival(robot_x, robot_z)
                    self._start_advance(robot_x, robot_z)

        elif self.state == self.ADVANCING:
            done = self.follower.update(robot_x, robot_z)
            if done:
                print("✅ 전진 완료! 맵 갱신")
                # 케이스 1 도달 후 전진 완료 시 늪 체크
                self.state = self.UPDATING_MAP

        elif self.state == self.UPDATING_MAP:
            self._update_map(robot_x, robot_z, curr_cloud)
            self.state = self.IDLE  # 다음 틱에 새 프론티어 탐색
 
    # ── 내부 구현 ────────────────────────────────
    def _enter_planning(self, rx: float, rz: float):
        if self.cld_map._origin_x is None:
            return  
 
        # 1. 프론티어 탐색 전에 A* 그래프를 먼저 빌드합니다.
        if self._rebuild_graph:
            if not self._adjacency:
                # 최초 1회만 전체 빌드
                self._adjacency, self._node_pos = _build_graph_with_positions(
                    self.my_map, self.cld_map)
                self._explored_tiles = {
                    (ix, iz)
                    for ix in range(self.my_map.width)
                    for iz in range(self.my_map.height)
                    if self.my_map.grid[ix][iz].explored
                }
            else:
                # 이후는 증분 업데이트
                new_tiles = update_nav_graph_incremental(
                    self.my_map, self.cld_map,
                    self._adjacency, self._node_pos,
                    self._explored_tiles
                )
                self._explored_tiles |= new_tiles

            self._rebuild_graph = False

            # 블랙리스트 노드 제거 (기존과 동일)
            for bad_key in self._blacklist:
                if bad_key in self._adjacency:
                    for other in self._adjacency:
                        self._adjacency[other] = [
                            (nk, c) for nk, c in self._adjacency[other]
                            if nk != bad_key
                        ]
                    del self._adjacency[bad_key]
                self._node_pos.pop(bad_key, None)

        # 2. 갱신된 그래프(노드)를 기반으로 프론티어 서치
        frontier_dict = find_frontiers_by_nodes(self.my_map, self.cld_map, self._node_pos, self._adjacency)
        frontier_dict = {f: t for f, t in frontier_dict.items() if f not in self._blacklist}
        frontier_dict = {f: t for f, t in frontier_dict.items() if f not in self._failed_targets}
        frontiers = list(frontier_dict.keys())
        if not frontiers:
            print("✅ 탐색 완료. 프론티어 없음.")
            self._failed_targets.clear()

            # ── 귀환 로직 추가 ──────────────────────────
            if self._start_node and not self._returning_home:
                if not self._node_pos:
                    print("⚠️ 그래프 없음 - 귀환 불가")
                    return

                if self._start_node not in self._node_pos:
                    self._start_node = nearest_node(
                        self._start_node[0], self._start_node[1], self._node_pos)
                    print(f"⚠️ start_node 대체: {self._start_node}")

                if self._start_node is None:
                    print("⚠️ 시작 타일 귀환 불가 - 노드 없음.")
                    return

                start_key = nearest_node(rx, rz, self._node_pos)
                if start_key is None:
                    print("⚠️ 현재 위치 노드 없음 - 귀환 불가.")
                    return

                path_keys = astar(self._adjacency, start_key,
                                self._start_node, self._node_pos)
                if path_keys:
                    waypoints = [self._node_pos[k] for k in path_keys[1:]]
                    self.follower.set_path(waypoints)
                    self._returning_home = True
                    self.state = self.FOLLOWING
                    print(f"🏠 탐색 완료 → 시작 타일로 귀환: {self._start_node}")
                else:
                    print("⚠️ 시작 타일 귀환 경로 없음.")
            # ────────────────────────────────────────────
            return
 
        # 3. 목표 지점 선택 (이 _target은 이제 완벽한 A* 노드 key 입니다)
        self._frontier_types = frontier_dict     
        self._target = select_frontier(
                                        self._frontier_types, rx, rz,
                                        self.my_map, self.cld_map
                                    )
        print(f"🎯 목표 A* 노드 (프론티어): {self._target}")
        self.state = self.PLANNING
 
    def _plan(self, rx: float, rz: float) -> bool:
        """A* 경로계획. 성공 시 True."""

        print("노드 수:", len(self._node_pos))
        print("간선 수:", sum(len(v) for v in self._adjacency.values()))

        if self._target is None:
            print("목표가 없음...실패")
            return False
 
        # 시작점만 가까운 노드로 매핑하고, 목표점은 _target 노드를 그대로 씁니다.
        start_key = nearest_node(rx, rz, self._node_pos)
        goal_key  = self._target  
 
        if start_key is None or goal_key is None:
            print("시작 또는 출발 지점 없음...")
            return False
 
        path_keys = astar(self._adjacency, start_key, goal_key, self._node_pos)
        if not path_keys:
            print("⚠️  A* 경로 없음.")
            self._failed_targets.add(self._target)   # 실패 목표 기록
            self._target = None
            return False
 
        waypoints = [self._node_pos[k] for k in path_keys]
        self.follower.set_path(waypoints)
        self.state = self.FOLLOWING
        print(f"🗺️  경로 계획 완료: {len(waypoints)}개 웨이포인트")
        #debug_save_graph(self._adjacency,self._node_pos,start_key,goal_key,path_keys,)
        return True
 
    def _update_map(self, rx: float, rz: float, curr_cloud):
        """목표 도달 후 맵 갱신"""
        self.cld_map.update(rx, rz, curr_cloud)
        self.my_map.update_explored_by_cloud(self.cld_map, rx, rz)
        #self.my_map.update_cloud_wall(rx, rz, self.cld_map)
        self._rebuild_graph = True  # 다음 계획 때 그래프 재빌드
        print(f"🗺️  맵 갱신 완료 @ ({rx:.3f}, {rz:.3f})")

    def _start_advance(self, rx: float, rz: float):
        """
        프론티어 방향(미탐색 쪽)으로 2cm만큼 전진.
        _target이 현재 위치 기준 어느 방향인지 계산해서 목표 설정.
        """
        if self._target is None:
            self.state = self.UPDATING_MAP
            return
        
        if self._frontier_types.get(self._target) == 2:
            print("  [ADVANCE] 케이스 2 프론티어 — 전진 생략")
            self.state = self.UPDATING_MAP
            return

        tx, tz = self._target

        # 프론티어 → 로봇 방향 벡터를 뒤집으면 미탐색 방향
        dx = tx - rx
        dz = tz - rz
        dist = math.hypot(dx, dz)

        if dist < 0.002:
            self.state = self.UPDATING_MAP
            return

        # 정규화 후 2cm 만큼 앞으로
        nx = tx + (dx / dist) * 0.02
        nz = tz + (dz / dist) * 0.02

        val = self.cld_map.get_value(nx, nz)
        if val == _WALL:
            print("  [ADVANCE] 전진 목표가 벽 — fail")
            self._failed_targets.add(self._target)  
            self.state = self.UPDATING_MAP
            return
        
        print(f"  [ADVANCE] 전진 목표: ({nx:.4f}, {nz:.4f})")
        self.follower.set_path([(nx, nz)])
        self.state = self.ADVANCING

    def _on_waypoint_skip(self, prev_key, skipped_key):
        """
        스턱으로 인해 웨이포인트를 스킵할 때 호출.
        해당 간선을 그래프에서 양방향 삭제하고 블랙리스트에 추가.
        """
        # 스킵된 노드 블랙리스트 등록
        self._blacklist.add(skipped_key)

        # prev → skipped 간선 삭제
        if prev_key and prev_key in self._adjacency:
            self._adjacency[prev_key] = [
                (nk, c) for nk, c in self._adjacency[prev_key]
                if nk != skipped_key
            ]

        # skipped → prev 간선 삭제 (양방향)
        if skipped_key in self._adjacency:
            self._adjacency[skipped_key] = [
                (nk, c) for nk, c in self._adjacency[skipped_key]
                if nk != prev_key
            ]

        print(f"[SKIP] 간선 삭제: {prev_key} ↔ {skipped_key}")

        # 재탐색
        self.state = explorer.IDLE
        self._target = None
        self._rebuild_graph = True
 
 
def _build_graph_with_positions(my_map, cld_map):
    """
    adjacency 와 node_positions 를 동시에 반환하는 헬퍼.
    node_positions: {key: (x, z)}
    """
    adjacency = build_nav_graph(my_map, cld_map)
    node_positions = {k: k for k in adjacency}  # key 자체가 (x, z) 튜플
    return adjacency, node_positions

def update_nav_graph_incremental(my_map, cld_map,
                                  adjacency, node_pos,
                                  known_tiles: set,
                                  passable_check_samples: int = 2) -> set:
    """새로 explored된 타일만 그래프에 증분 반영. 반환: 새 타일 집합"""
    current_tiles = {
        (ix, iz)
        for ix in range(my_map.width)
        for iz in range(my_map.height)
        if my_map.grid[ix][iz].explored
    }
    new_tiles = current_tiles - known_tiles
    if not new_tiles:
        return set()

    # 새 타일 노드 생성
    for ix, iz in new_tiles:
        tile_ox, tile_oz = _tile_top_left(my_map, cld_map, ix, iz)
        for node_idx, (dr, dc) in enumerate(_TILE_OFFSETS):
            refs = _NODE_CELL_REFS[node_idx]
            is_wall = any(
                my_map._in_bounds(ix+dix, iz+diz)
                and my_map.grid[ix+dix][iz+diz].explored
                and my_map.grid[ix+dix][iz+diz].cell[r][c] == _WALL
                for dix, diz, r, c in refs
            )
            if is_wall:
                continue
            node = NavNode(tile_ox + dc, tile_oz + dr)
            if cld_map.get_value(node.x, node.z) != _WALL:
                if node.key not in adjacency:
                    adjacency[node.key] = []
                    node_pos[node.key] = node.key

    # 새 타일 + 인접 기존 타일 경계 간선 갱신
    tiles_to_process = new_tiles.copy()
    for ix, iz in new_tiles:
        for dix, diz in [(-1,0),(1,0),(0,-1),(0,1)]:
            if (ix+dix, iz+diz) in known_tiles:
                tiles_to_process.add((ix+dix, iz+diz))

    neighbor_pairs = [
        (0,1),(1,2),(3,4),(4,5),(6,7),(7,8),
        (0,3),(3,6),(1,4),(4,7),(2,5),(5,8),
        (0,4),(4,8),(2,4),(4,6),
    ]
    for ix, iz in tiles_to_process:
        tile_ox, tile_oz = _tile_top_left(my_map, cld_map, ix, iz)
        tile_nodes = [NavNode(tile_ox+dc, tile_oz+dr) for dr, dc in _TILE_OFFSETS]
        for i, j in neighbor_pairs:
            a, b = tile_nodes[i], tile_nodes[j]
            if a.key not in adjacency or b.key not in adjacency:
                continue
            # 기존 간선 제거 후 재계산
            adjacency[a.key] = [(nk,c) for nk,c in adjacency[a.key] if nk != b.key]
            adjacency[b.key] = [(nk,c) for nk,c in adjacency[b.key] if nk != a.key]
            cost = _edge_cost(a, b, cld_map, my_map, passable_check_samples)
            if cost > 0:
                adjacency[a.key].append((b.key, cost))
                adjacency[b.key].append((a.key, cost))

    # 중복 제거
    for ix, iz in tiles_to_process:
        tile_ox, tile_oz = _tile_top_left(my_map, cld_map, ix, iz)
        for dr, dc in _TILE_OFFSETS:
            nk = (round(tile_ox+dc, 4), round(tile_oz+dr, 4))
            if nk in adjacency:
                adjacency[nk] = list({mk: c for mk, c in adjacency[nk]}.items())

    return new_tiles
 
def remove_wall_nodes(explorer, my_map, cld_map):
    """
    현재 생성된 노드들 중 GridMap에서 벽(_WALL)으로 판정된 위치의 노드를 삭제합니다.
    """
    if not explorer._node_pos:
        return

    # _TILE_OFFSETS 인덱스 → Cell[r][c] 매핑 (build_nav_graph와 동일)
    OFFSET_TO_CELL_RC = [
        (0, 0), (0, 2), (0, 4),
        (2, 0), (2, 2), (2, 4),
        (4, 0), (4, 2), (4, 4),
    ]
    BORDER_CELL_RC = {(0,0),(0,2),(0,4),(2,0),(2,4),(4,0),(4,2),(4,4)}

    nodes_to_remove = set()

    # 1. 벽 위치 노드 식별
    for node_key in explorer._node_pos:
        nx, nz = node_key

        # 노드 GPS 좌표 → GridMap 셀 인덱스
        result = my_map.get_cell_index(nx, nz)
        if result is None:
            continue
        ix, iz = result
        cell = my_map.grid[ix][iz]

        # 타일 좌상단 기준으로 이 노드가 몇 번째 OFFSET인지 찾기
        tile_ox, tile_oz = _tile_top_left(my_map, cld_map, ix, iz)

        for idx, (dr, dc) in enumerate(_TILE_OFFSETS):
            expected_x = round(tile_ox + dc, 4)
            expected_z = round(tile_oz + dr, 4)
            if abs(expected_x - nx) < 1e-5 and abs(expected_z - nz) < 1e-5:
                r, c = OFFSET_TO_CELL_RC[idx]
                # 테두리 노드이고 벽이면 제거 대상
                if (r, c) in BORDER_CELL_RC and cell.cell[r][c] == _WALL:
                    nodes_to_remove.add(node_key)
                break

    # 2. 노드 및 관련 간선 삭제
    for node_key in nodes_to_remove:
        # 이 노드로 들어오는 간선 제거 (list이므로 필터링)
        for other_key in explorer._adjacency:
            if other_key == node_key:
                continue
            explorer._adjacency[other_key] = [
                (nk, cost) for nk, cost in explorer._adjacency[other_key]
                if nk != node_key
            ]
        # 이 노드의 간선 목록 제거
        if node_key in explorer._adjacency:
            del explorer._adjacency[node_key]
        # 노드 위치 정보 제거
        if node_key in explorer._node_pos:
            del explorer._node_pos[node_key]

    if nodes_to_remove:
        print(f"[Graph Update] 벽 노드 {len(nodes_to_remove)}개 제거 완료.")

def debug_save_graph(adjacency, node_positions,
                    start_key=None,
                    goal_key=None,
                    path_keys=None,
                    save_dir="debug_graph",
                    filename=None):

    #if filename:
        #save_path = os.path.join(DEBUG_SAVE_DIR, filename + ".png")  # ← 이미 선언된 DEBUG_SAVE_DIR 사용
    #else:
        #save_path = os.path.join(DEBUG_SAVE_DIR, "Node_Graph.png")

    if filename:
        save_path = "C:/Users/nhyee/OneDrive/바탕 화면/ROBOT/2526RS/map_img/" + filename + ".png"
    else:
        save_path = "C:/Users/nhyee/OneDrive/바탕 화면/ROBOT/2526RS/map_img/Node_Graph_.png"

    plt.figure(figsize=(6, 6))

    # 간선
    for k, neighbors in adjacency.items():
        x1, z1 = node_positions[k]
        for nk, _ in neighbors:
            x2, z2 = node_positions[nk]
            plt.plot([x1, x2], [z1, z2], color='gray', linewidth=0.5)

    # 노드 
    xs = [node_positions[k][0] for k in node_positions]
    zs = [node_positions[k][1] for k in node_positions]
    plt.scatter(xs, zs, s=5, c='blue')

    # 시작점 
    if start_key is not None and start_key in node_positions:
        x, z = node_positions[start_key]
        plt.scatter(x, z, s=60, color='green', marker='o')
        plt.text(x, z, "  START", verticalalignment='bottom')

    # 목표점
    if goal_key is not None and goal_key in node_positions:
        x, z = node_positions[goal_key]
        plt.scatter(x, z, s=60, color='red', marker='x')
        plt.text(x, z, "  GOAL", verticalalignment='bottom')

    # 경로 
    if path_keys:
        path_x = [node_positions[k][0] for k in path_keys if k in node_positions]
        path_z = [node_positions[k][1] for k in path_keys if k in node_positions]
        if len(path_x) > 1:
            plt.plot(path_x, path_z, color='red', linewidth=2)

    # 마무리 
    plt.gca().set_aspect('equal')
    
    # --- 수정된 부분: 아래방향이 z+가 되도록 Y축(z좌표)을 뒤집음 ---
    plt.gca().invert_yaxis() 
    # -------------------------------------------------------

    plt.title("A* Graph Debug View (Z+ is Down, X+ is Right)")
    plt.grid(True)

    plt.savefig(save_path, dpi=150)
    plt.close()

    print(f"그래프 저장됨: {save_path}")

_last_marked_tile = {}  # sensor_key → (ix, iz)

def try_mark_cell(my_map, cs_x, cs_z, mark_fn, sensor_key: str) -> bool:
    """셀이 바뀔 때만 mark_fn 실행 - 중복 마킹 방지"""
    result = my_map.get_cell_index(cs_x, cs_z)
    if result is None:
        return False
    ix, iz = result

    if _last_marked_tile.get(sensor_key) == (ix, iz):
        return False  # 같은 셀이면 스킵

    _last_marked_tile[sensor_key] = (ix, iz)
    mark_fn(my_map.grid[ix][iz])
    return True

def update_zone(r, g, b, my_map, x, z):
    """컬러 타일 감지 시 curr_zone 업데이트 + Cell에 색상 마킹 (중복 방지)"""
    global curr_zone

    tilecolor = get_tile_color(r, g, b)
    if tilecolor is None:
        return

    # 셀이 바뀔 때만 실행
    result = my_map.get_cell_index(x, z)
    if result is None:
        return
    ix, iz = result

    if _last_marked_tile.get('zone') == (ix, iz):
        return  # 같은 셀 → 스킵

    _last_marked_tile['zone'] = (ix, iz)

    # 존 전환
    zones = _COLOR_TO_ZONE.get(tilecolor)
    if zones and curr_zone in zones:
        curr_zone = zones[1] if curr_zone == zones[0] else zones[0]
        print(f"[ZONE] 존 전환: {tilecolor} → Zone {curr_zone}")

    # Cell 마킹
    cell = my_map.grid[ix][iz]
    cell.cell[1][1] = tilecolor
    cell.cell[1][3] = tilecolor
    cell.cell[3][1] = tilecolor
    cell.cell[3][3] = tilecolor

def handle_hole(r, g, b, my_map, cld_map, x, z, explorer):
    """
    구멍 감지 시: 후진 + 전방 Cell에 HOLES 마킹 + 그래프 재계획
    반환: True = 구멍 감지됨
    """
    if not (r < 60 and g < 60 and b < 60):
        return False

    print("[HOLE] 구멍 감지! 후진 중...")
    wheel1.setVelocity(-max_velocity * 0.5)
    wheel2.setVelocity(-max_velocity * 0.5)

    # 현재 각도 기반 전방 방향 계산
    #curr_angle = getAngle()
    #angle_rad = math.radians(curr_angle)

    # 전방 셀 GPS 좌표 (TILE_M 만큼 앞)
    #front_x = x + math.sin(angle_rad) * TILE_M
    #front_z = z - math.cos(angle_rad) * TILE_M

    # 전방 셀 마킹
    front_cell = my_map.get_cell(x, z)
    if front_cell:
        front_cell.cell[2][2] = _HOLES
        front_cell.cell[1][1] = _HOLES
        front_cell.cell[1][3] = _HOLES
        front_cell.cell[3][1] = _HOLES
        front_cell.cell[3][3] = _HOLES
        front_cell.explored = True
        #front_cell.visited = True
        print(f"[HOLE] 전방 셀 마킹 완료 @ ({x:.3f}, {z:.3f}), angle={curr_angle:.1f}°")
    else:
        print(f"[HOLE] 전방 셀 범위 밖 @ ({x:.3f}, {z:.3f})")

    # 전방 셀 근처 노드 블랙리스트 + 그래프 제거
    hole_nodes = [
        k for k, pos in explorer._node_pos.items()
        if math.hypot(pos[0] - x, pos[1] - z) < CELL_SIZE * 2  # 0.02m로 대폭 축소
    ]
    for nk in hole_nodes:
        explorer._blacklist.add(nk)
        if nk in explorer._adjacency:
            for other in list(explorer._adjacency.keys()):
                explorer._adjacency[other] = [
                    (mk, c) for mk, c in explorer._adjacency[other] if mk != nk
                ]
            del explorer._adjacency[nk]
        explorer._node_pos.pop(nk, None)
    #debug_save_graph(explorer._adjacency,explorer._node_pos,save_dir=DEBUG_SAVE_DIR,filename=f"graph_after_hole_{int(x*100)}_{int(z*100)}")

    # 재계획
    explorer.state = explorer.IDLE
    explorer._target = None
    explorer._rebuild_graph = True
    return True

def update_start_tile(my_map, x, z):
    """시작타일매핑"""
    ix, iz = my_map.get_cell_index(x, z)

    # Cell 마킹
    cell = my_map.grid[ix][iz]
    cell.cell[1][1] = _STARTINGTILE
    cell.cell[1][3] = _STARTINGTILE
    cell.cell[3][1] = _STARTINGTILE
    cell.cell[3][3] = _STARTINGTILE
    cell.explored = True
    cell.visited = True

    # 시작 타일 중심 노드 좌표 저장 (중앙 = HALF_T 오프셋)
    # 메인루프에서 explorer에 전달
    tile_cx, tile_cz = _tile_index_to_world(my_map, Cld_Map, ix, iz)
    explorer._start_node = (round(tile_cx, 4), round(tile_cz, 4))
    print(f"🏠 시작 타일 노드 저장: {explorer._start_node}")



Cld_Map = CloudMap(n=10, m=10)
My_Map = GridMap(n=10, m=10)
 
explorer = FrontierExplorer(
    my_map      = My_Map,
    cld_map     = Cld_Map,
    wheel1      = wheel1,
    wheel2      = wheel2,
    get_angle_fn= getAngle,
    max_vel     = max_velocity,
)

def _do_color_mapping(rx, rz):
    cs_x, cs_z = get_color_sensor_pos(rx, rz)
    colour = colour_sensor.getImage()
    r = colour_sensor.imageGetRed(colour, 1, 0, 0)
    g = colour_sensor.imageGetGreen(colour, 1, 0, 0)
    b = colour_sensor.imageGetBlue(colour, 1, 0, 0)

    tile_type = detect_tile_type(r, g, b)
    if tile_type ==_HOLES:
        return
    
    if tile_type == _SWAMPS:
        def _mark_swamp(cell):
            if cell and cell.cell[1][1] != _SWAMPS:
                cell.cell[1][1] = _SWAMPS
                cell.cell[1][3] = _SWAMPS
                cell.cell[3][1] = _SWAMPS
                cell.cell[3][3] = _SWAMPS
                cell.visited = True
                explorer._rebuild_graph = True
                print(f"[SWAMP] 늪 감지 @ ({rx:.3f}, {rz:.3f})")
        try_mark_cell(My_Map, cs_x, cs_z, _mark_swamp, 'swamp')

    # 체크포인트 매핑
    if is_checkpoint(r, g, b):
        def _mark_checkpoint(cell):
            if cell and cell.cell[2][2] != _CHECKPOINT:
                cell.cell[1][1] = _CHECKPOINT
                cell.cell[1][3] = _CHECKPOINT
                cell.cell[3][1] = _CHECKPOINT
                cell.cell[3][3] = _CHECKPOINT
                print(f"[CHECKPOINT] 체크포인트 마킹 @ ({rx:.3f}, {rz:.3f})")
        try_mark_cell(My_Map, cs_x, cs_z, _mark_checkpoint, 'checkpoint')
        return  # 체크포인트면 존 전환 체크 안 함

    # 컬러 타일 존 전환
    update_zone(r, g, b, My_Map, cs_x, cs_z)

explorer._on_case2_arrival = _do_color_mapping

 
 
prev_coords = [None, None]
img_cnt=0

prev_explored_count = 0  
start_map = True

emergency_back = False

curr_zone = 1

_last_obstacle_target = None   
obstacle_count = 0             

start = robot.getTime()  # main loop 

# ══════════════════════════════════════════════════════════════════════════
#  메인 루프
# ══════════════════════════════════════════════════════════════════════════
while robot.step(timeStep) != -1:

    # ── 센서 읽기 ─────────────────────────────────────────────────────────
    dist1 = s1.getValue()
    dist2 = s2.getValue()
    dist3 = s3.getValue()
    dist4 = s4.getValue()
    dist5 = s5.getValue()

    _gui_send('sensors', {'s4':dist4,'s5':dist5})
    print(f"s4:{dist4:.3f} s2:{dist2:.3f} s1:{dist1:.3f} s3:{dist3:.3f} s5:{dist5:.3f}")

    angle = inertial_unit.getRollPitchYaw()[2]
    curr_angle = getAngle()

    curr_cloud = lidar.range_image[512 * _LIDAR_LAYER:512 * (_LIDAR_LAYER + 1):]
    curr_cloud = rotate_LidarValue(curr_cloud, curr_angle)
    curr_cloud = rotate_LidarValue(curr_cloud, 180)

    # ── 색상 센서 ─────────────────────────────────────────────────────────
    colour      = colour_sensor.getImage()
    r = colour_sensor.imageGetRed(colour,   1, 0, 0)
    g = colour_sensor.imageGetGreen(colour, 1, 0, 0)
    b = colour_sensor.imageGetBlue(colour,  1, 0, 0)

    # ── GPS + 맵 업데이트 ─────────────────────────────────────────────────
    gps_vals = gps.getValues()
    x, z = gps_vals[0], gps_vals[2]
    print(f"coords x:{x:.4f}, z:{z:.4f}  angle:{curr_angle:.1f}°")

    cs_x, cs_z = get_color_sensor_pos(x, z)


    if handle_hole(r, g, b, My_Map, Cld_Map, cs_x, cs_z, explorer):
        delay(1)
        continue   # 구멍이면 이번 틱 나머지 스킵
    
    tile_type = detect_tile_type(r, g, b)    

    curr_cloud = lidar.range_image[512 * _LIDAR_LAYER:512 * (_LIDAR_LAYER + 1):]
    curr_cloud = rotate_LidarValue(curr_cloud, curr_angle)
    curr_cloud = rotate_LidarValue(curr_cloud, 180)

    # 현재 셀 인덱스 조회
    idx = Cld_Map.coords_to_index(x, z)
    #My_Map.display()
    #My_Map.update_explored_by_cloud(Cld_Map)

    #Map Update...
    if idx:
        curr_coords = idx
        curr_state = Cld_Map.get_value(x, z)
        curr_cell = My_Map.get_cell(x,z)
        
        if (prev_coords[0] == None or abs(curr_coords[0]-prev_coords[0]) + abs(curr_coords[1]-prev_coords[1]) >= 1 ) and start_map:
            prev_coords = curr_coords
            if start_map:
                wheel1.setVelocity(-1)
                wheel2.setVelocity(-1)
                update_start_tile(My_Map, x, z)
                Cld_Map.update(x,z, curr_cloud)
                #My_Map.update_cloud_wall(x,z, Cld_Map)
                My_Map.update_explored_by_cloud(Cld_Map, x,z)
                explorer._rebuild_graph = True 
                start_map = False
                delay(5)
            
            #remove_wall_nodes(explorer, My_Map, Cld_Map)
        explored_count = sum(1 for ix in range(My_Map.width) 
                       for iz in range(My_Map.height) 
                       if My_Map.grid[ix][iz].explored)

        if explored_count != prev_explored_count:
            #Cld_Map.update(x, z, curr_cloud)
            save_folder = "C:/Users/nhyee/OneDrive/바탕 화면/ROBOT/2526RS/map_img"
            file_name = f"CloudMap_.png"
            full_path = f"{save_folder}/{file_name}"
            #Cld_Map.visualize(save_path=full_path)
            #My_Map.update_cloud_wall(x,z, Cld_Map)
            #My_Map.update_explored_by_cloud(Cld_Map)
            My_Map.display()
            #explorer._rebuild_graph = True
            prev_explored_count = explored_count

            print(f"origin=({Cld_Map._origin_x:.4f}, {Cld_Map._origin_z:.4f}), robot=({x:.4f}, {z:.4f})")
            
            
        print(f"Robot at map ({curr_coords}), Before ({prev_coords})")
        print(f"angle: {curr_angle}")
        # visited 판정
    result = My_Map.get_cell_index(x, z)
    if result:
        ix, iz = result
        cell = My_Map.grid[ix][iz]
        if (cell.explored and not cell.visited):
            tile_cx, tile_cz = _tile_index_to_world(My_Map, Cld_Map, ix, iz)
            if math.hypot(x - tile_cx, z - tile_cz) < VISITED_THRESHOLD:
                cell.visited = True


    # 회피
    force_replan = False

    # 메인 루프 장애물 회피
    print(f"dist1: {dist1}, dist2: {dist2}, dist3: {dist3}")

    if dist1 <= 0.012:
        # 1. 후진하면서 회전 (제자리 안 박히게)
        if dist4 < dist5:   # 왼쪽이 더 막힘 → 오른쪽으로 회피
            wheel1.setVelocity(-max_velocity * 0.8)
            wheel2.setVelocity(-max_velocity * 0.4)
        else:               # 오른쪽이 더 막힘 → 왼쪽으로 회피
            wheel1.setVelocity(-max_velocity * 0.4)
            wheel2.setVelocity(-max_velocity * 0.8)
        emergency_back = True
    elif dist2 <= 0.014:
        wheel1.setVelocity(-max_velocity * 0.4)
        wheel2.setVelocity(-max_velocity * 0.8)
        emergency_back = True
    elif dist3 <= 0.014:
        wheel1.setVelocity(-max_velocity * 0.8)
        wheel2.setVelocity(-max_velocity * 0.4)
        emergency_back = True
        
    if emergency_back:
        #curr_cell = My_Map.get_cell_index(x, z)
        curr_target = explorer._target

        if curr_target != _last_obstacle_target:
        #or curr_cell != _last_obstacle_cell:
            obstacle_count = 0
            #_last_obstacle_cell = curr_cell
            _last_obstacle_target = curr_target

        obstacle_count += 1
        print(f"장애물 인식 횟수: {obstacle_count}")
        delay(1)

        
        if (obstacle_count >= 3):

            # 3회 이상: 노드 삭제 + 블랙리스트
            if (explorer.state == explorer.FOLLOWING and
            explorer.follower._idx < len(explorer.follower._path)):

                bad_wp = explorer.follower._path[explorer.follower._idx]
                explorer._blacklist.add(bad_wp)

                # 그래프에서 즉시 제거
                if bad_wp in explorer._adjacency:
                    for other_key in explorer._adjacency:
                        explorer._adjacency[other_key] = [
                            (nk, c) for nk, c in explorer._adjacency[other_key]
                            if nk != bad_wp
                        ]
                    del explorer._adjacency[bad_wp]
                if bad_wp in explorer._node_pos:
                    del explorer._node_pos[bad_wp]
                print(f"블랙리스트 추가: {bad_wp}")

            # 맵 갱신 + 재계획
            Cld_Map.update(x, z, curr_cloud)
            My_Map.update_explored_by_cloud(Cld_Map, x, z)
            #My_Map.update_cloud_wall(x, z, Cld_Map)
            explorer._rebuild_graph = True
            explorer.state = explorer.IDLE
            explorer._target = None
            print("장애물 회피 - 재계획")
        emergency_back = False
        
    check_and_align_for_victim()

    # 프론티어 탐색 + A* + 이동
    explorer.step(x, z, curr_cloud, force_replan=force_replan)

    if explorer._home_reached:
        exit_mes = struct.pack('c', b'E')
        emitter.send(exit_mes)
        wheel1.setVelocity(0)
        wheel2.setVelocity(0)
        My_Map.display()
        #save_folder = "C://Users//naeun//OneDrive//Desktop//ROBOT//2026 Robocup in INCHEON//Debug"
        #file_name = f"CloudMap_0611.png"
        #full_path = f"{save_folder}/{file_name}"
        #Cld_Map.visualize(save_path=full_path)
        #debug_save_graph(explorer._adjacency, explorer._node_pos, filename ="NodeGraph_0611")
        delay(10)
        break   

    delay(1)
