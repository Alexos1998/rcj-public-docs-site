#include <lccv.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/dnn.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/core/ocl.hpp>
#include <iostream>
#include <fstream>
#include <cmath>
#include <string.h>
#include <thread>
#include <termios.h>
#include <fcntl.h>
#include <sys/signal.h>
#include <sstream>

#define harmed 2
#define stable 1
#define unharmed 0

using namespace cv;
using namespace std::chrono_literals;
using namespace std;

#define BAUDRATE B115200
#define MODEMDEVICE "/dev/ttyAMA0"

int uart0_filestream = -1; 

const float SCORE_THRESHOLD = 0.35;
const float NMS_THRESHOLD = 0.35;


cv::Size2f imageShape(cv::Size(320,320));

std::vector<std::string> class_list{"omega", "phi", "psi"};

bool is_cuda = false;

int getColorValue(Vec3b hsv) {
	int h = hsv[0];
	int s = hsv[1];
	int v = hsv[2];
	
	
	if (v < 75) return -2; // Black
	if (s < 35) return 100; // White
	if (h > 15 && h < 45) return 0; // Yellow
	if (h > 55 && h < 85 && s > 150) return 1; // Green
	if (h > 60 && h < 115) return 2; // Blue
	if (h < 15 || h > 130) return -1; // Red  
	else return -100;
	}



std::string camTitle(int num){
    std::string title("Video");
    title += std::to_string(num);
    return title;
}





int bullseye(Mat frame){
	
		// Making frame matrixes; the raw frame, grayscale (for binary thresholding), binary, and one for isolating each color
		Mat gray;
		Mat binary;
	
		resize(frame, frame, Size(frame.cols/4,frame.rows/4));

		
		cvtColor(frame,gray,COLOR_BGR2GRAY); // Put a grayscale version in 'gray' so that it can be used for binary thresholding
		cvtColor(frame, frame, COLOR_BGR2HSV); // Make the original frame HSV for color isolation
		
		threshold(gray,binary,150,255,THRESH_BINARY_INV); // Do the binary thresholding
		// Creating and filling contour vector for binary (to get the whole bullseye's radius)
		vector<vector<Point>> binary_contours;
		findContours(binary, binary_contours, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
		
		
		if (binary_contours.size() <= 0) return -100;
		
		// Finding largest contour (bullseye)
		double MaxArea = 0;
		int largestIdx = 0;
		for (size_t i = 0; i < binary_contours.size(); i++)
		{
			double area = contourArea(binary_contours[i]);
			if (area > 35000 || area < 750) continue;
			if (area > MaxArea) {
				MaxArea = area;
				largestIdx = i;
			}
				
		}
		
		
		if (contourArea(binary_contours[largestIdx]) <= 2000) return -100;

		// Get bullseye radius
		Point2f bullseye_center;
		float bullseye_radius = 0;
		minEnclosingCircle(binary_contours[largestIdx], bullseye_center, bullseye_radius);
		
		// draw circle
		int thickness = 2;
		Scalar color(255,0,0);
		circle(frame,bullseye_center,bullseye_radius,color,thickness);
		
		 // show images
		imshow("HSV", frame);
		//imshow("Binary", binary);
		
		// create color vector variables
		Vec3b ring1, ring2, ring3, ring4, ring5;
		int victim_total = 0;
		cout << "OUT OF BOUNDS" << (int)(bullseye_center.x + (4*(bullseye_radius/5)) + 2) << endl;
	
		// ring 1
		if((int)(bullseye_center.x + (0*(bullseye_radius/5)) + 2) > (frame.cols/4)) {
			victim_total += 100;
			 ring1[0] = 0;
			 ring1[1] = 0;
			 ring1[2] = 0;
		}
		else {
		 ring1 = frame.at<Vec3b>((int)bullseye_center.y, (int)(bullseye_center.x + (0*(bullseye_radius/5)) + 1)); }
		
		// ring 2
		 if((int)(bullseye_center.x + (1*(bullseye_radius/5)) + 2) > (frame.cols/4)) {
			victim_total += 100;
			 ring2[0] = 0;
			 ring2[1] = 0;
			 ring2[2] = 0;
		}
		else {
		 ring2 = frame.at<Vec3b>((int)bullseye_center.y, (int)(bullseye_center.x + (1*(bullseye_radius/5)) + 1)); }
		 
		 // ring 3
		 if((int)(bullseye_center.x + (2*(bullseye_radius/5)) + 2) > (frame.cols/4)) {
			victim_total += 100;
			 ring3[0] = 0;
			 ring3[1] = 0;
			 ring3[2] = 0;
		}
		else {
		 ring3 = frame.at<Vec3b>((int)bullseye_center.y, (int)(bullseye_center.x + (2*(bullseye_radius/5)) + 1)); }
		 
		 // ring 4
		 if((int)(bullseye_center.x + (3*(bullseye_radius/5)) + 2) > (frame.cols/4)) {
			victim_total += 100;
			 ring4[0] = 0;
			 ring4[1] = 0;
			 ring4[2] = 0;
		}
		else {
		 ring4 = frame.at<Vec3b>((int)bullseye_center.y, (int)(bullseye_center.x + (3*(bullseye_radius/5)) + 1)); }
		 
		 // ring 5
		 if((int)(bullseye_center.x + (4*(bullseye_radius/5)) + 2) > (frame.cols/4)) {
			victim_total += 100;
			 ring5[0] = 0;
			 ring5[1] = 0;
			 ring5[2] = 0;
		}
		else {
		 ring5 = frame.at<Vec3b>((int)bullseye_center.y, (int)(bullseye_center.x + (4*(bullseye_radius/5)) + 1)); }
		 
		 
		
		
		cout << (int)(bullseye_center.x + (0*(bullseye_radius/5)) + 2) << (int)(bullseye_center.x + (1*(bullseye_radius/5)) + 2) << (int)(bullseye_center.x + (2*(bullseye_radius/5)) + 2) << (int)(bullseye_center.x + (3*(bullseye_radius/5)) + 2) <<  (int)(bullseye_center.x + (4*(bullseye_radius/5)) + 2) << endl;
		
		
		
		

		
		
			
		victim_total += getColorValue(ring1);
		victim_total += getColorValue(ring2);
		victim_total += getColorValue(ring3);
		victim_total += getColorValue(ring4);
		victim_total += getColorValue(ring5);
		
			
		
		cout << "VALUE: " << victim_total << endl;
		
		return victim_total;
}



int greek(Mat img){
	
	cv::dnn::Net net = cv::dnn::readNet("/home/pi/Showrya/MazeV6.onnx"); // CHANGE THIS TO THE FILE PATH!!!
	
	net.setPreferableBackend(cv::dnn::DNN_BACKEND_OPENCV);
	net.setPreferableTarget(cv::dnn::DNN_TARGET_CPU);
	
		//resize(img, img, Size(640,480));
		resize(img, img, Size(640,480));

		Mat cimg = img.clone();
		Mat blob;
		

		// does necessary scaling and stuff for NN usage
		dnn::blobFromImage(img, blob, 1.0/255, imageShape, Scalar(), true, false);
		net.setInput(blob);
		vector<Mat> outputs;
		net.forward(outputs, net.getUnconnectedOutLayersNames());
		
		
		// some info about the output
		int rows = outputs[0].size[1];
		int dimensions = outputs[0].size[2];
		
		// swap for yolov8 
		rows = outputs[0].size[2];
		dimensions = outputs[0].size[1];
		
		// changing around dimensions (it changed for no reason in yolov8 so we need to switch it back)
		outputs[0] = outputs[0].reshape(1, dimensions);
		cv::transpose(outputs[0], outputs[0]);
		
		float *data = (float *)outputs[0].data;
		
		vector<int> class_ids;
		vector<float> confidences;
		vector<Rect> boxes;
		
		
		// loop through all the rows in the results
		for(int i = 0; i < rows; i++){
			float *classes_scores = data+4;
			
			
			
			Mat scores(1, class_list.size(), CV_32FC1, classes_scores);
			Point class_id;
			double maxClassScore;
			
			
			minMaxLoc(scores, 0, &maxClassScore, 0, &class_id);
			
			
			
			if(maxClassScore > 0.65){ // Confidence score; increase if its finding too much, decrease if not finding any
				printf("i = %d\tscore: %.2f\n", i, maxClassScore);
				
				confidences.push_back(maxClassScore);
				class_ids.push_back(class_id.x);
				
				printf("class id: %d\n", class_id.x);
				
				float x = data[0];
				float y = data[1];
				float w = data[2];
				float h = data[3];
				
				printf("x,y => %.2f, %.2f\n", x, y);
				
				int left = x * img.cols - w * img.cols / 2;
				int top = y * img.rows - h * img.rows / 2;
				
				int width = int(w * img.cols);
				int height = int(h * img.rows);
				
				boxes.push_back(Rect(left, top, width, height));
			}
			
			
			data += dimensions;
		}
		
		// printf("does it make it this far????? - Jeremy");
		
		// all done, time to draw
		vector<int> nms_result;
		dnn::NMSBoxes(boxes, confidences, SCORE_THRESHOLD, NMS_THRESHOLD, nms_result);
		
		
		int idx;
		for(unsigned long i = 0; i < nms_result.size(); i++){
			idx = nms_result[i];
			rectangle(img, boxes[idx], Scalar(0,255,0), 1);
			putText(img, to_string( int(confidences[idx] * 100)) + "% " + class_list[class_ids[idx]], Point(boxes[idx].x, boxes[idx].y), 1, 3, Scalar(0,255,0), 2);
			imshow("GREEK", img);
		}



		/*
		 * HELLO!
		 * Put the center check thing in all of the cases below and also put it in the visualization loop so that it doesn't display
		 * The code i'm talking about - it's the getcolorvalue thing below 
		 * 
		 * 
		 * */
		// return (finally)
		if(nms_result.size() > 0){
			if (class_ids[idx] == 0) return unharmed;
			else if (class_ids[idx] == 1) return stable;
			else if (class_ids[idx] == 2) return harmed;
			else return -1;
			
		}
		else{
			return -1;
		}
	
	}
	
	

int main(){
	
/*	Mat green(240, 320, CV_8UC3, Scalar(0, 255, 0));
	
	imshow("good", green);
	waitKey(0);
	

	

	return 0;*/
	
	
	// connect to arduino device 
	uart0_filestream = open(MODEMDEVICE, O_RDWR | O_NOCTTY | O_NDELAY);
	
	if (uart0_filestream == -1)
	{
		// Error - Can't open serial port
		printf("Error: Unable to open UART\nEnsure it is not in use by another application");
		exit(-1);
	}

	struct termios options; // config stuff
	tcgetattr(uart0_filestream, &options);
	options.c_cflag = BAUDRATE | CS8 | CLOCAL | CREAD; // creed?
	options.c_iflag = IGNPAR;
	options.c_oflag = 0;
	options.c_lflag = 0;
	tcflush(uart0_filestream, TCIFLUSH);
	tcsetattr(uart0_filestream, TCSANOW, &options);

	// Camera setup
	lccv::PiCamera cameras[2];
	int index = 0;
    for (auto& cam : cameras){
        cam.options->camera = index++;
        cam.options->video_width=1920;//640;
        cam.options->video_height=1080;//480;
        cam.options->framerate=60;
        cam.options->verbose=false;
        cam.startVideo();
        auto title = camTitle(cam.options->camera);
        std::cout << title << " Started:"<< std::endl;
        cv::namedWindow(title,cv::WINDOW_NORMAL);
    }
    
    Mat img;
    unsigned char rx_buffer[256];
    int rx_length = 0;
    char tx_buffer[100];
    
    while(1) {
	
	
	do {
		rx_length = read(uart0_filestream, (void*)rx_buffer, 255);
		this_thread::sleep_for(30ms);
		
	} while(rx_length <= 0); 
	
		
		// new ppi 5 version
		int counter = 0;
		Mat imgs[2];
		for (auto& cam : cameras){ 
            auto title = camTitle(cam.options->camera);
            if(!cam.getVideoFrame(imgs[counter],99999999)){
                std::cout<<"Timeout error " << title << "\t" <<counter <<std::endl;
            }
           counter++;            

		}
		

		flip(imgs[0], imgs[0], 0);
		flip(imgs[1], imgs[1], 0);

		
		
		Mat bullseye_image_one = imgs[0].clone();
		Mat greek_image_one = imgs[0].clone();
		
		Mat bullseye_image_two = imgs[1].clone();
		Mat greek_image_two = imgs[1].clone();
		
		int bull_one = bullseye(bullseye_image_one);
		printf("BULLSEYE ID LEFT: %d\n", bull_one);
		
		int letter_one = greek(greek_image_one);
		printf("GREEK ID LEFT: %d\n", letter_one);
		
		int bull_two = bullseye(bullseye_image_two);
		printf("BULLSEYE ID RIGHT: %d\n", bull_two);
		
		int letter_two = greek(greek_image_two);
		printf("GREEK ID RIGHT: %d\n", letter_two);
		
		imshow("LCAM", imgs[0]);

		imshow("RCAM", imgs[1]);
		
	
	
		
		sprintf(tx_buffer, "[%d,%d,%d,%d]", bull_one, letter_one, bull_two, letter_two);
		
		int count = write(uart0_filestream, &tx_buffer[0], strlen(tx_buffer));
		
		if (count < 0) printf("UART TX Error"); // Check for write error 
		
		//this_thread::sleep_for(200ms);
		
		char input = waitKey(1);
		
		if(input == 'q'){
			break;
		}
    
	}
	// End of loop, close cameras & clean up
		for (auto& cam : cameras){
			auto title = camTitle(cam.options->camera);
			
			std::cout << title << std::endl;
			cv::destroyWindow(title);
			cam.stopVideo();


		}

}
