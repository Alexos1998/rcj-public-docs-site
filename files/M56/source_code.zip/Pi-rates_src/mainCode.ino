//X = columns, Y = rows

//---------------------------------------------------------------------libraries
#include <Wire.h>
#include <LittleFS.h>
#include <SingleFileDrive.h>
#include <SoftwareSerial.h>
#include <math.h>
#include <queue>
#include <stack>
#include <map>
#include <string>

#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_APDS9960.h>
#include <Adafruit_NeoPixel.h>
#include <VL53L0X.h>
#include <vl53l4cx_class.h>
#include <Servo.h>
#include <PololuQik.h>

//---------------------------------------------------------------------macros
//display
#define TEXT_SIZE 1
#define TCAADDR 0x70

//bno degrees
#define WEST 270
#define EAST 90
#define SOUTH 180
#define NORTH 0

//speeds
#define TURN 45     //50
#define FORWARD 65  //55

//motor macros
#define WHEEL_DIAM 6
#define ENC_A 2
#define ENC_B 3

//wall distance
#define WALL 120

//mux ports for sensors
#define LB 1
#define RB 0
#define LF 2
#define RF 7
#define FL 5
#define FR 6
#define BNO 3
#define SSD 3
#define APDS 4
#define L4CX 4
#define BACK 3

//leds pin
#define LED 28
#define LRING 22
#define RRING 6
#define PIXELS 12

//servo & stepper pins
#define STEP_PIN 18
#define DIR_PIN 19
#define EN_PIN 26
#define SERVO 7

//servo & stepper macros
#define LEFT 120
#define RIGHT 45
#define CENTER 80
#define STEPS_PER_DROP 188
#define STEP_DELAY 800
#define L -1
#define R 1

//ramp cases
#define UP 1
#define DOWN -1

//obstacle cases
#define NONE 0
#define FAR 1
#define CLOSE 2
#define LONG_SIDEL 3
#define SIDEL 4
#define LONG_SIDER 5
#define SIDER 6

//obstacle threshholds
#define OBS_THRESH 120
#define WALL_THRESH 80
#define MAX_THRESH 350

//victim macros
#define harmed 2    //two; blink
#define stable 1    //one; blink
#define unharmed 0  //zero; blink

//return values for checkcolor
#define slver 0
#define rd 1
#define blck 2
#define blu 3

#define TILE_LEN 30
#define MAZE_DIM 20

//silver: 125, 140, 130, 250
//white: 65, 70, 60, 170
//black: 5, 5, 5, 10
//blue: 5, 10, 13, 25
//red: 20, 5, 7, 25

struct Color {
  int r, g, b, c;
};

Color silver{ 125, 140, 130, 250 };
Color white{ 130, 100, 75, 265 };
Color black{ 4, 3, 3, 8 };
Color blue{ 20, 25, 30, 60 };
Color red{ 43, 12, 12, 52 };

//---------------------------------------------------------------------constants
//color values
int THRESH_r = (red.r + black.r) / 2;                       //uses r between red and black
int THRESH_b = (blue.r + black.r) / 2;                      //uses r between blue and black
int SILVER = (white.r + silver.r) / 2;                      //uses r between white and silver
float BLUE = (float)(red.b / red.r + blue.b / blue.r) / 2;  //uses b/r between red and blue
float RED = (float)(red.r / red.b + blue.r / blue.b) / 2;   //uses r/b between red and blue

//array indexes for walls
enum dirs { north = 0,
            east = 1,
            south = 2,
            west = 3 };

//misc. globals
int NSEW = NORTH;
const char* filename = "./file.txt";
char buff[100];
uint16_t r, g, b, c;
bool check = false;
bool check_cameras = true;
bool check_obstacle = true;
int strikes = 0;

//maze initialization
struct tile {
  uint8_t x, y;
  bool walls[4];            //wall present
  bool visited;             //visited before
  bool victims_checked[4];  //victims present
};

//array to write file
struct information {
  tile maze[MAZE_DIM][MAZE_DIM];
  tile* cur;
};

//maze globals
information readinfo;
tile* starttile;
std::stack<tile*> path;
tile* current;
tile* parent[MAZE_DIM][MAZE_DIM];  //store tile came from

//sensors and co.
Adafruit_BNO055 bno = Adafruit_BNO055(55, 0x28);
Adafruit_SSD1306 display(128, 64, &Wire, -1);
Adafruit_APDS9960 apds;
VL53L0X tof;
VL53L4CX l4cx(&Wire, -1);
Servo servo;
PololuQik2s12v10 controller1(11, 10, 9);
PololuQik2s12v10 controller2(15, 14, 12);
PololuQik2s12v10 qiks[] = { controller1, controller2 };
Adafruit_NeoPixel pixels1 = Adafruit_NeoPixel(PIXELS, LRING, NEO_GRB + NEO_KHZ800);
Adafruit_NeoPixel pixels2 = Adafruit_NeoPixel(PIXELS, RRING, NEO_GRB + NEO_KHZ800);

//bno globals
float off_error = 0;
float start_error = 0;

//encoders
volatile long encoders_lf = 0;
float enc_per_cm = 84;

//---------------------------------------------------------------------motor functions
//encoder changes
//left front
volatile int counter = 0;
void enc_update_lf() {
  int a = digitalRead(ENC_A);
  int b = digitalRead(ENC_B);

  counter++;

  if (a == b) {
    encoders_lf--;
  } else {
    encoders_lf++;
  }
}

void reset_enc() {
  encoders_lf = 0;
}

//motor speeds
int cmap(int val, int olow, int ohigh, int mlow, int mhigh) {
  return constrain(map(val, olow, ohigh, mlow, mhigh), mlow, mhigh);
}

void speed(int left, int right) {
  int pwm;

  //straight
  if (left == right) {
    pwm = cmap(abs(right), 0, 100, 0, 127);
    if (right >= 0) {
      controller1.setM0Speed(-pwm);
      controller1.setM1Speed(-pwm);
    } else {
      controller1.setM0Speed(pwm);
      controller1.setM1Speed(pwm);
    }

    pwm = cmap(abs(left), 0, 100, 0, 127);
    if (left >= 0) {
      controller2.setM0Speed(pwm);
      controller2.setM1Speed(pwm);
    } else {
      controller2.setM0Speed(-pwm);
      controller2.setM1Speed(-pwm);
    }
    return;
  }

  //right
  pwm = cmap(abs(right), 0, 100, 0, 127);
  if (right >= 0) {
    controller1.setM0Speed(pwm);
    controller1.setM1Speed(pwm);
  } else {
    controller1.setM0Speed(-pwm);
    controller1.setM1Speed(-pwm);
  }

  //left
  pwm = cmap(abs(left), 0, 100, 0, 127);
  if (left >= 0) {
    controller2.setM0Speed(-pwm);
    controller2.setM1Speed(-pwm);
  } else {
    controller2.setM0Speed(pwm);
    controller2.setM1Speed(pwm);
  }
}

//---------------------------------------------------------------------misc. functions
//switch mux channels
void tcaselect(uint8_t channel) {
  Wire.beginTransmission(TCAADDR);
  Wire.write(1 << channel);
  int err = Wire.endTransmission();
  delay(10);
  if (err) {
    Serial.print("mux error: ");
    Serial.println(err);
    while (1)
      ;
  }
}

//print string on oled
void printoled(int line, String s, bool single = true) {
  tcaselect(SSD);
  if (single)
    display.clearDisplay();
  display.setCursor(0, TEXT_SIZE * line * 8);
  display.print(s);
  if (single)
    display.display();
  delay(5);
}

//blink the led for the interval
void blink() {
  for (int i = 0; i < 5; i++) {
    digitalWrite(LED, HIGH);
    delay(500);
    digitalWrite(LED, LOW);
    delay(500);
  }
}

//return if a tile is a deadend
bool isdeadend(tile* t) {
  int walls = 0;
  for (int i = 0; i < 4; i++)
    if (t->walls[i])
      walls++;
  return walls == 3;
}

//check if return value is a valid victim
bool validvic(int a) {
  if (a == harmed || a == unharmed || a == stable)
    return true;
  return false;
}

//check for and handle silver
void silvertile() {
  if (checkcolor() == slver) {
    //tone(22, 500, 500);
    readinfo.cur = current;
    write(&readinfo.maze[0][0], MAZE_DIM, MAZE_DIM);
  }
}

void done_routine() {
  printoled(0, "all tiles visited");
  speed(0, 0);
  delay(150);

  pathhome();
  navtarget(starttile, true);

  printoled(0, "done");
  //tone(22, 900, 250);
  while (1) {
    speed(0, 0);
    digitalWrite(LED, HIGH);
    delay(1000);
    digitalWrite(LED, LOW);
    delay(1000);
  }
}

//change coordinates based on direction
bool change_coords(int& nx, int& ny, int dir) {
  switch (dir) {
    case north:
      ny--;
      break;
    case east:
      nx++;
      break;
    case south:
      ny++;
      break;
    case west:
      nx--;
      break;
  }
  if (nx >= 0 && nx < MAZE_DIM && ny >= 0 && ny < MAZE_DIM)
    return true;
  return false;
}

//return offset from goal
int offset(float des, float cur) {
  int error = cur - des;
  if (error > 180)
    return error - 360;
  if (error < -180)
    return error + 360;
  return error;
}

//check for a ramp
int checkramp() {
  //ascending
  if (bno_z() > 15.0) {
    //tone(22, 500, 500);
    return UP;
  }
  //descending
  if (bno_z() < -5.0) {
    //tone(22, 250, 500);
    return DOWN;
  }
  //nothing
  return false;
}

//rescue letter victims
void letters(int val, int side) {
  switch (val) {
    case unharmed:
      blink();
      break;
    case stable:
      blink();
      drop(side, 1);
      break;
    case harmed:
      blink();
      drop(side, 2);  //might have to change to 1**
      break;
    default:  //no valid victim
      break;
  }
}

//rescue ring victims
void rings(int val, int side) {
  switch (val) {
    case unharmed:
      blink();
      break;
    case stable:
      blink();
      drop(side, 1);
      break;
    case harmed:
      blink();
      drop(side, 2);
      break;
    default:  //no valid victim
      break;
  }
}

//check if the address for the l4cx is open
bool l4cx_present() {
  tcaselect(L4CX);
  delay(10);

  Wire.beginTransmission(0x29);
  byte error = Wire.endTransmission();

  return (error == 0);
}

//write to stepper
void stepmotor(int steps) {
  digitalWrite(EN_PIN, LOW);
  for (int i = 0; i < steps; i++) {
    digitalWrite(STEP_PIN, HIGH);
    delayMicroseconds(STEP_DELAY);
    digitalWrite(STEP_PIN, LOW);
    delayMicroseconds(STEP_DELAY);
  }
  delay(200);
  digitalWrite(EN_PIN, HIGH);
}

//drop rescue kits
void drop(int side, int count) {
  //turn to side
  servo.attach(SERVO);
  if (side == L)
    servo.write(LEFT);
  else
    servo.write(RIGHT);

  delay(250);

  //do for number of kits
  for (int i = 0; i < count; i++) {
    stepmotor(STEPS_PER_DROP);
    delay(500);
  }

  //reset
  delay(250);
  servo.write(CENTER);
  servo.detach();
  delay(250);
}

//---------------------------------------------------------------------sensor and etc. functions
//return values from color sensor
void getcolor() {
  tcaselect(APDS);
  apds.getColorData(&r, &g, &b, &c);
  sprintf(buff, "r = %d, g = %d, b = %d, c = %d", r, g, b, c);
}

//return distance from one or two tofs
int get_dist(int tof1, int tof2 = 10) {
  tcaselect(tof1);
  delay(5);
  int a = tof.readRangeContinuousMillimeters();
  if (a == 8190)
    for (int i = 0; i < 5; i++) {
      //tone(22, 900, 250);
      tcaselect(tof1);
      delay(5);
      a = tof.readRangeContinuousMillimeters();
      if (a != 8190)
        break;
    }
  if (tof2 == 10)
    return a;
  tcaselect(tof2);
  delay(5);
  int b = tof.readRangeContinuousMillimeters();
  if (b == 8190)
    for (int i = 0; i < 5; i++) {
      //tone(22, 900, 250);
      tcaselect(tof2);
      delay(5);
      b = tof.readRangeContinuousMillimeters();
      if (b != 8190)
        break;
    }
  return (a + b) / 2;  //return average if two sensors given
}

//return distance from l4cx
int readl4cx() {
  tcaselect(L4CX);

  VL53L4CX_MultiRangingData_t data;
  uint8_t newDataReady = 0;
  int status;

  //wait until data returned
  do {
    status = l4cx.VL53L4CX_GetMeasurementDataReady(&newDataReady);

    if (status != 0) {
      return -1;
    }

    delay(1);

  } while (!newDataReady);

  //error in reading
  if (status != 0)
    return -1;

  status = l4cx.VL53L4CX_GetMultiRangingData(&data);

  //reading bad
  if (status != 0 || data.NumberOfObjectsFound == 0) {
    l4cx.VL53L4CX_ClearInterruptAndStartMeasurement();
    return -1;
  }

  //pick closest object
  int mindist = 9999;
  for (int i = 0; i < data.NumberOfObjectsFound; i++) {
    int d = data.RangeData[i].RangeMilliMeter;

    if (d > 0 && d < mindist)
      mindist = d;
  }

  l4cx.VL53L4CX_ClearInterruptAndStartMeasurement();

  return mindist;
}

//return yaw
float printbno() {
  tcaselect(BNO);
  sensors_event_t orientationData;
  bno.getEvent(&orientationData, Adafruit_BNO055::VECTOR_EULER);
  float heading = orientationData.orientation.x;
  sprintf(buff, "heading: %.2f", heading);
  printoled(0, buff);

  //change for drift and start shifting
  heading = heading + off_error - start_error;
  if (heading < 0)
    heading += 360;
  if (heading >= 360)
    heading -= 360;
  return heading;
}

//return pitch
float bno_z() {
  tcaselect(BNO);
  sensors_event_t orientationData;
  bno.getEvent(&orientationData, Adafruit_BNO055::VECTOR_EULER);
  sprintf(buff, "z = %d", orientationData.orientation.z);
  return -1 * orientationData.orientation.z;
}

//get victim values from cameras
void cameras(int& greek, int& bull, int& greek2, int& bull2) {
  //send pi trigger
  int bytes = Serial1.write('a');
  if (bytes < 1)
    Serial.println("serial write failed");

  if (strikes > 4) {
    bull = -1;
    greek = -1;
    bull2 = -1;
    greek2 = -1;
    return;
  }

  int start = millis();
  while (Serial1.available() < 1)
    if (millis() > start + 3000) {
      strikes++;
      bull = -1;
      greek = -1;
      bull2 = -1;
      greek2 = -1;
      return;
    }

  bull = Serial1.parseInt();
  greek = Serial1.parseInt();
  bull2 = Serial1.parseInt();
  greek2 = Serial1.parseInt();
}

//return color based on threshholds
int checkcolor() {
  speed(0, 0);

  getcolor();

  int tries = 0;
  //can't divide by zero; check again
  while ((r == 0 || b == 0) && tries < 5) {
    getcolor();
    printoled(0, "zero color values");
    delay(250);
    tries++;
  }

  if (r > SILVER) {
    printoled(0, "silver");
    return slver;
  } else if ((float)b / r > BLUE && r < THRESH_r) {
    printoled(0, "blue");
    return blu;
  } else if (r / b > RED && b < THRESH_b) {
    printoled(0, "red");
    return rd;
  } else if (b < THRESH_b && r < THRESH_r) {
    printoled(0, "black");
    return blck;
  }
  return -1;
}

//detect different types of obstacles
int obstacle_detection() {
  int left = get_dist(FL);
  int center;
  for (int i = 0; i < 3; i++)
    center = readl4cx();
  int right = get_dist(FR);

  sprintf(buff, "left: %d, center: %d, right: %d", left, center, right);
  Serial.println(buff);

  if (left > MAX_THRESH && center > MAX_THRESH && right > MAX_THRESH)
    return NONE;

  if (center == -1)
    return NONE;

  //everything sees; wall not obstacle
  if (abs(left - center) < WALL_THRESH && abs(right - center) < WALL_THRESH && abs(left - right) < WALL_THRESH)
    return NONE;

  //sort close obstacles
  if (center < OBS_THRESH)
    return CLOSE;
  if (left < OBS_THRESH)
    return SIDEL;
  if (right < OBS_THRESH)
    return SIDER;

  //sort far obstacles
  if (center < left && center < right)
    return FAR;
  if (left < right)
    return LONG_SIDEL;
  if (right < left)
    return LONG_SIDER;

  return NONE;
  //                                                                            add in else case later if center does not see but left and right do
}

//---------------------------------------------------------------------movement functions
//correct to direction
void correct(float dir) {
  while (true) {
    float cur = printbno();
    int err = offset(dir, cur);

    //close enough
    if (abs(err) <= 3)
      break;

    int turn_speed;

    //go slower if closer to target heading
    if (abs(err) < 20)
      turn_speed = TURN - 15;
    else
      turn_speed = TURN;

    //turn left or right depending on error
    if (err < 0)
      speed(turn_speed, -turn_speed);
    else
      speed(-turn_speed, turn_speed);

    delay(5);
  }

  speed(0, 0);
}

//align to wall
void corrections() {
  int correct_dist = 55;
  int dist1, dist2;
  int spd = 55;

  //distance
  if (get_dist(FL, FR) < 175) {
    if (get_dist(FL, FR) > correct_dist)
      while (get_dist(FL, FR) > correct_dist)
        speed(spd - 15, spd - 15);
    else
      while (get_dist(FL, FR) < correct_dist - 5)
        speed(-spd + 20, -spd + 20);
  } else  //too far from a wall to correct
    return;

  speed(0, 0);
  delay(150);

  //coarse angle
  if (abs(get_dist(FR) - get_dist(FL)) > 5) {
    if (get_dist(FR) > get_dist(FL))
      while (get_dist(FR) > get_dist(FL))
        speed(-TURN, TURN);
    else
      while (get_dist(FL) > get_dist(FR))
        speed(TURN, -TURN);
  }

  speed(0, 0);
  delay(10);

  //fine angle
  if (abs(get_dist(FR) - get_dist(FL)) > 0) {
    if (get_dist(FR) > get_dist(FL))
      while (get_dist(FR) > get_dist(FL))
        speed(-TURN + 20, TURN - 20);
    else
      while (get_dist(FL) > get_dist(FR))
        speed(TURN - 20, -TURN + 20);
  }

  speed(0, 0);

  off_error = NSEW - printbno();
}

//align heading to side walls
void side_adj(int s1, int s2) {
  //fine angle
  if (abs(get_dist(s1) - get_dist(s2)) > 3) {
    if (get_dist(s1) > get_dist(s2))
      while (get_dist(s1) > get_dist(s2) + 3)
        speed(-TURN + 25, TURN - 25);
    else
      while (get_dist(s2) > get_dist(s1) + 3)
        speed(TURN - 25, -TURN + 25);
  }

  speed(0, 0);

  off_error = NSEW - printbno();
}

//handle values return from camera
bool victims(tile* cur, int half = 0) {
  speed(0, 0);
  int left_ring = -1, left_letter = -1, right_ring = -1, right_letter = -1;

  printoled(0, "checking victims");

  //check cameras three times
  for (int i = 0; i < 3; i++) {
    int a, b, c, d;
    cameras(a, b, c, d);

    //if a valid value is returned, mark it down
    if (validvic(a))
      left_letter = a;
    if (validvic(b))
      left_ring = b;
    if (validvic(c))
      right_letter = c;
    if (validvic(d))
      right_ring = d;
  }

  sprintf(buff, "%d, %d, %d, %d", left_ring, left_letter, right_ring, right_letter);
  Serial.println(buff);

  int dir_forward = (((int)NSEW % 360) + 360) % 360 / 90;
  int dir_left = (dir_forward + 3) % 4;
  int dir_right = (dir_forward + 1) % 4;

  if (cur->victims_checked[dir_left] && cur->victims_checked[dir_right])
    return false;

  //handle values only if an unchecked wall is on that side
  //left wall
  if (!cur->victims_checked[dir_left] && (get_dist(LF) < WALL || get_dist(LB) < WALL)) {
    if (validvic(left_letter))
      letters(left_letter, L);

    if (validvic(left_ring))
      rings(left_ring, L);
  }

  //right wall
  if (!cur->victims_checked[dir_right] && (get_dist(RF) < WALL || get_dist(RB) < WALL)) {
    if (validvic(right_letter))
      letters(right_letter, R);

    if (validvic(right_ring))
      rings(right_ring, R);
  }

  if (!half) {
    cur->victims_checked[dir_left] = true;
    cur->victims_checked[dir_right] = true;
  }
  //return if victim was found
  if (validvic(left_letter) || validvic(right_letter) || validvic(left_ring) || validvic(right_ring))
    return true;
  return false;
}

bool obstacle_avoidance(int placement, tile* pos) {
  int dir = (((int)NSEW % 360) + 360) % 360 / 90;
  int nx = pos->x;
  int ny = pos->y;

  if (!change_coords(nx, ny, dir))
    return false;

  tile* blocked = &readinfo.maze[nx][ny];
  bool left_wall = (get_dist(LF) < WALL + 50);
  bool right_wall = (get_dist(RF) < WALL + 50);

  switch (placement) {
    //on border between current and next
    //block wall on tile ahead
    case CLOSE:
    case SIDEL:
    case SIDER:
      printoled(0, "close");
      delay(300);
      readinfo.maze[nx][ny].walls[(dir + 2) % 4] = true;
      break;
    //in middle of next tile
    //block of all walls
    case FAR:
      printoled(0, "far");
      delay(300);
      blocked->visited = true;
      for (int i = 0; i < 4; i++) {
        blocked->walls[i] = true;  //block off own walls

        //find surrounding tiles
        int nnx = nx;
        int nny = ny;

        if (change_coords(nnx, nny, i))
          readinfo.maze[nnx][nny].walls[(i + 2) % 4] = true;
      }
      break;
    // case SIDEL:  //on left of border
    //   //try to curve around it
    //     if(get_dist(LF, LB) < WALL)
    //       speed(30, 50);                                                               //fill in later; use trig to calculate stright line distance

    //     correct(NSEW);
    //   break;
    // case SIDER:  //on right of border
    //   //try to curve around it
    //     if(get_dist(RF, RB) < WALL)
    //       speed(50, 30);

    //     correct(NSEW);
    //   break;
    //on left of next tile
    //block off both walls touching the left wall and the left wall
    case LONG_SIDEL:
      printoled(0, "left");
      delay(300);
      blocked->visited = true;
      for (int i = 0; i < 4; i++) {
        if (i == (dir + 3) % 4)
          continue;
        blocked->walls[i] = true;  //block off own walls

        //find surrounding tiles
        int nnx = nx;
        int nny = ny;

        if (change_coords(nnx, nny, i))
          readinfo.maze[nnx][nny].walls[(i + 2) % 4] = true;
      }
      break;
    //on right of next tile
    //block off both walls touching the right wall and the right wall
    case LONG_SIDER:
      printoled(0, "right");
      delay(300);
      blocked->visited = true;
      for (int i = 0; i < 4; i++) {
        if (i == (dir + 1) % 4)
          continue;
        blocked->walls[i] = true;  //block off own walls

        //find surrounding tiles
        int nnx = nx;
        int nny = ny;

        if (change_coords(nnx, nny, i))
          readinfo.maze[nnx][nny].walls[(i + 2) % 4] = true;
      }
      break;
    //no obstacle detected
    case NONE:
      return false;
  }

  Serial.print("obstacle: ");
  Serial.println(placement);

  return true;
}

//travel up or down a ramp
void travelramp(int ramp) {
  int spd = 55;
  //go until level off
  while (abs(bno_z()) > 1.0) {
    if (ramp == UP)
      speed(spd + 20, spd + 20);
    else
      speed(spd - 10, spd - 10);
  }
  reset_enc();

  //adjust
  if (get_dist(FL) > 150) {
    if (ramp == UP)
      while (encoders_lf < enc_per_cm * 5)
        speed(spd - 10, spd - 10);
    else
      while (encoders_lf < enc_per_cm * 10)
        speed(spd - 10, spd - 10);
    corrections();
  }
}

//traverse and fill in information for a hole
void handlehole(int spd, long target) {
  printoled(0, "hole");
  //tone(22, 300, 1000);

  //find tile going to
  int dir = (((int)NSEW % 360) + 360) % 360 / 90;
  int nx = current->x;
  int ny = current->y;

  if (change_coords(nx, ny, dir)) {
    tile* blocked = &readinfo.maze[nx][ny];
    for (int i = 0; i < 4; i++) {
      blocked->walls[i] = true;  //block off own walls

      //find surrounding tiles
      int nnx = nx;
      int nny = ny;

      if (!change_coords(nnx, nny, i))
        continue;

      //mark corresponding wall in neighbor
      int opposite = (i + 2) % 4;
      readinfo.maze[nnx][nny].walls[opposite] = true;
    }
  }

  //go back to the original tile
  reset_enc();
  while (abs(encoders_lf) < target)
    speed(-spd, -spd);
  speed(0, 0);
}

//move straight in cm
int enc_forward(int dist_cm, int spd, bool special_checks = false) {
  reset_enc();
  long target = (long)(enc_per_cm * dist_cm);
  int ramp = false;
  float z = bno_z();
  bool found = false;

  //find tile going to
  int dir = (((int)NSEW % 360) + 360) % 360 / 90;
  int nx = current->x;
  int ny = current->y;

  int ct = 1;
  //move half a tile
  while (abs(encoders_lf) < target / 2) {
    speed(spd, spd);
    delay(1);

    if (special_checks && abs(encoders_lf) > 5 * enc_per_cm * ct) {
      delay(125);
      if (checkcolor() == blck) {
        handlehole(spd, 5 * enc_per_cm * ct);
        return blck;
      }
      ct++;
    }

    if (special_checks)
      ramp = checkramp();
  }

  //check if ramp was detected and go up if it was
  if (ramp)
    travelramp(ramp);

  reset_enc();
  speed(0, 0);

  if (special_checks)
    delay(500);

  //check for hole and victims
  if (special_checks && !ramp) {
    if (checkcolor() == blck) {
      handlehole(spd, target / 2);
      return blck;
    }
    //                                                                                                                            check cameras
    if (check_cameras)
      if (change_coords(nx, ny, dir))
        victims(&readinfo.maze[nx][ny], true);
  }

  //if no ramp yet, move the rest of the tile
  if (!ramp) {
    correct(NSEW);
    while (abs(encoders_lf) < target / 2) {
      speed(spd, spd);
      delay(1);

      if (special_checks)
        ramp = checkramp();
    }

    //check for ramp again
    if (ramp)
      travelramp(ramp);
    //                                                                                                                                check cameras
    if (check_cameras)
      if (special_checks && !ramp)
        if (change_coords(nx, ny, dir))
          victims(&readinfo.maze[nx][ny]);
  }

  speed(0, 0);
  delay(200);
  if (special_checks)
    delay(300);
  return -1;
}

//adjust if sensors on the same side are different
bool adjust(int s1, int s2) {
  int spd = 55;
  //if sensors disagree
  if (abs(get_dist(s1) - get_dist(s2)) > 170 && (get_dist(s1) < WALL + 50 || get_dist(s2) < WALL + 50)) {
    enc_forward(10, spd - 10);
    //check if sensors match now
    if (abs(get_dist(s1) - get_dist(s2)) > 170 && (get_dist(s1) < WALL + 50 || get_dist(s2) < WALL + 50))
      enc_forward(20, -spd + 10);
  }
  if (abs(get_dist(s1) - get_dist(s2)) > 100 && (get_dist(s1) < WALL + 50 || get_dist(s2) < WALL + 50)) {
    enc_forward(10, spd + 10);
    return false;
  }
  return true;
}

//---------------------------------------------------------------------file system
//write to file
void write(tile* m, int rows, int cols) {
  File outfile = LittleFS.open(filename, "w");
  if (!outfile) {
    printoled(0, "file opening failed write");
    return;
  }
  Serial.println("writing");

  //write in maze array
  for (int i = 0; i < rows; i++)
    for (int j = 0; j < cols; j++) {
      tile& t = m[i * cols + j];
      outfile.write(t.x);
      outfile.write(t.y);
      //write in walls & visited from struct
      for (int k = 0; k < 4; k++)
        outfile.write(t.walls[k] ? 1 : 0);
      outfile.write(t.visited ? 1 : 0);
      for (int k = 0; k < 4; k++)
        outfile.write(t.victims_checked[k] ? 1 : 0);
    }

  //write in the current tile
  outfile.write(readinfo.cur->x);
  outfile.write(readinfo.cur->y);

  outfile.close();
  Serial.println("written");
}

//read from file
void read(tile* m, int rows, int cols) {
  File infile = LittleFS.open(filename, "r");
  if (!infile) {
    printoled(0, "file opening failed read");
    return;
  }

  //read in the maze array
  for (int i = 0; i < rows; i++)
    for (int j = 0; j < cols; j++) {
      tile& t = m[i * cols + j];
      t.x = infile.read();
      t.y = infile.read();
      //read in the walls & visited for the struct
      for (int k = 0; k < 4; k++)
        t.walls[k] = infile.read() ? true : false;
      t.visited = infile.read() ? true : false;
      for (int k = 0; k < 4; k++)
        t.victims_checked[k] = infile.read() ? true : false;
    }

  //read in the current tile
  uint8_t cx = infile.read();
  uint8_t cy = infile.read();
  readinfo.cur = &readinfo.maze[cx][cy];

  infile.close();
}

//initialization if there is no file or the while should be cleared
void mazeinit_empty() {
  for (int i = 0; i < MAZE_DIM; i++) {
    for (int j = 0; j < MAZE_DIM; j++) {
      readinfo.maze[i][j].x = i;
      readinfo.maze[i][j].y = j;
      readinfo.maze[i][j].visited = false;
      for (int k = 0; k < 4; k++) {
        readinfo.maze[i][j].walls[k] = false;
        readinfo.maze[i][j].victims_checked[k] = false;
      }
    }
  }
  starttile = &readinfo.maze[MAZE_DIM / 2][MAZE_DIM / 2];
  readinfo.cur = starttile;
  starttile->visited = true;
}

//initalization if reading from file
void mazeinit_file() {
  read(&readinfo.maze[0][0], MAZE_DIM, MAZE_DIM);
  starttile = &readinfo.maze[MAZE_DIM / 2][MAZE_DIM / 2];  //always fixed start
  readinfo.cur = &readinfo.maze[readinfo.cur->x][readinfo.cur->y];
}

//---------------------------------------------------------------------bfs
//check in front and on left + right for walls
void check_walls(int set = true) {
  speed(0, 0);
  int dir_forward = (((int)NSEW % 360) + 360) % 360 / 90;

  //forward
  int d = get_dist(FL, FR);
  for (int i = 0; i < 3; i++) {
    d = get_dist(FL, FR);
    if (d < WALL)
      break;
  }
  if (d < WALL) {
    if (set) {
      current->walls[dir_forward] = true;
      printoled(0, "forward");
      delay(350);
    }
  }

  //right
  //if adjust didn't work, there might be an obstacle in that direction
  if (adjust(RF, RB)) {
    d = get_dist(RF, RB);
    int dir_right = (dir_forward + 1) % 4;
    if (d < WALL + 50) {
      if (set) {
        current->walls[dir_right] = true;
        printoled(1, "right");
        delay(350);
      }
      side_adj(RB, RF);
    }
  }

  //left
  //if adjust didn't work, there might be an obstacle in that direction
  if (adjust(LF, LB)) {
    d = get_dist(LF, LB);
    int dir_left = (dir_forward + 3) % 4;
    if (d < WALL + 50) {
      if (set) {
        current->walls[dir_left] = true;
        printoled(2, "left");
        delay(350);
      }
      side_adj(LF, LB);
    }
  }

  //play tones for the amount of walls present
  // for (int i = 0; i < 4; i++) {
  //   if (current->walls[i]) {
  //     //tone(22, 200, 300);
  //     delay(500);
  //   }
  //   delay(100);
  // }

  speed(0, 0);
}

//check behind upon starting for a wall
void check_back_wall() {
  int dir_back = south;

  corrections();

  //                                                                                                                             check cameras
  if (check_cameras)
    victims(starttile);

  NSEW = EAST;
  correct(NSEW);
  corrections();
  speed(0, 0);
  delay(150);

  //                                                                                                                              check cameras
  if (check_cameras)
    victims(starttile);

  int d = get_dist(RF, RB);
  starttile->walls[dir_back] = (d < WALL);

  if (d < WALL) {
    //tone(22, 300, 250);
    printoled(0, "behind");
  }
  delay(150);

  NSEW = NORTH;
  correct(NSEW);
  corrections();
  speed(0, 0);
}

//find nearest unvisited tile
tile* nearest_unvisited(tile* start) {
  bool seen[MAZE_DIM][MAZE_DIM] = { false };  //mark queued tiles
  for (int i = 0; i < MAZE_DIM; i++)
    for (int j = 0; j < MAZE_DIM; j++)
      parent[i][j] = nullptr;

  std::queue<tile*> q;
  q.push(start);
  seen[start->x][start->y] = true;

  while (!q.empty()) {
    tile* cur = q.front();
    q.pop();

    if (cur != start && !cur->visited) {
      //if true, found the nearest unvisited tile
      while (!path.empty())
        path.pop();
      //follow the parents back to start
      for (tile* t = cur; t != nullptr; t = parent[t->x][t->y])
        //make sure tile after start is at the top
        if (t != start)
          path.push(t);
      return cur;
    }

    for (auto i : { north, east, west, south }) {
      //if we already know there's a wall, skip
      if (cur->walls[i])
        continue;

      //convert direction into coordinates
      int nx = cur->x;
      int ny = cur->y;

      if (!change_coords(nx, ny, i))
        continue;

      if (!seen[nx][ny]) {
        seen[nx][ny] = true;  //its been queued
        parent[nx][ny] = cur;
        q.push(&readinfo.maze[nx][ny]);
      }
    }
  }
  return nullptr;
}

//follow path to target
void navtarget(tile* target, bool print) {
  while (!path.empty()) {
    tile* next = path.top();  //tile to move to
    path.pop();

    if (print) {
      sprintf(buff, "travelling to (%d, %d)", next->x, next->y);
      printoled(0, buff);
      delay(350);
    }

    int dx = next->x - current->x;
    int dy = next->y - current->y;

    //if can just back up
    if (((NSEW == NORTH && dx == 0 && dy == 1) || (NSEW == SOUTH && dx == 0 && dy == -1) || (NSEW == EAST && dx == -1 && dy == 0) || (NSEW == WEST && dx == 1 && dy == 0)) && (next->visited == true)) {
      if (isdeadend(current)) {
        NSEW = (NSEW + 90) % 360;
        correct(NSEW);
        speed(0, 0);
        delay(500);
        //                                                                                                                           check cameras
        if (check_cameras)
          victims(current);
        corrections();
        NSEW = (NSEW + 270) % 360;
        correct(NSEW);
        speed(0, 0);
        delay(100);
        corrections();
      }
      check_walls(false);

      check_cameras = false;
      //back up
      if (enc_forward(TILE_LEN, -FORWARD, true) == blck) {
        current->walls[(((int)NSEW % 360) + 360) % 360 / 90] = true;  //mark wall of current tile in direction of hole
        check_cameras = true;
        return;
      }

      check_cameras = true;

      check_walls(false);

      //made it to next tile
      current = next;

      silvertile();
      speed(0, 0);

      if (checkcolor() == blu)
        delay(5500);
    } else {
      int beginning = NSEW;
      //create new heading angle
      //dx = 1 means east
      //dx = -1 means west
      //dy = 1 means south
      //dy = -1 means north
      if (dx == 1 && dy == 0)
        NSEW = EAST;
      else if (dx == -1 && dy == 0)
        NSEW = WEST;
      else if (dx == 0 && dy == -1)
        NSEW = NORTH;
      else if (dx == 0 && dy == 1)
        NSEW = SOUTH;
      correct(NSEW);
      check_walls(false);

      //                                                                                                              check cameras after turning
      if (check_cameras)
        if (beginning != NSEW)
          victims(current);

      //check for obstacle
      if (check_obstacle)
        if (obstacle_avoidance(obstacle_detection(), current)) {
          current->walls[(((int)NSEW % 360) + 360) % 360 / 90] = true;  //mark wall of current tile in direction of obstacle
          return;
        }

      //move forward
      if (enc_forward(TILE_LEN, FORWARD, true) == blck) {
        current->walls[(((int)NSEW % 360) + 360) % 360 / 90] = true;
        return;
      }

      check_walls(false);

      //made it to next tile
      current = next;

      silvertile();
      speed(0, 0);

      if (checkcolor() == blu)
        delay(5500);
    }

    corrections();
    speed(0, 0);
  }
  correct(NSEW);
}

//bfs a path back home
void pathhome() {
  bool seen[MAZE_DIM][MAZE_DIM] = { false };
  std::queue<tile*> q;
  q.push(current);
  seen[current->x][current->y] = true;

  //reset parents
  for (int i = 0; i < MAZE_DIM; i++)
    for (int j = 0; j < MAZE_DIM; j++)
      parent[i][j] = nullptr;

  //go until start found
  while (!q.empty()) {
    tile* cur = q.front();
    q.pop();

    if (cur == starttile) {  //found path to start
      //clear old path
      while (!path.empty())
        path.pop();
      for (tile* t = cur; t != nullptr; t = parent[t->x][t->y])
        if (t != current)  //skip current
          path.push(t);
      return;
    }

    //check neighbors
    for (int i = 0; i < 4; i++) {
      if (cur->walls[i])  //skip if wall
        continue;

      int nx = cur->x;
      int ny = cur->y;

      if (!change_coords(nx, ny, i))
        continue;

      //add to bfs
      if (!seen[nx][ny]) {
        seen[nx][ny] = true;
        parent[nx][ny] = cur;
        q.push(&readinfo.maze[nx][ny]);
      }
    }
  }
}

//---------------------------------------------------------------------executions
void setup() {
  auto reason = rp2040.getResetReason();
  Wire.setSDA(0);
  Wire.setSCL(1);
  Wire.begin();
  Serial.begin(115200);
  Serial1.setTX(16);
  Serial1.setRX(17);
  Serial1.begin(115200);
  while(!Serial);
  delay(2000);

  LittleFS.begin();

  controller2.init();
  Serial.print("controller2 firmware: ");
  Serial.write(controller2.getFirmwareVersion());
  Serial.println();

  controller1.init();
  Serial.print("controller1 firmware: ");
  Serial.write(controller1.getFirmwareVersion());
  Serial.println();

  pinMode(ENC_A, INPUT_PULLUP);
  pinMode(ENC_B, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(ENC_A), enc_update_lf, CHANGE);
  Serial.println("encoders lf is fine");

  servo.attach(SERVO);
  servo.write(CENTER);
  delay(500);
  servo.detach();

  pixels1.begin();
  pixels2.begin();
  pixels1.clear();
  pixels2.clear();
  for (int i = 0; i < PIXELS; i++) {
    pixels1.setPixelColor(i, pixels2.Color(255, 255, 255));
    pixels2.setPixelColor(i, pixels2.Color(255, 255, 255));
  }
  pixels1.show();
  pixels2.show();

  pinMode(STEP_PIN, OUTPUT);
  pinMode(DIR_PIN, OUTPUT);
  pinMode(EN_PIN, OUTPUT);

  digitalWrite(EN_PIN, LOW);
  digitalWrite(DIR_PIN, HIGH);

  pinMode(20, INPUT_PULLUP);
  pinMode(21, INPUT_PULLUP);
  pinMode(LED, OUTPUT);

  tcaselect(SSD);
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3d)) {
    Serial.println("ssd is not fine");
    while (1)
      ;
  } else
    Serial.println("ssd is fine");

  display.clearDisplay();
  display.setTextSize(TEXT_SIZE);
  display.setTextColor(SSD1306_WHITE);

  sprintf(buff, "reason: %d", reason);
  printoled(0, buff);
  delay(500);

  tcaselect(APDS);
  if (!apds.begin(30, APDS9960_AGAIN_4X)) {
    Serial.println("color is not fine");
    while (1)
      ;
  } else
    Serial.println("color is fine");

  apds.enableColor(true);

  tcaselect(RB);
  tof.setTimeout(500);
  if (!tof.init()) {
    Serial.println("tof RB is not fine");
    while (1)
      ;
  } else
    Serial.println("tof RB is fine");
  tof.startContinuous();

  tcaselect(LF);
  tof.setTimeout(500);
  if (!tof.init()) {
    Serial.println("tof LF is not fine");
    while (1)
      ;
  } else
    Serial.println("tof LF is fine");
  tof.startContinuous();

  tcaselect(LB);
  tof.setTimeout(500);
  if (!tof.init()) {
    Serial.println("tof LB is not fine");
    while (1)
      ;
  } else
    Serial.println("tof LB is fine");
  tof.startContinuous();

  tcaselect(RF);
  tof.setTimeout(500);
  if (!tof.init()) {
    Serial.println("tof RF is not fine");
    while (1)
      ;
  } else
    Serial.println("tof RF is fine");
  tof.startContinuous();

  tcaselect(FL);
  tof.setTimeout(500);
  if (!tof.init()) {
    Serial.println("tof FL is not fine");
    while (1)
      ;
  } else
    Serial.println("tof FL is fine");
  tof.startContinuous();

  tcaselect(FR);
  tof.setTimeout(500);
  if (!tof.init()) {
    Serial.println("tof FR is not fine");
    while (1)
      ;
  } else
    Serial.println("tof FR is fine");
  tof.startContinuous();

  tcaselect(BACK);
  tof.setTimeout(500);
  if (!tof.init()) {
    Serial.println("tof BACK is not fine");
    while (1)
      ;
  } else
    Serial.println("tof BACK is fine");
  tof.startContinuous();

  tcaselect(L4CX);
  if (l4cx.begin() != VL53L4CX_ERROR_NONE || !l4cx_present()) {
    Serial.println("l4cx is not fine");
    if (!l4cx_present())
      Serial.println("0x29 is not fine");
    while (1)
      ;
  } else
    Serial.println("l4cx is fine");
  l4cx.VL53L4CX_Off();
  l4cx.InitSensor(0x29);
  l4cx.VL53L4CX_StartMeasurement();

  delay(500);

  display.clearDisplay();
  printoled(0, "ready to start", false);
  printoled(1, "press 21 twice to clear memory", false);
  display.display();

  // while (true) {
  //   if (!digitalRead(20))
  //     break;

  //   if (!digitalRead(21)) {
  //     delay(250);
  //     if (!digitalRead(21)) {  //21 twice to prevent accidental deletion
  //       printoled(0, "clearing memory...");
  //       LittleFS.remove(filename);
  //       delay(500);
  //       break;
  //     }
  //   }
  // }

  // while(true) {
  //   if(!digitalRead(20))
  //     Serial.println("not 20");
  //   else if(digitalRead(20))
  //     Serial.println("20");
  //   if(!digitalRead(21))
  //     Serial.println("not 21");
  //   else if(digitalRead(21))
  //     Serial.println(" 21");
  // }

  //set bno to current position
  tcaselect(BNO);
  if (!bno.begin(OPERATION_MODE_IMUPLUS)) {
    Serial.println("bno is not fine");
    while (1)
      ;
  } else
    Serial.println("bno is fine");

  sensors_event_t orientationData;
  bno.getEvent(&orientationData, Adafruit_BNO055::VECTOR_EULER);

  start_error = orientationData.orientation.x;

  //if file exists, load it
  if (LittleFS.exists(filename)) {
    mazeinit_file();
    printoled(0, "reading from file");
    delay(500);
  } else {
    mazeinit_empty();
    printoled(0, "no file");
    delay(500);
    check = true;
  }
}

// void loop() {
//   if (check)  //only if no file exists
//     check_back_wall();
//   current = readinfo.cur;

//   sprintf(buff, "(%d, %d)", current->x, current->y);
//   printoled(0, buff);

//   //check for obstacle
//   if (check_obstacle)
//     if (obstacle_avoidance(obstacle_detection(), current))
//       current->walls[(((int)NSEW % 360) + 360) % 360 / 90] = true;

//   while (1) {
//     speed(0, 0);
//     delay(125);
//     check_walls();
//     current->visited = true;

//     tile* goal = nearest_unvisited(current);

//     //all tiles visited
//     if (goal == nullptr)
//       done_routine();

//     navtarget(goal, true);
//   }
// }


//servo and stepper
// void loop() {
//   drop(L, 2);
//   delay(250);
//   drop(R, 9);
// }


// //motors and encoders
// void loop() {
//   while(1)
//   {
//     Serial.println(encoders_lf);
//     Serial.println(counter);
//   }
//   encoders_lf = 0;
//   while(encoders_lf < enc_per_cm * 30)
//     speed(50, 50);

//   delay(1000);
//   speed(50, -50);
//   delay(500);
//   speed(-50, 50);
//   delay(500);
//   speed(0, 0);
//   delay(2000);
// }

// void loop() {
//   speed(0, 0);
// }

void loop() {
  Serial.print("A=");
  Serial.print(digitalRead(ENC_A));
  Serial.print(" B=");
  Serial.println(digitalRead(ENC_B));
  delay(100);
}