# =========================================
# OPENMV H7+ TB6612FNG MOTOR Test
# LEFT/RIGHT SWITCHED
# =========================================

from pyb import Pin, Timer
import time

# ---------------- MOTOR PINS ----------------
AIN1 = Pin("P2", Pin.OUT_PP)
AIN2 = Pin("P9", Pin.OUT_PP)

BIN1 = Pin("P0", Pin.OUT_PP)
BIN2 = Pin("P1", Pin.OUT_PP)

STBY = Pin("P3", Pin.OUT_PP)

# ---------------- PWM ----------------
timer = Timer(4, freq=1000)

PWMA = timer.channel(1, Timer.PWM, pin=Pin("P7"))
PWMB = timer.channel(2, Timer.PWM, pin=Pin("P8"))

# =========================================
# FUNCTIONS
# =========================================

def stop():
    PWMA.pulse_width_percent(0)
    PWMB.pulse_width_percent(0)

    AIN1.low()
    AIN2.low()

    BIN1.low()
    BIN2.low()

    print("STOP")


# -------- SWITCHED --------
# A MOTOR = RIGHT
# B MOTOR = LEFT
# --------------------------

def right_motor(speed):
    speed = int(speed)

    if speed > 0:
        AIN1.low()
        AIN2.high()
        print("RIGHT MOTOR -> FORWARD")

    elif speed < 0:
        AIN1.high()
        AIN2.low()
        print("RIGHT MOTOR -> BACKWARD")

    else:
        AIN1.low()
        AIN2.low()
        print("RIGHT MOTOR -> STOP")

    PWMA.pulse_width_percent(abs(speed))


def left_motor(speed):
    speed = int(speed)

    if speed > 0:
        BIN1.high()
        BIN2.low()
        print("LEFT MOTOR -> FORWARD")

    elif speed < 0:
        BIN1.low()
        BIN2.high()
        print("LEFT MOTOR -> BACKWARD")

    else:
        BIN1.low()
        BIN2.low()
        print("LEFT MOTOR -> STOP")

    PWMB.pulse_width_percent(abs(speed))


def drive(left, right):
    STBY.high()

    print("----------------------")
    print("LEFT SPEED :", left)
    print("RIGHT SPEED:", right)

    left_motor(left)
    right_motor(right)


# =========================================
# TEST LOOP
# =========================================


while True:
    print("B motor forward")
    BIN1.high()
    BIN2.low()
    PWMB.pulse_width_percent(80)
    time.sleep(2)

    AIN1.high()
    AIN2.low()
    PWMA.pulse_width_percent(80)
    time.sleep(2)
