# =========================================================
# OPENMV H7+ 5-ROI LINE FOLLOWER + UART RAMP SPEED CONTROL
# GAP LOGIC: BACK-FORWARD ALIGN, THEN FORWARD COMMIT
# TB6612FNG
# =========================================================

import sensor, image, time
from pyb import Pin, Timer, UART

# =========================================================
# CAMERA
# =========================================================
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.set_windowing((300, 300))
sensor.skip_frames(time=2000)

sensor.set_vflip(True)
sensor.set_hmirror(True)
sensor.set_auto_whitebal(True)
sensor.set_auto_gain(True)

clock = time.clock()

# =========================================================
# UART FROM PICO
# =========================================================
uart = UART(1, 115200, timeout_char=10)

# =========================================================
# MOTOR PINS
# =========================================================
AIN1 = Pin("P2", Pin.OUT_PP)
AIN2 = Pin("P9", Pin.OUT_PP)

BIN1 = Pin("P4", Pin.OUT_PP)
BIN2 = Pin("P5", Pin.OUT_PP)

STBY = Pin("P3", Pin.OUT_PP)

timer = Timer(4, freq=1000)
PWMA = timer.channel(1, Timer.PWM, pin=Pin("P7"))
PWMB = timer.channel(2, Timer.PWM, pin=Pin("P8"))

# =========================================================
# NORMAL SPEED SETTINGS
# =========================================================
BASE_SPEED_FLAT = 35
BASE_SPEED_UP   = 65
BASE_SPEED_DOWN = 25

MAX_SPEED = 70
KP = 1.2

# =========================================================
# GAP RECOVERY SETTINGS
# =========================================================
GAP_BACK_SPEED = 27
GAP_FORWARD_SPEED = 27
ALIGN_SPEED = 25

GAP_BACK_TIME = 300
GAP_FORWARD_TIME = 400

CENTER_TOLERANCE = 16
ALIGN_STABLE_FRAMES = 4

FORWARD_COMMIT_SPEED = 40
FORWARD_COMMIT_TIME = 600

gap_mode = 0
gap_timer = time.ticks_ms()
align_count = 0

# gap_mode:
# 0 = normal following
# 1 = backing up during gap
# 2 = moving forward slowly/searching
# 3 = rotational alignment after line is found
# 4 = forward commit after alignment

# =========================================================
# LINE THRESHOLD
# =========================================================
THRESHOLD = [(0, 25, -20, 5, -5, 20)]

# =========================================================
# ROIs
# =========================================================
roi1 = (0,   0, 320, 48)
roi2 = (0,  48, 320, 48)
roi3 = (0,  96, 320, 48)
roi4 = (0, 144, 320, 48)
roi5 = (0, 192, 320, 48)

vL = (0,   0, 60, 120)
vC = (60, 0, 200, 120)
vR = (260, 0, 60, 120)

ramp_state = "F"

# =========================================================
# FUNCTIONS
# =========================================================
def clamp(v, lo, hi):
    if v < lo:
        return lo
    if v > hi:
        return hi
    return v

def stop():
    PWMA.pulse_width_percent(0)
    PWMB.pulse_width_percent(0)

    AIN1.low()
    AIN2.low()
    BIN1.low()
    BIN2.low()
    STBY.low()

def set_left(speed):
    speed = int(speed)

    if speed > 0:
        AIN1.low()
        AIN2.high()
    elif speed < 0:
        AIN1.high()
        AIN2.low()
    else:
        AIN1.low()
        AIN2.low()

    PWMA.pulse_width_percent(abs(speed))

def set_right(speed):
    speed = int(speed)

    if speed > 0:
        BIN1.high()
        BIN2.low()
    elif speed < 0:
        BIN1.low()
        BIN2.high()
    else:
        BIN1.low()
        BIN2.low()

    PWMB.pulse_width_percent(abs(speed))

def drive(left, right):
    left = clamp(left, -100, 100)
    right = clamp(right, -100, 100)

    STBY.high()
    set_left(left)
    set_right(right)

def get_error(img, roi):
    blobs = img.find_blobs(
        THRESHOLD,
        roi=roi,
        merge=True,
        pixels_threshold=120,
        area_threshold=120
    )

    if blobs:
        b = max(blobs, key=lambda x: x.pixels())
        img.draw_rectangle(b.rect(), color=(255, 0, 0))
        img.draw_cross(b.cx(), b.cy(), color=(0, 255, 0))
        return b.cx() - 160

    return None

def read_ramp_state():
    global ramp_state

    if uart.any():
        try:
            msg = uart.readline()
            if msg:
                msg = msg.decode().strip()
                if msg in ["U", "D", "F"]:
                    ramp_state = msg
        except:
            pass

def get_base_speed():
    if ramp_state == "U":
        return BASE_SPEED_UP
    elif ramp_state == "D":
        return BASE_SPEED_DOWN
    return BASE_SPEED_FLAT

# =========================================================
# MAIN LOOP
# =========================================================
while True:
    clock.tick()
    read_ramp_state()

    img = sensor.snapshot()

    img.draw_rectangle(roi1, color=(0, 0, 255))
    img.draw_rectangle(roi2, color=(0, 0, 255))
    img.draw_rectangle(roi3, color=(0, 0, 255))
    img.draw_rectangle(roi4, color=(0, 0, 255))
    img.draw_rectangle(roi5, color=(0, 0, 255))

    img.draw_rectangle(vL, color=(255, 255, 0))
    img.draw_rectangle(vC, color=(255, 255, 0))
    img.draw_rectangle(vR, color=(255, 255, 0))

    e1 = get_error(img, roi1)
    e2 = get_error(img, roi2)
    e3 = get_error(img, roi3)
    e4 = get_error(img, roi4)
    e5 = get_error(img, roi5)

    total = 0
    weight = 0

    if e1 is not None:
        total += e1 * 1
        weight += 1

    if e2 is not None:
        total += e2 * 2
        weight += 2

    if e3 is not None:
        total += e3 * 3
        weight += 3

    if e4 is not None:
        total += e4 * 4
        weight += 4

    if e5 is not None:
        total += e5 * 5
        weight += 5

    # =====================================================
    # LINE FOUND
    # =====================================================
    if weight > 0:
        error = total / weight

        # If line is found during gap search, start alignment mode
        if gap_mode == 1 or gap_mode == 2:
            gap_mode = 3
            align_count = 0
            print("LINE FOUND AFTER GAP. START ALIGNMENT.")
            continue

        # Mode 3: rotate until line is centered
        if gap_mode == 3:
            if abs(error) <= CENTER_TOLERANCE:
                align_count += 1
                drive(0, 0)

                if align_count >= ALIGN_STABLE_FRAMES:
                    gap_mode = 4
                    gap_timer = time.ticks_ms()
                    align_count = 0
                    print("ALIGNED. FORWARD COMMIT START.")

                else:
                    print("ALIGN STABLE:", align_count, "ERR:", error)

                continue

            else:
                align_count = 0

                # If it turns the wrong way, swap these two drive lines.
                if error > 0:
                    drive(-ALIGN_SPEED, ALIGN_SPEED)
                else:
                    drive(ALIGN_SPEED, -ALIGN_SPEED)

                print("ALIGNING ERR:", error)
                continue

        # Mode 4: force forward after alignment
        if gap_mode == 4:
            drive(FORWARD_COMMIT_SPEED, FORWARD_COMMIT_SPEED)

            if time.ticks_diff(time.ticks_ms(), gap_timer) > FORWARD_COMMIT_TIME:
                gap_mode = 0
                align_count = 0
                print("FORWARD COMMIT DONE. NORMAL FOLLOWING.")
            else:
                print("FORWARD COMMIT WITH LINE")
                continue

        # Normal line following
        turn = error * KP

        base_speed = get_base_speed()

        left_speed = base_speed - turn
        right_speed = base_speed + turn

        left_speed = clamp(left_speed, -85, MAX_SPEED)
        right_speed = clamp(right_speed, -85, MAX_SPEED)

        drive(left_speed, right_speed)

        print("NORMAL",
              "RAMP:", ramp_state,
              "ERR:", error,
              "L:", left_speed,
              "R:", right_speed,
              "FPS:", clock.fps())

    # =====================================================
    # NO LINE FOUND = GAP
    # =====================================================
    else:
        now = time.ticks_ms()

        # first gap detection
        if gap_mode == 0:
            gap_mode = 1
            gap_timer = now
            align_count = 0

            drive(-GAP_BACK_SPEED, -GAP_BACK_SPEED)

            print("GAP DETECTED. BACKING.")
            continue

        # Mode 1: go backward
        if gap_mode == 1:
            drive(-GAP_BACK_SPEED, -GAP_BACK_SPEED)

            if time.ticks_diff(now, gap_timer) > GAP_BACK_TIME:
                gap_mode = 2
                gap_timer = now

            print("GAP MODE 1: BACKING")
            continue

        # Mode 2: go forward slowly
        if gap_mode == 2:
            drive(GAP_FORWARD_SPEED, GAP_FORWARD_SPEED)

            if time.ticks_diff(now, gap_timer) > GAP_FORWARD_TIME:
                gap_mode = 1
                gap_timer = now

            print("GAP MODE 2: FORWARD SEARCH")
            continue

        # Mode 4 safety: if line disappears during forward commit, still move forward
        if gap_mode == 4:
            drive(FORWARD_COMMIT_SPEED, FORWARD_COMMIT_SPEED)

            if time.ticks_diff(now, gap_timer) > FORWARD_COMMIT_TIME:
                gap_mode = 0
                align_count = 0

            print("FORWARD COMMIT WITHOUT LINE")
            continue
