import sensor, image, time, os, math, uos, gc, pyb, math
from pyb import UART
from os import listdir, chdir
from machine import Pin
from time import sleep_ms
import math

sensor.reset()  # Reset and initialize the sensor.
sensor.set_pixformat(sensor.RGB565)  # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)  # Set frame size to QVGA (320x240)
sensor.skip_frames(time=500)  # Wait for settings take effect.
clock = time.clock()  # Create a clock object to track the FPS.


timer = pyb.Timer(4, freq=1000)
enr = timer.channel(1, pyb.Timer.PWM, pin=pyb.Pin('P7'))
r1 = pyb.Pin('P9', pyb.Pin.OUT_PP, pyb.Pin.PULL_NONE)
r2 = pyb.Pin('P2', pyb.Pin.OUT_PP, pyb.Pin.PULL_NONE)
enl = timer.channel(2, pyb.Timer.PWM, pin=pyb.Pin('P8'))
l2 = pyb.Pin('P0', pyb.Pin.OUT_PP, pyb.Pin.PULL_NONE)
l1 = pyb.Pin('P1', pyb.Pin.OUT_PP, pyb.Pin.PULL_NONE)

led_r = pyb.LED(1)
led_r.off()
led_g = pyb.LED(2)
led_g.off()
led_b = pyb.LED(3)
led_b.off()

roi5 = [0,18,320,30]
roi4 = [0,48,320,48]
roi3 = [0,96,320,48]
roi2 = [0,144,320,48]
roi1 = [10,192,300,48]
roif = [135,40,50,50]

def stopMotor():
    r1.value(0)
    r2.value(0)
    l1.value(0)
    l2.value(0)

def tank(p1,p2):
    if p1>50:
        p1=50
    if p1<-50:
        p1=-50
    if p2>50:
        p2=50
    if p2<-50:
        p2=-50
    if p1 > 0:
        l1.value(0)
        l2.value(1)
        enl.pulse_width_percent(abs(p1))
    elif p1 == 0:
        l1.value(0)
        l2.value(0)
    else:
        l1.value(1)
        l2.value(0)
        enl.pulse_width_percent(abs(p1))
    if p2 > 0:
        r1.value(0)
        r2.value(1)
        enr.pulse_width_percent(abs(p2))
    elif p2 == 0:
        r1.value(0)
        r2.value(0)
    else:
        r1.value(1)
        r2.value(0)
        enr.pulse_width_percent(abs(p2))

def steer(s):
    if s<-50:
        r1.value(0)
        r2.value(1)
        enr.pulse_width_percent(100)
        l1.value(1)
        l2.value(0)
        enl.pulse_width_percent(int((s+50)*-2))
    elif s<0:
        r1.value(0)
        r2.value(1)
        enr.pulse_width_percent(100)
        l1.value(0)
        l2.value(1)
        enl.pulse_width_percent(int((s+50)*2))
    elif s==0:
        r1.value(0)
        r2.value(1)
        enr.pulse_width_percent(100)
        l1.value(0)
        l2.value(1)
        enl.pulse_width_percent(100)
    elif s<51:
        r1.value(0)
        r2.value(1)
        enr.pulse_width_percent(int((50-s)*2))
        l1.value(0)
        l2.value(1)
        enl.pulse_width_percent(100)
    else:
        r1.value(1)
        r2.value(0)
        enr.pulse_width_percent(int((s-50)*2))
        l1.value(0)
        l2.value(1)
        enl.pulse_width_percent(100)

d1, d2, d3, d4, d5, s1, s2, s3, s4, s5, w1, w2, w3, w4, w5, cx1, cx2, cx3, cx4, cx5, cxg = 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0

while True:
    d1, d2, d3, d4, d5, w1, w2, w3, w4, w5, cx1, cx2, cx3, cx4, cx5, cxg = 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    s1, s2, s3, s4, s5 = 1,1,1,1,1
    clock.tick()
    img = sensor.snapshot()
    img = img.gamma_corr(gamma=1,contrast=1,brightness=0.1)
    img.lens_corr()
    img.draw_rectangle(roif,color=(255,0,0),thickness=4)
    img.draw_rectangle(roi5,color = (0,0,255),thickness = 2)
    img.draw_rectangle([0,48,320,48],color = (0,0,255),thickness = 2)
    img.draw_rectangle([0,96,320,48],color = (0,0,255),thickness = 2)
    img.draw_rectangle([0,144,320,48],color = (0,0,255),thickness = 2)
    img.draw_rectangle([10,192,300,48],color = (0,0,255),thickness = 2)
    cxg,lg,rg, p_gap, w5 = 0,0,0,0,0
    grn = []

    for blob in img.find_blobs([(10, 55, -40, 25, -20, 40)], merge = True, invert = False,roi = roi5,pixels_threshold=1000):
        img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
        img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
        d5 = blob.cx()- 160 #  * blob.pixels()*0.01
        s5 = blob.w()/blob.h()
        cx5 = blob.cx()
        w5 = blob.w()
        p_gap = 1
    for blob in img.find_blobs([(0, 35, -40, 25, -20, 40)], merge = True, invert = False,roi = roi4,pixels_threshold=1000):
        img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
        img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
        d4 = blob.cx()- 160 #  * blob.pixels()*0.01
        s4 = blob.w()/blob.h()
        w4 = blob.w()
        cx4 = blob.cx()
        p_gap = 1
    for blob in img.find_blobs([(0, 20, -10, 10, -10, 10)], merge = True, invert = False,roi = roi3,pixels_threshold=1200):
        img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
        img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
        d3 = blob.cx()- 160 #  * blob.pixels()*0.01
        s3 = blob.w()/blob.h()
        cx3 = blob.cx()
        w3 = blob.w()
        p_gap=1
    for blob in img.find_blobs([(0, 20, -40, 25, -20, 40)], merge = True, invert = False,roi = roi2,pixels_threshold=1200):
        img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
        img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
        d2 = blob.cx()- 160 #  * blob.pixels()*0.01
        w2 = blob.w()
        s2 = blob.w()/blob.h()
        cx2 = blob.cx()
        p_gap = 1
    for blob in img.find_blobs([(0, 35, -40, 25, -20, 40)], merge = True, invert = False,roi = roi1, pixels_threshold=1200):
        img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
        img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
        d1 = blob.cx()- 160 #  * blob.pixels()*0.01
        s1 = blob.w()/blob.h()
        w1 = blob.w()
        cx1 = blob.cx()
        p_gap = 1

    for blob in img.find_blobs([(25, 80, -50, 0, 0, 50)], merge = True, invert = False,roi = roi4, pixels_threshold=1200):
        img.draw_rectangle(blob.rect(),color = (0,255,0),thickness = 2)
        img.draw_cross(blob.cx(),blob.cy(),(0,0,255),size=10)
        grn.append((blob.cx(),blob.cy()))
        tank(20,20)
        pyb.delay(100)
        img = sensor.snapshot()
        img.lens_corr()
        img = img.gamma_corr(gamma=1,contrast=1,brightness=0.1)
        for blob in img.find_blobs([(25, 80, -50, 0, 0, 50)], merge = True, invert = False,roi = roi4, pixels_threshold=1000):
            img.draw_rectangle(blob.rect(),color = (0,255,0),thickness = 2)
            img.draw_cross(blob.cx(),blob.cy(),(0,0,255),size=10)
            grn.append((blob.cx(),blob.cy()))

    # for blob in img.find_blobs([(19,48,16,52,0,40)], merge = True, invert = False,roi = roi2, pixels_threshold=2000):
    #     img.draw_rectangle(blob.rect(),color = (0,255,0),thickness = 2)
    #     img.draw_cross(blob.cx(),blob.cy(),(0,0,255),size=10)
    #     if blob.w()>200:
    #         led_r.on()
    #         stopMotor()
    #         pyb.delay(123456789)

    print(grn)
    for f in grn:
        print(f[0],cx4)
        if f[0]<cx4:
            lg=1
        else:
            rg=1

    motf = ((d5 - d4) + (d4-d3) + (d3-d2) +(d2 - d1)) + (d4+d3+d2)/4
    #print(d5,s5,d4,s4,d3,s3)

    # if p_gap == 0:
    #     print("Gap")
    #     abc = True
    #     while abc:
    #         tank(-80,-80)
    #         img = sensor.snapshot()
    #         img.lens_corr()
    #         img = img.gamma_corr(gamma=1,contrast=1,brightness=0.1)
    #         for blob in img.find_blobs([(0, 35, -40, 25, -20, 40)], merge = True, invert = False,roi = roi2,pixels_threshold=1200):
    #             img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
    #             img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
    #             abc=False
    #     stopMotor()
    #     pyb.delay(200)
    #     abc = True
    #     a = 0
    #     while abc:
    #         img = sensor.snapshot()
    #         img.lens_corr()
    #         img = img.gamma_corr(gamma=1,contrast=1,brightness=0.1)
    #         for blob in img.find_blobs([(0, 35, -40, 25, -20, 40)], merge = True, invert = False,roi = roi2,pixels_threshold=1200):
    #             img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
    #             img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
    #             d2 = blob.cx()- 160 #  * blob.pixels()*0.01
    #             w2 = blob.w()
    #             s2 = blob.w()/blob.h()
    #             p_gap = 1
    #         for blob in img.find_blobs([(0, 35, -40, 25, -20, 40)], merge = True, invert = False,roi = roi1, pixels_threshold=1200):
    #             img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
    #             img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
    #             d1 = blob.cx()- 160 #  * blob.pixels()*0.01
    #             s1 = blob.w()/blob.h()
    #             p_gap = 1
    #         slope = d2-d1
    #         print("slope", slope)
    #         if slope<0:
    #             tank(-70,70)
    #         else:
    #             tank(70,-70)
    #         if abs(slope)<7:
    #             stopMotor()
    #             abc=False
    #         a += 1
    #         print(a)
    #         if a> 50:
    #             abc = False
    #     stopMotor()
    #     abc = True
    #     a = 0
    #     while a < 25:
    #         a+=1
    #         img = sensor.snapshot()
    #         img.lens_corr()
    #         img = img.gamma_corr(gamma=0.1,contrast=1,brightness=0.1)
    #         for blob in img.find_blobs([(90, 100, -30, 0, -10, 80)], merge = True, invert = False):
    #             img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
    #             img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
    #             print("Rescue")
    #             #Rescue()
    #     while abc:
    #         tank(100,100)
    #         img = sensor.snapshot()
    #         img.lens_corr()
    #         img = img.gamma_corr(gamma=1,contrast=1,brightness=0.1)
    #         for blob in img.find_blobs([(0, 35, -40, 25, -20, 40)], merge = True, invert = False,roi = roi4,pixels_threshold=1200):
    #             img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
    #             img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
    #             abc=False
    #             stopMotor()

    if w3>120 and w5 < 120 and w4 != 0 and (lg == 1 or rg ==1):
        print("After_Green")
        tank(20,20)
        pyb.delay(500)

    elif w3>120 and w5 < 120 and w5 != 0:
        print("Empty_Intersection")
        motf = 2*d5/s5 + d4/s4
        #motf = (((2.5*d1++2*d4+1.5*d5)/6))*((s1++s4+s5)/6)*1.5

    elif w3>120 and lg == 1:
        print("After_Green")
        tank(20,20)
        pyb.delay(200)

    elif w3>120 and rg == 1:
        print("After_Green")
        tank(20,20)
        pyb.delay(200)

    elif rg and lg:
        print("Double_Green")
        tank(20,20)
        pyb.delay(0)
        tank(-100, 100)
        pyb.delay(1700)
        abc = True
        while abc:
            img = sensor.snapshot()
            img.lens_corr()
            img = img.gamma_corr(gamma=1,contrast=1,brightness=0.1)
            tank(-90,90)
            for blob in img.find_blobs([(0, 35, -40, 25, -20, 40)], merge = True, invert = False,roi = roif,pixels_threshold=500):
                img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
                img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
                abc = False
        tank(20,20)
        pyb.delay(150)

    elif lg:
        print("Left_Green")
        stopMotor()
        pyb.delay(100)
        leftgg = True
        while leftgg:
            tank(20, 20)
            bwg = 0

            img3 = sensor.snapshot()
            img3 = img3.gamma_corr(gamma=1, contrast=1, brightness=0.1)
            img3.lens_corr()

            img3.draw_rectangle([30,120,50,50], color=(0, 0, 255), thickness=2)
            img3.draw_rectangle([240,120,50,50], color=(0, 0, 255), thickness=2)

            #img3.draw_rectangle(roi2, color=(255, 0, 0), thickness = 2)

            blobs = img3.find_blobs([(0, 20, -40, 25, -20, 40)], merge=True, invert=False, roi=[30,120,50,50], pixels_threshold=1000)
            blobs2 = img3.find_blobs([(0, 20, -40, 25, -20, 40)], merge=True, invert=False, roi=[240,120,50,50], pixels_threshold=1000)

            for blob in blobs:
                img3.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
                img3.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
                leftgg = False
            for blob in blobs2:
                img3.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
                img3.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
                leftgg = False

        pyb.delay(100)
        tank(-30,30)
        pyb.delay(600)
        abc = True
        a = 0
        while abc:
            a+=1
            img = sensor.snapshot()
            img.lens_corr()
            img = img.gamma_corr(gamma=1,contrast=1,brightness=0.1)
            tank(-30,30)
            for blob in img.find_blobs([(0, 35, -40, 25, -20, 40)], merge = True, invert = False,roi = roif,pixels_threshold=750):
                img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
                img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
                abc = False
        #     if a == 42:
        #         a = 42
        #         abc =False
        # if a == 42:
        #     abc = True
        #     while abc:
        #         img = sensor.snapshot()
        #         img.lens_corr()
        #         img = img.gamma_corr(gamma=1,contrast=1,brightness=0.1)
        #         tank(90,-90)
        #         for blob in img.find_blobs([(0, 35, -40, 25, -20, 40)], merge = True, invert = False,roi = roif,pixels_threshold=750):
        #             img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
        #             img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
        #             abc = False
        tank(20,20)
        pyb.delay(200)

    elif rg:
        print("Right_Green")
        stopMotor()
        rightgg = True
        while rightgg:
            tank(20, 20)
            bwgr = 0

            img4 = sensor.snapshot()
            img4 = img4.gamma_corr(gamma=1, contrast=1, brightness=0.1)
            img4.lens_corr()

            img4.draw_rectangle([0,160,50,50], color=(0, 0, 255), thickness=2)
            img4.draw_rectangle([270,160,50,50], color=(0, 0, 255), thickness=2)

            #img3.draw_rectangle(roi2, color=(255, 0, 0), thickness = 2)

            blobs3 = img4.find_blobs([(0, 20, -40, 25, -20, 40)], merge=True, invert=False, roi=[30,160,50,50], pixels_threshold=1000)
            blobs4 = img4.find_blobs([(0, 20, -40, 25, -20, 40)], merge=True, invert=False, roi=[240,160,50,50], pixels_threshold=1000)

            for blob in blobs3:
                img4.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
                img4.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
                rightgg = False
            for blob in blobs4:
                img4.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
                img4.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
                rightgg = False

        pyb.delay(100)
        tank(30,-30)
        pyb.delay(600)
        pyb.delay(600)
        abc = True
        a = 0
        while abc:
            a+=1
            img = sensor.snapshot()
            img.lens_corr()
            img = img.gamma_corr(gamma=1,contrast=1,brightness=0.1)
            tank(30,-30)
            for blob in img.find_blobs([(0, 35, -40, 25, -20, 40)], merge = True, invert = False,roi = roif,pixels_threshold=750):
                img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
                img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
                abc = False
        #     if a == 42:
        #         a = 42
        #         abc =False
        # if a == 42:
        #     abc = True
        #     while abc:
        #         img = sensor.snapshot()
        #         img.lens_corr()
        #         img = img.gamma_corr(gamma=1,contrast=1,brightness=0.1)
        #         tank(-90,90)
        #         for blob in img.find_blobs([(0, 35, -40, 25, -20, 40)], merge = True, invert = False,roi = roif,pixels_threshold=750):
        #             img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
        #             img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
        #             abc = False
        tank(20,20)
        pyb.delay(100)

    led_b.off()
    #steer(motf)
    motf  = int(motf)
    tank(35+motf,35-motf)

    #pyb.delay(motf)
    print(motf)
