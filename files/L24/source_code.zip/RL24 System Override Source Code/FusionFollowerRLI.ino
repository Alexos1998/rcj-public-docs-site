#define ena 10
#define enb 9
#define a1 7
#define a2 8
#define b1 5
#define b2 6

#include <Adafruit_NeoPixel.h>
#ifdef __AVR__
  #include <avr/power.h>
#endif

#define PIN            11

#define NUMPIXELS      16

Adafruit_NeoPixel pixels = Adafruit_NeoPixel(NUMPIXELS, PIN, NEO_GRB + NEO_KHZ800);

int delayval = 1; // delay for half a second

void tank(int b_speed, int a_speed){

  if(a_speed<-255) a_speed = -255;
  if(a_speed>255) a_speed = 255;
  if(b_speed<-255) b_speed = -255;
  if(b_speed>255) b_speed = 255;

  if(a_speed<0){
    analogWrite(ena,-a_speed);
    digitalWrite(a1,0);
    digitalWrite(a2,1);
  }else{
    analogWrite(ena,a_speed);
    digitalWrite(a1,1);
    digitalWrite(a2,0);
  }
  if(b_speed<0){
    //bsp = map(bsp,0,-255,-150,-255);
    analogWrite(enb,-b_speed);
    digitalWrite(b1,0);
    digitalWrite(b2,1);
  }else{
    //bsp = map(bsp,0,255,200,255);
    analogWrite(enb,b_speed);
    digitalWrite(b1,1);
    digitalWrite(b2,0);
  }
  
}

void stop(){
  digitalWrite(a1, 0);
  digitalWrite(a2, 0);
  digitalWrite(b1, 0);
  digitalWrite(b2, 0);
  digitalWrite(ena, 0);
  digitalWrite(enb, 0);
}

void setup() {
  Serial.begin(9600);
  pinMode(ena, 1);
  pinMode(enb, 1);
  pinMode(a1, 1);
  pinMode(a2, 1);
  pinMode(b1, 1);
  pinMode(b2, 1);
  pinMode(2,0);
  pinMode(3, 0);
  pinMode(4, 0);

  pixels.begin(); // This initializes the NeoPixel library.
  pixels.setBrightness(250);  // Brightness from 0 (off) to 255 (max)

for(int i=0;i<NUMPIXELS;i++){

    // pixels.Color takes RGB values, from 0,0,0 up to 255,255,255
    pixels.setPixelColor(i, pixels.Color(100,250,100)); // Moderately bright green color.

    pixels.show(); // This sends the updated pixel color to the hardware.

    delay(delayval); // Delay for a period of time (in milliseconds).
  }
}


int s1=0, s2=0, s3=0, s4=0, s5=0, s6=0, s7=0, s8=0;
int d2 = 0, d3 = 0, d4 = 0;

void loop() {
  // for(int i=0;i<NUMPIXELS;i++){

  //   // pixels.Color takes RGB values, from 0,0,0 up to 255,255,255
  //   pixels.setPixelColor(i, pixels.Color(100,250,100)); // Moderately bright green color.

  //   pixels.show(); // This sends the updated pixel color to the hardware.

  //   delay(delayval); // Delay for a period of time (in milliseconds).
  // }

  //s1 = analogRead(A0);
  s2 = analogRead(A1);
  s3 = analogRead(A2);
  s4 = analogRead(A3);
  s5 = analogRead(A0);
  s6 = analogRead(A7);
  s7 = analogRead(A6);
  //s8 = analogRead(A7);

  d2 = digitalRead(2);
  d3 = digitalRead(3);
  d4 = digitalRead(4);

  //Serial.println(String(s2) + " " + String(s3) + " " + String(s4) + " " + String(s5) + " " + String(s6) + " " + String(s7));

  int silver = (s2 + s4 + s5);
  //Serial.println(silver<150);

  int TH = 600;

  int blackCount =
    (s1 > TH) + (s2 > TH) + (s3 > TH) + (s4 > TH) +
    (s5 > TH) + (s6 > TH) + (s7 > TH) + (s8 > TH);

  if (blackCount >= 6) {
    Serial.println("Intersection");
    tank(80, 80);
    delay(250);
    return;
  }
  int sum = s3 + s4 + s5 + s6;
  //float kp = pow(1.1,1000/(sum-500));
  int corr = -(2*s2+2*s3+1*s4-1*s5-2*s6-2*s7)/4.5;
  //Serial.println(String(sum));

  /*
  if sum is big: lower correction
  if sum is lowe: higher correction
  */
  


  tank(90+corr, 90-corr);
  delay(1);

  //Serial.println(kp);
  if(silver<107){
    stop();
    Serial.println("SILVER");
    delay(10000);
    
  }
  if(d3>0 || d4>0){
    Serial.println("Green");
    stop();
    tank(50, 50);
    delay(100);

    d2 = digitalRead(2);
    d3 = digitalRead(3);
    d4 = digitalRead(4);

    if(d3>0 && d4>0){
      Serial.println("U Turn");
      tank(100, 100);
      delay(500);
      tank(-100, 100);
      delay(1800);
      while(analogRead(A0)<300);
      stop();
    }
    else if(d3>0){
      Serial.println("Left Turn");
      tank(100,100);
      delay(700);
      tank(-100, 100);
      while((s2<300) && (s7<300));
      delay(500);
      while(analogRead(A0)<300);
      stop();
    }
    else if(d4>0){
      Serial.println("Right Turn");
      tank(100,100);
      delay(700);
      tank(100, -100);
      delay(900);
      while(analogRead(A3)<300);
      stop();
    }
    else if(d2>0){
      Serial.println("After Green / Intersection");
      tank(100,100);
      while((s2<300) && (s7<300));
      while((s2>200) || (s7>200));
      delay(500);
      stop();
    }

    delay(500);
  }
}


