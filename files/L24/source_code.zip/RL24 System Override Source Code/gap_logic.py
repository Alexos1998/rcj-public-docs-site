# =========================================================
# OPENMV H7+ 5-ROI LINE FOLLOWER + GYRO/UART + GAP RECOVERY
# TB6612FNG
# =========================================================

import sensor, image, time
from pyb import Pin, Timer, UART

# =========================================================
# CAMERA
# =========================================================
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.set_windowing((320, 240))
sensor.skip_frames(time=2000)

sensor.set_vflip(True)
sensor.set_hmirror(True)

sensor.set_auto_gain(True)
sensor.set_auto_whitebal(True)

clock = time.clock()

# =========================================================
# UART FROM PICO / GYRO
# =========================================================
uart = UART(1, 115200, timeout_char=10)
ramp_state = "F"

# =========================================================
# MOTOR PINS
# =========================================================
AIN1 = Pin("P2", Pin.OUT_PP)
AIN2 = Pin("P9", Pin.OUT_PP)

BIN1 = Pin("P4", Pin.OUT_PP)
BIN2 = Pin("P5", Pin.OUT_PP)

STBY = Pin("P3", Pin.OUT_PP)

timer = Timer(4, freq=1000)
PWMA = timer.channel(1, Timer.PWM, pin=Pin("P7"))
PWMB = timer.channel(2, Timer.PWM, pin=Pin("P8"))

# =========================================================
# SPEED SETTINGS
# =========================================================
BASE_SPEED_FLAT = 55
BASE_SPEED_UP   = 65
BASE_SPEED_DOWN = 32

MAX_SPEED = 80
KP = 1.2

THRESHOLD = [(0, 25, -20, 5, -5, 20)]

# =========================================================
# GAP RECOVERY SETTINGS
# =========================================================
GAP_BACK_SPEED = 27
GAP_FORWARD_SPEED = 27
ALIGN_SPEED = 25

GAP_BACK_TIME = 300
GAP_FORWARD_TIME = 400

CENTER_TOLERANCE = 20
ALIGN_STABLE_FRAMES = 3

FORWARD_COMMIT_SPEED = 40

MAX_ALIGN_ATTEMPTS = 8

gap_mode = 0
gap_timer = time.ticks_ms()
align_count = 0
gap_attempts = 0

# gap_mode:
# 0 = normal line following
# 1 = backward alignment attempt
# 2 = forward alignment attempt
# 3 = commit forward until center line found

roi1 = (0,   0, 320, 48)
roi2 = (0,  48, 320, 48)
roi3 = (0,  96, 320, 48)
roi4 = (0, 144, 320, 48)
roi5 = (0, 192, 320, 48)

vL = (0,   0, 60, 120)
vC = (60, 0, 200, 120)
vR = (260, 0, 60, 120)

# centre-ish recovery region only
CENTER_FIND_ROI = (90, 96, 140, 144)

def clamp(v, lo, hi):
    if v < lo:
        return lo
    if v > hi:
        return hi
    return v

def stop():
    PWMA.pulse_width_percent(0)
    PWMB.pulse_width_percent(0)

    AIN1.low()
    AIN2.low()
    BIN1.low()
    BIN2.low()
    STBY.low()

def set_left(speed):
    speed = int(speed)

    if speed > 0:
        AIN1.low()
        AIN2.high()
    elif speed < 0:
        AIN1.high()
        AIN2.low()
    else:
        AIN1.low()
        AIN2.low()

    PWMA.pulse_width_percent(abs(speed))

def set_right(speed):
    speed = int(speed)

    if speed > 0:
        BIN1.high()
        BIN2.low()
    elif speed < 0:
        BIN1.low()
        BIN2.high()
    else:
        BIN1.low()
        BIN2.low()

    PWMB.pulse_width_percent(abs(speed))

def drive(left, right):
    left = clamp(left, -100, 100)
    right = clamp(right, -100, 100)

    STBY.high()
    set_left(left)
    set_right(right)

def read_ramp_state():
    global ramp_state

    if uart.any():
        try:
            msg = uart.readline()
            if msg:
                msg = msg.decode().strip()

                if msg in ["U", "D", "F"]:
                    ramp_state = msg

        except:
            pass

def get_base_speed():
    if ramp_state == "U":
        return BASE_SPEED_UP
    elif ramp_state == "D":
        return BASE_SPEED_DOWN
    else:
        return BASE_SPEED_FLAT

def get_error(img, roi):
    blobs = img.find_blobs(
        THRESHOLD,
        roi=roi,
        merge=True,
        pixels_threshold=120,
        area_threshold=120
    )

    if blobs:
        b = max(blobs, key=lambda x: x.pixels())

        img.draw_rectangle(b.rect(), color=(255, 0, 0))
        img.draw_cross(b.cx(), b.cy(), color=(0, 255, 0))

        return b.cx() - 160
    else:
        return None

def get_center_error(img):
    blobs = img.find_blobs(
        THRESHOLD,
        roi=CENTER_FIND_ROI,
        merge=True,
        pixels_threshold=80,
        area_threshold=80
    )

    if blobs:
        b = max(blobs, key=lambda x: x.pixels())

        img.draw_rectangle(b.rect(), color=(0, 255, 255))
        img.draw_cross(b.cx(), b.cy(), color=(255, 255, 255))

        return b.cx() - 160
    else:
        return None

def normal_follow(error):
    turn = error * KP
    base_speed = get_base_speed()

    left_speed  = base_speed - turn
    right_speed = base_speed + turn

    left_speed  = clamp(left_speed, -85, MAX_SPEED)
    right_speed = clamp(right_speed, -85, MAX_SPEED)

    drive(left_speed, right_speed)

    print("NORMAL",
          "RAMP:", ramp_state,
          "BASE:", base_speed,
          "ERR:", error,
          "L:", left_speed,
          "R:", right_speed,
          "FPS:", clock.fps())

# =========================================================
# MAIN LOOP
# =========================================================
while True:

    clock.tick()
    read_ramp_state()

    img = sensor.snapshot()

    img.draw_rectangle(roi1, color=(0,0,255))
    img.draw_rectangle(roi2, color=(0,0,255))
    img.draw_rectangle(roi3, color=(0,0,255))
    img.draw_rectangle(roi4, color=(0,0,255))
    img.draw_rectangle(roi5, color=(0,0,255))

    img.draw_rectangle(vL, color=(255,255,0))
    img.draw_rectangle(vC, color=(255,255,0))
    img.draw_rectangle(vR, color=(255,255,0))

    img.draw_rectangle(CENTER_FIND_ROI, color=(0,255,255))

    e1 = get_error(img, roi1)
    e2 = get_error(img, roi2)
    e3 = get_error(img, roi3)
    e4 = get_error(img, roi4)
    e5 = get_error(img, roi5)

    total = 0
    weight = 0

    if e1 is not None:
        total += e1 * 1
        weight += 1

    if e2 is not None:
        total += e2 * 2
        weight += 2

    if e3 is not None:
        total += e3 * 3
        weight += 3

    if e4 is not None:
        total += e4 * 4
        weight += 4

    if e5 is not None:
        total += e5 * 5
        weight += 5

    line_seen = weight > 0
    center_error = get_center_error(img)

    # =====================================================
    # NORMAL MODE
    # =====================================================
    if gap_mode == 0:

        if line_seen:
            error = total / weight
            normal_follow(error)

        else:
            gap_mode = 1
            gap_timer = time.ticks_ms()
            align_count = 0
            gap_attempts = 0

            drive(-GAP_BACK_SPEED, -GAP_BACK_SPEED)
            print("GAP START: BACK")

    # =====================================================
    # GAP MODE 1: GO BACKWARD AND TRY TO CENTRE
    # =====================================================
    elif gap_mode == 1:

        if center_error is not None and abs(center_error) < CENTER_TOLERANCE:
            align_count += 1
        else:
            align_count = 0

        if align_count >= ALIGN_STABLE_FRAMES:
            gap_mode = 3
            gap_timer = time.ticks_ms()
            print("CENTERED: COMMIT FORWARD")

        elif time.ticks_diff(time.ticks_ms(), gap_timer) > GAP_BACK_TIME:
            gap_mode = 2
            gap_timer = time.ticks_ms()
            gap_attempts += 1
            drive(GAP_FORWARD_SPEED, GAP_FORWARD_SPEED)
            print("GAP: FORWARD ALIGN ATTEMPT", gap_attempts)

        else:
            if center_error is not None:
                turn = center_error * 0.5
                drive(-GAP_BACK_SPEED + turn, -GAP_BACK_SPEED - turn)
            else:
                drive(-GAP_BACK_SPEED, -GAP_BACK_SPEED)

    # =====================================================
    # GAP MODE 2: GO FORWARD AND TRY TO CENTRE
    # =====================================================
    elif gap_mode == 2:

        if center_error is not None and abs(center_error) < CENTER_TOLERANCE:
            align_count += 1
        else:
            align_count = 0

        if align_count >= ALIGN_STABLE_FRAMES:
            gap_mode = 3
            gap_timer = time.ticks_ms()
            print("CENTERED: COMMIT FORWARD")

        elif time.ticks_diff(time.ticks_ms(), gap_timer) > GAP_FORWARD_TIME:
            if gap_attempts >= MAX_ALIGN_ATTEMPTS:
                gap_mode = 3
                gap_timer = time.ticks_ms()
                print("MAX ATTEMPTS: FORCE COMMIT FORWARD")
            else:
                gap_mode = 1
                gap_timer = time.ticks_ms()
                drive(-GAP_BACK_SPEED, -GAP_BACK_SPEED)
                print("GAP: BACK ALIGN ATTEMPT", gap_attempts)

        else:
            if center_error is not None:
                turn = center_error * 0.5
                drive(GAP_FORWARD_SPEED - turn, GAP_FORWARD_SPEED + turn)
            else:
                drive(GAP_FORWARD_SPEED, GAP_FORWARD_SPEED)

    # =====================================================
    # GAP MODE 3: GO FORWARD UNTIL LINE FOUND IN CENTRE
    # =====================================================
    elif gap_mode == 3:

        if center_error is not None and abs(center_error) < CENTER_TOLERANCE:
            gap_mode = 0
            align_count = 0
            gap_attempts = 0

            print("GAP RECOVERED: NORMAL MODE")

            # soft resume
            normal_follow(center_error)

        else:
            drive(FORWARD_COMMIT_SPEED, FORWARD_COMMIT_SPEED)
            print("COMMIT FORWARD: SEARCHING CENTRE LINE",
                  "CENTER_ERR:", center_error,
                  "FPS:", clock.fps())
