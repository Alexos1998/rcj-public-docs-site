from pyb import I2C
import time

SLAVE_ADDR = 0x12

i2c = I2C(2, I2C.SLAVE, addr=SLAVE_ADDR)

print("OpenMV I2C slave ready")

while True:
    try:
        data = i2c.recv(2, timeout=100)

        if data:
            msg = data.decode().strip()
            print(msg)

    except Exception as e:
        pass

    time.sleep_ms(10)
