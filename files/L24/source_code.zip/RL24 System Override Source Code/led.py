import pyb
import time

# Create an LED object (3 is Blue)
blue_led = pyb.LED(3)

# Ensure it's in a known off-state to begin with
blue_led.off()

while True:
    # Turn the LED on
    blue_led.on()
    time.sleep_ms(1000)

    # Turn the LED off
    blue_led.off()
    time.sleep_ms(1000)
