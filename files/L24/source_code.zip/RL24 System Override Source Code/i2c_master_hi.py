import time
from machine import I2C

# 1. Initialize OpenMV as I2C Master
# '2' selects Hardware I2C Bus 2.
# On most OpenMV Cams (like H7/RT1062): SCL is Pin P5, SDA is Pin P4.
# We set a lower 10kHz frequency to match the software-sampled Pico slave.
i2c = I2C(2, freq=10000)

# 2. Match the Target Address configured on the Pico
SLAVE_ADDR = 0x12

print("OpenMV Master running. Sending data...")

while True:
    try:
        # Define the payload as raw bytes (prefix string with b)
        payload = b"Hello Pico"

        # Write bytes over the I2C bus to the target address
        i2c.writeto(SLAVE_ADDR, payload)
        print("Successfully sent:", payload.decode('utf-8'))

    except OSError as e:
        # Catches [Errno 5] EIO if wires are disconnected or Pico is busy
        print("Transmission failed. Checking physical link... Error:", e)

    # Wait two seconds before sending the next message
    time.sleep(2)
