from pyb import I2C
import time


# OPENMV I2C SLAVE
# P4 = SDA
# P5 = SCL


SLAVE_ADDR = 0x12

i2c = I2C(
    2,
    I2C.SLAVE,
    addr=SLAVE_ADDR
)

print("OpenMV I2C slave ready")

while True:

    try:
        data = i2c.recv(64, timeout=100)

        if data:

            try:
                msg = data.decode().strip()

            except:
                msg = str(data)

            print("RECEIVED:", msg)

            # Optional parsing
            parts = msg.split(",")

            gx = 0
            gy = 0
            gz = 0

            for p in parts:

                if p.startswith("GX:"):
                    gx = float(p[3:])

                elif p.startswith("GY:"):
                    gy = float(p[3:])

                elif p.startswith("GZ:"):
                    gz = float(p[3:])

            print("GX =", gx)
            print("GY =", gy)
            print("GZ =", gz)

    except Exception as e:
        print("I2C Error:", e)

    time.sleep_ms(10)
