# =========================================
# OPENMV H7+ LINE FOLLOWING
# SIDE AVERAGE + LOCKED TURN MODE
# =========================================

import sensor, image, time
from pyb import Pin, Timer, UART

# =========================================
# CAMERA
# =========================================

sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.set_windowing((320, 240))
sensor.skip_frames(time=2000)

sensor.set_vflip(True)
sensor.set_hmirror(True)

sensor.set_auto_gain(True)
sensor.set_auto_whitebal(True)

clock = time.clock()

# =========================================
# UART
# =========================================

uart = UART(1, 115200, timeout_char=10)
ramp_state = "F"

# =========================================
# MOTOR PINS
# =========================================

AIN1 = Pin("P2", Pin.OUT_PP)
AIN2 = Pin("P9", Pin.OUT_PP)

BIN1 = Pin("P4", Pin.OUT_PP)
BIN2 = Pin("P5", Pin.OUT_PP)

STBY = Pin("P3", Pin.OUT_PP)

timer = Timer(4, freq=1000)

PWMA = timer.channel(1, Timer.PWM, pin=Pin("P7"))
PWMB = timer.channel(2, Timer.PWM, pin=Pin("P8"))

# =========================================
# SPEEDS
# =========================================

BASE_SPEED_FLAT = 45
BASE_SPEED_UP   = 65
BASE_SPEED_DOWN = 31

MAX_SPEED = 60
KP = 1

# =========================================
# TURN SETTINGS
# =========================================


TURN_SPEED = 43

MIN_TURN_TIME = 650
MAX_TURN_TIME = 1500
REACQUIRE_THRESHOLD = 450

SIDE_AVG_THRESHOLD = 180
SIDE_DIFF_THRESHOLD = 120
BOTTOM_LINE_THRESHOLD = 160

turn_mode = None
turn_start_time = 0

# =========================================
# THRESHOLD
# =========================================

THRESHOLD = [(0, 20, -20, 5, -5, 20)]

# =========================================
# NORMAL 5 HORIZONTAL ROIS
# =========================================

roi1 = (0,   0, 320, 48)
roi2 = (0,  48, 320, 48)
roi3 = (0,  96, 320, 48)
roi4 = (0, 144, 320, 48)
roi5 = (0, 192, 320, 48)

# =========================================
# LEFT SIDE 3 ROIS: A, B, C
# RIGHT SIDE 3 ROIS: X, Y, Z
# =========================================

LEFT_A = (0,  72, 90, 40)
LEFT_B = (0, 112, 90, 40)
LEFT_C = (0, 152, 90, 40)

RIGHT_X = (230,  72, 90, 40)
RIGHT_Y = (230, 112, 90, 40)
RIGHT_Z = (230, 152, 90, 40)

# Used to decide whether main/front line is still present
BOTTOM_CHECK_ROI = (80, 170, 160, 70)

# =========================================
# UTILS
# =========================================

def clamp(v, lo, hi):
    if v < lo:
        return lo
    if v > hi:
        return hi
    return v

# =========================================
# MOTOR CONTROL
# =========================================

def stop():

    PWMA.pulse_width_percent(0)
    PWMB.pulse_width_percent(0)

    AIN1.low()
    AIN2.low()

    BIN1.low()
    BIN2.low()

    STBY.low()

# A MOTOR = RIGHT
# B MOTOR = LEFT

def right_motor(speed):

    speed = int(speed)

    if speed > 0:
        AIN1.low()
        AIN2.high()

    elif speed < 0:
        AIN1.high()
        AIN2.low()

    else:
        AIN1.low()
        AIN2.low()

    PWMA.pulse_width_percent(abs(speed))

def left_motor(speed):

    speed = int(speed)

    if speed > 0:
        BIN1.high()
        BIN2.low()

    elif speed < 0:
        BIN1.low()
        BIN2.high()

    else:
        BIN1.low()
        BIN2.low()

    PWMB.pulse_width_percent(abs(speed))

def drive(left, right):

    STBY.high()

    left_motor(left)
    right_motor(right)

# =========================================
# UART RAMP READING
# =========================================

def read_ramp_state():

    global ramp_state

    if uart.any():

        try:
            msg = uart.readline()

            if msg:

                msg = msg.decode().strip()

                if msg in ["U", "D", "F"]:
                    ramp_state = msg

        except:
            pass

def get_base_speed():

    if ramp_state == "U":
        return BASE_SPEED_UP

    elif ramp_state == "D":
        return BASE_SPEED_DOWN

    else:
        return BASE_SPEED_FLAT

# =========================================
# BLOB FUNCTIONS
# =========================================

def get_error(img, roi):

    blobs = img.find_blobs(
        THRESHOLD,
        roi=roi,
        merge=True,
        pixels_threshold=120,
        area_threshold=120
    )

    if blobs:

        b = max(blobs, key=lambda x: x.pixels())

        img.draw_rectangle(b.rect(), color=(255,0,0))
        img.draw_cross(b.cx(), b.cy(), color=(0,255,0))

        return b.cx() - 160

    else:
        return None

def get_pixels(img, roi):

    blobs = img.find_blobs(
        THRESHOLD,
        roi=roi,
        merge=True,
        pixels_threshold=50,
        area_threshold=50
    )

    total_pixels = 0

    for b in blobs:
        total_pixels += b.pixels()
        img.draw_rectangle(b.rect(), color=(255,255,0))

    return total_pixels

# =========================================
# LEFT / RIGHT AVERAGE DECISION
# =========================================

def get_side_direction(img):

    A = get_pixels(img, LEFT_A)
    B = get_pixels(img, LEFT_B)
    C = get_pixels(img, LEFT_C)

    X = get_pixels(img, RIGHT_X)
    Y = get_pixels(img, RIGHT_Y)
    Z = get_pixels(img, RIGHT_Z)

    P = (A + B + C) / 3
    Q = (X + Y + Z) / 3

    diff = P - Q

    direction = None

    if P > SIDE_AVG_THRESHOLD or Q > SIDE_AVG_THRESHOLD:

        if diff > SIDE_DIFF_THRESHOLD:
            direction = "LEFT"

        elif diff < -SIDE_DIFF_THRESHOLD:
            direction = "RIGHT"

    return direction, P, Q, A, B, C, X, Y, Z

# =========================================
# MAIN LOOP
# =========================================

while True:

    clock.tick()
    read_ramp_state()

    img = sensor.snapshot()

    # Draw normal ROIs
    img.draw_rectangle(roi1, color=(0,0,255))
    img.draw_rectangle(roi2, color=(0,0,255))
    img.draw_rectangle(roi3, color=(0,0,255))
    img.draw_rectangle(roi4, color=(0,0,255))
    img.draw_rectangle(roi5, color=(0,0,255))

    # Draw left A/B/C ROIs
    img.draw_rectangle(LEFT_A, color=(255,0,255))
    img.draw_rectangle(LEFT_B, color=(255,0,255))
    img.draw_rectangle(LEFT_C, color=(255,0,255))

    # Draw right X/Y/Z ROIs
    img.draw_rectangle(RIGHT_X, color=(255,0,255))
    img.draw_rectangle(RIGHT_Y, color=(255,0,255))
    img.draw_rectangle(RIGHT_Z, color=(255,0,255))

    # Draw bottom checking ROI
    img.draw_rectangle(BOTTOM_CHECK_ROI, color=(0,255,255))

    bottom_pixels = get_pixels(img, BOTTOM_CHECK_ROI)

    side_direction, P, Q, A, B, C, X, Y, Z = get_side_direction(img)

    now = time.ticks_ms()

    # =====================================
    # LOCKED TURN MODE
    # Once LEFT/RIGHT is selected,
    # ignore P/Q until line is reacquired.
    # =====================================

    if turn_mode is not None:

        elapsed = time.ticks_diff(now, turn_start_time)

        if turn_mode == "LEFT":
            drive(TURN_SPEED, -TURN_SPEED)

        elif turn_mode == "RIGHT":
            drive(-TURN_SPEED, TURN_SPEED)

        print(
            "LOCKED TURN:",
            turn_mode,
            "ELAPSED:", elapsed,
            "BOTTOM:", bottom_pixels,
            "P:", P,
            "Q:", Q,
            "FPS:", clock.fps()
        )

        if elapsed > MIN_TURN_TIME and bottom_pixels > REACQUIRE_THRESHOLD:
            turn_mode = None
            print("LINE REACQUIRED - NORMAL FOLLOW")

        elif elapsed > MAX_TURN_TIME:
            turn_mode = None
            print("TURN TIMEOUT - NORMAL FOLLOW")

        continue

    # =====================================
    # SAFE TURN DETECTION
    # Only lock a turn when front/bottom line is weak.
    # =====================================

    bottom_line_is_weak = bottom_pixels < BOTTOM_LINE_THRESHOLD

    if bottom_line_is_weak and side_direction is not None:

        turn_mode = side_direction
        turn_start_time = time.ticks_ms()

        print(
            "TURN LOCKED:",
            turn_mode,
            "P:", P,
            "Q:", Q,
            "A:", A,
            "B:", B,
            "C:", C,
            "X:", X,
            "Y:", Y,
            "Z:", Z,
            "BOTTOM:", bottom_pixels
        )

        continue

    # =====================================
    # NORMAL LINE FOLLOWING
    # =====================================

    e1 = get_error(img, roi1)
    e2 = get_error(img, roi2)
    e3 = get_error(img, roi3)
    e4 = get_error(img, roi4)
    e5 = get_error(img, roi5)

    total = 0
    weight = 0

    if e1 is not None:
        total += e1 * 1
        weight += 1

    if e2 is not None:
        total += e2 * 2
        weight += 2

    if e3 is not None:
        total += e3 * 3
        weight += 3

    if e4 is not None:
        total += e4 * 4
        weight += 4

    if e5 is not None:
        total += e5 * 5
        weight += 5

    if weight > 0:

        error = total / weight

        turn = error * KP

        base_speed = get_base_speed()

        left_speed  = -(base_speed - turn)
        right_speed = -(base_speed + turn)

        left_speed  = clamp(left_speed, -MAX_SPEED, MAX_SPEED)
        right_speed = clamp(right_speed, -MAX_SPEED, MAX_SPEED)

        drive(left_speed, right_speed)

        print(
            "NORMAL",
            "ERR:", error,
            "P:", P,
            "Q:", Q,
            "BOTTOM:", bottom_pixels,
            "DIR:", side_direction,
            "L:", left_speed,
            "R:", right_speed,
            "FPS:", clock.fps()
        )

    else:

        stop()

        print(
            "NO LINE",
            "P:", P,
            "Q:", Q,
            "DIR:", side_direction,
            "BOTTOM:", bottom_pixels,
            "FPS:", clock.fps()
        )
