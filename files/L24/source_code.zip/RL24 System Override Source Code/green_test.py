import sensor, image, time, os, math, uos, gc, pyb, math
from pyb import UART
from os import listdir, chdir
from machine import Pin
from time import sleep_ms
import math
import struct


sensor.reset()  # Reset and initialize the sensor.
sensor.set_pixformat(sensor.RGB565)  # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)  # Set frame size to QVGA (320x240)
sensor.set_windowing(340, 180)
sensor.skip_frames(time=1000)  # Wait for settings take effect.
clock = time.clock()  # Create a clock object to track the FPS.
sensor.set_vflip(True)
sensor.set_hmirror(True)

uart = UART(3, 115200, timeout_char=1)

pitch_angle = 0
roll_angle = 0
ramp_state = "FLAT"

UPHILL_THRESHOLD = 10
DOWNHILL_THRESHOLD = -10

buff = ""

speed=65

def stopMotor():
    r1.value(0)
    r2.value(0)
    l1.value(0)
    l2.value(0)

def tank(p1,p2):
    if p1 > 0:
        l1.value(0)
        l2.value(1)
        enl.pulse_width_percent(abs(p1))
    elif p1 == 0:
        l1.value(0)
        l2.value(0)
    else:
        l1.value(1)
        l2.value(0)
        enl.pulse_width_percent(abs(p1))
    if p2 > 0:
        r1.value(0)
        r2.value(1)
        enr.pulse_width_percent(abs(p2))
    elif p2 == 0:
        r1.value(0)
        r2.value(0)
    else:
        r1.value(1)
        r2.value(0)
        enr.pulse_width_percent(abs(p2))
def steer(s):
    if s< -100:
        s=-100
    if s> 100:
        s=100
    if s<-50:
        r1.value(0)
        r2.value(1)
        enr.pulse_width_percent(speed)  # speed
        l1.value(1)
        l2.value(0)
        enl.pulse_width_percent(int((s+25)*-2))
    elif s<0:
        r1.value(0)
        r2.value(1)
        enr.pulse_width_percent(speed)
        l1.value(0)
        l2.value(1)
        enl.pulse_width_percent(int((s+25)*2))
    elif s==0:
        r1.value(0)
        r2.value(1)
        enr.pulse_width_percent(speed)
        l1.value(0)
        l2.value(1)
        enl.pulse_width_percent(speed)
    elif s<51:
        r1.value(0)
        r2.value(1)
        enr.pulse_width_percent(int((25-s)*2))
        l1.value(0)
        l2.value(1)
        enl.pulse_width_percent(speed)
    else:
        r1.value(1)
        r2.value(0)
        enr.pulse_width_percent(int((s-25)*2))
        l1.value(0)
        l2.value(1)
        enl.pulse_width_percent(speed)


#  motor pins

timer = pyb.Timer(4, freq=1000)
enr = timer.channel(1, pyb.Timer.PWM, pin=pyb.Pin('P7'))
r1 = pyb.Pin('P9', pyb.Pin.OUT_PP, pyb.Pin.PULL_NONE)
r2 = pyb.Pin('P2', pyb.Pin.OUT_PP, pyb.Pin.PULL_NONE)
enl = timer.channel(2, pyb.Timer.PWM, pin=pyb.Pin('P8'))
l2 = pyb.Pin('P0', pyb.Pin.OUT_PP, pyb.Pin.PULL_NONE)
l1 = pyb.Pin('P1', pyb.Pin.OUT_PP, pyb.Pin.PULL_NONE)
STBY = Pin("P3", Pin.OUT_PP)

STBY.high()
#       x,  y,  l,  h
roi1 = [30, 0, 260, 45]
roi2 = [0, 45, 320, 45]
roi3 = [0, 90, 320, 45]
roi4 = [30, 135, 260, 45]
# roi5 = [30, 180, 260, 45]
roi6 = [30, 30, 260, 50]
roi7 = [30, 80, 260, 50]
roi8 = [30, 130, 260, 50]




# [low_l,low_h,low_l,low_h,low_l,low_h]
black = [(0, 20, -15, 0, 0, 16)]


# GREEN THRESHOLD
green = [(40, 70, -50, -25, 25, 45)]

# FRONT GREEN ROI
green_roi = [0, 100, 320, 80]

green_state = "NONE"



# uart = UART(3, 115200, timeout_char=1)

gyro_value = 0.0

def read_gyro_uart():
    global gyro_value

    while uart.any() >= 4:
        data = uart.read(4)
        try:
            gyro_value = struct.unpack("<f", data)[0]
        except:
            pass

while True:

    img = sensor.snapshot()


    read_gyro_uart()
    time.sleep_ms(1)

    ramp_value = gyro_value

    if ramp_value > UPHILL_THRESHOLD:
        ramp_state = "D"
    elif ramp_value < DOWNHILL_THRESHOLD:
        ramp_state = "U"
    else:
        ramp_state = "F"

    # =========================================
    # GREEN DETECTION
    # =========================================

    green_state = "NONE"

    img.draw_rectangle(green_roi, color=(0,255,0), thickness=2)

    green_blobs = img.find_blobs(
        green,
        roi=green_roi,
        merge=False,
        pixels_threshold=80,
        area_threshold=80
    )

    left_green = False
    right_green = False

    for blob in green_blobs:

        if blob.area() < 80:
            continue

        img.draw_rectangle(blob.rect(), color=(0,255,0), thickness=2)
        img.draw_cross(blob.cx(), blob.cy(), color=(0,255,0), size=10)

        # LEFT SIDE
        if blob.cx() < 140:
            left_green = True

        # RIGHT SIDE
        elif blob.cx() > 180:
            right_green = True

    # =========================================
    # GREEN LOGIC
    # =========================================

    if left_green and right_green:
        green_state = "DOUBLE"

    elif left_green:
        green_state = "LEFT"

    elif right_green:
        green_state = "RIGHT"

    else:
        green_state = "NONE"

    #print("Gyro: ", gyro_value)






    #img.draw_rectangle(roi1,color = (0,0,255),thickness = 2)
    #img.draw_rectangle(roi2,color = (0,0,255),thickness = 2)
    #img.draw_rectangle(roi3,color = (0,0,255),thickness = 2)
    # img.draw_rectangle(roi4,color = (0,0,255),thickness = 2)
    # img.draw_rectangle(roi5,color = (0,0,255),thickness = 2)
    # img.draw_rectangle(roi6,color = (0,200,255),thickness = 2)
    # img.draw_rectangle(roi7,color = (0,200,255),thickness = 2)
    # img.draw_rectangle(roi8,color = (0,200,255),thickness = 2)

    # for blob in img.find_blobs((black), merge = True, invert = False,roi = roi1,pixels_threshold=1000):
    #     img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
    #     img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
    #     c1 = blob.cx() - 160

    # for blob in img.find_blobs((black), merge = True, invert = False,roi = roi2,pixels_threshold=1000):
    #     img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
    #     img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
    #     c2 = blob.cx() - 160

    # for blob in img.find_blobs((black), merge = True, invert = False,roi = roi3,pixels_threshold=1000):
    #     img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
    #     img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
    #     c3 = blob.cx() - 160

    # for blob in img.find_blobs((black), merge = True, invert = False,roi = roi4,pixels_threshold=1000):
    #     img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
    #     img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
    #     c4 = blob.cx() - 160

    # for blob in img.find_blobs((black), merge = True, invert = False,roi = roi5,pixels_threshold=1000):
    #     img.draw_rectangle(blob.rect(),color = (255,0,0),thickness = 2)
    #     img.draw_cross(blob.cx(),blob.cy(),(0,255,0),size=10)
    #     c5 = blob.cx() - 160

    # correction = int((5*c1+4*c2+3*c3+2*c4+1*c5)/12)
    # print(correction)
    # steer(correction)
    c1=c2=c3=c4=c5=0
    c6=c7=c8=0
    correction = 0

    if ramp_state == "F":
        #print("FLAT")

        speed = 50

        img.draw_rectangle(roi1, color=(0, 0, 255), thickness=2)
        img.draw_rectangle(roi2, color=(0 ,0, 255), thickness=2)
        img.draw_rectangle(roi3, color=(0, 0, 255), thickness=2)
        img.draw_rectangle(roi4, color=(0, 0, 255), thickness=2)
        #img.draw_rectangle(roi5, color=(0, 0, 255), thickness=2)

        for blob in img.find_blobs((black), merge=True, invert=False, roi=roi1, pixels_threshold=1000):
            img.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
            img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
            c1 = blob.cx() - 160

        for blob in img.find_blobs((black), merge=True, invert=False, roi=roi2, pixels_threshold=1000):
            img.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
            img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
            c2 = blob.cx() - 160

        for blob in img.find_blobs((black), merge=True, invert=False, roi=roi3, pixels_threshold=1000):
            img.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
            img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
            c3 = blob.cx() - 160

        for blob in img.find_blobs((black), merge=True, invert=False, roi=roi4, pixels_threshold=1000):
            img.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
            img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
            c4 = blob.cx() - 160

        # for blob in img.find_blobs((black), merge=True, invert=False, roi=roi5, pixels_threshold=1000):
        #     img.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
        #     img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
        #     c5 = blob.cx() - 160

        correction = int((5*c1 + 4*c2 + 3*c3 + 2*c4) / 8)


    elif ramp_state == "U":
        #print("UP")

        speed = 90

        img.draw_rectangle(roi6, color=(0, 200, 255), thickness=2)
        img.draw_rectangle(roi7, color=(0, 200, 255), thickness=2)
        img.draw_rectangle(roi8, color=(0, 200, 255), thickness=2)

        for blob in img.find_blobs((black), merge=True, invert=False, roi=roi6, pixels_threshold=1000):
            img.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
            img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
            c6 = blob.cx() - 160

        for blob in img.find_blobs((black), merge=True, invert=False, roi=roi7, pixels_threshold=1000):
            img.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
            img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
            c7 = blob.cx() - 160

        for blob in img.find_blobs((black), merge=True, invert=False, roi=roi8, pixels_threshold=1000):
            img.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
            img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
            c8 = blob.cx() - 160

        correction = int((3*c6 + 2*c7 + 1*c8) / 12)

    elif ramp_state == "D":
        #print("DOWN")

        speed = 55

        img.draw_rectangle(roi1, color=(0, 0, 255), thickness=2)
        img.draw_rectangle(roi2, color=(0, 0, 255), thickness=2)
        img.draw_rectangle(roi3, color=(0, 0, 255), thickness=2)
        img.draw_rectangle(roi4, color=(0, 0, 255), thickness=2)
        #img.draw_rectangle(roi5, color=(0, 0, 255), thickness=2)

        for blob in img.find_blobs((black), merge=True, invert=False, roi=roi1, pixels_threshold=1000):
            img.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
            img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
            c1 = blob.cx() - 160

        for blob in img.find_blobs((black), merge=True, invert=False, roi=roi2, pixels_threshold=1000):
            img.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
            img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
            c2 = blob.cx() - 160

        for blob in img.find_blobs((black), merge=True, invert=False, roi=roi3, pixels_threshold=1000):
            img.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
            img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
            c3 = blob.cx() - 160

        for blob in img.find_blobs((black), merge=True, invert=False, roi=roi4, pixels_threshold=1000):
            img.draw_rectangle(blob.rect(), color=(255 ,0, 0), thickness=2)
            img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
            c4 = blob.cx() - 160

        # for blob in img.find_blobs((black), merge=True, invert=False, roi=roi5, pixels_threshold=1000):
        #     img.draw_rectangle(blob.rect(), color=(255, 0, 0), thickness=2)
        #     img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
        #     c5 = blob.cx() - 160

        correction = int((5*c1 + 4*c2 + 3*c3 + 2*c4) / 12)

    # =========================================
    # GREEN ACTIONS
    # =========================================

    if green_state == "LEFT":

        print("LEFT GREEN")

        tank(-40, 40)
        time.sleep_ms(250)

    elif green_state == "RIGHT":

        print("RIGHT GREEN")

        tank(40, -40)
        time.sleep_ms(250)

    elif green_state == "DOUBLE":

        print("DOUBLE GREEN")

        tank(50, -50)
        time.sleep_ms(600)

    else:

        steer(correction)

    print(ramp_state, speed, correction, gyro_value)
    steer(correction)
