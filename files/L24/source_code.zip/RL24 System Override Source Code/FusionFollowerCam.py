import sensor,image, time, os, math, gc, pyb, math, uos
from pyb import UART
from os import listdir, chdir
from machine import Pin
from time import sleep_ms
import struct
from machine import Pin


sensor.reset()  # Reset and initialize the sensor.
sensor.set_pixformat(sensor.RGB565)  # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)  # Set frame size to QVGA (160x120)
sensor.skip_frames(time=1000)  # Wait for settings take effect.
clock = time.clock()  # Create a clock object to track the FPS.
sensor.set_vflip(True)
sensor.set_hmirror(True)

#uart = UART(3, 115200, timeout_char=1)

black = [0, 50, -10, 10, -10, 10]
black2 = [0, 20, -10, 10, -10, 10]
# GREEN THRESHOLD
green = [(50, 85, -60, -40, 30, 55)]

# FRONT GREEN ROI
roi = [0, 70, 320, 50]
roi2 = [0, 120, 320, 50]


green_state = "NONE"

p4 = Pin("P4", Pin.OUT_PP)
p5 = Pin("P5", Pin.OUT_PP)




while True:
    c = 0
    w1 = 0

    img = sensor.snapshot()

    for blob in img.find_blobs([black], merge=True, invert=False, roi=roi, area_threshold=1500):
        img.draw_rectangle(blob.rect(), color=(255 ,0, 0), thickness=2)
        img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
        c = blob.cx() - 160

    for blob in img.find_blobs([black2], merge=True, invert=False, roi=roi2, area_threshold=1500):
        img.draw_rectangle(blob.rect(), color=(255 ,0, 0), thickness=2)
        img.draw_cross(blob.cx(), blob.cy(), color=(0, 255, 0), size=10)
        c1 = blob.cx() - 160
        w1 = blob.w()



    green_state = "NONE"

    img.draw_rectangle(roi, color=(0,255,0), thickness=2)
    img.draw_rectangle(roi2, color=(0,255,0), thickness=2)

    green_blobs = img.find_blobs(green, roi=roi,merge=True, area_threshold=3000)

    left_green = False
    right_green = False

    greens= []

    for blob in green_blobs:

        img.draw_rectangle(blob.rect(), color=(0,0,255), thickness=2)
        img.draw_cross(blob.cx(), blob.cy(), color=(255,0,0), size=10)


        greens.append([blob.cx(), blob.cy()])

    if(len(greens) > 0):
        print("Greens")
        #print(greens)
        #print(c)
        for blob in greens:

            # LEFT SIDE
            if blob[0] - 160 < c:
                left_green = True

            # RIGHT SIDE
            elif blob[0] - 160 > c:
                right_green = True

        if left_green and right_green:
            green_state = "DOUBLE"

        elif left_green:
            green_state = "LEFT"


        elif right_green:
            green_state = "RIGHT"

        else:
            green_state = "NONE"

    if (w1 > 160):
        green_state = "NONE"

    # # GREEN ACTIONS

    if green_state == "LEFT":

        print("LEFT GREEN")
        p4.high()
        p5.low()

    elif green_state == "RIGHT":

        print("RIGHT GREEN")
        p5.high()
        p4.low()


    elif green_state == "DOUBLE":

        print("DOUBLE GREEN")
        p4.high()
        p5.high()

    else:

        print("NONE")
        p4.low()
        p5.low()

