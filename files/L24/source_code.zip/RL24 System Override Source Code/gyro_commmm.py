from pyb import UART

uart = UART(3, 115200)

pitch_angle = 0
roll_angle = 0

buffer = ""

while True:

    if uart.any():

        try:
            buffer += uart.read().decode()

            if "\n" in buffer:

                lines = buffer.split("\n")

                # keep newest unfinished chunk
                buffer = lines[-1]

                # ONLY newest full line
                latest = lines[-2]

                vals = latest.split(",")

                if len(vals) == 2:
                    pitch_angle = float(vals[0])
                    roll_angle = float(vals[1])

        except:
            pass

    # USE VALUES DIRECTLY HERE
    # NO PRINTS = MAX SPEED

    # Example:
    # if roll_angle < -8:
    #     uphill = True
