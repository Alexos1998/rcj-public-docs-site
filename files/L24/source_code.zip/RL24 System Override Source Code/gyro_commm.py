from pyb import UART
import time

uart = UART(3, 115200, timeout_char=100)

pitch_angle = 0
roll_angle = 0
ramp_state = "FLAT"

UPHILL_THRESHOLD = 8
DOWNHILL_THRESHOLD = -8

buffer = ""

def parse_line(line):
    global pitch_angle, roll_angle, ramp_state

    if not line.startswith("P:"):
        return

    if ",R:" not in line:
        return

    try:
        p_part, r_part = line.split(",R:")

        pitch_angle = float(p_part[2:])
        roll_angle = float(r_part)

        # Use roll OR pitch depending on your sensor mounting
        ramp_value = roll_angle

        if ramp_value > UPHILL_THRESHOLD:
            ramp_state = "DOWNHILL"
        elif ramp_value < DOWNHILL_THRESHOLD:
            ramp_state = "UPHILL"
        else:
            ramp_state = "FLAT"

        print("PITCH:", pitch_angle, "ROLL:", roll_angle, "STATE:", ramp_state)

    except:
        pass

while True:
    if uart.any():
        try:
            data = uart.read()

            if data:
                buffer += data.decode()

                if "\n" in buffer:
                    lines = buffer.split("\n")
                    buffer = lines[-1]

                    latest_line = lines[-2].strip()

                    if latest_line:
                        parse_line(latest_line)

        except:
            buffer = ""

    time.sleep_ms(1)
