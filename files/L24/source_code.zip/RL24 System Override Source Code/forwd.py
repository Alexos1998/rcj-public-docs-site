import sensor, image, time, os, math, uos, gc, pyb, math
from pyb import UART
from os import listdir, chdir
from machine import Pin
from time import sleep_ms
import math




sensor.reset()  # Reset and initialize the sensor.
sensor.set_pixformat(sensor.RGB565)  # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)  # Set frame size to QVGA (320x240)
sensor.skip_frames(time=1000)  # Wait for settings take effect.
clock = time.clock()  # Create a clock object to track the FPS.
sensor.set_vflip(True)
sensor.set_hmirror(True)

uart = UART(3,115200)
ramp_state = "F"

speed=60

def stopMotor():
    r1.value(0)
    r2.value(0)
    l1.value(0)
    l2.value(0)

def tank(p1,p2):
    if p1 > 0:
        l1.value(0)
        l2.value(1)
        enl.pulse_width_percent(abs(p1))
    elif p1 == 0:
        l1.value(0)
        l2.value(0)
    else:
        l1.value(1)
        l2.value(0)
        enl.pulse_width_percent(abs(p1))
    if p2 > 0:
        r1.value(0)
        r2.value(1)
        enr.pulse_width_percent(abs(p2))
    elif p2 == 0:
        r1.value(0)
        r2.value(0)
    else:
        r1.value(1)
        r2.value(0)
        enr.pulse_width_percent(abs(p2))
def steer(s):
    if s< -100:
        s=-100
    if s> 100:
        s=100
    if s<-50:
        r1.value(0)
        r2.value(1)
        enr.pulse_width_percent(speed)  # speed
        l1.value(1)
        l2.value(0)
        enl.pulse_width_percent(int((s+25)*-2))
    elif s<0:
        r1.value(0)
        r2.value(1)
        enr.pulse_width_percent(speed)
        l1.value(0)
        l2.value(1)
        enl.pulse_width_percent(int((s+25)*2))
    elif s==0:
        r1.value(0)
        r2.value(1)
        enr.pulse_width_percent(speed)
        l1.value(0)
        l2.value(1)
        enl.pulse_width_percent(speed)
    elif s<51:
        r1.value(0)
        r2.value(1)
        enr.pulse_width_percent(int((25-s)*2))
        l1.value(0)
        l2.value(1)
        enl.pulse_width_percent(speed)
    else:
        r1.value(1)
        r2.value(0)
        enr.pulse_width_percent(int((s-25)*2))
        l1.value(0)
        l2.value(1)
        enl.pulse_width_percent(speed)

def read_pico():
    global ramp_state

    if uart.any():
        try:
            msg = uart.readline()

            if msg:
                msg = msg.decode().strip()

                parts = msg.split(",")

                for p in parts:
                    if p.startswith("R:"):
                        ramp_state = p[2:]

        except:
            pass

#  motor pins

timer = pyb.Timer(4, freq=1000)
enr = timer.channel(1, pyb.Timer.PWM, pin=pyb.Pin('P7'))
r1 = pyb.Pin('P9', pyb.Pin.OUT_PP, pyb.Pin.PULL_NONE)
r2 = pyb.Pin('P2', pyb.Pin.OUT_PP, pyb.Pin.PULL_NONE)
enl = timer.channel(2, pyb.Timer.PWM, pin=pyb.Pin('P8'))
l2 = pyb.Pin('P5', pyb.Pin.OUT_PP, pyb.Pin.PULL_NONE)
l1 = pyb.Pin('P4', pyb.Pin.OUT_PP, pyb.Pin.PULL_NONE)
STBY = Pin("P3", Pin.OUT_PP)

STBY.high()

roi1 = [30, 0, 260, 48]
roi2 = [0, 48, 320, 48]
roi3 = [0, 96, 320, 48]
roi4 = [0, 144, 320, 48]
roi5 = [30, 192, 260, 48]
roi6 = [30, 180, 260, 55]
roi7 = [30, 134, 260, 55]
roi8 = [30, 86, 260, 55]

c1 = 0
c2 = 0
c3 = 0
c4 = 0
c5 = 0
# [low_l,low_h,low_l,low_h,low_l,low_h]
black = [(0, 10, -14, 0, 0, 18)]

while True:
    tank(100, 100)

