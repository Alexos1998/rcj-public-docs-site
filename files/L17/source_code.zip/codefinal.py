from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor
from pybricks.parameters import Port, Direction
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch

# --- Setup ---
hub = PrimeHub()
left_motor = Motor(Port.A, Direction.COUNTERCLOCKWISE)
right_motor = Motor(Port.B, Direction.CLOCKWISE)
left_sensor = ColorSensor(Port.C)
right_sensor = ColorSensor(Port.D)
obstacle_sensor = UltrasonicSensor(Port.E) # Front
# side_sensor = UltrasonicSensor(Port.F)     # Side
robot = DriveBase(left_motor, right_motor, wheel_diameter=56, axle_track=114)

# --- Constants & Variables ---
BASE_SPEED = 35 
KP, KI, KD = 9.0, 2.0, 26
last_error = 0
white_distance = 0
obstacle_count = 0  # Added for filtering ghost detections
gap_turned = False 

# Initialize timers
search_timer = StopWatch()
pid_timer = StopWatch()
retreat_timer = StopWatch()



def avoid_obstacle():
    print("Obstacle confirmed! Avoiding...")
    robot.stop()
    hub.speaker.beep()

    robot.turn(100)
    robot.straight(200) 

    robot.turn(-100)      
    while side_sensor.distance() < 250:
        robot.drive(BASE_SPEED, 0)
        wait(10)

    robot.straight(200)
    robot.turn(-80)
    robot.straight(170)

    while left_sensor.reflection() > 30 and right_sensor.reflection() > 30:
        robot.drive(BASE_SPEED, 0)
    robot.stop()
    robot.straight(50) 
    robot.turn(100)    
    print("Obstacle cleared.")



def check_green():
    l_hsv = left_sensor.hsv()
    r_hsv = right_sensor.hsv()
    left_found = 120 < l_hsv.h < 170 and l_hsv.s > 50
    right_found = 120 < r_hsv.h < 170 and r_hsv.s > 50

    if left_found or right_found:
        search_timer.reset()
        while search_timer.time() < 200: 
            robot.drive(20, 0)
            l_curr, r_curr = left_sensor.hsv(), right_sensor.hsv()
            if 120 < l_curr.h < 170 and l_curr.s > 50: left_found = True
            if 120 < r_curr.h < 170 and r_curr.s > 50: right_found = True
            if left_found and right_found: break 
        
        pid_timer.reset()
        last_err = 0
        while pid_timer.time() < 400: 
            error = left_sensor.reflection() - right_sensor.reflection()
            correction = (KP * error) + (KD * (error - last_err))
            robot.drive(BASE_SPEED, correction)
            last_err = error
            wait(10)
        
        robot.stop()
        is_verified = False
        retreat_timer.reset()
        while retreat_timer.time() < 800: 
            robot.drive(-30, 0)
            if left_sensor.reflection() < 30 or right_sensor.reflection() < 30:
                is_verified = True
                break
        
        robot.stop()
        if is_verified:
            robot.straight(15)
            if left_found and right_found:
                if left_sensor.reflection() < 30 and right_sensor.reflection() < 30:
                    robot.straight(30)
                    robot.turn(200)
            elif left_found:
                if left_sensor.reflection() < 30:
                    robot.straight(30)
                    robot.turn(-90)
            elif right_found:
                if right_sensor.reflection() < 30:
                    robot.straight(30)
                    robot.turn(90)
            return True
        else:
            return True 
    return False



def detect_red():
    # Get HSV values
    l_hsv = left_sensor.hsv()
    r_hsv = right_sensor.hsv()

    # Red Hue is usually < 10 or > 350. Saturation should be high (> 50).
    left_red = (l_hsv.h < 15 or l_hsv.h > 345) and l_hsv.s > 60
    right_red = (r_hsv.h < 15 or r_hsv.h > 345) and r_hsv.s > 60

    if left_red or right_red:
        return True
    return False


# --- MAIN LOOP ---
while True:
    # 0. Filtered Obstacle Detection
    dist = obstacle_sensor.distance()
    if 10 < dist < 120:  # Valid range check
        obstacle_count += 1
    else:
        obstacle_count = 0 # Reset if it was just a flicker
        
    if obstacle_count >= 3: # Must see it 3 times to believe it
        avoid_obstacle()
        obstacle_count = 0
        last_error = 0
        continue

    # 1. Green Logic
    if check_green():
        last_error = 0 
        continue

    # 2. Reading
    left_refl = left_sensor.reflection()
    right_refl = right_sensor.reflection()

    # 3. 90-degree logic
    if left_refl < 20 and right_refl > 80:
        robot.turn(-90)
        continue
    if right_refl < 20 and left_refl > 80:
        robot.turn(90)
        continue

    # 4. PID Calculation
    error = left_refl - right_refl
    derivative = error - last_error
    correction = (KP * error) + (KD * derivative)
    last_error = error

    # 5. Gap Handling
    if left_refl > 30 and right_refl > 30:
        if white_distance == 0:
            white_distance = robot.distance()
        
        if (robot.distance() - white_distance) > 10:
            # Perform the small left turn ONLY ONCE
            if gap_turned == False:
                robot.turn(-8)
                gap_turned = True 
            
            robot.drive(BASE_SPEED, 0) 
            print("Gap: Driving perfectly straight")
        else:
            robot.drive(BASE_SPEED, correction) 
    else:
        # Reset everything when we see the line again
        white_distance = 0
        gap_turned = False
        robot.drive(BASE_SPEED, correction)

    if detect_red():
        print("RED DETECTED: STOPPING")
        robot.stop()
        hub.speaker.beep(200, 500) # Long warning beep
        break # Exit the loop and end the program

    wait(10)
